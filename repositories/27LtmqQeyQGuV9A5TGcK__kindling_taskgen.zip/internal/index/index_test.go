package index_test

import (
	"reflect"
	"testing"
	"time"

	"github.com/dleblanc/kindling/internal/index"
	"github.com/dleblanc/kindling/internal/record"
)

func rec(level, service string, fields map[string]string) *record.Record {
	r := &record.Record{
		Timestamp: time.Now(),
		Level:     level,
		Service:   service,
		Fields:    map[string]string{"level": level, "service": service},
	}
	for k, v := range fields {
		r.Fields[k] = v
	}
	return r
}

func TestEmptyIndex(t *testing.T) {
	idx := index.New()
	if idx.Count() != 0 {
		t.Errorf("expected zero count")
	}
	if got := idx.Lookup("level", "info"); got != nil {
		t.Errorf("got %v", got)
	}
}

func TestAddAndLookup(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "auth", nil))
	idx.Add(2, rec("info", "users", nil))
	idx.Add(3, rec("warn", "auth", nil))
	got := idx.Lookup("level", "info")
	if !reflect.DeepEqual(got, []uint64{1, 2}) {
		t.Errorf("got %v", got)
	}
}

func TestKeysSorted(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "auth", map[string]string{"region": "us"}))
	keys := idx.Keys()
	for i := 1; i < len(keys); i++ {
		if keys[i-1] > keys[i] {
			t.Errorf("not sorted: %v", keys)
		}
	}
}

func TestCardinality(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "a", nil))
	idx.Add(2, rec("info", "b", nil))
	idx.Add(3, rec("info", "c", nil))
	if got := idx.Cardinality("service"); got != 3 {
		t.Errorf("got %d", got)
	}
}

func TestIntersect(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "auth", nil))
	idx.Add(2, rec("info", "users", nil))
	idx.Add(3, rec("warn", "auth", nil))
	idx.Add(4, rec("info", "auth", nil))
	got := idx.Intersect(map[string]string{"level": "info", "service": "auth"})
	want := []uint64{1, 4}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got %v want %v", got, want)
	}
}

func TestIntersectEmpty(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "auth", nil))
	got := idx.Intersect(map[string]string{"missing": "x"})
	if got != nil {
		t.Errorf("got %v", got)
	}
}

func TestIntersectNoMatch(t *testing.T) {
	idx := index.New()
	idx.Add(1, rec("info", "auth", nil))
	got := idx.Intersect(map[string]string{"level": "info", "service": "users"})
	if got != nil {
		t.Errorf("got %v", got)
	}
}

func TestCount(t *testing.T) {
	idx := index.New()
	for i := uint64(0); i < 10; i++ {
		idx.Add(i, rec("info", "auth", nil))
	}
	if idx.Count() != 10 {
		t.Errorf("got %d", idx.Count())
	}
}
