package rex

import (
	"rex/internal/compile"
	"rex/internal/match"
	"rex/internal/walk"
)

type Regexp struct {
	compiled *compile.Compiled
}

func Compile(pattern string) (*Regexp, error) {
	c, err := compile.Compile(pattern)
	if err != nil {
		return nil, err
	}

	return &Regexp{compiled: c}, nil
}

func MustCompile(pattern string) *Regexp {
	r, err := Compile(pattern)
	if err != nil {
		panic("rex: bad pattern: " + err.Error())
	}
	return r
}

func (r *Regexp) Match(s string) bool {
	m := match.NewMatcher(r.compiled)
	return m.FullMatch(s)
}

func (r *Regexp) Find(s string) (string, bool) {
	m := match.NewMatcher(r.compiled)
	res := m.Find(s)
	if !res.Matched {
		return "", false
	}
	return s[res.Start:res.End], true
}

func (r *Regexp) FindAll(s string) []string {
	m := match.NewMatcher(r.compiled)
	var out []string
	mr := m.FindAll(s)

	for _, res := range mr.Matches {
		out = append(out, s[res.Start:res.End])
	}

	return out
}

func (r *Regexp) Groups(s string) (map[string]string, bool) {
	m := match.NewMatcher(r.compiled)
	res := m.FindGroups(s)

	if !res.Matched {
		return nil, false
	}

	out := make(map[string]string)

	for name, span := range res.GroupNames {
		out[name] = s[span.Start:span.End]
	}

	return out, true
}

func (r *Regexp) NFAStates() int {
	return r.compiled.NFA.StateCount()
}

func (r *Regexp) ASTNodes() int {
	return walk.NodeCount(r.compiled.AST)
}

func (r *Regexp) String() string {
	return r.compiled.Pattern
}
