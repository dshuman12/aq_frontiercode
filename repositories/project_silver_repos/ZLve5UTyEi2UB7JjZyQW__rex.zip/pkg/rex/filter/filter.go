package filter

import (
	"rex/internal/compile"
	"rex/internal/prefilter"
)

type Filter struct {
	bm      *prefilter.BM
	Literal string
}

func New(pattern string) (*Filter, error) {
	compiled, err := compile.Compile(pattern)

	if err != nil {
		return nil, err
	}

	lit := prefilter.ExtractLiteral(compiled.AST)
	var bm *prefilter.BM

	if lit != "" {
		bm = prefilter.NewBM(lit)
	}

	return &Filter{bm: bm, Literal: lit}, nil
}

func (f *Filter) MightMatch(text string) bool {
	if f.bm == nil {
		return true
	}
	return f.bm.Search(text) >= 0
}
