package stats

import (
	"rex/internal/compile"
	"rex/internal/walk"
)

type PatternStats struct {
	Pattern    string
	ASTNodes   int
	ASTDepth   int
	NFAStates  int
	DFAStates  int
	HasGroups  bool
	GroupCount int
}

func Analyze(pattern string) (*PatternStats, error) {
	compiled, err := compile.Compile(pattern)
	if err != nil {
		return nil, err
	}

	s := &PatternStats{
		Pattern:   pattern,
		ASTNodes:  walk.NodeCount(compiled.AST),
		ASTDepth:  walk.MaxDepth(compiled.AST),
		NFAStates: compiled.NFA.StateCount(),
	}

	if compiled.Groups > 0 {
		s.HasGroups = true
		s.GroupCount = compiled.Groups
	}

	if err := compiled.BuildDFA(); err == nil && compiled.DFA != nil {
		s.DFAStates = len(compiled.DFA.States)
	}

	return s, nil
}
