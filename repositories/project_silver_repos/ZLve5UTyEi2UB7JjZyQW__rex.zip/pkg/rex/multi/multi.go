package multi

type State struct {
	children [256]*State
	fail     *State
	output   []int
}

type Matcher struct {
	root     *State
	patterns []string
}

func New(patterns []string) *Matcher {
	m := &Matcher{root: &State{}, patterns: patterns}
	m.build(patterns)
	return m
}

func (m *Matcher) build(patterns []string) {
	for idx, p := range patterns {
		cur := m.root

		for i := 0; i < len(p); i++ {
			c := p[i]
			if cur.children[c] == nil {
				cur.children[c] = &State{}
			}
			cur = cur.children[c]
		}

		cur.output = append(cur.output, idx)
	}

	queue := make([]*State, 0, 64)

	for c := range 256 {
		ch := m.root.children[c]
		if ch == nil {
			m.root.children[c] = m.root
		} else {
			ch.fail = m.root
			queue = append(queue, ch)
		}
	}

	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		cur.output = append(cur.output, cur.fail.output...)

		for c := range 256 {
			ch := cur.children[c]
			if ch == nil {
				cur.children[c] = cur.fail.children[c]
			} else {
				ch.fail = cur.fail.children[c]
				queue = append(queue, ch)
			}
		}
	}
}

type Match struct {
	PatternIdx int
	Pattern    string
	Start      int
	End        int
}

func (m *Matcher) FindAll(text string) []Match {
	var out []Match
	cur := m.root

	for i := 0; i < len(text); i++ {
		cur = cur.children[text[i]]

		for _, idx := range cur.output {
			p := m.patterns[idx]
			start := i - len(p) + 1
			out = append(out, Match{
				PatternIdx: idx,
				Pattern:    p,
				Start:      start,
				End:        i + 1,
			})
		}
	}

	return out
}
