package anchor

type Kind int

const (
	Start Kind = iota
	End
	Word
	NonWord
)

func (k Kind) String() string {
	switch k {
	case Start:
		return "^"
	case End:
		return "$"
	case Word:
		return "\\b"
	case NonWord:
		return "\\B"
	}
	return "?"
}

func isWordRune(r rune) bool {
	return (r >= 'a' && r <= 'z') ||
		(r >= 'A' && r <= 'Z') ||
		(r >= '0' && r <= '9') ||
		r == '_'
}

func atWordEdge(input string, pos int) bool {
	left := false
	if pos > 0 {
		left = isWordRune(rune(input[pos-1]))
	}

	right := false
	if pos < len(input) {
		right = isWordRune(rune(input[pos]))
	}

	return left != right
}

func Check(kind Kind, input string, pos int) bool {
	switch kind {
	case Start:
		return pos == 0
	case End:
		return pos == len(input)
	case Word:
		return atWordEdge(input, pos)
	case NonWord:
		return !atWordEdge(input, pos)
	}
	return false
}
