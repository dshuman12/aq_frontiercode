package explain

import (
	"fmt"
	"strings"

	"rex/internal/parser"
	"rex/internal/posixcc"
	"rex/internal/quantifier"
)

func Pattern(root *parser.Node) string {
	var b strings.Builder
	b.WriteString("pattern breakdown:\n")
	explainNode(&b, root, 0)
	return b.String()
}

func explainNode(b *strings.Builder, n *parser.Node, depth int) {
	if n == nil {
		return
	}

	indent := strings.Repeat("  ", depth)

	switch n.Kind {
	case parser.KindLiteral:
		ch := fmt.Sprintf("'%c'", n.Ch)

		switch n.Ch {
		case '\n':
			ch = "'\\n'"
		case '\t':
			ch = "'\\t'"
		}
		fmt.Fprintf(b, "%schar %s\n", indent, ch)

	case parser.KindDot:
		fmt.Fprintf(b, "%sany character (except newline)\n", indent)

	case parser.KindConcat:
		fmt.Fprintf(b, "%ssequence:\n", indent)
		for _, ch := range n.Children {
			explainNode(b, ch, depth+1)
		}

	case parser.KindAltern:
		fmt.Fprintf(b, "%seither:\n", indent)

		for i, ch := range n.Children {
			if i > 0 {
				fmt.Fprintf(b, "%sor:\n", indent)
			}
			explainNode(b, ch, depth+1)
		}

	case parser.KindRepeat:
		if n.Op == parser.OpRange {
			min := n.Min
			max := n.Max
			mode := "greedy"

			if n.Lazy {
				mode = "lazy"
			}

			desc := fmt.Sprintf("repeat ({%d,%d}, %s): min=%d", min, max, mode, min)

			if max < 0 {
				desc = fmt.Sprintf("repeat ({%d,}, %s): min=%d max=unlimited", min, mode, min)
			} else {
				desc += fmt.Sprintf(" max=%d", max)
			}

			fmt.Fprintf(b, "%s%s\n", indent, desc)
			explainNode(b, n.Child, depth+1)

			return
		}

		qk := quantifier.Star

		switch n.Op {
		case parser.OpPlus:
			qk = quantifier.Plus
		case parser.OpQuestion:
			qk = quantifier.Question
		}

		min, max := qk.MinMax()
		mode := "greedy"
		if n.Lazy {
			mode = "lazy"
		}
		desc := fmt.Sprintf("repeat (%s, %s): min=%d", qk.String(), mode, min)

		if max < 0 {
			desc += " max=unlimited"
		} else {
			desc += fmt.Sprintf(" max=%d", max)
		}

		fmt.Fprintf(b, "%s%s\n", indent, desc)
		explainNode(b, n.Child, depth+1)

	case parser.KindGroup:
		switch {
		case !n.Capturing:
			fmt.Fprintf(b, "%snon-capturing group:\n", indent)
		case n.GroupName != "":
			fmt.Fprintf(b, "%sgroup %d (name=%s):\n", indent, n.GroupIdx, n.GroupName)
		default:
			fmt.Fprintf(b, "%sgroup %d:\n", indent, n.GroupIdx)
		}
		explainNode(b, n.Child, depth+1)

	case parser.KindCharClass:
		classDesc := classDescription(n.Ranges)
		if n.Negated {
			fmt.Fprintf(b, "%snot one of: %s\n", indent, classDesc)
		} else {
			fmt.Fprintf(b, "%sone of: %s\n", indent, classDesc)
		}

	case parser.KindAnchorStart:
		fmt.Fprintf(b, "%sstart of string\n", indent)

	case parser.KindAnchorEnd:
		fmt.Fprintf(b, "%send of string\n", indent)

	case parser.KindWordBoundary:
		if n.Negated {
			fmt.Fprintf(b, "%snon-word-boundary\n", indent)
		} else {
			fmt.Fprintf(b, "%sword boundary\n", indent)
		}
	}
}

func rangesStr(ranges []parser.CharRange) string {
	var parts []string
	for _, r := range ranges {
		if r.Lo == r.Hi {
			parts = append(parts, fmt.Sprintf("'%c'", r.Lo))
		} else {
			parts = append(parts, fmt.Sprintf("'%c'-'%c'", r.Lo, r.Hi))
		}
	}
	return strings.Join(parts, ", ")
}

func classDescription(ranges []parser.CharRange) string {
	for _, name := range posixcc.Names() {
		class := posixcc.Lookup(name)
		if class == nil || len(class.Ranges) != len(ranges) {
			continue
		}
		match := true

		for i, r := range ranges {
			if rune(r.Lo) != class.Ranges[i][0] || rune(r.Hi) != class.Ranges[i][1] {
				match = false
				break
			}
		}

		if match {
			return "[:" + name + ":]"
		}
	}

	return rangesStr(ranges)
}
