package cli

import (
	"fmt"
	"os"
	"strconv"
)

type Flags struct {
	Args  []string
	Named map[string]string
}

func Parse(args []string) *Flags {
	f := &Flags{
		Named: make(map[string]string),
	}

	i := 0
	for i < len(args) {
		arg := args[i]
		if len(arg) > 2 && arg[:2] == "--" {
			key := arg[2:]

			eqIdx := -1

			for j := 0; j < len(key); j++ {
				if key[j] == '=' {
					eqIdx = j
					break
				}
			}

			if eqIdx >= 0 {
				f.Named[key[:eqIdx]] = key[eqIdx+1:]
			} else {
				f.Named[key] = "true"
			}
		} else {
			f.Args = append(f.Args, arg)
		}
		i++
	}

	return f
}

func (f *Flags) Get(name, defaultVal string) string {
	if v, ok := f.Named[name]; ok {
		return v
	}
	return defaultVal
}

func (f *Flags) GetInt(name string, defaultVal int) int {
	s := f.Get(name, "")

	if s == "" {
		return defaultVal
	}

	n, err := strconv.Atoi(s)

	if err != nil {
		return defaultVal
	}

	return n
}

func (f *Flags) Has(name string) bool {
	_, ok := f.Named[name]
	return ok
}

func (f *Flags) Positional(i int) string {
	if i >= len(f.Args) {
		return ""
	}
	return f.Args[i]
}

func (f *Flags) RequirePositional(i int, name string) string {
	v := f.Positional(i)

	if v == "" {
		fmt.Fprintf(os.Stderr, "missing required argument: %s\n", name)
		os.Exit(1)
	}

	return v
}

func (f *Flags) SetDefault(name, value string) {
	if _, ok := f.Named[name]; !ok {
		f.Named[name] = value
	}
}
