package convert

import "strings"

func GlobToRegex(glob string) string {
	var b strings.Builder
	b.WriteString("^")
	i := 0

	for i < len(glob) {
		ch := glob[i]
		switch ch {
		case '*':
			b.WriteString(".*")
		case '?':
			b.WriteString(".")
		case '[':
			j := strings.IndexByte(glob[i:], ']')
			if j < 0 {
				b.WriteString(`\[`)
			} else {
				b.WriteString(glob[i : i+j+1])
				i += j
			}
		case '.', '+', '^', '$', '{', '}', '(', ')', '|', '\\':
			b.WriteByte('\\')
			b.WriteByte(ch)
		default:
			b.WriteByte(ch)
		}
		i++
	}

	b.WriteString("$")
	return b.String()
}

func LikeToRegex(like string) string {
	var b strings.Builder
	b.WriteString("^")
	i := 0

	for i < len(like) {
		ch := like[i]
		switch ch {
		case '%':
			b.WriteString(".*")
		case '_':
			b.WriteString(".")
		case '\\':
			if i+1 < len(like) {
				i++
				b.WriteByte('\\')
				b.WriteByte(like[i])
			} else {
				b.WriteString(`\\`)
			}
		case '.', '+', '*', '?', '^', '$', '{', '}', '[', ']', '(', ')', '|':
			b.WriteByte('\\')
			b.WriteByte(ch)
		default:
			b.WriteByte(ch)
		}
		i++
	}

	b.WriteString("$")
	return b.String()
}
