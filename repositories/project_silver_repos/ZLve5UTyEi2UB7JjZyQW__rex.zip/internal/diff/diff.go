package diff

import (
	"fmt"
	"strings"

	"rex/internal/parser"
)

type Change struct {
	Path string
	A    string
	B    string
}

func Diff(a, b *parser.Node) []Change {
	var changes []Change
	diffNode(a, b, "root", &changes)
	return changes
}

func diffNode(a, b *parser.Node, path string, changes *[]Change) {
	if a == nil && b == nil {
		return
	}

	if a == nil {
		*changes = append(*changes, Change{Path: path, A: "<nil>", B: b.String()})
		return
	}

	if b == nil {
		*changes = append(*changes, Change{Path: path, A: a.String(), B: "<nil>"})
		return
	}

	if a.Kind != b.Kind {
		*changes = append(*changes, Change{
			Path: path,
			A:    fmt.Sprintf("kind=%v", a.Kind),
			B:    fmt.Sprintf("kind=%v", b.Kind),
		})
		return
	}

	if a.Ch != b.Ch {
		*changes = append(*changes, Change{
			Path: path,
			A:    fmt.Sprintf("ch=%q", a.Ch),
			B:    fmt.Sprintf("ch=%q", b.Ch),
		})
	}

	if a.Min != b.Min || a.Max != b.Max {
		*changes = append(*changes, Change{
			Path: path,
			A:    fmt.Sprintf("quant={%d,%d}", a.Min, a.Max),
			B:    fmt.Sprintf("quant={%d,%d}", b.Min, b.Max),
		})
	}

	if a.GroupIdx != b.GroupIdx {
		*changes = append(*changes, Change{
			Path: path,
			A:    fmt.Sprintf("group=%d", a.GroupIdx),
			B:    fmt.Sprintf("group=%d", b.GroupIdx),
		})
	}

	if a.Kind == parser.KindCharClass && !rangesEqual(a.Ranges, b.Ranges) {
		*changes = append(*changes, Change{
			Path: path,
			A:    fmt.Sprintf("ranges=%v negated=%v", a.Ranges, a.Negated),
			B:    fmt.Sprintf("ranges=%v negated=%v", b.Ranges, b.Negated),
		})
	}

	diffNode(a.Child, b.Child, path+".child", changes)
	maxch := max(len(b.Children), len(a.Children))

	for i := range maxch {
		var ac, bc *parser.Node
		if i < len(a.Children) {
			ac = a.Children[i]
		}
		if i < len(b.Children) {
			bc = b.Children[i]
		}
		diffNode(ac, bc, fmt.Sprintf("%s[%d]", path, i), changes)
	}
}

func rangesEqual(a, b []parser.CharRange) bool {
	if len(a) != len(b) {
		return false
	}

	for i := range a {
		if a[i].Lo != b[i].Lo || a[i].Hi != b[i].Hi {
			return false
		}
	}
	return true
}

func Format(changes []Change) string {
	if len(changes) == 0 {
		return "no differences"
	}

	var b strings.Builder
	for _, c := range changes {
		fmt.Fprintf(&b, "  %s: %s -> %s\n", c.Path, c.A, c.B)
	}
	return b.String()
}
