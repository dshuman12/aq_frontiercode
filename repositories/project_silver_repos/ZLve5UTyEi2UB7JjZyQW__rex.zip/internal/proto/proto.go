package proto

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"rex/internal/parser"
)

type SerialRange struct {
	Lo rune `json:"lo"`
	Hi rune `json:"hi"`
}

type SerialNode struct {
	Kind     string        `json:"kind"`
	Ch       rune          `json:"ch,omitempty"`
	Min      int           `json:"min,omitempty"`
	Max      int           `json:"max,omitempty"`
	Lazy     bool          `json:"lazy,omitempty"`
	Negated  bool          `json:"negated,omitempty"`
	Group    int           `json:"group,omitempty"`
	Name     string        `json:"name,omitempty"`
	Cap      bool          `json:"cap,omitempty"`
	Flags    uint32        `json:"flags,omitempty"`
	Ranges   []SerialRange `json:"ranges,omitempty"`
	Children []*SerialNode `json:"children,omitempty"`
	Child    *SerialNode   `json:"child,omitempty"`
}

func Marshal(root *parser.Node) ([]byte, error) {
	sn := toSerial(root)
	return json.MarshalIndent(sn, "", "  ")
}

func Unmarshal(data []byte) (*parser.Node, error) {
	var sn SerialNode
	if err := json.Unmarshal(data, &sn); err != nil {
		return nil, err
	}
	return fromSerial(&sn)
}

func toSerial(n *parser.Node) *SerialNode {
	if n == nil {
		return nil
	}
	s := &SerialNode{
		Kind:    kindName(n.Kind),
		Ch:      n.Ch,
		Min:     n.Min,
		Max:     n.Max,
		Lazy:    n.Lazy,
		Negated: n.Negated,
		Group:   n.GroupIdx,
		Name:    n.GroupName,
		Cap:     n.Capturing,
		Flags:   n.Flags,
		Child:   toSerial(n.Child),
	}

	for _, r := range n.Ranges {
		s.Ranges = append(s.Ranges, SerialRange{Lo: r.Lo, Hi: r.Hi})
	}

	for _, ch := range n.Children {
		s.Children = append(s.Children, toSerial(ch))
	}

	return s
}

func fromSerial(s *SerialNode) (*parser.Node, error) {
	if s == nil {
		return nil, nil
	}

	kind, err := parseKind(s.Kind)
	if err != nil {
		return nil, err
	}

	n := &parser.Node{
		Kind:      kind,
		Ch:        s.Ch,
		Min:       s.Min,
		Max:       s.Max,
		Lazy:      s.Lazy,
		Negated:   s.Negated,
		GroupIdx:  s.Group,
		GroupName: s.Name,
		Capturing: s.Cap,
		Flags:     s.Flags,
	}

	for _, r := range s.Ranges {
		n.Ranges = append(n.Ranges, parser.CharRange{Lo: r.Lo, Hi: r.Hi})
	}

	n.Child, err = fromSerial(s.Child)
	if err != nil {
		return nil, err
	}

	for _, ch := range s.Children {
		child, err := fromSerial(ch)
		if err != nil {
			return nil, err
		}
		n.Children = append(n.Children, child)
	}

	return n, nil
}

func kindName(k parser.NodeKind) string {
	switch k {
	case parser.KindLiteral:
		return "literal"
	case parser.KindDot:
		return "dot"
	case parser.KindCharClass:
		return "charclass"
	case parser.KindConcat:
		return "concat"
	case parser.KindAltern:
		return "altern"
	case parser.KindRepeat:
		return "repeat"
	case parser.KindGroup:
		return "group"
	case parser.KindAnchorStart:
		return "anchor_start"
	case parser.KindAnchorEnd:
		return "anchor_end"
	case parser.KindWordBoundary:
		return "word_boundary"

	default:
		return fmt.Sprintf("unknown_%d", k)
	}
}

func parseKind(s string) (parser.NodeKind, error) {
	switch strings.ToLower(s) {
	case "literal":
		return parser.KindLiteral, nil
	case "dot":
		return parser.KindDot, nil
	case "charclass":
		return parser.KindCharClass, nil
	case "concat":
		return parser.KindConcat, nil
	case "altern":
		return parser.KindAltern, nil
	case "repeat":
		return parser.KindRepeat, nil
	case "group":
		return parser.KindGroup, nil
	case "anchor_start":
		return parser.KindAnchorStart, nil
	case "anchor_end":
		return parser.KindAnchorEnd, nil
	case "word_boundary":
		return parser.KindWordBoundary, nil

	default:
		return 0, fmt.Errorf("unknown kind: %s", s)
	}
}

func SaveToFile(root *parser.Node, path string) error {
	data, err := Marshal(root)
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0644)
}

func LoadFromFile(path string) (*parser.Node, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return Unmarshal(data)
}
