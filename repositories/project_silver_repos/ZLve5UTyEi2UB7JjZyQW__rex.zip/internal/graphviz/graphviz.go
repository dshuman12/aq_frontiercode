package graphviz

import (
	"fmt"
	"strings"

	"rex/internal/dfa"
	"rex/internal/nfa"
)

func NFAToDOT(machine *nfa.NFA) string {
	var b strings.Builder
	b.WriteString("digraph NFA {\n")
	b.WriteString("  rankdir=LR;\n")

	visited := map[int]bool{}
	queue := []*nfa.State{machine.Start}
	var states []*nfa.State

	for len(queue) > 0 {
		s := queue[0]
		queue = queue[1:]
		if visited[s.ID] {
			continue
		}

		visited[s.ID] = true
		states = append(states, s)

		for _, arr := range s.Arrows {
			queue = append(queue, arr.Target)
		}
	}

	for _, s := range states {
		shape := "circle"
		if s.Accept {
			shape = "doublecircle"
		}
		fmt.Fprintf(&b, "  s%d [shape=%s label=\"q%d\"];\n", s.ID, shape, s.ID)
	}

	for _, s := range states {
		for _, arr := range s.Arrows {
			if arr.On == nil {
				fmt.Fprintf(&b, "  s%d -> s%d [label=\"eps\"];\n", s.ID, arr.Target.ID)
			} else {
				label := escapeDOT(arr.On.String())
				fmt.Fprintf(&b, "  s%d -> s%d [label=\"%s\"];\n", s.ID, arr.Target.ID, label)
			}
		}
	}

	b.WriteString("  __start [shape=none label=\"\"];\n")
	fmt.Fprintf(&b, "  __start -> s%d;\n", machine.Start.ID)
	b.WriteString("}\n")

	return b.String()
}

func DFAToDOT(d *dfa.DFA) string {
	var b strings.Builder
	b.WriteString("digraph DFA {\n")
	b.WriteString("  rankdir=LR;\n")

	for _, s := range d.States {
		shape := "circle"
		if s.Accept {
			shape = "doublecircle"
		}
		fmt.Fprintf(&b, "  d%d [shape=%s label=\"d%d\"];\n", s.ID, shape, s.ID)
	}

	for _, s := range d.States {
		for ch, t := range s.Transitions {
			if t == nil {
				continue
			}
			label := escapeDOT(string(ch))
			fmt.Fprintf(&b, "  d%d -> d%d [label=\"%s\"];\n", s.ID, t.ID, label)
		}
	}

	b.WriteString("  __start [shape=none label=\"\"];\n")
	fmt.Fprintf(&b, "  __start -> d%d;\n", d.Start.ID)
	b.WriteString("}\n")
	return b.String()
}

func escapeDOT(s string) string {
	s = strings.ReplaceAll(s, "\"", "\\\"")
	s = strings.ReplaceAll(s, "\n", "\\n")
	return s
}
