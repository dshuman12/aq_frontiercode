package quantifier

type QuantKind int

const (
	Star QuantKind = iota
	Plus
	Question
)

func (q QuantKind) String() string {
	switch q {
	case Star:
		return "*"
	case Plus:
		return "+"
	case Question:
		return "?"
	}
	return ""
}

func (q QuantKind) MinMax() (int, int) {
	switch q {
	case Star:
		return 0, -1
	case Plus:
		return 1, -1
	case Question:
		return 0, 1
	}
	return 0, 0
}

func (q QuantKind) CanBeEmpty() bool {
	return q == Star || q == Question
}
