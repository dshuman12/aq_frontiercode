package quantifier

import "fmt"

const RangeMaxBound = 1024

type Range struct {
	Min int
	Max int
}

func (r Range) Unbounded() bool {
	return r.Max < 0
}

func (r Range) Validate() error {
	if r.Min < 0 {
		return fmt.Errorf("range min must be non-negative, got %d", r.Min)
	}
	if r.Max >= 0 && r.Max < r.Min {
		return fmt.Errorf("range max %d less than min %d", r.Max, r.Min)
	}
	if r.Min > RangeMaxBound {
		return fmt.Errorf("range min %d exceeds limit %d", r.Min, RangeMaxBound)
	}
	if r.Max > RangeMaxBound {
		return fmt.Errorf("range max %d exceeds limit %d", r.Max, RangeMaxBound)
	}
	return nil
}

func (r Range) RequiredCopies() int {
	return r.Min
}

func (r Range) OptionalCopies() int {
	if r.Unbounded() {
		return 0
	}
	return r.Max - r.Min
}
