package quantifier

type Mode int

const (
	Greedy Mode = iota
	Lazy
)

func (m Mode) String() string {
	if m == Lazy {
		return "lazy"
	}
	return "greedy"
}

func ModeOf(lazy bool) Mode {
	if lazy {
		return Lazy
	}
	return Greedy
}

const (
	PrioPreferred = 1
	PrioDeferred  = 0
)

func LoopPriority(m Mode) int {
	if m == Lazy {
		return PrioDeferred
	}
	return PrioPreferred
}

func ExitPriority(m Mode) int {
	if m == Lazy {
		return PrioPreferred
	}
	return PrioDeferred
}
