package cache

import (
	"sync"

	"rex/internal/compile"
)

type Cache struct {
	mu      sync.RWMutex
	entries map[string]*compile.Compiled
	order   []string
	maxSize int
}

func New(maxSize int) *Cache {
	if maxSize <= 0 {
		maxSize = 64
	}

	return &Cache{
		entries: make(map[string]*compile.Compiled),
		maxSize: maxSize,
	}
}

var defaultCache = New(128)

func (c *Cache) Get(pattern string) (*compile.Compiled, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	entry, ok := c.entries[pattern]
	return entry, ok
}

func (c *Cache) Put(pattern string, compiled *compile.Compiled) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if _, exists := c.entries[pattern]; exists {
		return
	}

	for len(c.entries) >= c.maxSize && len(c.order) > 0 {
		oldest := c.order[0]
		c.order = c.order[1:]
		delete(c.entries, oldest)
	}

	c.entries[pattern] = compiled
	c.order = append(c.order, pattern)
}

func (c *Cache) GetOrCompile(pattern string) (*compile.Compiled, error) {
	if compiled, ok := c.Get(pattern); ok {
		return compiled, nil
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		return nil, err
	}

	c.Put(pattern, compiled)
	return compiled, nil
}

func (c *Cache) Size() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.entries)
}

func (c *Cache) Clear() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.entries = make(map[string]*compile.Compiled)
	c.order = nil
}

func DefaultCache() *Cache {
	return defaultCache
}
