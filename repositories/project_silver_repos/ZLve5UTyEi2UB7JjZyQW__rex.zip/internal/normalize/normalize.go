package normalize

import (
	"sort"

	"rex/internal/parser"
)

func Normalize(root *parser.Node) *parser.Node {
	if root == nil {
		return nil
	}
	return walk(root)
}

func walk(n *parser.Node) *parser.Node {
	out := *n
	for i, ch := range n.Children {
		out.Children[i] = walk(ch)
	}

	switch n.Kind {
	case parser.KindAltern:
		out.Children = sortAltern(out.Children)
	case parser.KindConcat:
		out.Children = flattenConcat(out.Children)
	}

	return &out
}

func sortAltern(children []*parser.Node) []*parser.Node {
	cp := make([]*parser.Node, len(children))
	copy(cp, children)
	sort.SliceStable(cp, func(i, j int) bool {
		return nodeKey(cp[i]) < nodeKey(cp[j])
	})
	return cp
}

func nodeKey(n *parser.Node) string {
	switch n.Kind {
	case parser.KindLiteral:
		return "L" + string(n.Ch)
	case parser.KindCharClass:
		return "C"
	case parser.KindGroup:
		return "G"
	default:
		return "Z"
	}
}

func flattenConcat(children []*parser.Node) []*parser.Node {
	var out []*parser.Node
	for _, ch := range children {
		if ch.Kind == parser.KindConcat {
			out = append(out, ch.Children...)
		} else {
			out = append(out, ch)
		}
	}
	return out
}
