package config

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"
)

type Config struct {
	DefaultFlags map[string]string
}

func Load() *Config {
	cfg := &Config{DefaultFlags: make(map[string]string)}

	candidates := []string{}
	if cwd, err := os.Getwd(); err == nil {
		candidates = append(candidates, filepath.Join(cwd, ".rexrc"))
	}

	if home, err := os.UserHomeDir(); err == nil {
		candidates = append(candidates, filepath.Join(home, ".rexrc"))
	}

	for _, path := range candidates {
		if _, err := os.Stat(path); err == nil {
			if err := parse(cfg, path); err == nil {
				break
			}
		}
	}
	return cfg
}

func parse(cfg *Config, path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		parts := strings.SplitN(line, "=", 2)

		if len(parts) == 2 {
			key := strings.TrimSpace(parts[0])
			val := strings.TrimSpace(parts[1])
			cfg.DefaultFlags[key] = val
		}
	}
	return scanner.Err()
}
