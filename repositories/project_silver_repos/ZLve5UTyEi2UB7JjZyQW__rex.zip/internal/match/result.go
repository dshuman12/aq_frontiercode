package match

type Span struct {
	Start int
	End   int
}

type Result struct {
	Matched    bool
	Start      int
	End        int
	Text       string
	Groups     []Span
	GroupNames map[string]Span
}

func (r Result) Pos() (int, int) {
	return r.Start, r.End
}

func (r Result) Len() int {
	return r.End - r.Start
}

type MultiResult struct {
	Matches []Result
	Count   int
}

func (mr MultiResult) Strings() []string {
	out := make([]string, len(mr.Matches))

	for i, m := range mr.Matches {
		out[i] = m.Text
	}

	return out
}

func (mr MultiResult) Positions() [][2]int {
	out := make([][2]int, len(mr.Matches))

	for i, m := range mr.Matches {
		out[i] = [2]int{m.Start, m.End}
	}
	return out
}
