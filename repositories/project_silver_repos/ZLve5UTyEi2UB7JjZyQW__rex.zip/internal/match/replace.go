package match

import (
	"strings"

	"rex/internal/compile"
	"rex/internal/nfa"
)

func Replace(c *compile.Compiled, input, replacement string) string {
	matches := nfa.FindAll(c.NFA, input)
	if len(matches) == 0 {
		return input
	}

	var buf strings.Builder
	prev := 0

	for _, m := range matches {
		buf.WriteString(input[prev:m.Start])
		buf.WriteString(replacement)
		prev = m.Start + m.Length
	}

	buf.WriteString(input[prev:])
	return buf.String()
}

func ReplaceFirst(c *compile.Compiled, input, replacement string) string {
	start, length, ok := nfa.FindFirst(c.NFA, input)
	if !ok {
		return input
	}

	var buf strings.Builder
	buf.WriteString(input[:start])
	buf.WriteString(replacement)
	buf.WriteString(input[start+length:])
	return buf.String()
}

func Split(c *compile.Compiled, input string) []string {
	matches := nfa.FindAll(c.NFA, input)
	if len(matches) == 0 {
		return []string{input}
	}

	var parts []string
	prev := 0

	for _, m := range matches {
		parts = append(parts, input[prev:m.Start])
		prev = m.Start + m.Length
	}

	parts = append(parts, input[prev:])
	return parts
}
