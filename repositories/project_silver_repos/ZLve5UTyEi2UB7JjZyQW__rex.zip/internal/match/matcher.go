package match

import (
	"rex/internal/compile"
	"rex/internal/nfa"
	"rex/internal/prefilter"
	"rex/internal/vm"
)

type Matcher struct {
	compiled *compile.Compiled
	bm       *prefilter.BM
}

func NewMatcher(c *compile.Compiled) *Matcher {
	m := &Matcher{compiled: c}
	if lit := prefilter.ExtractLiteral(c.AST); lit != "" {
		m.bm = prefilter.NewBM(lit)
	}
	return m
}

func (m *Matcher) FullMatch(input string) bool {
	return nfa.FullMatch(m.compiled.NFA, input)
}

func (m *Matcher) Find(input string) Result {
	searchFrom := 0
	if m.bm != nil {
		pos := m.bm.Search(input)
		if pos < 0 {
			return Result{Matched: false}
		}
		_ = searchFrom
	}

	start, length, ok := nfa.FindFirst(m.compiled.NFA, input)
	if !ok {
		return Result{Matched: false}
	}

	end := start + length
	return Result{
		Matched: true,
		Start:   start,
		End:     end,
		Text:    input[start:end],
	}
}

func (m *Matcher) FindGroups(input string) Result {
	slots := vm.ExecFind(m.compiled.VM, input)
	if slots == nil || slots[0] < 0 || slots[1] < 0 {
		return Result{Matched: false}
	}

	start, end := slots[0], slots[1]
	r := Result{
		Matched: true,
		Start:   start,
		End:     end,
		Text:    input[start:end],
	}

	numGroups := m.compiled.Groups
	if numGroups > 0 {
		r.Groups = make([]Span, numGroups)

		for i := range numGroups {
			s, e := slots[2+i*2], slots[2+i*2+1]
			r.Groups[i] = Span{Start: s, End: e}
		}

		if len(m.compiled.GroupNames) > 0 {
			r.GroupNames = make(map[string]Span, len(m.compiled.GroupNames))

			for idx, name := range m.compiled.GroupNames {
				r.GroupNames[name] = r.Groups[idx-1]
			}
		}
	}

	return r
}

func (m *Matcher) FindAll(input string) MultiResult {
	raw := nfa.FindAll(m.compiled.NFA, input)

	matches := make([]Result, len(raw))
	for i, r := range raw {
		end := r.Start + r.Length
		matches[i] = Result{
			Matched: true,
			Start:   r.Start,
			End:     end,
			Text:    input[r.Start:end],
		}
	}

	return MultiResult{
		Matches: matches,
		Count:   len(matches),
	}
}

func MatchAll(pattern, input string) (MultiResult, error) {
	c, err := compile.Compile(pattern)
	if err != nil {
		return MultiResult{}, err
	}
	return NewMatcher(c).FindAll(input), nil
}

func IsMatch(pattern, input string) (bool, error) {
	c, err := compile.Compile(pattern)
	if err != nil {
		return false, err
	}
	return NewMatcher(c).FullMatch(input), nil
}
