package limit

import (
	"fmt"
	"io"
)

type Writer struct {
	out   io.Writer
	n     int
	max   int
	trunc bool
}

func New(w io.Writer, max int) *Writer {
	return &Writer{out: w, max: max}
}

func (w *Writer) Write(p []byte) (int, error) {
	if w.trunc {
		return len(p), nil
	}

	if w.max <= 0 {
		return w.out.Write(p)
	}

	rem := w.max - w.n
	if rem <= 0 {
		w.trunc = true
		fmt.Fprintf(w.out, "\n... output truncated ...\n")
		return len(p), nil
	}

	if len(p) > rem {
		p = p[:rem]
		w.trunc = true
	}

	n, err := w.out.Write(p)
	w.n += n

	if w.trunc {
		fmt.Fprintf(w.out, "\n... output truncated ...\n")
	}
	return n, err
}

func (w *Writer) Truncated() bool {
	return w.trunc
}
