package hashcons

import (
	"fmt"
	"strings"

	"rex/internal/parser"
)

type Table struct {
	nodes map[string]*parser.Node
}

func New() *Table {
	return &Table{nodes: make(map[string]*parser.Node)}
}

func (t *Table) Intern(n *parser.Node) *parser.Node {
	key := nodeKey(n)
	if existing, ok := t.nodes[key]; ok {
		return existing
	}

	t.nodes[key] = n
	return n
}

func (t *Table) Size() int {
	return len(t.nodes)
}

func (t *Table) InternAll(root *parser.Node) *parser.Node {
	if root == nil {
		return nil
	}

	for i, ch := range root.Children {
		root.Children[i] = t.InternAll(ch)
	}

	if root.Child != nil {
		root.Child = t.InternAll(root.Child)
	}

	return t.Intern(root)
}

func nodeKey(n *parser.Node) string {
	if n == nil {
		return "nil"
	}

	var childKeys strings.Builder

	for _, ch := range n.Children {
		childKeys.WriteString("|" + nodeKey(ch))
	}

	return fmt.Sprintf("%d:%c:%d:%d:%s:%s",
		n.Kind, n.Ch, n.Min, n.Max,
		nodeKey(n.Child),
		childKeys.String(),
	)
}
