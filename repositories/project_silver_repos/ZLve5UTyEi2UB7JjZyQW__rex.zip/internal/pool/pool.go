package pool

import "sync"

type StateSet struct {
	ids  map[int]bool
	list []int
}

func NewStateSet() *StateSet {
	return &StateSet{
		ids: make(map[int]bool),
	}
}

func (s *StateSet) Add(id int) {
	if !s.ids[id] {
		s.ids[id] = true
		s.list = append(s.list, id)
	}
}

func (s *StateSet) Contains(id int) bool {
	return s.ids[id]
}

func (s *StateSet) Clear() {
	for k := range s.ids {
		delete(s.ids, k)
	}
	s.list = s.list[:0]
}

func (s *StateSet) Len() int {
	return len(s.list)
}

func (s *StateSet) IDs() []int {
	return s.list
}

var setPool = sync.Pool{
	New: func() any {
		return NewStateSet()
	},
}

func GetStateSet() *StateSet {
	s := setPool.Get().(*StateSet)
	s.Clear()
	return s
}

func PutStateSet(s *StateSet) {
	s.Clear()
	setPool.Put(s)
}
