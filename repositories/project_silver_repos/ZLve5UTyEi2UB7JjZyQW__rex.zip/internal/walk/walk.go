package walk

import "rex/internal/parser"

type Visitor interface {
	Enter(n *parser.Node) bool
	Leave(n *parser.Node)
}

func Walk(root *parser.Node, v Visitor) {
	if root == nil {
		return
	}

	if !v.Enter(root) {
		return
	}

	for _, ch := range root.Children {
		Walk(ch, v)
	}

	if root.Child != nil {
		Walk(root.Child, v)
	}

	v.Leave(root)
}

type countVisitor struct {
	total int
}

func (c *countVisitor) Enter(n *parser.Node) bool {
	c.total++
	return true
}

func (c *countVisitor) Leave(n *parser.Node) {}

func NodeCount(root *parser.Node) int {
	v := &countVisitor{}
	Walk(root, v)
	return v.total
}

type depthVisitor struct {
	cur int
	max int
}

func (d *depthVisitor) Enter(n *parser.Node) bool {
	d.cur++
	if d.cur > d.max {
		d.max = d.cur
	}
	return true
}

func (d *depthVisitor) Leave(n *parser.Node) {
	d.cur--
}

func MaxDepth(root *parser.Node) int {
	v := &depthVisitor{}
	Walk(root, v)
	return v.max
}

type kindCollector struct {
	target parser.NodeKind
	nodes  []*parser.Node
}

func (k *kindCollector) Enter(n *parser.Node) bool {
	if n.Kind == k.target {
		k.nodes = append(k.nodes, n)
	}
	return true
}

func (k *kindCollector) Leave(n *parser.Node) {}

func FindAll(root *parser.Node, kind parser.NodeKind) []*parser.Node {
	v := &kindCollector{target: kind}
	Walk(root, v)
	return v.nodes
}
