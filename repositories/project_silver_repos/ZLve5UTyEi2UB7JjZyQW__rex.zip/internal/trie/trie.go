package trie

type Node struct {
	children map[byte]*Node
	terminal bool
	value    int
}

type Trie struct {
	root *Node
}

func New() *Trie {
	return &Trie{root: &Node{children: make(map[byte]*Node)}}
}

func (t *Trie) Insert(key string, value int) {
	cur := t.root

	for i := 0; i < len(key); i++ {
		c := key[i]
		if cur.children[c] == nil {
			cur.children[c] = &Node{children: make(map[byte]*Node)}
		}
		cur = cur.children[c]
	}

	cur.terminal = true
	cur.value = value
}

func (t *Trie) Search(key string) (int, bool) {
	cur := t.root

	for i := 0; i < len(key); i++ {
		c := key[i]
		if cur.children[c] == nil {
			return 0, false
		}
		cur = cur.children[c]
	}

	return cur.value, cur.terminal
}

func (t *Trie) HasPrefix(s string) bool {
	cur := t.root

	for i := 0; i < len(s); i++ {
		c := s[i]
		if cur.children[c] == nil {
			return false
		}
		cur = cur.children[c]
		if cur.terminal {
			return true
		}
	}

	return false
}

func (t *Trie) AllWithPrefix(prefix string) []string {
	cur := t.root

	for i := 0; i < len(prefix); i++ {
		c := prefix[i]
		if cur.children[c] == nil {
			return nil
		}
		cur = cur.children[c]
	}

	var results []string
	collect(cur, prefix, &results)

	return results
}

func collect(n *Node, prefix string, results *[]string) {
	if n.terminal {
		*results = append(*results, prefix)
	}

	for c, child := range n.children {
		collect(child, prefix+string([]byte{c}), results)
	}
}

func (t *Trie) Size() int {
	return countNodes(t.root)
}

func countNodes(n *Node) int {
	if n == nil {
		return 0
	}

	count := 1
	for _, ch := range n.children {
		count += countNodes(ch)
	}

	return count
}
