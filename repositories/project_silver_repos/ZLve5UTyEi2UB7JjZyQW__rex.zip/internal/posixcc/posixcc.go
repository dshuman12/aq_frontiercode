package posixcc

import "unicode"

type Class struct {
	Name   string
	Table  *unicode.RangeTable
	Ranges [][2]rune
}

var classes = map[string]*Class{
	"alpha": {
		Name:  "alpha",
		Table: unicode.Letter,
		Ranges: [][2]rune{
			{'A', 'Z'},
			{'a', 'z'},
		},
	},
	"digit": {
		Name:  "digit",
		Table: unicode.Digit,
		Ranges: [][2]rune{
			{'0', '9'},
		},
	},
	"alnum": {
		Name: "alnum",
		Ranges: [][2]rune{
			{'0', '9'},
			{'A', 'Z'},
			{'a', 'z'},
		},
	},
	"space": {
		Name: "space",
		Ranges: [][2]rune{
			{'\t', '\r'},
			{' ', ' '},
		},
	},
	"upper": {
		Name: "upper",
		Ranges: [][2]rune{
			{'A', 'Z'},
		},
	},
	"lower": {
		Name: "lower",
		Ranges: [][2]rune{
			{'a', 'z'},
		},
	},
	"punct": {
		Name: "punct",
		Ranges: [][2]rune{
			{'!', '/'},
			{':', '@'},
			{'[', '`'},
			{'{', '~'},
		},
	},
	"xdigit": {
		Name: "xdigit",
		Ranges: [][2]rune{
			{'0', '9'},
			{'A', 'F'},
			{'a', 'f'},
		},
	},
	"blank": {
		Name: "blank",
		Ranges: [][2]rune{
			{'\t', '\t'},
			{' ', ' '},
		},
	},
	"print": {
		Name: "print",
		Ranges: [][2]rune{
			{' ', '~'},
		},
	},
	"graph": {
		Name: "graph",
		Ranges: [][2]rune{
			{'!', '~'},
		},
	},
	"cntrl": {
		Name: "cntrl",
		Ranges: [][2]rune{
			{0, '\x1f'},
			{'\x7f', '\x7f'},
		},
	},
}

func Lookup(name string) *Class {
	return classes[name]
}

func Names() []string {
	out := make([]string, 0, len(classes))

	for k := range classes {
		out = append(out, k)
	}

	return out
}

func Contains(name string, r rune) bool {
	c := classes[name]

	if c == nil {
		return false
	}

	for _, rng := range c.Ranges {
		if r >= rng[0] && r <= rng[1] {
			return true
		}
	}
	return false
}
