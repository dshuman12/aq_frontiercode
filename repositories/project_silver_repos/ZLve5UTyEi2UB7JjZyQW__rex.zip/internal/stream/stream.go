package stream

import (
	"bufio"
	"io"

	"rex/internal/nfa"
)

type Match struct {
	Line    int
	Content string
	Start   int
	End     int
}

func Find(machine *nfa.NFA, r io.Reader) ([]Match, error) {
	scanner := bufio.NewScanner(r)
	var results []Match
	lineNum := 0

	for scanner.Scan() {
		lineNum++
		line := scanner.Text()
		start, length, ok := nfa.FindFirst(machine, line)

		if ok {
			results = append(results, Match{
				Line:    lineNum,
				Content: line,
				Start:   start,
				End:     start + length,
			})
		}
	}
	
	return results, scanner.Err()
}
