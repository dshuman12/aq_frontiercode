package repl

import (
	"bufio"
	"fmt"
	"io"
	"strings"

	"rex/internal/compile"
	"rex/internal/nfa"
	"rex/internal/utf8util"
)

func Run(in io.Reader, out io.Writer) error {
	scanner := bufio.NewScanner(in)
	fmt.Fprintln(out, "rex repl - enter pattern, then lines to test (Ctrl-D to quit)")
	fmt.Fprint(out, "pattern> ")

	var pattern string

	if scanner.Scan() {
		pattern = strings.TrimRight(scanner.Text(), "\r\n")
	} else {
		return nil
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		return fmt.Errorf("bad pattern: %w", err)
	}

	fmt.Fprintf(out, "compiled: %q (%d NFA states)\n", pattern, compiled.NFA.StateCount())

	for {
		fmt.Fprint(out, "input> ")
		if !scanner.Scan() {
			break
		}

		line := strings.TrimRight(scanner.Text(), "\r\n")
		if line == ":q" || line == "quit" || line == "exit" {
			break
		}

		if !utf8util.IsValid(line) {
			fmt.Fprintln(out, "  warning: input is not valid UTF-8")
		}

		start, length, found := nfa.FindFirst(compiled.NFA, line)
		if !found {
			fmt.Fprintln(out, "  no match")
		} else {
			matched := line[start : start+length]
			runeCount := utf8util.RuneCount(matched)
			fmt.Fprintf(out, "  match at %d-%d: %q (%d runes)\n", start, start+length, matched, runeCount)
		}
	}

	return nil
}
