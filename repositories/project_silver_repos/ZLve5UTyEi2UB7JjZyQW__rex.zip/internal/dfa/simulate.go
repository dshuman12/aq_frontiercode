package dfa

import "unicode/utf8"

func FullMatch(d *DFA, input string) bool {
	cur := d.Start
	if cur == nil {
		return false
	}

	pos := 0

	for pos < len(input) {
		r, sz := utf8.DecodeRuneInString(input[pos:])
		next, ok := cur.Transitions[r]

		if !ok || next.Dead {
			return false
		}

		cur = next
		pos += sz
	}

	return cur.Accept
}

func FindFirst(d *DFA, input string) (int, int, bool) {
	start := 0
	for start <= len(input) {
		length, ok := matchAt(d, input, start)
		if ok {
			return start, length, true
		}

		if start >= len(input) {
			break
		}

		_, sz := utf8.DecodeRuneInString(input[start:])
		start += sz
	}
	return 0, 0, false
}

func FindAll(d *DFA, input string) []DFAMatch {
	var matches []DFAMatch
	pos := 0

	for pos <= len(input) {
		length, ok := matchAt(d, input, pos)

		if ok {
			matches = append(matches, DFAMatch{Start: pos, Length: length})

			if length == 0 {
				if pos < len(input) {
					_, sz := utf8.DecodeRuneInString(input[pos:])
					pos += sz
				} else {
					break
				}
			} else {
				pos += length
			}
		} else {
			if pos < len(input) {
				_, sz := utf8.DecodeRuneInString(input[pos:])
				pos += sz
			} else {
				break
			}
		}
	}

	return matches
}

type DFAMatch struct {
	Start  int
	Length int
}

func matchAt(d *DFA, input string, start int) (int, bool) {
	cur := d.Start
	if cur == nil {
		return 0, false
	}

	found := false
	bestLen := 0

	if cur.Accept {
		found = true
	}

	pos := start
	consumed := 0

	for pos < len(input) {
		r, sz := utf8.DecodeRuneInString(input[pos:])
		next, ok := cur.Transitions[r]

		if !ok || next.Dead {
			break
		}

		cur = next
		pos += sz
		consumed += sz

		if cur.Accept {
			found = true
			bestLen = consumed
		}
	}

	return bestLen, found
}
