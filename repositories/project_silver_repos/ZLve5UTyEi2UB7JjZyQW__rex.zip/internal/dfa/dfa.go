package dfa

import (
	"fmt"
	"sort"
	"strings"
)

type DFAState struct {
	ID          int
	NFAStateIDs []int
	Transitions map[rune]*DFAState
	Accept      bool
	Dead        bool
}

type DFA struct {
	Start  *DFAState
	States []*DFAState
	nextID int
}

func New() *DFA {
	return &DFA{}
}

func (d *DFA) newState(nfaIDs []int, accept bool) *DFAState {
	sorted := make([]int, len(nfaIDs))
	copy(sorted, nfaIDs)
	sort.Ints(sorted)

	s := &DFAState{
		ID:          d.nextID,
		NFAStateIDs: sorted,
		Transitions: make(map[rune]*DFAState),
		Accept:      accept,
	}

	d.nextID++
	d.States = append(d.States, s)
	return s
}

func (d *DFA) StateCount() int {
	return len(d.States)
}

func (s *DFAState) String() string {
	tag := ""

	if s.Accept {
		tag = " [accept]"
	}

	if s.Dead {
		tag += " [dead]"
	}

	return fmt.Sprintf("D%d%s", s.ID, tag)
}

func stateKey(ids []int) string {
	sorted := make([]int, len(ids))

	copy(sorted, ids)

	sort.Ints(sorted)
	parts := make([]string, len(sorted))

	for i, id := range sorted {
		parts[i] = fmt.Sprintf("%d", id)
	}

	return strings.Join(parts, ",")
}

func StateCount(d *DFA) int {
	return d.StateCount()
}
