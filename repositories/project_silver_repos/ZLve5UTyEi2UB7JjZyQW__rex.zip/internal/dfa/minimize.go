package dfa

func Minimize(d *DFA) *DFA {
	if len(d.States) <= 1 {
		return d
	}

	markDead(d)
	return removeDead(d)
}

func markDead(d *DFA) {
	canReach := make(map[int]bool)

	for _, s := range d.States {
		if s.Accept {
			canReach[s.ID] = true
		}
	}

	changed := true
	for changed {
		changed = false

		for _, s := range d.States {
			if canReach[s.ID] {
				continue
			}

			for _, target := range s.Transitions {
				if canReach[target.ID] {
					canReach[s.ID] = true
					changed = true
					break
				}
			}
		}
	}

	for _, s := range d.States {
		if !canReach[s.ID] {
			s.Dead = true
		}
	}
}

func removeDead(d *DFA) *DFA {
	if d.Start.Dead {
		result := New()
		s := result.newState(nil, false)
		s.Dead = true
		result.Start = s
		return result
	}

	return d
}

func Isomorphic(a, b *DFA) bool {
	if a == nil || b == nil {
		return a == b
	}

	mapping := make(map[int]int)
	rMapping := make(map[int]int)

	type pair struct{ ai, bi int }
	queue := []pair{{a.Start.ID, b.Start.ID}}
	aByID := stateByID(a)
	bByID := stateByID(b)

	for len(queue) > 0 {
		p := queue[0]
		queue = queue[1:]
		sa := aByID[p.ai]
		sb := bByID[p.bi]

		if sa == nil || sb == nil {
			return false
		}

		if sa.Accept != sb.Accept {
			return false
		}

		if prev, ok := mapping[p.ai]; ok {
			if prev != p.bi {
				return false
			}
			continue
		}

		if prev, ok := rMapping[p.bi]; ok {
			if prev != p.ai {
				return false
			}
		}

		mapping[p.ai] = p.bi
		rMapping[p.bi] = p.ai

		if len(sa.Transitions) != len(sb.Transitions) {
			return false
		}

		for ch, ta := range sa.Transitions {
			tb, ok := sb.Transitions[ch]
			if !ok {
				return false
			}
			queue = append(queue, pair{ta.ID, tb.ID})
		}
	}

	return true
}

func stateByID(d *DFA) map[int]*DFAState {
	m := make(map[int]*DFAState, len(d.States))

	for _, s := range d.States {
		m[s.ID] = s
	}

	return m
}
