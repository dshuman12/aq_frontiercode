package dfa

import (
	"rex/internal/charset"
	"rex/internal/nfa"
)

func FromNFA(machine *nfa.NFA, alphabet []rune) *DFA {
	if machine.Start == nil {
		d := New()
		s := d.newState(nil, false)
		d.Start = s
		return d
	}

	d := New()
	startClosure := nfa.EpsilonClosure([]*nfa.State{machine.Start})
	startIDs := extractIDs(startClosure)
	startAccept := nfa.HasAccept(startClosure)

	startState := d.newState(startIDs, startAccept)
	d.Start = startState

	stateMap := map[string]*DFAState{
		stateKey(startIDs): startState,
	}

	worklist := []*DFAState{startState}

	for len(worklist) > 0 {
		current := worklist[0]
		worklist = worklist[1:]

		nfaStates := gatherNFAStates(machine, current.NFAStateIDs)

		for _, ch := range alphabet {
			moved := nfa.Move(nfaStates, ch)

			if len(moved) == 0 {
				continue
			}

			closed := nfa.EpsilonClosure(moved)
			ids := extractIDs(closed)
			key := stateKey(ids)

			target, exists := stateMap[key]

			if !exists {
				accept := nfa.HasAccept(closed)
				target = d.newState(ids, accept)
				stateMap[key] = target
				worklist = append(worklist, target)
			}

			current.Transitions[ch] = target
		}
	}

	return d
}

func ExtractAlphabet(machine *nfa.NFA) []rune {
	seen := make(map[rune]bool)

	for _, s := range machine.States {
		for _, a := range s.Arrows {
			if a.On == nil {
				continue
			}
			collectChars(a.On, seen)
		}
	}

	result := make([]rune, 0, len(seen))

	for ch := range seen {
		result = append(result, ch)
	}

	return result
}

func collectChars(set charset.Set, seen map[rune]bool) {
	switch s := set.(type) {
	case charset.Single:
		seen[s.Ch] = true
	case charset.Range:
		for r := s.Lo; r <= s.Hi && r < s.Lo+256; r++ {
			seen[r] = true
		}
	case charset.Union:
		for _, inner := range s.Sets {
			collectChars(inner, seen)
		}
	case charset.Any:
		for r := rune(32); r < 127; r++ {
			seen[r] = true
		}
	case charset.Negate:
		for r := range rune(128) {
			seen[r] = true
		}
	}
}

func extractIDs(states []*nfa.State) []int {
	ids := make([]int, len(states))

	for i, s := range states {
		ids[i] = s.ID
	}
	return ids
}

func gatherNFAStates(machine *nfa.NFA, ids []int) []*nfa.State {
	idSet := make(map[int]bool, len(ids))

	for _, id := range ids {
		idSet[id] = true
	}

	var states []*nfa.State
	for _, s := range machine.States {
		if idSet[s.ID] {
			states = append(states, s)
		}
	}
	return states
}
