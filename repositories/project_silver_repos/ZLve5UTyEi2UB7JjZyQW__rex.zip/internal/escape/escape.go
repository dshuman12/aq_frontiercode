package escape

func ClassRanges(class rune) [][2]rune {
	switch class {
	case 'd', 'D':
		return [][2]rune{{0x30, 0x39}}
	case 'w', 'W':
		return [][2]rune{
			{0x30, 0x39},
			{0x41, 0x5a},
			{0x61, 0x7a},
			{0x5f, 0x5f},
		}
	case 's', 'S':
		return [][2]rune{
			{0x09, 0x0d},
			{0x20, 0x20},
		}
	}
	return nil
}

func IsMetaChar(r rune) bool {
	switch r {
	case '.', '*', '+', '?', '|', '(', ')', '[', ']', '{', '}', '^', '$', '\\':
		return true
	}
	return false
}

func Unescape(r rune) (rune, bool) {
	switch r {
	case 'n':
		return '\n', true
	case 't':
		return '\t', true
	case 'r':
		return '\r', true
	case 'f':
		return '\f', true
	case 'v':
		return '\v', true
	case '0':
		return 0, true
	}

	if IsMetaChar(r) {
		return r, true
	}

	return 0, false
}
