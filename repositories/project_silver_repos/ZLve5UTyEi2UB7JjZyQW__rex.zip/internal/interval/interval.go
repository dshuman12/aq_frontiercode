package interval

import "sort"

type Interval struct {
	Lo, Hi rune
}

type Set []Interval

func Single(r rune) Set {
	return Set{{r, r}}
}

func Range(lo, hi rune) Set {
	if lo > hi {
		return nil
	}
	return Set{{lo, hi}}
}

func (s Set) Contains(r rune) bool {
	for _, iv := range s {
		if r >= iv.Lo && r <= iv.Hi {
			return true
		}
	}
	return false
}

func Union(a, b Set) Set {
	merged := make(Set, 0, len(a)+len(b))
	merged = append(merged, a...)
	merged = append(merged, b...)
	return merged.Normalized()
}

func Intersect(a, b Set) Set {
	var out Set
	for _, x := range a {
		for _, y := range b {
			lo := max(y.Lo, x.Lo)
			hi := min(y.Hi, x.Hi)
			if lo <= hi {
				out = append(out, Interval{lo, hi})
			}
		}
	}
	return out.Normalized()
}

func Negate(s Set) Set {
	const maxRune = rune(0x10FFFF)
	s = s.Normalized()
	var out Set
	cur := rune(0)

	for _, iv := range s {
		if cur < iv.Lo {
			out = append(out, Interval{cur, iv.Lo - 1})
		}

		cur = iv.Hi + 1
		if cur < 0 {
			return out
		}
	}

	if cur <= maxRune {
		out = append(out, Interval{cur, maxRune})
	}

	return out
}

func Subtract(a, b Set) Set {
	return Intersect(a, Negate(b))
}

func (s Set) Normalized() Set {
	if len(s) == 0 {
		return nil
	}

	cp := make(Set, len(s))
	copy(cp, s)

	sort.Slice(cp, func(i, j int) bool {
		if cp[i].Lo != cp[j].Lo {
			return cp[i].Lo < cp[j].Lo
		}
		return cp[i].Hi < cp[j].Hi
	})

	out := Set{cp[0]}

	for _, iv := range cp[1:] {
		last := &out[len(out)-1]

		if iv.Lo <= last.Hi+1 {
			if iv.Hi > last.Hi {
				last.Hi = iv.Hi
			}
		} else {
			out = append(out, iv)
		}
	}

	return out
}

func (s Set) Len() int {
	n := 0
	for _, iv := range s {
		n += int(iv.Hi-iv.Lo) + 1
	}
	return n
}

func Equal(a, b Set) bool {
	a = a.Normalized()
	b = b.Normalized()

	if len(a) != len(b) {
		return false
	}

	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}

	return true
}

func FromRunes(runes []rune) Set {
	var s Set
	for _, r := range runes {
		s = append(s, Interval{r, r})
	}
	return s.Normalized()
}

func (s Set) Runes() []rune {
	var out []rune
	for _, iv := range s {
		for r := iv.Lo; r <= iv.Hi; r++ {
			out = append(out, r)
		}
	}
	return out
}
