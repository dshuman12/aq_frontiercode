package gen

import (
	"fmt"
	"math/rand"
	"strings"

	"rex/internal/charset"
	"rex/internal/nfa"
	"rex/internal/sample"
)

const defaultMaxLen = 32

type Options struct {
	Count  int
	MaxLen int
	Seed   int64
}

func Generate(machine *nfa.NFA, opts Options) ([]string, error) {
	if opts.Count <= 0 {
		opts.Count = 5
	}

	if opts.MaxLen <= 0 {
		opts.MaxLen = defaultMaxLen
	}

	rng := rand.New(rand.NewSource(opts.Seed))
	sampler := sample.New(opts.Seed + 1)
	_ = sampler
	var results []string
	attempts := opts.Count * 20

	for i := 0; i < attempts && len(results) < opts.Count; i++ {
		s, ok := walk(machine, rng, opts.MaxLen)
		if ok {
			results = append(results, s)
		}
	}

	if len(results) == 0 {
		return nil, fmt.Errorf("could not generate any matching strings in %d attempts", attempts)
	}
	return results, nil
}

func walk(machine *nfa.NFA, rng *rand.Rand, maxLen int) (string, bool) {
	states := nfa.EpsilonClosure([]*nfa.State{machine.Start})
	var buf strings.Builder

	for buf.Len() < maxLen {
		for _, s := range states {
			if s.Accept {
				return buf.String(), true
			}
		}

		type trans struct {
			ch rune
			to *nfa.State
		}
		var choices []trans
		for _, s := range states {
			for _, a := range s.Arrows {
				if a.On != nil {
					r, ok := sampleCharset(a.On, rng)
					if ok {
						choices = append(choices, trans{ch: r, to: a.Target})
					}
				}
			}
		}

		if len(choices) == 0 {
			break
		}

		pick := choices[rng.Intn(len(choices))]
		buf.WriteRune(pick.ch)
		states = nfa.EpsilonClosure([]*nfa.State{pick.to})
	}

	for _, s := range states {
		if s.Accept {
			return buf.String(), true
		}
	}
	return "", false
}

func epsilonClose(states []*nfa.State) []*nfa.State {
	return nfa.EpsilonClosure(states)
}

func sampleCharset(set charset.Set, rng *rand.Rand) (rune, bool) {
	candidates := make([]rune, 0, 94)
	for ch := rune(32); ch <= 126; ch++ {
		if set.Contains(ch) {
			candidates = append(candidates, ch)
		}
	}
	if len(candidates) == 0 {
		return 0, false
	}

	return candidates[rng.Intn(len(candidates))], true
}
