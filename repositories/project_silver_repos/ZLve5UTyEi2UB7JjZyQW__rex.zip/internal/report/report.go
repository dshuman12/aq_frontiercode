package report

import (
	"fmt"
	"io"
	"strings"
)

type Section struct {
	Title string
	Lines []string
}

type Report struct {
	Title    string
	Sections []Section
}

func New(title string) *Report {
	return &Report{Title: title}
}

func (r *Report) Add(section string, lines ...string) {
	r.Sections = append(r.Sections, Section{Title: section, Lines: lines})
}

func (r *Report) Addf(section string, format string, args ...any) {
	r.Add(section, fmt.Sprintf(format, args...))
}

func (r *Report) Write(w io.Writer) {
	fmt.Fprintf(w, "== %s ==\n", r.Title)
	for _, s := range r.Sections {
		fmt.Fprintf(w, "\n[%s]\n", s.Title)
		for _, l := range s.Lines {
			fmt.Fprintf(w, "  %s\n", l)
		}
	}
}

func (r *Report) String() string {
	var b strings.Builder
	r.Write(&b)
	return b.String()
}
