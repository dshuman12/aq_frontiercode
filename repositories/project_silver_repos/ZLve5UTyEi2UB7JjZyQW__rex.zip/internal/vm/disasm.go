package vm

import (
	"fmt"
	"strings"
)

func Disasm(prog *Prog) string {
	var b strings.Builder

	for i, instr := range prog.Instrs {
		fmt.Fprintf(&b, "%4d  %s\n", i, instr.String())
	}

	return b.String()
}
