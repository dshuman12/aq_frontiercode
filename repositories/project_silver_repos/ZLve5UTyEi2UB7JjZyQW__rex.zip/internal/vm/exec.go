package vm

import (
	"unicode/utf8"
)

type thread struct {
	pc   int
	save []int
}

func newThread(pc, numSave int) thread {
	s := make([]int, numSave)
	for i := range s {
		s[i] = -1
	}
	return thread{pc: pc, save: s}
}

func (t thread) clone() thread {
	s := make([]int, len(t.save))
	copy(s, t.save)
	return thread{pc: t.pc, save: s}
}

func ExecFind(prog *Prog, input string) []int {
	if len(prog.Instrs) == 0 {
		return nil
	}

	pos := 0
	for pos <= len(input) {
		result := runAt(prog.Instrs, input, pos, prog.NumSave)

		if result != nil {
			return result
		}

		if pos >= len(input) {
			break
		}
		_, sz := utf8.DecodeRuneInString(input[pos:])
		pos += sz
	}

	return nil
}

func ExecFull(prog *Prog, input string) bool {
	slots := runAt(prog.Instrs, input, 0, prog.NumSave)
	if slots == nil {
		return false
	}
	return slots[1] == len(input)
}

func runAt(instrs []Instr, input string, start, numSave int) []int {
	curr := make([]thread, 0, 8)
	visited := make([]bool, len(instrs))

	initial := newThread(0, numSave)
	initial.save[0] = start
	addThread(&curr, instrs, initial, input, start, visited)

	var best []int
	pos := start

	for len(curr) > 0 {
		for _, t := range curr {
			if t.pc < len(instrs) && instrs[t.pc].Op == OpMatch {
				best = t.save
				break
			}
		}

		if pos >= len(input) {
			break
		}

		r, sz := utf8.DecodeRuneInString(input[pos:])
		next := make([]thread, 0, len(curr))

		for i := range visited {
			visited[i] = false
		}

		for _, t := range curr {
			if t.pc >= len(instrs) {
				continue
			}

			instr := instrs[t.pc]
			var matched bool
			switch instr.Op {
			case OpChar:
				matched = r == instr.Ch
			case OpAnyChar:
				matched = r != '\n'
			case OpClass:
				matched = matchClass(instr, r)
			}

			if matched {
				nt := t.clone()
				nt.pc++
				addThread(&next, instrs, nt, input, pos+sz, visited)
			}
		}

		pos += sz
		curr = next
	}

	return best
}

func addThread(list *[]thread, instrs []Instr, t thread, input string, pos int, visited []bool) {
	if t.pc >= len(instrs) || visited[t.pc] {
		return
	}
	visited[t.pc] = true

	instr := instrs[t.pc]
	switch instr.Op {
	case OpJmp:
		nt := t.clone()
		nt.pc = instr.Arg
		addThread(list, instrs, nt, input, pos, visited)

	case OpSplit:
		a := t.clone()
		a.pc = instr.Arg
		addThread(list, instrs, a, input, pos, visited)

		b := t.clone()
		b.pc = instr.Arg2
		addThread(list, instrs, b, input, pos, visited)

	case OpSplitLazy:
		a := t.clone()
		a.pc = instr.Arg
		addThread(list, instrs, a, input, pos, visited)

		b := t.clone()
		b.pc = instr.Arg2
		addThread(list, instrs, b, input, pos, visited)

	case OpSave:
		nt := t.clone()
		nt.save[instr.Arg] = pos
		nt.pc++
		addThread(list, instrs, nt, input, pos, visited)

	case OpAnchorStart:
		if pos == 0 {
			nt := t.clone()
			nt.pc++
			addThread(list, instrs, nt, input, pos, visited)
		}

	case OpAnchorEnd:
		if pos == len(input) {
			nt := t.clone()
			nt.pc++
			addThread(list, instrs, nt, input, pos, visited)
		}

	case OpWordBound:
		at := isWordChar(input, pos)
		before := isWordCharBefore(input, pos)
		boundary := at != before
		want := instr.Arg == 0

		if boundary == want {
			nt := t.clone()
			nt.pc++
			addThread(list, instrs, nt, input, pos, visited)
		}

	default:
		*list = append(*list, t)
	}
}

func matchClass(instr Instr, r rune) bool {
	for _, cr := range instr.Ranges {
		if r >= cr.Lo && r <= cr.Hi {
			return !instr.Neg
		}
	}
	return instr.Neg
}

func isWordChar(input string, bytePos int) bool {
	if bytePos < 0 || bytePos >= len(input) {
		return false
	}

	r, _ := utf8.DecodeRuneInString(input[bytePos:])
	return isWord(r)
}

func isWordCharBefore(input string, bytePos int) bool {
	if bytePos <= 0 {
		return false
	}

	p := bytePos - 1
	for p > 0 && input[p]&0xc0 == 0x80 {
		p--
	}

	r, _ := utf8.DecodeRuneInString(input[p:])
	return isWord(r)
}

func isWord(r rune) bool {
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '_'
}
