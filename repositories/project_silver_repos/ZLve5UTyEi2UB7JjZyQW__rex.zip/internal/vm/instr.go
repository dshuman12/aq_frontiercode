package vm

import "fmt"

type Op uint8

const (
	OpChar Op = iota
	OpAnyChar
	OpMatch
	OpJmp
	OpSplit
	OpSplitLazy
	OpSave
	OpWordBound
	OpAnchorStart
	OpAnchorEnd
	OpClass
)

type ClassRange struct {
	Lo, Hi rune
}

type Instr struct {
	Op     Op
	Ch     rune
	Arg    int
	Arg2   int
	Neg    bool
	Ranges []ClassRange
}

func (i Instr) String() string {
	switch i.Op {
	case OpChar:
		return fmt.Sprintf("char %q", i.Ch)
	case OpAnyChar:
		return "anychar"
	case OpMatch:
		return "match"
	case OpJmp:
		return fmt.Sprintf("jmp %d", i.Arg)
	case OpSplit:
		return fmt.Sprintf("split %d, %d", i.Arg, i.Arg2)
	case OpSplitLazy:
		return fmt.Sprintf("split_lazy %d, %d", i.Arg, i.Arg2)
	case OpSave:
		return fmt.Sprintf("save %d", i.Arg)
	case OpWordBound:
		if i.Arg == 1 {
			return "boundary \\B"
		}
		return "boundary \\b"
	case OpAnchorStart:
		return "anchor ^"
	case OpAnchorEnd:
		return "anchor $"
	case OpClass:
		neg := ""
		if i.Neg {
			neg = "^"
		}
		return fmt.Sprintf("class [%s...]", neg)
	}
	return "?"
}

type Prog struct {
	Instrs  []Instr
	NumSave int
}
