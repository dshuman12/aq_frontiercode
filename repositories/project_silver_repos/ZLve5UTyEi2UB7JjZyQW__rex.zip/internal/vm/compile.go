package vm

import (
	"rex/internal/parser"
	"unicode"
)

type compiler struct {
	instrs  []Instr
	numSave int
}

func Compile(n *parser.Node) *Prog {
	c := &compiler{}
	c.numSave = 2

	c.emit(Instr{Op: OpSave, Arg: 0})
	c.compileNode(n)
	c.emit(Instr{Op: OpSave, Arg: 1})
	c.emit(Instr{Op: OpMatch})

	return &Prog{Instrs: c.instrs, NumSave: c.numSave}
}

func (c *compiler) emit(i Instr) int {
	c.instrs = append(c.instrs, i)
	return len(c.instrs) - 1
}

func (c *compiler) here() int {
	return len(c.instrs)
}

func (c *compiler) patch(idx, target int) {
	c.instrs[idx].Arg = target
}

func (c *compiler) patch2(idx, target int) {
	c.instrs[idx].Arg2 = target
}

func (c *compiler) compileNode(n *parser.Node) {
	if n == nil {
		return
	}

	switch n.Kind {
	case parser.KindLiteral:
		if n.Flags&parser.FlagCaseInsensitive != 0 {
			lo, up := unicode.ToLower(n.Ch), unicode.ToUpper(n.Ch)
			if lo != up {
				c.emit(Instr{Op: OpClass, Ranges: []ClassRange{{Lo: lo, Hi: lo}, {Lo: up, Hi: up}}})
				break
			}
		}
		c.emit(Instr{Op: OpChar, Ch: n.Ch})

	case parser.KindDot:
		c.emit(Instr{Op: OpAnyChar})

	case parser.KindAnchorStart:
		c.emit(Instr{Op: OpAnchorStart})

	case parser.KindAnchorEnd:
		c.emit(Instr{Op: OpAnchorEnd})

	case parser.KindWordBoundary:
		arg := 0
		if n.Negated {
			arg = 1
		}
		c.emit(Instr{Op: OpWordBound, Arg: arg})

	case parser.KindCharClass:
		ranges := make([]ClassRange, len(n.Ranges))

		for i, r := range n.Ranges {
			ranges[i] = ClassRange{Lo: r.Lo, Hi: r.Hi}
		}

		if n.Flags&parser.FlagCaseInsensitive != 0 {
			ranges = foldClassRanges(ranges)
		}

		c.emit(Instr{Op: OpClass, Neg: n.Negated, Ranges: ranges})

	case parser.KindConcat:
		for _, ch := range n.Children {
			c.compileNode(ch)
		}

	case parser.KindAltern:
		c.compileAltern(n.Children)

	case parser.KindRepeat:
		c.compileRepeat(n)

	case parser.KindGroup:
		if n.Capturing {
			slotStart := c.numSave
			slotEnd := c.numSave + 1
			c.numSave += 2

			c.emit(Instr{Op: OpSave, Arg: slotStart})
			c.compileNode(n.Child)
			c.emit(Instr{Op: OpSave, Arg: slotEnd})
		} else {
			c.compileNode(n.Child)
		}
	}
}

func (c *compiler) compileAltern(children []*parser.Node) {
	if len(children) == 0 {
		return
	}

	if len(children) == 1 {
		c.compileNode(children[0])
		return
	}

	var jmps []int
	for i := 0; i < len(children)-1; i++ {
		si := c.emit(Instr{Op: OpSplit})
		c.instrs[si].Arg = c.here()
		c.compileNode(children[i])

		ji := c.emit(Instr{Op: OpJmp})
		jmps = append(jmps, ji)
		c.instrs[si].Arg2 = c.here()
	}

	c.compileNode(children[len(children)-1])

	end := c.here()
	for _, j := range jmps {
		c.patch(j, end)
	}
}

func (c *compiler) compileRepeat(n *parser.Node) {
	switch n.Op {
	case parser.OpStar:
		c.compileStar(n.Child, n.Lazy)
	case parser.OpPlus:
		c.compilePlus(n.Child, n.Lazy)
	case parser.OpQuestion:
		c.compileQuestion(n.Child, n.Lazy)
	case parser.OpRange:
		c.compileRange(n.Child, n.Min, n.Max, n.Lazy)
	}
}

func (c *compiler) compileStar(child *parser.Node, lazy bool) {
	L := c.here()
	si := c.emit(Instr{Op: splitOp(lazy)})

	if lazy {
		c.instrs[si].Arg2 = c.here()
		c.compileNode(child)
		c.emit(Instr{Op: OpJmp, Arg: L})
		c.instrs[si].Arg = c.here()
	} else {
		c.instrs[si].Arg = c.here()
		c.compileNode(child)
		c.emit(Instr{Op: OpJmp, Arg: L})
		c.instrs[si].Arg2 = c.here()
	}
}

func (c *compiler) compilePlus(child *parser.Node, lazy bool) {
	L := c.here()
	c.compileNode(child)
	si := c.emit(Instr{Op: splitOp(lazy)})

	if lazy {
		c.instrs[si].Arg2 = L
		c.instrs[si].Arg = c.here()
	} else {
		c.instrs[si].Arg = L
		c.instrs[si].Arg2 = c.here()
	}
}

func (c *compiler) compileQuestion(child *parser.Node, lazy bool) {
	si := c.emit(Instr{Op: splitOp(lazy)})
	if lazy {
		c.instrs[si].Arg2 = c.here()
		c.compileNode(child)
		c.instrs[si].Arg = c.here()
	} else {
		c.instrs[si].Arg = c.here()
		c.compileNode(child)
		c.instrs[si].Arg2 = c.here()
	}
}

func (c *compiler) compileRange(child *parser.Node, min, max int, lazy bool) {
	for range min {
		c.compileNode(child)
	}

	if max < 0 {
		c.compileStar(child, lazy)
		return
	}

	for i := min; i < max; i++ {
		c.compileQuestion(child, lazy)
	}
}

func splitOp(lazy bool) Op {
	if lazy {
		return OpSplitLazy
	}
	return OpSplit
}

func foldClassRanges(ranges []ClassRange) []ClassRange {
	extra := ranges[:0:0]

	for _, r := range ranges {
		for ch := r.Lo; ch <= r.Hi; ch++ {
			lo := unicode.ToLower(ch)
			up := unicode.ToUpper(ch)

			if lo != ch {
				extra = append(extra, ClassRange{Lo: lo, Hi: lo})
			}

			if up != ch {
				extra = append(extra, ClassRange{Lo: up, Hi: up})
			}
		}
	}

	return append(ranges, extra...)
}
