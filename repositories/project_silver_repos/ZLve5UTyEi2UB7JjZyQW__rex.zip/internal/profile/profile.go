package profile

import (
	"fmt"
	"math"
	"slices"
	"sort"
	"strings"
	"time"
)

type MatchRecord struct {
	Pattern   string
	Input     string
	Matched   bool
	Duration  time.Duration
	StepCount int
	StateHits map[int]int
}

type Profile struct {
	records []MatchRecord
}

func New() *Profile {
	return &Profile{}
}

func (p *Profile) Add(r MatchRecord) {
	p.records = append(p.records, r)
}

func (p *Profile) Count() int {
	return len(p.records)
}

func (p *Profile) MatchCount() int {
	n := 0
	for _, r := range p.records {
		if r.Matched {
			n++
		}
	}
	return n
}

func (p *Profile) MissCount() int {
	return p.Count() - p.MatchCount()
}

func (p *Profile) TotalDuration() time.Duration {
	var d time.Duration
	for _, r := range p.records {
		d += r.Duration
	}
	return d
}

func (p *Profile) AverageDuration() time.Duration {
	if len(p.records) == 0 {
		return 0
	}
	return p.TotalDuration() / time.Duration(len(p.records))
}

func (p *Profile) MedianDuration() time.Duration {
	if len(p.records) == 0 {
		return 0
	}

	durs := make([]time.Duration, len(p.records))
	for i, r := range p.records {
		durs[i] = r.Duration
	}

	slices.Sort(durs)
	mid := len(durs) / 2

	if len(durs)%2 == 0 {
		return (durs[mid-1] + durs[mid]) / 2
	}

	return durs[mid]
}

func (p *Profile) MinDuration() time.Duration {
	if len(p.records) == 0 {
		return 0
	}

	min := p.records[0].Duration

	for _, r := range p.records[1:] {
		if r.Duration < min {
			min = r.Duration
		}
	}
	return min
}

func (p *Profile) MaxDuration() time.Duration {
	if len(p.records) == 0 {
		return 0
	}

	max := p.records[0].Duration
	for _, r := range p.records[1:] {
		if r.Duration > max {
			max = r.Duration
		}
	}

	return max
}

func (p *Profile) StdDev() float64 {
	if len(p.records) < 2 {
		return 0
	}

	mean := float64(p.AverageDuration())
	var sumSq float64

	for _, r := range p.records {
		d := float64(r.Duration) - mean
		sumSq += d * d
	}

	return math.Sqrt(sumSq / float64(len(p.records)-1))
}

func (p *Profile) TotalSteps() int {
	n := 0

	for _, r := range p.records {
		n += r.StepCount
	}

	return n
}

func (p *Profile) AverageSteps() float64 {
	if len(p.records) == 0 {
		return 0
	}
	return float64(p.TotalSteps()) / float64(len(p.records))
}

func (p *Profile) HotStates(topN int) []StateHit {
	combined := map[int]int{}

	for _, r := range p.records {
		for s, c := range r.StateHits {
			combined[s] += c
		}
	}

	result := make([]StateHit, 0, len(combined))
	for s, c := range combined {
		result = append(result, StateHit{State: s, Hits: c})
	}

	sort.Slice(result, func(i, j int) bool {
		if result[i].Hits != result[j].Hits {
			return result[i].Hits > result[j].Hits
		}

		return result[i].State < result[j].State
	})

	if topN > 0 && len(result) > topN {
		result = result[:topN]
	}
	return result
}

type StateHit struct {
	State int
	Hits  int
}

func (p *Profile) Summary() string {
	var b strings.Builder
	fmt.Fprintf(&b, "profile summary\n")
	fmt.Fprintf(&b, "  records   : %d\n", p.Count())
	fmt.Fprintf(&b, "  matched   : %d\n", p.MatchCount())
	fmt.Fprintf(&b, "  missed    : %d\n", p.MissCount())
	fmt.Fprintf(&b, "  total dur : %s\n", p.TotalDuration())
	fmt.Fprintf(&b, "  avg dur   : %s\n", p.AverageDuration())
	fmt.Fprintf(&b, "  median dur: %s\n", p.MedianDuration())
	fmt.Fprintf(&b, "  min dur   : %s\n", p.MinDuration())
	fmt.Fprintf(&b, "  max dur   : %s\n", p.MaxDuration())
	fmt.Fprintf(&b, "  stddev    : %.2f ns\n", p.StdDev())
	fmt.Fprintf(&b, "  total step: %d\n", p.TotalSteps())
	fmt.Fprintf(&b, "  avg steps : %.2f\n", p.AverageSteps())
	hot := p.HotStates(5)

	if len(hot) > 0 {
		fmt.Fprintf(&b, "  hot states:")
		for _, h := range hot {
			fmt.Fprintf(&b, " s%d(%d)", h.State, h.Hits)
		}
		fmt.Fprintln(&b)
	}

	return b.String()
}

func (p *Profile) Percentile(pct float64) time.Duration {
	if len(p.records) == 0 {
		return 0
	}

	durs := make([]time.Duration, len(p.records))
	for i, r := range p.records {
		durs[i] = r.Duration
	}

	slices.Sort(durs)
	idx := max(int(math.Ceil(pct/100.0*float64(len(durs))))-1, 0)

	if idx >= len(durs) {
		idx = len(durs) - 1
	}

	return durs[idx]
}

func (p *Profile) Histogram(buckets int) []HistBucket {
	if len(p.records) == 0 || buckets <= 0 {
		return nil
	}

	minD := p.MinDuration()
	maxD := p.MaxDuration()

	if minD == maxD {
		return []HistBucket{{Lo: minD, Hi: maxD, Count: len(p.records)}}
	}

	span := float64(maxD-minD) / float64(buckets)
	result := make([]HistBucket, buckets)

	for i := range result {
		result[i].Lo = minD + time.Duration(float64(i)*span)
		result[i].Hi = minD + time.Duration(float64(i+1)*span)
	}

	for _, r := range p.records {
		idx := int(float64(r.Duration-minD) / span)
		if idx >= buckets {
			idx = buckets - 1
		}
		result[idx].Count++
	}

	return result
}

type HistBucket struct {
	Lo    time.Duration
	Hi    time.Duration
	Count int
}

func HistString(h []HistBucket) string {
	if len(h) == 0 {
		return ""
	}

	maxC := 0
	for _, b := range h {
		if b.Count > maxC {
			maxC = b.Count
		}
	}

	barW := 40
	var b strings.Builder

	for _, bkt := range h {
		bar := 0
		if maxC > 0 {
			bar = bkt.Count * barW / maxC
		}
		fmt.Fprintf(&b, "[%8s-%8s] %s %d\n",
			bkt.Lo.Round(time.Microsecond),
			bkt.Hi.Round(time.Microsecond),
			strings.Repeat("#", bar),
			bkt.Count,
		)
	}

	return b.String()
}

func (p *Profile) FilterMatched() *Profile {
	np := New()
	for _, r := range p.records {
		if r.Matched {
			np.Add(r)
		}
	}
	return np
}

func (p *Profile) FilterMissed() *Profile {
	np := New()
	for _, r := range p.records {
		if !r.Matched {
			np.Add(r)
		}
	}
	return np
}

func (p *Profile) Merge(other *Profile) {
	p.records = append(p.records, other.records...)
}

func (p *Profile) Records() []MatchRecord {
	out := make([]MatchRecord, len(p.records))
	copy(out, p.records)
	return out
}
