package nfa

import (
	"fmt"
	"unicode"

	"rex/internal/charset"
	"rex/internal/parser"
	"rex/internal/quantifier"
)

func Build(root *parser.Node) (*NFA, error) {
	machine := New()
	frag, err := buildNode(machine, root)

	if err != nil {
		return nil, err
	}

	frag.Accept.Accept = true
	machine.Start = frag.Start
	machine.Accept = frag.Accept
	return machine, nil
}

func buildNode(m *NFA, n *parser.Node) (Fragment, error) {
	switch n.Kind {
	case parser.KindLiteral:
		if n.Ch == 0 {
			return EpsilonFrag(m), nil
		}

		if n.Flags&parser.FlagCaseInsensitive != 0 {
			lo, up := unicode.ToLower(n.Ch), unicode.ToUpper(n.Ch)
			if lo == up {
				return CharFrag(m, n.Ch), nil
			}
			set := charset.Union{Sets: []charset.Set{charset.Single{Ch: lo}, charset.Single{Ch: up}}}
			return SetFrag(m, set), nil
		}

		return CharFrag(m, n.Ch), nil

	case parser.KindDot:
		if n.Flags&parser.FlagDotAll != 0 {
			return SetFrag(m, charset.Any{}), nil
		}
		return SetFrag(m, charset.Any{}), nil

	case parser.KindConcat:
		if len(n.Children) == 0 {
			return EpsilonFrag(m), nil
		}

		result, err := buildNode(m, n.Children[0])
		if err != nil {
			return Fragment{}, err
		}

		for i := 1; i < len(n.Children); i++ {
			next, err := buildNode(m, n.Children[i])

			if err != nil {
				return Fragment{}, err
			}
			result = ConcatFrag(result, next)
		}

		return result, nil

	case parser.KindAltern:
		if len(n.Children) < 2 {
			return Fragment{}, fmt.Errorf("alternation needs at least 2 branches")
		}

		result, err := buildNode(m, n.Children[0])
		if err != nil {
			return Fragment{}, err
		}

		for i := 1; i < len(n.Children); i++ {
			right, err := buildNode(m, n.Children[i])
			if err != nil {
				return Fragment{}, err
			}
			result = AlternFrag(m, result, right)
		}
		return result, nil

	case parser.KindRepeat:
		if n.Op == parser.OpRange {
			return buildRange(m, n)
		}

		inner, err := buildNode(m, n.Child)

		if err != nil {
			return Fragment{}, err
		}

		switch n.Op {
		case parser.OpStar:
			if n.Lazy {
				return StarFragLazy(m, inner), nil
			}
			return StarFrag(m, inner), nil
		case parser.OpPlus:
			if n.Lazy {
				return PlusFragLazy(m, inner), nil
			}
			return PlusFrag(m, inner), nil
		case parser.OpQuestion:
			if n.Lazy {
				return QuestionFragLazy(m, inner), nil
			}
			return QuestionFrag(m, inner), nil
		default:
			return Fragment{}, fmt.Errorf("unknown repeat op: %d", n.Op)
		}

	case parser.KindGroup:
		return buildNode(m, n.Child)

	case parser.KindCharClass:
		ranges := n.Ranges
		if n.Flags&parser.FlagCaseInsensitive != 0 {
			ranges = foldRanges(ranges)
		}
		set := buildCharSet(ranges, n.Negated)
		return SetFrag(m, set), nil

	case parser.KindAnchorStart:
		s := m.NewState()
		s.IsAnchor = true
		s.AnchorKind = 0
		a := m.NewState()
		AddEpsilon(s, a)
		return Fragment{Start: s, Accept: a}, nil

	case parser.KindAnchorEnd:
		s := m.NewState()
		s.IsAnchor = true
		s.AnchorKind = 1
		a := m.NewState()
		AddEpsilon(s, a)
		return Fragment{Start: s, Accept: a}, nil

	case parser.KindWordBoundary:
		s := m.NewState()
		s.IsAnchor = true

		if n.Negated {
			s.AnchorKind = 3
		} else {
			s.AnchorKind = 2
		}

		a := m.NewState()
		AddEpsilon(s, a)

		return Fragment{Start: s, Accept: a}, nil

	default:
		return Fragment{}, fmt.Errorf("unhandled node kind: %d", n.Kind)
	}
}

func buildCharSet(ranges []parser.CharRange, negated bool) charset.Set {
	sets := make([]charset.Set, 0, len(ranges))
	for _, r := range ranges {
		if r.Lo == r.Hi {
			sets = append(sets, charset.Single{Ch: r.Lo})
		} else {
			sets = append(sets, charset.Range{Lo: r.Lo, Hi: r.Hi})
		}
	}

	var result charset.Set

	if len(sets) == 1 {
		result = sets[0]
	} else {
		result = charset.Union{Sets: sets}
	}

	if negated {
		result = charset.Negate{Inner: result}
	}
	return result
}

func foldRanges(ranges []parser.CharRange) []parser.CharRange {
	extra := ranges[:0:0]
	for _, r := range ranges {
		for ch := r.Lo; ch <= r.Hi; ch++ {
			lo := unicode.ToLower(ch)
			up := unicode.ToUpper(ch)

			if lo != ch {
				extra = append(extra, parser.CharRange{Lo: lo, Hi: lo})
			}

			if up != ch {
				extra = append(extra, parser.CharRange{Lo: up, Hi: up})
			}
		}
	}
	return append(ranges, extra...)
}

func buildRange(m *NFA, n *parser.Node) (Fragment, error) {
	r := quantifier.Range{Min: n.Min, Max: n.Max}
	if err := r.Validate(); err != nil {
		return Fragment{}, err
	}

	required := r.RequiredCopies()
	optional := r.OptionalCopies()

	star := StarFrag
	question := QuestionFrag

	if n.Lazy {
		star = StarFragLazy
		question = QuestionFragLazy
	}

	if required == 0 && r.Unbounded() {
		inner, err := buildNode(m, n.Child)
		if err != nil {
			return Fragment{}, err
		}
		return star(m, inner), nil
	}

	if required == 0 && optional == 0 {
		return EpsilonFrag(m), nil
	}

	var head Fragment
	first := true

	for range required {
		copy, err := buildNode(m, n.Child)

		if err != nil {
			return Fragment{}, err
		}

		if first {
			head = copy
			first = false
		} else {
			head = ConcatFrag(head, copy)
		}
	}

	if r.Unbounded() {
		tail, err := buildNode(m, n.Child)

		if err != nil {
			return Fragment{}, err
		}
		s := star(m, tail)
		if first {
			return s, nil
		}
		return ConcatFrag(head, s), nil
	}

	for range optional {
		copy, err := buildNode(m, n.Child)

		if err != nil {
			return Fragment{}, err
		}

		opt := question(m, copy)
		if first {
			head = opt
			first = false
		} else {
			head = ConcatFrag(head, opt)
		}
	}

	return head, nil
}
