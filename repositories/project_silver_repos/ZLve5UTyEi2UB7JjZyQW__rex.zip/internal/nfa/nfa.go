package nfa

import (
	"fmt"

	"rex/internal/anchor"
	"rex/internal/charset"
)

type State struct {
	ID         int
	Accept     bool
	Arrows     []Arrow
	IsAnchor   bool
	AnchorKind int
}

type Arrow struct {
	On       charset.Set
	Target   *State
	Priority int
}

type NFA struct {
	Start  *State
	Accept *State
	States []*State
	nextID int
}

func New() *NFA {
	return &NFA{}
}

func (n *NFA) NewState() *State {
	s := &State{ID: n.nextID}
	n.nextID++
	n.States = append(n.States, s)
	return s
}

func AddArrow(src *State, dst *State, on charset.Set) {
	src.Arrows = append(src.Arrows, Arrow{On: on, Target: dst})
}

func AddEpsilon(src *State, dst *State) {
	AddArrow(src, dst, nil)
}

func AddEpsilonPrio(src *State, dst *State, priority int) {
	src.Arrows = append(src.Arrows, Arrow{Target: dst, Priority: priority})
}

func (n *NFA) StateCount() int {
	return len(n.States)
}

func (s *State) String() string {
	tag := ""
	if s.Accept {
		tag = " [accept]"
	}
	return fmt.Sprintf("S%d%s", s.ID, tag)
}

func EpsilonClosure(states []*State) []*State {
	return epsilonClosureGated(states, nil)
}

func EpsilonClosureAt(states []*State, input string, pos int) []*State {
	return epsilonClosureGated(states, func(s *State) bool {
		if !s.IsAnchor {
			return true
		}

		kind := anchor.Start
		switch s.AnchorKind {
		case 1:
			kind = anchor.End
		case 2:
			kind = anchor.Word
		case 3:
			kind = anchor.NonWord
		}
		return anchor.Check(kind, input, pos)
	})
}

func epsilonClosureGated(states []*State, allow func(*State) bool) []*State {
	closure := make(map[int]*State)
	stack := make([]*State, 0, len(states))

	for _, s := range states {
		if allow != nil && !allow(s) {
			continue
		}

		closure[s.ID] = s
		stack = append(stack, s)
	}

	for len(stack) > 0 {
		cur := stack[len(stack)-1]
		stack = stack[:len(stack)-1]

		for _, a := range cur.Arrows {
			if a.On != nil {
				continue
			}

			tgt := a.Target
			if allow != nil && !allow(tgt) {
				continue
			}

			if _, seen := closure[tgt.ID]; !seen {
				closure[tgt.ID] = tgt
				stack = append(stack, tgt)
			}
		}
	}

	result := make([]*State, 0, len(closure))
	for _, s := range closure {
		result = append(result, s)
	}
	return result
}

func HasAccept(states []*State) bool {
	for _, s := range states {
		if s.Accept {
			return true
		}
	}
	return false
}

func Move(states []*State, ch rune) []*State {
	var next []*State
	seen := make(map[int]bool)

	for _, s := range states {
		for _, a := range s.Arrows {
			if a.On == nil {
				continue
			}

			if a.On.Contains(ch) && !seen[a.Target.ID] {
				seen[a.Target.ID] = true
				next = append(next, a.Target)
			}
		}
	}

	return next
}
