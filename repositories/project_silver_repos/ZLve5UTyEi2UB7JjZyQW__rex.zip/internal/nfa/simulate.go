package nfa

import (
	"unicode/utf8"
)

func FullMatch(machine *NFA, input string) bool {
	states := EpsilonClosureAt([]*State{machine.Start}, input, 0)

	pos := 0
	for pos < len(input) {
		r, sz := utf8.DecodeRuneInString(input[pos:])
		next := Move(states, r)

		if len(next) == 0 {
			return false
		}

		pos += sz
		states = EpsilonClosureAt(next, input, pos)
	}

	return HasAccept(states)
}

func FindFirst(machine *NFA, input string) (int, int, bool) {
	start := 0
	for start <= len(input) {
		length, ok := matchAt(machine, input, start)

		if ok {
			return start, length, true
		}

		if start >= len(input) {
			break
		}

		_, sz := utf8.DecodeRuneInString(input[start:])
		start += sz
	}
	return 0, 0, false
}

func FindAll(machine *NFA, input string) []Match {
	var matches []Match
	pos := 0

	for pos <= len(input) {
		length, ok := matchAt(machine, input, pos)

		if ok {
			matches = append(matches, Match{Start: pos, Length: length})

			if length == 0 {
				if pos < len(input) {
					_, sz := utf8.DecodeRuneInString(input[pos:])
					pos += sz
				} else {
					break
				}
			} else {
				pos += length
			}
		} else {
			if pos < len(input) {
				_, sz := utf8.DecodeRuneInString(input[pos:])
				pos += sz
			} else {
				break
			}
		}
	}

	return matches
}

type Match struct {
	Start  int
	Length int
}

func matchAt(machine *NFA, input string, start int) (int, bool) {
	states := EpsilonClosureAt([]*State{machine.Start}, input, start)

	found := false
	bestLen := 0

	if HasAccept(states) {
		found = true
		bestLen = 0
	}

	pos := start
	consumed := 0

	for pos < len(input) {
		r, sz := utf8.DecodeRuneInString(input[pos:])
		next := Move(states, r)

		if len(next) == 0 {
			break
		}

		pos += sz
		consumed += sz
		states = EpsilonClosureAt(next, input, pos)

		if HasAccept(states) {
			found = true
			bestLen = consumed
		}
	}

	return bestLen, found
}
