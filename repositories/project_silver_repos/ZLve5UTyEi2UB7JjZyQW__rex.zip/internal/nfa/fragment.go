package nfa

import "rex/internal/charset"

type Fragment struct {
	Start  *State
	Accept *State
}

func CharFrag(machine *NFA, ch rune) Fragment {
	s := machine.NewState()
	a := machine.NewState()
	AddArrow(s, a, charset.Single{Ch: ch})
	return Fragment{Start: s, Accept: a}
}

func SetFrag(machine *NFA, set charset.Set) Fragment {
	s := machine.NewState()
	a := machine.NewState()
	AddArrow(s, a, set)
	return Fragment{Start: s, Accept: a}
}

func EpsilonFrag(machine *NFA) Fragment {
	s := machine.NewState()
	a := machine.NewState()
	AddEpsilon(s, a)
	return Fragment{Start: s, Accept: a}
}

func ConcatFrag(a, b Fragment) Fragment {
	AddEpsilon(a.Accept, b.Start)
	return Fragment{Start: a.Start, Accept: b.Accept}
}

func AlternFrag(machine *NFA, a, b Fragment) Fragment {
	s := machine.NewState()
	accept := machine.NewState()
	AddEpsilon(s, a.Start)
	AddEpsilon(s, b.Start)
	AddEpsilon(a.Accept, accept)
	AddEpsilon(b.Accept, accept)
	return Fragment{Start: s, Accept: accept}
}

func StarFrag(machine *NFA, inner Fragment) Fragment {
	return starFragWithPrio(machine, inner, false)
}

func StarFragLazy(machine *NFA, inner Fragment) Fragment {
	return starFragWithPrio(machine, inner, true)
}

func starFragWithPrio(machine *NFA, inner Fragment, lazy bool) Fragment {
	s := machine.NewState()
	accept := machine.NewState()

	loopPrio, exitPrio := 1, 0
	if lazy {
		loopPrio, exitPrio = 0, 1
	}

	AddEpsilonPrio(s, inner.Start, loopPrio)
	AddEpsilonPrio(s, accept, exitPrio)
	AddEpsilonPrio(inner.Accept, inner.Start, loopPrio)
	AddEpsilonPrio(inner.Accept, accept, exitPrio)
	return Fragment{Start: s, Accept: accept}
}

func PlusFrag(machine *NFA, inner Fragment) Fragment {
	return plusFragWithPrio(machine, inner, false)
}

func PlusFragLazy(machine *NFA, inner Fragment) Fragment {
	return plusFragWithPrio(machine, inner, true)
}

func plusFragWithPrio(machine *NFA, inner Fragment, lazy bool) Fragment {
	s := machine.NewState()
	accept := machine.NewState()

	loopPrio, exitPrio := 1, 0
	if lazy {
		loopPrio, exitPrio = 0, 1
	}

	AddEpsilon(s, inner.Start)
	AddEpsilonPrio(inner.Accept, inner.Start, loopPrio)
	AddEpsilonPrio(inner.Accept, accept, exitPrio)
	return Fragment{Start: s, Accept: accept}
}

func QuestionFrag(machine *NFA, inner Fragment) Fragment {
	return questionFragWithPrio(machine, inner, false)
}

func QuestionFragLazy(machine *NFA, inner Fragment) Fragment {
	return questionFragWithPrio(machine, inner, true)
}

func questionFragWithPrio(machine *NFA, inner Fragment, lazy bool) Fragment {
	s := machine.NewState()
	accept := machine.NewState()

	takePrio, skipPrio := 1, 0
	if lazy {
		takePrio, skipPrio = 0, 1
	}

	AddEpsilonPrio(s, inner.Start, takePrio)
	AddEpsilonPrio(s, accept, skipPrio)
	AddEpsilon(inner.Accept, accept)
	return Fragment{Start: s, Accept: accept}
}
