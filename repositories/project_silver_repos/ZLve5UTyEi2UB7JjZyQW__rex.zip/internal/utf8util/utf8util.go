package utf8util

import "unicode/utf8"

func RuneAt(s string, bytePos int) (rune, int) {
	if bytePos >= len(s) {
		return utf8.RuneError, 0
	}
	return utf8.DecodeRuneInString(s[bytePos:])
}

func RuneBefore(s string, bytePos int) (rune, int) {
	if bytePos <= 0 {
		return utf8.RuneError, 0
	}
	return utf8.DecodeLastRuneInString(s[:bytePos])
}

func ByteLen(r rune) int {
	return utf8.RuneLen(r)
}

func IsValid(s string) bool {
	return utf8.ValidString(s)
}

func RuneCount(s string) int {
	return utf8.RuneCountInString(s)
}

func ToRunes(s string) []rune {
	return []rune(s)
}

func IsASCII(s string) bool {
	for i := 0; i < len(s); i++ {
		if s[i] > 127 {
			return false
		}
	}
	return true
}

func TruncateAtRune(s string, maxRunes int) string {
	count := 0
	for i := range s {
		if count == maxRunes {
			return s[:i]
		}
		count++
	}
	return s
}

func SafeIndex(runes []rune, i int) (rune, bool) {
	if i < 0 || i >= len(runes) {
		return 0, false
	}
	return runes[i], true
}

func IndexRune(s string, r rune) int {
	for i, ch := range s {
		if ch == r {
			return i
		}
	}
	return -1
}

func LastIndexRune(s string, r rune) int {
	last := -1
	for i, ch := range s {
		if ch == r {
			last = i
		}
	}
	return last
}

func ForEachRune(s string, fn func(pos int, r rune)) {
	for pos, r := range s {
		fn(pos, r)
	}
}
