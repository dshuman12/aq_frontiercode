package trace

import (
	"fmt"
	"strings"
	"unicode/utf8"

	"rex/internal/nfa"
)

type Step struct {
	Position     int
	Char         rune
	StatesBefore []int
	StatesAfter  []int
	Matched      bool
}

func Trace(machine *nfa.NFA, input string) []Step {
	var steps []Step

	states := nfa.EpsilonClosure([]*nfa.State{machine.Start})

	pos := 0
	for pos < len(input) {
		r, sz := utf8.DecodeRuneInString(input[pos:])

		beforeIDs := stateIDs(states)
		next := nfa.Move(states, r)
		states = nfa.EpsilonClosure(next)
		afterIDs := stateIDs(states)

		steps = append(steps, Step{
			Position:     pos,
			Char:         r,
			StatesBefore: beforeIDs,
			StatesAfter:  afterIDs,
			Matched:      nfa.HasAccept(states),
		})

		pos += sz

		if len(states) == 0 {
			break
		}
	}

	return steps
}

func Format(steps []Step) string {
	var b strings.Builder

	for i, step := range steps {
		ch := fmt.Sprintf("'%c'", step.Char)

		if step.Char == '\n' {
			ch = "'\\n'"
		}

		fmt.Fprintf(&b, "step %d: pos=%d char=%s states=%v -> %v",
			i, step.Position, ch, step.StatesBefore, step.StatesAfter)

		if step.Matched {
			b.WriteString(" [match]")
		}

		b.WriteString("\n")
	}

	return b.String()
}

func stateIDs(states []*nfa.State) []int {
	ids := make([]int, len(states))

	for i, s := range states {
		ids[i] = s.ID
	}

	return ids
}
