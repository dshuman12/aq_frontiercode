package debug

import (
	"fmt"
	"strings"

	"rex/internal/dfa"
	"rex/internal/nfa"
)

func PrintNFA(machine *nfa.NFA) string {
	var b strings.Builder

	fmt.Fprintf(&b, "NFA: %d states\n", machine.StateCount())

	if machine.Start != nil {
		fmt.Fprintf(&b, "start: S%d\n", machine.Start.ID)
	}

	if machine.Accept != nil {
		fmt.Fprintf(&b, "accept: S%d\n", machine.Accept.ID)
	}

	b.WriteString("\n")

	for _, s := range machine.States {
		tag := ""

		if s.Accept {
			tag = " (accept)"
		}

		if s.IsAnchor {
			anchors := []string{"^", "$", "\\b", "\\B"}
			tag += fmt.Sprintf(" (anchor:%s)", anchors[s.AnchorKind])
		}

		fmt.Fprintf(&b, "S%d%s:\n", s.ID, tag)

		for _, a := range s.Arrows {
			label := "ε"
			if a.On != nil {
				label = a.On.String()
			}
			fmt.Fprintf(&b, "  --%s--> S%d\n", label, a.Target.ID)
		}
	}

	return b.String()
}

func PrintDFA(d *dfa.DFA) string {
	var b strings.Builder

	fmt.Fprintf(&b, "DFA: %d states\n", d.StateCount())
	if d.Start != nil {
		fmt.Fprintf(&b, "start: D%d\n", d.Start.ID)
	}

	b.WriteString("\n")

	for _, s := range d.States {
		tag := ""

		if s.Accept {
			tag = " (accept)"
		}

		if s.Dead {
			tag += " (dead)"
		}

		fmt.Fprintf(&b, "D%d%s [nfa: %v]:\n", s.ID, tag, s.NFAStateIDs)

		for ch, target := range s.Transitions {
			label := fmt.Sprintf("'%c'", ch)

			if ch == '\n' {
				label = "'\\n'"
			}

			fmt.Fprintf(&b, "  --%s--> D%d\n", label, target.ID)
		}
	}

	return b.String()
}
