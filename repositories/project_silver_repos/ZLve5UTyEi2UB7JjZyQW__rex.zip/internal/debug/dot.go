package debug

import (
	"fmt"
	"strings"

	"rex/internal/dfa"
	"rex/internal/nfa"
)

func NFAToDot(machine *nfa.NFA) string {
	var b strings.Builder
	b.WriteString("digraph NFA {\n")
	b.WriteString("  rankdir=LR;\n")
	b.WriteString("  node [shape=circle];\n")

	for _, s := range machine.States {
		if s.Accept {
			fmt.Fprintf(&b, "  S%d [shape=doublecircle];\n", s.ID)
		}
	}

	b.WriteString("  start [shape=point];\n")

	if machine.Start != nil {
		fmt.Fprintf(&b, "  start -> S%d;\n", machine.Start.ID)
	}

	for _, s := range machine.States {
		for _, a := range s.Arrows {
			label := "ε"

			if a.On != nil {
				label = a.On.String()
			}

			fmt.Fprintf(&b, "  S%d -> S%d [label=\"%s\"];\n",
				s.ID, a.Target.ID, escapeDot(label))
		}
	}

	b.WriteString("}\n")
	return b.String()
}

func DFAToDot(d *dfa.DFA) string {
	var b strings.Builder
	b.WriteString("digraph DFA {\n")
	b.WriteString("  rankdir=LR;\n")
	b.WriteString("  node [shape=circle];\n")

	for _, s := range d.States {
		if s.Accept {
			fmt.Fprintf(&b, "  D%d [shape=doublecircle];\n", s.ID)
		}

		if s.Dead {
			fmt.Fprintf(&b, "  D%d [style=dashed];\n", s.ID)
		}
	}

	b.WriteString("  start [shape=point];\n")

	if d.Start != nil {
		fmt.Fprintf(&b, "  start -> D%d;\n", d.Start.ID)
	}

	for _, s := range d.States {
		for ch, target := range s.Transitions {
			label := string(ch)

			switch ch {
			case '\n':
				label = "\\n"
			case '\t':
				label = "\\t"
			}

			fmt.Fprintf(&b, "  D%d -> D%d [label=\"%s\"];\n",
				s.ID, target.ID, escapeDot(label))
		}
	}

	b.WriteString("}\n")
	return b.String()
}

func escapeDot(s string) string {
	s = strings.ReplaceAll(s, "\\", "\\\\")
	s = strings.ReplaceAll(s, "\"", "\\\"")
	return s
}
