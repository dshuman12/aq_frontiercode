package compile

import (
	"rex/internal/dfa"
	"rex/internal/nfa"
	"rex/internal/optimize"
	"rex/internal/parser"
	"rex/internal/vm"
)

type Pipeline struct {
	Optimize bool
	BuildDFA bool
}

var DefaultPipeline = Pipeline{
	Optimize: false,
	BuildDFA: false,
}

func (p Pipeline) Run(pattern string) (*Compiled, error) {
	ast, err := parser.Parse(pattern)
	if err != nil {
		return nil, err
	}

	if p.Optimize {
		ast = optimize.SimplifyAST(ast)
	}

	c, err := compileFromAST(pattern, ast)
	if err != nil {
		return nil, err
	}

	if p.BuildDFA {
		if err := c.BuildDFA(); err != nil {
			return nil, err
		}
	}

	return c, nil
}

func compileFromAST(pattern string, ast *parser.Node) (*Compiled, error) {
	machine, err := nfa.Build(ast)
	if err != nil {
		return nil, err
	}

	groups := countGroups(ast)

	return &Compiled{
		Pattern: pattern,
		AST:     ast,
		NFA:     machine,
		VM:      vm.Compile(ast),
		Groups:  groups,
	}, nil
}

func PrefixOptimized(pattern string) (string, *Compiled, error) {
	c, err := Compile(pattern)
	if err != nil {
		return "", nil, err
	}

	prefix := optimize.ExtractPrefix(c.AST)
	return prefix, c, nil
}

func CompileWithDFA(pattern string) (*Compiled, error) {
	c, err := Compile(pattern)

	if err != nil {
		return nil, err
	}

	alphabet := dfa.ExtractAlphabet(c.NFA)
	c.DFA = dfa.FromNFA(c.NFA, alphabet)

	return c, nil
}
