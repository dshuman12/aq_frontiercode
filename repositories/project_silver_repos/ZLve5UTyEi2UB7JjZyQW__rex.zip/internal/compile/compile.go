package compile

import (
	"fmt"
	"slices"

	"rex/internal/dfa"
	"rex/internal/nfa"
	"rex/internal/optimize"
	"rex/internal/parser"
	"rex/internal/vm"
)

type Compiled struct {
	Pattern    string
	AST        *parser.Node
	NFA        *nfa.NFA
	DFA        *dfa.DFA
	VM         *vm.Prog
	Groups     int
	GroupNames map[int]string
}

func Compile(pattern string) (*Compiled, error) {
	ast, err := parser.Parse(pattern)
	if err != nil {
		return nil, fmt.Errorf("compile failed: %w", err)
	}

	ast = optimize.RunToFixedPoint(ast, optimize.DefaultPasses())
	machine, err := nfa.Build(ast)

	if err != nil {
		return nil, fmt.Errorf("nfa build failed: %w", err)
	}

	groups := countGroups(ast)
	names := collectGroupNames(ast)

	return &Compiled{
		Pattern:    pattern,
		AST:        ast,
		NFA:        machine,
		VM:         vm.Compile(ast),
		Groups:     groups,
		GroupNames: names,
	}, nil
}

func MustCompile(pattern string) *Compiled {
	c, err := Compile(pattern)
	if err != nil {
		panic(err)
	}
	return c
}

func (c *Compiled) BuildDFA() error {
	if c.DFA != nil {
		return nil
	}

	if hasLazy(c.AST) {
		return fmt.Errorf("DFA engine does not support lazy quantifiers")
	}

	alphabet := dfa.ExtractAlphabet(c.NFA)
	c.DFA = dfa.FromNFA(c.NFA, alphabet)
	return nil
}

func hasLazy(n *parser.Node) bool {
	if n == nil {
		return false
	}

	if n.Kind == parser.KindRepeat && n.Lazy {
		return true
	}

	if hasLazy(n.Child) {
		return true
	}

	return slices.ContainsFunc(n.Children, hasLazy)
}

func (c *Compiled) HasDFA() bool {
	return c.DFA != nil
}

func collectGroupNames(n *parser.Node) map[int]string {
	out := make(map[int]string)
	walkGroupNames(n, out)
	return out
}

func walkGroupNames(n *parser.Node, out map[int]string) {
	if n == nil {
		return
	}

	if n.Kind == parser.KindGroup && n.GroupName != "" {
		out[n.GroupIdx] = n.GroupName
	}

	walkGroupNames(n.Child, out)

	for _, ch := range n.Children {
		walkGroupNames(ch, out)
	}
}

func countGroups(n *parser.Node) int {
	if n == nil {
		return 0
	}

	max := 0
	if n.Kind == parser.KindGroup && n.GroupIdx > max {
		max = n.GroupIdx
	}

	if n.Child != nil {
		if g := countGroups(n.Child); g > max {
			max = g
		}
	}

	for _, ch := range n.Children {
		if g := countGroups(ch); g > max {
			max = g
		}
	}

	return max
}
