package sample

import (
	"math/rand"

	"rex/internal/charset"
)

type Sampler struct {
	rng *rand.Rand
}

func New(seed int64) *Sampler {
	return &Sampler{rng: rand.New(rand.NewSource(seed))}
}

func (s *Sampler) SampleSet(set charset.Set) (rune, bool) {
	var candidates []rune
	for r := rune(32); r <= 126; r++ {
		if set.Contains(r) {
			candidates = append(candidates, r)
		}
	}
	if len(candidates) == 0 {
		return 0, false
	}
	return candidates[s.rng.Intn(len(candidates))], true
}

func (s *Sampler) PickIndex(n int) int {
	if n <= 0 {
		return 0
	}
	return s.rng.Intn(n)
}

func (s *Sampler) Intn(n int) int {
	return s.rng.Intn(n)
}
