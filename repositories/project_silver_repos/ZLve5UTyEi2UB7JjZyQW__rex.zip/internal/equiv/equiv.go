package equiv

import (
	"fmt"

	"rex/internal/compile"
	"rex/internal/dfa"
)

func Check(a, b string) (bool, error) {
	ca, err := compile.Compile(a)
	if err != nil {
		return false, fmt.Errorf("pattern a: %w", err)
	}

	cb, err := compile.Compile(b)
	if err != nil {
		return false, fmt.Errorf("pattern b: %w", err)
	}

	if err := ca.BuildDFA(); err != nil {
		return false, fmt.Errorf("dfa a: %w", err)
	}

	if err := cb.BuildDFA(); err != nil {
		return false, fmt.Errorf("dfa b: %w", err)
	}

	minA := dfa.Minimize(ca.DFA)
	minB := dfa.Minimize(cb.DFA)

	return dfa.Isomorphic(minA, minB), nil
}
