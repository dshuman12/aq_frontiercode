package format

const (
	Reset  = "\033[0m"
	Red    = "\033[31m"
	Green  = "\033[32m"
	Yellow = "\033[33m"
	Blue   = "\033[34m"
	Cyan   = "\033[36m"
	Bold   = "\033[1m"
	Dim    = "\033[2m"
)

var colorEnabled = true

func DisableColors() {
	colorEnabled = false
}

func EnableColors() {
	colorEnabled = true
}

func Colorize(text, color string) string {
	if !colorEnabled {
		return text
	}
	return color + text + Reset
}

func RedText(s string) string    { return Colorize(s, Red) }
func GreenText(s string) string  { return Colorize(s, Green) }
func YellowText(s string) string { return Colorize(s, Yellow) }
func BlueText(s string) string   { return Colorize(s, Blue) }
func CyanText(s string) string   { return Colorize(s, Cyan) }
func BoldText(s string) string   { return Colorize(s, Bold) }
func DimText(s string) string    { return Colorize(s, Dim) }
