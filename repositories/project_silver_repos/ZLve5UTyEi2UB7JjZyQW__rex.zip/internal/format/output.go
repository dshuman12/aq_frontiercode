package format

import (
	"fmt"
	"strings"
)

func Table(headers []string, rows [][]string) string {
	if len(headers) == 0 {
		return ""
	}

	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h)
	}

	for _, row := range rows {
		for i, cell := range row {
			if i < len(widths) && len(cell) > widths[i] {
				widths[i] = len(cell)
			}
		}
	}

	var b strings.Builder

	for i, h := range headers {
		if i > 0 {
			b.WriteString(" | ")
		}
		fmt.Fprintf(&b, "%-*s", widths[i], h)
	}
	b.WriteString("\n")

	for i, w := range widths {
		if i > 0 {
			b.WriteString("-+-")
		}
		b.WriteString(strings.Repeat("-", w))
	}
	b.WriteString("\n")

	for _, row := range rows {
		for i, cell := range row {
			if i > 0 {
				b.WriteString(" | ")
			}

			if i < len(widths) {
				fmt.Fprintf(&b, "%-*s", widths[i], cell)
			}
		}
		b.WriteString("\n")
	}

	return b.String()
}

func Indent(text string, prefix string) string {
	lines := strings.Split(text, "\n")
	for i, l := range lines {
		if l != "" {
			lines[i] = prefix + l
		}
	}
	return strings.Join(lines, "\n")
}

func Wrap(text string, width int) string {
	if width <= 0 || len(text) <= width {
		return text
	}

	var b strings.Builder
	words := strings.Fields(text)
	lineLen := 0

	for i, w := range words {
		if i > 0 && lineLen+1+len(w) > width {
			b.WriteString("\n")
			lineLen = 0
		} else if i > 0 {
			b.WriteString(" ")
			lineLen++
		}

		b.WriteString(w)
		lineLen += len(w)
	}

	return b.String()
}
