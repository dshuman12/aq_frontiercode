package optimize

import (
	"sort"

	"rex/internal/parser"
)

type Coalesce struct{}

func (Coalesce) Name() string { return "coalesce" }

func (c Coalesce) Apply(root *parser.Node) *parser.Node {
	return c.walk(root)
}

func (c Coalesce) walk(n *parser.Node) *parser.Node {
	if n == nil {
		return nil
	}

	if n.Child != nil {
		n.Child = c.walk(n.Child)
	}

	for i, ch := range n.Children {
		n.Children[i] = c.walk(ch)
	}

	if n.Kind == parser.KindCharClass {
		n.Ranges = coalesceRanges(n.Ranges)
	}

	return n
}

func coalesceRanges(ranges []parser.CharRange) []parser.CharRange {
	if len(ranges) <= 1 {
		return ranges
	}

	sorted := make([]parser.CharRange, len(ranges))

	copy(sorted, ranges)

	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].Lo < sorted[j].Lo
	})

	out := sorted[:1:len(sorted)]

	for _, r := range sorted[1:] {
		last := &out[len(out)-1]

		if r.Lo <= last.Hi+1 {
			if r.Hi > last.Hi {
				last.Hi = r.Hi
			}
		} else {
			out = append(out, r)
		}
	}

	return out
}
