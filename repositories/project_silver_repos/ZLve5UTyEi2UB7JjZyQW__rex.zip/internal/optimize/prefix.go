package optimize

import (
	"rex/internal/parser"
	"strings"
)

func ExtractPrefix(root *parser.Node) string {
	if root == nil {
		return ""
	}

	switch root.Kind {
	case parser.KindLiteral:
		if root.Ch == 0 {
			return ""
		}
		return string(root.Ch)

	case parser.KindConcat:
		var prefix strings.Builder
		for _, ch := range root.Children {
			if ch.Kind == parser.KindLiteral && ch.Ch != 0 {
				prefix.WriteString(string(ch.Ch))
			} else {
				break
			}
		}
		return prefix.String()

	default:
		return ""
	}
}

func HasConstantPrefix(root *parser.Node) bool {
	return ExtractPrefix(root) != ""
}
