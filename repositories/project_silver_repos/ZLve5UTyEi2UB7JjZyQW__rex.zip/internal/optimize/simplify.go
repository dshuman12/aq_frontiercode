package optimize

import "rex/internal/parser"

func simplifyNode(n *parser.Node) *parser.Node {
	if n == nil {
		return nil
	}

	if n.Child != nil {
		n.Child = simplifyNode(n.Child)
	}

	for i, ch := range n.Children {
		n.Children[i] = simplifyNode(ch)
	}

	switch n.Kind {
	case parser.KindConcat:
		return simplifyConcat(n)
	case parser.KindAltern:
		return simplifyAltern(n)
	case parser.KindGroup:
		if n.GroupIdx == 0 && n.Child != nil {
			return n.Child
		}
	}

	return n
}

func simplifyConcat(n *parser.Node) *parser.Node {
	var flat []*parser.Node
	for _, ch := range n.Children {
		if ch.Kind == parser.KindConcat {
			flat = append(flat, ch.Children...)
		} else {
			flat = append(flat, ch)
		}
	}

	var filtered []*parser.Node

	for _, ch := range flat {
		if ch.Kind == parser.KindLiteral && ch.Ch == 0 {
			continue
		}
		filtered = append(filtered, ch)
	}

	if len(filtered) == 0 {
		return &parser.Node{Kind: parser.KindLiteral, Ch: 0}
	}
	if len(filtered) == 1 {
		return filtered[0]
	}

	n.Children = filtered
	return n
}

func simplifyAltern(n *parser.Node) *parser.Node {
	var flat []*parser.Node
	for _, ch := range n.Children {
		if ch.Kind == parser.KindAltern {
			flat = append(flat, ch.Children...)
		} else {
			flat = append(flat, ch)
		}
	}

	if len(flat) == 1 {
		return flat[0]
	}

	n.Children = flat
	return n
}
