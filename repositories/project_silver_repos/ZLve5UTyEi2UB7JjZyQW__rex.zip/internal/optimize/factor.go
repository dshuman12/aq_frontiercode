package optimize

import (
	"rex/internal/parser"
	"slices"
)

type Factor struct{}

func (Factor) Name() string { return "factor" }

func (f Factor) Apply(root *parser.Node) *parser.Node {
	return f.walk(root)
}

func (f Factor) walk(n *parser.Node) *parser.Node {
	if n == nil {
		return nil
	}
	if n.Child != nil {
		n.Child = f.walk(n.Child)
	}
	for i, ch := range n.Children {
		n.Children[i] = f.walk(ch)
	}
	if n.Kind == parser.KindAltern {
		return factorAltern(n)
	}
	return n
}

func factorAltern(n *parser.Node) *parser.Node {
	if len(n.Children) < 2 {
		return n
	}

	if slices.ContainsFunc(n.Children, startsWithAnchor) {
		return n
	}

	prefix := commonPrefix(n.Children)
	if len(prefix) == 0 {
		return n
	}

	stripped := make([]*parser.Node, len(n.Children))

	for i, ch := range n.Children {
		stripped[i] = stripPrefix(ch, len(prefix))
	}

	alt := &parser.Node{Kind: parser.KindAltern, Children: stripped}
	return concatNodes(prefixToNodes(prefix), alt)
}

func startsWithAnchor(n *parser.Node) bool {
	switch n.Kind {
	case parser.KindAnchorStart, parser.KindAnchorEnd, parser.KindWordBoundary:
		return true
	case parser.KindConcat:
		if len(n.Children) > 0 {
			return startsWithAnchor(n.Children[0])
		}
	}
	return false
}

func commonPrefix(branches []*parser.Node) []rune {
	heads := make([][]rune, len(branches))

	for i, b := range branches {
		heads[i] = leadingLiterals(b)
	}

	var prefix []rune
	for pos := 0; ; pos++ {
		if pos >= len(heads[0]) {
			break
		}

		ch := heads[0][pos]
		ok := true

		for _, h := range heads[1:] {
			if pos >= len(h) || h[pos] != ch {
				ok = false
				break
			}
		}

		if !ok {
			break
		}

		prefix = append(prefix, ch)
	}

	return prefix
}

func leadingLiterals(n *parser.Node) []rune {
	switch n.Kind {
	case parser.KindLiteral:
		if n.Ch != 0 {
			return []rune{n.Ch}
		}

	case parser.KindConcat:
		var out []rune
		for _, ch := range n.Children {
			lits := leadingLiterals(ch)
			if len(lits) == 0 {
				break
			}
			out = append(out, lits...)
		}
		return out
	}

	return nil
}

func stripPrefix(n *parser.Node, count int) *parser.Node {
	if count == 0 {
		return n
	}

	switch n.Kind {
	case parser.KindLiteral:
		if count == 1 {
			return &parser.Node{Kind: parser.KindLiteral, Ch: 0}
		}

	case parser.KindConcat:
		result := make([]*parser.Node, 0, len(n.Children))
		remaining := count

		for _, ch := range n.Children {
			lits := leadingLiterals(ch)
			if remaining <= 0 {
				result = append(result, ch)
				continue
			}

			if len(lits) <= remaining {
				remaining -= len(lits)
			} else {
				result = append(result, stripPrefix(ch, remaining))
				remaining = 0
			}
		}

		if len(result) == 0 {
			return &parser.Node{Kind: parser.KindLiteral, Ch: 0}
		}

		if len(result) == 1 {
			return result[0]
		}

		return &parser.Node{Kind: parser.KindConcat, Children: result}
	}

	return n
}

func prefixToNodes(runes []rune) []*parser.Node {
	nodes := make([]*parser.Node, len(runes))
	for i, r := range runes {
		nodes[i] = &parser.Node{Kind: parser.KindLiteral, Ch: r}
	}
	return nodes
}

func concatNodes(prefix []*parser.Node, tail *parser.Node) *parser.Node {
	all := append(prefix, tail)
	if len(all) == 1 {
		return all[0]
	}
	return &parser.Node{Kind: parser.KindConcat, Children: all}
}
