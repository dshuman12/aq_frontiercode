package optimize

import "rex/internal/parser"

type Pass interface {
	Name() string
	Apply(root *parser.Node) *parser.Node
}

func RunAll(root *parser.Node, passes []Pass) *parser.Node {
	for _, p := range passes {
		root = p.Apply(root)
	}
	return root
}

func SimplifyAST(root *parser.Node) *parser.Node {
	return simplifyNode(root)
}
