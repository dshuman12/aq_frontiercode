package optimize

import (
	"rex/internal/hashcons"
	"rex/internal/parser"
)

type Dedup struct {
	table *hashcons.Table
}

func (Dedup) Name() string { return "dedup" }

func (d Dedup) Apply(root *parser.Node) *parser.Node {
	if d.table == nil {
		d.table = hashcons.New()
	}
	return d.walk(root)
}

func (d Dedup) walk(n *parser.Node) *parser.Node {
	if n == nil {
		return nil
	}

	if n.Child != nil {
		n.Child = d.walk(n.Child)
	}

	for i, ch := range n.Children {
		n.Children[i] = d.walk(ch)
	}

	if n.Kind == parser.KindAltern {
		return dedupAltern(n)
	}

	return n
}

func dedupAltern(n *parser.Node) *parser.Node {
	seen := make([]*parser.Node, 0, len(n.Children))

	for _, ch := range n.Children {
		dup := false

		for _, s := range seen {
			if nodeEqual(s, ch) {
				dup = true
				break
			}
		}

		if !dup {
			seen = append(seen, ch)
		}
	}

	if len(seen) == len(n.Children) {
		return n
	}

	if len(seen) == 1 {
		return seen[0]
	}

	return &parser.Node{Kind: parser.KindAltern, Children: seen}
}

func nodeEqual(a, b *parser.Node) bool {
	if a == nil && b == nil {
		return true
	}

	if a == nil || b == nil {
		return false
	}

	if a.Kind != b.Kind {
		return false
	}

	if a.Ch != b.Ch {
		return false
	}

	if a.Op != b.Op || a.Min != b.Min || a.Max != b.Max || a.Lazy != b.Lazy {
		return false
	}

	if a.Negated != b.Negated || a.GroupIdx != b.GroupIdx || a.GroupName != b.GroupName {
		return false
	}

	if a.Capturing != b.Capturing {
		return false
	}

	if len(a.Ranges) != len(b.Ranges) {
		return false
	}

	for i := range a.Ranges {
		if a.Ranges[i] != b.Ranges[i] {
			return false
		}
	}

	if !nodeEqual(a.Child, b.Child) {
		return false
	}

	if len(a.Children) != len(b.Children) {
		return false
	}

	for i := range a.Children {
		if !nodeEqual(a.Children[i], b.Children[i]) {
			return false
		}
	}

	return true
}
