package optimize

import "rex/internal/parser"

func RunToFixedPoint(root *parser.Node, passes []Pass) *parser.Node {
	for {
		prev := cloneAST(root)

		for _, p := range passes {
			root = p.Apply(root)
		}

		if nodeEqual(prev, root) {
			break
		}
	}
	return root
}

func DefaultPasses() []Pass {
	return []Pass{
		Coalesce{},
		Dedup{},
		Factor{},
		simplifyPass{},
	}
}

type simplifyPass struct{}

func (simplifyPass) Name() string { return "simplify" }
func (s simplifyPass) Apply(root *parser.Node) *parser.Node {
	return simplifyNode(root)
}

func cloneAST(n *parser.Node) *parser.Node {
	if n == nil {
		return nil
	}

	out := *n
	out.Child = cloneAST(n.Child)
	out.Children = make([]*parser.Node, len(n.Children))

	for i, ch := range n.Children {
		out.Children[i] = cloneAST(ch)
	}

	if len(n.Ranges) > 0 {
		out.Ranges = make([]parser.CharRange, len(n.Ranges))
		copy(out.Ranges, n.Ranges)
	}

	return &out
}
