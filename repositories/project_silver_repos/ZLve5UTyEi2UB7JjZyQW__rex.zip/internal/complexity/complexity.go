package complexity

import (
	"rex/internal/parser"
)

type Rating int

const (
	RatingLinear Rating = iota
	RatingPolynomial
	RatingExponential
)

func (r Rating) String() string {
	switch r {
	case RatingLinear:
		return "linear"
	case RatingPolynomial:
		return "polynomial"
	case RatingExponential:
		return "exponential"
	}
	return "unknown"
}

type Result struct {
	Rating  Rating
	Reasons []string
}

func Analyze(root *parser.Node) Result {
	var reasons []string
	r := analyze(root, false, &reasons)
	return Result{Rating: r, Reasons: reasons}
}

func analyze(n *parser.Node, insideUnbounded bool, reasons *[]string) Rating {
	if n == nil {
		return RatingLinear
	}

	worst := RatingLinear

	switch n.Kind {
	case parser.KindRepeat:
		unbounded := n.Op == parser.OpStar || n.Op == parser.OpPlus || (n.Op == parser.OpRange && n.Max < 0)

		if unbounded && insideUnbounded {
			msg := "nested unbounded quantifier detected"
			*reasons = append(*reasons, msg)
			return RatingExponential
		}

		child := analyze(n.Child, unbounded || insideUnbounded, reasons)
		if child > worst {
			worst = child
		}

		if unbounded && child >= RatingPolynomial {
			worst = RatingExponential
		}

	case parser.KindAltern:
		if insideUnbounded {
			worst = RatingPolynomial
		}

		for _, ch := range n.Children {
			r := analyze(ch, insideUnbounded, reasons)
			if r > worst {
				worst = r
			}
		}

	default:
		child := analyze(n.Child, insideUnbounded, reasons)
		if child > worst {
			worst = child
		}

		for _, ch := range n.Children {
			r := analyze(ch, insideUnbounded, reasons)
			if r > worst {
				worst = r
			}
		}
	}

	return worst
}
