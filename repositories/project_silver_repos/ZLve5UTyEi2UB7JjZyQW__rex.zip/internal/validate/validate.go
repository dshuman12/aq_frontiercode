package validate

import (
	"fmt"
	"strings"
)

func PatternCheck(pattern string) error {
	if pattern == "" {
		return nil
	}

	depth := 0
	inClass := false
	escaped := false

	for i, ch := range pattern {
		if escaped {
			escaped = false
			continue
		}

		if ch == '\\' {
			escaped = true
			continue
		}

		if inClass {
			if ch == ']' {
				inClass = false
			}
			continue
		}

		switch ch {
		case '(':
			depth++
		case ')':
			depth--
			if depth < 0 {
				return fmt.Errorf("unmatched ')' at position %d", i)
			}
		case '[':
			inClass = true
		case '*', '+', '?':
			if i == 0 {
				return fmt.Errorf("nothing to repeat at position %d", i)
			}
		}
	}

	if escaped {
		return fmt.Errorf("pattern ends with backslash")
	}
	if depth > 0 {
		return fmt.Errorf("unclosed group - %d '(' without matching ')'", depth)
	}
	if inClass {
		return fmt.Errorf("unclosed character class")
	}

	return nil
}

func InputCheck(input string) error {
	if !isValidUTF8(input) {
		return fmt.Errorf("input contains invalid utf8")
	}
	return nil
}

func isValidUTF8(s string) bool {
	return strings.ToValidUTF8(s, "") == s
}
