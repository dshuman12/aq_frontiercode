package parser

import "unicode/utf8"

func (l *lexer) tryReadGroupPrefix(lparenPos int) bool {
	if l.offset >= len(l.src) || l.src[l.offset] != '?' {
		return false
	}

	saved := l.offset
	l.offset++

	if l.offset >= len(l.src) {
		l.offset = saved
		return false
	}

	next := l.src[l.offset]

	switch next {
	case ':':
		l.offset++
		l.emit(tokGroupNonCap, 0, lparenPos)
		return true
	case '#':
		l.offset++

		for l.offset < len(l.src) && l.src[l.offset] != ')' {
			l.offset++
		}

		if l.offset < len(l.src) {
			l.offset++
		}
		return true
	case 'P':
		if l.offset+1 < len(l.src) && l.src[l.offset+1] == '<' {
			l.offset += 2
			return l.readGroupName(lparenPos, '>')
		}
	case '<':
		l.offset++
		return l.readGroupName(lparenPos, '>')
	case '\'':
		l.offset++
		return l.readGroupName(lparenPos, '\'')
	}

	if isFlagOrDash(next) {
		return l.readFlagSpan(lparenPos)
	}

	l.offset = saved
	return false
}

func (l *lexer) readGroupName(lparenPos int, closer byte) bool {
	nameStart := l.offset

	for l.offset < len(l.src) && l.src[l.offset] != closer {
		r, sz := utf8.DecodeRuneInString(l.src[l.offset:])

		if r == utf8.RuneError && sz == 1 {
			return false
		}

		if !isNameRune(r) {
			return false
		}

		l.offset += sz
	}

	if l.offset >= len(l.src) || l.offset == nameStart {
		return false
	}

	name := l.src[nameStart:l.offset]
	l.offset++
	l.tokens = append(l.tokens, token{kind: tokGroupNamed, name: name, pos: lparenPos})

	return true
}

func (l *lexer) readFlagSpan(lparenPos int) bool {
	var set, clr uint32
	negate := false

	for l.offset < len(l.src) {
		c := l.src[l.offset]

		if c == ')' {
			l.offset++
			l.tokens = append(l.tokens, token{kind: tokFlagSpan, flagsSet: set, flagsClr: clr, pos: lparenPos})
			return true
		}

		if c == '-' {
			if negate {
				return false
			}

			negate = true
			l.offset++
			continue
		}

		f, ok := flagFromRune(rune(c))
		if !ok {
			return false
		}

		if negate {
			clr |= f
		} else {
			set |= f
		}

		l.offset++
	}
	return false
}

func isFlagOrDash(b byte) bool {
	switch b {
	case 'i', 'm', 's', 'x', '-':
		return true
	}
	return false
}

func isNameRune(r rune) bool {
	return r == '_' ||
		(r >= 'a' && r <= 'z') ||
		(r >= 'A' && r <= 'Z') ||
		(r >= '0' && r <= '9')
}
