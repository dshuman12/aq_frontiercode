package parser

import "fmt"

type NodeKind int

const (
	KindLiteral NodeKind = iota
	KindDot
	KindConcat
	KindAltern
	KindRepeat
	KindGroup
	KindCharClass
	KindAnchorStart
	KindAnchorEnd
	KindWordBoundary
)

type RepeatOp int

const (
	OpStar RepeatOp = iota
	OpPlus
	OpQuestion
	OpRange
)

type CharRange struct {
	Lo rune
	Hi rune
}

type Node struct {
	Kind      NodeKind
	Ch        rune
	Children  []*Node
	Child     *Node
	Op        RepeatOp
	Min       int
	Max       int
	Lazy      bool
	Ranges    []CharRange
	Negated   bool
	GroupIdx  int
	GroupName string
	Capturing bool
	Flags     uint32
}

func (n *Node) String() string {
	switch n.Kind {
	case KindLiteral:
		return fmt.Sprintf("lit(%c)", n.Ch)
	case KindDot:
		return "dot"
	case KindConcat:
		return "concat"
	case KindAltern:
		return "alt"
	case KindRepeat:
		m := map[RepeatOp]string{OpStar: "*", OpPlus: "+", OpQuestion: "?"}
		suffix := ""
		if n.Lazy {
			suffix = "?"
		}
		if n.Op == OpRange {
			if n.Max < 0 {
				return fmt.Sprintf("{%d,}%s", n.Min, suffix)
			}
			if n.Min == n.Max {
				return fmt.Sprintf("{%d}%s", n.Min, suffix)
			}
			return fmt.Sprintf("{%d,%d}%s", n.Min, n.Max, suffix)
		}
		return m[n.Op] + suffix
	case KindGroup:
		if !n.Capturing {
			return "group(?:)"
		}
		if n.GroupName != "" {
			return fmt.Sprintf("group(%d, ?P<%s>)", n.GroupIdx, n.GroupName)
		}
		return fmt.Sprintf("group(%d)", n.GroupIdx)
	case KindCharClass:
		if n.Negated {
			return "[^...]"
		}
		return "[...]"
	case KindAnchorStart:
		return "^"
	case KindAnchorEnd:
		return "$"
	case KindWordBoundary:
		if n.Negated {
			return "\\B"
		}
		return "\\b"
	}
	return "?"
}

func litNode(ch rune) *Node {
	return &Node{Kind: KindLiteral, Ch: ch}
}

func dotNode() *Node {
	return &Node{Kind: KindDot}
}

func concatNode(children ...*Node) *Node {
	return &Node{Kind: KindConcat, Children: children}
}

func alternNode(children ...*Node) *Node {
	return &Node{Kind: KindAltern, Children: children}
}

func repeatNode(child *Node, op RepeatOp) *Node {
	return &Node{Kind: KindRepeat, Child: child, Op: op}
}

func rangeRepeatNode(child *Node, min, max int) *Node {
	return &Node{Kind: KindRepeat, Child: child, Op: OpRange, Min: min, Max: max}
}

func groupNode(child *Node, idx int) *Node {
	return &Node{Kind: KindGroup, Child: child, GroupIdx: idx, Capturing: true}
}

func nonCapturingGroupNode(child *Node) *Node {
	return &Node{Kind: KindGroup, Child: child, Capturing: false}
}

func namedGroupNode(child *Node, idx int, name string) *Node {
	return &Node{Kind: KindGroup, Child: child, GroupIdx: idx, GroupName: name, Capturing: true}
}
