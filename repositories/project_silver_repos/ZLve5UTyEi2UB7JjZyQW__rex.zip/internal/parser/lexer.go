package parser

import (
	"fmt"
	"unicode/utf8"
)

type tokKind int

const (
	tokChar tokKind = iota
	tokDot
	tokStar
	tokPlus
	tokQmark
	tokPipe
	tokLparen
	tokGroupNonCap
	tokGroupNamed
	tokFlagSpan
	tokRparen
	tokLbrack
	tokRbrack
	tokCaret
	tokDollar
	tokClass
	tokPosixClass
	tokRepeat
	tokWordBoundary
	tokEOF
)

type token struct {
	kind      tokKind
	ch        rune
	classChar rune
	min, max  int
	name      string
	flagsSet  uint32
	flagsClr  uint32
	pos       int
}

type lexer struct {
	src     string
	offset  int
	tokens  []token
	inClass bool
}

func newLexer(src string) *lexer {
	return &lexer{src: src}
}

func (l *lexer) tokenize() ([]token, error) {
	l.tokens = nil
	l.offset = 0

	for l.offset < len(l.src) {
		r, sz := utf8.DecodeRuneInString(l.src[l.offset:])

		if r == utf8.RuneError && sz == 1 {
			return nil, newError(l.offset, "bad utf8 byte in pattern")
		}

		start := l.offset
		l.offset += sz

		switch r {
		case '\\':
			t, err := l.readEscape(start)
			if err != nil {
				return nil, err
			}
			l.tokens = append(l.tokens, t)
		case '.':
			l.emit(tokDot, 0, start)
		case '*':
			l.emit(tokStar, 0, start)
		case '+':
			l.emit(tokPlus, 0, start)
		case '?':
			l.emit(tokQmark, 0, start)
		case '|':
			l.emit(tokPipe, 0, start)
		case '(':
			if l.tryReadGroupPrefix(start) {
				continue
			}
			l.emit(tokLparen, 0, start)
		case ')':
			l.emit(tokRparen, 0, start)
		case '[':
			if l.inClass {
				if l.tryReadPosixClass(start) {
					continue
				}
				l.tokens = append(l.tokens, token{kind: tokChar, ch: '[', pos: start})
			} else {
				l.emit(tokLbrack, 0, start)
				l.inClass = true
			}
		case ']':
			if l.inClass {
				l.inClass = false
			}
			l.emit(tokRbrack, 0, start)
		case '^':
			l.emit(tokCaret, 0, start)
		case '$':
			l.emit(tokDollar, 0, start)
		case '{':
			if !l.tryReadRepeat(start) {
				l.tokens = append(l.tokens, token{kind: tokChar, ch: '{', pos: start})
			}
		default:
			l.tokens = append(l.tokens, token{kind: tokChar, ch: r, pos: start})
		}
	}

	l.tokens = append(l.tokens, token{kind: tokEOF, pos: l.offset})
	return l.tokens, nil
}

func (l *lexer) emit(k tokKind, ch rune, pos int) {
	l.tokens = append(l.tokens, token{kind: k, ch: ch, pos: pos})
}

func (l *lexer) readEscape(backslashPos int) (token, error) {
	if l.offset >= len(l.src) {
		return token{}, newError(backslashPos, "pattern ends with backslash")
	}

	r, sz := utf8.DecodeRuneInString(l.src[l.offset:])
	l.offset += sz

	switch r {
	case 'd', 'D', 'w', 'W', 's', 'S':
		return token{kind: tokClass, classChar: r, pos: backslashPos}, nil
	case 'b':
		return token{kind: tokWordBoundary, ch: 0, pos: backslashPos}, nil
	case 'B':
		return token{kind: tokWordBoundary, ch: 1, pos: backslashPos}, nil
	}

	switch r {
	case '\\', '.', '*', '+', '?', '|', '(', ')', '[', ']', '{', '}', '^', '$', '-':
		return token{kind: tokChar, ch: r, pos: backslashPos}, nil
	case 'n':
		return token{kind: tokChar, ch: '\n', pos: backslashPos}, nil
	case 't':
		return token{kind: tokChar, ch: '\t', pos: backslashPos}, nil
	case 'r':
		return token{kind: tokChar, ch: '\r', pos: backslashPos}, nil
	case 'f':
		return token{kind: tokChar, ch: '\f', pos: backslashPos}, nil
	case 'v':
		return token{kind: tokChar, ch: '\v', pos: backslashPos}, nil
	case 'x':
		ch, err := l.readHexEscape(backslashPos)
		if err != nil {
			return token{}, err
		}
		return token{kind: tokChar, ch: ch, pos: backslashPos}, nil
	case 'u':
		ch, err := l.readUnicodeEscape(backslashPos)
		if err != nil {
			return token{}, err
		}
		return token{kind: tokChar, ch: ch, pos: backslashPos}, nil
	case '0':
		ch := l.readOctalTail(0, 3)
		return token{kind: tokChar, ch: ch, pos: backslashPos}, nil
	}

	return token{}, errorf(backslashPos, "unknown escape: \\%c", r)
}

func (l *lexer) readOctalTail(seed rune, maxDigits int) rune {
	v := seed

	for i := 0; i < maxDigits && l.offset < len(l.src); i++ {
		c := l.src[l.offset]

		if c < '0' || c > '7' {
			break
		}

		v = v*8 + rune(c-'0')
		l.offset++
	}

	return v
}

func (l *lexer) readHexEscape(backslashPos int) (rune, error) {
	if l.peekByte() == '{' {
		l.offset++
		start := l.offset

		for l.offset < len(l.src) && l.src[l.offset] != '}' {
			l.offset++
		}

		if l.offset >= len(l.src) {
			return 0, newError(backslashPos, "unterminated \\x{...}")
		}

		body := l.src[start:l.offset]
		l.offset++

		if len(body) == 0 || len(body) > 8 {
			return 0, errorf(backslashPos, "bad \\x{} length")
		}

		v, ok := parseHex(body)
		if !ok {
			return 0, errorf(backslashPos, "bad hex digits in \\x{}")
		}

		if v > 0x10FFFF {
			return 0, errorf(backslashPos, "\\x{} value out of range")
		}
		return rune(v), nil
	}

	if l.offset+2 > len(l.src) {
		return 0, newError(backslashPos, "\\x needs two hex digits")
	}

	v, ok := parseHex(l.src[l.offset : l.offset+2])
	if !ok {
		return 0, errorf(backslashPos, "bad hex digits in \\x")
	}

	l.offset += 2
	return rune(v), nil
}

func (l *lexer) readUnicodeEscape(backslashPos int) (rune, error) {
	if l.peekByte() == '{' {
		l.offset++
		start := l.offset

		for l.offset < len(l.src) && l.src[l.offset] != '}' {
			l.offset++
		}

		if l.offset >= len(l.src) {
			return 0, newError(backslashPos, "unterminated \\u{...}")
		}

		body := l.src[start:l.offset]
		l.offset++

		if len(body) == 0 || len(body) > 8 {
			return 0, errorf(backslashPos, "bad \\u{} length")
		}

		v, ok := parseHex(body)
		if !ok {
			return 0, errorf(backslashPos, "bad hex digits in \\u{}")
		}

		if v > 0x10FFFF {
			return 0, errorf(backslashPos, "\\u{} value out of range")
		}
		return rune(v), nil
	}

	if l.offset+4 > len(l.src) {
		return 0, newError(backslashPos, "\\u needs four hex digits")
	}

	v, ok := parseHex(l.src[l.offset : l.offset+4])
	if !ok {
		return 0, errorf(backslashPos, "bad hex digits in \\u")
	}

	l.offset += 4
	return rune(v), nil
}

func parseHex(s string) (uint32, bool) {
	var v uint32

	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case c >= '0' && c <= '9':
			v = v<<4 | uint32(c-'0')
		case c >= 'a' && c <= 'f':
			v = v<<4 | uint32(c-'a'+10)
		case c >= 'A' && c <= 'F':
			v = v<<4 | uint32(c-'A'+10)
		default:
			return 0, false
		}
	}

	return v, true
}

func (l *lexer) tryReadPosixClass(lbrackPos int) bool {
	if l.peekByte() != ':' {
		return false
	}

	save := l.offset
	l.offset++

	negated := false
	if l.peekByte() == '^' {
		negated = true
		l.offset++
	}

	nameStart := l.offset
	for l.offset < len(l.src) {
		c := l.src[l.offset]
		if c < 'a' || c > 'z' {
			break
		}
		l.offset++
	}

	name := l.src[nameStart:l.offset]

	if name == "" || l.peekByte() != ':' {
		l.offset = save
		return false
	}

	l.offset++
	if l.peekByte() != ']' {
		l.offset = save
		return false
	}

	l.offset++
	t := token{kind: tokPosixClass, name: name, pos: lbrackPos}

	if negated {
		t.ch = 1
	}

	l.tokens = append(l.tokens, t)
	return true
}

func (l *lexer) tryReadRepeat(lbracePos int) bool {
	save := l.offset

	min, ok := l.readDigits()
	if !ok {
		l.offset = save
		return false
	}

	max := min
	if l.peekByte() == ',' {
		l.offset++
		if l.peekByte() == '}' {
			max = -1
		} else {
			m, ok := l.readDigits()
			if !ok {
				l.offset = save
				return false
			}
			max = m
		}
	}

	if l.peekByte() != '}' {
		l.offset = save
		return false
	}

	l.offset++

	l.tokens = append(l.tokens, token{
		kind: tokRepeat,
		min:  min,
		max:  max,
		pos:  lbracePos,
	})

	return true
}

func (l *lexer) readDigits() (int, bool) {
	start := l.offset
	n := 0

	for l.offset < len(l.src) {
		c := l.src[l.offset]

		if c < '0' || c > '9' {
			break
		}

		n = n*10 + int(c-'0')
		l.offset++

		if n > 1<<20 {
			return 0, false
		}
	}
	return n, l.offset > start
}

func (l *lexer) peekByte() byte {
	if l.offset >= len(l.src) {
		return 0
	}
	return l.src[l.offset]
}

func (t token) String() string {
	switch t.kind {
	case tokChar:
		return fmt.Sprintf("char(%c)", t.ch)
	case tokClass:
		return fmt.Sprintf("class(\\%c)", t.classChar)
	case tokPosixClass:
		if t.ch == 1 {
			return fmt.Sprintf("posix([:^%s:])", t.name)
		}
		return fmt.Sprintf("posix([:%s:])", t.name)
	case tokRepeat:
		if t.max < 0 {
			return fmt.Sprintf("{%d,}", t.min)
		}
		if t.min == t.max {
			return fmt.Sprintf("{%d}", t.min)
		}
		return fmt.Sprintf("{%d,%d}", t.min, t.max)
	case tokEOF:
		return "EOF"
	default:
		names := map[tokKind]string{
			tokDot: ".", tokStar: "*", tokPlus: "+", tokQmark: "?",
			tokPipe: "|", tokLparen: "(", tokRparen: ")",
			tokLbrack: "[", tokRbrack: "]", tokCaret: "^", tokDollar: "$",
			tokGroupNonCap: "(?:", tokGroupNamed: "(?<>",
			tokFlagSpan: "(?flags)",
		}

		if n, ok := names[t.kind]; ok {
			return n
		}

		return "?"
	}
}
