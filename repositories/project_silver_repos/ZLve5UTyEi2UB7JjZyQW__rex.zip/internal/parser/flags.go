package parser

const (
	FlagCaseInsensitive uint32 = 1 << iota
	FlagMultiline
	FlagDotAll
	FlagExtended
)

func flagFromRune(r rune) (uint32, bool) {
	switch r {
	case 'i':
		return FlagCaseInsensitive, true
	case 'm':
		return FlagMultiline, true
	case 's':
		return FlagDotAll, true
	case 'x':
		return FlagExtended, true
	}
	return 0, false
}
