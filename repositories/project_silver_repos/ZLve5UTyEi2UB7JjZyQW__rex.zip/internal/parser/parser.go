package parser

import (
	"rex/internal/escape"
	"rex/internal/posix"
)

type Parser struct {
	tokens     []token
	pos        int
	groups     int
	groupNames map[string]int
	flagSet    uint32
}

func Parse(pattern string) (*Node, error) {
	lex := newLexer(pattern)
	tokens, err := lex.tokenize()

	if err != nil {
		return nil, err
	}

	p := &Parser{tokens: tokens}
	node, err := p.parseRegex()

	if err != nil {
		return nil, err
	}

	if p.current().kind != tokEOF {
		return nil, errorf(p.current().pos, "unexpected token: %s", p.current())
	}

	return node, nil
}

func (p *Parser) current() token {
	if p.pos >= len(p.tokens) {
		return token{kind: tokEOF, pos: -1}
	}
	return p.tokens[p.pos]
}

func (p *Parser) advance() token {
	t := p.current()
	if p.pos < len(p.tokens) {
		p.pos++
	}
	return t
}

func (p *Parser) peek() tokKind {
	return p.current().kind
}

func (p *Parser) parseRegex() (*Node, error) {
	return p.parseAltern()
}

func (p *Parser) parseAltern() (*Node, error) {
	left, err := p.parseConcat()

	if err != nil {
		return nil, err
	}

	if p.peek() != tokPipe {
		return left, nil
	}

	children := []*Node{left}
	for p.peek() == tokPipe {
		p.advance()
		right, err := p.parseConcat()

		if err != nil {
			return nil, err
		}

		children = append(children, right)
	}

	return alternNode(children...), nil
}

func (p *Parser) parseConcat() (*Node, error) {
	var parts []*Node

	for p.isAtomStart() {
		node, err := p.parseRepeat()

		if err != nil {
			return nil, err
		}

		parts = append(parts, node)
	}

	if len(parts) == 0 {
		return litNode(0), nil
	}

	if len(parts) == 1 {
		return parts[0], nil
	}

	return concatNode(parts...), nil
}

func (p *Parser) parseRepeat() (*Node, error) {
	atom, err := p.parseAtom()

	if err != nil {
		return nil, err
	}

	switch p.peek() {
	case tokStar:
		p.advance()
		return p.maybeLazy(repeatNode(atom, OpStar)), nil
	case tokPlus:
		p.advance()
		return p.maybeLazy(repeatNode(atom, OpPlus)), nil
	case tokQmark:
		p.advance()
		return p.maybeLazy(repeatNode(atom, OpQuestion)), nil
	case tokRepeat:
		t := p.advance()
		if t.max >= 0 && t.max < t.min {
			return nil, errorf(t.pos, "invalid repeat range {%d,%d}", t.min, t.max)
		}
		return p.maybeLazy(rangeRepeatNode(atom, t.min, t.max)), nil
	}

	return atom, nil
}

func (p *Parser) maybeLazy(n *Node) *Node {
	if p.peek() == tokQmark {
		p.advance()
		n.Lazy = true
	}
	return n
}

func (p *Parser) parseAtom() (*Node, error) {
	t := p.current()

	switch t.kind {
	case tokChar:
		p.advance()
		n := litNode(t.ch)
		n.Flags = p.flagSet
		return n, nil

	case tokDot:
		p.advance()
		n := dotNode()
		n.Flags = p.flagSet
		return n, nil

	case tokCaret:
		p.advance()
		return &Node{Kind: KindAnchorStart}, nil

	case tokDollar:
		p.advance()
		return &Node{Kind: KindAnchorEnd}, nil

	case tokWordBoundary:
		p.advance()
		return &Node{Kind: KindWordBoundary, Negated: t.ch == 1}, nil

	case tokLparen:
		p.advance()
		p.groups++
		idx := p.groups
		inner, err := p.parseRegex()

		if err != nil {
			return nil, err
		}

		if p.peek() != tokRparen {
			return nil, errorf(p.current().pos, "missing closing parenthesis")
		}

		p.advance()
		return groupNode(inner, idx), nil

	case tokGroupNonCap:
		p.advance()
		inner, err := p.parseRegex()

		if err != nil {
			return nil, err
		}

		if p.peek() != tokRparen {
			return nil, errorf(p.current().pos, "missing closing parenthesis")
		}

		p.advance()
		return nonCapturingGroupNode(inner), nil

	case tokGroupNamed:
		p.advance()
		p.groups++
		idx := p.groups
		name := t.name

		if _, dup := p.groupNames[name]; dup {
			return nil, errorf(t.pos, "duplicate group name %q", name)
		}

		if p.groupNames == nil {
			p.groupNames = map[string]int{}
		}

		p.groupNames[name] = idx
		inner, err := p.parseRegex()

		if err != nil {
			return nil, err
		}

		if p.peek() != tokRparen {
			return nil, errorf(p.current().pos, "missing closing parenthesis")
		}

		p.advance()
		return namedGroupNode(inner, idx, name), nil

	case tokFlagSpan:
		p.advance()
		p.flagSet |= t.flagsSet
		p.flagSet &^= t.flagsClr
		return p.parseAtom()

	case tokLbrack:
		return p.parseCharClass()

	case tokClass:
		p.advance()
		ranges := escape.ClassRanges(t.classChar)
		neg := t.classChar >= 'A' && t.classChar <= 'Z'

		return &Node{
			Kind:    KindCharClass,
			Ranges:  toCharRanges(ranges),
			Negated: neg,
		}, nil

	default:
		return nil, errorf(t.pos, "unexpected: %s", t)
	}
}

func (p *Parser) parseCharClass() (*Node, error) {
	p.advance()

	negated := false

	if p.peek() == tokCaret {
		negated = true
		p.advance()
	}

	var ranges []CharRange

	for p.peek() != tokRbrack && p.peek() != tokEOF {
		if p.peek() == tokPosixClass {
			t := p.advance()
			posRanges, ok := posix.Lookup(t.name)

			if !ok {
				return nil, errorf(t.pos, "unknown posix class %q", t.name)
			}

			if t.ch == 1 {
				ranges = append(ranges, invertRanges(posRanges)...)
			} else {
				for _, r := range posRanges {
					ranges = append(ranges, CharRange{Lo: r.Lo, Hi: r.Hi})
				}
			}
			continue
		}

		lo, err := p.classChar()

		if err != nil {
			return nil, err
		}

		if p.peek() == tokChar && p.current().ch == '-' {
			if p.pos+1 < len(p.tokens) && p.isClassCharToken(p.tokens[p.pos+1]) {
				p.advance()
				hi, err := p.classChar()

				if err != nil {
					return nil, err
				}

				if hi < lo {
					return nil, errorf(p.current().pos-1, "invalid range: %c-%c", lo, hi)
				}

				ranges = append(ranges, CharRange{Lo: lo, Hi: hi})
				continue
			}
		}

		ranges = append(ranges, CharRange{Lo: lo, Hi: lo})
	}

	if p.peek() != tokRbrack {
		return nil, newError(p.current().pos, "unclosed character class")
	}
	p.advance()

	if len(ranges) == 0 {
		return nil, newError(p.current().pos-1, "empty character class")
	}

	return &Node{
		Kind:    KindCharClass,
		Ranges:  ranges,
		Negated: negated,
		Flags:   p.flagSet,
	}, nil
}

func (p *Parser) classChar() (rune, error) {
	t := p.current()

	switch t.kind {
	case tokChar:
		p.advance()
		return t.ch, nil
	case tokClass:
		p.advance()
		return t.classChar, nil
	case tokDot, tokStar, tokPlus, tokQmark, tokPipe, tokLparen, tokRparen, tokCaret, tokDollar:
		p.advance()
		meta := map[tokKind]rune{
			tokDot: '.', tokStar: '*', tokPlus: '+', tokQmark: '?',
			tokPipe: '|', tokLparen: '(', tokRparen: ')',
			tokCaret: '^', tokDollar: '$',
		}

		if ch, ok := meta[t.kind]; ok {
			return ch, nil
		}

		return 0, errorf(t.pos, "unexpected in char class")
	default:
		return 0, errorf(t.pos, "unexpected in char class: %s", t)
	}
}

func (p *Parser) isClassCharToken(t token) bool {
	switch t.kind {
	case tokChar, tokDot, tokStar, tokPlus, tokQmark, tokPipe,
		tokLparen, tokRparen, tokCaret, tokDollar, tokClass:
		return true
	}
	return false
}

func (p *Parser) isAtomStart() bool {
	switch p.peek() {
	case tokChar, tokDot, tokLparen, tokLbrack, tokCaret, tokDollar, tokClass,
		tokGroupNonCap, tokGroupNamed, tokFlagSpan, tokWordBoundary:
		return true
	}
	return false
}

func toCharRanges(ranges [][2]rune) []CharRange {
	out := make([]CharRange, len(ranges))
	for i, r := range ranges {
		out[i] = CharRange{Lo: r[0], Hi: r[1]}
	}
	return out
}

func invertRanges(rs []posix.Range) []CharRange {
	prev := rune(0)
	var out []CharRange

	for _, r := range rs {
		if r.Lo > prev {
			out = append(out, CharRange{Lo: prev, Hi: r.Lo - 1})
		}

		if r.Hi+1 > prev {
			prev = r.Hi + 1
		}
	}

	if prev <= 0x10FFFF {
		out = append(out, CharRange{Lo: prev, Hi: 0x10FFFF})
	}

	return out
}
