package parser

import "fmt"

type ParseError struct {
	Pos int
	Msg string
}

func (e *ParseError) Error() string {
	return fmt.Sprintf("parse error at position %d: %s", e.Pos, e.Msg)
}

func newError(pos int, msg string) *ParseError {
	return &ParseError{Pos: pos, Msg: msg}
}

func errorf(pos int, format string, args ...any) *ParseError {
	return &ParseError{Pos: pos, Msg: fmt.Sprintf(format, args...)}
}
