package posix

type Range struct {
	Lo rune
	Hi rune
}

var classes = map[string][]Range{
	"alpha":  {{'A', 'Z'}, {'a', 'z'}},
	"upper":  {{'A', 'Z'}},
	"lower":  {{'a', 'z'}},
	"digit":  {{'0', '9'}},
	"xdigit": {{'0', '9'}, {'A', 'F'}, {'a', 'f'}},
	"alnum":  {{'0', '9'}, {'A', 'Z'}, {'a', 'z'}},
	"space":  {{0x09, 0x0d}, {' ', ' '}},
	"blank":  {{'\t', '\t'}, {' ', ' '}},
	"cntrl":  {{0x00, 0x1f}, {0x7f, 0x7f}},
	"print":  {{0x20, 0x7e}},
	"graph":  {{0x21, 0x7e}},
	"punct":  {{0x21, 0x2f}, {0x3a, 0x40}, {0x5b, 0x60}, {0x7b, 0x7e}},
}

func Lookup(name string) ([]Range, bool) {
	r, ok := classes[name]
	return r, ok
}

func Names() []string {
	out := make([]string, 0, len(classes))
	for k := range classes {
		out = append(out, k)
	}
	return out
}
