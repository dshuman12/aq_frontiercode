package bench

import (
	"fmt"
	"strings"

	"rex/internal/format"
)

func FormatResult(r *Result) string {
	var b strings.Builder

	engine := "NFA"

	if r.UseDFA {
		engine = "DFA"
	}

	fmt.Fprintf(&b, "engine:     %s\n", engine)
	fmt.Fprintf(&b, "pattern:    %s\n", r.Pattern)

	inputDisplay := r.Input
	if len(inputDisplay) > 60 {
		inputDisplay = inputDisplay[:57] + "..."
	}

	fmt.Fprintf(&b, "input:      %s\n", inputDisplay)
	fmt.Fprintf(&b, "matched:    %v\n", r.Matched)
	fmt.Fprintf(&b, "iterations: %d\n", r.Iterations)
	fmt.Fprintf(&b, "total:      %s\n", r.TotalTime)
	fmt.Fprintf(&b, "per match:  %s\n", r.AvgTime)

	return b.String()
}

func FormatComparison(nfaRes, dfaRes *Result) string {
	var b strings.Builder

	b.WriteString("== benchmark comparison ==\n\n")

	headers := []string{"metric", "NFA", "DFA"}
	rows := [][]string{
		{"total time", nfaRes.TotalTime.String(), dfaRes.TotalTime.String()},
		{"avg/match", nfaRes.AvgTime.String(), dfaRes.AvgTime.String()},
		{"matched", fmt.Sprintf("%v", nfaRes.Matched), fmt.Sprintf("%v", dfaRes.Matched)},
	}

	b.WriteString(format.Table(headers, rows))

	if nfaRes.AvgTime > 0 && dfaRes.AvgTime > 0 {
		speedup := float64(nfaRes.AvgTime) / float64(dfaRes.AvgTime)
		b.WriteString("\n")

		if speedup > 1 {
			fmt.Fprintf(&b, "DFA was %.1fx faster\n", speedup)
		} else if speedup < 1 {
			fmt.Fprintf(&b, "NFA was %.1fx faster\n", 1/speedup)
		} else {
			b.WriteString("about the same speed\n")
		}
	}

	return b.String()
}
