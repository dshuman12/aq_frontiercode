package bench

import (
	"time"

	"rex/internal/compile"
	dfaPkg "rex/internal/dfa"
	nfaPkg "rex/internal/nfa"
)

type Result struct {
	Pattern    string
	Input      string
	Iterations int
	TotalTime  time.Duration
	AvgTime    time.Duration
	Matched    bool
	UseDFA     bool
}

func Run(pattern, input string, iterations int, useDFA bool) (*Result, error) {
	compiled, err := compile.Compile(pattern)

	if err != nil {
		return nil, err
	}

	if useDFA {
		if err := compiled.BuildDFA(); err != nil {
			return nil, err
		}
	}

	var matched bool

	start := time.Now()

	for range iterations {
		if useDFA && compiled.DFA != nil {
			matched = dfaPkg.FullMatch(compiled.DFA, input)
		} else {
			matched = nfaPkg.FullMatch(compiled.NFA, input)
		}
	}

	total := time.Since(start)

	return &Result{
		Pattern:    pattern,
		Input:      input,
		Iterations: iterations,
		TotalTime:  total,
		AvgTime:    total / time.Duration(iterations),
		Matched:    matched,
		UseDFA:     useDFA,
	}, nil
}

func Compare(pattern, input string, iterations int) (*Result, *Result, error) {
	nfaRes, err := Run(pattern, input, iterations, false)
	if err != nil {
		return nil, nil, err
	}

	dfaRes, err := Run(pattern, input, iterations, true)

	if err != nil {
		return nil, nil, err
	}

	return nfaRes, dfaRes, nil
}
