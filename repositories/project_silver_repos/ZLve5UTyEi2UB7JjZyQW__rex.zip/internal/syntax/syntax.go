package syntax

import "rex/internal/parser"

type Features struct {
	HasGroups    bool
	HasAltern    bool
	HasRepeat    bool
	HasCharClass bool
	HasDot       bool
	HasAnchors   bool
	HasEscapes   bool
	GroupCount   int
	MaxDepth     int
}

func Analyze(root *parser.Node) Features {
	f := Features{}
	walkFeatures(root, &f, 0)
	return f
}

func walkFeatures(n *parser.Node, f *Features, depth int) {
	if n == nil {
		return
	}

	if depth > f.MaxDepth {
		f.MaxDepth = depth
	}

	switch n.Kind {
	case parser.KindGroup:
		f.HasGroups = true
		f.GroupCount++
	case parser.KindAltern:
		f.HasAltern = true
	case parser.KindRepeat:
		f.HasRepeat = true
	case parser.KindCharClass:
		f.HasCharClass = true
	case parser.KindDot:
		f.HasDot = true
	case parser.KindAnchorStart, parser.KindAnchorEnd:
		f.HasAnchors = true
	}

	if n.Child != nil {
		walkFeatures(n.Child, f, depth+1)
	}
	for _, ch := range n.Children {
		walkFeatures(ch, f, depth+1)
	}
}
