package syntax

import (
	"fmt"

	"rex/internal/parser"
)

func Validate(root *parser.Node) error {
	return validateNode(root, 0)
}

func validateNode(n *parser.Node, depth int) error {
	if n == nil {
		return nil
	}

	if depth > 200 {
		return fmt.Errorf("pattern is nested too deep (%d levels)", depth)
	}

	switch n.Kind {
	case parser.KindRepeat:
		if n.Child == nil {
			return fmt.Errorf("repeat has no child node")
		}

		if n.Child.Kind == parser.KindAnchorStart || n.Child.Kind == parser.KindAnchorEnd {
			return fmt.Errorf("cannot repeat an anchor")
		}

	case parser.KindCharClass:
		if len(n.Ranges) == 0 {
			return fmt.Errorf("empty character class")
		}

		for _, r := range n.Ranges {
			if r.Hi < r.Lo {
				return fmt.Errorf("invalid character range: %c-%c", r.Lo, r.Hi)
			}
		}

	case parser.KindGroup:
		if n.Child == nil {
			return fmt.Errorf("group has no child")
		}

	case parser.KindAltern:
		if len(n.Children) < 2 {
			return fmt.Errorf("alternation with less than 2 branches")
		}
	}

	if n.Child != nil {
		if err := validateNode(n.Child, depth+1); err != nil {
			return err
		}
	}

	for _, ch := range n.Children {
		if err := validateNode(ch, depth+1); err != nil {
			return err
		}
	}

	return nil
}
