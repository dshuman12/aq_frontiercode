package charset

import "unicode"

var Letter Set = &unicodeCategory{table: unicode.Letter}
var Number Set = &unicodeCategory{table: unicode.Number}
var Punct Set = &unicodeCategory{table: unicode.Punct}
var Symbol Set = &unicodeCategory{table: unicode.Symbol}
var Mark Set = &unicodeCategory{table: unicode.Mark}

type unicodeCategory struct {
	table *unicode.RangeTable
}

func (c *unicodeCategory) Contains(r rune) bool {
	return unicode.Is(c.table, r)
}

func (c *unicodeCategory) String() string {
	return "\\p{...}"
}

func IsASCII(r rune) bool {
	return r <= 127
}

func RuneLen(r rune) int {
	switch {
	case r <= 0x7f:
		return 1
	case r <= 0x7ff:
		return 2
	case r <= 0xffff:
		return 3
	default:
		return 4
	}
}
