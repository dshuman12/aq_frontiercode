package charset

import "strings"

type Set interface {
	Contains(r rune) bool
	String() string
}

type Single struct {
	Ch rune
}

func (s Single) Contains(r rune) bool { return r == s.Ch }
func (s Single) String() string       { return string(s.Ch) }

type Range struct {
	Lo, Hi rune
}

func (rng Range) Contains(r rune) bool {
	return r >= rng.Lo && r <= rng.Hi
}

func (rng Range) String() string {
	if rng.Lo == rng.Hi {
		return string(rng.Lo)
	}
	return string(rng.Lo) + "-" + string(rng.Hi)
}

type Union struct {
	Sets []Set
}

func (u Union) Contains(r rune) bool {
	for _, s := range u.Sets {
		if s.Contains(r) {
			return true
		}
	}
	return false
}

func (u Union) String() string {
	var out strings.Builder
	out.WriteString("[")

	for _, s := range u.Sets {
		out.WriteString(s.String())
	}

	return out.String() + "]"
}

type Negate struct {
	Inner Set
}

func (n Negate) Contains(r rune) bool {
	return !n.Inner.Contains(r)
}

func (n Negate) String() string {
	return "[^" + n.Inner.String() + "]"
}

type Any struct{}

func (a Any) Contains(r rune) bool { return r != '\n' }
func (a Any) String() string       { return "." }

type AnyIncludingNewline struct{}

func (a AnyIncludingNewline) Contains(r rune) bool { return true }
func (a AnyIncludingNewline) String() string       { return "(?s:.)" }
