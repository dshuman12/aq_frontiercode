package charset

var Digit Set = Union{Sets: []Set{
	Range{Lo: '0', Hi: '9'},
}}

var Word Set = Union{Sets: []Set{
	Range{Lo: '0', Hi: '9'},
	Range{Lo: 'A', Hi: 'Z'},
	Range{Lo: 'a', Hi: 'z'},
	Single{Ch: '_'},
}}

var Space Set = Union{Sets: []Set{
	Single{Ch: ' '},
	Single{Ch: '\t'},
	Single{Ch: '\n'},
	Single{Ch: '\r'},
	Single{Ch: '\f'},
	Single{Ch: '\v'},
}}

var NotDigit Set = Negate{Inner: Digit}
var NotWord Set = Negate{Inner: Word}
var NotSpace Set = Negate{Inner: Space}

func ClassByChar(ch rune) Set {
	switch ch {
	case 'd':
		return Digit
	case 'D':
		return NotDigit
	case 'w':
		return Word
	case 'W':
		return NotWord
	case 's':
		return Space
	case 'S':
		return NotSpace
	}
	return nil
}

func IsWordChar(r rune) bool {
	if IsASCII(r) {
		return Word.Contains(r)
	}

	return Letter.Contains(r) || Number.Contains(r)
}
