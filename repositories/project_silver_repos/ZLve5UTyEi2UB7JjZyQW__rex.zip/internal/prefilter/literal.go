package prefilter

import (
	"rex/internal/interval"
	"rex/internal/parser"
	"strings"
)

func ExtractLiteral(root *parser.Node) string {
	s := extractLit(root)
	return s
}

func CharRanges(root *parser.Node) interval.Set {
	return collectRanges(root)
}

func collectRanges(n *parser.Node) interval.Set {
	if n == nil {
		return nil
	}

	var s interval.Set
	if n.Kind == parser.KindCharClass {
		for _, r := range n.Ranges {
			s = interval.Union(s, interval.Range(rune(r.Lo), rune(r.Hi)))
		}
	}

	for _, ch := range n.Children {
		s = interval.Union(s, collectRanges(ch))
	}

	if n.Child != nil {
		s = interval.Union(s, collectRanges(n.Child))
	}
	return s
}

func extractLit(n *parser.Node) string {
	if n == nil {
		return ""
	}

	switch n.Kind {
	case parser.KindLiteral:
		if n.Ch == 0 {
			return ""
		}
		return string(n.Ch)

	case parser.KindConcat:
		var out strings.Builder
		for _, ch := range n.Children {
			s := extractLit(ch)
			if s == "" {
				break
			}
			out.WriteString(s)
		}
		return out.String()

	case parser.KindGroup:
		return extractLit(n.Child)

	case parser.KindAltern:
		if len(n.Children) == 0 {
			return ""
		}

		prefix := extractLit(n.Children[0])

		for _, ch := range n.Children[1:] {
			p := extractLit(ch)
			prefix = commonStr(prefix, p)
			if prefix == "" {
				return ""
			}
		}
		return prefix
	}

	return ""
}

func commonStr(a, b string) string {
	i := 0
	for i < len(a) && i < len(b) && a[i] == b[i] {
		i++
	}
	return a[:i]
}
