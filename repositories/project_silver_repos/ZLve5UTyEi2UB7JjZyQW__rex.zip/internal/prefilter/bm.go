package prefilter

const bmMaxChar = 256

type BM struct {
	pattern []byte
	skip    [bmMaxChar]int
}

func NewBM(pattern string) *BM {
	pat := []byte(pattern)
	bm := &BM{pattern: pat}
	m := len(pat)

	for i := range bmMaxChar {
		bm.skip[i] = m
	}

	for i := 0; i < m-1; i++ {
		bm.skip[pat[i]] = m - 1 - i
	}
	return bm
}

func (bm *BM) Search(text string) int {
	n := len(text)
	m := len(bm.pattern)

	if m == 0 {
		return 0
	}

	if n < m {
		return -1
	}

	i := m - 1

	for i < n {
		j := m - 1
		k := i

		for j >= 0 && text[k] == bm.pattern[j] {
			j--
			k--
		}

		if j < 0 {
			return k + 1
		}

		skip := bm.skip[text[i]]
		i += skip
	}

	return -1
}

func (bm *BM) SearchFrom(text string, start int) int {
	idx := bm.Search(text[start:])
	if idx < 0 {
		return -1
	}
	return start + idx
}
