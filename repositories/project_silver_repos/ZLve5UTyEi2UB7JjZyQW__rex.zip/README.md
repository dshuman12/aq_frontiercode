# rex

a regex engine.

## usage

1. build the binary - `go build ./cmd/rex` or `make build`
2. run `./rex --help` to see usage
