package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/equiv"
)

func cmdEquiv(flags *cli.Flags) {
	a := flags.RequirePositional(0, "pattern-a")
	b := flags.RequirePositional(1, "pattern-b")

	eq, err := equiv.Check(a, b)
	if err != nil {
		exitErrf("equiv: %v", err)
	}

	if flags.Has("json") {
		writeJSON(map[string]any{
			"pattern_a":  a,
			"pattern_b":  b,
			"equivalent": eq,
		})
		return
	}

	if eq {
		fmt.Println("equivalent: true")
	} else {
		fmt.Println("equivalent: false")
	}
}
