package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/explain"
	"rex/internal/prefilter"
)

func cmdExplain(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	output := explain.Pattern(compiled.AST)

	if flags.Has("json") {
		lit := prefilter.ExtractLiteral(compiled.AST)
		writeJSON(map[string]any{
			"pattern":        pattern,
			"explanation":    output,
			"literal_prefix": lit,
		})
		return
	}

	fmt.Print(output)

	lit := prefilter.ExtractLiteral(compiled.AST)
	if lit != "" {
		fmt.Printf("literal prefix: %q\n", lit)
	}

	ranges := prefilter.CharRanges(compiled.AST)
	if len(ranges) > 0 {
		fmt.Printf("char class ranges: %d interval(s)\n", len(ranges))
	}
}
