package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/graphviz"
)

func cmdDot(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	target := flags.Get("target", "nfa")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	switch target {
	case "nfa":
		fmt.Print(graphviz.NFAToDOT(compiled.NFA))
	case "dfa":
		if err := compiled.BuildDFA(); err != nil {
			exitErrf("dfa: %v", err)
		}
		fmt.Print(graphviz.DFAToDOT(compiled.DFA))
	default:
		exitErrf("unknown target %q (nfa or dfa)", target)
	}
}
