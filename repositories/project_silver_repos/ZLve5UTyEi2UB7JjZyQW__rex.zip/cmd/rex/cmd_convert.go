package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/convert"
	"rex/internal/debug"
	"rex/internal/dfa"
)

func cmdConvert(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	target := flags.Get("to", "dfa")

	switch target {
	case "glob":
		rx := convert.GlobToRegex(pattern)
		if flags.Has("json") {
			writeJSON(map[string]any{"input": pattern, "type": "glob", "regex": rx})
		} else {
			fmt.Printf("glob '%s' -> regex: %s\n", pattern, rx)
		}
		return

	case "like":
		rx := convert.LikeToRegex(pattern)
		if flags.Has("json") {
			writeJSON(map[string]any{"input": pattern, "type": "like", "regex": rx})
		} else {
			fmt.Printf("like '%s' -> regex: %s\n", pattern, rx)
		}
		return
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	switch target {
	case "nfa":
		if flags.Has("json") {
			writeJSON(map[string]any{
				"pattern": pattern,
				"type":    "NFA",
				"states":  compiled.NFA.StateCount(),
				"text":    debug.PrintNFA(compiled.NFA),
			})
		} else {
			fmt.Printf("NFA for '%s':\n\n", pattern)
			fmt.Print(debug.PrintNFA(compiled.NFA))
		}

	case "dfa":
		if err := compiled.BuildDFA(); err != nil {
			exitErrf("dfa: %v", err)
		}

		if compiled.DFA == nil {
			exitErr("failed to build DFA from NFA")
		}

		if flags.Has("json") {
			writeJSON(map[string]any{
				"pattern":    pattern,
				"type":       "DFA",
				"nfa_states": compiled.NFA.StateCount(),
				"dfa_states": dfa.StateCount(compiled.DFA),
				"text":       debug.PrintDFA(compiled.DFA),
			})
		} else {
			fmt.Printf("DFA for '%s':\n\n", pattern)
			fmt.Printf("  NFA states: %d\n", compiled.NFA.StateCount())
			fmt.Printf("  DFA states: %d\n", dfa.StateCount(compiled.DFA))
			fmt.Println()
			fmt.Print(debug.PrintDFA(compiled.DFA))
		}

	case "glob", "like":
		// handled above

	default:
		exitErrf("unknown target: %s (use 'nfa', 'dfa', 'glob', 'like')", target)
	}
}
