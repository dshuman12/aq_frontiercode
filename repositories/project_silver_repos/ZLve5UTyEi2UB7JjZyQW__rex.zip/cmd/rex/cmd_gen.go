package main

import (
	"fmt"
	"strconv"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/gen"
)

func cmdGen(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	count := 5
	if c := flags.Get("count", ""); c != "" {
		if n, err := strconv.Atoi(c); err == nil && n > 0 {
			count = n
		}
	}

	maxLen := 32
	if m := flags.Get("max-len", ""); m != "" {
		if n, err := strconv.Atoi(m); err == nil && n > 0 {
			maxLen = n
		}
	}

	var seed int64
	if s := flags.Get("seed", ""); s != "" {
		if n, err := strconv.ParseInt(s, 10, 64); err == nil {
			seed = n
		}
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	opts := gen.Options{
		Count:  count,
		MaxLen: maxLen,
		Seed:   seed,
	}

	results, err := gen.Generate(compiled.NFA, opts)
	if err != nil {
		exitErrf("gen: %v", err)
	}

	for _, s := range results {
		fmt.Println(s)
	}
}
