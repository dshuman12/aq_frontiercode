package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/limit"
	"rex/internal/match"
	"rex/internal/nfa"
	"rex/internal/stream"
	"rex/internal/vm"
	"rex/pkg/rex/filter"
)

func cmdFind(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	findAll := flags.Has("all")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	pf, _ := filter.New(pattern)
	inputArg := flags.Positional(1)

	if inputArg == "-" || inputArg == "" {
		matches, err := stream.Find(compiled.NFA, os.Stdin)

		if err != nil {
			exitErrf("stream: %v", err)
		}

		if len(matches) == 0 {
			fmt.Println("no matches found")
			return
		}

		for _, m := range matches {
			line := m.Content[m.Start:m.End]
			if pf != nil && !pf.MightMatch(m.Content) {
				continue
			}
			fmt.Printf("line %d, pos %d-%d: %s\n", m.Line, m.Start, m.End, line)
		}

		return
	}

	input := inputArg

	if findAll {
		doFindAll(compiled, pattern, input, flags)
	} else {
		doFindFirst(compiled, pattern, input, flags)
	}
}

func doFindFirst(compiled *compile.Compiled, pattern, input string, flags *cli.Flags) {
	useVM := flags.Has("vm")
	showGroups := flags.Has("groups")

	if showGroups || (useVM && compiled.Groups > 0) {
		m := match.NewMatcher(compiled)
		r := m.FindGroups(input)

		printGroupResult(pattern, input, r, flags)
		return
	}

	var start, length int
	var found bool

	if useVM {
		slots := vm.ExecFind(compiled.VM, input)

		if slots != nil && slots[0] >= 0 && slots[1] >= 0 {
			start = slots[0]
			length = slots[1] - slots[0]
			found = true
		}
	} else {
		start, length, found = nfa.FindFirst(compiled.NFA, input)
	}

	if flags.Has("json") {
		if !found {
			writeJSON(map[string]any{
				"pattern": pattern,
				"input":   input,
				"found":   false,
			})
		} else {
			writeJSON(map[string]any{
				"pattern": pattern,
				"input":   input,
				"found":   true,
				"start":   start,
				"length":  length,
				"text":    input[start : start+length],
			})
		}
		return
	}

	if !found {
		fmt.Println("no match found")
	} else {
		text := input[start : start+length]
		fmt.Printf("found at %d-%d: %s\n", start, start+length, text)
	}
}

func doFindAll(compiled *compile.Compiled, pattern, input string, flags *cli.Flags) {
	matches := nfa.FindAll(compiled.NFA, input)
	out := limit.New(os.Stdout, 64*1024)

	if flags.Has("json") {
		type jsonMatch struct {
			Start  int    `json:"start"`
			Length int    `json:"length"`
			Text   string `json:"text"`
		}

		var results []jsonMatch
		for _, m := range matches {
			results = append(results, jsonMatch{
				Start:  m.Start,
				Length: m.Length,
				Text:   input[m.Start : m.Start+m.Length],
			})
		}

		writeJSON(map[string]any{
			"pattern": pattern,
			"input":   input,
			"count":   len(results),
			"matches": results,
		})
		return
	}

	if len(matches) == 0 {
		fmt.Println("no matches found")
		return
	}

	fmt.Fprintf(out, "found %d match(es):\n", len(matches))

	for i, m := range matches {
		text := input[m.Start : m.Start+m.Length]
		fmt.Fprintf(out, "  %d: pos %d-%d \"%s\"\n", i+1, m.Start, m.Start+m.Length, text)
	}

	if out.Truncated() {
		fmt.Fprintln(os.Stderr, "(output truncated)")
	}
}

func printGroupResult(pattern, input string, r match.Result, flags *cli.Flags) {
	if flags.Has("json") {
		if !r.Matched {
			writeJSON(map[string]any{"pattern": pattern, "input": input, "found": false})
			return
		}

		type jsonSpan struct {
			Start int    `json:"start"`
			End   int    `json:"end"`
			Text  string `json:"text"`
		}

		var groups []jsonSpan

		for _, g := range r.Groups {
			if g.Start < 0 || g.End < 0 {
				groups = append(groups, jsonSpan{Start: -1, End: -1, Text: ""})
			} else {
				groups = append(groups, jsonSpan{g.Start, g.End, input[g.Start:g.End]})
			}
		}

		out := map[string]any{
			"pattern": pattern,
			"input":   input,
			"found":   true,
			"start":   r.Start,
			"end":     r.End,
			"text":    r.Text,
			"groups":  groups,
		}

		if len(r.GroupNames) > 0 {
			named := make(map[string]any, len(r.GroupNames))
			for name, sp := range r.GroupNames {
				if sp.Start >= 0 && sp.End >= 0 {
					named[name] = map[string]any{"start": sp.Start, "end": sp.End, "text": input[sp.Start:sp.End]}
				}
			}
			out["named"] = named
		}

		writeJSON(out)
		return
	}

	if !r.Matched {
		fmt.Println("no match found")
		return
	}

	fmt.Printf("found at %d-%d: %s\n", r.Start, r.End, r.Text)

	for i, g := range r.Groups {
		if g.Start < 0 || g.End < 0 {
			fmt.Printf("  group %d: <no match>\n", i+1)
		} else {
			fmt.Printf("  group %d: %s (pos %d-%d)\n", i+1, input[g.Start:g.End], g.Start, g.End)
		}
	}

	for name, sp := range r.GroupNames {
		if sp.Start >= 0 && sp.End >= 0 {
			fmt.Printf("  group %q: %s (pos %d-%d)\n", name, input[sp.Start:sp.End], sp.Start, sp.End)
		}
	}
}
