package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/pkg/rex/stats"
)

func cmdStats(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	s, err := stats.Analyze(pattern)
	if err != nil {
		exitErrf("analyze: %v", err)
	}

	if flags.Has("json") {
		writeJSON(s)
		return
	}

	fmt.Printf("pattern:    %s\n", s.Pattern)
	fmt.Printf("ast nodes:  %d\n", s.ASTNodes)
	fmt.Printf("ast depth:  %d\n", s.ASTDepth)
	fmt.Printf("nfa states: %d\n", s.NFAStates)
	if s.DFAStates > 0 {
		fmt.Printf("dfa states: %d\n", s.DFAStates)
	}
	if s.HasGroups {
		fmt.Printf("groups:     %d\n", s.GroupCount)
	}
}
