package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/diff"
	"rex/internal/parser"
)

func cmdDiff(flags *cli.Flags) {
	patA := flags.RequirePositional(0, "pattern-a")
	patB := flags.RequirePositional(1, "pattern-b")

	astA, err := parser.Parse(patA)
	if err != nil {
		exitErrf("pattern-a: %v", err)
	}

	astB, err := parser.Parse(patB)
	if err != nil {
		exitErrf("pattern-b: %v", err)
	}

	changes := diff.Diff(astA, astB)

	if flags.Has("json") {
		type ch struct {
			Path string `json:"path"`
			A    string `json:"a"`
			B    string `json:"b"`
		}
		out := make([]ch, len(changes))

		for i, c := range changes {
			out[i] = ch{c.Path, c.A, c.B}
		}

		writeJSON(map[string]any{"a": patA, "b": patB, "changes": out})
		return
	}

	if len(changes) == 0 {
		fmt.Println("patterns are structurally identical")
		return
	}

	fmt.Printf("diff '%s' vs '%s':\n", patA, patB)
	fmt.Print(diff.Format(changes))
}
