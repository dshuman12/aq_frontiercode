package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/format"
	"rex/internal/nfa"
)

func cmdTest(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	inputs := flags.Args[1:]

	if len(inputs) == 0 {
		exitErr("need at least one test input")
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	if flags.Has("json") {
		cmdTestJSON(compiled, pattern, inputs)
		return
	}

	anyFailed := false
	for _, input := range inputs {
		matched := nfa.FullMatch(compiled.NFA, input)
		if matched {
			fmt.Printf("[%s] \"%s\"\n", format.GreenText("pass"), input)
		} else {
			fmt.Printf("[%s] \"%s\"\n", format.RedText("fail"), input)
			anyFailed = true
		}
	}

	if anyFailed {
		os.Exit(1)
	}
}

func cmdTestJSON(compiled *compile.Compiled, pattern string, inputs []string) {
	type testResult struct {
		Input   string `json:"input"`
		Matched bool   `json:"matched"`
	}

	var results []testResult
	for _, input := range inputs {
		matched := nfa.FullMatch(compiled.NFA, input)
		results = append(results, testResult{
			Input:   input,
			Matched: matched,
		})
	}

	writeJSON(map[string]any{
		"pattern": pattern,
		"results": results,
	})
}
