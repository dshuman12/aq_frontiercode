package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/debug"
	"rex/internal/dfa"
	"rex/internal/vm"
)

func cmdDebug(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	outputFormat := flags.Get("format", "text")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	showDFA := flags.Has("dfa")
	showVM := flags.Has("vm")

	if showVM {
		fmt.Print(vm.Disasm(compiled.VM))
		return
	}

	switch outputFormat {
	case "dot":
		if showDFA {
			if err := compiled.BuildDFA(); err != nil {
				exitErrf("dfa: %v", err)
			}
			if compiled.DFA != nil {
				fmt.Print(debug.DFAToDot(compiled.DFA))
			} else {
				exitErr("failed to build DFA")
			}
		} else {
			fmt.Print(debug.NFAToDot(compiled.NFA))
		}

	case "text":
		if showDFA {
			if err := compiled.BuildDFA(); err != nil {
				exitErrf("dfa: %v", err)
			}
			if compiled.DFA != nil {
				fmt.Print(debug.PrintDFA(compiled.DFA))
			} else {
				exitErr("failed to build DFA")
			}
		} else {
			fmt.Print(debug.PrintNFA(compiled.NFA))
		}

	case "json":
		cmdDebugJSON(compiled, pattern, showDFA)

	default:
		fmt.Fprintf(os.Stderr, "unknown format: %s (try 'text', 'dot', or 'json')\n", outputFormat)
		os.Exit(1)
	}
}

func cmdDebugJSON(compiled *compile.Compiled, pattern string, showDFA bool) {
	info := map[string]any{
		"pattern":    pattern,
		"nfa_states": compiled.NFA.StateCount(),
		"groups":     compiled.Groups,
	}

	if showDFA {
		if err := compiled.BuildDFA(); err != nil {
			exitErrf("dfa: %v", err)
		}
		if compiled.DFA != nil {
			info["dfa_states"] = dfa.StateCount(compiled.DFA)
		}
	}

	writeJSON(info)
}
