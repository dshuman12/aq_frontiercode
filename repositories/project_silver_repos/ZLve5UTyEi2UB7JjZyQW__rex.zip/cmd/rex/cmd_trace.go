package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/trace"
)

func cmdTrace(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	input := flags.RequirePositional(1, "input")

	compiled, err := compile.Compile(pattern)

	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	steps := trace.Trace(compiled.NFA, input)

	if flags.Has("json") {
		type jsonStep struct {
			Position     int    `json:"position"`
			Char         string `json:"char"`
			StatesBefore []int  `json:"states_before"`
			StatesAfter  []int  `json:"states_after"`
			Matched      bool   `json:"matched"`
		}

		var results []jsonStep
		for _, s := range steps {
			results = append(results, jsonStep{
				Position:     s.Position,
				Char:         string(s.Char),
				StatesBefore: s.StatesBefore,
				StatesAfter:  s.StatesAfter,
				Matched:      s.Matched,
			})
		}

		writeJSON(map[string]any{
			"pattern": pattern,
			"input":   input,
			"steps":   results,
		})

		return
	}

	fmt.Print(trace.Format(steps))
}
