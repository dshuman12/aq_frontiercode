package main

import (
	"fmt"
	"os"

	"rex/internal/bench"
	"rex/internal/cli"
	"rex/internal/report"
)

func cmdBench(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	input := flags.RequirePositional(1, "input")

	iterations := max(flags.GetInt("iterations", 10000), 1)

	compare := flags.Has("compare")

	if compare {
		nfaRes, dfaRes, err := bench.Compare(pattern, input, iterations)
		if err != nil {
			exitErrf("bench failed: %v", err)
		}

		if flags.Has("json") {
			writeJSON(map[string]any{
				"nfa": map[string]any{
					"total_ms": nfaRes.TotalTime.Milliseconds(),
					"avg_ns":   nfaRes.AvgTime.Nanoseconds(),
					"matched":  nfaRes.Matched,
				},
				"dfa": map[string]any{
					"total_ms": dfaRes.TotalTime.Milliseconds(),
					"avg_ns":   dfaRes.AvgTime.Nanoseconds(),
					"matched":  dfaRes.Matched,
				},
				"iterations": iterations,
			})
			return
		}

		fmt.Print(bench.FormatComparison(nfaRes, dfaRes))
		return
	}

	useDFA := flags.Has("dfa")
	result, err := bench.Run(pattern, input, iterations, useDFA)

	if err != nil {
		exitErrf("bench failed: %v", err)
	}

	if flags.Has("json") {
		writeJSON(map[string]any{
			"total_ms":   result.TotalTime.Milliseconds(),
			"avg_ns":     result.AvgTime.Nanoseconds(),
			"matched":    result.Matched,
			"iterations": result.Iterations,
			"engine":     map[bool]string{true: "DFA", false: "NFA"}[useDFA],
		})
		return
	}

	fmt.Print(bench.FormatResult(result))

	if flags.Has("report") {
		rpt := report.New("bench results")
		rpt.Addf("pattern", "%s", pattern)
		rpt.Addf("input", "%s", input)
		rpt.Addf("engine", "%s", map[bool]string{true: "DFA", false: "NFA"}[useDFA])
		rpt.Addf("iterations", "%d", result.Iterations)
		rpt.Addf("total", "%v", result.TotalTime)
		rpt.Addf("avg", "%v", result.AvgTime)
		rpt.Addf("matched", "%v", result.Matched)
		rpt.Write(os.Stdout)
	}
}
