package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/normalize"
	"rex/internal/parser"
	"rex/internal/walk"
)

func cmdAST(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	ast, err := parser.Parse(pattern)
	if err != nil {
		exitErrf("parse error: %v", err)
	}

	if flags.Has("normalize") {
		ast = normalize.Normalize(ast)
	}

	if flags.Has("json") {
		writeJSON(map[string]any{
			"pattern": pattern,
			"ast":     ast.String(),
			"depth":   walk.MaxDepth(ast),
			"nodes":   walk.NodeCount(ast),
		})
		return
	}

	fmt.Printf("pattern: %s\n", pattern)
	fmt.Printf("nodes:   %d\n", walk.NodeCount(ast))
	fmt.Printf("depth:   %d\n", walk.MaxDepth(ast))
	fmt.Printf("\n%s\n", ast.String())
}
