package main

import (
	"os"

	"rex/internal/cli"
	"rex/internal/repl"
)

func cmdRepl(flags *cli.Flags) {
	_ = flags
	if err := repl.Run(os.Stdin, os.Stdout); err != nil {
		exitErrf("repl: %v", err)
	}
}
