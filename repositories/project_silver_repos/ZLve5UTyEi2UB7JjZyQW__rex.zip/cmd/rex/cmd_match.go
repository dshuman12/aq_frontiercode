package main

import (
	"encoding/json"
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/dfa"
	"rex/internal/nfa"
	"rex/internal/vm"
)

func cmdMatch(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	input := flags.RequirePositional(1, "input")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	useDFA := flags.Has("dfa")
	useVM := flags.Has("vm")
	var matched bool

	if useDFA {
		if err := compiled.BuildDFA(); err != nil {
			exitErrf("dfa: %v", err)
		}
		if compiled.DFA != nil {
			matched = dfa.FullMatch(compiled.DFA, input)
		}
	} else if useVM {
		matched = vm.ExecFull(compiled.VM, input)
	} else {
		matched = nfa.FullMatch(compiled.NFA, input)
	}

	if flags.Has("json") {
		result := map[string]any{
			"pattern": pattern,
			"input":   input,
			"matched": matched,
		}
		writeJSON(result)
	} else {
		if matched {
			fmt.Println("match: true")
		} else {
			fmt.Println("match: false")
			os.Exit(1)
		}
	}
}

func outputMatchJSON(pattern, input string, matched bool) {
	out := map[string]any{
		"pattern": pattern,
		"input":   input,
		"matched": matched,
	}
	data, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(data))
}
