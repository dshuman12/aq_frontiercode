package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/match"
	"rex/internal/profile"
)

func cmdProfile(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	if len(flags.Positional(0)) == 0 && pattern == "" {
		fmt.Fprintln(os.Stderr, "usage: rex profile <pattern> <text1> [text2..]")
		os.Exit(1)
	}

	_ = flags.Positional(0)
	posArgs := []string{}
	inPos := false

	for _, a := range os.Args[2:] {
		if len(a) > 0 && a[0] == '-' {
			continue
		}
		posArgs = append(posArgs, a)
		inPos = true
	}

	_ = inPos

	if len(posArgs) < 2 {
		fmt.Fprintln(os.Stderr, "usage: rex profile <pattern> <text1> [text2..]")
		os.Exit(1)
	}

	pattern = posArgs[0]
	texts := posArgs[1:]

	compiled, err := compile.Compile(pattern)

	if err != nil {
		fmt.Fprintf(os.Stderr, "compile error: %v\n", err)
		os.Exit(1)
	}

	p := profile.New()

	for _, text := range texts {
		start := time.Now()
		m := match.NewMatcher(compiled)
		result := m.FullMatch(text)
		elapsed := time.Since(start)

		rec := profile.MatchRecord{
			Pattern:  pattern,
			Input:    text,
			Matched:  result,
			Duration: elapsed,
		}
		p.Add(rec)
	}

	if flags.Has("json") {
		type jsonRecord struct {
			Pattern    string `json:"pattern"`
			Input      string `json:"input"`
			Matched    bool   `json:"matched"`
			DurationNs int64  `json:"duration_ns"`
		}
		type jsonSummary struct {
			Count      int          `json:"count"`
			Matched    int          `json:"matched"`
			Missed     int          `json:"missed"`
			TotalNs    int64        `json:"total_ns"`
			AvgNs      int64        `json:"avg_ns"`
			MinNs      int64        `json:"min_ns"`
			MaxNs      int64        `json:"max_ns"`
			TotalSteps int          `json:"total_steps"`
			Records    []jsonRecord `json:"records"`
		}

		records := make([]jsonRecord, 0, len(texts))
		for _, r := range p.Records() {
			records = append(records, jsonRecord{
				Pattern:    r.Pattern,
				Input:      r.Input,
				Matched:    r.Matched,
				DurationNs: r.Duration.Nanoseconds(),
			})
		}

		out := jsonSummary{
			Count:      p.Count(),
			Matched:    p.MatchCount(),
			Missed:     p.MissCount(),
			TotalNs:    p.TotalDuration().Nanoseconds(),
			AvgNs:      p.AverageDuration().Nanoseconds(),
			MinNs:      p.MinDuration().Nanoseconds(),
			MaxNs:      p.MaxDuration().Nanoseconds(),
			TotalSteps: p.TotalSteps(),
			Records:    records,
		}
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		enc.Encode(out)
		return
	}

	fmt.Print(p.Summary())

	if flags.Has("histogram") {
		buckets := 8
		h := p.Histogram(buckets)
		fmt.Println("\nduration histogram:")
		fmt.Print(profile.HistString(h))
	}

	if flags.Has("percentiles") {
		fmt.Printf("\npercentiles:\n")
		for _, pct := range []float64{50, 75, 90, 95, 99} {
			fmt.Printf("  p%.0f: %s\n", pct, p.Percentile(pct).Round(time.Microsecond))
		}
	}

	if flags.Has("matched-only") {
		sub := p.FilterMatched()
		fmt.Printf("\nmatched only (%d records):\n", sub.Count())
		fmt.Printf("  avg dur: %s\n", sub.AverageDuration())
	}

	if flags.Has("missed-only") {
		sub := p.FilterMissed()
		fmt.Printf("\nmissed only (%d records):\n", sub.Count())
		fmt.Printf("  avg dur: %s\n", sub.AverageDuration())
	}
}
