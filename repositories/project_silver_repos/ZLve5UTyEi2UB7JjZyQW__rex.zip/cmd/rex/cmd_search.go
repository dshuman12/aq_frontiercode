package main

import (
	"bufio"
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/trie"
	"rex/pkg/rex/multi"
)

func cmdSearch(flags *cli.Flags) {
	if len(flags.Args) < 1 {
		exitErr("usage: rex search <pattern1> [pattern2...] [--text=<input>]")
	}

	patterns := flags.Args
	text := flags.Get("text", "")
	showJSON := flags.Has("json")

	t := trie.New()
	for i, p := range patterns {
		t.Insert(p, i)
	}

	m := multi.New(patterns)

	var lines []string
	if text != "" {
		lines = []string{text}
	} else {
		sc := bufio.NewScanner(os.Stdin)
		for sc.Scan() {
			lines = append(lines, sc.Text())
		}
	}

	type lineResult struct {
		Line    int           `json:"line"`
		Text    string        `json:"text"`
		Matches []multi.Match `json:"matches"`
	}

	var results []lineResult

	for i, line := range lines {
		hasCand := false
		for start := 0; start < len(line) && !hasCand; start++ {
			if t.HasPrefix(line[start:]) {
				hasCand = true
			}
		}
		if !hasCand {
			continue
		}
		matches := m.FindAll(line)
		if len(matches) == 0 {
			continue
		}
		results = append(results, lineResult{Line: i + 1, Text: line, Matches: matches})
	}

	if showJSON {
		writeJSON(results)
		return
	}

	if len(results) == 0 {
		fmt.Println("no matches")
		return
	}

	for _, r := range results {
		for _, match := range r.Matches {
			hi := highlightSpan(r.Text, match.Start, match.End)
			fmt.Printf("line %d [pattern %d]: %s\n", r.Line, match.PatternIdx, hi)
		}
	}
}

func highlightSpan(s string, start, end int) string {
	if start < 0 || end > len(s) || start >= end {
		return s
	}
	return s[:start] + "\033[1;31m" + s[start:end] + "\033[0m" + s[end:]
}
