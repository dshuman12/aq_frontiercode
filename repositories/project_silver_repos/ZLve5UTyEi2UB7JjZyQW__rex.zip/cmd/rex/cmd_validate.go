package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/syntax"
	"rex/internal/validate"
)

func cmdValidate(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	if err := validate.PatternCheck(pattern); err != nil {
		if flags.Has("json") {
			writeJSON(map[string]any{
				"pattern": pattern,
				"valid":   false,
				"error":   err.Error(),
			})
			return
		}
		fmt.Fprintf(os.Stderr, "invalid: %v\n", err)
		os.Exit(1)
	}

	compiled, err := compile.Compile(pattern)
	if err != nil {
		if flags.Has("json") {
			writeJSON(map[string]any{
				"pattern": pattern,
				"valid":   false,
				"error":   err.Error(),
			})
			return
		}
		fmt.Fprintf(os.Stderr, "invalid: %v\n", err)
		os.Exit(1)
	}

	if err := syntax.Validate(compiled.AST); err != nil {
		if flags.Has("json") {
			writeJSON(map[string]any{
				"pattern": pattern,
				"valid":   false,
				"error":   err.Error(),
			})
			return
		}
		fmt.Fprintf(os.Stderr, "invalid: %v\n", err)
		os.Exit(1)
	}

	features := syntax.Analyze(compiled.AST)

	if flags.Has("json") {
		writeJSON(map[string]any{
			"pattern":    pattern,
			"valid":      true,
			"nfa_states": compiled.NFA.StateCount(),
			"groups":     compiled.Groups,
			"features": map[string]any{
				"has_alternation": features.HasAltern,
				"has_repetition":  features.HasRepeat,
				"has_groups":      features.HasGroups,
				"has_char_class":  features.HasCharClass,
				"has_anchors":     features.HasAnchors,
				"has_dot":         features.HasDot,
			},
		})
		return
	}

	fmt.Printf("pattern is valid\n")
	fmt.Printf("  nfa states: %d\n", compiled.NFA.StateCount())
	fmt.Printf("  groups: %d\n", compiled.Groups)
}
