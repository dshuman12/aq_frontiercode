package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/match"
)

func cmdReplace(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")
	replacement := flags.RequirePositional(1, "replacement")
	input := flags.RequirePositional(2, "input")
	firstOnly := flags.Has("first")

	compiled, err := compile.Compile(pattern)

	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	var result string

	if firstOnly {
		result = match.ReplaceFirst(compiled, input, replacement)
	} else {
		result = match.Replace(compiled, input, replacement)
	}

	if flags.Has("json") {
		writeJSON(map[string]any{
			"pattern":     pattern,
			"replacement": replacement,
			"input":       input,
			"output":      result,
			"changed":     result != input,
		})
		return
	}

	fmt.Println(result)
}
