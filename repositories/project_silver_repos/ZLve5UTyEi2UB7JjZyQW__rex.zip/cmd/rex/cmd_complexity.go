package main

import (
	"fmt"

	"rex/internal/cli"
	"rex/internal/compile"
	"rex/internal/complexity"
)

func cmdComplexity(flags *cli.Flags) {
	pattern := flags.RequirePositional(0, "pattern")

	compiled, err := compile.Compile(pattern)
	if err != nil {
		exitErrf("bad pattern: %v", err)
	}

	result := complexity.Analyze(compiled.AST)

	if flags.Has("json") {
		out := map[string]any{
			"pattern": pattern,
			"rating":  result.Rating.String(),
			"reasons": result.Reasons,
		}
		writeJSON(out)
		return
	}

	fmt.Printf("pattern:    %s\n", pattern)
	fmt.Printf("complexity: %s\n", result.Rating)
	if len(result.Reasons) > 0 {
		for _, r := range result.Reasons {
			fmt.Printf("  warning: %s\n", r)
		}
	}
}
