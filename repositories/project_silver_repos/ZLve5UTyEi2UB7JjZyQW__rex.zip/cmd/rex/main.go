package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/config"
)

const version = "1.21.0"

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	cmd := os.Args[1]

	if cmd == "--version" || cmd == "-v" {
		fmt.Printf("rex %s\n", version)
		return
	}

	if cmd == "--help" || cmd == "-h" {
		printUsage()
		return
	}

	flags := cli.Parse(os.Args[2:])

	cfg := config.Load()
	for k, v := range cfg.DefaultFlags {
		if !flags.Has(k) {
			flags.SetDefault(k, v)
		}
	}

	switch cmd {
	case "match":
		cmdMatch(flags)
	case "find":
		cmdFind(flags)
	case "replace":
		cmdReplace(flags)
	case "test":
		cmdTest(flags)
	case "debug":
		cmdDebug(flags)
	case "explain":
		cmdExplain(flags)
	case "bench":
		cmdBench(flags)
	case "validate":
		cmdValidate(flags)
	case "convert":
		cmdConvert(flags)
	case "trace":
		cmdTrace(flags)
	case "gen":
		cmdGen(flags)
	case "repl":
		cmdRepl(flags)
	case "complexity":
		cmdComplexity(flags)
	case "equiv":
		cmdEquiv(flags)
	case "search":
		cmdSearch(flags)
	case "dot":
		cmdDot(flags)
	case "ast":
		cmdAST(flags)
	case "diff":
		cmdDiff(flags)
	case "serialize":
		cmdSerialize(flags)
	case "stats":
		cmdStats(flags)
	case "profile":
		cmdProfile(flags)
	default:
		fmt.Fprintf(os.Stderr, "unknown command: %s\n", cmd)
		printUsage()
		os.Exit(1)
	}
}

func printUsage() {
	fmt.Println(`rex - a regex engine.

usage: rex <command> [options]

commands:
  match       <pattern> <text>                       test if text matches pattern
  find        <pattern> [text|-]  [--all]            find matches in text or stdin
  replace     [--first] <pattern> <repl> <text>      replace matches
  test        <pattern> <text1> [text2..]            test against multiple strings
  debug       <pattern> [--format=fmt]               show NFA/DFA/VM states
  explain     <pattern>                              explain pattern in plain english
  bench       <pattern> <text> [--iterations=N]      benchmark matching
  validate    <pattern>                              check pattern syntax
  convert     <pattern> [--to=nfa|dfa|glob|like]     show conversion details
  trace       <pattern> <text>                       step-by-step execution trace
  gen         <pattern> [--count=N] [--seed=N]       generate matching strings
  repl                                               interactive REPL
  complexity  <pattern>                              static complexity analysis
  equiv       <pattern-a> <pattern-b>                check language equivalence
  search      <pattern1> [pattern2..] [--text=s]     multi-pattern search
  dot         <pattern> [--target=nfa|dfa]           export NFA/DFA as DOT graph
  ast         <pattern> [--normalize]                inspect AST structure
  diff        <pattern-a> <pattern-b>                structural AST diff
  serialize   <dump|load|roundtrip> <pattern|path>   serialize/deserialize AST
  stats       <pattern>                              show pattern metrics
  profile     <pattern> <text1> [text2..]            per-input timing profile

global flags:
  --json       output in JSON format
  --dfa        use DFA engine instead of NFA
  --vm         use VM (Pike) engine
  --help, -h   show help
  --version    show version`)
}
