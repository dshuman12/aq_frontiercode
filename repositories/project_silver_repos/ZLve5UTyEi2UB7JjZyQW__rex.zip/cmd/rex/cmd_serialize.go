package main

import (
	"fmt"
	"os"

	"rex/internal/cli"
	"rex/internal/parser"
	"rex/internal/proto"
	"rex/internal/walk"
)

func cmdSerialize(flags *cli.Flags) {
	sub := flags.Positional(0)
	switch sub {
	case "dump":
		pattern := flags.RequirePositional(1, "pattern")
		ast, err := parser.Parse(pattern)
		if err != nil {
			exitErrf("parse error: %v", err)
		}

		out := flags.Get("out", "")
		if out != "" {
			if err := proto.SaveToFile(ast, out); err != nil {
				exitErrf("save: %v", err)
			}
			fmt.Printf("saved to %s\n", out)
		} else {
			data, err := proto.Marshal(ast)
			if err != nil {
				exitErrf("marshal: %v", err)
			}
			fmt.Println(string(data))
		}

	case "load":
		path := flags.RequirePositional(1, "path")
		ast, err := proto.LoadFromFile(path)
		if err != nil {
			exitErrf("load: %v", err)
		}
		fmt.Printf("loaded AST: kind=%v nodes=%d\n", ast.Kind, walk.NodeCount(ast))

	case "roundtrip":
		pattern := flags.RequirePositional(1, "pattern")
		ast, err := parser.Parse(pattern)

		if err != nil {
			exitErrf("parse: %v", err)
		}

		data, err := proto.Marshal(ast)
		if err != nil {
			exitErrf("marshal: %v", err)
		}

		ast2, err := proto.Unmarshal(data)
		if err != nil {
			exitErrf("unmarshal: %v", err)
		}

		if ast.String() == ast2.String() {
			fmt.Println("roundtrip: OK")
		} else {
			fmt.Fprintf(os.Stderr, "roundtrip mismatch:\n  before: %s\n  after:  %s\n", ast.String(), ast2.String())
			os.Exit(1)
		}

	default:
		exitErr("usage: rex serialize <dump|load|roundtrip> ...")
	}
}
