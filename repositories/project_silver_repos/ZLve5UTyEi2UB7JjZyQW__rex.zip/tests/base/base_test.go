package base

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"testing"
)

var (
	rexBin      string
	projectRoot string
)

func TestMain(m *testing.M) {
	_, here, _, ok := runtime.Caller(0)

	if !ok {
		fmt.Fprintln(os.Stderr, "runtime.Caller failed")
		os.Exit(1)
	}

	root, err := filepath.Abs(filepath.Join(filepath.Dir(here), "..", ".."))

	if err != nil {
		fmt.Fprintf(os.Stderr, "abs path: %v\n", err)
		os.Exit(1)
	}

	projectRoot = root
	rexBin = filepath.Join(projectRoot, "rex_bin")

	build := exec.Command("go", "build", "-o", rexBin, "./cmd/rex")
	build.Dir = projectRoot

	if out, err := build.CombinedOutput(); err != nil {
		fmt.Fprintf(os.Stderr, "build failed: %v\n%s\n", err, out)
		os.Exit(1)
	}

	code := m.Run()
	_ = os.Remove(rexBin)
	os.Exit(code)
}

type result struct {
	stdout string
	stderr string
	code   int
}

func run(t *testing.T, args ...string) result {
	t.Helper()
	return runWithStdin(t, "", args...)
}

func runWithStdin(t *testing.T, stdin string, args ...string) result {
	t.Helper()
	cmd := exec.Command(rexBin, args...)
	cmd.Dir = projectRoot

	if stdin != "" {
		cmd.Stdin = strings.NewReader(stdin)
	}

	var out, errb strings.Builder
	cmd.Stdout = &out
	cmd.Stderr = &errb
	err := cmd.Run()
	code := 0

	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		} else {
			t.Fatalf("rex %v: %v", args, err)
		}
	}

	return result{out.String(), errb.String(), code}
}

func mustOK(t *testing.T, r result) result {
	t.Helper()
	if r.code != 0 {
		t.Fatalf("expected exit 0, got %d\nstdout: %s\nstderr: %s", r.code, r.stdout, r.stderr)
	}
	return r
}

func parseObj(t *testing.T, s string) map[string]any {
	t.Helper()
	var v map[string]any
	if err := json.Unmarshal([]byte(s), &v); err != nil {
		t.Fatalf("json object decode: %v\nbody: %s", err, s)
	}
	return v
}

func parseArr(t *testing.T, s string) []any {
	t.Helper()
	var v []any
	if err := json.Unmarshal([]byte(s), &v); err != nil {
		t.Fatalf("json array decode: %v\nbody: %s", err, s)
	}
	return v
}

func mustBool(t *testing.T, m map[string]any, key string) bool {
	t.Helper()
	v, ok := m[key]

	if !ok {
		t.Fatalf("key %q missing in %v", key, m)
	}

	b, ok := v.(bool)
	if !ok {
		t.Fatalf("key %q not bool: %T (%v)", key, v, v)
	}

	return b
}

func mustStr(t *testing.T, m map[string]any, key string) string {
	t.Helper()
	v, ok := m[key]

	if !ok {
		t.Fatalf("key %q missing in %v", key, m)
	}

	s, ok := v.(string)
	if !ok {
		t.Fatalf("key %q not string: %T", key, v)
	}

	return s
}

func mustNum(t *testing.T, m map[string]any, key string) float64 {
	t.Helper()
	v, ok := m[key]
	if !ok {
		t.Fatalf("key %q missing in %v", key, m)
	}
	f, ok := v.(float64)
	if !ok {
		t.Fatalf("key %q not number: %T", key, v)
	}
	return f
}

func matched(t *testing.T, args ...string) bool {
	t.Helper()
	r := run(t, args...)
	if r.stdout == "" {
		t.Fatalf("rex %v: empty stdout (stderr: %s)", args, r.stderr)
	}
	return mustBool(t, parseObj(t, r.stdout), "matched")
}

func splitNonEmpty(s string) []string {
	var out []string
	for _, l := range strings.Split(strings.TrimSpace(s), "\n") {
		if l != "" {
			out = append(out, l)
		}
	}
	return out
}

// match: literals, dot, escapes

func TestMatchLiterals(t *testing.T) {
	if !matched(t, "match", "hello", "hello", "--json") {
		t.Fatal("hello/hello should match")
	}
	if matched(t, "match", "hello", "world", "--json") {
		t.Fatal("hello/world should not match")
	}
}

func TestMatchDot(t *testing.T) {
	if !matched(t, "match", "a.c", "abc", "--json") {
		t.Fatal("a.c/abc")
	}
	if !matched(t, "match", "a.c", "aXc", "--json") {
		t.Fatal("a.c/aXc")
	}
	if matched(t, "match", "a.c", "ac", "--json") {
		t.Fatal("a.c should require one char between a and c")
	}
}

func TestMatchEscapedDot(t *testing.T) {
	if !matched(t, "match", `a\.b`, "a.b", "--json") {
		t.Fatal(`a\.b/a.b`)
	}
	if matched(t, "match", `a\.b`, "axb", "--json") {
		t.Fatal(`a\.b should be literal dot`)
	}
}

func TestMatchMetaclasses(t *testing.T) {
	if !matched(t, "match", `\d+`, "42", "--json") {
		t.Fatal(`\d+/42`)
	}
	if matched(t, "match", `\d+`, "abc", "--json") {
		t.Fatal(`\d+/abc`)
	}
	if !matched(t, "match", `\w+`, "hello_123", "--json") {
		t.Fatal(`\w+`)
	}
	if !matched(t, "match", `\s+`, "   ", "--json") {
		t.Fatal(`\s+`)
	}
}

// match: quantifiers

func TestMatchStar(t *testing.T) {
	if !matched(t, "match", "ab*c", "ac", "--json") {
		t.Fatal("ab*c/ac")
	}
	if !matched(t, "match", "ab*c", "abbc", "--json") {
		t.Fatal("ab*c/abbc")
	}
}

func TestMatchPlus(t *testing.T) {
	if !matched(t, "match", "ab+c", "abc", "--json") {
		t.Fatal("ab+c/abc")
	}
	if matched(t, "match", "ab+c", "ac", "--json") {
		t.Fatal("ab+c requires at least one b")
	}
}

func TestMatchOptional(t *testing.T) {
	if !matched(t, "match", "ab?c", "ac", "--json") {
		t.Fatal("ab?c/ac")
	}
	if !matched(t, "match", "ab?c", "abc", "--json") {
		t.Fatal("ab?c/abc")
	}
	if matched(t, "match", "ab?c", "abbc", "--json") {
		t.Fatal("ab?c rejects two bs")
	}
}

// match: groups, alternation, char classes, anchors

func TestMatchGroupRepetition(t *testing.T) {
	if !matched(t, "match", "(ab)+", "abab", "--json") {
		t.Fatal("(ab)+/abab")
	}
}

func TestMatchAlternation(t *testing.T) {
	if !matched(t, "match", "cat|dog", "dog", "--json") {
		t.Fatal("cat|dog/dog")
	}
	if matched(t, "match", "cat|dog", "fish", "--json") {
		t.Fatal("cat|dog/fish")
	}
	if !matched(t, "match", "(a|b)+c", "abbc", "--json") {
		t.Fatal("(a|b)+c/abbc")
	}
}

func TestMatchCharClassBasics(t *testing.T) {
	if !matched(t, "match", "[abc]", "b", "--json") {
		t.Fatal("[abc]/b")
	}
	if matched(t, "match", "[abc]", "d", "--json") {
		t.Fatal("[abc]/d")
	}
	if !matched(t, "match", "[a-z]+", "hello", "--json") {
		t.Fatal("[a-z]+")
	}
}

func TestMatchCharClassNegationAndDash(t *testing.T) {
	if !matched(t, "match", "[^abc]", "d", "--json") {
		t.Fatal("[^abc]/d")
	}
	if matched(t, "match", "[^abc]", "a", "--json") {
		t.Fatal("[^abc]/a")
	}
	if !matched(t, "match", "[-abc]", "-", "--json") {
		t.Fatal("[-abc]/-")
	}
}

func TestMatchAnchors(t *testing.T) {
	if !matched(t, "match", "^abc$", "abc", "--json") {
		t.Fatal("^abc$/abc")
	}
	if matched(t, "match", "^abc$", "xabc", "--json") {
		t.Fatal("^abc$/xabc")
	}
}

func TestMatchComplexPatterns(t *testing.T) {
	if !matched(t, "match", "(a|b)+c[d-f]*", "abcde", "--json") {
		t.Fatal("(a|b)+c[d-f]*")
	}
	if !matched(t, "match", "(a+)+", "aaa", "--json") {
		t.Fatal("(a+)+")
	}
	if !matched(t, "match", "(a|bc)*", "abcbc", "--json") {
		t.Fatal("(a|bc)*")
	}
	if !matched(t, "match", "(cat|dog)+[0-9]*", "catdog42", "--json") {
		t.Fatal("(cat|dog)+[0-9]*")
	}
}

// match: dfa engine, plain output

func TestMatchDFAEngine(t *testing.T) {
	if !matched(t, "match", "hello", "hello", "--dfa", "--json") {
		t.Fatal("dfa hello/hello")
	}
	if matched(t, "match", "hello", "world", "--dfa", "--json") {
		t.Fatal("dfa hello/world")
	}
	if !matched(t, "match", "(a|b)+c", "abbc", "--dfa", "--json") {
		t.Fatal("dfa (a|b)+c/abbc")
	}
}

func TestMatchPlainOutput(t *testing.T) {
	r := run(t, "match", "hello", "hello")
	if !strings.Contains(strings.ToLower(r.stdout), "true") {
		t.Fatalf("plain match should say true: %q", r.stdout)
	}
	r = run(t, "match", "hello", "world")
	if !strings.Contains(strings.ToLower(r.stdout), "false") {
		t.Fatalf("plain non-match should say false: %q", r.stdout)
	}
}

// find

func TestFindFirst(t *testing.T) {
	r := mustOK(t, run(t, "find", "cat", "the cat sat on the cat mat", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") {
		t.Fatal("found")
	}
	if mustStr(t, o, "text") != "cat" {
		t.Fatalf("text=%v", o["text"])
	}
	if mustNum(t, o, "start") != 4 {
		t.Fatalf("start=%v", o["start"])
	}
}

func TestFindAll(t *testing.T) {
	r := mustOK(t, run(t, "find", "--all", "cat", "the cat sat on the cat mat", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "count") != 2 {
		t.Fatalf("count=%v", o["count"])
	}
	matches := o["matches"].([]any)
	if matches[0].(map[string]any)["text"].(string) != "cat" {
		t.Fatal("first match text")
	}
	if matches[1].(map[string]any)["start"].(float64) != 19 {
		t.Fatal("second match start")
	}
}

func TestFindAllDigits(t *testing.T) {
	r := mustOK(t, run(t, "find", "--all", `\d+`, "abc 123 def 456", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "count") != 2 {
		t.Fatalf("count=%v", o["count"])
	}
	matches := o["matches"].([]any)
	if matches[0].(map[string]any)["text"].(string) != "123" {
		t.Fatal("first")
	}
	if matches[1].(map[string]any)["text"].(string) != "456" {
		t.Fatal("second")
	}
}

func TestFindNoMatch(t *testing.T) {
	r := run(t, "find", "xyz", "hello world", "--json")
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "found") {
		t.Fatal("xyz should not be found")
	}
}

func TestFindUnicode(t *testing.T) {
	r := mustOK(t, run(t, "find", "héllo", "say héllo world", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") {
		t.Fatal("found")
	}
	if mustStr(t, o, "text") != "héllo" {
		t.Fatalf("text=%v", o["text"])
	}
}

// replace

func TestReplaceAll(t *testing.T) {
	r := mustOK(t, run(t, "replace", `\d+`, "NUM", "abc 123 def 456", "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "output") != "abc NUM def NUM" {
		t.Fatalf("output=%v", o["output"])
	}
	if !mustBool(t, o, "changed") {
		t.Fatal("changed")
	}
}

func TestReplaceFirst(t *testing.T) {
	r := mustOK(t, run(t, "replace", "--first", `\d+`, "NUM", "abc 123 def 456", "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "output") != "abc NUM def 456" {
		t.Fatalf("output=%v", o["output"])
	}

	r = mustOK(t, run(t, "replace", "cat", "dog", "the cat sat on the cat mat", "--first", "--json"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "output") != "the dog sat on the cat mat" {
		t.Fatalf("output=%v", o["output"])
	}
}

func TestReplaceNoMatch(t *testing.T) {
	r := run(t, "replace", "xyz", "abc", "hello world", "--json")
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "changed") {
		t.Fatal("changed should be false")
	}
	if mustStr(t, o, "output") != "hello world" {
		t.Fatalf("output=%v", o["output"])
	}
}

func TestReplaceDot(t *testing.T) {
	r := mustOK(t, run(t, "replace", ".", "X", "abc", "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "output") != "XXX" {
		t.Fatalf("output=%v", o["output"])
	}
}

// test

func TestTestSubcommand(t *testing.T) {
	r := mustOK(t, run(t, "test", "a+b", "aab", "ccc", "--json"))
	o := parseObj(t, r.stdout)
	results := o["results"].([]any)
	if !results[0].(map[string]any)["matched"].(bool) {
		t.Fatal("aab matches a+b")
	}
	if results[1].(map[string]any)["matched"].(bool) {
		t.Fatal("ccc does not match a+b")
	}

	r = run(t, "test", "a+b", "aab", "ccc")
	if !strings.Contains(r.stdout, "pass") || !strings.Contains(r.stdout, "fail") {
		t.Fatalf("plain test should print pass and fail: %q", r.stdout)
	}
}

// validate

func TestValidateBasic(t *testing.T) {
	r := mustOK(t, run(t, "validate", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "valid") {
		t.Fatal("a+b should be valid")
	}
	if mustNum(t, o, "nfa_states") <= 0 {
		t.Fatalf("nfa_states=%v", o["nfa_states"])
	}
}

func TestValidateFeatureFlags(t *testing.T) {
	r := mustOK(t, run(t, "validate", `(a|b)+[c-f]*\d`, "--json"))
	o := parseObj(t, r.stdout)
	feat := o["features"].(map[string]any)
	if !feat["has_alternation"].(bool) {
		t.Fatal("has_alternation")
	}
	if !feat["has_char_class"].(bool) {
		t.Fatal("has_char_class")
	}
	if !feat["has_groups"].(bool) {
		t.Fatal("has_groups")
	}
}

func TestValidateInvalidPattern(t *testing.T) {
	r := run(t, "validate", "(abc", "--json")
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "valid") {
		t.Fatal("(abc should be invalid")
	}
	if _, ok := o["error"]; !ok {
		t.Fatal("expected error key")
	}
}

// explain

func TestExplainBasic(t *testing.T) {
	r := mustOK(t, run(t, "explain", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	exp := mustStr(t, o, "explanation")
	low := strings.ToLower(exp)
	if !strings.Contains(low, "repeat") && !strings.Contains(exp, "+") {
		t.Fatalf("explanation lacks repeat/+: %q", exp)
	}
}

// debug

func TestDebugTextFormat(t *testing.T) {
	r := mustOK(t, run(t, "debug", "a+b"))
	if !strings.Contains(r.stdout, "NFA:") {
		t.Fatalf("debug missing NFA:: %q", r.stdout)
	}
	if !strings.Contains(strings.ToLower(r.stdout), "accept") {
		t.Fatalf("debug missing accept: %q", r.stdout)
	}
}

func TestDebugDotFormat(t *testing.T) {
	r := mustOK(t, run(t, "debug", "a+b", "--format=dot"))
	if !strings.Contains(r.stdout, "digraph") {
		t.Fatal("dot output missing digraph")
	}
	if !strings.Contains(r.stdout, "->") {
		t.Fatal("dot output missing edges")
	}
}

func TestDebugBadFormat(t *testing.T) {
	r := run(t, "debug", "a+b", "--format=badformat")
	if r.code == 0 {
		t.Fatal("bad format should error")
	}
}

// trace

func TestTraceMatched(t *testing.T) {
	r := mustOK(t, run(t, "trace", "a+b", "aaab", "--json"))
	o := parseObj(t, r.stdout)
	steps := o["steps"].([]any)
	if len(steps) == 0 {
		t.Fatal("expected steps")
	}
	last := steps[len(steps)-1].(map[string]any)
	if !last["matched"].(bool) {
		t.Fatal("last step should match")
	}
}

func TestTraceUnmatched(t *testing.T) {
	r := mustOK(t, run(t, "trace", "a+b", "ccc", "--json"))
	o := parseObj(t, r.stdout)
	steps := o["steps"].([]any)
	for _, s := range steps {
		if s.(map[string]any)["matched"].(bool) {
			t.Fatal("no step should match for ccc")
		}
	}
}

// bench

func TestBenchBasic(t *testing.T) {
	r := mustOK(t, run(t, "bench", "a+b", "aaab", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "iterations") <= 0 {
		t.Fatal("iterations")
	}
	if !mustBool(t, o, "matched") {
		t.Fatal("matched")
	}
}

func TestBenchCompare(t *testing.T) {
	r := mustOK(t, run(t, "bench", "--compare", "a+b", "aaab", "--json"))
	o := parseObj(t, r.stdout)
	if !o["nfa"].(map[string]any)["matched"].(bool) {
		t.Fatal("nfa.matched")
	}
	if !o["dfa"].(map[string]any)["matched"].(bool) {
		t.Fatal("dfa.matched")
	}
}

func TestBenchReportFlag(t *testing.T) {
	r := mustOK(t, run(t, "bench", "a+", "aaa", "--report"))
	for _, k := range []string{"bench results", "[pattern]", "[engine]", "[iterations]", "[matched]"} {
		if !strings.Contains(r.stdout, k) {
			t.Fatalf("report missing %q: %q", k, r.stdout)
		}
	}

	r = mustOK(t, run(t, "bench", "a+", "aaa", "--dfa", "--report"))
	if !strings.Contains(r.stdout, "DFA") || !strings.Contains(r.stdout, "[engine]") {
		t.Fatal("dfa report markers missing")
	}

	r = mustOK(t, run(t, "bench", "a+", "aaa"))
	if strings.Contains(r.stdout, "[pattern]") {
		t.Fatalf("non-report should not include [pattern]: %q", r.stdout)
	}
}

// convert

func TestConvertBasic(t *testing.T) {
	r := mustOK(t, run(t, "convert", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "nfa_states") <= 0 {
		t.Fatal("nfa_states")
	}
	if mustNum(t, o, "dfa_states") <= 0 {
		t.Fatal("dfa_states")
	}
}

func TestConvertGlob(t *testing.T) {
	r := mustOK(t, run(t, "convert", "*.txt", "--to=glob"))
	if !strings.Contains(r.stdout, "regex:") || !strings.Contains(r.stdout, "txt") {
		t.Fatalf("glob: %q", r.stdout)
	}
}

func TestConvertLike(t *testing.T) {
	r := mustOK(t, run(t, "convert", "foo%bar", "--to=like"))
	if !strings.Contains(r.stdout, "regex:") || !strings.Contains(r.stdout, "foo") || !strings.Contains(r.stdout, "bar") {
		t.Fatalf("like: %q", r.stdout)
	}
}

func TestConvertNFAandDFA(t *testing.T) {
	r := mustOK(t, run(t, "convert", "a+b", "--to=nfa"))
	if !strings.Contains(r.stdout, "NFA:") || !strings.Contains(r.stdout, "states") {
		t.Fatalf("nfa: %q", r.stdout)
	}

	r = mustOK(t, run(t, "convert", "a+b", "--to=dfa"))
	if !strings.Contains(r.stdout, "DFA") {
		t.Fatalf("dfa: %q", r.stdout)
	}
}

func TestConvertInvalidTarget(t *testing.T) {
	r := run(t, "convert", "a+b", "--to=invalid")
	if r.code == 0 {
		t.Fatal("invalid target should error")
	}
}

// CLI: version, help, errors

func TestVersionFlag(t *testing.T) {
	r := mustOK(t, run(t, "--version"))
	if !strings.Contains(r.stdout, "rex") {
		t.Fatalf("version missing 'rex': %q", r.stdout)
	}
	hasDigit := false
	for _, c := range r.stdout {
		if c >= '0' && c <= '9' {
			hasDigit = true
			break
		}
	}
	if !hasDigit {
		t.Fatalf("version missing digit: %q", r.stdout)
	}
}

func TestHelpFlag(t *testing.T) {
	r := mustOK(t, run(t, "--help"))
	if !strings.Contains(strings.ToLower(r.stdout), "usage") {
		t.Fatalf("help missing usage: %q", r.stdout)
	}
	for _, cmd := range []string{"match", "find", "replace", "test", "debug", "explain", "bench", "validate", "convert", "trace"} {
		if !strings.Contains(r.stdout, cmd) {
			t.Fatalf("help missing %q", cmd)
		}
	}
}

func TestInvalidPatternError(t *testing.T) {
	r := run(t, "match", "(unclosed", "test", "--json")
	if r.code == 0 {
		t.Fatal("invalid pattern should error")
	}
}

func TestUnknownCommandError(t *testing.T) {
	r := run(t, "notacommand")
	if r.code == 0 {
		t.Fatal("unknown command should error")
	}
}

func TestMissingArgsError(t *testing.T) {
	if r := run(t, "match"); r.code == 0 {
		t.Fatal("match with no args should error")
	}
	if r := run(t, "find"); r.code == 0 {
		t.Fatal("find with no args should error")
	}
}

// lazy quantifiers, range repeat, named, noncapturing groups

func TestLazyQuantifiers(t *testing.T) {
	if !matched(t, "match", "a+?", "aaa", "--json") {
		t.Fatal("a+?/aaa")
	}
	if !matched(t, "match", "a+?b", "aaab", "--json") {
		t.Fatal("a+?b/aaab")
	}
	if !matched(t, "match", "a*?b", "b", "--json") {
		t.Fatal("a*?b/b")
	}
	if !matched(t, "match", "a*?b", "aab", "--json") {
		t.Fatal("a*?b/aab")
	}
	if matched(t, "match", "a*?b", "aac", "--json") {
		t.Fatal("a*?b/aac")
	}
	if !matched(t, "match", "a??b", "b", "--json") {
		t.Fatal("a??b/b")
	}
	if !matched(t, "match", "a??b", "ab", "--json") {
		t.Fatal("a??b/ab")
	}

	r := mustOK(t, run(t, "find", "a+?", "aaa", "--json"))
	o := parseObj(t, r.stdout)

	if !mustBool(t, o, "found") {
		t.Fatal("found")
	}
	if mustNum(t, o, "start") != 0 {
		t.Fatalf("start=%v", o["start"])
	}

	r = mustOK(t, run(t, "find", "a.*?b", "aXbYb", "--json"))
	o = parseObj(t, r.stdout)

	if !mustBool(t, o, "found") {
		t.Fatal("found a.*?b")
	}

	tx := mustStr(t, o, "text")
	if !strings.HasPrefix(tx, "a") || !strings.HasSuffix(tx, "b") {
		t.Fatalf("a.*?b text=%q", tx)
	}
}

func TestRangeRepeatExact(t *testing.T) {
	if !matched(t, "match", "a{3}", "aaa", "--json") {
		t.Fatal("a{3}/aaa")
	}
	if matched(t, "match", "a{3}", "aa", "--json") {
		t.Fatal("a{3}/aa")
	}
	if matched(t, "match", "a{3}", "aaaa", "--json") {
		t.Fatal("a{3}/aaaa")
	}
}

func TestRangeRepeatBounded(t *testing.T) {
	if !matched(t, "match", "a{2,4}", "aa", "--json") {
		t.Fatal("a{2,4}/aa")
	}
	if !matched(t, "match", "a{2,4}", "aaaa", "--json") {
		t.Fatal("a{2,4}/aaaa")
	}
	if matched(t, "match", "a{2,4}", "a", "--json") {
		t.Fatal("a{2,4}/a")
	}
	if matched(t, "match", "a{2,4}", "aaaaa", "--json") {
		t.Fatal("a{2,4}/aaaaa")
	}
	if !matched(t, "match", `\d{3}-\d{4}`, "555-1234", "--json") {
		t.Fatal(`\d{3}-\d{4}`)
	}
	if matched(t, "match", `\d{3}-\d{4}`, "55-1234", "--json") {
		t.Fatal("short fail")
	}
}

func TestRangeRepeatOpen(t *testing.T) {
	if !matched(t, "match", "a{2,}", "aa", "--json") {
		t.Fatal("a{2,}/aa")
	}
	if !matched(t, "match", "a{2,}", "aaaaaaa", "--json") {
		t.Fatal("a{2,}/aaaaaaa")
	}
	if matched(t, "match", "a{2,}", "a", "--json") {
		t.Fatal("a{2,}/a")
	}
}

func TestNoncapturingGroups(t *testing.T) {
	if !matched(t, "match", "(?:ab)+", "ababab", "--json") {
		t.Fatal("(?:ab)+")
	}
	if !matched(t, "match", "(?:cat|dog)", "cat", "--json") {
		t.Fatal("(?:cat|dog)/cat")
	}
	if matched(t, "match", "(?:cat|dog)", "fish", "--json") {
		t.Fatal("(?:cat|dog)/fish")
	}
}

func TestNamedGroups(t *testing.T) {
	r := mustOK(t, run(t, "find", `(?P<word>\w+)`, "hello", "--groups", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") {
		t.Fatal("found")
	}
	named := o["named"].(map[string]any)
	if named["word"].(map[string]any)["text"].(string) != "hello" {
		t.Fatal("named word")
	}

	r = mustOK(t, run(t, "find", `(?P<year>\d{4})-(?P<month>\d{2})`, "2024-01", "--groups", "--json"))
	o = parseObj(t, r.stdout)
	named = o["named"].(map[string]any)
	if named["year"].(map[string]any)["text"].(string) != "2024" {
		t.Fatal("year")
	}
	if named["month"].(map[string]any)["text"].(string) != "01" {
		t.Fatal("month")
	}
}

func TestNestedCapturingGroups(t *testing.T) {
	r := mustOK(t, run(t, "find", `((\d+))`, "42", "--groups", "--json"))
	o := parseObj(t, r.stdout)
	groups := o["groups"].([]any)
	if len(groups) != 2 {
		t.Fatalf("expected 2 groups, got %d", len(groups))
	}
	if groups[0].(map[string]any)["text"].(string) != "42" {
		t.Fatal("group 0 text")
	}
}

// word boundary, escapes, posix

func TestWordBoundary(t *testing.T) {
	if !matched(t, "match", `\bhello\b`, "hello", "--json") {
		t.Fatal(`\bhello\b/hello`)
	}

	r := mustOK(t, run(t, "find", `\bhello\b`, "say hello world", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") || mustStr(t, o, "text") != "hello" {
		t.Fatalf("expected hello: %v", o)
	}

	r = mustOK(t, run(t, "find", `\b\w+\b`, "test", "--json"))
	o = parseObj(t, r.stdout)
	if !mustBool(t, o, "found") || mustStr(t, o, "text") != "test" {
		t.Fatalf("word: %v", o)
	}
}

func TestNonWordBoundary(t *testing.T) {
	r := mustOK(t, run(t, "find", `\Bhello\B`, "sayhelloworld", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") || mustStr(t, o, "text") != "hello" {
		t.Fatalf("non-boundary: %v", o)
	}

	r = run(t, "find", `\Bhello\B`, "hello world", "--json")
	o = parseObj(t, r.stdout)
	if mustBool(t, o, "found") {
		t.Fatal("\\Bhello\\B should not find with leading boundary")
	}
}

func TestHexEscapes(t *testing.T) {
	if !matched(t, "match", `\x41`, "A", "--json") {
		t.Fatal(`\x41/A`)
	}
	if !matched(t, "match", `\x61\x62\x63`, "abc", "--json") {
		t.Fatal("hex abc")
	}
	if !matched(t, "match", `\x41+`, "AAA", "--json") {
		t.Fatal(`\x41+/AAA`)
	}
	if matched(t, "match", `\x41`, "B", "--json") {
		t.Fatal(`\x41/B`)
	}
}

func TestUnicodeEscapes(t *testing.T) {
	if !matched(t, "match", `\u0041`, "A", "--json") {
		t.Fatal(`\u0041/A`)
	}
	if !matched(t, "match", `\u0048\u0065\u006C\u006C\u006F`, "Hello", "--json") {
		t.Fatal("unicode Hello")
	}
}

func TestOctalEscapes(t *testing.T) {
	if !matched(t, "match", `\0101`, "A", "--json") {
		t.Fatal(`\0101/A`)
	}
}

func TestPosixCharClasses(t *testing.T) {
	cases := []struct{ cls, char, bad string }{
		{"alpha", "a", "1"},
		{"digit", "5", "a"},
		{"alnum", "a", "!"},
		{"space", " ", "a"},
		{"upper", "A", "a"},
		{"lower", "a", "A"},
		{"punct", "!", "a"},
	}

	for _, c := range cases {
		pat := fmt.Sprintf("[[:%s:]]", c.cls)
		if !matched(t, "match", pat, c.char, "--json") {
			t.Fatalf("[:%s:] should match %q", c.cls, c.char)
		}
		if matched(t, "match", pat, c.bad, "--json") {
			t.Fatalf("[:%s:] should not match %q", c.cls, c.bad)
		}
	}

	if !matched(t, "match", `[[:alpha:]]+\d+`, "abc123", "--json") {
		t.Fatal("alpha+digit")
	}
	if !matched(t, "match", "[[:upper:]][[:lower:]]+", "Hello", "--json") {
		t.Fatal("upper+lower Hello")
	}
	if !matched(t, "match", "[^[:digit:]]", "a", "--json") {
		t.Fatal("[^[:digit:]]/a")
	}
	if matched(t, "match", "[^[:digit:]]", "5", "--json") {
		t.Fatal("[^[:digit:]]/5")
	}
}

// vm engine

func TestVMFind(t *testing.T) {
	r := mustOK(t, run(t, "find", `\d+`, "42 abc", "--vm", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") || mustStr(t, o, "text") != "42" {
		t.Fatalf("vm find: %v", o)
	}
}

func TestVMGroups(t *testing.T) {
	r := mustOK(t, run(t, "find", `(a+)`, "aaab", "--vm", "--groups", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "found") {
		t.Fatal("vm groups found")
	}
	groups := o["groups"].([]any)
	if len(groups) < 1 {
		t.Fatalf("groups=%v", groups)
	}
	if groups[0].(map[string]any)["text"].(string) != "aaa" {
		t.Fatalf("group0=%v", groups[0])
	}

	r = mustOK(t, run(t, "find", `(\d+)`, "42 abc", "--vm", "--groups", "--json"))
	o = parseObj(t, r.stdout)
	groups = o["groups"].([]any)
	if groups[0].(map[string]any)["text"].(string) != "42" {
		t.Fatalf("vm \\d+ group: %v", groups[0])
	}
}

func TestVMNoMatch(t *testing.T) {
	r := run(t, "find", "xyz", "hello world", "--vm", "--json")
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "found") {
		t.Fatal("vm xyz should not match")
	}
}

func TestVMDebug(t *testing.T) {
	r := mustOK(t, run(t, "debug", `(a+)b`, "--vm"))
	low := strings.ToLower(r.stdout)
	if !strings.Contains(low, "save") || !strings.Contains(low, "char") || !strings.Contains(low, "match") {
		t.Fatalf("vm debug missing ops: %q", r.stdout)
	}
}

// inline flags

func TestInlineFlagCaseInsensitive(t *testing.T) {
	if !matched(t, "match", "(?i)hello", "HELLO", "--json") {
		t.Fatal("(?i)/HELLO")
	}
	if !matched(t, "match", "(?i)hello", "Hello", "--json") {
		t.Fatal("(?i)/Hello")
	}
	if !matched(t, "match", "(?i)[a-z]+", "UPPER", "--json") {
		t.Fatal("(?i)[a-z]+/UPPER")
	}
	if matched(t, "match", "(?i)abc", "xyz", "--json") {
		t.Fatal("(?i)abc/xyz")
	}
}

func TestInlineFlagDotall(t *testing.T) {
	if !matched(t, "match", "(?s)a.b", "axb", "--json") {
		t.Fatal("(?s)a.b/axb")
	}
	if matched(t, "match", "a.b", "a\nb", "--json") {
		t.Fatal("a.b should not match newline without dotall")
	}
}

func TestInlineFlagMultiline(t *testing.T) {
	r := run(t, "find", "(?m)^foo", "bar\nfoo\nbaz", "--json")
	o := parseObj(t, r.stdout)
	if _, ok := o["found"]; !ok {
		t.Fatalf("expected 'found' key: %v", o)
	}
}

// complexity

func TestComplexityExponential(t *testing.T) {
	r := mustOK(t, run(t, "complexity", "(a+)+", "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "rating") != "exponential" {
		t.Fatalf("rating=%v", o["rating"])
	}

	r = mustOK(t, run(t, "complexity", "(a|b)+", "--json"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "rating") != "exponential" {
		t.Fatalf("rating=%v", o["rating"])
	}

	r = mustOK(t, run(t, "complexity", "(a+)+"))
	if !strings.Contains(r.stdout, "exponential") {
		t.Fatalf("plain: %q", r.stdout)
	}
}

func TestComplexityLinear(t *testing.T) {
	r := mustOK(t, run(t, "complexity", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "rating") != "linear" {
		t.Fatalf("rating=%v", o["rating"])
	}

	r = mustOK(t, run(t, "complexity", `\d+\w*`, "--json"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "rating") != "linear" {
		t.Fatalf("rating=%v", o["rating"])
	}

	r = mustOK(t, run(t, "complexity", "a+b"))
	if !strings.Contains(r.stdout, "linear") {
		t.Fatalf("plain: %q", r.stdout)
	}
}

// equiv

func TestEquivEqual(t *testing.T) {
	r := mustOK(t, run(t, "equiv", "a|b", "b|a", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "equivalent") {
		t.Fatal("a|b == b|a")
	}

	r = mustOK(t, run(t, "equiv", `\d`, "[0-9]", "--json"))
	o = parseObj(t, r.stdout)
	if !mustBool(t, o, "equivalent") {
		t.Fatal(`\d == [0-9]`)
	}

	r = mustOK(t, run(t, "equiv", "a|b", "b|a"))
	if !strings.Contains(r.stdout, "equivalent: true") {
		t.Fatalf("plain: %q", r.stdout)
	}
}

func TestEquivNotEqual(t *testing.T) {
	r := mustOK(t, run(t, "equiv", "a+", "a*", "--json"))
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "equivalent") {
		t.Fatal("a+ != a*")
	}

	r = mustOK(t, run(t, "equiv", "abc", "def", "--json"))
	o = parseObj(t, r.stdout)
	if mustBool(t, o, "equivalent") {
		t.Fatal("abc != def")
	}

	r = mustOK(t, run(t, "equiv", "a+", "b+"))
	if !strings.Contains(r.stdout, "equivalent: false") {
		t.Fatalf("plain: %q", r.stdout)
	}
}

func TestEquivKeyPresent(t *testing.T) {
	r := mustOK(t, run(t, "equiv", "a+", "aa*", "--json"))
	o := parseObj(t, r.stdout)
	if _, ok := o["equivalent"]; !ok {
		t.Fatal("missing equivalent key")
	}
}

// gen

func TestGenCount(t *testing.T) {
	r := mustOK(t, run(t, "gen", `\d{3}-\d{4}`, "--count=5"))
	lines := splitNonEmpty(r.stdout)
	if len(lines) != 5 {
		t.Fatalf("expected 5 lines, got %d: %q", len(lines), r.stdout)
	}

	re := regexp.MustCompile(`^\d{3}-\d{4}$`)
	for _, l := range lines {
		if !re.MatchString(l) {
			t.Fatalf("generated %q does not match \\d{3}-\\d{4}", l)
		}
	}

	r = mustOK(t, run(t, "gen", "[a-z]+", "--count=3"))
	lines = splitNonEmpty(r.stdout)
	if len(lines) != 3 {
		t.Fatalf("expected 3 lines: %q", r.stdout)
	}

	re = regexp.MustCompile(`^[a-z]+$`)
	for _, l := range lines {
		if !re.MatchString(l) {
			t.Fatalf("generated %q not [a-z]+", l)
		}
	}
}

func TestGenSeedReproducibility(t *testing.T) {
	r1 := mustOK(t, run(t, "gen", `\w+`, "--count=3", "--seed=42"))
	r2 := mustOK(t, run(t, "gen", `\w+`, "--count=3", "--seed=42"))
	if r1.stdout != r2.stdout {
		t.Fatalf("seeded gen not reproducible:\n%q\nvs\n%q", r1.stdout, r2.stdout)
	}
}

// search

func TestSearchPlainText(t *testing.T) {
	r := mustOK(t, run(t, "search", "hello", "world", "--text=hello world test"))
	if !strings.Contains(r.stdout, "hello") || !strings.Contains(r.stdout, "world") {
		t.Fatalf("search plain: %q", r.stdout)
	}
}

func TestSearchJSON(t *testing.T) {
	r := mustOK(t, run(t, "search", "foo", "bar", "--text=foobar test", "--json"))
	arr := parseArr(t, r.stdout)
	if len(arr) == 0 {
		t.Fatal("expected non-empty array")
	}
	first := arr[0].(map[string]any)
	if first["line"].(float64) != 1 {
		t.Fatalf("line=%v", first["line"])
	}
}

func TestSearchNoMatches(t *testing.T) {
	r := mustOK(t, run(t, "search", "xyz", "--text=hello world"))
	if !strings.Contains(r.stdout, "no matches") {
		t.Fatalf("expected 'no matches', got %q", r.stdout)
	}
}

func TestSearchStdin(t *testing.T) {
	r := runWithStdin(t, "hello world\nfoo bar\nhello again", "search", "hello", "world")
	if r.code != 0 {
		t.Fatalf("stdin search exit %d: %s", r.code, r.stderr)
	}
	if !strings.Contains(r.stdout, "hello") {
		t.Fatalf("stdin search: %q", r.stdout)
	}
}

func TestSearchPatternIndex(t *testing.T) {
	r := mustOK(t, run(t, "search", "hello", "world", "--text=hello world", "--json"))
	arr := parseArr(t, r.stdout)
	hasHello, hasWorld := false, false

	for _, line := range arr {
		ms := line.(map[string]any)["matches"].([]any)

		for _, m := range ms {
			p := m.(map[string]any)["Pattern"].(string)
			if p == "hello" {
				hasHello = true
			}
			if p == "world" {
				hasWorld = true
			}
		}
	}

	if !hasHello || !hasWorld {
		t.Fatalf("expected both: hello=%v world=%v", hasHello, hasWorld)
	}
}

func TestSearchMissingArgs(t *testing.T) {
	r := run(t, "search")
	if r.code == 0 {
		t.Fatal("search without args should error")
	}
}

// dot

func TestDotNFA(t *testing.T) {
	r := mustOK(t, run(t, "dot", "a(b|c)+", "--target=nfa"))
	if !strings.Contains(r.stdout, "digraph NFA") {
		t.Fatal("missing digraph NFA")
	}
	if !strings.Contains(r.stdout, "->") || !strings.Contains(r.stdout, "__start") {
		t.Fatal("nfa dot incomplete")
	}
}

func TestDotDFA(t *testing.T) {
	r := mustOK(t, run(t, "dot", "a(b|c)+", "--target=dfa"))
	if !strings.Contains(r.stdout, "digraph DFA") || !strings.Contains(r.stdout, "doublecircle") {
		t.Fatal("dfa dot missing markers")
	}
}

func TestDotDefault(t *testing.T) {
	r := mustOK(t, run(t, "dot", "a+b"))
	if !strings.Contains(r.stdout, "digraph") {
		t.Fatal("default dot missing digraph")
	}
}

func TestDotInvalidTarget(t *testing.T) {
	r := run(t, "dot", "a+", "--target=invalid")
	if r.code == 0 {
		t.Fatal("invalid target should error")
	}
}

func TestDotComplexPattern(t *testing.T) {
	r := mustOK(t, run(t, "dot", `\d+-\w+`, "--target=nfa"))
	if !strings.Contains(r.stdout, "digraph NFA") {
		t.Fatal("nfa for \\d+-\\w+")
	}
	r = mustOK(t, run(t, "dot", `\d+-\w+`, "--target=dfa"))
	if !strings.Contains(r.stdout, "digraph DFA") {
		t.Fatal("dfa for \\d+-\\w+")
	}
}

// ast

func TestASTJSON(t *testing.T) {
	r := mustOK(t, run(t, "ast", "(a|b)+c", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "nodes") <= 0 {
		t.Fatal("nodes")
	}
	if mustNum(t, o, "depth") <= 0 {
		t.Fatal("depth")
	}
	if mustStr(t, o, "pattern") != "(a|b)+c" {
		t.Fatalf("pattern=%v", o["pattern"])
	}
}

func TestASTPlain(t *testing.T) {
	r := mustOK(t, run(t, "ast", "(a|b)+c"))
	if !strings.Contains(r.stdout, "nodes:") || !strings.Contains(r.stdout, "depth:") {
		t.Fatalf("plain ast: %q", r.stdout)
	}
}

func TestASTNormalize(t *testing.T) {
	a := mustOK(t, run(t, "ast", "(a|b)+c", "--json"))
	b := mustOK(t, run(t, "ast", "(a|b)+c", "--normalize", "--json"))
	if mustNum(t, parseObj(t, a.stdout), "nodes") != mustNum(t, parseObj(t, b.stdout), "nodes") {
		t.Fatal("normalize should preserve node count for this pattern")
	}
}

func TestASTSimplePattern(t *testing.T) {
	r := mustOK(t, run(t, "ast", "abc", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "nodes") < 3 {
		t.Fatalf("abc nodes=%v", o["nodes"])
	}

	r = mustOK(t, run(t, "ast", "a", "--json"))
	o = parseObj(t, r.stdout)
	if mustNum(t, o, "depth") < 1 {
		t.Fatalf("a depth=%v", o["depth"])
	}
}

func TestASTInvalidPattern(t *testing.T) {
	r := run(t, "ast", "(invalid")
	if r.code == 0 {
		t.Fatal("invalid pattern should error")
	}
}

// diff

func TestDiffChanges(t *testing.T) {
	r := mustOK(t, run(t, "diff", "a|b", "a|c", "--json"))
	o := parseObj(t, r.stdout)
	if len(o["changes"].([]any)) == 0 {
		t.Fatal("expected changes")
	}

	r = mustOK(t, run(t, "diff", `\d`, `\w`, "--json"))
	o = parseObj(t, r.stdout)
	if len(o["changes"].([]any)) == 0 {
		t.Fatal("\\d vs \\w should differ")
	}
}

func TestDiffIdentical(t *testing.T) {
	r := mustOK(t, run(t, "diff", "a+b", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	if len(o["changes"].([]any)) != 0 {
		t.Fatalf("identical patterns should have no changes: %v", o["changes"])
	}

	r = mustOK(t, run(t, "diff", "a+b", "a+b"))
	if !strings.Contains(r.stdout, "identical") {
		t.Fatalf("plain identical: %q", r.stdout)
	}
}

func TestDiffPlainOutput(t *testing.T) {
	r := mustOK(t, run(t, "diff", "a|b", "a|c"))
	if !strings.Contains(r.stdout, "ch=") {
		t.Fatalf("plain diff: %q", r.stdout)
	}
}

func TestDiffInvalid(t *testing.T) {
	r := run(t, "diff", "(unclosed", "a+")
	if r.code == 0 {
		t.Fatal("invalid pattern should error")
	}
}

// serialize

func TestSerializeDump(t *testing.T) {
	r := mustOK(t, run(t, "serialize", "dump", `\d+`))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "kind") != "repeat" {
		t.Fatalf("kind=%v", o["kind"])
	}
	child := o["child"].(map[string]any)
	if child["kind"].(string) != "charclass" {
		t.Fatalf("child kind=%v", child["kind"])
	}
	if len(child["ranges"].([]any)) == 0 {
		t.Fatal("ranges empty")
	}

	r = mustOK(t, run(t, "serialize", "dump", "abc"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "kind") != "concat" {
		t.Fatalf("abc kind=%v", o["kind"])
	}
	if len(o["children"].([]any)) != 3 {
		t.Fatalf("abc children=%d", len(o["children"].([]any)))
	}
}

func TestSerializeRoundtrip(t *testing.T) {
	r := mustOK(t, run(t, "serialize", "roundtrip", `(\d+)-(\w+)`))
	if !strings.Contains(r.stdout, "roundtrip: OK") {
		t.Fatalf("roundtrip: %q", r.stdout)
	}

	r = mustOK(t, run(t, "serialize", "roundtrip", "(a|b)+c"))
	if !strings.Contains(r.stdout, "roundtrip: OK") {
		t.Fatalf("roundtrip: %q", r.stdout)
	}
}

func TestSerializeLoad(t *testing.T) {
	dump := mustOK(t, run(t, "serialize", "dump", "a+b"))
	tmp, err := os.CreateTemp("", "rex-ser-*.json")

	if err != nil {
		t.Fatalf("temp file: %v", err)
	}

	defer os.Remove(tmp.Name())

	if _, err := tmp.WriteString(dump.stdout); err != nil {
		t.Fatalf("write: %v", err)
	}

	tmp.Close()

	r := mustOK(t, run(t, "serialize", "load", tmp.Name()))
	if !strings.Contains(r.stdout, "loaded AST") || !strings.Contains(r.stdout, "nodes=") {
		t.Fatalf("load: %q", r.stdout)
	}
}

func TestSerializeBadCommand(t *testing.T) {
	r := run(t, "serialize", "badcmd")
	if r.code == 0 {
		t.Fatal("badcmd should error")
	}
}

// stats

func TestStatsWithGroups(t *testing.T) {
	r := mustOK(t, run(t, "stats", "(a|b)+", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "ASTNodes") <= 0 {
		t.Fatal("ASTNodes")
	}
	if mustNum(t, o, "ASTDepth") <= 0 {
		t.Fatal("ASTDepth")
	}
	if mustNum(t, o, "NFAStates") <= 0 {
		t.Fatal("NFAStates")
	}
	if mustNum(t, o, "DFAStates") <= 0 {
		t.Fatal("DFAStates")
	}
	if !mustBool(t, o, "HasGroups") {
		t.Fatal("HasGroups")
	}
	if mustNum(t, o, "GroupCount") != 1 {
		t.Fatalf("GroupCount=%v", o["GroupCount"])
	}
}

func TestStatsNoGroups(t *testing.T) {
	r := mustOK(t, run(t, "stats", "a+b", "--json"))
	o := parseObj(t, r.stdout)
	if mustBool(t, o, "HasGroups") {
		t.Fatal("a+b should not have groups")
	}
	if mustNum(t, o, "GroupCount") != 0 {
		t.Fatalf("GroupCount=%v", o["GroupCount"])
	}
}

func TestStatsMultipleGroups(t *testing.T) {
	r := mustOK(t, run(t, "stats", `(\d+)-(\w+)`, "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "GroupCount") != 2 {
		t.Fatalf("GroupCount=%v", o["GroupCount"])
	}
	if !mustBool(t, o, "HasGroups") {
		t.Fatal("HasGroups")
	}
}

func TestStatsPlainOutput(t *testing.T) {
	r := mustOK(t, run(t, "stats", `(a|b)+\d{3}`))
	for _, k := range []string{"ast nodes:", "nfa states:", "dfa states:", "groups:"} {
		if !strings.Contains(r.stdout, k) {
			t.Fatalf("plain stats missing %q: %q", k, r.stdout)
		}
	}
}

func TestStatsInvalid(t *testing.T) {
	r := run(t, "stats", "(invalid")
	if r.code == 0 {
		t.Fatal("invalid should error")
	}
}

// explain extended

func TestExplainLiteralPrefix(t *testing.T) {
	r := mustOK(t, run(t, "explain", `foo\d+`, "--json"))
	o := parseObj(t, r.stdout)
	if mustStr(t, o, "literal_prefix") != "foo" {
		t.Fatalf("literal_prefix=%v", o["literal_prefix"])
	}

	r = mustOK(t, run(t, "explain", `\d+`, "--json"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "literal_prefix") != "" {
		t.Fatalf("literal_prefix=%v", o["literal_prefix"])
	}

	r = mustOK(t, run(t, "explain", "abc", "--json"))
	o = parseObj(t, r.stdout)
	if mustStr(t, o, "literal_prefix") != "abc" {
		t.Fatalf("literal_prefix=%v", o["literal_prefix"])
	}
}

func TestExplainPlainOutput(t *testing.T) {
	r := mustOK(t, run(t, "explain", `(\d{3})-(\d{4})`))
	if !strings.Contains(r.stdout, "[:digit:]") {
		t.Fatalf("expected [:digit:]: %q", r.stdout)
	}
	if !strings.Contains(r.stdout, "char class ranges:") {
		t.Fatalf("expected char class ranges: %q", r.stdout)
	}

	r = mustOK(t, run(t, "explain", `hello\d+`))
	if !strings.Contains(r.stdout, "literal prefix:") || !strings.Contains(r.stdout, "hello") {
		t.Fatalf("explain plain: %q", r.stdout)
	}
}

// find: stdin and edge cases

func TestFindStdinSingleLine(t *testing.T) {
	r := runWithStdin(t, "price: 42 dollars", "find", `\d+`)
	if !strings.Contains(r.stdout, "42") {
		t.Fatalf("stdin find: %q", r.stdout)
	}
}

func TestFindStdinMultiline(t *testing.T) {
	r := runWithStdin(t, "bar\nfoo\nbaz", "find", "foo")
	if !strings.Contains(r.stdout, "foo") {
		t.Fatalf("stdin multi-line find: %q", r.stdout)
	}
}

func TestFindAllOnSpaceSeparated(t *testing.T) {
	r := mustOK(t, run(t, "find", "--all", `\d+`, "1 2 3", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "count") != 3 {
		t.Fatalf("count=%v", o["count"])
	}
}

// validate extended

func TestValidateRepetitionAndCharClass(t *testing.T) {
	r := mustOK(t, run(t, "validate", `\d+\w*`, "--json"))
	o := parseObj(t, r.stdout)
	feat := o["features"].(map[string]any)

	if !feat["has_char_class"].(bool) {
		t.Fatal("has_char_class")
	}
	if !feat["has_repetition"].(bool) {
		t.Fatal("has_repetition")
	}
	if feat["has_groups"].(bool) {
		t.Fatal("has_groups should be false")
	}
}

func TestValidateAnchorsAndDot(t *testing.T) {
	r := mustOK(t, run(t, "validate", "^abc$", "--json"))
	o := parseObj(t, r.stdout)

	if !o["features"].(map[string]any)["has_anchors"].(bool) {
		t.Fatal("has_anchors")
	}

	r = mustOK(t, run(t, "validate", "a.b", "--json"))
	o = parseObj(t, r.stdout)

	if !o["features"].(map[string]any)["has_dot"].(bool) {
		t.Fatal("has_dot")
	}
}

func TestValidatePosixAndNamed(t *testing.T) {
	r := mustOK(t, run(t, "validate", "[[:alpha:]]+", "--json"))
	o := parseObj(t, r.stdout)
	if !mustBool(t, o, "valid") {
		t.Fatal("posix should be valid")
	}

	r = mustOK(t, run(t, "validate", `(?i)(?P<name>\w+)`, "--json"))
	o = parseObj(t, r.stdout)
	if !mustBool(t, o, "valid") {
		t.Fatal("inline flag + named group valid")
	}
	if mustNum(t, o, "groups") < 1 {
		t.Fatalf("groups=%v", o["groups"])
	}
}

// profile

func TestProfileMixed(t *testing.T) {
	r := mustOK(t, run(t, "profile", "a+b", "aaab", "b", "hello", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "count") != 3 {
		t.Fatalf("count=%v", o["count"])
	}
	if mustNum(t, o, "matched") != 1 {
		t.Fatalf("matched=%v", o["matched"])
	}
	if mustNum(t, o, "missed") != 2 {
		t.Fatalf("missed=%v", o["missed"])
	}
	if mustNum(t, o, "max_ns") < mustNum(t, o, "min_ns") {
		t.Fatal("max_ns < min_ns")
	}
	records := o["records"].([]any)
	if len(records) != 3 {
		t.Fatalf("records=%d", len(records))
	}
	first := records[0].(map[string]any)
	if !first["matched"].(bool) {
		t.Fatal("first matched")
	}
	if first["pattern"].(string) != "a+b" || first["input"].(string) != "aaab" {
		t.Fatalf("first record: %v", first)
	}
	if records[1].(map[string]any)["matched"].(bool) {
		t.Fatal("second matched should be false")
	}
}

func TestProfilePlainOutput(t *testing.T) {
	r := mustOK(t, run(t, "profile", "a+b", "aaab", "b"))
	for _, k := range []string{"profile summary", "records", "matched", "missed"} {
		if !strings.Contains(r.stdout, k) {
			t.Fatalf("plain profile missing %q: %q", k, r.stdout)
		}
	}
}

func TestProfileSingleMatch(t *testing.T) {
	r := mustOK(t, run(t, "profile", `\d+`, "123", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "count") != 1 || mustNum(t, o, "matched") != 1 || mustNum(t, o, "missed") != 0 {
		t.Fatalf("counts: %v", o)
	}
}

func TestProfileSingleMiss(t *testing.T) {
	r := mustOK(t, run(t, "profile", `\d+`, "abc", "--json"))
	o := parseObj(t, r.stdout)
	if mustNum(t, o, "matched") != 0 || mustNum(t, o, "missed") != 1 {
		t.Fatalf("counts: %v", o)
	}
}

func TestProfileMissingArgs(t *testing.T) {
	r := run(t, "profile")
	if r.code == 0 {
		t.Fatal("profile without args should error")
	}
}
