import { Graph } from '../src/graph';
import { networkStats, nodeRobustness, criticalNodes, smallWorldCoeff, algebraicConnectivity, networkEfficiency, vulnerabilityIndex, degreeAssortativity } from '../src/network';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c','d'].forEach(n=>{g.addNode(n); g.addEdge('hub',n,1);}); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); return g; }
function makeDisconnected(): Graph { const g = new Graph(); ['a','b','x','y'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('x','y'); return g; }

describe('networkStats', () => {
  it('nodeCount correct', () => { expect(networkStats(makeTriangle()).nodeCount).toBe(3); });
  it('edgeCount correct', () => { expect(networkStats(makeTriangle()).edgeCount).toBe(3); });
  it('density in [0,1]', () => { const d = networkStats(makeTriangle()).density; expect(d).toBeGreaterThanOrEqual(0); expect(d).toBeLessThanOrEqual(1); });
  it('connected graph isConnected true', () => { expect(networkStats(makeTriangle()).isConnected).toBe(true); });
  it('disconnected graph isConnected false', () => { expect(networkStats(makeDisconnected()).isConnected).toBe(false); });
  it('componentCount correct for disconnected', () => { expect(networkStats(makeDisconnected()).componentCount).toBe(2); });
  it('avgDegree is number', () => { expect(typeof networkStats(makeStar()).avgDegree).toBe('number'); });
  it('maxDegree is number', () => { expect(typeof networkStats(makeStar()).maxDegree).toBe('number'); });
  it('avgClusteringCoeff in [0,1]', () => { const c = networkStats(makeTriangle()).avgClusteringCoeff; expect(c).toBeGreaterThanOrEqual(0); expect(c).toBeLessThanOrEqual(1); });
});

describe('nodeRobustness', () => {
  it('removing hub from star increases components', () => { const r = nodeRobustness(makeStar(), 'hub'); expect(r.componentsAfter).toBeGreaterThan(r.componentsBefore); });
  it('connectivity changed when removing hub', () => { expect(nodeRobustness(makeStar(), 'hub').connectivityChanged).toBe(true); });
  it('removing leaf from star keeps connected', () => { expect(nodeRobustness(makeStar(), 'a').connectivityChanged).toBe(false); });
  it('returns RobustnessResult', () => { const r = nodeRobustness(makeTriangle(), 'a'); expect(r).toHaveProperty('removedNode'); expect(r).toHaveProperty('componentsBefore'); });
  it('removedNode is correct', () => { expect(nodeRobustness(makeStar(), 'hub').removedNode).toBe('hub'); });
});

describe('criticalNodes', () => {
  it('hub of star is critical', () => { expect(criticalNodes(makeStar())).toContain('hub'); });
  it('triangle has no critical nodes', () => { expect(criticalNodes(makeTriangle())).toHaveLength(0); });
  it('path interior nodes are critical', () => { const cn = criticalNodes(makePath()); expect(cn).toContain('b'); expect(cn).toContain('c'); });
  it('returns array', () => { expect(Array.isArray(criticalNodes(makeTriangle()))).toBe(true); });
});

describe('smallWorldCoeff', () => {
  it('returns sigma and omega', () => { const r = smallWorldCoeff(makeTriangle()); expect(r).toHaveProperty('sigma'); expect(r).toHaveProperty('omega'); });
  it('sigma is a number', () => { expect(typeof smallWorldCoeff(makeStar()).sigma).toBe('number'); });
  it('omega is a number', () => { expect(typeof smallWorldCoeff(makeStar()).omega).toBe('number'); });
  it('empty graph returns 0', () => { const r = smallWorldCoeff(new Graph()); expect(r.sigma).toBe(0); });
});

describe('algebraicConnectivity', () => {
  it('connected graph has positive connectivity', () => { expect(algebraicConnectivity(makeTriangle())).toBeGreaterThanOrEqual(0); });
  it('returns a number', () => { expect(typeof algebraicConnectivity(makePath())).toBe('number'); });
  it('single node is 0', () => { const g = new Graph(); g.addNode('x'); expect(algebraicConnectivity(g)).toBe(0); });
});

describe('networkEfficiency', () => {
  it('connected graph has positive efficiency', () => { expect(networkEfficiency(makeTriangle())).toBeGreaterThan(0); });
  it('in [0,1] for triangle', () => { const e = networkEfficiency(makeTriangle()); expect(e).toBeGreaterThanOrEqual(0); expect(e).toBeLessThanOrEqual(1); });
  it('returns number', () => { expect(typeof networkEfficiency(makePath())).toBe('number'); });
  it('empty graph is 0', () => { expect(networkEfficiency(new Graph())).toBe(0); });
  it('complete graph has higher efficiency than path', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); expect(networkEfficiency(g)).toBeGreaterThan(networkEfficiency(makePath())); });
});

describe('vulnerabilityIndex', () => {
  it('returns number in [0,1]', () => { const v = vulnerabilityIndex(makeTriangle()); expect(v).toBeGreaterThanOrEqual(0); expect(v).toBeLessThanOrEqual(1); });
  it('star has high vulnerability', () => { expect(vulnerabilityIndex(makeStar())).toBeGreaterThan(0); });
  it('returns number', () => { expect(typeof vulnerabilityIndex(makePath())).toBe('number'); });
});

describe('degreeAssortativity', () => {
  it('returns a number', () => { expect(typeof degreeAssortativity(makeTriangle())).toBe('number'); });
  it('in [-1,1]', () => { const a = degreeAssortativity(makeStar()); expect(a).toBeGreaterThanOrEqual(-1); expect(a).toBeLessThanOrEqual(1); });
  it('empty graph is 0', () => { expect(degreeAssortativity(new Graph())).toBe(0); });
  it('star has negative assortativity', () => { expect(degreeAssortativity(makeStar())).toBeLessThanOrEqual(0); });
});

describe('network advanced', () => {
  it('networkEfficiency of complete is 1', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); const e = networkEfficiency(g); expect(e).toBeCloseTo(1,1); });
  it('degreeAssortativity returns number', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); expect(typeof degreeAssortativity(g)).toBe('number'); });
  it('networkStats.density for K3 is 1', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(networkStats(g).density).toBeCloseTo(1,1); });
})


