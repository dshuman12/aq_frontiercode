import { Graph } from '../src/graph';
import { spanningTree, randomSpanningTree, countSpanningTrees, isSpanningTree, greedyTreeDecomp, treeWidth, pathWidth, isChordal, chordalCompletion } from '../src/topology';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); return g; }
function makeTree(): Graph { const g = new Graph(); ['r','a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('r','a',1); g.addEdge('r','b',1); g.addEdge('a','c',1); return g; }
function makeK4(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); return g; }

describe('spanningTree', () => {
  it('has n-1 edges', () => { expect(spanningTree(makeTriangle()).edgeCount).toBe(2); });
  it('is valid spanning tree', () => { const st = spanningTree(makeTriangle()); expect(isSpanningTree(makeTriangle(), st.tree)).toBe(true); });
  it('single node spanning tree', () => { const g = new Graph(); g.addNode('x'); expect(spanningTree(g).edgeCount).toBe(0); });
  it('weight is a number', () => { expect(typeof spanningTree(makeTriangle()).weight).toBe('number'); });
  it('path spanning tree equals path', () => { expect(spanningTree(makePath()).edgeCount).toBe(3); });
});

describe('randomSpanningTree', () => {
  it('has n-1 edges for connected', () => { expect(randomSpanningTree(makeTriangle()).edgeCount).toBe(2); });
  it('is valid spanning tree', () => { const st = randomSpanningTree(makeTriangle()); expect(isSpanningTree(makeTriangle(), st.tree)).toBe(true); });
  it('all nodes in tree', () => { const st = randomSpanningTree(makeTriangle()); expect(st.tree.nodeCount()).toBe(3); });
  it('different seeds may differ', () => {
    const s1 = randomSpanningTree(makeK4(), 1);
    const s2 = randomSpanningTree(makeK4(), 2);
    expect(s1.edgeCount).toBe(s2.edgeCount);
  });
});

describe('countSpanningTrees', () => {
  it('triangle has 3 spanning trees', () => { expect(countSpanningTrees(makeTriangle())).toBe(3); });
  it('path has 1 spanning tree', () => { expect(countSpanningTrees(makePath())).toBe(1); });
  it('tree has 1 spanning tree', () => { expect(countSpanningTrees(makeTree())).toBe(1); });
  it('empty graph returns 0', () => { expect(countSpanningTrees(new Graph())).toBe(0); });
  it('single node returns 1', () => { const g = new Graph(); g.addNode('x'); expect(countSpanningTrees(g)).toBe(1); });
});

describe('isSpanningTree', () => {
  it('MST of triangle is spanning tree', () => { const st = spanningTree(makeTriangle()); expect(isSpanningTree(makeTriangle(), st.tree)).toBe(true); });
  it('path is spanning tree of path', () => { expect(isSpanningTree(makePath(), makePath())).toBe(true); });
  it('wrong node count fails', () => { const t = new Graph(); t.addNode('a'); t.addNode('b'); t.addEdge('a','b'); expect(isSpanningTree(makeTriangle(), t)).toBe(false); });
  it('too many edges fails', () => { expect(isSpanningTree(makeTriangle(), makeTriangle())).toBe(false); });
});

describe('greedyTreeDecomp', () => {
  it('has bags for each node', () => { const d = greedyTreeDecomp(makePath()); expect(d.bags.size).toBeGreaterThan(0); });
  it('treeWidth is non-negative', () => { expect(greedyTreeDecomp(makePath()).treeWidth).toBeGreaterThanOrEqual(0); });
  it('returns decomposition object', () => { const d = greedyTreeDecomp(makeTriangle()); expect(d).toHaveProperty('bags'); expect(d).toHaveProperty('treeWidth'); });
});

describe('treeWidth', () => {
  it('path has treeWidth 1', () => { expect(treeWidth(makePath())).toBe(1); });
  it('single node has treeWidth 0', () => { const g = new Graph(); g.addNode('x'); expect(treeWidth(g)).toBe(0); });
  it('returns non-negative', () => { expect(treeWidth(makeTriangle())).toBeGreaterThanOrEqual(0); });
  it('K4 has treeWidth >= 3', () => { expect(treeWidth(makeK4())).toBeGreaterThanOrEqual(3); });
});

describe('isChordal', () => {
  it('tree is chordal', () => { expect(isChordal(makeTree())).toBe(true); });
  it('K4 is chordal', () => { expect(isChordal(makeK4())).toBe(true); });
  it('path is chordal', () => { expect(isChordal(makePath())).toBe(true); });
  it('triangle is chordal', () => { expect(isChordal(makeTriangle())).toBe(true); });
  it('C4 is not chordal', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','a'); expect(isChordal(g)).toBe(false); });
});

describe('chordalCompletion', () => {
  it('result is chordal', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','a'); expect(isChordal(chordalCompletion(g))).toBe(true); });
  it('preserves nodes', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','a'); expect(chordalCompletion(g).nodeCount()).toBe(4); });
  it('has at least as many edges', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','a'); expect(chordalCompletion(g).edgeCount()).toBeGreaterThanOrEqual(4); });
  it('chordal graph unchanged', () => { expect(chordalCompletion(makeTriangle()).edgeCount()).toBe(3); });
});

describe('topology extended', () => {
  it('countSpanningTrees K4 is 16', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); expect(countSpanningTrees(g)).toBe(16); });
  it('pathWidth of K4 is >= 3', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); expect(pathWidth(g)).toBeGreaterThanOrEqual(2); });
  it('chordalCompletion C5 makes it chordal', () => { const g = new Graph(); ['a','b','c','d','e'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','e'); g.addEdge('e','a'); expect(isChordal(chordalCompletion(g))).toBe(true); });
})


