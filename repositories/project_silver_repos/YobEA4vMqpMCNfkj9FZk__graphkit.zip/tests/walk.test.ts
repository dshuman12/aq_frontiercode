import { Graph } from '../src/graph';
import { randomWalk, stationaryDistribution, hitting_time, commute_time, coverTime } from '../src/walk';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n); g.addEdge('hub',n,1);}); return g; }

describe('randomWalk', () => {
  it('starts at specified node', () => { expect(randomWalk(makeTriangle(),'a',{maxSteps:10}).path[0]).toBe('a'); });
  it('path length is steps+1', () => { const r = randomWalk(makeTriangle(),'a',{maxSteps:10}); expect(r.path.length).toBe(r.steps+1); });
  it('stays within graph', () => { const nodes = makeTriangle().nodeIds(); for (const n of randomWalk(makeTriangle(),'a',{maxSteps:20}).path) expect(nodes).toContain(n); });
  it('consecutive nodes adjacent', () => { const walk = randomWalk(makeTriangle(),'a',{maxSteps:10}).path; for (let i=0;i<walk.length-1;i++) expect(makeTriangle().hasEdge(walk[i],walk[i+1])).toBe(true); });
  it('works on star', () => { const r = randomWalk(makeStar(),'hub',{maxSteps:5}); expect(r.path.length).toBeGreaterThan(0); });
  it('visited set not empty', () => { expect(randomWalk(makeTriangle(),'a',{maxSteps:10}).visited.size).toBeGreaterThan(0); });
  it('steps is a number', () => { expect(typeof randomWalk(makeTriangle(),'a',{maxSteps:5}).steps).toBe('number'); });
});

describe('stationaryDistribution', () => {
  it('sums to 1', () => { const sd = stationaryDistribution(makeTriangle()); const sum = [...sd.values()].reduce((s,v)=>s+v,0); expect(Math.abs(sum-1)).toBeLessThan(0.01); });
  it('all values positive', () => { for (const v of stationaryDistribution(makeTriangle()).values()) expect(v).toBeGreaterThan(0); });
  it('all nodes present', () => { const sd = stationaryDistribution(makeTriangle()); for (const n of makeTriangle().nodeIds()) expect(sd.has(n)).toBe(true); });
  it('hub has non-zero prob in star', () => { expect(stationaryDistribution(makeStar()).get('hub')).toBeGreaterThan(0); });
  it('triangle is uniform', () => { const sd = stationaryDistribution(makeTriangle()); const vals = [...sd.values()]; expect(Math.abs(vals[0]-vals[1])).toBeLessThan(0.01); });
  it('returns Map', () => { expect(stationaryDistribution(makeTriangle()) instanceof Map).toBe(true); });
});

describe('hitting_time', () => {
  it('self hitting time is 0', () => { expect(hitting_time(makeTriangle(),'a','a')).toBe(0); });
  it('positive between different nodes', () => { expect(hitting_time(makeTriangle(),'a','b')).toBeGreaterThan(0); });
  it('returns number', () => { expect(typeof hitting_time(makeStar(),'hub','a')).toBe('number'); });
  it('finite for connected', () => { expect(hitting_time(makeTriangle(),'a','c')).toBeLessThan(Infinity); });
});

describe('commute_time', () => {
  it('positive', () => { expect(commute_time(makeTriangle(),'a','b')).toBeGreaterThan(0); });
  it('positive', () => { expect(commute_time(makeStar(),'hub','a')).toBeGreaterThan(0); });
  it('returns number', () => { expect(typeof commute_time(makeTriangle(),'a','b')).toBe('number'); });
  it('>= hitting time', () => { expect(commute_time(makeTriangle(),'a','b')).toBeGreaterThanOrEqual(hitting_time(makeTriangle(),'a','b')); });
});

describe('coverTime', () => {
  it('positive', () => { expect(coverTime(makeTriangle(),'a')).toBeGreaterThan(0); });
  it('returns number', () => { expect(typeof coverTime(makeStar(),'hub')).toBe('number'); });
  it('finite', () => { expect(coverTime(makeTriangle(),'a')).toBeLessThan(Infinity); });
  it('single node is 0', () => { const g = new Graph(); g.addNode('x'); expect(coverTime(g,'x')).toBe(0); });
});

describe('walk advanced', () => {
  it('randomWalk returns WalkResult object', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); const r = randomWalk(g,'a',{maxSteps:5}); expect(r).toHaveProperty('path'); expect(r).toHaveProperty('steps'); expect(r).toHaveProperty('visited'); });
  it('stationaryDistribution triangle all equal', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); const sd = stationaryDistribution(g); const vals = [...sd.values()]; expect(Math.abs(vals[0]-vals[1])).toBeLessThan(0.05); });
  it('hitting_time non-negative for connected', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); expect(hitting_time(g,'a','b')).toBeGreaterThanOrEqual(0); });
  it('commute_time >= hitting_time', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); const h = hitting_time(g,'a','b'); const c2 = commute_time(g,'a','b'); expect(c2).toBeGreaterThanOrEqual(h); });
  it('coverTime of single-edge is small', () => { const g = new Graph(); g.addNode('a'); g.addNode('b'); g.addEdge('a','b',1); expect(coverTime(g,'a')).toBeGreaterThanOrEqual(0); });
})


