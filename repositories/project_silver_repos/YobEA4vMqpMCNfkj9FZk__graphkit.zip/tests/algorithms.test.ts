import { Graph } from '../src/graph';
import { DiGraph } from '../src/digraph';
import { dfsTree, bfsTree, iterativeDFS, iddfs, greedyBestFirst, topologicalLevels, longestPath, criticalPath, hasCycle, countPaths, graphCenter, periphery, kCoreDecomposition, kCore } from '../src/algorithms';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n);g.addEdge('hub',n,1);}); return g; }
function makeDAG(): DiGraph { const g = new DiGraph(); ['a','b','c','d','e'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('b','d'); g.addEdge('c','d'); g.addEdge('d','e'); return g; }
function makeK4(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); return g; }

describe('dfsTree', () => {
  it('preorder starts at start node', () => { expect(dfsTree(makePath(), 'a').preorder[0]).toBe('a'); });
  it('all nodes visited', () => { expect(dfsTree(makePath(), 'a').preorder).toHaveLength(4); });
  it('postorder has all nodes', () => { expect(dfsTree(makePath(), 'a').postorder).toHaveLength(4); });
  it('start has null parent', () => { expect(dfsTree(makePath(), 'a').parent.get('a')).toBeNull(); });
  it('start has depth 0', () => { expect(dfsTree(makePath(), 'a').depth.get('a')).toBe(0); });
  it('triangle has back edges', () => { expect(dfsTree(makeTriangle(), 'a').backEdges.length).toBeGreaterThan(0); });
  it('path has tree edges only', () => { expect(dfsTree(makePath(), 'a').treeEdges).toHaveLength(3); });
  it('treeEdges is array of tuples', () => { for (const e of dfsTree(makePath(),'a').treeEdges) expect(e).toHaveLength(2); });
});

describe('bfsTree', () => {
  it('order starts at start node', () => { expect(bfsTree(makePath(), 'a').order[0]).toBe('a'); });
  it('all nodes in order', () => { expect(bfsTree(makePath(), 'a').order).toHaveLength(4); });
  it('start has null parent', () => { expect(bfsTree(makePath(), 'a').parent.get('a')).toBeNull(); });
  it('start has depth 0', () => { expect(bfsTree(makePath(), 'a').depth.get('a')).toBe(0); });
  it('b has depth 1', () => { expect(bfsTree(makePath(), 'a').depth.get('b')).toBe(1); });
  it('treeEdges has n-1 entries', () => { expect(bfsTree(makePath(), 'a').treeEdges).toHaveLength(3); });
  it('returns BFSTree', () => { const t = bfsTree(makePath(),'a'); expect(t).toHaveProperty('order'); expect(t).toHaveProperty('treeEdges'); });
});

describe('iterativeDFS', () => {
  it('starts at start node', () => { expect(iterativeDFS(makePath(), 'a')[0]).toBe('a'); });
  it('visits all nodes', () => { expect(iterativeDFS(makePath(), 'a')).toHaveLength(4); });
  it('no duplicates', () => { const r = iterativeDFS(makeTriangle(), 'a'); expect(new Set(r).size).toBe(r.length); });
  it('returns array', () => { expect(Array.isArray(iterativeDFS(makePath(), 'a'))).toBe(true); });
  it('single node', () => { const g = new Graph(); g.addNode('x'); expect(iterativeDFS(g, 'x')).toEqual(['x']); });
});

describe('iddfs', () => {
  it('finds path in path graph', () => { expect(iddfs(makePath(), 'a', 'd')).not.toBeNull(); });
  it('path ends at goal', () => { const r = iddfs(makePath(), 'a', 'd')!; expect(r[r.length-1]).toBe('d'); });
  it('path starts at start', () => { const r = iddfs(makePath(), 'a', 'd')!; expect(r[0]).toBe('a'); });
  it('disconnected returns null', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(iddfs(g, 'x', 'y')).toBeNull(); });
  it('self search returns single node', () => { const r = iddfs(makePath(), 'a', 'a')!; expect(r[0]).toBe('a'); });
});

describe('greedyBestFirst', () => {
  it('finds path when h=0', () => { const r = greedyBestFirst(makePath(), 'a', 'd', () => 0); expect(r[r.length-1]).toBe('d'); });
  it('starts at source', () => { expect(greedyBestFirst(makePath(), 'a', 'd', () => 0)[0]).toBe('a'); });
  it('returns empty for disconnected', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(greedyBestFirst(g, 'x', 'y', () => 0)).toHaveLength(0); });
  it('returns array', () => { expect(Array.isArray(greedyBestFirst(makePath(), 'a', 'b', () => 0))).toBe(true); });
});

describe('topologicalLevels', () => {
  it('first level contains source nodes', () => { const levels = topologicalLevels(makeDAG()); expect(levels[0]).toContain('a'); });
  it('all nodes covered', () => { const levels = topologicalLevels(makeDAG()); const total = levels.reduce((s,l)=>s+l.length,0); expect(total).toBe(5); });
  it('returns array of arrays', () => { for (const l of topologicalLevels(makeDAG())) expect(Array.isArray(l)).toBe(true); });
  it('multiple levels for chained DAG', () => { expect(topologicalLevels(makeDAG()).length).toBeGreaterThan(1); });
  it('last level has sink', () => { const levels = topologicalLevels(makeDAG()); expect(levels[levels.length-1]).toContain('e'); });
});

describe('longestPath', () => {
  it('starts at valid node', () => { const p = longestPath(makeDAG()); expect(makeDAG().hasNode(p[0])).toBe(true); });
  it('returns array', () => { expect(Array.isArray(longestPath(makeDAG()))).toBe(true); });
  it('cyclic graph returns empty', () => { const g = new DiGraph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(longestPath(g)).toHaveLength(0); });
  it('path length > 1 for non-trivial DAG', () => { expect(longestPath(makeDAG()).length).toBeGreaterThan(1); });
});

describe('criticalPath', () => {
  it('length is non-negative', () => { expect(criticalPath(makeDAG()).length).toBeGreaterThanOrEqual(0); });
  it('path is array', () => { expect(Array.isArray(criticalPath(makeDAG()).path)).toBe(true); });
  it('returns object with path and length', () => { const r = criticalPath(makeDAG()); expect(r).toHaveProperty('path'); expect(r).toHaveProperty('length'); });
});

describe('hasCycle', () => {
  it('triangle has cycle', () => { expect(hasCycle(makeTriangle())).toBe(true); });
  it('disconnected graph has no cycle', () => { const g = new Graph(); ['a','b'].forEach(n=>g.addNode(n)); expect(hasCycle(g)).toBe(false); });
  it('single node has no cycle', () => { const g = new Graph(); g.addNode('x'); expect(hasCycle(g)).toBe(false); });
  it('empty graph has no cycle', () => { expect(hasCycle(new Graph())).toBe(false); });
  it('K4 has cycle', () => { expect(hasCycle(makeK4())).toBe(true); });
});

describe('countPaths', () => {
  it('counts paths between nodes', () => { expect(countPaths(makePath(), 'a', 'd')).toBeGreaterThan(0); });
  it('disconnected has 0 paths', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(countPaths(g, 'x', 'y')).toBe(0); });
  it('triangle a to c has multiple paths', () => { expect(countPaths(makeTriangle(), 'a', 'c')).toBeGreaterThanOrEqual(1); });
  it('returns non-negative', () => { expect(countPaths(makePath(), 'a', 'b')).toBeGreaterThanOrEqual(0); });
});

describe('graphCenter', () => {
  it('star center is hub', () => { expect(graphCenter(makeStar())).toContain('hub'); });
  it('returns array', () => { expect(Array.isArray(graphCenter(makePath()))).toBe(true); });
  it('empty graph returns empty', () => { expect(graphCenter(new Graph())).toHaveLength(0); });
  it('non-empty for connected', () => { expect(graphCenter(makePath()).length).toBeGreaterThan(0); });
});

describe('kCoreDecomposition', () => {
  it('all nodes have core number', () => { const c = kCoreDecomposition(makeK4()); for (const n of makeK4().nodeIds()) expect(c.has(n)).toBe(true); });
  it('K4 core number is 3', () => { const c = kCoreDecomposition(makeK4()); for (const v of c.values()) expect(v).toBeGreaterThanOrEqual(3); });
  it('returns Map', () => { expect(kCoreDecomposition(makePath()) instanceof Map).toBe(true); });
  it('path has core number >= 0', () => { for (const v of kCoreDecomposition(makePath()).values()) expect(v).toBeGreaterThanOrEqual(0); });
});

describe('kCore', () => {
  it('k=1 keeps connected nodes', () => { expect(kCore(makeK4(), 1).nodeCount()).toBeGreaterThan(0); });
  it('k=4 of K4 has all nodes', () => { expect(kCore(makeK4(), 4).nodeCount()).toBe(0); });
  it('k=3 of K4 has all nodes', () => { expect(kCore(makeK4(), 3).nodeCount()).toBe(4); });
  it('returns Graph', () => { expect(kCore(makePath(), 1).nodeCount()).toBeGreaterThanOrEqual(0); });
  it('k=0 returns all nodes', () => { expect(kCore(makeTriangle(), 0).nodeCount()).toBe(3); });
  it('kCore k=2 triangle has 3 nodes', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(kCore(g,2).nodeCount()).toBe(3); });
  it('kCore k=3 triangle has 0 nodes', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(kCore(g,3).nodeCount()).toBe(0); });
});



