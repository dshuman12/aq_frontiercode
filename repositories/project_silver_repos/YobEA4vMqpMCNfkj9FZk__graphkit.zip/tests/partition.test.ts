import { Graph } from '../src/graph';
import { kernighanLin, computeModularity, labelPropagation } from '../src/partition';

function makeClusters(): Graph {
  const g = new Graph();
  ['a','b','c','d','e','f'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('a','c',1);
  g.addEdge('d','e',1); g.addEdge('e','f',1); g.addEdge('d','f',1);
  g.addEdge('c','d',0.1);
  return g;
}
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); return g; }

describe('kernighanLin', () => {
  it('has two parts', () => { expect(kernighanLin(makeClusters()).parts).toHaveLength(2); });
  it('all nodes covered', () => { const r = kernighanLin(makeClusters()); const total = r.parts[0].length + r.parts[1].length; expect(total).toBe(6); });
  it('parts are non-empty', () => { const r = kernighanLin(makeClusters()); expect(r.parts[0].length).toBeGreaterThan(0); expect(r.parts[1].length).toBeGreaterThan(0); });
  it('no node in both parts', () => { const r = kernighanLin(makeClusters()); const s0 = new Set(r.parts[0]); for (const n of r.parts[1]) expect(s0.has(n)).toBe(false); });
  it('nodeToPartition map has all nodes', () => { expect(kernighanLin(makeClusters()).nodeToPartition.size).toBe(6); });
  it('cutEdges is a number', () => { expect(typeof kernighanLin(makeClusters()).cutEdges).toBe('number'); });
  it('works on path', () => { const r = kernighanLin(makePath()); expect(r.parts[0].length + r.parts[1].length).toBe(4); });
});

describe('computeModularity', () => {
  it('in [-1,1]', () => { const m = computeModularity(makeClusters(),[['a','b','c'],['d','e','f']]); expect(m).toBeGreaterThanOrEqual(-1); expect(m).toBeLessThanOrEqual(1); });
  it('good partition is positive', () => { expect(computeModularity(makeClusters(),[['a','b','c'],['d','e','f']])).toBeGreaterThan(0); });
  it('all in one <= good partition', () => { const allOne = computeModularity(makeClusters(),[['a','b','c','d','e','f']]); const good = computeModularity(makeClusters(),[['a','b','c'],['d','e','f']]); expect(good).toBeGreaterThanOrEqual(allOne); });
  it('returns number', () => { expect(typeof computeModularity(makePath(),[['a','b'],['c','d']])).toBe('number'); });
});

describe('labelPropagation', () => {
  it('covers all nodes', () => { const c = labelPropagation(makeClusters()); const total = c.reduce((s,com)=>s+com.length,0); expect(total).toBe(6); });
  it('returns >= 1 community', () => { expect(labelPropagation(makeClusters()).length).toBeGreaterThanOrEqual(1); });
  it('no node twice', () => { const all = labelPropagation(makeClusters()).flat(); expect(new Set(all).size).toBe(all.length); });
  it('single node is 1 community', () => { const g = new Graph(); g.addNode('x'); expect(labelPropagation(g)).toHaveLength(1); });
  it('returns array of arrays', () => { for (const c of labelPropagation(makeClusters())) expect(Array.isArray(c)).toBe(true); });
});

describe('partition advanced', () => {
  it('kernighanLin with 2 nodes', () => { const g = new Graph(); g.addNode('a'); g.addNode('b'); g.addEdge('a','b',1); const r = kernighanLin(g); expect(r.parts[0].length + r.parts[1].length).toBe(2); });
  it('computeModularity single community is 0', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); const m = computeModularity(g,[['a','b','c']]); expect(typeof m).toBe('number'); });
  it('labelPropagation triangle is 1 community', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); const c = labelPropagation(g); expect(c.length).toBeGreaterThanOrEqual(1); });
  it('kernighanLin isolates two components', () => { const g = new Graph(); ['a','b','x','y'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('x','y'); g.addEdge('b','x',0.01); const r = kernighanLin(g); expect(r.parts).toHaveLength(2); });
})


