import {
  createTemporalGraph, addTemporalEdge, snapshotAt, snapshotBetween,
  temporalMetrics, temporalDegree, temporalNeighbors, temporalReachability,
  temporalShortestPath, temporalCentrality, activeNodes,
  temporalDensityOverTime, aggregateGraph, temporalComponents,
  interEventTimes, filterByTimeWindow, temporalEdgeCount
} from '../src/temporal';

function makeTG() {
  const tg = createTemporalGraph();
  addTemporalEdge(tg, { source: 'a', target: 'b', weight: 1, timestamp: 1, duration: 2 });
  addTemporalEdge(tg, { source: 'b', target: 'c', weight: 1, timestamp: 2, duration: 1 });
  addTemporalEdge(tg, { source: 'a', target: 'c', weight: 1, timestamp: 4, duration: 1 });
  return tg;
}

describe('createTemporalGraph', () => {
  it('starts with no edges', () => {
    expect(createTemporalGraph().edges.length).toBe(0);
  });
  it('starts with no nodes', () => {
    expect(createTemporalGraph().nodes.size).toBe(0);
  });
  it('directed flag defaults to false', () => {
    expect(createTemporalGraph().directed).toBe(false);
  });
  it('directed flag can be set to true', () => {
    expect(createTemporalGraph(true).directed).toBe(true);
  });
});

describe('addTemporalEdge', () => {
  it('adds edge to temporal graph', () => {
    const tg = createTemporalGraph();
    addTemporalEdge(tg, { source: 'a', target: 'b', weight: 1, timestamp: 1 });
    expect(tg.edges.length).toBe(1);
  });
  it('adds nodes implicitly', () => {
    const tg = createTemporalGraph();
    addTemporalEdge(tg, { source: 'x', target: 'y', weight: 1, timestamp: 0 });
    expect(tg.nodes.has('x')).toBe(true);
    expect(tg.nodes.has('y')).toBe(true);
  });
  it('allows duplicate timestamps', () => {
    const tg = createTemporalGraph();
    addTemporalEdge(tg, { source: 'a', target: 'b', weight: 1, timestamp: 1 });
    addTemporalEdge(tg, { source: 'c', target: 'd', weight: 1, timestamp: 1 });
    expect(tg.edges.length).toBe(2);
  });
});

describe('snapshotAt', () => {
  it('returns graph active at t=1', () => {
    const g = snapshotAt(makeTG(), 1);
    expect(g.nodeCount()).toBe(3);
  });
  it('snapshot at t=0 has no edges', () => {
    const g = snapshotAt(makeTG(), 0);
    expect(g.edgeCount()).toBe(0);
  });
  it('snapshot includes active edge', () => {
    const g = snapshotAt(makeTG(), 1);
    expect(g.hasEdge('a','b') || g.hasEdge('b','a')).toBe(true);
  });
  it('snapshot at t=4 includes a-c edge', () => {
    const g = snapshotAt(makeTG(), 4);
    expect(g.hasEdge('a','c') || g.hasEdge('c','a')).toBe(true);
  });
});

describe('snapshotBetween', () => {
  it('includes edges in time window', () => {
    const g = snapshotBetween(makeTG(), 1, 2);
    expect(g.edgeCount()).toBeGreaterThan(0);
  });
  it('empty window returns no edges', () => {
    const g = snapshotBetween(makeTG(), 10, 20);
    expect(g.edgeCount()).toBe(0);
  });
  it('full window includes all edges', () => {
    const g = snapshotBetween(makeTG(), 0, 100);
    expect(g.edgeCount()).toBe(3);
  });
});

describe('temporalMetrics', () => {
  it('nodeCount is correct', () => {
    expect(temporalMetrics(makeTG()).nodeCount).toBe(3);
  });
  it('edgeCount is correct', () => {
    expect(temporalMetrics(makeTG()).edgeCount).toBe(3);
  });
  it('uniqueTimestamps has correct length', () => {
    expect(temporalMetrics(makeTG()).uniqueTimestamps.length).toBe(3);
  });
  it('density is non-negative', () => {
    expect(temporalMetrics(makeTG()).density).toBeGreaterThanOrEqual(0);
  });
  it('empty graph returns zero metrics', () => {
    const m = temporalMetrics(createTemporalGraph());
    expect(m.nodeCount).toBe(0);
    expect(m.edgeCount).toBe(0);
  });
});

describe('temporalDegree', () => {
  it('node a appears in 2 edges', () => {
    expect(temporalDegree(makeTG(), 'a')).toBe(2);
  });
  it('nonexistent node has degree 0', () => {
    expect(temporalDegree(makeTG(), 'z')).toBe(0);
  });
});

describe('temporalNeighbors', () => {
  it('at t=1 node a has neighbor b', () => {
    const nbrs = temporalNeighbors(makeTG(), 'a', 1);
    expect(nbrs.includes('b')).toBe(true);
  });
  it('at t=0 no neighbors', () => {
    expect(temporalNeighbors(makeTG(), 'a', 0).length).toBe(0);
  });
});

describe('temporalReachability', () => {
  it('source can reach itself', () => {
    const reach = temporalReachability(makeTG(), 'a');
    expect(reach.has('a')).toBe(true);
  });
  it('a can reach c via temporal path', () => {
    const reach = temporalReachability(makeTG(), 'a');
    expect(reach.has('c')).toBe(true);
  });
  it('reachability map is not empty', () => {
    expect(temporalReachability(makeTG(), 'a').size).toBeGreaterThan(0);
  });
});

describe('temporalShortestPath', () => {
  it('returns path from a to c', () => {
    const path = temporalShortestPath(makeTG(), 'a', 'c');
    expect(path).not.toBeNull();
    expect(path!.nodes[0]).toBe('a');
    expect(path!.nodes[path!.nodes.length - 1]).toBe('c');
  });
  it('no path from c to a in empty graph', () => {
    expect(temporalShortestPath(createTemporalGraph(), 'a', 'b')).toBeNull();
  });
  it('duration is non-negative', () => {
    const path = temporalShortestPath(makeTG(), 'a', 'c');
    if (path) expect(path.duration).toBeGreaterThanOrEqual(0);
  });
});

describe('temporalCentrality', () => {
  it('returns centrality for all nodes', () => {
    const c = temporalCentrality(makeTG());
    expect(c.length).toBe(3);
  });
  it('sorted descending by score', () => {
    const c = temporalCentrality(makeTG());
    for (let i = 1; i < c.length; i++)
      expect(c[i-1].score).toBeGreaterThanOrEqual(c[i].score);
  });
});

describe('activeNodes', () => {
  it('at t=1 nodes a and b are active', () => {
    const active = activeNodes(makeTG(), 1);
    expect(active.includes('a')).toBe(true);
    expect(active.includes('b')).toBe(true);
  });
  it('at t=0 no active nodes', () => {
    expect(activeNodes(makeTG(), 0).length).toBe(0);
  });
});

describe('aggregateGraph', () => {
  it('aggregate has all nodes', () => {
    const g = aggregateGraph(makeTG());
    expect(g.nodeCount()).toBe(3);
  });
  it('aggregate has all unique edges', () => {
    const g = aggregateGraph(makeTG());
    expect(g.edgeCount()).toBe(3);
  });
});

describe('interEventTimes', () => {
  it('node a has 1 inter-event time', () => {
    expect(interEventTimes(makeTG(), 'a').length).toBe(1);
  });
  it('inter-event times are non-negative', () => {
    for (const t of interEventTimes(makeTG(), 'a'))
      expect(t).toBeGreaterThanOrEqual(0);
  });
});

describe('filterByTimeWindow', () => {
  it('returns only edges in window', () => {
    const filtered = filterByTimeWindow(makeTG(), 1, 2);
    expect(filtered.edges.every(e => e.timestamp >= 1 && e.timestamp <= 2)).toBe(true);
  });
  it('empty window returns no edges', () => {
    expect(filterByTimeWindow(makeTG(), 10, 20).edges.length).toBe(0);
  });
});

describe('temporalEdgeCount', () => {
  it('counts edges in window', () => {
    expect(temporalEdgeCount(makeTG(), 1, 3)).toBe(2);
  });
  it('full range counts all edges', () => {
    expect(temporalEdgeCount(makeTG(), 0, 100)).toBe(3);
  });
  it('empty range counts 0', () => {
    expect(temporalEdgeCount(makeTG(), 10, 20)).toBe(0);
  });
});

