import {
  buildGeometricGraph, buildKNNGraph, convexHull, buildGabrielGraph,
  buildRelativeNeighborhoodGraph, spectralEmbedding, forceDirectedPositions,
  closestPair, minimumSpanningEuclidean, pointsInRadius,
  graphDiameter2D, averageEdgeLength, clusteringByProximity
} from '../src/geometric';
import type { Point2D } from '../src/geometric';

const square: Point2D[] = [
  { id: 'a', x: 0, y: 0 }, { id: 'b', x: 1, y: 0 },
  { id: 'c', x: 1, y: 1 }, { id: 'd', x: 0, y: 1 }
];
const collinear: Point2D[] = [
  { id: 'p1', x: 0, y: 0 }, { id: 'p2', x: 1, y: 0 }, { id: 'p3', x: 2, y: 0 }
];

describe('buildGeometricGraph', () => {
  it('builds graph with correct node count', () => {
    const { graph } = buildGeometricGraph(square, 2);
    expect(graph.nodeCount()).toBe(4);
  });
  it('large radius connects all nodes', () => {
    const { graph } = buildGeometricGraph(square, 10);
    expect(graph.edgeCount()).toBeGreaterThan(0);
  });
  it('radius 0 produces no edges', () => {
    const { graph } = buildGeometricGraph(square, 0);
    expect(graph.edgeCount()).toBe(0);
  });
  it('returns positions map', () => {
    const { positions } = buildGeometricGraph(square, 2);
    expect(positions.size).toBe(4);
  });
  it('empty points returns empty graph', () => {
    const { graph } = buildGeometricGraph([], 1);
    expect(graph.nodeCount()).toBe(0);
  });
});

describe('buildKNNGraph', () => {
  it('builds graph with correct node count', () => {
    const { graph } = buildKNNGraph(square, 2);
    expect(graph.nodeCount()).toBe(4);
  });
  it('k=1 each node has at least 1 neighbour', () => {
    const { graph } = buildKNNGraph(square, 1);
    for (const n of graph.nodeIds()) expect(graph.degree(n)).toBeGreaterThanOrEqual(1);
  });
  it('k >= n-1 produces more edges than k=1', () => {
    const g1 = buildKNNGraph(square, 1).graph;
    const g3 = buildKNNGraph(square, 3).graph;
    expect(g3.edgeCount()).toBeGreaterThanOrEqual(g1.edgeCount());
  });
  it('returns positions map with all nodes', () => {
    const { positions } = buildKNNGraph(square, 2);
    expect(positions.size).toBe(4);
  });
});

describe('convexHull', () => {
  it('square hull has 4 points', () => {
    const result = convexHull(square);
    expect(result.hull.length).toBe(4);
  });
  it('collinear points hull is non-empty', () => {
    const result = convexHull(collinear);
    expect(result.hull.length).toBeGreaterThanOrEqual(2);
  });
  it('area is non-negative', () => {
    expect(convexHull(square).area).toBeGreaterThanOrEqual(0);
  });
  it('square area is approximately 1', () => {
    expect(convexHull(square).area).toBeCloseTo(1, 5);
  });
  it('empty returns empty hull', () => {
    expect(convexHull([]).hull).toHaveLength(0);
  });
  it('interior contains points inside hull', () => {
    const pts: Point2D[] = [...square, { id: 'm', x: 0.5, y: 0.5 }];
    const result = convexHull(pts);
    expect(result.interior.length).toBeGreaterThanOrEqual(0);
  });
});

describe('buildGabrielGraph', () => {
  it('builds graph with correct node count', () => {
    const { graph } = buildGabrielGraph(square);
    expect(graph.nodeCount()).toBe(4);
  });
  it('produces non-negative edge count', () => {
    expect(buildGabrielGraph(square).graph.edgeCount()).toBeGreaterThanOrEqual(0);
  });
  it('returns positions for all nodes', () => {
    expect(buildGabrielGraph(square).positions.size).toBe(4);
  });
});

describe('buildRelativeNeighborhoodGraph', () => {
  it('builds graph with correct node count', () => {
    const { graph } = buildRelativeNeighborhoodGraph(square);
    expect(graph.nodeCount()).toBe(4);
  });
  it('produces non-negative edge count', () => {
    expect(buildRelativeNeighborhoodGraph(square).graph.edgeCount()).toBeGreaterThanOrEqual(0);
  });
});

describe('closestPair', () => {
  it('returns tuple of two points and distance', () => {
    const result = closestPair(square);
    expect(result.length).toBe(3);
  });
  it('two distinct points returned', () => {
    const [p1, p2] = closestPair(square);
    expect(p1.id).not.toBe(p2.id);
  });
  it('distance is approximately 1 for unit square', () => {
    const [, , d] = closestPair(square);
    expect(d).toBeCloseTo(1, 5);
  });
  it('distance is non-negative', () => {
    const [, , d] = closestPair(square);
    expect(d).toBeGreaterThanOrEqual(0);
  });
});

describe('minimumSpanningEuclidean', () => {
  it('MST graph has n nodes', () => {
    const { graph } = minimumSpanningEuclidean(square);
    expect(graph.nodeCount()).toBe(4);
  });
  it('MST graph has n-1 edges', () => {
    const { graph } = minimumSpanningEuclidean(square);
    expect(graph.edgeCount()).toBe(3);
  });
  it('MST positions map has all nodes', () => {
    const { positions } = minimumSpanningEuclidean(square);
    expect(positions.size).toBe(4);
  });
  it('empty points returns empty graph', () => {
    const { graph } = minimumSpanningEuclidean([]);
    expect(graph.nodeCount()).toBe(0);
  });
});

describe('pointsInRadius', () => {
  it('large radius returns all other points', () => {
    const center: Point2D = { id: 'q', x: 0.5, y: 0.5 };
    expect(pointsInRadius(center, square, 10).length).toBe(4);
  });
  it('radius 0 returns no points', () => {
    const center: Point2D = { id: 'q', x: 5, y: 5 };
    expect(pointsInRadius(center, square, 0).length).toBe(0);
  });
  it('excludes center itself', () => {
    const res = pointsInRadius(square[0], square, 10);
    expect(res.every(p => p.id !== square[0].id)).toBe(true);
  });
});

describe('spectralEmbedding', () => {
  it('returns positions for all nodes', () => {
    const { graph } = buildGeometricGraph(square, 2);
    const result = spectralEmbedding(graph, 2);
    expect(result.positions.size).toBe(4);
  });
  it('returns stress value', () => {
    const { graph } = buildGeometricGraph(square, 2);
    expect(spectralEmbedding(graph, 2).stress).toBeGreaterThanOrEqual(0);
  });
});

describe('forceDirectedPositions', () => {
  it('returns positions for all nodes', () => {
    const { graph } = buildGeometricGraph(square, 2);
    const positions = forceDirectedPositions(graph, 50);
    expect(positions.size).toBe(4);
  });
  it('positions are finite numbers', () => {
    const { graph } = buildGeometricGraph(square, 2);
    const positions = forceDirectedPositions(graph, 10);
    for (const [, pos] of positions) {
      expect(isFinite(pos.x)).toBe(true);
      expect(isFinite(pos.y)).toBe(true);
    }
  });
});

describe('graphDiameter2D', () => {
  it('diameter of square is sqrt(2)', () => {
    const gg = buildGeometricGraph(square, 10);
    expect(graphDiameter2D(gg)).toBeCloseTo(Math.SQRT2, 5);
  });
  it('single-node graph has diameter 0', () => {
    const gg = buildGeometricGraph([{ id: 'x', x: 0, y: 0 }], 1);
    expect(graphDiameter2D(gg)).toBe(0);
  });
});

describe('averageEdgeLength', () => {
  it('is positive for a connected graph', () => {
    const gg = buildKNNGraph(square, 2);
    expect(averageEdgeLength(gg)).toBeGreaterThan(0);
  });
  it('no-edge graph returns 0', () => {
    const gg = buildGeometricGraph(square, 0);
    expect(averageEdgeLength(gg)).toBe(0);
  });
});

describe('clusteringByProximity', () => {
  it('returns a Map of node to cluster label', () => {
    const labels = clusteringByProximity(square, 0.5);
    expect(labels instanceof Map).toBe(true);
    expect(labels.size).toBe(4);
  });
  it('large radius puts all nodes in same cluster', () => {
    const labels = clusteringByProximity(square, 10);
    const clusters = new Set(labels.values());
    expect(clusters.size).toBe(1);
  });
  it('zero radius puts each node in its own cluster', () => {
    const labels = clusteringByProximity(square, 0);
    const clusters = new Set(labels.values());
    expect(clusters.size).toBe(4);
  });
});

