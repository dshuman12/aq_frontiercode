import { Graph } from '../src/graph';
import { maxClique, allMaximalCliques, maximumIndependentSet, vertexCover, cliqueNumber, isClique, independenceNumber } from '../src/clique';

function makeK4(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); return g; }
function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); return g; }

describe('maxClique', () => {
  it('K4 max clique is 4', () => { expect(maxClique(makeK4())).toHaveLength(4); });
  it('triangle max clique is 3', () => { expect(maxClique(makeTriangle())).toHaveLength(3); });
  it('path max clique is 2', () => { expect(maxClique(makePath())).toHaveLength(2); });
  it('single node is 1', () => { const g = new Graph(); g.addNode('a'); expect(maxClique(g)).toHaveLength(1); });
  it('clique nodes all connected', () => { const c = maxClique(makeK4()); for (let i=0;i<c.length;i++) for (let j=i+1;j<c.length;j++) expect(makeK4().hasEdge(c[i],c[j])).toBe(true); });
  it('returns array', () => { expect(Array.isArray(maxClique(makeTriangle()))).toBe(true); });
});

describe('allMaximalCliques', () => {
  it('K4 has cliques', () => { expect(allMaximalCliques(makeK4()).length).toBeGreaterThan(0); });
  it('all returned are valid cliques', () => { for (const c of allMaximalCliques(makeTriangle())) expect(isClique(makeTriangle(), c)).toBe(true); });
  it('returns array of arrays', () => { for (const c of allMaximalCliques(makeTriangle())) expect(Array.isArray(c)).toBe(true); });
  it('K4 max clique found', () => { const maxLen = Math.max(...allMaximalCliques(makeK4()).map(c=>c.length)); expect(maxLen).toBe(4); });
});

describe('cliqueNumber', () => {
  it('K4 is 4', () => { expect(cliqueNumber(makeK4())).toBe(4); });
  it('triangle is 3', () => { expect(cliqueNumber(makeTriangle())).toBe(3); });
  it('path is 2', () => { expect(cliqueNumber(makePath())).toBe(2); });
  it('single node is 1', () => { const g = new Graph(); g.addNode('x'); expect(cliqueNumber(g)).toBe(1); });
  it('returns number', () => { expect(typeof cliqueNumber(makeTriangle())).toBe('number'); });
});

describe('maximumIndependentSet', () => {
  it('K4 IS size 1', () => { expect(maximumIndependentSet(makeK4())).toHaveLength(1); });
  it('path IS >= 2', () => { expect(maximumIndependentSet(makePath()).length).toBeGreaterThanOrEqual(2); });
  it('no two adjacent', () => { const is = maximumIndependentSet(makePath()); for (let i=0;i<is.length;i++) for (let j=i+1;j<is.length;j++) expect(makePath().hasEdge(is[i],is[j])).toBe(false); });
  it('returns array', () => { expect(Array.isArray(maximumIndependentSet(makeTriangle()))).toBe(true); });
});

describe('vertexCover', () => {
  it('covers all edges', () => { const vc = vertexCover(makePath()); for (const e of makePath().edges()) expect(vc.includes(e.source)||vc.includes(e.target)).toBe(true); });
  it('triangle cover >= 2', () => { expect(vertexCover(makeTriangle()).length).toBeGreaterThanOrEqual(2); });
  it('returns array', () => { expect(Array.isArray(vertexCover(makeTriangle()))).toBe(true); });
  it('empty graph returns empty', () => { expect(vertexCover(new Graph())).toHaveLength(0); });
});

describe('isClique', () => {
  it('K4 nodes form clique', () => { expect(isClique(makeK4(), ['a','b','c','d'])).toBe(true); });
  it('triangle nodes form clique', () => { expect(isClique(makeTriangle(), ['a','b','c'])).toBe(true); });
  it('non-adjacent nodes do not', () => { expect(isClique(makePath(), ['a','c'])).toBe(false); });
  it('empty set is clique', () => { expect(isClique(makeTriangle(), [])).toBe(true); });
  it('single node is clique', () => { expect(isClique(makeTriangle(), ['a'])).toBe(true); });
});

describe('clique advanced', () => {
  it('cliqueNumber of K4 is 4', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); expect(cliqueNumber(g)).toBe(4); });
  it('independenceNumber of K4 is 1', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); expect(independenceNumber(g)).toBe(1); });
  it('isClique true for K3', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(isClique(g,['a','b','c'])).toBe(true); });
  it('isClique false for path', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); expect(isClique(g,['a','b','c'])).toBe(false); });
  it('allMaximalCliques for triangle has 1 maximal clique', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); expect(allMaximalCliques(g).length).toBeGreaterThan(0); });
  it('vertexCover covers all edges', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); const vc = vertexCover(g); for (const e of g.edges()) expect(vc.includes(e.source) || vc.includes(e.target)).toBe(true); });
  it('maximumIndependentSet is non-empty', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); expect(maximumIndependentSet(g).length).toBeGreaterThan(0); });
  it('maxClique of isolated nodes is 1', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); expect(maxClique(g).length).toBe(1); });
})


