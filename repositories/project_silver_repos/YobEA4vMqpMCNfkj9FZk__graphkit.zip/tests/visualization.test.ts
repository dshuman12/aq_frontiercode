import { Graph } from '../src/graph';
import { DiGraph } from '../src/digraph';
import { circularLayout, hierarchicalLayout, forceDirectedLayout, renderASCII, toMermaid, toGraphvizDOT, graphSummary } from '../src/visualization';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n); g.addEdge('hub',n);}); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); return g; }
function makeDigraph(): DiGraph { const g = new DiGraph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); return g; }

describe('circularLayout', () => {
  it('returns position for each node', () => { const layout = circularLayout(makeTriangle()); for (const n of makeTriangle().nodeIds()) expect(layout.has(n)).toBe(true); });
  it('positions have x and y', () => { for (const pos of circularLayout(makeTriangle()).values()) { expect(pos).toHaveProperty('x'); expect(pos).toHaveProperty('y'); } });
  it('returns Map', () => { expect(circularLayout(makeTriangle()) instanceof Map).toBe(true); });
  it('works on single node', () => { const g = new Graph(); g.addNode('x'); expect(circularLayout(g).size).toBe(1); });
  it('works on star', () => { expect(circularLayout(makeStar()).size).toBe(4); });
  it('x and y are numbers', () => { for (const pos of circularLayout(makeTriangle()).values()) { expect(typeof pos.x).toBe('number'); expect(typeof pos.y).toBe('number'); } });
});

describe('hierarchicalLayout', () => {
  it('returns position for each node', () => { const layout = hierarchicalLayout(makeDigraph()); for (const n of makeDigraph().nodeIds()) expect(layout.has(n)).toBe(true); });
  it('positions have x and y', () => { for (const pos of hierarchicalLayout(makeDigraph()).values()) { expect(pos).toHaveProperty('x'); expect(pos).toHaveProperty('y'); } });
  it('returns Map', () => { expect(hierarchicalLayout(makeDigraph()) instanceof Map).toBe(true); });
  it('single node digraph', () => { const g = new DiGraph(); g.addNode('x'); expect(hierarchicalLayout(g).size).toBe(1); });
});

describe('forceDirectedLayout', () => {
  it('returns position for each node', () => { const layout = forceDirectedLayout(makeTriangle()); for (const n of makeTriangle().nodeIds()) expect(layout.has(n)).toBe(true); });
  it('positions have x and y', () => { for (const pos of forceDirectedLayout(makeTriangle()).values()) { expect(pos).toHaveProperty('x'); expect(pos).toHaveProperty('y'); } });
  it('returns Map', () => { expect(forceDirectedLayout(makeTriangle()) instanceof Map).toBe(true); });
  it('works on path', () => { expect(forceDirectedLayout(makePath()).size).toBe(4); });
  it('x and y are numbers', () => { for (const pos of forceDirectedLayout(makeStar()).values()) { expect(typeof pos.x).toBe('number'); } });
});

describe('renderASCII', () => {
  it('returns a string', () => { const layout = circularLayout(makeTriangle()); expect(typeof renderASCII(makeTriangle(), layout)).toBe('string'); });
  it('non-empty output', () => { const layout = circularLayout(makeTriangle()); expect(renderASCII(makeTriangle(), layout).length).toBeGreaterThan(0); });
  it('works with force layout', () => { const layout = forceDirectedLayout(makeStar()); expect(typeof renderASCII(makeStar(), layout)).toBe('string'); });
});

describe('toMermaid', () => {
  it('returns string', () => { expect(typeof toMermaid(makeTriangle())).toBe('string'); });
  it('contains node names', () => { expect(toMermaid(makeTriangle())).toContain('a'); });
  it('non-empty', () => { expect(toMermaid(makeTriangle()).length).toBeGreaterThan(0); });
  it('digraph output defined', () => { expect(toMermaid(makeDigraph())).toBeDefined(); });
  it('contains b', () => { expect(toMermaid(makePath())).toContain('b'); });
});

describe('toGraphvizDOT', () => {
  it('returns string', () => { expect(typeof toGraphvizDOT(makeTriangle())).toBe('string'); });
  it('contains graph keyword', () => { expect(toGraphvizDOT(makeTriangle())).toContain('graph'); });
  it('ends with closing brace', () => { expect(toGraphvizDOT(makeTriangle()).trim().endsWith('}')).toBe(true); });
  it('contains node names', () => { expect(toGraphvizDOT(makeTriangle())).toContain('a'); });
  it('digraph uses digraph keyword', () => { expect(toGraphvizDOT(makeDigraph())).toContain('digraph'); });
  it('non-empty', () => { expect(toGraphvizDOT(makeTriangle()).length).toBeGreaterThan(0); });
});

describe('graphSummary', () => {
  it('returns string', () => { expect(typeof graphSummary(makeTriangle())).toBe('string'); });
  it('non-empty', () => { expect(graphSummary(makeTriangle()).length).toBeGreaterThan(0); });
  it('contains 3', () => { expect(graphSummary(makeTriangle())).toContain('3'); });
  it('empty graph works', () => { expect(graphSummary(new Graph()).length).toBeGreaterThan(0); });
  it('star summary has 4', () => { expect(graphSummary(makeStar())).toContain('4'); });
});


