import { Graph } from '../src/graph';
import {
  monteCarloConnectivity, bondPercolation, sitePercolation,
  estimateReliability, simulateEpidemicSIR, simulateEpidemicSIS,
  approximateChromatic, randomizedMinCut
} from '../src/probabilistic';

function makeTriangle(): Graph {
  const g = new Graph();
  ['a','b','c'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1);
  return g;
}
function makePath4(): Graph {
  const g = new Graph();
  ['a','b','c','d'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1);
  return g;
}
function makeK4(): Graph {
  const g = new Graph();
  ['a','b','c','d'].forEach(n => g.addNode(n));
  g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d');
  g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d');
  return g;
}

describe('monteCarloConnectivity', () => {
  it('complete graph with 0 failure prob has estimate ~1', () => {
    const r = monteCarloConnectivity(makeK4(), 0, 200);
    expect(r.estimate).toBeCloseTo(1, 1);
  });
  it('returns confidence interval with lower <= upper', () => {
    const r = monteCarloConnectivity(makeTriangle(), 0.1, 100);
    expect(r.confidence95[0]).toBeLessThanOrEqual(r.confidence95[1]);
  });
  it('estimate is in [0,1]', () => {
    const r = monteCarloConnectivity(makePath4(), 0.5, 100);
    expect(r.estimate).toBeGreaterThanOrEqual(0);
    expect(r.estimate).toBeLessThanOrEqual(1);
  });
  it('samples count matches input', () => {
    expect(monteCarloConnectivity(makeTriangle(), 0, 50).samples).toBe(50);
  });
  it('empty graph returns estimate 1', () => {
    const g = new Graph();
    expect(monteCarloConnectivity(g, 0.5, 10).estimate).toBe(1);
  });
  it('variance is non-negative', () => {
    expect(monteCarloConnectivity(makeK4(), 0.2, 100).variance).toBeGreaterThanOrEqual(0);
  });
  it('high failure prob gives low estimate', () => {
    const r = monteCarloConnectivity(makePath4(), 0.99, 200);
    expect(r.estimate).toBeLessThan(0.5);
  });
  it('confidence interval width is positive for uncertain case', () => {
    const r = monteCarloConnectivity(makePath4(), 0.5, 200);
    expect(r.confidence95[1] - r.confidence95[0]).toBeGreaterThanOrEqual(0);
  });
});

describe('bondPercolation', () => {
  it('p=1 percolates for connected graph', () => {
    const r = bondPercolation(makeK4(), 1);
    expect(r.giantComponentSize).toBe(4);
  });
  it('p=0 results in isolated nodes', () => {
    const r = bondPercolation(makeK4(), 0);
    expect(r.giantComponentSize).toBe(1);
  });
  it('returns componentSizes array', () => {
    expect(Array.isArray(bondPercolation(makeTriangle(), 0.5).componentSizes)).toBe(true);
  });
  it('percolationThreshold is positive', () => {
    expect(bondPercolation(makeK4(), 0.5).percolationThreshold).toBeGreaterThan(0);
  });
  it('giantComponentSize <= nodeCount', () => {
    const r = bondPercolation(makeK4(), 0.5);
    expect(r.giantComponentSize).toBeLessThanOrEqual(4);
  });
  it('empty graph giant component is 0', () => {
    const r = bondPercolation(new Graph(), 0.5);
    expect(r.giantComponentSize).toBe(0);
  });
});

describe('sitePercolation', () => {
  it('p=1 keeps all nodes', () => {
    expect(sitePercolation(makeK4(), 1).giantComponentSize).toBe(4);
  });
  it('p=0 leaves no nodes', () => {
    expect(sitePercolation(makeK4(), 0).giantComponentSize).toBe(0);
  });
  it('componentSizes sum <= nodeCount', () => {
    const r = sitePercolation(makeK4(), 0.5);
    const total = r.componentSizes.reduce((s, v) => s + v, 0);
    expect(total).toBeLessThanOrEqual(4);
  });
  it('threshold is in (0,1)', () => {
    const r = sitePercolation(makeK4(), 0.5);
    expect(r.percolationThreshold).toBeGreaterThan(0);
    expect(r.percolationThreshold).toBeLessThan(2);
  });
});

describe('estimateReliability', () => {
  it('reliability is in [0,1]', () => {
    const r = estimateReliability(makeK4(), 1, 'a', 'd', 100);
    expect(r.reliability).toBeGreaterThanOrEqual(0);
    expect(r.reliability).toBeLessThanOrEqual(1);
  });
  it('variance is non-negative', () => {
    expect(estimateReliability(makeTriangle(), 0.9, 'a', 'c', 50).variance).toBeGreaterThanOrEqual(0);
  });
  it('criticalEdges is an array', () => {
    expect(Array.isArray(estimateReliability(makePath4(), 0.8, 'a', 'd', 50).criticalEdges)).toBe(true);
  });
  it('perfect reliability when survival prob = 1', () => {
    expect(estimateReliability(makeK4(), 1, 'a', 'b', 50).reliability).toBe(1);
  });
});

describe('simulateEpidemicSIR', () => {
  it('returns susceptible, infected, recovered arrays', () => {
    const r = simulateEpidemicSIR(makeK4(), 0.5, 0.3, ['a'], 10);
    expect(Array.isArray(r.susceptible)).toBe(true);
    expect(Array.isArray(r.infected)).toBe(true);
    expect(Array.isArray(r.recovered)).toBe(true);
  });
  it('initial infected count is 1', () => {
    const r = simulateEpidemicSIR(makeK4(), 0.5, 0.3, ['a'], 10);
    expect(r.infected[0]).toBe(1);
  });
  it('population is conserved at every step', () => {
    const r = simulateEpidemicSIR(makeK4(), 0.5, 0.3, ['a'], 5);
    for (let i = 0; i < r.susceptible.length; i++)
      expect(r.susceptible[i] + r.infected[i] + r.recovered[i]).toBe(4);
  });
  it('no initial recovered', () => {
    const r = simulateEpidemicSIR(makeTriangle(), 0.3, 0.2, ['a'], 5);
    expect(r.recovered[0]).toBe(0);
  });
  it('time steps array matches length', () => {
    const r = simulateEpidemicSIR(makeK4(), 0.5, 0.3, ['a'], 8);
    expect(r.susceptible.length).toBe(r.infected.length);
  });
});

describe('simulateEpidemicSIS', () => {
  it('population is conserved at every step', () => {
    const r = simulateEpidemicSIS(makeK4(), 0.4, 0.3, ['a'], 5);
    for (let i = 0; i < r.susceptible.length; i++)
      expect(r.susceptible[i] + r.infected[i]).toBe(4);
  });
  it('initial infected is 1', () => {
    const r = simulateEpidemicSIS(makeK4(), 0.4, 0.3, ['a'], 5);
    expect(r.infected[0]).toBe(1);
  });
  it('no recovered array (SIS model)', () => {
    const r = simulateEpidemicSIS(makeK4(), 0.4, 0.3, ['a'], 5);
    expect((r as any).recovered).toBeUndefined();
  });
});

describe('approximateChromatic', () => {
  it('triangle needs at least 3 colours', () => {
    expect(approximateChromatic(makeTriangle(), 20)).toBeGreaterThanOrEqual(3);
  });
  it('K4 needs at least 4 colours', () => {
    expect(approximateChromatic(makeK4(), 20)).toBeGreaterThanOrEqual(4);
  });
  it('path needs at most 3 colours', () => {
    expect(approximateChromatic(makePath4(), 20)).toBeLessThanOrEqual(3);
  });
  it('single node needs 1 colour', () => {
    const g = new Graph(); g.addNode('x');
    expect(approximateChromatic(g, 10)).toBe(1);
  });
  it('empty graph returns non-positive', () => {
    expect(approximateChromatic(new Graph(), 10)).toBeLessThanOrEqual(0);
  });
});

describe('randomizedMinCut', () => {
  it('returns non-negative number', () => {
    expect(randomizedMinCut(makeTriangle(), 20)).toBeGreaterThanOrEqual(0);
  });
  it('empty graph returns 0', () => {
    expect(randomizedMinCut(new Graph(), 5)).toBe(0);
  });
  it('K4 min cut is at least 1', () => {
    expect(randomizedMinCut(makeK4(), 30)).toBeGreaterThanOrEqual(1);
  });
  it('single node returns 0', () => {
    const g = new Graph(); g.addNode('a');
    expect(randomizedMinCut(g, 5)).toBe(0);
  });
});

