import { Graph } from '../src/graph';
import { maximumMatching, maximumWeightMatching, perfectMatching, matchingNumber, isMatchingValid, stableMatching, edgeCover } from '../src/matching';

function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); return g; }
function makeK4(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',3); g.addEdge('a','c',1); g.addEdge('a','d',2); g.addEdge('b','c',2); g.addEdge('b','d',1); g.addEdge('c','d',3); return g; }
function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makeBipartite(): Graph { const g = new Graph(); ['l1','l2','r1','r2'].forEach(n=>g.addNode(n)); g.addEdge('l1','r1',2); g.addEdge('l1','r2',1); g.addEdge('l2','r1',1); g.addEdge('l2','r2',2); return g; }

describe('maximumMatching', () => {
  it('path matching has size 2', () => { expect(maximumMatching(makePath()).size).toBe(2); });
  it('matching is valid', () => { const r = maximumMatching(makePath()); expect(isMatchingValid(makePath(), r.matching)).toBe(true); });
  it('K4 matching has size 2', () => { expect(maximumMatching(makeK4()).size).toBe(2); });
  it('K4 matching is perfect', () => { expect(maximumMatching(makeK4()).isPerfect).toBe(true); });
  it('triangle matching has size 1', () => { expect(maximumMatching(makeTriangle()).size).toBe(1); });
  it('empty graph has 0 matching', () => { expect(maximumMatching(new Graph()).size).toBe(0); });
  it('single node has 0 matching', () => { const g = new Graph(); g.addNode('x'); expect(maximumMatching(g).size).toBe(0); });
  it('returns MatchingResult', () => { const r = maximumMatching(makePath()); expect(r).toHaveProperty('matching'); expect(r).toHaveProperty('size'); expect(r).toHaveProperty('isPerfect'); });
});

describe('maximumWeightMatching', () => {
  it('returns valid matching', () => { const r = maximumWeightMatching(makeK4()); expect(isMatchingValid(makeK4(), r.matching)).toBe(true); });
  it('weight is positive', () => { expect(maximumWeightMatching(makeK4()).weight).toBeGreaterThan(0); });
  it('bipartite prefers high-weight edges', () => { const r = maximumWeightMatching(makeBipartite()); expect(r.weight).toBeGreaterThanOrEqual(3); });
  it('empty graph weight 0', () => { expect(maximumWeightMatching(new Graph()).weight).toBe(0); });
  it('size is number', () => { expect(typeof maximumWeightMatching(makePath()).size).toBe('number'); });
});

describe('perfectMatching', () => {
  it('K4 has perfect matching', () => { expect(perfectMatching(makeK4())).not.toBeNull(); });
  it('triangle has no perfect matching', () => { expect(perfectMatching(makeTriangle())).toBeNull(); });
  it('path of 4 has perfect matching', () => { expect(perfectMatching(makePath())).not.toBeNull(); });
  it('odd path has no perfect matching', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); expect(perfectMatching(g)).toBeNull(); });
  it('empty graph returns null', () => { expect(perfectMatching(new Graph())).toBeNull(); });
});

describe('matchingNumber', () => {
  it('path matching number is 2', () => { expect(matchingNumber(makePath())).toBe(2); });
  it('K4 matching number is 2', () => { expect(matchingNumber(makeK4())).toBe(2); });
  it('triangle matching number is 1', () => { expect(matchingNumber(makeTriangle())).toBe(1); });
  it('empty graph is 0', () => { expect(matchingNumber(new Graph())).toBe(0); });
});

describe('isMatchingValid', () => {
  it('valid matching returns true', () => { const r = maximumMatching(makePath()); expect(isMatchingValid(makePath(), r.matching)).toBe(true); });
  it('invalid matching returns false', () => { const bad = new Map([['a','b'],['b','c']]); expect(isMatchingValid(makePath(), bad)).toBe(false); });
  it('empty matching is valid', () => { expect(isMatchingValid(makePath(), new Map())).toBe(true); });
  it('non-edge returns false', () => { const bad = new Map([['a','d']]); expect(isMatchingValid(makePath(), bad)).toBe(false); });
});

describe('stableMatching', () => {
  it('returns matching of size proposers', () => {
    const proposers = ['m1','m2'];
    const receivers = ['w1','w2'];
    const pp = new Map([['m1',['w1','w2']], ['m2',['w1','w2']]]);
    const rp = new Map([['w1',['m1','m2']], ['w2',['m2','m1']]]);
    const r = stableMatching(proposers, receivers, pp, rp);
    expect(r.size).toBe(2);
  });
  it('is stable', () => {
    const proposers = ['m1','m2'];
    const receivers = ['w1','w2'];
    const pp = new Map([['m1',['w1','w2']], ['m2',['w2','w1']]]);
    const rp = new Map([['w1',['m1','m2']], ['w2',['m1','m2']]]);
    const r = stableMatching(proposers, receivers, pp, rp);
    expect(r.isStable).toBe(true);
  });
  it('returns MatchingResult type', () => {
    const r = stableMatching(['m1'],['w1'], new Map([['m1',['w1']]]), new Map([['w1',['m1']]]));
    expect(r).toHaveProperty('matching');
  });
});

describe('edgeCover', () => {
  it('covers all nodes', () => { const ec = edgeCover(makePath()); const covered = new Set(ec.flat()); for (const n of makePath().nodeIds()) expect(covered.has(n)).toBe(true); });
  it('each entry is a pair', () => { for (const e of edgeCover(makePath())) expect(e).toHaveLength(2); });
  it('returns array', () => { expect(Array.isArray(edgeCover(makePath()))).toBe(true); });
});

describe('matching extended', () => {
  it('maximumMatching on K6 is perfect', () => { const g = new Graph(); ['a','b','c','d','e','f'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('c','d'); g.addEdge('e','f'); g.addEdge('a','c'); g.addEdge('b','d'); g.addEdge('d','f'); expect(maximumMatching(g).size).toBeGreaterThan(0); });
  it('edgeCover returns non-empty for connected', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); expect(edgeCover(g).length).toBeGreaterThan(0); });
  it('matchingNumber of path 6 is 3', () => { const g = new Graph(); ['a','b','c','d','e','f'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); g.addEdge('d','e'); g.addEdge('e','f'); expect(matchingNumber(g)).toBe(3); });
})


