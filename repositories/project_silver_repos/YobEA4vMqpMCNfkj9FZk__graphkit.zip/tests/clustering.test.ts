import { Graph } from '../src/graph';
import { singleLinkageClustering, completeLinkageClustering, averageLinkageClustering, kMedoidsClustering, clusterSilhouette, clusterDensity, interClusterEdges, clusterConductance, optimalClusters } from '../src/clustering';

function makeConnected(): Graph {
  const g = new Graph();
  ['a','b','c','x','y','z'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('a','c',1);
  g.addEdge('x','y',1); g.addEdge('y','z',1); g.addEdge('x','z',1);
  g.addEdge('c','x',5);
  return g;
}
function makeSmall(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); return g; }

describe('singleLinkageClustering', () => {
  it('k=1 returns one cluster with all nodes', () => { const c = singleLinkageClustering(makeConnected(), 1); expect(c).toHaveLength(1); expect(c[0]).toHaveLength(6); });
  it('k=2 returns two clusters', () => { expect(singleLinkageClustering(makeConnected(), 2)).toHaveLength(2); });
  it('covers all nodes', () => { const c = singleLinkageClustering(makeConnected(), 2); const total = c.reduce((s,cl)=>s+cl.length,0); expect(total).toBe(6); });
  it('k=n returns n singleton clusters', () => { const c = singleLinkageClustering(makeSmall(), 3); expect(c).toHaveLength(3); for (const cl of c) expect(cl).toHaveLength(1); });
  it('empty graph returns empty', () => { expect(singleLinkageClustering(new Graph(), 1)).toHaveLength(0); });
  it('no node in two clusters', () => { const c = singleLinkageClustering(makeConnected(), 2); const all = c.flat(); expect(new Set(all).size).toBe(all.length); });
});

describe('completeLinkageClustering', () => {
  it('k=2 returns 2 clusters', () => { expect(completeLinkageClustering(makeConnected(), 2)).toHaveLength(2); });
  it('covers all nodes', () => { const c = completeLinkageClustering(makeConnected(), 2); const total = c.reduce((s,cl)=>s+cl.length,0); expect(total).toBe(6); });
  it('k=1 one cluster', () => { const c = completeLinkageClustering(makeSmall(), 1); expect(c).toHaveLength(1); });
  it('no duplicates', () => { const c = completeLinkageClustering(makeConnected(), 2); const all = c.flat(); expect(new Set(all).size).toBe(all.length); });
  it('empty returns empty', () => { expect(completeLinkageClustering(new Graph(), 1)).toHaveLength(0); });
});

describe('averageLinkageClustering', () => {
  it('k=2 returns 2 clusters', () => { expect(averageLinkageClustering(makeConnected(), 2)).toHaveLength(2); });
  it('covers all nodes', () => { const c = averageLinkageClustering(makeConnected(), 2); const total = c.reduce((s,cl)=>s+cl.length,0); expect(total).toBe(6); });
  it('k=1 one cluster', () => { expect(averageLinkageClustering(makeSmall(), 1)).toHaveLength(1); });
  it('no duplicates', () => { const c = averageLinkageClustering(makeConnected(), 2); const all = c.flat(); expect(new Set(all).size).toBe(all.length); });
});

describe('kMedoidsClustering', () => {
  it('k=2 returns 2 clusters', () => { expect(kMedoidsClustering(makeConnected(), 2)).toHaveLength(2); });
  it('covers all nodes', () => { const c = kMedoidsClustering(makeConnected(), 2); const total = c.reduce((s,cl)=>s+cl.length,0); expect(total).toBe(6); });
  it('k=1 one cluster', () => { expect(kMedoidsClustering(makeSmall(), 1)).toHaveLength(1); });
  it('no duplicates', () => { const c = kMedoidsClustering(makeConnected(), 2); const all = c.flat(); expect(new Set(all).size).toBe(all.length); });
  it('empty returns empty', () => { expect(kMedoidsClustering(new Graph(), 1)).toHaveLength(0); });
});

describe('clusterSilhouette', () => {
  it('returns number in [-1,1]', () => { const c = singleLinkageClustering(makeConnected(), 2); const s = clusterSilhouette(makeConnected(), c); expect(s).toBeGreaterThanOrEqual(-1); expect(s).toBeLessThanOrEqual(1); });
  it('good partition has positive silhouette', () => { const c = [['a','b','c'],['x','y','z']]; expect(clusterSilhouette(makeConnected(), c)).toBeGreaterThan(0); });
  it('returns number', () => { expect(typeof clusterSilhouette(makeSmall(), [['a','b','c']])).toBe('number'); });
});

describe('clusterDensity', () => {
  it('triangle cluster density is 1', () => { expect(clusterDensity(makeSmall(), ['a','b','c'])).toBe(1); });
  it('single node density is 0', () => { expect(clusterDensity(makeSmall(), ['a'])).toBe(0); });
  it('in [0,1]', () => { const d = clusterDensity(makeConnected(), ['a','b','c']); expect(d).toBeGreaterThanOrEqual(0); expect(d).toBeLessThanOrEqual(1); });
  it('empty cluster is 0', () => { expect(clusterDensity(makeSmall(), [])).toBe(0); });
});

describe('interClusterEdges', () => {
  it('disjoint clusters count bridge edges', () => { expect(interClusterEdges(makeConnected(), ['a','b','c'], ['x','y','z'])).toBeGreaterThan(0); });
  it('non-adjacent clusters have 0', () => { const g = new Graph(); ['a','b','x','y'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('x','y'); expect(interClusterEdges(g, ['a','b'], ['x','y'])).toBe(0); });
  it('returns non-negative', () => { expect(interClusterEdges(makeConnected(), ['a'], ['b','c'])).toBeGreaterThanOrEqual(0); });
});

describe('clusterConductance', () => {
  it('isolated cluster has 0 conductance', () => { const g = new Graph(); ['a','b','x','y'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('x','y'); expect(clusterConductance(g, ['a','b'])).toBe(0); });
  it('returns in [0,1]', () => { const c = clusterConductance(makeConnected(), ['a','b','c']); expect(c).toBeGreaterThanOrEqual(0); expect(c).toBeLessThanOrEqual(1); });
  it('returns number', () => { expect(typeof clusterConductance(makeSmall(), ['a','b'])).toBe('number'); });
});

describe('optimalClusters', () => {
  it('returns positive integer', () => { expect(optimalClusters(makeConnected())).toBeGreaterThan(0); });
  it('single node returns 1', () => { const g = new Graph(); g.addNode('x'); expect(optimalClusters(g)).toBe(1); });
  it('returns number <= maxK', () => { expect(optimalClusters(makeConnected(), 3)).toBeLessThanOrEqual(3); });
  it('empty graph returns 1', () => { expect(optimalClusters(new Graph())).toBe(1); });
});


