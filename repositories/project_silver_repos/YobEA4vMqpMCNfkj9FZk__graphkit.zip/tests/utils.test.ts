import { range, shuffle, sample, groupBy, unique, flatten, zip, product, clamp, lerp, sumBy, maxBy, minBy, countBy, sortBy, partition2, intersect, difference, union, combinations, permutations, nodeSetEqual, memoize, timer } from '../src/utils';

describe('range', () => {
  it('range(5) gives [0..4]', () => { expect(range(5)).toEqual([0,1,2,3,4]); });
  it('range(0) gives []', () => { expect(range(0)).toEqual([]); });
  it('length matches n', () => { expect(range(10)).toHaveLength(10); });
});

describe('shuffle', () => {
  it('preserves length', () => { expect(shuffle([1,2,3,4,5])).toHaveLength(5); });
  it('same seed gives same result', () => { expect(shuffle([1,2,3,4,5],1)).toEqual(shuffle([1,2,3,4,5],1)); });
  it('different seeds differ', () => { expect(shuffle([1,2,3,4,5,6,7,8],1)).not.toEqual(shuffle([1,2,3,4,5,6,7,8],2)); });
  it('contains all elements', () => { const s = shuffle([1,2,3]); expect(s.sort()).toEqual([1,2,3]); });
});

describe('sample', () => {
  it('returns k elements', () => { expect(sample([1,2,3,4,5],3)).toHaveLength(3); });
  it('k > n returns all', () => { expect(sample([1,2,3],10)).toHaveLength(3); });
  it('k=0 returns empty', () => { expect(sample([1,2,3],0)).toHaveLength(0); });
  it('all elements valid', () => { const src = [1,2,3,4,5]; for (const x of sample(src,3)) expect(src).toContain(x); });
});

describe('unique', () => {
  it('removes duplicates', () => { expect(unique([1,1,2,2,3])).toHaveLength(3); });
  it('preserves order', () => { expect(unique([3,1,2,1,3])[0]).toBe(3); });
  it('empty stays empty', () => { expect(unique([])).toHaveLength(0); });
});

describe('flatten', () => {
  it('flattens nested arrays', () => { expect(flatten([[1,2],[3,4]])).toEqual([1,2,3,4]); });
  it('empty inner stays flat', () => { expect(flatten([[],[1,2]])).toEqual([1,2]); });
  it('length is sum of inner lengths', () => { expect(flatten([[1,2],[3],[4,5,6]])).toHaveLength(6); });
});

describe('zip', () => {
  it('pairs elements', () => { expect(zip([1,2,3],['a','b','c'])).toEqual([[1,'a'],[2,'b'],[3,'c']]); });
  it('shorter array limits length', () => { expect(zip([1,2,3],['a','b'])).toHaveLength(2); });
  it('empty arrays', () => { expect(zip([],[]).length).toBe(0); });
});

describe('clamp', () => {
  it('within range returns value', () => { expect(clamp(5,0,10)).toBe(5); });
  it('below min returns min', () => { expect(clamp(-1,0,10)).toBe(0); });
  it('above max returns max', () => { expect(clamp(15,0,10)).toBe(10); });
});

describe('lerp', () => {
  it('t=0 returns a', () => { expect(lerp(0,10,0)).toBe(0); });
  it('t=1 returns b', () => { expect(lerp(0,10,1)).toBe(10); });
  it('t=0.5 returns midpoint', () => { expect(lerp(0,10,0.5)).toBe(5); });
});

describe('sumBy', () => {
  it('sums by fn', () => { expect(sumBy([1,2,3], x=>x)).toBe(6); });
  it('empty is 0', () => { expect(sumBy([],x=>x)).toBe(0); });
});

describe('maxBy/minBy', () => {
  it('maxBy finds max', () => { expect(maxBy([1,5,3], x=>x)).toBe(5); });
  it('minBy finds min', () => { expect(minBy([1,5,3], x=>x)).toBe(1); });
  it('maxBy empty is undefined', () => { expect(maxBy([], x=>x)).toBeUndefined(); });
});

describe('sortBy', () => {
  it('sorts ascending', () => { expect(sortBy([3,1,2], x=>x)).toEqual([1,2,3]); });
  it('sorts descending', () => { expect(sortBy([3,1,2], x=>x, true)).toEqual([3,2,1]); });
});

describe('partition2', () => {
  it('splits by predicate', () => { const [yes,no] = partition2([1,2,3,4], x=>x%2===0); expect(yes).toEqual([2,4]); expect(no).toEqual([1,3]); });
  it('all true gives empty no', () => { const [yes,no] = partition2([1,2,3], x=>true); expect(no).toHaveLength(0); });
});

describe('set operations', () => {
  it('intersect', () => { expect(intersect([1,2,3],[2,3,4])).toEqual([2,3]); });
  it('difference', () => { expect(difference([1,2,3],[2,3])).toEqual([1]); });
  it('union', () => { expect(union([1,2],[2,3]).sort()).toEqual([1,2,3]); });
});

describe('combinations', () => {
  it('C(3,2)=3', () => { expect(combinations([1,2,3],2)).toHaveLength(3); });
  it('C(4,1)=4', () => { expect(combinations([1,2,3,4],1)).toHaveLength(4); });
  it('C(n,0)=1', () => { expect(combinations([1,2,3],0)).toHaveLength(1); });
  it('each combination has k elements', () => { for (const c of combinations([1,2,3,4],2)) expect(c).toHaveLength(2); });
});

describe('nodeSetEqual', () => {
  it('same sets are equal', () => { expect(nodeSetEqual(['a','b','c'],['b','c','a'])).toBe(true); });
  it('different sets not equal', () => { expect(nodeSetEqual(['a','b'],['a','c'])).toBe(false); });
  it('different lengths not equal', () => { expect(nodeSetEqual(['a','b'],['a'])).toBe(false); });
});

describe('memoize', () => {
  it('returns same result', () => { const fn = memoize((x: number) => x*2); expect(fn(5)).toBe(10); expect(fn(5)).toBe(10); });
  it('caches calls', () => { let calls = 0; const fn = memoize((x: number) => { calls++; return x*2; }); fn(3); fn(3); expect(calls).toBe(1); });
});

describe('timer', () => {
  it('returns result', () => { expect(timer(()=>42).result).toBe(42); });
  it('elapsed is non-negative', () => { expect(timer(()=>{}).elapsed).toBeGreaterThanOrEqual(0); });
});


