import { Graph } from '../src/graph';
import { degreeDistribution, isTree, findCycles, eccentricity, center, periphery, girth, topKCentralNodes, generateReport, compareGraphs } from '../src/analysis';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); return g; }
function makeTree(): Graph { const g = new Graph(); ['r','a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('r','a'); g.addEdge('r','b'); g.addEdge('a','c'); g.addEdge('a','d'); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','d'); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n);g.addEdge('hub',n);}); return g; }

describe('degreeDistribution', () => {
  it('has histogram', () => { expect(degreeDistribution(makeTriangle())).toHaveProperty('histogram'); });
  it('has mean', () => { expect(typeof degreeDistribution(makeTriangle()).mean).toBe('number'); });
  it('triangle mean degree is 2', () => { expect(degreeDistribution(makeTriangle()).mean).toBe(2); });
  it('has max', () => { expect(typeof degreeDistribution(makeTriangle()).max).toBe('number'); });
  it('has min', () => { expect(typeof degreeDistribution(makeTriangle()).min).toBe('number'); });
  it('has stdDev', () => { expect(typeof degreeDistribution(makeTriangle()).stdDev).toBe('number'); });
  it('path mean degree is 1.5', () => { expect(degreeDistribution(makePath()).mean).toBe(1.5); });
});

describe('isTree', () => {
  it('tree is a tree', () => { expect(isTree(makeTree())).toBe(true); });
  it('triangle is not a tree', () => { expect(isTree(makeTriangle())).toBe(false); });
  it('path is a tree', () => { expect(isTree(makePath())).toBe(true); });
  it('single node is a tree', () => { const g = new Graph(); g.addNode('x'); expect(isTree(g)).toBe(true); });
  it('star is a tree', () => { expect(isTree(makeStar())).toBe(true); });
  it('disconnected is not a tree', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(isTree(g)).toBe(false); });
});

describe('findCycles', () => {
  it('triangle has cycles', () => { expect(findCycles(makeTriangle()).length).toBeGreaterThan(0); });
  it('tree has no cycles', () => { expect(findCycles(makeTree())).toHaveLength(0); });
  it('path has no cycles', () => { expect(findCycles(makePath())).toHaveLength(0); });
  it('returns array', () => { expect(Array.isArray(findCycles(makeTriangle()))).toBe(true); });
  it('each cycle is an array', () => { for (const c of findCycles(makeTriangle())) expect(Array.isArray(c)).toBe(true); });
});

describe('eccentricity', () => {
  it('returns Map', () => { expect(eccentricity(makePath()) instanceof Map).toBe(true); });
  it('all nodes have eccentricity', () => { for (const n of makePath().nodeIds()) expect(eccentricity(makePath()).has(n)).toBe(true); });
  it('endpoints have higher eccentricity', () => { const e = eccentricity(makePath()); expect(e.get('a')).toBeGreaterThan(e.get('b')!); });
  it('triangle nodes all equal', () => { const e = eccentricity(makeTriangle()); const vals = [...e.values()]; expect(vals[0]).toBe(vals[1]); });
  it('star hub eccentricity is 1', () => { expect(eccentricity(makeStar()).get('hub')).toBe(1); });
});

describe('center', () => {
  it('returns array', () => { expect(Array.isArray(center(makePath()))).toBe(true); });
  it('path center is middle', () => { const c = center(makePath()); expect(c.includes('b') || c.includes('c')).toBe(true); });
  it('star center is hub', () => { expect(center(makeStar())).toContain('hub'); });
  it('non-empty', () => { expect(center(makePath()).length).toBeGreaterThan(0); });
});

describe('periphery', () => {
  it('returns array', () => { expect(Array.isArray(periphery(makePath()))).toBe(true); });
  it('path endpoints in periphery', () => { const p = periphery(makePath()); expect(p.includes('a') || p.includes('d')).toBe(true); });
  it('non-empty', () => { expect(periphery(makePath()).length).toBeGreaterThan(0); });
});

describe('girth', () => {
  it('triangle girth is 3', () => { expect(girth(makeTriangle())).toBe(3); });
  it('tree girth has no cycle', () => { expect(girth(makeTree())).not.toBe(3); });
  it('path girth has no short cycle', () => { expect(girth(makePath())).not.toBe(3); });
  it('returns number', () => { expect(typeof girth(makeTriangle())).toBe('number'); });
});

describe('topKCentralNodes', () => {
  it('returns k nodes', () => { expect(topKCentralNodes(makeStar(), 2)).toHaveLength(2); });
  it('hub is most central in star', () => { expect(topKCentralNodes(makeStar(), 1)[0]).toBe('hub'); });
  it('k=0 returns empty', () => { expect(topKCentralNodes(makeStar(), 0)).toHaveLength(0); });
  it('returns array', () => { expect(Array.isArray(topKCentralNodes(makePath(), 2))).toBe(true); });
  it('k=1 returns one node', () => { expect(topKCentralNodes(makeTree(), 1)).toHaveLength(1); });
});

describe('generateReport', () => {
  it('has nodeCount', () => { expect(generateReport(makeTriangle())).toHaveProperty('nodeCount'); });
  it('has edgeCount', () => { expect(generateReport(makeTriangle())).toHaveProperty('edgeCount'); });
  it('nodeCount correct', () => { expect(generateReport(makeTriangle()).nodeCount).toBe(3); });
  it('edgeCount correct', () => { expect(generateReport(makeTriangle()).edgeCount).toBe(3); });
  it('returns object', () => { expect(typeof generateReport(makeTriangle())).toBe('object'); });
});

describe('compareGraphs', () => {
  it('same graph sameNodeCount true', () => { expect(compareGraphs(makeTriangle(), makeTriangle()).sameNodeCount).toBe(true); });
  it('same graph sameEdgeCount true', () => { expect(compareGraphs(makeTriangle(), makeTriangle()).sameEdgeCount).toBe(true); });
  it('different graphs differ', () => { expect(compareGraphs(makeTriangle(), makePath()).sameNodeCount).toBe(false); });
  it('has degreeDifference', () => { expect(typeof compareGraphs(makeTriangle(), makePath()).degreeDifference).toBe('number'); });
  it('same graph degreeDifference 0', () => { expect(compareGraphs(makeTriangle(), makeTriangle()).degreeDifference).toBe(0); });
});


