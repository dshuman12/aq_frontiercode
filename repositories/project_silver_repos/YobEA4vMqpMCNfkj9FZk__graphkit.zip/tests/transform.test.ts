import { Graph } from '../src/graph';
import { DiGraph } from '../src/digraph';
import { complement, lineGraph, cartesianProduct, tensorProduct, inducedSubgraph, graphUnion, graphIntersection, graphDifference, powerGraph, subdivide, toDiGraph, toUndirected } from '../src/transform';

function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makePath(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); return g; }
function makeK4(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('a','c'); g.addEdge('a','d'); g.addEdge('b','c'); g.addEdge('b','d'); g.addEdge('c','d'); return g; }

describe('complement', () => {
  it('complement of K4 has 0 edges', () => { expect(complement(makeK4()).edgeCount()).toBe(0); });
  it('complement of triangle has 0 edges', () => { expect(complement(makeTriangle()).edgeCount()).toBe(0); });
  it('complement of path has extra edges', () => { expect(complement(makePath()).edgeCount()).toBe(1); });
  it('node count preserved', () => { expect(complement(makeTriangle()).nodeCount()).toBe(3); });
  it('double complement equals original edge count', () => { expect(complement(complement(makeTriangle())).edgeCount()).toBe(makeTriangle().edgeCount()); });
  it('complement of empty has all edges', () => { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); expect(complement(g).edgeCount()).toBe(3); });
});

describe('lineGraph', () => {
  it('triangle line graph has 3 nodes', () => { expect(lineGraph(makeTriangle()).nodeCount()).toBe(3); });
  it('path line graph has 2 nodes', () => { expect(lineGraph(makePath()).nodeCount()).toBe(2); });
  it('line graph of empty has 0 nodes', () => { expect(lineGraph(new Graph()).nodeCount()).toBe(0); });
  it('returns Graph', () => { expect(lineGraph(makeTriangle()).nodeCount()).toBeGreaterThanOrEqual(0); });
});

describe('cartesianProduct', () => {
  it('node count is n1 * n2', () => { expect(cartesianProduct(makePath(), makeTriangle()).nodeCount()).toBe(9); });
  it('returns graph', () => { expect(cartesianProduct(makePath(), makePath()).edgeCount()).toBeGreaterThanOrEqual(0); });
  it('empty product', () => { expect(cartesianProduct(new Graph(), makeTriangle()).nodeCount()).toBe(0); });
  it('has correct edge count for paths', () => { const p = cartesianProduct(makePath(), makePath()); expect(p.edgeCount()).toBeGreaterThan(0); });
});

describe('inducedSubgraph', () => {
  it('subset nodes', () => { expect(inducedSubgraph(makeTriangle(), ['a','b']).nodeCount()).toBe(2); });
  it('preserves edges between subset', () => { expect(inducedSubgraph(makeTriangle(), ['a','b']).edgeCount()).toBe(1); });
  it('empty subset is empty', () => { expect(inducedSubgraph(makeTriangle(), []).nodeCount()).toBe(0); });
  it('full graph induced equals original', () => { expect(inducedSubgraph(makeTriangle(), ['a','b','c']).edgeCount()).toBe(3); });
  it('disjoint subset has 0 edges', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('c','d'); expect(inducedSubgraph(g, ['a','c']).edgeCount()).toBe(0); });
});

describe('graphUnion', () => {
  it('union has all nodes', () => { const g2 = new Graph(); ['x','y'].forEach(n=>g2.addNode(n)); g2.addEdge('x','y'); const u = graphUnion(makeTriangle(), g2); expect(u.nodeCount()).toBe(5); });
  it('union has all edges', () => { const g2 = new Graph(); ['x','y'].forEach(n=>g2.addNode(n)); g2.addEdge('x','y'); const u = graphUnion(makeTriangle(), g2); expect(u.edgeCount()).toBe(4); });
  it('union with empty equals original', () => { expect(graphUnion(makeTriangle(), new Graph()).edgeCount()).toBe(3); });
});

describe('graphIntersection', () => {
  it('intersection of identical equals original', () => { expect(graphIntersection(makeTriangle(), makeTriangle()).edgeCount()).toBe(3); });
  it('intersection with empty is empty', () => { expect(graphIntersection(makeTriangle(), new Graph()).nodeCount()).toBe(0); });
  it('intersection of disjoint is empty', () => { const g2 = new Graph(); ['x','y'].forEach(n=>g2.addNode(n)); g2.addEdge('x','y'); expect(graphIntersection(makeTriangle(), g2).edgeCount()).toBe(0); });
});

describe('graphDifference', () => {
  it('difference keeps all nodes', () => { expect(graphDifference(makeTriangle(), makeTriangle()).nodeCount()).toBe(3); });
  it('difference removes edges in g2', () => { const g2 = new Graph(); ['a','b','c'].forEach(n=>g2.addNode(n)); g2.addEdge('a','b'); const d = graphDifference(makeTriangle(), g2); expect(d.edgeCount()).toBe(2); });
  it('difference with empty equals original', () => { expect(graphDifference(makeTriangle(), new Graph()).edgeCount()).toBe(3); });
});

describe('powerGraph', () => {
  it('power 1 equals original edges', () => { expect(powerGraph(makePath(), 1).edgeCount()).toBe(makePath().edgeCount()); });
  it('power 2 adds shortcuts', () => { expect(powerGraph(makePath(), 2).edgeCount()).toBeGreaterThanOrEqual(makePath().edgeCount()); });
  it('node count unchanged', () => { expect(powerGraph(makePath(), 2).nodeCount()).toBe(3); });
});

describe('subdivide', () => {
  it('adds one node per edge', () => { expect(subdivide(makePath()).nodeCount()).toBe(3 + makePath().edgeCount()); });
  it('doubles edge count', () => { expect(subdivide(makePath()).edgeCount()).toBe(makePath().edgeCount() * 2); });
  it('empty graph unchanged', () => { expect(subdivide(new Graph()).nodeCount()).toBe(0); });
});

describe('toDiGraph and toUndirected', () => {
  it('toDiGraph doubles edges', () => { expect(toDiGraph(makeTriangle()).edgeCount()).toBe(6); });
  it('toUndirected halves edges', () => { const dg = toDiGraph(makeTriangle()); expect(toUndirected(dg).edgeCount()).toBe(3); });
  it('toDiGraph preserves nodes', () => { expect(toDiGraph(makeTriangle()).nodeCount()).toBe(3); });
  it('roundtrip preserves structure', () => { expect(toUndirected(toDiGraph(makePath())).edgeCount()).toBe(makePath().edgeCount()); });
});

describe('transform extended', () => {
  it('tensorProduct node count', () => { const g1 = new Graph(); ["a","b"].forEach(n=>g1.addNode(n)); g1.addEdge("a","b"); const g2 = new Graph(); ["x","y"].forEach(n=>g2.addNode(n)); g2.addEdge("x","y"); expect(tensorProduct(g1,g2).nodeCount()).toBe(4); });
  it('graphUnion combines edges', () => { const g1 = new Graph(); ["a","b"].forEach(n=>g1.addNode(n)); g1.addEdge("a","b"); const g2 = new Graph(); ["c","d"].forEach(n=>g2.addNode(n)); g2.addEdge("c","d"); expect(graphUnion(g1,g2).edgeCount()).toBe(2); });
})


