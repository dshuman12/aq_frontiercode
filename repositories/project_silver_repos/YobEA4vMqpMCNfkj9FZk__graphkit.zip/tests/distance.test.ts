import { Graph } from '../src/graph';
import { graphDistance, distanceMatrix, averagePathLength, hopDistance, wienerIndex, graphEditDistance, closenessCentrality, harmonicCentrality, peripheralNodes } from '../src/distance';

function makePath(): Graph { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); return g; }
function makeTriangle(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','a',1); return g; }
function makeStar(): Graph { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n); g.addEdge('hub',n,1);}); return g; }

describe('graphDistance', () => {
  it('distance to self is 0', () => { expect(graphDistance(makePath(), 'a', 'a')).toBe(0); });
  it('adjacent distance is 1', () => { expect(graphDistance(makePath(), 'a', 'b')).toBe(1); });
  it('path distance a to d is 3', () => { expect(graphDistance(makePath(), 'a', 'd')).toBe(3); });
  it('unreachable is Infinity', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(graphDistance(g, 'x', 'y')).toBe(Infinity); });
  it('symmetric for undirected', () => { expect(graphDistance(makePath(),'a','c')).toBe(graphDistance(makePath(),'c','a')); });
});

describe('distanceMatrix', () => {
  it('has nodes array', () => { expect(distanceMatrix(makePath()).nodes).toHaveLength(4); });
  it('matrix is n x n', () => { const d = distanceMatrix(makePath()); expect(d.matrix).toHaveLength(4); expect(d.matrix[0]).toHaveLength(4); });
  it('diagonal is 0', () => { const {matrix} = distanceMatrix(makePath()); for (let i=0;i<4;i++) expect(matrix[i][i]).toBe(0); });
  it('symmetric for undirected', () => { const {matrix} = distanceMatrix(makeTriangle()); expect(matrix[0][1]).toBe(matrix[1][0]); });
  it('off-diagonal >= 1', () => { const {matrix} = distanceMatrix(makePath()); for (let i=0;i<4;i++) for (let j=0;j<4;j++) if (i!==j) expect(matrix[i][j]).toBeGreaterThanOrEqual(1); });
});

describe('averagePathLength', () => {
  it('positive for connected graph', () => { expect(averagePathLength(makePath())).toBeGreaterThan(0); });
  it('triangle APL is 1', () => { expect(averagePathLength(makeTriangle())).toBeCloseTo(1); });
  it('single node is 0', () => { const g = new Graph(); g.addNode('x'); expect(averagePathLength(g)).toBe(0); });
  it('returns number', () => { expect(typeof averagePathLength(makeStar())).toBe('number'); });
  it('star APL < path APL', () => { expect(averagePathLength(makeStar())).toBeLessThan(averagePathLength(makePath())); });
});

describe('hopDistance', () => {
  it('self hop is 0', () => { expect(hopDistance(makePath(), 'a', 'a')).toBe(0); });
  it('adjacent hop is 1', () => { expect(hopDistance(makePath(), 'a', 'b')).toBe(1); });
  it('hop a to d is 3', () => { expect(hopDistance(makePath(), 'a', 'd')).toBe(3); });
  it('unreachable is Infinity', () => { const g = new Graph(); g.addNode('x'); g.addNode('y'); expect(hopDistance(g, 'x', 'y')).toBe(Infinity); });
});

describe('wienerIndex', () => {
  it('positive for connected', () => { expect(wienerIndex(makePath())).toBeGreaterThan(0); });
  it('triangle wiener is 3', () => { expect(wienerIndex(makeTriangle())).toBe(3); });
  it('returns number', () => { expect(typeof wienerIndex(makeStar())).toBe('number'); });
  it('empty graph is 0', () => { expect(wienerIndex(new Graph())).toBe(0); });
  it('single node is 0', () => { const g = new Graph(); g.addNode('x'); expect(wienerIndex(g)).toBe(0); });
});

describe('graphEditDistance', () => {
  it('identical graphs have 0 edit distance', () => { expect(graphEditDistance(makeTriangle(), makeTriangle())).toBe(0); });
  it('different graphs have positive distance', () => { expect(graphEditDistance(makeTriangle(), makePath())).toBeGreaterThan(0); });
  it('returns non-negative', () => { expect(graphEditDistance(makePath(), makeStar())).toBeGreaterThanOrEqual(0); });
  it('returns number', () => { expect(typeof graphEditDistance(makePath(), makeTriangle())).toBe('number'); });
  it('symmetric', () => { expect(graphEditDistance(makePath(), makeStar())).toBe(graphEditDistance(makeStar(), makePath())); });
});

describe('closenessCentrality (distance module)', () => {
  it('hub has high centrality in star', () => { const cc = closenessCentrality(makeStar()); expect(cc.get('hub')).toBeGreaterThan(cc.get('a')!); });
  it('all values non-negative', () => { for (const v of closenessCentrality(makePath()).values()) expect(v).toBeGreaterThanOrEqual(0); });
  it('returns Map', () => { expect(closenessCentrality(makePath()) instanceof Map).toBe(true); });
  it('all nodes have centrality', () => { const cc = closenessCentrality(makePath()); for (const n of makePath().nodeIds()) expect(cc.has(n)).toBe(true); });
});

describe('harmonicCentrality', () => {
  it('hub has high harmonic centrality', () => { const hc = harmonicCentrality(makeStar()); expect(hc.get('hub')).toBeGreaterThan(hc.get('a')!); });
  it('all non-negative', () => { for (const v of harmonicCentrality(makePath()).values()) expect(v).toBeGreaterThanOrEqual(0); });
  it('returns Map', () => { expect(harmonicCentrality(makePath()) instanceof Map).toBe(true); });
  it('single node is 0', () => { const g = new Graph(); g.addNode('x'); expect(harmonicCentrality(g).get('x')).toBe(0); });
});

describe('peripheralNodes', () => {
  it('path endpoints are peripheral', () => { const p = peripheralNodes(makePath()); expect(p.includes('a') || p.includes('d')).toBe(true); });
  it('returns array', () => { expect(Array.isArray(peripheralNodes(makePath()))).toBe(true); });
  it('empty graph returns empty', () => { expect(peripheralNodes(new Graph())).toHaveLength(0); });
  it('non-empty for connected', () => { expect(peripheralNodes(makePath()).length).toBeGreaterThan(0); });
});

describe('distance advanced', () => {
  it('wienerIndex of star 4-nodes is positive', () => { const g = new Graph(); g.addNode('hub'); ['a','b','c'].forEach(n=>{g.addNode(n);g.addEdge('hub',n,1);}); expect(wienerIndex(g)).toBeGreaterThan(0); });
  it('closenessCentrality returns all nodes', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); for (const n of g.nodeIds()) expect(closenessCentrality(g).has(n)).toBe(true); });
  it('graphEditDistance is 0 for same graph', () => { const g = new Graph(); ['a','b'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); expect(graphEditDistance(g,g)).toBe(0); });
  it('hopDistance equal to 1 for adjacent', () => { const g = new Graph(); g.addNode('a'); g.addNode('b'); g.addEdge('a','b',1); expect(hopDistance(g,'a','b')).toBe(1); });
  it('peripheralNodes returns array', () => { const g = new Graph(); ['a','b','c','d'].forEach(n=>g.addNode(n)); g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1); expect(Array.isArray(peripheralNodes(g))).toBe(true); });
})


