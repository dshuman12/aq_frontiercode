import { Graph } from '../src/graph';
import { DiGraph } from '../src/digraph';
import {
  longestPathDP, shortestPathDP, minimumVertexCover, maximumIndependentSetDP,
  minimumDominatingSet, approximateSteinerTree, tspNearestNeighbor,
  tspDynamicProgramming, knapsackOnGraph, graphColoringDP, weightedIndependentSet
} from '../src/dynamic';

function makeDAG(): DiGraph {
  const g = new DiGraph();
  ['a','b','c','d'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('a','c',2); g.addEdge('b','d',3); g.addEdge('c','d',1);
  return g;
}
function makeUndirected(): Graph {
  const g = new Graph();
  ['a','b','c','d'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('c','d',1);
  return g;
}
function makeComplete(): Graph {
  const g = new Graph();
  ['a','b','c'].forEach(n => g.addNode(n));
  g.addEdge('a','b',1); g.addEdge('b','c',1); g.addEdge('a','c',1);
  return g;
}

describe('longestPathDP', () => {
  it('returns non-negative value', () => {
    expect(longestPathDP(makeDAG(), 'a').value).toBeGreaterThanOrEqual(0);
  });
  it('path starts from source', () => {
    const r = longestPathDP(makeDAG(), 'a');
    expect(r.path[0]).toBe('a');
  });
  it('table contains all nodes', () => {
    const r = longestPathDP(makeDAG(), 'a');
    expect(r.table.size).toBe(4);
  });
  it('empty graph returns value 0', () => {
    expect(longestPathDP(new DiGraph(), 'a').value).toBe(0);
  });
  it('returns non-negative value from a to reachable node', () => {
    const r = longestPathDP(makeDAG(), 'a');
    expect(r.value).toBeGreaterThanOrEqual(0);
  });
});

describe('shortestPathDP', () => {
  it('returns finite value for reachable node', () => {
    const r = shortestPathDP(makeUndirected(), 'a');
    expect(r.value).toBeLessThan(Infinity);
  });
  it('path starts from source', () => {
    expect(shortestPathDP(makeUndirected(), 'a').path[0]).toBe('a');
  });
  it('table size equals node count', () => {
    const r = shortestPathDP(makeUndirected(), 'a');
    expect(r.table.size).toBe(4);
  });
  it('source distance is 0 in table', () => {
    const r = shortestPathDP(makeUndirected(), 'a');
    expect(r.table.get('a')).toBe(0);
  });
});

describe('minimumVertexCover', () => {
  it('cover is valid (covers all edges)', () => {
    const g = makeUndirected();
    const r = minimumVertexCover(g);
    for (const e of g.edges()) {
      expect(r.cover.includes(e.source) || r.cover.includes(e.target)).toBe(true);
    }
  });
  it('empty graph returns cover of size 0', () => {
    expect(minimumVertexCover(new Graph()).size).toBe(0);
  });
  it('cover size <= node count', () => {
    const r = minimumVertexCover(makeComplete());
    expect(r.size).toBeLessThanOrEqual(3);
  });
  it('triangle minimum cover has at least 2 nodes', () => {
    expect(minimumVertexCover(makeComplete()).size).toBeGreaterThanOrEqual(2);
  });
});

describe('maximumIndependentSetDP', () => {
  it('independent set is valid (no adjacent nodes)', () => {
    const g = makeUndirected();
    const r = maximumIndependentSetDP(g);
    const nodeSet = new Set(r.nodes);
    for (const u of r.nodes)
      for (const v of g.neighbors(u))
        expect(nodeSet.has(v)).toBe(false);
  });
  it('size is non-negative', () => {
    expect(maximumIndependentSetDP(makeUndirected()).size).toBeGreaterThanOrEqual(0);
  });
  it('empty graph returns empty set', () => {
    expect(maximumIndependentSetDP(new Graph()).size).toBe(0);
  });
  it('cover + independent set = all nodes', () => {
    const g = makeUndirected();
    const cover = new Set(minimumVertexCover(g).cover);
    const indep = new Set(maximumIndependentSetDP(g).nodes);
    const all = new Set(g.nodeIds());
    for (const n of all) expect(cover.has(n) || indep.has(n)).toBe(true);
  });
});

describe('minimumDominatingSet', () => {
  it('dominating set covers all nodes', () => {
    const g = makeUndirected();
    const r = minimumDominatingSet(g);
    const dominated = new Set(r.set);
    for (const n of r.set) for (const v of g.neighbors(n)) dominated.add(v);
    for (const n of g.nodeIds()) expect(dominated.has(n)).toBe(true);
  });
  it('empty graph returns empty set', () => {
    expect(minimumDominatingSet(new Graph()).size).toBe(0);
  });
  it('size is positive for non-empty graph', () => {
    expect(minimumDominatingSet(makeComplete()).size).toBeGreaterThan(0);
  });
});

describe('approximateSteinerTree', () => {
  it('returns tree connecting terminals', () => {
    const r = approximateSteinerTree(makeUndirected(), ['a', 'd']);
    expect(r.nodes.includes('a')).toBe(true);
  });
  it('empty terminals returns empty result', () => {
    expect(approximateSteinerTree(makeUndirected(), []).edges.length).toBe(0);
  });
  it('total weight is non-negative', () => {
    expect(approximateSteinerTree(makeUndirected(), ['a','c']).totalWeight).toBeGreaterThanOrEqual(0);
  });
  it('single terminal returns no edges', () => {
    expect(approximateSteinerTree(makeUndirected(), ['a']).edges.length).toBe(0);
  });
});

describe('tspNearestNeighbor', () => {
  it('tour visits all nodes', () => {
    const g = makeComplete();
    const r = tspNearestNeighbor(g);
    const unique = new Set(r.tour.slice(0, -1));
    expect(unique.size).toBe(3);
  });
  it('tour starts and ends at same node', () => {
    const r = tspNearestNeighbor(makeComplete());
    expect(r.tour[0]).toBe(r.tour[r.tour.length - 1]);
  });
  it('total weight is positive', () => {
    expect(tspNearestNeighbor(makeComplete()).totalWeight).toBeGreaterThan(0);
  });
  it('empty graph returns empty tour', () => {
    expect(tspNearestNeighbor(new Graph()).tour.length).toBe(0);
  });
});

describe('tspDynamicProgramming', () => {
  it('tour visits all nodes', () => {
    const r = tspDynamicProgramming(makeComplete());
    const unique = new Set(r.tour.slice(0, -1));
    expect(unique.size).toBe(3);
  });
  it('optimal flag is true for small graph', () => {
    expect(tspDynamicProgramming(makeComplete()).optimal).toBe(true);
  });
  it('total weight equals nearest neighbour for 3-node complete', () => {
    const g = makeComplete();
    const dp = tspDynamicProgramming(g);
    expect(dp.totalWeight).toBeGreaterThan(0);
  });
  it('empty graph returns empty tour', () => {
    expect(tspDynamicProgramming(new Graph()).tour.length).toBe(0);
  });
});

describe('knapsackOnGraph', () => {
  it('selects items within capacity', () => {
    const g = makeUndirected();
    const weights = new Map([['a',1],['b',2],['c',1],['d',3]]);
    const values = new Map([['a',4],['b',3],['c',2],['d',5]]);
    const r = knapsackOnGraph(g, weights, values, 4);
    const totalW = r.selected.reduce((s: number, n) => s + (weights.get(n as string) ?? 0), 0);
    expect(totalW).toBeLessThanOrEqual(4);
  });
  it('value is non-negative', () => {
    const g = makeUndirected();
    const w = new Map<string,number>([['a',1],['b',1],['c',1],['d',1]]);
    const v = new Map<string,number>([['a',1],['b',1],['c',1],['d',1]]);
    expect(knapsackOnGraph(g, w, v, 2).value).toBeGreaterThanOrEqual(0);
  });
  it('capacity 0 selects nothing', () => {
    const g = makeUndirected();
    const w = new Map<string,number>([['a',1],['b',1],['c',1],['d',1]]);
    const v = new Map<string,number>([['a',1],['b',1],['c',1],['d',1]]);
    expect(knapsackOnGraph(g, w, v, 0).selected.length).toBe(0);
  });
});

describe('graphColoringDP', () => {
  it('adjacent nodes have different colours', () => {
    const g = makeUndirected();
    const coloring = graphColoringDP(g);
    for (const e of g.edges())
      expect(coloring.get(e.source)).not.toBe(coloring.get(e.target));
  });
  it('all nodes are assigned a colour', () => {
    const g = makeUndirected();
    const coloring = graphColoringDP(g);
    for (const n of g.nodeIds()) expect(coloring.has(n)).toBe(true);
  });
  it('empty graph returns empty map', () => {
    expect(graphColoringDP(new Graph()).size).toBe(0);
  });
});

describe('weightedIndependentSet', () => {
  it('selected nodes form independent set', () => {
    const g = makeUndirected();
    const weights = new Map<string,number>([['a',3],['b',1],['c',3],['d',1]]);
    const r = weightedIndependentSet(g, weights);
    const nodeSet = new Set(r.nodes);
    for (const u of r.nodes)
      for (const v of g.neighbors(u))
        expect(nodeSet.has(v)).toBe(false);
  });
  it('value is positive', () => {
    const g = makeUndirected();
    const weights = new Map<string,number>([['a',1],['b',1],['c',1],['d',1]]);
    expect(weightedIndependentSet(g, weights).value).toBeGreaterThan(0);
  });
});

