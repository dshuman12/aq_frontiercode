import {
  createHypergraph, addHyperNode, addHyperedge, removeHyperNode,
  removeHyperedge, hyperdegree, hyperedgeSize, hyperNeighbors,
  hypergraphMetrics, toCliqueGraph, toStarGraph, buildIncidenceMatrix,
  dualHypergraph, hypergraphConnected, hypergraphComponents,
  hypergraphClustering, uniformHypergraph, hyperedgesContaining,
  edgeIntersection, edgeUnion, sunflowerCheck, hypergraphSpectralGap
} from '../src/hypergraph';

function makeHG() {
  const hg = createHypergraph();
  addHyperNode(hg, 'a'); addHyperNode(hg, 'b');
  addHyperNode(hg, 'c'); addHyperNode(hg, 'd');
  addHyperedge(hg, ['a','b','c'], 1, 'e1');
  addHyperedge(hg, ['b','c','d'], 1, 'e2');
  return hg;
}

describe('createHypergraph', () => {
  it('starts with no nodes', () => {
    expect(createHypergraph().nodes.size).toBe(0);
  });
  it('starts with no edges', () => {
    expect(createHypergraph().edges.size).toBe(0);
  });
  it('directed defaults to false', () => {
    expect(createHypergraph().directed).toBe(false);
  });
  it('can be created as directed', () => {
    expect(createHypergraph(true).directed).toBe(true);
  });
});

describe('addHyperNode', () => {
  it('adds a node', () => {
    const hg = createHypergraph();
    addHyperNode(hg, 'x');
    expect(hg.nodes.has('x')).toBe(true);
  });
  it('stores node data', () => {
    const hg = createHypergraph();
    addHyperNode(hg, 'x', { label: 'test' });
    expect(hg.nodes.get('x')?.label).toBe('test');
  });
});

describe('addHyperedge', () => {
  it('adds edge with correct nodes', () => {
    const hg = createHypergraph();
    const id = addHyperedge(hg, ['a','b','c'], 1);
    expect(hg.edges.get(id)?.nodes.has('a')).toBe(true);
  });
  it('implicitly adds nodes', () => {
    const hg = createHypergraph();
    addHyperedge(hg, ['x','y'], 1);
    expect(hg.nodes.has('x')).toBe(true);
  });
  it('returns the edge id', () => {
    const hg = createHypergraph();
    const id = addHyperedge(hg, ['a','b'], 1, 'myedge');
    expect(id).toBe('myedge');
  });
  it('uses custom id', () => {
    const hg = createHypergraph();
    addHyperedge(hg, ['a','b'], 1, 'e99');
    expect(hg.edges.has('e99')).toBe(true);
  });
});

describe('removeHyperNode', () => {
  it('removes the node', () => {
    const hg = makeHG();
    removeHyperNode(hg, 'a');
    expect(hg.nodes.has('a')).toBe(false);
  });
  it('removes node from edges', () => {
    const hg = makeHG();
    removeHyperNode(hg, 'a');
    expect(hg.edges.get('e1')?.nodes.has('a')).toBeFalsy();
  });
  it('removes empty edges', () => {
    const hg = createHypergraph();
    addHyperedge(hg, ['x'], 1, 'solo');
    removeHyperNode(hg, 'x');
    expect(hg.edges.has('solo')).toBe(false);
  });
});

describe('removeHyperedge', () => {
  it('removes the edge', () => {
    const hg = makeHG();
    removeHyperedge(hg, 'e1');
    expect(hg.edges.has('e1')).toBe(false);
  });
  it('nodes remain after edge removal', () => {
    const hg = makeHG();
    removeHyperedge(hg, 'e1');
    expect(hg.nodes.has('a')).toBe(true);
  });
});

describe('hyperdegree', () => {
  it('node a appears in 1 edge', () => {
    expect(hyperdegree(makeHG(), 'a')).toBe(1);
  });
  it('node b appears in 2 edges', () => {
    expect(hyperdegree(makeHG(), 'b')).toBe(2);
  });
  it('nonexistent node has degree 0', () => {
    expect(hyperdegree(makeHG(), 'z')).toBe(0);
  });
});

describe('hyperedgeSize', () => {
  it('e1 has size 3', () => {
    expect(hyperedgeSize(makeHG(), 'e1')).toBe(3);
  });
  it('nonexistent edge has size 0', () => {
    expect(hyperedgeSize(makeHG(), 'e99')).toBe(0);
  });
});

describe('hyperNeighbors', () => {
  it('a is neighbor of b via e1', () => {
    const nbrs = hyperNeighbors(makeHG(), 'a');
    expect(nbrs.has('b')).toBe(true);
  });
  it('a is not its own neighbor', () => {
    expect(hyperNeighbors(makeHG(), 'a').has('a')).toBe(false);
  });
  it('b has neighbors a, c, d', () => {
    const nbrs = hyperNeighbors(makeHG(), 'b');
    expect(nbrs.has('a')).toBe(true);
    expect(nbrs.has('c')).toBe(true);
    expect(nbrs.has('d')).toBe(true);
  });
});

describe('hypergraphMetrics', () => {
  it('nodeCount is 4', () => {
    expect(hypergraphMetrics(makeHG()).nodeCount).toBe(4);
  });
  it('edgeCount is 2', () => {
    expect(hypergraphMetrics(makeHG()).edgeCount).toBe(2);
  });
  it('avgEdgeSize is 3', () => {
    expect(hypergraphMetrics(makeHG()).avgEdgeSize).toBe(3);
  });
  it('maxEdgeSize is 3', () => {
    expect(hypergraphMetrics(makeHG()).maxEdgeSize).toBe(3);
  });
  it('density is non-negative', () => {
    expect(hypergraphMetrics(makeHG()).density).toBeGreaterThanOrEqual(0);
  });
  it('empty hypergraph has zero metrics', () => {
    const m = hypergraphMetrics(createHypergraph());
    expect(m.nodeCount).toBe(0);
    expect(m.edgeCount).toBe(0);
  });
});

describe('toCliqueGraph', () => {
  it('has correct node count', () => {
    expect(toCliqueGraph(makeHG()).nodeCount()).toBe(4);
  });
  it('a and b are connected', () => {
    const g = toCliqueGraph(makeHG());
    expect(g.hasEdge('a','b') || g.hasEdge('b','a')).toBe(true);
  });
  it('edge count is positive', () => {
    expect(toCliqueGraph(makeHG()).edgeCount()).toBeGreaterThan(0);
  });
});

describe('toStarGraph', () => {
  it('has hyperedge nodes + hyperedge ids as nodes', () => {
    const g = toStarGraph(makeHG());
    expect(g.nodeCount()).toBeGreaterThan(4);
  });
  it('edge nodes connect to hyperedge node', () => {
    const g = toStarGraph(makeHG());
    expect(g.hasEdge('e1','a') || g.hasEdge('a','e1')).toBe(true);
  });
});

describe('buildIncidenceMatrix', () => {
  it('matrix has correct dimensions', () => {
    const { matrix } = buildIncidenceMatrix(makeHG());
    expect(matrix.length).toBe(4);
    expect(matrix[0].length).toBe(2);
  });
  it('nodeIndex has all nodes', () => {
    expect(buildIncidenceMatrix(makeHG()).nodeIndex.size).toBe(4);
  });
  it('edgeIndex has all edges', () => {
    expect(buildIncidenceMatrix(makeHG()).edgeIndex.size).toBe(2);
  });
});

describe('dualHypergraph', () => {
  it('dual nodes correspond to original edges', () => {
    const dual = dualHypergraph(makeHG());
    expect(dual.nodes.has('e1')).toBe(true);
    expect(dual.nodes.has('e2')).toBe(true);
  });
  it('dual edges correspond to original nodes', () => {
    const dual = dualHypergraph(makeHG());
    expect(dual.edges.has('a')).toBe(true);
  });
});

describe('hypergraphConnected', () => {
  it('connected hypergraph returns true', () => {
    expect(hypergraphConnected(makeHG())).toBe(true);
  });
  it('empty hypergraph is connected', () => {
    expect(hypergraphConnected(createHypergraph())).toBe(true);
  });
  it('isolated node makes it disconnected', () => {
    const hg = makeHG();
    addHyperNode(hg, 'isolated');
    expect(hypergraphConnected(hg)).toBe(false);
  });
});

describe('hypergraphComponents', () => {
  it('connected graph has 1 component', () => {
    expect(hypergraphComponents(makeHG()).length).toBe(1);
  });
  it('components cover all nodes', () => {
    const comps = hypergraphComponents(makeHG());
    const total = comps.reduce((s, c) => s + c.length, 0);
    expect(total).toBe(4);
  });
  it('isolated node creates extra component', () => {
    const hg = makeHG();
    addHyperNode(hg, 'iso');
    expect(hypergraphComponents(hg).length).toBe(2);
  });
});

describe('uniformHypergraph', () => {
  it('all size-3 edges → uniform', () => {
    expect(uniformHypergraph(makeHG())).toBe(true);
  });
  it('mixed sizes → not uniform', () => {
    const hg = makeHG();
    addHyperedge(hg, ['a','b'], 1, 'e3');
    expect(uniformHypergraph(hg)).toBe(false);
  });
  it('empty hypergraph is uniform', () => {
    expect(uniformHypergraph(createHypergraph())).toBe(true);
  });
});

describe('hyperedgesContaining', () => {
  it('a is in 1 edge', () => {
    expect(hyperedgesContaining(makeHG(), 'a').length).toBe(1);
  });
  it('b is in 2 edges', () => {
    expect(hyperedgesContaining(makeHG(), 'b').length).toBe(2);
  });
  it('nonexistent node in 0 edges', () => {
    expect(hyperedgesContaining(makeHG(), 'z').length).toBe(0);
  });
});

describe('edgeIntersection', () => {
  it('e1 ∩ e2 = {b, c}', () => {
    const inter = edgeIntersection(makeHG(), 'e1', 'e2');
    expect(inter).toContain('b');
    expect(inter).toContain('c');
    expect(inter.length).toBe(2);
  });
});

describe('edgeUnion', () => {
  it('e1 ∪ e2 = {a, b, c, d}', () => {
    const u = edgeUnion(makeHG(), 'e1', 'e2');
    expect(u.length).toBe(4);
    expect(u).toContain('a');
    expect(u).toContain('d');
  });
});

describe('sunflowerCheck', () => {
  it('returns isSunflower and core', () => {
    const r = sunflowerCheck(makeHG());
    expect(typeof r.isSunflower).toBe('boolean');
    expect(Array.isArray(r.core)).toBe(true);
  });
  it('single edge is sunflower', () => {
    const hg = createHypergraph();
    addHyperedge(hg, ['a','b'], 1, 'e1');
    expect(sunflowerCheck(hg).isSunflower).toBe(true);
  });
});

describe('hypergraphSpectralGap', () => {
  it('returns non-negative value', () => {
    expect(hypergraphSpectralGap(makeHG())).toBeGreaterThanOrEqual(0);
  });
  it('empty hypergraph returns 0', () => {
    expect(hypergraphSpectralGap(createHypergraph())).toBe(0);
  });
  it('single node returns 0', () => {
    const hg = createHypergraph();
    addHyperNode(hg, 'x');
    expect(hypergraphSpectralGap(hg)).toBe(0);
  });
});

