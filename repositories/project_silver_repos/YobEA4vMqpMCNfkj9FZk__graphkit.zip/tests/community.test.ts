import { Graph } from '../src/graph';
import { louvain, girvanNewman, infomap, communityQuality } from '../src/community';

function makeTwoClusters(): Graph {
  const g = new Graph();
  ['a','b','c','x','y','z'].forEach(n => g.addNode(n));
  g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('a','c');
  g.addEdge('x','y'); g.addEdge('y','z'); g.addEdge('x','z');
  g.addEdge('c','x');
  return g;
}
function makeSmall(): Graph { const g = new Graph(); ['a','b','c'].forEach(n=>g.addNode(n)); g.addEdge('a','b'); g.addEdge('b','c'); g.addEdge('c','a'); return g; }

describe('louvain', () => {
  it('covers all nodes', () => { const r = louvain(makeTwoClusters()); const total = r.communities.reduce((s,c)=>s+c.length,0); expect(total).toBe(6); });
  it('has communities array', () => { expect(Array.isArray(louvain(makeTwoClusters()).communities)).toBe(true); });
  it('has nodeToComm map', () => { expect(louvain(makeTwoClusters()).nodeToComm instanceof Map).toBe(true); });
  it('no node twice', () => { const all = louvain(makeTwoClusters()).communities.flat(); expect(new Set(all).size).toBe(all.length); });
  it('modularity is number', () => { expect(typeof louvain(makeTwoClusters()).modularity).toBe('number'); });
  it('works on triangle', () => { const r = louvain(makeSmall()); const total = r.communities.flat().length; expect(total).toBe(3); });
  it('single node graph', () => { const g = new Graph(); g.addNode('x'); expect(louvain(g).communities).toHaveLength(1); });
});

describe('girvanNewman', () => {
  it('covers all nodes', () => { const r = girvanNewman(makeTwoClusters(),2); const total = r.communities.reduce((s,c)=>s+c.length,0); expect(total).toBe(6); });
  it('has communities array', () => { expect(Array.isArray(girvanNewman(makeTwoClusters(),2).communities)).toBe(true); });
  it('has >= target communities', () => { expect(girvanNewman(makeTwoClusters(),2).communities.length).toBeGreaterThanOrEqual(2); });
  it('modularity is number', () => { expect(typeof girvanNewman(makeTwoClusters(),2).modularity).toBe('number'); });
  it('all community members are strings', () => { for (const c of girvanNewman(makeSmall(),2).communities) for (const n of c) expect(typeof n).toBe('string'); });
});

describe('infomap', () => {
  it('covers all nodes', () => { const r = infomap(makeTwoClusters()); const total = r.communities.reduce((s,c)=>s+c.length,0); expect(total).toBe(6); });
  it('has communities array', () => { expect(Array.isArray(infomap(makeTwoClusters()).communities)).toBe(true); });
  it('no node twice', () => { const all = infomap(makeTwoClusters()).communities.flat(); expect(new Set(all).size).toBe(all.length); });
  it('modularity is number', () => { expect(typeof infomap(makeTwoClusters()).modularity).toBe('number'); });
});

describe('communityQuality', () => {
  it('has coverage', () => { expect(communityQuality(makeTwoClusters(),[['a','b','c'],['x','y','z']])).toHaveProperty('coverage'); });
  it('has conductance', () => { expect(communityQuality(makeTwoClusters(),[['a','b','c'],['x','y','z']])).toHaveProperty('conductance'); });
  it('coverage in [0,1]', () => { const q = communityQuality(makeTwoClusters(),[['a','b','c'],['x','y','z']]); expect(q.coverage).toBeGreaterThanOrEqual(0); expect(q.coverage).toBeLessThanOrEqual(1); });
  it('conductance is array', () => { const q = communityQuality(makeTwoClusters(),[['a','b','c'],['x','y','z']]); expect(Array.isArray(q.conductance)).toBe(true); });
});


