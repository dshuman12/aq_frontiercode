# graphkit-ts

A comprehensive TypeScript library of graph data structures and algorithms.

## Features

- **Core Structures** – `Graph` (undirected) and `DiGraph` (directed)
- **Traversal** – BFS, DFS, iterative DFS, bidirectional BFS, level BFS
- **Shortest Paths** – Dijkstra, Bellman-Ford, Floyd-Warshall, A*
- **Minimum Spanning Tree** – Kruskal, Prim, Borůvka
- **Connected Components** – SCC, articulation points, bridges, bipartite check
- **Graph Coloring** – greedy, DSatur, backtracking, 2-coloring
- **Centrality & Metrics** – degree, closeness, betweenness, clustering coefficient, PageRank
- **Network Analysis** – robustness, percolation, small-world coefficient, algebraic connectivity, efficiency
- **Distance Metrics** – Wiener index, resistance distance, harmonic centrality, graph edit distance
- **Matching** – maximum matching, maximum weight matching, stable matching, edge cover
- **Flow** – Ford-Fulkerson max flow, min cut, bipartite matching
- **Clique / Independent Set** – Bron-Kerbosch, max clique, vertex cover, independence number
- **Community Detection** – Louvain, Girvan-Newman, Infomap, label propagation
- **Graph Partitioning** – Kernighan-Lin, spectral, modularity
- **Clustering** – single/complete/average linkage, k-medoids, silhouette score
- **Topology** – spanning trees, tree-width, path-width, chordal completion
- **Graph Transforms** – complement, line graph, Cartesian/tensor product, induced subgraph, union, intersection
- **Algorithms** – DFS/BFS trees, IDDFS, k-core decomposition, longest path, topological levels
- **Random Walks** – stationary distribution, hitting time, commute time, cover time
- **Matrix** – adjacency, Laplacian, incidence, spectral radius, matrix power
- **Graph Generation** – complete, path, cycle, star, grid, Petersen, Barabási-Albert, random DAG
- **Serialization** – JSON, DOT, adjacency list, edge list
- **Visualization** – circular/hierarchical/force-directed layouts, ASCII render, Mermaid, Graphviz DOT
- **Utilities** – combinatorics, set operations, memoization, timer

## Installation

```bash
npm install
```

## Usage

```typescript
import { Graph, dijkstra, kruskal, pageRank } from './src';

const g = new Graph();
g.addNode('a'); g.addNode('b'); g.addNode('c');
g.addEdge('a', 'b', 4);
g.addEdge('b', 'c', 2);
g.addEdge('a', 'c', 7);

const result = dijkstra(g, 'a');
console.log(result.distances); // Map { a: 0, b: 4, c: 6 }

const mst = kruskal(g);
console.log(mst.totalWeight); // 6
```

## Running Tests

```bash
npm test
# or without coverage
npx jest --no-coverage
```

## Building

```bash
npm run build
```

## Docker

```bash
docker build -t graphkit-ts .
docker run graphkit-ts npm test
```

## Stats

- **30 source modules** · ~4000 source lines
- **27 test suites** · 1014 tests · 100% passing
- **6000 total lines** of TypeScript

## License

MIT


