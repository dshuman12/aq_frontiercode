import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { kruskal } from './mst';
import { isConnected } from './components';

export interface SpanningTree {
  tree: Graph;
  weight: number;
  edgeCount: number;
}

export interface TreeDecomposition {
  bags: Map<number, NodeId[]>;
  treeEdges: [number, number][];
  treeWidth: number;
}

export function spanningTree(g: Graph): SpanningTree {
  try {
    const mst = kruskal(g);
    const tree = new Graph();
    for (const n of g.nodes()) tree.addNode(n.id, n.data, n.label);
    for (const e of mst.edges) tree.addEdge(e.source, e.target, e.weight);
    return { tree, weight: mst.totalWeight, edgeCount: mst.edgeCount };
  } catch {
    const tree = new Graph();
    for (const n of g.nodes()) tree.addNode(n.id, n.data, n.label);
    return { tree, weight: 0, edgeCount: 0 };
  }
}

export function randomSpanningTree(g: Graph, seed = 42): SpanningTree {
  const ids = g.nodeIds();
  if (ids.length === 0) return { tree: new Graph(), weight: 0, edgeCount: 0 };
  const tree = new Graph();
  for (const n of g.nodes()) tree.addNode(n.id, n.data, n.label);
  const inTree = new Set<NodeId>([ids[0]]);
  let totalWeight = 0;
  let rng = seed;
  const rand = () => { rng = (rng * 1664525 + 1013904223) & 0xffffffff; return Math.abs(rng) / 0x80000000; };
  while (inTree.size < ids.length) {
    const candidates: Array<{ u: NodeId; v: NodeId; w: number }> = [];
    for (const u of inTree) {
      for (const e of g.edges()) {
        if ((e.source === u && !inTree.has(e.target)) || (e.target === u && !inTree.has(e.source))) {
          const v = e.source === u ? e.target : e.source;
          candidates.push({ u, v, w: typeof e.weight === 'number' ? e.weight : 1 });
        }
      }
    }
    if (candidates.length === 0) break;
    const chosen = candidates[Math.floor(rand() * candidates.length)];
    tree.addEdge(chosen.u, chosen.v, chosen.w);
    inTree.add(chosen.v);
    totalWeight += chosen.w;
  }
  return { tree, weight: totalWeight, edgeCount: tree.edgeCount() };
}

export function countSpanningTrees(g: Graph): number {
  const n = g.nodeCount();
  if (n === 0) return 0;
  if (n === 1) return 1;
  if (!isConnected(g)) return 0;
  const ids = g.nodeIds();
  const idx = new Map<NodeId, number>(ids.map((id, i) => [id, i]));
  const L: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (const id of ids) {
    const i = idx.get(id)!;
    L[i][i] = g.degree(id);
    for (const nb of g.neighbors(id)) { const j = idx.get(nb)!; L[i][j] = -1; }
  }
  const size = n - 1;
  const M: number[][] = Array.from({ length: size }, (_, i) => Array.from({ length: size }, (__, j) => L[i][j]));
  let det = 1;
  for (let col = 0; col < size; col++) {
    let pivot = -1;
    for (let row = col; row < size; row++) { if (Math.abs(M[row][col]) > 1e-10) { pivot = row; break; } }
    if (pivot === -1) return 0;
    if (pivot !== col) { [M[col], M[pivot]] = [M[pivot], M[col]]; det *= -1; }
    det *= M[col][col];
    for (let row = col + 1; row < size; row++) {
      const factor = M[row][col] / M[col][col];
      for (let k = col; k < size; k++) M[row][k] -= factor * M[col][k];
    }
  }
  return Math.round(Math.abs(det));
}

export function isSpanningTree(g: Graph, tree: Graph): boolean {
  if (tree.nodeCount() !== g.nodeCount()) return false;
  if (tree.edgeCount() !== g.nodeCount() - 1) return false;
  for (const e of tree.edges()) if (!g.hasEdge(e.source, e.target)) return false;
  return isConnected(tree);
}

export function greedyTreeDecomp(g: Graph): TreeDecomposition {
  const ids = g.nodeIds();
  const bags = new Map<number, NodeId[]>();
  const treeEdges: [number, number][] = [];
  let bagId = 0;
  let maxBagSize = 0;
  const remaining = new Set(ids);
  const processed = new Map<NodeId, number>();
  const queue = [...ids];
  while (queue.length > 0) {
    const v = queue.shift()!;
    if (!remaining.has(v)) continue;
    remaining.delete(v);
    const nbrs = g.neighbors(v).filter(n => remaining.has(n));
    const bag = [v, ...nbrs];
    bags.set(bagId, bag);
    if (bag.length > maxBagSize) maxBagSize = bag.length;
    for (const [prev, prevBagId] of processed) {
      if (bag.includes(prev)) { treeEdges.push([prevBagId, bagId]); break; }
    }
    processed.set(v, bagId);
    bagId++;
  }
  return { bags, treeEdges, treeWidth: Math.max(0, maxBagSize - 1) };
}

export function treeWidth(g: Graph): number {
  return greedyTreeDecomp(g).treeWidth;
}

export function pathWidth(g: Graph): number {
  const n = g.nodeCount();
  if (n === 0) return 0;
  let bestWidth = n;
  const ids = g.nodeIds();
  const check = (order: NodeId[]) => {
    let maxBag = 0;
    for (let i = 0; i < order.length; i++) {
      const future = new Set(order.slice(i));
      let bag = 1;
      for (const nb of g.neighbors(order[i])) if (future.has(nb)) bag++;
      if (bag > maxBag) maxBag = bag;
    }
    return maxBag - 1;
  };
  for (let start = 0; start < Math.min(ids.length, 5); start++) {
    const order: NodeId[] = [];
    const visited = new Set<NodeId>();
    const queue: NodeId[] = [ids[start]];
    while (queue.length > 0) {
      const v = queue.shift()!;
      if (visited.has(v)) continue;
      visited.add(v);
      order.push(v);
      for (const nb of g.neighbors(v)) if (!visited.has(nb)) queue.push(nb);
    }
    for (const id of ids) if (!visited.has(id)) order.push(id);
    const w = check(order);
    if (w < bestWidth) bestWidth = w;
  }
  return bestWidth;
}

export function isChordal(g: Graph): boolean {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n < 4) return true;
  const adj = new Map<NodeId, Set<NodeId>>();
  for (const id of ids) adj.set(id, new Set(g.neighbors(id)));
  const eliminated = new Set<NodeId>();
  for (let step = 0; step < n; step++) {
    let bestV: NodeId | null = null;
    let bestFill = Infinity;
    for (const v of ids) {
      if (eliminated.has(v)) continue;
      const nbrs = [...(adj.get(v) ?? [])].filter(x => !eliminated.has(x));
      let fill = 0;
      for (let i = 0; i < nbrs.length; i++) for (let j = i + 1; j < nbrs.length; j++) if (!(adj.get(nbrs[i])?.has(nbrs[j]))) fill++;
      if (fill < bestFill) { bestFill = fill; bestV = v; }
    }
    if (bestV === null) break;
    if (bestFill > 0) return false;
    eliminated.add(bestV);
  }
  return true;
}

export function chordalCompletion(g: Graph): Graph {
  const result = g.clone();
  const ids = g.nodeIds();
  const n = ids.length;
  const adj = new Map<NodeId, Set<NodeId>>();
  for (const id of ids) adj.set(id, new Set(g.neighbors(id)));
  const eliminated = new Set<NodeId>();
  for (let step = 0; step < n; step++) {
    let bestV: NodeId | null = null;
    let bestFill = Infinity;
    for (const v of ids) {
      if (eliminated.has(v)) continue;
      const nbrs = [...(adj.get(v) ?? [])].filter(x => !eliminated.has(x));
      let fill = 0;
      for (let i = 0; i < nbrs.length; i++) for (let j = i + 1; j < nbrs.length; j++) if (!(adj.get(nbrs[i])?.has(nbrs[j]))) fill++;
      if (fill < bestFill) { bestFill = fill; bestV = v; }
    }
    if (bestV === null) break;
    const nbrs = [...(adj.get(bestV) ?? [])].filter(x => !eliminated.has(x));
    for (let i = 0; i < nbrs.length; i++) {
      for (let j = i + 1; j < nbrs.length; j++) {
        if (!(adj.get(nbrs[i])?.has(nbrs[j]))) {
          adj.get(nbrs[i])!.add(nbrs[j]);
          adj.get(nbrs[j])!.add(nbrs[i]);
          if (!result.hasEdge(nbrs[i], nbrs[j])) result.addEdge(nbrs[i], nbrs[j], 1);
        }
      }
    }
    eliminated.add(bestV);
  }
  return result;
}


