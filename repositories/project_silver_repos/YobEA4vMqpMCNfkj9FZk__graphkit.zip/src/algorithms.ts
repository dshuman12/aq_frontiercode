import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { bfs, dfs } from './traversal';
import { dijkstra } from './shortest_path';

export interface DFSTree {
  preorder: NodeId[];
  postorder: NodeId[];
  parent: Map<NodeId, NodeId | null>;
  depth: Map<NodeId, number>;
  treeEdges: [NodeId, NodeId][];
  backEdges: [NodeId, NodeId][];
  forwardEdges: [NodeId, NodeId][];
  crossEdges: [NodeId, NodeId][];
}

export interface BFSTree {
  order: NodeId[];
  parent: Map<NodeId, NodeId | null>;
  depth: Map<NodeId, number>;
  treeEdges: [NodeId, NodeId][];
  nonTreeEdges: [NodeId, NodeId][];
}

export function dfsTree(g: Graph, start: NodeId): DFSTree {
  const preorder: NodeId[] = [];
  const postorder: NodeId[] = [];
  const parent = new Map<NodeId, NodeId | null>([[start, null]]);
  const depth = new Map<NodeId, number>([[start, 0]]);
  const treeEdges: [NodeId, NodeId][] = [];
  const backEdges: [NodeId, NodeId][] = [];
  const forwardEdges: [NodeId, NodeId][] = [];
  const crossEdges: [NodeId, NodeId][] = [];
  const color = new Map<NodeId, 'white'|'gray'|'black'>();
  for (const id of g.nodeIds()) color.set(id, 'white');
  const visit = (u: NodeId) => {
    color.set(u, 'gray');
    preorder.push(u);
    for (const v of g.neighbors(u)) {
      const c = color.get(v) ?? 'white';
      if (c === 'white') { parent.set(v, u); depth.set(v, (depth.get(u)??0)+1); treeEdges.push([u, v]); visit(v); }
      else if (c === 'gray') backEdges.push([u, v]);
      else if ((depth.get(u)??0) < (depth.get(v)??0)) forwardEdges.push([u, v]);
      else crossEdges.push([u, v]);
    }
    color.set(u, 'black');
    postorder.push(u);
  };
  visit(start);
  return { preorder, postorder, parent, depth, treeEdges, backEdges, forwardEdges, crossEdges };
}

export function bfsTree(g: Graph, start: NodeId): BFSTree {
  const order: NodeId[] = [];
  const parent = new Map<NodeId, NodeId | null>([[start, null]]);
  const depth = new Map<NodeId, number>([[start, 0]]);
  const treeEdges: [NodeId, NodeId][] = [];
  const nonTreeEdges: [NodeId, NodeId][] = [];
  const visited = new Set<NodeId>([start]);
  const queue: NodeId[] = [start];
  while (queue.length > 0) {
    const u = queue.shift()!;
    order.push(u);
    for (const v of g.neighbors(u)) {
      if (!visited.has(v)) {
        visited.add(v);
        parent.set(v, u);
        depth.set(v, (depth.get(u) ?? 0) + 1);
        treeEdges.push([u, v]);
        queue.push(v);
      } else if (v !== parent.get(u)) {
        nonTreeEdges.push([u, v]);
      }
    }
  }
  return { order, parent, depth, treeEdges, nonTreeEdges };
}

export function iterativeDFS(g: Graph, start: NodeId): NodeId[] {
  const visited: NodeId[] = [];
  const seen = new Set<NodeId>();
  const stack: NodeId[] = [start];
  while (stack.length > 0) {
    const u = stack.pop()!;
    if (seen.has(u)) continue;
    seen.add(u);
    visited.push(u);
    const nbrs = [...g.neighbors(u)].reverse();
    for (const v of nbrs) if (!seen.has(v)) stack.push(v);
  }
  return visited;
}

export function iddfs(g: Graph, start: NodeId, goal: NodeId, maxDepth = 20): NodeId[] | null {
  for (let depth = 0; depth <= maxDepth; depth++) {
    const path = dls(g, start, goal, depth);
    if (path !== null) return path;
  }
  return null;
}

function dls(g: Graph, current: NodeId, goal: NodeId, depth: number, path: NodeId[] = [], visited = new Set<NodeId>()): NodeId[] | null {
  if (current === goal) return [...path, current];
  if (depth === 0) return null;
  visited.add(current);
  for (const nb of g.neighbors(current)) {
    if (!visited.has(nb)) {
      const result = dls(g, nb, goal, depth - 1, [...path, current], new Set(visited));
      if (result !== null) return result;
    }
  }
  return null;
}

export function greedyBestFirst(g: Graph, start: NodeId, goal: NodeId, h: (n: NodeId) => number): NodeId[] {
  const visited = new Set<NodeId>();
  const parent = new Map<NodeId, NodeId | null>([[start, null]]);
  const pq: Array<[number, NodeId]> = [[h(start), start]];
  while (pq.length > 0) {
    pq.sort((a, b) => a[0] - b[0]);
    const [, u] = pq.shift()!;
    if (visited.has(u)) continue;
    visited.add(u);
    if (u === goal) {
      const path: NodeId[] = [];
      let cur: NodeId | null = goal;
      while (cur !== null) { path.unshift(cur); cur = parent.get(cur) ?? null; }
      return path;
    }
    for (const v of g.neighbors(u)) {
      if (!visited.has(v)) { parent.set(v, u); pq.push([h(v), v]); }
    }
  }
  return [];
}

export function topologicalLevels(g: DiGraph): NodeId[][] {
  const inDeg = new Map<NodeId, number>();
  for (const id of g.nodeIds()) inDeg.set(id, g.inDegree(id));
  const levels: NodeId[][] = [];
  let current = g.nodeIds().filter(id => (inDeg.get(id) ?? 0) === 0);
  while (current.length > 0) {
    levels.push([...current]);
    const next: NodeId[] = [];
    for (const u of current) {
      for (const v of g.successors(u)) {
        inDeg.set(v, (inDeg.get(v) ?? 1) - 1);
        if (inDeg.get(v) === 0) next.push(v);
      }
    }
    current = next;
  }
  return levels;
}

export function longestPath(g: DiGraph): NodeId[] {
  if (!g.isDAG()) return [];
  const dist = new Map<NodeId, number>();
  const prev = new Map<NodeId, NodeId | null>();
  for (const id of g.nodeIds()) { dist.set(id, 0); prev.set(id, null); }
  for (const u of g.topoSort()) {
    for (const v of g.successors(u)) {
      if ((dist.get(u) ?? 0) + 1 > (dist.get(v) ?? 0)) {
        dist.set(v, (dist.get(u) ?? 0) + 1);
        prev.set(v, u);
      }
    }
  }
  let end = [...dist.entries()].reduce((a, b) => b[1] > a[1] ? b : a, [g.nodeIds()[0], 0] as [NodeId, number])[0];
  const path: NodeId[] = [];
  let cur: NodeId | null = end;
  while (cur !== null) { path.unshift(cur); cur = prev.get(cur) ?? null; }
  return path;
}

export function criticalPath(g: DiGraph): { path: NodeId[]; length: number } {
  const path = longestPath(g);
  return { path, length: path.length - 1 };
}

export function hasCycle(g: Graph): boolean {
  const visited = new Set<NodeId>();
  const recStack = new Set<NodeId>();
  const dfsVisit = (u: NodeId): boolean => {
    visited.add(u); recStack.add(u);
    for (const v of g.neighbors(u)) {
      if (!visited.has(v) && dfsVisit(v)) return true;
      if (recStack.has(v)) return true;
    }
    recStack.delete(u);
    return false;
  };
  for (const id of g.nodeIds()) if (!visited.has(id) && dfsVisit(id)) return true;
  return false;
}

export function countPaths(g: Graph, source: NodeId, target: NodeId, maxDepth = 20): number {
  let count = 0;
  const visit = (u: NodeId, visited: Set<NodeId>, d: number) => {
    if (u === target && visited.size > 1) { count++; return; }
    if (d >= maxDepth) return;
    for (const v of g.neighbors(u)) if (!visited.has(v)) { visited.add(v); visit(v, visited, d+1); visited.delete(v); }
  };
  const vs = new Set([source]);
  visit(source, vs, 0);
  return count;
}

export function graphCenter(g: Graph): NodeId[] {
  if (g.nodeCount() === 0) return [];
  const ecc = new Map<NodeId, number>();
  for (const id of g.nodeIds()) {
    const res = dijkstra(g, id);
    let e = 0;
    for (const d of res.distances.values()) if (d < Infinity && d > e) e = d;
    ecc.set(id, e);
  }
  const minEcc = Math.min(...ecc.values());
  return g.nodeIds().filter(id => ecc.get(id) === minEcc);
}

export function periphery(g: Graph): NodeId[] {
  if (g.nodeCount() === 0) return [];
  const ecc = new Map<NodeId, number>();
  for (const id of g.nodeIds()) {
    const res = dijkstra(g, id);
    let e = 0;
    for (const d of res.distances.values()) if (d < Infinity && d > e) e = d;
    ecc.set(id, e);
  }
  const maxEcc = Math.max(...ecc.values());
  return g.nodeIds().filter(id => ecc.get(id) === maxEcc);
}

export function kCoreDecomposition(g: Graph): Map<NodeId, number> {
  const degree = new Map<NodeId, number>();
  for (const id of g.nodeIds()) degree.set(id, g.degree(id));
  const coreNumber = new Map<NodeId, number>();
  let k = 0;
  const remaining = new Set(g.nodeIds());
  while (remaining.size > 0) {
    let changed = true;
    while (changed) {
      changed = false;
      for (const v of remaining) {
        const d = [...g.neighbors(v)].filter(n => remaining.has(n)).length;
        if (d <= k) { coreNumber.set(v, k); remaining.delete(v); changed = true; }
      }
    }
    k++;
  }
  for (const v of g.nodeIds()) if (!coreNumber.has(v)) coreNumber.set(v, k - 1);
  return coreNumber;
}

export function kCore(g: Graph, k: number): Graph {
  const coreNum = kCoreDecomposition(g);
  const sub = new Graph();
  for (const n of g.nodes()) if ((coreNum.get(n.id) ?? 0) >= k) sub.addNode(n.id, n.data, n.label);
  for (const e of g.edges()) if (sub.hasNode(e.source) && sub.hasNode(e.target)) sub.addEdge(e.source, e.target, e.weight);
  return sub;
}


