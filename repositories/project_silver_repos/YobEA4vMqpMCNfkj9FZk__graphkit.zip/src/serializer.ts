import { Graph } from './graph';
import { DiGraph } from './digraph';
import { SerializedGraph, NodeId } from './types';

type AnyGraph = Graph | DiGraph;

export function toJSON(g: AnyGraph): SerializedGraph {
  return { type: g instanceof DiGraph ? 'digraph' : 'graph', directed: g instanceof DiGraph, nodes: g.nodes().map(n => ({ ...n })), edges: g.edges().map(e => ({ ...e })), metadata: { nodeCount: g.nodeCount(), edgeCount: g.edgeCount() } };
}

export function fromJSON(data: SerializedGraph): Graph | DiGraph {
  const g = data.directed ? new DiGraph() : new Graph();
  for (const node of data.nodes) g.addNode(node.id, node.data, node.label, node.attributes);
  for (const edge of data.edges) {
    (g as any)._edges.set(edge.id, { ...edge });
    (g as any)._addAdj(edge.source, edge.target, edge.id);
    if (!data.directed) (g as any)._addAdj(edge.target, edge.source, edge.id);
    if (data.directed) (g as any)._addInAdj?.(edge.target, edge.source, edge.id);
    const num = parseInt(edge.id.slice(1), 10); if (!isNaN(num)) (g as any)._edgeCounter = Math.max((g as any)._edgeCounter, num);
  }
  return g;
}

export function toDOT(g: AnyGraph, name = 'G'): string {
  const dir = g instanceof DiGraph; const kw = dir ? 'digraph' : 'graph'; const arr = dir ? '->' : '--';
  const lines: string[] = [`${kw} ${name} {`];
  for (const n of g.nodes()) { const a = n.label ? ` [label="${n.label}"]` : ''; lines.push(`  "${n.id}"${a};`); }
  const seen = new Set<string>();
  for (const e of g.edges()) {
    if (!dir) { const k = [e.source, e.target].sort().join('--'); if (seen.has(k)) continue; seen.add(k); }
    const attrs: string[] = []; if (typeof e.weight === 'number' && e.weight !== 1) attrs.push(`weight=${e.weight}`); if (e.label) attrs.push(`label="${e.label}"`);
    lines.push(`  "${e.source}" ${arr} "${e.target}"${attrs.length ? ` [${attrs.join(', ')}]` : ''};`);
  }
  lines.push('}'); return lines.join('\n');
}

export function fromDOT(dot: string): Graph | DiGraph {
  const directed = /^\s*digraph/.test(dot); const g = directed ? new DiGraph({ allowMultiEdges: true }) : new Graph({ allowMultiEdges: true });
  const edgeRe = /^\s*"?([^"\s\->]+)"?\s*(->>?|--)\s*"?([^"\s\[\];]+)"?\s*(\[[^\]]*\])?\s*;/gm;
  let m: RegExpExecArray | null;
  while ((m = edgeRe.exec(dot)) !== null) {
    const [, src, , tgt, attrs] = m; g.addNodeIfAbsent(src); g.addNodeIfAbsent(tgt);
    let w = 1; if (attrs) { const wm = /weight\s*=\s*([0-9.]+)/.exec(attrs); if (wm) w = parseFloat(wm[1]); }
    g.addEdge(src, tgt, w as any);
  }
  return g;
}

export function toAdjacencyList(g: AnyGraph): Record<string, string[]> {
  const r: Record<string, string[]> = {};
  for (const id of g.nodeIds()) r[String(id)] = (g instanceof DiGraph ? g.successors(id) : g.neighbors(id)).map(String);
  return r;
}

export function fromAdjacencyList(adj: Record<string, string[]>, directed = false): Graph | DiGraph {
  const g = directed ? new DiGraph({ allowMultiEdges: true }) : new Graph({ allowMultiEdges: true });
  for (const id of Object.keys(adj)) g.addNodeIfAbsent(id);
  for (const [src, targets] of Object.entries(adj)) for (const tgt of targets) { g.addNodeIfAbsent(tgt); if (!directed && g.hasEdge(src, tgt)) continue; g.addEdge(src, tgt); }
  return g;
}

export function toEdgeList(g: AnyGraph): [string, string, number][] {
  const seen = new Set<string>(); const result: [string, string, number][] = [];
  for (const e of g.edges()) { const k = g instanceof DiGraph ? `${e.source}->${e.target}` : [e.source, e.target].sort().join('--'); if (!seen.has(k)) { seen.add(k); result.push([String(e.source), String(e.target), typeof e.weight === 'number' ? e.weight : 1]); } }
  return result;
}

export function fromEdgeList(edges: [string, string, number][], directed = false): Graph | DiGraph {
  const g = directed ? new DiGraph({ allowMultiEdges: true }) : new Graph({ allowMultiEdges: true });
  for (const [s, t, w] of edges) { g.addNodeIfAbsent(s); g.addNodeIfAbsent(t); g.addEdge(s, t, w as any); }
  return g;
}


