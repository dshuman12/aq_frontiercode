import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

export interface DPResult { value: number; path: NodeId[]; table: Map<NodeId, number>; }
export interface VertexCoverDP { size: number; cover: NodeId[]; }
export interface IndependentSetDP { size: number; nodes: NodeId[]; }
export interface DominatingSetResult { size: number; set: NodeId[]; }
export interface SteinerTreeResult { edges: [NodeId, NodeId][]; totalWeight: number; nodes: NodeId[]; }
export interface TravelingSalesmanResult { tour: NodeId[]; totalWeight: number; optimal: boolean; }
export interface KnapsackGraphResult { value: number; selected: NodeId[]; }

export function longestPathDP(g: DiGraph, source: NodeId): DPResult {
  const nodes = g.nodeIds();
  const dist = new Map<NodeId, number>(nodes.map(n => [n, -Infinity]));
  const prev = new Map<NodeId, NodeId | null>(nodes.map(n => [n, null]));
  dist.set(source, 0);

  let sorted: NodeId[];
  try { sorted = g.topoSort(); } catch { sorted = nodes; }

  for (const u of sorted) {
    if (dist.get(u) === -Infinity) continue;
    for (const [v, w] of Object.entries(g['_adjacency'].get(u) ?? {})) {
      const newDist = dist.get(u)! + (w as number);
      if (newDist > (dist.get(v as NodeId) ?? -Infinity)) {
        dist.set(v as NodeId, newDist);
        prev.set(v as NodeId, u);
      }
    }
  }

  let best = source, bestVal = 0;
  for (const [n, d] of dist) if (d > bestVal) { bestVal = d; best = n; }

  const path: NodeId[] = [];
  let cur: NodeId | null = best;
  while (cur !== null) { path.unshift(cur); cur = prev.get(cur) ?? null; }

  return { value: bestVal, path, table: dist };
}

export function shortestPathDP(g: Graph, source: NodeId): DPResult {
  const nodes = g.nodeIds();
  const dist = new Map<NodeId, number>(nodes.map(n => [n, Infinity]));
  const prev = new Map<NodeId, NodeId | null>(nodes.map(n => [n, null]));
  dist.set(source, 0);

  const pq: [number, NodeId][] = [[0, source]];
  while (pq.length > 0) {
    pq.sort((a, b) => a[0] - b[0]);
    const [d, u] = pq.shift()!;
    if (d > dist.get(u)!) continue;
    for (const v of g.neighbors(u)) {
      const w = g.getEdge(u, v)?.weight ?? 1;
      const nd = d + w;
      if (nd < dist.get(v)!) { dist.set(v, nd); prev.set(v, u); pq.push([nd, v]); }
    }
  }

  let best = source, bestVal = Infinity;
  for (const [n, d] of dist) if (d < bestVal && n !== source) { bestVal = d; best = n; }
  const path: NodeId[] = [];
  let cur: NodeId | null = best;
  while (cur !== null) { path.unshift(cur); cur = prev.get(cur) ?? null; }

  return { value: bestVal === Infinity ? 0 : bestVal, path, table: dist };
}

export function minimumVertexCover(g: Graph): VertexCoverDP {
  const nodes = g.nodeIds();
  if (nodes.length === 0) return { size: 0, cover: [] };
  const cover = new Set<NodeId>();
  for (const e of g.edges()) {
    if (!cover.has(e.source) && !cover.has(e.target)) {
      cover.add(e.source);
      cover.add(e.target);
    }
  }
  return { size: cover.size, cover: [...cover] };
}

export function maximumIndependentSetDP(g: Graph): IndependentSetDP {
  const nodes = g.nodeIds();
  if (nodes.length === 0) return { size: 0, nodes: [] };
  const cover = minimumVertexCover(g);
  const coverSet = new Set(cover.cover);
  const independent = nodes.filter(n => !coverSet.has(n));
  return { size: independent.length, nodes: independent };
}

export function minimumDominatingSet(g: Graph): DominatingSetResult {
  const nodes = g.nodeIds();
  const dominated = new Set<NodeId>();
  const domSet: NodeId[] = [];
  const nodesByDegree = [...nodes].sort((a, b) => g.degree(b) - g.degree(a));
  for (const u of nodesByDegree) {
    if (dominated.has(u)) continue;
    domSet.push(u);
    dominated.add(u);
    for (const v of g.neighbors(u)) dominated.add(v);
    if (dominated.size === nodes.length) break;
  }
  return { size: domSet.length, set: domSet };
}

export function approximateSteinerTree(
  g: Graph,
  terminals: NodeId[]
): SteinerTreeResult {
  if (terminals.length === 0) return { edges: [], totalWeight: 0, nodes: [] };
  const edgeSet: [NodeId, NodeId][] = [];
  const nodeSet = new Set<NodeId>([terminals[0]]);
  let totalWeight = 0;

  const remaining = new Set(terminals.slice(1));
  while (remaining.size > 0) {
    let bestDist = Infinity, bestEdge: [NodeId, NodeId] | null = null, bestTarget: NodeId | null = null;
    for (const u of nodeSet) {
      for (const v of g.neighbors(u)) {
        const w = g.getEdge(u, v)?.weight ?? 1;
        if (!nodeSet.has(v) && w < bestDist) {
          bestDist = w; bestEdge = [u, v]; bestTarget = v;
        }
      }
    }
    if (!bestEdge || !bestTarget) break;
    edgeSet.push(bestEdge);
    nodeSet.add(bestTarget);
    totalWeight += bestDist;
    remaining.delete(bestTarget);
  }
  return { edges: edgeSet, totalWeight, nodes: [...nodeSet] };
}

export function tspNearestNeighbor(g: Graph, start?: NodeId): TravelingSalesmanResult {
  const nodes = g.nodeIds();
  if (nodes.length === 0) return { tour: [], totalWeight: 0, optimal: false };
  const startNode = start ?? nodes[0];
  const visited = new Set<NodeId>([startNode]);
  const tour: NodeId[] = [startNode];
  let totalWeight = 0;
  let cur = startNode;

  while (visited.size < nodes.length) {
    let bestDist = Infinity, bestNext: NodeId | null = null;
    for (const v of nodes) {
      if (visited.has(v)) continue;
      const w = g.hasEdge(cur, v) ? (g.getEdge(cur, v)?.weight ?? 1) : Infinity;
      if (w < bestDist) { bestDist = w; bestNext = v; }
    }
    if (!bestNext) break;
    tour.push(bestNext);
    visited.add(bestNext);
    totalWeight += bestDist;
    cur = bestNext;
  }

  if (g.hasEdge(cur, startNode)) totalWeight += g.getEdge(cur, startNode)?.weight ?? 1;
  tour.push(startNode);
  return { tour, totalWeight, optimal: nodes.length <= 3 };
}

export function tspDynamicProgramming(g: Graph): TravelingSalesmanResult {
  const nodes = g.nodeIds();
  const n = nodes.length;
  if (n === 0) return { tour: [], totalWeight: 0, optimal: true };
  if (n === 1) return { tour: [nodes[0]], totalWeight: 0, optimal: true };
  if (n > 15) return tspNearestNeighbor(g);

  const idx = new Map(nodes.map((n, i) => [n, i]));
  const w = (u: NodeId, v: NodeId) => g.hasEdge(u, v) ? (g.getEdge(u, v)?.weight ?? Infinity) : Infinity;

  const dp: number[][] = Array.from({ length: 1 << n }, () => Array(n).fill(Infinity));
  const parent: number[][] = Array.from({ length: 1 << n }, () => Array(n).fill(-1));
  dp[1][0] = 0;

  for (let mask = 1; mask < (1 << n); mask++) {
    for (let u = 0; u < n; u++) {
      if (!(mask & (1 << u)) || dp[mask][u] === Infinity) continue;
      for (let v = 0; v < n; v++) {
        if (mask & (1 << v)) continue;
        const nm = mask | (1 << v);
        const nd = dp[mask][u] + w(nodes[u], nodes[v]);
        if (nd < dp[nm][v]) { dp[nm][v] = nd; parent[nm][v] = u; }
      }
    }
  }

  const fullMask = (1 << n) - 1;
  let best = Infinity, last = -1;
  for (let u = 1; u < n; u++) {
    const val = dp[fullMask][u] + w(nodes[u], nodes[0]);
    if (val < best) { best = val; last = u; }
  }

  const tour: number[] = [];
  let mask = fullMask, cur = last;
  while (cur !== -1) { tour.unshift(cur); const p = parent[mask][cur]; mask ^= (1 << cur); cur = p; }
  tour.push(0);

  return { tour: tour.map(i => nodes[i]), totalWeight: best, optimal: true };
}

export function knapsackOnGraph(
  g: Graph,
  weights: Map<NodeId, number>,
  values: Map<NodeId, number>,
  capacity: number
): KnapsackGraphResult {
  const nodes = g.nodeIds();
  const n = nodes.length;
  const W = Math.ceil(capacity);
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const node = nodes[i - 1];
    const wi = Math.ceil(weights.get(node) ?? 0);
    const vi = values.get(node) ?? 0;
    for (let c = 0; c <= W; c++) {
      dp[i][c] = dp[i - 1][c];
      if (c >= wi && dp[i - 1][c - wi] + vi > dp[i][c]) dp[i][c] = dp[i - 1][c - wi] + vi;
    }
  }

  const selected: NodeId[] = [];
  let c = W;
  for (let i = n; i > 0; i--) {
    if (dp[i][c] !== dp[i - 1][c]) { selected.push(nodes[i - 1]); c -= Math.ceil(weights.get(nodes[i - 1]) ?? 0); }
  }
  return { value: dp[n][W], selected };
}

export function graphColoringDP(g: Graph): Map<NodeId, number> {
  const nodes = g.nodeIds();
  const color = new Map<NodeId, number>();
  for (const u of nodes) {
    const used = new Set(g.neighbors(u).map(v => color.get(v) ?? -1));
    let c = 0;
    while (used.has(c)) c++;
    color.set(u, c);
  }
  return color;
}

export function weightedIndependentSet(g: Graph, weights: Map<NodeId, number>): { value: number; nodes: NodeId[] } {
  const nodes = [...g.nodeIds()].sort((a, b) => (weights.get(b) ?? 0) - (weights.get(a) ?? 0));
  const selected = new Set<NodeId>();
  const excluded = new Set<NodeId>();
  let value = 0;
  for (const u of nodes) {
    if (excluded.has(u)) continue;
    selected.add(u);
    value += weights.get(u) ?? 0;
    for (const v of g.neighbors(u)) excluded.add(v);
  }
  return { value, nodes: [...selected] };
}


