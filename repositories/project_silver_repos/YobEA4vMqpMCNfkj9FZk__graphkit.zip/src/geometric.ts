import { Graph } from './graph';
import { NodeId } from './types';

export interface Point2D { x: number; y: number; id: NodeId; }
export interface GeometricGraph { graph: Graph; positions: Map<NodeId, Point2D>; }
export interface ConvexHullResult { hull: Point2D[]; interior: Point2D[]; area: number; }
export interface EmbeddingResult { positions: Map<NodeId, Point2D>; stress: number; iterations: number; }

function dist(a: Point2D, b: Point2D): number {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

function cross(O: Point2D, A: Point2D, B: Point2D): number {
  return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

export function buildGeometricGraph(points: Point2D[], radius: number): GeometricGraph {
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  for (let i = 0; i < points.length; i++)
    for (let j = i + 1; j < points.length; j++)
      if (dist(points[i], points[j]) <= radius)
        g.addEdge(points[i].id, points[j].id, dist(points[i], points[j]));
  return { graph: g, positions };
}

export function buildKNNGraph(points: Point2D[], k: number): GeometricGraph {
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  for (let i = 0; i < points.length; i++) {
    const nearest = points.map((p, j) => ({ j, d: dist(points[i], p) }))
      .filter(x => x.j !== i).sort((a, b) => a.d - b.d).slice(0, k);
    for (const { j, d } of nearest)
      if (!g.hasEdge(points[i].id, points[j].id)) g.addEdge(points[i].id, points[j].id, d);
  }
  return { graph: g, positions };
}

export function convexHull(points: Point2D[]): ConvexHullResult {
  if (points.length < 3) return { hull: points, interior: [], area: 0 };
  const sorted = [...points].sort((a, b) => a.x !== b.x ? a.x - b.x : a.y - b.y);
  const lower: Point2D[] = [];
  for (const p of sorted) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0)
      lower.pop();
    lower.push(p);
  }
  const upper: Point2D[] = [];
  for (const p of [...sorted].reverse()) {
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0)
      upper.pop();
    upper.push(p);
  }
  lower.pop(); upper.pop();
  const hull = [...lower, ...upper];
  const hullSet = new Set(hull.map(p => p.id));
  const interior = points.filter(p => !hullSet.has(p.id));
  let area = 0;
  for (let i = 0; i < hull.length; i++) {
    const j = (i + 1) % hull.length;
    area += hull[i].x * hull[j].y - hull[j].x * hull[i].y;
  }
  return { hull, interior, area: Math.abs(area) / 2 };
}

export function buildDelaunayApprox(points: Point2D[]): GeometricGraph {
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  for (let i = 0; i < points.length; i++) {
    const nearest = points.map((p, j) => ({ j, d: dist(points[i], p) }))
      .filter(x => x.j !== i).sort((a, b) => a.d - b.d).slice(0, Math.min(4, points.length - 1));
    for (const { j, d } of nearest)
      if (!g.hasEdge(points[i].id, points[j].id)) g.addEdge(points[i].id, points[j].id, d);
  }
  return { graph: g, positions };
}

export function buildGabrielGraph(points: Point2D[]): GeometricGraph {
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      const cx = (points[i].x + points[j].x) / 2;
      const cy = (points[i].y + points[j].y) / 2;
      const r = dist(points[i], points[j]) / 2;
      const blocked = points.some((p, k) =>
        k !== i && k !== j && Math.sqrt((p.x - cx) ** 2 + (p.y - cy) ** 2) < r
      );
      if (!blocked) g.addEdge(points[i].id, points[j].id, dist(points[i], points[j]));
    }
  }
  return { graph: g, positions };
}

export function buildRelativeNeighborhoodGraph(points: Point2D[]): GeometricGraph {
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      const d = dist(points[i], points[j]);
      const dominated = points.some((p, k) =>
        k !== i && k !== j && dist(points[i], p) < d && dist(points[j], p) < d
      );
      if (!dominated) g.addEdge(points[i].id, points[j].id, d);
    }
  }
  return { graph: g, positions };
}

export function spectralEmbedding(g: Graph, dims = 2, seed = 42): EmbeddingResult {
  const nodes = g.nodeIds();
  const n = nodes.length;
  if (n === 0) return { positions: new Map(), stress: 0, iterations: 0 };
  let s = seed;
  const rng = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 0xffffffff; };
  const positions = new Map<NodeId, Point2D>();
  nodes.forEach(node => positions.set(node, { x: rng() * 10, y: rng() * 10, id: node }));

  const k = 100;
  let stress = 0;
  for (let iter = 0; iter < k; iter++) {
    for (const u of nodes) {
      const pu = positions.get(u)!;
      let fx = 0, fy = 0;
      for (const v of nodes) {
        if (v === u) continue;
        const pv = positions.get(v)!;
        const d = Math.max(0.01, dist(pu, pv));
        const ideal = g.hasEdge(u, v) ? 1 : 3;
        const force = (d - ideal) / d;
        fx += force * (pv.x - pu.x);
        fy += force * (pv.y - pu.y);
      }
      pu.x += fx * 0.01;
      pu.y += fy * 0.01;
    }
  }

  stress = 0;
  for (const e of g.edges()) {
    const pu = positions.get(e.source)!, pv = positions.get(e.target)!;
    stress += (dist(pu, pv) - 1) ** 2;
  }
  return { positions, stress, iterations: k };
}

export function forceDirectedPositions(g: Graph, iterations = 50, seed = 42): Map<NodeId, Point2D> {
  const nodes = g.nodeIds();
  let s = seed;
  const rng = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 0xffffffff; };
  const pos = new Map<NodeId, Point2D>(nodes.map(n => [n, { x: rng() * 100, y: rng() * 100, id: n }]));
  const k = Math.sqrt(10000 / Math.max(1, nodes.length));

  for (let iter = 0; iter < iterations; iter++) {
    const disp = new Map<NodeId, { dx: number; dy: number }>(nodes.map(n => [n, { dx: 0, dy: 0 }]));
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const u = nodes[i], v = nodes[j];
        const pu = pos.get(u)!, pv = pos.get(v)!;
        const dx = pu.x - pv.x, dy = pu.y - pv.y;
        const d = Math.max(0.01, Math.sqrt(dx * dx + dy * dy));
        const rep = k * k / d;
        disp.get(u)!.dx += (dx / d) * rep;
        disp.get(u)!.dy += (dy / d) * rep;
        disp.get(v)!.dx -= (dx / d) * rep;
        disp.get(v)!.dy -= (dy / d) * rep;
      }
    }
    for (const e of g.edges()) {
      const pu = pos.get(e.source)!, pv = pos.get(e.target)!;
      const dx = pu.x - pv.x, dy = pu.y - pv.y;
      const d = Math.max(0.01, Math.sqrt(dx * dx + dy * dy));
      const att = d * d / k;
      disp.get(e.source)!.dx -= (dx / d) * att;
      disp.get(e.source)!.dy -= (dy / d) * att;
      disp.get(e.target)!.dx += (dx / d) * att;
      disp.get(e.target)!.dy += (dy / d) * att;
    }
    const temp = Math.max(0.1, 10 * (1 - iter / iterations));
    for (const n of nodes) {
      const p = pos.get(n)!, d2 = disp.get(n)!;
      const len = Math.max(0.01, Math.sqrt(d2.dx ** 2 + d2.dy ** 2));
      p.x += (d2.dx / len) * Math.min(len, temp);
      p.y += (d2.dy / len) * Math.min(len, temp);
    }
  }
  return pos;
}

export function closestPair(points: Point2D[]): [Point2D, Point2D, number] {
  let minDist = Infinity, a = points[0], b = points[1];
  for (let i = 0; i < points.length; i++)
    for (let j = i + 1; j < points.length; j++) {
      const d = dist(points[i], points[j]);
      if (d < minDist) { minDist = d; a = points[i]; b = points[j]; }
    }
  return [a, b, minDist];
}

export function minimumSpanningEuclidean(points: Point2D[]): GeometricGraph {
  if (points.length === 0) return { graph: new Graph(), positions: new Map() };
  const g = new Graph();
  const positions = new Map<NodeId, Point2D>();
  for (const p of points) { g.addNode(p.id); positions.set(p.id, p); }
  const inMST = new Set<NodeId>([points[0].id]);
  while (inMST.size < points.length) {
    let bestD = Infinity, bestU: NodeId = points[0].id, bestV: NodeId = points[0].id;
    for (const u of inMST) {
      for (const p of points) {
        if (inMST.has(p.id)) continue;
        const d = dist(positions.get(u)!, p);
        if (d < bestD) { bestD = d; bestU = u; bestV = p.id; }
      }
    }
    g.addEdge(bestU, bestV, bestD);
    inMST.add(bestV);
  }
  return { graph: g, positions };
}

export function pointsInRadius(center: Point2D, points: Point2D[], radius: number): Point2D[] {
  return points.filter(p => p.id !== center.id && dist(center, p) <= radius);
}

export function graphDiameter2D(gg: GeometricGraph): number {
  const nodes = gg.graph.nodeIds();
  let max = 0;
  for (let i = 0; i < nodes.length; i++)
    for (let j = i + 1; j < nodes.length; j++) {
      const pu = gg.positions.get(nodes[i])!, pv = gg.positions.get(nodes[j])!;
      const d = dist(pu, pv);
      if (d > max) max = d;
    }
  return max;
}

export function averageEdgeLength(gg: GeometricGraph): number {
  const edges = gg.graph.edges();
  if (edges.length === 0) return 0;
  return edges.reduce((s, e) => s + (e.weight ?? 1), 0) / edges.length;
}

export function clusteringByProximity(points: Point2D[], radius: number): Map<NodeId, number> {
  const labels = new Map<NodeId, number>();
  let cluster = 0;
  const visited = new Set<NodeId>();
  for (const p of points) {
    if (visited.has(p.id)) continue;
    const queue = [p];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      if (visited.has(curr.id)) continue;
      visited.add(curr.id);
      labels.set(curr.id, cluster);
      for (const q of points)
        if (!visited.has(q.id) && dist(curr, q) <= radius) queue.push(q);
    }
    cluster++;
  }
  return labels;
}


