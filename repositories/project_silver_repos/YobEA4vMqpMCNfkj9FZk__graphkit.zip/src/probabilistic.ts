import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { bfs } from './traversal';

export interface MonteCarloResult {
  estimate: number;
  variance: number;
  samples: number;
  confidence95: [number, number];
}

export interface PercolationResult {
  percolates: boolean;
  giantComponentSize: number;
  percolationThreshold: number;
  componentSizes: number[];
}

export interface ReliabilityResult {
  reliability: number;
  variance: number;
  criticalEdges: [NodeId, NodeId][];
}

export interface SimulationResult {
  iterations: number;
  convergence: boolean;
  finalValue: number;
  history: number[];
}

function seededRng(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}

export function monteCarloConnectivity(
  g: Graph,
  edgeFailProb: number,
  samples = 1000,
  seed = 42
): MonteCarloResult {
  const rng = seededRng(seed);
  const edges = g.edges();
  const nodes = g.nodeIds();
  if (nodes.length === 0) return { estimate: 1, variance: 0, samples, confidence95: [1, 1] };

  let successes = 0;
  const results: number[] = [];

  for (let i = 0; i < samples; i++) {
    const alive = new Set(edges.filter(() => rng() > edgeFailProb).map(e => `${e.source}-${e.target}`));
    const tempG = new Graph();
    nodes.forEach(n => tempG.addNode(n));
    for (const e of edges) {
      if (alive.has(`${e.source}-${e.target}`)) tempG.addEdge(e.source, e.target, e.weight);
    }
    const visited = new Set<NodeId>();
    const stack = [nodes[0]];
    while (stack.length > 0) {
      const u = stack.pop()!;
      if (!visited.has(u)) {
        visited.add(u);
        for (const v of tempG.neighbors(u)) if (!visited.has(v)) stack.push(v);
      }
    }
    const connected = visited.size === nodes.length ? 1 : 0;
    results.push(connected);
    successes += connected;
  }

  const estimate = successes / samples;
  const variance = results.reduce((s, v) => s + (v - estimate) ** 2, 0) / (samples - 1);
  const se = Math.sqrt(variance / samples);
  return {
    estimate,
    variance,
    samples,
    confidence95: [Math.max(0, estimate - 1.96 * se), Math.min(1, estimate + 1.96 * se)],
  };
}

export function bondPercolation(
  g: Graph,
  p: number,
  seed = 42
): PercolationResult {
  const rng = seededRng(seed);
  const nodes = g.nodeIds();
  const subG = new Graph();
  nodes.forEach(n => subG.addNode(n));
  for (const e of g.edges()) {
    if (rng() < p) subG.addEdge(e.source, e.target, e.weight);
  }

  const visited = new Set<NodeId>();
  const componentSizes: number[] = [];
  for (const start of nodes) {
    if (visited.has(start)) continue;
    const comp: NodeId[] = [];
    const stack = [start];
    while (stack.length > 0) {
      const u = stack.pop()!;
      if (!visited.has(u)) {
        visited.add(u);
        comp.push(u);
        for (const v of subG.neighbors(u)) if (!visited.has(v)) stack.push(v);
      }
    }
    componentSizes.push(comp.length);
  }

  const giantSize = componentSizes.length > 0 ? Math.max(...componentSizes) : 0;
  return {
    percolates: giantSize === nodes.length,
    giantComponentSize: giantSize,
    percolationThreshold: 1 / Math.max(1, g.edgeCount()),
    componentSizes: componentSizes.sort((a, b) => b - a),
  };
}

export function sitePercolation(
  g: Graph,
  p: number,
  seed = 42
): PercolationResult {
  const rng = seededRng(seed);
  const nodes = g.nodeIds();
  const alive = new Set(nodes.filter(() => rng() < p));
  const subG = new Graph();
  alive.forEach(n => subG.addNode(n));
  for (const e of g.edges()) {
    if (alive.has(e.source) && alive.has(e.target)) subG.addEdge(e.source, e.target, e.weight);
  }

  const visited = new Set<NodeId>();
  const componentSizes: number[] = [];
  for (const start of alive) {
    if (visited.has(start)) continue;
    const comp: NodeId[] = [];
    const stack = [start];
    while (stack.length > 0) {
      const u = stack.pop()!;
      if (!visited.has(u)) { visited.add(u); comp.push(u); for (const v of subG.neighbors(u)) if (!visited.has(v)) stack.push(v); }
    }
    componentSizes.push(comp.length);
  }

  const giantSize = componentSizes.length > 0 ? Math.max(...componentSizes) : 0;
  return {
    percolates: giantSize === nodes.length,
    giantComponentSize: giantSize,
    percolationThreshold: 0.5,
    componentSizes: componentSizes.sort((a, b) => b - a),
  };
}

export function estimateReliability(
  g: Graph,
  edgeSurvivalProb: number,
  source: NodeId,
  target: NodeId,
  samples = 500,
  seed = 42
): ReliabilityResult {
  const rng = seededRng(seed);
  const edges = g.edges();
  let successes = 0;
  const edgeFailCounts = new Map<string, number>();

  for (const e of edges) edgeFailCounts.set(`${e.source}-${e.target}`, 0);

  for (let i = 0; i < samples; i++) {
    const tempG = new Graph();
    for (const n of g.nodeIds()) tempG.addNode(n);
    const failedEdges: string[] = [];
    for (const e of edges) {
      if (rng() < edgeSurvivalProb) {
        tempG.addEdge(e.source, e.target, e.weight);
      } else {
        failedEdges.push(`${e.source}-${e.target}`);
      }
    }
    const res = bfs(tempG, source);
    if (res.visited.includes(target)) {
      successes++;
    } else {
      for (const f of failedEdges) edgeFailCounts.set(f, (edgeFailCounts.get(f) ?? 0) + 1);
    }
  }

  const reliability = successes / samples;
  const variance = (reliability * (1 - reliability)) / samples;
  const criticalEdges = [...edgeFailCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([key]) => key.split('-') as [NodeId, NodeId]);

  return { reliability, variance, criticalEdges };
}

export function simulateEpidemicSIR(
  g: Graph,
  infectionRate: number,
  recoveryRate: number,
  initialInfected: NodeId[],
  steps = 20,
  seed = 42
): { susceptible: number[]; infected: number[]; recovered: number[] } {
  const rng = seededRng(seed);
  const nodes = g.nodeIds();
  const S = new Set(nodes);
  const I = new Set(initialInfected);
  const R = new Set<NodeId>();
  initialInfected.forEach(n => S.delete(n));

  const susceptible = [S.size];
  const infected = [I.size];
  const recovered = [R.size];

  for (let t = 0; t < steps; t++) {
    const newI = new Set<NodeId>();
    const newR = new Set<NodeId>();
    for (const u of I) {
      if (rng() < recoveryRate) { newR.add(u); continue; }
      for (const v of g.neighbors(u)) {
        if (S.has(v) && rng() < infectionRate) newI.add(v);
      }
    }
    newR.forEach(n => { I.delete(n); R.add(n); });
    newI.forEach(n => { S.delete(n); I.add(n); });
    susceptible.push(S.size);
    infected.push(I.size);
    recovered.push(R.size);
    if (I.size === 0) break;
  }
  return { susceptible, infected, recovered };
}

export function simulateEpidemicSIS(
  g: Graph,
  infectionRate: number,
  recoveryRate: number,
  initialInfected: NodeId[],
  steps = 30,
  seed = 42
): { susceptible: number[]; infected: number[] } {
  const rng = seededRng(seed);
  const nodes = g.nodeIds();
  const S = new Set(nodes);
  const I = new Set(initialInfected);
  initialInfected.forEach(n => S.delete(n));

  const susceptible = [S.size];
  const infected = [I.size];

  for (let t = 0; t < steps; t++) {
    const newI = new Set<NodeId>();
    const newS = new Set<NodeId>();
    for (const u of I) {
      if (rng() < recoveryRate) { newS.add(u); }
      else {
        for (const v of g.neighbors(u)) {
          if (S.has(v) && rng() < infectionRate) newI.add(v);
        }
      }
    }
    newS.forEach(n => { I.delete(n); S.add(n); });
    newI.forEach(n => { S.delete(n); I.add(n); });
    susceptible.push(S.size);
    infected.push(I.size);
    if (I.size === 0) break;
  }
  return { susceptible, infected };
}

export function approximateChromatic(
  g: Graph,
  trials = 100,
  seed = 42
): number {
  const rng = seededRng(seed);
  const nodes = g.nodeIds();
  let best = nodes.length;

  for (let t = 0; t < trials; t++) {
    const order = [...nodes].sort(() => rng() - 0.5);
    const color = new Map<NodeId, number>();
    for (const u of order) {
      const neighborColors = new Set(g.neighbors(u).map(v => color.get(v) ?? -1));
      let c = 0;
      while (neighborColors.has(c)) c++;
      color.set(u, c);
    }
    const maxColor = Math.max(...color.values()) + 1;
    if (maxColor < best) best = maxColor;
  }
  return best;
}

export function randomizedMinCut(
  g: Graph,
  trials = 50,
  seed = 42
): number {
  const rng = seededRng(seed);
  let minCut = Infinity;

  for (let t = 0; t < trials; t++) {
    const nodes = g.nodeIds().map(n => [n]);
    const superNodes = new Map<NodeId, NodeId[]>(nodes.map(([n]) => [n, [n]]));
    const edges = [...g.edges()];

    while (superNodes.size > 2) {
      if (edges.length === 0) break;
      const idx = Math.floor(rng() * edges.length);
      const e = edges[idx];
      const uSuper = [...superNodes.entries()].find(([, vs]) => vs.includes(e.source))?.[0];
      const vSuper = [...superNodes.entries()].find(([, vs]) => vs.includes(e.target))?.[0];
      if (!uSuper || !vSuper || uSuper === vSuper) { edges.splice(idx, 1); continue; }
      const merged = [...(superNodes.get(uSuper) ?? []), ...(superNodes.get(vSuper) ?? [])];
      superNodes.delete(vSuper);
      superNodes.set(uSuper, merged);
      edges.splice(idx, 1);
    }

    const [a, b] = [...superNodes.values()];
    if (!a || !b) continue;
    const setA = new Set(a);
    let cut = 0;
    for (const e of g.edges()) {
      const inA = setA.has(e.source);
      const inB = !setA.has(e.target);
      if (inA && inB) cut++;
      if (!inA && setA.has(e.target)) cut++;
    }
    if (cut < minCut) minCut = cut;
  }
  return minCut === Infinity ? 0 : minCut;
}


