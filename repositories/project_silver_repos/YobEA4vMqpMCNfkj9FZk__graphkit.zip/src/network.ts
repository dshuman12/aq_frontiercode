import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { connectedComponents, isConnected } from './components';
import { dijkstra } from './shortest_path';

export interface NetworkStats {
  nodeCount: number;
  edgeCount: number;
  density: number;
  avgDegree: number;
  maxDegree: number;
  minDegree: number;
  isConnected: boolean;
  componentCount: number;
  avgClusteringCoeff: number;
}

export interface RobustnessResult {
  removedNode: NodeId;
  componentsBefore: number;
  componentsAfter: number;
  largestComponentBefore: number;
  largestComponentAfter: number;
  connectivityChanged: boolean;
}

export function networkStats(g: Graph): NetworkStats {
  const n = g.nodeCount();
  const m = g.edgeCount();
  const degrees = g.nodeIds().map(id => g.degree(id));
  const avgDeg = n === 0 ? 0 : degrees.reduce((s, d) => s + d, 0) / n;
  const maxDeg = n === 0 ? 0 : Math.max(...degrees);
  const minDeg = n === 0 ? 0 : Math.min(...degrees);
  const cc = connectedComponents(g);
  let totalCluster = 0;
  for (const id of g.nodeIds()) {
    const nbrs = g.neighbors(id);
    const k = nbrs.length;
    if (k < 2) continue;
    let links = 0;
    for (let i = 0; i < nbrs.length; i++) for (let j = i+1; j < nbrs.length; j++) if (g.hasEdge(nbrs[i], nbrs[j])) links++;
    totalCluster += (2 * links) / (k * (k - 1));
  }
  const avgCC = n === 0 ? 0 : totalCluster / n;
  return { nodeCount: n, edgeCount: m, density: g.density(), avgDegree: avgDeg, maxDegree: maxDeg, minDegree: minDeg, isConnected: cc.count <= 1, componentCount: cc.count, avgClusteringCoeff: avgCC };
}

export function nodeRobustness(g: Graph, nodeId: NodeId): RobustnessResult {
  const before = connectedComponents(g);
  const clone = g.clone();
  clone.removeNode(nodeId);
  const after = connectedComponents(clone);
  return { removedNode: nodeId, componentsBefore: before.count, componentsAfter: after.count, largestComponentBefore: before.largestComponent.length, largestComponentAfter: after.largestComponent?.length ?? 0, connectivityChanged: before.count !== after.count };
}

export function criticalNodes(g: Graph): NodeId[] {
  const base = connectedComponents(g).count;
  const critical: NodeId[] = [];
  for (const id of g.nodeIds()) {
    const clone = g.clone();
    clone.removeNode(id);
    if (connectedComponents(clone).count > base) critical.push(id);
  }
  return critical;
}

export function percolationThreshold(g: Graph, trials = 10): number {
  const n = g.nodeCount();
  if (n === 0) return 0;
  let threshold = 0;
  for (let t = 0; t < trials; t++) {
    const nodes = [...g.nodeIds()].sort(() => Math.random() - 0.5);
    for (let i = 1; i <= nodes.length; i++) {
      const sub = g.subgraph(nodes.slice(0, i));
      if (isConnected(sub)) { threshold += i / n; break; }
    }
  }
  return threshold / trials;
}

export function smallWorldCoeff(g: Graph): { sigma: number; omega: number } {
  const n = g.nodeCount();
  if (n < 2) return { sigma: 0, omega: 0 };
  const degrees = g.nodeIds().map(id => g.degree(id));
  const avgDeg = degrees.reduce((s, d) => s + d, 0) / n;
  const sigma = avgDeg > 0 ? n / (avgDeg * Math.log(n + 1)) : 0;
  const omega = sigma > 1 ? 1 / sigma : sigma;
  return { sigma, omega };
}

export function algebraicConnectivity(g: Graph): number {
  const n = g.nodeCount();
  if (n < 2) return 0;
  const ids = g.nodeIds();
  const idx = new Map<NodeId, number>(ids.map((id, i) => [id, i]));
  const L: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (const id of ids) {
    const i = idx.get(id)!;
    L[i][i] = g.degree(id);
    for (const nb of g.neighbors(id)) { const j = idx.get(nb)!; L[i][j] = -1; }
  }
  let minNonZero = Infinity;
  for (let iter = 0; iter < 50; iter++) {
    let v = Array.from({ length: n }, () => Math.random() - 0.5);
    const vMean = v.reduce((s, x) => s + x, 0) / n;
    v = v.map(x => x - vMean);
    let norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    if (norm === 0) continue;
    v = v.map(x => x / norm);
    for (let power = 0; power < 30; power++) {
      const Lv = v.map((_, i) => L[i].reduce((s, Lij, j) => s + Lij * v[j], 0));
      norm = Math.sqrt(Lv.reduce((s, x) => s + x * x, 0));
      if (norm === 0) break;
      v = Lv.map(x => x / norm);
    }
    const Lv = v.map((_, i) => L[i].reduce((s, Lij, j) => s + Lij * v[j], 0));
    const lambda = v.reduce((s, vi, i) => s + vi * Lv[i], 0);
    if (lambda > 1e-9 && lambda < minNonZero) minNonZero = lambda;
  }
  return minNonZero === Infinity ? 0 : minNonZero;
}

export function networkEfficiency(g: Graph): number {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n < 2) return 0;
  let sum = 0;
  for (const src of ids) {
    const res = dijkstra(g, src);
    for (const tgt of ids) {
      if (tgt !== src) {
        const d = res.distances.get(tgt) ?? Infinity;
        if (d > 0 && d < Infinity) sum += 1 / d;
      }
    }
  }
  return sum / (n * (n - 1));
}

export function vulnerabilityIndex(g: Graph): number {
  const base = networkEfficiency(g);
  if (base === 0) return 0;
  let maxVulnerability = 0;
  for (const id of g.nodeIds()) {
    const clone = g.clone();
    clone.removeNode(id);
    const eff = networkEfficiency(clone);
    const v = (base - eff) / base;
    if (v > maxVulnerability) maxVulnerability = v;
  }
  return maxVulnerability;
}

export function degreeAssortativity(g: Graph): number {
  const edges = g.edges();
  if (edges.length === 0) return 0;
  const m = edges.length;
  let sum1 = 0, sum2 = 0, sum3 = 0;
  for (const e of edges) {
    const di = g.degree(e.source), dj = g.degree(e.target);
    sum1 += di * dj;
    sum2 += (di + dj) / 2;
    sum3 += (di * di + dj * dj) / 2;
  }
  const num = sum1 / m - (sum2 / m) ** 2;
  const den = sum3 / m - (sum2 / m) ** 2;
  return den === 0 ? 0 : num / den;
}


