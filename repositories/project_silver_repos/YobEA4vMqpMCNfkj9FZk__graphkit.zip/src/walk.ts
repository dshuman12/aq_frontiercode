import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

type AnyGraph = Graph | DiGraph;

function getNeighbors(g: AnyGraph, id: NodeId): NodeId[] {
  return g instanceof DiGraph ? g.successors(id) : g.neighbors(id);
}

export interface WalkResult {
  path: NodeId[];
  visited: Set<NodeId>;
  steps: number;
}

export interface RandomWalkOptions {
  maxSteps?: number;
  restartProbability?: number;
  seed?: number;
}

class SimpleRNG {
  private state: number;
  constructor(seed: number) { this.state = seed; }
  next(): number {
    this.state = (this.state * 1664525 + 1013904223) & 0xFFFFFFFF;
    return Math.abs(this.state) / 0x80000000;
  }
  choice<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}

export function randomWalk(
  g: AnyGraph,
  start: NodeId,
  options: RandomWalkOptions = {}
): WalkResult {
  const maxSteps = options.maxSteps ?? 100;
  const restartProb = options.restartProbability ?? 0;
  const rng = new SimpleRNG(options.seed ?? 42);

  const path: NodeId[] = [start];
  const visited = new Set<NodeId>([start]);
  let current = start;

  for (let step = 0; step < maxSteps; step++) {
    if (restartProb > 0 && rng.next() < restartProb) {
      current = start;
      path.push(current);
      continue;
    }

    const nbrs = getNeighbors(g, current);
    if (nbrs.length === 0) break;

    current = rng.choice(nbrs);
    path.push(current);
    visited.add(current);
  }

  return { path, visited, steps: path.length - 1 };
}

export function biasedRandomWalk(
  g: AnyGraph,
  start: NodeId,
  p: number,
  q: number,
  walkLength: number,
  seed = 42
): NodeId[] {
  const rng = new SimpleRNG(seed);
  const path: NodeId[] = [start];
  let prev: NodeId | null = null;
  let current = start;

  for (let step = 0; step < walkLength - 1; step++) {
    const nbrs = getNeighbors(g, current);
    if (nbrs.length === 0) break;

    const weights: number[] = nbrs.map((v) => {
      if (prev === null) return 1;
      if (v === prev) return 1 / p;
      if (g.hasEdge(prev, v) || g.hasEdge(v, prev)) return 1;
      return 1 / q;
    });

    const totalWeight = weights.reduce((s, w) => s + w, 0);
    let r = rng.next() * totalWeight;
    let chosen = nbrs[nbrs.length - 1];
    for (let i = 0; i < nbrs.length; i++) {
      r -= weights[i];
      if (r <= 0) { chosen = nbrs[i]; break; }
    }

    prev = current;
    current = chosen;
    path.push(current);
  }

  return path;
}

export function coverTime(g: Graph, start: NodeId, seed = 42): number {
  const rng = new SimpleRNG(seed);
  const unvisited = new Set(g.nodeIds());
  let current = start;
  unvisited.delete(start);
  let steps = 0;
  const maxSteps = g.nodeCount() * g.nodeCount() * 10;

  while (unvisited.size > 0 && steps < maxSteps) {
    const nbrs = g.neighbors(current);
    if (nbrs.length === 0) break;
    current = rng.choice(nbrs);
    unvisited.delete(current);
    steps++;
  }

  return unvisited.size === 0 ? steps : -1;
}

export function transitionMatrix(g: Graph): number[][] {
  const nodes = g.nodeIds();
  const n = nodes.length;
  const idx = new Map(nodes.map((id, i) => [id, i]));
  const T: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));

  for (let i = 0; i < n; i++) {
    const nbrs = g.neighbors(nodes[i]);
    const deg = nbrs.length;
    if (deg === 0) continue;
    for (const v of nbrs) {
      T[i][idx.get(v)!] = 1 / deg;
    }
  }

  return T;
}

export function stationaryDistribution(
  g: Graph,
  maxIter = 1000,
  tolerance = 1e-8
): Map<NodeId, number> {
  const nodes = g.nodeIds();
  const n = nodes.length;
  if (n === 0) return new Map();

  const T = transitionMatrix(g);
  let dist = new Array(n).fill(1 / n);

  for (let iter = 0; iter < maxIter; iter++) {
    const newDist = new Array(n).fill(0);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        newDist[i] += dist[j] * T[j][i];
      }
    }

    let diff = 0;
    for (let i = 0; i < n; i++) diff += Math.abs(newDist[i] - dist[i]);
    dist = newDist;
    if (diff < tolerance) break;
  }

  return new Map(nodes.map((id, i) => [id, dist[i]]));
}

export function hitting_time(
  g: Graph,
  source: NodeId,
  target: NodeId,
  simulations = 100,
  seed = 42
): number {
  let totalSteps = 0;
  let reached = 0;
  const maxSteps = g.nodeCount() * 100;

  for (let sim = 0; sim < simulations; sim++) {
    const result = randomWalk(g, source, {
      maxSteps,
      seed: seed + sim,
    });
    const idx = result.path.indexOf(target);
    if (idx !== -1) {
      totalSteps += idx;
      reached++;
    }
  }

  return reached > 0 ? totalSteps / reached : Infinity;
}

export function commute_time(
  g: Graph,
  u: NodeId,
  v: NodeId,
  simulations = 50,
  seed = 42
): number {
  return (
    hitting_time(g, u, v, simulations, seed) +
    hitting_time(g, v, u, simulations, seed + 1000)
  );
}

export function generateWalks(
  g: AnyGraph,
  walksPerNode: number,
  walkLength: number,
  seed = 42
): NodeId[][] {
  const walks: NodeId[][] = [];
  let s = seed;

  for (const node of g.nodeIds()) {
    for (let w = 0; w < walksPerNode; w++) {
      const walk = randomWalk(g, node, { maxSteps: walkLength - 1, seed: s++ });
      walks.push(walk.path);
    }
  }

  return walks;
}

export function approximatePageRankByWalk(
  g: AnyGraph,
  walksPerNode = 50,
  walkLength = 20,
  seed = 42
): Map<NodeId, number> {
  const visits = new Map<NodeId, number>(g.nodeIds().map(id => [id, 0]));
  const totalWalks = g.nodeCount() * walksPerNode;
  const walks = generateWalks(g, walksPerNode, walkLength, seed);

  for (const walk of walks) {
    for (const node of walk) {
      visits.set(node, (visits.get(node) ?? 0) + 1);
    }
  }

  const totalVisits = [...visits.values()].reduce((s, v) => s + v, 0) || 1;
  return new Map([...visits].map(([id, count]) => [id, count / totalVisits]));
}


