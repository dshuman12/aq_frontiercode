import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

export interface TemporalEdge { source: NodeId; target: NodeId; weight: number; timestamp: number; duration?: number; }
export interface TemporalGraph { nodes: Set<NodeId>; edges: TemporalEdge[]; directed: boolean; }
export interface TemporalPath { nodes: NodeId[]; timestamps: number[]; duration: number; }
export interface TemporalCentrality { node: NodeId; score: number; }
export interface TemporalComponent { nodes: NodeId[]; start: number; end: number; }
export interface TemporalMetrics {
  nodeCount: number; edgeCount: number; uniqueTimestamps: number[];
  avgDuration: number; density: number; burstiness: number;
}

export function createTemporalGraph(directed = false): TemporalGraph {
  return { nodes: new Set(), edges: [], directed };
}

export function addTemporalEdge(tg: TemporalGraph, e: TemporalEdge): void {
  tg.nodes.add(e.source);
  tg.nodes.add(e.target);
  tg.edges.push(e);
}

export function snapshotAt(tg: TemporalGraph, t: number): Graph {
  const g = new Graph();
  for (const n of tg.nodes) g.addNode(n);
  for (const e of tg.edges) {
    const end = e.timestamp + (e.duration ?? 0);
    if (e.timestamp <= t && t <= end) {
      if (!g.hasEdge(e.source, e.target)) g.addEdge(e.source, e.target, e.weight);
    }
  }
  return g;
}

export function snapshotBetween(tg: TemporalGraph, t1: number, t2: number): Graph {
  const g = new Graph();
  for (const n of tg.nodes) g.addNode(n);
  for (const e of tg.edges)
    if (e.timestamp >= t1 && e.timestamp <= t2)
      if (!g.hasEdge(e.source, e.target)) g.addEdge(e.source, e.target, e.weight);
  return g;
}

export function temporalMetrics(tg: TemporalGraph): TemporalMetrics {
  const n = tg.nodes.size;
  const timestamps = [...new Set(tg.edges.map(e => e.timestamp))].sort((a, b) => a - b);
  const avgDuration = tg.edges.length === 0 ? 0 :
    tg.edges.reduce((s, e) => s + (e.duration ?? 0), 0) / tg.edges.length;
  const maxEdges = n * (n - 1) / 2;
  const density = maxEdges === 0 ? 0 : tg.edges.length / (maxEdges * Math.max(1, timestamps.length));

  let burstiness = 0;
  if (timestamps.length > 1) {
    const intervals = timestamps.slice(1).map((t, i) => t - timestamps[i]);
    const mean = intervals.reduce((s, v) => s + v, 0) / intervals.length;
    const std = Math.sqrt(intervals.reduce((s, v) => s + (v - mean) ** 2, 0) / intervals.length);
    burstiness = mean > 0 ? (std - mean) / (std + mean) : 0;
  }
  return { nodeCount: n, edgeCount: tg.edges.length, uniqueTimestamps: timestamps, avgDuration, density, burstiness };
}

export function temporalDegree(tg: TemporalGraph, node: NodeId): number {
  return tg.edges.filter(e => e.source === node || e.target === node).length;
}

export function temporalNeighbors(tg: TemporalGraph, node: NodeId, t: number): NodeId[] {
  const nbrs: NodeId[] = [];
  for (const e of tg.edges)
    if (e.timestamp <= t && (e.source === node || e.target === node))
      nbrs.push(e.source === node ? e.target : e.source);
  return [...new Set(nbrs)];
}

export function temporalReachability(tg: TemporalGraph, source: NodeId): Map<NodeId, number> {
  const reach = new Map<NodeId, number>();
  reach.set(source, -Infinity);
  const sorted = [...tg.edges].sort((a, b) => a.timestamp - b.timestamp);
  for (const e of sorted) {
    const srcReach = reach.get(e.source);
    if (srcReach !== undefined && e.timestamp >= srcReach) {
      const cur = reach.get(e.target) ?? Infinity;
      if (e.timestamp < cur) reach.set(e.target, e.timestamp);
    }
    if (!tg.directed) {
      const tgtReach = reach.get(e.target);
      if (tgtReach !== undefined && e.timestamp >= tgtReach) {
        const cur = reach.get(e.source) ?? Infinity;
        if (e.timestamp < cur) reach.set(e.source, e.timestamp);
      }
    }
  }
  return reach;
}

export function temporalShortestPath(tg: TemporalGraph, source: NodeId, target: NodeId): TemporalPath | null {
  const sorted = [...tg.edges].sort((a, b) => a.timestamp - b.timestamp);
  const dist = new Map<NodeId, { time: number; path: NodeId[]; timestamps: number[] }>();
  dist.set(source, { time: -Infinity, path: [source], timestamps: [] });

  for (const e of sorted) {
    const process = (from: NodeId, to: NodeId) => {
      const fromDist = dist.get(from);
      if (!fromDist || e.timestamp < fromDist.time) return;
      const cur = dist.get(to);
      if (!cur || e.timestamp < cur.time) {
        dist.set(to, {
          time: e.timestamp,
          path: [...fromDist.path, to],
          timestamps: [...fromDist.timestamps, e.timestamp],
        });
      }
    };
    process(e.source, e.target);
    if (!tg.directed) process(e.target, e.source);
  }

  const result = dist.get(target);
  if (!result || result.path.length <= 1) return null;
  return {
    nodes: result.path,
    timestamps: result.timestamps,
    duration: result.timestamps.length > 0 ? result.timestamps[result.timestamps.length - 1] - result.timestamps[0] : 0,
  };
}

export function temporalCentrality(tg: TemporalGraph): TemporalCentrality[] {
  const scores = new Map<NodeId, number>();
  for (const n of tg.nodes) scores.set(n, 0);
  for (const n of tg.nodes) {
    const reach = temporalReachability(tg, n);
    scores.set(n, reach.size);
  }
  return [...scores.entries()]
    .map(([node, score]) => ({ node, score }))
    .sort((a, b) => b.score - a.score);
}

export function activeNodes(tg: TemporalGraph, t: number): NodeId[] {
  const active = new Set<NodeId>();
  for (const e of tg.edges) {
    const end = e.timestamp + (e.duration ?? 0);
    if (e.timestamp <= t && t <= end) { active.add(e.source); active.add(e.target); }
  }
  return [...active];
}

export function temporalDensityOverTime(tg: TemporalGraph): { time: number; density: number }[] {
  const timestamps = [...new Set(tg.edges.map(e => e.timestamp))].sort((a, b) => a - b);
  const n = tg.nodes.size;
  const maxEdges = n * (n - 1) / 2;
  return timestamps.map(t => {
    const g = snapshotAt(tg, t);
    return { time: t, density: maxEdges === 0 ? 0 : g.edgeCount() / maxEdges };
  });
}

export function aggregateGraph(tg: TemporalGraph): Graph {
  const g = new Graph();
  for (const n of tg.nodes) g.addNode(n);
  const edgeWeights = new Map<string, number>();
  for (const e of tg.edges) {
    const key = [e.source, e.target].sort().join('||');
    edgeWeights.set(key, (edgeWeights.get(key) ?? 0) + e.weight);
  }
  for (const [key, w] of edgeWeights) {
    const [u, v] = key.split('||');
    if (!g.hasEdge(u, v)) g.addEdge(u, v, w);
  }
  return g;
}

export function temporalComponents(tg: TemporalGraph): TemporalComponent[] {
  const timestamps = [...new Set(tg.edges.map(e => e.timestamp))].sort((a, b) => a - b);
  if (timestamps.length === 0) return [];

  const comps: TemporalComponent[] = [];
  let start = timestamps[0];
  let prevNodes = new Set(activeNodes(tg, timestamps[0]));

  for (let i = 1; i < timestamps.length; i++) {
    const curr = new Set(activeNodes(tg, timestamps[i]));
    const overlap = [...prevNodes].filter(n => curr.has(n));
    if (overlap.length === 0) {
      comps.push({ nodes: [...prevNodes], start, end: timestamps[i - 1] });
      start = timestamps[i];
    }
    prevNodes = curr;
  }
  comps.push({ nodes: [...prevNodes], start, end: timestamps[timestamps.length - 1] });
  return comps;
}

export function interEventTimes(tg: TemporalGraph, node: NodeId): number[] {
  const times = tg.edges
    .filter(e => e.source === node || e.target === node)
    .map(e => e.timestamp)
    .sort((a, b) => a - b);
  return times.slice(1).map((t, i) => t - times[i]);
}

export function filterByTimeWindow(tg: TemporalGraph, start: number, end: number): TemporalGraph {
  const filtered = createTemporalGraph(tg.directed);
  for (const e of tg.edges)
    if (e.timestamp >= start && e.timestamp <= end) addTemporalEdge(filtered, e);
  return filtered;
}

export function temporalEdgeCount(tg: TemporalGraph, t1: number, t2: number): number {
  return tg.edges.filter(e => e.timestamp >= t1 && e.timestamp <= t2).length;
}


