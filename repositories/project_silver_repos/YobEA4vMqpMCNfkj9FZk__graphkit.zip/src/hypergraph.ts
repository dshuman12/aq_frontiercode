import { Graph } from './graph';
import { NodeId } from './types';

export interface Hyperedge { id: string; nodes: Set<NodeId>; weight: number; }
export interface Hypergraph { nodes: Map<NodeId, Record<string, unknown>>; edges: Map<string, Hyperedge>; directed: boolean; }
export interface HypergraphMetrics { nodeCount: number; edgeCount: number; avgEdgeSize: number; maxEdgeSize: number; density: number; }
export interface IncidenceMatrix { nodeIndex: Map<NodeId, number>; edgeIndex: Map<string, number>; matrix: number[][]; }
export interface DualHypergraph { nodes: Map<string, { edges: Set<string> }>; edges: Map<NodeId, Set<string>>; }

let edgeCounter = 0;
function nextEdgeId(): string { return `he${++edgeCounter}`; }

export function createHypergraph(directed = false): Hypergraph {
  return { nodes: new Map(), edges: new Map(), directed };
}

export function addHyperNode(hg: Hypergraph, id: NodeId, data: Record<string, unknown> = {}): void {
  hg.nodes.set(id, data);
}

export function addHyperedge(hg: Hypergraph, nodes: NodeId[], weight = 1, id?: string): string {
  const eid = id ?? nextEdgeId();
  for (const n of nodes) if (!hg.nodes.has(n)) hg.nodes.set(n, {});
  hg.edges.set(eid, { id: eid, nodes: new Set(nodes), weight });
  return eid;
}

export function removeHyperNode(hg: Hypergraph, id: NodeId): void {
  hg.nodes.delete(id);
  for (const [eid, e] of hg.edges) {
    e.nodes.delete(id);
    if (e.nodes.size === 0) hg.edges.delete(eid);
  }
}

export function removeHyperedge(hg: Hypergraph, id: string): void {
  hg.edges.delete(id);
}

export function hyperdegree(hg: Hypergraph, node: NodeId): number {
  let count = 0;
  for (const e of hg.edges.values()) if (e.nodes.has(node)) count++;
  return count;
}

export function hyperedgeSize(hg: Hypergraph, edgeId: string): number {
  return hg.edges.get(edgeId)?.nodes.size ?? 0;
}

export function hyperNeighbors(hg: Hypergraph, node: NodeId): Set<NodeId> {
  const nbrs = new Set<NodeId>();
  for (const e of hg.edges.values()) {
    if (e.nodes.has(node)) for (const v of e.nodes) if (v !== node) nbrs.add(v);
  }
  return nbrs;
}

export function hypergraphMetrics(hg: Hypergraph): HypergraphMetrics {
  const sizes = [...hg.edges.values()].map(e => e.nodes.size);
  const avgEdgeSize = sizes.length === 0 ? 0 : sizes.reduce((s, v) => s + v, 0) / sizes.length;
  const maxEdgeSize = sizes.length === 0 ? 0 : Math.max(...sizes);
  const n = hg.nodes.size;
  const maxEdges = n > 0 ? Math.pow(2, n) - n - 1 : 0;
  return {
    nodeCount: n,
    edgeCount: hg.edges.size,
    avgEdgeSize,
    maxEdgeSize,
    density: maxEdges === 0 ? 0 : hg.edges.size / maxEdges,
  };
}

export function toCliqueGraph(hg: Hypergraph): Graph {
  const g = new Graph();
  for (const n of hg.nodes.keys()) g.addNode(n);
  for (const e of hg.edges.values()) {
    const ns = [...e.nodes];
    for (let i = 0; i < ns.length; i++)
      for (let j = i + 1; j < ns.length; j++)
        if (!g.hasEdge(ns[i], ns[j])) g.addEdge(ns[i], ns[j], e.weight);
  }
  return g;
}

export function toStarGraph(hg: Hypergraph): Graph {
  const g = new Graph();
  for (const n of hg.nodes.keys()) g.addNode(n);
  for (const [eid, e] of hg.edges) {
    g.addNode(eid);
    for (const n of e.nodes) g.addEdge(eid, n, e.weight);
  }
  return g;
}

export function buildIncidenceMatrix(hg: Hypergraph): IncidenceMatrix {
  const nodeIndex = new Map<NodeId, number>([...hg.nodes.keys()].map((n, i) => [n, i]));
  const edgeIndex = new Map<string, number>([...hg.edges.keys()].map((e, i) => [e, i]));
  const rows = hg.nodes.size, cols = hg.edges.size;
  const matrix: number[][] = Array.from({ length: rows }, () => Array(cols).fill(0));
  for (const [eid, e] of hg.edges) {
    const j = edgeIndex.get(eid)!;
    for (const n of e.nodes) { const i = nodeIndex.get(n)!; matrix[i][j] = e.weight; }
  }
  return { nodeIndex, edgeIndex, matrix };
}

export function dualHypergraph(hg: Hypergraph): DualHypergraph {
  const nodes = new Map<string, { edges: Set<string> }>();
  const edges = new Map<NodeId, Set<string>>();
  for (const eid of hg.edges.keys()) nodes.set(eid, { edges: new Set() });
  for (const n of hg.nodes.keys()) edges.set(n, new Set());
  for (const [eid, e] of hg.edges)
    for (const n of e.nodes) {
      nodes.get(eid)!.edges.add(n as string);
      edges.get(n)!.add(eid);
    }
  return { nodes, edges };
}

export function hypergraphConnected(hg: Hypergraph): boolean {
  if (hg.nodes.size === 0) return true;
  const g = toCliqueGraph(hg);
  const start = [...hg.nodes.keys()][0];
  const visited = new Set<NodeId>([start]);
  const stack = [start];
  while (stack.length > 0) {
    const u = stack.pop()!;
    for (const v of g.neighbors(u)) if (!visited.has(v)) { visited.add(v); stack.push(v); }
  }
  return visited.size === hg.nodes.size;
}

export function hypergraphComponents(hg: Hypergraph): NodeId[][] {
  const g = toCliqueGraph(hg);
  const visited = new Set<NodeId>();
  const comps: NodeId[][] = [];
  for (const n of hg.nodes.keys()) {
    if (visited.has(n)) continue;
    const comp: NodeId[] = [];
    const stack = [n];
    while (stack.length > 0) {
      const u = stack.pop()!;
      if (visited.has(u)) continue;
      visited.add(u); comp.push(u);
      for (const v of g.neighbors(u)) if (!visited.has(v)) stack.push(v);
    }
    comps.push(comp);
  }
  return comps;
}

export function hypergraphClustering(hg: Hypergraph, node: NodeId): number {
  const nbrs = [...hyperNeighbors(hg, node)];
  if (nbrs.length < 2) return 0;
  let sharedEdges = 0;
  const nodeEdges = (n: NodeId) => new Set([...hg.edges.values()].filter(e => e.nodes.has(n)).map(e => e.id));
  const ne = nodeEdges(node);
  for (let i = 0; i < nbrs.length; i++)
    for (let j = i + 1; j < nbrs.length; j++) {
      const ei = nodeEdges(nbrs[i]);
      if ([...ne].some(e => ei.has(e))) sharedEdges++;
    }
  return (2 * sharedEdges) / (nbrs.length * (nbrs.length - 1));
}

export function uniformHypergraph(hg: Hypergraph): boolean {
  const sizes = [...hg.edges.values()].map(e => e.nodes.size);
  return sizes.length === 0 || sizes.every(s => s === sizes[0]);
}

export function hyperedgesContaining(hg: Hypergraph, node: NodeId): Hyperedge[] {
  return [...hg.edges.values()].filter(e => e.nodes.has(node));
}

export function edgeIntersection(hg: Hypergraph, e1: string, e2: string): NodeId[] {
  const a = hg.edges.get(e1)?.nodes ?? new Set();
  const b = hg.edges.get(e2)?.nodes ?? new Set();
  return [...a].filter(n => b.has(n));
}

export function edgeUnion(hg: Hypergraph, e1: string, e2: string): NodeId[] {
  const a = hg.edges.get(e1)?.nodes ?? new Set();
  const b = hg.edges.get(e2)?.nodes ?? new Set();
  return [...new Set([...a, ...b])];
}

export function sunflowerCheck(hg: Hypergraph): { isSunflower: boolean; core: NodeId[] } {
  const edges = [...hg.edges.values()];
  if (edges.length < 2) return { isSunflower: true, core: [] };
  let core = [...edges[0].nodes];
  for (let i = 1; i < edges.length; i++) {
    const ei = edges[i].nodes;
    core = core.filter(n => ei.has(n));
  }
  const coreSet = new Set(core);
  const isSunflower = edges.every((e, i) =>
    edges.every((f, j) => i === j || [...e.nodes].filter(n => f.nodes.has(n) && !coreSet.has(n)).length === 0)
  );
  return { isSunflower, core };
}

export function hypergraphSpectralGap(hg: Hypergraph): number {
  const n = hg.nodes.size;
  if (n < 2) return 0;
  const nodes = [...hg.nodes.keys()];
  const deg = nodes.map(v => hyperdegree(hg, v));
  const avgDeg = deg.reduce((s, d) => s + d, 0) / n;
  return avgDeg > 0 ? Math.min(...deg) / avgDeg : 0;
}


