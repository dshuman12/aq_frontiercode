import { Graph } from './graph';
import { NodeId } from './types';
import { dijkstra } from './shortest_path';

export interface HierarchicalCluster {
  id: string;
  members: NodeId[];
  left?: HierarchicalCluster;
  right?: HierarchicalCluster;
  distance: number;
  level: number;
}

export interface DendrogramNode {
  id: string;
  children: DendrogramNode[];
  members: NodeId[];
  height: number;
}

function computeDistanceMatrix(g: Graph): Map<NodeId, Map<NodeId, number>> {
  const ids = g.nodeIds();
  const dist = new Map<NodeId, Map<NodeId, number>>();
  for (const src of ids) {
    const res = dijkstra(g, src);
    const row = new Map<NodeId, number>();
    for (const tgt of ids) row.set(tgt, tgt === src ? 0 : (res.distances.get(tgt) ?? Infinity));
    dist.set(src, row);
  }
  return dist;
}

export function singleLinkageClustering(g: Graph, k: number): NodeId[][] {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n === 0) return [];
  if (k >= n) return ids.map(id => [id]);
  const dist = computeDistanceMatrix(g);
  let clusters: NodeId[][] = ids.map(id => [id]);
  while (clusters.length > k) {
    let minDist = Infinity;
    let mergeI = 0, mergeJ = 1;
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        let linkage = Infinity;
        for (const u of clusters[i]) for (const v of clusters[j]) {
          const d = dist.get(u)?.get(v) ?? Infinity;
          if (d < linkage) linkage = d;
        }
        if (linkage < minDist) { minDist = linkage; mergeI = i; mergeJ = j; }
      }
    }
    const merged = [...clusters[mergeI], ...clusters[mergeJ]];
    clusters = clusters.filter((_, idx) => idx !== mergeI && idx !== mergeJ);
    clusters.push(merged);
  }
  return clusters;
}

export function completeLinkageClustering(g: Graph, k: number): NodeId[][] {
  const ids = g.nodeIds();
  if (ids.length === 0) return [];
  if (k >= ids.length) return ids.map(id => [id]);
  const dist = computeDistanceMatrix(g);
  let clusters: NodeId[][] = ids.map(id => [id]);
  while (clusters.length > k) {
    let minDist = Infinity;
    let mergeI = 0, mergeJ = 1;
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        let linkage = -Infinity;
        for (const u of clusters[i]) for (const v of clusters[j]) {
          const d = dist.get(u)?.get(v) ?? Infinity;
          if (d < Infinity && d > linkage) linkage = d;
        }
        if (linkage < minDist) { minDist = linkage; mergeI = i; mergeJ = j; }
      }
    }
    const merged = [...clusters[mergeI], ...clusters[mergeJ]];
    clusters = clusters.filter((_, idx) => idx !== mergeI && idx !== mergeJ);
    clusters.push(merged);
  }
  return clusters;
}

export function averageLinkageClustering(g: Graph, k: number): NodeId[][] {
  const ids = g.nodeIds();
  if (ids.length === 0) return [];
  if (k >= ids.length) return ids.map(id => [id]);
  const dist = computeDistanceMatrix(g);
  let clusters: NodeId[][] = ids.map(id => [id]);
  while (clusters.length > k) {
    let minDist = Infinity;
    let mergeI = 0, mergeJ = 1;
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        let total = 0, count = 0;
        for (const u of clusters[i]) for (const v of clusters[j]) {
          const d = dist.get(u)?.get(v) ?? Infinity;
          if (d < Infinity) { total += d; count++; }
        }
        const linkage = count === 0 ? Infinity : total / count;
        if (linkage < minDist) { minDist = linkage; mergeI = i; mergeJ = j; }
      }
    }
    const merged = [...clusters[mergeI], ...clusters[mergeJ]];
    clusters = clusters.filter((_, idx) => idx !== mergeI && idx !== mergeJ);
    clusters.push(merged);
  }
  return clusters;
}

export function kMedoidsClustering(g: Graph, k: number, maxIter = 50): NodeId[][] {
  const ids = g.nodeIds();
  if (ids.length === 0) return [];
  if (k >= ids.length) return ids.map(id => [id]);
  const dist = computeDistanceMatrix(g);
  let medoids = ids.slice(0, k);
  for (let iter = 0; iter < maxIter; iter++) {
    const assignment = new Map<NodeId, number>(ids.map(id => {
      let best = 0, bestDist = Infinity;
      medoids.forEach((m, i) => { const d = dist.get(id)?.get(m) ?? Infinity; if (d < bestDist) { bestDist = d; best = i; } });
      return [id, best];
    }));
    const newMedoids = [...medoids];
    for (let i = 0; i < k; i++) {
      const cluster = ids.filter(id => assignment.get(id) === i);
      if (cluster.length === 0) continue;
      let bestMedoid = cluster[0], bestCost = Infinity;
      for (const candidate of cluster) {
        const cost = cluster.reduce((s: number, id: NodeId) => s + (dist.get(candidate)?.get(id) ?? 0), 0);
        if (cost < bestCost) { bestCost = cost; bestMedoid = candidate; }
      }
      newMedoids[i] = bestMedoid;
    }
    if (newMedoids.every((m, i) => m === medoids[i])) break;
    medoids = newMedoids;
  }
  const assignment = new Map<NodeId, number>(ids.map(id => {
    let best = 0, bestDist = Infinity;
    medoids.forEach((m, i) => { const d = dist.get(id)?.get(m) ?? Infinity; if (d < bestDist) { bestDist = d; best = i; } });
    return [id, best];
  }));
  return Array.from({ length: k }, (_, i) => ids.filter(id => assignment.get(id) === i));
}

export function clusterSilhouette(g: Graph, clusters: NodeId[][]): number {
  const dist = computeDistanceMatrix(g);
  const assignment = new Map<NodeId, number>();
  clusters.forEach((cl, i) => cl.forEach(id => assignment.set(id, i)));
  let totalS = 0; let count = 0;
  for (const [id, ci] of assignment) {
    const own = clusters[ci].filter(v => v !== id);
    if (own.length === 0) continue;
    const a = own.reduce((s: number, v: NodeId) => s + (dist.get(id)?.get(v) ?? 0), 0) / own.length;
    let b = Infinity;
    for (let j = 0; j < clusters.length; j++) {
      if (j === ci) continue;
      if (clusters[j].length === 0) continue;
      const avg = clusters[j].reduce((s: number, v: NodeId) => s + (dist.get(id)?.get(v) ?? 0), 0) / clusters[j].length;
      if (avg < b) b = avg;
    }
    if (b === Infinity) continue;
    totalS += (b - a) / Math.max(a, b);
    count++;
  }
  return count === 0 ? 0 : totalS / count;
}

export function clusterDensity(g: Graph, cluster: NodeId[]): number {
  if (cluster.length < 2) return 0;
  let edges = 0;
  const set = new Set(cluster);
  for (const u of cluster) for (const v of g.neighbors(u)) if (set.has(v)) edges++;
  const maxEdges = cluster.length * (cluster.length - 1);
  return maxEdges === 0 ? 0 : edges / maxEdges;
}

export function interClusterEdges(g: Graph, c1: NodeId[], c2: NodeId[]): number {
  const set2 = new Set(c2);
  let count = 0;
  for (const u of c1) for (const v of g.neighbors(u)) if (set2.has(v)) count++;
  return count;
}

export function clusterConductance(g: Graph, cluster: NodeId[]): number {
  const set = new Set(cluster);
  let internal = 0, external = 0;
  for (const u of cluster) {
    for (const v of g.neighbors(u)) {
      if (set.has(v)) internal++;
      else external++;
    }
  }
  const vol = internal + external;
  return vol === 0 ? 0 : external / vol;
}

export function optimalClusters(g: Graph, maxK = 5): number {
  const ids = g.nodeIds();
  if (ids.length < 2) return 1;
  let bestK = 1, bestScore = -Infinity;
  for (let k = 1; k <= Math.min(maxK, ids.length); k++) {
    const clusters = singleLinkageClustering(g, k);
    const score = k === 1 ? 0 : clusterSilhouette(g, clusters);
    if (score > bestScore) { bestScore = score; bestK = k; }
  }
  return bestK;
}


