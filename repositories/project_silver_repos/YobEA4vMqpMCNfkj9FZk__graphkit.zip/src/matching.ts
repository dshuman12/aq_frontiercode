import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

export interface MatchingResult {
  matching: Map<NodeId, NodeId>;
  size: number;
  weight: number;
  isPerfect: boolean;
}

export interface StableMatchingResult {
  matching: Map<NodeId, NodeId>;
  isStable: boolean;
  size: number;
}

function augment(g: Graph, u: NodeId, matched: Map<NodeId, NodeId>, visited: Set<NodeId>): boolean {
  for (const v of g.neighbors(u)) {
    if (!visited.has(v)) {
      visited.add(v);
      if (!matched.has(v) || augment(g, matched.get(v)!, matched, visited)) {
        matched.set(v, u);
        matched.set(u, v);
        return true;
      }
    }
  }
  return false;
}

export function maximumMatching(g: Graph): MatchingResult {
  const matched = new Map<NodeId, NodeId>();
  for (const u of g.nodeIds()) {
    if (!matched.has(u)) {
      augment(g, u, matched, new Set([u]));
    }
  }
  const seen = new Set<string>();
  const finalMatching = new Map<NodeId, NodeId>();
  for (const [u, v] of matched) {
    const key = [u, v].sort().join('|');
    if (!seen.has(key)) {
      seen.add(key);
      finalMatching.set(u, v);
    }
  }
  const size = finalMatching.size;
  const isPerfect = size * 2 === g.nodeCount() && g.nodeCount() > 0;
  return { matching: finalMatching, size, weight: size, isPerfect };
}

export function maximumWeightMatching(g: Graph): MatchingResult {
  const edges = g.edges().sort((a, b) => (b.weight ?? 1) - (a.weight ?? 1));
  const matched = new Map<NodeId, NodeId>();
  const inMatching = new Set<NodeId>();
  let totalWeight = 0;
  for (const e of edges) {
    if (!inMatching.has(e.source) && !inMatching.has(e.target)) {
      matched.set(e.source, e.target);
      inMatching.add(e.source);
      inMatching.add(e.target);
      totalWeight += typeof e.weight === 'number' ? e.weight : 1;
    }
  }
  return { matching: matched, size: matched.size, weight: totalWeight, isPerfect: matched.size * 2 === g.nodeCount() };
}

export function perfectMatching(g: Graph): MatchingResult | null {
  if (g.nodeCount() % 2 !== 0) return null;
  const result = maximumMatching(g);
  return result.isPerfect ? result : null;
}

export function matchingNumber(g: Graph): number {
  return maximumMatching(g).size;
}

export function isMatchingValid(g: Graph, matching: Map<NodeId, NodeId>): boolean {
  const seen = new Set<NodeId>();
  for (const [u, v] of matching) {
    if (seen.has(u) || seen.has(v)) return false;
    if (!g.hasEdge(u, v)) return false;
    seen.add(u);
    seen.add(v);
  }
  return true;
}

export function stableMatching(
  proposers: NodeId[],
  receivers: NodeId[],
  proposerPrefs: Map<NodeId, NodeId[]>,
  receiverPrefs: Map<NodeId, NodeId[]>
): StableMatchingResult {
  const freeProposes = [...proposers];
  const engaged = new Map<NodeId, NodeId>();
  const current = new Map<NodeId, number>(proposers.map(p => [p, 0]));
  const receiverRank = new Map<NodeId, Map<NodeId, number>>();
  for (const r of receivers) {
    const prefs = receiverPrefs.get(r) ?? [];
    const rank = new Map<NodeId, number>();
    prefs.forEach((p, i) => rank.set(p, i));
    receiverRank.set(r, rank);
  }
  while (freeProposes.length > 0) {
    const p = freeProposes[0];
    const prefs = proposerPrefs.get(p) ?? [];
    const idx = current.get(p) ?? 0;
    if (idx >= prefs.length) { freeProposes.shift(); continue; }
    const r = prefs[idx];
    current.set(p, idx + 1);
    if (!engaged.has(r)) {
      engaged.set(r, p);
      engaged.set(p, r);
      freeProposes.shift();
    } else {
      const currentP = engaged.get(r)!;
      const rank = receiverRank.get(r)!;
      if ((rank.get(p) ?? Infinity) < (rank.get(currentP) ?? Infinity)) {
        engaged.set(r, p);
        engaged.set(p, r);
        engaged.delete(currentP);
        freeProposes.shift();
        freeProposes.push(currentP);
      }
    }
  }
  const matching = new Map<NodeId, NodeId>();
  for (const r of receivers) {
    if (engaged.has(r)) { const p = engaged.get(r)!; matching.set(p, r); }
  }
  return { matching, isStable: true, size: matching.size };
}

export function augmentingPathExists(g: Graph, matching: Map<NodeId, NodeId>): boolean {
  const unmatched = g.nodeIds().filter(n => !matching.has(n));
  for (const start of unmatched) {
    const visited = new Set<NodeId>();
    const queue = [start];
    while (queue.length > 0) {
      const u = queue.shift()!;
      if (visited.has(u)) continue;
      visited.add(u);
      for (const v of g.neighbors(u)) {
        if (!matching.has(v) && v !== start) return true;
        if (matching.has(v) && !visited.has(v)) queue.push(matching.get(v)!);
      }
    }
  }
  return false;
}

export function edgeCover(g: Graph): [NodeId, NodeId][] {
  const result = maximumMatching(g);
  const cover: [NodeId, NodeId][] = [];
  const covered = new Set<NodeId>();
  for (const [u, v] of result.matching) { cover.push([u, v]); covered.add(u); covered.add(v); }
  for (const n of g.nodeIds()) {
    if (!covered.has(n)) {
      const nbrs = g.neighbors(n);
      if (nbrs.length > 0) { cover.push([n, nbrs[0]]); covered.add(n); }
    }
  }
  return cover;
}


