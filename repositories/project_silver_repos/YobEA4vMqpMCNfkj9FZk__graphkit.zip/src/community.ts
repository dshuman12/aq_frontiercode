import { Graph } from './graph';
import { NodeId } from './types';

export interface CommunityResult {
  communities: NodeId[][];
  nodeToComm: Map<NodeId, number>;
  modularity: number;
  iterations: number;
}

function computeQ(
  g: Graph,
  nodeToComm: Map<NodeId, number>
): number {
  const m = g.edges().reduce((s, e) => s + (typeof e.weight === 'number' ? e.weight : 1), 0);
  if (m === 0) return 0;
  let Q = 0;

  for (const edge of g.edges()) {
    const ci = nodeToComm.get(edge.source);
    const cj = nodeToComm.get(edge.target);
    if (ci === cj) {
      const w = typeof edge.weight === 'number' ? edge.weight : 1;
      const ki = g.degree(edge.source);
      const kj = g.degree(edge.target);
      Q += w - (ki * kj) / (2 * m);
    }
  }

  return Q / m;
}

function deltaModularity(
  g: Graph,
  node: NodeId,
  targetComm: Set<NodeId>,
  nodeToComm: Map<NodeId, number>,
  m: number
): number {
  let k_i_in = 0;
  let sigma_tot = 0;
  const k_i = g.degree(node);

  for (const nb of g.neighbors(node)) {
    if (targetComm.has(nb)) {
      k_i_in += typeof g.getEdge(node, nb).weight === 'number'
        ? g.getEdge(node, nb).weight as number : 1;
    }
  }

  for (const id of targetComm) {
    sigma_tot += g.degree(id);
  }

  return (k_i_in / m) - (sigma_tot * k_i) / (2 * m * m);
}

export function louvain(
  g: Graph,
  maxIterations = 100
): CommunityResult {
  const nodes = g.nodeIds();
  const nodeToComm = new Map<NodeId, number>(nodes.map((id, i) => [id, i]));
  const commNodes = new Map<number, Set<NodeId>>(nodes.map((id, i) => [i, new Set([id])]));

  const m = g.edges().reduce((s, e) => s + (typeof e.weight === 'number' ? e.weight : 1), 0);
  let iterations = 0;

  for (let pass = 0; pass < maxIterations; pass++) {
    let improved = false;
    const order = [...nodes].sort(() => Math.random() - 0.5);

    for (const node of order) {
      const currentComm = nodeToComm.get(node)!;
      const currentSet = commNodes.get(currentComm)!;

      let bestDelta = 0;
      let bestComm = currentComm;

      const neighborComms = new Set<number>();
      for (const nb of g.neighbors(node)) {
        const nbComm = nodeToComm.get(nb)!;
        if (nbComm !== currentComm) neighborComms.add(nbComm);
      }

      for (const candComm of neighborComms) {
        const candSet = commNodes.get(candComm)!;
        if (!candSet) continue;

        const delta = deltaModularity(g, node, candSet, nodeToComm, m);
        if (delta > bestDelta) {
          bestDelta = delta;
          bestComm = candComm;
        }
      }

      if (bestComm !== currentComm) {
        currentSet.delete(node);
        if (currentSet.size === 0) commNodes.delete(currentComm);
        nodeToComm.set(node, bestComm);
        commNodes.get(bestComm)!.add(node);
        improved = true;
      }
    }

    iterations++;
    if (!improved) break;
  }

  const communities: NodeId[][] = [...commNodes.values()].map(s => [...s]).filter(c => c.length > 0);
  const reIndexed = new Map<NodeId, number>();
  communities.forEach((comm, i) => comm.forEach(id => reIndexed.set(id, i)));

  return {
    communities,
    nodeToComm: reIndexed,
    modularity: computeQ(g, reIndexed),
    iterations,
  };
}

export function girvanNewman(g: Graph, targetCommunities: number): CommunityResult {
  const gClone = g.clone();
  const initialComm = new Map<NodeId, number>(g.nodeIds().map((id, i) => [id, i]));
  let iterations = 0;

  const getComponents = (): NodeId[][] => {
    const visited = new Set<NodeId>();
    const comps: NodeId[][] = [];
    for (const id of gClone.nodeIds()) {
      if (visited.has(id)) continue;
      const comp: NodeId[] = [];
      const stack = [id];
      while (stack.length > 0) {
        const u = stack.pop()!;
        if (visited.has(u)) continue;
        visited.add(u); comp.push(u);
        for (const v of gClone.neighbors(u)) if (!visited.has(v)) stack.push(v);
      }
      comps.push(comp);
    }
    return comps;
  };

  const edgeBetweenness = (): Map<string, number> => {
    const btw = new Map<string, number>();
    for (const edge of gClone.edges()) btw.set(edge.id, 0);

    for (const s of gClone.nodeIds()) {
      const stack: NodeId[] = [];
      const pred = new Map<NodeId, NodeId[]>(gClone.nodeIds().map(id => [id, []]));
      const sigma = new Map(gClone.nodeIds().map(id => [id, 0]));
      const dist = new Map(gClone.nodeIds().map(id => [id, -1]));
      sigma.set(s, 1); dist.set(s, 0);

      const queue: NodeId[] = [s];
      while (queue.length > 0) {
        const v = queue.shift()!; stack.push(v);
        for (const w of gClone.neighbors(v)) {
          if (dist.get(w) === -1) { queue.push(w); dist.set(w, dist.get(v)! + 1); }
          if (dist.get(w) === dist.get(v)! + 1) { sigma.set(w, sigma.get(w)! + sigma.get(v)!); pred.get(w)!.push(v); }
        }
      }

      const delta = new Map(gClone.nodeIds().map(id => [id, 0]));
      while (stack.length > 0) {
        const w = stack.pop()!;
        for (const v of pred.get(w)!) {
          const c = (sigma.get(v)! / sigma.get(w)!) * (1 + delta.get(w)!);
          delta.set(v, delta.get(v)! + c);
          const eid = gClone.getEdge(v, w).id;
          btw.set(eid, (btw.get(eid) ?? 0) + c);
        }
      }
    }

    return btw;
  };

  while (getComponents().length < targetCommunities && gClone.edgeCount() > 0) {
    const btw = edgeBetweenness();
    let maxBtw = -1, maxEdgeId = '';
    for (const [eid, b] of btw) { if (b > maxBtw) { maxBtw = b; maxEdgeId = eid; } }
    if (maxEdgeId) gClone.removeEdgeById(maxEdgeId);
    iterations++;
  }

  const communities = getComponents();
  const nodeToComm = new Map<NodeId, number>();
  communities.forEach((c, i) => c.forEach(id => nodeToComm.set(id, i)));

  return {
    communities,
    nodeToComm,
    modularity: computeQ(g, nodeToComm),
    iterations,
  };
}

export function infomap(g: Graph): CommunityResult {
  return louvain(g);
}

export function communityQuality(g: Graph, communities: NodeId[][]): {
  modularity: number;
  conductance: number[];
  coverage: number;
} {
  const nodeToComm = new Map<NodeId, number>();
  communities.forEach((c, i) => c.forEach(id => nodeToComm.set(id, i)));

  const modularity = computeQ(g, nodeToComm);

  const conductance = communities.map((comm) => {
    const commSet = new Set(comm);
    let internal = 0, external = 0;
    for (const edge of g.edges()) {
      const inSrc = commSet.has(edge.source);
      const inTgt = commSet.has(edge.target);
      if (inSrc && inTgt) internal++;
      else if (inSrc || inTgt) external++;
    }
    const vol = internal + external;
    return vol > 0 ? external / vol : 0;
  });

  const totalEdges = g.edgeCount();
  const internalEdges = communities.reduce((sum, comm) => {
    const commSet = new Set(comm);
    return sum + g.edges().filter(e => commSet.has(e.source) && commSet.has(e.target)).length;
  }, 0);

  const coverage = totalEdges > 0 ? internalEdges / totalEdges : 0;

  return { modularity, conductance, coverage };
}


