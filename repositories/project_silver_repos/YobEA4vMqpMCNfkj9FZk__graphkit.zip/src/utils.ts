import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

export function range(n: number): number[] { return Array.from({ length: n }, (_, i) => i); }

export function shuffle<T>(arr: T[], seed = 42): T[] {
  const a = [...arr];
  let s = seed;
  const rand = () => { s = (s * 1664525 + 1013904223) & 0xffffffff; return Math.abs(s) / 0x80000000; };
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

export function sample<T>(arr: T[], k: number, seed = 42): T[] {
  return shuffle(arr, seed).slice(0, Math.min(k, arr.length));
}

export function groupBy<T>(arr: T[], fn: (x: T) => string): Record<string, T[]> {
  const result: Record<string, T[]> = {};
  for (const x of arr) { const k = fn(x); (result[k] = result[k] ?? []).push(x); }
  return result;
}

export function unique<T>(arr: T[]): T[] { return [...new Set(arr)]; }

export function flatten<T>(arr: T[][]): T[] { return arr.reduce((a, b) => [...a, ...b], []); }

export function zip<A, B>(a: A[], b: B[]): [A, B][] {
  return a.slice(0, Math.min(a.length, b.length)).map((v, i) => [v, b[i]]);
}

export function product<A, B>(a: A[], b: B[]): [A, B][] {
  return a.flatMap(x => b.map(y => [x, y] as [A, B]));
}

export function clamp(v: number, lo: number, hi: number): number { return Math.max(lo, Math.min(hi, v)); }

export function lerp(a: number, b: number, t: number): number { return a + (b - a) * clamp(t, 0, 1); }

export function sumBy<T>(arr: T[], fn: (x: T) => number): number { return arr.reduce((s, x) => s + fn(x), 0); }

export function maxBy<T>(arr: T[], fn: (x: T) => number): T | undefined {
  if (arr.length === 0) return undefined;
  return arr.reduce((best, x) => fn(x) > fn(best) ? x : best);
}

export function minBy<T>(arr: T[], fn: (x: T) => number): T | undefined {
  if (arr.length === 0) return undefined;
  return arr.reduce((best, x) => fn(x) < fn(best) ? x : best);
}

export function countBy<T>(arr: T[], fn: (x: T) => string): Map<string, number> {
  const map = new Map<string, number>();
  for (const x of arr) { const k = fn(x); map.set(k, (map.get(k) ?? 0) + 1); }
  return map;
}

export function sortBy<T>(arr: T[], fn: (x: T) => number, desc = false): T[] {
  return [...arr].sort((a, b) => desc ? fn(b) - fn(a) : fn(a) - fn(b));
}

export function partition2<T>(arr: T[], pred: (x: T) => boolean): [T[], T[]] {
  const yes: T[] = [], no: T[] = [];
  for (const x of arr) (pred(x) ? yes : no).push(x);
  return [yes, no];
}

export function intersect<T>(a: T[], b: T[]): T[] {
  const sb = new Set(b);
  return a.filter(x => sb.has(x));
}

export function difference<T>(a: T[], b: T[]): T[] {
  const sb = new Set(b);
  return a.filter(x => !sb.has(x));
}

export function union<T>(a: T[], b: T[]): T[] { return unique([...a, ...b]); }

export function combinations<T>(arr: T[], k: number): T[][] {
  if (k === 0) return [[]];
  if (arr.length < k) return [];
  const [first, ...rest] = arr;
  return [...combinations(rest, k - 1).map(c => [first, ...c]), ...combinations(rest, k)];
}

export function permutations<T>(arr: T[]): T[][] {
  if (arr.length <= 1) return [arr];
  return arr.flatMap((x, i) => permutations(arr.filter((_, j) => j !== i)).map(p => [x, ...p]));
}

export function nodeSetEqual(a: NodeId[], b: NodeId[]): boolean {
  if (a.length !== b.length) return false;
  const sa = new Set(a.map(String));
  return b.every(x => sa.has(String(x)));
}

export function edgeSetEqual(g1: Graph, g2: Graph): boolean {
  if (g1.edgeCount() !== g2.edgeCount()) return false;
  for (const e of g1.edges()) if (!g2.hasEdge(e.source, e.target)) return false;
  return true;
}

export function graphEquals(g1: Graph, g2: Graph): boolean {
  return nodeSetEqual(g1.nodeIds(), g2.nodeIds()) && edgeSetEqual(g1, g2);
}

export function mapToObject<K extends string, V>(m: Map<K, V>): Record<K, V> {
  const obj = {} as Record<K, V>;
  for (const [k, v] of m) obj[k] = v;
  return obj;
}

export function objectToMap<K extends string, V>(obj: Record<K, V>): Map<K, V> {
  return new Map(Object.entries(obj) as [K, V][]);
}

export function deepClone<T>(obj: T): T { return JSON.parse(JSON.stringify(obj)); }

export function memoize<TArgs extends unknown[], TResult>(fn: (...args: TArgs) => TResult): (...args: TArgs) => TResult {
  const cache = new Map<string, TResult>();
  return (...args: TArgs) => {
    const key = JSON.stringify(args);
    if (cache.has(key)) return cache.get(key)!;
    const result = fn(...args);
    cache.set(key, result);
    return result;
  };
}

export function timer<T>(fn: () => T): { result: T; elapsed: number } {
  const start = Date.now();
  const result = fn();
  return { result, elapsed: Date.now() - start };
}


