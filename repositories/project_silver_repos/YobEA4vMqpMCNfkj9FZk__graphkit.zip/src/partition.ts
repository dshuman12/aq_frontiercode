import { Graph } from './graph';
import { NodeId } from './types';

export interface Partition {
  parts: NodeId[][];
  nodeToPartition: Map<NodeId, number>;
  cutEdges: number;
  modularity: number;
}

export function kernighanLin(g: Graph, maxIterations = 10): Partition {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n < 2) return { parts: [ids, []], nodeToPartition: new Map(ids.map(id => [id, 0])), cutEdges: 0, modularity: 0 };

  const half = Math.floor(n / 2);
  let partA = new Set(ids.slice(0, half));
  let partB = new Set(ids.slice(half));

  const D = (u: NodeId, part: Set<NodeId>): number => {
    let ext = 0, int2 = 0;
    for (const v of g.neighbors(u)) {
      const w = typeof g.getEdge(u, v).weight === 'number' ? g.getEdge(u, v).weight as number : 1;
      if (part.has(v)) int2 += w; else ext += w;
    }
    return ext - int2;
  };

  for (let iter = 0; iter < maxIterations; iter++) {
    const locked = new Set<NodeId>();
    let bestGain = -Infinity;
    let bestA = [...partA][0], bestB = [...partB][0];

    for (let step = 0; step < Math.min(partA.size, partB.size); step++) {
      let maxGain = -Infinity;
      let candA: NodeId = ids[0], candB: NodeId = ids[0];

      for (const a of partA) {
        if (locked.has(a)) continue;
        for (const b of partB) {
          if (locked.has(b)) continue;
          const cab = g.hasEdge(a, b) ? (typeof g.getEdge(a, b).weight === 'number' ? g.getEdge(a, b).weight as number : 1) : 0;
          const gain = D(a, partA) + D(b, partB) - 2 * cab;
          if (gain > maxGain) { maxGain = gain; candA = a; candB = b; }
        }
      }

      if (maxGain > bestGain) { bestGain = maxGain; bestA = candA; bestB = candB; }
      locked.add(candA); locked.add(candB);
      partA.delete(candA); partA.add(candB);
      partB.delete(candB); partB.add(candA);
    }

    if (bestGain <= 0) break;
    partA = new Set([...partA.values()]);
    partB = new Set([...partB.values()]);
  }

  const nodeToPartition = new Map<NodeId, number>();
  for (const id of partA) nodeToPartition.set(id, 0);
  for (const id of partB) nodeToPartition.set(id, 1);

  let cutEdges = 0;
  for (const edge of g.edges()) {
    if (nodeToPartition.get(edge.source) !== nodeToPartition.get(edge.target)) cutEdges++;
  }

  return { parts: [[...partA], [...partB]], nodeToPartition, cutEdges, modularity: computeModularity(g, [[...partA], [...partB]]) };
}

export function computeModularity(g: Graph, communities: NodeId[][]): number {
  const totalDeg = g.edges().reduce((s, e) => s + 2 * (typeof e.weight === 'number' ? e.weight : 1), 0);
  if (totalDeg === 0) return 0;

  const nodeComm = new Map<NodeId, number>();
  communities.forEach((c, i) => c.forEach(id => nodeComm.set(id, i)));

  let Q = 0;
  for (const edge of g.edges()) {
    const ci = nodeComm.get(edge.source), cj = nodeComm.get(edge.target);
    if (ci === cj) {
      const w = typeof edge.weight === 'number' ? edge.weight : 1;
      const ki = g.degree(edge.source), kj = g.degree(edge.target);
      Q += w - (ki * kj) / totalDeg;
    }
  }
  return (2 / totalDeg) * Q;
}

export function labelPropagation(g: Graph, maxIterations = 100): NodeId[][] {
  const label = new Map<NodeId, NodeId>(g.nodeIds().map(id => [id, id]));

  for (let iter = 0; iter < maxIterations; iter++) {
    let changed = false;
    const order = [...g.nodeIds()].sort(() => Math.random() - 0.5);

    for (const u of order) {
      const nbs = g.neighbors(u);
      if (nbs.length === 0) continue;

      const freq = new Map<NodeId, number>();
      for (const v of nbs) {
        const l = label.get(v)!;
        freq.set(l, (freq.get(l) ?? 0) + (typeof g.getEdge(u, v).weight === 'number' ? g.getEdge(u, v).weight as number : 1));
      }

      let maxFreq = -1;
      let bestLabel: NodeId = label.get(u)!;
      for (const [l, f] of freq) { if (f > maxFreq) { maxFreq = f; bestLabel = l; } }

      if (bestLabel !== label.get(u)) { label.set(u, bestLabel); changed = true; }
    }

    if (!changed) break;
  }

  const communities = new Map<NodeId, NodeId[]>();
  for (const [id, l] of label) {
    if (!communities.has(l)) communities.set(l, []);
    communities.get(l)!.push(id);
  }

  return [...communities.values()];
}


