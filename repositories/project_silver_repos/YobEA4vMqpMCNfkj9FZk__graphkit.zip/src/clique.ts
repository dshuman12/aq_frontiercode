import { Graph } from './graph';
import { NodeId } from './types';

export function bronKerbosch(g: Graph): NodeId[][] {
  const cliques: NodeId[][] = [];

  const bk = (R: Set<NodeId>, P: Set<NodeId>, X: Set<NodeId>): void => {
    if (P.size === 0 && X.size === 0) {
      if (R.size > 0) cliques.push([...R]);
      return;
    }

    const pivot = [...P, ...X].reduce((best, v) => {
      const nb = new Set(g.neighbors(v));
      const bestNb = new Set(g.neighbors(best));
      return [...P].filter(u => nb.has(u)).length > [...P].filter(u => bestNb.has(u)).length ? v : best;
    });

    const pivotNb = new Set(g.neighbors(pivot));
    const candidates = [...P].filter(v => !pivotNb.has(v));

    for (const v of candidates) {
      const nb = new Set(g.neighbors(v));
      bk(
        new Set([...R, v]),
        new Set([...P].filter(u => nb.has(u))),
        new Set([...X].filter(u => nb.has(u)))
      );
      P.delete(v);
      X.add(v);
    }
  };

  bk(new Set(), new Set(g.nodeIds()), new Set());
  return cliques;
}

export function maxClique(g: Graph): NodeId[] {
  const cliques = bronKerbosch(g);
  return cliques.reduce((best, c) => c.length > best.length ? c : best, []);
}

export function cliqueNumber(g: Graph): number {
  return maxClique(g).length;
}

export function allMaximalCliques(g: Graph): NodeId[][] {
  return bronKerbosch(g);
}

export function isClique(g: Graph, nodes: NodeId[]): boolean {
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      if (!g.hasEdge(nodes[i], nodes[j])) return false;
    }
  }
  return true;
}

export function independentSets(g: Graph): NodeId[][] {
  return bronKerbosch(g.complement());
}

export function maximumIndependentSet(g: Graph): NodeId[] {
  return maxClique(g.complement());
}

export function independenceNumber(g: Graph): number {
  return maximumIndependentSet(g).length;
}

export function vertexCover(g: Graph): NodeId[] {
  const mis = maximumIndependentSet(g);
  const misSet = new Set(mis);
  return g.nodeIds().filter(id => !misSet.has(id));
}


