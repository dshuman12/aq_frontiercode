import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { bfsLevels } from './traversal';

type AnyGraph = Graph | DiGraph;

export interface LayoutOptions {
  width?: number;
  height?: number;
  margin?: number;
}

export interface NodePosition {
  x: number;
  y: number;
}

export function circularLayout(
  g: AnyGraph,
  options: LayoutOptions = {}
): Map<NodeId, NodePosition> {
  const { width = 40, height = 20 } = options;
  const nodes = g.nodeIds();
  const n = nodes.length;
  const positions = new Map<NodeId, NodePosition>();

  if (n === 0) return positions;

  const cx = width / 2;
  const cy = height / 2;
  const rx = (width - 4) / 2;
  const ry = (height - 2) / 2;

  for (let i = 0; i < n; i++) {
    const angle = (2 * Math.PI * i) / n;
    positions.set(nodes[i], {
      x: Math.round(cx + rx * Math.cos(angle)),
      y: Math.round(cy + ry * Math.sin(angle)),
    });
  }

  return positions;
}

export function hierarchicalLayout(
  g: AnyGraph,
  root?: NodeId,
  options: LayoutOptions = {}
): Map<NodeId, NodePosition> {
  const { width = 60, height = 20 } = options;
  const positions = new Map<NodeId, NodePosition>();
  const start = root ?? g.nodeIds()[0];
  if (!start) return positions;

  const levels = bfsLevels(g, start);

  levels.forEach((level, depth) => {
    const y = Math.round((depth / Math.max(levels.length - 1, 1)) * (height - 1));
    level.forEach((id, i) => {
      const x = Math.round(((i + 1) / (level.length + 1)) * (width - 1));
      positions.set(id, { x, y });
    });
  });

  return positions;
}

export function forceDirectedLayout(
  g: AnyGraph,
  options: LayoutOptions = {},
  iterations = 50
): Map<NodeId, NodePosition> {
  const { width = 60, height = 30 } = options;
  const nodes = g.nodeIds();
  const n = nodes.length;
  const positions = new Map<NodeId, NodePosition>();

  for (let i = 0; i < n; i++) {
    positions.set(nodes[i], {
      x: Math.random() * width,
      y: Math.random() * height,
    });
  }

  const k = Math.sqrt((width * height) / Math.max(n, 1));

  for (let iter = 0; iter < iterations; iter++) {
    const displacement = new Map<NodeId, { dx: number; dy: number }>(
      nodes.map(id => [id, { dx: 0, dy: 0 }])
    );

    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        if (i === j) continue;
        const pi = positions.get(nodes[i])!;
        const pj = positions.get(nodes[j])!;
        const dx = pi.x - pj.x;
        const dy = pi.y - pj.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 0.01;
        const repForce = (k * k) / dist;
        const disp = displacement.get(nodes[i])!;
        disp.dx += (dx / dist) * repForce;
        disp.dy += (dy / dist) * repForce;
      }
    }

    for (const edge of g.edges()) {
      const pu = positions.get(edge.source)!;
      const pv = positions.get(edge.target)!;
      const dx = pu.x - pv.x;
      const dy = pu.y - pv.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 0.01;
      const attrForce = (dist * dist) / k;
      const dispU = displacement.get(edge.source)!;
      const dispV = displacement.get(edge.target)!;
      const fdx = (dx / dist) * attrForce;
      const fdy = (dy / dist) * attrForce;
      dispU.dx -= fdx;
      dispU.dy -= fdy;
      dispV.dx += fdx;
      dispV.dy += fdy;
    }

    const temp = width / (iter + 1);
    for (const id of nodes) {
      const disp = displacement.get(id)!;
      const mag = Math.sqrt(disp.dx * disp.dx + disp.dy * disp.dy) || 0.01;
      const p = positions.get(id)!;
      p.x = Math.max(1, Math.min(width - 1, p.x + (disp.dx / mag) * Math.min(mag, temp)));
      p.y = Math.max(1, Math.min(height - 1, p.y + (disp.dy / mag) * Math.min(mag, temp)));
    }
  }

  for (const [id, pos] of positions) {
    positions.set(id, { x: Math.round(pos.x), y: Math.round(pos.y) });
  }

  return positions;
}

export function renderASCII(
  g: AnyGraph,
  positions: Map<NodeId, NodePosition>,
  options: LayoutOptions = {}
): string {
  const { width = 60, height = 20 } = options;
  const grid: string[][] = Array.from({ length: height }, () => new Array(width).fill(' '));

  const directedArrow = g instanceof DiGraph ? '>' : '-';

  for (const edge of g.edges()) {
    const pu = positions.get(edge.source);
    const pv = positions.get(edge.target);
    if (!pu || !pv) continue;

    let x0 = pu.x, y0 = pu.y, x1 = pv.x, y1 = pv.y;
    const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx - dy;
    let cx = x0, cy = y0;

    while (cx !== x1 || cy !== y1) {
      const gx = Math.round(cx), gy = Math.round(cy);
      if (gx >= 0 && gx < width && gy >= 0 && gy < height && grid[gy][gx] === ' ') {
        grid[gy][gx] = dx > dy ? '-' : '|';
      }
      const e2 = 2 * err;
      if (e2 > -dy) { err -= dy; cx += sx; }
      if (e2 < dx) { err += dx; cy += sy; }
    }
  }

  for (const [id, pos] of positions) {
    const x = Math.round(pos.x), y = Math.round(pos.y);
    if (x >= 0 && x < width && y >= 0 && y < height) {
      const label = String(id).slice(0, 1);
      grid[y][x] = label;
    }
  }

  return grid.map(row => row.join('')).join('\n');
}

export function toMermaid(g: AnyGraph, graphId = 'G'): string {
  const directed = g instanceof DiGraph;
  const lines: string[] = [directed ? `graph TD` : `graph LR`];

  const nodeIds = g.nodeIds();
  const sanitize = (id: NodeId): string => String(id).replace(/[^a-zA-Z0-9_]/g, '_');

  for (const id of nodeIds) {
    const node = g.getNode(id);
    const label = node.label ?? String(id);
    lines.push(`  ${sanitize(id)}["${label}"]`);
  }

  const seenEdges = new Set<string>();
  for (const edge of g.edges()) {
    const key = directed
      ? `${edge.source}->${edge.target}`
      : [edge.source, edge.target].sort().join('--');
    if (seenEdges.has(key)) continue;
    seenEdges.add(key);
    const arrow = directed ? '-->' : '---';
    const w = typeof edge.weight === 'number' && edge.weight !== 1
      ? `|${edge.weight}|` : '';
    lines.push(`  ${sanitize(edge.source)} ${arrow}${w} ${sanitize(edge.target)}`);
  }

  return lines.join('\n');
}

export function toGraphvizDOT(g: AnyGraph, name = 'G'): string {
  const directed = g instanceof DiGraph;
  const gkw = directed ? 'digraph' : 'graph';
  const arrow = directed ? '->' : '--';
  const lines: string[] = [`${gkw} ${name} {`, '  rankdir=LR;', '  node [shape=circle];'];

  for (const node of g.nodes()) {
    const attrs: string[] = [];
    if (node.label) attrs.push(`label="${node.label}"`);
    if (node.attributes?.color) attrs.push(`color="${node.attributes.color}"`);
    const attrStr = attrs.length ? ` [${attrs.join(', ')}]` : '';
    lines.push(`  "${node.id}"${attrStr};`);
  }

  const seenEdges = new Set<string>();
  for (const edge of g.edges()) {
    const key = directed
      ? `${edge.source}->${edge.target}`
      : [edge.source, edge.target].sort().join('--');
    if (seenEdges.has(key)) continue;
    seenEdges.add(key);
    const attrs: string[] = [];
    if (typeof edge.weight === 'number' && edge.weight !== 1) {
      attrs.push(`label="${edge.weight}"`, `weight=${edge.weight}`);
    }
    if (edge.label) attrs.push(`label="${edge.label}"`);
    const attrStr = attrs.length ? ` [${attrs.join(', ')}]` : '';
    lines.push(`  "${edge.source}" ${arrow} "${edge.target}"${attrStr};`);
  }

  lines.push('}');
  return lines.join('\n');
}

export function graphSummary(g: AnyGraph): string {
  const directed = g instanceof DiGraph;
  const n = g.nodeCount(), m = g.edgeCount();
  const density = g.density().toFixed(4);
  const deg = g.nodeIds().map(id => g.degree(id));
  const maxDeg = deg.length ? Math.max(...deg) : 0;
  const minDeg = deg.length ? Math.min(...deg) : 0;
  const avgDeg = deg.length ? (deg.reduce((s, d) => s + d, 0) / deg.length).toFixed(2) : '0';

  const lines = [
    `Graph Summary`,
    `  Type:         ${directed ? 'Directed' : 'Undirected'}`,
    `  Nodes:        ${n}`,
    `  Edges:        ${m}`,
    `  Density:      ${density}`,
    `  Degree range: ${minDeg} - ${maxDeg}`,
    `  Avg degree:   ${avgDeg}`,
  ];

  return lines.join('\n');
}


