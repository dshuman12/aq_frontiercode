import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';
import { connectedComponents, isBipartite, bridges, articulationPoints } from './components';
import { greedyColoring } from './coloring';
import { dijkstra } from './shortest_path';
import { degreeCentrality, clusteringCoefficient, diameter } from './metrics';

type AnyGraph = Graph | DiGraph;

export interface DegreeDistribution {
  histogram: Map<number, number>;
  min: number;
  max: number;
  mean: number;
  variance: number;
  stdDev: number;
  median: number;
}

export interface GraphReport {
  nodeCount: number;
  edgeCount: number;
  density: number;
  directed: boolean;
  connected: boolean;
  componentCount: number;
  largestComponentSize: number;
  averageDegree: number;
  maxDegree: number;
  minDegree: number;
  diameter: number;
  isTree: boolean;
  isBipartite: boolean;
  chromaticNumber: number;
  bridgeCount: number;
  articulationPointCount: number;
  averageClusteringCoefficient: number;
}

export function degreeDistribution(g: AnyGraph): DegreeDistribution {
  const degrees = g.nodeIds().map(id => g.degree(id));
  const n = degrees.length;

  if (n === 0) {
    return { histogram: new Map(), min: 0, max: 0, mean: 0, variance: 0, stdDev: 0, median: 0 };
  }

  const sorted = [...degrees].sort((a, b) => a - b);
  const histogram = new Map<number, number>();
  for (const d of degrees) histogram.set(d, (histogram.get(d) ?? 0) + 1);

  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  const mean = degrees.reduce((s, d) => s + d, 0) / n;
  const variance = degrees.reduce((s, d) => s + (d - mean) ** 2, 0) / n;
  const stdDev = Math.sqrt(variance);
  const mid = Math.floor(n / 2);
  const median = n % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;

  return { histogram, min, max, mean, variance, stdDev, median };
}

export function isTree(g: Graph): boolean {
  if (g.nodeCount() === 0) return true;
  if (g.edgeCount() !== g.nodeCount() - 1) return false;
  const result = connectedComponents(g);
  return result.count === 1;
}

export function findCycles(g: Graph): NodeId[][] {
  const cycles: NodeId[][] = [];
  const visited = new Set<NodeId>();
  const recStack = new Set<NodeId>();
  const parent = new Map<NodeId, NodeId | null>();

  const dfs = (u: NodeId, path: NodeId[]): void => {
    visited.add(u);
    recStack.add(u);
    path.push(u);

    for (const v of g.neighbors(u)) {
      if (!visited.has(v)) {
        parent.set(v, u);
        dfs(v, path);
      } else if (recStack.has(v) && v !== parent.get(u)) {
        const cycleStart = path.indexOf(v);
        if (cycleStart !== -1) {
          cycles.push(path.slice(cycleStart));
        }
      }
    }

    path.pop();
    recStack.delete(u);
  };

  for (const id of g.nodeIds()) {
    if (!visited.has(id)) {
      parent.set(id, null);
      dfs(id, []);
    }
  }

  return cycles;
}

export function eccentricity(g: Graph): Map<NodeId, number> {
  const result = new Map<NodeId, number>();
  const INFINITY = Number.POSITIVE_INFINITY;

  for (const id of g.nodeIds()) {
    const { distances } = dijkstra(g, id);
    let maxDist = 0;
    for (const [nid, d] of distances) {
      if (nid !== id && d < INFINITY) maxDist = Math.max(maxDist, d);
    }
    result.set(id, maxDist);
  }

  return result;
}

export function center(g: Graph): NodeId[] {
  const ecc = eccentricity(g);
  const rad = Math.min(...ecc.values());
  return [...ecc.entries()].filter(([, e]) => e === rad).map(([id]) => id);
}

export function periphery(g: Graph): NodeId[] {
  const ecc = eccentricity(g);
  const diam = Math.max(...ecc.values());
  return [...ecc.entries()].filter(([, e]) => e === diam).map(([id]) => id);
}

export function girth(g: Graph): number {
  let minCycle = Infinity;

  for (const start of g.nodeIds()) {
    const dist = new Map<NodeId, number>([[start, 0]]);
    const parent = new Map<NodeId, NodeId | null>([[start, null]]);
    const queue: NodeId[] = [start];

    while (queue.length > 0) {
      const u = queue.shift()!;
      for (const v of g.neighbors(u)) {
        if (!dist.has(v)) {
          dist.set(v, dist.get(u)! + 1);
          parent.set(v, u);
          queue.push(v);
        } else if (parent.get(u) !== v) {
          const cycleLen = dist.get(u)! + dist.get(v)! + 1;
          minCycle = Math.min(minCycle, cycleLen);
        }
      }
    }
  }

  return minCycle === Infinity ? 0 : minCycle;
}

export function topKCentralNodes(
  g: AnyGraph,
  k: number,
  metric: 'degree' | 'closeness' = 'degree'
): NodeId[] {
  let scores: Map<NodeId, number>;

  if (metric === 'degree') {
    scores = degreeCentrality(g);
  } else {
    scores = g instanceof Graph
      ? new Map(g.nodeIds().map(id => {
          const { distances } = dijkstra(g as Graph, id);
          const finite = [...distances.values()].filter(d => d < Infinity && d > 0);
          return [id, finite.length > 0 ? finite.length / finite.reduce((s, d) => s + d, 0) : 0];
        }))
      : degreeCentrality(g);
  }

  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, k)
    .map(([id]) => id);
}

export function generateReport(g: Graph): GraphReport {
  const comp = connectedComponents(g);
  const directed = false;
  const bip = isBipartite(g).bipartite;
  const coloring = greedyColoring(g);
  const brs = bridges(g);
  const aps = articulationPoints(g);
  const cc = clusteringCoefficient(g);
  const avgCC = g.nodeCount() > 0
    ? [...cc.values()].reduce((s, v) => s + v, 0) / g.nodeCount()
    : 0;
  const deg = g.nodeIds().map(id => g.degree(id));
  const maxDeg = deg.length ? Math.max(...deg) : 0;
  const minDeg = deg.length ? Math.min(...deg) : 0;
  const avgDeg = deg.length ? deg.reduce((s, d) => s + d, 0) / deg.length : 0;
  const diam = comp.count === 1 ? diameter(g) : 0;

  return {
    nodeCount: g.nodeCount(),
    edgeCount: g.edgeCount(),
    density: g.density(),
    directed,
    connected: comp.count === 1,
    componentCount: comp.count,
    largestComponentSize: comp.largestComponent.length,
    averageDegree: avgDeg,
    maxDegree: maxDeg,
    minDegree: minDeg,
    diameter: diam,
    isTree: isTree(g),
    isBipartite: bip,
    chromaticNumber: coloring.chromaticNumber,
    bridgeCount: brs.length,
    articulationPointCount: aps.length,
    averageClusteringCoefficient: avgCC,
  };
}

export function compareGraphs(g1: Graph, g2: Graph): {
  sameNodeCount: boolean;
  sameEdgeCount: boolean;
  sameDensity: boolean;
  degreeDifference: number;
  reportG1: GraphReport;
  reportG2: GraphReport;
} {
  const r1 = generateReport(g1);
  const r2 = generateReport(g2);

  return {
    sameNodeCount: r1.nodeCount === r2.nodeCount,
    sameEdgeCount: r1.edgeCount === r2.edgeCount,
    sameDensity: Math.abs(r1.density - r2.density) < 1e-6,
    degreeDifference: Math.abs(r1.averageDegree - r2.averageDegree),
    reportG1: r1,
    reportG2: r2,
  };
}


