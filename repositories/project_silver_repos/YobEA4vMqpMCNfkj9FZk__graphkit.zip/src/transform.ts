import { Graph } from './graph';
import { DiGraph } from './digraph';
import { NodeId } from './types';

export function complement(g: Graph): Graph {
  const c = new Graph();
  for (const n of g.nodes()) c.addNode(n.id, n.data, n.label);
  const ids = g.nodeIds();
  for (let i = 0; i < ids.length; i++) {
    for (let j = i + 1; j < ids.length; j++) {
      if (!g.hasEdge(ids[i], ids[j])) c.addEdge(ids[i], ids[j], 1);
    }
  }
  return c;
}

export function lineGraph(g: Graph): Graph {
  const edges = g.edges();
  const lg = new Graph();
  edges.forEach(e => lg.addNode(`${e.source}-${e.target}`));
  for (let i = 0; i < edges.length; i++) {
    for (let j = i + 1; j < edges.length; j++) {
      const ei = edges[i], ej = edges[j];
      const shared = (ei.source === ej.source || ei.source === ej.target || ei.target === ej.source || ei.target === ej.target);
      if (shared) lg.addEdge(`${ei.source}-${ei.target}`, `${ej.source}-${ej.target}`, 1);
    }
  }
  return lg;
}

export function cartesianProduct(g1: Graph, g2: Graph): Graph {
  const prod = new Graph();
  for (const u of g1.nodeIds()) for (const v of g2.nodeIds()) prod.addNode(`${u},${v}`);
  for (const u of g1.nodeIds()) {
    for (const v1 of g2.nodeIds()) {
      for (const v2 of g2.nodeIds()) {
        if (g2.hasEdge(v1, v2) && !prod.hasEdge(`${u},${v1}`, `${u},${v2}`)) prod.addEdge(`${u},${v1}`, `${u},${v2}`, 1);
      }
    }
  }
  for (const v of g2.nodeIds()) {
    for (const u1 of g1.nodeIds()) {
      for (const u2 of g1.nodeIds()) {
        if (g1.hasEdge(u1, u2) && !prod.hasEdge(`${u1},${v}`, `${u2},${v}`)) prod.addEdge(`${u1},${v}`, `${u2},${v}`, 1);
      }
    }
  }
  return prod;
}

export function tensorProduct(g1: Graph, g2: Graph): Graph {
  const prod = new Graph();
  for (const u of g1.nodeIds()) for (const v of g2.nodeIds()) prod.addNode(`${u},${v}`);
  for (const e1 of g1.edges()) {
    for (const e2 of g2.edges()) {
      prod.addEdge(`${e1.source},${e2.source}`, `${e1.target},${e2.target}`, 1);
      prod.addEdge(`${e1.source},${e2.target}`, `${e1.target},${e2.source}`, 1);
    }
  }
  return prod;
}

export function inducedSubgraph(g: Graph, nodes: NodeId[]): Graph {
  const sub = new Graph();
  const nodeSet = new Set(nodes);
  for (const id of nodes) { const n = g.getNode(id); sub.addNode(id, n.data, n.label); }
  for (const e of g.edges()) {
    if (nodeSet.has(e.source) && nodeSet.has(e.target)) sub.addEdge(e.source, e.target, e.weight);
  }
  return sub;
}

export function edgeSubgraph(g: Graph, edgeIds: string[]): Graph {
  const sub = new Graph();
  const edgeSet = new Set(edgeIds);
  for (const e of g.edges()) {
    if (edgeSet.has(e.id)) {
      if (!sub.hasNode(e.source)) sub.addNode(e.source);
      if (!sub.hasNode(e.target)) sub.addNode(e.target);
      sub.addEdge(e.source, e.target, e.weight);
    }
  }
  return sub;
}

export function graphUnion(g1: Graph, g2: Graph): Graph {
  const result = g1.clone();
  for (const n of g2.nodes()) if (!result.hasNode(n.id)) result.addNode(n.id, n.data, n.label);
  for (const e of g2.edges()) if (!result.hasEdge(e.source, e.target)) result.addEdge(e.source, e.target, e.weight);
  return result;
}

export function graphIntersection(g1: Graph, g2: Graph): Graph {
  const result = new Graph();
  for (const n of g1.nodes()) if (g2.hasNode(n.id)) result.addNode(n.id, n.data, n.label);
  for (const e of g1.edges()) if (g2.hasEdge(e.source, e.target) && result.hasNode(e.source) && result.hasNode(e.target)) result.addEdge(e.source, e.target, e.weight);
  return result;
}

export function graphDifference(g1: Graph, g2: Graph): Graph {
  const result = new Graph();
  for (const n of g1.nodes()) result.addNode(n.id, n.data, n.label);
  for (const e of g1.edges()) if (!g2.hasEdge(e.source, e.target)) result.addEdge(e.source, e.target, e.weight);
  return result;
}

export function powerGraph(g: Graph, k: number): Graph {
  const ids = g.nodeIds();
  const dist = new Map<string, number>();
  for (const src of ids) {
    const queue: [NodeId, number][] = [[src, 0]];
    const visited = new Set<NodeId>();
    while (queue.length > 0) {
      const [u, d] = queue.shift()!;
      if (visited.has(u)) continue;
      visited.add(u);
      dist.set(`${src}:${u}`, d);
      if (d < k) for (const nb of g.neighbors(u)) if (!visited.has(nb)) queue.push([nb, d + 1]);
    }
  }
  const result = new Graph();
  for (const id of ids) result.addNode(id);
  for (const u of ids) for (const v of ids) {
    if (u !== v && (dist.get(`${u}:${v}`) ?? Infinity) <= k && !result.hasEdge(u, v)) result.addEdge(u, v, 1);
  }
  return result;
}

export function subdivide(g: Graph): Graph {
  const result = new Graph();
  for (const n of g.nodes()) result.addNode(n.id, n.data, n.label);
  let eid = 0;
  for (const e of g.edges()) {
    const mid = `_e${eid++}`;
    result.addNode(mid);
    result.addEdge(e.source, mid, 1);
    result.addEdge(mid, e.target, 1);
  }
  return result;
}

export function toDiGraph(g: Graph): DiGraph {
  const dg = new DiGraph();
  for (const n of g.nodes()) dg.addNode(n.id, n.data, n.label);
  for (const e of g.edges()) { dg.addEdge(e.source, e.target, e.weight); dg.addEdge(e.target, e.source, e.weight); }
  return dg;
}

export function toUndirected(dg: DiGraph): Graph {
  const g = new Graph();
  for (const n of dg.nodes()) g.addNode(n.id, n.data, n.label);
  for (const e of dg.edges()) if (!g.hasEdge(e.source, e.target)) g.addEdge(e.source, e.target, e.weight);
  return g;
}


