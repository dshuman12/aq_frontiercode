import { Graph } from './graph';
import { NodeId } from './types';
import { dijkstra } from './shortest_path';
import { bfs } from './traversal';

export function graphDistance(g: Graph, u: NodeId, v: NodeId): number {
  if (u === v) return 0;
  return dijkstra(g, u).distances.get(v) ?? Infinity;
}

export function distanceMatrix(g: Graph): { nodes: NodeId[]; matrix: number[][] } {
  const ids = g.nodeIds();
  const n = ids.length;
  const idx = new Map<NodeId, number>(ids.map((id, i) => [id, i]));
  const matrix: number[][] = Array.from({ length: n }, () => Array(n).fill(Infinity));
  for (let i = 0; i < n; i++) matrix[i][i] = 0;
  for (const src of ids) {
    const res = dijkstra(g, src);
    const i = idx.get(src)!;
    for (const tgt of ids) {
      const j = idx.get(tgt)!;
      matrix[i][j] = res.distances.get(tgt) ?? Infinity;
    }
  }
  return { nodes: ids, matrix };
}

export function averagePathLength(g: Graph): number {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n < 2) return 0;
  let sum = 0; let count = 0;
  for (const src of ids) {
    const res = dijkstra(g, src);
    for (const tgt of ids) {
      if (tgt !== src) {
        const d = res.distances.get(tgt) ?? Infinity;
        if (d < Infinity) { sum += d; count++; }
      }
    }
  }
  return count === 0 ? Infinity : sum / count;
}

export function hopDistance(g: Graph, u: NodeId, v: NodeId): number {
  if (u === v) return 0;
  const res = bfs(g, u);
  return res.depth.get(v) ?? Infinity;
}

export function wienerIndex(g: Graph): number {
  const ids = g.nodeIds();
  let sum = 0;
  for (let i = 0; i < ids.length; i++) {
    const res = dijkstra(g, ids[i]);
    for (let j = i + 1; j < ids.length; j++) {
      const d = res.distances.get(ids[j]) ?? 0;
      if (d < Infinity) sum += d;
    }
  }
  return sum;
}

export function graphEditDistance(g1: Graph, g2: Graph): number {
  const ids1 = new Set(g1.nodeIds());
  const ids2 = new Set(g2.nodeIds());
  const allNodes = new Set([...ids1, ...ids2]);
  let cost = 0;
  for (const n of allNodes) {
    if (!ids1.has(n)) cost++;
    else if (!ids2.has(n)) cost++;
  }
  const commonNodes = [...allNodes].filter(n => ids1.has(n) && ids2.has(n));
  for (let i = 0; i < commonNodes.length; i++) {
    for (let j = i + 1; j < commonNodes.length; j++) {
      const u = commonNodes[i], v = commonNodes[j];
      const inG1 = g1.hasEdge(u, v);
      const inG2 = g2.hasEdge(u, v);
      if (inG1 !== inG2) cost++;
    }
  }
  return cost;
}

export function resistanceDistance(g: Graph, u: NodeId, v: NodeId): number {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n === 0) return Infinity;
  const idx = new Map<NodeId, number>(ids.map((id, i) => [id, i]));
  const L: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (const id of ids) {
    const i = idx.get(id)!;
    L[i][i] = g.degree(id);
    for (const nb of g.neighbors(id)) { const j = idx.get(nb)!; L[i][j] = -1; }
  }
  const eps = 1e-10;
  for (let i = 0; i < n; i++) L[i][i] += eps;
  const Gamma: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (let col = 0; col < n; col++) {
    let x = Array(n).fill(0);
    x[col] = 1;
    for (let iter = 0; iter < 100; iter++) {
      const newX = Array(n).fill(0);
      for (let i = 0; i < n; i++) {
        let rhs = x[col === i ? col : i];
        rhs = col === i ? 1 : 0;
        let sum2 = 0;
        for (let j = 0; j < n; j++) if (j !== i) sum2 += L[i][j] * x[j];
        newX[i] = L[i][i] === 0 ? 0 : (rhs - sum2) / L[i][i];
      }
      x = newX;
    }
    for (let i = 0; i < n; i++) Gamma[i][col] = x[i];
  }
  const ui = idx.get(u) ?? 0, vi = idx.get(v) ?? 0;
  return Math.max(0, Gamma[ui][ui] + Gamma[vi][vi] - Gamma[ui][vi] - Gamma[vi][ui]);
}

export function closenessCentrality(g: Graph, normalized = true): Map<NodeId, number> {
  const result = new Map<NodeId, number>();
  const n = g.nodeCount();
  for (const id of g.nodeIds()) {
    const res = dijkstra(g, id);
    let sum = 0; let reachable = 0;
    for (const [tgt, d] of res.distances) {
      if (tgt !== id && d < Infinity) { sum += d; reachable++; }
    }
    const cc = sum === 0 ? 0 : reachable / sum;
    result.set(id, normalized && n > 1 ? cc * (n - 1) / reachable || 0 : cc);
  }
  return result;
}

export function harmonicCentrality(g: Graph): Map<NodeId, number> {
  const result = new Map<NodeId, number>();
  const n = g.nodeCount();
  for (const id of g.nodeIds()) {
    const res = dijkstra(g, id);
    let sum = 0;
    for (const [tgt, d] of res.distances) {
      if (tgt !== id && d > 0 && d < Infinity) sum += 1 / d;
    }
    result.set(id, n <= 1 ? 0 : sum / (n - 1));
  }
  return result;
}

export function peripheralNodes(g: Graph): NodeId[] {
  const ids = g.nodeIds();
  if (ids.length === 0) return [];
  let maxEcc = -Infinity;
  const ecc = new Map<NodeId, number>();
  for (const id of ids) {
    const res = dijkstra(g, id);
    let e = 0;
    for (const d of res.distances.values()) if (d < Infinity && d > e) e = d;
    ecc.set(id, e);
    if (e > maxEcc) maxEcc = e;
  }
  return ids.filter(id => ecc.get(id) === maxEcc);
}

export function normalizedLaplacianSpectrum(g: Graph): number[] {
  const ids = g.nodeIds();
  const n = ids.length;
  if (n === 0) return [];
  const idx = new Map(ids.map((id, i) => [id, i]));
  const L: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  for (const id of ids) {
    const i = idx.get(id)!;
    const di = g.degree(id);
    if (di === 0) continue;
    L[i][i] = 1;
    for (const nb of g.neighbors(id)) {
      const j = idx.get(nb)!;
      const dj = g.degree(nb);
      L[i][j] = -1 / Math.sqrt(di * dj);
    }
  }
  const eigenvalues: number[] = [];
  for (let k = 0; k < Math.min(n, 5); k++) {
    let v = Array.from({ length: n }, () => Math.random());
    const norm0 = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    v = v.map(x => x / (norm0 || 1));
    for (let iter = 0; iter < 50; iter++) {
      const Lv = v.map((_, i) => L[i].reduce((s, Lij, j) => s + Lij * v[j], 0));
      const lambda = v.reduce((s, vi, i) => s + vi * Lv[i], 0);
      const norm2 = Math.sqrt(Lv.reduce((s, x) => s + x * x, 0));
      v = Lv.map(x => x / (norm2 || 1));
      if (iter === 49) eigenvalues.push(Math.max(0, lambda));
    }
  }
  return eigenvalues.sort((a, b) => a - b);
}


