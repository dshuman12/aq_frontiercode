"""Tests for the ruleset loader."""

from __future__ import annotations

from bulwark.loader import load_dir, load_sources


def test_load_single_source() -> None:
    src = 'phase pre_route { rule r { when path == "/x" then block(status=403) } }'
    res = load_sources([("a.cdn", src)])
    assert res.ok, res.diagnostics
    assert res.ruleset is not None
    assert len(res.ruleset.program.phases) == 1


def test_version_is_deterministic() -> None:
    src = 'phase pre_route { rule r { when path == "/x" then block(status=403) } }'
    a = load_sources([("a.cdn", src)])
    b = load_sources([("a.cdn", src)])
    assert a.ruleset is not None and b.ruleset is not None
    assert a.ruleset.version == b.ruleset.version


def test_version_changes_when_source_changes() -> None:
    a = load_sources([("a.cdn", 'phase pre_route { rule r { when path == "/x" then allow() } }')])
    b = load_sources([("a.cdn", 'phase pre_route { rule r { when path == "/y" then allow() } }')])
    assert a.ruleset is not None and b.ruleset is not None
    assert a.ruleset.version != b.ruleset.version


def test_parse_error_surfaces_diagnostic() -> None:
    res = load_sources([("a.cdn", "phase { rule oops")])
    assert not res.ok
    assert res.diagnostics
    assert any("a.cdn" in d.message for d in res.diagnostics)


def test_empty_input_is_an_error() -> None:
    res = load_sources([])
    assert not res.ok


def test_load_dir(tmp_path) -> None:
    (tmp_path / "z.cdn").write_text(
        'phase pre_route { rule r { when path == "/x" then allow() } }'
    )
    (tmp_path / "a.cdn").write_text(
        'phase response { rule s { when path == "/y" then tag(name="seen") } }'
    )
    (tmp_path / "skip.txt").write_text("ignored")
    res = load_dir(str(tmp_path))
    assert res.ok, res.diagnostics
    assert res.ruleset is not None
    assert len(res.ruleset.program.phases) == 2
