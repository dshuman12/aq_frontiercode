"""Tests for the circuit breaker."""

from __future__ import annotations

import pytest

from bulwark.breaker import Breaker, BreakerState
from bulwark.clock import FakeClock


def _b(clk: FakeClock, **kw) -> Breaker:
    defaults = dict(failure_threshold=3, window_size=5, cooldown_seconds=10.0, clock=clk)
    defaults.update(kw)
    return Breaker(**defaults)


def test_closed_initially() -> None:
    clk = FakeClock()
    b = _b(clk)
    assert b.state is BreakerState.CLOSED
    assert b.allow()


def test_trips_open_at_threshold() -> None:
    clk = FakeClock()
    b = _b(clk)
    b.on_failure()
    assert b.allow()
    b.on_failure()
    assert b.allow()
    b.on_failure()
    assert not b.allow()
    assert b.state is BreakerState.OPEN


def test_window_excludes_old_failures() -> None:
    clk = FakeClock()
    b = _b(clk, failure_threshold=3, window_size=4)
    b.on_failure()
    b.on_success()
    b.on_failure()
    b.on_success()
    b.on_failure()
    # Last 4: F S F S F → 2 failures, still under threshold.
    assert b.allow()


def test_half_open_after_cooldown() -> None:
    clk = FakeClock()
    b = _b(clk, cooldown_seconds=5.0)
    b.on_failure()
    b.on_failure()
    b.on_failure()
    assert b.state is BreakerState.OPEN
    clk.advance(5.1)
    assert b.state is BreakerState.HALF_OPEN
    assert b.allow()


def test_half_open_success_closes() -> None:
    clk = FakeClock()
    b = _b(clk, cooldown_seconds=1.0)
    for _ in range(3):
        b.on_failure()
    clk.advance(1.1)
    assert b.allow()  # half-open
    b.on_success()
    assert b.state is BreakerState.CLOSED


def test_half_open_failure_reopens_with_fresh_cooldown() -> None:
    clk = FakeClock()
    b = _b(clk, cooldown_seconds=1.0)
    for _ in range(3):
        b.on_failure()
    clk.advance(1.1)
    assert b.state is BreakerState.HALF_OPEN
    b.on_failure()
    assert b.state is BreakerState.OPEN
    # Cooldown should be fresh -- t+0.5s shouldn't half-open yet.
    clk.advance(0.5)
    assert b.state is BreakerState.OPEN
    clk.advance(0.6)
    assert b.state is BreakerState.HALF_OPEN


def test_validates_inputs() -> None:
    clk = FakeClock()
    with pytest.raises(ValueError):
        Breaker(failure_threshold=0, window_size=5, cooldown_seconds=1.0, clock=clk)
    with pytest.raises(ValueError):
        Breaker(failure_threshold=5, window_size=2, cooldown_seconds=1.0, clock=clk)
    with pytest.raises(ValueError):
        Breaker(failure_threshold=2, window_size=5, cooldown_seconds=0.0, clock=clk)
