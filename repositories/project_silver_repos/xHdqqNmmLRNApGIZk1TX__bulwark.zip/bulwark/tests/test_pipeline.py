"""Tests for the request pipeline."""

from __future__ import annotations

import pytest

from bulwark.audit import AuditEmitter
from bulwark.breaker import Breaker
from bulwark.chainlog import ChainLog
from bulwark.clock import FakeClock
from bulwark.headers import Headers
from bulwark.loader import load_sources
from bulwark.pipeline import Pipeline
from bulwark.pool import Pool
from bulwark.proxy import Proxy
from bulwark.reload import Coordinator
from bulwark.trust import TrustConfig
from bulwark.upstream import Endpoint, Upstream


def _coord(rule_src: str) -> Coordinator:
    res = load_sources([("a.cdn", rule_src)])
    assert res.ok, res.diagnostics
    c = Coordinator()
    c.install(res.ruleset)
    return c


def _audit() -> tuple[ChainLog, AuditEmitter, FakeClock]:
    chain = ChainLog()
    clk = FakeClock()
    return chain, AuditEmitter(chain=chain, clock=clk), clk


def _proxy(clk: FakeClock) -> Proxy[str]:
    upstream = Upstream(name="api", endpoints=(Endpoint("a", 80),), strategy="round_robin")
    pool: Pool[str] = Pool(clock=clk)
    breaker = Breaker(failure_threshold=3, window_size=5, cooldown_seconds=10.0, clock=clk)
    return Proxy(
        upstream=upstream,
        pool=pool,
        breaker=breaker,
        materialize=lambda ep: f"handle-{ep.address()}",
    )


def test_block_short_circuits_proxy() -> None:
    coord = _coord(
        'phase pre_route { rule deny { '
        'when path == "/admin" then block(status=403) } }'
    )
    chain, audit, clk = _audit()
    p = Pipeline(coordinator=coord, audit=audit, proxy=_proxy(clk), trust=TrustConfig())
    out = p.handle(method="GET", target="/admin", headers=Headers(), peer="10.0.0.1")
    assert out.verdict.action == "block"
    assert not out.proxied
    # Audit was written.
    assert chain.entries()


def test_allow_proxies() -> None:
    coord = _coord('phase pre_route { rule r { when path == "/x" then allow() } }')
    chain, audit, clk = _audit()
    p = Pipeline(coordinator=coord, audit=audit, proxy=_proxy(clk), trust=TrustConfig())
    out = p.handle(method="GET", target="/x", headers=Headers(), peer="10.0.0.1")
    assert out.verdict.action == "allow"
    assert out.proxied
    assert out.upstream_endpoint == "a:80"


def test_default_when_no_rule_matches_is_allow() -> None:
    coord = _coord('phase pre_route { rule r { when path == "/never" then block(status=403) } }')
    chain, audit, clk = _audit()
    p = Pipeline(coordinator=coord, audit=audit, proxy=_proxy(clk), trust=TrustConfig())
    out = p.handle(method="GET", target="/x", headers=Headers(), peer="10.0.0.1")
    assert out.verdict.action == "allow"
    assert out.proxied


def test_audit_carries_pinned_version() -> None:
    coord = _coord('phase pre_route { rule r { when path == "/x" then block(status=403) } }')
    chain, audit, clk = _audit()
    p = Pipeline(coordinator=coord, audit=audit, proxy=None, trust=TrustConfig())
    p.handle(method="GET", target="/x", headers=Headers(), peer="10.0.0.1")
    entry = chain.entries()[0]
    assert entry["payload"]["verdict"]["version"]


def test_unpins_after_request() -> None:
    coord = _coord('phase pre_route { rule r { when path == "/x" then allow() } }')
    chain, audit, clk = _audit()
    p = Pipeline(coordinator=coord, audit=audit, proxy=None, trust=TrustConfig())
    versions_before = coord.versions_in_use()
    p.handle(method="GET", target="/x", headers=Headers(), peer="10.0.0.1")
    assert coord.versions_in_use() == versions_before


def test_breaker_open_yields_502() -> None:
    coord = _coord('phase pre_route { rule r { when path == "/x" then allow() } }')
    chain, audit, clk = _audit()
    proxy = _proxy(clk)
    # Trip the breaker manually.
    for _ in range(3):
        proxy.breaker.on_failure()
    p = Pipeline(coordinator=coord, audit=audit, proxy=proxy, trust=TrustConfig())
    out = p.handle(method="GET", target="/x", headers=Headers(), peer="10.0.0.1")
    assert out.verdict.action == "block"
    assert out.verdict.kwargs.get("status") == 502
