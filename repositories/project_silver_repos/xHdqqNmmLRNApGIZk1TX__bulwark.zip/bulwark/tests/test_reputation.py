"""Tests for the reputation service."""

from __future__ import annotations

from bulwark.reputation import Reputation, ReputationEntry, load_feed


def test_basic_lookup() -> None:
    rep = Reputation()
    rep.add(ReputationEntry(cidr="1.2.3.0/24", tag="bad"))
    e = rep.lookup("1.2.3.4")
    assert e is not None and e.tag == "bad"
    assert rep.lookup("9.9.9.9") is None


def test_ttl_expires_lazily() -> None:
    fake_now = [1000.0]
    rep = Reputation(now=lambda: fake_now[0])
    rep.add(ReputationEntry(cidr="1.2.3.0/24", tag="bad", expires_at=1500.0))
    assert rep.has_tag("1.2.3.4", "bad")
    fake_now[0] = 2000.0
    assert not rep.has_tag("1.2.3.4", "bad")


def test_never_expires() -> None:
    fake_now = [10**9]
    rep = Reputation(now=lambda: fake_now[0])
    rep.add(ReputationEntry(cidr="1.2.3.0/24", tag="bad", expires_at=None))
    assert rep.has_tag("1.2.3.1", "bad")


def test_reload_replaces_trie_atomically() -> None:
    rep = Reputation()
    rep.add(ReputationEntry(cidr="1.2.3.0/24", tag="old"))
    rep.reload([ReputationEntry(cidr="1.2.3.0/24", tag="new")])
    e = rep.lookup("1.2.3.4")
    assert e is not None and e.tag == "new"


def test_load_feed_from_file(tmp_path) -> None:
    f = tmp_path / "feed.tsv"
    f.write_text(
        "# header comment\n"
        "1.2.3.0/24\tabuse\t10\t-1\n"
        "fc00::/7\tula\t0\t-1\n"
        "\n"
    )
    entries = load_feed(f)
    assert len(entries) == 2
    assert entries[0].tag == "abuse"
    assert entries[0].score == 10
    assert entries[0].expires_at is None


def test_longest_prefix_wins_via_trie() -> None:
    rep = Reputation()
    rep.add(ReputationEntry(cidr="10.0.0.0/8", tag="lan"))
    rep.add(ReputationEntry(cidr="10.0.0.0/16", tag="vpn"))
    e = rep.lookup("10.0.5.5")
    assert e is not None and e.tag == "vpn"
    e2 = rep.lookup("10.5.5.5")
    assert e2 is not None and e2.tag == "lan"
