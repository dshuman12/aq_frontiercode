"""Tests for the Aho-Corasick PatternSet."""

from __future__ import annotations

import pytest

from bulwark.patternset import PatternSet


def test_no_match() -> None:
    ps = PatternSet.build(["abc", "def"])
    assert ps.matches("xyz") == []
    assert not ps.has_match("xyz")


def test_single_match() -> None:
    ps = PatternSet.build(["needle"])
    assert ps.matches("a needle in a haystack") == ["needle"]


def test_overlapping_patterns() -> None:
    ps = PatternSet.build(["he", "she", "his", "hers"])
    matches = ps.matches("ushers")
    # "she" ending at index 4, "he" ending at index 4, "hers" ending at index 6.
    assert "she" in matches
    assert "he" in matches
    assert "hers" in matches


def test_failure_link_cascade() -> None:
    ps = PatternSet.build(["abc", "bc"])
    # When matching "abc", the failure link from 'c' must surface "bc".
    assert sorted(ps.matches("abc")) == ["abc", "bc"]


def test_repeated_input() -> None:
    ps = PatternSet.build(["aa"])
    matches = ps.matches("aaaa")
    assert len(matches) == 3  # "aa" at end positions 2, 3, 4


def test_empty_pattern_rejected() -> None:
    with pytest.raises(ValueError):
        PatternSet.build([""])


def test_find_all_returns_offsets() -> None:
    ps = PatternSet.build(["he", "she"])
    res = ps.find_all("she")
    # "he" ends at offset 3, "she" ends at offset 3.
    assert (3, 0) in res
    assert (3, 1) in res


def test_has_match_short_circuits() -> None:
    ps = PatternSet.build(["needle"])
    assert ps.has_match("aneedle")
    assert not ps.has_match("haystack")


def test_unicode_input() -> None:
    ps = PatternSet.build(["café", "naïve"])
    assert "café" in ps.matches("a café and naïveté")
    assert "naïve" in ps.matches("a café and naïveté")
