"""Tests for the CIDR trie."""

from __future__ import annotations

from bulwark.cidrtrie import CidrTrie


def test_basic_insert_and_lookup() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("10.0.0.0/8", "lan")
    assert t.lookup("10.1.2.3") == "lan"
    assert t.lookup("8.8.8.8") is None


def test_longest_prefix_wins() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("10.0.0.0/8", "broad")
    t.insert("10.1.0.0/16", "narrow")
    assert t.lookup("10.1.2.3") == "narrow"
    assert t.lookup("10.2.2.3") == "broad"


def test_insert_order_does_not_matter() -> None:
    t1: CidrTrie[str] = CidrTrie()
    t1.insert("10.0.0.0/8", "broad")
    t1.insert("10.1.0.0/16", "narrow")

    t2: CidrTrie[str] = CidrTrie()
    t2.insert("10.1.0.0/16", "narrow")
    t2.insert("10.0.0.0/8", "broad")

    assert t1.lookup("10.1.2.3") == t2.lookup("10.1.2.3") == "narrow"
    assert t1.lookup("10.5.5.5") == t2.lookup("10.5.5.5") == "broad"


def test_ipv6_independent_from_v4() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("10.0.0.0/8", "v4-lan")
    t.insert("fc00::/7", "v6-ula")
    assert t.lookup("10.0.0.1") == "v4-lan"
    assert t.lookup("fd12:3456::1") == "v6-ula"
    assert t.lookup("2001:db8::1") is None


def test_remove() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("10.0.0.0/8", "lan")
    assert t.lookup("10.1.2.3") == "lan"
    assert t.remove("10.0.0.0/8") is True
    assert t.lookup("10.1.2.3") is None


def test_zero_prefix_is_default_route() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("0.0.0.0/0", "any")
    t.insert("8.8.8.8/32", "google")
    assert t.lookup("1.1.1.1") == "any"
    assert t.lookup("8.8.8.8") == "google"


def test_contains() -> None:
    t: CidrTrie[str] = CidrTrie()
    t.insert("10.0.0.0/24", "x")
    assert "10.0.0.5" in t
    assert "10.0.1.5" not in t
