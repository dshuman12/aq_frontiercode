"""Tests for status code helpers and Response."""

from __future__ import annotations

from bulwark import status as s
from bulwark.response import Response, ResponseBuilder


# ---------------------------------------------------------------------------
# Status helpers
# ---------------------------------------------------------------------------


def test_reason_known_codes() -> None:
    assert s.reason(404) == "Not Found"
    assert s.reason(500) == "Internal Server Error"


def test_reason_unknown() -> None:
    assert s.reason(999) == "Unknown"


def test_classifiers() -> None:
    assert s.is_success(200) and s.is_success(204)
    assert s.is_client_error(404) and not s.is_client_error(500)
    assert s.is_server_error(500) and not s.is_server_error(404)
    assert not s.is_success(404)


def test_default_for_action() -> None:
    assert s.default_for("block") == s.FORBIDDEN
    assert s.default_for("allow") == s.OK
    assert s.default_for("challenge") == s.UNAUTHORIZED
    assert s.default_for("nope") == s.INTERNAL_SERVER_ERROR


# ---------------------------------------------------------------------------
# Response
# ---------------------------------------------------------------------------


def test_from_action_uses_default_status() -> None:
    r = Response.from_action("block")
    assert r.status == s.FORBIDDEN
    assert r.reason == "Forbidden"


def test_from_action_explicit_status() -> None:
    r = Response.from_action("block", status=429, body=b"slow down")
    assert r.status == 429
    assert r.reason == "Too Many Requests"
    assert r.body == b"slow down"
    assert r.header("Content-Length") == "9"


def test_serialize_shape() -> None:
    r = Response.from_action("block", status=403, body=b"nope")
    wire = r.serialize()
    assert wire.startswith(b"HTTP/1.1 403 Forbidden\r\n")
    assert b"Content-Length: 4" in wire
    assert wire.endswith(b"\r\n\r\nnope")


def test_response_builder_chainable() -> None:
    r = (ResponseBuilder()
         .with_status(s.NO_CONTENT)
         .with_header("X-Bulwark-Rule", "deny")
         .with_body(b"")).build()
    assert r.status == s.NO_CONTENT
    assert r.reason == "No Content"
    assert r.header("X-Bulwark-Rule") == "deny"


def test_response_builder_default_reason_filled_in() -> None:
    r = ResponseBuilder().with_status(403).build()
    assert r.reason == "Forbidden"
