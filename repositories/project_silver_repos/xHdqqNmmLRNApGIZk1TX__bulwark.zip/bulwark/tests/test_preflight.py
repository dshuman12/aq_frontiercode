"""Tests for CORS preflight handling."""

from __future__ import annotations

from bulwark.headers import Headers
from bulwark.preflight import PreflightConfig, is_preflight, respond


def test_is_preflight_requires_options_method() -> None:
    h = Headers([("Origin", "https://x"), ("Access-Control-Request-Method", "POST")])
    assert is_preflight("OPTIONS", h)
    assert not is_preflight("GET", h)


def test_is_preflight_requires_origin() -> None:
    h = Headers([("Access-Control-Request-Method", "POST")])
    assert not is_preflight("OPTIONS", h)


def test_origin_not_allowed_returns_403() -> None:
    cfg = PreflightConfig(allowed_origins=("https://allowed",))
    h = Headers([("Origin", "https://evil"), ("Access-Control-Request-Method", "POST")])
    r = respond(h, cfg)
    assert r.status == 403


def test_method_not_allowed_returns_405() -> None:
    cfg = PreflightConfig(allowed_origins=("https://x",), allowed_methods=("GET",))
    h = Headers([("Origin", "https://x"), ("Access-Control-Request-Method", "PUT")])
    r = respond(h, cfg)
    assert r.status == 405


def test_disallowed_request_header_returns_400() -> None:
    cfg = PreflightConfig(allowed_origins=("https://x",), allowed_headers=())
    h = Headers([
        ("Origin", "https://x"),
        ("Access-Control-Request-Method", "POST"),
        ("Access-Control-Request-Headers", "X-Custom"),
    ])
    r = respond(h, cfg)
    assert r.status == 400


def test_safe_headers_always_allowed() -> None:
    cfg = PreflightConfig(allowed_origins=("https://x",))
    h = Headers([
        ("Origin", "https://x"),
        ("Access-Control-Request-Method", "POST"),
        ("Access-Control-Request-Headers", "Accept, Content-Type"),
    ])
    r = respond(h, cfg)
    assert r.status == 204


def test_wildcard_origin_with_credentials_echoes_actual_origin() -> None:
    cfg = PreflightConfig(allowed_origins=("*",), allow_credentials=True)
    h = Headers([
        ("Origin", "https://example.com"),
        ("Access-Control-Request-Method", "POST"),
    ])
    r = respond(h, cfg)
    assert r.header("Access-Control-Allow-Origin") == "https://example.com"
    assert r.header("Access-Control-Allow-Credentials") == "true"


def test_max_age_set() -> None:
    cfg = PreflightConfig(allowed_origins=("https://x",), max_age_seconds=3600)
    h = Headers([("Origin", "https://x"), ("Access-Control-Request-Method", "GET")])
    r = respond(h, cfg)
    assert r.header("Access-Control-Max-Age") == "3600"
