"""Tests for `bulwark disasm` and `bulwark load`."""

from __future__ import annotations

import io
import sys

from bulwark.cli import main


def _run(args: list[str]) -> tuple[int, str, str]:
    out = io.StringIO()
    err = io.StringIO()
    saved_out, saved_err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = out, err
    try:
        rc = main(args)
    finally:
        sys.stdout, sys.stderr = saved_out, saved_err
    return rc, out.getvalue(), err.getvalue()


def test_disasm_outputs_phase_and_rule(tmp_path) -> None:
    src = 'phase pre_route { rule r { when path == "/x" then allow() } }'
    f = tmp_path / "a.cdn"
    f.write_text(src)
    rc, out, err = _run(["disasm", str(f)])
    assert rc == 0
    assert "phase pre_route" in out
    assert "rule r" in out


def test_disasm_reports_parse_error(tmp_path) -> None:
    f = tmp_path / "bad.cdn"
    f.write_text("phase { rule")
    rc, out, err = _run(["disasm", str(f)])
    assert rc == 1
    assert "error" in err.lower() or "expected" in err.lower()


def test_load_dir(tmp_path) -> None:
    (tmp_path / "x.cdn").write_text(
        'phase pre_route { rule r { when path == "/x" then allow() } }'
    )
    rc, out, err = _run(["load", str(tmp_path)])
    assert rc == 0
    assert "loaded 1 file" in out
    assert "version" in out


def test_load_dir_reports_errors(tmp_path) -> None:
    (tmp_path / "x.cdn").write_text("phase oops {")
    rc, out, err = _run(["load", str(tmp_path)])
    assert rc == 1
    assert err
