"""Tests for the backoff helper."""

from __future__ import annotations

import pytest

from bulwark.backoff import Backoff


def test_grows_exponentially() -> None:
    seq = iter([1.0, 2.0, 4.0, 8.0, 16.0])
    b = Backoff(base_seconds=1.0, max_seconds=100.0, rng=lambda lo, hi: next(seq))
    assert b.next_delay() == 1.0
    assert b.next_delay() == 2.0
    assert b.next_delay() == 4.0
    assert b.next_delay() == 8.0


def test_capped_at_max() -> None:
    delays: list[float] = []

    def fake(lo: float, hi: float) -> float:
        delays.append(hi)
        return hi

    b = Backoff(base_seconds=1.0, max_seconds=4.0, rng=fake)
    for _ in range(6):
        b.next_delay()
    # Caps at 4 starting from attempt index 2 (1, 2, 4, 4, 4, 4).
    assert delays == [1.0, 2.0, 4.0, 4.0, 4.0, 4.0]


def test_reset_returns_to_base() -> None:
    delays: list[float] = []

    def fake(lo: float, hi: float) -> float:
        delays.append(hi)
        return hi

    b = Backoff(base_seconds=1.0, max_seconds=10.0, rng=fake)
    b.next_delay()
    b.next_delay()
    b.reset()
    b.next_delay()
    assert delays == [1.0, 2.0, 1.0]
    assert b.attempts() == 1


def test_validates_inputs() -> None:
    with pytest.raises(ValueError):
        Backoff(base_seconds=0.0, max_seconds=1.0)
    with pytest.raises(ValueError):
        Backoff(base_seconds=10.0, max_seconds=1.0)
