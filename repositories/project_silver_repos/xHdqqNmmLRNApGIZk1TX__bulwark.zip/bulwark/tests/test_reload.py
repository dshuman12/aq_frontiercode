"""Tests for the reload coordinator."""

from __future__ import annotations

import pytest

from bulwark.loader import load_sources
from bulwark.reload import Coordinator


def _rs(text: str):
    res = load_sources([("a.cdn", text)])
    assert res.ok, res.diagnostics
    return res.ruleset


def test_install_and_pin() -> None:
    c = Coordinator()
    rs = _rs('phase pre_route { rule r { when path == "/x" then allow() } }')
    c.install(rs)
    pinned = c.pin()
    assert pinned.version == rs.version


def test_pin_without_install_errors() -> None:
    c = Coordinator()
    with pytest.raises(RuntimeError):
        c.pin()


def test_old_version_kept_until_unpinned() -> None:
    c = Coordinator()
    v1 = _rs('phase pre_route { rule r { when path == "/x" then allow() } }')
    v2 = _rs('phase pre_route { rule r { when path == "/y" then allow() } }')
    c.install(v1)
    pinned = c.pin()
    c.install(v2)
    # Both versions should be tracked while v1 is still pinned.
    assert pinned.version in c.versions_in_use()
    assert v2.version in c.versions_in_use()
    c.unpin(pinned.version)
    # After unpinning, v1 is GC'd; v2 remains as current.
    assert c.versions_in_use() == (v2.version,)


def test_install_same_version_is_noop() -> None:
    c = Coordinator()
    rs = _rs('phase pre_route { rule r { when path == "/x" then allow() } }')
    c.install(rs)
    c.install(rs)
    assert c.versions_in_use() == (rs.version,)


def test_unpin_unknown_version_is_silent() -> None:
    c = Coordinator()
    rs = _rs('phase pre_route { rule r { when path == "/x" then allow() } }')
    c.install(rs)
    # Should not raise.
    c.unpin("notaversion")
