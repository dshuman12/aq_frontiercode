"""Tests for body buffering and JSON guard."""

from __future__ import annotations

import pytest

from bulwark.body import BodyBuffer, decide_buffering
from bulwark.jsonguard import JsonGuardError, JsonLimits, validate


# ---------------------------------------------------------------------------
# BodyBuffer
# ---------------------------------------------------------------------------


def test_body_buffer_within_cap() -> None:
    b = BodyBuffer(max_bytes=10)
    assert b.write(b"hello")
    assert b.write(b"!!")
    assert b.value() == b"hello!!"
    assert not b.truncated()


def test_body_buffer_truncates_beyond_cap() -> None:
    b = BodyBuffer(max_bytes=5)
    assert b.write(b"hi")
    assert not b.write(b"world!!")
    assert b.truncated()
    assert b.size() == 2


def test_body_buffer_does_not_partially_keep_chunk() -> None:
    # Subtle invariant: if writing "world" pushes us past max, we must
    # NOT keep "wor" -- the partial chunk would corrupt downstream.
    b = BodyBuffer(max_bytes=5)
    b.write(b"hi")
    b.write(b"world")
    assert b.value() == b"hi"


def test_decide_buffering_known_too_large_inspect_required() -> None:
    assert (
        decide_buffering(content_length=10_000, chunked=False, max_bytes=1_000, inspect_required=True)
        == "reject"
    )


def test_decide_buffering_known_too_large_streaming_ok() -> None:
    assert (
        decide_buffering(content_length=10_000, chunked=False, max_bytes=1_000, inspect_required=False)
        == "stream"
    )


# ---------------------------------------------------------------------------
# JSON guard
# ---------------------------------------------------------------------------


def test_validate_simple_object() -> None:
    validate(b'{"a": 1, "b": [2, 3]}')


def test_validate_max_depth_exceeded() -> None:
    payload = b"[" * 50 + b"]" * 50
    with pytest.raises(JsonGuardError, match="max_depth"):
        validate(payload, JsonLimits(max_depth=10))


def test_validate_max_array_exceeded() -> None:
    payload = b"[" + b",".join(b"1" for _ in range(20)) + b"]"
    with pytest.raises(JsonGuardError, match="max_array"):
        validate(payload, JsonLimits(max_array=5))


def test_validate_max_keys_exceeded() -> None:
    parts = [f'"k{i}":{i}'.encode() for i in range(20)]
    payload = b"{" + b",".join(parts) + b"}"
    with pytest.raises(JsonGuardError, match="max_keys"):
        validate(payload, JsonLimits(max_keys=5))


def test_validate_strings_with_braces_are_safe() -> None:
    # A string value containing "{{{{{" should not bump depth.
    payload = b'{"k": "{{{{{{{{{{{{{{{{{{{{{{{{{{{{"}'
    validate(payload, JsonLimits(max_depth=2))


def test_validate_escaped_quote_in_string() -> None:
    payload = rb'{"k": "a\"b"}'
    validate(payload)
