"""Tests for the request inspector."""

from __future__ import annotations

from bulwark.headers import Headers
from bulwark.inspector import inspect
from bulwark.normalize import normalize_request


def _req(path: str, headers: list[tuple[str, str]]) -> "NormalizedRequest":  # type: ignore[name-defined]
    return normalize_request(
        method="POST",
        target=path,
        headers=Headers(headers),
        peer="10.0.0.1",
        trust_depth=0,
    )


def test_json_body() -> None:
    r = inspect(_req("/api/foo", [("Content-Type", "application/json")]))
    assert r.body_kind == "json"
    assert r.is_api


def test_form_body() -> None:
    r = inspect(_req("/login", [("Content-Type", "application/x-www-form-urlencoded")]))
    assert r.body_kind == "form"
    assert not r.is_api


def test_multipart_extracts_boundary() -> None:
    r = inspect(_req("/upload", [("Content-Type", 'multipart/form-data; boundary="xyz123"')]))
    assert r.body_kind == "multipart"
    assert r.boundary == "xyz123"


def test_multipart_unquoted_boundary() -> None:
    r = inspect(_req("/upload", [("Content-Type", "multipart/form-data; boundary=plain")]))
    assert r.boundary == "plain"


def test_empty_body() -> None:
    r = inspect(_req("/health", []))
    assert r.body_kind == "empty"


def test_zero_content_length_is_empty_even_with_ctype() -> None:
    r = inspect(_req("/api/foo", [
        ("Content-Type", "application/json"),
        ("Content-Length", "0"),
    ]))
    assert r.body_kind == "empty"


def test_accept_json_implies_api() -> None:
    r = inspect(_req("/x", [("Accept", "application/json")]))
    assert r.is_api


def test_sensitive_prefix() -> None:
    assert inspect(_req("/admin", [])).sensitive_prefix == "/admin"
    assert inspect(_req("/admin/users", [])).sensitive_prefix == "/admin"
    assert inspect(_req("/administrator", [])).sensitive_prefix is None
    assert inspect(_req("/api/internal/health", [])).sensitive_prefix == "/api/internal"
    assert inspect(_req("/", [])).sensitive_prefix is None
