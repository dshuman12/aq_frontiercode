"""Tests for request ID handling."""

from __future__ import annotations

import pytest

from bulwark.request_id import constant_time_eq, generate, random_token, sanitize


def test_generate_is_hex_and_unique() -> None:
    a = generate()
    b = generate()
    assert a != b
    assert len(a) == 32
    assert all(c in "0123456789abcdef" for c in a)


def test_sanitize_passthrough() -> None:
    assert sanitize("abc-123") == "abc-123"
    assert sanitize("My_Req.1") == "My_Req.1"


def test_sanitize_strips_whitespace() -> None:
    assert sanitize("  ok  ") == "ok"


def test_sanitize_replaces_garbage() -> None:
    out = sanitize("not<>valid")
    assert out != "not<>valid"
    assert len(out) == 32  # fell back to generate()


def test_sanitize_caps_length() -> None:
    out = sanitize("a" * 70)
    assert len(out) == 32  # too long -> rejected -> fresh id


def test_sanitize_none() -> None:
    assert len(sanitize(None)) == 32


def test_constant_time_eq() -> None:
    assert constant_time_eq("abc", "abc")
    assert not constant_time_eq("abc", "abd")
    # Different lengths must not raise.
    assert not constant_time_eq("abc", "abcd")


def test_random_token_length() -> None:
    t = random_token(8)
    assert len(t) == 16


def test_random_token_validates() -> None:
    with pytest.raises(ValueError):
        random_token(0)
