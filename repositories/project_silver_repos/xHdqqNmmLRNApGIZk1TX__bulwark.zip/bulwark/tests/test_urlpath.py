"""Tests for URL path canonicalization."""

from __future__ import annotations

from bulwark.urlpath import normalize_path


def test_simple_passthrough() -> None:
    assert normalize_path("/index.html") == "/index.html"
    assert normalize_path("/api/v1/users") == "/api/v1/users"


def test_dot_segment_collapse() -> None:
    assert normalize_path("/a/./b") == "/a/b"
    assert normalize_path("/a/b/../c") == "/a/c"
    assert normalize_path("/a/b/../../c") == "/c"
    # Out-of-root ..
    assert normalize_path("/../a") == "/a"
    assert normalize_path("/a/../../b") == "/b"


def test_percent_decode_then_collapse() -> None:
    # If we collapsed before decoding, %2e%2e would still be there.
    assert normalize_path("/api/%2e%2e/admin") == "/admin"
    assert normalize_path("/api/%2e/users") == "/api/users"


def test_encoded_slash_is_preserved() -> None:
    # %2F must NOT fold into '/' -- it is part of the segment.
    assert normalize_path("/api%2F..%2Fadmin") == "/api%2F..%2Fadmin"
    assert normalize_path("/file/with%2fslash") == "/file/with%2Fslash"


def test_re_encodes_high_bytes() -> None:
    # A literal non-ASCII char in the path gets percent-encoded.
    assert normalize_path("/résumé") == "/r%C3%A9sum%C3%A9"


def test_re_encodes_spaces_and_quotes() -> None:
    assert normalize_path("/hello world") == "/hello%20world"


def test_empty_path_passes_through() -> None:
    assert normalize_path("") == ""


def test_trailing_slash_preserved() -> None:
    assert normalize_path("/api/") == "/api/"


def test_mixed_case_percent_normalized() -> None:
    assert normalize_path("/x%2fy") == "/x%2Fy"
