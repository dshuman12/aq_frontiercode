"""Tests for the tiny-TOML config loader."""

from __future__ import annotations

import pytest

from bulwark.config import ConfigError, BulwarkConfig, loads


def test_basic_section() -> None:
    d = loads('''
[server]
listen = "0.0.0.0:80"
upstream = "http://api:8080"
max_body_bytes = 1048576
''')
    assert d["server"]["listen"] == "0.0.0.0:80"
    assert d["server"]["max_body_bytes"] == 1048576


def test_booleans_and_arrays() -> None:
    d = loads('''
[trust]
strict = true
relax = false
cidrs = ["10.0.0.0/8", "192.168.0.0/16"]
''')
    assert d["trust"]["strict"] is True
    assert d["trust"]["relax"] is False
    assert d["trust"]["cidrs"] == ["10.0.0.0/8", "192.168.0.0/16"]


def test_integer_hex_octal() -> None:
    d = loads('[x]\na = 0x10\nb = 0o20\nc = 16\n')
    assert d["x"]["a"] == 16
    assert d["x"]["b"] == 16
    assert d["x"]["c"] == 16


def test_floats() -> None:
    d = loads('[x]\na = 1.5\nb = 1e3\n')
    assert d["x"]["a"] == 1.5
    assert d["x"]["b"] == 1000.0


def test_string_escapes() -> None:
    d = loads(r'''
[x]
a = "line1\nline2"
b = "tab\there"
''')
    assert d["x"]["a"] == "line1\nline2"
    assert d["x"]["b"] == "tab\there"


def test_array_with_strings_containing_commas() -> None:
    d = loads('[x]\na = ["hello, world", "no comma"]\n')
    assert d["x"]["a"] == ["hello, world", "no comma"]


def test_comments_ignored() -> None:
    d = loads('# top comment\n[x]\n# inner\na = 1\n')
    assert d["x"]["a"] == 1


def test_empty_section_name_errors() -> None:
    with pytest.raises(ConfigError, match="empty section"):
        loads("[]\nfoo = 1\n")


def test_missing_equals_errors() -> None:
    with pytest.raises(ConfigError, match="missing '='"):
        loads("[x]\nfoo bar\n")


def test_bad_escape_errors() -> None:
    with pytest.raises(ConfigError, match="bad escape"):
        loads(r'[x]' "\n" r'a = "\q"' "\n")


def test_bulwark_config_from_dict_defaults() -> None:
    cfg = BulwarkConfig.from_dict({})
    assert cfg.listen.startswith("127.")
    assert cfg.max_body_bytes > 0


def test_bulwark_config_from_dict_overrides() -> None:
    cfg = BulwarkConfig.from_dict({
        "server": {"listen": "0.0.0.0:443", "max_body_bytes": 2048},
        "trust": {"proxy_depth": 2, "cookie_secret": "shh"},
    })
    assert cfg.listen == "0.0.0.0:443"
    assert cfg.max_body_bytes == 2048
    assert cfg.proxy_depth == 2
    assert cfg.cookie_secret == "shh"
