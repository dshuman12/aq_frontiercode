"""Tests for the multipart/form-data parser."""

from __future__ import annotations

import pytest

from bulwark.multipart import MultipartError, MultipartLimits, parse


B = b"BoUnDaRy"


def _build(parts: list[tuple[bytes, bytes]]) -> bytes:
    """parts is a list of (header_block, body_bytes) tuples."""
    out = b""
    for hdr, body in parts:
        out += b"--" + B + b"\r\n" + hdr + b"\r\n\r\n" + body + b"\r\n"
    out += b"--" + B + b"--\r\n"
    return out


def test_single_part() -> None:
    body = _build([
        (b'Content-Disposition: form-data; name="file"', b"hello"),
    ])
    parts = parse(body, B)
    assert len(parts) == 1
    assert parts[0].body == b"hello"
    assert parts[0].header("Content-Disposition") == 'form-data; name="file"'


def test_multiple_parts() -> None:
    body = _build([
        (b'Content-Disposition: form-data; name="a"', b"AAAA"),
        (b'Content-Disposition: form-data; name="b"', b"BBBB"),
        (b'Content-Disposition: form-data; name="c"', b""),
    ])
    parts = parse(body, B)
    assert [p.body for p in parts] == [b"AAAA", b"BBBB", b""]


def test_max_parts() -> None:
    body = _build([(b"X: 1", b"x") for _ in range(10)])
    with pytest.raises(MultipartError, match="max_parts"):
        parse(body, B, MultipartLimits(max_parts=3))


def test_missing_opening_boundary() -> None:
    with pytest.raises(MultipartError, match="opening"):
        parse(b"no boundary here", B)


def test_missing_trailing_boundary() -> None:
    body = b"--" + B + b"\r\nX: 1\r\n\r\nbody-without-end"
    with pytest.raises(MultipartError, match="trailing"):
        parse(body, B)


def test_header_too_large() -> None:
    big = b"X: " + b"a" * 5000
    body = _build([(big, b"x")])
    with pytest.raises(MultipartError, match="header"):
        parse(body, B, MultipartLimits(max_header_bytes=100))


def test_part_too_large() -> None:
    body = _build([(b"X: 1", b"x" * 200)])
    with pytest.raises(MultipartError, match="too large"):
        parse(body, B, MultipartLimits(max_part_bytes=10))


def test_lf_only_separators() -> None:
    body = b"--" + B + b"\nX: 1\n\nhello\n--" + B + b"--\n"
    parts = parse(body, B)
    assert parts[0].body == b"hello"
