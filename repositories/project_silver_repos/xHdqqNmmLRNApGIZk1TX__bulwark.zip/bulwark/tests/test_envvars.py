"""Tests for the env-override merger."""

from __future__ import annotations

from bulwark.config import BulwarkConfig
from bulwark.envvars import merge_env


def test_no_env_returns_input() -> None:
    cfg = BulwarkConfig(listen="127.0.0.1:7878")
    out = merge_env(cfg, env={})
    assert out.listen == "127.0.0.1:7878"


def test_listen_override() -> None:
    cfg = BulwarkConfig()
    out = merge_env(cfg, env={"BULWARK_SERVER_LISTEN": "0.0.0.0:443"})
    assert out.listen == "0.0.0.0:443"


def test_proxy_depth_parsed_as_int() -> None:
    cfg = BulwarkConfig()
    out = merge_env(cfg, env={"BULWARK_TRUST_PROXY_DEPTH": "3"})
    assert out.proxy_depth == 3


def test_max_body_bytes_parsed() -> None:
    cfg = BulwarkConfig()
    out = merge_env(cfg, env={"BULWARK_SERVER_MAX_BODY_BYTES": "1048576"})
    assert out.max_body_bytes == 1048576


def test_unrelated_env_ignored() -> None:
    cfg = BulwarkConfig(listen="x")
    out = merge_env(cfg, env={"PATH": "/bin", "HOME": "/root"})
    assert out.listen == "x"


def test_secret_override() -> None:
    cfg = BulwarkConfig()
    out = merge_env(cfg, env={"BULWARK_TRUST_COOKIE_SECRET": "shh"})
    assert out.cookie_secret == "shh"
