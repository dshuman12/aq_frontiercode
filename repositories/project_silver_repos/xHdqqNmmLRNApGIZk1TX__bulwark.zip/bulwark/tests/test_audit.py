"""Tests for redaction, chainlog, and audit emission."""

from __future__ import annotations

import pytest

from bulwark.audit import AuditEmitter
from bulwark.chainlog import ChainLog, GENESIS, verify
from bulwark.clock import FakeClock
from bulwark.headers import Headers
from bulwark.normalize import normalize_request
from bulwark.redact import RedactPolicy, redact_body, redact_headers, redact_string
from bulwark.verdict import Verdict


# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------


def test_redact_authorization_header() -> None:
    out = redact_headers([("Authorization", "Bearer abc.def.xyz")])
    assert out[0][1] == "[REDACTED]"


def test_redact_email_in_arbitrary_header() -> None:
    out = redact_headers([("X-Note", "ping alice@example.com about it")])
    assert "alice@example.com" not in out[0][1]
    assert "[REDACTED]" in out[0][1]


def test_redact_string_strips_bearer() -> None:
    assert "abc.def" not in redact_string("Bearer abc.def.xyz tail")


def test_redact_body_keys_case_insensitive() -> None:
    out = redact_body({"Password": "hunter2", "name": "alice"})
    assert out["Password"] == "[REDACTED]"
    assert out["name"] == "alice"


def test_redact_body_recursive() -> None:
    out = redact_body({"user": {"token": "t", "info": ["alice@example.com"]}})
    assert out["user"]["token"] == "[REDACTED]"
    assert out["user"]["info"][0] == "[REDACTED]"


def test_redact_card_number() -> None:
    s = "card 4111 1111 1111 1111 was used"
    out = redact_string(s)
    assert "4111" not in out


# ---------------------------------------------------------------------------
# ChainLog
# ---------------------------------------------------------------------------


def test_chain_links_to_genesis() -> None:
    log = ChainLog()
    e0 = log.append({"x": 1})
    assert e0["prev"] == GENESIS
    assert e0["seq"] == 0


def test_chain_each_entry_links_to_previous() -> None:
    log = ChainLog()
    e0 = log.append({"x": 1})
    e1 = log.append({"x": 2})
    assert e1["prev"] == e0["tag"]


def test_verify_clean_chain() -> None:
    log = ChainLog()
    for i in range(5):
        log.append({"i": i})
    assert verify(log.entries())


def test_verify_detects_tamper() -> None:
    log = ChainLog()
    for i in range(3):
        log.append({"i": i})
    es = log.entries()
    es[1]["payload"]["i"] = 99
    assert not verify(es)


# ---------------------------------------------------------------------------
# AuditEmitter integration
# ---------------------------------------------------------------------------


def _norm() -> "NormalizedRequest":  # type: ignore[name-defined]
    return normalize_request(
        method="GET",
        target="/admin?token=secret",
        headers=Headers([("Authorization", "Bearer xyz"), ("Accept", "application/json")]),
        peer="10.0.0.5",
        trust_depth=0,
    )


def test_audit_redacts_sensitive_headers() -> None:
    log = ChainLog()
    clk = FakeClock()
    clk.set_wall(1234567890.0)
    em = AuditEmitter(chain=log, clock=clk)
    v = Verdict(rule="r", phase="pre_route", action="block", kwargs={"status": 403, "tags": ["pii"]}, version="v1")
    em.emit(req=_norm(), verdict=v, upstream_name=None, endpoint_address=None)
    entry = log.entries()[0]
    headers = dict(entry["payload"]["headers"])
    assert headers["Authorization"] == "[REDACTED]"
    assert entry["payload"]["verdict"]["status"] == 403
    assert entry["payload"]["verdict"]["tags"] == ["pii"]
    assert entry["payload"]["ts"] == 1234567890.0
