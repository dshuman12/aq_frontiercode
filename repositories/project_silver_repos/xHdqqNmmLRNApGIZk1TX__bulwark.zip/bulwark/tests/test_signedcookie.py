"""Tests for HMAC-signed cookies."""

from __future__ import annotations

import pytest

from bulwark.signedcookie import SignError, sign, verify


SECRET = "deadbeef"


def test_round_trip() -> None:
    cookie = sign(SECRET, "alice", now=1_000)
    sc = verify(SECRET, cookie, now=1_000, max_age=300)
    assert sc.payload == "alice"
    assert sc.timestamp == 1_000


def test_expired() -> None:
    cookie = sign(SECRET, "alice", now=1_000)
    with pytest.raises(SignError, match="expired"):
        verify(SECRET, cookie, now=2_000, max_age=300)


def test_signature_tamper() -> None:
    cookie = sign(SECRET, "alice", now=1_000)
    head, _ = cookie.rsplit(".", 1)
    bad = head + "." + "X" * 8
    with pytest.raises(SignError):
        verify(SECRET, bad, now=1_000, max_age=300)


def test_wrong_secret() -> None:
    cookie = sign(SECRET, "alice", now=1_000)
    with pytest.raises(SignError, match="signature"):
        verify("other", cookie, now=1_000, max_age=300)


def test_payload_with_dot_rejected() -> None:
    with pytest.raises(SignError):
        sign(SECRET, "ali.ce", now=1_000)


def test_empty_secret_rejected() -> None:
    with pytest.raises(SignError):
        sign("", "alice", now=1_000)
    with pytest.raises(SignError):
        verify("", "alice.1.x", now=1_000, max_age=300)


def test_malformed_cookie() -> None:
    with pytest.raises(SignError, match="malformed"):
        verify(SECRET, "badcookie", now=1_000, max_age=300)


def test_future_timestamp_rejected() -> None:
    cookie = sign(SECRET, "alice", now=2_000)
    with pytest.raises(SignError, match="future"):
        verify(SECRET, cookie, now=1_000, max_age=300)


def test_clock_skew_tolerated() -> None:
    cookie = sign(SECRET, "alice", now=1_030)
    # 30 seconds in the future -- within the 60-second tolerance.
    sc = verify(SECRET, cookie, now=1_000, max_age=300)
    assert sc.payload == "alice"
