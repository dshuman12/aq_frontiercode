"""Tests that exercise the disassembler against compiled programs."""

from __future__ import annotations

from bulwark.compiler import compile_program
from bulwark.disasm import disassemble_program, disassemble_rule
from bulwark.parser import parse


def test_disasm_includes_rule_name_and_action() -> None:
    src = (
        'phase pre_route { rule mine { '
        'when path == "/x" then block(status=403) } }'
    )
    text = disassemble_program(compile_program(parse(src)))
    assert "phase pre_route" in text
    assert "rule mine" in text
    assert "action: block" in text
    assert "status=403" in text


def test_disasm_shows_const_pool_indices() -> None:
    src = 'phase pre_route { rule r { when path == "/x" then allow() } }'
    cp = compile_program(parse(src))
    rule = cp.phases[0].rules[0]
    text = disassemble_rule(rule)
    assert "LOAD_PATH" in text
    assert "LOAD_CONST" in text


def test_disasm_renders_jumps_with_signs() -> None:
    src = (
        'phase pre_route { rule r { '
        'when path == "/a" and path == "/b" then allow() } }'
    )
    cp = compile_program(parse(src))
    text = disassemble_rule(cp.phases[0].rules[0])
    assert "JUMP_IF_FALSE" in text
    # Either a + or - signed offset is present
    assert ("+" in text) or ("-" in text)
