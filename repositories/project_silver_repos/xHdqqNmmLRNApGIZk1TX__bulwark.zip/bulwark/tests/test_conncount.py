"""Tests for the concurrent-connection counter."""

from __future__ import annotations

import pytest

from bulwark.conncount import ConnCounter


def test_reserve_under_limit() -> None:
    c = ConnCounter(limit=3)
    assert c.reserve("a")
    assert c.reserve("a")
    assert c.reserve("a")
    assert not c.reserve("a")


def test_release_frees_slot() -> None:
    c = ConnCounter(limit=1)
    c.reserve("a")
    c.release("a")
    assert c.reserve("a")


def test_keys_independent() -> None:
    c = ConnCounter(limit=1)
    assert c.reserve("a")
    assert c.reserve("b")
    assert not c.reserve("a")


def test_release_unknown_is_silent() -> None:
    c = ConnCounter(limit=1)
    c.release("never-reserved")  # must not raise


def test_double_release_clamps() -> None:
    c = ConnCounter(limit=2)
    c.reserve("a")
    c.release("a")
    c.release("a")
    # After second release, "a" should be gone (no negative count).
    assert c.in_use("a") == 0


def test_total_count() -> None:
    c = ConnCounter(limit=5)
    c.reserve("a")
    c.reserve("a")
    c.reserve("b")
    assert c.total() == 3


def test_keys_view_clears_when_count_zero() -> None:
    c = ConnCounter(limit=2)
    c.reserve("a")
    c.release("a")
    assert "a" not in c.keys()


def test_validates_inputs() -> None:
    with pytest.raises(ValueError):
        ConnCounter(limit=0)
