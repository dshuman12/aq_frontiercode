"""Tests for the request normalization wrapper."""

from __future__ import annotations

from bulwark.headers import Headers
from bulwark.normalize import normalize_request


def test_method_upcased() -> None:
    req = normalize_request(
        method="get",
        target="/x",
        headers=Headers(),
        peer="10.0.0.1",
        trust_depth=0,
    )
    assert req.method == "GET"


def test_path_canonicalized_and_query_split() -> None:
    req = normalize_request(
        method="GET",
        target="/api/%2e%2e/users?a=1&b=2",
        headers=Headers(),
        peer="10.0.0.1",
        trust_depth=0,
    )
    assert req.path == "/users"
    assert req.query_string == "a=1&b=2"
    assert req.raw_target == "/api/%2e%2e/users?a=1&b=2"


def test_xff_resolves_through_identity() -> None:
    req = normalize_request(
        method="GET",
        target="/",
        headers=Headers([("X-Forwarded-For", "1.2.3.4, 10.0.0.5")]),
        peer="10.0.0.10",
        trust_depth=1,
    )
    assert req.identity.client_ip == "10.0.0.5"


def test_no_query_string_when_no_question_mark() -> None:
    req = normalize_request(
        method="GET",
        target="/x",
        headers=Headers(),
        peer="10.0.0.1",
        trust_depth=0,
    )
    assert req.query_string == ""
