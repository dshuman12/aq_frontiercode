"""Tests for the User-Agent classifier."""

from __future__ import annotations

from bulwark import ua


CHROME = "Mozilla/5.0 (X11; Linux) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
FIREFOX = "Mozilla/5.0 (X11; Linux) Gecko/20100101 Firefox/118.0"
SAFARI = "Mozilla/5.0 (Macintosh) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"
EDGE = "Mozilla/5.0 Edg/120.0"
IE = "Mozilla/5.0 (compatible; MSIE 11.0; Windows NT 10.0; Trident/7.0)"
GOOGLEBOT = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
CURL = "curl/8.5.0"


def test_chrome() -> None:
    p = ua.parse(CHROME)
    assert p.family == "chrome" and p.kind == "browser"


def test_firefox() -> None:
    assert ua.parse(FIREFOX).family == "firefox"


def test_safari_not_chrome() -> None:
    assert ua.parse(SAFARI).family == "safari"


def test_edge_takes_precedence_over_chrome() -> None:
    assert ua.parse(EDGE).family == "edge"


def test_ie_legacy() -> None:
    assert ua.parse(IE).family == "ie"


def test_bot_detection() -> None:
    assert ua.is_bot(GOOGLEBOT)
    assert ua.parse(GOOGLEBOT).family == "bot"


def test_tool_detection() -> None:
    p = ua.parse(CURL)
    assert p.kind == "tool"
    assert p.family == "curl"


def test_unknown_default() -> None:
    p = ua.parse("Mosaic/1.0")
    assert p.family == "other" and p.kind == "unknown"


def test_caching_returns_same_object() -> None:
    a = ua.parse(CHROME)
    b = ua.parse(CHROME)
    assert a is b
