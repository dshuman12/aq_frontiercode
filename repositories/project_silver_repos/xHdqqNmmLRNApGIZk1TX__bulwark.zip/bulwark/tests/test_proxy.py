"""Tests for the high-level Proxy abstraction."""

from __future__ import annotations

import pytest

from bulwark.breaker import Breaker, BreakerState
from bulwark.clock import FakeClock
from bulwark.pool import Pool
from bulwark.proxy import Proxy, ProxyUnavailable
from bulwark.upstream import Endpoint, Upstream


EPS = (Endpoint("a", 80), Endpoint("b", 80))


def _setup() -> tuple[FakeClock, Proxy[str]]:
    clk = FakeClock()
    upstream = Upstream(name="api", endpoints=EPS, strategy="round_robin")
    pool: Pool[str] = Pool(clock=clk, max_per_endpoint=4, idle_seconds=60.0)
    breaker = Breaker(failure_threshold=3, window_size=5, cooldown_seconds=10.0, clock=clk)
    counter = {"n": 0}

    def materialize(ep: Endpoint) -> str:
        counter["n"] += 1
        return f"{ep.address()}#{counter['n']}"

    return clk, Proxy(upstream=upstream, pool=pool, breaker=breaker, materialize=materialize)


def test_begin_materializes_first_handle() -> None:
    _, p = _setup()
    ctx = p.begin()
    assert ctx.fresh
    assert ctx.endpoint.host == "a"


def test_release_and_reuse() -> None:
    _, p = _setup()
    ctx1 = p.begin()
    p.end(ctx1, success=True, reusable=True)
    # Round-robin moved on to b, so this should also be fresh on b.
    ctx2 = p.begin()
    assert ctx2.fresh and ctx2.endpoint.host == "b"
    p.end(ctx2, success=True, reusable=True)
    # Third pick wraps to a -- handle should be reused.
    ctx3 = p.begin()
    assert not ctx3.fresh and ctx3.endpoint.host == "a"
    assert ctx3.handle == ctx1.handle


def test_failure_increments_breaker_and_drops_handle() -> None:
    clk, p = _setup()
    for _ in range(3):
        ctx = p.begin()
        p.end(ctx, success=False, reusable=False)
    # Breaker should now be open.
    assert p.breaker.state is BreakerState.OPEN
    with pytest.raises(ProxyUnavailable, match="breaker open"):
        p.begin()


def test_materialize_failure_propagates_as_unavailable() -> None:
    clk = FakeClock()
    upstream = Upstream(name="api", endpoints=EPS, strategy="round_robin")
    pool: Pool[str] = Pool(clock=clk)
    breaker = Breaker(failure_threshold=2, window_size=5, cooldown_seconds=10.0, clock=clk)
    p: Proxy[str] = Proxy(
        upstream=upstream,
        pool=pool,
        breaker=breaker,
        materialize=lambda ep: None,
    )
    with pytest.raises(ProxyUnavailable, match="could not connect"):
        p.begin()
    # Breaker recorded a failure too.
    assert breaker._failures() == 1


def test_inflight_count_decremented_on_end() -> None:
    _, p = _setup()
    ctx = p.begin()
    assert p.upstream.inflight(ctx.endpoint) == 1
    p.end(ctx, success=True, reusable=True)
    assert p.upstream.inflight(ctx.endpoint) == 0
