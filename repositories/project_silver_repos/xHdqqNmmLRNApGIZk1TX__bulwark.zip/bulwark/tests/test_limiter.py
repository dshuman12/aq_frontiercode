"""Tests for the limiter family."""

from __future__ import annotations

import pytest

from bulwark.buckets import TokenBucket
from bulwark.clock import FakeClock
from bulwark.gcra import GCRA
from bulwark.limiter import LimitConfig, Limiter
from bulwark.slidingwindow import SlidingWindowLog


# ---------------------------------------------------------------------------
# TokenBucket
# ---------------------------------------------------------------------------


def test_token_bucket_initial_burst() -> None:
    clk = FakeClock()
    b = TokenBucket(rate=1.0, burst=3.0, clock=clk)
    assert b.take()
    assert b.take()
    assert b.take()
    assert not b.take()


def test_token_bucket_refills() -> None:
    clk = FakeClock()
    b = TokenBucket(rate=2.0, burst=1.0, clock=clk)
    assert b.take()
    assert not b.take()
    clk.advance(0.5)
    assert b.take()


def test_token_bucket_clock_regression_does_not_refill() -> None:
    clk = FakeClock()
    clk.advance(10.0)
    b = TokenBucket(rate=1.0, burst=1.0, clock=clk)
    assert b.take()
    # NTP-step backwards
    clk._now_ns -= 5 * 1_000_000_000
    # We must NOT see a free token.
    assert not b.take()


# ---------------------------------------------------------------------------
# GCRA
# ---------------------------------------------------------------------------


def test_gcra_admits_burst_then_steady() -> None:
    clk = FakeClock()
    g = GCRA(rate=1.0, burst=3.0, clock=clk)
    assert g.take()
    assert g.take()
    assert g.take()
    assert not g.take()
    # After one period, one slot recovers.
    clk.advance(1.0)
    assert g.take()
    assert not g.take()


def test_gcra_clock_regression_safe() -> None:
    clk = FakeClock()
    clk.advance(60.0)
    g = GCRA(rate=1.0, burst=1.0, clock=clk)
    assert g.take()
    clk._now_ns -= 30 * 1_000_000_000
    # Bucket must still refuse -- TAT is in the future.
    assert not g.take()


# ---------------------------------------------------------------------------
# SlidingWindowLog
# ---------------------------------------------------------------------------


def test_sliding_window_capacity() -> None:
    clk = FakeClock()
    log = SlidingWindowLog(capacity=3, window_ns=1_000_000_000, clock=clk)
    assert log.take()
    assert log.take()
    assert log.take()
    assert not log.take()
    clk.advance(1.1)
    assert log.take()
    assert log.count() == 1


# ---------------------------------------------------------------------------
# Composite Limiter
# ---------------------------------------------------------------------------


def test_limit_config_parses_per_minute() -> None:
    cfg = LimitConfig.from_rate("5/min", burst=2)
    assert cfg.rate_per_sec == pytest.approx(5 / 60)
    assert cfg.burst == 2.0


def test_limit_config_rejects_garbage() -> None:
    with pytest.raises(ValueError):
        LimitConfig.from_rate("five per minute")


def test_limiter_keys_independently() -> None:
    clk = FakeClock()
    lim = Limiter(clock=clk)
    cfg = LimitConfig.from_rate("1/sec", burst=1)
    assert lim.take(rule="login", key="alice", cfg=cfg)
    assert lim.take(rule="login", key="bob", cfg=cfg)
    assert not lim.take(rule="login", key="alice", cfg=cfg)
    assert not lim.take(rule="login", key="bob", cfg=cfg)


def test_limiter_supports_log_algorithm() -> None:
    clk = FakeClock()
    lim = Limiter(clock=clk)
    cfg = LimitConfig(rate_per_sec=2.0, burst=2.0, algorithm="log", window_seconds=1.0)
    assert lim.take(rule="r", key="k", cfg=cfg)
    assert lim.take(rule="r", key="k", cfg=cfg)
    assert not lim.take(rule="r", key="k", cfg=cfg)
