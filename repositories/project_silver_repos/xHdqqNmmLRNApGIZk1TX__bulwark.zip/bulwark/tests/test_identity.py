"""Tests for identity (XFF) extraction."""

from __future__ import annotations

import pytest

from bulwark.identity import real_client_ip


def test_no_xff_uses_peer() -> None:
    ident = real_client_ip(peer="10.0.0.1", xff_header=None, trust_depth=2)
    assert ident.client_ip == "10.0.0.1"


def test_trust_depth_zero_ignores_xff() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="1.2.3.4, 5.6.7.8",
        trust_depth=0,
    )
    assert ident.client_ip == "10.0.0.1"


def test_trust_depth_one_takes_rightmost() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="1.2.3.4, 5.6.7.8",
        trust_depth=1,
    )
    assert ident.client_ip == "5.6.7.8"


def test_trust_depth_two_takes_second_from_right() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="9.9.9.9, 1.2.3.4, 5.6.7.8",
        trust_depth=2,
    )
    assert ident.client_ip == "1.2.3.4"


def test_chain_shorter_than_depth_falls_back_to_peer() -> None:
    """The critical anti-spoof: if XFF is shorter than the trust
    boundary, do *not* use the leftmost entry."""
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="1.2.3.4",  # only one entry
        trust_depth=2,
    )
    assert ident.client_ip == "10.0.0.1"


def test_invalid_ip_in_chain_falls_back_to_peer() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="not-an-ip, evil",
        trust_depth=1,
    )
    assert ident.client_ip == "10.0.0.1"


def test_ipv4_mapped_ipv6_normalized_to_ipv4() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="::ffff:1.2.3.4",
        trust_depth=1,
    )
    assert ident.client_ip == "1.2.3.4"


def test_negative_trust_depth_rejected() -> None:
    with pytest.raises(ValueError):
        real_client_ip(peer="10.0.0.1", xff_header=None, trust_depth=-1)


def test_chain_is_recorded_even_when_unused() -> None:
    ident = real_client_ip(
        peer="10.0.0.1",
        xff_header="1.2.3.4, 5.6.7.8",
        trust_depth=0,
    )
    assert ident.forwarded_chain == ("1.2.3.4", "5.6.7.8")
