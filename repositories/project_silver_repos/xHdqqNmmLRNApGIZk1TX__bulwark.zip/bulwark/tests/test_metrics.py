"""Tests for the metrics registry."""

from __future__ import annotations

import pytest

from bulwark.metrics import Registry


def test_counter_increments() -> None:
    r = Registry()
    c = r.counter("requests_total", route="/x")
    c.inc()
    c.inc(5)
    out = r.render()
    assert 'requests_total{route="/x"} 6' in out


def test_counter_disallows_negative() -> None:
    r = Registry()
    c = r.counter("requests_total")
    with pytest.raises(ValueError):
        c.inc(-1)


def test_histogram_buckets() -> None:
    r = Registry()
    h = r.histogram("latency_seconds")
    for v in (0.0005, 0.005, 0.05, 0.5, 5.0, 50.0):
        h.observe(v)
    out = r.render()
    assert "latency_seconds_count" in out
    # Six observations, including one in the overflow band.
    assert "latency_seconds_count 6" in out


def test_histogram_sum() -> None:
    r = Registry()
    h = r.histogram("latency_seconds")
    h.observe(0.5)
    h.observe(1.0)
    out = r.render()
    assert "latency_seconds_sum 1.5" in out


def test_histogram_buckets_are_cumulative() -> None:
    r = Registry()
    h = r.histogram("latency_seconds")
    h.observe(0.0005)  # falls into 0.001 bucket
    h.observe(0.005)   # falls into 0.01 bucket
    out = r.render()
    # 0.01 bucket should be cumulative -> 2.
    assert 'latency_seconds_bucket{le="0.01"} 2' in out


def test_render_label_combo_unique() -> None:
    r = Registry()
    r.counter("requests_total", route="/x").inc()
    r.counter("requests_total", route="/y").inc(3)
    out = r.render()
    assert 'requests_total{route="/x"} 1' in out
    assert 'requests_total{route="/y"} 3' in out


def test_histogram_singleton_per_label_combo() -> None:
    r = Registry()
    h1 = r.histogram("latency_seconds", route="/x")
    h2 = r.histogram("latency_seconds", route="/x")
    assert h1 is h2
