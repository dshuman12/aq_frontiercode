"""Tests for the LRU cache."""

from __future__ import annotations

import pytest

from bulwark.lru import LRU


def test_basic_put_get() -> None:
    c: LRU[str, int] = LRU(3)
    c.put("a", 1)
    c.put("b", 2)
    assert c.get("a") == 1
    assert c.get("b") == 2
    assert c.get("missing") is None


def test_eviction_lru_first() -> None:
    c: LRU[str, int] = LRU(2)
    c.put("a", 1)
    c.put("b", 2)
    c.put("c", 3)  # evicts "a"
    assert "a" not in c
    assert "b" in c and "c" in c


def test_get_promotes() -> None:
    c: LRU[str, int] = LRU(2)
    c.put("a", 1)
    c.put("b", 2)
    c.get("a")  # "a" is now MRU
    c.put("c", 3)  # should evict "b"
    assert "a" in c
    assert "b" not in c


def test_put_returns_evicted_value() -> None:
    c: LRU[str, int] = LRU(1)
    assert c.put("a", 1) is None
    assert c.put("b", 2) == 1


def test_update_does_not_evict() -> None:
    c: LRU[str, int] = LRU(1)
    c.put("a", 1)
    assert c.put("a", 2) is None
    assert c.get("a") == 2


def test_capacity_must_be_positive() -> None:
    with pytest.raises(ValueError):
        LRU(0)


def test_clear_empties_cache() -> None:
    c: LRU[str, int] = LRU(2)
    c.put("a", 1)
    c.clear()
    assert len(c) == 0


def test_keys_in_lru_order() -> None:
    c: LRU[str, int] = LRU(3)
    c.put("a", 1)
    c.put("b", 2)
    c.put("c", 3)
    c.get("a")  # a now MRU
    keys = c.keys()
    assert keys == ["b", "c", "a"]
