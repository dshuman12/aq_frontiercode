"""Tests for upstream selection."""

from __future__ import annotations

import pytest

from bulwark.upstream import Endpoint, Upstream


EPS = (
    Endpoint("a", 80),
    Endpoint("b", 80),
    Endpoint("c", 80),
)


def test_round_robin_rotates() -> None:
    u = Upstream(name="api", endpoints=EPS, strategy="round_robin")
    picks = [u.pick().host for _ in range(6)]
    assert picks == ["a", "b", "c", "a", "b", "c"]


def test_random_uses_injected_rng() -> None:
    seq = iter([2, 0, 1])
    u = Upstream(
        name="api",
        endpoints=EPS,
        strategy="random",
        _rng=lambda n: next(seq),
    )
    assert u.pick().host == "c"
    assert u.pick().host == "a"
    assert u.pick().host == "b"


def test_least_inflight() -> None:
    u = Upstream(name="api", endpoints=EPS, strategy="least_inflight")
    u.begin(EPS[0])
    u.begin(EPS[0])
    u.begin(EPS[1])
    # b has 1, c has 0 → c wins.
    assert u.pick().host == "c"
    u.end(EPS[1])
    assert u.pick().host == "b"


def test_replace_endpoints_preserves_inflight_for_survivors() -> None:
    u = Upstream(name="api", endpoints=EPS, strategy="least_inflight")
    u.begin(EPS[0])
    u.begin(EPS[0])
    new_eps = (EPS[0], Endpoint("d", 80))
    u.replace_endpoints(new_eps)
    assert u.inflight(EPS[0]) == 2
    assert u.inflight(Endpoint("d", 80)) == 0


def test_end_does_not_go_negative() -> None:
    u = Upstream(name="api", endpoints=EPS, strategy="least_inflight")
    u.end(EPS[0])
    assert u.inflight(EPS[0]) == 0


def test_validates_inputs() -> None:
    with pytest.raises(ValueError):
        Upstream(name="api", endpoints=(), strategy="round_robin")
    with pytest.raises(ValueError):
        Upstream(name="api", endpoints=EPS, strategy="banana")


def test_replace_endpoints_validates() -> None:
    u = Upstream(name="api", endpoints=EPS)
    with pytest.raises(ValueError):
        u.replace_endpoints(())


def test_round_robin_index_clamped_after_replace() -> None:
    u = Upstream(name="api", endpoints=EPS, strategy="round_robin")
    u.pick()
    u.pick()
    u.pick()  # _rr_index is now 0 again
    u.pick()  # _rr_index = 1
    u.replace_endpoints((Endpoint("only", 80),))
    # No IndexError -- clamps to 0.
    assert u.pick().host == "only"
