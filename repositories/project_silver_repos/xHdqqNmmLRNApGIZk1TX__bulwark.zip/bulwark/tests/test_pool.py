"""Tests for the connection pool."""

from __future__ import annotations

from bulwark.clock import FakeClock
from bulwark.pool import Pool
from bulwark.upstream import Endpoint


EP = Endpoint("a", 80)


def test_acquire_returns_none_when_nothing_idle() -> None:
    p: Pool[str] = Pool(clock=FakeClock())
    assert p.acquire(EP) is None


def test_release_then_acquire_returns_same_handle() -> None:
    p: Pool[str] = Pool(clock=FakeClock())
    p.register(EP)
    p.release(EP, "h1")
    assert p.acquire(EP) == "h1"


def test_lifo_order() -> None:
    p: Pool[str] = Pool(clock=FakeClock())
    p.register(EP); p.register(EP); p.register(EP)
    p.release(EP, "h1")
    p.release(EP, "h2")
    p.release(EP, "h3")
    # Most recently released comes back first.
    assert p.acquire(EP) == "h3"
    assert p.acquire(EP) == "h2"
    assert p.acquire(EP) == "h1"


def test_idle_eviction() -> None:
    clk = FakeClock()
    p: Pool[str] = Pool(clock=clk, idle_seconds=10.0)
    p.register(EP)
    p.release(EP, "h1")
    assert p.idle_count(EP) == 1
    clk.advance(15.0)
    assert p.acquire(EP) is None
    # Eviction cleared the idle queue and decremented open count.
    assert p.idle_count(EP) == 0
    assert p.open_count(EP) == 0


def test_max_per_endpoint() -> None:
    p: Pool[str] = Pool(clock=FakeClock(), max_per_endpoint=2)
    p.register(EP)
    p.register(EP)
    # Pool is at the cap with no idle handles → acquire returns None.
    assert p.acquire(EP) is None


def test_mark_dead_decrements_open_count() -> None:
    p: Pool[str] = Pool(clock=FakeClock())
    p.register(EP)
    p.mark_dead(EP, "h1")
    assert p.open_count(EP) == 0


def test_mark_dead_scrubs_from_idle() -> None:
    p: Pool[str] = Pool(clock=FakeClock())
    p.register(EP)
    p.release(EP, "h1")
    p.mark_dead(EP, "h1")
    assert p.idle_count(EP) == 0
