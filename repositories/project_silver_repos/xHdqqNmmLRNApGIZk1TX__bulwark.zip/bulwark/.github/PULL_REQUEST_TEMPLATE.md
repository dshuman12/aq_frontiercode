### Summary

<!-- short description of the change -->

### Rule changes (if any)

<!-- new rule files, behavior changes in pipeline phases, etc. -->

### Checklist

- [ ] `make check` passes
- [ ] new behavior covered by a test
- [ ] docs updated if user-visible
