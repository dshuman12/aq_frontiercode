"""Body buffering with hard size limits.

The inspector and the rule engine both want to look at request bodies.
The pipeline forbids holding the entire body in memory if it exceeds
``max_bytes``. This module gives the rest of the system three options:

* **buffer up to N bytes** -- useful for JSON / form decoding.
* **stream past N bytes** -- body is forwarded as-is, never inspected.
* **reject** -- the request is failed at this stage.

The decision is made up-front from the ``Content-Length`` header (when
present and non-chunked). For chunked bodies, ``BodyBuffer`` enforces
the same cap at write time and returns False once the cap is hit.
"""

from __future__ import annotations

from dataclasses import dataclass, field


class BodyTooLarge(Exception):
    """Raised when a body would exceed the configured cap."""


@dataclass
class BodyBuffer:
    max_bytes: int
    _chunks: list[bytes] = field(default_factory=list)
    _size: int = 0
    _truncated: bool = False

    def write(self, data: bytes) -> bool:
        """Append ``data``. Returns False if the cap was hit."""
        if self._truncated:
            return False
        if self._size + len(data) > self.max_bytes:
            # Don't buffer past the cap. Marking truncated lets callers
            # decide whether to fail the request or stream-through.
            self._truncated = True
            return False
        self._chunks.append(data)
        self._size += len(data)
        return True

    def value(self) -> bytes:
        return b"".join(self._chunks)

    def truncated(self) -> bool:
        return self._truncated

    def size(self) -> int:
        return self._size


def decide_buffering(
    *,
    content_length: int | None,
    chunked: bool,
    max_bytes: int,
    inspect_required: bool,
) -> str:
    """Return one of: ``"buffer"``, ``"stream"``, ``"reject"``."""
    if content_length is not None and content_length > max_bytes:
        # We know the body is too big up front.
        return "reject" if inspect_required else "stream"
    if chunked:
        # Unknown size -- buffer with a cap; the caller decides what to do
        # if the cap trips mid-stream.
        return "buffer"
    return "buffer"
