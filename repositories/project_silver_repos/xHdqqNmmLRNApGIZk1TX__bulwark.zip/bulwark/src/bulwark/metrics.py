"""Counters and histograms.

A self-contained metrics tier so bulwark doesn't need a Prometheus
client at runtime. The export format matches Prometheus' text
exposition format for ease of integration.

Counters monotonically increase. Histograms track sum + count + a
small fixed bucket layout chosen to be useful for HTTP latencies
(0.001s to 10s by ~3x). Labels are unrolled into the metric name
during increment -- no per-label allocation on the hot path.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field


_LATENCY_BUCKETS = (
    0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0,
)


@dataclass
class Registry:
    _counters: dict[tuple[str, tuple[tuple[str, str], ...]], int] = field(default_factory=dict)
    _histograms: dict[tuple[str, tuple[tuple[str, str], ...]], "Histogram"] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def counter(self, name: str, **labels: str) -> "Counter":
        return Counter(self, name, _label_key(labels))

    def histogram(self, name: str, **labels: str) -> "Histogram":
        key = (name, _label_key(labels))
        with self._lock:
            existing = self._histograms.get(key)
            if existing is None:
                existing = Histogram(name=name, label_key=key[1], buckets=_LATENCY_BUCKETS)
                self._histograms[key] = existing
            return existing

    def render(self) -> str:
        """Render in Prometheus text exposition format."""
        lines: list[str] = []
        with self._lock:
            for (name, labels), value in sorted(self._counters.items()):
                lines.append(f"{name}{_format_labels(labels)} {value}")
            for (name, labels), h in sorted(self._histograms.items()):
                base = _format_labels(labels)
                cumulative = 0
                for upper, count in zip(h.buckets, h.bucket_counts):
                    cumulative += count
                    le = "+Inf" if upper == float("inf") else f"{upper}"
                    lines.append(f'{name}_bucket{_with_label(base, "le", le)} {cumulative}')
                cumulative += h.overflow
                lines.append(f'{name}_bucket{_with_label(base, "le", "+Inf")} {cumulative}')
                lines.append(f"{name}_sum{base} {h.sum}")
                lines.append(f"{name}_count{base} {h.count}")
        return "\n".join(lines) + ("\n" if lines else "")


def _label_key(labels: dict[str, str]) -> tuple[tuple[str, str], ...]:
    return tuple(sorted(labels.items()))


def _format_labels(labels: tuple[tuple[str, str], ...]) -> str:
    if not labels:
        return ""
    inner = ",".join(f'{k}="{v}"' for k, v in labels)
    return "{" + inner + "}"


def _with_label(existing: str, k: str, v: str) -> str:
    if not existing:
        return f'{{{k}="{v}"}}'
    # Insert before the closing brace.
    return existing[:-1] + f',{k}="{v}"}}'


@dataclass
class Counter:
    registry: Registry
    name: str
    label_key: tuple[tuple[str, str], ...]

    def inc(self, n: int = 1) -> None:
        if n < 0:
            raise ValueError("Counter cannot decrease")
        key = (self.name, self.label_key)
        with self.registry._lock:
            self.registry._counters[key] = self.registry._counters.get(key, 0) + n


@dataclass
class Histogram:
    name: str
    label_key: tuple[tuple[str, str], ...]
    buckets: tuple[float, ...]
    bucket_counts: list[int] = field(default_factory=list)
    overflow: int = 0
    sum: float = 0.0
    count: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self) -> None:
        if not self.bucket_counts:
            self.bucket_counts = [0] * len(self.buckets)

    def observe(self, value: float) -> None:
        with self._lock:
            self.sum += value
            self.count += 1
            for i, upper in enumerate(self.buckets):
                if value <= upper:
                    self.bucket_counts[i] += 1
                    return
            self.overflow += 1
