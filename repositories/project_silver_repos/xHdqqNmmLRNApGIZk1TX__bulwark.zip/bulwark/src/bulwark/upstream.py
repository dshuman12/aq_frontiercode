"""Upstream definitions.

An *upstream* is a logical destination for a request -- typically a
service name plus a list of host:port endpoints. The pipeline picks
one endpoint per request via :class:`Selector`. Selection strategies:

* ``round_robin`` -- rotate through endpoints in order.
* ``random`` -- uniform random pick (uses an injected RNG for tests).
* ``least_inflight`` -- pick the endpoint with the fewest open
  connections. Ties broken by RR.

Endpoints are stored as a tuple so the strategy can index by position;
mutation goes through :meth:`Upstream.replace_endpoints` which rebuilds
the strategy state atomically.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable


@dataclass(frozen=True)
class Endpoint:
    host: str
    port: int

    def address(self) -> str:
        return f"{self.host}:{self.port}"


@dataclass
class Upstream:
    name: str
    endpoints: tuple[Endpoint, ...]
    strategy: str = "round_robin"
    _rr_index: int = 0
    _inflight: dict[Endpoint, int] = field(default_factory=dict)
    _rng: Callable[[int], int] = field(default=lambda n: random.randrange(n))

    def __post_init__(self) -> None:
        if not self.endpoints:
            raise ValueError("upstream must have at least one endpoint")
        if self.strategy not in {"round_robin", "random", "least_inflight"}:
            raise ValueError(f"unknown strategy {self.strategy!r}")
        self._inflight = {ep: 0 for ep in self.endpoints}

    def replace_endpoints(self, eps: tuple[Endpoint, ...]) -> None:
        if not eps:
            raise ValueError("upstream must have at least one endpoint")
        # Preserve in-flight counts for endpoints that are still present.
        new_inflight = {ep: self._inflight.get(ep, 0) for ep in eps}
        # Use object.__setattr__ since dataclass isn't frozen but we want
        # an obviously-atomic-from-outside swap.
        self.endpoints = eps
        self._inflight = new_inflight
        if self._rr_index >= len(eps):
            self._rr_index = 0

    def pick(self) -> Endpoint:
        if self.strategy == "round_robin":
            ep = self.endpoints[self._rr_index]
            self._rr_index = (self._rr_index + 1) % len(self.endpoints)
            return ep
        if self.strategy == "random":
            return self.endpoints[self._rng(len(self.endpoints))]
        # least_inflight
        best = self.endpoints[0]
        best_count = self._inflight[best]
        for ep in self.endpoints[1:]:
            c = self._inflight[ep]
            if c < best_count:
                best = ep
                best_count = c
        return best

    def begin(self, ep: Endpoint) -> None:
        self._inflight[ep] = self._inflight.get(ep, 0) + 1

    def end(self, ep: Endpoint) -> None:
        cur = self._inflight.get(ep, 0)
        # Don't go negative -- if begin/end are mismatched that's a caller bug
        # but a negative gauge will mislead the next least-inflight pick.
        self._inflight[ep] = max(0, cur - 1)

    def inflight(self, ep: Endpoint) -> int:
        return self._inflight.get(ep, 0)
