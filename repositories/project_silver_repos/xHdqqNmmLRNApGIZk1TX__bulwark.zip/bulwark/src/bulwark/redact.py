"""PII redaction for the audit trail.

The audit log is the system's record of what each request was allowed
to do and why. The log lives somewhere durable (file, syslog, S3) so
PII in headers and bodies is a real problem.

Redaction works on already-decoded data: ``Headers``, decoded JSON
bodies (as :class:`dict` / :class:`list`), and free-form strings. We
do not redact raw bytes. The pipeline must call :func:`redact_string`
on any user-controlled string before it lands in the audit record.

Patterns are conservative -- false negatives are recoverable, false
positives shred otherwise-useful logs.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


_DEFAULT_HEADERS = (
    "authorization",
    "cookie",
    "set-cookie",
    "proxy-authorization",
    "x-api-key",
    "x-auth-token",
)


_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_BEARER_RE = re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-+=]+")
# Credit card heuristic: 13–19 digits with optional separators. Conservative --
# only match groups of 4 with single-char separators, the most common form.
_CARD_RE = re.compile(r"\b(?:\d[ -]?){12,18}\d\b")


@dataclass
class RedactPolicy:
    redact_headers: tuple[str, ...] = _DEFAULT_HEADERS
    redact_body_keys: tuple[str, ...] = ("password", "secret", "token", "apiKey")
    placeholder: str = "[REDACTED]"


def redact_headers(headers: list[tuple[str, str]], policy: RedactPolicy = RedactPolicy()) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    deny = {h.lower() for h in policy.redact_headers}
    for name, value in headers:
        if name.lower() in deny:
            out.append((name, policy.placeholder))
        else:
            out.append((name, redact_string(value, policy)))
    return out


def redact_body(value: Any, policy: RedactPolicy = RedactPolicy()) -> Any:
    deny = {k.lower() for k in policy.redact_body_keys}
    return _walk(value, deny, policy)


def redact_string(text: str, policy: RedactPolicy = RedactPolicy()) -> str:
    text = _BEARER_RE.sub(f"Bearer {policy.placeholder}", text)
    text = _CARD_RE.sub(policy.placeholder, text)
    text = _EMAIL_RE.sub(policy.placeholder, text)
    return text


def _walk(value: Any, deny: set[str], policy: RedactPolicy) -> Any:
    if isinstance(value, dict):
        return {
            k: (policy.placeholder if k.lower() in deny else _walk(v, deny, policy))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_walk(v, deny, policy) for v in value]
    if isinstance(value, str):
        return redact_string(value, policy)
    return value
