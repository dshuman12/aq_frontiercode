"""HTTP status codes used by bulwark's verdict actions.

A small static table. The pipeline converts a verdict into a status
code; if a rule emits ``status=`` directly, it wins. Otherwise we
default by action.
"""

from __future__ import annotations


# Codes bulwark actually emits. We're not trying to be exhaustive -- these
# are the ones rules typically produce.
OK = 200
CREATED = 201
NO_CONTENT = 204

BAD_REQUEST = 400
UNAUTHORIZED = 401
FORBIDDEN = 403
NOT_FOUND = 404
METHOD_NOT_ALLOWED = 405
PAYLOAD_TOO_LARGE = 413
UNSUPPORTED_MEDIA_TYPE = 415
TOO_MANY_REQUESTS = 429

INTERNAL_SERVER_ERROR = 500
BAD_GATEWAY = 502
SERVICE_UNAVAILABLE = 503
GATEWAY_TIMEOUT = 504


_REASON: dict[int, str] = {
    OK: "OK",
    CREATED: "Created",
    NO_CONTENT: "No Content",
    BAD_REQUEST: "Bad Request",
    UNAUTHORIZED: "Unauthorized",
    FORBIDDEN: "Forbidden",
    NOT_FOUND: "Not Found",
    METHOD_NOT_ALLOWED: "Method Not Allowed",
    PAYLOAD_TOO_LARGE: "Payload Too Large",
    UNSUPPORTED_MEDIA_TYPE: "Unsupported Media Type",
    TOO_MANY_REQUESTS: "Too Many Requests",
    INTERNAL_SERVER_ERROR: "Internal Server Error",
    BAD_GATEWAY: "Bad Gateway",
    SERVICE_UNAVAILABLE: "Service Unavailable",
    GATEWAY_TIMEOUT: "Gateway Timeout",
}


# Default status when an action doesn't explicitly carry one.
DEFAULTS: dict[str, int] = {
    "allow": OK,
    "tag": OK,
    "challenge": UNAUTHORIZED,
    "block": FORBIDDEN,
}


def reason(code: int) -> str:
    """Return the canonical reason phrase for a status code."""
    return _REASON.get(code, "Unknown")


def is_success(code: int) -> bool:
    return 200 <= code < 300


def is_redirect(code: int) -> bool:
    return 300 <= code < 400


def is_client_error(code: int) -> bool:
    return 400 <= code < 500


def is_server_error(code: int) -> bool:
    return 500 <= code < 600


def default_for(action: str) -> int:
    return DEFAULTS.get(action, INTERNAL_SERVER_ERROR)
