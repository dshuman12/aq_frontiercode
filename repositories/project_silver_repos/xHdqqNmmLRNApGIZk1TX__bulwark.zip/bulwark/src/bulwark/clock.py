"""Monotonic clock injection.

The pipeline uses a single clock object so that every time-sensitive
component (limiter, breaker, audit timestamps, reputation TTLs) reads
from the same source. This matters for two reasons:

1. **Tests can replay deterministically.** Every call site that needs
   "now" must go through the injected clock; tests substitute a fake
   clock that advances on demand.

2. **Monotonic regressions are handled in one place.** Wall-clock
   timestamps go backwards on NTP step or VM migration. Components
   that care about *durations* must use the monotonic clock; only the
   audit log uses wall time, and even there we record both.

If you find yourself calling :func:`time.time` or :func:`time.monotonic`
directly inside bulwark, that's a bug -- route it through ``Clock``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass


class Clock:
    """Wraps the standard library clocks.

    The default implementation delegates to :mod:`time`. Tests inject
    :class:`FakeClock` instead. There's no abstract base class -- the
    duck-typing surface is small enough to not bother.
    """

    def now_ns(self) -> int:
        return time.monotonic_ns()

    def wall_time(self) -> float:
        """Wall-clock seconds since the unix epoch."""
        return time.time()

    def sleep(self, seconds: float) -> None:  # pragma: no cover - thin wrapper
        time.sleep(seconds)


@dataclass
class FakeClock:
    """Test double for :class:`Clock`.

    Time only advances when the test explicitly calls :meth:`advance`.
    """

    _now_ns: int = 0
    _wall: float = 0.0

    def now_ns(self) -> int:
        return self._now_ns

    def wall_time(self) -> float:
        return self._wall

    def advance(self, seconds: float) -> None:
        self._now_ns += int(seconds * 1_000_000_000)
        self._wall += seconds

    def set_wall(self, wall: float) -> None:
        self._wall = wall

    def sleep(self, seconds: float) -> None:
        self.advance(seconds)
