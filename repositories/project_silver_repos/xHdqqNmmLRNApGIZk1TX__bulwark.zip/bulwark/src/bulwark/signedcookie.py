"""HMAC-signed cookies.

Used by the ``challenge`` action to set a single signed cookie that
the client echoes back on the next request. The challenge succeeds
when the signature verifies and the embedded timestamp is recent.

The cookie format is ``payload.timestamp.signature`` where
``signature`` is the URL-safe base64 of ``HMAC-SHA256(secret,
payload || "." || timestamp)``.
"""

from __future__ import annotations

import base64
import hashlib
import hmac as _hmac
from dataclasses import dataclass


class SignError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class SignedCookie:
    payload: str
    timestamp: int


def _b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def sign(secret: str, payload: str, *, now: int) -> str:
    if not secret:
        raise SignError("empty secret")
    if "." in payload:
        raise SignError("payload may not contain '.'")
    msg = f"{payload}.{now}".encode("utf-8")
    sig = _hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).digest()
    return f"{payload}.{now}.{_b64encode(sig)}"


def verify(secret: str, cookie: str, *, now: int, max_age: int) -> SignedCookie:
    """Return a SignedCookie if the cookie is valid; raise otherwise."""
    if not secret:
        raise SignError("empty secret")
    parts = cookie.rsplit(".", 2)
    if len(parts) != 3:
        raise SignError("malformed cookie")
    payload, ts_str, sig = parts
    try:
        ts = int(ts_str)
    except ValueError:
        raise SignError("non-integer timestamp")
    expected_sig = sign(secret, payload, now=ts).rsplit(".", 1)[1]
    if not _hmac.compare_digest(sig, expected_sig):
        raise SignError("signature mismatch")
    if now - ts > max_age:
        raise SignError("expired")
    if ts > now + 60:
        # Tolerate a minute of clock skew.
        raise SignError("timestamp from the future")
    return SignedCookie(payload=payload, timestamp=ts)
