"""Ruleset loader.

Reads ``.cdn`` source files from a directory, parses them, type-checks,
compiles to bytecode, and packages everything into a versioned
:class:`Ruleset` object.

The version string is the SHA-256 of all source files concatenated in
sorted order. Two loads from identical inputs produce the same version,
so a hot reload that didn't actually change anything is detectable
(and a no-op for the pipeline).
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass

from bulwark.bytecode import CompiledProgram
from bulwark.compiler import compile_program
from bulwark.errors import Diagnostic
from bulwark.optimizer import optimize
from bulwark.parser import parse
from bulwark.semcheck import check


@dataclass(frozen=True, slots=True)
class Ruleset:
    version: str
    program: CompiledProgram
    sources: tuple[tuple[str, str], ...]  # (filename, source) pairs


@dataclass(frozen=True, slots=True)
class LoadResult:
    ok: bool
    ruleset: Ruleset | None
    diagnostics: tuple[Diagnostic, ...]


def load_dir(path: str) -> LoadResult:
    """Load every ``.cdn`` file in ``path``."""
    files = sorted(
        f for f in os.listdir(path) if f.endswith(".cdn") and not f.startswith(".")
    )
    blobs: list[tuple[str, str]] = []
    for f in files:
        with open(os.path.join(path, f), "r", encoding="utf-8") as h:
            blobs.append((f, h.read()))
    return load_sources(blobs)


def load_sources(blobs: list[tuple[str, str]]) -> LoadResult:
    if not blobs:
        return LoadResult(
            ok=False,
            ruleset=None,
            diagnostics=(Diagnostic(message="no rule sources found", span=None),),
        )
    diags: list[Diagnostic] = []
    # Concatenate all sources into one program. Each file becomes a
    # block in the same global namespace; rules collide if names match
    # across files. semcheck reports the collision as an error.
    parts = []
    for filename, source in blobs:
        try:
            program = parse(source)
        except Exception as e:  # parse errors carry their own diagnostics
            diags.append(Diagnostic(message=f"{filename}: {e}", span=None))
            continue
        parts.append(program)
    if diags:
        return LoadResult(ok=False, ruleset=None, diagnostics=tuple(diags))
    if not parts:
        return LoadResult(
            ok=False, ruleset=None,
            diagnostics=(Diagnostic(message="all sources failed to parse", span=None),),
        )
    merged = _merge_programs(parts)
    sem = check(merged)
    if not sem.ok:
        return LoadResult(ok=False, ruleset=None, diagnostics=tuple(sem.diagnostics))
    compiled = compile_program(optimize(merged))
    version = _version(blobs)
    return LoadResult(
        ok=True,
        ruleset=Ruleset(version=version, program=compiled, sources=tuple(blobs)),
        diagnostics=(),
    )


def _merge_programs(parts):
    if len(parts) == 1:
        return parts[0]
    head = parts[0]
    # Concatenate phases -- naive: rely on semcheck to catch dup phase names.
    from bulwark.ast_nodes import Program  # local import to avoid cycles

    all_phases = []
    for p in parts:
        all_phases.extend(p.phases)
    return Program(phases=all_phases, span=head.span)


def _version(blobs: list[tuple[str, str]]) -> str:
    h = hashlib.sha256()
    for name, src in sorted(blobs):
        h.update(name.encode())
        h.update(b"\0")
        h.update(src.encode())
        h.update(b"\0")
    return h.hexdigest()[:16]
