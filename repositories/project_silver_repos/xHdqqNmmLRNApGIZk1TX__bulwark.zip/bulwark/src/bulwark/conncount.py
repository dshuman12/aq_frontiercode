"""Per-key concurrent connection accounting.

Wraps a dict of (key → in-flight count) with reservation semantics:
:meth:`reserve` returns True when the count was below the limit and
increments; :meth:`release` decrements. Counts are clamped non-negative.

Two failure modes the limiter avoids:

* **Reservation leaks.** Callers that forget to release are bounded
  by an LRU-like sweep of the keyspace (the `keys()` view never grows
  unbounded).
* **Negative counters.** A double-release won't push the count
  negative -- that would make the next reservation behave as if the
  key had never been seen.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ConnCounter:
    limit: int
    _counts: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.limit <= 0:
            raise ValueError("limit must be positive")

    def reserve(self, key: str) -> bool:
        cur = self._counts.get(key, 0)
        if cur >= self.limit:
            return False
        self._counts[key] = cur + 1
        return True

    def release(self, key: str) -> None:
        cur = self._counts.get(key, 0)
        if cur <= 1:
            self._counts.pop(key, None)
            return
        self._counts[key] = cur - 1

    def in_use(self, key: str) -> int:
        return self._counts.get(key, 0)

    def total(self) -> int:
        return sum(self._counts.values())

    def keys(self) -> list[str]:
        return list(self._counts)
