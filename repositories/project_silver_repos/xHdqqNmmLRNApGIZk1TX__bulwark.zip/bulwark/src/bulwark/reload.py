"""Atomic ruleset reload.

Bulwark supports zero-downtime ruleset reloads. The constraint that
makes this tricky is invariant **I7**: a request that has started
processing under ruleset version ``vN`` must finish under ``vN``,
even if a reload completes mid-request. The audit record carries
``vN`` so replay is deterministic.

The reload coordinator implements that with two pieces of state:

* ``_current``: the ruleset every *new* request reads.
* ``_pinned``: a refcount-keyed dict of older rulesets still in use.

When a request begins it calls :meth:`pin`, which returns the current
ruleset and increments its refcount. When it ends it calls
:meth:`unpin`, which decrements. A reload installs a new current
ruleset and triggers garbage collection of any old ruleset whose
refcount has hit zero.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bulwark.loader import Ruleset


@dataclass
class _Pinned:
    ruleset: Ruleset
    refcount: int = 0


@dataclass
class Coordinator:
    """Manages ruleset versions across in-flight requests."""

    _current: Ruleset | None = None
    _by_version: dict[str, _Pinned] = field(default_factory=dict)

    def install(self, rs: Ruleset) -> None:
        """Set ``rs`` as the current ruleset for new requests.

        If ``rs`` has the same version as the current one, this is a
        no-op (so loaders that compute identical hashes don't churn).
        """
        if self._current is not None and self._current.version == rs.version:
            return
        self._current = rs
        self._by_version.setdefault(rs.version, _Pinned(ruleset=rs))

    def pin(self) -> Ruleset:
        """Pin the current ruleset for one request. Must be paired with :meth:`unpin`."""
        if self._current is None:
            raise RuntimeError("no ruleset installed")
        entry = self._by_version[self._current.version]
        entry.refcount += 1
        return entry.ruleset

    def unpin(self, version: str) -> None:
        entry = self._by_version.get(version)
        if entry is None:
            return
        entry.refcount -= 1
        # GC: drop entries that aren't current and have no in-flight users.
        if (
            entry.refcount <= 0
            and self._current is not None
            and entry.ruleset.version != self._current.version
        ):
            del self._by_version[version]

    def versions_in_use(self) -> tuple[str, ...]:
        """Diagnostic helper -- every ruleset currently referenced."""
        return tuple(sorted(self._by_version))
