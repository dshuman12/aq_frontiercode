"""HTTP response shape.

When bulwark decides to short-circuit a request (block, challenge, or
synthesize) it emits a :class:`Response` directly. The serializer
turns this into wire bytes for the asyncio adapter.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bulwark import status as status_codes


@dataclass(frozen=True, slots=True)
class Response:
    status: int
    reason: str = ""
    headers: tuple[tuple[str, str], ...] = ()
    body: bytes = b""

    @classmethod
    def from_action(
        cls,
        action: str,
        *,
        status: int | None = None,
        reason: str | None = None,
        body: bytes = b"",
        extra_headers: tuple[tuple[str, str], ...] = (),
    ) -> "Response":
        code = status if status is not None else status_codes.default_for(action)
        text = reason if reason is not None else status_codes.reason(code)
        headers = (
            ("Content-Length", str(len(body))),
            ("Content-Type", "text/plain; charset=utf-8"),
        ) + extra_headers
        return cls(status=code, reason=text, headers=headers, body=body)

    def header(self, name: str) -> str | None:
        lower = name.lower()
        for n, v in self.headers:
            if n.lower() == lower:
                return v
        return None

    def serialize(self) -> bytes:
        """Render to HTTP/1.1 wire bytes."""
        status_line = f"HTTP/1.1 {self.status} {self.reason}\r\n".encode("ascii")
        header_block = b"".join(
            f"{n}: {v}\r\n".encode("latin-1") for n, v in self.headers
        )
        return status_line + header_block + b"\r\n" + self.body


@dataclass
class ResponseBuilder:
    """Mutable accumulator for response bytes prior to serialization."""

    status: int = status_codes.OK
    reason: str = ""
    headers: list[tuple[str, str]] = field(default_factory=list)
    body: bytearray = field(default_factory=bytearray)

    def with_status(self, code: int, reason: str | None = None) -> "ResponseBuilder":
        self.status = code
        self.reason = reason if reason is not None else status_codes.reason(code)
        return self

    def with_header(self, name: str, value: str) -> "ResponseBuilder":
        self.headers.append((name, value))
        return self

    def with_body(self, body: bytes) -> "ResponseBuilder":
        self.body = bytearray(body)
        return self

    def build(self) -> Response:
        return Response(
            status=self.status,
            reason=self.reason or status_codes.reason(self.status),
            headers=tuple(self.headers),
            body=bytes(self.body),
        )
