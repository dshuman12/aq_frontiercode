"""Request IDs.

A request ID is an opaque string used to thread a single request
through the audit log, the upstream call, and any downstream logs.
Bulwark emits a fresh one when none is supplied; if the caller sends
``X-Request-ID`` it's preserved (after sanitization).

Sanitization:
* trim to 64 chars,
* allow only ``[A-Za-z0-9._-]``,
* fall back to a freshly-generated id if nothing valid is left.
"""

from __future__ import annotations

import hmac
import os
import re
import secrets


_VALID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")


def generate() -> str:
    """Return a new fresh request id (16 random bytes hex-encoded)."""
    return secrets.token_hex(16)


def sanitize(supplied: str | None) -> str:
    """Return ``supplied`` if it's well-formed, else a fresh id."""
    if supplied is None:
        return generate()
    trimmed = supplied.strip()
    if _VALID.match(trimmed):
        return trimmed
    return generate()


def constant_time_eq(a: str, b: str) -> bool:
    """Constant-time string comparison.

    Useful for comparing request IDs that double as anti-replay tokens.
    """
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def random_token(length: int = 16) -> str:
    """``length`` random bytes hex-encoded. ``length`` is in bytes."""
    if length <= 0:
        raise ValueError("length must be positive")
    return os.urandom(length).hex()
