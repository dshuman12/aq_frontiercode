"""Aho-Corasick multi-pattern matcher.

Used by the inspector to flag known-bad request shapes (forbidden
header values, suspicious tokens in path) without scanning the input
once per pattern.

The implementation follows the classic Aho-Corasick algorithm:

1. Build a trie of the patterns.
2. Compute failure links by BFS -- each node's failure pointer goes
   to the longest proper suffix that's also a node in the trie.
3. Match by walking input characters; on each char, follow failure
   links until either an edge matches or we're back at the root.

Once built, matching is O(n + matches) where n is input length.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Iterable


@dataclass
class _Node:
    edges: dict[str, int] = field(default_factory=dict)
    fail: int = 0
    outputs: list[int] = field(default_factory=list)


@dataclass
class PatternSet:
    """Multi-pattern string matcher built once, queried many times."""

    patterns: tuple[str, ...]
    _nodes: list[_Node] = field(default_factory=list)
    _built: bool = False

    @classmethod
    def build(cls, patterns: Iterable[str]) -> "PatternSet":
        ps = cls(patterns=tuple(patterns))
        ps._build()
        return ps

    def _build(self) -> None:
        self._nodes = [_Node()]
        # Trie pass.
        for pi, pattern in enumerate(self.patterns):
            if not pattern:
                raise ValueError("empty pattern not allowed")
            node = 0
            for ch in pattern:
                nxt = self._nodes[node].edges.get(ch)
                if nxt is None:
                    self._nodes.append(_Node())
                    nxt = len(self._nodes) - 1
                    self._nodes[node].edges[ch] = nxt
                node = nxt
            self._nodes[node].outputs.append(pi)
        # Failure links via BFS.
        q: deque[int] = deque()
        for child in self._nodes[0].edges.values():
            self._nodes[child].fail = 0
            q.append(child)
        while q:
            r = q.popleft()
            for ch, c in self._nodes[r].edges.items():
                q.append(c)
                state = self._nodes[r].fail
                while state != 0 and ch not in self._nodes[state].edges:
                    state = self._nodes[state].fail
                self._nodes[c].fail = self._nodes[state].edges.get(ch, 0)
                if self._nodes[c].fail == c:
                    self._nodes[c].fail = 0
                # Collect outputs along the failure chain.
                self._nodes[c].outputs.extend(self._nodes[self._nodes[c].fail].outputs)
        self._built = True

    def find_all(self, text: str) -> list[tuple[int, int]]:
        """Return ``(end_offset, pattern_index)`` for every match."""
        if not self._built:
            self._build()
        out: list[tuple[int, int]] = []
        state = 0
        for i, ch in enumerate(text):
            while state != 0 and ch not in self._nodes[state].edges:
                state = self._nodes[state].fail
            state = self._nodes[state].edges.get(ch, 0)
            for pi in self._nodes[state].outputs:
                out.append((i + 1, pi))
        return out

    def matches(self, text: str) -> list[str]:
        """Return the list of matched pattern strings (with duplicates)."""
        return [self.patterns[pi] for _, pi in self.find_all(text)]

    def has_match(self, text: str) -> bool:
        if not self._built:
            self._build()
        state = 0
        for ch in text:
            while state != 0 and ch not in self._nodes[state].edges:
                state = self._nodes[state].fail
            state = self._nodes[state].edges.get(ch, 0)
            if self._nodes[state].outputs:
                return True
        return False
