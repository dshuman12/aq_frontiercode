"""Bounded LRU cache.

Pure-Python, no functools.lru_cache. We need explicit eviction and
some introspection (size, keys) the stdlib decorator doesn't expose.

Intended for caches that live for the process lifetime: compiled
regexes, parsed user-agents, IP→geoip lookups. Not thread-safe -- wrap
in a lock if you need concurrent access.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Generic, TypeVar

K = TypeVar("K")
V = TypeVar("V")


class LRU(Generic[K, V]):
    def __init__(self, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self._data: "OrderedDict[K, V]" = OrderedDict()

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, key: K) -> bool:
        return key in self._data

    def get(self, key: K, default: V | None = None) -> V | None:
        if key not in self._data:
            return default
        self._data.move_to_end(key)
        return self._data[key]

    def put(self, key: K, value: V) -> V | None:
        """Insert or update ``key``. Returns the evicted value, if any."""
        evicted: V | None = None
        if key in self._data:
            self._data.move_to_end(key)
            self._data[key] = value
            return None
        self._data[key] = value
        if len(self._data) > self.capacity:
            _, evicted = self._data.popitem(last=False)
        return evicted

    def keys(self) -> list[K]:
        return list(self._data)

    def clear(self) -> None:
        self._data.clear()
