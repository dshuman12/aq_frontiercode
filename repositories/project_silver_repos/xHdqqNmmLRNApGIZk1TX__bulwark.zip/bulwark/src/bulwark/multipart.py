"""Streaming multipart/form-data parser.

We need just enough multipart support to enforce a hard cap on the
number of parts and the size of each part header before the body
gets through to the inspector. We do not decode part bodies -- those
are handed off as byte slices.

The parser is byte-oriented. RFC 7578 says headers in a multipart
body are 7-bit ASCII; we do not deviate from that.
"""

from __future__ import annotations

from dataclasses import dataclass


class MultipartError(Exception):
    pass


@dataclass(frozen=True)
class Part:
    headers: tuple[tuple[str, str], ...]
    body: bytes

    def header(self, name: str) -> str | None:
        lower = name.lower()
        for n, v in self.headers:
            if n.lower() == lower:
                return v
        return None


@dataclass
class MultipartLimits:
    max_parts: int = 100
    max_header_bytes: int = 8 * 1024
    max_part_bytes: int = 64 * 1024


def parse(body: bytes, boundary: bytes, limits: MultipartLimits = MultipartLimits()) -> list[Part]:
    """Parse a multipart body. Returns the list of parts."""
    if not boundary:
        raise MultipartError("empty boundary")
    delim = b"--" + boundary
    end = b"--" + boundary + b"--"

    # Find the first delimiter.
    idx = body.find(delim)
    if idx < 0:
        raise MultipartError("opening boundary missing")

    parts: list[Part] = []
    cursor = idx + len(delim)
    while True:
        # Skip CRLF or LF after a boundary.
        if body[cursor:cursor + 2] == b"\r\n":
            cursor += 2
        elif body[cursor:cursor + 1] == b"\n":
            cursor += 1
        else:
            # Could be the closing "--".
            if body[cursor:cursor + 2] == b"--":
                break
            raise MultipartError("malformed boundary terminator")
        # Header block ends at the first blank line.
        header_end = body.find(b"\r\n\r\n", cursor)
        if header_end < 0:
            header_end = body.find(b"\n\n", cursor)
            sep_len = 2
        else:
            sep_len = 4
        if header_end < 0 or header_end - cursor > limits.max_header_bytes:
            raise MultipartError("part header missing or too large")
        header_block = body[cursor:header_end]
        cursor = header_end + sep_len
        # Find next boundary marker.
        next_idx = body.find(delim, cursor)
        if next_idx < 0:
            raise MultipartError("trailing boundary missing")
        # Walk back past the trailing CRLF that precedes the boundary.
        body_end = next_idx
        if body[body_end - 2:body_end] == b"\r\n":
            body_end -= 2
        elif body[body_end - 1:body_end] == b"\n":
            body_end -= 1
        part_body = body[cursor:body_end]
        if len(part_body) > limits.max_part_bytes:
            raise MultipartError("part body too large")
        headers = _parse_headers(header_block)
        parts.append(Part(headers=tuple(headers), body=part_body))
        if len(parts) > limits.max_parts:
            raise MultipartError("max_parts exceeded")
        cursor = next_idx + len(delim)
        # Closing?
        if body[next_idx:next_idx + len(end)] == end:
            break
    return parts


def _parse_headers(block: bytes) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for raw in block.split(b"\r\n"):
        if not raw:
            continue
        if b":" not in raw:
            raise MultipartError("malformed header line")
        name, _, value = raw.partition(b":")
        out.append((name.strip().decode("ascii", errors="replace"),
                    value.strip().decode("ascii", errors="replace")))
    return out
