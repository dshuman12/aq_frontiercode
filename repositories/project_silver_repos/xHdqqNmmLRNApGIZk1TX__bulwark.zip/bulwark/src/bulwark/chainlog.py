"""Hash-chained audit log writer.

The chain is a Merkle-spine: each entry includes the SHA-256 hash of
the previous entry's serialized form (its "tag"). Verifying a log is
"walk every entry; recompute the previous tag from the previous entry;
make sure it matches what the next entry stored." That's enough to
detect any in-place edit short of writing the whole tail anew.

The chainlog is intentionally append-only and serializes entries as
newline-delimited JSON. Real production deployments would want a
proper log-structured store, but for bulwark's purposes a JSONL file
is plenty.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Iterable


GENESIS = "0" * 64


def _tag(entry: dict[str, Any]) -> str:
    """Compute the SHA-256 of ``entry`` serialized canonically."""
    blob = json.dumps(entry, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(blob).hexdigest()


@dataclass
class ChainLog:
    """In-memory hash-chained log."""

    _entries: list[dict[str, Any]] = field(default_factory=list)
    _last_tag: str = GENESIS

    def append(self, payload: dict[str, Any]) -> dict[str, Any]:
        entry = {
            "seq": len(self._entries),
            "prev": self._last_tag,
            "payload": payload,
        }
        tag = _tag(entry)
        entry["tag"] = tag
        self._entries.append(entry)
        self._last_tag = tag
        return entry

    def entries(self) -> list[dict[str, Any]]:
        return list(self._entries)

    def head(self) -> str:
        return self._last_tag


def verify(entries: Iterable[dict[str, Any]]) -> bool:
    """Return True iff the chain hashes link cleanly from genesis."""
    expected_prev = GENESIS
    for i, e in enumerate(entries):
        if e.get("seq") != i:
            return False
        if e.get("prev") != expected_prev:
            return False
        # Recompute tag without the stored "tag" key.
        recomputed = _tag({k: v for k, v in e.items() if k != "tag"})
        if recomputed != e.get("tag"):
            return False
        expected_prev = recomputed
    return True
