"""Sliding-window-log limiter.

For low-rate "you may do this 5 times per hour" scenarios where the
exact identity of each event matters (think account lockouts), a
sliding window of timestamps is the right primitive. Token bucket
gives you average rate; the log gives you a precise, auditable count
of events in the last ``window`` seconds.

Memory usage scales with ``rate * window``, which makes it unsuitable
for high-rate paths -- at 1k req/s with a 60s window each key holds
60k timestamps. Use :class:`bulwark.buckets.TokenBucket` or
:class:`bulwark.gcra.GCRA` for those.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from bulwark.clock import Clock


@dataclass
class SlidingWindowLog:
    """Limit to ``capacity`` events within any rolling ``window`` seconds."""

    capacity: int
    window_ns: int
    clock: Clock
    _events: deque[int] = field(default_factory=deque)

    def __post_init__(self) -> None:
        if self.capacity <= 0:
            raise ValueError("capacity must be positive")
        if self.window_ns <= 0:
            raise ValueError("window_ns must be positive")

    def take(self) -> bool:
        now = self.clock.now_ns()
        self._evict(now)
        if len(self._events) >= self.capacity:
            return False
        self._events.append(now)
        return True

    def count(self) -> int:
        self._evict(self.clock.now_ns())
        return len(self._events)

    def _evict(self, now: int) -> None:
        cutoff = now - self.window_ns
        while self._events and self._events[0] <= cutoff:
            self._events.popleft()
