"""Per-request pipeline.

The pipeline is the orchestrator that ties together every other
module. For each incoming request it:

1. Pins a ruleset version via :class:`bulwark.reload.Coordinator`.
2. Normalizes the wire-level request through :mod:`bulwark.normalize`.
3. Classifies the body via :mod:`bulwark.inspector`.
4. Builds the engine environment (path, identity, inspection, …).
5. Runs the ``pre_route`` phase. If a ``block`` verdict wins, it
   emits an audit record and short-circuits.
6. Otherwise hands off to :class:`bulwark.proxy.Proxy` to obtain a
   handle. The actual byte shuffling lives outside this module -- we
   model that step as a caller-provided coroutine.
7. Runs the ``response`` phase (with a placeholder for response
   shape, since bulwark doesn't model responses yet).
8. Emits the audit record and unpins the ruleset.

The pipeline is deliberately *synchronous* in this module. The
asyncio adapter wraps the synchronous core with proper IO.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from bulwark.audit import AuditEmitter
from bulwark.engine import Env, run_phase
from bulwark.headers import Headers
from bulwark.inspector import Inspection, inspect
from bulwark.normalize import NormalizedRequest, normalize_request
from bulwark.proxy import Proxy, ProxyContext, ProxyUnavailable
from bulwark.reload import Coordinator
from bulwark.trust import TrustConfig
from bulwark.verdict import Verdict, coalesce


@dataclass(frozen=True, slots=True)
class PipelineResult:
    verdict: Verdict
    proxied: bool
    upstream_endpoint: str | None


@dataclass
class Pipeline:
    coordinator: Coordinator
    audit: AuditEmitter
    proxy: Proxy | None
    trust: TrustConfig
    do_proxy: Callable[[ProxyContext], bool] | None = None

    def handle(
        self,
        *,
        method: str,
        target: str,
        headers: Headers,
        peer: str,
    ) -> PipelineResult:
        ruleset = self.coordinator.pin()
        try:
            req = normalize_request(
                method=method,
                target=target,
                headers=headers,
                peer=peer,
                trust_depth=self.trust.proxy_depth,
            )
            inspection = inspect(req)
            env = self._env(req, inspection)

            verdicts: list[Verdict] = []
            pre_phase = next(
                (p for p in ruleset.program.phases if p.name == "pre_route"),
                None,
            )
            if pre_phase is not None:
                verdicts.extend(run_phase(pre_phase, env, version=ruleset.version))
            decision = coalesce(verdicts) or Verdict(
                rule="<default>",
                phase="pre_route",
                action="allow",
                kwargs={},
                version=ruleset.version,
            )

            proxied = False
            ep_address: str | None = None
            if decision.action != "block" and self.proxy is not None:
                try:
                    ctx = self.proxy.begin()
                    ep_address = ctx.endpoint.address()
                    success = True
                    if self.do_proxy is not None:
                        success = self.do_proxy(ctx)
                    self.proxy.end(ctx, success=success, reusable=success)
                    proxied = True
                except ProxyUnavailable:
                    decision = Verdict(
                        rule="<upstream>",
                        phase="pre_route",
                        action="block",
                        kwargs={"status": 502, "reason": "upstream unavailable"},
                        version=ruleset.version,
                    )

            self.audit.emit(
                req=req,
                verdict=decision,
                upstream_name=self.proxy.upstream.name if self.proxy else None,
                endpoint_address=ep_address,
            )
            return PipelineResult(verdict=decision, proxied=proxied, upstream_endpoint=ep_address)
        finally:
            self.coordinator.unpin(ruleset.version)

    # ---- helpers --------------------------------------------------------

    @staticmethod
    def _env(req: NormalizedRequest, inspection: Inspection) -> Env:
        paths: dict[str, object] = {
            "path": req.path,
            "method": req.method,
            "ident.client_ip": req.identity.client_ip,
            "ident.peer": req.identity.peer,
            "ident.forwarded_chain": ",".join(req.identity.forwarded_chain),
            "inspection.body_kind": inspection.body_kind,
            "inspection.is_api": inspection.is_api,
            "inspection.sensitive_prefix": inspection.sensitive_prefix or "",
        }
        for name, value in req.headers:
            paths[f"header.{name.lower()}"] = value
        return Env(paths=paths, builtins={})

    @staticmethod
    def _tag_with_version(verdicts: list[Verdict], version: str) -> list[Verdict]:
        # The engine doesn't know its own version -- we stamp it here so
        # the audit log can replay precisely.
        return [
            Verdict(
                rule=v.rule,
                phase=v.phase,
                action=v.action,
                kwargs=v.kwargs,
                version=version,
            )
            for v in verdicts
        ]
