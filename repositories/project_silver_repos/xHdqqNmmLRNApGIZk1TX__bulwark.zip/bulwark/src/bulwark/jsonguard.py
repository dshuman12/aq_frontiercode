"""JSON guard.

Rules can match against decoded JSON bodies, but only if the body is
within both a byte cap (handled by :mod:`bulwark.body`) and *structural*
caps. The guard validates max depth, max array length, max key count
per object, and max total node count without ever materializing values
the caller doesn't ask for -- it walks the byte stream once.

The implementation is intentionally not :mod:`json` based. Standard
:func:`json.loads` builds the entire object tree before we can inspect
it. With adversarial input (a million-deep nested array) that's already
a DoS by the time we get to count anything.
"""

from __future__ import annotations

from dataclasses import dataclass


class JsonGuardError(Exception):
    """Raised when JSON exceeds a structural limit."""


@dataclass
class JsonLimits:
    max_depth: int = 32
    max_array: int = 10_000
    max_keys: int = 1_000
    max_nodes: int = 100_000


def validate(data: bytes, limits: JsonLimits = JsonLimits()) -> None:
    """Walk ``data`` as JSON and raise :class:`JsonGuardError` on excess.

    This does not return the parsed value; callers wanting the value
    pass via :func:`json.loads` after a successful validate.
    """
    depth = 0
    nodes = 0
    array_len_stack: list[int] = []
    key_count_stack: list[int] = []
    container_stack: list[str] = []  # 'a' or 'o'

    i = 0
    n = len(data)
    in_string = False
    string_quote = b'"'
    escaped = False
    expecting_key = False

    while i < n:
        c = data[i:i+1]
        if in_string:
            if escaped:
                escaped = False
            elif c == b"\\":
                escaped = True
            elif c == string_quote:
                in_string = False
                # A finished string in key position counts as a key.
                if container_stack and container_stack[-1] == "o" and expecting_key:
                    key_count_stack[-1] += 1
                    if key_count_stack[-1] > limits.max_keys:
                        raise JsonGuardError("max_keys exceeded")
                    expecting_key = False
            i += 1
            continue
        if c in (b" ", b"\t", b"\r", b"\n"):
            i += 1
            continue
        if c == b'"':
            in_string = True
            i += 1
            continue
        if c == b"{":
            depth += 1
            if depth > limits.max_depth:
                raise JsonGuardError("max_depth exceeded")
            container_stack.append("o")
            key_count_stack.append(0)
            expecting_key = True
            nodes += 1
            i += 1
            continue
        if c == b"[":
            depth += 1
            if depth > limits.max_depth:
                raise JsonGuardError("max_depth exceeded")
            container_stack.append("a")
            array_len_stack.append(0)
            nodes += 1
            i += 1
            continue
        if c == b"}":
            depth -= 1
            if container_stack and container_stack[-1] == "o":
                container_stack.pop()
                key_count_stack.pop()
            i += 1
            continue
        if c == b"]":
            depth -= 1
            if container_stack and container_stack[-1] == "a":
                container_stack.pop()
                array_len_stack.pop()
            i += 1
            continue
        if c == b",":
            if container_stack and container_stack[-1] == "o":
                expecting_key = True
            elif container_stack and container_stack[-1] == "a":
                array_len_stack[-1] += 1
                if array_len_stack[-1] > limits.max_array:
                    raise JsonGuardError("max_array exceeded")
            i += 1
            continue
        if c == b":":
            i += 1
            continue
        # Scalar: number / true / false / null. Skip until next structural.
        nodes += 1
        if nodes > limits.max_nodes:
            raise JsonGuardError("max_nodes exceeded")
        # If we're inside an array and this is the first element, count it.
        if (
            container_stack
            and container_stack[-1] == "a"
            and array_len_stack[-1] == 0
        ):
            array_len_stack[-1] = 1
        while i < n and data[i:i+1] not in (b",", b"}", b"]", b" ", b"\t", b"\r", b"\n"):
            i += 1
