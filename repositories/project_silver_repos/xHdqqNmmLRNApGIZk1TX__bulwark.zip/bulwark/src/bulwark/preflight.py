"""CORS preflight handling.

Browsers send an ``OPTIONS`` request with ``Access-Control-Request-*``
headers ahead of any non-simple request. The proxy can answer
preflights itself when the rule writer hasn't bothered to wire them
through to the application.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bulwark.headers import Headers
from bulwark.response import Response


SAFE_HEADERS_LOWER = frozenset({
    "accept",
    "accept-language",
    "content-language",
    "content-type",
})


@dataclass
class PreflightConfig:
    allowed_origins: tuple[str, ...] = ()
    allowed_methods: tuple[str, ...] = ("GET", "POST", "OPTIONS")
    allowed_headers: tuple[str, ...] = ()
    max_age_seconds: int = 600
    allow_credentials: bool = False
    expose_headers: tuple[str, ...] = ()

    @property
    def _origins_set(self) -> frozenset[str]:
        return frozenset(self.allowed_origins)


def is_preflight(method: str, headers: Headers) -> bool:
    if method.upper() != "OPTIONS":
        return False
    if not headers.get("origin"):
        return False
    if not headers.get("access-control-request-method"):
        return False
    return True


def respond(req_headers: Headers, cfg: PreflightConfig) -> Response:
    origin = req_headers.get("origin") or ""
    requested_method = (req_headers.get("access-control-request-method") or "").upper()
    requested_headers_csv = req_headers.get("access-control-request-headers") or ""
    requested_headers = [h.strip().lower() for h in requested_headers_csv.split(",") if h.strip()]

    out_headers: list[tuple[str, str]] = []

    # Origin check.
    origin_ok = "*" in cfg._origins_set or origin in cfg._origins_set
    if not origin_ok:
        return Response.from_action("block", status=403, body=b"origin not allowed")

    if "*" in cfg._origins_set and not cfg.allow_credentials:
        out_headers.append(("Access-Control-Allow-Origin", "*"))
    else:
        out_headers.append(("Access-Control-Allow-Origin", origin))
        out_headers.append(("Vary", "Origin"))

    # Method check.
    if requested_method and requested_method not in cfg.allowed_methods:
        return Response.from_action("block", status=405, body=b"method not allowed")
    out_headers.append(("Access-Control-Allow-Methods", ", ".join(cfg.allowed_methods)))

    # Header check.
    if requested_headers:
        allowed = {h.lower() for h in cfg.allowed_headers} | SAFE_HEADERS_LOWER
        missing = [h for h in requested_headers if h not in allowed]
        if missing:
            return Response.from_action("block", status=400, body=b"header not allowed")
        out_headers.append(("Access-Control-Allow-Headers", ", ".join(cfg.allowed_headers) or requested_headers_csv))

    if cfg.allow_credentials:
        out_headers.append(("Access-Control-Allow-Credentials", "true"))
    if cfg.expose_headers:
        out_headers.append(("Access-Control-Expose-Headers", ", ".join(cfg.expose_headers)))

    out_headers.append(("Access-Control-Max-Age", str(cfg.max_age_seconds)))

    return Response(status=204, reason="No Content", headers=tuple(out_headers), body=b"")
