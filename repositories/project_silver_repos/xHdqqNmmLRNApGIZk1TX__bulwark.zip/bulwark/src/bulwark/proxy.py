"""High-level proxy abstraction.

The proxy stitches together :mod:`bulwark.upstream` (which endpoint),
:mod:`bulwark.pool` (which connection), and :mod:`bulwark.breaker`
(should we even try). It is *transport-agnostic* -- the actual byte
shuffling between client and upstream is the job of an asyncio
adapter (not yet implemented), but the policy decisions live here.

The selection algorithm is:

1. Ask the breaker if requests are allowed. If not, fail with
   :class:`ProxyUnavailable`.
2. Pick an endpoint via the upstream's strategy.
3. Try to acquire a pooled handle for that endpoint. The caller
   obtains a handle (existing or fresh) and runs the request.
4. Report success/failure back to the breaker AND the upstream
   inflight counter.

Step 3 is split awkwardly because the pool's ``acquire`` returns
``None`` when no idle handle exists *and* the per-endpoint cap is
not yet reached. The proxy expects the caller to call
:meth:`Proxy.materialize` to obtain a handle and register it. This
seam exists so tests can drive proxying without real sockets.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Generic, TypeVar

from bulwark.breaker import Breaker
from bulwark.pool import Pool
from bulwark.upstream import Endpoint, Upstream


H = TypeVar("H")


class ProxyUnavailable(Exception):
    """Raised when the breaker is open or no endpoint can be reached."""


@dataclass
class ProxyContext(Generic[H]):
    """Bookkeeping for one in-flight proxied request."""

    endpoint: Endpoint
    handle: H
    fresh: bool  # True if materialized just now (vs. pulled from pool).


@dataclass
class Proxy(Generic[H]):
    upstream: Upstream
    pool: Pool[H]
    breaker: Breaker
    materialize: Callable[[Endpoint], H | None]
    _last_endpoint: Endpoint | None = field(default=None)

    def begin(self) -> ProxyContext[H]:
        if not self.breaker.allow():
            raise ProxyUnavailable("breaker open")
        ep = self.upstream.pick()
        handle = self.pool.acquire(ep)
        fresh = False
        if handle is None:
            # No idle handle -- try to materialize a new one.
            handle = self.materialize(ep)
            if handle is None:
                # Materialization itself failed; treat as a soft failure.
                self.breaker.on_failure()
                raise ProxyUnavailable(f"could not connect to {ep.address()}")
            self.pool.register(ep)
            fresh = True
        self.upstream.begin(ep)
        self._last_endpoint = ep
        return ProxyContext(endpoint=ep, handle=handle, fresh=fresh)

    def end(self, ctx: ProxyContext[H], *, success: bool, reusable: bool) -> None:
        self.upstream.end(ctx.endpoint)
        if success:
            self.breaker.on_success()
            if reusable:
                self.pool.release(ctx.endpoint, ctx.handle)
            else:
                self.pool.mark_dead(ctx.endpoint, ctx.handle)
        else:
            self.breaker.on_failure()
            self.pool.mark_dead(ctx.endpoint, ctx.handle)
