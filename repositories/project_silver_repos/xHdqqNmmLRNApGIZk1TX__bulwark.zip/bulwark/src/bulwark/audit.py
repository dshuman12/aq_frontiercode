"""Audit emission.

Every request produces exactly one audit record. The record describes:

* the normalized request (path, method, real client IP, etc.),
* the verdict from the rule engine (action, status, tags),
* the upstream selection that was made (or "n/a" if the request was
  blocked before proxying), and
* a hash linking it to the previous record.

The audit module is responsible for:

1. Building the record dict from the per-request state.
2. Calling :func:`bulwark.redact` on user-controlled fields.
3. Appending to the :class:`bulwark.chainlog.ChainLog`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bulwark.chainlog import ChainLog
from bulwark.clock import Clock
from bulwark.normalize import NormalizedRequest
from bulwark.redact import RedactPolicy, redact_headers, redact_string
from bulwark.verdict import Verdict


@dataclass
class AuditEmitter:
    chain: ChainLog
    clock: Clock
    policy: RedactPolicy = field(default_factory=RedactPolicy)

    def emit(
        self,
        *,
        req: NormalizedRequest,
        verdict: Verdict,
        upstream_name: str | None,
        endpoint_address: str | None,
    ) -> dict[str, Any]:
        payload = {
            "ts": self.clock.wall_time(),
            "method": req.method,
            "path": redact_string(req.path, self.policy),
            "query": redact_string(req.query_string, self.policy),
            "client_ip": req.identity.client_ip,
            "headers": redact_headers(list(req.headers), self.policy),
            "verdict": {
                "rule": verdict.rule,
                "phase": verdict.phase,
                "action": verdict.action,
                "status": verdict.kwargs.get("status"),
                "tags": list(verdict.kwargs.get("tags", [])),
                "version": verdict.version,
            },
            "upstream": upstream_name,
            "endpoint": endpoint_address,
        }
        return self.chain.append(payload)
