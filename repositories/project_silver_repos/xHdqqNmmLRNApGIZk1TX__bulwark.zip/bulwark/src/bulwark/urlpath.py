"""URL path canonicalization.

The contract:

1. Decode percent-escapes for ASCII unreserved + sub-delims.
2. **Do not decode** ``%2F`` (encoded slash) -- folding it into ``/``
   would let an attacker bypass path-prefix rules. We keep the
   ``%2F`` literally; it is part of the path segment.
3. Collapse ``.``/``..`` segments per RFC 3986 §5.2.4 (remove dot
   segments). ``..`` is bounded at the root: ``/a/../../b`` → ``/b``,
   not ``/../b``.
4. Re-encode any remaining bytes that are not unreserved using lowercase
   percent-escapes. ``%2F`` is output as ``%2F`` (we preserve it because
   step 2 kept it).

Order matters: percent-decoding runs *before* dot-segment collapse.
Doing it in the other order lets ``/api/%2e%2e/admin`` slip past.
"""

from __future__ import annotations

import re

_UNRESERVED = (
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-._~"
)


_PCT_RE = re.compile(r"%([0-9A-Fa-f]{2})")


def normalize_path(raw: str) -> str:
    """Canonicalize a URL path; raises :class:`ValueError` on malformed input.

    Returns a path that always starts with ``/`` (as long as the input
    did). Empty input returns ``""``.
    """
    if raw == "":
        return ""
    decoded = _percent_decode_preserving_slash(raw)
    collapsed = _remove_dot_segments(decoded)
    return _percent_encode(collapsed)


def _percent_decode_preserving_slash(raw: str) -> str:
    """Percent-decode ``raw`` but leave ``%2F``/``%2f`` intact.

    Sentinel-substitution trick: replace literal ``%2F``/``%2f`` with a
    placeholder that can't appear in URL syntax, decode the rest, then
    swap the placeholder back. This avoids ambiguity with subsequent
    decoded ``/`` characters.
    """
    sentinel = "\x00ENC_SLASH\x00"
    holed = raw.replace("%2F", sentinel).replace("%2f", sentinel)

    def _sub(m: re.Match[str]) -> str:
        try:
            n = int(m.group(1), 16)
        except ValueError as exc:  # pragma: no cover - regex restricts to hex
            raise ValueError(f"bad percent-escape {m.group(0)!r}") from exc
        return chr(n)

    decoded = _PCT_RE.sub(_sub, holed)
    return decoded.replace(sentinel, "%2F")


def _remove_dot_segments(path: str) -> str:
    """Implementation of RFC 3986 §5.2.4."""
    out: list[str] = []
    inp = path
    while inp:
        if inp.startswith("../"):
            inp = inp[3:]
            continue
        if inp.startswith("./"):
            inp = inp[2:]
            continue
        if inp.startswith("/./"):
            inp = "/" + inp[3:]
            continue
        if inp == "/.":
            inp = "/"
            continue
        if inp.startswith("/../"):
            inp = "/" + inp[4:]
            if out:
                # Pop the last *segment* (everything back to and
                # including the previous '/').
                idx = "".join(out).rfind("/")
                if idx >= 0:
                    out = list("".join(out)[:idx])
            continue
        if inp == "/..":
            inp = "/"
            if out:
                idx = "".join(out).rfind("/")
                if idx >= 0:
                    out = list("".join(out)[:idx])
            continue
        if inp == "." or inp == "..":
            inp = ""
            continue
        # Move the first segment from inp to out.
        if inp.startswith("/"):
            out.append("/")
            inp = inp[1:]
        nxt = inp.find("/")
        if nxt < 0:
            out.append(inp)
            inp = ""
        else:
            out.append(inp[:nxt])
            inp = inp[nxt:]
    return "".join(out)


def _percent_encode(s: str) -> str:
    out: list[str] = []
    for ch in s:
        if ch == "%":
            # Already-encoded sequence -- preserve verbatim, lowercased.
            out.append(ch)
            continue
        if ch in _UNRESERVED or ch == "/":
            out.append(ch)
            continue
        for byte in ch.encode("utf-8"):
            out.append(f"%{byte:02X}")
    return "".join(out)
