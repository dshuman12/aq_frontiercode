"""Per-upstream circuit breaker.

The breaker has three states:

* **closed** -- requests flow normally; failures count toward the
  ``failure_threshold``.
* **open** -- requests fail fast; the breaker stays open for at least
  ``cooldown_seconds``.
* **half_open** -- after the cooldown the breaker admits a single
  trial request. A success transitions back to closed; a failure
  bumps the breaker open again with a fresh cooldown.

Failures are not raw counts: we use a moving-window of the last
``window_size`` outcomes and require ``failure_threshold`` failures
within that window before tripping. This keeps a single random
timeout from opening the breaker on a steady upstream, but reacts
quickly when an upstream goes properly bad.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import Enum

from bulwark.clock import Clock


class BreakerState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class Breaker:
    failure_threshold: int
    window_size: int
    cooldown_seconds: float
    clock: Clock
    _state: BreakerState = BreakerState.CLOSED
    _outcomes: deque[bool] = field(default_factory=deque)
    _opened_at_ns: int = 0

    def __post_init__(self) -> None:
        if self.failure_threshold <= 0:
            raise ValueError("failure_threshold must be positive")
        if self.window_size < self.failure_threshold:
            raise ValueError("window_size must be >= failure_threshold")
        if self.cooldown_seconds <= 0:
            raise ValueError("cooldown_seconds must be positive")

    @property
    def state(self) -> BreakerState:
        self._maybe_half_open()
        return self._state

    def allow(self) -> bool:
        """Decide whether to admit a request."""
        self._maybe_half_open()
        if self._state is BreakerState.OPEN:
            return False
        # closed or half-open: admit
        return True

    def on_success(self) -> None:
        self._record(True)
        if self._state is BreakerState.HALF_OPEN:
            # Trial succeeded -- close.
            self._state = BreakerState.CLOSED
            self._outcomes.clear()

    def on_failure(self) -> None:
        self._record(False)
        if self._state is BreakerState.HALF_OPEN:
            # Trial failed -- re-open with a fresh cooldown.
            self._open()
            return
        if self._state is BreakerState.CLOSED and self._failures() >= self.failure_threshold:
            self._open()

    # ---- internals ------------------------------------------------------

    def _record(self, ok: bool) -> None:
        self._outcomes.append(ok)
        while len(self._outcomes) > self.window_size:
            self._outcomes.popleft()

    def _failures(self) -> int:
        return sum(1 for ok in self._outcomes if not ok)

    def _open(self) -> None:
        self._state = BreakerState.OPEN
        self._opened_at_ns = self.clock.now_ns()

    def _maybe_half_open(self) -> None:
        if self._state is not BreakerState.OPEN:
            return
        elapsed_ns = self.clock.now_ns() - self._opened_at_ns
        if elapsed_ns >= int(self.cooldown_seconds * 1_000_000_000):
            self._state = BreakerState.HALF_OPEN
