"""Identity extraction from request metadata.

We resolve the *real* client IP from the trio of:

* the TCP peer address (the load balancer, in production)
* the ``X-Forwarded-For`` chain (and eventually ``Forwarded``, RFC 7239)
* a configured trust depth -- how many proxies in front of bulwark are
  trusted to set XFF entries.

The rule: walk XFF *right to left* exactly ``trust_depth`` hops. If
the chain is shorter than ``trust_depth``, fall back to the socket
peer (do **not** silently use the leftmost XFF entry -- that would let
a client spoof the IP by writing whatever they like into XFF).
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Identity:
    """Resolved identity for a request."""

    client_ip: str
    # The original socket peer; useful for audit when trust_depth==0.
    peer: str
    # The full XFF chain we observed, before trimming. Never trust this
    # for authorization decisions -- it's caller-supplied -- but it's
    # useful for forensics.
    forwarded_chain: tuple[str, ...] = ()


def real_client_ip(
    *,
    peer: str,
    xff_header: str | None,
    trust_depth: int,
) -> Identity:
    """Compute the real client ip given a peer address and an XFF header.

    ``trust_depth`` is the number of trusted proxies in front of
    bulwark. Concretely:

    * 0 → ignore XFF entirely; the peer address is the client.
    * 1 → use the rightmost XFF entry (the proxy directly in front).
    * N → use the entry N from the right.

    If the XFF chain is shorter than ``trust_depth``, fall back to the
    peer address.
    """
    if trust_depth < 0:
        raise ValueError("trust_depth must be non-negative")

    chain = _parse_xff(xff_header)
    if trust_depth == 0:
        return Identity(client_ip=peer, peer=peer, forwarded_chain=tuple(chain))
    if len(chain) < trust_depth:
        # Chain too short -- refuse to use the leftmost (untrusted) entry.
        return Identity(client_ip=peer, peer=peer, forwarded_chain=tuple(chain))
    candidate = chain[-trust_depth]
    if not _is_valid_ip(candidate):
        return Identity(client_ip=peer, peer=peer, forwarded_chain=tuple(chain))
    return Identity(
        client_ip=_normalize_ip(candidate),
        peer=peer,
        forwarded_chain=tuple(chain),
    )


def _parse_xff(header: str | None) -> list[str]:
    if not header:
        return []
    return [piece.strip() for piece in header.split(",") if piece.strip()]


def _is_valid_ip(text: str) -> bool:
    try:
        ipaddress.ip_address(text)
        return True
    except ValueError:
        return False


def _normalize_ip(text: str) -> str:
    """Normalize an IP address.

    For IPv4-mapped IPv6 (``::ffff:1.2.3.4``) we collapse to the
    underlying IPv4 representation. This matters because rate-limiting
    keyed by IP must treat the two forms as identical -- otherwise a
    client can switch encodings and double its budget.
    """
    addr = ipaddress.ip_address(text)
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        return str(addr.ipv4_mapped)
    return str(addr)
