"""Composite limiter -- what rules see at the engine boundary.

A rule's ``limit`` action says "key by X, allow Y per window". We
materialize one limiter per key on first sight and route subsequent
calls to it. The choice of underlying algorithm is per-rule:

* ``rate`` like ``"5/min"`` with a small ``burst`` → token bucket.
* ``rate`` like ``"5/min"`` with no ``burst`` → GCRA (more accurate).
* ``algorithm: log`` keyword → sliding window log.

The keyspace is unbounded (one entry per (rule, key) pair) so a
sweeper periodically expires idle limiters. Sweeping is approximate
and lazy -- we only evict on insert when the table grows past the
soft cap.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Protocol

from bulwark.buckets import TokenBucket
from bulwark.clock import Clock
from bulwark.gcra import GCRA
from bulwark.slidingwindow import SlidingWindowLog


class _LimiterProtocol(Protocol):
    def take(self) -> bool: ...


@dataclass
class LimitConfig:
    rate_per_sec: float
    burst: float
    algorithm: str = "bucket"  # "bucket" | "gcra" | "log"
    window_seconds: float = 1.0  # only used for "log"

    @classmethod
    def from_rate(
        cls,
        rate: str,
        *,
        burst: int | None = None,
        algorithm: str = "bucket",
    ) -> "LimitConfig":
        per_sec, win = _parse_rate(rate)
        return cls(
            rate_per_sec=per_sec,
            burst=float(burst if burst is not None else max(1, int(per_sec))),
            algorithm=algorithm,
            window_seconds=win,
        )


_RATE_RE = re.compile(r"^\s*(\d+)\s*/\s*(s|sec|second|min|minute|h|hour)\s*$")


def _parse_rate(text: str) -> tuple[float, float]:
    """Parse ``"5/min"`` into ``(rate_per_second, window_seconds)``."""
    m = _RATE_RE.match(text)
    if not m:
        raise ValueError(f"invalid rate string {text!r}")
    n = int(m.group(1))
    unit = m.group(2)
    seconds = {
        "s": 1,
        "sec": 1,
        "second": 1,
        "min": 60,
        "minute": 60,
        "h": 3600,
        "hour": 3600,
    }[unit]
    return n / seconds, float(seconds)


@dataclass
class Limiter:
    clock: Clock
    soft_cap: int = 100_000
    _limiters: dict[tuple[str, str], _LimiterProtocol] = field(
        default_factory=dict
    )

    def take(self, *, rule: str, key: str, cfg: LimitConfig) -> bool:
        bucket_key = (rule, key)
        lim = self._limiters.get(bucket_key)
        if lim is None:
            lim = self._make(cfg)
            if len(self._limiters) >= self.soft_cap:
                # Drop a quarter of the oldest entries -- cheap LRU-ish.
                victims = list(self._limiters.keys())[: self.soft_cap // 4]
                for v in victims:
                    del self._limiters[v]
            self._limiters[bucket_key] = lim
        return lim.take()

    def _make(self, cfg: LimitConfig) -> _LimiterProtocol:
        if cfg.algorithm == "bucket":
            return TokenBucket(rate=cfg.rate_per_sec, burst=cfg.burst, clock=self.clock)
        if cfg.algorithm == "gcra":
            return GCRA(rate=cfg.rate_per_sec, burst=cfg.burst, clock=self.clock)
        if cfg.algorithm == "log":
            return SlidingWindowLog(
                capacity=int(cfg.rate_per_sec * cfg.window_seconds),
                window_ns=int(cfg.window_seconds * 1_000_000_000),
                clock=self.clock,
            )
        raise ValueError(f"unknown algorithm {cfg.algorithm!r}")
