"""Environment variable overrides for BulwarkConfig.

The TOML config is the source of truth at boot time, but bulwark
honors a few well-known environment variables for deploy-specific
overrides. The convention is ``BULWARK_<SECTION>_<KEY>`` in
upper-snake-case.

Examples:
    BULWARK_SERVER_LISTEN=0.0.0.0:443
    BULWARK_SERVER_RULES_PATH=/etc/bulwark/rules.d
    BULWARK_TRUST_PROXY_DEPTH=1
"""

from __future__ import annotations

import os
from typing import Any

from bulwark.config import BulwarkConfig


def merge_env(cfg: BulwarkConfig, env: dict[str, str] | None = None) -> BulwarkConfig:
    """Return a new ``BulwarkConfig`` with env overrides applied."""
    e = env if env is not None else os.environ

    def get(key: str, default: Any) -> str:
        return e.get(key, str(default))

    return BulwarkConfig(
        listen=get("BULWARK_SERVER_LISTEN", cfg.listen),
        upstream=get("BULWARK_SERVER_UPSTREAM", cfg.upstream),
        rules_path=get("BULWARK_SERVER_RULES_PATH", cfg.rules_path),
        log_level=get("BULWARK_SERVER_LOG_LEVEL", cfg.log_level),
        max_body_bytes=int(get("BULWARK_SERVER_MAX_BODY_BYTES", cfg.max_body_bytes)),
        proxy_depth=int(get("BULWARK_TRUST_PROXY_DEPTH", cfg.proxy_depth)),
        cookie_secret=get("BULWARK_TRUST_COOKIE_SECRET", cfg.cookie_secret),
    )
