"""IP reputation lookup backed by a signed feed file.

The reputation service reads a feed from disk on startup (and on
:py:meth:`reload`). Each feed entry maps a CIDR to a tag/score record.
At lookup time the trie is queried for the longest-prefix match; if
none is found the IP is treated as unknown (no record).

Each entry can carry a TTL -- useful for "this address misbehaved 24
hours ago, expire it tonight" lists. TTLs are evaluated lazily on
lookup; an entry whose TTL has expired is ignored even though it's
still in the trie. We don't try to garbage-collect; reload rebuilds.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from bulwark.cidrtrie import CidrTrie


@dataclass(frozen=True, slots=True)
class ReputationEntry:
    cidr: str
    tag: str
    score: int = 0
    expires_at: float | None = None  # unix seconds; None means never expires

    def is_live(self, *, now: float) -> bool:
        return self.expires_at is None or self.expires_at > now


@dataclass
class Reputation:
    """Repository of CIDR → reputation entries.

    ``now`` is injected so tests can drive the TTL machinery without
    needing the real clock. Defaults to :func:`time.time`.
    """

    now: Callable[[], float] = time.time
    _trie: CidrTrie[ReputationEntry] = field(default_factory=CidrTrie)

    # ---- mutation -------------------------------------------------------

    def add(self, entry: ReputationEntry) -> None:
        self._trie.insert(entry.cidr, entry)

    def add_many(self, entries: Iterable[ReputationEntry]) -> None:
        for e in entries:
            self.add(e)

    def reload(self, entries: Iterable[ReputationEntry]) -> None:
        """Atomic-ish reload -- rebuild the trie from scratch."""
        self._trie = CidrTrie()
        self.add_many(entries)

    # ---- queries --------------------------------------------------------

    def lookup(self, ip: str) -> ReputationEntry | None:
        entry = self._trie.lookup(ip)
        if entry is None:
            return None
        if not entry.is_live(now=self.now()):
            return None
        return entry

    def has_tag(self, ip: str, tag: str) -> bool:
        e = self.lookup(ip)
        return e is not None and e.tag == tag


# ---------------------------------------------------------------------------
# Feed loader
# ---------------------------------------------------------------------------


def load_feed(path: str | Path) -> list[ReputationEntry]:
    """Load a reputation feed from disk.

    The feed format is one record per line, tab-separated:

        CIDR\\tTAG\\tSCORE\\tEXPIRES_AT

    ``EXPIRES_AT`` is a unix-seconds integer; ``-1`` means "never".
    Lines starting with ``#`` are comments. Blank lines are skipped.
    """
    out: list[ReputationEntry] = []
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 2:
                raise ValueError(f"malformed reputation line {raw!r}")
            cidr = parts[0].strip()
            tag = parts[1].strip()
            score = int(parts[2]) if len(parts) > 2 and parts[2] else 0
            exp_raw = parts[3] if len(parts) > 3 else "-1"
            expires_at: float | None = None
            if exp_raw and exp_raw.strip() != "-1":
                expires_at = float(exp_raw)
            out.append(
                ReputationEntry(
                    cidr=cidr, tag=tag, score=score, expires_at=expires_at
                )
            )
    return out
