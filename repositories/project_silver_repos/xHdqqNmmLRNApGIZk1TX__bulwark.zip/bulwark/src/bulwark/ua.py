"""User-Agent classifier.

Just enough to drive a few rules -- bots, mobile, browser-by-vendor.
We do not try to be a full UA parser; the parsed shape stops at
``family`` / ``kind``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from bulwark.lru import LRU


@dataclass(frozen=True, slots=True)
class UserAgent:
    raw: str
    family: str  # "chrome" | "firefox" | "safari" | "edge" | "ie" | "bot" | "tool" | "other"
    kind: str    # "browser" | "bot" | "tool" | "unknown"


_BOT_PATTERNS = (
    "googlebot", "bingbot", "yandex", "duckduckbot",
    "ahrefsbot", "semrushbot", "applebot", "facebot",
)

_TOOL_PATTERNS = (
    "curl/", "wget/", "python-requests", "httpx", "scrapy",
)


_CACHE: LRU[str, UserAgent] = LRU(2048)


def parse(raw: str) -> UserAgent:
    cached = _CACHE.get(raw)
    if cached is not None:
        return cached
    parsed = _parse_uncached(raw)
    _CACHE.put(raw, parsed)
    return parsed


def _parse_uncached(raw: str) -> UserAgent:
    low = raw.lower()
    if _any_in(low, _BOT_PATTERNS):
        return UserAgent(raw=raw, family="bot", kind="bot")
    if _any_in(low, _TOOL_PATTERNS):
        # The leading family (e.g. "curl/8.5") is informative.
        m = re.match(r"^([A-Za-z][A-Za-z0-9\-_]*)", raw.strip())
        family = m.group(1).lower() if m else "tool"
        return UserAgent(raw=raw, family=family, kind="tool")
    if "edg/" in low:
        return UserAgent(raw=raw, family="edge", kind="browser")
    if "chrome/" in low and "edg/" not in low:
        return UserAgent(raw=raw, family="chrome", kind="browser")
    if "firefox/" in low:
        return UserAgent(raw=raw, family="firefox", kind="browser")
    if "safari/" in low and "chrome/" not in low:
        return UserAgent(raw=raw, family="safari", kind="browser")
    if "msie" in low or "trident/" in low:
        return UserAgent(raw=raw, family="ie", kind="browser")
    return UserAgent(raw=raw, family="other", kind="unknown")


def _any_in(haystack: str, needles: Iterable[str]) -> bool:
    for n in needles:
        if n in haystack:
            return True
    return False


def is_bot(raw: str) -> bool:
    return parse(raw).kind == "bot"


def is_browser(raw: str) -> bool:
    return parse(raw).kind == "browser"
