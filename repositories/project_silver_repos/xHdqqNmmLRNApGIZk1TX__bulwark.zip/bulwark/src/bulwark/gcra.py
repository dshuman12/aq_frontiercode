"""Generic Cell Rate Algorithm (GCRA) limiter.

GCRA is the same shape as a leaky bucket but is described in terms of
a *theoretical arrival time* (TAT) rather than a token count. It uses
exactly two pieces of state -- TAT and the increment ``T`` -- and is
both simpler and more numerically stable than its leaky-bucket twin.

Reference: Performance Implications of the GCRA, ATM Forum (1996).

Notation, mapping rate-limit jargon onto GCRA:

    rate            requests per second the steady-state stream sustains
    burst           how many requests can land back-to-back
    T = 1 / rate    period
    tau = burst*T   tolerance (max distance new TAT can leap forward)

A new request at wall-clock ``t_now`` is admitted iff
``t_now + T - tat <= tau``. On admit, ``tat = max(tat, t_now) + T``.

Like :class:`bulwark.buckets.TokenBucket`, GCRA reads from an
injected clock and clamps on regression -- once TAT has been advanced
to a future value, it must not slide back even if the clock dips.
"""

from __future__ import annotations

from dataclasses import dataclass

from bulwark.clock import Clock


@dataclass
class GCRA:
    """Generic Cell Rate Algorithm limiter."""

    rate: float
    burst: float
    clock: Clock

    def __post_init__(self) -> None:
        if self.rate <= 0:
            raise ValueError("rate must be positive")
        if self.burst <= 0:
            raise ValueError("burst must be positive")
        self._period_ns: int = max(1, int(1_000_000_000.0 / self.rate))
        # tau is the max distance the new TAT can leap *past* the current
        # time. With burst=N the first N back-to-back arrivals all fit
        # inside the window, hence (N-1)*T.
        self._tau_ns: int = int(max(0, (self.burst - 1) * self._period_ns))
        self._tat_ns: int = self.clock.now_ns()

    def take(self) -> bool:
        """Admit one request, or refuse it. Returns True on admit."""
        now = self.clock.now_ns()
        new_tat = max(self._tat_ns, now) + self._period_ns
        # Reject when admitting would push TAT more than (tau + T) past now.
        if new_tat - now > self._tau_ns + self._period_ns:
            return False
        self._tat_ns = new_tat
        return True

    def time_to_recover_ns(self) -> int:
        """Estimate ns until the bucket has room for one more request."""
        now = self.clock.now_ns()
        debt = self._tat_ns - now - self._tau_ns
        return max(0, debt)
