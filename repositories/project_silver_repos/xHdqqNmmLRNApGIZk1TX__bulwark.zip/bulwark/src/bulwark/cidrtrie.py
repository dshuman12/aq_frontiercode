"""Radix CIDR trie for IPv4 + IPv6 prefix matching.

Lookup is longest-prefix-match. Insert order does not matter -- a
subsequent insert of a more specific prefix takes priority over a
broader one regardless of the order they were added.

Both v4 and v6 share the same trie internally by encoding addresses
as fixed-width bit strings (32 for v4, 128 for v6); the family is
disambiguated by the prefix length and the leading bytes.

This is the canonical home for "is the client in this allowlist /
denylist / network range" -- used by :mod:`bulwark.reputation`,
the ``ip_in`` built-in, and the limiter's identity composition.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass
class _Node(Generic[T]):
    children: dict[int, "_Node[T]"] = field(default_factory=dict)
    # Value stored at this node, if any. None means "no entry here".
    value: T | None = None
    has_value: bool = False


@dataclass
class CidrTrie(Generic[T]):
    """A bit-keyed radix trie over IPv4 and IPv6 networks."""

    _v4_root: _Node[T] = field(default_factory=_Node)
    _v6_root: _Node[T] = field(default_factory=_Node)

    # ---- mutation -------------------------------------------------------

    def insert(self, cidr: str, value: T) -> None:
        net = _parse_cidr(cidr)
        bits = _net_bits(net)
        root = self._v6_root if net.version == 6 else self._v4_root
        node = root
        for b in bits:
            child = node.children.get(b)
            if child is None:
                child = _Node()
                node.children[b] = child
            node = child
        node.value = value
        node.has_value = True

    def remove(self, cidr: str) -> bool:
        net = _parse_cidr(cidr)
        bits = _net_bits(net)
        root = self._v6_root if net.version == 6 else self._v4_root
        node = root
        for b in bits:
            child = node.children.get(b)
            if child is None:
                return False
            node = child
        if not node.has_value:
            return False
        node.value = None
        node.has_value = False
        return True

    # ---- queries --------------------------------------------------------

    def lookup(self, ip: str) -> T | None:
        """Return the value of the longest matching prefix, or ``None``."""
        addr = ipaddress.ip_address(ip)
        bits = _addr_bits(addr)
        root = self._v6_root if addr.version == 6 else self._v4_root
        node = root
        last: T | None = None
        if root.has_value:
            last = root.value
        for b in bits:
            child = node.children.get(b)
            if child is None:
                break
            node = child
            if node.has_value:
                last = node.value
        return last

    def __contains__(self, ip: str) -> bool:
        return self.lookup(ip) is not None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_cidr(cidr: str) -> ipaddress._BaseNetwork:
    return ipaddress.ip_network(cidr, strict=False)


def _net_bits(net: ipaddress._BaseNetwork) -> list[int]:
    addr = int(net.network_address)
    width = 128 if net.version == 6 else 32
    bits: list[int] = []
    for i in range(net.prefixlen):
        shift = width - 1 - i
        bits.append((addr >> shift) & 1)
    return bits


def _addr_bits(addr: ipaddress._BaseAddress) -> list[int]:
    n = int(addr)
    width = 128 if addr.version == 6 else 32
    return [(n >> (width - 1 - i)) & 1 for i in range(width)]
