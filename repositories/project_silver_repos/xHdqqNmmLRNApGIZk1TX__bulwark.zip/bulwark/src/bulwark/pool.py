"""Connection pool primitive.

The pool itself is transport-agnostic. It holds *connection handles*
of an opaque type ``H`` and exposes ``acquire`` / ``release`` /
``mark_dead``. The actual TCP/TLS bring-up lives in the proxy module.

Design notes:

* Idle handles older than ``idle_seconds`` are evicted on the next
  acquire that touches them. Eviction is lazy -- we don't run a
  sweeper thread.
* ``max_per_endpoint`` is a soft cap. If it's reached and no idle
  handle is available, ``acquire`` returns ``None``; callers are
  expected to wait or fail rather than the pool blocking.
* Released handles go to the *front* of the deque (LIFO) so a tight
  burst reuses the same handle and the rest age out together.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Generic, TypeVar

from bulwark.clock import Clock
from bulwark.upstream import Endpoint

H = TypeVar("H")


@dataclass
class _IdleHandle(Generic[H]):
    handle: H
    released_at_ns: int


@dataclass
class Pool(Generic[H]):
    clock: Clock
    max_per_endpoint: int = 32
    idle_seconds: float = 30.0
    _idle: dict[Endpoint, deque[_IdleHandle[H]]] = field(default_factory=dict)
    _open: dict[Endpoint, int] = field(default_factory=dict)

    def acquire(self, ep: Endpoint) -> H | None:
        idle_ns = int(self.idle_seconds * 1_000_000_000)
        now = self.clock.now_ns()
        q = self._idle.get(ep)
        if q is not None:
            while q:
                top = q[0]
                if now - top.released_at_ns > idle_ns:
                    q.popleft()
                    self._open[ep] = self._open.get(ep, 0) - 1
                    continue
                # LIFO: pop from front.
                q.popleft()
                # Note: still counted as "open" -- caller will release.
                return top.handle
        # No idle handle. Can we open another?
        if self._open.get(ep, 0) >= self.max_per_endpoint:
            return None
        # Caller must materialize the handle and call register().
        return None

    def register(self, ep: Endpoint) -> None:
        """Account for a freshly opened handle."""
        self._open[ep] = self._open.get(ep, 0) + 1

    def release(self, ep: Endpoint, handle: H) -> None:
        q = self._idle.setdefault(ep, deque())
        q.appendleft(_IdleHandle(handle=handle, released_at_ns=self.clock.now_ns()))

    def mark_dead(self, ep: Endpoint, handle: H) -> None:
        # The handle is gone; just drop our open accounting.
        self._open[ep] = max(0, self._open.get(ep, 0) - 1)
        # Defensively scrub from idle queue if somebody released a dead one.
        q = self._idle.get(ep)
        if q is not None:
            self._idle[ep] = deque(x for x in q if x.handle is not handle)

    def open_count(self, ep: Endpoint) -> int:
        return self._open.get(ep, 0)

    def idle_count(self, ep: Endpoint) -> int:
        q = self._idle.get(ep)
        return len(q) if q is not None else 0
