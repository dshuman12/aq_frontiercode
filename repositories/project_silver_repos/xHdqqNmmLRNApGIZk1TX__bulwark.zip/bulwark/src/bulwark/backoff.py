"""Exponential backoff with jitter.

Helper used by the proxy to schedule retries against a flaky upstream
without becoming a synchronized retry storm. The backoff yields a
sequence of monotonically growing delays (with bounded jitter).

The base interval is ``base_seconds``; subsequent attempts multiply
by 2, capped at ``max_seconds``. We add a uniform random jitter in
``[0, attempt_delay)`` -- "decorrelated" jitter as recommended by the
AWS architecture blog post that everyone cites.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Callable


@dataclass
class Backoff:
    base_seconds: float
    max_seconds: float
    rng: Callable[[float], float] = random.uniform  # type: ignore[assignment]
    _attempt: int = 0

    def __post_init__(self) -> None:
        if self.base_seconds <= 0:
            raise ValueError("base_seconds must be positive")
        if self.max_seconds < self.base_seconds:
            raise ValueError("max_seconds must be >= base_seconds")

    def reset(self) -> None:
        self._attempt = 0

    def next_delay(self) -> float:
        """Return the delay (in seconds) for the next attempt."""
        # Exponential backoff: base * 2^attempt
        raw = self.base_seconds * (2 ** self._attempt)
        capped = min(raw, self.max_seconds)
        jittered = self.rng(0.0, capped)
        self._attempt += 1
        return jittered

    def attempts(self) -> int:
        return self._attempt
