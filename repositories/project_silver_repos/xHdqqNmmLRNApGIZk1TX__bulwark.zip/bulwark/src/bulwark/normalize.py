"""High-level request normalization that the pipeline calls.

This module is glue: it stitches together :mod:`bulwark.urlpath` (path
canonicalization) and :mod:`bulwark.identity` (XFF resolution) and
exposes a single ``normalize_request`` function for the pipeline to
call before it hands off to the engine.
"""

from __future__ import annotations

from dataclasses import dataclass

from bulwark.headers import Headers
from bulwark.identity import Identity, real_client_ip
from bulwark.urlpath import normalize_path


@dataclass(frozen=True, slots=True)
class NormalizedRequest:
    method: str
    path: str
    raw_target: str
    query_string: str
    headers: Headers
    identity: Identity


def normalize_request(
    *,
    method: str,
    target: str,
    headers: Headers,
    peer: str,
    trust_depth: int,
) -> NormalizedRequest:
    """Produce a normalized representation of a request.

    The raw ``target`` may include a query string (``/x?a=1``); we
    split it off but preserve the original. The path component is
    fully canonicalized; the query string is left alone (callers parse
    it as needed via :mod:`bulwark.urlpath`'s siblings, not yet
    written).
    """
    raw_path, sep, query = target.partition("?")
    path = normalize_path(raw_path)
    xff = headers.get("x-forwarded-for")
    ident = real_client_ip(peer=peer, xff_header=xff, trust_depth=trust_depth)
    return NormalizedRequest(
        method=method.upper(),
        path=path,
        raw_target=target,
        query_string=query if sep else "",
        headers=headers,
        identity=ident,
    )
