"""Token bucket rate limiter.

A token bucket is the simplest of the three primitives. Each bucket
has a capacity ``burst`` and refills at ``rate`` tokens per second.
Each successful request consumes one token; if the bucket is empty,
the request is rejected.

The bucket reads time from an injected :class:`Clock` so tests can
drive it deterministically. Buckets also clamp time to the last
observed value: if a clock regression happens (NTP step), we *do
not* refill backwards. The next non-regressed reading resumes refill
from the clamp.
"""

from __future__ import annotations

from dataclasses import dataclass

from bulwark.clock import Clock


@dataclass
class TokenBucket:
    """Classic token bucket limiter.

    Args:
        rate: refill rate in tokens per second.
        burst: bucket capacity (and starting value).
        clock: time source.
    """

    rate: float
    burst: float
    clock: Clock

    def __post_init__(self) -> None:
        if self.rate <= 0:
            raise ValueError("rate must be positive")
        if self.burst <= 0:
            raise ValueError("burst must be positive")
        self._tokens: float = float(self.burst)
        self._last_ns: int = self.clock.now_ns()

    def take(self, n: float = 1.0) -> bool:
        """Try to consume ``n`` tokens. Return True on success."""
        self._refill()
        if self._tokens >= n:
            self._tokens -= n
            return True
        return False

    def available(self) -> float:
        """Return the current token balance (refilling first)."""
        self._refill()
        return self._tokens

    # ---- internals ------------------------------------------------------

    def _refill(self) -> None:
        now = self.clock.now_ns()
        if now < self._last_ns:
            # Clock regression -- clamp instead of refilling backwards.
            self._last_ns = now
            return
        elapsed = (now - self._last_ns) / 1_000_000_000.0
        self._last_ns = now
        added = elapsed * self.rate
        self._tokens = min(self.burst, self._tokens + added)
