"""Request shape inspection.

The inspector classifies a normalized request before the rule engine
runs. It computes things rules want to look at but that don't belong
in the bytecode VM:

* The MIME family of the request body (``json``, ``form``,
  ``multipart``, ``binary``, ``empty``).
* Whether the request smells like an API call vs. a browser hit
  (loosely: does it have an ``Accept: application/json`` header).
* Whether the URL path matches a small static set of "sensitive"
  prefixes (``/admin``, ``/api/internal``, ``/.git``).

Decisions live here so the engine has a single source of truth and
rule writers don't have to re-implement string-prefix matching in the
DSL.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from bulwark.normalize import NormalizedRequest


@dataclass(frozen=True)
class Inspection:
    body_kind: str  # "json" | "form" | "multipart" | "binary" | "empty"
    boundary: str | None
    is_api: bool
    sensitive_prefix: str | None


# Keep this list short. Every entry adds latency to every request.
_SENSITIVE = (
    "/admin",
    "/api/internal",
    "/.git",
    "/.env",
)


def inspect(req: NormalizedRequest) -> Inspection:
    ctype_raw = req.headers.get("content-type") or ""
    body_kind, boundary = _classify_content_type(ctype_raw)
    if body_kind != "empty" and req.headers.get("content-length") == "0":
        body_kind = "empty"
        boundary = None

    accept = req.headers.get("accept") or ""
    is_api = (
        body_kind == "json"
        or "application/json" in accept.lower()
    )
    return Inspection(
        body_kind=body_kind,
        boundary=boundary,
        is_api=is_api,
        sensitive_prefix=_first_match(req.path, _SENSITIVE),
    )


def _classify_content_type(raw: str) -> tuple[str, str | None]:
    if not raw:
        return "empty", None
    media, *params = [p.strip() for p in raw.split(";")]
    media = media.lower()
    if media == "application/json":
        return "json", None
    if media == "application/x-www-form-urlencoded":
        return "form", None
    if media == "multipart/form-data":
        # Find boundary param.
        for p in params:
            if p.lower().startswith("boundary="):
                value = p.split("=", 1)[1]
                if value.startswith('"') and value.endswith('"') and len(value) >= 2:
                    value = value[1:-1]
                return "multipart", value
        return "multipart", None
    return "binary", None


def _first_match(path: str, candidates: Iterable[str]) -> str | None:
    for c in candidates:
        if path == c or path.startswith(c + "/"):
            return c
    return None
