"""Trust configuration.

A simple typed record for the bits the pipeline cares about. Backed
by YAML/TOML on disk, but the rest of the codebase only sees this
class.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class TrustConfig:
    """Per-deployment trust knobs.

    Attributes:
        proxy_depth: How many proxies in front of bulwark are trusted
            to set the X-Forwarded-For header. ``0`` means bulwark is
            internet-facing and any XFF the client sends is hostile.
        trusted_proxy_cidrs: Optional CIDR allowlist for the immediate
            peer; if set, requests from outside these CIDRs are not
            trusted to populate XFF and ``proxy_depth`` is forced to 0
            for that request.
        cookie_secret: HMAC secret for signed cookies. Empty string
            means signing is disabled (and therefore challenge actions
            will fail at engine initialization).
    """

    proxy_depth: int = 0
    trusted_proxy_cidrs: tuple[str, ...] = ()
    cookie_secret: str = ""

    def with_proxy_depth(self, depth: int) -> "TrustConfig":
        return TrustConfig(
            proxy_depth=depth,
            trusted_proxy_cidrs=self.trusted_proxy_cidrs,
            cookie_secret=self.cookie_secret,
        )


@dataclass(frozen=True, slots=True)
class ServerConfig:
    listen: str = "127.0.0.1:7878"
    upstream: str = ""
    rules_path: str = ""
    log_level: str = "info"
    max_body_bytes: int = 16 * 1024 * 1024
    trust: TrustConfig = field(default_factory=TrustConfig)
