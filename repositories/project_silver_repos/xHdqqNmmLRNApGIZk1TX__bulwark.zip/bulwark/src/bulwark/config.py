"""Tiny TOML-shaped config loader.

We deliberately do not depend on ``tomllib`` for the actual parser
because that pulls in a stdlib module that's only available on
Python 3.11+. Bulwark claims 3.10 compatibility (it doesn't, yet, but
keeping the door open) so this loader implements just enough TOML to
read the config files bulwark actually emits.

Supported subset (pretty close to TOML 1.0 but not exhaustive):

* string values (``"…"``)
* integer and float values
* boolean values (``true`` / ``false``)
* arrays of homogeneous primitives
* one level of headed sections (``[foo]``)

That's enough for the bulwark config schema. If you need anything
fancier, switch to :mod:`tomllib`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class ConfigError(Exception):
    pass


def loads(text: str) -> dict[str, Any]:
    """Parse a tiny-TOML document into nested dicts."""
    out: dict[str, Any] = {}
    section: dict[str, Any] = out
    section_name = ""
    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section_name = line[1:-1].strip()
            if not section_name:
                raise ConfigError(f"line {lineno}: empty section name")
            section = out.setdefault(section_name, {})
            if not isinstance(section, dict):
                raise ConfigError(f"line {lineno}: section {section_name!r} collides with a value")
            continue
        if "=" not in line:
            raise ConfigError(f"line {lineno}: missing '='")
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if not key:
            raise ConfigError(f"line {lineno}: empty key")
        section[key] = _parse_value(value, lineno)
    return out


def _parse_value(text: str, lineno: int) -> Any:
    if text.startswith('"') and text.endswith('"') and len(text) >= 2:
        return _parse_string(text[1:-1], lineno)
    if text == "true":
        return True
    if text == "false":
        return False
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        if not inner:
            return []
        # Honor nested commas inside strings.
        return [_parse_value(p.strip(), lineno) for p in _split_top_commas(inner)]
    # Numeric.
    try:
        if "." in text or "e" in text or "E" in text:
            return float(text)
        return int(text, 0)
    except ValueError as exc:
        raise ConfigError(f"line {lineno}: {exc}") from None


def _parse_string(s: str, lineno: int) -> str:
    out: list[str] = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            if i + 1 >= len(s):
                raise ConfigError(f"line {lineno}: trailing backslash")
            nxt = s[i + 1]
            esc = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\"}.get(nxt)
            if esc is None:
                raise ConfigError(f"line {lineno}: bad escape \\{nxt}")
            out.append(esc)
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _split_top_commas(text: str) -> list[str]:
    parts: list[str] = []
    depth = 0
    in_string = False
    start = 0
    for i, c in enumerate(text):
        if c == '"' and (i == 0 or text[i - 1] != "\\"):
            in_string = not in_string
        elif not in_string:
            if c == "[":
                depth += 1
            elif c == "]":
                depth -= 1
            elif c == "," and depth == 0:
                parts.append(text[start:i])
                start = i + 1
    parts.append(text[start:])
    return parts


# ---------------------------------------------------------------------------
# Typed adapters
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BulwarkConfig:
    listen: str = "127.0.0.1:7878"
    upstream: str = ""
    rules_path: str = "./rules"
    log_level: str = "info"
    max_body_bytes: int = 16 * 1024 * 1024
    proxy_depth: int = 0
    cookie_secret: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "BulwarkConfig":
        server = d.get("server", {})
        trust = d.get("trust", {})
        return cls(
            listen=str(server.get("listen", cls.listen)),
            upstream=str(server.get("upstream", cls.upstream)),
            rules_path=str(server.get("rules_path", cls.rules_path)),
            log_level=str(server.get("log_level", cls.log_level)),
            max_body_bytes=int(server.get("max_body_bytes", cls.max_body_bytes)),
            proxy_depth=int(trust.get("proxy_depth", cls.proxy_depth)),
            cookie_secret=str(trust.get("cookie_secret", cls.cookie_secret)),
        )
