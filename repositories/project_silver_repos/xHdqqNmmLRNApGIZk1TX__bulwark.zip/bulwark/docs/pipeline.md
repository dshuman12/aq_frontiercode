# Pipeline

The 16 layers, in order, that handle one request:

1. **wire** (`bulwark.wire`) -- parse the request line and headers from
   raw bytes. Smuggling-resistant: rejects ambiguous framing.
2. **headers** (`bulwark.headers`) -- case-insensitive header collection.
3. **chunked** (`bulwark.chunked`) -- body decoder for
   `Transfer-Encoding: chunked`.
4. **normalize** (`bulwark.normalize`) -- canonicalize the path, split
   query string, decode percent-encodings (preserving `%2F`).
5. **identity** (`bulwark.identity`) -- resolve client IP through the
   trusted XFF chain.
6. **inspector** (`bulwark.inspector`) -- classify body MIME, decide
   sensitive prefix, mark API vs. browser.
7. **semcheck** (`bulwark.semcheck`) -- at ruleset load time only.
8. **compiler** (`bulwark.compiler`) -- at ruleset load time only.
9. **optimizer** (`bulwark.optimizer`) -- at ruleset load time only.
10. **engine** (`bulwark.engine`) -- interpret bytecode against the
    request, collect verdicts.
11. **limiter** (`bulwark.limiter`) -- invoked from `limit()` actions
    inside the engine.
12. **reputation** (`bulwark.reputation`) -- IP-keyed feed lookup with
    TTL and longest-prefix-match.
13. **pipeline** (`bulwark.pipeline`) -- coalesce verdicts, decide
    short-circuit vs. proxy.
14. **proxy** (`bulwark.proxy`) -- pick endpoint, acquire pooled
    handle, run the upstream call, account for success/failure.
15. **audit** (`bulwark.audit`) -- redact and append to chainlog.
16. **config / loader / reload** (`bulwark.config`, `bulwark.loader`,
    `bulwark.reload`) -- boot-time config and hot reload.

Each layer enforces some piece of an invariant. The full list lives
in `NOTES.md` (I1–I15). Cross-layer invariants are the source of most
real bugs in this codebase.

## Cross-layer invariants

**I1 (normalize/urlpath)** -- `%2F` is preserved through normalization;
other percent-escapes are decoded.

**I4 (identity)** -- when XFF is shorter than `proxy_depth`, the real
client IP falls back to the socket peer.

**I6 (limiter/clock)** -- clock injection is mandatory; backwards
clock motion never refills.

**I7 (pipeline/reload)** -- every request pins exactly one ruleset
version for its entire lifetime.

**I9 (audit/chainlog)** -- the audit chain links every entry to its
predecessor; a single in-place edit breaks `verify()`.

These invariants are tested individually in the corresponding test
files. The pipeline test file exercises some of them in combination.
