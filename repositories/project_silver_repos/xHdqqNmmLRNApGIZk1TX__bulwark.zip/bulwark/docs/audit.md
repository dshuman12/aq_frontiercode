# Audit log

Every request handled by bulwark produces exactly one entry in the
audit log. The log is hash-chained: each entry stores the SHA-256 of
the previous entry's serialized form, so any in-place edit short of
rewriting the whole tail breaks the chain.

```python
from bulwark.chainlog import ChainLog, verify

log = ChainLog()
# ... pipeline writes entries ...
assert verify(log.entries())
```

## Record shape

```jsonc
{
    "seq": 42,
    "prev": "f7…",        // sha256 of previous entry
    "tag":  "9c…",        // sha256 of THIS entry
    "payload": {
        "ts": 1717100000.123,
        "method": "GET",
        "path": "/admin",
        "client_ip": "10.0.0.5",
        "headers": [["Authorization", "[REDACTED]"], ...],
        "verdict": {
            "rule":   "deny_internal",
            "phase":  "pre_route",
            "action": "block",
            "status": 403,
            "tags":   [],
            "version": "abc123…"  // ruleset version pinned for the request
        },
        "upstream": "api",
        "endpoint": "10.0.0.50:8080"
    }
}
```

## Redaction

The audit emitter calls `bulwark.redact` on every user-controlled
field before it goes into the log. The default policy redacts:

* the values of these headers: `Authorization`, `Cookie`, `Set-Cookie`,
  `Proxy-Authorization`, `X-API-Key`, `X-Auth-Token`.
* JSON keys named `password`, `secret`, `token`, `apiKey`
  (case-insensitive).
* Email addresses and credit-card-shaped digit runs in any string.
* `Bearer …` tokens anywhere in a string.

The policy is conservative -- false negatives are recoverable, false
positives shred otherwise-useful logs. Override by passing a custom
`RedactPolicy` to `AuditEmitter`.

## Ruleset version pinning

The audit record includes the `version` of the ruleset that decided
the request. Hot reloads create a new version; in-flight requests
finish under the version they started with. This means you can
correlate `verdict.version` with the source files in `examples/` (or
your own deployment) for forensic replay.
