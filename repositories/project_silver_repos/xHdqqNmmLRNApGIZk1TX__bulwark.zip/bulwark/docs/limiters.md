# Rate limiters

Bulwark ships three rate-limiter primitives. They share a common API:

```python
from bulwark.clock import Clock
from bulwark.buckets import TokenBucket
from bulwark.gcra import GCRA
from bulwark.slidingwindow import SlidingWindowLog

clk = Clock()
b = TokenBucket(rate=100.0, burst=200, clock=clk)
b.take()  # → True / False
```

## Token bucket

`bulwark.buckets.TokenBucket` is the friendliest of the three. It refills
linearly and admits a burst of up to `burst` tokens at a time. Use it
when you want "average rate, with some leniency" semantics, e.g. login
attempts at "5 / minute, burst 10".

## GCRA

`bulwark.gcra.GCRA` is a constant-cost limiter using a single state
variable (the theoretical arrival time). It's marginally more accurate
than a token bucket at the cost of slightly less intuitive `burst`
semantics: `burst=N` admits up to N back-to-back requests before
shaping kicks in.

GCRA is what you want when you're rate-limiting many keys (each one's
state is a single integer) or when you want to derive the next
admission time without simulating a refill.

## Sliding window log

`bulwark.slidingwindow.SlidingWindowLog` keeps an explicit deque of
event timestamps. It's exact -- there's no smoothing -- but it's also
linear in the number of events held. Use it for low-rate, high-stakes
limits like "5 password resets per email per hour", and never for
high-RPS APIs.

## Clock injection

Every limiter takes a `Clock` (or, in tests, a `FakeClock`). The
limiter clamps against backwards clock motion. Real production
deployments are still strongly recommended to use `time.monotonic_ns`
which never goes backwards.

## Composition: `Limiter`

`bulwark.limiter.Limiter` materializes one underlying limiter per
`(rule_name, key)` pair on demand. Rule writers can declare:

```text
when path == "/login" then limit(key=ident.client_ip, rate="5/min", burst=10)
```

The composite limiter keeps a soft-cap on the keyspace and evicts
the oldest quarter when the cap is hit.
