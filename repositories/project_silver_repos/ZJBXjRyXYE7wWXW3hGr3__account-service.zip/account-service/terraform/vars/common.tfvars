SERVICE_NAME      = "account-service"
SERVICE_NAME_OIDC = "account-service-oidc"
REGION            = "eu-west-1"

BASE_PATH                = "service/accounts"
DISABLE_DEFAULT_ENDPOINT = true

ACCOUNT_UPSERTED_EVENT_LAMBDA  = "accountUpsertedEvent"
CUSTOMER_UPSERTED_EVENT_LAMBDA = "customerUpsertedEvent"

GITHUB_REPO = "onmoapp/account-service"
