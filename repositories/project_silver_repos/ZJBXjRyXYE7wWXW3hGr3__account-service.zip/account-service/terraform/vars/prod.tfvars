ENVIRONMENT = "prod"

ONMO_API_URL             = "api.onmo.app"
FRONTEND_URL             = "https://onmo.app"
ONMO_AUTH_URL            = "auth.onmo.app"
INTERNAL_API_DOMAIN_NAME = "internal-api.onmo.app"
CRM_API_DOMAIN_NAME      = "crm-api.onmo.app"

SF_FE_URL           = "https://onmo.my.salesforce.com"
SF_LIGHTNING_FE_URL = "https://onmo.lightning.force.com/"

CUSTOM_DOMAIN_NAMES          = ["internal-api.onmo.app", "crm-api.onmo.app"]
CUSTOM_DOMAIN_NAMES_CUSTOMER = ["api.onmo.app"]

THROTTLING_BURST_LIMIT = 6000
THROTTLING_RATE_LIMIT  = 2000

PROMOTION_REMINDER_HORIZON_DAYS = 14

DOCUMENT_BUCKET_NAME = "onmo-transfer"
SLACK_CHANNEL        = "alerts-prod"

MAMBU_SECRET_ARN                      = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-mambu-prod-7DobVE"
STRIPE_SECRET_ARN                     = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-stripe-prod-uIqtQZ"
PAYMENTOLOGY_SECRET_ARN               = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-paymentology-prod-NNCm5W"
PAYMENTOLOGY_SECRET_SSL_ARN           = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-paymentology-ssl-prod-QAppy5"
DIRECT_DEBIT_SECRET_ARN               = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-directdebit-prod-HXvNMM"
CRM_SECRET_ARN                        = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-crm-prod-xcwCpB"
API_KEY_SECRET_ARN                    = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-service-layer-prod-376R2F"
SALES_FORCE_API_CONNECTION_SECRET_ARN = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:events!connection/onmo-sales-force-api-connection-prod/40528f5f-372d-4218-8a1a-694a93145c0c-Yp9Cr9"
POSTHOG_SECRET_ARN                    = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-posthog-prod-505ciL"
