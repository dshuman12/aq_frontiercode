ENVIRONMENT = "staging"

ONMO_API_URL             = "api.staging.onmo.app"
FRONTEND_URL             = "https://staging.onmo.app"
ONMO_AUTH_URL            = "auth.staging.onmo.app"
INTERNAL_API_DOMAIN_NAME = "internal-api.staging.onmo.app"
CRM_API_DOMAIN_NAME      = "crm-api.staging.onmo.app"

SF_FE_URL           = "https://onmo--staging.sandbox.my.salesforce.com"
SF_LIGHTNING_FE_URL = "https://onmo--staging.sandbox.lightning.force.com/"

CUSTOM_DOMAIN_NAMES          = ["internal-api.staging.onmo.app", "crm-api.staging.onmo.app"]
CUSTOM_DOMAIN_NAMES_CUSTOMER = ["api.staging.onmo.app"]

THROTTLING_BURST_LIMIT = 200
THROTTLING_RATE_LIMIT  = 75

PROMOTION_REMINDER_HORIZON_DAYS = 14

DOCUMENT_BUCKET_NAME = "onmo-transfer-staging"
SLACK_CHANNEL        = "datadog-alert-testing"

MAMBU_SECRET_ARN                      = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-mambu-staging-YdSH1E"
STRIPE_SECRET_ARN                     = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-stripe-staging-mdNyEZ"
PAYMENTOLOGY_SECRET_ARN               = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-paymentology-staging-OWKuz3"
PAYMENTOLOGY_SECRET_SSL_ARN           = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-paymentology-ssl-staging-Z28hI4"
DIRECT_DEBIT_SECRET_ARN               = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-directdebit-staging-tKOoYq"
CRM_SECRET_ARN                        = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:crm_staging-RwKALK"
API_KEY_SECRET_ARN                    = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-service-layer-staging-QMEtOV"
SALES_FORCE_API_CONNECTION_SECRET_ARN = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:events!connection/onmo-sales-force-api-connection-staging/2529cce3-3d1d-4457-bc66-08b8a38048a4-LApI8v"
POSTHOG_SECRET_ARN                    = "arn:aws:secretsmanager:eu-west-1:363532003063:secret:onmo-posthog-staging-rn3jRm"
