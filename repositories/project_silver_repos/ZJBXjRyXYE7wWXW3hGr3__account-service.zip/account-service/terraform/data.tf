data "aws_ssm_parameter" "account_upserted_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/onmo-account-upserted-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "mambu_ip_list" {
  name = "/mambu/sender-ip-addresses/${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "mambu_webhooks_user_agents" {
  name = "/mambu/webhooks/user-agents/${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "apata_webhooks_user_agents" {
  name = "/apata/webhooks/user-agents/${var.ENVIRONMENT}"
}

# Paymentology VPC config
data "aws_ssm_parameter" "pty_subnets" {
  name = "/onmo/paymentology/service-layer/subnetIds/${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "pty_security_groups" {
  name = "/onmo/paymentology/service-layer/securityGroupIds/${var.ENVIRONMENT}"
}

# OIDC Authorizer
data "aws_lambda_function" "oidc_authorizer_function" {
  function_name = "${var.ENVIRONMENT}-authentication-authorizer"
}

# API Gateway ARN
data "aws_api_gateway_rest_api" "customer-api" {
  name = "${var.ENVIRONMENT}-customer-service"
}

data "aws_api_gateway_rest_api" "transaction-api" {
  name = "${var.ENVIRONMENT}-transactions-service"
}

data "aws_api_gateway_rest_api" "card-api" {
  name = "${var.ENVIRONMENT}-card-service"
}

data "aws_api_gateway_rest_api" "repayment-api" {
  name = "${var.ENVIRONMENT}-repayment-service"
}

data "aws_api_gateway_rest_api" "analytics-api" {
  name = "${var.ENVIRONMENT}-analytics-service"
}

data "aws_api_gateway_rest_api" "customer-care-api" {
  name = "${var.ENVIRONMENT}-customer-care"
}

data "aws_ssm_parameter" "clm_updated_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/onmo-clm-updated-${var.ENVIRONMENT}"
}

data "aws_dynamodb_table" "clm" {
  name = local.CLM_TABLE
}

