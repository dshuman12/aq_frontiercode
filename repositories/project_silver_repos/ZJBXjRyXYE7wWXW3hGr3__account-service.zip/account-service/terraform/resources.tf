
data "aws_lambda_function" "authorizer_function" {
  function_name = "${var.ENVIRONMENT}-account-service-authorizer"
}

/**
 * Create a dead letter queue for the account created queue
 */
resource "aws_sqs_queue" "account-created-event-dlq" {
  name                       = "account-created-event-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 300
}

/**
 * Create a queue and associate it with the dlq
 * The queue will have a redrive policy that will send messages to the dlq after 3 failed attempts
 */
resource "aws_sqs_queue" "account-created-event-queue" {
  depends_on                 = [aws_sqs_queue.account-created-event-dlq]
  name                       = "account-created-event-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 300

  redrive_policy = jsonencode({
    maxReceiveCount     = 4
    deadLetterTargetArn = aws_sqs_queue.account-created-event-dlq.arn
  })
}
