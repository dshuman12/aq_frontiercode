# Service Config

locals {
  # Derived resource names - common prefix/suffix + environment
  USER_TABLE                      = "mobile-${var.ENVIRONMENT}"
  CLM_TABLE                       = "clm-${var.ENVIRONMENT}"
  CUSTOMER_TO_CARD_MAPPING_TABLE  = "customer-to-card-mapping-${var.ENVIRONMENT}"
  INTEREST_FEES_FREEZE_TABLE      = "interest-fees-freeze-${var.ENVIRONMENT}"
  PROMOTIONS_TABLE                = "promotions-${var.ENVIRONMENT}"
  ARCHIVED_S3_BUCKET_NAME         = "onmo-archived-events-${var.ENVIRONMENT}"
  ARCHIVED_S3_BUCKET_ARN          = "arn:aws:s3:::${local.ARCHIVED_S3_BUCKET_NAME}"
  DD_RETRY_GROUP_NAME             = "${var.ENVIRONMENT}-repayment-service-dd-retries"
  ONMO_BUSINESS_EVENTS_STREAM     = "onmo-business-events-stream-${var.ENVIRONMENT}"
  ONMO_BUSINESS_EVENTS_STREAM_DLQ = "onmo-business-stream-events-dlq-${var.ENVIRONMENT}"
  AUTH_TOKENS_TABLE               = "auth-tokens-${var.ENVIRONMENT}"

  service_config = {
    service_name        = var.SERVICE_NAME
    environment         = var.ENVIRONMENT
    region              = var.REGION
    aws_account_id      = var.AWS_ACCOUNT_ID
    SF_FE_URL           = var.SF_FE_URL
    SF_LIGHTNING_FE_URL = var.SF_LIGHTNING_FE_URL
  }

  service_config_oidc = {
    service_name   = var.SERVICE_NAME_OIDC
    environment    = var.ENVIRONMENT
    region         = var.REGION
    aws_account_id = var.AWS_ACCOUNT_ID
  }

  lambda_environment_variables = {
    ENVIRONMENT                           = var.ENVIRONMENT
    STAGE                                 = var.ENVIRONMENT
    REGION                                = var.REGION
    AWS_ACCOUNT_ID                        = var.AWS_ACCOUNT_ID
    ONMO_API_URL                          = var.ONMO_API_URL
    MAMBU_SECRET_ARN                      = var.MAMBU_SECRET_ARN
    CRM_SECRET_ARN                        = var.CRM_SECRET_ARN
    API_KEY_SECRET_ARN                    = var.API_KEY_SECRET_ARN
    SALES_FORCE_API_CONNECTION_SECRET_ARN = var.SALES_FORCE_API_CONNECTION_SECRET_ARN
    CRM_API_DOMAIN_NAME                   = var.CRM_API_DOMAIN_NAME
    USER_TABLE                            = local.USER_TABLE
    CUSTOMER_TO_CARD_MAPPING_TABLE        = local.CUSTOMER_TO_CARD_MAPPING_TABLE
    CLM_TABLE                             = local.CLM_TABLE
    SERVICE_NAME                          = var.SERVICE_NAME
    ACCOUNT_UPSERTED_SCHEMA_VERSION       = data.aws_ssm_parameter.account_upserted_schema_version_id.value
    SUPPRESS_LOGS                         = var.SUPPRESS_LOGS
    MAMBU_WEBHOOKS_USER_AGENTS            = data.aws_ssm_parameter.mambu_webhooks_user_agents.value
    APATA_WEBHOOKS_USER_AGENTS            = data.aws_ssm_parameter.apata_webhooks_user_agents.value
    ACCOUNT_CREATED_EVENT_QUEUE           = aws_sqs_queue.account-created-event-queue.url
    INTEREST_FEES_FREEZE_TABLE            = local.INTEREST_FEES_FREEZE_TABLE
    ARCHIVED_S3_BUCKET_ARN                = local.ARCHIVED_S3_BUCKET_ARN
    ARCHIVED_S3_BUCKET_NAME               = local.ARCHIVED_S3_BUCKET_NAME
    REPAYMENT_COLLECTED_RETRY_DLQ_URL     = aws_sqs_queue.repaymentCollectedRetryDlq.url
    DD_RETRY_GROUP_NAME                   = local.DD_RETRY_GROUP_NAME
    CLM_UPDATE_SCHEMA_VERSION             = data.aws_ssm_parameter.clm_updated_schema_version_id.value
    SFMC_COMMS_QUEUE_URL                  = var.SFMC_COMMS_QUEUE_URL
    POSTHOG_SECRET_NAME                   = var.POSTHOG_SECRET_ARN
    PROMOTIONS_TABLE                      = local.PROMOTIONS_TABLE
    PROMOTION_REMINDER_HORIZON_DAYS       = var.PROMOTION_REMINDER_HORIZON_DAYS
  }


  lambda_config = {
    source_dir  = "${path.root}/../build"
    file_suffix = ".mjs"
  }


  gateway_config = {
    disable_default_endpoint = var.DISABLE_DEFAULT_ENDPOINT,
    custom_domain_names      = var.CUSTOM_DOMAIN_NAMES
    web_acl_arn              = var.WEB_ACL_ARN
    throttling_burst_limit   = var.THROTTLING_BURST_LIMIT
    throttling_rate_limit    = var.THROTTLING_RATE_LIMIT
    base_path                = var.BASE_PATH
    MAMBU_IP_LIST            = split(",", data.aws_ssm_parameter.mambu_ip_list.value)
  }

  gateway_config_oidc = {
    disable_default_endpoint = var.DISABLE_DEFAULT_ENDPOINT,
    custom_domain_names      = var.CUSTOM_DOMAIN_NAMES_CUSTOMER
    web_acl_arn              = var.WEB_ACL_ARN
    throttling_burst_limit   = var.THROTTLING_BURST_LIMIT
    throttling_rate_limit    = var.THROTTLING_RATE_LIMIT
    base_path                = var.BASE_PATH
  }

  paymentology_vpc_config = {
    subnet_ids         = split(",", data.aws_ssm_parameter.pty_subnets.value)
    security_group_ids = split(",", data.aws_ssm_parameter.pty_security_groups.value)
  }

  # Lambda env var groups for test output
  lambda_test_env = {
    ENVIRONMENT                = var.ENVIRONMENT
    STAGE                      = var.ENVIRONMENT
    REGION                     = var.REGION
    ONMO_API_URL               = var.ONMO_API_URL
    ONMO_AUTH_URL              = var.ONMO_AUTH_URL
    INTERNAL_API_DOMAIN_NAME   = var.INTERNAL_API_DOMAIN_NAME
    USER_TABLE                 = local.USER_TABLE
    CLM_TABLE                  = local.CLM_TABLE
    DOCUMENT_BUCKET_NAME       = var.DOCUMENT_BUCKET_NAME
    INTEREST_FEES_FREEZE_TABLE = local.INTEREST_FEES_FREEZE_TABLE
    AUTH_TOKENS_TABLE          = local.AUTH_TOKENS_TABLE
    PROMOTIONS_TABLE           = local.PROMOTIONS_TABLE
  }
}

# SERVICE CONFIG
variable "SERVICE_NAME" {
  type = string
}

variable "SERVICE_NAME_OIDC" {
  type = string
}

variable "ENVIRONMENT" {
  type = string
}

variable "REGION" {
  type = string
}

variable "AWS_ACCOUNT_ID" {
  type = string
}

# SECRET ARNS

variable "MAMBU_SECRET_ARN" {
  type = string
}

variable "PAYMENTOLOGY_SECRET_ARN" {
  type = string
}

variable "PAYMENTOLOGY_SECRET_SSL_ARN" {
  type = string
}

variable "CRM_SECRET_ARN" {
  type = string
}

variable "API_KEY_SECRET_ARN" {
  type = string
}

variable "SALES_FORCE_API_CONNECTION_SECRET_ARN" {
  type = string
}

variable "DIRECT_DEBIT_SECRET_ARN" {
  type = string
}

variable "STRIPE_SECRET_ARN" {
  type = string
}

variable "POSTHOG_SECRET_ARN" {
  type = string
}

variable "ONMO_BUSINESS_EVENTS_STREAM" {
  type = string
}

variable "ONMO_BUSINESS_EVENTS_STREAM_DLQ" {
  type = string
}

# GATEWAY CONFIG
variable "DISABLE_DEFAULT_ENDPOINT" {
  type = bool
}

variable "CUSTOM_DOMAIN_NAMES" {
  type = list(string)
}

variable "CUSTOM_DOMAIN_NAMES_CUSTOMER" {
  type = list(string)
}

variable "WEB_ACL_ARN" {
  type = string
}

variable "THROTTLING_BURST_LIMIT" {
  type = number
}

variable "THROTTLING_RATE_LIMIT" {
  type = number
}

variable "ONMO_API_URL" {
  type = string
}

variable "BASE_PATH" {
  type = string
}

variable "SF_FE_URL" {
  type = string
}

variable "SF_LIGHTNING_FE_URL" {
  type = string
}

variable "FRONTEND_URL" {
  type = string
}

variable "ONMO_AUTH_URL" {
  type = string
}

variable "INTERNAL_API_DOMAIN_NAME" {
  type = string
}

variable "DOCUMENT_BUCKET_NAME" {
  type = string
}

variable "CRM_API_DOMAIN_NAME" {
  type = string
}

variable "SUPPRESS_LOGS" {
  type    = string
  default = "true"
}

variable "ACCOUNT_UPSERTED_EVENT_LAMBDA" {
  type = string
}

variable "CUSTOMER_UPSERTED_EVENT_LAMBDA" {
  type = string
}

variable "DATADOG_API_KEY" {
  type = string
}

variable "DATADOG_APP_KEY" {
  type = string
}

variable "GITHUB_REPO" {
  type = string
}

variable "SLACK_CHANNEL" {
  type = string
}

variable "SFMC_COMMS_QUEUE_URL" {
  type = string
}

variable "SFMC_COMMS_QUEUE_ARN" {
  type = string
}

variable "PROMOTION_REMINDER_HORIZON_DAYS" {
  type = number
}
