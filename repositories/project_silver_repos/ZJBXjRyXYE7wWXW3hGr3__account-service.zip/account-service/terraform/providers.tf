terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.40.0"
    }
    datadog = {
      source  = "DataDog/datadog"
      version = "~> 3.42.0"
    }
  }

  backend "s3" {
    # terraform/config/${environment}.backend.remote
  }
}

provider "aws" {
  region = var.REGION
  default_tags {
    tags = {
      ManagedBy   = "Terraform",
      Owner       = "Engineering-Team",
      OwnerEmail  = "engineering-team@onmo.app",
      Project     = var.SERVICE_NAME,
      Environment = var.ENVIRONMENT
    }
  }
}

provider "datadog" {
  api_key = var.DATADOG_API_KEY
  app_key = var.DATADOG_APP_KEY
  api_url = "https://api.datadoghq.eu"
}
