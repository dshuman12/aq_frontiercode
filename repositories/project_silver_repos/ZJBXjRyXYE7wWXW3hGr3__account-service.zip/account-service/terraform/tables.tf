resource "aws_dynamodb_table" "interest_fees_freeze" {
  name         = "interest-fees-freeze-${var.ENVIRONMENT}"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "accountId"
  range_key    = "createdAt"

  deletion_protection_enabled = true

  attribute {
    name = "accountId"
    type = "S"
  }
  attribute {
    name = "createdAt"
    type = "S"
  }
  attribute {
    name = "status"
    type = "S"
  }

  local_secondary_index {
    name            = "LSI_Status"
    range_key       = "status"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "CreatedAtIndex"
    projection_type = "ALL"

    key_schema {
      attribute_name = "createdAt"
      key_type       = "HASH"
    }
  }

  tags = {
    Name = "interest-fees-freeze-${var.ENVIRONMENT}"
  }
}

resource "aws_dynamodb_table" "promotions" {
  name         = "promotions-${var.ENVIRONMENT}"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"
  range_key    = "promotion_id"

  deletion_protection_enabled = true

  attribute {
    name = "id"
    type = "S"
  }
  attribute {
    name = "promotion_id"
    type = "S"
  }
  attribute {
    name = "status"
    type = "S"
  }
  attribute {
    name = "promotion_type"
    type = "S"
  }
  attribute {
    name = "notification_status"
    type = "S"
  }
  attribute {
    name = "end_date"
    type = "N"
  }

  global_secondary_index {
    name            = "sweep-index"
    projection_type = "ALL"

    key_schema {
      attribute_name = "status"
      key_type       = "HASH"
    }
    key_schema {
      attribute_name = "promotion_type"
      key_type       = "HASH"
    }
    key_schema {
      attribute_name = "end_date"
      key_type       = "RANGE"
    }
  }

  global_secondary_index {
    name            = "email-sweep-index"
    projection_type = "ALL"

    key_schema {
      attribute_name = "notification_status"
      key_type       = "HASH"
    }
    key_schema {
      attribute_name = "promotion_type"
      key_type       = "HASH"
    }
    key_schema {
      attribute_name = "end_date"
      key_type       = "RANGE"
    }
  }

  point_in_time_recovery {
    enabled = true
  }

  tags = {
    Name = "promotions-${var.ENVIRONMENT}"
  }
}
