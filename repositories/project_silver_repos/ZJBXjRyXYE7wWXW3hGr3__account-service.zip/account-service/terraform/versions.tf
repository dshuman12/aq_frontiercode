# ── Version Stage Quota Guard ────────────────────────────────────────────────
#
# Each version module creates one API Gateway stage per minor version entry.
# AWS enforces a quota on stages per REST API (default 10, currently 15).
# Exceeding this quota causes terraform apply to hang indefinitely on stage
# creation — AWS silently rejects the request and the provider retries forever.
#
# To prevent this:
#  1. Minor version lists are defined as locals (below) so the stage guard can count them.
#  2. The "api_gateway_stage_limit" check block fails terraform plan before any
#     resources are touched if the total would exceed the quota.
#
# When adding a new minor version:
# - Add it to the relevant local list below
# - If the guard fails, either prune old minor versions no longer receiving
#   traffic, or request a quota increase in the AWS console
#   (Service Quotas > API Gateway > Stages per API)

locals {
  v5_minor_versions      = [31, 32, 33, 34, 35, 36, 37, 39, 41, 42, 43, 44]
  v1_oidc_minor_versions = [19, 20, 22, 23, 24, 25, 26]

  # Stage budget per gateway:
  #   v5 gateway:   1 fixed (v5 base) + v5 minors
  #   oidc gateway: 1 fixed (v1 base) + v1_oidc minors
  api_gateway_stage_count_v5   = 1 + length(local.v5_minor_versions)
  api_gateway_stage_count_oidc = 1 + length(local.v1_oidc_minor_versions)
  api_gateway_stage_quota      = 15
}

resource "terraform_data" "api_gateway_stage_limit" {
  lifecycle {
    precondition {
      condition     = local.api_gateway_stage_count_v5 <= local.api_gateway_stage_quota
      error_message = "v5 API Gateway stages (${local.api_gateway_stage_count_v5}) would exceed quota (${local.api_gateway_stage_quota}). Prune old minor versions or request a quota increase."
    }
    precondition {
      condition     = local.api_gateway_stage_count_oidc <= local.api_gateway_stage_quota
      error_message = "v1_oidc API Gateway stages (${local.api_gateway_stage_count_oidc}) would exceed quota (${local.api_gateway_stage_quota}). Prune old minor versions or request a quota increase."
    }
  }
}

module "v5" {
  source         = "app.terraform.io/onmo/module-version-api/aws"
  version        = "4.0.2"
  service_config = local.service_config
  gateway_config = local.gateway_config

  rest_api_gateway = module.rest_api_gateway
  version_name     = "v5"
  minor_versions   = local.v5_minor_versions
  # we can remove up to v_25, as it was last used on 23-Apr-2025.

  lambda_functions = [
    module.creditGetAccount,
    module.creditUpdateAccount,
    module.creditFullLock,
    module.creditFullUnlock,
    module.creditSpendingLock,
    module.creditSpendingUnlock,
    module.creditCloseAccount,
    module.creditGetDocuments,
    module.getSignedURLOfDocument,
    module.creditPaymentPlan,
    module.accountUpsertedEvent,
    module.accountCreatedEventToSqs,
    module.updateAccountFlag,
    module.creditFreezeAccount,
    module.creditUnfreezeAccount,
    module.accountBalancesBreakdown,
    module.creditWriteOffAccount,
    module.updateCreditLimit,
    module.updateCLMPreferences,
    module.getCLMPreferences,
    module.createPromotion,
    module.getAccountsPromotions,
    { name = "${var.ENVIRONMENT}-account-service-authorizer", version = data.aws_lambda_function.authorizer_function.version },
  ]
}

module "v1_oidc" {
  source         = "app.terraform.io/onmo/module-version-api/aws"
  version        = "4.0.2"
  service_config = local.service_config_oidc
  gateway_config = local.gateway_config_oidc

  rest_api_gateway = module.rest_api_gateway_oidc
  version_name     = "v1"
  minor_versions   = local.v1_oidc_minor_versions
  # we can remove up to v_9, as it was last used on 05-Feb-2025.

  lambda_functions = [
    module.creditGetAccount,
    module.creditGetDocuments,
    module.creditUpdateAccount,
    module.getSignedURLOfDocument,
    module.accountBalancesBreakdown,
    module.updateCLMPreferences,
    module.getCLMPreferences,
    { name = "${var.ENVIRONMENT}-authentication-authorizer", version = data.aws_lambda_function.oidc_authorizer_function.version },
  ]
}
