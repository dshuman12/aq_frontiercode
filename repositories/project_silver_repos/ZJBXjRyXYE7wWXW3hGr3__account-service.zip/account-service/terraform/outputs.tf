output "lambda_test_env" {
  description = "Union of all Lambda env var groups for CI test jobs"
  value = {
    for k, v in local.lambda_test_env : k => v
  }
  sensitive = false
}
