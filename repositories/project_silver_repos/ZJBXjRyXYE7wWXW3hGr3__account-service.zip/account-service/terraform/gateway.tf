locals {
  uri_prefix     = "arn:aws:apigateway:${var.REGION}:lambda:path/2015-03-31/functions"
  kinesis_prefix = "arn:aws:kinesis:${var.REGION}:${var.AWS_ACCOUNT_ID}:stream"
}


module "rest_api_gateway" {
  source         = "app.terraform.io/onmo/module-rest-api-gateway/aws"
  version        = "3.0.0"
  service_config = local.service_config
  gateway_config = local.gateway_config
  description    = "Account Service"

  aws_integration_paths = [
    {
      path_from_root = "/credit/{accountId}"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "PATCH",
          lambda_function_name   = module.creditUpdateAccount.name,
          lambda_authorizer_name = module.authorizer.name

        },
        {
          method                 = "GET",
          lambda_function_name   = module.creditGetAccount.name,
          lambda_authorizer_name = module.authorizer.name

        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/balance-breakdown"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = module.accountBalancesBreakdown.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/full-lock"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST",
          lambda_function_name   = module.creditFullLock.name,
          lambda_authorizer_name = module.authorizer.name

        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/full-unlock"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditFullUnlock.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/spending-lock"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditSpendingLock.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/spending-unlock"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditSpendingUnlock.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/close"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditCloseAccount.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/write-off"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditWriteOffAccount.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/credit-limit"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.updateCreditLimit.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/documents"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = module.creditGetDocuments.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/document/generate-url"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.getSignedURLOfDocument.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/payment-plan"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditPaymentPlan.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/publish-account-upserted-event"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.accountUpsertedEvent.name,
          lambda_authorizer_name = module.authorizer.name
          deny_conditions = jsonencode([
            {
              NotIpAddress = {
                "aws:SourceIp" = local.gateway_config.MAMBU_IP_LIST
              }
            }
          ])
        }
      ]
    },
    {
      path_from_root = "/publish-account-created-event"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.accountCreatedEventToSqs.name,
          lambda_authorizer_name = module.authorizer.name
          deny_conditions = jsonencode([
            {
              NotIpAddress = {
                "aws:SourceIp" = local.gateway_config.MAMBU_IP_LIST
              }
            }
          ])
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/update-flag"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.updateAccountFlag.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/interest-and-fees/freeze"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditFreezeAccount.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/interest-and-fees/unfreeze"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.creditUnfreezeAccount.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/clm/preferences"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "PUT",
          lambda_function_name   = module.updateCLMPreferences.name,
          lambda_authorizer_name = module.authorizer.name
        },
        {
          method                 = "GET",
          lambda_function_name   = module.getCLMPreferences.name,
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/promotions"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.createPromotion.name
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    },
    {
      path_from_root = "/promotions/batch-get"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.getAccountsPromotions.name
          lambda_authorizer_name = module.authorizer.name
        }
      ]
    }
  ]

  lambda_authorizers = [
    { lambda_function_name = module.authorizer.name, auth_config = { type = "request" }, ttl = 0 }
  ]

}

module "rest_api_gateway_oidc" {
  source         = "app.terraform.io/onmo/module-rest-api-gateway/aws"
  version        = "3.0.0"
  service_config = local.service_config_oidc
  gateway_config = local.gateway_config_oidc
  description    = "Account Service With OIDC Authentication"

  aws_integration_paths = [
    {
      path_from_root = "/credit/{accountId}"
      cors           = { allow_origins = [var.FRONTEND_URL], allow_custom_headers = ["Content-Type", "Cookie", "Authorization"] }

      integrations = [
        {
          method                 = "GET",
          lambda_function_name   = module.creditGetAccount.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "PATCH",
          lambda_function_name   = module.creditUpdateAccount.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
      ]
    },
    {
      path_from_root = "/credit/{accountId}/documents"
      cors           = { allow_origins = [var.FRONTEND_URL], allow_custom_headers = ["Content-Type", "Cookie", "Authorization"] }

      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = module.creditGetDocuments.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/document/generate-url"
      cors           = { allow_origins = [var.FRONTEND_URL], allow_custom_headers = ["Content-Type", "Cookie", "Authorization"] }

      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = module.getSignedURLOfDocument.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/balance-breakdown"
      cors           = { allow_origins = [var.FRONTEND_URL], allow_custom_headers = ["Content-Type", "Cookie", "Authorization"] }

      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = module.accountBalancesBreakdown.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "/credit/{accountId}/clm/preferences"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }

      integrations = [
        {
          method                 = "PUT",
          lambda_function_name   = module.updateCLMPreferences.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "GET",
          lambda_function_name   = module.getCLMPreferences.name,
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    }
  ]

  lambda_authorizers = [
    {
      lambda_function_name = "${var.ENVIRONMENT}-authentication-authorizer",
      auth_config          = { type = "token", location = "header", key_name = "Authorization" }
      ttl                  = 0
    }
  ]
}
