locals {
  staging_notification_emails = ["aayush.chauhan@elevationservices.co.uk"]
  prod_notification_emails    = ["aayush.chauhan@elevationservices.co.uk", "joe.kadi@onmo.app", "ravi.patel@elevationservices.co.uk", "jim.eisenberg@onmo.app"]
  notification_emails         = var.ENVIRONMENT == "prod" ? local.prod_notification_emails : local.staging_notification_emails
}
module "service_monitor" {
  source  = "app.terraform.io/onmo/module-service-monitor/aws"
  version = "~> 1.0"

  service_config = local.service_config # Mandatory

  # List of Lambda functions to monitor
  lambda_functions = [ # Mandatory
    { name = module.accountBalancesBreakdown.name },
    { name = module.creditGetAccount.name },
    { name = module.creditFullLock.name },
    { name = module.creditFullUnlock.name },
    { name = module.creditSpendingLock.name },
    { name = module.creditSpendingUnlock.name },
    { name = module.creditCloseAccount.name },
    { name = module.creditGetDocuments.name },
    { name = module.getSignedURLOfDocument.name },
    { name = module.creditPaymentPlan.name },
    { name = module.accountUpsertedEvent.name },
    { name = module.authorizer.name },
    { name = module.accountCreatedEventToSqs.name },
    { name = module.updateAccountFlag.name },
    { name = module.creditFreezeAccount.name },
    { name = module.creditUnfreezeAccount.name },
    { name = module.repaymentCollectedListener.name },
    { name = module.mandateUpsertedListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 3000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.mandateCancelledListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 3000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.cardProvisionedMambuListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.cardStateChangedMambuListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }

    } },
    { name = module.accountCreatedEvent.name, alert_config = {

      # TODO: Set up alerts for when SQS messages are sent to the DLQ.
      # Disabling lambda errors as they are not needed in production at the moment.
      errors = {
        enabled = false
      }
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }

    } },
    { name = module.retryRepaymentCollected.name },
    { name = module.repaymentCollectedRetryDlqS3.name },
    { name = module.clmUpdatedListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    # Revenue-impacting: a failure leaves customers on incorrect interest rates
    { name = module.handlePromoExpiration.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 60
      }
      # TODO (COM-260): tune threshold once p95 execution time is known; 60 s is a placeholder
      duration = {
        enabled           = true
        threshold         = 60000
        time_window       = "last_1h"
        renotify_interval = 60
      }
    } },
    { name = module.handlePromotionReminders.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 60
      }
      # TODO (COM-260): tune threshold once p95 execution time is known; 60 s is a placeholder
      duration = {
        enabled           = true
        threshold         = 60000
        time_window       = "last_1h"
        renotify_interval = 60
      }
    } }
  ]


  # List of API gateways to monitor
  api_gateways = [ # Mandatory
    { name = module.rest_api_gateway.name },
    { name = module.rest_api_gateway_oidc.name }
  ]

  # GitHub repository associated with the service,
  github_repository = var.GITHUB_REPO

  # Email addresses to receive notifications for alerts
  notification_emails = local.notification_emails

  # Slack channels to receive notifications for alerts
  notification_slack_channels = ["${var.SLACK_CHANNEL}"]
  monitor_configs = {
    api_latency = {
      enabled           = true
      threshold         = 15000
      time_window       = "last_1h"
      renotify_interval = 0
    }

    # Disabling lambda errors as they are not needed in production at the moment.
    lambda_errors = {
      enabled = false
    }
    # Disabling lambda duration as they are not needed in production at the moment.
    lambda_duration = {
      enabled = false
    }

    lambda_throttles = {
      enabled           = true
      threshold         = 5
      time_window       = "last_1h"
      renotify_interval = 0
    }

    api_5xx_errors = {
      enabled           = true
      threshold         = 1.0
      time_window       = "last_1h"
      renotify_interval = 0
    }

    # Disabling 4xx errors as they are not needed in production at the moment.
    api_4xx_errors = {
      enabled     = false
      threshold   = 15.0
      time_window = "last_30m"
    }

  }
}
