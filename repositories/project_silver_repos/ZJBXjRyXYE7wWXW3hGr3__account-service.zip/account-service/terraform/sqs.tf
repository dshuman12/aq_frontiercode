resource "aws_sqs_queue" "repaymentCollectedRetryDlq" {
  name                       = "repayment-collected-retry-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "repaymentCollectedRetryQueue" {
  depends_on                 = [aws_sqs_queue.repaymentCollectedRetryDlq]
  name                       = "repayment-collected-retry-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 3600 # keep the message hidden for 1h before retrying again

  redrive_policy = jsonencode({
    maxReceiveCount     = 5 # after 5h waiting we are getting too close to the expiry of idempotency key
    deadLetterTargetArn = aws_sqs_queue.repaymentCollectedRetryDlq.arn
  })
}
