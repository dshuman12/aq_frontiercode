# EventBridge cron rule — fires daily at 02:00 UTC for 0% promo Lambdas
resource "aws_cloudwatch_event_rule" "promoDaily" {
  name                = "promoDaily-${var.ENVIRONMENT}"
  description         = "Daily trigger at 02:00 UTC for 0% promo Lambdas"
  schedule_expression = "cron(0 2 * * ? *)"
}

resource "aws_cloudwatch_event_target" "handlePromoExpiration" {
  rule      = aws_cloudwatch_event_rule.promoDaily.name
  target_id = "handlePromoExpiration"
  arn       = module.handlePromoExpiration.arn

  retry_policy {
    maximum_retry_attempts       = 2
    maximum_event_age_in_seconds = 3600
  }
}

resource "aws_cloudwatch_event_target" "handlePromotionReminders" {
  rule      = aws_cloudwatch_event_rule.promoDaily.name
  target_id = "handlePromotionReminders"
  arn       = module.handlePromotionReminders.arn

  retry_policy {
    maximum_retry_attempts       = 2
    maximum_event_age_in_seconds = 3600
  }
}

resource "aws_lambda_permission" "allow_eventbridge_handlePromoExpiration" {
  statement_id  = "AllowEventBridgeInvokeHandlePromoExpiration"
  action        = "lambda:InvokeFunction"
  function_name = module.handlePromoExpiration.arn
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.promoDaily.arn
}

resource "aws_lambda_permission" "allow_eventbridge_handlePromotionReminders" {
  statement_id  = "AllowEventBridgeInvokeHandlePromotionReminders"
  action        = "lambda:InvokeFunction"
  function_name = module.handlePromotionReminders.arn
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.promoDaily.arn
}

resource "aws_lambda_event_source_mapping" "clmUpdatedListener" {
  event_source_arn              = data.aws_dynamodb_table.clm.stream_arn
  function_name                 = module.clmUpdatedListener.arn
  starting_position             = "LATEST"
  maximum_record_age_in_seconds = 604800
  maximum_retry_attempts        = 10
  batch_size                    = 1
  filter_criteria {
    filter {
      pattern = jsonencode({
        eventName : ["INSERT", "MODIFY"],
        dynamodb : {
          NewImage : {
            auto_apply : { BOOL : [true, false] },
            opt_out : { BOOL : [true, false] }
          }
        }
      })
    }
  }
}