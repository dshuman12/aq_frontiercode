locals {
  dynamo_prefix       = "arn:aws:dynamodb:${var.REGION}:${var.AWS_ACCOUNT_ID}:table"
  s3_prefix           = "arn:aws:s3:::"
  event_stream_prefix = "arn:aws:kinesis:${var.REGION}:${var.AWS_ACCOUNT_ID}:stream"
  sqs_prefix          = "arn:aws:sqs:${var.REGION}:${var.AWS_ACCOUNT_ID}"
  lambda_prefix       = "arn:aws:lambda:${var.REGION}:${var.AWS_ACCOUNT_ID}:function"

  # ── Resource ARNs ──────────────────────────────────────────────────────────

  user_table_arn       = "${local.dynamo_prefix}/${local.USER_TABLE}"
  user_table_index_arn = "${local.user_table_arn}/index/*"

  card_mapping_table_arn       = "${local.dynamo_prefix}/${local.CUSTOMER_TO_CARD_MAPPING_TABLE}"
  card_mapping_table_index_arn = "${local.card_mapping_table_arn}/index/*"

  clm_table_arn       = "${local.dynamo_prefix}/${local.CLM_TABLE}"
  clm_table_index_arn = "${local.clm_table_arn}/index/*"

  freeze_table_arn       = "${local.dynamo_prefix}/${local.INTEREST_FEES_FREEZE_TABLE}"
  freeze_table_index_arn = "${local.freeze_table_arn}/index/*"

  promotions_table_arn       = "${local.dynamo_prefix}/${local.PROMOTIONS_TABLE}"
  promotions_table_index_arn = "${local.promotions_table_arn}/index/*"

  document_bucket_arn     = "${local.s3_prefix}${var.DOCUMENT_BUCKET_NAME}"
  document_bucket_obj_arn = "${local.document_bucket_arn}/*"

  business_events_stream_arn = "${local.event_stream_prefix}/${local.ONMO_BUSINESS_EVENTS_STREAM}"
  business_events_dlq_arn    = "${local.sqs_prefix}:${local.ONMO_BUSINESS_EVENTS_STREAM_DLQ}"

  # ── Reusable permission bundles ────────────────────────────────────────────

  # Secrets
  perm_mambu_secret = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.MAMBU_SECRET_ARN]
  }]

  perm_mambu_dd_secrets = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.MAMBU_SECRET_ARN, var.DIRECT_DEBIT_SECRET_ARN]
  }]

  perm_mambu_stripe_secrets = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.MAMBU_SECRET_ARN, var.STRIPE_SECRET_ARN]
  }]

  perm_pty_secrets = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.PAYMENTOLOGY_SECRET_ARN, var.PAYMENTOLOGY_SECRET_SSL_ARN]
  }]

  perm_api_key_secret = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.API_KEY_SECRET_ARN]
  }]

  perm_posthog_secret = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.POSTHOG_SECRET_ARN]
  }]

  perm_sf_secret = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    Resource = [var.SALES_FORCE_API_CONNECTION_SECRET_ARN]
  }]

  perm_mambu_secret_get_only = [{
    Effect   = "Allow"
    Actions  = ["secretsmanager:GetSecretValue"]
    Resource = [var.MAMBU_SECRET_ARN]
  }]

  # DynamoDB
  perm_user_table_full = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.user_table_arn, local.user_table_index_arn]
  }]

  perm_user_table_base = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.user_table_arn]
  }]

  perm_user_table_read_update = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"]
    Resource = [local.user_table_arn, local.user_table_index_arn]
  }]

  perm_card_mapping_table = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.card_mapping_table_arn, local.card_mapping_table_index_arn]
  }]

  perm_clm_table = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.clm_table_arn, local.clm_table_index_arn]
  }]

  perm_freeze_table = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.freeze_table_arn, local.freeze_table_index_arn]
  }]

  perm_promotions_table = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:*"]
    Resource = [local.promotions_table_arn, local.promotions_table_index_arn]
  }]

  # S3
  perm_document_bucket_read = [{
    Effect   = "Allow"
    Actions  = ["s3:ListBucket", "s3:GetObject"]
    Resource = [local.document_bucket_arn, local.document_bucket_obj_arn]
  }]

  perm_archived_bucket_write = [{
    Effect   = "Allow"
    Actions  = ["s3:PutObject"]
    Resource = [local.ARCHIVED_S3_BUCKET_ARN, "${local.ARCHIVED_S3_BUCKET_ARN}/*"]
  }]

  # Kinesis / Glue
  perm_glue_schema = [{
    Effect   = "Allow"
    Actions  = ["glue:GetSchemaVersion"]
    Resource = ["*"]
  }]

  perm_kinesis_put = [{
    Effect   = "Allow"
    Actions  = ["kinesis:PutRecord"]
    Resource = [local.business_events_stream_arn]
  }]

  perm_kinesis_read = [{
    Effect   = "Allow"
    Actions  = ["kinesis:GetRecords", "kinesis:GetShardIterator", "kinesis:DescribeStream"]
    Resource = [local.business_events_stream_arn]
  }]

  perm_kinesis_read_write = [{
    Effect   = "Allow"
    Actions  = ["kinesis:GetRecords", "kinesis:GetShardIterator", "kinesis:DescribeStream", "kinesis:PutRecord", "kinesis:PutRecords"]
    Resource = [local.business_events_stream_arn]
  }]

  perm_events_dlq_write = [{
    Effect   = "Allow"
    Actions  = ["sqs:SendMessage"]
    Resource = [local.business_events_dlq_arn]
  }]

  perm_events_dlq_sfmc_send = [{
    Effect   = "Allow"
    Actions  = ["sqs:SendMessage"]
    Resource = [local.business_events_dlq_arn, var.SFMC_COMMS_QUEUE_ARN]
  }]

  # SQS
  perm_account_created_queue_send = [{
    Effect   = "Allow"
    Actions  = ["sqs:SendMessage"]
    Resource = ["${local.sqs_prefix}:${aws_sqs_queue.account-created-event-queue.name}"]
  }]

  perm_account_created_queues_process = [{
    Effect   = "Allow"
    Actions  = ["sqs:SendMessage", "sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:GetQueueAttributes"]
    Resource = ["${local.sqs_prefix}:${aws_sqs_queue.account-created-event-queue.name}", "${local.sqs_prefix}:${aws_sqs_queue.account-created-event-dlq.name}"]
  }]

  perm_repayment_retry_queue = [{
    Effect   = "Allow"
    Actions  = ["sqs:*"]
    Resource = [aws_sqs_queue.repaymentCollectedRetryQueue.arn]
  }]

  perm_repayment_retry_dlq = [{
    Effect   = "Allow"
    Actions  = ["sqs:*"]
    Resource = [aws_sqs_queue.repaymentCollectedRetryDlq.arn]
  }]

  # Lambda invoke
  perm_upsert_lambda_invoke = [{
    Effect  = "Allow"
    Actions = ["lambda:InvokeFunction"]
    Resource = [
      "${local.lambda_prefix}:${var.ENVIRONMENT}-${var.SERVICE_NAME}-${var.ACCOUNT_UPSERTED_EVENT_LAMBDA}:next",
      "${local.lambda_prefix}:${var.ENVIRONMENT}-customer-service-${var.CUSTOMER_UPSERTED_EVENT_LAMBDA}:next"
    ]
  }]

  # Scheduler
  perm_scheduler_all = [{
    Effect   = "Allow"
    Actions  = ["scheduler:*"]
    Resource = ["*"]
  }]

  perm_scheduler_cancel = [{
    Effect   = "Allow"
    Actions  = ["scheduler:ListSchedules", "scheduler:DeleteSchedule"]
    Resource = ["*"]
  }]

  # CLM stream
  perm_clm_stream_read = [{
    Effect   = "Allow"
    Actions  = ["dynamodb:GetRecords", "dynamodb:GetShardIterator", "dynamodb:DescribeStream", "dynamodb:ListStreams", "dynamodb:GetItem"]
    Resource = [data.aws_dynamodb_table.clm.stream_arn]
  }]
}

module "creditCloseAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditCloseAccount"
  permission_statements = concat(local.perm_user_table_full, local.perm_mambu_secret)
}

module "creditFullLock" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditFullLock"
  permission_statements = local.perm_mambu_secret
}

module "creditFullUnlock" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditFullUnlock"
  permission_statements = local.perm_mambu_secret
}

module "creditGetDocuments" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = module.rest_api_gateway_oidc.execution_arn }
  ]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditGetDocuments"
  permission_statements = concat(local.perm_user_table_full, local.perm_document_bucket_read)
}

module "getSignedURLOfDocument" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = module.rest_api_gateway_oidc.execution_arn }
  ]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "getSignedURLOfDocument"
  permission_statements = concat(local.perm_document_bucket_read, local.perm_user_table_base)
}

module "creditSpendingLock" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditSpendingLock"
  permission_statements = local.perm_mambu_secret
}

module "creditSpendingUnlock" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditSpendingUnlock"
  permission_statements = local.perm_mambu_secret
}

module "creditUpdateAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = module.rest_api_gateway_oidc.execution_arn }
  ]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditUpdateAccount"
  permission_statements = concat(local.perm_mambu_dd_secrets, local.perm_user_table_full, local.perm_card_mapping_table)
}

module "creditPaymentPlan" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditPaymentPlan"
  permission_statements = local.perm_mambu_secret
}


module "authorizer" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.customer-api.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.transaction-api.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.card-api.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.repayment-api.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.analytics-api.execution_arn },
    { service = "APIGateway", source_arn = data.aws_api_gateway_rest_api.customer-care-api.execution_arn }
  ]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "authorizer"
  permission_statements = local.perm_api_key_secret
}

module "creditGetAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = module.rest_api_gateway_oidc.execution_arn }
  ]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = merge(local.lambda_environment_variables, { SUPPRESS_LOGS = "false" })
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditGetAccount"
  permission_statements = concat(local.perm_mambu_dd_secrets, local.perm_posthog_secret, local.perm_user_table_full, local.perm_promotions_table)
}

module "accountUpsertedEvent" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "accountUpsertedEvent"
  permission_statements = concat(local.perm_kinesis_put, local.perm_glue_schema, local.perm_mambu_dd_secrets, local.perm_user_table_full)
}

module "accountCreatedEventToSqs" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "accountCreatedEventToSqs"
  permission_statements = local.perm_account_created_queue_send
  depends_on = [
    aws_sqs_queue.account-created-event-queue
  ]
}

module "accountCreatedEvent" {
  source                = "app.terraform.io/onmo/modules/aws//lambda-function"
  version               = "0.6.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "accountCreatedEvent"
  execution_from = [{
    service    = "SQS",
    source_arn = "${local.sqs_prefix}:${aws_sqs_queue.account-created-event-queue.name}"
  }]
  permission_statements = concat(local.perm_kinesis_put, local.perm_glue_schema, local.perm_mambu_dd_secrets, local.perm_user_table_full, local.perm_account_created_queues_process, local.perm_upsert_lambda_invoke)
  depends_on = [
    aws_sqs_queue.account-created-event-queue,
    aws_sqs_queue.account-created-event-dlq
  ]
}

module "updateAccountFlag" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 1048
  timeout               = 30
  lambda_function_name  = "updateAccountFlag"
  permission_statements = concat(local.perm_mambu_dd_secrets, local.perm_user_table_full)
}

module "cardStateChangedMambuListener" {
  source                = "app.terraform.io/onmo/modules/aws//lambda-function"
  version               = "0.6.5"
  memory_size           = 2048
  timeout               = 900
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables
  lambda_function_name  = "cardStateChangedMambuListener"
  description           = "A cardStateChangedMambuListener lambda function that listens to the card state changes and updates the card state in the mambu account."
  execution_from = [{
    service    = "Kinesis",
    source_arn = local.business_events_stream_arn
    kinesis_config = {
      starting_position  = "LATEST"
      max_retry_attempts = 15
      max_record_age     = 900
      on_failure = {
        destination_arn     = local.business_events_dlq_arn
        destination_service = "SQS"
      }
      filter_criteria = jsonencode({ data = { event = ["CardStateChanged"] } })
    }
  }]
  permission_statements = concat(local.perm_mambu_dd_secrets, local.perm_pty_secrets, local.perm_user_table_full, local.perm_card_mapping_table, local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_write)
  vpc_config = {
    subnet_ids         = local.paymentology_vpc_config.subnet_ids
    security_group_ids = local.paymentology_vpc_config.security_group_ids
  }
}

module "cardProvisionedMambuListener" {
  source                = "app.terraform.io/onmo/modules/aws//lambda-function"
  version               = "0.6.5"
  memory_size           = 2048
  timeout               = 900
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables
  lambda_function_name  = "cardProvisionedMambuListener"
  description           = "A cardProvisionedMambuListener lambda function that listens to the cardProvisioned event and updates the card details in the mambu account."
  execution_from = [{
    service    = "Kinesis",
    source_arn = local.business_events_stream_arn
    kinesis_config = {
      starting_position  = "LATEST"
      max_retry_attempts = 15
      max_record_age     = 900
      on_failure = {
        destination_arn     = local.business_events_dlq_arn
        destination_service = "SQS"
      }
      filter_criteria = jsonencode({ data = { event = ["CardProvisioned"] } })
    }
  }]
  permission_statements = concat(local.perm_mambu_dd_secrets, local.perm_user_table_full, local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_write)
}

module "creditFreezeAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 900
  lambda_function_name  = "creditFreezeAccount"
  permission_statements = concat(local.perm_mambu_secret, local.perm_user_table_full, local.perm_freeze_table)
}

module "creditUnfreezeAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditUnfreezeAccount"
  permission_statements = concat(local.perm_mambu_secret, local.perm_freeze_table)
}


module "accountBalancesBreakdown" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.6"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from = [
    { service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn },
    { service = "APIGateway", source_arn = module.rest_api_gateway_oidc.execution_arn }
  ]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "accountBalancesBreakdown"
  permission_statements = concat(local.perm_mambu_secret, local.perm_user_table_full)
}

# Repayments 
module "repaymentCollectedListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "repaymentCollectedListener"
  description          = "Lambda function to respond to a RepaymentCollected event raised from the Repayment service"

  execution_from = [{ service = "Kinesis", source_arn = local.business_events_stream_arn, kinesis_config = {
    starting_position = "LATEST",
    max_retry_attempts : 1,
    max_record_age = 86400, // 1 day
    on_failure = {
      destination_arn     = local.business_events_dlq_arn
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["RepaymentCollected"] } })
  } }]
  reserved_concurrency  = 10
  permission_statements = concat(local.perm_glue_schema, local.perm_kinesis_read_write, local.perm_events_dlq_write, local.perm_user_table_full, local.perm_mambu_stripe_secrets, local.perm_sf_secret, local.perm_posthog_secret, local.perm_scheduler_all)
  memory_size           = 2048
  timeout               = 900
}

module "mandateUpsertedListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "mandateUpsertedListener"
  description          = "Lambda function to respond to a MandateUpserted event raised from the Repayment service"

  execution_from = [{ service = "Kinesis", source_arn = local.business_events_stream_arn, kinesis_config = {
    starting_position = "LATEST",
    max_retry_attempts : 5,
    max_record_age = 9000,
    on_failure = {
      destination_arn     = local.business_events_dlq_arn
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["MandateUpserted"] } })
  } }]
  permission_statements = concat(local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_write, local.perm_user_table_full, local.perm_mambu_stripe_secrets)
  memory_size           = 2048
  timeout               = 900
}

module "mandateCancelledListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "mandateCancelledListener"
  description          = "Lambda function to respond to a MandateCancelled event raised from the Repayment service"

  execution_from = [{ service = "Kinesis", source_arn = local.business_events_stream_arn, kinesis_config = {
    starting_position = "LATEST",
    max_retry_attempts : 5,
    max_record_age = 21600, // 6h
    on_failure = {
      destination_arn     = local.business_events_dlq_arn
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["MandateCancelled"] } })
  } }]
  permission_statements = concat(local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_write, local.perm_user_table_full, local.perm_mambu_secret, local.perm_scheduler_cancel)
  memory_size           = 2048
  timeout               = 900
}

module "creditWriteOffAccount" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "creditWriteOffAccount"
  permission_statements = concat(local.perm_mambu_secret, local.perm_user_table_full)
}

module "updateCreditLimit" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 300
  lambda_function_name  = "updateCreditLimit"
  permission_statements = concat(local.perm_mambu_secret, local.perm_sf_secret, local.perm_user_table_full)
}

module "retryRepaymentCollected" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "retryRepaymentCollected"
  description          = "Lambda to retry repaymentCollected failed due to Mambu error. It fetches messages from repayment-collected-retry-queue"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.repaymentCollectedRetryQueue.arn
    # Configured to process max 10 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 10,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = concat(local.perm_mambu_secret_get_only, local.perm_user_table_read_update, local.perm_repayment_retry_queue)
  memory_size           = 2048
  timeout               = 900
}

module "repaymentCollectedRetryDlqS3" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "repaymentCollectedRetryDlqS3"
  description          = "Lambda to archive failed events to S3. It fetches messages from repayment-collected-retry-dlq"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.repaymentCollectedRetryDlq.arn
    # Configured to process max 500 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 500,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = concat(local.perm_repayment_retry_dlq, local.perm_archived_bucket_write)
  memory_size           = 2048
  timeout               = 900
}

module "updateCLMPreferences" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "updateCLMPreferences"
  permission_statements = concat(local.perm_clm_table, local.perm_user_table_full)
}

module "getCLMPreferences" {
  source         = "app.terraform.io/onmo/modules/aws//lambda-function"
  version        = "0.6.0"
  service_config = local.service_config
  lambda_config  = local.lambda_config

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  layers                = [{ name = "getSecrets", version = 5 }]
  environment_variables = local.lambda_environment_variables
  memory_size           = 2048
  timeout               = 30
  lambda_function_name  = "getCLMPreferences"
  permission_statements = concat(local.perm_clm_table, local.perm_user_table_full)
}

module "clmUpdatedListener" {
  source                = "app.terraform.io/onmo/modules/aws//lambda-function"
  version               = "0.6.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "clmUpdatedListener"
  description          = "DynamoDB stream listener for CLM Updates"

  execution_from        = []
  permission_statements = concat(local.perm_kinesis_put, local.perm_glue_schema, local.perm_clm_stream_read)
  memory_size           = 2048
  timeout               = 30
}

module "cpaSubCreatedListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "cpaSubCreatedListener"
  description          = "Lambda function to respond to a CPASubscriptionCreated event. Sends SFMC comms to the customer."

  execution_from = [{ service = "Kinesis", source_arn = local.business_events_stream_arn, kinesis_config = {
    starting_position  = "LATEST",
    max_retry_attempts = 5,
    max_record_age     = 900,
    on_failure = {
      destination_arn     = local.business_events_dlq_arn
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["CPASubscriptionCreated"] } })
  } }]
  permission_statements = concat(local.perm_mambu_stripe_secrets, local.perm_sf_secret, local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_sfmc_send, local.perm_user_table_full)
  memory_size           = 2048
  timeout               = 900
}

module "cpaSubCancelledListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables


  lambda_function_name = "cpaSubCancelledListener"
  description          = "Lambda function to respond to a CPASubscriptionCancelled event. Expires Salesforce collection plan, sends SFMC comms, and updates Mambu interest rates."

  execution_from = [{ service = "Kinesis", source_arn = local.business_events_stream_arn, kinesis_config = {
    starting_position  = "LATEST",
    max_retry_attempts = 5,
    max_record_age     = 900,
    on_failure = {
      destination_arn     = local.business_events_dlq_arn
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["CPASubscriptionCancelled"] } })
  } }]
  permission_statements = concat(local.perm_mambu_stripe_secrets, local.perm_sf_secret, local.perm_glue_schema, local.perm_kinesis_read, local.perm_events_dlq_sfmc_send, local.perm_user_table_full)
  memory_size           = 2048
  timeout               = 900
}

# 0% Promo Lambdas — triggered daily by EventBridge cron (see events.tf)

module "handlePromoExpiration" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = merge(local.lambda_environment_variables, { SUPPRESS_LOGS = "false" })

  lambda_function_name = "handlePromoExpiration"
  description          = "Restores standard interest rate for customers whose 0% promo period has ended"

  execution_from = []
  # TODO (COM-260): add DynamoDB and Mambu permission_statements once business logic is implemented
  permission_statements = []
  # TODO (COM-260): tune once account iteration pattern is known; 2 GB is a placeholder
  memory_size = 2048
  timeout     = 900
}

module "handlePromotionReminders" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = merge(local.lambda_environment_variables, { SUPPRESS_LOGS = "false" })

  lambda_function_name = "handlePromotionReminders"
  description          = "Sends 2-week-before-end reminder notifications for customers in a 0% promo period"

  execution_from = []
  # TODO (COM-260): add DynamoDB and Mambu permission_statements once business logic is implemented
  permission_statements = []
  # TODO (COM-260): tune once account iteration pattern is known; 2 GB is a placeholder
  memory_size = 2048
  timeout     = 900
}

module "createPromotion" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = merge(local.lambda_environment_variables, { SUPPRESS_LOGS = "false" })

  lambda_function_name = "createPromotion"
  description          = "Creates a promotional offer for a credit account"

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = local.perm_promotions_table
  memory_size           = 2048
  timeout               = 30
}

module "getAccountsPromotions" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = merge(local.lambda_environment_variables, { SUPPRESS_LOGS = "false" })

  lambda_function_name = "getAccountsPromotions"
  description          = "Batch-fetches promotions for multiple credit accounts"

  execution_from        = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = local.perm_promotions_table
  memory_size           = 2048
  timeout               = 30
}


