## DO NOT REMOVE UNLESS YOU KNOW WHAT YOU'RE DOING

resource "null_resource" "checks" {
  depends_on = [
    module.v5,
    module.v1_oidc
  ]
}
