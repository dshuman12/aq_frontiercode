import { CoreBanking, CoreBankingFactory } from "@onmoapp/core-banking";
import { CorePayments, CorePaymentsFactory } from "@onmoapp/core-payments";
import { CoreRepayments, CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";
import { SalesforceClient } from "@onmoapp/salesforce-adapter";
import { s3Client } from "@onmoapp/s3-adapter";
import { getLogger } from "@utils/logger";

const RETRY_DELAY = 1000 * 60; // 1 minute
// const RETRY_DELAY = 2000;
// retryCount * 500

export const getCoreBankingAdapter = async (): Promise<CoreBanking> => {
    return await CoreBankingFactory.build("mambu", {
        axiosConfig: {
            retries: 3,
            retryDelay: (retryCount: number) => retryCount * RETRY_DELAY,
            retryCondition: (error) => {
                return error?.response?.status >= 500;
            },
            onRetry: (retryCount, error, requestConfig) => {
                const logger = getLogger();
                logger.info(
                    `Retry attempt ${retryCount} for ${requestConfig.method} ${requestConfig?.url}`,
                );
                logger.info(`Previous error message: ${error?.message}`);
                logger.info({ previousApiCallResponse: error?.response?.data });
            },
        },
    });
};

export const getCorePaymentsAdapter = async (): Promise<CorePayments> => {
    return await CorePaymentsFactory.build("paymentology");
};

export const getCoreRepaymentsAdapter = async (): Promise<CoreRepayments> => {
    return await CoreRepaymentsFactory.build("stripe");
};

export const getEventHubAdapter = async <T>(): Promise<EventHubKinesisAdapter<T>> => {
    return await EventHubKinesisAdapter.build();
};

export const getSalesforceAdapter = async (): Promise<SalesforceClient> => {
    return await SalesforceClient.build();
};

export const getDocumentManagementAdapter = async (): Promise<s3Client> => {
    return await s3Client.build();
};
