import {
    AccountGenericData,
    GetPaymentMethodByPspCustomerIdDirectDebitOutcome,
    Transaction,
} from "@onmoapp/onmo-types";

export const defaultCreditAccount: AccountGenericData = {
    accountDetails: {
        accountId: "account-id",
        accountEncodedKey: "key",
        coreBankingCustomerEncodedKey: "key2",
        customerId: "customer-id",
        state: "ACTIVE",
        accountState: "ACTIVE",
        inArrearsDate: null,
        creditLimit: null,
        interestRate: null,
        apr: null,
        startOfBillingCycle: null,
    },
    directDebitSettings: {},
    accountBalances: {
        totalNextMinimumPaymentDue: null,
        balances: {
            total: 1,
            principal: 100,
            interest: null,
            fees: null,
            technicalAccountBalance: null,
        },
        arrearBalances: {
            total: null,
            principal: null,
            interest: null,
            fees: null,
        },
        interestAccrued: 0,
        due: {
            total: null,
            principal: null,
            interest: null,
            fees: null,
        },
    },
    cards: [],
    paymentPlans: [],
};

export const defaultTransaction: Transaction = {
    transactionId: "transaction-id",
    cardId: "card-id",
    terminalId: "terminal-id",
    settlementId: "settlement-id",
    onmoTransactionType: "purchase",
    cardTransactionType: "credit",
    packetType: "financial",
    status: "approved",
    declineReason: null,
    sourceAmount: 100,
    destinationAmount: 100,
    feeAmount: 0,
    currencyCode: "GBP",
    sourceToBaseExchangeRate: 1,
    baseToDestinationExchangeRate: 1,
    dateTime: "2025-09-23T10:15:30Z",
    valueDate: "2025-09-23",
    merchantInfo: {
        merchantName: "Corner Shop",
        merchantCountryCode: "GB",
        merchantPostCode: "EC2A 3LT",
        merchantCity: "London",
        merchantCategoryCode: "5411",
    },
    adjustmentTransactionKey: null,
    notes: null,
    transactionChannelKey: "pos",
    transactionChannelId: "in_store",
};

export type EventValidationResponse = {
    isValid: boolean;
    validationErrors: Record<string, string[]>;
};

export const defaultValidationResponse: EventValidationResponse = {
    isValid: true,
    validationErrors: {},
};

export type EventPublishResponse = {
    isValid: boolean;
    validationErrors: Record<string, string[]>;
    isPublished: boolean;
};

export const defaultEventPublishResponse: EventPublishResponse = {
    isValid: true,
    validationErrors: {},
    isPublished: true,
};

export const defaultPaymentMethodByMandate: GetPaymentMethodByPspCustomerIdDirectDebitOutcome = {
    paymentMethodId: "payment-method-id",
    pspCustomerId: "pspCustomerId",
    created: "2023-10-10T10:00:00Z",
    type: "direct-debit",
    directDebit: {
        bankCode: "400300",
        last4: "1234",
    },
    billingDetails: {
        name: "John Doe",
        address: {
            city: "City",
            country: "Country",
            line1: "Line 1",
            line2: "Line 2",
            postal_code: "12345",
            state: "State",
        },
    },
};
