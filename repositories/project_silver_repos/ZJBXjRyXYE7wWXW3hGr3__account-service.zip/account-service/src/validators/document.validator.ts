import Joi from "joi";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(customParseFormat);

/**
 * @name pathParametersSchema
 * @description Defines the schema for path parameters.
 * @type {Joi.ObjectSchema}
 * @property {Joi.StringSchema} accountId - The unique identifier of the account. Must be a string with a minimum length of 3 characters.
 */
export const pathParametersSchema = Joi.object({
    accountId: Joi.string().min(3).required(),
}).required();

/**
 * @name queryParametersSchema
 * @description Defines the schema for query parameters.
 * @type {Joi.ObjectSchema}
 * @property {Joi.StringSchema} documentType - The type of document to retrieve. Valid values are "contracts", "statements", or "all".
 * @property {Joi.StringSchema} periodFrom - The start date of the period to retrieve documents for. Must be in the format "YYYYMM".
 * @property {Joi.NumberSchema} [count=6] - The number of documents to retrieve. Defaults to 6.
 * @property {Joi.NumberSchema} [documentCursor=0] - The cursor for pagination. Defaults to 0.
 */
export const queryParametersSchema = Joi.object({
    documentType: Joi.string().valid("contracts", "statements", "all").required(),
    periodFrom: Joi.string()
        .default(dayjs().format("YYYYMM"))
        .custom((value, helpers) => {
            const valid = dayjs(value, "YYYYMM", true).isValid();
            if (valid) {
                return value;
            } else {
                return helpers.message({
                    custom: "please enter a valid periodFrom value",
                });
            }
        }),
    count: Joi.number().default(6),
    documentCursor: Joi.number().default(0),
}).required();

export const getSignedURLBodySchema = Joi.object({
    documentId: Joi.string().min(10).required(),
}).required();
