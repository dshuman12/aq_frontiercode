import { z } from "zod";

import { PromotionResponseItemSchema } from "@libs/types/promotion";

export const GetCreditAccountResponseSchema = z.object({
    accountDetails: z
        .object({
            accountId: z.string(),
            customerId: z.string(),
            state: z.string(),
            inArrearsDate: z.string().nullable(),
            isInArrears: z.boolean().nullable().optional(),
            interestRate: z.number().nullable(),
            creditLimit: z.number().nullable(),
            accountState: z.string(),
            additionalAccountState: z.string().nullable(),
            availableCredit: z.number().nullable().optional(),
            apr: z.number().nullable(),
            startOfBillingCycle: z.string().nullable(),
            nextStatementDueDate: z.string().nullable(),
            daysLate: z.number().nullable(),
        })
        .strict(),
    directDebitSettings: z
        .object({
            amountPreference: z.string().nullable(),
            mandateID: z.string().nullable(),
            mandateReference: z.string().nullable(),
            provider: z.string().nullable(),
            nextDirectDebitAmount: z.number().nullable(),
            scheduledDirectDebitAmount: z.number().nullable(),
            directDebitRetryInProgress: z.boolean(),
            directDebitRetryDate: z.string().nullable(),
            directDebitPreventRetryDate: z.string().nullable(),
            directDebitAvoidFeeCutOffDate: z.string().nullable(),
        })
        .strict(),
    accountBalances: z.object({
        totalNextMinimumPaymentDue: z.number().nullable(),
        balances: z
            .object({
                total: z.number().nullable(),
                principal: z.number().nullable(),
                interest: z.number().nullable(),
                fees: z.number().nullable(),
            })
            .strict(),
        arrearBalances: z
            .object({
                total: z.number().nullable().nullable(),
                principal: z.number().nullable().nullable(),
                interest: z.number().nullable().nullable(),
                fees: z.number().nullable().nullable(),
            })
            .strict(),
        due: z
            .object({
                total: z.number().nullable(),
                principal: z.number().nullable(),
                interest: z.number().nullable(),
                fees: z.number().nullable(),
            })
            .strict(),
        suggestedSmartPaymentAmount: z.number().nullable(),
        smartPaymentMultiplier: z.number().nullable(),
        smartPaymentVariant: z.string().nullable(),
    }),
    cards: z.array(
        z
            .object({
                cardId: z.string().nullable(),
                state: z.string().nullable(),
                isActivated: z.boolean().nullable(),
                hasPinSet: z.boolean().nullable(),
                creationDate: z.string().nullable(),
                expirationDate: z.string().nullable(),
            })
            .strict(),
    ),
    paymentPlans: z.array(
        z
            .object({
                type: z.string().nullable(),
                status: z.string().nullable(),
                amount: z.string().nullable(),
                startDate: z.string().nullable(),
                endDate: z.string().nullable(),
            })
            .strict(),
    ),
    promotions: z.array(PromotionResponseItemSchema),
});
