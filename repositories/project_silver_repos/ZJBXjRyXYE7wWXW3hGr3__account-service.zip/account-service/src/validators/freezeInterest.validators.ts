import Joi from "joi";
import { dateValidation } from "./index";
import { REASONS } from "@libs/constants";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(customParseFormat);

/**
 * Validates the payload for Interest and Fees freeze.
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const freezeInterestSchema = Joi.object({
    reason: Joi.string()
        .valid(...REASONS)
        .required(),
    startDate: Joi.string()
        .trim()
        .custom(dateValidation("startDate", "YYYY-MM-DD", false), "Start date validation")
        .required(),
    disableFreezeWhenArrearsCleared: Joi.boolean().required(),
    applyAccruedInterest: Joi.boolean().required(),
    rollbackFreezeProcess: Joi.boolean().default(false),
    endDate: Joi.alternatives().conditional("endDate", {
        is: Joi.exist(),
        then: Joi.string()
            .trim()
            .custom((value, helpers) => {
                if (!dayjs(value, "YYYY-MM-DD", true).isValid()) {
                    return helpers.message({
                        custom: "End date must be a valid date in the format YYYY-MM-DD",
                    });
                }

                const { startDate } = helpers.state.ancestors[0];
                const start = dayjs(startDate, "YYYY-MM-DD", true);
                const end = dayjs(value, "YYYY-MM-DD", true);

                if (end.isBefore(start)) {
                    return helpers.message({ custom: "End date should be after start date" });
                }
                return value;
            }, "End date validation"),
    }),
}).required();
