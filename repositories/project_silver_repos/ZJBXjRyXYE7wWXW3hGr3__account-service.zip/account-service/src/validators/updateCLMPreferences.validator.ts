import Joi from "joi";

/**
 * Validates the payload for write off account
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const updateCLMPreferencesValidationSchema = Joi.object({
    opt_out: Joi.boolean().required(),
    auto_apply: Joi.alternatives().conditional("opt_out", {
        is: true,
        then: false,
        otherwise: Joi.boolean().required(),
    }),
}).required();
