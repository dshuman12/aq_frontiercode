import Joi from "joi";
/**
 * Validates the input for updating an account flag.
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const updateAccountSchema = Joi.object({
    directDebitSettings: Joi.object({
        amountPreference: Joi.string()
            .valid("Full Statement Balance", "Minimum Payment", "Custom")
            .required(),
        customAmount: Joi.when("amountPreference", {
            is: "Custom",
            then: Joi.number().min(10).required().messages({
                "number.min": "Custom amount must be at least £10",
            }),
            otherwise: Joi.forbidden(),
        }),
    }).required(),
});
