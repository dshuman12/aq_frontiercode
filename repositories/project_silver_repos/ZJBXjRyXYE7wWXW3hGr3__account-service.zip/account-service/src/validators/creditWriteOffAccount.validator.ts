import Joi from "joi";

import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { WRITE_OFF_TYPE } from "@libs/constants";

dayjs.extend(customParseFormat);

/**
 * Validates the payload for write off account
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const writeOffAccountValidationSchema = Joi.object({
    writeOffType: Joi.valid(...Object.values(WRITE_OFF_TYPE)).default(WRITE_OFF_TYPE.FULL),
    notes: Joi.string().required(),
}).required();
