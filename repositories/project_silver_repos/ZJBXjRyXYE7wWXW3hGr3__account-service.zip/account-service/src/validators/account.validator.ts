import Joi from "joi";

/**
 * @name pathParametersSchema
 * @description This function returns a Joi schema object for validating the path parameters of a request.
 * @param {string} accountId - The unique identifier of Credit/Debit Account.
 * @returns {Joi.ObjectSchema} - A Joi schema object that validates the accountId parameter.
 */
export const accountIdPathParametersSchema = Joi.object({
    accountId: Joi.string().min(3).max(10).required(),
});
