import Joi from "joi";
import { Logger } from "@onmoapp/onmo-logger";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(customParseFormat);

/** Initialized Logger to log */
const logger = new Logger(
    {
        env: process.env.STAGE,
    },
    "INFO",
);

/**
 * Validates the input payload against a provided Joi schema.
 * If the validation fails, it logs an error and throws an OnmoError.
 * If the validation passes, it logs a success message and returns the validated payload.
 *
 * @param validationSchema - The Joi schema to validate the payload against.
 * @param payload - The payload to validate.
 * @throws {OnmoError} Throws an OnmoError if the validation fails.
 * @returns {any} Returns the validated payload if the validation passes.
 */
export function checkValidation(
    validationSchema: Joi.Schema,
    payload: any,
    options?: {
        contextMessage?: string;
    },
) {
    const validate = validationSchema?.validate(payload, {
        errors: {
            wrap: {
                // Remove quotes from variable names in error messages
                label: false,
            },
        },
    });
    if (validate?.error) {
        logger.error({
            message: "Validation error",
            error: validate?.error?.details[0]?.message,
        });
        /** For Logging purpose what we have received in payload */
        logger.debug({ message: "[Debug] Invalid Payload", payload });

        throw new OnmoError({
            name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
            message:
                validate?.error?.details[0]?.message +
                (options?.contextMessage ? " " + options?.contextMessage : ""),
        });
    } else {
        logger.info({
            message: "Validation success",
        });
        logger.debug({
            message: "[Debug] Validation success",
            payload: validate.value,
        });
        return validate?.value;
    }
}

/**
 * Validates a date string based on the provided format and checks if it's a future date.
 *
 * @param fieldName - The name of the field being validated.
 * @param dateFormat - The format of the date string.
 * @param allowFutureDate - Whether future dates are allowed.
 * @returns A validation function that can be used with Joi.
 */
export function dateValidation(fieldName: string, dateFormat: string, allowFutureDate: boolean) {
    return (value: any, helpers: Joi.CustomHelpers<any>) => {
        const valid = dayjs(value, dateFormat, true).isValid(); // strictly validate date with dateFormat
        if (valid) {
            if (!allowFutureDate) {
                const isFutureDate = dayjs(value, dateFormat, true).isAfter(dayjs());
                if (isFutureDate)
                    return helpers.message({
                        custom: `please enter a valid ${fieldName}, Please enter today's date or an earlier date`,
                    });
                else {
                    return value;
                }
            }
            return value;
        } else {
            return helpers.message({
                custom: `please enter a valid ${fieldName} in ${dateFormat} format`,
            });
        }
    };
}
