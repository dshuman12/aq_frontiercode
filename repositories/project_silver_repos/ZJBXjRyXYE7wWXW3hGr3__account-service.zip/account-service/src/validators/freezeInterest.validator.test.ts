import { describe } from "node:test";
import { freezeInterestSchema } from "./freezeInterest.validators";
import { expect, it } from "vitest";
import dayjs from "dayjs";
import { IFreezeInterestAndFeesPayload } from "@libs/types/interestAndFees";

describe("freezeInterestSchema", () => {
    var baseStartDate = dayjs().add(-1, "day").format("YYYY-MM-DD");
    const basePayload: IFreezeInterestAndFeesPayload = {
        reason: "NoticeOfDefault",
        startDate: baseStartDate,
        endDate: "2021-09-01",
        disableFreezeWhenArrearsCleared: true,
        applyAccruedInterest: true,
    };

    it("returns an error when the `reason` is invalid", () => {
        const { error } = freezeInterestSchema.validate({
            ...basePayload,
            reason: "INVALID_REASON",
        });
        expect(error.details[0].message).toStrictEqual(
            `"reason" must be one of [NoticeOfDefault, Deceased, TokenPlan, SupportPlan, IVA, Bankruptcy, DRO, BreathingSpace]`,
        );
    });

    it("returns an error when the `disableFreezeWhenArrearsCleared` is not set", () => {
        const { error } = freezeInterestSchema.validate({
            ...basePayload,
            disableFreezeWhenArrearsCleared: undefined,
        });
        expect(error.details[0].message).toStrictEqual(
            `"disableFreezeWhenArrearsCleared" is required`,
        );
    });

    it("returns an error when the `applyAccruedInterest` is not set", () => {
        const { error } = freezeInterestSchema.validate({
            ...basePayload,
            applyAccruedInterest: undefined,
        });
        expect(error.details[0].message).toStrictEqual(`"applyAccruedInterest" is required`);
    });

    describe("startDate validation", () => {
        it('says that "startDate" is required', () => {
            var endDate = dayjs().format("YYYY-MM-DD");

            const payload = { ...basePayload, startDate: undefined, endDate };
            const { error } = freezeInterestSchema.validate(payload);
            expect(error.details[0].message).toStrictEqual(`"startDate" is required`);
        });
        it(`says that "startDate" should today's date or an earlier date`, () => {
            var startDate = dayjs().add(1, "day").format("YYYY-MM-DD");
            var endDate = dayjs().format("YYYY-MM-DD");

            const payload = { ...basePayload, startDate, endDate };
            const { error } = freezeInterestSchema.validate(payload);
            expect(error.details[0].message).toStrictEqual(
                `please enter a valid startDate, Please enter today's date or an earlier date`,
            );
        });
        it(`says that "startDate" should have YYYY-MM-DD format`, () => {
            const endDate = dayjs().format("YYYY-MM-DD");
            const payload = { ...basePayload, startDate: "01/01/2024", endDate };

            const { error } = freezeInterestSchema.validate(payload);

            expect(error.details[0].message).toStrictEqual(
                `please enter a valid startDate in YYYY-MM-DD format`,
            );
        });
    });
    describe("endDate validation", () => {
        it("does not complain when endDate is not provided", () => {
            const payload = { ...basePayload, endDate: undefined };
            const { error } = freezeInterestSchema.validate(payload);
            expect(error).toBeUndefined();
        });
        it(`says that "endDate" should be after startDate`, () => {
            const startDate = dayjs().add(-1, "day").format("YYYY-MM-DD");
            const endDate = dayjs().add(-3, "day").format("YYYY-MM-DD");

            const payload = { ...basePayload, startDate, endDate };
            const { error } = freezeInterestSchema.validate(payload);
            expect(error.details[0].message).toStrictEqual(`End date should be after start date`);
        });
        it(`says that "endDate" should have YYYY-MM-DD format`, () => {
            const payload = { ...basePayload, endDate: "01/01/2021" };
            const { error } = freezeInterestSchema.validate(payload);
            expect(error.details[0].message).toStrictEqual(
                `End date must be a valid date in the format YYYY-MM-DD`,
            );
        });
    });
});
