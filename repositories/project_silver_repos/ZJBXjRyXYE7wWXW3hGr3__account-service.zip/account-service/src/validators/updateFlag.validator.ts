import Joi from "joi";
import { dateValidation } from "./index";
import { ACCOUNT_FLAGS } from "@libs/constants";

/**
 * Validates the input for updating an account flag.
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const updateAccountFlagSchema = Joi.object({
    flagName: Joi.string()
        .trim()
        .valid(...ACCOUNT_FLAGS)
        .messages({
            "any.only": "Invalid account flag",
        })
        .required(),
    flagDetails: Joi.object({
        status: Joi.boolean().required(),
        startDate: Joi.string()
            .trim()
            .custom(dateValidation("flagDetails.startDate", "YYYY-MM-DD", true))
            .optional(),
        endDate: Joi.string()
            .trim()
            .custom(dateValidation("flagDetails.endDate", "YYYY-MM-DD", true))
            .allow(null)
            .optional(),
    }).required(),
}).required();
