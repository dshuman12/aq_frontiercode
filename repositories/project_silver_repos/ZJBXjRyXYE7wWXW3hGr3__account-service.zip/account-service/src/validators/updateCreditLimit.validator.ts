import Joi from "joi";

import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";

dayjs.extend(customParseFormat);

/**
 * Validates the payload for write off account
 *
 * @param {object} data - The data to be validated.
 * @returns {Joi.ValidationResult} - The validation result.
 */
export const updateCreditLimitValidationSchema = Joi.object({
    amount: Joi.number().required(),
    notes: Joi.string(),
}).required();
