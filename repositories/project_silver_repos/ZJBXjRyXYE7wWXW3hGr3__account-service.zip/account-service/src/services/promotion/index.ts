import dayjs from "dayjs";
import { logger, serializeError } from "@onmoapp/logger";
import { putItemMethod, queryTableMethod, updateItemMethod } from "@onmoapp/onmo-dynamodb";

import { Success, Failure } from "@libs/types/result";
import {
    type PromotionRecord,
    type CreatePromotionInput,
    type PromotionResult,
    type PagedResult,
    type PromotionType,
    PromotionStatus,
    NotificationStatus,
    PromotionErrorCode,
} from "@libs/types/promotion";
import { buildPartitionKey, buildSortKey } from "./keys";

export class PromotionService {
    private readonly tableName = process.env.PROMOTIONS_TABLE!;
    private static instance: PromotionService | null = null;

    static getInstance(): PromotionService {
        if (!this.instance) {
            this.instance = new PromotionService();
        }
        return this.instance;
    }

    async create(input: CreatePromotionInput): Promise<PromotionResult<{ promotion_id: string }>> {
        const id = buildPartitionKey(input.credit_account_id);
        const promotionId = buildSortKey(input.promotion_type, input.start_date);

        const now = dayjs().unix();

        const record: PromotionRecord = {
            id,
            promotion_id: promotionId,
            onmouuid: input.onmouuid,
            promotion_type: input.promotion_type,
            credit_account_id: input.credit_account_id,
            promotional_interest_rate: input.promotional_interest_rate,
            original_interest_rate: input.original_interest_rate,
            original_apr: input.original_apr,
            status: PromotionStatus.ACTIVE,
            notification_status: NotificationStatus.PENDING,
            start_date: input.start_date,
            end_date: input.end_date,
            applied_at: null,
            cancelled_at: null,
            notification_sent_at: null,
            cancelled_reason: null,
            version: 1,
            created_at: now,
            updated_at: now,
        };

        try {
            await putItemMethod({
                TableName: this.tableName,
                Item: record,
                ConditionExpression: "attribute_not_exists(promotion_id)",
            });
            return Success({ promotion_id: promotionId });
        } catch (error: any) {
            if (error?.name === "ConditionalCheckFailedException") {
                return Failure({
                    code: PromotionErrorCode.ALREADY_EXISTS,
                    message: `Promotion already exists for account ${input.credit_account_id}`,
                });
            }
            logger.error(
                `Failed to create promotion for account ${input.credit_account_id}: ${serializeError(error)}`,
            );
            return Failure({
                code: PromotionErrorCode.WRITE_FAILED,
                message: `Failed to create promotion for account ${input.credit_account_id}`,
            });
        }
    }

    async markApplied(record: PromotionRecord): Promise<PromotionResult<void>> {
        const now = dayjs().unix();

        return this.updateWithOptimisticLock(
            record,
            "SET #status = :status, #applied_at = :applied_at, #updated_at = :updated_at, #version = :newVersion " +
                "REMOVE #notification_status",
            {
                "#status": "status",
                "#applied_at": "applied_at",
                "#updated_at": "updated_at",
                "#notification_status": "notification_status",
            },
            {
                ":status": PromotionStatus.APPLIED,
                ":applied_at": now,
                ":updated_at": now,
                ":expectedStatus": PromotionStatus.ACTIVE,
            },
            "AND #status = :expectedStatus",
        );
    }

    async markCancelled(record: PromotionRecord, reason: string): Promise<PromotionResult<void>> {
        const now = dayjs().unix();

        return this.updateWithOptimisticLock(
            record,
            "SET #status = :status, #cancelled_at = :cancelled_at, #cancelled_reason = :cancelled_reason, " +
                "#updated_at = :updated_at, #version = :newVersion " +
                "REMOVE #notification_status",
            {
                "#status": "status",
                "#cancelled_at": "cancelled_at",
                "#cancelled_reason": "cancelled_reason",
                "#updated_at": "updated_at",
                "#notification_status": "notification_status",
            },
            {
                ":status": PromotionStatus.CANCELLED,
                ":cancelled_at": now,
                ":cancelled_reason": reason,
                ":updated_at": now,
                ":expectedStatus": PromotionStatus.ACTIVE,
            },
            "AND #status = :expectedStatus",
        );
    }

    async markNotified(record: PromotionRecord): Promise<PromotionResult<void>> {
        const now = dayjs().unix();

        return this.updateWithOptimisticLock(
            record,
            "SET #notification_sent_at = :notification_sent_at, #updated_at = :updated_at, #version = :newVersion " +
                "REMOVE #notification_status",
            {
                "#notification_sent_at": "notification_sent_at",
                "#updated_at": "updated_at",
                "#notification_status": "notification_status",
                "#status": "status",
            },
            {
                ":notification_sent_at": now,
                ":updated_at": now,
                ":expectedStatus": PromotionStatus.ACTIVE,
            },
            "AND #status = :expectedStatus",
        );
    }

    async getForAccount(
        creditAccountId: string,
        promotionType?: PromotionType,
    ): Promise<PromotionResult<PromotionRecord[]>> {
        const id = buildPartitionKey(creditAccountId);

        const params = {
            KeyConditionExpression: "#id = :id",
            ExpressionAttributeNames: { "#id": "id" } as Record<string, string>,
            ExpressionAttributeValues: { ":id": id } as Record<string, unknown>,
        };

        if (promotionType) {
            params.KeyConditionExpression +=
                " AND begins_with(#promotion_id, :promotion_id_prefix)";
            params.ExpressionAttributeNames["#promotion_id"] = "promotion_id";
            params.ExpressionAttributeValues[":promotion_id_prefix"] = `${promotionType}#`;
        }

        return this.queryAll(params);
    }

    async getForAccounts(
        creditAccountIds: string[],
        promotionType?: PromotionType,
    ): Promise<PromotionResult<PromotionRecord[]>> {
        const uniqueIds = [...new Set(creditAccountIds)];
        const results = await Promise.all(
            uniqueIds.map((id) => this.getForAccount(id, promotionType)),
        );

        const records: PromotionRecord[] = [];
        for (const result of results) {
            if (!result.ok) {
                return result;
            }
            records.push(...result.data);
        }

        return Success(records);
    }

    async getExpiredActive(
        promotionType: PromotionType,
        cursor?: Record<string, unknown>,
    ): Promise<PromotionResult<PagedResult<PromotionRecord>>> {
        const now = dayjs().unix();

        return this.queryPage(
            {
                KeyConditionExpression: "#status = :status AND #pt = :pt AND #ed <= :ed",
                ExpressionAttributeNames: {
                    "#status": "status",
                    "#pt": "promotion_type",
                    "#ed": "end_date",
                },
                ExpressionAttributeValues: {
                    ":status": PromotionStatus.ACTIVE,
                    ":pt": promotionType,
                    ":ed": now,
                },
            },
            "sweep-index",
            cursor,
        );
    }

    async getPendingNotification(
        promotionType: PromotionType,
        horizonDays: number,
        cursor?: Record<string, unknown>,
    ): Promise<PromotionResult<PagedResult<PromotionRecord>>> {
        const horizon = dayjs().add(horizonDays, "day").unix();

        return this.queryPage(
            {
                KeyConditionExpression: "#ns = :ns AND #pt = :pt AND #ed <= :ed",
                ExpressionAttributeNames: {
                    "#ns": "notification_status",
                    "#pt": "promotion_type",
                    "#ed": "end_date",
                },
                ExpressionAttributeValues: {
                    ":ns": NotificationStatus.PENDING,
                    ":pt": promotionType,
                    ":ed": horizon,
                },
            },
            "email-sweep-index",
            cursor,
        );
    }

    private async updateWithOptimisticLock(
        record: PromotionRecord,
        updateExpression: string,
        expressionAttributeNames: Record<string, string>,
        expressionAttributeValues: Record<string, unknown>,
        additionalCondition?: string,
    ): Promise<PromotionResult<void>> {
        try {
            await updateItemMethod({
                TableName: this.tableName,
                Key: { id: record.id, promotion_id: record.promotion_id },
                UpdateExpression: updateExpression,
                ExpressionAttributeNames: {
                    ...expressionAttributeNames,
                    "#version": "version",
                },
                ExpressionAttributeValues: {
                    ...expressionAttributeValues,
                    ":expectedVersion": record.version,
                    ":newVersion": record.version + 1,
                },
                ConditionExpression: `#version = :expectedVersion${additionalCondition ? ` ${additionalCondition}` : ""}`,
                ReturnValues: "ALL_NEW",
            });
            return Success();
        } catch (error: any) {
            logger.error(
                `Failed to update promotion ${record.promotion_id}: ${serializeError(error)}`,
            );
            return Failure({
                code: PromotionErrorCode.UPDATE_FAILED,
                message: `Failed to update promotion ${record.promotion_id}`,
            });
        }
    }

    private async queryAll(params: {
        KeyConditionExpression: string;
        ExpressionAttributeNames: Record<string, string>;
        ExpressionAttributeValues: Record<string, unknown>;
    }): Promise<PromotionResult<PromotionRecord[]>> {
        const items: PromotionRecord[] = [];
        let cursor: Record<string, unknown> | undefined;

        try {
            do {
                const result = await queryTableMethod({
                    TableName: this.tableName,
                    ...params,
                    ...(cursor && { ExclusiveStartKey: cursor }),
                } as Parameters<typeof queryTableMethod>[0]);

                if (result?.Items) {
                    items.push(...(result.Items as PromotionRecord[]));
                }
                cursor = result?.LastEvaluatedKey;
            } while (cursor);

            return Success(items);
        } catch (error: any) {
            logger.error(`Failed to query promotions: ${serializeError(error)}`);
            return Failure({
                code: PromotionErrorCode.QUERY_FAILED,
                message: "Failed to query promotions",
            });
        }
    }

    private async queryPage(
        params: {
            KeyConditionExpression: string;
            ExpressionAttributeNames: Record<string, string>;
            ExpressionAttributeValues: Record<string, unknown>;
        },
        indexName: string,
        cursor?: Record<string, unknown>,
    ): Promise<PromotionResult<PagedResult<PromotionRecord>>> {
        try {
            const result = await queryTableMethod({
                TableName: this.tableName,
                IndexName: indexName,
                ...params,
                ...(cursor && { ExclusiveStartKey: cursor }),
            } as Parameters<typeof queryTableMethod>[0]);

            return Success({
                items: (result?.Items as PromotionRecord[]) ?? [],
                cursor: result?.LastEvaluatedKey,
            });
        } catch (error: any) {
            logger.error(`Failed to query promotions (${indexName}): ${serializeError(error)}`);
            return Failure({
                code: PromotionErrorCode.QUERY_FAILED,
                message: `Failed to query promotions (${indexName})`,
            });
        }
    }
}
