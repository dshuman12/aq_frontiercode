import { v5 as uuidv5 } from "uuid";

// uuidv5("onmo.promotions", uuidv5.DNS)
const PROMOTION_UUID_NAMESPACE = "fe9c9014-48ea-50f6-ac45-0461efe8bb25";

export const buildPartitionKey = (creditAccountId: string): string =>
    uuidv5(creditAccountId, PROMOTION_UUID_NAMESPACE);

export const buildSortKey = (promotionType: string, startDate: number): string =>
    `${promotionType}#${startDate}`;
