import { describe, expect, it, vi, beforeEach, beforeAll, afterAll } from "vitest";

import { buildPartitionKey, buildSortKey } from "./keys";

vi.mock("@onmoapp/onmo-dynamodb", () => ({
    putItemMethod: vi.fn(),
    queryTableMethod: vi.fn(),
    updateItemMethod: vi.fn(),
}));

import { queryTableMethod } from "@onmoapp/onmo-dynamodb";
import { PromotionService } from "./index";
import { PromotionErrorCode, PromotionType } from "@libs/types/promotion";
import { makePromotionRecord } from "@utils/testUtils/promotionFixtures";

describe("buildPartitionKey", () => {
    it("should produce a stable value for ACC-001", () => {
        expect(buildPartitionKey("ACC-001")).toBe("22c1e3e0-a8b1-545a-9dd5-ba00b7b6daff");
    });
});

describe("buildSortKey", () => {
    it("should produce a readable composite key", () => {
        expect(buildSortKey("HONEYMOON", 1700000000)).toBe("HONEYMOON#1700000000");
    });
});

describe("PromotionService.getForAccounts", () => {
    let service: PromotionService;
    const originalPromotionsTable = process.env.PROMOTIONS_TABLE;

    beforeAll(() => {
        process.env.PROMOTIONS_TABLE = "test-promotions";
    });

    afterAll(() => {
        if (originalPromotionsTable === undefined) {
            delete process.env.PROMOTIONS_TABLE;
            return;
        }
        process.env.PROMOTIONS_TABLE = originalPromotionsTable;
    });

    beforeEach(() => {
        vi.clearAllMocks();
        // Reset singleton so each test gets a fresh instance
        (PromotionService as any).instance = null;
        service = PromotionService.getInstance();
    });

    it("returns flattened records across multiple accounts", async () => {
        const recordA = makePromotionRecord({ credit_account_id: "ACC-001" });
        const recordB = makePromotionRecord({
            credit_account_id: "ACC-002",
            promotion_id: "HONEYMOON#1710000000",
            start_date: 1710000000,
            end_date: 1720000000,
        });

        vi.mocked(queryTableMethod)
            .mockResolvedValueOnce({ Items: [recordA] } as any)
            .mockResolvedValueOnce({ Items: [recordB] } as any);

        const result = await service.getForAccounts(["ACC-001", "ACC-002"]);

        expect(result.ok).toBe(true);
        if (result.ok) {
            expect(result.data).toEqual([recordA, recordB]);
        }
        expect(queryTableMethod).toHaveBeenCalledTimes(2);

        const queriedIds = vi
            .mocked(queryTableMethod)
            .mock.calls.map((call) => (call[0] as any).ExpressionAttributeValues[":id"]);
        expect(queriedIds).toEqual([buildPartitionKey("ACC-001"), buildPartitionKey("ACC-002")]);
    });

    it("deduplicates repeated account ids", async () => {
        vi.mocked(queryTableMethod).mockResolvedValue({ Items: [] } as any);

        const result = await service.getForAccounts(["ACC-001", "ACC-001", "ACC-002"]);

        expect(result.ok).toBe(true);
        expect(queryTableMethod).toHaveBeenCalledTimes(2);

        const queriedIds = vi
            .mocked(queryTableMethod)
            .mock.calls.map((call) => (call[0] as any).ExpressionAttributeValues[":id"]);
        expect(queriedIds).toEqual([buildPartitionKey("ACC-001"), buildPartitionKey("ACC-002")]);
    });

    it("returns empty array when no accounts provided", async () => {
        const result = await service.getForAccounts([]);

        expect(result.ok).toBe(true);
        if (result.ok) {
            expect(result.data).toEqual([]);
        }
        expect(queryTableMethod).not.toHaveBeenCalled();
    });

    it("returns Failure when a per-account query fails", async () => {
        vi.mocked(queryTableMethod)
            .mockResolvedValueOnce({ Items: [makePromotionRecord()] } as any)
            .mockRejectedValueOnce(new Error("dynamo throttled"));

        const result = await service.getForAccounts(["ACC-001", "ACC-002"]);

        expect(result.ok).toBe(false);
        if (!result.ok) {
            expect(result.error.code).toBe(PromotionErrorCode.QUERY_FAILED);
        }
    });

    it("pushes a promotion_type filter down as begins_with on the sort key", async () => {
        vi.mocked(queryTableMethod).mockResolvedValue({ Items: [] } as any);

        await service.getForAccounts(["ACC-001"], PromotionType.HONEYMOON);

        expect(queryTableMethod).toHaveBeenCalledTimes(1);
        const call = vi.mocked(queryTableMethod).mock.calls[0][0] as any;
        expect(call.KeyConditionExpression).toBe(
            "#id = :id AND begins_with(#promotion_id, :promotion_id_prefix)",
        );
        expect(call.ExpressionAttributeNames).toEqual({
            "#id": "id",
            "#promotion_id": "promotion_id",
        });
        expect(call.ExpressionAttributeValues).toEqual({
            ":id": buildPartitionKey("ACC-001"),
            ":promotion_id_prefix": `${PromotionType.HONEYMOON}#`,
        });
    });

    it("omits the sort-key filter when no promotion_type is provided", async () => {
        vi.mocked(queryTableMethod).mockResolvedValue({ Items: [] } as any);

        await service.getForAccounts(["ACC-001"]);

        const call = vi.mocked(queryTableMethod).mock.calls[0][0] as any;
        expect(call.KeyConditionExpression).toBe("#id = :id");
        expect(call.ExpressionAttributeNames).toEqual({ "#id": "id" });
    });
});
