import { EventData, EventHubDataToPublishType } from "@onmoapp/event-hub-kinesis-adapter";
import { deserializeUtil } from "./util";

export const deserializeKinesisEvent = async <T>(event: any): Promise<EventData<T>> => {
    const data = event?.Records[0]?.kinesis?.data;
    const dataBuffer = JSON.parse(
        Buffer.from(data, "base64").toString(),
    ) as EventHubDataToPublishType;
    return deserializeUtil(dataBuffer.data, dataBuffer.schemaId);
};
