import {
    SchedulerClient,
    ListSchedulesCommand,
    ListSchedulesCommandInput,
    DeleteScheduleCommandInput,
    DeleteScheduleCommand,
} from "@aws-sdk/client-scheduler";
import { DD_RETRY_NAME_PREFIX } from "@libs/constants";
import { getLogger } from "@utils/logger";

export const findAndDeleteSchedule = async (accountId: string): Promise<void> => {
    const logger = getLogger();

    logger.addContext({ functionName: "findAndDeleteSchedule", accountId });
    try {
        const client = new SchedulerClient({ region: process.env.REGION });

        const params = {
            GroupName: process.env.DD_RETRY_GROUP_NAME,
            MaxResults: 1,
            NamePrefix: `${DD_RETRY_NAME_PREFIX}-${accountId}`,
        } as ListSchedulesCommandInput;

        logger.addContext({ params });
        logger.info({ message: "Sending command to list schedules by name prefix" });
        const command = new ListSchedulesCommand(params);

        const response = await client.send(command);
        logger.info({ message: "Received response", response });

        if (response.Schedules.length > 0) {
            const deleteCommand = {
                Name: response.Schedules[0].Name,
                GroupName: process.env.DD_RETRY_GROUP_NAME,
            } as DeleteScheduleCommandInput;

            logger.info({ message: "Sending command to delete schedule", deleteCommand });
            const delCommand = new DeleteScheduleCommand(deleteCommand);
            const delRes = await client.send(delCommand);
            logger.info({ message: "Received response", delRes });
        }
    } catch (err) {
        logger.error({ message: "Error in findAndDeleteSchedule", error: err });
        throw err;
    }
};
