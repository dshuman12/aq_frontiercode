import { beforeEach, describe, expect, it, vi } from "vitest";
import { InterestAndFeesService } from "./interestAndFeesService";
import { GetAllTransactionOutcome } from "@onmoapp/onmo-types";
import { MambuClient } from "@onmoapp/mambu-adapter";

describe("InterestAndFeesService", () => {
    const accountEncodedKey = "test-account-key";
    const startDate = "2023-01-01";
    const endDate = "2023-01-31";

    const coreBankingClient = {
        getAllApprovedTransactions: vi.fn(),
    } as unknown as MambuClient;

    beforeEach(() => {
        vi.clearAllMocks();
        vi.resetAllMocks();
    });

    it("should fetch all transactions with multiple requests if total exceeds limit", async () => {
        const mockFirstResponse: GetAllTransactionOutcome = {
            data: {
                transactions: Array(50).fill({}),
                totalTransactionsCount: 120,
            },
            error: null,
        };
        const mockSecondResponse: GetAllTransactionOutcome = {
            data: {
                transactions: Array(50).fill({}),
                totalTransactionsCount: 120,
            },
            error: null,
        };
        const mockThirdResponse: GetAllTransactionOutcome = {
            data: {
                transactions: Array(20).fill({}),
                totalTransactionsCount: 120,
            },
            error: null,
        };

        // Mock the coreBankingClient to return the mocked responses sequentially
        vi.mocked(coreBankingClient.getAllApprovedTransactions)
            .mockResolvedValueOnce(mockFirstResponse)
            .mockResolvedValueOnce(mockSecondResponse)
            .mockResolvedValueOnce(mockThirdResponse);

        const result = await InterestAndFeesService.fetchAllApprovedTransactions(
            accountEncodedKey,
            {
                startDate,
                endDate,
            },
            coreBankingClient,
        );

        expect(coreBankingClient.getAllApprovedTransactions).toHaveBeenCalledTimes(3);
        expect(result.length).toBe(120); // Ensure all 120 transactions are fetched
    });

    it("should exit the loop after 3 attempts and return the 49 transaction", async () => {
        const mockFirstResponse: GetAllTransactionOutcome = {
            data: {
                transactions: Array(49).fill({}),
                totalTransactionsCount: 50,
            },
            error: null,
        };
        const mockSecondResponse: GetAllTransactionOutcome = {
            data: {
                transactions: Array(0).fill({}),
                totalTransactionsCount: 50,
            },
            error: null,
        };

        vi.mocked(coreBankingClient.getAllApprovedTransactions)
            .mockResolvedValueOnce(mockFirstResponse)
            .mockResolvedValueOnce(mockSecondResponse)
            .mockResolvedValueOnce(mockSecondResponse)
            .mockResolvedValueOnce(mockSecondResponse)
            .mockResolvedValueOnce(mockSecondResponse);

        const result = await InterestAndFeesService.fetchAllApprovedTransactions(
            accountEncodedKey,
            {
                startDate,
                endDate,
            },
            coreBankingClient,
        );

        expect(coreBankingClient.getAllApprovedTransactions).toHaveBeenCalledTimes(4);
        expect(result.length).toBe(49);
    });

    it("should handle case where no transactions are found", async () => {
        const mockEmptyResponse: GetAllTransactionOutcome = {
            data: {
                transactions: [],
                totalTransactionsCount: 0,
            },
            error: null,
        };

        vi.mocked(coreBankingClient.getAllApprovedTransactions).mockResolvedValue(
            mockEmptyResponse,
        );

        const result = await InterestAndFeesService.fetchAllApprovedTransactions(
            accountEncodedKey,
            {
                startDate,
                endDate,
            },
            coreBankingClient,
        );

        expect(coreBankingClient.getAllApprovedTransactions).toHaveBeenCalledTimes(1); // Only one call expected
        expect(result.length).toBe(0); // No transactions should be returned
    });
});
