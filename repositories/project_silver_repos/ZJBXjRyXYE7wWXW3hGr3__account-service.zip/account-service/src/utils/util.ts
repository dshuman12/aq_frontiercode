import { IndexType, DocType } from "@libs/types";
import { DocumentInfo } from "@onmoapp/onmo-types";
import { AWSGlueClient } from "@onmoapp/onmo-glue";

/**
 * Sorts the given array of DocumentInfo objects based on their timeStamp and fileName.
 * If the timeStamps are equal, the files are sorted by their names.
 * The order of the sorted array can be specified by the 'orderBy' parameter.
 * If 'orderBy' is set to 'asc', the array is sorted in ascending order.
 * If 'orderBy' is set to 'desc', the array is sorted in descending order.
 *
 * @param docs The array of DocumentInfo objects to be sorted.
 * @param orderBy The order of the sorted array. Can be either 'asc' or 'desc'.
 * @returns The sorted array of DocumentInfo objects.
 */
export function sortByDate(docs: DocumentInfo[], orderBy: "asc" | "desc"): DocumentInfo[] {
    return docs.sort((a: DocumentInfo, b: DocumentInfo) => {
        if (orderBy === "desc") {
            return b.timeStamp === a.timeStamp
                ? b.fileName.localeCompare(a.fileName)
                : b.timeStamp - a.timeStamp;
        } else {
            return a.timeStamp === b.timeStamp
                ? a.fileName.localeCompare(b.fileName)
                : a.timeStamp - b.timeStamp;
        }
    });
}

/**
 * Indexes the given array of DocumentInfo objects by their year and month.
 * The resulting indexedDocs array will have each DocumentInfo object's id set to its index in the original array.
 * The docIndex object will contain a map of the year-month format string
 * to the starting and ending indexes of the documents in that time period,
 * along with the total number of documents in that period.
 *
 * @param docs The array of DocumentInfo objects to be indexed.
 * @returns { indexedDocs: DocType[] docIndex: IndexType } An object containing
 * the indexedDocs array (which contain id) and the docIndex object.
 */
export function indexDocumentsByYearAndMonth(docs: DocumentInfo[]): {
    indexedDocs: DocType[];
    docIndex: IndexType;
} {
    const docIndex: IndexType = {}; // metadata of documents indexed by YYYYMM
    const indexedDocs = docs.map((doc: DocumentInfo, index: number): DocType => {
        const yyyymm = doc.year + doc.month; // YYYYMM format string
        if (docIndex[yyyymm]) {
            const ele = docIndex[yyyymm];
            if (index < ele["startingIndex"]) {
                ele["startingIndex"] = index;
            }
            if (index > ele["endingIndex"]) {
                ele["endingIndex"] = index;
            }
            ele["length"] = ele["endingIndex"] - ele["startingIndex"] + 1;
        } else {
            docIndex[yyyymm] = {
                startingIndex: index,
                endingIndex: index,
                length: 1,
            };
        }
        doc["id"] = index;
        return doc as DocType;
    });
    return { indexedDocs, docIndex };
}

/**
 * Returns a promise that resolves to an object containing an empty array of documents.
 * The promise also resolves with a null error.
 *
 * @returns A promise that resolves to an object with an empty array of documents and a null error.
 */
export const emptyDocsPromise = Promise.resolve({
    data: {
        documents: [],
    },
    error: null,
});

export const deserializeUtil = async (dataString: string, schemaId: string): Promise<any> => {
    const glueClient = new AWSGlueClient();
    const decodedData = await glueClient.deserializeWithDataSchema(dataString, {
        SchemaVersionId: schemaId,
    });
    return decodedData;
};
