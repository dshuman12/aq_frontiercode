import { ApiResponse, APIGatewayProxyEvent, apiResponse } from "@onmoapp/handler-middleware";
import { OnmoError } from "@onmoapp/onmo-error-types";

import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { checkAccess } from "@utils/oidc-authorization";

export type AccessCheck =
    | { allow: true; response?: never }
    | { allow: false; response: ApiResponse };

// Migration scaffolding: checkAccess throws OnmoError, but withApiErrorHandling collapses
// every exception into a 500 — we'd lose the 401/404 contracts the OIDC gateway relies on.
// This guard catches OnmoError once at the boundary and maps it to the right apiResponse
// so handler bodies can stay try/catch-free.
// End state: once the remaining legacy handlers migrate, convert checkAccess itself to a
// Result<void, AuthError> and delete this guard.
export const guardAccountAccess = async (
    requestContext: APIGatewayProxyEvent["requestContext"],
    accountId: string,
): Promise<AccessCheck> => {
    try {
        await checkAccess(requestContext, accountId);
        return { allow: true };
    } catch (error) {
        if (!(error instanceof OnmoError)) throw error;
        const { statusCode, message } = generateErrorResponse(error);
        return { allow: false, response: apiResponse(statusCode, { message }) };
    }
};
