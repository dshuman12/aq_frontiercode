import { AccountFlagTypes } from "@libs/types";

/**
 * Mapping of AccountFlagTypes enum values to their corresponding Core Banking input format.
 * This object contains the flag module and key, as well as the optional flag status, start date, and end date.
 */
const flagMapping = {
    ParticularlyVulnerableCustomer: "collectionPlanFlags.particularlyVulnerable",
    ConfirmedBankruptcy: "collectionPlanFlags.confirmedBankruptcy",
    ConfirmedDebtReliefOrder: "collectionPlanFlags.confirmedDRO",
    ConfirmedIVA: "collectionPlanFlags.confirmedIVA",
    DebtRespiteSchemeBreathingSpace: "collectionPlanFlags.breathingSpaceDebtRespiteScheme",
    DebtRespiteSchemeMentalHealthMoratorium:
        "collectionPlanFlags.breathingSpaceMentalHealthMoratorium",
    InternalBreathingSpace: "collectionPlanFlags.breathingSpaceInternal",
    Default: "collectionPlanFlags.default",
    PendingBankruptcy: "collectionPlanFlags.pendingBankruptcy",
    PendingIVA: "collectionPlanFlags.pendingIVA",
    DCAArdent: "collectionPlanFlags.ardentDCA",
    PEP: "fraudAndFinancialFlags.confirmedPEP",
    ActiveComplaint: "creditAccountCRMFlags.activeComplaint",
    ConfirmedDeceased: "customerSupportFlags.confirmedDeceased",
    DisputedDebt: "fraudAndFinancialFlags.disputedDebt",
    PendingDeceased: "customerSupportFlags.pendingDeceased",
    Confirmed1stParty: "fraudAndFinancialFlags.confirmed1stParty",
    Suspected1stParty: "fraudAndFinancialFlags.suspected1stParty",
    Suspected3rdParty: "fraudAndFinancialFlags.suspected3rdParty",
    Confirmed3rdParty: "fraudAndFinancialFlags.confirmed3rdParty",
    ConfirmedRCA: "fraudAndFinancialFlags.confirmedRCA",
    SuspectedDesignatedPerson: "fraudAndFinancialFlags.suspectedDesignatedPerson",
    ConfirmedDesignatedPerson: "fraudAndFinancialFlags.confirmedDesignatedPerson",
    CifasFirstPartyMatch: "fraudAndFinancialFlags.cifasFirstPartyMatch",
    Inconsistent: "fraudAndFinancialFlags.inconsistent",
};

/**
 * Mapping of AccountFlagTypes enum values to their corresponding Core Banking input format.
 * This object contains the flag module and key, as well as the optional flag status, start date, and end date.
 */
const flagWithDate = {
    ConfirmedBankruptcy: "collectionPlanFlags.confirmedBankruptcyDate.startDate",
    ConfirmedDebtReliefOrder: "collectionPlanFlags.DROExpiryDate.endDate",
    ConfirmedIVA: "collectionPlanFlags.confirmedIVADate.startDate",
    DebtRespiteSchemeBreathingSpace: "collectionPlanFlags.breathingSpaceEndDate.endDate",
    DebtRespiteSchemeMentalHealthMoratorium: "collectionPlanFlags.breathingSpaceEndDate.endDate",
    InternalBreathingSpace: "collectionPlanFlags.breathingSpaceEndDate.endDate",
    Default: "collectionPlanFlags.defaultDate.startDate",
    PendingIVA: "collectionPlanFlags.pendingIVADate.startDate",
    DCAArdent: "collectionPlanFlags.ardentDCADatePassed.startDate",
    PEP: "fraudAndFinancialFlags.confirmedPEPDate.startDate",
    Confirmed1stParty: "fraudAndFinancialFlags.confirmed1stPartyDate.startDate",
    Suspected1stParty: "fraudAndFinancialFlags.suspected1stPartyDate.startDate",
    Suspected3rdParty: "fraudAndFinancialFlags.suspected3rdPartyDate.startDate",
    Confirmed3rdParty: "fraudAndFinancialFlags.confirmed3rdPartyDate.startDate",
    ConfirmedRCA: "fraudAndFinancialFlags.confirmedRCADate.startDate",
    SuspectedRCA: "fraudAndFinancialFlags.suspectedRCADate.startDate",
    SuspectedDesignatedPerson: "fraudAndFinancialFlags.suspectedDesignatedPersonDate.startDate",
    ConfirmedDesignatedPerson: "fraudAndFinancialFlags.confirmedDesignatedPersonDate.startDate",
    CifasFirstPartyMatch: "fraudAndFinancialFlags.cifasFirstPartyMatchDate.startDate",
};

/**
 * Transforms a flag from the AccountFlagTypes enum to a format suitable for input to the Core Banking Adapter.
 *
 * @param flag - The AccountFlagTypes enum value to be transformed.
 * @param options - An object containing the flag status and optional start and end dates.
 * @returns A mapping object containing the transformed flag and its associated values.
 */
export function transformFlagToCoreBankingInputType(
    flag: AccountFlagTypes,
    options: {
        flagStatus: boolean;
        startDate?: string;
        endDate?: string | null;
    },
) {
    const [flagModule, flagKey] = flagMapping[flag] ? (flagMapping[flag] as string).split(".") : [];
    const [, flagDateKey, flagDateAcceptanceType] = flagWithDate[flag]
        ? (flagWithDate[flag] as string).split(".")
        : [];
    if (flagModule && flagKey) {
        const mapping = {
            [flagModule]: {
                [flagKey]: options?.flagStatus,
                ...(flagDateKey &&
                    options[flagDateAcceptanceType] && {
                        [flagDateKey]: options[flagDateAcceptanceType],
                    }),
            },
        };
        return mapping;
    }
    return null;
}
