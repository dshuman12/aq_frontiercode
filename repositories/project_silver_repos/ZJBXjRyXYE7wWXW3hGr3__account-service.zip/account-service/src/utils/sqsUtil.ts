import { deleteMessage } from "@onmoapp/onmo-sqs";
import { getLogger } from "./logger";
import { formatErrorMessage } from "./onmoErrorHandler";
import { SQSRecord } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";

export type ErrorLogInput = {
    sqsRecord: SQSRecord;
    message: string;
    logger: Logger;
};

export const deleteMessageFromQueue = async ({
    queueUrl,
    receiptHandle,
}: {
    queueUrl: string;
    receiptHandle: string;
}): Promise<void> => {
    const logger = getLogger();
    logger.addContext({ origin: "deleteMessageFromQueue" });
    try {
        await deleteMessage({
            ReceiptHandle: receiptHandle,
            QueueUrl: queueUrl,
        });
        logger.info({
            outputMessage: "Message deleted successfully",
            receiptHandle,
        });
    } catch (error) {
        const errorMessage = formatErrorMessage(error);
        logger.error({
            errorMessage: `Error deleting message: ${errorMessage}`,
            error,
        });
        throw error;
    }
};

export const logAndReturnFailedMessage = ({ logger, message, sqsRecord }: ErrorLogInput) => {
    logErrorWithContextReset({ logger, message, sqsRecord });
    return {
        error: {
            message,
            sqsMessageId: sqsRecord.messageId,
        },
    };
};

export const logErrorWithContextReset = ({ logger, message, sqsRecord }: ErrorLogInput) => {
    logger.addContext({ sqsRecord });
    logger.error(message);
    logger.removeContext("sqsRecord");
};
