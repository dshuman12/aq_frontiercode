import { DocType, IndexType } from "@libs/types";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";

/**
 * Paginates the documents based on the provided parameters.
 *
 * @param Docs - An array of document objects.
 * @param indexing - An object containing the indexing information for each month.
 * @param periodFrom - The starting period for pagination.
 * @param count - The number of documents to return in each page.
 * @param documentCursor - The cursor to be used for pagination.
 * @param orderBy - The order by parameter for sorting the documents.
 *
 * @returns An object containing the paginated documents, the next document cursor, and the next period from.
 */
export const paginationLogic = (
    Docs: DocType[],
    indexing: IndexType,
    periodFrom: string,
    count: number,
    documentCursor: number,
    orderBy: "asc" | "desc",
) => {
    const sortedMonths = Object.keys(indexing);
    const monthQueryFrom =
        orderBy === "asc"
            ? sortedMonths.find((mon) => mon >= periodFrom)
            : sortedMonths.reverse().find((mon) => mon <= periodFrom);

    if (monthQueryFrom) {
        if (monthQueryFrom !== periodFrom) documentCursor = 0;
        if (monthQueryFrom === periodFrom && documentCursor > +indexing[monthQueryFrom].length - 1)
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "Invalid Document cursor",
            });
        const strIndex = +indexing[monthQueryFrom].startingIndex + documentCursor;
        if (strIndex + count < Docs.length) {
            const endIndex = strIndex + count;
            const nextEle = Docs[endIndex];
            const nextPeriodFrom = nextEle.year + nextEle.month;
            return {
                documents: Docs.slice(strIndex, endIndex).map((doc) => {
                    return {
                        documentType: doc.documentType,
                        documentId: doc.documentId, // s3 Key
                        fileName: doc.fileName,
                        year: doc.year,
                        month: doc.month,
                        ...(doc.documentType === "contracts" && {
                            day: doc.day,
                        }),
                    };
                }),
                nextDocumentCursor: nextEle.id - indexing[nextPeriodFrom].startingIndex,
                nextPeriodFrom,
            };
        } else {
            return {
                documents: Docs.slice(strIndex, Docs.length).map((doc) => {
                    return {
                        documentType: doc.documentType,
                        documentId: doc.documentId, // s3 Key
                        fileName: doc.fileName,
                        year: doc.year,
                        month: doc.month,
                        ...(doc.documentType === "contracts" && {
                            day: doc.day,
                        }),
                    };
                }),
                nextDocumentCursor: 0,
                nextPeriodFrom: "",
            };
        }
    } else {
        // if monthQueryFrom is not found, then return empty array
        return {
            documents: [],
            nextDocumentCursor: 0,
            nextPeriodFrom: "",
        };
    }
};
