import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";

/**
 * Generates an error response object based on the provided error.
 *
 * @param error - The error object to generate a response for.
 * @returns An object containing the status code, error message, and debug message.
 */
export function generateErrorResponse(error: OnmoError | Error | any) {
    let statusCode = 500;
    let message = "Internal Server Error";
    let debugMessage = error;

    if (error instanceof OnmoError) {
        // if error type is OnmoError
        if (error?.cause?.errorCode) {
            // if error cause has an errorCode from s3 adapter
            const errorCode = error.cause.errorCode;
            switch (errorCode) {
                case 1:
                    statusCode = 400;
                    message = error?.cause?.errorMessage || "Bad Request";
                    break;
                case 2:
                    statusCode = 401;
                    message = error?.cause?.errorMessage || "Unauthorized";
                    break;
                case 3:
                    statusCode = 403;
                    message = "Forbidden";
                    break;
                case 4:
                    statusCode = 404;
                    message = error?.cause?.errorMessage || "Not Found";
                    break;
                default:
                    statusCode = 500;
                    message = "Internal Server Error";
                    break;
            }
        } else {
            if (error.name === ErrorNamesEnum.INPUT_VALIDATION_ERROR) {
                statusCode = 400;
                message = error.message;
            } else if (error.name === "NOT_AUTHORIZED") {
                statusCode = 401;
                message = error.message;
            } else if (error.name === ErrorNamesEnum.NOT_FOUND_ERROR) {
                statusCode = 404;
                message = error.message;
            } else {
                statusCode = 500;
            }
        }
    } else {
        statusCode = 500;
        debugMessage = error.stack;
    }

    return {
        statusCode,
        message,
        debugMessage,
    };
}

/**
 * Throws an error if the adapter response has an error or if the extra condition is true.
 *
 * @param adapterResponse - The response object from the adapter.
 * @param options - An object containing the extra condition and the error message.
 * @throws {OnmoError} - Throws an OnmoError with the specified message and the adapter error as the cause.
 */
export function throwErrorIfAdapterResHaveError(
    adapterResponse: { data: any | null; error: any | null } | undefined,
    options: {
        extraCondition?: boolean;
        message: string;
    },
) {
    if (
        !adapterResponse ||
        adapterResponse.error ||
        !adapterResponse.data ||
        options.extraCondition
    ) {
        throw new OnmoError({
            name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
            message: options.message || "Something went wrong",
            cause: adapterResponse?.error,
        });
    }
}

export const formatErrorMessage = (error: any): string => {
    const errorMessage =
        error instanceof Error ? `${error.name}: ${error.message}` : JSON.stringify(error);
    return errorMessage;
};
