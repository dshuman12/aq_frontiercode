import { APIGatewayEvent } from "aws-lambda";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { OnmoError } from "@onmoapp/onmo-error-types";
import { logger } from "@utils/logger";

/**
 * Checks if the user has access to the specified account.
 *
 * @param requestContext - The API Gateway request context containing the domain name and authorizer information.
 * @param accountId - The ID of the account the user is trying to access.
 * @returns Nothing.
 * @throws Throws an `OnmoError` if the user is not authorized to access the specified account.
 */

export const checkAccess = async (
    requestContext: APIGatewayEvent["requestContext"],
    accountId: string,
): Promise<void> => {
    logger.info("Request is from domain := " + requestContext.domainName);
    const onmo_api_url = process.env.ONMO_API_URL;
    if (onmo_api_url === requestContext.domainName) {
        const customerId = requestContext.authorizer.onmouuid ?? null;
        if (!customerId) {
            throw new OnmoError({
                name: "NOT_AUTHORIZED",
                message: "Customer ID not found in request authorization context",
            } as any);
        }
        const customerData = await getItemMethod({
            TableName: process.env.USER_TABLE,
            Key: {
                onmouuid: customerId,
            },
        });
        logger.debug({ customerData });
        if (!customerData.Item) {
            throw new OnmoError({
                name: "NOT_FOUND_ERROR",
                message: "authorized user not found",
            });
        }
        if (accountId !== customerData.Item.mambuCreditCardAccountID) {
            logger.warn({
                message: "User is not authorized to access this account",
                accountId,
                authorizedCustomer: {
                    customerId: customerId,
                    accountId: customerData.Item.mambuCreditCardAccountID ?? null,
                },
            });
            throw new OnmoError({
                name: "NOT_AUTHORIZED",
                message: "user is not authorized to access this account",
            } as any);
        }
    }
};
