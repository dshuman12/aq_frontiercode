import { Logger } from "@onmoapp/onmo-logger";

export const logger = new Logger(
    {
        env: process.env.STAGE,
    },
    "INFO",
);

export const getLogger = () =>
    // need to create a new logger every time as the context is shared between invocations
    new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );
