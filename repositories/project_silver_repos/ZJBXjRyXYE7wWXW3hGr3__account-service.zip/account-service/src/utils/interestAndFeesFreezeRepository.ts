import {
    IInterestAndFeesFreezeRepository,
    InterestAndFeesFreezeData,
    UpdateFieldsPayload,
    interestAndFeesPK,
} from "@libs/types/interestAndFees";
import { putItemMethod, queryTableMethod, updateItemMethod } from "@onmoapp/onmo-dynamodb";
import { OnmoError } from "@onmoapp/onmo-error-types";
import dayjs from "dayjs";
import { INTEREST_FEES_FREEZE_STATUS } from "@libs/constants";
import { Logger } from "@onmoapp/onmo-logger";

export const logger = new Logger(
    {
        env: process.env.STAGE,
    },
    "INFO",
);

export class InterestAndFeesFreezeRepository implements IInterestAndFeesFreezeRepository {
    private tableName: string;
    static instance: InterestAndFeesFreezeRepository | null;

    constructor(tableName: string) {
        this.tableName = tableName;
    }

    static getInstance() {
        logger.removeContext();
        if (!this.instance) {
            this.instance = new InterestAndFeesFreezeRepository(
                process.env.INTEREST_FEES_FREEZE_TABLE,
            );
        }
        return this.instance;
    }

    // returns latest record
    async getByAccountId(accountId: string): Promise<InterestAndFeesFreezeData> {
        try {
            const queryTableMethodRes = await queryTableMethod({
                TableName: this.tableName,
                KeyConditionExpression: "#accountId = :accountId",
                ExpressionAttributeValues: {
                    ":accountId": accountId,
                },
                ExpressionAttributeNames: {
                    "#accountId": "accountId",
                },
                ScanIndexForward: false,
            });

            if (queryTableMethodRes?.Items?.[0]) {
                return queryTableMethodRes?.Items?.[0] as InterestAndFeesFreezeData;
            }

            throw "No data found";
        } catch (error) {
            logger.error(`GetByAccountId ERROR ===> ${error}`);
            throw new OnmoError({
                name: "INTERNAL_SERVER_ERROR",
                message: `Error fetching interest and fees account record for accountId ${accountId}`,
            });
        }
    }

    async create(data: InterestAndFeesFreezeData): Promise<InterestAndFeesFreezeData> {
        try {
            const now = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
            const _data = { ...data, createdAt: now, updatedAt: now };

            await putItemMethod({
                TableName: this.tableName,
                Item: _data,
            });
            return _data;
        } catch (error) {
            logger.error(`Create ERROR ===> ${error}`);
            throw new OnmoError({
                name: "INTERNAL_SERVER_ERROR",
                message: `Error saving interest and fees account record for accountId ${data.accountId}`,
            });
        }
    }

    async update(data: InterestAndFeesFreezeData): Promise<void> {
        try {
            const {
                accountId,
                adjustedTransactions,
                originalInterestRate,
                apr,
                status,
                createdAt,
            } = data;

            const now = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
            logger.info({ updateData: data });

            await updateItemMethod({
                TableName: this.tableName,
                Key: {
                    accountId,
                    createdAt,
                },
                UpdateExpression: `
                    SET updatedAt = :updatedAt,
                        originalInterestRate = :originalInterestRate,
                        apr = :apr,
                        #status = :status,
                        adjustedTransactions = :adjustedTransactions
                    `,

                ExpressionAttributeValues: {
                    ":updatedAt": now,
                    ":originalInterestRate": originalInterestRate,
                    ":apr": apr ?? null,
                    ":status": status,
                    ":adjustedTransactions": adjustedTransactions,
                },
                ExpressionAttributeNames: {
                    "#status": "status",
                },
                ReturnValues: "ALL_NEW",
            });
        } catch (error) {
            logger.error(`Update ERROR ===> ${error}`);
            throw new OnmoError({
                name: "INTERNAL_SERVER_ERROR",
                message: `Error saving interest and fees account record for accountId ${data.accountId}`,
            });
        }
    }

    async updateFieldsByPK(
        primaryKey: interestAndFeesPK,
        updateData: UpdateFieldsPayload,
    ): Promise<InterestAndFeesFreezeData> {
        try {
            let updateExpression = "SET ";
            const expressionAttributeValues = {};
            const expressionAttributeNames = {};
            let updateExpressions = [];

            const now = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSSZ");

            updateData["updatedAt"] = now;

            logger.info({ updateData });

            for (const [field, value] of Object.entries(updateData)) {
                const placeholder = `#${field}`;
                const valuePlaceholder = `:${field}`;

                updateExpressions.push(`${placeholder} = ${valuePlaceholder}`);
                expressionAttributeValues[valuePlaceholder] = value;
                expressionAttributeNames[placeholder] = field;
            }

            updateExpression += updateExpressions.join(", ");

            const res = await updateItemMethod({
                TableName: this.tableName,
                Key: {
                    accountId: primaryKey.accountId,
                    createdAt: primaryKey.createdAt,
                },
                UpdateExpression: updateExpression,
                ExpressionAttributeValues: expressionAttributeValues,
                ExpressionAttributeNames: expressionAttributeNames,
                ReturnValues: "ALL_NEW",
            });
            return res.Attributes as InterestAndFeesFreezeData;
        } catch (error) {
            logger.error(`Update ERROR ===> ${error}`);
            throw new OnmoError({
                name: "INTERNAL_SERVER_ERROR",
                message: `Error saving interest and fees account record for accountId ${primaryKey.accountId}`,
            });
        }
    }

    async getByAccountIdAndStatus(accountId: string, status: INTEREST_FEES_FREEZE_STATUS) {
        try {
            const queryTableMethodRes = await queryTableMethod({
                TableName: this.tableName,
                IndexName: "LSI_Status",
                KeyConditionExpression: "#accountId = :accountId AND #status = :status",
                ExpressionAttributeValues: {
                    ":accountId": accountId,
                    ":status": status,
                },
                ExpressionAttributeNames: {
                    "#accountId": "accountId",
                    "#status": "status",
                },
            });
            return queryTableMethodRes.Items as InterestAndFeesFreezeData[];
        } catch (error) {
            logger.error(`getByAccountIdAndStatus ERROR ===> ${error}`);
            throw new OnmoError({
                name: "INTERNAL_SERVER_ERROR",
                message: `Error fetching interest and fees account record for accountId ${accountId}`,
            });
        }
    }
}
