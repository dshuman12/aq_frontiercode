import {
    CASH_CHANNEL_ID,
    INTEREST_FEES_FREEZE_STATUS,
    STATEMENT_DISBURSEMENT_TRANSACTION_CHANNEL_ID,
    TRANSACTION_TYPES,
} from "@libs/constants";
import { IInterestAndFeeService, InterestAndFeesFreezeData } from "@libs/types/interestAndFees";
import { throwErrorIfAdapterResHaveError } from "./onmoErrorHandler";
import { Transaction, GetAllTransactionOutcome } from "@onmoapp/onmo-types";
import { InterestAndFeesFreezeRepository } from "./interestAndFeesFreezeRepository";
import { v4 as uuid } from "uuid";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { transactionMetaData } from "@libs/types/interestAndFees";
import { MambuClient } from "@onmoapp/mambu-adapter";
import { Logger } from "@onmoapp/onmo-logger";

export const logger = new Logger(
    {
        env: process.env.STAGE,
    },
    "INFO",
);

dayjs.extend(utc);
dayjs.extend(timezone);

function check1PDisbursementTransaction(transaction: Transaction) {
    return (
        transaction.onmoTransactionType === TRANSACTION_TYPES.DISBURSEMENT &&
        transaction.transactionChannelId === STATEMENT_DISBURSEMENT_TRANSACTION_CHANNEL_ID
    );
}

function checkCashDisbursementTransaction(transaction: Transaction) {
    return (
        !transaction.adjustmentTransactionKey &&
        transaction.onmoTransactionType === TRANSACTION_TYPES.DISBURSEMENT &&
        transaction.transactionChannelId === CASH_CHANNEL_ID
    );
}

function checkRepaymentTransaction(transaction: Transaction) {
    return (
        transaction.onmoTransactionType === TRANSACTION_TYPES.REPAYMENT ||
        transaction.onmoTransactionType.startsWith(TRANSACTION_TYPES.REPAYMENT + " - ")
    );
}

export const adjustTransactionFilter = (transaction: Transaction): boolean => {
    return (
        !transaction.adjustmentTransactionKey &&
        (transaction.onmoTransactionType.startsWith(TRANSACTION_TYPES.FEE_APPLIED) ||
            transaction.onmoTransactionType === TRANSACTION_TYPES.INTEREST_APPLIED ||
            check1PDisbursementTransaction(transaction) ||
            checkRepaymentTransaction(transaction))
    );
};

export class InterestAndFeesService implements IInterestAndFeeService {
    static instance: InterestAndFeesService | null;
    private interestAndFeesFreezeRepository: InterestAndFeesFreezeRepository | null;
    private historyItem: InterestAndFeesFreezeData | null;
    private transactions: Transaction[];
    private coreBankingClient: MambuClient | null;

    constructor(coreBankingClient: MambuClient, transactions: Transaction[]) {
        logger.removeContext();
        this.interestAndFeesFreezeRepository = InterestAndFeesFreezeRepository.getInstance();
        this.coreBankingClient = coreBankingClient;
        this.transactions = transactions;
    }
    checkHistoryItem() {
        if (!this.historyItem) {
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "history item not found",
            });
        }
    }
    setHistoryItem(historyItem: InterestAndFeesFreezeData) {
        this.historyItem = historyItem;
        logger.addContext({ accountId: historyItem.accountId });
    }

    async updateHistoryStatus(status: INTEREST_FEES_FREEZE_STATUS) {
        await this.interestAndFeesFreezeRepository.updateFieldsByPK(
            {
                accountId: this.historyItem.accountId,
                createdAt: this.historyItem.createdAt,
            },
            {
                status: status,
            },
        );
    }
    static async fetchAllApprovedTransactions(
        accountEncodedKey: string,
        {
            startDate,
            endDate,
        }: {
            startDate: string;
            endDate: string;
        },
        coreBankingClient: MambuClient,
    ) {
        let offset = 0,
            limit = 50,
            totalTransactionsFetched = 0,
            allTransactions: Transaction[] = [],
            transactionData: GetAllTransactionOutcome;

        let attempts = 0;
        do {
            transactionData = await coreBankingClient.getAllApprovedTransactions(
                accountEncodedKey,
                {
                    startDate,
                    endDate,
                },
                {
                    offset,
                    limit,
                },
            );

            throwErrorIfAdapterResHaveError(transactionData, {
                message: "Failed to get all approved transactions",
            });

            allTransactions = [...allTransactions, ...transactionData?.data?.transactions];

            if (transactionData?.data?.transactions.length === 0) {
                logger.warn({
                    description: "No transaction found",
                    accountEncodedKey,
                    startDate,
                    endDate,
                    offset,
                    limit,
                });
                // We do not go to the next iteration if we have no transactions while we did expect some
                // we try again to fetch the transactions from core banking
                attempts = attempts + 1;
            } else {
                offset += Math.min(limit, transactionData?.data?.transactions.length);
            }
            totalTransactionsFetched = allTransactions.length;

            logger.info({
                fetchedTransactions: transactionData.data.transactions.length,
                totalTransactions: transactionData?.data?.totalTransactionsCount,
            });
        } while (
            totalTransactionsFetched < transactionData?.data?.totalTransactionsCount &&
            attempts < 3
        );

        return allTransactions;
    }

    private checkCashDisbursementTransactionsExists() {
        logger.info(`totalTransactionFound := ${this.transactions?.length}`);
        const existFlag = this.transactions?.some(checkCashDisbursementTransaction);
        logger.info(`cashDisbursementTransactionExistFlag ${existFlag}`);

        if (existFlag) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "some cash disbursement transaction found between dates",
            });
        }
    }

    async validationCheck(currentBalance: number) {
        logger.info("Check cash disbursement transaction exist or not");
        this.checkCashDisbursementTransactionsExists();
        logger.info("No cash disbursement transaction found : Moving ahead...");

        let balance = currentBalance;
        const filteredTransactions = this.transactions?.filter(adjustTransactionFilter) || [];
        logger.info(`current balance : ${balance}`);

        // adjustment part
        filteredTransactions.forEach((tn) => {
            if (checkRepaymentTransaction(tn)) {
                balance += tn.destinationAmount * -1;
            } else {
                balance -= tn.destinationAmount;
            }
        });
        logger.info(`expected balance after adjustment : ${balance}`);

        // recreation part
        filteredTransactions.reverse().forEach((tn) => {
            if (checkRepaymentTransaction(tn)) {
                balance -= tn.destinationAmount * -1;
            } else if (check1PDisbursementTransaction(tn)) {
                balance += tn.destinationAmount;
            }

            if (balance < 0) {
                throw new OnmoError({
                    name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                    message:
                        "The account is not in a state where we can proceed with the interest and fee freeze process.",
                });
            }
        });
    }

    private async adjustTransactionsOneByOne(transactions: Transaction[]) {
        let adjustedTransactions = [],
            failedToAdjustTransactions = [];

        // adjust transaction one by one
        for (let i = 0; i < transactions?.length; i++) {
            const transaction = transactions[i];

            try {
                logger.info({
                    message: "Before adjusting Transaction",
                    transactionId: transaction.coreBankingTransactionId,
                });

                const adjustedTransactionRes =
                    await this.coreBankingClient.adjustTransactionByTransactionId(
                        transaction.coreBankingTransactionId,
                        `Transaction adjusted in interest fee freeze process due to ${this.historyItem.reason}`,
                    );

                logger.debug({ adjustedTransactionRes });

                throwErrorIfAdapterResHaveError(adjustedTransactionRes, {
                    message: "Failed to adjust transaction",
                });

                const adjustedTransactionData = adjustedTransactionRes.data;
                adjustedTransactions.push(adjustedTransactionData);

                logger.info({
                    message: "After adjusting Transaction : Adjusted successfully",
                    transactionId: adjustedTransactionData.coreBankingTransactionId,
                });
            } catch (err) {
                logger.error({
                    message: "Error while adjusting Transaction",
                    transactionInfo: transaction,
                    error: err,
                });
                failedToAdjustTransactions = transactions
                    .slice(i)
                    .map((transaction) => transaction);
                break;
            }
        }

        return {
            adjustedTransactions: adjustedTransactions,
            failedToAdjustTransactions: failedToAdjustTransactions,
        };
    }

    private verifyTnAdjustmentFailure(transaction: Transaction): Transaction | null {
        const alreadyAdjustedTransaction = this.transactions.find(
            (tn) => tn.coreBankingTransactionId === transaction.coreBankingTransactionId,
        );

        if (alreadyAdjustedTransaction && alreadyAdjustedTransaction.adjustmentTransactionKey) {
            logger.info(
                `Adjusted transaction found ${alreadyAdjustedTransaction.coreBankingTransactionId} with adjustmentTransactionKey ${alreadyAdjustedTransaction.adjustmentTransactionKey}`,
            );

            return alreadyAdjustedTransaction;
        }
        return null;
    }

    private wasTnCreatedInPreviousRun(transaction: Transaction): boolean {
        const alreadyExistTransaction = this.transactions.find(
            (tn) =>
                !tn.adjustmentTransactionKey &&
                (transaction.transactionId === tn.transactionId ||
                    (transaction.onmoTransactionType === tn.onmoTransactionType &&
                        transaction.destinationAmount === tn.destinationAmount &&
                        transaction.currencyCode === tn.currencyCode &&
                        transaction.valueDate === tn.valueDate)),
        );

        if (alreadyExistTransaction) {
            logger.info({ alreadyExistTransaction });
            logger.info(`Transaction is already exist!`);
            return true;
        }
        return false;
    }

    async adjustTransactions() {
        let adjustedTransactions: Transaction[] = [
            ...(this.historyItem.adjustedTransactions || []),
        ];
        let failedToAdjustTransactions: Transaction[] = [];
        let adjustmentVerified: boolean = true;

        this.checkHistoryItem();

        try {
            logger.info("verifying transaction adjustment failure in previous run ...");
            const adjustmentFailedTransaction = this.historyItem?.failedToAdjustTransactions?.[0];
            logger.info({ adjustmentFailedTransaction });

            if (adjustmentFailedTransaction) {
                logger.info("adjustment failed transaction found in previous run");
                const alreadyAdjustedTransaction = this.verifyTnAdjustmentFailure(
                    adjustmentFailedTransaction,
                );
                logger.info({ alreadyAdjustedTransaction });

                if (alreadyAdjustedTransaction) {
                    logger.info("transaction was already adjusted in previous run!");
                    adjustedTransactions.push(alreadyAdjustedTransaction);
                }
            }
            logger.info("Transaction adjustment failure verification DONE");

            logger.info(`totalTransactionFound := ${this.transactions?.length}`);

            const filteredTransactions = this.transactions?.filter(adjustTransactionFilter) || [];

            logger.info({
                filteredTransactions: filteredTransactions.map((t) => t.coreBankingTransactionId),
            });
            filteredTransactions.sort((t1: Transaction, t2: Transaction) => {
                return +t2.coreBankingTransactionId - +t1.coreBankingTransactionId;
            });
            logger.info(`After filter, totalTransactionToAdjust := ${filteredTransactions.length}`);
            logger.info({
                filteredTransactions: filteredTransactions.map((t) => t.coreBankingTransactionId),
            });

            const {
                adjustedTransactions: _adjustedTransactions,
                failedToAdjustTransactions: _failedToAdjustTransactions,
            } = await this.adjustTransactionsOneByOne(filteredTransactions);

            adjustedTransactions.push(..._adjustedTransactions);
            failedToAdjustTransactions.push(..._failedToAdjustTransactions);

            adjustedTransactions.sort((t1: Transaction, t2: Transaction) => {
                return +t2.coreBankingTransactionId - +t1.coreBankingTransactionId;
            });

            if (filteredTransactions.length === 0) {
                logger.info("No transaction adjusted : verification skipped");
            }

            // failed to adjust some transaction
            if (failedToAdjustTransactions.length !== 0) {
                logger.error({
                    message: "Adjustment Process : failed to adjust some transactions",
                    failedToAdjustTransactions: failedToAdjustTransactions.map(
                        (t) => t.coreBankingTransactionId,
                    ),
                });

                adjustmentVerified = false;
                throw new OnmoError({
                    name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                    message: "Adjustment Process : failed to adjust some transactions",
                });
            }

            /*  WE DON'T NEED VERIFICATION AT THIS MOMENT, DON'T REMOVE THIS CODE.
            // all adjusted but verify as well
            if (adjustedTransactions.length !== 0 && failedToAdjustTransactions.length === 0) {
                logger.info("verifying adjustment successful or not");

                const newTransactions = await this.fetchAllApprovedTransactions(
                    accountEncodedKey,
                    adjustTransactionsBetweenDatesInput,
                );

                const filteredNewTransactions =
                    newTransactions?.filter(adjustTransactionFilter) || [];

                logger.info({
                    filteredNewTransactions: filteredNewTransactions.map(
                        (t) => t.coreBankingTransactionId,
                    ),
                });

                if (filteredNewTransactions.length === 0) {
                    adjustmentVerified = true;
                    logger.info({
                        message: "Adjustment Process : adjustment verification done",
                        adjustedTransactions: adjustedTransactions.map(
                            (t) => t.coreBankingTransactionId,
                        ),
                    });
                } else {
                    adjustmentVerified = false;
                    logger.error("Adjustment Process : adjustment verification failed");
                    throw new OnmoError({
                        message: "Adjustment verification failed",
                        name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                    });
                }
            }
            */

            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                {
                    accountId: this.historyItem.accountId,
                    createdAt: this.historyItem.createdAt,
                },
                {
                    status: INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_COMPLETED,
                    adjustedTransactions: adjustedTransactions,
                    failedToAdjustTransactions: failedToAdjustTransactions,
                    adjustmentVerified: adjustmentVerified,
                },
            );
            logger.info("History updated with ADJUSTMENT_PROCESS_COMPLETED");
        } catch (err) {
            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                {
                    accountId: this.historyItem.accountId,
                    createdAt: this.historyItem.createdAt,
                },
                {
                    status: INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_FAILED,
                    adjustedTransactions: adjustedTransactions,
                    failedToAdjustTransactions: failedToAdjustTransactions,
                    adjustmentVerified: adjustmentVerified,
                },
            );
            logger.info("History updated with ADJUSTMENT_PROCESS_FAILED");

            throw err;
        }
    }

    async updateZeroInterestRateToAccount(accountId: string, valueDate: string) {
        this.checkHistoryItem();
        try {
            valueDate = dayjs
                .tz(valueDate, "Europe/London")
                .utc()
                .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

            logger.addContext({ accountId });
            logger.info("starting to update interest rate zero");

            const updateInterestRes =
                await this.coreBankingClient.updateInterestRateToCreditAccount(accountId, {
                    interestRate: 0,
                    valueDate: valueDate,
                    notes: `Interest Frozen due to ${this.historyItem.reason} Process`,
                    idempotencyKey: uuid(),
                });

            logger.info(updateInterestRes);

            throwErrorIfAdapterResHaveError(updateInterestRes, {
                message: "Error while updating interest rate zero to account",
            });

            logger.info("interestRate zero updated to account successful!");

            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                { accountId: this.historyItem.accountId, createdAt: this.historyItem.createdAt },
                {
                    updateZeroInterestDate: valueDate,
                    status: INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_COMPLETED,
                },
            );
            logger.info("History updated to UPDATE_ZERO_INTEREST_COMPLETED");
            return updateInterestRes.data;
        } catch (err) {
            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                { accountId: this.historyItem.accountId, createdAt: this.historyItem.createdAt },
                {
                    updateZeroInterestDate: valueDate,
                    status: INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_FAILED,
                },
            );
            throw err;
        }
    }

    async updateZeroInterestOnRateChangeDate(accountId: string) {
        try {
            this.checkHistoryItem();

            logger.info(
                "Starting to update the interest rate to zero on the date when the interest rate was changed",
            );

            const interestRateChangeTns =
                this.transactions?.filter(
                    (tn) => tn.onmoTransactionType === TRANSACTION_TYPES.INTEREST_RATE_CHANGED,
                ) || [];

            const interestRateChangeTnsDate = interestRateChangeTns?.map((tn) =>
                dayjs.tz(tn.valueDate, "Europe/London").format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            );

            const uniqueInterestRateChangeTnsDate = Array.from(
                new Set(interestRateChangeTnsDate),
            )?.reverse();

            if (uniqueInterestRateChangeTnsDate?.length > 0) {
                logger.info("INTEREST_RATE_CHANGED transaction found between dates");
                logger.info({ uniqueInterestRateChangeTnsDate });

                for (let i = 0; i < uniqueInterestRateChangeTnsDate?.length; i++) {
                    const interestChangeDate = uniqueInterestRateChangeTnsDate[i];

                    logger.info(`updating interest rate to zero on date : ${interestChangeDate}`);
                    const updateInterestRes =
                        await this.coreBankingClient.updateInterestRateToCreditAccount(accountId, {
                            interestRate: 0,
                            valueDate: interestChangeDate,
                            notes: `Interest Frozen due to ${this.historyItem.reason} Process`,
                            idempotencyKey: uuid(),
                        });

                    logger.info(updateInterestRes);
                    throwErrorIfAdapterResHaveError(updateInterestRes, {
                        message: "Error while updating interest rate zero to account",
                    });
                }
            } else {
                logger.info("No INTEREST_RATE_CHANGED transaction between dates");
            }

            logger.info("updated interestRate zero to the account when interest rate was changed");
        } catch (error) {
            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                { accountId: this.historyItem.accountId, createdAt: this.historyItem.createdAt },
                {
                    status: INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_FAILED,
                },
            );
            throw error;
        }
    }

    async applyAccruedInterest(accountId: string, applyDate: string) {
        let accruedInterestStatus = "";
        this.checkHistoryItem();

        try {
            logger.addContext({ accountId });
            logger.info("starting to apply accrued interest to account");

            const applyAccruedInterestRes =
                await this.coreBankingClient.applyInterestToCreditAccount(accountId, {
                    interestApplicationDate: applyDate,
                    notes: `Accrued interest applied in interest fee freeze process due to ${this.historyItem.reason}`,
                });

            logger.info({ applyAccruedInterestRes });

            throwErrorIfAdapterResHaveError(applyAccruedInterestRes, {
                message: applyAccruedInterestRes?.error?.errorMessage,
            });

            accruedInterestStatus = "accrued_interest_applied";
            logger.info("accrued interest applied successfully");
        } catch (applyAccruedInterestErr) {
            if (applyAccruedInterestErr?.message?.includes("ACCOUNT_HAS_NO_ACCRUED_INTEREST")) {
                logger.info("accrued interest skipped");
                accruedInterestStatus = "accrued_interest_skipped";
            } else {
                await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                    {
                        accountId: this.historyItem.accountId,
                        createdAt: this.historyItem.createdAt,
                    },
                    {
                        status: INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_FAILED,
                        accruedInterestStatus: accruedInterestStatus,
                        accruedInterestDate: applyDate,
                    },
                );
                logger.info("History status updated to ACCRUED_INTEREST_FAILED");
                throw applyAccruedInterestErr;
            }
        }

        await this.interestAndFeesFreezeRepository.updateFieldsByPK(
            {
                accountId: this.historyItem.accountId,
                createdAt: this.historyItem.createdAt,
            },
            {
                status: INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_COMPLETED,
                accruedInterestStatus: accruedInterestStatus,
                accruedInterestDate: applyDate,
            },
        );
        logger.info("History status updated to ACCRUED_INTEREST_COMPLETED");
    }

    private async createRepaymentTransaction(
        accountId: string,
        transaction: Transaction & {
            recreate_status?: string;
            recreatedTransactionId?: string;
        },
    ) {
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : REPAYMENT START`,
        );
        let repaymentTypes;
        let transactionMetaData: transactionMetaData;

        if (transaction.onmoTransactionType === TRANSACTION_TYPES.REPAYMENT_ACQUIRED) {
            repaymentTypes = "Acquired";
            transactionMetaData = {
                serviceProvider: "Acquired",
                debitCardPaymentId: transaction.transactionId,
            };
        } else if (transaction.onmoTransactionType === TRANSACTION_TYPES.REPAYMENT_GO_CARDLESS) {
            repaymentTypes = "Gocardless";
            transactionMetaData = {
                serviceProvider: "Gocardless",
                directDebitPaymentId: transaction.transactionId,
            };
        } else if (transaction.onmoTransactionType === TRANSACTION_TYPES.REPAYMENT_STRIPE_CARD) {
            repaymentTypes = "Stripe";
            transactionMetaData = {
                serviceProvider: "Stripe",
                debitCardPaymentId: transaction.transactionId,
            };
        } else if (transaction.onmoTransactionType === TRANSACTION_TYPES.REPAYMENT_STRIPE_DD) {
            repaymentTypes = "Stripe";
            transactionMetaData = {
                serviceProvider: "Stripe",
                directDebitPaymentId: transaction.transactionId,
            };
        }

        logger.info({ transactionMetaData });

        const makeRepaymentRes = await this.coreBankingClient.makeRepaymentToCreditAccount(
            accountId,
            {
                amount: transaction.destinationAmount * -1,
                bookingDate: transaction.valueDate,
                valueDate: transaction.valueDate,
                externalId: `FreezeIntFee-${transaction.coreBankingTransactionId}-${new Date(this.historyItem.createdAt).getTime()}`,
                transactionChannelId: transaction.transactionChannelId,
                notes: transaction.notes || "",
                ...(repaymentTypes && { transactionMetaData: transactionMetaData }),
            },
        );

        logger.debug({ makeRepaymentRes });

        if (makeRepaymentRes.error) {
            logger.error({ recreateError: makeRepaymentRes.error });
            logger.info(
                `Recreating Transaction ${transaction.coreBankingTransactionId} : REPAYMENT FAILED`,
            );
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Error while recreating transaction",
            });
        }
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : REPAYMENT SUCCESS`,
        );
        transaction.recreate_status = "DONE";
        transaction.recreatedTransactionId = makeRepaymentRes.data.coreBankingTransactionId;

        return {
            transactionId: transaction.coreBankingTransactionId,
            transactionType: TRANSACTION_TYPES.REPAYMENT,
        };
    }

    private async createDisbursementTransaction(
        accountId: string,
        transaction: Transaction & {
            recreate_status?: string;
            recreatedTransactionId?: string;
        },
    ) {
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : DISBURSEMENT START`,
        );

        const makeDisbursementRes = await this.coreBankingClient.makeDisbursementToCreditAccount(
            accountId,
            {
                amount: transaction.destinationAmount,
                bookingDate: transaction.valueDate,
                valueDate: transaction.valueDate,
                externalId: `FreezeIntFee-${transaction.coreBankingTransactionId}-${new Date(this.historyItem.createdAt).getTime()}`,
                transactionChannelId: transaction.transactionChannelId,
                notes: transaction.notes || "",
            },
        );
        logger.debug({ makeDisbursementRes });

        if (makeDisbursementRes.error) {
            logger.info({ recreateError: makeDisbursementRes.error });
            logger.info(
                `Recreating Transaction ${transaction.coreBankingTransactionId} : DISBURSEMENT FAILED`,
            );

            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Error while recreating transaction",
            });
        }
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : DISBURSEMENT SUCCESS`,
        );
        transaction.recreate_status = "DONE";
        transaction.recreatedTransactionId = makeDisbursementRes.data.coreBankingTransactionId;

        return {
            transactionId: transaction.coreBankingTransactionId,
            transactionType: TRANSACTION_TYPES.DISBURSEMENT,
        };
    }

    private async createFeeTransaction(
        accountId: string,
        transaction: Transaction & {
            recreate_status?: string;
        },
    ) {
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY FEE START`,
        );

        const applyFeeInput = {
            bookingDate: transaction.valueDate,
            valueDate: transaction.valueDate,
            externalId: `FreezeIntFee-${transaction.coreBankingTransactionId}-${new Date(this.historyItem.createdAt).getTime()}`,
            notes: transaction.notes || "",
            feeKey: transaction.fees?.[0]?.predefinedFeeKey,
        };

        let applyFeeRes = await this.coreBankingClient.applyFeeToCreditAccount(accountId, {
            ...applyFeeInput,
            amount: transaction.destinationAmount,
        });
        logger.info({ applyFeeRes });

        if (applyFeeRes.error) {
            if (
                applyFeeRes?.error?.errorMessage?.includes("FEE_AMOUNT_ALREADY_DEFINED_IN_PRODUCT")
            ) {
                logger.info("Retrying apply fee without amount...");
                applyFeeRes = await this.coreBankingClient.applyFeeToCreditAccount(
                    accountId,
                    applyFeeInput,
                );
            }
        }

        if (applyFeeRes.error) {
            logger.info(
                `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY FAILED FAILED`,
            );
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Error while recreating transaction",
            });
        }

        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY FEE SUCCESS`,
        );

        transaction.recreate_status = "DONE";

        return {
            transactionId: transaction.coreBankingTransactionId,
            transactionType: TRANSACTION_TYPES.FEE_APPLIED,
            success: true,
        };
    }
    private async createInterestTransaction(
        accountId: string,
        transaction: Transaction & {
            recreate_status?: string;
        },
    ) {
        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY INTEREST START`,
        );

        const interestApplyDate = dayjs
            .tz(transaction.valueDate, "Europe/London")
            .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

        const applyInterestRes = await this.coreBankingClient.applyInterestToCreditAccount(
            accountId,
            {
                interestApplicationDate: interestApplyDate,
                notes: transaction.notes || "",
            },
        );
        logger.info({ applyInterestRes });

        if (applyInterestRes.error) {
            logger.info(
                `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY INTEREST FAILED`,
            );

            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Error while recreating transaction",
            });
        }

        logger.info(
            `Recreating Transaction ${transaction.coreBankingTransactionId} : APPLY INTEREST SUCCESS`,
        );
        transaction.recreate_status = "DONE";

        return {
            transactionId: transaction.coreBankingTransactionId,
            transactionType: TRANSACTION_TYPES.INTEREST_APPLIED,
        };
    }

    async recreateTransaction(accountId: string, rollbackFlag: boolean = false) {
        const freezeAccountItem =
            await this.interestAndFeesFreezeRepository.getByAccountId(accountId);

        if (!freezeAccountItem) {
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "freeze account item not found",
            });
        }

        logger.addContext({ accountId });
        logger.info("Transaction Recreate Process : Started");

        const transactions = freezeAccountItem.adjustedTransactions || [];

        const transactionsToRecreate = transactions.filter((transaction) => {
            return (
                transaction.recreate_status != "DONE" &&
                (rollbackFlag ||
                    checkRepaymentTransaction(transaction) ||
                    check1PDisbursementTransaction(transaction))
            );
        });

        logger.info(`Total transactions to recreate := ${transactionsToRecreate.length}`);
        logger.info({
            transactionsToRecreate: transactionsToRecreate
                .map((t) => t.coreBankingTransactionId)
                .reverse(),
        });

        const recreation_result: any = [];
        let recreationProcessFlag = true;

        // Transaction recreate failure verification
        const failedToRecreateTn = transactionsToRecreate.pop();

        if (failedToRecreateTn) {
            if (
                failedToRecreateTn?.recreate_status === "PENDING" &&
                this.wasTnCreatedInPreviousRun(failedToRecreateTn)
            ) {
                logger.info("Make transaction recreate status : DONE");
                failedToRecreateTn.recreate_status = "DONE" as string;
                logger.info({ updatedDoneStatus: failedToRecreateTn });
            } else {
                transactionsToRecreate.push(failedToRecreateTn);
            }
        }

        for (let i = transactionsToRecreate?.length - 1; i >= 0; i--) {
            const transaction = transactionsToRecreate[i];

            try {
                if (check1PDisbursementTransaction(transaction)) {
                    const result = await this.createDisbursementTransaction(accountId, transaction);
                    recreation_result.push(result);
                } else if (checkRepaymentTransaction(transaction)) {
                    const result = await this.createRepaymentTransaction(accountId, transaction);
                    recreation_result.push(result);
                } else if (transaction.onmoTransactionType === TRANSACTION_TYPES.INTEREST_APPLIED) {
                    const result = await this.createInterestTransaction(accountId, transaction);
                    recreation_result.push(result);
                } else if (
                    transaction.onmoTransactionType.startsWith(TRANSACTION_TYPES.FEE_APPLIED)
                ) {
                    const result = await this.createFeeTransaction(accountId, transaction);
                    recreation_result.push(result);
                }
            } catch (err) {
                const failedTransactionToRecreate = transactionsToRecreate.slice(0, i + 1);
                logger.info({
                    failedTransactionToRecreate: failedTransactionToRecreate.map(
                        (tn) => tn.coreBankingTransactionId,
                    ),
                });
                failedTransactionToRecreate.forEach((transaction) => {
                    transaction.recreate_status = "PENDING";
                });
                recreationProcessFlag = false;
                break;
            }
        }
        logger.info("Transaction Recreate Process : Completed");
        logger.info({ recreation_result });

        if (!recreationProcessFlag) {
            logger.error({
                message: "Transaction Recreate Process : failed",
            });

            const processStatus = rollbackFlag
                ? INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_ROLLBACK_FAILED
                : INTEREST_FEES_FREEZE_STATUS.FAILED_TO_RECREATE_SOME_TRANSACTION;

            await this.interestAndFeesFreezeRepository.update({
                ...freezeAccountItem,
                status: processStatus,
            });
            logger.info(`History status updated to ${processStatus}`);

            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "error occurred while re-creating transactions",
            });
        }

        const processStatus = rollbackFlag
            ? INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_ROLLBACK_DONE
            : INTEREST_FEES_FREEZE_STATUS.RECREATED_ALL_TRANSACTION_COMPLETED;

        await this.interestAndFeesFreezeRepository.update({
            ...freezeAccountItem,
            status: processStatus,
        });
        logger.info(`History status updated to ${processStatus}`);
        logger.info("Transaction Recreate Process : Successful");
    }

    async rollbackFreezeProcess(rollbackData: { accountEncodedKey: string; processCode: number }) {
        const { accountEncodedKey, processCode } = rollbackData;

        logger.info(`Rollback Process : processCode ${processCode}`);

        await this.interestAndFeesFreezeRepository.updateFieldsByPK(
            {
                accountId: this.historyItem.accountId,
                createdAt: this.historyItem.createdAt,
            },
            {
                status: INTEREST_FEES_FREEZE_STATUS.ROLLBACK_STARTED,
            },
        );

        // Rollback : Adjust all recreated transaction
        if (processCode >= 4) {
            logger.info("Rollback Process : Starting adjusting recreated transaction...");

            const transactions = this.historyItem?.adjustedTransactions?.filter((tn) => {
                return tn.recreate_status === "DONE";
            });

            const transactionsToAdjust = await Promise.all(
                transactions.map(async (transaction) => {
                    const transactionRes =
                        await this.coreBankingClient.getTransactionByCoreBankingTransactionId(
                            transaction.recreatedTransactionId,
                        );

                    return transactionRes.data;
                }),
            );

            logger.info(`Total recreate transaction to adjust : ${transactionsToAdjust.length}`);

            // adjust all of recreated transaction
            if (transactionsToAdjust.length > 0) {
                const { adjustedTransactions, failedToAdjustTransactions } =
                    await this.adjustTransactionsOneByOne(transactionsToAdjust);

                logger.info({ adjustedTransactions });
                logger.info({ failedToAdjustTransactions });

                const adjustedTransactionIds = adjustedTransactions.map(
                    (Tn) => Tn.coreBankingTransactionId,
                );
                transactions.forEach((transaction) => {
                    if (adjustedTransactionIds.includes(transaction.recreatedTransactionId)) {
                        transaction.recreate_status = "PENDING";
                        transaction.recreatedTransactionId = null;
                    }
                });

                if (failedToAdjustTransactions.length > 0) {
                    logger.error("Rollback Process : failed to adjust transaction");

                    await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                        {
                            accountId: this.historyItem.accountId,
                            createdAt: this.historyItem.createdAt,
                        },
                        {
                            adjustedTransactions: this.historyItem?.adjustedTransactions,
                            status: INTEREST_FEES_FREEZE_STATUS.TRANSACTION_RECREATION_ROLLBACK_FAILED,
                        },
                    );
                    throw new OnmoError({
                        name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                        message: "failed to adjust recreated transaction",
                    });
                }
            } else {
                logger.info("Rollback Process : No any recreate transaction to adjust");
            }

            await this.interestAndFeesFreezeRepository.updateFieldsByPK(
                {
                    accountId: this.historyItem.accountId,
                    createdAt: this.historyItem.createdAt,
                },
                {
                    ...(transactionsToAdjust.length > 0 && {
                        adjustedTransactions: this.historyItem?.adjustedTransactions,
                    }),
                    status: INTEREST_FEES_FREEZE_STATUS.TRANSACTION_RECREATION_ROLLBACK_DONE,
                },
            );
            logger.info("Rollback Process : Completed adjustment of recreate transaction");
        }

        // Rollback : update interest rate to original one
        if (processCode >= 3.5) {
            logger.info("Rollback Process : Starting updating interest rate to original one...");
            const updateInterestRes =
                await this.coreBankingClient.updateInterestRateToCreditAccount(
                    this.historyItem.accountId,
                    {
                        interestRate: this.historyItem.originalInterestRate,
                        valueDate: this.historyItem.updateZeroInterestDate,
                        notes: "updating interest rate to original due to interest fee freeze rollback process",
                        idempotencyKey: uuid(),
                    },
                );
            logger.info(updateInterestRes);

            if (updateInterestRes.error) {
                await this.updateHistoryStatus(
                    INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_ROLLBACK_FAILED,
                );
                throw new OnmoError({
                    name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                    message: "update interest rate zero rollback failed!",
                });
            }

            await this.updateHistoryStatus(
                INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_ROLLBACK_DONE,
            );
            logger.info("Rollback Process : Completed update interest rate to original one");
        }

        // Rollback accrued interest transaction
        if (processCode >= 3) {
            const accruedInterestDate = dayjs(this.historyItem.accruedInterestDate)
                .tz("Europe/London")
                .format("YYYY-MM-DD");

            if (this.historyItem.accruedInterestStatus === "accrued_interest_applied") {
                logger.info("Rollback Process : Starting to adjust accrued interest");
                const transactions = await InterestAndFeesService.fetchAllApprovedTransactions(
                    accountEncodedKey,
                    {
                        startDate: accruedInterestDate,
                        endDate: accruedInterestDate,
                    },
                    this.coreBankingClient,
                );

                const filteredTransactions = transactions?.filter(
                    (tn) =>
                        !tn.adjustmentTransactionKey &&
                        tn.onmoTransactionType === TRANSACTION_TYPES.INTEREST_APPLIED,
                );

                const interestTransaction = filteredTransactions?.[0];

                if (interestTransaction) {
                    const adjustedInterestTnRes =
                        await this.coreBankingClient.adjustTransactionByTransactionId(
                            interestTransaction.coreBankingTransactionId,
                        );

                    if (adjustedInterestTnRes.error) {
                        await this.updateHistoryStatus(
                            INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_FAILED,
                        );
                        throw new OnmoError({
                            name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                            message: "apply accrued interest rollback failed!",
                        });
                    }

                    await this.updateHistoryStatus(
                        INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_DONE,
                    );
                } else {
                    logger.info("Rollback Process : Apply accrued interest rollback failed!");
                    await this.updateHistoryStatus(
                        INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_FAILED,
                    );
                    throw new OnmoError({
                        name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                        message:
                            "failed to find applied accrued interest transaction in rollback process",
                    });
                }
                logger.info("Rollback Process : Completed adjustment of accrued interest");
            }
        }

        // Rollback : Recreate all adjusted transaction
        if (processCode >= 2) {
            logger.info("Rollback Process : Starting to recreate all of the adjusted transaction");
            await this.recreateTransaction(this.historyItem.accountId, true);
            logger.info("Rollback Process : Completed recreation of adjusted transaction");
        }

        await this.updateHistoryStatus(INTEREST_FEES_FREEZE_STATUS.ROLLBACK_DONE);
        logger.info("Rollback Process : history status updated to ROLLBACK_DONE");
    }
}
