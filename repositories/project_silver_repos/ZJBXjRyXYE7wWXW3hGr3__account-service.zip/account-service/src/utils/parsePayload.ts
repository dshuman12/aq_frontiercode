import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";

/**
 * Parses the payload of an API Gateway event.
 *
 * @param payload - The payload to parse. It can be a string or an object.
 * @returns The parsed payload as an object.
 * @throws {OnmoError} If the payload cannot be parsed, an `OnmoError` is thrown with the `INPUT_VALIDATION_ERROR` name and a message indicating the parsing failure.
 */
export function parseAPIGateWayEventBody(payload: string | Object): Object {
    try {
        if (typeof payload === "string") {
            return JSON.parse(payload);
        } else if (typeof payload === "object") {
            return payload;
        }
        throw Error(`Payload type ${typeof payload} is unexpected, should be object or string`);
    } catch (error) {
        throw new OnmoError({
            name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
            message: "Unable to parse event body",
            cause: error?.message || error,
        });
    }
}
