import { describe, test, expect, vi, beforeEach } from "vitest";

vi.mock("@utils/oidc-authorization", () => ({
    checkAccess: vi.fn(),
}));

import { checkAccess } from "@utils/oidc-authorization";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";

import { guardAccountAccess } from "@utils/authGuard";

const makeContext = () => ({ authorizer: {}, domainName: "internal" }) as any;

describe("guardAccountAccess", () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    test("returns { allow: true } when checkAccess resolves", async () => {
        vi.mocked(checkAccess).mockResolvedValue();

        const result = await guardAccountAccess(makeContext(), "ACC-001");

        expect(result).toEqual({ allow: true });
    });

    test("returns 401 response when checkAccess throws NOT_AUTHORIZED OnmoError", async () => {
        vi.mocked(checkAccess).mockRejectedValue(
            new OnmoError({ name: "NOT_AUTHORIZED", message: "not you" } as any),
        );

        const result = await guardAccountAccess(makeContext(), "ACC-001");

        expect(result.allow).toBe(false);
        if (result.allow) throw new Error("unreachable");
        expect(result.response.statusCode).toBe(401);
        expect(result.response.body).toEqual({ message: "not you" });
    });

    test("returns 404 response when checkAccess throws NOT_FOUND OnmoError", async () => {
        vi.mocked(checkAccess).mockRejectedValue(
            new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "user missing",
            }),
        );

        const result = await guardAccountAccess(makeContext(), "ACC-001");

        expect(result.allow).toBe(false);
        if (result.allow) throw new Error("unreachable");
        expect(result.response.statusCode).toBe(404);
        expect(result.response.body).toEqual({ message: "user missing" });
    });

    test("re-throws non-OnmoError so middleware handles it", async () => {
        vi.mocked(checkAccess).mockRejectedValue(new Error("ddb down"));

        await expect(guardAccountAccess(makeContext(), "ACC-001")).rejects.toThrow("ddb down");
    });
});
