import { randomBytes } from "crypto";

export const getCurrentTimestampInSeconds = () => Math.floor(Date.now() / 1000);
export const generateJti = () => randomBytes(16).toString("hex");
