import {
    NotificationStatus,
    PromotionRecord,
    PromotionStatus,
    PromotionType,
} from "@libs/types/promotion";

export const makePromotionRecord = (overrides: Partial<PromotionRecord> = {}): PromotionRecord => ({
    id: "id-x",
    promotion_id: "HONEYMOON#1700000000",
    onmouuid: "11111111-1111-1111-1111-111111111111",
    promotion_type: PromotionType.HONEYMOON,
    credit_account_id: "ACC-001",
    promotional_interest_rate: 0,
    original_interest_rate: 27.5,
    original_apr: 29.9,
    status: PromotionStatus.ACTIVE,
    notification_status: NotificationStatus.PENDING,
    start_date: 1_700_000_000,
    end_date: 1_703_000_000,
    applied_at: null,
    cancelled_at: null,
    notification_sent_at: null,
    cancelled_reason: null,
    version: 1,
    created_at: 1_700_000_000,
    updated_at: 1_700_000_000,
    ...overrides,
});
