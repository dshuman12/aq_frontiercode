import { deleteItemMethod, putItemMethod, updateItemMethod } from "@onmoapp/onmo-dynamodb";
import {
    CreditUserCredentials,
    deleteTestCreditCustomerAccount,
    setUpTestCreditCustomerAccount,
} from "./testUtils";

const clmTable = process.env.CLM_TABLE as string;

export const setupTestCreditAccountForCLMPreferences = async (createCLMRecord: boolean = true) => {
    const userCreds = await setUpTestCreditCustomerAccount();

    if (createCLMRecord) await setupCLMRecordInDynamoDBTable(userCreds);

    return userCreds;
};

export const deleteTestCreditAccountForCLMPreferences = async (
    userCreds: CreditUserCredentials,
) => {
    try {
        await deleteTestCreditCustomerAccount(userCreds);
        await deleteCLMRecordFromDynamoDBTable(userCreds);
    } catch (error) {
        console.error(
            `Failed to delete CLM record for onmouuid ${userCreds.coreBankingCustomerId}: ${error}`,
        );
    }
};

export const setupCLMRecordInDynamoDBTable = async (userCreds: CreditUserCredentials) => {
    try {
        const clmRecord = {
            onmouuid: userCreds.customerId,
            auto_apply: true,
            date_taken: 20250521,
            effective_to: 20250528,
            loan_account_id: userCreds.creditAccountId,
            notified_date: 20250521,
            opt_out: false,
            status: "taken",
            validated: null,
        };

        const response = await putItemMethod({
            TableName: clmTable,
            Item: clmRecord,
        });

        return response?.Attributes;
    } catch (error) {
        throw new Error(
            `Failed to set up CLM record in DynamoDB for onmouuid ${userCreds.coreBankingCustomerId}: ${error}`,
        );
    }
};

export const deleteCLMRecordFromDynamoDBTable = async (userCreds: CreditUserCredentials) => {
    try {
        const response = await deleteItemMethod({
            TableName: clmTable,
            Key: {
                onmouuid: userCreds.customerId,
            },
        });

        return response?.Attributes;
    } catch (error) {
        throw new Error(
            `Failed to delete CLM record in DynamoDB for onmouuid ${userCreds.coreBankingCustomerId}: ${error}`,
        );
    }
};

export const updateCLMRecordFromDynamoDBTable = async (
    userCreds: CreditUserCredentials,
    updatePayload: { auto_apply: boolean; opt_out: boolean } = { auto_apply: true, opt_out: false },
) => {
    try {
        const response = await updateItemMethod({
            TableName: clmTable,
            Key: {
                onmouuid: userCreds.coreBankingCustomerId,
            },
            UpdateExpression: "set auto_apply = :auto_apply, opt_out = :opt_out",
            ExpressionAttributeValues: {
                ":auto_apply": updatePayload.auto_apply,
                ":opt_out": updatePayload.opt_out,
            },
        });

        return response?.Attributes;
    } catch (error) {
        throw new Error(
            `Failed to update CLM record in DynamoDB for onmouuid ${userCreds.coreBankingCustomerId}: ${error}`,
        );
    }
};
