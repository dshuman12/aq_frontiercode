import { deleteItemMethod, putItemMethod, getItemMethod } from "@onmoapp/onmo-dynamodb";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { putObject, listAllObjects, deleteObjects } from "@onmoapp/onmo-s3";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import {
    AccountType,
    DocumentType,
    CreateCustomerInput,
    CreateCustomerOutcome,
    CreateCreditAccountInput,
    CreateCreditAccountOutcome,
    CreateTechnicalAccountInput,
    CreateTechnicalAccountOutcome,
} from "@onmoapp/onmo-types";

import {
    CASH_CHANNEL_ID,
    CREDIT_ACCOUNT_PRODUCT_KEY,
    SALESFORCE_TEST_ACCOUNT_ID,
    SALESFORCE_TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY,
    SALESFORCE_TEST_CUSTOMER_UUID,
    TECHNICAL_ACCOUNT_PRODUCT_KEY,
    TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY,
    TEST_CUSTOMER_UUID,
    TEST_FEE_KEY,
    TEST_TECHNICAL_ACCOUNT_ID,
} from "@libs/constants";
import { v4 as uuidV4 } from "uuid";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { throwErrorIfAdapterResHaveError } from "../onmoErrorHandler";
import { InterestAndFeesFreezeData, interestAndFeesPK } from "@libs/types/interestAndFees";
import { getCoreBankingAdapter, getSalesforceAdapter } from "src/adapters";
import { CoreBanking } from "@onmoapp/core-banking";
dayjs.extend(utc);
dayjs.extend(timezone);

const env = process.env.ENVIRONMENT as string;
const userTable = process.env.USER_TABLE as string;
const DocumentBucket = process.env.DOCUMENT_BUCKET_NAME as string;
const interestfeesfreezeTable = process.env.INTEREST_FEES_FREEZE_TABLE as string;

dayjs.extend(utc);
dayjs.extend(timezone);

export type UserCredentials = {
    customerId: string;
    creditAccountId: string;
};

export type CreditUserCredentials = {
    coreBankingCustomerId?: string;
    creditAccountId: string;
    customerId: string;
    technicalAccountId: string;
    coreBankingCustomerEncodedKey?: string;
};

export type queryParams = {
    count?: string;
    periodFrom?: string;
    documentType?: string;
    documentCursor?: string;
    [key: string]: string;
};

const generateUniqueIdentifier = () => `TEST-${Date.now().toString()}`;
const generateTestAccountId = () => `TEST-${(Math.random() * 1000).toFixed()}`;

/**
 * Builds a query string from the provided query parameters.
 *
 * @param queryParameters - An object containing the query parameters.
 * @returns A string representing the query parameters in the format of key-value pairs separated by '&'.
 */
export const buildQueryString = (queryParameters: queryParams) => {
    const queryString = Object.keys(queryParameters)
        .map((key) => `${key}=${queryParameters[key]}`)
        .join("&");
    return queryString;
};

/**
 * Sets up a test account by creating a user record in the mobile table and logging the test account details.
 *
 * @returns The test account credentials containing the unique identifier and credit account ID.
 */
export const setUpTestAccount = async (): Promise<UserCredentials> => {
    const testAccount: CreditUserCredentials = {
        customerId: generateUniqueIdentifier(),
        creditAccountId: generateTestAccountId(),
        technicalAccountId: "",
    };
    await createUserRecordInMobileTable(testAccount);
    return testAccount;
};

export const setUpTestCreditCustomerAccount = async () => {
    const createCustomerInput: CreateCustomerInput = {
        applicationDetail: {
            onmoUuid: generateUniqueIdentifier(),
            crmId: generateUniqueIdentifier(),
        },
        personalData: {
            firstName: "test",
            lastName: "test",
            dateOfBirth: "1990-01-01",
            emailAddresses: ["test@test.com"],
            mobileNumbers: ["1234567890"],
        },
    };
    let createCustomerOutcome: CreateCustomerOutcome;

    const coreBankingAdapter = await getCoreBankingAdapter();
    createCustomerOutcome = await coreBankingAdapter.createCustomer(createCustomerInput);
    const { coreBankingCustomerId, coreBankingCustomerEncodedKey } = createCustomerOutcome.data;
    const createCreditAccountInput: CreateCreditAccountInput = {
        coreBankingCustomerEncodedKey,
        productKey: CREDIT_ACCOUNT_PRODUCT_KEY,
        loanAmount: 100,
        interestRate: 1,
        paymentDay: 30,
        apr: "44.9",
        creditRiskGroup: "987",
    };

    const createCreditAccountOutcome: CreateCreditAccountOutcome =
        await coreBankingAdapter.createCreditAccount(createCreditAccountInput);

    const createTechnicalAccountInput: CreateTechnicalAccountInput = {
        coreBankingCustomerEncodedKey,
        productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
    };
    const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
        await coreBankingAdapter.createTechnicalAccount(createTechnicalAccountInput);

    await coreBankingAdapter.approveTechnicalAccount(
        createTechnicalAccountOutcome.data.technicalAccountId,
    );

    const testUserCreds: CreditUserCredentials = {
        coreBankingCustomerId,
        coreBankingCustomerEncodedKey,
        creditAccountId: createCreditAccountOutcome.data.accountId,
        customerId: createCustomerInput?.applicationDetail?.onmoUuid,
        technicalAccountId: createTechnicalAccountOutcome.data.technicalAccountId,
    };
    await createUserRecordInMobileTable(testUserCreds);
    return testUserCreds;
};

export const calculateFutureDates = (): { startDate: string; endDate: string } => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset to midnight to ignore the time part

    // Calculate startDate (1 week in the future)
    const startDate = new Date(today);
    startDate.setDate(today.getDate() + 7);

    // Calculate endDate (2 weeks in the future)
    const endDate = new Date(today);
    endDate.setDate(today.getDate() + 14);

    // Format dates as YYYY-MM-DD using toISOString
    const formatDate = (date: Date): string => {
        return date.toISOString().split("T")[0];
    };

    return {
        startDate: formatDate(startDate),
        endDate: formatDate(endDate),
    };
};

export const deleteTestCreditCustomerAccount = async (userCredentials: CreditUserCredentials) => {
    const coreBankingAdapter = await getCoreBankingAdapter();
    await coreBankingAdapter.deleteCreditAccount(userCredentials.creditAccountId);
    await coreBankingAdapter.deleteTechnicalAccount(userCredentials.technicalAccountId);
    await coreBankingAdapter.deleteCustomer(userCredentials.coreBankingCustomerId);
    await deleteUserRecordInMobileTable(userCredentials.customerId);
};

/**
 * Tears down the test account by deleting the user record in the mobile table and removing the test documents for the specified customer.
 *
 * @param customerId - The unique identifier of the test account.
 */
export const tearDownTestAccount = async (customerId: string) => {
    await deleteUserRecordInMobileTable(customerId);
    await deleteTestDocuments(customerId, "contracts");
    await deleteTestDocuments(customerId, "statements");
};

/**
 * Creates a new user record in the mobile table.
 *
 * @param userCredentials - An object containing the unique identifier and credit account ID for the new user.
 * @returns A Promise that resolves when the user record is successfully created.
 */
export const createUserRecordInMobileTable = async (userCredentials: CreditUserCredentials) => {
    try {
        await putItemMethod({
            TableName: userTable,
            Item: {
                onmouuid: userCredentials.customerId,
                mambuCreditCardAccountID: userCredentials.creditAccountId,
                ...(userCredentials.technicalAccountId && {
                    mambuTechnicalAccountID: userCredentials.technicalAccountId,
                }),
            },
        });
    } catch (error) {
        console.log("[createUserRecordInMobileTable] ERROR ", error);
    }
};

/**
 * Deletes a user record from the mobile table based on the provided unique identifier.
 *
 * @param customerId - The unique identifier of the user whose record needs to be deleted.
 * @returns A Promise that resolves when the user record is successfully deleted.
 */
export const deleteUserRecordInMobileTable = async (customerId: string) => {
    await deleteItemMethod({ TableName: userTable, Key: { onmouuid: customerId } });
};

/**
 * Generates a random set of dates within the specified range.
 *
 * @param count - The number of dates to generate. Defaults to 10.
 * @param startDate - The start date for the range of dates.
 * @param endDate - The end date for the range of dates.
 * @returns An array of objects, each containing the year, month, and day of a randomly generated date within the specified range.
 * @example
 * const randomDates = generateRandomDates(5, new Date(2022, 0, 1), new Date(2022, 11, 31));
 * console.log(randomDates);
 */
export const generateRandomDates = (
    count = 10,
    startDate: Date,
    endDate: Date,
): { year: string; month: string; day: string }[] => {
    const dates = [];
    for (let i = 0; i < count; i++) {
        const date = new Date(
            startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()),
        );
        dates.push({
            year: date.getFullYear().toString().padStart(4, "0"),
            month: (date.getMonth() + 1).toString().padStart(2, "0"),
            day: date.getDay().toString().padStart(2, "0"),
        });
    }
    return dates.sort(
        (a, b) =>
            new Date(+a.year, +a.month - 1, +a.day).getTime() -
            new Date(+b.year, +b.month - 1, +b.day).getTime(),
    );
};

/**
 * Generates a sequence of monthly dates within the specified range.
 *
 * @param startDate - The start date for the range of dates.
 * @param endDate - The end date for the range of dates.
 * @returns An array of objects, each containing the year and month of a date within the specified range.
 * @example
 * const monthlyDates = generateMonthlyDates(new Date(2022, 0, 1), new Date(2022, 11, 31));
 * console.log(monthlyDates);
 */
export const generateMonthlyDates = (
    startDate: Date,
    endDate: Date,
): { year: string; month: string }[] => {
    const dates = [];
    let date = startDate;
    while (date.getTime() < endDate.getTime()) {
        dates.push({
            year: date.getFullYear().toString().padStart(4, "0"),
            month: (date.getMonth() + 1).toString().padStart(2, "0"),
        });
        date.setMonth(date.getMonth() + 1);
    }
    return dates.sort(
        (a, b) =>
            new Date(+a.year, +a.month - 1, 0).getTime() -
            new Date(+b.year, +b.month - 1, 0).getTime(),
    );
};

/**
 * Uploads a sequence of test contracts for a specified customer to the specified S3 bucket.
 *
 * @param customerId - The unique identifier of the customer.
 * @param accountType - The type of account for the test contracts (either "credit" or "debit").
 * @param dates - An array of objects, each containing the year, month, and day of a date within the specified range.
 * @returns A Promise that resolves when all the test contracts are successfully uploaded.
 * @example
 * const testContracts = [
 *     { year: "2022", month: "01", day: "01" },
 *     { year: "2022", month: "01", day: "02" },
 *     // ...
 * ];
 * await uploadTestContractsForCustomer(customerId, "credit", testContracts);
 */
export const uploadTestContractsForCustomer = async (
    customerId: string,
    accountType: "credit" | "debit",
    dates: { year: string; month: string; day: string }[],
) => {
    await Promise.all(
        dates.map(async (date, index) => {
            return await putObject({
                Bucket: DocumentBucket,
                Key: `processed/contracts/customer=${customerId}/year=${date.year}/month=${
                    date.month
                }/day=${date.day}/account=${accountType}/testDoc-${index + 1}.json`,
                Body: JSON.stringify({
                    customerId,
                    accountType,
                    ...date,
                }),
            });
        }),
    );
};

/**
 * Uploads a sequence of test statements for a specified customer to the specified S3 bucket.
 *
 * @param customerId - The unique identifier of the customer.
 * @param accountType - The type of account for the test statements (either "credit" or "debit").
 * @param dates - An array of objects, each containing the year and month of a date within the specified range.
 * @returns A Promise that resolves when all the test statements are successfully uploaded.
 * @example
 * const testStatements = [
 *     { year: "2022", month: "01" },
 *     { year: "2022", month: "01" },
 *     // ...
 * ];
 * await uploadTestStatementsForCustomer(customerId, "credit", testStatements);
 */
export const uploadTestStatementsForCustomer = async (
    customerId: string,
    accountType: AccountType,
    dates: { year: string; month: string }[],
) => {
    await Promise.all(
        dates.map(async (date, index) => {
            return await putObject({
                Bucket: DocumentBucket,
                Key: `processed/statements/customer=${customerId}/year=${date.year}/month=${
                    date.month
                }/account=${accountType}/testDoc-${index + 1}.json`,
                Body: JSON.stringify({
                    customerId,
                    accountType,
                    ...date,
                }),
            });
        }),
    );
};

// export const sortDocumentsByDate = ()

/**
 * Deletes the test documents for the specified customer and document type from the specified S3 bucket.
 *
 * @param customerId - The unique identifier of the customer.
 * @param documentType - The type of document to delete (either "contracts" or "statements").
 * @returns A Promise that resolves when all the test documents are successfully deleted.
 * @example
 * await deleteTestDocuments(customerId, "contracts");
 * await deleteTestDocuments(customerId, "statements");
 */
export const deleteTestDocuments = async (customerId: string, documentType: DocumentType) => {
    const documents = await listAllObjects({
        Bucket: DocumentBucket,
        Prefix: `processed/${documentType}/customer=${customerId}/`,
    });
    if (documents?.Contents?.length > 0) {
        const objectKeys = documents?.Contents?.map(({ Key }) => {
            return {
                Key,
            };
        });

        await deleteObjects({
            Bucket: DocumentBucket,
            Delete: {
                Objects: objectKeys,
            },
        });
    }
};

/**
 * Fetches the API secret from AWS Secrets Manager.
 *
 * @returns The API secret as a string.
 * @throws {OnmoError} If the secret is not found or if the API key is undefined.
 * @example
 * const apiSecret = await fetchAPISecret();
 */

export const fetchAPISecret = async () => {
    console.log("fetchAPISecret env : ", env);
    const { SecretString } = await getSecret("onmo-service-layer-" + env);
    if (!SecretString) {
        throw new OnmoError({
            name: ErrorNamesEnum.GET_SECRET_VALUE_ERROR,
            message: "API secret not found",
        });
    }
    const apiSecret = JSON.parse(SecretString);
    return apiSecret?.apiKey;
};

/**
 * Creates a new user record in the interest-fee-freeze table.
 *
 * @param userCredentials - An object containing the unique identifier and credit account ID for the new user.
 * @returns A Promise that resolves when the user record is successfully created.
 */
export const createRecordInInterestAndFeesFreezeTable = async (data: InterestAndFeesFreezeData) => {
    try {
        await putItemMethod({
            TableName: interestfeesfreezeTable,
            Item: data,
        });
    } catch (error) {
        console.log("[createRecordInInterestAndFeesFreezeTable] ERROR", error);
    }
};

/**
 * Deletes a user record from the interest-fee-freeze table based on the credit account id.
 *
 * @param userCredentials - An object containing the unique identifier and credit account ID for the new user.
 * @returns A Promise that resolves when the user record is successfully deleted.
 */
export const deleteRecordInInterestAndFeesFreezeTable = async (
    accountId: string,
    createdAt: string,
) => {
    try {
        await deleteItemMethod({
            TableName: interestfeesfreezeTable,
            Key: { accountId, createdAt },
        });
    } catch (error) {
        console.log("[deleteRecordInInterestAndFeesFreezeTable] ERROR", error);
    }
};
/**
 * Retrieves a user record from the interest-fee-freeze table based on the credit account id.
 *
 * @param userCredentials - An object containing the unique identifier and credit account ID for the new user.
 * @returns A Promise that resolves with the user record.
 */
export const getRecordInInterestAndFeesFreezeTable = async (key: interestAndFeesPK) => {
    try {
        return await getItemMethod({ TableName: interestfeesfreezeTable, Key: key });
    } catch (error) {
        console.log("[getRecordInInterestAndFeesFreezeTable] ERROR", error);
    }
};

/**
 * Sets up a credit arrangement for the test customer and add the credit account to the credit arrangement.
 *
 * @param userCredentials - An object containing the unique identifier and credit account ID for the new user.
 */
export const setupCreditArrangement = async (userCredentials: CreditUserCredentials) => {
    try {
        const { creditAccountId, coreBankingCustomerEncodedKey } = userCredentials;
        const coreBankingAdapter = await getCoreBankingAdapter();

        const currentDate = dayjs().tz("Europe/London");
        const creditArrangement = await coreBankingAdapter.createCreditArrangement({
            amount: 1000,
            startDate: currentDate.add(-1, "year").format(),
            coreBankingCustomerEncodedKey: coreBankingCustomerEncodedKey,
            coreBankingCustomerType: "CLIENT",
            expiryDate: currentDate.add(2, "year").format(),
            idempotencyKey: uuidV4(),
        });

        await coreBankingAdapter.addCreditAccountToCreditArrangement(
            creditArrangement.data.creditArrangementId,
            {
                creditAccountId: creditAccountId,
                coreBankingAccountType: "credit",
            },
        );

        await coreBankingAdapter.setCreditAccountStatus(creditAccountId, {
            action: "APPROVE",
            notes: "Test account setup",
        });

        await coreBankingAdapter.makeDisbursementToCreditAccount(creditAccountId, {
            amount: 100,
            valueDate: "2024-04-09T07:01:39+01:00",
            bookingDate: "2024-04-09T07:01:39+01:00",
            externalId: `externalId-e2e-test-${Date.now()}`,
            notes: "e2e-test-case",
            transactionChannelId: "cash",
        });
    } catch (error) {
        console.log(error);
    }
};

export const getCreditAccount = async (creditAccountId: string) => {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const creditAccountResponse = await coreBankingAdapter.getCreditAccount(creditAccountId);
        return creditAccountResponse;
    } catch (error) {
        console.log("[getCreditAccount] ERROR", error);
    }
};

export const fetchMambuApiKeySecret = async () => {
    const { SecretString } = await getSecret("mambu_" + env);
    if (!SecretString) {
        throw new OnmoError({
            name: ErrorNamesEnum.GET_SECRET_VALUE_ERROR,
            message: "API secret not found",
        });
    }
    const apiSecret = JSON.parse(SecretString);
    return apiSecret?.api_key;
};

export async function approveMambuLoanAccount(mambuLoanAccountId) {
    const mambuApiKey = await fetchMambuApiKeySecret();
    const baseUrl = "https://onmo.sandbox.mambu.com/api/";

    const response = await fetch(`${baseUrl}loans/${mambuLoanAccountId}:changeState`, {
        method: "POST",
        body: JSON.stringify({
            action: "APPROVE",
            notes: "Loan Account Approved via API",
        }),
        headers: {
            "Content-Type": "application/json",
            "Idempotency-Key": uuidV4(),
            Accept: "application/vnd.mambu.v2+json",
            apiKey: mambuApiKey,
        },
    });

    if (response.status !== 200) throw new Error("not approved loanAccount ");
    return await response.json();
}

export async function writeOffMambuLoanAccount(mambuLoanAccountId) {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        await coreBankingAdapter.writeOffCreditAccount(mambuLoanAccountId, {
            notes: "writing off test account",
        });
    } catch (error) {
        console.log("[writeOffMambuLoanAccount] ERROR ", error);
    }
}

export async function updateInterestRate(
    coreBankingClient: CoreBanking,
    accountId: string,
    date: string,
    interestRate: number,
) {
    const updateInterestRateRes = await coreBankingClient.updateInterestRateToCreditAccount(
        accountId,
        {
            interestRate: interestRate,
            valueDate: date,
            notes: "unit test case",
        },
    );

    throwErrorIfAdapterResHaveError(updateInterestRateRes, {
        message: "pre test error while interest rate change",
    });
}

async function makeDisbursementTest(
    coreBankingClient: CoreBanking,
    accountId: string,
    date: string,
    amount: number,
    cashTransaction = false,
) {
    const disbursementRes = await coreBankingClient.makeDisbursementToCreditAccount(accountId, {
        amount: amount,
        valueDate: date,
        bookingDate: date,
        externalId: `test-external-${Date.now()}`,
        transactionChannelId: cashTransaction ? CASH_CHANNEL_ID : "Statement_Disbursement",
    });

    throwErrorIfAdapterResHaveError(disbursementRes, {
        message: "pre test error while disbursement",
    });
}

async function makeRepaymentTest(
    coreBankingClient: CoreBanking,
    accountId: string,
    date: string,
    amount: number,
) {
    const repaymentRes = await coreBankingClient.makeRepaymentToCreditAccount(accountId, {
        amount: amount,
        valueDate: date,
        bookingDate: date,
        externalId: `test-external-${Date.now()}`,
        transactionChannelId: "repaymt_direct_debit",
    });
    console.log({ repaymentRes });

    throwErrorIfAdapterResHaveError(repaymentRes, {
        message: "pre test error while repayment",
    });
}

async function applyFeeTest(
    coreBankingClient: CoreBanking,
    accountId: string,
    date: string,
    amount: number,
) {
    const applyFeeRes = await coreBankingClient.applyFeeToCreditAccount(accountId, {
        bookingDate: date,
        valueDate: date,
        externalId: `test-external-${Date.now()}`,
        feeKey: TEST_FEE_KEY,
        amount: amount,
    });

    throwErrorIfAdapterResHaveError(applyFeeRes, {
        message: "pre test error while apply fee",
    });
}

export const setupTestAccountForCreditUnfreezeAccount = async () => {
    try {
        const now = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
        const createCreditAccountInput: CreateCreditAccountInput = {
            coreBankingCustomerEncodedKey: TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY,
            productKey: CREDIT_ACCOUNT_PRODUCT_KEY,
            loanAmount: 1000,
            interestRate: 10,
            paymentDay: 30,
            apr: "44.9",
            creditRiskGroup: "987",
        };
        const coreBankingAdapter = await getCoreBankingAdapter();
        const createCreditAccountOutcome: CreateCreditAccountOutcome =
            await coreBankingAdapter.createCreditAccount(createCreditAccountInput);
        const accountId = createCreditAccountOutcome.data.accountId;

        await approveMambuLoanAccount(accountId);

        await makeDisbursementTest(
            coreBankingAdapter,
            accountId,
            dayjs().add(-5, "day").tz("Europe/London").format(),
            51,
        );
        await applyFeeTest(
            coreBankingAdapter,
            accountId,
            dayjs().add(-4, "day").tz("Europe/London").format(),
            10,
        );
        await makeRepaymentTest(
            coreBankingAdapter,
            accountId,
            dayjs().tz("Europe/London").format(),
            30,
        );
        await makeDisbursementTest(
            coreBankingAdapter,
            accountId,
            dayjs().tz("Europe/London").format(),
            56,
        );

        return { accountId, createdAt: now };
    } catch (error) {
        console.log(" [setupTestAccountForCreditUnfreezeAccount] ERROR : ", error);
    }
};

export const createTestAccount = async (
    coreBankingClient: CoreBanking,
    createTechnicalAccount = false,
    createCreditArrangement = false,
    _coreBankingCustomerEncodedKey?: string,
    _customerId?: string,
) => {
    const coreBankingCustomerEncodedKey =
        _coreBankingCustomerEncodedKey ?? TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY;

    const customerId = _customerId ?? TEST_CUSTOMER_UUID;
    const createCreditAccountInput: CreateCreditAccountInput = {
        coreBankingCustomerEncodedKey: coreBankingCustomerEncodedKey,
        productKey: CREDIT_ACCOUNT_PRODUCT_KEY,
        loanAmount: 1000,
        interestRate: 10,
        paymentDay: 30,
        apr: "44.9",
        creditRiskGroup: "987",
    };
    const createCreditAccountOutcome: CreateCreditAccountOutcome =
        await coreBankingClient.createCreditAccount(createCreditAccountInput);
    const accountId = createCreditAccountOutcome.data.accountId;

    let technicalId = TEST_TECHNICAL_ACCOUNT_ID;

    if (createTechnicalAccount) {
        const createTechnicalAccountInput: CreateTechnicalAccountInput = {
            coreBankingCustomerEncodedKey: coreBankingCustomerEncodedKey,
            productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
        };
        const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
            await coreBankingClient.createTechnicalAccount(createTechnicalAccountInput);
        technicalId = createTechnicalAccountOutcome.data.technicalAccountId;
        await coreBankingClient.approveTechnicalAccount(technicalId);
    }

    if (createCreditArrangement) {
        const currentDate = dayjs().tz("Europe/London");
        const creditArrangement = await coreBankingClient.createCreditArrangement({
            amount: 1000,
            startDate: currentDate.add(-1, "year").format(),
            coreBankingCustomerEncodedKey: coreBankingCustomerEncodedKey,
            coreBankingCustomerType: "CLIENT",
            expiryDate: currentDate.add(2, "year").format(),
            idempotencyKey: uuidV4(),
        });

        await coreBankingClient.addCreditAccountToCreditArrangement(
            creditArrangement.data.creditArrangementId,
            {
                creditAccountId: accountId,
                coreBankingAccountType: "credit",
            },
        );
    }

    await approveMambuLoanAccount(accountId);
    await createUserRecordInMobileTable({
        customerId: customerId,
        creditAccountId: accountId,
        technicalAccountId: technicalId,
    });

    return accountId;
};

export const setupTestAccountWithTransactions = async ({
    includeCashTransaction = false,
    createTechnicalAccount = false,
}: {
    includeCashTransaction?: boolean;
    createTechnicalAccount?: boolean;
}) => {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountId = await createTestAccount(coreBankingAdapter, createTechnicalAccount);

        const _backDate = dayjs().add(-5, "day").tz("Europe/London").format();
        const _date = dayjs().tz("Europe/London").format();

        await makeDisbursementTest(coreBankingAdapter, accountId, _backDate, 51);
        await applyFeeTest(coreBankingAdapter, accountId, _date, 10);
        await makeDisbursementTest(coreBankingAdapter, accountId, _date, 50);
        await makeRepaymentTest(coreBankingAdapter, accountId, _date, 30);

        if (includeCashTransaction)
            await makeDisbursementTest(coreBankingAdapter, accountId, _date, 17, true);

        return accountId;
    } catch (error) {
        console.log(" [setupTestAccountWithTransactions] ERROR : ", error);
    }
};

export const setupTestAccountWithSalesforceAccount = async () => {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountId = await createTestAccount(
            coreBankingAdapter,
            false,
            true,
            SALESFORCE_TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY,
            SALESFORCE_TEST_CUSTOMER_UUID,
        );
        const _date = dayjs().tz("Europe/London").format();
        await makeDisbursementTest(coreBankingAdapter, accountId, _date, 51);

        const salesforceAdapter = await getSalesforceAdapter();
        const createFinancialAccRes = await salesforceAdapter.createFinancialAcc({
            customerId: SALESFORCE_TEST_CUSTOMER_UUID,
            financialAccountId: SALESFORCE_TEST_ACCOUNT_ID,
            loanAccountId: accountId,
            EligibleforCustomerCareJourney: true,
        });

        console.log({ createFinancialAccRes });
        return { accountId, crmFinancialAccountId: createFinancialAccRes.data.id };
    } catch (error) {
        console.log(" [setupTestAccountWithSalesforceAccount] ERROR : ", error);
    }
};

export const setupTestAccountForValidationScenarioForCreditFreezeAccount = async () => {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountId = await createTestAccount(coreBankingAdapter);

        const _backDate = dayjs().add(-5, "day").tz("Europe/London").format();
        const _date = dayjs().tz("Europe/London").format();

        await makeDisbursementTest(coreBankingAdapter, accountId, _backDate, 100);
        await applyFeeTest(coreBankingAdapter, accountId, _date, 10);
        await applyFeeTest(coreBankingAdapter, accountId, _date, 20);
        await applyFeeTest(coreBankingAdapter, accountId, _date, 30);
        await applyFeeTest(coreBankingAdapter, accountId, _date, 40);
        await makeDisbursementTest(coreBankingAdapter, accountId, _date, 50);
        await makeRepaymentTest(coreBankingAdapter, accountId, _date, 240);
        return accountId;
    } catch (error) {
        console.log(
            " [setupTestAccountForValidationScenarioForCreditFreezeAccount] ERROR : ",
            error,
        );
    }
};

export const setupTestAccountForInterestScenarioForCreditFreezeAccount = async (
    coreBankingClient: CoreBanking,
) => {
    try {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const _backDate = dayjs().add(-5, "day").tz("Europe/London");
        const _date1 = dayjs().add(-1, "day").add(-4, "hour").tz("Europe/London");
        const _date2 = dayjs().add(-1, "day").add(-3, "hour").tz("Europe/London");
        const _date3 = dayjs().add(-1, "day").add(-2, "hour").tz("Europe/London");
        const _date4 = dayjs().add(-1, "day").add(-1, "hour").tz("Europe/London");
        const _date5 = dayjs().tz("Europe/London");

        const accountId = await createTestAccount(coreBankingClient);

        await makeDisbursementTest(coreBankingAdapter, accountId, _backDate.format(), 51);
        await applyFeeTest(coreBankingAdapter, accountId, _date1.format(), 10);
        await updateInterestRate(
            coreBankingAdapter,
            accountId,
            _date2.format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            50,
        );
        await applyFeeTest(coreBankingAdapter, accountId, _date3.format(), 20);
        await makeDisbursementTest(coreBankingAdapter, accountId, _date3.format(), 50);
        await makeRepaymentTest(coreBankingAdapter, accountId, _date3.format(), 30);
        await updateInterestRate(
            coreBankingAdapter,
            accountId,
            _date4.format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            50,
        );
        await applyFeeTest(coreBankingAdapter, accountId, _date5.format(), 17);
        await makeRepaymentTest(coreBankingAdapter, accountId, _date5.format(), 15);
        return accountId;
    } catch (error) {
        console.log(" [setupTestAccountForInterestScenarioForCreditFreezeAccount] ERROR : ", error);
    }
};
