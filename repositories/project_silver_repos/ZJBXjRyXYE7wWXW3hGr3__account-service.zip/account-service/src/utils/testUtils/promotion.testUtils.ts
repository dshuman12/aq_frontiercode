import { randomUUID } from "crypto";
import { deleteItemMethod } from "@onmoapp/onmo-dynamodb";

import { PromotionRecord, PromotionType } from "@libs/types/promotion";
import { PromotionService } from "@services/promotion";
import { buildPartitionKey, buildSortKey } from "@services/promotion/keys";

const promotionsTable = process.env.PROMOTIONS_TABLE as string;

export const generateTestCreditAccountId = () =>
    `TEST-PROMO-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export type SeededPromotion = {
    onmouuid: string;
    credit_account_id: string;
    promotion_type: PromotionType;
    start_date: number;
    end_date: number;
    promotional_interest_rate: number;
    original_interest_rate: number;
    original_apr: number;
};

const seededPromotions: Array<{
    credit_account_id: string;
    promotion_type: PromotionType;
    start_date: number;
}> = [];

export const seedPromotion = async (
    overrides: Partial<SeededPromotion> = {},
): Promise<SeededPromotion> => {
    const start_date = overrides.start_date ?? 1_700_000_000;
    const seed: SeededPromotion = {
        onmouuid: overrides.onmouuid ?? randomUUID(),
        credit_account_id: overrides.credit_account_id ?? generateTestCreditAccountId(),
        promotion_type: overrides.promotion_type ?? PromotionType.HONEYMOON,
        start_date,
        end_date: overrides.end_date ?? start_date + 90 * 24 * 3600,
        promotional_interest_rate: overrides.promotional_interest_rate ?? 0,
        original_interest_rate: overrides.original_interest_rate ?? 22.5,
        original_apr: overrides.original_apr ?? 24.9,
    };

    const result = await PromotionService.getInstance().create(seed);
    if (!result.ok) {
        throw new Error(`Failed to seed promotion: ${result.error.message}`);
    }

    trackPromotionForCleanup(seed.credit_account_id, seed.promotion_type, seed.start_date);
    return seed;
};

export const trackPromotionForCleanup = (
    creditAccountId: string,
    promotionType: PromotionType,
    startDate: number,
) => {
    seededPromotions.push({
        credit_account_id: creditAccountId,
        promotion_type: promotionType,
        start_date: startDate,
    });
};

export const teardownSeededPromotions = async () => {
    const results = await Promise.allSettled(
        seededPromotions.map((p) =>
            deletePromotionRecord(p.credit_account_id, p.promotion_type, p.start_date),
        ),
    );
    seededPromotions.length = 0;
    const failures = results.filter((r): r is PromiseRejectedResult => r.status === "rejected");
    if (failures.length > 0) {
        throw new Error(
            `Failed to delete ${failures.length} seeded promotion(s): ${failures
                .map((f) => String(f.reason))
                .join("; ")}`,
        );
    }
};

export const getPromotionRecord = async (
    creditAccountId: string,
    promotionType: PromotionType,
    startDate: number,
): Promise<PromotionRecord | null> => {
    const result = await PromotionService.getInstance().getForAccount(creditAccountId);
    if (!result.ok) {
        throw new Error(`Failed to fetch promotions: ${result.error.message}`);
    }
    const promotionId = buildSortKey(promotionType, startDate);
    return result.data.find((p) => p.promotion_id === promotionId) ?? null;
};

export const deletePromotionRecord = async (
    creditAccountId: string,
    promotionType: string,
    startDate: number,
) => {
    await deleteItemMethod({
        TableName: promotionsTable,
        Key: {
            id: buildPartitionKey(creditAccountId),
            promotion_id: buildSortKey(promotionType, startDate),
        },
    });
};
