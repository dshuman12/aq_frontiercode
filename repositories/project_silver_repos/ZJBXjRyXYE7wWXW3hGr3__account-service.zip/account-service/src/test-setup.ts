import { vi } from "vitest";

// Mock handler-middleware to be a passthrough in tests.
vi.mock("@onmoapp/handler-middleware", async (importOriginal) => {
    const actual = (await importOriginal()) as Record<string, unknown>;
    return {
        ...actual,
        createApiHandler: (_name: string) => ({
            use: () => ({ handle: (fn: any) => fn }),
            handle: (fn: any) => fn,
        }),
        createEventHandler: (_name: string) => ({
            use: () => ({ handle: (fn: any) => fn }),
            handle: (fn: any) => fn,
        }),
    };
});
