import { test, expect, beforeAll, afterAll } from "vitest";
import {
    CreditUserCredentials,
    fetchAPISecret,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
} from "@utils/testUtils";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeSpendingLock = async (
    accountId: string,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const payment_plan_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/spending-lock`;
    return await fetch(payment_plan_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    userCreds = await setUpTestCreditCustomerAccount();
});

afterAll(async () => {
    await deleteTestCreditCustomerAccount(userCreds);
});

test("happy path", async () => {
    const response = await invokeSpendingLock(userCreds.creditAccountId);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Spending lock applied" });
});

test("non-existent account id", async () => {
    const response = await invokeSpendingLock("fake-account-id");

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "failed to update credit account, INVALID_LOAN_ACCOUNT_ID",
    });
});

test("no api key", async () => {
    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const response = await invokeSpendingLock(
        userCreds.creditAccountId,
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});
