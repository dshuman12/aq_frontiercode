import { APIGatewayEvent } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/api-gateway";
import {
    ACCOUNT_UPSERTED_EVENT_NAME,
    CORE_BANKING_WEBHOOK_EVENT_INITIATOR_NAME,
} from "@libs/constants";
import { getCoreBankingAdapter, getEventHubAdapter } from "src/adapters";
import { v4 as uuid } from "uuid";
import { AccountUpsertedEvent, AccountUpsertedEventRequestBody } from "@libs/types";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { GetCreditAccountOutcome } from "@onmoapp/onmo-types";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";

export const handler = async (event: APIGatewayEvent): Promise<any> => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        logger.info({ message: `Received an event ${JSON.stringify(event)}` });
        const parsedRequestBody = parseAPIGateWayEventBody(
            event.body,
        ) as AccountUpsertedEventRequestBody;
        logger.info(`Parsed request body: ${JSON.stringify(parsedRequestBody)}`);
        const { accountId, customerId, state } = parsedRequestBody;
        if (!accountId || !customerId || !state) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "Missing required fields in request body",
            });
        }
        logger.addContext({ accountId });
        let accountIdToQuery = accountId; // default to accountId from request (assuming it's credit account id)

        const isTechnicalAccountId = parsedRequestBody.coreBankingAccountType === "TECHNICAL";
        if ("coreBankingAccountType" in parsedRequestBody && !isTechnicalAccountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: `Unexpected value for coreBankingAccountType received, expected TECHNICAL but received ${parsedRequestBody.coreBankingAccountType}`,
            });
        }
        if (isTechnicalAccountId) {
            logger.info(
                `Received request from technical account webhook, fetching credit account id from ${process.env.USER_TABLE}`,
            );
            const userTableRecord = await getItemMethod({
                TableName: process.env.USER_TABLE,
                Key: {
                    onmouuid: customerId,
                },
            });
            logger.info(`Obtained customer record from ${process.env.USER_TABLE}`);

            if (
                !userTableRecord.Item ||
                !userTableRecord?.Item?.mambuTechnicalAccountID ||
                !userTableRecord?.Item?.mambuCreditCardAccountID ||
                userTableRecord?.Item?.mambuTechnicalAccountID !== accountId
            ) {
                throw new OnmoError({
                    name: ErrorNamesEnum.NOT_FOUND_ERROR,
                    message: `Not able match customerId to a valid record in ${process.env.USER_TABLE} table`,
                });
            }
            logger.info(
                `Matched technical account id to a record in ${process.env.USER_TABLE} table`,
            );
            accountIdToQuery = userTableRecord?.Item?.mambuCreditCardAccountID;
        }
        logger.addContext({ accountIdToQuery, customerId });
        logger.info(`Got required fields from request body`);

        logger.info("Fetching account details from core banking");
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountDetails: GetCreditAccountOutcome =
            await coreBankingAdapter.getCreditAccount(accountIdToQuery);
        if (!accountDetails.data || accountDetails.error) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "Failed to get account details",
                cause: accountDetails.error,
            });
        }
        logger.info("Account details fetched successfully");

        logger.info("EventHub adapter initialized successfully");
        const id = uuid();
        const correlationId = uuid();
        const eventPayload: AccountUpsertedEvent = {
            accountDetails: {
                accountId: accountDetails.data.accountDetails.accountId,
                customerId: accountDetails.data.accountDetails.customerId,
                state: accountDetails.data.accountDetails.state,
                accountState: accountDetails.data.accountDetails.accountState,
                additionalAccountState: accountDetails.data.accountDetails.additionalAccountState,
                inArrearsDate: accountDetails.data.accountDetails.inArrearsDate,
                isInArrears: accountDetails.data.accountDetails.ifInArrears,
                creditLimit: accountDetails.data.accountDetails.creditLimit,
                availableCredit: accountDetails.data.accountDetails.availableCredit,
                apr: accountDetails.data.accountDetails.apr,
                interestRate: accountDetails.data.accountDetails.interestRate,
                startOfBillingCycle: accountDetails.data.accountDetails.startOfBillingCycle,
                nextStatementDueDate: accountDetails.data.accountDetails.nextStatementDueDate,
                daysLate: accountDetails?.data?.accountDetails?.daysLate ?? null,
            },
            directDebitSettings: {
                amountPreference: accountDetails.data.directDebitSettings.amountPreference,
                mandateID: accountDetails.data.directDebitSettings.mandateID,
                mandateReference: accountDetails.data.directDebitSettings.mandateReference,
                provider: accountDetails.data.directDebitSettings.provider,
                nextDirectDebitAmount:
                    accountDetails.data.directDebitSettings.nextDirectDebitAmount,
                directDebitRetryInProgress:
                    accountDetails.data.directDebitSettings.directDebitRetryInProgress,
                scheduledDirectDebitAmount:
                    accountDetails.data.directDebitSettings.scheduledDirectDebitAmount,
            },
            accountBalances: {
                totalNextMinimumPayment:
                    accountDetails.data.accountBalances.totalNextMinimumPaymentDue,
                balances: {
                    total: accountDetails.data.accountBalances.balances.total,
                    principal: accountDetails.data.accountBalances.balances.principal,
                    interest: accountDetails.data.accountBalances.balances.interest,
                    fees: accountDetails.data.accountBalances.balances.fees,
                },
                arrearBalances: accountDetails.data.accountBalances.arrearBalances,
                due: accountDetails.data.accountBalances.due,
            },
        };
        const EventData: EventData<AccountUpsertedEvent> = {
            id, // unique identifier for the event
            idempotencyKey: id, // unique id per event
            correlationId, // unique relation identifier between events
            event: ACCOUNT_UPSERTED_EVENT_NAME,
            subtype: null,
            initiatedBy: CORE_BANKING_WEBHOOK_EVENT_INITIATOR_NAME,
            source: process.env.SERVICE_NAME, // source who publishes an event
            schemaVersion: process.env.ACCOUNT_UPSERTED_SCHEMA_VERSION, // glue schema version for event data validation
            eventData: eventPayload, // event payload (json)
            created: new Date().toISOString(), // timestamp of the event
        };
        logger.debug({ EventData });
        const eventHubAdapter = await getEventHubAdapter<AccountUpsertedEvent>();
        const { isValid: isEventDataValid, validationErrors } =
            await eventHubAdapter.validateEvent(EventData);
        logger.info({
            message: "Result of Event validation",
            isEventDataValid,
            validationErrors,
        });
        if (!isEventDataValid)
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Validation Failed: Invalid Event Data",
                cause: validationErrors,
            });

        const {
            isPublished,
            isValid: isPublishingEventValid,
            validationErrors: publishingValidationErrors,
        } = await eventHubAdapter.publishToEventHub(EventData, correlationId);
        logger.info({
            message: "Response from EventHub for publishing event",
            isPublished,
            isPublishingEventValid,
            publishingValidationErrors,
        });
        if (!isPublished || !isPublishingEventValid) {
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to publish Event to event hub",
                cause: publishingValidationErrors,
            });
        }

        return formatJSONResponse(200, {
            message: "Account upserted event published successfully",
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
