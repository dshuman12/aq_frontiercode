import { z } from "zod";

import { PromotionType } from "@libs/types/promotion";

export const MAX_ACCOUNT_IDS_PER_REQUEST = 100;

export const getAccountsPromotionsRequestSchema = z.object({
    credit_account_ids: z.array(z.string().min(1)).min(1).max(MAX_ACCOUNT_IDS_PER_REQUEST),
    promotion_type: z.nativeEnum(PromotionType).optional(),
});

export type GetAccountsPromotionsRequest = z.infer<typeof getAccountsPromotionsRequestSchema>;
