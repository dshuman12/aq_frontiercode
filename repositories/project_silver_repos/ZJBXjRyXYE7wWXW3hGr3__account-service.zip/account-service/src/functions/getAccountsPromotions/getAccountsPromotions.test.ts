import { test, expect, beforeAll, afterAll } from "vitest";
import { fetchAPISecret } from "@utils/testUtils";
import {
    generateTestCreditAccountId,
    seedPromotion,
    teardownSeededPromotions,
} from "@utils/testUtils/promotion.testUtils";
import {
    NotificationStatus,
    PromotionRecord,
    PromotionStatus,
    PromotionType,
} from "@libs/types/promotion";
import { MAX_ACCOUNT_IDS_PER_REQUEST } from "./types";

let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string;

const invokeGetAccountsPromotions = async (
    body: unknown,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const url = `https://${internal_api_domain}/service/accounts/next/promotions/batch-get`;
    return await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(body),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

afterAll(teardownSeededPromotions);

test("no api key returns 401", async () => {
    const response = await invokeGetAccountsPromotions({}, apiKey, false);

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});

test("invalid api key returns 401", async () => {
    const response = await invokeGetAccountsPromotions({}, "invalid-key", true);

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});

test("empty body returns 400", async () => {
    const response = await invokeGetAccountsPromotions({});

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid request body" });
});

test("empty credit_account_ids array returns 400", async () => {
    const response = await invokeGetAccountsPromotions({ credit_account_ids: [] });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid request body" });
});

test(`more than ${MAX_ACCOUNT_IDS_PER_REQUEST} account ids returns 400`, async () => {
    const credit_account_ids = Array.from(
        { length: MAX_ACCOUNT_IDS_PER_REQUEST + 1 },
        (_, i) => `ACC-${i}`,
    );
    const response = await invokeGetAccountsPromotions({ credit_account_ids });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid request body" });
});

test("unknown account ids return 200 with empty array", async () => {
    const response = await invokeGetAccountsPromotions({
        credit_account_ids: [generateTestCreditAccountId(), generateTestCreditAccountId()],
    });

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ promotions: [] });
});

type PromotionsResponse = { promotions: PromotionRecord[] };

test("happy path: returns seeded promotion with full record shape", async () => {
    const seed = await seedPromotion();

    const response = await invokeGetAccountsPromotions({
        credit_account_ids: [seed.credit_account_id],
    });

    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as PromotionsResponse;
    expect(responseBody.promotions).toHaveLength(1);
    expect(responseBody.promotions[0]).toMatchObject({
        onmouuid: seed.onmouuid,
        credit_account_id: seed.credit_account_id,
        promotion_id: `${PromotionType.HONEYMOON}#${seed.start_date}`,
        promotion_type: PromotionType.HONEYMOON,
        promotional_interest_rate: seed.promotional_interest_rate,
        original_interest_rate: seed.original_interest_rate,
        original_apr: seed.original_apr,
        status: PromotionStatus.ACTIVE,
        notification_status: NotificationStatus.PENDING,
        start_date: seed.start_date,
        end_date: seed.end_date,
        version: 1,
    });
});

test("returns promotions for multiple accounts in one request", async () => {
    const seedA = await seedPromotion();
    const seedB = await seedPromotion();

    const response = await invokeGetAccountsPromotions({
        credit_account_ids: [seedA.credit_account_id, seedB.credit_account_id],
    });

    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as PromotionsResponse;
    const returnedAccountIds = responseBody.promotions.map((p) => p.credit_account_id).sort();
    expect(returnedAccountIds).toEqual([seedA.credit_account_id, seedB.credit_account_id].sort());
});

test("unknown accounts mixed with known are silently skipped", async () => {
    const seed = await seedPromotion();

    const response = await invokeGetAccountsPromotions({
        credit_account_ids: [
            seed.credit_account_id,
            generateTestCreditAccountId(),
            generateTestCreditAccountId(),
        ],
    });

    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as PromotionsResponse;
    expect(responseBody.promotions).toHaveLength(1);
    expect(responseBody.promotions[0].credit_account_id).toBe(seed.credit_account_id);
});

test("duplicate credit_account_ids are deduped in response", async () => {
    const seed = await seedPromotion();

    const response = await invokeGetAccountsPromotions({
        credit_account_ids: [seed.credit_account_id, seed.credit_account_id],
    });

    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as PromotionsResponse;
    expect(responseBody.promotions).toHaveLength(1);
    expect(responseBody.promotions[0].credit_account_id).toBe(seed.credit_account_id);
});
