import { APIGatewayProxyEvent, apiResponse, createApiHandler } from "@onmoapp/handler-middleware";
import { logger } from "@onmoapp/logger";

import { PromotionService } from "@services/promotion";
import { getAccountsPromotionsRequestSchema } from "./types";

export const getAccountsPromotionsHandler = async (event: APIGatewayProxyEvent) => {
    const parsed = getAccountsPromotionsRequestSchema.safeParse(
        event.body ? JSON.parse(event.body) : {},
    );

    if (!parsed.success) {
        logger.addContext("validation_errors", parsed.error.issues);
        return apiResponse(400, { message: "Invalid request body" });
    }

    const { credit_account_ids, promotion_type } = parsed.data;
    logger.addContext("account_count", credit_account_ids.length);
    if (promotion_type) logger.addContext("promotion_type_filter", promotion_type);

    const service = PromotionService.getInstance();
    const result = await service.getForAccounts(credit_account_ids, promotion_type);

    if (!result.ok) {
        logger.addContext("error_code", result.error.code);
        logger.addContext("error", result.error.message);
        return apiResponse(500, { message: "Something went wrong" });
    }

    logger.addContext("promotion_count", result.data.length);
    return apiResponse(200, { promotions: result.data });
};

export const handler = createApiHandler<APIGatewayProxyEvent>(__HANDLER_NAME__).handle(
    getAccountsPromotionsHandler,
);
