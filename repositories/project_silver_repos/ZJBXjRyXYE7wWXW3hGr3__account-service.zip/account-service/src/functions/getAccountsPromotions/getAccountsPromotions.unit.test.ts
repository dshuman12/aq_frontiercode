import { describe, expect, test, vi, beforeEach } from "vitest";
import { APIGatewayProxyEvent } from "@onmoapp/handler-middleware";

import { getAccountsPromotionsHandler } from "./getAccountsPromotions";
import { PromotionService } from "@services/promotion";
import { PromotionErrorCode, PromotionType } from "@libs/types/promotion";
import { Success, Failure } from "@libs/types/result";
import { logger } from "@onmoapp/logger";
import { MAX_ACCOUNT_IDS_PER_REQUEST } from "./types";
import { makePromotionRecord } from "@utils/testUtils/promotionFixtures";

vi.mock("@services/promotion", () => ({
    PromotionService: {
        getInstance: vi.fn(),
    },
}));

vi.mock("@onmoapp/logger", () => ({
    logger: {
        addContext: vi.fn(),
        error: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
    },
}));

const makeEvent = (body: unknown): APIGatewayProxyEvent =>
    ({ body: body === undefined ? null : JSON.stringify(body) }) as APIGatewayProxyEvent;

describe("getAccountsPromotions", () => {
    let mockGetForAccounts: ReturnType<typeof vi.fn>;

    beforeEach(() => {
        vi.clearAllMocks();
        mockGetForAccounts = vi.fn();
        vi.mocked(PromotionService.getInstance).mockReturnValue({
            getForAccounts: mockGetForAccounts,
        } as any);
    });

    test("200 returns the service's records under `promotions`", async () => {
        const records = [
            makePromotionRecord({ credit_account_id: "ACC-001" }),
            makePromotionRecord({
                credit_account_id: "ACC-002",
                promotion_id: "HONEYMOON#1710000000",
                start_date: 1710000000,
            }),
        ];
        mockGetForAccounts.mockResolvedValue(Success(records));

        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: ["ACC-001", "ACC-002"] }),
        );

        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ promotions: records });
        expect(mockGetForAccounts).toHaveBeenCalledWith(["ACC-001", "ACC-002"], undefined);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("account_count", 2);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("promotion_count", 2);
    });

    test("200 passes promotion_type filter through to the service", async () => {
        mockGetForAccounts.mockResolvedValue(Success([]));

        const response = await getAccountsPromotionsHandler(
            makeEvent({
                credit_account_ids: ["ACC-001"],
                promotion_type: PromotionType.HONEYMOON,
            }),
        );

        expect(response.statusCode).toBe(200);
        expect(mockGetForAccounts).toHaveBeenCalledWith(["ACC-001"], PromotionType.HONEYMOON);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "promotion_type_filter",
            PromotionType.HONEYMOON,
        );
    });

    test("400 when promotion_type is not a known enum value", async () => {
        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: ["ACC-001"], promotion_type: "NOT_A_TYPE" }),
        );

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("200 with empty array when no promotions found", async () => {
        mockGetForAccounts.mockResolvedValue(Success([]));

        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: ["ACC-999"] }),
        );

        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ promotions: [] });
    });

    test("400 on empty body", async () => {
        const response = await getAccountsPromotionsHandler(makeEvent(undefined));

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("400 when credit_account_ids missing", async () => {
        const response = await getAccountsPromotionsHandler(makeEvent({}));

        expect(response.statusCode).toBe(400);
        expect(response.body).toEqual({ message: "Invalid request body" });
        expect(mockGetForAccounts).not.toHaveBeenCalled();
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "validation_errors",
            expect.any(Array),
        );
    });

    test("400 when credit_account_ids is empty array", async () => {
        const response = await getAccountsPromotionsHandler(makeEvent({ credit_account_ids: [] }));

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("400 when credit_account_ids exceeds max entries", async () => {
        const tooMany = Array.from(
            { length: MAX_ACCOUNT_IDS_PER_REQUEST + 1 },
            (_, i) => `ACC-${i + 1}`,
        );

        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: tooMany }),
        );

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("400 when credit_account_ids contains empty string", async () => {
        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: ["ACC-001", ""] }),
        );

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("400 when credit_account_ids is wrong type", async () => {
        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: "ACC-001" }),
        );

        expect(response.statusCode).toBe(400);
        expect(mockGetForAccounts).not.toHaveBeenCalled();
    });

    test("500 on service failure", async () => {
        mockGetForAccounts.mockResolvedValue(
            Failure({
                code: PromotionErrorCode.QUERY_FAILED,
                message: "Failed to query promotions",
            }),
        );

        const response = await getAccountsPromotionsHandler(
            makeEvent({ credit_account_ids: ["ACC-001"] }),
        );

        expect(response.statusCode).toBe(500);
        expect(response.body).toEqual({ message: "Something went wrong" });
    });
});
