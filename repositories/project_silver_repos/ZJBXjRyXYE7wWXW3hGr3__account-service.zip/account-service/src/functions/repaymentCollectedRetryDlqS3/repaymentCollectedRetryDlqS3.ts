import { REPAYMENT_COLLECTED_ARCHIVED_BUCKET_FOLDER } from "@libs/constants";
import { KinesisDlqData } from "@libs/types";

import { Logger } from "@onmoapp/onmo-logger";
import { getLogger } from "@utils/logger";
import { formatErrorMessage } from "@utils/onmoErrorHandler";
import { uploadToS3 } from "@utils/s3Util";
import { deleteMessageFromQueue } from "@utils/sqsUtil";
import { SQSEvent, SQSRecord } from "aws-lambda";
import dayjs from "dayjs";

export const archiveAndDeleteMessage = async ({
    record,
    queueUrl,
    folder,
    bucket,
    logger,
}: {
    record: SQSRecord;
    queueUrl: string;
    bucket: string;
    folder: string;
    logger: Logger;
}) => {
    const kinesisFailedEvent = JSON.parse(record.body) as KinesisDlqData;
    logger.info({ message: "Processing message", kinesisFailedEvent });

    const repaymentCollected = kinesisFailedEvent.eventData.eventData;

    const date = dayjs(
        kinesisFailedEvent.metaData.KinesisBatchInfo.approximateArrivalOfFirstRecord,
    );

    const path = `${folder}/${date.get("year")}/${("0" + String(date.get("month") + 1)).slice(-2)}/${("0" + String(date.get("date"))).slice(-2)}/${("0" + String(date.get("hour"))).slice(-2)}/${kinesisFailedEvent.metaData.KinesisBatchInfo.shardId}/${date.format("YYYYMMDDHHMMss")}_${kinesisFailedEvent.metaData.KinesisBatchInfo.startSequenceNumber}.json`;
    logger.info({ mesage: "Uploading to S3", path, bucket });

    await uploadToS3({
        data: Buffer.from(JSON.stringify(kinesisFailedEvent)),
        key: path,
        bucket,
    });

    logger.warn(
        `Alert_RepaymentCollected: Could not process repayment: ${repaymentCollected.repayment.paymentMethod} ${repaymentCollected.repayment.externalId} for account ${repaymentCollected.accountId} - date ${repaymentCollected.date}`,
    );

    // Delete the message
    try {
        await deleteMessageFromQueue({
            queueUrl,
            receiptHandle: record.receiptHandle,
        });
    } catch (error) {
        const errorMessage = formatErrorMessage(error);
        logger.error({
            errorMessage,
            error,
            record,
        });
        throw new Error(
            "Some error has occured while processing the records. Please check the logs for more details.",
        );
    }
};

export const handler = async (event: SQSEvent) => {
    const logger = getLogger();
    logger.addContext({ functionName: "repaymentCollectedRetryDlqS3" });
    logger.info({ message: "Message reveived", event });

    const promises = event.Records.map((record) =>
        archiveAndDeleteMessage({
            bucket: process.env.ARCHIVED_S3_BUCKET_NAME,
            folder: REPAYMENT_COLLECTED_ARCHIVED_BUCKET_FOLDER,
            logger,
            queueUrl: process.env.REPAYMENT_COLLECTED_RETRY_DLQ_URL,
            record,
        }),
    );

    await Promise.all(promises);
};
