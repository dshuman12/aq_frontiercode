import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { getLogger } from "@utils/logger";
import { processRepayment } from "@libs/processRepayment";
import { SQSEvent, SQSRecord } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";
import { formatErrorMessage } from "@utils/onmoErrorHandler";
import { KinesisDlqData } from "@libs/types";
dayjs.extend(customParseFormat);

type ProcessRepaymentOutcome = {
    success?: boolean;
    error?: {
        message: string;
        sqsMessageId: string;
    };
};

const processMessage = async ({
    record,
    logger,
}: {
    record: SQSRecord;
    logger: Logger;
}): Promise<ProcessRepaymentOutcome> => {
    try {
        const event = JSON.parse(record.body) as KinesisDlqData;
        await processRepayment(event.eventData, logger);
        return { success: true };
    } catch (e) {
        logger.error({ message: formatErrorMessage(e), sqsMessageId: record.messageId, record });
        throw e;
    }
};

export const handler = async (event: SQSEvent) => {
    const logger = getLogger();
    logger.addContext({ functionName: "retryRepaymentCollected" });

    const promises = event.Records.map(async (record) => processMessage({ record, logger }));
    logger.info({ message: `Processing ${event.Records.length} records` });
    await Promise.all(promises);
};
