import { z } from "zod";

import { PromotionType } from "@libs/types/promotion";

export const createPromotionRequestSchema = z
    .object({
        onmouuid: z.string().uuid(),
        credit_account_id: z.string().min(1),
        promotion_type: z.nativeEnum(PromotionType),
        promotional_interest_rate: z.number().nonnegative(),
        original_interest_rate: z.number().nonnegative(),
        original_apr: z.number().nonnegative(),
        start_date: z.number().int().positive(),
        end_date: z.number().int().positive(),
    })
    .refine((data) => data.end_date > data.start_date, {
        message: "end_date must be after start_date",
        path: ["end_date"],
    });

export type CreatePromotionRequest = z.infer<typeof createPromotionRequestSchema>;
