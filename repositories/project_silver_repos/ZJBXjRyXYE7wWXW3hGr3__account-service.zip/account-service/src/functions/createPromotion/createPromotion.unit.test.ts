import { describe, expect, test, vi, beforeEach } from "vitest";
import { APIGatewayProxyEvent } from "@onmoapp/handler-middleware";

import { handler, createPromotionHandler } from "./createPromotion";
import { PromotionService } from "@services/promotion";
import { PromotionType, PromotionErrorCode } from "@libs/types/promotion";
import { Success, Failure } from "@libs/types/result";
import { logger } from "@onmoapp/logger";

vi.mock("@services/promotion", () => ({
    PromotionService: {
        getInstance: vi.fn(),
    },
}));

vi.mock("@onmoapp/logger", () => ({
    logger: {
        addContext: vi.fn(),
        error: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
    },
}));

const validBody = {
    onmouuid: "11111111-1111-1111-1111-111111111111",
    credit_account_id: "ACC-001",
    promotion_type: PromotionType.HONEYMOON,
    promotional_interest_rate: 0,
    original_interest_rate: 5.5,
    original_apr: 6.1,
    start_date: 1700000000,
    end_date: 1703000000,
};

const makeEvent = (body: unknown): APIGatewayProxyEvent =>
    ({ body: body === undefined ? null : JSON.stringify(body) }) as APIGatewayProxyEvent;

describe("createPromotion", () => {
    let mockCreate: ReturnType<typeof vi.fn>;

    beforeEach(() => {
        vi.clearAllMocks();
        mockCreate = vi.fn();
        vi.mocked(PromotionService.getInstance).mockReturnValue({
            create: mockCreate,
        } as any);
    });

    test("handler is a function", () => {
        expect(typeof handler).toBe("function");
    });

    test("201 on successful create", async () => {
        mockCreate.mockResolvedValue(Success({ promotion_id: "HONEYMOON#1700000000" }));

        const response = await createPromotionHandler(makeEvent(validBody));

        expect(response.statusCode).toBe(201);
        expect(response.body).toEqual({ promotion_id: "HONEYMOON#1700000000" });
        expect(mockCreate).toHaveBeenCalledWith(validBody);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "promotion_id",
            "HONEYMOON#1700000000",
        );
    });

    test("409 when promotion already exists", async () => {
        mockCreate.mockResolvedValue(
            Failure({
                code: PromotionErrorCode.ALREADY_EXISTS,
                message: "Promotion already exists for account ACC-001",
            }),
        );

        const response = await createPromotionHandler(makeEvent(validBody));

        expect(response.statusCode).toBe(409);
        expect(response.body).toEqual({
            message: "Promotion already exists",
        });
    });

    test("500 on generic service failure", async () => {
        mockCreate.mockResolvedValue(
            Failure({
                code: PromotionErrorCode.WRITE_FAILED,
                message: "Failed to create promotion for account ACC-001",
            }),
        );

        const response = await createPromotionHandler(makeEvent(validBody));

        expect(response.statusCode).toBe(500);
        expect(response.body).toEqual({ message: "Something went wrong" });
    });

    test("400 on invalid body — missing field", async () => {
        const { onmouuid, ...invalid } = validBody;

        const response = await createPromotionHandler(makeEvent(invalid));

        expect(response.statusCode).toBe(400);
        expect(mockCreate).not.toHaveBeenCalled();
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "validation_errors",
            expect.any(Array),
        );
    });

    test("400 on invalid body — wrong type", async () => {
        const response = await createPromotionHandler(
            makeEvent({ ...validBody, promotional_interest_rate: "zero" }),
        );

        expect(response.statusCode).toBe(400);
        expect(mockCreate).not.toHaveBeenCalled();
    });

    test("400 when end_date <= start_date", async () => {
        const response = await createPromotionHandler(
            makeEvent({ ...validBody, end_date: validBody.start_date }),
        );

        expect(response.statusCode).toBe(400);
        expect(response.body).toEqual({ message: "Invalid request body" });
        expect(mockCreate).not.toHaveBeenCalled();
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "validation_errors",
            expect.arrayContaining([
                expect.objectContaining({ message: "end_date must be after start_date" }),
            ]),
        );
    });

    test("400 on empty body", async () => {
        const response = await createPromotionHandler(makeEvent(undefined));

        expect(response.statusCode).toBe(400);
        expect(mockCreate).not.toHaveBeenCalled();
    });
});
