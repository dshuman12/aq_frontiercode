import { randomUUID } from "crypto";
import { test, expect, beforeAll, afterAll } from "vitest";
import { fetchAPISecret } from "@utils/testUtils";
import {
    generateTestCreditAccountId,
    getPromotionRecord,
    teardownSeededPromotions,
    trackPromotionForCleanup,
} from "@utils/testUtils/promotion.testUtils";
import { NotificationStatus, PromotionStatus, PromotionType } from "@libs/types/promotion";

let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string;

type CreatePromotionBody = {
    onmouuid: string;
    credit_account_id: string;
    promotion_type: PromotionType;
    promotional_interest_rate: number;
    original_interest_rate: number;
    original_apr: number;
    start_date: number;
    end_date: number;
};

const makeValidBody = (overrides: Partial<CreatePromotionBody> = {}): CreatePromotionBody => {
    const start_date = overrides.start_date ?? 1_700_000_000;
    return {
        onmouuid: randomUUID(),
        credit_account_id: generateTestCreditAccountId(),
        promotion_type: PromotionType.HONEYMOON,
        promotional_interest_rate: 0,
        original_interest_rate: 22.5,
        original_apr: 24.9,
        start_date,
        end_date: start_date + 90 * 24 * 3600,
        ...overrides,
    };
};

const invokeCreatePromotion = async (
    body: unknown,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const url = `https://${internal_api_domain}/service/accounts/next/promotions`;
    return await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(body),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

afterAll(teardownSeededPromotions);

test("no api key returns 401", async () => {
    const response = await invokeCreatePromotion({}, apiKey, false);

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});

test("invalid api key returns 401", async () => {
    const response = await invokeCreatePromotion({}, "invalid-key", true);

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});

test("valid api key with empty body returns 400", async () => {
    const response = await invokeCreatePromotion({});

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid request body" });
});

test("end_date <= start_date returns 400", async () => {
    const body = makeValidBody();
    const response = await invokeCreatePromotion({ ...body, end_date: body.start_date });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid request body" });
});

test("happy path: valid body returns 201 and writes row to DynamoDB", async () => {
    const body = makeValidBody();
    trackPromotionForCleanup(body.credit_account_id, body.promotion_type, body.start_date);

    const response = await invokeCreatePromotion(body);

    expect(response.status).toBe(201);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        promotion_id: `${PromotionType.HONEYMOON}#${body.start_date}`,
    });

    const record = await getPromotionRecord(
        body.credit_account_id,
        body.promotion_type,
        body.start_date,
    );
    expect(record).toMatchObject({
        onmouuid: body.onmouuid,
        credit_account_id: body.credit_account_id,
        promotion_id: `${PromotionType.HONEYMOON}#${body.start_date}`,
        promotion_type: PromotionType.HONEYMOON,
        promotional_interest_rate: body.promotional_interest_rate,
        original_interest_rate: body.original_interest_rate,
        original_apr: body.original_apr,
        status: PromotionStatus.ACTIVE,
        notification_status: NotificationStatus.PENDING,
        start_date: body.start_date,
        end_date: body.end_date,
        version: 1,
    });
});

test("same (account, type, start_date) returns 409 on second POST", async () => {
    const body = makeValidBody();
    trackPromotionForCleanup(body.credit_account_id, body.promotion_type, body.start_date);

    const first = await invokeCreatePromotion(body);
    expect(first.status).toBe(201);

    const second = await invokeCreatePromotion(body);
    expect(second.status).toBe(409);
    const responseBody = await second.json();
    expect(responseBody).toEqual({ message: "Promotion already exists" });
});
