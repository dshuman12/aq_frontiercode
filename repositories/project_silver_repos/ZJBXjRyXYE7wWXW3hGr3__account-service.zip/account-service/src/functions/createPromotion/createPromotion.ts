import { APIGatewayProxyEvent, apiResponse, createApiHandler } from "@onmoapp/handler-middleware";
import { logger } from "@onmoapp/logger";

import { PromotionService } from "@services/promotion";
import { PromotionErrorCode } from "@libs/types/promotion";
import { createPromotionRequestSchema } from "./types";

export const createPromotionHandler = async (event: APIGatewayProxyEvent) => {
    const parsed = createPromotionRequestSchema.safeParse(event.body ? JSON.parse(event.body) : {});

    if (!parsed.success) {
        logger.addContext("validation_errors", parsed.error.issues);
        return apiResponse(400, { message: "Invalid request body" });
    }

    const input = {
        onmouuid: parsed.data.onmouuid!,
        credit_account_id: parsed.data.credit_account_id!,
        promotion_type: parsed.data.promotion_type!,
        promotional_interest_rate: parsed.data.promotional_interest_rate!,
        original_interest_rate: parsed.data.original_interest_rate!,
        original_apr: parsed.data.original_apr!,
        start_date: parsed.data.start_date!,
        end_date: parsed.data.end_date!,
    };

    logger.addContext("onmouuid", input.onmouuid);
    logger.addContext("credit_account_id", input.credit_account_id);
    logger.addContext("promotion_type", input.promotion_type);

    const service = PromotionService.getInstance();
    const result = await service.create(input);

    if (!result.ok) {
        logger.addContext("error_code", result.error.code);
        logger.addContext("error", result.error.message);
        if (result.error.code === PromotionErrorCode.ALREADY_EXISTS) {
            return apiResponse(409, { message: "Promotion already exists" });
        }
        return apiResponse(500, { message: "Something went wrong" });
    }

    logger.addContext("promotion_id", result.data.promotion_id);
    return apiResponse(201, { promotion_id: result.data.promotion_id });
};

export const handler =
    createApiHandler<APIGatewayProxyEvent>(__HANDLER_NAME__).handle(createPromotionHandler);
