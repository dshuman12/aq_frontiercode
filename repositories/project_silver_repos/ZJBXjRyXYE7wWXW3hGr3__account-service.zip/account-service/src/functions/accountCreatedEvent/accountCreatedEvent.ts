import { LambdaClient, InvokeCommand, InvokeCommandInput } from "@aws-sdk/client-lambda";
import { formatJSONResponse } from "@libs/api-gateway";
import { AccountCreatedRequestBody } from "@libs/types";
import { getCoreBankingAdapter } from "src/adapters";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { Logger } from "@onmoapp/onmo-logger";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { queryTableMethod } from "@onmoapp/onmo-dynamodb";
import { deleteMessage } from "@onmoapp/onmo-sqs";

export const handler = async (event: any) => {
    const logger = new Logger({ env: process.env.Environment });
    try {
        const parsedRequestBody: AccountCreatedRequestBody = JSON.parse(event.Records[0].body);
        logger.info(`Received request body: ${JSON.stringify(parsedRequestBody)}`);

        const { technicalAccountId, customerId } = parsedRequestBody;

        if (!technicalAccountId || !customerId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "Missing required fields in request body",
            });
        }

        logger.addContext({ technicalAccountId, customerId });
        logger.info(`Got required fields from request body`);

        const queryMobileTableRes = await queryTableMethod({
            TableName: process.env.USER_TABLE,
            KeyConditionExpression: "onmouuid = :customerId",
            ExpressionAttributeValues: { ":customerId": customerId },
        });

        if (!queryMobileTableRes.Items || queryMobileTableRes.Items.length <= 0) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "user doesn't exist in the mobile table",
            });
        }
        logger.info(`User has record in ${process.env.USER_TABLE} table`);

        const creditAccountId = queryMobileTableRes?.Items[0].mambuCreditCardAccountID;

        // Build Promises
        const coreBankingAdapter = await getCoreBankingAdapter();
        const creditAccountPromise = coreBankingAdapter.getCreditAccount(creditAccountId);
        const technicalAccountPromise = coreBankingAdapter.getTechnicalAccount(technicalAccountId);
        const [creditAccountRes, technicalAccountRes] = await Promise.all([
            creditAccountPromise,
            technicalAccountPromise,
        ]);

        throwErrorIfAdapterResHaveError(creditAccountRes, {
            message: "Failed to get credit account details",
        });

        throwErrorIfAdapterResHaveError(technicalAccountRes, {
            message: "Failed to get technical account details",
        });

        const client = new LambdaClient({ region: process.env.REGION });

        // Trigger the CustomerUpserted lambda function
        const CustomerUpsertedEventData = {
            customerId: customerId,
        };
        const customerParams: InvokeCommandInput = {
            FunctionName: `${process.env.ENVIRONMENT}-customer-service-customerUpsertedEvent:next`,
            InvocationType: "RequestResponse",
            Payload: JSON.stringify({ body: CustomerUpsertedEventData }),
        };
        const customerCommand = new InvokeCommand(customerParams);
        const customerResponse = await client.send(customerCommand);

        logger.debug(customerResponse);
        if (customerResponse.StatusCode !== 200) {
            logger.error("Error in CustomerUpserted lambda function");
            throw new OnmoError({
                name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
                message: "Error in CustomerUpserted lambda function",
            });
        }
        logger.info("CustomerUpserted lambda function triggered successfully");

        // Trigger the AccountUpserted lambda function
        const AccountUpsertedEventData = {
            customerId: customerId,
            accountId: creditAccountRes?.data?.accountDetails?.accountId,
            state: creditAccountRes?.data?.accountDetails?.state,
        };

        const accountParams: InvokeCommandInput = {
            FunctionName: `${process.env.ENVIRONMENT}-${process.env.SERVICE_NAME}-accountUpsertedEvent:next`,
            InvocationType: "RequestResponse",
            Payload: JSON.stringify({ body: AccountUpsertedEventData }),
        };

        const accountCommand = new InvokeCommand(accountParams);
        const accountResponse = await client.send(accountCommand);

        logger.debug(accountResponse);
        if (accountResponse.StatusCode !== 200) {
            logger.error("Error in AccountUpserted lambda function");
            throw new OnmoError({
                name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
                message: "Error in AccountUpserted lambda function",
            });
        }
        logger.info("AccountUpserted lambda function triggered successfully");

        const deleteMsgResponse = await deleteMessage({
            QueueUrl: process.env.ACCOUNT_CREATED_EVENT_QUEUE,
            ReceiptHandle: event.Records[0].receiptHandle,
        });

        logger.info("Message successfuly deleted from SQS queue");
        logger.debug(deleteMsgResponse);

        logger.info("Events published successfully");
        return formatJSONResponse(200, {
            message: "Events published successfully",
        });
    } catch (error) {
        logger.error(error);
        throw new OnmoError({
            name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
            message: "Internal Server Error",
        });
    }
};
