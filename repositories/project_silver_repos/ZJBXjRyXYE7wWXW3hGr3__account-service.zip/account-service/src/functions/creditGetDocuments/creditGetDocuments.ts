import { APIGatewayEvent } from "aws-lambda";
import { formatJSONResponse } from "@libs/api-gateway";
import { getDocumentManagementAdapter } from "src/adapters";
import { sortByDate, indexDocumentsByYearAndMonth, emptyDocsPromise } from "@utils/util";
import { paginationLogic } from "@utils/pagination";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { checkValidation } from "@validators/index";
import { pathParametersSchema, queryParametersSchema } from "@validators/document.validator";
import { Logger } from "@onmoapp/onmo-logger";
import { checkAccess } from "@utils/oidc-authorization";

/**
 * Handles the API Gateway event for getting documents of an account.
 *
 * @param {APIGatewayEvent} event - The API Gateway event object containing the request information.
 * @returns {Promise<APIGatewayProxyResult>} - A Promise that resolves to the API Gateway response object.
 */
export const handler = async (event: APIGatewayEvent) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        // Validate the path parameters against the provided schema and extract the 'accountId'.
        const { accountId } = checkValidation(pathParametersSchema, event.pathParameters ?? {});
        logger.addContext({ accountId });

        /** will check access of user if request is from onmo api url */
        await checkAccess(event.requestContext, accountId);

        // Validate the query parameters against the provided schema and extract details.
        const { documentType, periodFrom, count, documentCursor } = checkValidation(
            queryParametersSchema,
            event.queryStringParameters ?? {},
        );

        const documentManagementAdapter = await getDocumentManagementAdapter();
        const [statementsDocs, contractsDocs] = await Promise.all([
            ["statements", "all"].includes(documentType)
                ? documentManagementAdapter.getDocumentsOfAccount({
                      accountId,
                      documentType: "statements",
                      accountType: "credit",
                  })
                : emptyDocsPromise,
            ["contracts", "all"].includes(documentType)
                ? documentManagementAdapter.getDocumentsOfAccount({
                      accountId,
                      documentType: "contracts",
                      accountType: "credit",
                  })
                : emptyDocsPromise,
        ]);

        if (!statementsDocs || statementsDocs.error || !contractsDocs || contractsDocs.error) {
            throw new OnmoError({
                name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
                message: "Failed to get documents from S3",
                cause: statementsDocs?.error ?? contractsDocs?.error,
            });
        }
        // return sorted documents in descending order
        const sortedDocs = sortByDate(
            [...(statementsDocs?.data?.documents ?? []), ...(contractsDocs?.data?.documents ?? [])],
            "desc",
        );

        // assigning id to all documents in indexedDocs and make index for all documents in YYYYMM format
        const { indexedDocs: DocsWithId, docIndex } = indexDocumentsByYearAndMonth(sortedDocs);

        // apply pagination logic for filtering based on periodFrom and documentCursor in descending order
        const { documents, nextDocumentCursor, nextPeriodFrom } = paginationLogic(
            DocsWithId,
            docIndex,
            periodFrom,
            Number(count),
            Number(documentCursor),
            "desc",
        );
        return formatJSONResponse(200, {
            documents,
            nextPeriodFrom,
            documentCursor: nextDocumentCursor,
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
