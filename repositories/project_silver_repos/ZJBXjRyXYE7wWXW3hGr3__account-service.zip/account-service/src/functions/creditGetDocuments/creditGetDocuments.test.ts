import { test, expect, beforeAll, beforeEach, afterEach } from "vitest";
import { DocumentType } from "@onmoapp/onmo-types";
import dayjs from "dayjs";
import {
    queryParams,
    buildQueryString,
    fetchAPISecret,
    generateRandomDates,
    setUpTestAccount,
    uploadTestContractsForCustomer,
    generateMonthlyDates,
    uploadTestStatementsForCustomer,
    tearDownTestAccount,
    UserCredentials,
} from "@utils/testUtils";
import { DocumentsRes } from "@libs/types";

let userCreds: UserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetAccountDocuments = async (
    accountId: string,
    documentType: DocumentType | "all",
    queryParams: queryParams,
    apiKeyValue = apiKey,
) => {
    const queryString = buildQueryString({
        documentType,
        ...queryParams,
    });
    const get_documents_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/documents?${queryString}`;

    return await fetch(get_documents_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKeyValue,
            "x-api-test-secret": api_test_secret,
        },
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

beforeEach(async () => {
    userCreds = await setUpTestAccount();
});

afterEach(async () => {
    await tearDownTestAccount(userCreds.customerId);
});

test("happy path - should return empty array of document if no documents were found", async () => {
    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {});
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.length).toEqual(0);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because no more documents are available
});

test("happy path - Get all User Contracts Documents", async () => {
    /** uploading contract documents */
    const contractsDates = generateRandomDates(20, new Date(2020, 0, 1), new Date());
    await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {
        count: String(contractsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${contractsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.at(0)).toHaveProperty("day");
    expect(body.documents.length).toEqual(contractsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
});

test("happy path - Get all User Statements Documents", async () => {
    /** uploading statement documents */
    const statementsDates = generateMonthlyDates(new Date(2020, 0, 1), new Date());
    await uploadTestStatementsForCustomer(userCreds.customerId, "credit", statementsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "statements", {
        count: String(statementsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${statementsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.length).toEqual(statementsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
});

test("happy path - Get all User credit Contracts Documents (should ignore debit contracts)", async () => {
    /** uploading contract documents for credit and debit accounts both*/
    const contractsDates = generateRandomDates(20, new Date(2020, 0, 1), new Date());
    await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);
    await uploadTestContractsForCustomer(userCreds.customerId, "debit", contractsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {
        count: String(contractsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${contractsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.at(0)).toHaveProperty("day");
    expect(body.documents.length).toEqual(contractsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
});

test("happy path - Get all User credit Statements Documents (should ignore debit statements)", async () => {
    /** uploading statement documents for credit and debit accounts both*/
    const statementsDates = generateMonthlyDates(new Date(2020, 0, 1), new Date());
    await uploadTestStatementsForCustomer(userCreds.customerId, "credit", statementsDates);
    await uploadTestStatementsForCustomer(userCreds.customerId, "debit", statementsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "statements", {
        count: String(statementsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${statementsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.length).toEqual(statementsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
});

test("happy path - Get all User Documents (contracts and statements)", async () => {
    /** uploading statement and contract documents for credit account */
    const statementsDates = generateMonthlyDates(new Date(2020, 0, 1), new Date());
    await uploadTestStatementsForCustomer(userCreds.customerId, "credit", statementsDates);
    const contractsDates = generateRandomDates(20, new Date(2020, 0, 1), new Date());
    await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "all", {
        count: String(statementsDates.length + contractsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toContain("testDoc");
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.length).toEqual(statementsDates.length + contractsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
});

test(
    "happy path - Get all User Documents (contracts and statements) recursively and should ignore debit documents",
    {
        timeout: 15000,
    },
    async () => {
        /** uploading statement and contract documents for credit and debit account both */
        const statementsDates = generateMonthlyDates(new Date(2020, 0, 1), new Date());
        await uploadTestStatementsForCustomer(userCreds.customerId, "credit", statementsDates);
        await uploadTestStatementsForCustomer(userCreds.customerId, "debit", statementsDates);
        const contractsDates = generateRandomDates(20, new Date(2020, 0, 1), new Date());
        await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);
        await uploadTestContractsForCustomer(userCreds.customerId, "debit", contractsDates);

        let documentCursor = 0;
        let periodFrom = dayjs().format("YYYYMM");
        let totalCount = 0;
        const count = 15; // number of documents we want for each API request
        /** recursive logic for Getting Account Documents using documentCursor and periodFrom */
        while (periodFrom !== "") {
            const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "all", {
                count: String(count),
                documentCursor: String(documentCursor),
                periodFrom,
            });
            const body = (await res.json()) as DocumentsRes;
            expect(res.status).toEqual(200);
            if (body.documentCursor === 0 && body.nextPeriodFrom === "") {
                expect(body.documents.length).lessThanOrEqual(count);
            } else {
                expect(body.documents.length).toEqual(count);
            }
            documentCursor = body.documentCursor;
            periodFrom = body.nextPeriodFrom;
            totalCount += body.documents.length;
        }

        expect(totalCount).toEqual(statementsDates.length + contractsDates.length);
    },
);

test("sad path - Get All Documents Validation Error for Documents Types", async () => {
    /** invoking Get account Documents API with wrong input */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "allll" as any, {
        count: "10",
        documentCursor: "0",
    }); // wrong document type
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("documentType must be one of [contracts, statements, all]"); // should empty because all documents are fetched
});

test("sad path - Get All Documents Validation Error invalid creditAccountId", async () => {
    /** invoking Get account Documents API with invalid AccountId */
    const res = await invokeGetAccountDocuments("AB", "all" as any, {
        count: "10",
        documentCursor: "0",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("accountId length must be at least 3 characters long"); // should empty because all documents are fetched
});

test("sad path - Get All Documents Validation Error invalid periodFrom value in query Parameters", async () => {
    /** invoking Get account Documents API with invalid periodFrom */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "all" as any, {
        count: "10",
        documentCursor: "0",
        periodFrom: "202314", // invalid period from
    });
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("please enter a valid periodFrom value"); // should empty because all documents are fetched
});

test("sad path - Account not Found", async () => {
    /** invoking Get account Documents API with AccountId Doesn't Exist */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId + "abc", "all" as any, {
        count: "10",
    });
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(404);
    expect(body.message).toEqual("Not Found"); // not found
});
