import { test, expect, beforeEach, afterEach } from "vitest";
import { DocumentType } from "@onmoapp/onmo-types";
import {
    queryParams,
    buildQueryString,
    setUpTestAccount,
    tearDownTestAccount,
    UserCredentials,
    generateAccessTokenOfTestUser,
    deleteAccessTokenOfTestUser,
} from "@utils/testUtils";
import { accessTokenObject, DocumentsRes, ErrorMessageResponse } from "@libs/types";

let userCreds: UserCredentials;
let accessToken: accessTokenObject;

const onmo_api_url = process.env.ONMO_API_URL as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetAccountDocuments = async (
    accountId: string,
    documentType: DocumentType | "all",
    queryParams: queryParams,
    token = accessToken.access_token,
) => {
    const queryString = buildQueryString({
        documentType,
        ...queryParams,
    });
    const get_documents_url = `https://${onmo_api_url}/service/accounts/next/credit/${accountId}/documents?${queryString}`;

    return await fetch(get_documents_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            "x-api-test-secret": api_test_secret,
        },
    });
};

beforeEach(async () => {
    userCreds = await setUpTestAccount();
    accessToken = await generateAccessTokenOfTestUser(userCreds.customerId);
});

afterEach(async () => {
    await tearDownTestAccount(userCreds.customerId);
    await deleteAccessTokenOfTestUser(userCreds.customerId, accessToken);
});

test("happy path - should return empty array of document if no documents were found", async () => {
    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {});
    const body = (await res.json()) as DocumentsRes;

    expect(res.status).toEqual(200);
    expect(body.documents.length).toEqual(0);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because no more documents are available
});

test("invalid Access Token", async () => {
    const response = await invokeGetAccountDocuments(
        userCreds.creditAccountId,
        "contracts",
        {},
        "INVALID_ACCESS_TOKEN",
    );
    expect(response.status).toBe(401);
});

test("trying to access any other's account's Documents should return 401 unauthorized access", async () => {
    const response = await invokeGetAccountDocuments("ABCD123", "contracts", {});

    expect(response.status).toBe(401);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("user is not authorized to access this account");
});
