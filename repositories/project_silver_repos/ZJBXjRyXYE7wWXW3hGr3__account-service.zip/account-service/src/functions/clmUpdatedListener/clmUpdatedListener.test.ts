import { describe, expect, test, vi } from "vitest";
import { handler } from "./clmUpdatedListener";
import testEvent from "./testevent.json";

import { getEventHubAdapter, EventData } from "src/adapters";
import { CLMPreferenceChangeEvent } from "@libs/types";
import { OnmoError } from "@onmoapp/onmo-error-types";
import { ClmUpdatedStreamEvent } from "./clmUpdatedListener";

vi.mock("src/adapters");

describe("clmUpdatedListener", () => {
    test("handler decodes event successfully", async () => {
        vi.mocked(getEventHubAdapter, { partial: true }).mockResolvedValue({
            publishToEventHub: vi.fn().mockResolvedValue({
                isValid: true,
                isPublished: true,
                validationErrors: {},
            }),
        });

        await handler(testEvent as unknown as ClmUpdatedStreamEvent);

        const eventHubMock = vi.mocked(getEventHubAdapter).mock.results[0].value;
        const call =
            eventHubMock.publishToEventHub.mock.lastCall.pop() as EventData<CLMPreferenceChangeEvent>;

        expect(call.eventData).toEqual({
            accountId: "XKLS281",
            customerId: "73883414-9588-447f-9f0e-eebb2215017d",
            optOut: false,
            autoApply: true,
        });
    });

    test("handler throws when event is malformed", async () => {
        const missingId = { ...testEvent } as unknown as ClmUpdatedStreamEvent;
        delete missingId.Records[0].dynamodb?.NewImage["loan_account_id"];

        await expect(() => handler({} as any)).rejects.toThrow(OnmoError);
        await expect(() => handler(missingId)).rejects.toThrow(OnmoError);
    });
});
