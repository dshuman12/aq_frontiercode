import { getLogger } from "@utils/logger";
import { DynamoDBStreams } from "aws-sdk";
import { getEventHubAdapter } from "src/adapters";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { CLMPreferenceChangeEvent } from "@libs/types";
import { EventData } from "@onmoapp/event-hub-kinesis-adapter";
import { v4 as uuid } from "uuid";
import { CLM_UPDATE_EVENT_INITIATED_BY } from "@libs/constants";

const logger = getLogger();

export interface ClmUpdatedStreamEvent {
    Records: DynamoDBStreams.Record[];
}

export const handler = async (event: ClmUpdatedStreamEvent) => {
    try {
        logger.info("CLM updated stream Event handler invoked");
        logger.removeContext();
        logger.info(event);

        if (event.Records === undefined || event.Records.length === 0) {
            throw new OnmoError({
                message: "payload missing records",
                name: "INPUT_VALIDATION_ERROR",
            });
        }

        const customerId = event.Records[0]?.dynamodb?.NewImage?.onmouuid?.S;
        const optOut = event.Records[0]?.dynamodb?.NewImage.opt_out?.BOOL || false;
        const autoApply = event.Records[0]?.dynamodb?.NewImage.auto_apply?.BOOL || false;
        const accountId = event.Records[0]?.dynamodb?.NewImage.loan_account_id?.S;

        const payload: CLMPreferenceChangeEvent = {
            accountId,
            customerId,
            optOut,
            autoApply,
        };

        logger.addContext({
            functionName: "clmUpdatedListener",
            customerId,
        });

        if (Object.values(payload).some((value) => value === undefined)) {
            throw new OnmoError({
                message: "failed populating payload",
                name: "INPUT_VALIDATION_ERROR",
            });
        }

        const id = uuid();

        const hubEvent: EventData<CLMPreferenceChangeEvent> = {
            id,
            schemaVersion: process.env.CLM_UPDATE_SCHEMA_VERSION,
            created: new Date().toISOString(),
            event: "CLMUpdated",
            subtype: null,
            idempotencyKey: id,
            correlationId: customerId,
            source: process.env.SERVICE_NAME, // source who publishes an event,
            initiatedBy: CLM_UPDATE_EVENT_INITIATED_BY,
            eventData: payload,
        };

        const eventHubAdapter = await getEventHubAdapter<CLMPreferenceChangeEvent>();

        const { isPublished, isValid, validationErrors } =
            await eventHubAdapter.publishToEventHub(hubEvent);

        logger.info({
            message: "Response from EventHub for publishing event",
            isPublished,
            isValid,
            validationErrors,
        });

        if (!isPublished || !isValid) {
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to publish Event to event hub",
                cause: validationErrors,
            });
        }
    } catch (error) {
        logger.error("Error handling CLM dynamodb stream event");
        logger.error(error?.message);
        throw error;
    }
};
