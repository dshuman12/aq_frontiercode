//TODO: api tests

import { test, expect } from "vitest";
test("test test", async () => {
    expect(true).toEqual(true);
});
