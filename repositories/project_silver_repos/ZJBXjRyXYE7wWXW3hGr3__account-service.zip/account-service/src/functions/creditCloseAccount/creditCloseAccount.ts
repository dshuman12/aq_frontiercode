import { getCoreBankingAdapter } from "src/adapters";
import { formatJSONResponse } from "@libs/api-gateway";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse, throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { Logger } from "@onmoapp/onmo-logger";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { closeAccountPayload } from "@libs/types";

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        // validate accountId is on path params
        const accountId: string = event.pathParameters?.accountId || {};
        const payload = parseAPIGateWayEventBody(event.body || "{}") as closeAccountPayload;

        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        if (typeof accountId !== "string") {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId should be of type string",
            });
        }
        logger.addContext({ accountId });
        logger.info("Got accountId from path parameters");

        // update account by calling adapter method
        const coreBankingAdapter = await getCoreBankingAdapter();
        const closeAccountResponse = await coreBankingAdapter.closeAccount(accountId, {
            notes: payload?.notes || "",
        });

        throwErrorIfAdapterResHaveError(closeAccountResponse, {
            message: "Failed to close account",
        });

        logger.info("Account closed and all cards voided");
        return formatJSONResponse(200, { message: "Account closed and all cards voided" });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error({ statusCode, message, debugMessage });
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
