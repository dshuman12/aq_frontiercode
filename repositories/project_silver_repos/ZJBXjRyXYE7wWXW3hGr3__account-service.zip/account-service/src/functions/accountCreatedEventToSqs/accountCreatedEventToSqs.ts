import { formatJSONResponse } from "@libs/api-gateway";
import { AccountCreatedRequestBody } from "@libs/types";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { Logger } from "@onmoapp/onmo-logger";
import { sendMessage } from "@onmoapp/onmo-sqs";

export const handler = async (event: any) => {
    const logger = new Logger({ env: process.env.Environment });
    try {
        const parsedRequestBody: AccountCreatedRequestBody = JSON.parse(event.body);
        logger.info(`Received request body: ${JSON.stringify(parsedRequestBody)}`);

        // Extract required fields from request body
        const { technicalAccountId, customerId } = parsedRequestBody;

        // Validate request body
        if (!technicalAccountId || !customerId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "Missing required fields in request body",
            });
        }

        logger.addContext({ technicalAccountId, customerId });
        logger.info(`Got required fields from request body`);

        // Prepare SQS body
        const sqsBody = {
            technicalAccountId,
            customerId,
        };

        // Publish event to SQS
        const sqsResponse = await sendMessage({
            MessageBody: JSON.stringify(sqsBody),
            QueueUrl: process.env.ACCOUNT_CREATED_EVENT_QUEUE,
        });

        // Check if event is published successfully
        if (sqsResponse.$metadata.httpStatusCode !== 200 || !sqsResponse.MessageId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
                message: "Error while publishing events to SQS",
            });
        }

        logger.debug({ sqsResponse });
        logger.info(`Published event to SQS`);

        return formatJSONResponse(200, {
            message: "Event successfully send to queue",
        });
    } catch (error) {
        logger.error(error);
        return formatJSONResponse(500, {
            body: JSON.stringify({ message: "Internal Server Error" }),
        });
    }
};
