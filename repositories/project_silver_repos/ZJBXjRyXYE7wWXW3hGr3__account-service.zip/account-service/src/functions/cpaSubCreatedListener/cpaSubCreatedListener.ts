import { getLogger } from "@utils/logger";
import { formatJSONResponse } from "@libs/api-gateway";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { CPASubscriptionCreatedEvent } from "@libs/types/eventHub-types";
import {
    getCoreBankingAdapter,
    getCoreRepaymentsAdapter,
    getSalesforceAdapter,
} from "src/adapters";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { sendMessage } from "@onmoapp/onmo-sqs";
import dayjs from "dayjs";

export const handler = async (event: any) => {
    const logger = getLogger();
    logger.addContext({ functionName: "cpaSubCreatedListener" });

    const cpaSubscriptionCreated =
        await deserializeKinesisEvent<CPASubscriptionCreatedEvent>(event);
    const { customerId, accountId, pspCustomerId, subscriptionDetails } =
        cpaSubscriptionCreated.eventData;
    logger.info({ message: "CPASubscriptionCreated received", cpaSubscriptionCreated });
    logger.addContext({ accountId, customerId });

    // Send SFMC comms
    const coreBankingAdapter = await getCoreBankingAdapter();
    const repaymentClient = await getCoreRepaymentsAdapter();
    const salesforceClient = await getSalesforceAdapter();

    const [crmCustomerDetails, coreBankingCustomer, creditAccountRes, subscriptionsResult] =
        await Promise.all([
            salesforceClient.getCrmCustomerDetailsByCustomerId(customerId),
            coreBankingAdapter.getCustomerByCustomerId(customerId),
            coreBankingAdapter.getCreditAccount(accountId),
            repaymentClient.getSubscriptionsByPsPCustomerId(pspCustomerId),
        ]);

    throwErrorIfAdapterResHaveError(crmCustomerDetails, {
        message: "Failed to get CRM customer details",
    });
    throwErrorIfAdapterResHaveError(coreBankingCustomer, {
        message: "Failed to get core banking customer details",
    });
    throwErrorIfAdapterResHaveError(creditAccountRes, {
        message: "Failed to get credit account details",
    });

    const activeSubscription = subscriptionsResult.subscriptions.find(
        (sub) => sub.subscriptionId === subscriptionDetails.subscriptionId,
    );
    const planEndDate = activeSubscription?.cancelAt
        ? dayjs.unix(activeSubscription.cancelAt).format("YYYY-MM-DD")
        : null;

    const commsEvent = {
        creative: "Email1",
        firstName: coreBankingCustomer.data.firstName.trim(),
        emailAddress: coreBankingCustomer.data.emailAddresses.primary,
        customerId,
        personContactId: crmCustomerDetails.data.contactId,
        paymentPlanDate: dayjs.unix(subscriptionDetails.currentPeriodEnd).format("YYYY-MM-DD"),
        planEndDate,
        retryDate: null,
        paymentPlanValue: subscriptionDetails.amount / 100,
        arrearsBalance: creditAccountRes.data?.accountBalances?.arrearBalances?.total ?? null,
    };

    logger.info({ message: "Sending SFMC comms for CPA subscription created", commsEvent });
    const result = await sendMessage({
        MessageBody: JSON.stringify(commsEvent),
        QueueUrl: process.env.SFMC_COMMS_QUEUE_URL,
    });
    logger.info({
        message: "SFMC comms sent for CPA subscription created",
        messageId: result.MessageId,
    });

    return formatJSONResponse(200, {
        message: "CPASubscriptionCreated event processed successfully",
    });
};
