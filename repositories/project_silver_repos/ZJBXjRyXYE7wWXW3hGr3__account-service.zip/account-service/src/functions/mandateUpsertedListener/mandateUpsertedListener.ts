import { getCoreBankingAdapter, getCoreRepaymentsAdapter } from "src/adapters";
import { MANDATE_SLEEP_TIME_IN_MILLISECONDS } from "@libs/constants";
import { MandateUpsertedEvent } from "@libs/types/index";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { formatJSONResponse } from "@libs/api-gateway";
import { getLogger } from "@utils/logger";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { OnmoError } from "@onmoapp/onmo-error-types";
dayjs.extend(customParseFormat);

const isAlreadyDeletedError = (errorMessage: string): boolean => {
    return (
        errorMessage.includes("No mandate found") ||
        errorMessage.includes("No payment method found") ||
        errorMessage.includes("No customer found on payment method")
    );
};

export const handler = async (event: any) => {
    const logger = getLogger();
    logger.addContext({ functionName: "mandateUpsertedListener" });

    const mandateUpsertedEvent = await deserializeKinesisEvent<MandateUpsertedEvent>(event);
    const mandateUpserted = mandateUpsertedEvent.eventData;
    logger.info({ message: "MandateUpserted received", mandateUpsertedEvent });
    logger.addContext({
        accountId: mandateUpserted.mandateDetails.accountId,
        customerId: mandateUpserted.mandateDetails.customerId,
    });

    const dynamoResponse = await getItemMethod({
        TableName: process.env.USER_TABLE,
        Key: {
            onmouuid: mandateUpserted.mandateDetails.customerId,
        },
    });

    if (!dynamoResponse.Item) {
        throw new OnmoError({
            name: "NOT_FOUND_ERROR",
            message: "User not found",
        });
    }

    // Check that the accountId provided exists
    const coreBankingAdapter = await getCoreBankingAdapter();
    const { data, error: getCreditAccountError } = await coreBankingAdapter.getCreditAccount(
        mandateUpserted.mandateDetails.accountId,
    );

    if (getCreditAccountError) {
        logger.error({ message: "Error getting credit account", getCreditAccountError });
        throw new OnmoError({
            message: "Error getting credit account",
            name: "ADAPTER_CLIENT_CALL_FAILURE_ERROR",
            cause: getCreditAccountError,
        });
    }

    if (mandateUpserted.mandateDetails.status === "PENDING") {
        logger.info(
            `Mandate ${mandateUpserted.mandateDetails.mandateId} for account ${mandateUpserted.mandateDetails.accountId} is pending activation.`,
        );
        return formatJSONResponse(200, {
            message: "Direct debit information processed successfully.",
        });
    }

    if (mandateUpserted.mandateDetails.status === "ACTIVE") {
        if (process.env.ENVIRONMENT === "staging" && data.directDebitSettings?.mandateID) {
            // Adding a delay to simulate some waiting time before new mandate becomes active
            logger.info({
                message: `Staging enviromment: sleeping for ${MANDATE_SLEEP_TIME_IN_MILLISECONDS / 1000 / 60} minutes before firing event.`,
            });
            await new Promise((resolve) => setTimeout(resolve, MANDATE_SLEEP_TIME_IN_MILLISECONDS));
            logger.info({ mesgage: "Timer finished. About to publish event." });
        }

        if (
            mandateUpserted.mandateDetails.oldMandateId &&
            mandateUpserted.mandateDetails.oldMandateId !== mandateUpserted.mandateDetails.mandateId
        ) {
            // This is a mandate update, we need to cancel the old mandate
            logger.info({ message: "Old mandate ID present. Deleting payment method..." });
            try {
                const coreRepaymentsAdapter = await getCoreRepaymentsAdapter();
                const paymentMethod = await coreRepaymentsAdapter.getPaymentMethodByMandateId(
                    mandateUpserted.mandateDetails.oldMandateId,
                );
                if (paymentMethod) {
                    await coreRepaymentsAdapter.deletePaymentMethod({
                        paymentMethodId: paymentMethod.paymentMethodId,
                    });
                    logger.info({ message: "Payment method deleted successfully." });
                } else {
                    logger.info({ message: "Payment method already deleted." });
                }
            } catch (err) {
                if (isAlreadyDeletedError(err.message)) {
                    // this will be refactored later so that the adapter doesn't throw but return a wrapped {data,error} object instead
                    logger.info({ message: "Payment method already deleted." });
                } else {
                    throw err;
                }
            }
        }

        const { data: updateAccountOutcome, error: updateAccountError } =
            await coreBankingAdapter.updateCreditAccount(mandateUpserted.mandateDetails.accountId, {
                directDebitSettings: {
                    mandateID: mandateUpserted.mandateDetails.mandateId,
                    mandateReference: mandateUpserted.mandateDetails.processorReference,
                    provider: "Stripe",
                },
            });

        if (updateAccountError) {
            logger.addContext({ error: updateAccountError });
            logger.error(
                `Could not update credit account ${mandateUpserted.mandateDetails.accountId}`,
            );
            throw new OnmoError({
                name: "ADAPTER_CLIENT_CALL_FAILURE_ERROR",
                message: `Could not update credit account ${mandateUpserted.mandateDetails.accountId}`,
                cause: updateAccountError,
            });
        }

        return formatJSONResponse(200, {
            message: `Direct debit information updated successfully for account ${updateAccountOutcome.accountId}`,
        });
    }

    logger.warn(`Received unhandled mandate status: ${mandateUpserted.mandateDetails.status}`);

    return formatJSONResponse(200, { message: "Direct debit information processed successfully." });
};
