import { test, expect, describe, vi, beforeEach } from "vitest";
import { handler } from "./mandateUpsertedListener";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { getCoreBankingAdapter, getCoreRepaymentsAdapter } from "src/adapters";
import { defaultCreditAccount, defaultPaymentMethodByMandate } from "src/fixtures";

vi.mock("src/adapters");
vi.mock("@utils/deserializeUtil");
vi.mock("@onmoapp/onmo-dynamodb");

const testData = require("./testData.json");

describe("mandateUpsertedListener tests", () => {
    const mandateActiveEvent = testData.mandateActiveEvent;
    const mandatePendingEvent = testData.mandatePendingEvent;
    const mandateFailedEvent = testData.mandateFailedEvent;
    const mandateActiveWithOldMandateEvent = testData.mandateActiveEventWithOldMandate;
    const matchingNewOldMandateIds = testData.matchingNewOldMandateIds;
    beforeEach(() => {
        vi.resetAllMocks();
    });

    test("Happy path - Mandate Status is active - It should update the direct debit settings", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
            getPaymentMethodByMandateId: vi.fn().mockResolvedValue(defaultPaymentMethodByMandate),
            deletePaymentMethod: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateActiveEvent);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).toHaveBeenCalled();

        const updateAccountCall = vi.mocked(coreBankingMock).updateCreditAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
        expect(updateAccountCall[1]).toMatchObject({
            directDebitSettings: {
                mandateID: "mandate_id",
                mandateReference: "processor-reference",
                provider: "Stripe",
            },
        });
    });
    test("Happy path - Mandate Status is active and there id an old mandate - It should update DD settings and cancel old mandate", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
            getPaymentMethodByMandateId: vi.fn().mockResolvedValue({
                ...defaultPaymentMethodByMandate,
                paymentMethodId: "payment-method-id-for-old-mandate",
            }),
            deletePaymentMethod: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveWithOldMandateEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateActiveWithOldMandateEvent);
        expect(response.statusCode).toBe(200);

        const coreRepaymentsMock = vi.mocked(getCoreRepaymentsAdapter).mock.results[0].value;
        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).toHaveBeenCalled();

        expect(coreRepaymentsMock.deletePaymentMethod).toHaveBeenCalled();
        const getPaymentMethodCall = coreRepaymentsMock.getPaymentMethodByMandateId.mock.calls[0];
        expect(getPaymentMethodCall[0]).toBe("old_mandate_id");
        const deletePaymentMethodCall = coreRepaymentsMock.deletePaymentMethod.mock.calls[0];
        expect(deletePaymentMethodCall[0]).toMatchObject({
            paymentMethodId: "payment-method-id-for-old-mandate",
        });

        const updateAccountCall = coreBankingMock.updateCreditAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
        expect(updateAccountCall[1]).toMatchObject({
            directDebitSettings: {
                mandateID: "mandate_id",
                mandateReference: "processor-reference",
                provider: "Stripe",
            },
        });
    });
    test("Happy path - Mandate Status is pending - It should not update the direct debit settings", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandatePendingEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandatePendingEvent);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).not.toHaveBeenCalled();
    });
    test("Happy path - Mandate Status is failed - It should not update the direct debit settings", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateFailedEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateFailedEvent);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).not.toHaveBeenCalled();
    });
    test("Happy path - Mandate Status is active and there is an old mandate - Old mandate is already deleted and throws, no customer attached", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
            getPaymentMethodByMandateId: vi
                .fn()
                .mockRejectedValue(new Error("No customer found on payment method")),
            deletePaymentMethod: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveWithOldMandateEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateActiveWithOldMandateEvent);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).toHaveBeenCalled();

        const coreRepaymentsMock = vi.mocked(getCoreRepaymentsAdapter).mock.results[0].value;

        expect(coreRepaymentsMock.deletePaymentMethod).not.toHaveBeenCalled();
        const getPaymentMethodCall = coreRepaymentsMock.getPaymentMethodByMandateId.mock.calls[0];
        expect(getPaymentMethodCall[0]).toBe("old_mandate_id");

        const updateAccountCall = coreBankingMock.updateCreditAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
        expect(updateAccountCall[1]).toMatchObject({
            directDebitSettings: {
                mandateID: "mandate_id",
                mandateReference: "processor-reference",
                provider: "Stripe",
            },
        });
    });
    test("Happy path - Mandate Status is active and there is an old mandate - Old mandate is already deleted and is null, no customer attached", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
            getPaymentMethodByMandateId: vi.fn().mockResolvedValue(null),
            deletePaymentMethod: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveWithOldMandateEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateActiveWithOldMandateEvent);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).toHaveBeenCalled();

        const coreRepaymentsMock = vi.mocked(getCoreRepaymentsAdapter).mock.results[0].value;
        expect(coreRepaymentsMock.deletePaymentMethod).not.toHaveBeenCalled();
        const getPaymentMethodCall = coreRepaymentsMock.getPaymentMethodByMandateId.mock.calls[0];
        expect(getPaymentMethodCall[0]).toBe("old_mandate_id");

        const updateAccountCall = coreBankingMock.updateCreditAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
        expect(updateAccountCall[1]).toMatchObject({
            directDebitSettings: {
                mandateID: "mandate_id",
                mandateReference: "processor-reference",
                provider: "Stripe",
            },
        });
    });
    test("Happy path - Mandate Status is active and old mandate id = new mandate id - it should not cancel the mandate", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            }),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultCreditAccount,
                error: null,
            }),
        });

        vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
            getPaymentMethodByMandateId: vi.fn().mockResolvedValue(defaultPaymentMethodByMandate),
            deletePaymentMethod: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(matchingNewOldMandateIds);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(matchingNewOldMandateIds);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).toHaveBeenCalled();

        const updateAccountCall = coreBankingMock.updateCreditAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
        expect(updateAccountCall[1]).toMatchObject({
            directDebitSettings: {
                mandateID: "mandate_id",
                mandateReference: "processor-reference",
                provider: "Stripe",
            },
        });
    });
    test("Unhappy path - Error getting credit account - it should throw", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue(null),
            getCreditAccount: vi.fn().mockResolvedValue({
                data: null,
                error: { errorMessage: "Cannot find account ID", errorCode: 500, severity: 1 },
            }),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        await expect(handler(mandateActiveEvent)).rejects.toThrow();

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).not.toHaveBeenCalled();
    });
    test("Unhappy path - Error getting customer from Dynamo - it should throw", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            updateCreditAccount: vi.fn().mockResolvedValue(null),
            getCreditAccount: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateActiveEvent);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: undefined,
        });

        await expect(handler(mandateActiveEvent)).rejects.toThrow();
    });
});
