import { test, expect, beforeAll, afterAll } from "vitest";
import { CreditUserCredentials, fetchAPISecret } from "@utils/testUtils";
import {
    deleteTestCreditAccountForCLMPreferences,
    setupTestCreditAccountForCLMPreferences,
} from "@utils/testUtils/clm.testUtils";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetCLMPreferences = async (
    accountId: string,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const clm_preference = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/clm/preferences`;
    return await fetch(clm_preference, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    userCreds = await setupTestCreditAccountForCLMPreferences(true);
});
afterAll(async () => {
    await deleteTestCreditAccountForCLMPreferences(userCreds);
});

test("happy path: Should CLM Preferences", async () => {
    const response = await invokeGetCLMPreferences(userCreds.creditAccountId);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ opt_out: false, auto_apply: true });
}, 10000);

test("sad path: Should throw Validation Error for Missing property in request", async () => {
    const response = await invokeGetCLMPreferences(null as string);

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account not found" });
}, 10000);

test("Sad Path: non-existent account id", async () => {
    /** invalid account Id */
    const response = await invokeGetCLMPreferences("invalid");

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account not found" });
}, 10000);

test("Sad Path: non-existent account id in CLM Table", async () => {
    const noCLMDataUserCreds = await setupTestCreditAccountForCLMPreferences(false);
    const response = await invokeGetCLMPreferences(noCLMDataUserCreds.creditAccountId);

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "No CLM records found" });
}, 10000);

test("Sad Path: no api key", async () => {
    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const response = await invokeGetCLMPreferences(
        userCreds.creditAccountId,
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);

test("Sad Path: Invalid Api key", async () => {
    const apiKeyValue = "invalid-api-key-XXXXX";
    const response = await invokeGetCLMPreferences(userCreds.creditAccountId, apiKeyValue);

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);
