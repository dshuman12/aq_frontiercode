import { formatJSONResponse } from "@libs/api-gateway";
import { getLogger } from "@utils/logger";
import { queryTableMethod } from "@onmoapp/onmo-dynamodb";

const logger = getLogger();

export const handler = async (event) => {
    try {
        logger.info("Get CLM Preferences handler invoked");
        logger.info(event);
        logger.removeContext();
        logger.addContext({
            functionName: "getCLMPreferences",
            requestId: event.requestContext?.requestId || "unknown",
            accountId: event.pathParameters?.accountId || "unknown",
        });
        const accountId = event.pathParameters?.accountId;
        if (!accountId) {
            logger.error("Account ID is missing in the request");
            return formatJSONResponse(400, {
                message: "Account ID is required",
            });
        }

        logger.addContext({
            accountId: accountId,
        });

        logger.info(`Get CLM preferences for accountId: ${event.pathParameters?.accountId}`);

        const accountDetails = await queryTableMethod({
            TableName: process.env.USER_TABLE,
            IndexName: "mambuCreditCardAccountID-index",
            KeyConditionExpression: "mambuCreditCardAccountID = :accountId",
            ExpressionAttributeValues: { ":accountId": accountId },
        });

        if (!accountDetails?.Items?.length) {
            logger.error(`Account with ID ${accountId} not found`);
            return formatJSONResponse(404, {
                message: `Account not found`,
            });
        }

        const clmDetails = await queryTableMethod({
            TableName: process.env.CLM_TABLE,
            KeyConditionExpression: "onmouuid = :onmouuid",
            ExpressionAttributeValues: { ":onmouuid": accountDetails.Items[0].onmouuid },
        });

        if (!clmDetails?.Items?.length) {
            logger.error(`Account with ID ${accountId} not found`);
            return formatJSONResponse(404, {
                message: `No CLM records found`,
            });
        }
        logger.info(`Account details retrieved for accountId: ${accountId}`);
        logger.info(clmDetails.Items[0]);

        let clmData = clmDetails.Items[0];

        return formatJSONResponse(200, {
            opt_out: clmData?.opt_out,
            auto_apply: clmData?.auto_apply,
        });
    } catch (error) {
        logger.error("Error getting CLM preferences");
        logger.error(error?.message);
        return formatJSONResponse(500, error.message);
    }
};
