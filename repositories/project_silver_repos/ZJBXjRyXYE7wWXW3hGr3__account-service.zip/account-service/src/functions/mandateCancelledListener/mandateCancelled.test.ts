import { test, expect, describe, vi, beforeEach } from "vitest";
import { handler } from "./mandateCancelledListener";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { getCoreBankingAdapter } from "src/adapters";
import { defaultCreditAccount } from "src/fixtures";

vi.mock("@utils/deserializeUtil");
vi.mock("src/adapters");
vi.mock("@onmoapp/onmo-dynamodb");

const testData = require("./testData.json");

const defaultMandateCreditAccount = {
    ...defaultCreditAccount,
    directDebitSettings: {
        mandateID: "mandate_id_from_event",
    },
};

describe("mandateCancelledListener tests", () => {
    const mandateCancelled = testData.mandateCancelledEvent;
    beforeEach(() => {
        vi.resetAllMocks();
    });

    test("Happy path - Mandate IDs match - It should erase all direct debit settings in Mambu", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi.fn().mockResolvedValue({
                data: defaultMandateCreditAccount,
                error: null,
            }),
            resetDirectDebitSettingsOnAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account_id" },
                error: null,
            }),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateCancelled);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateCancelled);

        expect(response.statusCode).toBe(200);
        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.resetDirectDebitSettingsOnAccount).toHaveBeenCalled();

        const updateAccountCall =
            vi.mocked(coreBankingMock).resetDirectDebitSettingsOnAccount.mock.calls[0];
        expect(updateAccountCall[0]).toBe("account_id_from_event");
    });
    test("Happy path - Mandate IDs do not match - It should NOT call erase direct debit settings in Mambu", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi.fn().mockResolvedValue({
                data: {
                    ...defaultMandateCreditAccount,
                    directDebitSettings: {
                        mandateID: "different_mandate_id",
                    },
                },
                error: null,
            }),
            resetDirectDebitSettingsOnAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account_id" },
                error: null,
            }),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateCancelled);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        const response = await handler(mandateCancelled);
        expect(response.statusCode).toBe(200);

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalledWith("account_id_from_event");
        expect(coreBankingMock.resetDirectDebitSettingsOnAccount).not.toHaveBeenCalled();
    });
    test("Unhappy path - Error getting credit account - it should throw", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi.fn().mockResolvedValue({
                data: null,
                error: { errorMessage: "Cannot find account ID", errorCode: 500, severity: 1 },
            }),
            resetDirectDebitSettingsOnAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account_id" },
                error: null,
            }),
            updateCreditAccount: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateCancelled);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: { onmouuid: "customer_id" },
        });

        await expect(handler(mandateCancelled)).rejects.toThrow();

        const coreBankingMock = vi.mocked(getCoreBankingAdapter).mock.results[0].value;
        expect(coreBankingMock.getCreditAccount).toHaveBeenCalled();
        expect(coreBankingMock.updateCreditAccount).not.toHaveBeenCalled();
    });
    test("Unhappy path - Error getting customer from Dynamo - it should throw", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi.fn().mockResolvedValue(null),
            resetDirectDebitSettingsOnAccount: vi.fn().mockResolvedValue({
                data: { accountId: "account_id" },
                error: null,
            }),
            updateCreditAccount: vi.fn().mockResolvedValue(null),
        });

        vi.mocked(deserializeKinesisEvent).mockResolvedValue(mandateCancelled);
        vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
            Item: undefined,
        });

        await expect(handler(mandateCancelled)).rejects.toThrow();
    });
});
