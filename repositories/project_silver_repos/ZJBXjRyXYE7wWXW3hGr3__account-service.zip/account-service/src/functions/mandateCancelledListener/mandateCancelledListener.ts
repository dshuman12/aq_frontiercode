import { getCoreBankingAdapter } from "src/adapters";
import { MandateCancelledEvent } from "@libs/types/index";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { formatJSONResponse } from "@libs/api-gateway";
import { getLogger } from "@utils/logger";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { OnmoError } from "@onmoapp/onmo-error-types";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { findAndDeleteSchedule } from "@utils/findAndDeleteSchedule";
dayjs.extend(customParseFormat);

export const handler = async (event: any) => {
    const logger = getLogger();
    logger.addContext({ functionName: "mandateCancelledListener" });

    const mandateCancelledEvent = await deserializeKinesisEvent<MandateCancelledEvent>(event);
    const mandateCancelled = mandateCancelledEvent.eventData;
    const { accountId, customerId } = mandateCancelled;
    logger.info({ message: "MandateCancelled received", mandateCancelledEvent });
    logger.addContext({
        accountId,
        customerId,
    });

    const dynamoResponse = await getItemMethod({
        TableName: process.env.USER_TABLE,
        Key: {
            onmouuid: mandateCancelled.customerId,
        },
    });

    if (!dynamoResponse.Item) {
        throw new OnmoError({
            name: "NOT_FOUND_ERROR",
            message: "User not found",
        });
    }

    // Check that the accountId provided exists
    const coreBankingAdapter = await getCoreBankingAdapter();
    const getAccountRes = await coreBankingAdapter.getCreditAccount(accountId);
    throwErrorIfAdapterResHaveError(getAccountRes, {
        message: `Could not get credit account ${accountId}`,
    });

    const accountData = getAccountRes.data;

    if (accountData.directDebitSettings.mandateID === mandateCancelled.mandateId) {
        // We only update the status if this event is linked to the currently active mandate
        // this is to cater to people updating their bank details: this will trigger the creation of a new mandate
        // that won't be updated until it is active. Once active, we cancel this old one so we don't need to update Mambu again

        if (accountData.directDebitSettings.directDebitRetryInProgress) {
            await findAndDeleteSchedule(accountId);
            await coreBankingAdapter.updateDDRetryFields(accountId, false, null, null, null);
            logger.info({ message: "Direct debit retry fields reset successfully." });
        }

        const updateAccountRes =
            await coreBankingAdapter.resetDirectDebitSettingsOnAccount(accountId);
        throwErrorIfAdapterResHaveError(updateAccountRes, {
            message: `Could not update credit account ${accountId}`,
        });
        logger.info({ message: "Direct debit information removed successfully." });
    } else {
        logger.info({
            message: `Mandate ID does not match the active mandate. Ignoring. Active: ${accountData.directDebitSettings.mandateID} - Event: ${mandateCancelled.mandateId}`,
        });
    }

    return formatJSONResponse(200, { message: "Direct debit information processed successfully." });
};
