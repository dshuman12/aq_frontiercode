import { test, expect, beforeAll } from "vitest";
import { fetchAPISecret, setupTestAccountWithTransactions } from "@utils/testUtils";

let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

interface WriteOffAccountRes {
    message: string;
}

const invokeWriteOffAccountAPI = async (
    accountId: string,
    payload: Record<string, any>,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
): Promise<{ result: WriteOffAccountRes; statusCode: number }> => {
    const write_off_account_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/write-off`;
    const response = await fetch(write_off_account_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(payload),
    });
    const result = (await response.json()) as WriteOffAccountRes;
    return { result, statusCode: response.status };
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

// TODO: Fix flaky integration test — returns 404 intermittently in staging
test.skip("happy path: account is written off successfully", async () => {
    const accountId = await setupTestAccountWithTransactions({ createTechnicalAccount: true });
    const { result, statusCode } = await invokeWriteOffAccountAPI(accountId, {
        notes: "integration test",
    });
    expect(statusCode).toEqual(200);
    expect(result.message).toEqual("The account has been written off successfully");
});

test("sad path: notes is required", async () => {
    const { result, statusCode } = await invokeWriteOffAccountAPI("XXXXXXX", {});
    expect(statusCode).toEqual(400);
    expect(result.message).toEqual("notes is required");
});

test("return error message when invalid type is provided", async () => {
    const { result, statusCode } = await invokeWriteOffAccountAPI("XXXXXXX", {
        writeOffType: "FULLL",
        notes: "integration test",
    });
    expect(statusCode).toEqual(400);
    expect(result.message).toEqual("writeOffType must be one of [FULL, PARTIAL]");
});

test("partial write off is not currently handled", async () => {
    const { result, statusCode } = await invokeWriteOffAccountAPI("XXXXXXX", {
        writeOffType: "PARTIAL",
        notes: "integration test",
    });
    expect(statusCode).toEqual(400);
    expect(result.message).toEqual(
        "This service is not available for partial write off account right now",
    );
});

test("returns error when a wrong accountId is provided", async () => {
    const { result, statusCode } = await invokeWriteOffAccountAPI("XXXXXXX", {
        notes: "integration test",
    });
    expect(statusCode).toEqual(404);
    expect(result.message).toEqual(
        "failed write off credit account XXXXXXX, INVALID_LOAN_ACCOUNT_ID",
    );
});
