import { APIGatewayEvent } from "aws-lambda";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { checkValidation } from "@validators/index";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { formatJSONResponse } from "@libs/api-gateway";
import { generateErrorResponse, throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { getLogger } from "@utils/logger";
import { getCoreBankingAdapter } from "src/adapters";
import { WRITE_OFF_TYPE } from "@libs/constants";
import { writeOffAccountValidationSchema } from "@validators/creditWriteOffAccount.validator";
import { creditWriteOffAccount } from "@libs/types";

export const handler = async (event: APIGatewayEvent) => {
    const logger = getLogger();
    const accountId: string = event.pathParameters?.accountId || "";

    try {
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });
        const coreBankingAdapter = await getCoreBankingAdapter();

        const payload = checkValidation(
            writeOffAccountValidationSchema,
            parseAPIGateWayEventBody(event.body),
        ) as creditWriteOffAccount;
        logger.info({ payload });

        let writeOffAccountRes;
        if (payload.writeOffType === WRITE_OFF_TYPE.FULL) {
            writeOffAccountRes = await coreBankingAdapter.writeOffCreditAccount(accountId, {
                notes: payload.notes,
                closeTechnicalAccount: true,
            });
        } else if (payload.writeOffType === WRITE_OFF_TYPE.PARTIAL) {
            //NOTE: Future scope : partial write off account
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "This service is not available for partial write off account right now",
            });
        }

        logger.info({ writeOffAccountRes });

        throwErrorIfAdapterResHaveError(writeOffAccountRes, {
            message: "Failed to write off account",
        });
        return formatJSONResponse(200, {
            message: "The account has been written off successfully",
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error({ debugMessage, message, errorMessage: error.message });
        const errorMessage =
            statusCode === 500 ? (debugMessage?.cause?.errorMessage ?? error.message) : message;

        return formatJSONResponse(statusCode, {
            message: errorMessage,
        });
    }
};
