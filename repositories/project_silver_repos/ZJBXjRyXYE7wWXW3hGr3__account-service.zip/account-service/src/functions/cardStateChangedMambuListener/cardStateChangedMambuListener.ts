import { CardStatusChangedEvent } from "@libs/types/index";
import { EventHubDataToPublishType } from "@libs/types/index";
import { getCoreBankingAdapter, getCorePaymentsAdapter } from "src/adapters";
import { deserializeUtil } from "@utils/util";
import { Logger } from "@onmoapp/onmo-logger";
import { UpdateCreditAccountInput, CardStatus, GetCreditAccountOutcome } from "@onmoapp/onmo-types";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { EventData } from "@onmoapp/event-hub-kinesis-adapter";

export const handler = async (event: any) => {
    const logger = new Logger({ env: process.env.STAGE }, "INFO");

    /** Parse the event data */
    const data = event?.Records[0]?.kinesis?.data;
    const dataBuffer = JSON.parse(
        Buffer.from(data, "base64").toString(),
    ) as EventHubDataToPublishType;

    const cardResponse: EventData<CardStatusChangedEvent> = await deserializeUtil(
        dataBuffer.data,
        dataBuffer.schemaId,
    );

    logger.info("Card State Listener Event Received");
    logger.debug({
        message: "Card State Listener Event Received",
        cardResponse,
    });

    let eventData: CardStatusChangedEvent = cardResponse?.eventData;

    const { cardId, statusCode, statusDate, reasonCode } = eventData;

    if (!cardId || !statusCode) {
        throw new OnmoError({
            name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
            message: "Card Id or Status Code missing in the event data",
        });
    }

    logger.addContext({ cardId });

    // fetching Credit Account (coreBankingAccountId) from CardId
    const corePaymentsAdapter = await getCorePaymentsAdapter();
    const cardMappingRes = await corePaymentsAdapter.getAccountIdFromCardId(cardId);

    logger.info({ message: "Successfully get card response from core payments Adapter" });
    logger.debug({ cardMappingRes });

    throwErrorIfAdapterResHaveError(cardMappingRes, {
        message: "Unable to get account ID from CardId",
    });

    const { data: accountId } = cardMappingRes;
    if (!accountId) {
        throw new OnmoError({
            name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
            message: "Not able to find the credit account Linked to Card",
        });
    }

    // Get the account details by card id - need account id
    const coreBankingAdapter = await getCoreBankingAdapter();
    const accountResponse: GetCreditAccountOutcome = await coreBankingAdapter.getCreditAccount(
        accountId ?? "",
    );

    logger.info({ message: "Account Details Response" });
    logger.debug({
        message: "Account Details",
        accountResponse,
    });

    throwErrorIfAdapterResHaveError(accountResponse, {
        message: "Failed to fetch the account details",
    });

    logger.addContext({ accountId });
    const currentCardId = accountResponse?.data?.cards?.at(0)?.cardId ?? null;

    if (["VOID", "LOST"].includes(statusCode) && currentCardId !== cardId) {
        logger.info({
            message: "We don't need to update the card in Core Banking",
        });
    } else {
        // Prepare the input for updating the account
        const updateCreditAccountInput: UpdateCreditAccountInput = {
            cardDetails: {
                status: statusCode as CardStatus,
                statusDate,
                event: reasonCode,
            },
        };

        // Update the account with the new card status
        const updateAccountResponse = await coreBankingAdapter.updateCreditAccount(
            accountId,
            updateCreditAccountInput,
        );

        logger.debug({
            message: "Update Account Response",
            updateAccountResponse,
        });
        logger.info({ message: "Update Account Response" });

        throwErrorIfAdapterResHaveError(accountResponse, {
            message: "Failed to update account status",
        });

        logger.info({ message: "Card State Change Listener Event Processed Successfully" });
    }
};
