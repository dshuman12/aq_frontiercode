import { test, expect, beforeAll, afterAll } from "vitest";
import {
    fetchAPISecret,
    setupTestAccountWithTransactions,
    setupTestAccountForInterestScenarioForCreditFreezeAccount,
    setupTestAccountForValidationScenarioForCreditFreezeAccount,
    writeOffMambuLoanAccount,
} from "@utils/testUtils";
import { IFreezeInterestAndFeesPayload } from "@libs/types/interestAndFees";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { TEST_ACCOUNT_ID } from "@libs/constants";
import { getCoreBankingAdapter } from "src/adapters";

dayjs.extend(utc);
dayjs.extend(timezone);

let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF
const testAccountId = TEST_ACCOUNT_ID;

const baseStartDate = dayjs().add(-1, "day").tz("Europe/London").format("YYYY-MM-DD");
const baseEndDate = dayjs().tz("Europe/London").format("YYYY-MM-DD");
const basePayload: IFreezeInterestAndFeesPayload = {
    reason: "NoticeOfDefault",
    startDate: baseStartDate,
    endDate: baseEndDate,
    applyAccruedInterest: false,
    disableFreezeWhenArrearsCleared: false,
};

const invokeFreezeInterestAndFees = async (
    accountId: string,
    payload: IFreezeInterestAndFeesPayload,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const interestAndFeesFreezeUrl = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/interest-and-fees/freeze`;
    return await fetch(interestAndFeesFreezeUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(payload),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

afterAll(async () => {});

test(
    "happy path",
    {
        timeout: 30000,
    },
    async () => {
        const accountId = await setupTestAccountWithTransactions({
            includeCashTransaction: false,
        });
        const response = await invokeFreezeInterestAndFees(accountId, basePayload);
        await writeOffMambuLoanAccount(accountId);

        expect(response.status).toBe(200);
        const responseBody = await response.json();
        expect(responseBody).toEqual({
            message: `Account ${accountId} updated`,
        });

        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountInfo = await coreBankingAdapter.getCreditAccount(accountId);
        expect(accountInfo.data.accountDetails.interestRate).toEqual(0);
    },
);

test("no api key", async () => {
    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const response = await invokeFreezeInterestAndFees(
        testAccountId,
        basePayload,
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});

test("reason is required ", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        reason: undefined,
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "reason is required",
    });
});

test("valid reason must be provided", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        reason: "InvalidReason",
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message:
            "reason must be one of [NoticeOfDefault, Deceased, TokenPlan, SupportPlan, IVA, Bankruptcy, DRO, BreathingSpace]",
    });
});

test("disableFreezeWhenArrearsCleared is required", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        disableFreezeWhenArrearsCleared: undefined,
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "disableFreezeWhenArrearsCleared is required",
    });
});

test("applyAccruedInterest is required", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        applyAccruedInterest: undefined,
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "applyAccruedInterest is required",
    });
});

test("startDate is required", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        startDate: undefined,
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "startDate is required",
    });
});

test("startDate should be today's date or an earlier date", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        startDate: dayjs().add(1, "day").format("YYYY-MM-DD"),
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: `please enter a valid startDate, Please enter today's date or an earlier date`,
    });
});

test("endDate should be after startDate", async () => {
    const response = await invokeFreezeInterestAndFees(testAccountId, {
        ...basePayload,
        endDate: dayjs().add(-20, "day").format("YYYY-MM-DD"),
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "End date should be after start date",
    });
});

test(
    "cash transaction found between dates",
    {
        timeout: 30000,
    },
    async () => {
        const accountId = await setupTestAccountWithTransactions({
            includeCashTransaction: true,
        });

        const response = await invokeFreezeInterestAndFees(accountId, basePayload);
        await writeOffMambuLoanAccount(accountId);

        expect(response.status).toBe(400);
        const responseBody = await response.json();
        expect(responseBody).toEqual({
            message: "some cash disbursement transaction found between dates",
        });
    },
);

// This test case covers the scenario where mambu doesn't allow to create repayment more than account balance
test(
    "account validation check : repayment issue",
    {
        timeout: 30000,
    },
    async () => {
        const accountId = await setupTestAccountForValidationScenarioForCreditFreezeAccount();

        const response = await invokeFreezeInterestAndFees(accountId, basePayload);
        await writeOffMambuLoanAccount(accountId);

        expect(response.status).toBe(400);
        const responseBody = await response.json();
        expect(responseBody).toEqual({
            message:
                "The account is not in a state where we can proceed with the interest and fee freeze process.",
        });
    },
);

// This test case covers if account has multiple interest rate then it will be become zero
test(
    "happy path : multiple interest rate transaction",
    {
        timeout: 30000,
    },
    async () => {
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountId =
            await setupTestAccountForInterestScenarioForCreditFreezeAccount(coreBankingAdapter);

        const response = await invokeFreezeInterestAndFees(accountId, basePayload);
        await writeOffMambuLoanAccount(accountId);

        expect(response.status).toBe(200);
        const responseBody = await response.json();
        expect(responseBody).toEqual({
            message: `Account ${accountId} updated`,
        });

        const accountInfo = await coreBankingAdapter.getCreditAccount(accountId);
        expect(accountInfo.data.accountDetails.interestRate).toEqual(0);
    },
);
