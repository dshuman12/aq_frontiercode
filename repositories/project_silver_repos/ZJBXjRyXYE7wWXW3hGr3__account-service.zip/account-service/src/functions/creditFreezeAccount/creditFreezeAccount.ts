import { Logger } from "@onmoapp/onmo-logger";
import { generateErrorResponse, throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { freezeInterestSchema } from "@validators/freezeInterest.validators";
import { checkValidation } from "@validators/index";
import { InterestAndFeesService } from "@utils/interestAndFeesService";
import { IFreezeInterestAndFeesPayload } from "@libs/types/interestAndFees";
import { getCoreBankingAdapter } from "src/adapters";
import {
    INTEREST_FEES_FREEZE_STATUS,
    FreezeProcessErrorStatuses,
    FreezeProcessStatusAndProcessCodeMap,
    RollbackFreezeProcessErrorStatuses,
} from "@libs/constants";
import dayjs from "dayjs";
import { InterestAndFeesFreezeRepository } from "@utils/interestAndFeesFreezeRepository";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { formatJSONResponse } from "@libs/api-gateway";
import timezone from "dayjs/plugin/timezone";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(customParseFormat);
dayjs.extend(timezone);

const interestAndFeesFreezeRepository = InterestAndFeesFreezeRepository.getInstance();

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );
    const accountId: string = event.pathParameters?.accountId || "";

    try {
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });

        // payload validation
        const payload = checkValidation(
            freezeInterestSchema,
            parseAPIGateWayEventBody(event.body),
        ) as IFreezeInterestAndFeesPayload;
        logger.info({ payload });

        const rollbackProcessFlag = payload.rollbackFreezeProcess;

        const coreBankingAdapter = await getCoreBankingAdapter();
        const creditAccountRes = await coreBankingAdapter.getCreditAccount(accountId);

        throwErrorIfAdapterResHaveError(creditAccountRes, {
            message: "Failed to get credit account details",
        });

        const { accountDetails, accountBalances } = creditAccountRes.data;
        const creditAccountEncodedKey = accountDetails.accountEncodedKey;
        const todayDate = dayjs().tz("Europe/London").format("YYYY-MM-DD");

        const transactions = await InterestAndFeesService.fetchAllApprovedTransactions(
            creditAccountEncodedKey,
            {
                startDate: payload.startDate,
                endDate: todayDate,
            },
            coreBankingAdapter,
        );

        const interestAndFeesService = new InterestAndFeesService(coreBankingAdapter, transactions);

        if (!rollbackProcessFlag) {
            logger.info("Verify whether the account is in a state to proceed or not");
            await interestAndFeesService.validationCheck(accountBalances?.balances?.total);
            logger.info("The account is in a state to process : Moving ahead...");
        }

        // fetch previous history for an account
        let previousHistoryItem = null;
        try {
            previousHistoryItem = await interestAndFeesFreezeRepository.getByAccountId(accountId);
        } catch (error) {
            logger.info(`Previous history not found for an account`);
        }

        let processCode = 0,
            previousError = false;

        if (previousHistoryItem) {
            const previousStatus = previousHistoryItem.status;
            logger.info(`Previous history found for an account with status : ${previousStatus}`);

            /**
             * If an error occurred in a previous process run, resume the current process accordingly.
             * Set the processCode to resume the process from where it stopped in the previous run.
             * rollbackProcessFlag flag true, rollback whole process
             */
            if (rollbackProcessFlag) {
                if (
                    [...FreezeProcessErrorStatuses, ...RollbackFreezeProcessErrorStatuses].includes(
                        previousStatus,
                    )
                ) {
                    processCode = FreezeProcessStatusAndProcessCodeMap[previousStatus];
                    previousError = true;
                    await interestAndFeesFreezeRepository.updateFieldsByPK(
                        {
                            accountId: previousHistoryItem.accountId,
                            createdAt: previousHistoryItem.createdAt,
                        },
                        { status: INTEREST_FEES_FREEZE_STATUS.RE_PROCESSED }, // rollback
                    );
                    logger.info("Previous history status updated to RE_PROCESSED");
                } else {
                    throw new OnmoError({
                        name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                        message:
                            "Transaction rollback is not possible as there is nothing to rollback",
                    });
                }
            } else {
                if (RollbackFreezeProcessErrorStatuses.includes(previousStatus)) {
                    throw new OnmoError({
                        name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                        message: "Can not start freezing process. Rollback failed history found",
                    });
                } else if (FreezeProcessErrorStatuses.includes(previousStatus)) {
                    processCode = FreezeProcessStatusAndProcessCodeMap[previousStatus];
                    previousError = true;
                    await interestAndFeesFreezeRepository.updateFieldsByPK(
                        {
                            accountId: previousHistoryItem.accountId,
                            createdAt: previousHistoryItem.createdAt,
                        },
                        { status: INTEREST_FEES_FREEZE_STATUS.RE_PROCESSED },
                    );
                    logger.info("Previous history status updated to RE_PROCESSED");
                }
            }
        }

        logger.info(`processCode : ${processCode}`);

        // create history item, copy previous run history if error in previous one
        const historyItem = await interestAndFeesFreezeRepository.create({
            ...(previousHistoryItem && previousError && { ...previousHistoryItem }),
            accountId: accountId,
            reason: payload.reason,
            startDate: payload.startDate,
            endDate: payload.endDate,
            status: INTEREST_FEES_FREEZE_STATUS.INITIATED,
            ...(processCode <= 3 && {
                apr: accountDetails.apr,
                originalInterestRate: accountDetails.interestRate,
            }),
        });
        logger.info("History created with status INITIATED");

        interestAndFeesService.setHistoryItem(historyItem);

        if (rollbackProcessFlag) {
            await interestAndFeesService.rollbackFreezeProcess({
                accountEncodedKey: creditAccountEncodedKey,
                processCode: processCode,
            });
            return formatJSONResponse(200, {
                message: `The rollback for Account ${accountId} has been successfully completed`,
            });
        }

        logger.info(`Starting to freeze interest and fees on credit account ${accountId}`);

        // adjust transaction between dates
        if (processCode <= 1) {
            logger.info("Adjustment Process : Started");
            await interestAndFeesService.adjustTransactions();
            logger.info("Adjustment Process : Completed");
        } else {
            logger.info("adjustmentProcess skipped!");
        }

        // apply accrued interest to account if flag is true
        if (processCode <= 2 && payload.applyAccruedInterest) {
            const interestApplyDate = dayjs
                .tz(payload.startDate, "Europe/London")
                .utc()
                .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

            await interestAndFeesService.applyAccruedInterest(accountId, interestApplyDate);
        } else {
            logger.info("applyAccruedInterest skipped!");
        }

        // update interest rate to zero at start date
        if (processCode <= 3) {
            const updateZeroInterestRateToAccountRes =
                await interestAndFeesService.updateZeroInterestRateToAccount(
                    accountId,
                    payload.startDate,
                );
            logger.info({ updateZeroInterestRateToAccountRes });

            await interestAndFeesService.updateZeroInterestOnRateChangeDate(accountId);
        } else {
            logger.info("updateZeroInterestRateToAccount skipped!");
        }

        // re-create adjusted disbursement and repayment transaction
        if (processCode <= 4) {
            await interestAndFeesService.recreateTransaction(accountId);
        } else {
            logger.info("recreateTransaction skipped!");
        }

        // all process done : make status frozen
        await interestAndFeesService.updateHistoryStatus(INTEREST_FEES_FREEZE_STATUS.FROZEN);
        logger.info("History status updated to FROZEN");

        return formatJSONResponse(200, {
            message: `Account ${accountId} updated`,
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error({ debugMessage, message, errorMessage: error.message });
        const errorMessage = statusCode === 500 ? error.message : message;

        return formatJSONResponse(statusCode, {
            message: errorMessage,
        });
    }
};
