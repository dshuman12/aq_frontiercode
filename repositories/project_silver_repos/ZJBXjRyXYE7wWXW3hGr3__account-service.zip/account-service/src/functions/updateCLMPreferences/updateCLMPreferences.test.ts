import { test, expect, beforeAll, afterAll } from "vitest";
import { CreditUserCredentials, fetchAPISecret } from "@utils/testUtils";
import {
    deleteTestCreditAccountForCLMPreferences,
    setupTestCreditAccountForCLMPreferences,
} from "@utils/testUtils/clm.testUtils";
import { UpdateCLMPreferencesRequestBody } from "@libs/types/updateCLMPreferences";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeUpdateCLMPreferences = async (
    accountId: string,
    eventBody: UpdateCLMPreferencesRequestBody,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const clm_preference = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/clm/preferences`;
    return await fetch(clm_preference, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(eventBody),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    userCreds = await setupTestCreditAccountForCLMPreferences(true);
});
afterAll(async () => {
    await deleteTestCreditAccountForCLMPreferences(userCreds);
});

test("happy path: Should CLM Preferences", async () => {
    const response = await invokeUpdateCLMPreferences(userCreds.creditAccountId, {
        opt_out: false,
        auto_apply: true,
    });

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account CLM preference has been updated" });
}, 10000);

test("sad path: Should throw Validation Error for Invalid Body", async () => {
    const response = await invokeUpdateCLMPreferences(userCreds.creditAccountId, {
        opt_out: null, // Invalid type
        auto_apply: true,
    } as any);

    expect(response.status).toBe(400);
    const responseBody: any = await response.json();
    expect(responseBody.message).toEqual("Invalid request body");
}, 10000);

test("sad path: Should throw Validation Error for Missing property in body", async () => {
    const response = await invokeUpdateCLMPreferences(userCreds.creditAccountId, {
        opt_out: true,
        auto_apply: null,
    } as any);

    expect(response.status).toBe(400);
    const responseBody: any = await response.json();
    expect(responseBody.message).toEqual("Invalid request body");
}, 10000);

test("sad path: Should throw Validation Error for Missing account ID in body", async () => {
    const response = await invokeUpdateCLMPreferences(undefined as string, {
        opt_out: true,
        auto_apply: true,
    });

    expect(response.status).toBe(400);
    const responseBody: any = await response.json();
    console.log({ responseBody });
    expect(responseBody.message).toEqual("Invalid request body");
}, 10000);

test("Sad Path: non-existent account id", async () => {
    /** invalid account Id */
    const response = await invokeUpdateCLMPreferences("invalid", {
        opt_out: false,
        auto_apply: true,
    });

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account not found" });
}, 10000);

test("Sad Path: non-existent account id for CLM", async () => {
    let userCredsData = await setupTestCreditAccountForCLMPreferences(false);
    /** invalid account Id */
    const response = await invokeUpdateCLMPreferences(userCredsData.creditAccountId, {
        opt_out: false,
        auto_apply: true,
    });

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "No CLM records found" });
    await deleteTestCreditAccountForCLMPreferences(userCredsData);
}, 10000);

test("Sad Path: no api key", async () => {
    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const response = await invokeUpdateCLMPreferences(
        userCreds.creditAccountId,
        {
            auto_apply: true,
            opt_out: false,
        },
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);

test("Sad Path: Invalid Api key", async () => {
    const apiKeyValue = "invalid-api-key-XXXXX";
    const response = await invokeUpdateCLMPreferences(
        userCreds.creditAccountId,
        {
            auto_apply: true,
            opt_out: false,
        },
        apiKeyValue,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);
