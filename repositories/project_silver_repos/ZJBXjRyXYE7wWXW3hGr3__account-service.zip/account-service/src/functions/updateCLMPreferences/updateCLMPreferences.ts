import { formatJSONResponse } from "@libs/api-gateway";
import { getLogger } from "@utils/logger";
import { updateCLMPreferencesValidationSchema } from "@validators/updateCLMPreferences.validator";
import { putItemMethod, queryTableMethod } from "@onmoapp/onmo-dynamodb";
import { UpdateCLMPreferencesRequestBody } from "@libs/types/updateCLMPreferences";

const logger = getLogger();

export const handler = async (event) => {
    try {
        logger.info("Update CLM Preferences handler invoked");
        logger.removeContext();
        logger.info(event);
        logger.addContext({
            functionName: "updateCLMPreferences",
            accountId: event.pathParameters?.accountId || "unknown",
        });
        const accountId = event.pathParameters?.accountId;
        if (!accountId) {
            logger.error("Account ID is missing in the request");
            return formatJSONResponse(400, {
                message: "Account ID is missing in the request",
            });
        }

        logger.addContext({
            accountId: accountId,
        });

        const payload = JSON.parse(event?.body ?? "{}") as UpdateCLMPreferencesRequestBody;
        const validation = updateCLMPreferencesValidationSchema.validate(payload);
        logger.info(`Updating CLM preferences for accountId: ${event.pathParameters?.accountId}`);

        if (validation.error) {
            logger.error(`Validation error: ${validation.error.details}`);
            return formatJSONResponse(400, {
                message: "Invalid request body",
                details: validation.error.details,
            });
        }
        const accountDetails = await queryTableMethod({
            TableName: process.env.USER_TABLE,
            IndexName: "mambuCreditCardAccountID-index",
            KeyConditionExpression: "mambuCreditCardAccountID = :accountId",
            ExpressionAttributeValues: { ":accountId": accountId },
        });

        if (!accountDetails?.Items?.length) {
            logger.error(`Account with ID ${accountId} not found`);
            return formatJSONResponse(404, {
                message: `Account not found`,
            });
        }

        const clmDetails = await queryTableMethod({
            TableName: process.env.CLM_TABLE,
            KeyConditionExpression: "onmouuid = :onmouuid",
            ExpressionAttributeValues: { ":onmouuid": accountDetails.Items[0].onmouuid },
        });

        if (!clmDetails?.Items?.length) {
            logger.error(`Account with ID ${accountId} not found`);
            return formatJSONResponse(404, {
                message: `No CLM records found`,
            });
        }
        logger.info(`Account details retrieved for accountId: ${accountId}`);
        logger.info(clmDetails.Items[0]);

        let clmData = clmDetails.Items[0];
        clmData["opt_out"] = payload.opt_out;
        clmData["auto_apply"] = payload.auto_apply;

        await putItemMethod({
            TableName: process.env.CLM_TABLE,
            Item: clmData,
        });

        return formatJSONResponse(200, {
            message: "Account CLM preference has been updated",
        });
    } catch (error) {
        logger.error("Error updating CLM preferences");
        logger.error(error?.message);
        return formatJSONResponse(500, error.message);
    }
};
