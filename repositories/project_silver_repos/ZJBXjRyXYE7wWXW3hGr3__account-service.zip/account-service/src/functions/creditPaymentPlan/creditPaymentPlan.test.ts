import { test, expect, beforeAll, afterAll } from "vitest";
import {
    CreditUserCredentials,
    fetchAPISecret,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
    calculateFutureDates,
} from "@utils/testUtils";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

export type PaymentPlanRequestBody = {
    type?: string;
    status?: string;
    amount?: number | string;
    startDate?: string;
    endDate?: string;
};

const invokePostPaymentPlan = async (
    accountId: string,
    requestBody: PaymentPlanRequestBody,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const payment_plan_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/payment-plan`;
    return await fetch(payment_plan_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(requestBody),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    userCreds = await setUpTestCreditCustomerAccount();
});

afterAll(async () => {
    await deleteTestCreditCustomerAccount(userCreds);
});

test("happy path - promise to pay ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - payment plan ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Payment Plan",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - payment plan with fees ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Payment Plan - With Fees",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - DCA payment plan ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "DCA Payment Plan",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - IVA payment plan ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "IVA Payment Plan",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - DRO payment plan ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "DRO Payment Plan",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("happy path - DMC payment plan ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "DMC Payment Plan",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Account's payment plan updated" });
});

test("missing type in body", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Missing attributes in request: type, status and amount are required",
    });
});

test("missing amount in body", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Missing attributes in request: type, status and amount are required",
    });
});

test("missing status in body", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Missing attributes in request: type, status and amount are required",
    });
});

test("non-existent account id", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan("fake-account-id", requestBody);

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "failed to update credit account, INVALID_LOAN_ACCOUNT_ID",
    });
});

test("invalid payment plan type", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "fake payment plan type",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid payment plan type provided." });
});

test("invalid payment plan status ", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "fake account status",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid payment plan status provided." });
});

test("non numeric amount", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: "100",
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid amount provided; it must be a number." });
});

test("invalid start date format ", async () => {
    const { endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "20244-04-04-04",
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Error with supplied startDate: Invalid date format; must be YYYY-MM-DD",
    });
});

test("invalid end date format ", async () => {
    const { startDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: "20244-04-04-04",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Error with supplied endDate: Invalid date format; must be YYYY-MM-DD",
    });
});

test("non-existent start date ", async () => {
    const { endDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2030-05-40",
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Error with supplied startDate: Date does not exist" });
});

test("non existent end date", async () => {
    const { startDate } = calculateFutureDates();

    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: "2030-05-40",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Error with supplied endDate: Date does not exist" });
});

test("start date is after end date", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2040-05-05",
        endDate: "2040-04-05",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Start date must be before end date",
    });
});

test("future start date is equal to future end date", async () => {
    const { startDate } = calculateFutureDates();
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: startDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("past start date is equal to past end date with Active status", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2020-05-05",
        endDate: "2020-05-05",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "End date is invalid for an active flag",
    });
});

test("start date is equal to end date", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date().toISOString().split("T")[0],
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("past start date with future end date", async () => {
    const { endDate } = calculateFutureDates();
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2020-05-05",
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("future start date with future end date", async () => {
    const { startDate } = calculateFutureDates();
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: startDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("today start date with future end date", async () => {
    const { endDate } = calculateFutureDates();
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: new Date().toISOString().split("T")[0],
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("past start date with today end date", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2024-08-05",
        endDate: new Date().toISOString().split("T")[0],
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("past end date with Active status", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: "2024-08-05",
        endDate: "2024-08-06",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "End date is invalid for an active flag",
    });
});

test("past end date with Broken status", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Broken",
        amount: 100,
        startDate: "2024-08-05",
        endDate: "2024-08-06",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("past end date with Expired status", async () => {
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Expired",
        amount: 100,
        startDate: "2024-08-05",
        endDate: "2024-08-06",
    };
    const response = await invokePostPaymentPlan(userCreds.creditAccountId, requestBody);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "Account's payment plan updated",
    });
});

test("no api key", async () => {
    const { startDate, endDate } = calculateFutureDates();

    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const requestBody: PaymentPlanRequestBody = {
        type: "Promise To Pay",
        status: "Active",
        amount: 100,
        startDate: startDate,
        endDate: endDate,
    };
    const response = await invokePostPaymentPlan(
        userCreds.creditAccountId,
        requestBody,
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
});
