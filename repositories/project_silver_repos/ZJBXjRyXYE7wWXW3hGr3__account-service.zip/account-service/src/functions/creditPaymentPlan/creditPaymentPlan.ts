import { formatJSONResponse } from "@libs/api-gateway";
import { getCoreBankingAdapter } from "src/adapters";
import { PaymentPlan, UpdateCreditAccountInput } from "@onmoapp/onmo-types";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import {
    PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME,
    PAYMENT_PLAN_STATUS_OPTIONS,
} from "@libs/constants";
import { Logger } from "@onmoapp/onmo-logger";

const isValidRealDate = (date: string): { isValid: boolean; reason?: string } => {
    // checks format is YYYY-MM-DD
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return { isValid: false, reason: "Invalid date format; must be YYYY-MM-DD" };
    }

    // validates it's a real date
    const [year, month, day] = date.split("-").map(Number);
    const dateObj = new Date(year, month - 1, day);

    if (
        !(
            dateObj.getFullYear() === year &&
            dateObj.getMonth() === month - 1 &&
            dateObj.getDate() === day
        )
    ) {
        return { isValid: false, reason: "Date does not exist" };
    }

    return { isValid: true };
};

const validateRequestBody = (body: any): { isValid: boolean; reason?: string } => {
    //validate that type, amount and status exists
    if (!body.type || !body.amount || !body.status) {
        return {
            isValid: false,
            reason: "Missing attributes in request: type, status and amount are required",
        };
    }

    if (!(body.type in PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME)) {
        return { isValid: false, reason: "Invalid payment plan type provided." };
    }

    if (!PAYMENT_PLAN_STATUS_OPTIONS.includes(body.status)) {
        return { isValid: false, reason: "Invalid payment plan status provided." };
    }

    if (typeof body.amount !== "number") {
        return { isValid: false, reason: "Invalid amount provided; it must be a number." };
    }

    if (body.startDate) {
        const dateValidationResult = isValidRealDate(body.startDate);
        if (!dateValidationResult.isValid) {
            return {
                isValid: false,
                reason: `Error with supplied startDate: ${dateValidationResult.reason}`,
            };
        }
    }
    if (body.endDate) {
        const dateValidationResult = isValidRealDate(body.endDate);
        if (!dateValidationResult.isValid) {
            return {
                isValid: false,
                reason: `Error with supplied endDate: ${dateValidationResult.reason}`,
            };
        }
    }
    const today = new Date().toISOString().split("T")[0];

    if (body.endDate < today && body.status === "Active") {
        return { isValid: false, reason: "End date is invalid for an active flag" };
    }

    // validate that start date is before end date and they are not equal
    if (body.startDate && body.endDate) {
        const [startYear, startMonth, startDay] = body.startDate.split("-").map(Number);
        const startDateObj = new Date(startYear, startMonth - 1, startDay);

        const [endYear, endMonth, endDay] = body.endDate.split("-").map(Number);
        const endDateObj = new Date(endYear, endMonth - 1, endDay);

        if (startDateObj > endDateObj) {
            return {
                isValid: false,
                reason: "Start date must be before end date",
            };
        }
    }

    return { isValid: true };
};

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        // validate accountId is on path params
        const accountId: string = event.pathParameters?.accountId || "";
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });
        logger.info("Got accountId from path parameters");
        const parsedRequestBody = JSON.parse(event.body);
        const { isValid, reason } = validateRequestBody(parsedRequestBody);
        if (!isValid) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: reason,
            });
        }
        logger.info("Request body validated");

        // form initial input object for updateCreditCardAccount adapter method
        const paymentPlanUpdateInput: PaymentPlan = {
            paymentPlanStatus: parsedRequestBody.status,
            paymentPlanAmount: parsedRequestBody.amount,
            ...(parsedRequestBody.startDate && {
                paymentPlanStartDate: parsedRequestBody.startDate,
            }),
            ...(parsedRequestBody.endDate && { paymentPlanEndDate: parsedRequestBody.endDate }),
        };

        // set the boolean flags for all payment plan options (only the request payment plan type will be true, all else set to false)
        const requstedPaymentPlanName =
            PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME[parsedRequestBody.type];
        Object.keys(PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME).forEach((key) => {
            const currentPlanName = PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME[key];
            paymentPlanUpdateInput[currentPlanName] = currentPlanName === requstedPaymentPlanName;
        });

        // update account by calling adapter method
        logger.info(
            `Updating account's payment plan with: ${JSON.stringify(paymentPlanUpdateInput)}`,
        );
        const detailsToUpdate: UpdateCreditAccountInput = { paymentPlan: paymentPlanUpdateInput };

        const coreBankingAdapter = await getCoreBankingAdapter();
        const response = await coreBankingAdapter.updateCreditAccount(accountId, detailsToUpdate);

        // handle error response from adapter method
        if (!response || response.error || !response.data) {
            logger.error(`Unable to update account: ${JSON.stringify(response?.error)}`);
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to update account",
                cause: response?.error,
            });
        }

        logger.info("Account payment plan updated successfully");
        return formatJSONResponse(200, { message: "Account's payment plan updated" });
    } catch (error) {
        const { statusCode, message } = generateErrorResponse(error);
        logger.error(message);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
