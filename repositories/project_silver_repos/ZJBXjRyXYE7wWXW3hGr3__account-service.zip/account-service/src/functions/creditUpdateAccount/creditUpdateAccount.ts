import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/api-gateway";
import { getCoreBankingAdapter } from "src/adapters";
import { GetCreditAccountOutcome, UpdateCreditAccountInput } from "@onmoapp/onmo-types";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { checkValidation } from "@validators/index";
import { updateAccountSchema } from "@validators/updateAccount.validator";
import { checkAccess } from "@utils/oidc-authorization";

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        // validate accountId is on path params
        const accountId: string = event.pathParameters?.accountId || {};
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });
        logger.info("Got accountId from path parameters");

        // payload validation
        const payload: UpdateCreditAccountInput = checkValidation(
            updateAccountSchema,
            parseAPIGateWayEventBody(event.body),
        );
        logger.info(`Payload is valid: ${JSON.stringify(payload)}`);

        await checkAccess(event.requestContext, accountId);
        const coreBankingAdapter = await getCoreBankingAdapter();

        // if custom amount passed, ensure its not > than accounts credit limit
        if (payload.directDebitSettings.customAmount) {
            logger.info("Validating that custom amount isn't greater than account's credit limit");
            const accountDetails: GetCreditAccountOutcome =
                await coreBankingAdapter.getCreditAccount(accountId);

            if (!accountDetails.data || accountDetails.error) {
                throw new OnmoError({
                    name: ErrorNamesEnum.NOT_FOUND_ERROR,
                    message: "Failed to get account details",
                    cause: accountDetails.error,
                });
            }
            if (
                payload.directDebitSettings.customAmount >
                accountDetails.data.accountDetails.creditLimit
            ) {
                throw new OnmoError({
                    name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                    message: "Custom amount cannot be greater than account's credit limit",
                });
            }
        }

        //perform the update
        const updateAccountResponse = await coreBankingAdapter.updateCreditAccount(
            accountId,
            payload,
        );

        // handle error response from adapter method
        if (!updateAccountResponse || updateAccountResponse.error || !updateAccountResponse.data) {
            logger.error(
                `Unable to update account: ${JSON.stringify(updateAccountResponse?.error)}`,
            );
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to update account",
                cause: updateAccountResponse?.error,
            });
        }

        logger.info("Account updated successfully");
        return formatJSONResponse(200, { message: "Account updated" });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
