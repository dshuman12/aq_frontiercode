import { test, expect, beforeEach, afterEach } from "vitest";
import {
    CreditUserCredentials,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
    generateAccessTokenOfTestUser,
    deleteAccessTokenOfTestUser,
} from "@utils/testUtils";
import { UpdateAccountResponse, ErrorMessageResponse, accessTokenObject } from "@libs/types";

const onmo_api_url = process.env.ONMO_API_URL as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

let userCreds: CreditUserCredentials;
let accessToken: accessTokenObject;

beforeEach(async () => {
    userCreds = await setUpTestCreditCustomerAccount();
    accessToken = await generateAccessTokenOfTestUser(userCreds.customerId);
});

afterEach(async () => {
    await deleteTestCreditCustomerAccount(userCreds);
    await deleteAccessTokenOfTestUser(userCreds.customerId, accessToken);
});

const invokeUpdateAccount = async (
    accountId: string,
    eventBody: any,
    token = accessToken.access_token,
) => {
    const get_account_url = `https://${onmo_api_url}/service/accounts/next/credit/${accountId}`;
    return await fetch(get_account_url, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(eventBody),
    });
};

test("happy path - minimum payment", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Minimum Payment",
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as UpdateAccountResponse;
    expect(responseBody.message).toEqual("Account updated");
}, 50000);

test("happy path - full statement balance", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Full Statement Balance",
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as UpdateAccountResponse;
    expect(responseBody.message).toEqual("Account updated");
}, 50000);

test("happy path - custom", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Custom",
            customAmount: 100,
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as UpdateAccountResponse;
    expect(responseBody.message).toEqual("Account updated");
}, 50000);

test("sad path - invalid preference string", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "random",
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(400);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual(
        "directDebitSettings.amountPreference must be one of [Full Statement Balance, Minimum Payment, Custom]",
    );
}, 50000);

test("sad path - custom but missing amount", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Custom",
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(400);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("directDebitSettings.customAmount is required");
}, 50000);

test("sad path - passing custom amount when not applicable", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Minimum Payment",
            customAmount: 100,
        },
    };
    const response = await invokeUpdateAccount(userCreds.creditAccountId, eventBody);
    expect(response.status).toBe(400);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("directDebitSettings.customAmount is not allowed");
}, 50000);

test("trying to access any other's account should return 401 unauthorized access", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Custom",
            customAmount: 100,
        },
    };
    const response = await invokeUpdateAccount("ABCD123", eventBody, accessToken.access_token);

    expect(response.status).toBe(401);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("user is not authorized to access this account");
}, 50000);

test("invalid Access Token", async () => {
    const eventBody = {
        directDebitSettings: {
            amountPreference: "Custom",
            customAmount: 100,
        },
    };
    const response = await invokeUpdateAccount(
        userCreds.creditAccountId,
        eventBody,
        "INVALID_ACCESS_TOKEN",
    );
    expect(response.status).toBe(401);
}, 50000);
