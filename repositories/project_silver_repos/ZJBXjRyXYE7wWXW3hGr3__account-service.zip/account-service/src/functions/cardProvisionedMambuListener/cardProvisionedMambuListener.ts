import { getCoreBankingAdapter } from "src/adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { EventHubDataToPublishType, CardProvisionedEvent } from "@libs/types/index";
import { UpdateCreditAccountInput } from "@onmoapp/onmo-types";
import { deserializeUtil } from "@utils/util";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { EventData } from "@onmoapp/event-hub-kinesis-adapter";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(customParseFormat);

export const handler = async (event: any) => {
    const logger = new Logger({ env: process.env.STAGE }, "INFO");

    /** Parse the event data */
    const data = event?.Records[0]?.kinesis?.data;
    let dataBuffer: any;

    dataBuffer = JSON.parse(
        Buffer.from(data, "base64").toString("utf-8"),
    ) as EventHubDataToPublishType;

    const cardProvisionedResponse: EventData<CardProvisionedEvent> = await deserializeUtil(
        dataBuffer.data,
        dataBuffer.schemaId,
    );

    logger.info("Card Provisioned Listener Event Received");
    logger.debug({
        message: "Card Provisioned Listener Event Received",
        cardProvisionedResponse,
    });

    let eventData: CardProvisionedEvent = cardProvisionedResponse?.eventData;

    const {
        cardId,
        accountId,
        lastFourDigits,
        creationDate,
        activationDate,
        expirationDate,
        statusCode,
        statusDate,
        reasonCode,
    } = eventData;

    if (!accountId || !cardId) {
        throw new OnmoError({
            name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
            message: "Account Id or Card Id missing in the event data",
        });
    }

    logger.addContext({ accountId, cardId });

    // Link card to the mambu account
    const coreBankingAdapter = await getCoreBankingAdapter();
    const cardLinkResponse = await coreBankingAdapter.linkCardToCreditAccount(accountId, cardId);

    logger.info({ message: "Card Link Response" });
    logger.debug({
        message: "Card Link Response",
        cardLinkResponse,
    });

    throwErrorIfAdapterResHaveError(cardLinkResponse, {
        message: "Failed to link card to account",
    });

    logger.info({ message: "Card Successfully Linked to the Account" });

    // Prepare the input for updating the account
    const updateCreditAccountInput: UpdateCreditAccountInput = {
        cardDetails: {
            cardId,
            lastFourDigits,
            creationDate,
            activationDate,
            expirationDate: dayjs(expirationDate, "YYMM").format("YYYY-MM-DD"), // Convert YYMM to YYYY-MM-DD
            status: statusCode,
            statusDate,
            event: reasonCode,
            physicalCardActivated: false,
        },
    };

    // Update the account with the new card status
    const updateAccountResponse = await coreBankingAdapter.updateCreditAccount(
        accountId,
        updateCreditAccountInput,
    );

    logger.info({ message: "Update Account Response" });
    logger.debug({
        message: "Update Account Response",
        updateAccountResponse,
    });

    throwErrorIfAdapterResHaveError(updateAccountResponse, {
        message: "Failed update the account",
    });

    logger.info({ message: "Card Provisioned Listener Event Processed Successfully" });
};
