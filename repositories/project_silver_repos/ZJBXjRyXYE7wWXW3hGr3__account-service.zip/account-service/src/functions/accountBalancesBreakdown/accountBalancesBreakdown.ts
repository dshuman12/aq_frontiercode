import { formatJSONResponse } from "@libs/api-gateway";
import { getCoreBankingAdapter } from "src/adapters";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { Logger } from "@onmoapp/onmo-logger";
import { GetAccountBalanceBreakdownOutcome } from "@onmoapp/onmo-types";
import { APIGatewayEvent } from "aws-lambda";
import { checkAccess } from "@utils/oidc-authorization";
import { queryTableMethod } from "@onmoapp/onmo-dynamodb";

export const handler = async (event: APIGatewayEvent) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        const accountId: string = event.pathParameters?.accountId || "";
        logger.addContext({ accountId });
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        /** will check access of user if request is from onmo api url */
        await checkAccess(event.requestContext, accountId);

        const queryMobileTableRes = await queryTableMethod({
            TableName: process.env.USER_TABLE,
            IndexName: "mambuCreditCardAccountID-index",
            KeyConditionExpression: "mambuCreditCardAccountID = :accountId",
            ExpressionAttributeValues: { ":accountId": accountId },
        });

        if (!queryMobileTableRes.Items || queryMobileTableRes.Items.length <= 0) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: `Customer doesn't exist in ${process.env.USER_TABLE} table`,
            });
        }
        logger.info(`User has record in ${process.env.USER_TABLE} table`);

        const technicalAccountId = queryMobileTableRes?.Items[0].mambuTechnicalAccountID;
        if (!technicalAccountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "Technical account ID not found in the mobile table",
            });
        }
        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountBreakdownResponse: GetAccountBalanceBreakdownOutcome =
            await coreBankingAdapter.getBalanceBreakdown(accountId, technicalAccountId);

        if (!accountBreakdownResponse.data || accountBreakdownResponse.error) {
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Failed to get account breakdown values",
                cause: accountBreakdownResponse.error,
            });
        }

        return formatJSONResponse(200, accountBreakdownResponse.data);
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
