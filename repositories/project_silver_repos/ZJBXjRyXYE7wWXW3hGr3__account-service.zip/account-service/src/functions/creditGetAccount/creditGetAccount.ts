import { APIGatewayProxyEvent, apiResponse, createApiHandler } from "@onmoapp/handler-middleware";
import { logger } from "@onmoapp/logger";
import dayjs from "dayjs";
import advancedFormat from "dayjs/plugin/advancedFormat";

import { getCoreBankingAdapter } from "src/adapters";
import { FeatureFlagClient } from "@onmoapp/feature-flag";
import { GetCreditAccountOutcome } from "@onmoapp/onmo-types";
import { GetAccountResponseBodyData } from "@libs/types";
import { calculateSmartPayment } from "@libs/smartPayment";
import { getActivePromotions } from "./promotionsUtil";
import { guardAccountAccess } from "@utils/authGuard";

dayjs.extend(advancedFormat);

const formatDDRetryDate = (d) => (d ? dayjs(d).format("D MMMM YYYY") : d);

export const creditGetAccountHandler = async (event: APIGatewayProxyEvent) => {
    const accountId: string = event.pathParameters?.accountId || "";
    logger.addContext("accountId", accountId);
    if (!accountId) {
        return apiResponse(400, { message: "AccountId missing in path params" });
    }

    /** will check access of user if request is from onmo api url */
    const access = await guardAccountAccess(event.requestContext, accountId);
    if (!access.allow) return access.response;

    const coreBankingAdapter = await getCoreBankingAdapter();
    const accountDetails: GetCreditAccountOutcome =
        await coreBankingAdapter.getCreditAccount(accountId);

    if (!accountDetails.data || accountDetails.error) {
        return apiResponse(404, {
            message: accountDetails.error?.errorMessage || "Failed to get account details",
        });
    }

    const minPayment = accountDetails.data.accountBalances.totalNextMinimumPaymentDue;
    const totalBalance = accountDetails.data.accountBalances.balances.total;
    const customerId = event.requestContext?.authorizer?.onmouuid;

    let smartPayment = null;
    if (minPayment > 0 && totalBalance != null && customerId) {
        try {
            const featureFlagClient = await FeatureFlagClient.build();
            smartPayment = await calculateSmartPayment(
                featureFlagClient,
                customerId,
                minPayment,
                totalBalance,
            );
        } catch (error) {
            logger.error(`Failed to get smart payment: ${error.message}`);
        }
    }

    const promotions = await getActivePromotions(accountId);

    const responseAccountDetails: GetAccountResponseBodyData = {
        accountDetails: {
            accountId: accountDetails.data.accountDetails.accountId,
            customerId: accountDetails.data.accountDetails.customerId,
            state: accountDetails.data.accountDetails.state,
            accountState: accountDetails.data.accountDetails.accountState,
            additionalAccountState: accountDetails.data.accountDetails.additionalAccountState,
            inArrearsDate: accountDetails.data.accountDetails.inArrearsDate,
            isInArrears: accountDetails.data.accountDetails.ifInArrears,
            creditLimit: accountDetails.data.accountDetails.creditLimit,
            availableCredit: accountDetails.data.accountDetails.availableCredit,
            apr: accountDetails.data.accountDetails.apr,
            interestRate: accountDetails.data.accountDetails.interestRate,
            startOfBillingCycle: accountDetails.data.accountDetails.startOfBillingCycle,
            nextStatementDueDate: accountDetails?.data.accountDetails?.nextStatementDueDate,
            daysLate: accountDetails?.data?.accountDetails?.daysLate ?? null,
        },
        directDebitSettings: {
            amountPreference: accountDetails.data.directDebitSettings.amountPreference,
            mandateID: accountDetails.data.directDebitSettings.mandateID,
            mandateReference: accountDetails.data.directDebitSettings.mandateReference,
            provider: accountDetails.data.directDebitSettings.provider,
            nextDirectDebitAmount: accountDetails.data.directDebitSettings.nextDirectDebitAmount,
            scheduledDirectDebitAmount:
                accountDetails.data.directDebitSettings.scheduledDirectDebitAmount,
            directDebitRetryInProgress:
                accountDetails.data.directDebitSettings.directDebitRetryInProgress,
            directDebitRetryDate: formatDDRetryDate(
                accountDetails.data.directDebitSettings.directDebitRetryDate,
            ),
            directDebitPreventRetryDate: formatDDRetryDate(
                accountDetails.data.directDebitSettings.directDebitPreventRetryDate,
            ),
            directDebitAvoidFeeCutOffDate: formatDDRetryDate(
                accountDetails.data.directDebitSettings.directDebitAvoidFeeCutOffDate,
            ),
        },
        accountBalances: {
            totalNextMinimumPaymentDue:
                accountDetails.data.accountBalances.totalNextMinimumPaymentDue,
            balances: {
                total: accountDetails.data.accountBalances.balances.total,
                principal: accountDetails.data.accountBalances.balances.principal,
                interest: accountDetails.data.accountBalances.balances.interest,
                fees: accountDetails.data.accountBalances.balances.fees,
            },
            arrearBalances: accountDetails.data.accountBalances.arrearBalances,
            due: accountDetails.data.accountBalances.due,
            suggestedSmartPaymentAmount: smartPayment?.suggestedAmount ?? null,
            smartPaymentMultiplier: smartPayment?.multiplier ?? null,
            smartPaymentVariant: smartPayment?.variant ?? null,
        },
        cards: accountDetails.data.cards,
        paymentPlans: [
            {
                type: accountDetails.data.paymentPlans[0].type,
                status: accountDetails.data.paymentPlans[0].paymentPlanStatus,
                amount: accountDetails.data.paymentPlans[0].paymentPlanAmount,
                startDate: accountDetails.data.paymentPlans[0].paymentPlanStartDate,
                endDate: accountDetails.data.paymentPlans[0].paymentPlanEndDate,
            },
        ],
        promotions,
    };

    return apiResponse(200, responseAccountDetails);
};

export const handler =
    createApiHandler<APIGatewayProxyEvent>(__HANDLER_NAME__).handle(creditGetAccountHandler);
