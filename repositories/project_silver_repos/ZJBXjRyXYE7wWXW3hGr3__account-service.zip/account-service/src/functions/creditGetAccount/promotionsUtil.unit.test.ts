import { describe, test, expect } from "vitest";

import { isPromotionLiveAt, toPromotionResponseItem } from "./promotionsUtil";
import { PromotionStatus, PromotionType } from "@libs/types/promotion";
import { makePromotionRecord } from "@utils/testUtils/promotionFixtures";

describe("isPromotionLiveAt", () => {
    const baseActive = () => makePromotionRecord({ start_date: 1000, end_date: 2000 });

    test("returns true when status is ACTIVE and now is inside [start, end]", () => {
        expect(isPromotionLiveAt(baseActive(), 1500)).toBe(true);
    });

    test("returns true at the exact boundaries (inclusive)", () => {
        expect(isPromotionLiveAt(baseActive(), 1000)).toBe(true);
        expect(isPromotionLiveAt(baseActive(), 2000)).toBe(true);
    });

    test("returns false when now is before start_date", () => {
        expect(isPromotionLiveAt(baseActive(), 999)).toBe(false);
    });

    test("returns false when now is after end_date", () => {
        expect(isPromotionLiveAt(baseActive(), 2001)).toBe(false);
    });

    test("returns false for APPLIED status inside the window", () => {
        expect(isPromotionLiveAt({ ...baseActive(), status: PromotionStatus.APPLIED }, 1500)).toBe(
            false,
        );
    });

    test("returns false for CANCELLED status inside the window", () => {
        expect(
            isPromotionLiveAt({ ...baseActive(), status: PromotionStatus.CANCELLED }, 1500),
        ).toBe(false);
    });
});

describe("toPromotionResponseItem", () => {
    test("strips internal fields and keeps only the consumer-safe shape", () => {
        const record = makePromotionRecord({
            promotional_interest_rate: 1.5,
            end_date: 1_800_000_000,
            version: 7,
            onmouuid: "secret-user",
        });

        expect(toPromotionResponseItem(record)).toEqual({
            promotionType: PromotionType.HONEYMOON,
            promotionalInterestRate: 1.5,
            originalInterestRate: 27.5,
            originalApr: 29.9,
            startDate: 1_700_000_000,
            endDate: 1_800_000_000,
        });
    });
});
