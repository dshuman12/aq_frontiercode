import { test, expect, beforeEach, afterEach } from "vitest";
import {
    CreditUserCredentials,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
    generateAccessTokenOfTestUser,
    deleteAccessTokenOfTestUser,
} from "@utils/testUtils";
import { GetAccountResponseBodyData, ErrorMessageResponse, accessTokenObject } from "@libs/types";
import { GetCreditAccountResponseSchema } from "@validators/testCasesValidation/creditGetAccount";

const onmo_api_url = process.env.ONMO_API_URL as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

let userCreds: CreditUserCredentials;
let accessToken: accessTokenObject;

beforeEach(async () => {
    userCreds = await setUpTestCreditCustomerAccount();
    accessToken = await generateAccessTokenOfTestUser(userCreds.customerId);
});

afterEach(async () => {
    await deleteTestCreditCustomerAccount(userCreds);
    await deleteAccessTokenOfTestUser(userCreds.customerId, accessToken);
});

const invokeGetAccount = async (accountId: string, token = accessToken.access_token) => {
    const get_account_url = `https://${onmo_api_url}/service/accounts/next/credit/${accountId}`;
    return await fetch(get_account_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            "x-api-test-secret": api_test_secret,
        },
    });
};

test("happy path", async () => {
    const response = await invokeGetAccount(userCreds.creditAccountId);
    expect(response.status).toBe(200);
    const responseBody = (await response.json()) as GetAccountResponseBodyData;

    // Validate the response body against the schema
    GetCreditAccountResponseSchema.parse(responseBody);
}, 50000);

test("trying to access any other's account should return 401 unauthorized access", async () => {
    const response = await invokeGetAccount("ABCD123", accessToken.access_token);

    expect(response.status).toBe(401);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("user is not authorized to access this account");
}, 50000);

test("invalid Access Token", async () => {
    const response = await invokeGetAccount(userCreds.creditAccountId, "INVALID_ACCESS_TOKEN");
    expect(response.status).toBe(401);
}, 50000);
