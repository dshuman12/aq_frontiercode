import { describe, test, expect, vi, beforeEach } from "vitest";
import { APIGatewayProxyEvent } from "@onmoapp/handler-middleware";

vi.mock("src/adapters");
vi.mock("@services/promotion", async (importOriginal) => {
    const actual = await importOriginal<typeof import("@services/promotion")>();
    return {
        ...actual,
        PromotionService: {
            getInstance: vi.fn(),
        },
    };
});
vi.mock("@utils/oidc-authorization", () => ({
    checkAccess: vi.fn(),
}));
vi.mock("@onmoapp/feature-flag", () => ({
    FeatureFlagClient: { build: vi.fn() },
}));
vi.mock("@libs/smartPayment", () => ({
    calculateSmartPayment: vi.fn(),
}));

import { getCoreBankingAdapter } from "src/adapters";
import { PromotionService } from "@services/promotion";
import { checkAccess } from "@utils/oidc-authorization";
import { creditGetAccountHandler } from "./creditGetAccount";
import { Success, Failure } from "@libs/types/result";
import { PromotionErrorCode, PromotionStatus, PromotionType } from "@libs/types/promotion";
import { makePromotionRecord } from "@utils/testUtils/promotionFixtures";

const makeEvent = (accountId?: string): APIGatewayProxyEvent =>
    ({
        pathParameters: accountId ? { accountId } : {},
        requestContext: { authorizer: {}, domainName: "internal.example.com" },
    }) as any;

const makeAccountData = () => ({
    accountDetails: {
        accountId: "ACC-001",
        customerId: "cust-1",
        state: "ACTIVE",
        accountState: "ACTIVE",
        additionalAccountState: null,
        inArrearsDate: null,
        ifInArrears: false,
        creditLimit: 1000,
        availableCredit: 900,
        apr: 24.9,
        interestRate: 22.5,
        startOfBillingCycle: "2026-01-01",
        nextStatementDueDate: "2026-02-01",
        daysLate: null,
    },
    directDebitSettings: {
        amountPreference: null,
        mandateID: null,
        mandateReference: null,
        provider: null,
        nextDirectDebitAmount: null,
        scheduledDirectDebitAmount: null,
        directDebitRetryInProgress: false,
        directDebitRetryDate: null,
        directDebitPreventRetryDate: null,
        directDebitAvoidFeeCutOffDate: null,
    },
    accountBalances: {
        totalNextMinimumPaymentDue: 0,
        balances: { total: 0, principal: 0, interest: 0, fees: 0 },
        arrearBalances: { total: null, principal: null, interest: null, fees: null },
        due: { total: 0, principal: 0, interest: 0, fees: 0 },
    },
    cards: [],
    paymentPlans: [
        {
            type: null,
            paymentPlanStatus: null,
            paymentPlanAmount: null,
            paymentPlanStartDate: null,
            paymentPlanEndDate: null,
        },
    ],
});

describe("creditGetAccount handler", () => {
    let mockGetForAccount: ReturnType<typeof vi.fn>;

    beforeEach(() => {
        vi.clearAllMocks();
        mockGetForAccount = vi.fn().mockResolvedValue(Success([]));
        vi.mocked(PromotionService.getInstance).mockReturnValue({
            getForAccount: mockGetForAccount,
        } as any);
        vi.mocked(checkAccess).mockResolvedValue();
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi.fn().mockResolvedValue({
                data: makeAccountData(),
                error: null,
            }),
        });
    });

    test("400 when accountId is missing from path", async () => {
        const response = await creditGetAccountHandler(makeEvent());

        expect(response.statusCode).toBe(400);
        expect(response.body).toEqual({ message: "AccountId missing in path params" });
    });

    test("404 when core-banking returns no account data", async () => {
        vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue({
            getCreditAccount: vi
                .fn()
                .mockResolvedValue({ data: null, error: { code: "NOT_FOUND" } }),
        });

        const response = await creditGetAccountHandler(makeEvent("ACC-001"));

        expect(response.statusCode).toBe(404);
        expect(response.body).toEqual({ message: "Failed to get account details" });
    });

    test("200 with empty promotions when none exist", async () => {
        const response = await creditGetAccountHandler(makeEvent("ACC-001"));

        expect(response.statusCode).toBe(200);
        expect((response.body as any).promotions).toEqual([]);
        expect(mockGetForAccount).toHaveBeenCalledWith("ACC-001");
    });

    test("200 returns sanitised active promo, strips internal fields", async () => {
        const activeRecord = makePromotionRecord({
            start_date: 1_700_000_000,
            end_date: 9_999_999_999,
            promotional_interest_rate: 1.5,
        });
        mockGetForAccount.mockResolvedValue(Success([activeRecord]));

        const response = await creditGetAccountHandler(makeEvent("ACC-001"));

        expect(response.statusCode).toBe(200);
        expect((response.body as any).promotions).toEqual([
            {
                promotionType: PromotionType.HONEYMOON,
                promotionalInterestRate: 1.5,
                originalInterestRate: 27.5,
                originalApr: 29.9,
                startDate: 1_700_000_000,
                endDate: 9_999_999_999,
            },
        ]);
    });

    test("filters out APPLIED/CANCELLED and out-of-window ACTIVE promos", async () => {
        const applied = makePromotionRecord({
            promotion_id: "HONEYMOON#1600000000",
            status: PromotionStatus.APPLIED,
        });
        const cancelled = makePromotionRecord({
            promotion_id: "HONEYMOON#1650000000",
            status: PromotionStatus.CANCELLED,
        });
        const expiredActive = makePromotionRecord({
            promotion_id: "HONEYMOON#1500000000",
            start_date: 1_500_000_000,
            end_date: 1_600_000_000,
        });
        const futureActive = makePromotionRecord({
            promotion_id: "HONEYMOON#9999999998",
            start_date: 9_999_999_998,
            end_date: 9_999_999_999,
        });
        const live = makePromotionRecord({
            promotion_id: "HONEYMOON#1700000000",
            start_date: 1_700_000_000,
            end_date: 9_999_999_999,
        });
        mockGetForAccount.mockResolvedValue(
            Success([applied, cancelled, expiredActive, futureActive, live]),
        );

        const response = await creditGetAccountHandler(makeEvent("ACC-001"));

        expect(response.statusCode).toBe(200);
        expect((response.body as any).promotions).toHaveLength(1);
        expect((response.body as any).promotions[0].startDate).toBe(1_700_000_000);
    });

    test("DynamoDB query failure does not fail the account load; returns empty promotions", async () => {
        mockGetForAccount.mockResolvedValue(
            Failure({ code: PromotionErrorCode.QUERY_FAILED, message: "DDB timeout" }),
        );

        const response = await creditGetAccountHandler(makeEvent("ACC-001"));

        expect(response.statusCode).toBe(200);
        expect((response.body as any).promotions).toEqual([]);
    });
});
