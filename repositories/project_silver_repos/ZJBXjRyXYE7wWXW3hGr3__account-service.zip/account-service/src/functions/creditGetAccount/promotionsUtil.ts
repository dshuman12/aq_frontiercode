import dayjs from "dayjs";
import { logger } from "@onmoapp/logger";

import { PromotionRecord, PromotionResponseItem, PromotionStatus } from "@libs/types/promotion";
import { PromotionService } from "@services/promotion";

export const isPromotionLiveAt = (record: PromotionRecord, nowSeconds: number): boolean =>
    record.status === PromotionStatus.ACTIVE &&
    record.start_date <= nowSeconds &&
    record.end_date >= nowSeconds;

export const toPromotionResponseItem = (record: PromotionRecord): PromotionResponseItem => ({
    promotionType: record.promotion_type,
    promotionalInterestRate: record.promotional_interest_rate,
    originalInterestRate: record.original_interest_rate,
    originalApr: record.original_apr,
    startDate: record.start_date,
    endDate: record.end_date,
});

export const getActivePromotions = async (accountId: string): Promise<PromotionResponseItem[]> => {
    const result = await PromotionService.getInstance().getForAccount(accountId);
    if (!result.ok) {
        logger.error(`Failed to fetch promotions: ${result.error.message}`);
        return [];
    }
    const now = dayjs().unix();
    return result.data
        .filter((record) => isPromotionLiveAt(record, now))
        .map(toPromotionResponseItem);
};
