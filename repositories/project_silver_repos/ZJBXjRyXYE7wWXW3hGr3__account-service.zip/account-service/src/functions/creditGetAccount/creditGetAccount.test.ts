import { test, expect, beforeAll, afterAll, describe, afterEach, beforeEach } from "vitest";
import {
    CreditUserCredentials,
    fetchAPISecret,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
    createUserRecordInMobileTable,
} from "@utils/testUtils";
import { seedPromotion, teardownSeededPromotions } from "@utils/testUtils/promotion.testUtils";
import { GetAccountResponseBodyData, ErrorMessageResponse } from "@libs/types";
import { GetCreditAccountResponseSchema } from "@validators/testCasesValidation/creditGetAccount";
import { getCoreBankingAdapter } from "src/adapters";
import { TECHNICAL_ACCOUNT_PRODUCT_KEY } from "@libs/constants";
import { CreateTechnicalAccountOutcome } from "@onmoapp/onmo-types";
import { PromotionType } from "@libs/types/promotion";
import dayjs from "dayjs";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetAccount = async (
    accountId: string,
    apiKey: string,
    includeApiKey: boolean = true,
) => {
    const get_account_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}`;
    return await fetch(get_account_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKey } : {}),
            "x-api-test-secret": api_test_secret,
        },
    });
};

describe("GET Credit Account Endpoint Test cases", () => {
    beforeAll(async () => {
        apiKey = await fetchAPISecret();
        userCreds = await setUpTestCreditCustomerAccount();
    });

    afterAll(async () => {
        await teardownSeededPromotions();
        await deleteTestCreditCustomerAccount(userCreds);
    });

    test("happy path", async () => {
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        // Validate the response body against the schema
        GetCreditAccountResponseSchema.parse(responseBody);
        expect(responseBody.promotions).toEqual([]);
    });

    test("returns active promotion in response when one exists for the account", async () => {
        const now = dayjs().unix();
        const seeded = await seedPromotion({
            credit_account_id: userCreds.creditAccountId,
            onmouuid: userCreds.customerId,
            start_date: now - 24 * 3600,
            end_date: now + 30 * 24 * 3600,
            promotional_interest_rate: 0,
            original_interest_rate: 22.5,
            original_apr: 24.9,
        });

        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        GetCreditAccountResponseSchema.parse(responseBody);
        expect(responseBody.promotions).toHaveLength(1);
        expect(responseBody.promotions[0]).toEqual({
            promotionType: PromotionType.HONEYMOON,
            promotionalInterestRate: 0,
            originalInterestRate: 22.5,
            originalApr: 24.9,
            startDate: seeded.start_date,
            endDate: seeded.end_date,
        });
    });

    test("non-existent account id", async () => {
        const response = await invokeGetAccount("fake-accountId", apiKey);

        expect(response.status).toBe(404);
        const responseBody = (await response.json()) as ErrorMessageResponse;
        expect(responseBody.message).toEqual("Could not found an account");
    });

    test("no api key", async () => {
        const includeApiKey = false;
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey, includeApiKey);

        const responseBody = await response.json();

        expect(response.status).toBe(401);
        expect(responseBody).toEqual({ message: "Unauthorized" });
    });
});

describe("GET credit account test cases, Technical Account scenarios", () => {
    beforeAll(async () => {
        apiKey = await fetchAPISecret();
    });

    beforeEach(async () => {
        userCreds = await setUpTestCreditCustomerAccount();
    });

    afterEach(async () => {
        await deleteTestCreditCustomerAccount(userCreds);
    });

    test("happy path: customer has only one technical account", async () => {
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        // Validate the response body against the schema
        GetCreditAccountResponseSchema.parse(responseBody);
    });

    test("happy path: customer has only one technical account but Nothing in Mobile Db", async () => {
        // update user record without technical account
        await createUserRecordInMobileTable({
            customerId: userCreds.customerId,
            coreBankingCustomerId: userCreds.coreBankingCustomerId,
            creditAccountId: userCreds.creditAccountId,
        } as any);
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        // Validate the response body against the schema
        GetCreditAccountResponseSchema.parse(responseBody);
    });

    test("happy path: customer has only one technical account but mismatched in Mobile Db", async () => {
        // update user record without technical account
        await createUserRecordInMobileTable({ ...userCreds, technicalAccountId: "MIS_MATCH" });
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        // Validate the response body against the schema
        GetCreditAccountResponseSchema.parse(responseBody);
    });

    test("happy path: customer has two technical account should pick up which mention in Mobile DB", async () => {
        /** attaching the second technical account to the customer */
        const coreBankingAdapter = await getCoreBankingAdapter();
        const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
            await coreBankingAdapter.createTechnicalAccount({
                coreBankingCustomerEncodedKey: userCreds.coreBankingCustomerEncodedKey,
                productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
            });
        await coreBankingAdapter.approveTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(200);
        const responseBody = (await response.json()) as GetAccountResponseBodyData;

        // Validate the response body against the schema
        GetCreditAccountResponseSchema.parse(responseBody);

        // deleting the second technical account
        await coreBankingAdapter.deleteTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
    });

    test("sad path: none of mambu the technical account matches Mobile Db one", async () => {
        /** attaching the second technical account to the customer */
        const coreBankingAdapter = await getCoreBankingAdapter();
        const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
            await coreBankingAdapter.createTechnicalAccount({
                coreBankingCustomerEncodedKey: userCreds.coreBankingCustomerEncodedKey,
                productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
            });
        await coreBankingAdapter.approveTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
        await createUserRecordInMobileTable({ ...userCreds, technicalAccountId: "NOTHING" });
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(404);
        expect(await response.json()).toEqual({
            message: "Mambu Technical Accounts are mismatched with mobile DB Technical Account",
        });

        // deleting the second technical account
        await coreBankingAdapter.deleteTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
    });

    test("sad path: technical account is not found in Mobile DB", async () => {
        /** attaching the second technical account to the customer */
        const coreBankingAdapter = await getCoreBankingAdapter();
        const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
            await coreBankingAdapter.createTechnicalAccount({
                coreBankingCustomerEncodedKey: userCreds.coreBankingCustomerEncodedKey,
                productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
            });
        await coreBankingAdapter.approveTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
        // update user record without technical account
        await createUserRecordInMobileTable({
            customerId: userCreds.customerId,
            coreBankingCustomerId: userCreds.coreBankingCustomerId,
            creditAccountId: userCreds.creditAccountId,
        } as any);
        const response = await invokeGetAccount(userCreds.creditAccountId, apiKey);
        expect(response.status).toBe(404);
        expect(await response.json()).toEqual({
            message: "Technical account has been not found in mobile DB",
        });

        // deleting the second technical account
        await coreBankingAdapter.deleteTechnicalAccount(
            createTechnicalAccountOutcome.data.technicalAccountId,
        );
    });
});
