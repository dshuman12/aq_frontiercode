import { formatJSONResponse } from "@libs/api-gateway";
import { getCoreBankingAdapter } from "src/adapters";
import { Statuses, UpdateCreditAccountInput } from "@onmoapp/onmo-types";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { Logger } from "@onmoapp/onmo-logger";

export const handler = async (event: any) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        // validate accountId is on path params
        const accountId: string = event.pathParameters?.accountId || "";
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });
        logger.info("Got accountId from path parameters");

        // form initial input object for updateCreditAccount adapter method
        const statuses: Statuses = {
            lockedStatus: "FULL_LOCK",
        };

        // update account by calling adapter method
        logger.info(`Updating account locked_status to "FULL_LOCK"`);
        const detailsToUpdate: UpdateCreditAccountInput = { statuses };
        const coreBankingAdapter = await getCoreBankingAdapter();
        const response = await coreBankingAdapter.updateCreditAccount(accountId, detailsToUpdate);

        // handle error response from adapter method
        if (!response || response.error || !response.data) {
            logger.error(`Unable to update account: ${JSON.stringify(response?.error)}`);
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to update account",
                cause: response?.error,
            });
        }

        logger.info("Full lock applied successfully");
        return formatJSONResponse(200, { message: "Full lock applied" });
    } catch (error) {
        logger.error(`Error occurred in creditFullLock handler: ${error}`);
        const { statusCode, message } = generateErrorResponse(error);
        logger.error(message);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
