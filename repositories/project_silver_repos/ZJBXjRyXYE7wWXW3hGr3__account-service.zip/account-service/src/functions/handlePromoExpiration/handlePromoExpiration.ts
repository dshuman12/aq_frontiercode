import { createEventHandler, ScheduledEvent } from "@onmoapp/handler-middleware";
import { logger } from "@onmoapp/logger";

import { PromotionService } from "@services/promotion";
import { PromotionRecord, PromotionType } from "@libs/types/promotion";

export const MARK_APPLIED_BATCH_SIZE = 100;

export const handlerLogic = async () => {
    const promotionService = PromotionService.getInstance();
    let cursor: Record<string, unknown> | undefined = undefined;
    let count = 0;

    do {
        let result;
        result = await promotionService.getExpiredActive(PromotionType.HONEYMOON, cursor);

        if (!result.ok) {
            logger.error(`Failed to query expired promotions: ${result.error.message}`);
            break;
        }

        const { items, cursor: nextCursor } = result.data;
        cursor = nextCursor;

        for (let i = 0; i < items.length; i += MARK_APPLIED_BATCH_SIZE) {
            const batch = items.slice(i, i + MARK_APPLIED_BATCH_SIZE);
            const settled = await Promise.allSettled(
                batch.map(async (record: PromotionRecord) => promotionService.markApplied(record)),
            );

            for (const [index, result] of settled.entries()) {
                const { promotion_id } = batch[index];
                if (result.status === "rejected") {
                    logger.error(
                        `Failed to apply expired promotion ${promotion_id}: ${String(result.reason)}`,
                    );
                    continue;
                }
                if (!result.value.ok) {
                    logger.error(
                        `Failed to apply expired promotion ${promotion_id}: ${result.value.error.message}`,
                    );
                    continue;
                }
                count++;
            }
        }
    } while (cursor !== undefined);

    logger.addContext("records_applied", count);
};

export const handler = createEventHandler<ScheduledEvent>(__HANDLER_NAME__).handle(handlerLogic);
