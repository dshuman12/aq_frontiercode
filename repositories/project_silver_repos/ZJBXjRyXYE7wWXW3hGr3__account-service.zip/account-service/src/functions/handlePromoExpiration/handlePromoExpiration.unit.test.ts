import { describe, expect, test, vi, beforeEach } from "vitest";
import { handler, handlerLogic, MARK_APPLIED_BATCH_SIZE } from "./handlePromoExpiration";
import { PromotionService } from "@services/promotion";
import {
    PromotionRecord,
    PromotionType,
    PromotionStatus,
    NotificationStatus,
} from "@libs/types/promotion";
import { logger } from "@onmoapp/logger";

vi.mock("@services/promotion", () => ({
    PromotionService: {
        getInstance: vi.fn(),
    },
}));

vi.mock("@onmoapp/logger", () => ({
    logger: {
        addContext: vi.fn(),
        error: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
    },
}));

const scheduledEvent = {
    version: "0",
    id: "test-event-id",
    "detail-type": "Scheduled Event" as const,
    source: "aws.events",
    account: "123456789",
    time: "2024-01-01T02:00:00Z",
    region: "eu-west-1",
    resources: ["arn:aws:events:eu-west-1:123456789:rule/promoDaily-test"],
    detail: {},
};

const makeRecord = (overrides: Partial<PromotionRecord> = {}): PromotionRecord => ({
    id: "partition-key",
    promotion_id: "HONEYMOON#1700000000",
    onmouuid: "onmo-uuid-1",
    promotion_type: PromotionType.HONEYMOON,
    credit_account_id: "ACC-001",
    promotional_interest_rate: 0,
    original_interest_rate: 5.5,
    original_apr: 6.1,
    status: PromotionStatus.ACTIVE,
    notification_status: NotificationStatus.PENDING,
    start_date: 1700000000,
    end_date: 1703000000,
    applied_at: null,
    cancelled_at: null,
    notification_sent_at: null,
    cancelled_reason: null,
    version: 1,
    created_at: 1700000000,
    updated_at: 1700000000,
    ...overrides,
});

const makePageOk = (items: PromotionRecord[], cursor?: Record<string, unknown>) => ({
    ok: true,
    data: { items, cursor },
});

const makePageFail = (message: string) => ({ ok: false, error: { message } });

const makeMarkOk = () => ({ ok: true, data: undefined });
const makeMarkFail = (message: string) => ({ ok: false, error: { message } });

describe("handlePromoExpiration", () => {
    let mockGetExpiredActive: ReturnType<typeof vi.fn>;
    let mockMarkApplied: ReturnType<typeof vi.fn>;

    beforeEach(() => {
        vi.clearAllMocks();
        mockGetExpiredActive = vi.fn();
        mockMarkApplied = vi.fn().mockResolvedValue(makeMarkOk());
        vi.mocked(PromotionService.getInstance).mockReturnValue({
            getExpiredActive: mockGetExpiredActive,
            markApplied: mockMarkApplied,
        } as any);
    });

    test("handler is a function", () => {
        expect(typeof handler).toBe("function");
    });

    test("handler resolves without throwing on a scheduled event", async () => {
        mockGetExpiredActive.mockResolvedValue(makePageOk([]));
        await expect(handler(scheduledEvent, {} as any)).resolves.toBeUndefined();
    });

    test("records found — markApplied called once and count logged as 1", async () => {
        const record = makeRecord();
        mockGetExpiredActive.mockResolvedValue(makePageOk([record]));

        await handlerLogic();

        expect(mockMarkApplied).toHaveBeenCalledTimes(1);
        expect(mockMarkApplied).toHaveBeenCalledWith(record);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 1);
    });

    test("no records — markApplied never called and count logged as 0", async () => {
        mockGetExpiredActive.mockResolvedValue(makePageOk([]));

        await handlerLogic();

        expect(mockMarkApplied).not.toHaveBeenCalled();
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 0);
    });

    test("pagination — two pages processed, markApplied called twice and count logged as 2", async () => {
        const record1 = makeRecord({ credit_account_id: "ACC-001" });
        const record2 = makeRecord({ credit_account_id: "ACC-002" });
        const paginationCursor = { pk: "cursor-token" };

        mockGetExpiredActive
            .mockResolvedValueOnce(makePageOk([record1], paginationCursor))
            .mockResolvedValueOnce(makePageOk([record2]));

        await handlerLogic();

        expect(mockGetExpiredActive).toHaveBeenCalledTimes(2);
        expect(mockGetExpiredActive).toHaveBeenNthCalledWith(1, PromotionType.HONEYMOON, undefined);
        expect(mockGetExpiredActive).toHaveBeenNthCalledWith(
            2,
            PromotionType.HONEYMOON,
            paginationCursor,
        );
        expect(mockMarkApplied).toHaveBeenCalledTimes(2);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 2);
    });

    test("batch boundary — MARK_APPLIED_BATCH_SIZE + 1 records processed across two batches", async () => {
        const records = Array.from({ length: MARK_APPLIED_BATCH_SIZE + 1 }, (_, i) =>
            makeRecord({ credit_account_id: `ACC-${String(i).padStart(3, "0")}` }),
        );
        mockGetExpiredActive.mockResolvedValueOnce(makePageOk(records));

        await handlerLogic();

        expect(mockMarkApplied).toHaveBeenCalledTimes(MARK_APPLIED_BATCH_SIZE + 1);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith(
            "records_applied",
            MARK_APPLIED_BATCH_SIZE + 1,
        );
    });

    test("markApplied failure — error logged, handler resolves, remaining records still processed", async () => {
        const record1 = makeRecord({ credit_account_id: "ACC-001" });
        const record2 = makeRecord({ credit_account_id: "ACC-002" });
        mockGetExpiredActive.mockResolvedValue(makePageOk([record1, record2]));

        mockMarkApplied
            .mockResolvedValueOnce(makeMarkFail("ConditionalCheckFailedException"))
            .mockResolvedValueOnce(makeMarkOk());

        await expect(handlerLogic()).resolves.toBeUndefined();

        expect(mockMarkApplied).toHaveBeenCalledTimes(2);
        expect(vi.mocked(logger.error)).toHaveBeenCalledOnce();
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(
            "ConditionalCheckFailedException",
        );
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(record1.promotion_id);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 1);
    });

    test("markApplied rejected promise — error logged, handler resolves, remaining records still processed", async () => {
        const record1 = makeRecord({ credit_account_id: "ACC-001" });
        const record2 = makeRecord({ credit_account_id: "ACC-002" });
        mockGetExpiredActive.mockResolvedValue(makePageOk([record1, record2]));

        mockMarkApplied
            .mockRejectedValueOnce(new Error("Network timeout"))
            .mockResolvedValueOnce(makeMarkOk());

        await expect(handlerLogic()).resolves.toBeUndefined();

        expect(mockMarkApplied).toHaveBeenCalledTimes(2);
        expect(vi.mocked(logger.error)).toHaveBeenCalledOnce();
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain("Network timeout");
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(record1.promotion_id);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 1);
    });

    test("getExpiredActive failure — error logged, markApplied never called, handler resolves", async () => {
        mockGetExpiredActive.mockResolvedValue(
            makePageFail("Failed to query promotions (sweep-index)"),
        );

        await expect(handlerLogic()).resolves.toBeUndefined();

        expect(mockMarkApplied).not.toHaveBeenCalled();
        expect(vi.mocked(logger.error)).toHaveBeenCalledOnce();
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(
            "Failed to query expired promotions",
        );
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_applied", 0);
    });
});
