import { StatementEffect } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { APIGatewayRequestAuthorizerEvent, Callback, APIGatewayAuthorizerResult } from "aws-lambda";

const generatePolicy = (effect: StatementEffect, resource: string): APIGatewayAuthorizerResult => {
    return {
        principalId: "user",
        policyDocument: {
            Version: "2012-10-17",
            Statement: [
                {
                    Action: "execute-api:Invoke",
                    Effect: effect,
                    Resource: resource,
                },
            ],
        },
    };
};

const getHeaderCaseInsensitive = (headers, headerName) => {
    const lowerCaseHeaderName = headerName.toLowerCase();
    return (
        headers[lowerCaseHeaderName] ||
        headers[Object.keys(headers).find((key) => key.toLowerCase() === lowerCaseHeaderName)]
    );
};

export const handler = async (
    event: APIGatewayRequestAuthorizerEvent,
    _context: any,
    callback: Callback,
) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        logger.info(`Received event: ${JSON.stringify(event)}`);

        const receivedApiKey: string = event.headers["x-api-key"] || event.headers["X-Api-Key"];
        if (!receivedApiKey) {
            logger.error("No api key in request headers");
            return callback("Unauthorized");
        }

        //get host from headers
        const host: string = getHeaderCaseInsensitive(event.headers, "host");
        if (!host) {
            logger.error("No host in request headers");
            return callback("Unauthorized");
        }
        logger.info(`Host is ${host}`);

        //get user agent from headers
        const userAgent: string = getHeaderCaseInsensitive(event.headers, "user-agent");
        logger.info(`User agent is ${userAgent}`);
        const allowedWebhookUserAgents = [
            ...(process.env.MAMBU_WEBHOOKS_USER_AGENTS || "").split(","),
            ...(process.env.APATA_WEBHOOKS_USER_AGENTS || "").split(","),
        ]
            .map((val) => val.trim())
            .filter(Boolean);

        //get api key based on host and/or user agent value
        const secretString: string = (await getSecret(process.env.API_KEY_SECRET_ARN)).SecretString;
        const storedApiKey: string =
            host === process.env.CRM_API_DOMAIN_NAME || allowedWebhookUserAgents.includes(userAgent)
                ? JSON.parse(secretString).staticApiKey
                : JSON.parse(secretString).apiKey;

        if (!storedApiKey) {
            logger.error("No api key found in secrets manager");
            return callback("Unauthorized");
        }

        if (receivedApiKey !== storedApiKey) {
            logger.error("Api key mismatch");
            return callback("Unauthorized");
        }

        logger.info("API keys match, returning allow policy");
        callback(null, generatePolicy("Allow", event.methodArn));
    } catch (error) {
        logger.error(
            `Authorization failed because ${error.message || error}, returning unauthorized`,
        );
        callback("Unauthorized");
    }
};
