import { test, expect, beforeAll, afterAll } from "vitest";
import {
    CreditUserCredentials,
    fetchAPISecret,
    setUpTestCreditCustomerAccount,
    deleteTestCreditCustomerAccount,
} from "@utils/testUtils";
import { UpdateAccountFlagRequestBody } from "@libs/types/updateAccountFlag";
import { ACCOUNT_FLAGS } from "@libs/constants";

let userCreds: CreditUserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeUpdateAccountFlag = async (
    accountId: string,
    eventBody: UpdateAccountFlagRequestBody,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const update_flag_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/update-flag`;
    return await fetch(update_flag_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(eventBody),
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    userCreds = await setUpTestCreditCustomerAccount();
});
afterAll(async () => {
    await deleteTestCreditCustomerAccount(userCreds);
});

for (let flag of ACCOUNT_FLAGS) {
    test("happy path: Should Update Account Flag for ${flag}", async () => {
        const response = await invokeUpdateAccountFlag(userCreds.creditAccountId, {
            flagName: flag,
            flagDetails: {
                status: Math.random() < 0.5, // random boolean (true or false),
                startDate: new Date()?.toISOString()?.split("T")[0],
                endDate: new Date()?.toISOString()?.split("T")[0],
            },
        });

        expect(response.status).toBe(200);
        const responseBody = await response.json();
        expect(responseBody).toEqual({ message: "Successfully updated Flags" });
    });
}

test("sad path: Should throw Validation Error for Invalid Flag", async () => {
    const response = await invokeUpdateAccountFlag(userCreds.creditAccountId, {
        flagName: "invalid_flag",
        flagDetails: {
            status: true,
        },
    } as any);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Invalid account flag" });
}, 10000);

test("sad path: Should throw Validation Error for Invalid Flag status", async () => {
    const response = await invokeUpdateAccountFlag(userCreds.creditAccountId, {
        flagName: "ActiveComplaint",
        flagDetails: {
            status: "invalid",
        },
    } as any);

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "flagDetails.status must be a boolean" });
}, 10000);

test("sad path: Should throw Validation Error for Invalid start Date Format", async () => {
    const response = await invokeUpdateAccountFlag(userCreds.creditAccountId, {
        flagName: "ActiveComplaint",
        flagDetails: {
            status: true,
            startDate: "20234-04-01",
            endDate: "2023-04-01",
        },
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "please enter a valid flagDetails.startDate in YYYY-MM-DD format",
    });
}, 10000);

test("sad path: Should throw Validation Error for Invalid end Date", async () => {
    const response = await invokeUpdateAccountFlag(userCreds.creditAccountId, {
        flagName: "ActiveComplaint",
        flagDetails: {
            status: true,
            startDate: "2023-04-01",
            endDate: "2023-15-01",
        },
    });

    expect(response.status).toBe(400);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: "please enter a valid flagDetails.endDate in YYYY-MM-DD format",
    });
}, 10000);

test("non-existent account id", async () => {
    /** invalid account Id */
    const response = await invokeUpdateAccountFlag("invalid", {
        flagName: "ActiveComplaint",
        flagDetails: {
            status: true,
            startDate: "2023-04-01",
            endDate: "2023-04-01",
        },
    });

    expect(response.status).toBe(404);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Could not found an account" });
}, 10000);

test("Sad Path: no api key", async () => {
    const apiKeyValue = apiKey;
    const includeApiKey = false;
    const response = await invokeUpdateAccountFlag(
        userCreds.creditAccountId,
        {
            flagName: "ActiveComplaint",
            flagDetails: {
                status: true,
                startDate: "2023-04-01",
                endDate: "2023-04-01",
            },
        },
        apiKeyValue,
        includeApiKey,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);

test("Sad Path: Invalid Api key", async () => {
    const apiKeyValue = "invalid-api-key-XXXXX";
    const response = await invokeUpdateAccountFlag(
        userCreds.creditAccountId,
        {
            flagName: "ActiveComplaint",
            flagDetails: {
                status: true,
                startDate: "2023-04-01",
                endDate: "2023-04-01",
            },
        },
        apiKeyValue,
    );

    expect(response.status).toBe(401);
    const responseBody = await response.json();
    expect(responseBody).toEqual({ message: "Unauthorized" });
}, 10000);
