import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/api-gateway";
import { getCoreBankingAdapter } from "src/adapters";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { checkValidation } from "@validators/index";
import { accountIdPathParametersSchema } from "@validators/account.validator";
import { updateAccountFlagSchema } from "@validators/updateFlag.validator";
import { UpdateAccountFlagRequestBody } from "@libs/types/updateAccountFlag";
import { transformFlagToCoreBankingInputType } from "@utils/transform";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        const payload = parseAPIGateWayEventBody(event.body || "{}");
        // validate accountId is on path params
        // Validate the path parameters against the provided schema and extract the 'accountId'.
        const { accountId } = checkValidation(
            accountIdPathParametersSchema,
            event.pathParameters ?? {},
        );
        logger.addContext({ accountId });
        const { flagName, flagDetails } = checkValidation(
            updateAccountFlagSchema,
            payload ?? {},
        ) as UpdateAccountFlagRequestBody;

        const patchPayload = transformFlagToCoreBankingInputType(flagName, {
            flagStatus: flagDetails.status,
            startDate: flagDetails?.startDate,
            endDate: flagDetails?.endDate,
        });
        logger.info({
            message: "we have successfully prepared payload",
            patchPayloadKeys: (patchPayload && Object.keys(patchPayload)) ?? null,
        });
        logger.debug({ patchPayload });

        /**
         * NOTE:
         * Added logic to fetch the account to handle cases where the PATCH payload
         * contains only extra flags and no updates for Mambu.
         * This ensures that if the account ID is invalid, we will return a 400 status code.
         */

        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountDetails = await coreBankingAdapter.getCreditAccount(accountId);
        logger.info({
            message: "Successfully fetched account details",
        });
        logger.debug({ accountDetails });
        throwErrorIfAdapterResHaveError(accountDetails, {
            message: "Failed to get credit account Details",
        });
        if (patchPayload) {
            /** if there is actually anything to update in Core banking */
            const updatedRes = await coreBankingAdapter.updateCreditAccount(accountId, {
                flags: patchPayload,
            });
            logger.debug({ updatedRes });
            throwErrorIfAdapterResHaveError(updatedRes, {
                message: "Failed to Update Account Flag in CoreBanking Account",
            });
        }
        logger.info({ message: "Account Flags updated successfully" });
        return formatJSONResponse(200, { message: "Successfully updated Flags" });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
