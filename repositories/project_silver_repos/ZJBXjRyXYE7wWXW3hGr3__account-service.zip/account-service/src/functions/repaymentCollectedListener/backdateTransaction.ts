import { RepaymentCollectedEvent } from "@libs/types";
import { EventData, getEventHubAdapter } from "src/adapters";
import { OnmoError } from "@onmoapp/onmo-error-types";
import { Logger } from "@onmoapp/onmo-logger";
import dayjs from "dayjs";
import { v4 as uuid } from "uuid";

export const backdateTransaction = async (
    repaymentCollectedEvent: EventData<RepaymentCollectedEvent>,
    logger: Logger,
) => {
    const repaymentCollected = repaymentCollectedEvent.eventData;

    const repaymentDate = dayjs(repaymentCollected.date);
    const today = dayjs();

    if (repaymentDate.isSame(today, "day")) {
        // This was the last available date to put the transaction. Throw. (this shouldn't happen)
        logger.error;
        throw new OnmoError({
            message: "Could not backdate transaction.",
            name: "SOME_ERROR_OCCURRED",
        });
    }

    let addedOneDay = repaymentDate.add(1, "day");

    if (addedOneDay.isSame(today, "day")) {
        // if there were any disbursement same day we need to make sure we try to enter the transaction after
        // otherwise we will keep getting the excess repayment error
        addedOneDay = addedOneDay.set("hour", today.hour());
        addedOneDay = addedOneDay.set("minute", today.minute());
        addedOneDay = addedOneDay.set("second", today.second());
    }

    logger.info({
        message: `Retrying the transaction for ${addedOneDay.toISOString()} ${repaymentCollectedEvent.eventData.accountId}`,
    });

    // Send a new event with the new date to try to record the transaction
    repaymentCollectedEvent.idempotencyKey = uuid(); // need a new key as we are sending a new payload
    repaymentCollectedEvent.initiatedBy = "repaymentCollected-excess-repayment-retry";
    repaymentCollectedEvent.eventData.date = addedOneDay.toISOString();
    repaymentCollectedEvent.id = uuid(); // new event id

    const eventHubAdapter = await getEventHubAdapter<RepaymentCollectedEvent>();
    const { isValid: isEventValid, validationErrors } =
        await eventHubAdapter.validateEvent(repaymentCollectedEvent);
    if (!isEventValid) {
        logger.error({ message: "Validation failed", validationErrors });
        throw new OnmoError({
            message: "Validation failed",
            name: "SOME_ERROR_OCCURRED",
            cause: validationErrors,
        });
    }
    const {
        isPublished,
        isValid,
        validationErrors: publishError,
    } = await eventHubAdapter.publishToEventHub(repaymentCollectedEvent);
    if (!isPublished || !isValid) {
        logger.error({ message: "Failed to publish event", publishError });
        throw new OnmoError({
            message: "Failed to publish event",
            name: "SOME_ERROR_OCCURRED",
            cause: validationErrors,
        });
    }
    logger.info({ message: "Event published successfully" });
};
