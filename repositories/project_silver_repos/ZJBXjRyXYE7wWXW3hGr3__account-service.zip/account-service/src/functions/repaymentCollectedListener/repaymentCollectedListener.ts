import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { getLogger } from "@utils/logger";
import { processRepayment } from "@libs/processRepayment";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { RepaymentCollectedEvent } from "@libs/types";
dayjs.extend(customParseFormat);

export const handler = async (event: any) => {
    const logger = getLogger();
    logger.addContext({ functionName: "repaymentCollectedListener" });

    const repaymentCollectedEvent = await deserializeKinesisEvent<RepaymentCollectedEvent>(event);
    return await processRepayment(repaymentCollectedEvent, logger);
};
