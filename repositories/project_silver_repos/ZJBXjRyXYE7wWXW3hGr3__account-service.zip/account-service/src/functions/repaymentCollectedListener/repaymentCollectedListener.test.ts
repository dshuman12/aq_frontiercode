import { test, expect, describe, vi, beforeEach, Mocked } from "vitest";
import { handler } from "./repaymentCollectedListener";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { Transaction } from "@onmoapp/onmo-types";
import { v4 as uuid } from "uuid";
import { getCoreBankingAdapter, getEventHubAdapter, getCoreRepaymentsAdapter } from "src/adapters";
import { StripeClient } from "@onmoapp/core-repayments/stripe";
import {
    defaultCreditAccount,
    defaultEventPublishResponse,
    defaultTransaction,
    defaultValidationResponse,
} from "src/fixtures";
import { CoreBanking } from "@onmoapp/core-banking";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";
import { RepaymentCollectedEvent } from "@libs/types";

vi.mock("src/adapters");
vi.mock("@onmoapp/core-repayments/stripe");
vi.mock("@utils/deserializeUtil");
vi.mock("@onmoapp/onmo-dynamodb");
vi.mock("uuid", () => ({
    v4: vi.fn(() => "mocked-uuid"),
}));

const testData = require("./testData.json");

const creditAccountResponse = {
    ...defaultCreditAccount,
    accountBalances: {
        ...defaultCreditAccount.accountBalances,
        balances: {
            ...defaultCreditAccount.accountBalances.balances,
            fees: 1,
            interest: 2,
            principal: 5,
        },
    },
};

const technicalAccountDepositTransaction = {
    ...defaultTransaction,
    transactionId: "technical-account-deposit",
    sourceAmount: -1000,
    destinationAmount: -1000,
};

const noTransactions = { transactions: [] };

describe("repaymentCollectedListener tests", () => {
    const ddEvent = testData.ddRepaymentCollectedEvent;

    describe("Card repayment", () => {
        const expectedRepaymentRequest = {
            amount: 10.0, // Amount was converted to GBP
            valueDate: "2024-11-30T12:17:52+00:00",
            bookingDate: "2024-11-30T12:17:52+00:00",
            externalId: "external_id_payment_intent_id_card1",
            notes: "Stripe card repayment for loan account account_id",
            transactionChannelId: "repaymt_card_stripe",
            transactionMetaData: {
                serviceProvider: "Stripe",
                debitCardPaymentId: "external_id_payment_intent_id_card1",
            },
            idempotencyKey: "idempotency_key_from_event",
        };

        const negativeAmountCreditAccountTransaction = {
            transactions: [
                {
                    ...defaultTransaction,
                    destinationAmount: -8,
                },
            ],
        };

        const negativeAmountTechnicalAccountTransaction = {
            transactions: [
                {
                    ...defaultTransaction,
                    destinationAmount: -2,
                },
            ],
        };

        const cardEvent = testData.cardRepaymentCollectedEvent;
        let coreBankingMock: Partial<Mocked<CoreBanking>>;

        beforeEach(() => {
            vi.resetAllMocks();
            vi.mocked(StripeClient).retrieveSecrets.mockResolvedValue({
                ddRetryProdWait: false,
                ddRetryAlwaysProdWaitAccounts: [],
                secretKey: "key",
                paymentIntentSucceedSecret: "success-secret",
                paymentIntentFailedSecret: "failed-secret",
                webhook: "webhook",
            });

            coreBankingMock = {
                makeDepositToTechnicalAccount: vi.fn().mockResolvedValue({
                    data: technicalAccountDepositTransaction,
                    error: null,
                }),
                applyInterestToCreditAccount: vi.fn().mockResolvedValue({
                    data: { message: "Interest applied successfully" },
                    error: null,
                }),
                findCreditAccountTransactionsByExternalId: vi.fn().mockResolvedValue({
                    data: noTransactions,
                    error: null,
                }),
                findTechnicalAccountTransactionsByExternalId: vi.fn().mockResolvedValue({
                    data: noTransactions,
                    error: null,
                }),
                makeRepaymentToCreditAccount: vi.fn().mockResolvedValue({
                    data: {
                        ...defaultTransaction,
                        transactionId: "credit-account-repayment",
                    },
                    error: null,
                }),
                getCreditAccount: vi.fn().mockResolvedValue({
                    data: creditAccountResponse,
                    error: null,
                }),
                setScheduledAmount: vi.fn().mockResolvedValue({
                    data: { accountId: "account-id" },
                    error: null,
                }),
            };
            vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue(coreBankingMock);

            vi.mocked(getCoreRepaymentsAdapter, { partial: true }).mockResolvedValue({
                getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({ subscriptions: [] }),
                cancelSubscription: vi.fn().mockResolvedValue({ data: null, error: null }),
            });

            vi.mocked(deserializeKinesisEvent).mockResolvedValue(cardEvent);
            vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
                Item: {
                    mambuTechnicalAccountID: "technical_account_id",
                    pspCustomerId: "psp_customer_id",
                },
            });
        });

        test("Happy path - Amount is less than full balance - it should not make a deposit in technical account", async () => {
            coreBankingMock.getCreditAccount.mockResolvedValueOnce({
                data: defaultCreditAccount,
                error: null,
            });

            const response = await handler(cardEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall =
                vi.mocked(coreBankingMock).applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeRepaymentCall =
                vi.mocked(coreBankingMock).makeRepaymentToCreditAccount.mock.calls[0];
            expect(makeRepaymentCall[0]).toBe("account_id");
            expect(makeRepaymentCall[1]).toMatchObject(expectedRepaymentRequest);
        });

        test("Happy path - It should round all amounts to 2 digits", async () => {
            const event = testData.cardRepaymentCollectedEvent2;
            coreBankingMock.getCreditAccount.mockResolvedValueOnce({
                data: {
                    ...defaultCreditAccount,
                    accountBalances: {
                        ...defaultCreditAccount.accountBalances,
                        balances: {
                            ...defaultCreditAccount.accountBalances.balances,
                            fees: 0.111111111,
                            interest: 0.2222222222,
                            principal: 10.33333333333334,
                        },
                    },
                    directDebitSettings: {
                        directDebitRetryInProgress: false,
                    },
                },
                error: null,
            });

            const response = await handler(event);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeRepaymentCall = coreBankingMock.makeRepaymentToCreditAccount.mock.calls[0];
            expect(makeRepaymentCall[0]).toBe("account_id");
            expect(makeRepaymentCall[1]).toMatchObject(expectedRepaymentRequest);
        });

        test("Happy path - Amount is more than full balance - transaction already exists - it should store the remaining in the technical account and skip creating a transaction", async () => {
            coreBankingMock.findCreditAccountTransactionsByExternalId.mockResolvedValueOnce({
                data: negativeAmountCreditAccountTransaction,
                error: null,
            });

            const response = await handler(cardEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 2.0, // Amount was converted to GBP
                externalId: "external_id_payment_intent_id_card1",
                notes: "Stripe card deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_card_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    debitCardPaymentId: "external_id_payment_intent_id_card1",
                },
                idempotencyKey: "idempotency_key_from_event",
            });
        });

        test("Happy path - Amount is more than full balance - transaction already exists - deposit already exists - it should skip creating both transactions", async () => {
            coreBankingMock.findCreditAccountTransactionsByExternalId.mockResolvedValueOnce({
                data: negativeAmountCreditAccountTransaction,
                error: null,
            });
            coreBankingMock.findTechnicalAccountTransactionsByExternalId.mockResolvedValueOnce({
                data: negativeAmountTechnicalAccountTransaction,
                error: null,
            });

            const response = await handler(cardEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });
        });

        test("Happy path - Amount is more than full balance - it should store the remaining in the technical account", async () => {
            coreBankingMock.getCreditAccount.mockResolvedValueOnce({
                data: {
                    ...creditAccountResponse,
                    directDebitSettings: {
                        directDebitRetryInProgress: false,
                    },
                },
                error: null,
            });

            const response = await handler(cardEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall =
                vi.mocked(coreBankingMock).applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeRepaymentCall =
                vi.mocked(coreBankingMock).makeRepaymentToCreditAccount.mock.calls[0];
            expect(makeRepaymentCall[0]).toBe("account_id");
            expect(makeRepaymentCall[1]).toMatchObject({
                amount: 8.0, // Amount was converted to GBP
                valueDate: "2024-11-30T12:17:52+00:00",
                bookingDate: "2024-11-30T12:17:52+00:00",
                externalId: "external_id_payment_intent_id_card1",
                notes: "Stripe card repayment for loan account account_id",
                transactionChannelId: "repaymt_card_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    debitCardPaymentId: "external_id_payment_intent_id_card1",
                },
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 2.0, // Amount was converted to GBP
                externalId: "external_id_payment_intent_id_card1",
                notes: "Stripe card deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_card_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    debitCardPaymentId: "external_id_payment_intent_id_card1",
                },
                idempotencyKey: "idempotency_key_from_event",
            });
        });

        test("Happy path - Full balance is zero - it should store the whole amount in technical account", async () => {
            const cardEvent = testData.cardRepaymentCollectedEvent;
            vi.mocked(coreBankingMock).getCreditAccount.mockResolvedValueOnce({
                data: {
                    ...defaultCreditAccount,
                    accountBalances: {
                        ...defaultCreditAccount.accountBalances,
                        balances: {
                            ...defaultCreditAccount.accountBalances.balances,
                            fees: 0,
                            interest: 0,
                            principal: 0,
                        },
                    },
                },
                error: null,
            });

            const event = cardEvent;
            const response = await handler(event);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.932Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 10.0, // Amount was converted to GBP
                externalId: "external_id_payment_intent_id_card1",
                notes: "Stripe card deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_card_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    debitCardPaymentId: "external_id_payment_intent_id_card1",
                },
                idempotencyKey: "idempotency_key_from_event",
            });
        });

        test("Happy path - No accrued interest to apply - it should not error", async () => {
            const cardEvent = testData.cardRepaymentCollectedEvent;
            vi.mocked(coreBankingMock).applyInterestToCreditAccount.mockResolvedValueOnce({
                data: null,
                error: {
                    errorMessage:
                        "Failed to apply interest to the credit account, ACCOUNT_HAS_NO_ACCRUED_INTEREST",
                    errorCode: 1,
                    severity: 1,
                },
            });
            vi.mocked(coreBankingMock).getCreditAccount.mockResolvedValueOnce({
                data: {
                    ...defaultCreditAccount,
                    accountBalances: {
                        ...defaultCreditAccount.accountBalances,
                        balances: {
                            ...defaultCreditAccount.accountBalances.balances,
                            fees: 0,
                            interest: 0,
                            principal: 100,
                        },
                    },
                    directDebitSettings: {
                        directDebitRetryInProgress: false,
                    },
                },
                error: null,
            });

            const response = await handler(cardEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();
        });
    });

    describe("Direct Debit repayment", () => {
        const zeroBalance = {
            fees: 0,
            interest: 0,
            principal: 0,
        };

        const highBalance = {
            fees: 0,
            interest: 0,
            principal: 100,
        };

        const lowBalance = {
            fees: 1,
            interest: 2,
            principal: 5,
        };

        const createCreditAccountResponse = (input) => ({
            ...defaultCreditAccount,
            accountBalances: {
                ...defaultCreditAccount.accountBalances,
                balances: {
                    ...defaultCreditAccount.accountBalances.balances,
                    ...input,
                },
            },
            directDebitSettings: {
                scheduledDirectDebitAmount: 10,
                directDebitRetryInProgress: false,
            },
        });

        let coreBankingMock: Partial<Mocked<CoreBanking>>;

        beforeEach(() => {
            vi.resetAllMocks();

            vi.mocked(StripeClient).retrieveSecrets.mockResolvedValue({
                ddRetryProdWait: false,
                ddRetryAlwaysProdWaitAccounts: [],
                secretKey: "key",
                paymentIntentSucceedSecret: "success-secret",
                paymentIntentFailedSecret: "failed-secret",
                webhook: "webhook",
            });
            coreBankingMock = {
                makeDepositToTechnicalAccount: vi.fn().mockResolvedValue({
                    data: technicalAccountDepositTransaction,
                    error: null,
                }),
                applyInterestToCreditAccount: vi.fn().mockResolvedValue({
                    data: { message: "Interest applied successfully" },
                    error: null,
                }),
                findCreditAccountTransactionsByExternalId: vi.fn().mockResolvedValue({
                    data: noTransactions,
                    error: null,
                }),
                findTechnicalAccountTransactionsByExternalId: vi.fn().mockResolvedValue({
                    data: noTransactions,
                    error: null,
                }),
                makeRepaymentToCreditAccount: vi.fn().mockResolvedValue({
                    data: defaultTransaction,
                    error: null,
                }),
                setScheduledAmount: vi.fn().mockResolvedValue({
                    data: { accountId: "account-id" },
                    error: null,
                }),
                getCreditAccount: vi.fn().mockResolvedValue(null),
            };
            vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue(coreBankingMock);

            vi.mocked(deserializeKinesisEvent).mockResolvedValue(ddEvent);
            vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
                Item: { mambuTechnicalAccountID: "technical_account_id" },
            });
        });

        test("Happy path - Amount is less than full balance - it should not make a deposit in technical account", async () => {
            coreBankingMock.getCreditAccount.mockResolvedValue({
                data: createCreditAccountResponse(highBalance),
                error: null,
            });

            const response = await handler(ddEvent);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.155Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeRepaymentCall = coreBankingMock.makeRepaymentToCreditAccount.mock.calls[0];
            expect(makeRepaymentCall[0]).toBe("account_id");
            expect(makeRepaymentCall[1]).toMatchObject({
                amount: 10.0, // Amount was converted to GBP
                valueDate: "2024-11-30T12:17:52+00:00",
                bookingDate: "2024-11-30T12:17:52+00:00",
                externalId: "external_id_payment_intent_id_dd",
                notes: "Stripe direct debit repayment for loan account account_id",
                transactionChannelId: "repaymt_direct_debit_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    directDebitPaymentId: "external_id_payment_intent_id_dd",
                },
                idempotencyKey: "idempotency_key_from_event",
            });

            const scheduledAmountCall = coreBankingMock.setScheduledAmount.mock.calls[0];
            expect(scheduledAmountCall[0]).toBe("account_id");
            expect(scheduledAmountCall[1]).toBe(0);
        });
        test("Happy path - Amount is more than full balance - it should store the remaining in the technical account", async () => {
            coreBankingMock.getCreditAccount.mockResolvedValue({
                data: createCreditAccountResponse(lowBalance),
                error: null,
            });

            const event = JSON.parse(JSON.stringify(ddEvent)); // deep clone
            const response = await handler(event);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.155Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeRepaymentCall = coreBankingMock.makeRepaymentToCreditAccount.mock.calls[0];
            expect(makeRepaymentCall[0]).toBe("account_id");
            expect(makeRepaymentCall[1]).toMatchObject({
                amount: 8.0, // Amount was converted to GBP
                valueDate: "2024-11-30T12:17:52+00:00",
                bookingDate: "2024-11-30T12:17:52+00:00",
                externalId: "external_id_payment_intent_id_dd",
                notes: "Stripe direct debit repayment for loan account account_id",
                transactionChannelId: "repaymt_direct_debit_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    directDebitPaymentId: "external_id_payment_intent_id_dd",
                },
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 2.0, // Amount was converted to GBP
                externalId: "external_id_payment_intent_id_dd",
                notes: "Stripe direct debit deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_direct_debit_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    directDebitPaymentId: "external_id_payment_intent_id_dd",
                },
                idempotencyKey: "idempotency_key_from_event",
            });

            const scheduledAmountCall = coreBankingMock.setScheduledAmount.mock.calls[0];
            expect(scheduledAmountCall[0]).toBe("account_id");
            expect(scheduledAmountCall[1]).toBe(0);
        });

        test("Happy path - Full balance is zero - it should store the whole amount in technical account", async () => {
            coreBankingMock.getCreditAccount.mockResolvedValue({
                data: createCreditAccountResponse(zeroBalance),
                error: null,
            });

            const event = JSON.parse(JSON.stringify(ddEvent)); // deep clone
            const response = await handler(event);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.155Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 10.0, // Amount was converted to GBP
                externalId: "external_id_payment_intent_id_dd",
                notes: "Stripe direct debit deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_direct_debit_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    directDebitPaymentId: "external_id_payment_intent_id_dd",
                },
                idempotencyKey: "idempotency_key_from_event",
            });

            const scheduledAmountCall = coreBankingMock.setScheduledAmount.mock.calls[0];
            expect(scheduledAmountCall[0]).toBe("account_id");
            expect(scheduledAmountCall[1]).toBe(0);
        });
    });

    describe("Retry mechanism", () => {
        let coreBankingMock: Partial<Mocked<CoreBanking>>;
        beforeEach(() => {
            vi.resetAllMocks();
            vi.mocked(StripeClient).retrieveSecrets.mockResolvedValue({
                ddRetryProdWait: false,
                ddRetryAlwaysProdWaitAccounts: [],
                secretKey: "key",
                paymentIntentSucceedSecret: "success-secret",
                paymentIntentFailedSecret: "failed-secret",
                webhook: "webhook",
            });

            coreBankingMock = {
                makeDepositToTechnicalAccount: vi.fn().mockResolvedValue(null),
                applyInterestToCreditAccount: vi.fn().mockResolvedValue(null),
                findCreditAccountTransactionsByExternalId: vi.fn().mockResolvedValue(null),
                findTechnicalAccountTransactionsByExternalId: vi.fn().mockResolvedValue(null),
                makeRepaymentToCreditAccount: vi.fn().mockResolvedValue(null),
                getCreditAccount: vi.fn().mockResolvedValue(null),
                setScheduledAmount: vi.fn().mockResolvedValue(null),
            };

            vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue(coreBankingMock);
        });

        test("Failure to make deposit transaction - on retry, it should have proper value for the deposit based on balance and existing transaction", async () => {
            const transaction = testData.transaction as Transaction;
            const eventData = testData.retryCaseEvent;

            coreBankingMock.makeDepositToTechnicalAccount.mockResolvedValue({
                data: transaction,
                error: null,
            });
            coreBankingMock.applyInterestToCreditAccount.mockResolvedValue({
                data: { message: "Interest applied successfully" },
                error: null,
            });
            coreBankingMock.findCreditAccountTransactionsByExternalId.mockResolvedValue({
                data: { transactions: [transaction] },
                error: null,
            });
            coreBankingMock.findTechnicalAccountTransactionsByExternalId.mockResolvedValue({
                data: noTransactions,
                error: null,
            });
            coreBankingMock.makeRepaymentToCreditAccount.mockResolvedValue({
                data: defaultTransaction,
                error: null,
            });
            coreBankingMock.getCreditAccount.mockResolvedValue({
                data: {
                    ...defaultCreditAccount,
                    accountBalances: {
                        ...defaultCreditAccount.accountBalances,
                        balances: {
                            ...defaultCreditAccount.accountBalances.balances,
                            fees: 0,
                            interest: 0,
                            principal: 0, // balance is 0 the second time as we recorded a repayment on the first try
                        },
                    },
                    directDebitSettings: {
                        scheduledDirectDebitAmount: 10,
                        directDebitRetryInProgress: false,
                    },
                },
                error: null,
            });
            coreBankingMock.setScheduledAmount.mockResolvedValue({
                data: { accountId: "account-id" },
                error: null,
            });
            vi.mocked(deserializeKinesisEvent).mockResolvedValue(eventData);
            vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
                Item: { mambuTechnicalAccountID: "technical_account_id" },
            });

            const response = await handler(eventData);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).not.toHaveBeenCalled(); // balance is 0
            expect(coreBankingMock.makeDepositToTechnicalAccount).toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).toHaveBeenCalled();

            const applyInterestCall = coreBankingMock.applyInterestToCreditAccount.mock.calls[0];
            expect(applyInterestCall[0]).toBe("account_id");
            expect(applyInterestCall[1]).toMatchObject({
                interestApplicationDate: "2024-11-30T12:17:52.155Z",
                idempotencyKey: "idempotency_key_from_event",
            });

            const makeDepositCall = coreBankingMock.makeDepositToTechnicalAccount.mock.calls[0];
            expect(makeDepositCall[0]).toBe("technical_account_id");
            expect(makeDepositCall[1]).toMatchObject({
                amount: 200, // Amount from already made transaction was removed from the total amount
                notes: "Stripe direct debit deposit for technical account technical_account_id",
                transactionChannelId: "repaymt_direct_debit_stripe",
                transactionMetaData: {
                    serviceProvider: "Stripe",
                    directDebitPaymentId: "external_id_payment_intent_id_retry",
                },
                externalId: "external_id_payment_intent_id_retry",
                idempotencyKey: "idempotency_key_from_event",
            });

            const findTransactionCall =
                coreBankingMock.findCreditAccountTransactionsByExternalId.mock.calls[0];
            expect(findTransactionCall[0]).toBe("account_id");
            expect(findTransactionCall[1]).toBe("external_id_payment_intent_id_retry");

            const scheduledAmountCall = coreBankingMock.setScheduledAmount.mock.calls[0];
            expect(scheduledAmountCall[0]).toBe("account_id");
            expect(scheduledAmountCall[1]).toBe(0);
        });
    });

    describe("Backdating logic", () => {
        const directDebitCreditAccount = {
            ...creditAccountResponse,
            directDebitSettings: {
                scheduledDirectDebitAmount: 10,
                directDebitRetryInProgress: false,
            },
        };

        let coreBankingMock: Partial<Mocked<CoreBanking>>;
        let eventHubMock: Partial<Mocked<EventHubKinesisAdapter<RepaymentCollectedEvent>>>;

        beforeEach(() => {
            vi.resetAllMocks();
            vi.mocked(StripeClient).retrieveSecrets.mockResolvedValue({
                ddRetryProdWait: false,
                ddRetryAlwaysProdWaitAccounts: [],
                secretKey: "key",
                paymentIntentSucceedSecret: "success-secret",
                paymentIntentFailedSecret: "failed-secret",
                webhook: "webhook",
            });

            vi.mocked(uuid, { partial: true }).mockReturnValue("new_generated_key");

            coreBankingMock = {
                makeRepaymentToCreditAccount: vi.fn().mockResolvedValue({
                    data: technicalAccountDepositTransaction,
                    error: null,
                }),
                findCreditAccountTransactionsByExternalId: vi.fn().mockResolvedValue({
                    data: noTransactions,
                    error: null,
                }),
                applyInterestToCreditAccount: vi.fn().mockResolvedValue({
                    data: { message: "Interest applied successfully" },
                    error: null,
                }),
                getCreditAccount: vi.fn().mockResolvedValue({
                    data: directDebitCreditAccount,
                    error: null,
                }),
                setScheduledAmount: vi.fn().mockResolvedValue({
                    data: { accountId: "account-id" },
                    error: null,
                }),
                makeDepositToTechnicalAccount: vi.fn().mockResolvedValue(null),
            };
            vi.mocked(getCoreBankingAdapter, { partial: true }).mockResolvedValue(coreBankingMock);

            eventHubMock = {
                validateEvent: vi.fn().mockResolvedValue(defaultValidationResponse),
                publishToEventHub: vi.fn().mockResolvedValue(defaultEventPublishResponse),
            };
            vi.mocked(getEventHubAdapter, { partial: true }).mockResolvedValue(eventHubMock);

            vi.mocked(deserializeKinesisEvent).mockResolvedValue(ddEvent);
            vi.mocked(getItemMethod, { partial: true }).mockResolvedValue({
                Item: { mambuTechnicalAccountID: "technical_account_id" },
            });
        });

        test("It should resend the event with one less day to try to backdate when we get EXCESS_REPAYMENT_ERROR", async () => {
            coreBankingMock.makeRepaymentToCreditAccount.mockResolvedValueOnce({
                data: null,
                error: { errorMessage: "EXCESS_REPAYMENT_ERROR" },
            });

            const event = JSON.parse(JSON.stringify(ddEvent)); // deep clone

            vi.mocked(deserializeKinesisEvent).mockResolvedValueOnce(event);
            const response = await handler(event);

            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const publishEventCall = eventHubMock.publishToEventHub.mock.calls[0];
            expect(publishEventCall[0]).toMatchObject({
                ...event,
                initiatedBy: "repaymentCollected-excess-repayment-retry",
                idempotencyKey: "new_generated_key",
                eventData: {
                    ...ddEvent.eventData,
                    date: "2024-12-01T12:17:52.155Z",
                },
            });
        });

        test("It should resend the event with one less day to try to backdate when we get NON_POSITIVE_TOTAL_BALANCE", async () => {
            coreBankingMock.makeRepaymentToCreditAccount.mockResolvedValueOnce({
                data: null,
                error: { errorMessage: "NON_POSITIVE_TOTAL_BALANCE" },
            });

            const event = JSON.parse(JSON.stringify(ddEvent)); // deep clone
            vi.mocked(deserializeKinesisEvent).mockResolvedValueOnce(event);

            const response = await handler(event);
            expect(response.statusCode).toBe(200);

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();

            const publishEventCall = eventHubMock.publishToEventHub.mock.calls[0];
            expect(publishEventCall[0]).toMatchObject({
                ...event,
                initiatedBy: "repaymentCollected-excess-repayment-retry",
                idempotencyKey: "new_generated_key",
                eventData: {
                    ...ddEvent.eventData,
                    date: "2024-12-01T12:17:52.155Z",
                },
            });
        });

        test("It should NOT resend the event when we get any other kind of errors", async () => {
            coreBankingMock.makeRepaymentToCreditAccount.mockResolvedValueOnce({
                data: null,
                error: { errorMessage: "SOME_OTHER_ERROR" },
            });

            await expect(handler(ddEvent)).rejects.toThrow();

            expect(coreBankingMock.applyInterestToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();
            expect(eventHubMock.publishToEventHub).not.toBeCalled();
        });

        test("Sad Path - It should error if this is a retried event with today's date and still throwing EXCESS_REPAYMENT_ERROR", async () => {
            coreBankingMock.makeRepaymentToCreditAccount.mockResolvedValueOnce({
                data: null,
                error: { errorMessage: "EXCESS_REPAYMENT_ERROR" },
            });

            const event = JSON.parse(JSON.stringify(ddEvent)); // deep clone
            event.eventData.date = new Date().toISOString();
            event.initiatedBy = "repaymentCollected-excess-repayment-retry";
            vi.mocked(deserializeKinesisEvent).mockResolvedValueOnce(event);
            await expect(handler(event)).rejects.toThrow();

            // we skip applying interest during the backdating retry
            expect(coreBankingMock.applyInterestToCreditAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.makeRepaymentToCreditAccount).toHaveBeenCalled();
            expect(coreBankingMock.makeDepositToTechnicalAccount).not.toHaveBeenCalled();
            expect(coreBankingMock.setScheduledAmount).not.toHaveBeenCalled();
            expect(eventHubMock.publishToEventHub).not.toBeCalled();
        });
    });
});
