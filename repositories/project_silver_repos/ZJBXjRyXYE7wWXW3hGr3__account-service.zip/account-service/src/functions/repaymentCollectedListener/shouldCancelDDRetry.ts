import { Logger } from "@onmoapp/onmo-logger";
import { calculateAmountToRetry } from "./directDebitUtil";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { DirectDebitSettings } from "@onmoapp/onmo-types";
import dayjs from "dayjs";
import { getCoreBankingAdapter, getCoreRepaymentsAdapter } from "src/adapters";

export const shouldCancelDDRetry = async ({
    mandateId,
    logger,
    repaymentAmount,
    currentTransaction,
    ddSettings,
}: {
    mandateId: string;
    logger: Logger;
    repaymentAmount: number;
    currentTransaction: string;
    ddSettings: DirectDebitSettings;
}) => {
    if (!mandateId) {
        logger.warn({
            message: `No mandateId provided, check if MandateCancelled listener is erroring`,
        });
        return true;
    }

    const preventRetryDate = dayjs(ddSettings.directDebitPreventRetryDate);
    const today = dayjs();
    if (today.isAfter(preventRetryDate, "day")) {
        logger.info({
            message: `Prevent retry date has passed: ${preventRetryDate.format("YYYY-MM-DD")}, the DD retry is pending, we need to keep the flags on.`,
        });
        return false;
    }

    const coreRepaymentAdapter = await getCoreRepaymentsAdapter();
    const coreBankingAdapter = await getCoreBankingAdapter();
    const failedDDPaymentIntent =
        await coreRepaymentAdapter.getLatestFailedMandatePaymentIntent(mandateId);
    if (!!failedDDPaymentIntent) {
        const result = await calculateAmountToRetry({
            failedPaymentIntent: failedDDPaymentIntent,
            repaymentAmount,
            currentTransaction,
            logger,
            coreBankingAdapter,
        });
        throwErrorIfAdapterResHaveError(result, { message: "Failed to calculate amount to retry" });

        const ddAmount = result.data.directDebitRetryAmount;
        logger.info({
            message: `amount remaining to pay for this instalment: ${ddAmount}`,
        });
        return ddAmount <= 0;
    } else {
        logger.error({
            message: `No failed payment intent found for mandateId: ${mandateId}`,
        });
        return false;
    }
};
