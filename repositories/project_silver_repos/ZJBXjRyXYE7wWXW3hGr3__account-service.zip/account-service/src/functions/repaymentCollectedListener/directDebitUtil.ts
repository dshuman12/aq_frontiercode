import { getCoreBankingAdapter } from "src/adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { ErrorOutcome, GetPaymentIntentOutcome, Installment } from "@onmoapp/onmo-types";
import dayjs from "dayjs";
import { CoreBanking } from "@onmoapp/core-banking";

export type CalculateAmountToRetryOutcome = {
    data: {
        directDebitRetryAmount: number; // in base currency (GBP)
    } | null;
    error: ErrorOutcome | null;
};

const logWarningAndReturnError = ({
    paymentIntentId,
    logger,
    alertKeyword,
    message,
}: {
    paymentIntentId: string;
    logger: Logger;
    alertKeyword: string;
    message: string;
}): CalculateAmountToRetryOutcome => {
    logger.warn({ message: `${alertKeyword}: ${message} for ${paymentIntentId}` });
    return {
        data: null,
        error: {
            errorMessage: `${message} for ${paymentIntentId}`,
        },
    };
};

const calculateMinimumDue = (instalment: Installment): number => {
    const principalDue = instalment.principal.amount.due || 0;
    const interestDue = instalment.interest.amount.due || 0;
    const feeDue = instalment.fee.amount.due || 0;
    return principalDue + interestDue + feeDue;
};

const getTotalRepaymentInDateRange = async ({
    dateFrom,
    dateTo,
    accountId,
    currentTransaction,
    logger,
}: {
    dateFrom: string;
    dateTo: string;
    accountId;
    currentTransaction: string;
    logger: Logger;
}): Promise<number> => {
    if (!dayjs(dateFrom, "YYYY-MM-DDTHH:mm:ss.SSS[Z]", true).isValid()) {
        throw new Error(`Invalid date format for dateFrom: ${dateFrom}. Expected ISO format`);
    }

    if (!dayjs(dateTo, "YYYY-MM-DDTHH:mm:ss.SSS[Z]", true).isValid()) {
        throw new Error(`Invalid date format for dateTo: ${dateTo}. Expected ISO format`);
    }

    const coreBankingAdapter = await getCoreBankingAdapter();
    const res = await coreBankingAdapter.getTransactionsInDateRange({
        accountId,
        dateFrom,
        dateTo,
        limit: 100,
    });

    if (res.error) {
        throw new Error(res.error.errorMessage);
    }

    logger.debug({ message: "Full res of getTransactionsInDateRange:", res });
    const repaymentTransactions = res.data.transactions.filter(
        (transaction) =>
            transaction.onmoTransactionType.includes("REPAYMENT") &&
            transaction.transactionId !== currentTransaction,
    );
    logger.debug({ message: "Filtered repayment transactions:", repaymentTransactions });

    const sumAlreadyPaid = repaymentTransactions
        .map((transaction) => transaction.destinationAmount)
        .reduce((sum, current) => sum + current, 0);
    logger.debug({
        message: `Sum of repayments in date range, before Math.abs: ${sumAlreadyPaid}`,
    });

    return Math.abs(sumAlreadyPaid); // a repayment is logged as negative as it reduces how much you owe
};

export const calculateAmountToRetry = async ({
    failedPaymentIntent,
    repaymentAmount,
    currentTransaction,
    logger,
    coreBankingAdapter,
}: {
    failedPaymentIntent: GetPaymentIntentOutcome;
    repaymentAmount: number;
    currentTransaction: string;
    logger: Logger;
    coreBankingAdapter: CoreBanking;
}): Promise<CalculateAmountToRetryOutcome> => {
    const amountPreference = failedPaymentIntent.metadata.originalUserPreference;
    const instalmentDate = failedPaymentIntent.metadata.instalmentDate;
    const accountId = failedPaymentIntent.metadata.accountId;

    if (!instalmentDate) {
        return logWarningAndReturnError({
            paymentIntentId: failedPaymentIntent.paymentIntentId,
            logger,
            alertKeyword: "Alert_NoInstalment",
            message: "Instalment date not found in payment intent metadata",
        });
    }
    if (!amountPreference) {
        return logWarningAndReturnError({
            paymentIntentId: failedPaymentIntent.paymentIntentId,
            logger,
            alertKeyword: "Alert_NoAmountPreference",
            message: "Amount preference not found in payment intent metadata",
        });
    }

    if (!accountId) {
        return logWarningAndReturnError({
            paymentIntentId: failedPaymentIntent.paymentIntentId,
            logger,
            alertKeyword: "Alert_NoAccountId",
            message: "Account ID not found in payment intent metadata",
        });
    }

    const dateFrom = dayjs(failedPaymentIntent.creationDate).toISOString();
    const dateTo = dayjs().toISOString();

    logger.debug({
        message: "calculateAmountToRetry setup:",
        instalmentDate,
        amountPreference,
        accountId,
        dateFrom,
        dateTo,
        currentTransaction,
    });

    const adhocRepaymentsTotal = await getTotalRepaymentInDateRange({
        dateFrom,
        dateTo,
        accountId,
        currentTransaction,
        logger,
    });
    const adhocTotalInPence = Number((adhocRepaymentsTotal * 100).toFixed(2));
    let ddRetryAmountInPence = 0;

    switch (amountPreference) {
        case "Full Statement Balance":
        case "Custom": {
            ddRetryAmountInPence = failedPaymentIntent.amount - adhocTotalInPence;
            break;
        }
        case "Minimum Payment": {
            // Fetch the instalment saved on the payment intent
            const res = await coreBankingAdapter.getInstalmentByDueDate(accountId, instalmentDate);
            if (res.error) {
                return logWarningAndReturnError({
                    paymentIntentId: failedPaymentIntent.paymentIntentId,
                    logger,
                    alertKeyword: "Alert_NoInstalmentInMambu",
                    message: "Instalment not found when searching Mambu",
                });
            }
            const minimumDue = calculateMinimumDue(res.data);
            ddRetryAmountInPence = Number((minimumDue * 100).toFixed(2));
            // no need to remove adhoc payments
            // Mambu takes care of it automatically
            break;
        }
        default: {
            logger.error("Invalid amount preference");
            throw new Error(`Invalid amount preference: ${amountPreference}`);
        }
    }

    ddRetryAmountInPence = ddRetryAmountInPence - repaymentAmount; // we need to include this repayment as it is not included in Mambu yet
    return {
        data: {
            directDebitRetryAmount: Number((ddRetryAmountInPence / 100).toFixed(2)), // this may be negative if the user made more repayments than needed
        },
        error: null,
    };
};
