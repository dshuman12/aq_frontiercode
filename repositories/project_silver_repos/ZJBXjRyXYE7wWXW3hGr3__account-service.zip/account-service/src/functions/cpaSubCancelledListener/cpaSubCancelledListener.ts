import { getLogger } from "@utils/logger";
import { formatJSONResponse } from "@libs/api-gateway";
import { deserializeKinesisEvent } from "@utils/deserializeUtil";
import { CPASubscriptionCancelledEvent, CPACancellationReason } from "@libs/types/eventHub-types";
import { getCoreBankingAdapter, getSalesforceAdapter } from "src/adapters";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { sendMessage } from "@onmoapp/onmo-sqs";
import dayjs from "dayjs";

export const handler = async (event: any) => {
    const logger = getLogger();
    logger.addContext({ functionName: "cpaSubCancelledListener" });

    const cpaSubscriptionCancelled =
        await deserializeKinesisEvent<CPASubscriptionCancelledEvent>(event);
    const { customerId, accountId, subscriptionDetails } = cpaSubscriptionCancelled.eventData;
    logger.info({ message: "CPASubscriptionCancelled received", cpaSubscriptionCancelled });
    logger.addContext({ accountId, customerId });

    const salesforceClient = await getSalesforceAdapter();
    const expireResult = await salesforceClient.expireCollectionPlansByCustomerId(customerId);

    if (expireResult.error) {
        logger.warn({
            message: "Failed to expire collection plan in Salesforce",
            error: expireResult.error,
        });
    } else {
        logger.info({ message: "Successfully expired collection plan in Salesforce", customerId });
    }

    const coreBankingAdapter = await getCoreBankingAdapter();

    const crmCustomerDetails = await salesforceClient.getCrmCustomerDetailsByCustomerId(customerId);
    throwErrorIfAdapterResHaveError(crmCustomerDetails, {
        message: "Failed to get CRM customer details",
    });

    const coreBankingCustomer = await coreBankingAdapter.getCustomerByCustomerId(customerId);
    throwErrorIfAdapterResHaveError(coreBankingCustomer, {
        message: "Failed to get core banking customer details",
    });

    // Verify the interest rate is currently 0 before attempting to restore
    const creditAccountRes = await coreBankingAdapter.getCreditAccount(accountId);
    throwErrorIfAdapterResHaveError(creditAccountRes, {
        message: "Failed to get credit account details",
    });

    const currentInterestRate = creditAccountRes.data?.accountDetails?.interestRate;

    if (currentInterestRate !== 0) {
        logger.info({
            message: "Interest rate is not 0, no restoration needed",
            currentInterestRate,
            accountId,
            customerId,
        });
    } else {
        // Restore the interest rate that was set to zero during subscription
        const fromDate = dayjs()
            .subtract(365 * 2, "day")
            .format("YYYY-MM-DD");
        const toDate = dayjs().add(1, "day").format("YYYY-MM-DD");

        const activityRes = await coreBankingAdapter.getCustomerActivity({
            customerId,
            fromDate,
            toDate,
        });
        throwErrorIfAdapterResHaveError(activityRes, {
            message: "Failed to get customer activity",
        });

        const activities = activityRes.data?.activity || [];

        // Find the most recent activity where interest rate was changed to 0
        const interestRateChangeToZero = activities
            .filter((a) =>
                a.activity.fieldChanges?.some(
                    (fc) => fc.fieldChangeName === "INTEREST_RATE" && fc.newValue === "0",
                ),
            )
            .sort(
                (a, b) =>
                    new Date(b.activity.timestamp).getTime() -
                    new Date(a.activity.timestamp).getTime(),
            )[0];

        if (!interestRateChangeToZero) {
            logger.warn({
                message: "No INTEREST_RATE change to 0 found in customer activity",
                customerId,
                accountId,
            });
        } else {
            const interestRateFieldChange = interestRateChangeToZero.activity.fieldChanges.find(
                (fc) => fc.fieldChangeName === "INTEREST_RATE" && fc.newValue === "0",
            );

            if (!interestRateFieldChange?.originalValue) {
                logger.warn({
                    message: "Original interest rate value is missing, skipping restoration",
                    accountId,
                    customerId,
                });
                return formatJSONResponse(200, {
                    message: "CPASubscriptionCancelled event processed successfully",
                });
            }

            const originalInterestRate = parseFloat(interestRateFieldChange.originalValue);

            if (isNaN(originalInterestRate)) {
                logger.warn({
                    message:
                        "Original interest rate value is not a valid number, skipping restoration",
                    originalValue: interestRateFieldChange.originalValue,
                    accountId,
                    customerId,
                });
                return formatJSONResponse(200, {
                    message: "CPASubscriptionCancelled event processed successfully",
                });
            }

            logger.info({
                message: "Found original interest rate to restore",
                originalInterestRate,
                accountId,
                customerId,
            });

            const valueDate = dayjs().toISOString();
            const updateResult = await coreBankingAdapter.updateInterestRateToCreditAccount(
                accountId,
                {
                    interestRate: originalInterestRate,
                    valueDate,
                    notes: "Restoring interest rate after CPA subscription cancelled",
                },
            );
            throwErrorIfAdapterResHaveError(updateResult, {
                message: "Failed to restore interest rate after CPA subscription cancelled",
            });

            logger.info({
                message: "Successfully restored interest rate after CPA subscription cancelled",
                originalInterestRate,
                accountId,
                customerId,
            });
        }
    }

    const { cancellationReason } = subscriptionDetails;

    let creative: string | null = null;

    if (cancellationReason === CPACancellationReason.PaymentFailed) {
        creative = "Email5";
    } else if (
        cancellationReason === CPACancellationReason.EndDateReached ||
        cancellationReason === CPACancellationReason.BalancePaid
    ) {
        creative = "Email6";
    }

    if (!creative) {
        logger.info({
            message: "No SFMC comms required for this cancellation reason",
            cancellationReason,
            customerId,
        });
        return formatJSONResponse(200, {
            message: "CPASubscriptionCancelled event processed successfully",
        });
    }

    const commsEvent = {
        creative,
        firstName: coreBankingCustomer.data.firstName.trim(),
        emailAddress: coreBankingCustomer.data.emailAddresses.primary,
        customerId,
        personContactId: crmCustomerDetails.data.contactId,
        paymentPlanDate: dayjs.unix(subscriptionDetails.currentPeriodEnd).format("YYYY-MM-DD"),
        planEndDate: dayjs().format("YYYY-MM-DD"),
        retryDate: null,
        paymentPlanValue: subscriptionDetails.amount / 100,
        arrearsBalance: creditAccountRes.data?.accountBalances?.arrearBalances?.total ?? null,
    };

    logger.info({ message: "Sending SFMC comms for CPA subscription cancelled", commsEvent });
    const result = await sendMessage({
        MessageBody: JSON.stringify(commsEvent),
        QueueUrl: process.env.SFMC_COMMS_QUEUE_URL,
    });
    logger.info({
        message: "SFMC comms sent for CPA subscription cancelled",
        messageId: result.MessageId,
    });

    return formatJSONResponse(200, {
        message: "CPASubscriptionCancelled event processed successfully",
    });
};
