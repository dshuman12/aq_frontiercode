import { test, expect, beforeAll, beforeEach, afterEach } from "vitest";
import { DocumentType } from "@onmoapp/onmo-types";
import {
    queryParams,
    buildQueryString,
    fetchAPISecret,
    generateRandomDates,
    setUpTestAccount,
    uploadTestContractsForCustomer,
    generateMonthlyDates,
    uploadTestStatementsForCustomer,
    tearDownTestAccount,
    UserCredentials,
} from "@utils/testUtils";
import { DocumentsRes } from "@libs/types";

let userCreds: UserCredentials;
let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetAccountDocuments = async (
    accountId: string,
    documentType: DocumentType | "all",
    queryParams: queryParams,
    apiKeyValue = apiKey,
) => {
    const queryString = buildQueryString({
        documentType,
        ...queryParams,
    });
    const get_documents_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/documents?${queryString}`;

    return await fetch(get_documents_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKeyValue,
            "x-api-test-secret": api_test_secret,
        },
    });
};

const invokeGenerateSignedURL = async (
    accountId: string,
    eventBody: {
        documentId: string;
    },
    apiKeyValue = apiKey,
) => {
    const get_documents_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/document/generate-url`;

    return await fetch(get_documents_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKeyValue,
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(eventBody),
    });
};

const getDataFromSignedURL = async (signedURL: string) => {
    return await fetch(signedURL, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

beforeEach(async () => {
    userCreds = await setUpTestAccount();
});

afterEach(async () => {
    await tearDownTestAccount(userCreds.customerId);
});

test("happy path - Get Signed URL for Contracts Document", async () => {
    /** uploading 1 contract documents */
    const contractsDates = generateRandomDates(1, new Date(2020, 0, 1), new Date());
    await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {
        count: String(contractsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;
    const generateSignedURLResponse = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: body.documents.at(0).documentId,
    });
    const signedURL = ((await generateSignedURLResponse.json()) as { signedURL: string }).signedURL;
    const s3DataRes = await getDataFromSignedURL(signedURL);
    const s3Data = await s3DataRes.json();

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${contractsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.at(0)).toHaveProperty("day");
    expect(body.documents.length).toEqual(contractsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
    expect(generateSignedURLResponse.status).toEqual(200);
    expect(s3DataRes.status).toEqual(200);
    expect(signedURL).toContain(userCreds.customerId);
    expect(s3Data).toEqual({
        customerId: userCreds.customerId,
        accountType: "credit",
        year: contractsDates[0].year,
        month: contractsDates[0].month,
        day: contractsDates[0].day,
    });
});

test("happy path - Get Signed URL for Statement Document", async () => {
    /** uploading statement documents */
    const today = new Date();
    const lastMonth = new Date(today.setMonth(today.getMonth() - 1));
    const statementsDates = generateMonthlyDates(lastMonth, new Date());
    await uploadTestStatementsForCustomer(userCreds.customerId, "credit", [statementsDates[0]]); // uploading one document

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "statements", {
        count: "1",
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;

    const generateSignedURLResponse = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: body.documents.at(0).documentId,
    });
    const signedURL = ((await generateSignedURLResponse.json()) as { signedURL: string }).signedURL;
    const s3DataRes = await getDataFromSignedURL(signedURL);
    const s3Data = await s3DataRes.json();

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-1.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.length).toEqual(1);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
    expect(generateSignedURLResponse.status).toEqual(200);
    expect(s3DataRes.status).toEqual(200);
    expect(signedURL).toContain(userCreds.customerId);
    expect(s3Data).toEqual({
        customerId: userCreds.customerId,
        accountType: "credit",
        year: statementsDates[0].year,
        month: statementsDates[0].month,
    });
});

test("sad path - Get Signed URL Validation Error invalid creditAccountId", async () => {
    /** invoking Get account Documents API with invalid AccountId */
    const res = await invokeGenerateSignedURL("AB", {
        documentId: "123",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("accountId length must be at least 3 characters long");
});

test("sad path - Get Signed URL Validation Error invalid documentId", async () => {
    /** invoking Get account Documents API with invalid AccountId */
    const res = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: "123",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("documentId length must be at least 10 characters long");
});

test("sad path - File not Found", async () => {
    /** invoking Get Signed URL API with DocumentId Doesn't Exist */
    const res = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: "randomPath/customer=999/invalidValue",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(404);
    expect(body.message).toEqual("File not found"); // not found
});
