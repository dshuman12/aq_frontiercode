import { APIGatewayEvent } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/api-gateway";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { fileExist, getPresignedURLGetObj } from "@onmoapp/onmo-s3";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { checkValidation } from "@validators/index";
import { getSignedURLBodySchema, pathParametersSchema } from "@validators/document.validator";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { DOCUMENT_BUCKET_NAME } from "@libs/constants";
import { checkAccess } from "@utils/oidc-authorization";

/**
 * Handles the API Gateway event for getting documents of an account.
 *
 * @param {APIGatewayEvent} event - The API Gateway event object containing the request information.
 * @returns {Promise<APIGatewayProxyResult>} - A Promise that resolves to the API Gateway response object.
 */
export const handler = async (event: APIGatewayEvent) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );

    try {
        const payload = parseAPIGateWayEventBody(event.body || "{}");
        // Validate the path parameters against the provided schema and extract the 'accountId'.
        const { accountId } = checkValidation(pathParametersSchema, event.pathParameters ?? {});

        /** will check access of user if request is from onmo api url */
        await checkAccess(event.requestContext, accountId);

        const { documentId } = checkValidation(getSignedURLBodySchema, payload ?? {});
        logger.addContext({ accountId, documentId });
        logger.info("Got accountId and documentId");
        const checkFile = await fileExist({
            Bucket: DOCUMENT_BUCKET_NAME,
            Key: documentId,
        }).catch(() => {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "File not found",
            });
        });
        if (checkFile.$metadata.httpStatusCode !== 200) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: "File not found",
            });
        }
        const preSignedURL = await getPresignedURLGetObj({
            Bucket: DOCUMENT_BUCKET_NAME,
            Key: documentId,
            expires: 60 * 2, // 2 minutes
        });
        if (!preSignedURL)
            throw new OnmoError({
                name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
                message: "Unable to generate presigned URL",
            });

        return formatJSONResponse(200, {
            signedURL: preSignedURL,
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error(debugMessage);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
