import { test, expect, beforeEach, afterEach } from "vitest";
import { DocumentType } from "@onmoapp/onmo-types";
import {
    queryParams,
    buildQueryString,
    generateRandomDates,
    setUpTestAccount,
    uploadTestContractsForCustomer,
    tearDownTestAccount,
    UserCredentials,
    generateAccessTokenOfTestUser,
    deleteAccessTokenOfTestUser,
} from "@utils/testUtils";
import { accessTokenObject, DocumentsRes, ErrorMessageResponse } from "@libs/types";

let userCreds: UserCredentials;
let accessToken: accessTokenObject;

const onmo_api_url = process.env.ONMO_API_URL as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeGetAccountDocuments = async (
    accountId: string,
    documentType: DocumentType | "all",
    queryParams: queryParams,
    token = accessToken.access_token,
) => {
    const queryString = buildQueryString({
        documentType,
        ...queryParams,
    });
    const get_documents_url = `https://${onmo_api_url}/service/accounts/next/credit/${accountId}/documents?${queryString}`;

    return await fetch(get_documents_url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            Authorization: token,
            "x-api-test-secret": api_test_secret,
        },
    });
};

const invokeGenerateSignedURL = async (
    accountId: string,
    eventBody: {
        documentId: string;
    },
    token = accessToken.access_token,
) => {
    const get_documents_url = `https://${onmo_api_url}/service/accounts/next/credit/${accountId}/document/generate-url`;

    return await fetch(get_documents_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: token,
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(eventBody),
    });
};

const getDataFromSignedURL = async (signedURL: string) => {
    return await fetch(signedURL, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    });
};

beforeEach(async () => {
    userCreds = await setUpTestAccount();
    accessToken = await generateAccessTokenOfTestUser(userCreds.customerId);
});

afterEach(async () => {
    await tearDownTestAccount(userCreds.customerId);
    await deleteAccessTokenOfTestUser(userCreds.customerId, accessToken);
});

test("happy path - Get Signed URL for Contracts Document", async () => {
    /** uploading 1 contract documents */
    const contractsDates = generateRandomDates(1, new Date(2020, 0, 1), new Date());
    await uploadTestContractsForCustomer(userCreds.customerId, "credit", contractsDates);

    /** invoking Get account Documents API */
    const res = await invokeGetAccountDocuments(userCreds.creditAccountId, "contracts", {
        count: String(contractsDates.length + 1),
        documentCursor: "0",
    });
    const body = (await res.json()) as DocumentsRes;
    const generateSignedURLResponse = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: body.documents.at(0).documentId,
    });
    const signedURL = ((await generateSignedURLResponse.json()) as { signedURL: string }).signedURL;
    const s3DataRes = await getDataFromSignedURL(signedURL);
    const s3Data = await s3DataRes.json();

    expect(res.status).toEqual(200);
    expect(body.documents.at(0)).toHaveProperty("documentType");
    expect(body.documents.at(0)).toHaveProperty("documentId");
    expect(body.documents.at(0)).toHaveProperty("fileName");
    expect(body.documents.at(0).fileName).toEqual(`testDoc-${contractsDates.length}.json`); // documents will be in descending order
    expect(body.documents.at(0)).toHaveProperty("year");
    expect(body.documents.at(0)).toHaveProperty("month");
    expect(body.documents.at(0)).toHaveProperty("day");
    expect(body.documents.length).toEqual(contractsDates.length);
    expect(body.documentCursor).toEqual(0);
    expect(body.nextPeriodFrom).toEqual(""); // should empty because all documents are fetched
    expect(generateSignedURLResponse.status).toEqual(200);
    expect(s3DataRes.status).toEqual(200);
    expect(signedURL).toContain(userCreds.customerId);
    expect(s3Data).toEqual({
        customerId: userCreds.customerId,
        accountType: "credit",
        year: contractsDates[0].year,
        month: contractsDates[0].month,
        day: contractsDates[0].day,
    });
});

test("sad path - Get Signed URL Validation Error invalid documentId", async () => {
    /** invoking Get account Documents API with invalid AccountId */
    const res = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: "123",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(400);
    expect(body.message).toEqual("documentId length must be at least 10 characters long");
});

test("sad path - File not Found", async () => {
    /** invoking Get Signed URL API with DocumentId Doesn't Exist */
    const res = await invokeGenerateSignedURL(userCreds.creditAccountId, {
        documentId: "randomPath/customer=999/invalidValue",
    }); // invalid account Id
    const body = (await res.json()) as { message: string };

    expect(res.status).toEqual(404);
    expect(body.message).toEqual("File not found"); // not found
});

test("invalid Access Token", async () => {
    const response = await invokeGenerateSignedURL(
        userCreds.creditAccountId,
        {
            documentId: "randomPath/customer=999/invalidValue",
        },
        "INVALID_ACCESS_TOKEN",
    ); // invalid account Id
    expect(response.status).toBe(401);
});

test("trying to access any other's account's Document Signed URL, should return 401 unauthorized access", async () => {
    const response = await invokeGenerateSignedURL("ABCD123", {
        documentId: "randomPath/customer=999/invalidValue",
    });

    expect(response.status).toBe(401);
    const responseBody = (await response.json()) as ErrorMessageResponse;
    expect(responseBody.message).toEqual("user is not authorized to access this account");
});
