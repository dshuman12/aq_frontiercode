import { createEventHandler, ScheduledEvent } from "@onmoapp/handler-middleware";
import { logger } from "@onmoapp/logger";

import { PromotionService } from "@services/promotion";
import { PromotionRecord, PromotionType } from "@libs/types/promotion";

export const handlerLogic = async () => {
    const horizonDays = Number(process.env.PROMOTION_REMINDER_HORIZON_DAYS!);
    if (Number.isNaN(horizonDays)) {
        throw new Error("PROMOTION_REMINDER_HORIZON_DAYS must be a valid number");
    }

    const promotionService = PromotionService.getInstance();
    let cursor: Record<string, unknown> | undefined = undefined;
    let count = 0;

    do {
        const result = await promotionService.getPendingNotification(
            PromotionType.HONEYMOON,
            horizonDays,
            cursor,
        );

        if (!result.ok) {
            logger.error(`Failed to query pending notifications: ${result.error.message}`);
            break;
        }

        const { items, cursor: nextCursor } = result.data;
        cursor = nextCursor;

        const settled = await Promise.allSettled(
            items.map(async (record: PromotionRecord) => {
                // TODO (1c — pending SFMC): send SQS message to reminder queue
                // payload: { credit_account_id, end_date, original_interest_rate, original_apr }
                // await sendMessage({ MessageBody: JSON.stringify({ ... }), QueueUrl: process.env.HANDLE_PROMOTION_REMINDERS_QUEUE_URL });

                return promotionService.markNotified(record);
            }),
        );

        for (const result of settled) {
            if (result.status === "rejected") {
                logger.error(
                    `Failed to mark notification sent for promotion record: ${String(result.reason)}`,
                );
                continue;
            }
            if (!result.value.ok) {
                logger.error(
                    `Failed to mark notification sent for promotion record: ${result.value.error.message}`,
                );
                continue;
            }
            count++;
        }
    } while (cursor !== undefined);

    logger.addContext("records_marked", count);
};

export const handler = createEventHandler<ScheduledEvent>(__HANDLER_NAME__).handle(handlerLogic);
