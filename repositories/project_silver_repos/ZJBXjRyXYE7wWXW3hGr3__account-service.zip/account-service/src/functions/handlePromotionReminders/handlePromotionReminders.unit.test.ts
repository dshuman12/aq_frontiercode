import { describe, expect, test, vi, beforeEach, afterAll } from "vitest";
import { handler, handlerLogic } from "./handlePromotionReminders";
import { PromotionService } from "@services/promotion";
import {
    PromotionRecord,
    PromotionType,
    PromotionStatus,
    NotificationStatus,
} from "@libs/types/promotion";
import { logger } from "@onmoapp/logger";

const originalPromotionReminderHorizonDays = process.env.PROMOTION_REMINDER_HORIZON_DAYS;

vi.mock("@services/promotion", () => ({
    PromotionService: {
        getInstance: vi.fn(),
    },
}));

vi.mock("@onmoapp/logger", () => ({
    logger: {
        addContext: vi.fn(),
        error: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
    },
}));

const scheduledEvent = {
    version: "0",
    id: "test-event-id",
    "detail-type": "Scheduled Event" as const,
    source: "aws.events",
    account: "123456789",
    time: "2024-01-01T02:00:00Z",
    region: "eu-west-1",
    resources: ["arn:aws:events:eu-west-1:123456789:rule/promoDaily-test"],
    detail: {},
};

const makeRecord = (overrides: Partial<PromotionRecord> = {}): PromotionRecord => ({
    id: "partition-key",
    promotion_id: "HONEYMOON#1700000000",
    onmouuid: "onmo-uuid-1",
    promotion_type: PromotionType.HONEYMOON,
    credit_account_id: "ACC-001",
    promotional_interest_rate: 0,
    original_interest_rate: 5.5,
    original_apr: 6.1,
    status: PromotionStatus.ACTIVE,
    notification_status: NotificationStatus.PENDING,
    start_date: 1700000000,
    end_date: 1703000000,
    applied_at: null,
    cancelled_at: null,
    notification_sent_at: null,
    cancelled_reason: null,
    version: 1,
    created_at: 1700000000,
    updated_at: 1700000000,
    ...overrides,
});

const makePageOk = (items: PromotionRecord[], cursor?: Record<string, unknown>) => ({
    ok: true,
    data: { items, cursor },
});

const makePageFail = (message: string) => ({ ok: false, error: { message } });

const makeMarkOk = () => ({ ok: true, data: undefined });
const makeMarkFail = (message: string) => ({ ok: false, error: { message } });

describe("handlePromotionReminders", () => {
    let mockGetPendingNotification: ReturnType<typeof vi.fn>;
    let mockMarkNotified: ReturnType<typeof vi.fn>;

    beforeEach(() => {
        vi.clearAllMocks();
        process.env.PROMOTION_REMINDER_HORIZON_DAYS = "14";
        mockGetPendingNotification = vi.fn();
        mockMarkNotified = vi.fn().mockResolvedValue(makeMarkOk());
        vi.mocked(PromotionService.getInstance).mockReturnValue({
            getPendingNotification: mockGetPendingNotification,
            markNotified: mockMarkNotified,
        } as any);
    });

    afterAll(() => {
        if (originalPromotionReminderHorizonDays === undefined) {
            delete process.env.PROMOTION_REMINDER_HORIZON_DAYS;
            return;
        }
        process.env.PROMOTION_REMINDER_HORIZON_DAYS = originalPromotionReminderHorizonDays;
    });

    test("handler is a function", () => {
        expect(typeof handler).toBe("function");
    });

    test("handler resolves without throwing on a scheduled event", async () => {
        mockGetPendingNotification.mockResolvedValue(makePageOk([]));
        await expect(handler(scheduledEvent, {} as any)).resolves.toBeUndefined();
    });

    test("records found — markNotified called once and count logged as 1", async () => {
        const record = makeRecord();
        mockGetPendingNotification.mockResolvedValue(makePageOk([record]));

        await handlerLogic();

        expect(mockMarkNotified).toHaveBeenCalledTimes(1);
        expect(mockMarkNotified).toHaveBeenCalledWith(record);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_marked", 1);
    });

    test("no records — markNotified never called and count logged as 0", async () => {
        mockGetPendingNotification.mockResolvedValue(makePageOk([]));

        await handlerLogic();

        expect(mockMarkNotified).not.toHaveBeenCalled();
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_marked", 0);
    });

    test("pagination — two pages processed, markNotified called twice and count logged as 2", async () => {
        const record1 = makeRecord({ credit_account_id: "ACC-001" });
        const record2 = makeRecord({ credit_account_id: "ACC-002" });
        const paginationCursor = { pk: "cursor-token" };

        mockGetPendingNotification
            .mockResolvedValueOnce(makePageOk([record1], paginationCursor))
            .mockResolvedValueOnce(makePageOk([record2]));

        await handlerLogic();

        expect(mockGetPendingNotification).toHaveBeenCalledTimes(2);
        expect(mockGetPendingNotification).toHaveBeenNthCalledWith(
            1,
            PromotionType.HONEYMOON,
            14,
            undefined,
        );
        expect(mockGetPendingNotification).toHaveBeenNthCalledWith(
            2,
            PromotionType.HONEYMOON,
            14,
            paginationCursor,
        );
        expect(mockMarkNotified).toHaveBeenCalledTimes(2);
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_marked", 2);
    });

    test("markNotified failure — error logged, handler resolves, remaining records still processed", async () => {
        const record1 = makeRecord({ credit_account_id: "ACC-001" });
        const record2 = makeRecord({ credit_account_id: "ACC-002" });
        mockGetPendingNotification.mockResolvedValue(makePageOk([record1, record2]));

        mockMarkNotified
            .mockResolvedValueOnce(makeMarkFail("ConditionalCheckFailedException"))
            .mockResolvedValueOnce(makeMarkOk());

        await expect(handlerLogic()).resolves.toBeUndefined();

        expect(mockMarkNotified).toHaveBeenCalledTimes(2);
        expect(vi.mocked(logger.error)).toHaveBeenCalledOnce();
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(
            "ConditionalCheckFailedException",
        );
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_marked", 1);
    });

    test("getPendingNotification failure — error logged, markNotified never called, handler resolves", async () => {
        mockGetPendingNotification.mockResolvedValue(
            makePageFail("Failed to query promotions (email-sweep-index)"),
        );

        await expect(handlerLogic()).resolves.toBeUndefined();

        expect(mockMarkNotified).not.toHaveBeenCalled();
        expect(vi.mocked(logger.error)).toHaveBeenCalledOnce();
        expect(vi.mocked(logger.error).mock.calls[0][0]).toContain(
            "Failed to query pending notifications",
        );
        expect(vi.mocked(logger.addContext)).toHaveBeenCalledWith("records_marked", 0);
    });
});
