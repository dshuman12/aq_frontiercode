import { test, expect, beforeAll, afterAll } from "vitest";
import {
    fetchAPISecret,
    getRecordInInterestAndFeesFreezeTable,
    deleteRecordInInterestAndFeesFreezeTable,
    getCreditAccount,
    writeOffMambuLoanAccount,
    setupTestAccountForCreditUnfreezeAccount,
    deleteUserRecordInMobileTable,
    createUserRecordInMobileTable,
    createRecordInInterestAndFeesFreezeTable,
} from "@utils/testUtils";
import {
    INTEREST_FEES_FREEZE_STATUS,
    TEST_CUSTOMER_UUID,
    TEST_TECHNICAL_ACCOUNT_ID,
} from "@libs/constants";

let apiKey: string;
let accountId: string;
let createdAt: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeUnfreezeInterestAndFees = async (
    accountId: string,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
) => {
    const interestAndFeesUnfreezeUrl = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/interest-and-fees/unfreeze`;
    return await fetch(interestAndFeesUnfreezeUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
    });
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
    const accountData = await setupTestAccountForCreditUnfreezeAccount();
    accountId = accountData.accountId;
    createdAt = accountData.createdAt;
    await createUserRecordInMobileTable({
        customerId: TEST_CUSTOMER_UUID,
        creditAccountId: accountId,
        technicalAccountId: TEST_TECHNICAL_ACCOUNT_ID,
    });
    await createRecordInInterestAndFeesFreezeTable({
        accountId: accountId,
        apr: 35,
        originalInterestRate: 12.3,
        status: INTEREST_FEES_FREEZE_STATUS.FROZEN,
        createdAt,
    });
});

afterAll(async () => {
    await writeOffMambuLoanAccount(accountId);
    await deleteRecordInInterestAndFeesFreezeTable(accountId, createdAt);
    await deleteUserRecordInMobileTable(TEST_CUSTOMER_UUID);
});

// TODO: Fix flaky integration test — returns 500 intermittently in staging
test.skip("Unfreeze the credit account", async () => {
    const response = await invokeUnfreezeInterestAndFees(accountId);

    expect(response.status).toBe(200);
    const responseBody = await response.json();
    expect(responseBody).toEqual({
        message: `Account ${accountId} is unfrozen`,
    });

    const dbRecord = await getRecordInInterestAndFeesFreezeTable({ accountId, createdAt });
    expect(dbRecord.Item.status).toBe("UNFROZEN");

    const updatedCreditAccount = await getCreditAccount(accountId);

    expect(updatedCreditAccount.data.accountDetails.interestRate).toEqual(
        dbRecord.Item.originalInterestRate,
    );
});

test("Throws error if the accountId is not provided", async () => {
    const response = await invokeUnfreezeInterestAndFees("");

    expect(response.status).toBe(400);
    expect(await response.json()).toEqual({
        message: "AccountId missing in path params",
    });
});
