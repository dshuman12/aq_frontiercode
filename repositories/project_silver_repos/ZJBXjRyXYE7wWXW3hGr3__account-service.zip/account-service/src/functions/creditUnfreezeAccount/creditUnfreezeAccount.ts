import { Logger } from "@onmoapp/onmo-logger";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { formatJSONResponse } from "@libs/api-gateway";
import { generateErrorResponse } from "@utils/onmoErrorHandler";
import { InterestAndFeesFreezeRepository } from "@utils/interestAndFeesFreezeRepository";
import { getCoreBankingAdapter } from "src/adapters";
import { INTEREST_FEES_FREEZE_STATUS } from "@libs/constants";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import customParseFormat from "dayjs/plugin/customParseFormat";
dayjs.extend(utc);
dayjs.extend(customParseFormat);
dayjs.extend(timezone);

export const handler = async (event) => {
    const logger = new Logger(
        {
            env: process.env.STAGE,
        },
        "INFO",
    );
    try {
        const accountId: string = event.pathParameters?.accountId;
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }

        logger.addContext({ accountId });

        const interestAndFeesFreezeRepository = InterestAndFeesFreezeRepository.getInstance();

        const accountFreezeData = await interestAndFeesFreezeRepository.getByAccountId(accountId);

        logger.info(
            `Retrieved account's freeze details for ${accountFreezeData.accountId} - creation date:${accountFreezeData.createdAt} - status: ${accountFreezeData.status}`,
        );

        if (!accountFreezeData) {
            throw new OnmoError({
                name: ErrorNamesEnum.NOT_FOUND_ERROR,
                message: `Interest and fees freeze details not found for accountId ${accountId}`,
            });
        }

        if (accountFreezeData.status !== INTEREST_FEES_FREEZE_STATUS.FROZEN) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: `Account ${accountId} is not frozen`,
            });
        }

        logger.info(`Retrieved account's freeze details ${accountFreezeData}}`);

        const { accountId: retrievedAccountId, createdAt } = accountFreezeData;

        const valueDate = dayjs().tz("UTC").format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

        const coreBankingAdapter = await getCoreBankingAdapter();
        const response = await coreBankingAdapter.updateInterestRateToCreditAccount(
            retrievedAccountId,
            {
                interestRate: accountFreezeData.originalInterestRate,
                valueDate: valueDate,
                notes: "Unfreezing interest and fees",
            },
        );

        if (!response || response.error || !response.data) {
            throw new OnmoError({
                name: ErrorNamesEnum.ADAPTER_CLIENT_CALL_FAILURE_ERROR,
                message: "Unable to update credit account",
                cause: {
                    errorCode: response?.error.errorCode,
                    errorMessage: response?.error.errorMessage,
                },
            });
        }

        logger.info(
            `Updated interest rate on account  ${accountId} to ${accountFreezeData.originalInterestRate}`,
        );

        await interestAndFeesFreezeRepository.updateFieldsByPK(
            { accountId: retrievedAccountId, createdAt },
            { status: INTEREST_FEES_FREEZE_STATUS.UNFROZEN },
        );

        logger.info(`Updated account's freeze status for ${accountId}} to UNFROZEN`);

        return formatJSONResponse(200, { message: `Account ${accountId} is unfrozen` });
    } catch (error) {
        logger.error(`Error occurred in creditUnfreezeAccount handler: ${error}`);
        const { statusCode, message } = generateErrorResponse(error);
        return formatJSONResponse(statusCode, {
            message,
        });
    }
};
