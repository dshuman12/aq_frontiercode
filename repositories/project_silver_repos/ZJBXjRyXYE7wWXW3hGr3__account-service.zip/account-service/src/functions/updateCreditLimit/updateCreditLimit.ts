import { APIGatewayEvent } from "aws-lambda";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { checkValidation } from "@validators/index";
import { parseAPIGateWayEventBody } from "@utils/parsePayload";
import { formatJSONResponse } from "@libs/api-gateway";
import { generateErrorResponse, throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { getLogger } from "@utils/logger";
import { updateCreditLimitPayload } from "@libs/types";
import { updateCreditLimitValidationSchema } from "@validators/updateCreditLimit.validator";
import { getCoreBankingAdapter, getSalesforceAdapter } from "src/adapters";

export const restrictedAccountFlags = [
    "ParticularlyVulnerableCustomer",
    "DebtSale",
    "PendingDeceased",
    "ConfirmedDeceased",
];

export const handler = async (event: APIGatewayEvent) => {
    const logger = getLogger();
    const accountId: string = event.pathParameters?.accountId || "";

    try {
        if (!accountId) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "AccountId missing in path params",
            });
        }
        logger.addContext({ accountId });

        const payload = checkValidation(
            updateCreditLimitValidationSchema,
            parseAPIGateWayEventBody(event.body),
        ) as updateCreditLimitPayload;
        logger.info({ payload });

        const coreBankingAdapter = await getCoreBankingAdapter();
        const accountInformationRes = await coreBankingAdapter.getCreditAccount(accountId);

        throwErrorIfAdapterResHaveError(accountInformationRes, {
            message: "Failed to get credit account",
        });

        const accountInfo = accountInformationRes.data;
        const { creditLimit, availableCredit, interestRate } = accountInfo.accountDetails;
        const principalBalance = accountInfo?.accountBalances?.balances?.principal ?? 0;
        const totalCreditUtilization = parseFloat(
            (creditLimit - availableCredit + (principalBalance * interestRate) / 100).toFixed(2),
        );

        const isEligibleForNewCreditLimit = !(totalCreditUtilization > payload.amount);

        logger.info({
            creditLimit,
            availableCredit,
            principalBalance,
            interestRate,
            totalCreditUtilization,
            isEligibleForNewCreditLimit,
        });

        if (!isEligibleForNewCreditLimit) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: "The account is not eligible for given credit limit",
            });
        }

        const salesforceAdapter = await getSalesforceAdapter();
        const accountFlags = await salesforceAdapter.getActiveCustomerFlagsByCustomerId(
            accountInfo.accountDetails.customerId,
        );

        logger.info({ accountFlags });

        const matchAccountFlag = accountFlags.find((flag) => restrictedAccountFlags.includes(flag));

        if (matchAccountFlag) {
            throw new OnmoError({
                name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
                message: `Unable to update credit limit as restricted flag ${matchAccountFlag} are present`,
            });
        }

        const updateCreditAccountLimitRes = await coreBankingAdapter.updateCreditAccountLimit(
            accountId,
            payload.amount,
            payload.notes ?? "",
        );

        logger.info({ updateCreditAccountLimitRes });

        throwErrorIfAdapterResHaveError(updateCreditAccountLimitRes, {
            message: "Failed to update credit account limit",
        });

        return formatJSONResponse(200, {
            message: "The account has been updated with given credit limit",
        });
    } catch (error) {
        const { statusCode, message, debugMessage } = generateErrorResponse(error);
        logger.error({ debugMessage, message, errorMessage: error.message });
        const errorMessage =
            statusCode === 500 ? (debugMessage?.cause?.errorMessage ?? error.message) : message;

        return formatJSONResponse(statusCode, {
            message: errorMessage,
        });
    }
};
