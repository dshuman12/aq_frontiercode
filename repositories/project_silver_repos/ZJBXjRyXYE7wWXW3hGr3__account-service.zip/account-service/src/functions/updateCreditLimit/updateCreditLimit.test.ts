import { test, expect, beforeAll } from "vitest";
import { fetchAPISecret, setupTestAccountWithSalesforceAccount } from "@utils/testUtils";
import { getSalesforceAdapter } from "src/adapters";
import dayjs from "dayjs";
import { restrictedAccountFlags } from "./updateCreditLimit";
import { AccountFlags } from "@onmoapp/onmo-types";

let apiKey: string;
const internal_api_domain = process.env.INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string; // WAF

const invokeUpdateCreditLimitAPI = async (
    accountId: string,
    payload: Record<string, any>,
    apiKeyValue: string = apiKey,
    includeApiKey: boolean = true,
): Promise<{ result: { message: string }; statusCode: number }> => {
    const update_credit_limit_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/credit-limit`;
    const response = await fetch(update_credit_limit_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
            "x-api-test-secret": api_test_secret,
        },
        body: JSON.stringify(payload),
    });
    const result = (await response.json()) as { message: string };
    return { result, statusCode: response.status };
};

beforeAll(async () => {
    apiKey = await fetchAPISecret();
});

test("happy path: credit limit updated successfully", async () => {
    const { accountId } = await setupTestAccountWithSalesforceAccount();

    const { result, statusCode } = await invokeUpdateCreditLimitAPI(accountId, {
        amount: 5000,
    });
    const salesforceAdapter = await getSalesforceAdapter();
    await salesforceAdapter.deleteFinancialAcc(accountId);
    expect(statusCode).toEqual(200);
    expect(result.message).toBe("The account has been updated with given credit limit");
});

// TODO: Fix flaky integration test — restricted flag check not working in staging
test.skip("should error: can not update credit limit as restricted flag present", async () => {
    const salesforceAdapter = await getSalesforceAdapter();

    for (const flag of restrictedAccountFlags) {
        const { accountId, crmFinancialAccountId } = await setupTestAccountWithSalesforceAccount();

        await salesforceAdapter.createAccountFlag({
            financialAccountId: crmFinancialAccountId,
            flagType: flag as AccountFlags,
            startDate: dayjs().startOf("month").format("YYYY-MM-DD"),
            endDate: dayjs().endOf("month").format("YYYY-MM-DD"),
            status: true,
        });
        const { result, statusCode } = await invokeUpdateCreditLimitAPI(accountId, {
            amount: 5000,
        });
        await salesforceAdapter.deleteFinancialAcc(accountId);
        expect(result.message).toBe(
            `Unable to update credit limit as restricted flag ${flag} are present`,
        );
        expect(statusCode).toEqual(400);
    }
});

test("should error: account is not eligible for credit limit update", async () => {
    const { accountId } = await setupTestAccountWithSalesforceAccount();
    const { result, statusCode } = await invokeUpdateCreditLimitAPI(accountId, {
        amount: 40,
    });
    const salesforceAdapter = await getSalesforceAdapter();
    await salesforceAdapter.deleteFinancialAcc(accountId);
    expect(statusCode).toEqual(400);
    expect(result.message).toBe("The account is not eligible for given credit limit");
});

test("should error: amount is required", async () => {
    const { result, statusCode } = await invokeUpdateCreditLimitAPI("ABCDE", {});
    expect(statusCode).toEqual(400);
    expect(result.message).toEqual("amount is required");
});

test("should error: accountId is required", async () => {
    const { result, statusCode } = await invokeUpdateCreditLimitAPI("", { amount: 5000 });
    expect(statusCode).toEqual(400);
    expect(result.message).toEqual("AccountId missing in path params");
});

test("should error: account not found", async () => {
    const { result, statusCode } = await invokeUpdateCreditLimitAPI("ABCDE", { amount: 5000 });
    expect(statusCode).toEqual(404);
    expect(result.message).toEqual("Could not found an account");
});
