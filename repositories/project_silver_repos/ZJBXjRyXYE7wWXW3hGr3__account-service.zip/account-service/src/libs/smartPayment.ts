import { FeatureFlagClient } from "@onmoapp/feature-flag";
import { SMART_PAYMENTS_FLAG } from "@libs/constants";

export type SmartPayment = {
    suggestedAmount: number;
    multiplier: number;
    variant: string;
};

export async function calculateSmartPayment(
    featureFlagClient: FeatureFlagClient,
    customerId: string,
    minPayment: number,
    totalBalance: number,
): Promise<SmartPayment | null> {
    const variant = await featureFlagClient.getFeatureFlag(SMART_PAYMENTS_FLAG, customerId);
    if (!variant || typeof variant !== "string") return null;

    const payload = await featureFlagClient.getFeatureFlagPayload(
        SMART_PAYMENTS_FLAG,
        customerId,
        variant,
    );

    const raw = (payload as Record<string, unknown>)?.multiplier;
    if (typeof raw !== "number") return null;

    const suggestedAmount = Math.min(Number((minPayment * raw).toFixed(2)), totalBalance);
    if (suggestedAmount <= 0) return null;

    return { suggestedAmount, multiplier: raw, variant };
}
