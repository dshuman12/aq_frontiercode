import { CoreBanking } from "@onmoapp/core-banking";
import { Logger } from "@onmoapp/onmo-logger";
import { DirectDebitSettings, UpdateCreditAccountOutcome } from "@onmoapp/onmo-types";
import { findAndDeleteSchedule } from "@utils/findAndDeleteSchedule";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";

export const retryFlagsRemoved = (ddSettings: DirectDebitSettings): boolean => {
    return (
        !ddSettings.directDebitAvoidFeeCutOffDate &&
        !ddSettings.directDebitPreventRetryDate &&
        !ddSettings.directDebitRetryDate
    );
};

export const handleDDRetryCancellation = async ({
    shouldCancel,
    ddSettings,
    logger,
    coreBankingClient,
    accountId,
}: {
    shouldCancel: boolean;
    ddSettings: DirectDebitSettings;
    logger: Logger;
    coreBankingClient: CoreBanking;
    accountId: string;
}) => {
    if (!shouldCancel) {
        logger.info({
            message: `The user did not cover the DD amount. Keeping the retry for account ${accountId}`,
        });
        return;
    }

    logger.info({
        message: `The user covered the DD amount. Cancelling the retry for account ${accountId}`,
    });

    await findAndDeleteSchedule(accountId);

    if (retryFlagsRemoved(ddSettings)) {
        if (!ddSettings.mandateID) {
            logger.info({
                message: "The user cancelled their DD mandate. No need to remove DD retry flags.",
            });
            return;
        }

        // DD retry flags where removed but we still have the mandateID. This shouldn't happen, raise an alert
        logger.error({
            message: `Alert_DDRetryFlagsWithMandate: The DD retry flags were removed for ${accountId} yet the mandate is still present. Investigate.`,
        });
    }

    const updateDDRetryFields: UpdateCreditAccountOutcome =
        await coreBankingClient.updateDDRetryFields(accountId, false, null, null, null);
    throwErrorIfAdapterResHaveError(updateDDRetryFields, {
        message: "Failed to update DD retry fields",
    });
    logger.info({
        message: "Removing dd retry fields from credit account",
    });
};
