export const formatJSONResponse = (statusCode: number, response: Record<string, unknown>) => {
    return {
        statusCode: statusCode,
        headers: {
            "Content-Type": "application/json",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        },
        body: response,
    };
};
