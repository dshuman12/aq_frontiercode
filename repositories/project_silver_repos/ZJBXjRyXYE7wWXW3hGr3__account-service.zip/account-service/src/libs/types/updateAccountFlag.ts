import { AccountFlagTypes } from ".";

export type UpdateAccountFlagRequestBody = {
    flagName: AccountFlagTypes;
    flagDetails: {
        status: boolean;
        startDate?: string;
        endDate?: string;
    };
};
