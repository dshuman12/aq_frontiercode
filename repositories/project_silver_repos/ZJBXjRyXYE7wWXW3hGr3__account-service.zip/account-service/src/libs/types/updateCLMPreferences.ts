export type UpdateCLMPreferencesRequestBody = {
    opt_out: boolean;
    auto_apply: boolean;
};
