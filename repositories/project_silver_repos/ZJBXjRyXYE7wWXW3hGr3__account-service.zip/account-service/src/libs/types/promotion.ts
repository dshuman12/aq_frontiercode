import { z } from "zod";

import type { Result } from "./result";

export const PromotionStatus = {
    ACTIVE: "ACTIVE",
    APPLIED: "APPLIED",
    CANCELLED: "CANCELLED",
} as const;
export type PromotionStatus = (typeof PromotionStatus)[keyof typeof PromotionStatus];

export const PromotionType = {
    HONEYMOON: "HONEYMOON",
} as const;
export type PromotionType = (typeof PromotionType)[keyof typeof PromotionType];

export const NotificationStatus = {
    PENDING: "PENDING",
} as const;
export type NotificationStatus = (typeof NotificationStatus)[keyof typeof NotificationStatus];

export const PromotionErrorCode = {
    ALREADY_EXISTS: "ALREADY_EXISTS",
    WRITE_FAILED: "WRITE_FAILED",
    QUERY_FAILED: "QUERY_FAILED",
    UPDATE_FAILED: "UPDATE_FAILED",
} as const;
export type PromotionErrorCode = (typeof PromotionErrorCode)[keyof typeof PromotionErrorCode];

export interface PromotionError {
    code: PromotionErrorCode;
    message: string;
}

export type PromotionResult<Data = void> = Result<Data, PromotionError>;

export interface PagedResult<T> {
    items: T[];
    cursor?: Record<string, unknown>;
}

export interface PromotionRecord {
    id: string;
    promotion_id: string;
    onmouuid: string;
    promotion_type: PromotionType;
    credit_account_id: string;
    promotional_interest_rate: number;
    original_interest_rate: number;
    original_apr: number;
    status: PromotionStatus;
    notification_status?: NotificationStatus;
    start_date: number;
    end_date: number;
    applied_at?: number | null;
    cancelled_at?: number | null;
    notification_sent_at?: number | null;
    cancelled_reason?: string | null;
    version: number;
    created_at: number;
    updated_at: number;
}

export const PromotionResponseItemSchema = z
    .object({
        promotionType: z.enum(Object.values(PromotionType) as [PromotionType, ...PromotionType[]]),
        promotionalInterestRate: z.number(),
        originalInterestRate: z.number(),
        originalApr: z.number(),
        startDate: z.number(),
        endDate: z.number(),
    })
    .strict();

export type PromotionResponseItem = z.infer<typeof PromotionResponseItemSchema>;

export interface CreatePromotionInput {
    onmouuid: string;
    credit_account_id: string;
    promotion_type: PromotionType;
    promotional_interest_rate: number;
    original_interest_rate: number;
    original_apr: number;
    start_date: number;
    end_date: number;
}
