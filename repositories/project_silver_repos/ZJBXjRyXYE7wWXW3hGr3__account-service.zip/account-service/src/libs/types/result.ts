export type Result<Data, Err extends { message: string }> =
    | { ok: true; data: Data; error?: never }
    | { ok: false; error: Err; data?: never };

export const Success = <Data = void>(data?: Data) => ({
    ok: true as const,
    data: data as Data,
});

export const Failure = <Err extends { message: string }>(error: Err) => ({
    ok: false as const,
    error,
});
