import {
    DocumentInfo,
    AccountGenericData,
    AccountDetails,
    DirectDebitSettings,
    Balances,
    Due,
    ArrearBalances,
    PaymentPlan,
    CardStatus,
    AccountBalances,
} from "@onmoapp/onmo-types";
import { ACCOUNT_FLAGS, WRITE_OFF_TYPE } from "../constants";
import { PromotionResponseItem } from "./promotion";

export * from "./oidcAuth";
export * from "./eventHub-types";

/** Document Type with id */
export type DocType = DocumentInfo & {
    id: number;
};

export type IndexType = {
    [key: string]: {
        startingIndex: number;
        endingIndex: number;
        length: number;
    };
};

export type DocumentsRes = {
    documents: DocumentInfo[];
    nextPeriodFrom: string;
    documentCursor: 0;
};

export type ModifiedAccountDetails = Omit<
    AccountDetails,
    | "accountEncodedKey"
    | "coreBankingCustomerEncodedKey"
    | "ifInArrears"
    | "monthlyRepaymentDays"
    | "approvedDate"
> & {
    isInArrears: boolean | null;
};

export type PaymentPlanRenamedFields = {
    status?: string | null;
    amount?: number | null;
    startDate?: string | null;
    endDate?: string | null;
};

export type PaymentPlanOmittedFields =
    | "promiseToPay"
    | "paymentPlan"
    | "paymentPlanWithFees"
    | "thirdPartyTokenPlan"
    | "paymentPlanStatus"
    | "paymentPlanAmount"
    | "paymentPlanStartDate"
    | "paymentPlanEndDate";

export type ModifiedPaymentPlan = Omit<PaymentPlan, PaymentPlanOmittedFields> &
    PaymentPlanRenamedFields;

type BalancesWithoutTechnicalAccountBalance = Omit<Balances, "technicalAccountBalance">;

type ModifiedAccountBalances = Omit<AccountBalances, "interestAccrued" | "balances"> & {
    balances: BalancesWithoutTechnicalAccountBalance;
    suggestedSmartPaymentAmount: number | null;
    smartPaymentMultiplier: number | null;
    smartPaymentVariant: string | null;
};

export type GetAccountResponseBodyData = {
    [K in keyof Omit<AccountGenericData, "installmentDetails">]: K extends "accountDetails"
        ? ModifiedAccountDetails
        : K extends "paymentPlans"
          ? ModifiedPaymentPlan[]
          : K extends "accountBalances"
            ? ModifiedAccountBalances
            : AccountGenericData[K];
} & {
    promotions: PromotionResponseItem[];
};

export type ErrorMessageResponse = {
    message: string;
};

export type UpdateAccountResponse = {
    message: string;
};

export type AccountUpsertedEvent = {
    accountDetails: {
        accountId: string;
        customerId: string;
        state: string;
        accountState: string;
        additionalAccountState: string;
        inArrearsDate: string | null;
        isInArrears: boolean;
        interestRate: number;
        creditLimit: number;
        availableCredit: number;
        apr: number;
        startOfBillingCycle: string;
        nextStatementDueDate: string | null;
        daysLate: number | null;
    };
    directDebitSettings: DirectDebitSettings;
    accountBalances: {
        totalNextMinimumPayment: number;
        balances: BalancesWithoutTechnicalAccountBalance;
        arrearBalances: ArrearBalances;
        due: Due;
    };
};

export type AccountUpsertedEventRequestBody = {
    accountId: string;
    customerId: string;
    state: string;
    coreBankingAccountType?: string;
};

export type AccountCreatedRequestBody = {
    technicalAccountId: string;
    customerId: string;
};

/** Account Flags Types (CRM Flags) */
export type AccountFlagTypes = (typeof ACCOUNT_FLAGS)[number];

export type EventHubDataToPublishType = {
    schemaId: string;
    event: string;
    subtype: string;
    data: string;
};

export type CardStatusChangedEvent = {
    cardId: string;
    statusCode: CardStatus;
    statusDate: string;
    reasonCode: string;
    prevStatusCode?: CardStatus | "NA";
};

export type CardProvisionedEvent = {
    cardId: string;
    accountId: string;
    lastFourDigits: string;
    creationDate: string;
    activationDate: string;
    expirationDate: string;
    statusCode: CardStatus;
    statusDate: string;
    reasonCode: string;
    numberOfInvalidPinAttempts?: number;
};

export interface creditWriteOffAccount {
    writeOffType: WRITE_OFF_TYPE;
    notes: string;
}

export interface closeAccountPayload {
    notes: string;
}

export interface updateCreditLimitPayload {
    amount: number;
    notes?: string;
}
