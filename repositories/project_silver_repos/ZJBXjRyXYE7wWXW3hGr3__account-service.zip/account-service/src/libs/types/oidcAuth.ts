export type accessTokenObject = {
    access_token: string;
    token_id: string;
};
