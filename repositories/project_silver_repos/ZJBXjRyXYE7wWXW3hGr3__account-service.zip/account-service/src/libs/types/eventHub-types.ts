import { EventData } from "src/adapters";

export enum AccountType {
    Card = "CARD",
    Load = "LOAN", // not in use for now, this will be for term loans
}

export enum RepaymentType {
    Card = "CARD",
    Bank = "PAY_BY_BANK",
    DirectDebit = "DIRECT_DEBIT",
    DirectDebitRetry = "DIRECT_DEBIT_RETRY",
    CPA = "CPA",
}

export type Repayment = {
    amount: number;
    paymentMethod: RepaymentType;
    externalId: string;
};

export type RepaymentCollectedEvent = {
    accountId: string;
    accountType: AccountType;
    customerId: string;
    repayment: Repayment;
    processor: "Stripe";
    date: string;
    mandateId: string | null;
};

export type MandateUpsertedEvent = {
    mandateDetails: MandateDetails;
    startDate: number;
    created: number;
};

type MandateDetails = {
    mandateId: string;
    oldMandateId: string | null;
    accountId: string;
    customerId: string;
    status: "PENDING" | "ACTIVE" | "CANCELLED" | "FAILED";
    bankDetails: BankDetails;
    startDate: number;
    processorReference: string;
};

type BankDetails = {
    accountNumber: string;
    sortCode: string;
    accountName: string;
};

export type MandateCancelledEvent = {
    mandateId: string;
    accountId: string;
    customerId: string;
    cancellationReason: CancellationReason;
    cancellationDate: number;
};

type CancellationReason =
    | "ACCOUNT_CLOSED"
    | "BANK_ACCOUNT_CLOSED"
    | "BANK_ACCOUNT_RESTRICTED"
    | "MANDATE_EXPIRED"
    | "PAYMENT_FAILED"
    | "OTHER";

export type Body = {
    context?: {
        partnerResourceArn: string;
        condition: string;
    };
    requestContext?: {
        requestId: string;
        functionArn: string;
        condition: string;
        approximateInvokeCount: number;
    };
    responseContext?: {
        statusCode: number;
        executedVersion: string;
        functionError: string;
    };
    version: string;
    timestamp: string;
    KinesisBatchInfo: {
        shardId: string;
        startSequenceNumber: string;
        endSequenceNumber: string;
        approximateArrivalOfFirstRecord: string;
        approximateArrivalOfLastRecord: string;
        batchSize: number;
        streamArn: string;
    };
};

export type KinesisDlqData = {
    eventData: EventData<RepaymentCollectedEvent>;
    metaData: Body;
};

export type CLMPreferenceChangeEvent = {
    accountId: string;
    customerId: string;
    optOut: boolean;
    autoApply: boolean;
};

export enum CPACancellationReason {
    CancellationRequested = "cancellation_requested",
    PaymentDisputed = "payment_disputed",
    PaymentFailed = "payment_failed",
    EndDateReached = "end_date_reached",
    BalancePaid = "balance_paid",
}

type CPASubscriptionDetails = {
    subscriptionId: string;
    status: string;
    amount: number;
    currentPeriodEnd: number;
};

export type CPASubscriptionCreatedEvent = {
    accountId: string;
    accountType: AccountType;
    customerId: string;
    pspCustomerId: string;
    subscriptionDetails: CPASubscriptionDetails;
    processor: string;
    processorReference: string | null;
};

export type CPASubscriptionCancelledEvent = {
    accountId: string;
    accountType: AccountType;
    customerId: string;
    pspCustomerId: string;
    subscriptionDetails: CPASubscriptionDetails & {
        cancellationReason: CPACancellationReason;
    };
    processor: string;
    processorReference: string | null;
};
