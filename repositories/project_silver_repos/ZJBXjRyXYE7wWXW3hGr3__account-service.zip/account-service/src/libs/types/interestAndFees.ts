import { INTEREST_FEES_FREEZE_STATUS, REASONS } from "@libs/constants";
import { Transaction, ResponseMessage } from "@onmoapp/onmo-types";

export type Reason = (typeof REASONS)[number];

type GocardlessTransactionMetaData = {
    serviceProvider: "Gocardless";
    directDebitPaymentId: string;
};
type AcquiredTransactionMetaData = {
    serviceProvider: "Acquired";
    debitCardPaymentId: string;
};

type StripeTransactionMetaData = {
    serviceProvider: "Stripe";
    directDebitPaymentId?: string;
    debitCardPaymentId?: string;
};

export type transactionMetaData =
    | GocardlessTransactionMetaData
    | AcquiredTransactionMetaData
    | StripeTransactionMetaData;

export interface IFreezeInterestAndFeesPayload {
    reason: Reason;
    startDate: string;
    endDate?: string;
    disableFreezeWhenArrearsCleared: boolean;
    applyAccruedInterest: boolean;
    rollbackFreezeProcess?: boolean;
}

export interface interestAndFeesPK {
    accountId: string;
    createdAt: string;
}
export interface UpdateFieldsPayload {
    originalInterestRate?: number;
    apr?: number;
    status?: INTEREST_FEES_FREEZE_STATUS;
    adjustedTransactions?: (Transaction & {
        recreate_status?: string;
        recreatedTransactionId?: string;
    })[];
    failedToAdjustTransactions?: (Transaction & {
        recreate_status?: string;
    })[];
    adjustmentVerified?: boolean;
    accruedInterestStatus?: string;
    accruedInterestDate?: string;
    updateZeroInterestDate?: string;
}

export interface InterestAndFeesFreezeData {
    accountId: string;
    onmouuid?: string;
    originalInterestRate: number;
    apr: number;
    status: INTEREST_FEES_FREEZE_STATUS;
    reason: Reason;
    startDate: string;
    endDate: string;
    createdAt?: string;
    updatedAt?: string;

    adjustedTransactions?: (Transaction & {
        recreate_status?: string;
        recreatedTransactionId?: string;
    })[];
    failedToAdjustTransactions?: (Transaction & {
        recreate_status?: string;
    })[];
    adjustmentVerified?: boolean;
    accruedInterestStatus?: string;
    accruedInterestDate?: string;
    updateZeroInterestDate?: string;
}

export interface IInterestAndFeesFreezeRepository {
    getByAccountId(accountId: string): Promise<InterestAndFeesFreezeData>;
    create(accountRecords: InterestAndFeesFreezeData): Promise<InterestAndFeesFreezeData>;
    update(accountRecords: InterestAndFeesFreezeData): Promise<void>;
    updateFieldsByPK(
        primaryKey: interestAndFeesPK,
        updateData: UpdateFieldsPayload,
    ): Promise<InterestAndFeesFreezeData>;
    getByAccountIdAndStatus(
        accountId: string,
        status: INTEREST_FEES_FREEZE_STATUS,
    ): Promise<InterestAndFeesFreezeData[]>;
}

export interface IInterestAndFeeService {
    checkHistoryItem(): void;
    setHistoryItem(historyItem: InterestAndFeesFreezeData): void;
    updateHistoryStatus(status: INTEREST_FEES_FREEZE_STATUS): Promise<void>;

    validationCheck(currentBalance: number): Promise<void>;
    adjustTransactions(): Promise<void>;
    updateZeroInterestRateToAccount(accountId: string, valueDate: string): Promise<ResponseMessage>;
    applyAccruedInterest(accountId: string, applyDate: string): Promise<void>;
    recreateTransaction(accountId: string): Promise<void>;
    rollbackFreezeProcess(rollbackData: {
        accountEncodedKey: string;
        processCode: number;
    }): Promise<void>;
}
