import { getCoreBankingAdapter, getEventHubAdapter, getCoreRepaymentsAdapter } from "src/adapters";
import { StripeClient } from "@onmoapp/core-repayments/stripe";
import { BACKDATE_TRANSACTION_INITIATED_BY } from "@libs/constants";
import { RepaymentCollectedEvent, RepaymentType } from "@libs/types/index";
import dayjs, { Dayjs } from "dayjs";

import customParseFormat from "dayjs/plugin/customParseFormat";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(customParseFormat);
dayjs.extend(utc);
dayjs.extend(timezone);

import { getItemMethod } from "@onmoapp/onmo-dynamodb";
import { OnmoError } from "@onmoapp/onmo-error-types";
import {
    MakeRepaymentToCreditAccountInput,
    Transaction,
    UpdateCreditAccountOutcome,
} from "@onmoapp/onmo-types";
import { formatJSONResponse } from "@libs/api-gateway";
import { throwErrorIfAdapterResHaveError } from "@utils/onmoErrorHandler";
import { shouldCancelDDRetry } from "../functions/repaymentCollectedListener/shouldCancelDDRetry";

import { Logger } from "@onmoapp/onmo-logger";
import { v4 as uuid } from "uuid";
import { handleDDRetryCancellation } from "./ddRetryCancelUtil";

import { EventData } from "@onmoapp/event-hub-kinesis-adapter";
dayjs.extend(customParseFormat);

const errorMessageToIgnore = ["ACCOUNT_HAS_NO_ACCRUED_INTEREST", "TRANSACTION_ALREADY_ADJUSTED"]; // for retries

const backdatingErrors = ["EXCESS_REPAYMENT_ERROR", "NON_POSITIVE_TOTAL_BALANCE"];

const transactionChannelIdMapping = {
    Stripe: {
        [RepaymentType.Card]: "repaymt_card_stripe",
        [RepaymentType.DirectDebit]: "repaymt_direct_debit_stripe",
        [RepaymentType.Bank]: "repaymt_pay_by_bank",
        [RepaymentType.DirectDebitRetry]: "repaymt_direct_debit_stripe",
        [RepaymentType.CPA]: "repaymt_cpa_stripe",
    },
};

const getTransactionChannelId = (event: RepaymentCollectedEvent) => {
    return transactionChannelIdMapping[event.processor][event.repayment.paymentMethod];
};

const getTransactionMetadata = (
    event: RepaymentCollectedEvent,
): MakeRepaymentToCreditAccountInput["transactionMetaData"] => {
    if (
        event.repayment.paymentMethod === RepaymentType.Card ||
        event.repayment.paymentMethod === RepaymentType.CPA
    )
        return {
            serviceProvider: event.processor,
            debitCardPaymentId: event.repayment.externalId,
        };
    if (event.repayment.paymentMethod === RepaymentType.Bank)
        return {
            serviceProvider: event.processor,
            debitCardPaymentId: event.repayment.externalId,
        };
    if (
        event.repayment.paymentMethod === RepaymentType.DirectDebit ||
        event.repayment.paymentMethod === RepaymentType.DirectDebitRetry
    )
        return {
            serviceProvider: event.processor,
            directDebitPaymentId: event.repayment.externalId,
        };
};

const getTechnicalAccountAmount = ({
    amount,
    loanAccountAmountInPence,
    existingTransaction,
}: {
    amount: number;
    loanAccountAmountInPence: number;
    existingTransaction?: Transaction;
}) => {
    // The amount needs to be consistent whether or not the transaction already exists
    const existingTransactionAmountInPence = existingTransaction
        ? Number((existingTransaction.destinationAmount * 100).toFixed(2))
        : 0;

    const technicalAccountAmountInPence = existingTransaction
        ? amount + existingTransactionAmountInPence // transaction amount is negative
        : amount - loanAccountAmountInPence;

    return technicalAccountAmountInPence;
};

const getTransactionValueDate = async ({
    repaymentDate,
    accountId,
    logger,
}: {
    repaymentDate: string;
    accountId: string;
    logger: Logger;
}): Promise<Dayjs> => {
    let valueDate = dayjs(repaymentDate).tz("Europe/London");

    if (process.env.ENVIRONMENT === "staging") {
        const secrets = await StripeClient.retrieveSecrets(process.env.ENVIRONMENT);
        if (secrets.ddRetryBypassDateInFutureAccounts?.includes(accountId)) {
            logger.info({
                message: `Account ${accountId} is in the bypass list. Setting value date to today`,
            });
            return dayjs().tz("Europe/London"); // Set transaction date to today
        }
    }
    return valueDate;
};

const backdateTransaction = async (
    repaymentCollectedEvent: EventData<RepaymentCollectedEvent>,
    logger: Logger,
) => {
    const repaymentCollected = repaymentCollectedEvent.eventData;

    const repaymentDate = dayjs(repaymentCollected.date);
    const today = dayjs();

    if (repaymentDate.isSame(today, "day")) {
        // This was the last available date to put the transaction. Throw. (this shouldn't happen)
        logger.error({ message: "Cannot backdate transaction to today!" });
        throw new OnmoError({
            message: "Could not backdate transaction.",
            name: "SOME_ERROR_OCCURRED",
        });
    }

    let addedOneDay = repaymentDate.add(1, "day");

    if (addedOneDay.isSame(today, "day")) {
        // if there were any disbursement same day we need to make sure we try to enter the transaction after
        // otherwise we will keep getting the excess repayment error
        addedOneDay = addedOneDay.set("hour", today.hour());
        addedOneDay = addedOneDay.set("minute", today.minute());
        addedOneDay = addedOneDay.set("second", today.second());
    }

    logger.info({
        message: `Retrying the transaction for ${addedOneDay.toISOString()} ${repaymentCollectedEvent.eventData.accountId}`,
    });

    // Send a new event with the new date to try to record the transaction
    repaymentCollectedEvent.idempotencyKey = uuid(); // need a new key as we are sending a new payload
    repaymentCollectedEvent.initiatedBy = BACKDATE_TRANSACTION_INITIATED_BY;
    repaymentCollectedEvent.eventData.date = addedOneDay.toISOString();
    repaymentCollectedEvent.id = uuid(); // new event id

    const eventHubAdapter = await getEventHubAdapter<RepaymentCollectedEvent>();
    const { isValid: isEventValid, validationErrors } =
        await eventHubAdapter.validateEvent(repaymentCollectedEvent);
    if (!isEventValid) {
        logger.error({ message: "Validation failed", validationErrors });
        throw new OnmoError({
            message: "Validation failed",
            name: "SOME_ERROR_OCCURRED",
            cause: validationErrors,
        });
    }
    const {
        isPublished,
        isValid,
        validationErrors: publishError,
    } = await eventHubAdapter.publishToEventHub(repaymentCollectedEvent);
    if (!isPublished || !isValid) {
        logger.error({ message: "Failed to publish event", publishError });
        throw new OnmoError({
            message: "Failed to publish event",
            name: "SOME_ERROR_OCCURRED",
            cause: validationErrors,
        });
    }
    logger.info({ message: "Event published successfully" });
};

export const processRepayment = async (
    repaymentCollectedEvent: EventData<RepaymentCollectedEvent>,
    logger: Logger,
) => {
    const repaymentCollected = repaymentCollectedEvent.eventData;
    logger.info({ message: "RepaymentCollected received", repaymentCollectedEvent });
    logger.addContext({
        accountId: repaymentCollected.accountId,
        customerId: repaymentCollected.customerId,
    });

    const dynamoResponse = await getItemMethod({
        TableName: process.env.USER_TABLE,
        Key: {
            onmouuid: repaymentCollected.customerId,
        },
    });

    if (!dynamoResponse.Item) {
        throw new OnmoError({
            name: "NOT_FOUND_ERROR",
            message: "User not found",
        });
    }
    const technicalAccountId = dynamoResponse.Item.mambuTechnicalAccountID;
    logger.addContext({ technicalAccountId });

    const { accountId, date: repaymentDate, processor } = repaymentCollected;

    const valueDate = await getTransactionValueDate({ repaymentDate, accountId, logger });
    const coreBankingAdapter = await getCoreBankingAdapter();

    if (repaymentCollectedEvent.initiatedBy !== BACKDATE_TRANSACTION_INITIATED_BY) {
        const { error: applyInterestError } = await coreBankingAdapter.applyInterestToCreditAccount(
            repaymentCollected.accountId,
            {
                interestApplicationDate: valueDate.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
                idempotencyKey: repaymentCollectedEvent.idempotencyKey,
            },
        );

        if (
            applyInterestError &&
            !errorMessageToIgnore.some((error) => applyInterestError.errorMessage?.includes(error))
        ) {
            logger.error({
                message: "Error applying interest to credit account",
                applyInterestError,
            });
            throw new OnmoError({
                message: "Error applying interest to credit account",
                name: "ADAPTER_CLIENT_CALL_FAILURE_ERROR",
                cause: applyInterestError,
            });
        }
    }

    const {
        amount: repaymentAmount,
        externalId,
        paymentMethod: repaymentType,
    } = repaymentCollected.repayment;
    const response = await coreBankingAdapter.getCreditAccount(accountId);
    throwErrorIfAdapterResHaveError(response, {
        message: "Failed to get credit account Details",
    });

    const loanBalances = response.data.accountBalances.balances;

    // Amount we receive from the provider is in pences to avoid floating point errors
    const totalBalanceInPence = Number(
        ((loanBalances.fees + loanBalances.interest + loanBalances.principal) * 100).toFixed(2),
    );

    // If the repayment made is more than the total balance, we put the extra in the technical account
    const loanAccountAmountInPence = Math.min(totalBalanceInPence, repaymentAmount);

    const isDDorDDRetry =
        repaymentType === RepaymentType.DirectDebit ||
        repaymentType === RepaymentType.DirectDebitRetry;

    logger.info({ totalBalanceInPence, loanAccountAmountInPence });

    const findTransactionsResponse =
        await coreBankingAdapter.findCreditAccountTransactionsByExternalId(accountId, externalId);
    throwErrorIfAdapterResHaveError(findTransactionsResponse, {
        message: "Failed to search transactions",
    });

    const existingTransaction =
        findTransactionsResponse.data.transactions.length > 0
            ? findTransactionsResponse.data.transactions[0]
            : null;

    if (loanAccountAmountInPence > 0 && !existingTransaction) {
        const payload = {
            amount: Number((loanAccountAmountInPence / 100).toFixed(2)), // Convert to base currency for Mambu
            valueDate: valueDate.format("YYYY-MM-DDTHH:mm:ssZ"),
            bookingDate: valueDate.format("YYYY-MM-DDTHH:mm:ssZ"),
            externalId,
            notes: `${processor} ${repaymentType.toLocaleLowerCase().replace("_", " ")} repayment for loan account ${accountId}`,
            transactionChannelId: getTransactionChannelId(repaymentCollected),
            transactionMetaData: getTransactionMetadata(repaymentCollected),
            idempotencyKey: repaymentCollectedEvent.idempotencyKey,
        };
        logger.info({
            message: `Making repayment to credit account ${accountId}`,
            payload,
        });
        const repaymentResponse = await coreBankingAdapter.makeRepaymentToCreditAccount(
            accountId,
            payload,
        );

        if (
            !!backdatingErrors.find((errorMsg) =>
                repaymentResponse.error?.errorMessage.includes(errorMsg),
            )
        ) {
            logger.info({
                message: "Error is eligible for backdated retry.",
            });
            await backdateTransaction(repaymentCollectedEvent, logger);
            return formatJSONResponse(200, { message: "Repayment retried successfully." });
        }

        throwErrorIfAdapterResHaveError(repaymentResponse, {
            message: "Error making repayment to credit account",
        });
    } else if (!!existingTransaction) {
        logger.info({
            message: "Loan account transaction already exists. Skipping.",
            existingTransaction,
        });
    }

    // CPA: cancel subscription if total balance is now fully paid
    logger.debug({ loanBalances });
    const loanBalanceTotalInPence = Number((loanBalances.total * 100).toFixed(2));
    const remainingBalanceInPence = loanBalanceTotalInPence - repaymentAmount;
    logger.debug({
        message: "CPA cancellation eligibility check",
        accountId,
        customerId: repaymentCollected.customerId,
        repaymentType,
        repaymentAmount,
        loanBalancesTotalRaw: loanBalances.total,
        loanBalanceTotalInPence,
        remainingBalanceInPence,
    });

    if (remainingBalanceInPence <= 0) {
        logger.debug({
            message: "Total balance is zero or negative, checking for CPA subscription",
        });
        const pspCustomerId = dynamoResponse.Item?.pspCustomerId;

        if (!pspCustomerId) {
            logger.info({
                message: "No pspCustomerId found for customer, skipping CPA balance check",
                customerId: repaymentCollected.customerId,
            });
        } else {
            logger.info({
                message: "Found pspCustomerId. Fetching subscriptions for CPA cancellation",
                pspCustomerId,
            });
            const repaymentsClient = await getCoreRepaymentsAdapter();
            const accountSubscriptions =
                await repaymentsClient.getSubscriptionsByPsPCustomerId(pspCustomerId);
            logger.info({
                message: "Fetched subscriptions for CPA cancellation",
                pspCustomerId,
                subscriptionsCount: accountSubscriptions.subscriptions.length,
                subscriptions: accountSubscriptions.subscriptions.map((sub) => ({
                    subscriptionId: sub.subscriptionId,
                    status: sub.status,
                })),
            });
            const activeSubscription = accountSubscriptions.subscriptions.find(
                (sub) => sub.status === "active",
            );

            if (activeSubscription) {
                logger.info({
                    message: "Total balance is zero, cancelling CPA subscription",
                    pspCustomerId,
                    subscriptionId: activeSubscription.subscriptionId,
                    remainingBalanceInPence,
                });
                const cancelResult = await repaymentsClient.cancelSubscription({
                    subscriptionId: activeSubscription.subscriptionId,
                    metadata: { cancellationReason: "balance_paid" },
                });

                if (cancelResult.error) {
                    logger.error({
                        message: "Failed to cancel CPA subscription after balance paid",
                        error: cancelResult.error,
                        subscriptionId: activeSubscription.subscriptionId,
                    });
                } else {
                    logger.info({
                        message: "CPA subscription cancelled — balance fully paid",
                        subscriptionId: activeSubscription.subscriptionId,
                    });
                }
            } else {
                logger.info({
                    message: "No active CPA subscription found. Skipping cancellation",
                    pspCustomerId,
                    subscriptionsCount: accountSubscriptions.subscriptions.length,
                });
            }
        }
    } else {
        logger.info({
            message: "Skipping CPA cancellation because remaining balance is positive",
            remainingBalanceInPence,
            repaymentAmount,
            loanBalanceTotalInPence,
        });
    }

    /* This is to cater to the edge case where the event was successful in creating the repayment transaction
    but the technical account deposit failed: 
    The idempotency key doesn't help here because the call to retry is the one that failed, so we need 
    to ensure we're providing the correct amount
    
    Example: first attempt: repayment amount: 1200; balance: 1000
    mambu call to add 1000 to go to loan account -> success
    mambu call to add 200 to go to technical account -> failure
    
    retry: same amount of 1200
    the balance is now 0 as we already made a 1000 repayment on retry 1
    loanAccountAmountInPence = 0 so we skip the mambu call to loan account
    as a result, 1200 would go to technical account -> this is wrong, we want 200
    */
    const technicalAccountAmountInPence = getTechnicalAccountAmount({
        amount: repaymentAmount,
        loanAccountAmountInPence,
        existingTransaction,
    });

    const findTechnicalTransactionsResponse =
        await coreBankingAdapter.findTechnicalAccountTransactionsByExternalId(
            accountId,
            externalId,
        );
    throwErrorIfAdapterResHaveError(findTransactionsResponse, {
        message: "Failed to search technical account transactions",
    });

    const existingDeposit =
        findTechnicalTransactionsResponse.data.transactions.length > 0
            ? findTransactionsResponse.data.transactions[0]
            : null;

    if (technicalAccountAmountInPence > 0 && !existingDeposit) {
        const depositPayload = {
            amount: Number((technicalAccountAmountInPence / 100).toFixed(2)),
            notes: `${processor} ${repaymentType.toLocaleLowerCase().replace("_", " ")} deposit for technical account ${technicalAccountId}`,
            transactionChannelId: getTransactionChannelId(repaymentCollected),
            transactionMetaData: getTransactionMetadata(repaymentCollected),
            externalId,
            idempotencyKey: repaymentCollectedEvent.idempotencyKey,
        };
        logger.info({
            message: `Making deposit to technical account ${technicalAccountId}`,
            depositPayload,
        });
        const depositResponse = await coreBankingAdapter.makeDepositToTechnicalAccount(
            technicalAccountId,
            depositPayload,
        );
        throwErrorIfAdapterResHaveError(depositResponse, {
            message: "Failed to make deposit transaction",
        });
    } else if (!!existingDeposit) {
        logger.info({
            message: "Technical account transaction already exists. Skipping.",
            existingDeposit,
        });
    }

    const ddSettings = response.data.directDebitSettings;

    // If a DD retry is in progress we need to check if this payment may cover the DD amount
    if (!isDDorDDRetry && ddSettings?.directDebitRetryInProgress) {
        logger.info({
            message: "DD retry pending. Checking if this payment may cover it.",
        });
        logger.debug({ message: "calling shouldCancelDDRetry", existingTransaction });
        const shouldCancel = await shouldCancelDDRetry({
            mandateId: ddSettings.mandateID,
            logger,
            repaymentAmount,
            currentTransaction: externalId,
            ddSettings,
            // if the transaction already exists it will show up in the search
            // and we should not add it after, it would be a duplicate
        });

        await handleDDRetryCancellation({
            shouldCancel,
            ddSettings,
            logger,
            coreBankingClient: coreBankingAdapter,
            accountId,
        });
    }

    if (isDDorDDRetry && !!ddSettings.scheduledDirectDebitAmount) {
        logger.info({
            message: "Removing scheduled amount from credit account",
        });
        const setScheduledAmount: UpdateCreditAccountOutcome =
            await coreBankingAdapter.setScheduledAmount(accountId, 0);
        throwErrorIfAdapterResHaveError(setScheduledAmount, {
            message: "Failed to remove scheduled amount",
        });
        logger.info({ message: "Scheduled amount removed" });
    }

    if (repaymentType === RepaymentType.DirectDebitRetry) {
        logger.info({
            message: "Removing dd retry fields from credit account",
        });
        const updateDDRetryFields: UpdateCreditAccountOutcome =
            await coreBankingAdapter.updateDDRetryFields(accountId, false, null, null, null);
        throwErrorIfAdapterResHaveError(updateDDRetryFields, {
            message: "Failed to update DD retry fields",
        });
        logger.info({
            message: "Removing dd retry fields from credit account",
        });
    }
    return formatJSONResponse(200, { message: "Repayment recorded successfully." });
};
