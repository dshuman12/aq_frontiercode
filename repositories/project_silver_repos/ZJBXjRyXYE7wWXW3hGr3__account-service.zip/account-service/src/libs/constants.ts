export const TEST_NUMBER = "+447776661234";
export const ACCOUNT_UPSERTED_EVENT_NAME = "AccountUpserted";
export const STATEMENT_DISBURSEMENT_TRANSACTION_CHANNEL_ID = "Statement_Disbursement";
export const CASH_CHANNEL_ID = "cash";
export const CORE_BANKING_WEBHOOK_EVENT_INITIATOR_NAME = "Mambu Webhook";
export const CREDIT_ACCOUNT_PRODUCT_KEY = "8a195c577be36893017be4085f860a03";
export const TECHNICAL_ACCOUNT_PRODUCT_KEY = "8a19518a784041660178408b2afd2100";
export const TEST_ACCOUNT_ID = "YCTE993";

export const DOCUMENT_BUCKET_NAME =
    process.env.STAGE === "prod" ? "onmo-transfer" : "onmo-transfer-staging";

export const TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY = "8a19b17a9136b8e3019145209d5d28f6";
export const TEST_CUSTOMER_UUID = "TEST-1723441655838";
export const TEST_TECHNICAL_ACCOUNT_ID = "KLIL272";
export const TEST_FEE_KEY = "8a195c577be36893017be40a3d150ecf";
export const SALESFORCE_TEST_CUSTOMER_UUID = "TEST-1742977395927";
export const SALESFORCE_TEST_CORE_BANKING_CUSTOMER_ENCODED_KEY = "8a19c87795d1165c0195d18b909454dc";
export const SALESFORCE_TEST_ACCOUNT_ID = "001KD000007hm0gYAA";

/** Account Payment plan */
export const PAYMENT_PLAN_TYPE_OPTIONS_TO_PLAN_NAME = {
    "Promise To Pay": "promiseToPay",
    "Payment Plan": "paymentPlan",
    "Payment Plan - With Fees": "paymentPlanWithFees",
    "DCA Payment Plan": "thirdPartyTokenPlan",
    "IVA Payment Plan": "thirdPartyTokenPlan",
    "DRO Payment Plan": "thirdPartyTokenPlan",
    "DMC Payment Plan": "thirdPartyTokenPlan",
};

export const PAYMENT_PLAN_STATUS_OPTIONS = ["Active", "Broken", "Expired"];

/** Account Flags (CRM Flags) */
export const ACCOUNT_FLAGS = [
    "VulnerableCustomer",
    "ParticularlyVulnerableCustomer",
    "ThirdPartyPlanArrears",
    "ThirdPartyPlanShortTermSupportPlan",
    "ThirdPartyPlanTokenPlan",
    "ArrearsPlan",
    "ConfirmedBankruptcy",
    "ConfirmedCountyCourtJudgement",
    "ConfirmedDebtReliefOrder",
    "ConfirmedIVA",
    "ConfirmedProtectedTrustDeeds",
    "DebtRespiteSchemeBreathingSpace",
    "DebtRespiteSchemeMentalHealthMoratorium",
    "Default",
    "InternalBreathingSpace",
    "PendingBankruptcy",
    "PendingCountyCourtJudgement",
    "PendingDebtReliefOrder",
    "PendingIVA",
    "PendingProtectedTrustDeeds",
    "PendingSequestration",
    "PromiseToPay",
    "RecoveriesFirstPlacementDCA",
    "RecoveriesSecondPlacementDCA",
    "RecoveriesThirdPartyPlan",
    "RecoveriesDebtSale",
    "RecoveriesInternalPlan",
    "ShortTermSupportPlan",
    "TokenPlan",
    "DCAArdent",
    "DCACOEO",
    "CourtProtectionOrder",
    "DisputesCaseOpen",
    "FailedIDandV",
    "FraudCaseOpen",
    "PEP",
    "Sanction",
    "ActiveComplaint",
    "ConfirmedDeceased",
    "CustomerAbroad",
    "DisputedDebt",
    "GoneAway",
    "PendingDeceased",
    "TechIssue",
    "IRI",
    "Confirmed1stParty",
    "Suspected1stParty",
    "Suspected3rdParty",
    "Confirmed3rdParty",
    "ConfirmedRCA",
    "SuspectedDesignatedPerson",
    "ConfirmedDesignatedPerson",
    "CifasFirstPartyMatch",
    "Inconsistent",
] as const;

/** Transaction Types */
export const TRANSACTION_TYPES = {
    INTEREST_APPLIED: "INTEREST_APPLIED",
    INTEREST_APPLIED_ADJUSTMENT: "INTEREST_APPLIED_ADJUSTMENT",
    FEE_APPLIED: "FEE_APPLIED",
    FEE_ADJUSTMENT: "FEE_ADJUSTMENT",
    DISBURSEMENT: "DISBURSEMENT",
    REPAYMENT: "REPAYMENT",
    DISBURSEMENT_ADJUSTMENT: "DISBURSEMENT_ADJUSTMENT",
    REPAYMENT_ADJUSTMENT: "REPAYMENT_ADJUSTMENT",
    INTEREST_RATE_CHANGED: "INTEREST_RATE_CHANGED",
    REPAYMENT_GO_CARDLESS: "REPAYMENT - GOCARDLESS",
    REPAYMENT_ACQUIRED: "REPAYMENT - ACQUIRED",
    REPAYMENT_STRIPE_CARD: "REPAYMENT - STRIPE_CARD",
    REPAYMENT_STRIPE_DD: "REPAYMENT - STRIPE_DD",
    REPAYMENT_PAY_BY_BANK: "REPAYMENT - PAY_BY_BANK",
} as const;

export type TRANSACTION_TYPES = (typeof TRANSACTION_TYPES)[keyof typeof TRANSACTION_TYPES];

/** Interest and Fess Freeze : Reasons */
export const REASONS = [
    "NoticeOfDefault",
    "Deceased",
    "TokenPlan",
    "SupportPlan",
    "IVA",
    "Bankruptcy",
    "DRO",
    "BreathingSpace",
];

/** Interest and Fess Freeze : Status */
export const INTEREST_FEES_FREEZE_STATUS = {
    INITIATED: "INITIATED",
    ACCRUED_INTEREST_COMPLETED: "ACCRUED_INTEREST_COMPLETED",
    ACCRUED_INTEREST_FAILED: "ACCRUED_INTEREST_FAILED",
    ADJUSTMENT_PROCESS_COMPLETED: "ADJUSTMENT_PROCESS_COMPLETED",
    ADJUSTMENT_PROCESS_FAILED: "ADJUSTMENT_PROCESS_FAILED",
    UPDATE_ZERO_INTEREST_COMPLETED: "UPDATE_ZERO_INTEREST_COMPLETED",
    UPDATE_ZERO_INTEREST_FAILED: "UPDATE_ZERO_INTEREST_FAILED",
    FAILED_TO_RECREATE_SOME_TRANSACTION: "FAILED_TO_RECREATE_SOME_TRANSACTION",
    RECREATED_ALL_TRANSACTION_COMPLETED: "RECREATED_ALL_TRANSACTION_COMPLETED",
    FROZEN: "FROZEN",
    UNFROZEN: "UNFROZEN",
    RE_PROCESSED: "RE_PROCESSED",
    RECOVERED: "RECOVERED",

    /** Rollback success statuses */
    ROLLBACK_STARTED: "ROLLBACK_STARTED",
    TRANSACTION_RECREATION_ROLLBACK_DONE: "TRANSACTION_RECREATION_ROLLBACK_DONE",
    UPDATE_ZERO_INTEREST_ROLLBACK_DONE: "UPDATE_ZERO_INTEREST_ROLLBACK_DONE",
    ADJUSTMENT_PROCESS_ROLLBACK_DONE: "ADJUSTMENT_PROCESS_ROLLBACK_DONE",
    ACCRUED_INTEREST_ROLLBACK_DONE: "ACCRUED_INTEREST_ROLLBACK_DONE",
    ROLLBACK_DONE: "ROLLBACK_DONE",
    /** Rollback failed statuses */
    TRANSACTION_RECREATION_ROLLBACK_FAILED: "TRANSACTION_RECREATION_ROLLBACK_FAILED",
    UPDATE_ZERO_INTEREST_ROLLBACK_FAILED: "UPDATE_ZERO_INTEREST_ROLLBACK_FAILED",
    ADJUSTMENT_PROCESS_ROLLBACK_FAILED: "ADJUSTMENT_PROCESS_ROLLBACK_FAILED",
    ACCRUED_INTEREST_ROLLBACK_FAILED: "ACCRUED_INTEREST_ROLLBACK_FAILED",
} as const;

export type INTEREST_FEES_FREEZE_STATUS =
    (typeof INTEREST_FEES_FREEZE_STATUS)[keyof typeof INTEREST_FEES_FREEZE_STATUS];

/** Interest and Fess Freeze : possible error status  */
export const FreezeProcessErrorStatuses: INTEREST_FEES_FREEZE_STATUS[] = [
    INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_FAILED,
    INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_FAILED,
    INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_FAILED,
    INTEREST_FEES_FREEZE_STATUS.FAILED_TO_RECREATE_SOME_TRANSACTION,
    INTEREST_FEES_FREEZE_STATUS.INITIATED, // very rare possibility
    INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_COMPLETED, // rare possibility
    INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_COMPLETED, // rare possibility
    INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_COMPLETED, // rare possibility
];

/** Interest and Fess Freeze : possible rollback error status  */
export const RollbackFreezeProcessErrorStatuses: INTEREST_FEES_FREEZE_STATUS[] = [
    INTEREST_FEES_FREEZE_STATUS.TRANSACTION_RECREATION_ROLLBACK_FAILED,
    INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_ROLLBACK_FAILED,
    INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_FAILED,
    INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_ROLLBACK_FAILED,
];

/** Interest and Fess Freeze : error status and process code mapping  */
export const FreezeProcessStatusAndProcessCodeMap = {
    [INTEREST_FEES_FREEZE_STATUS.INITIATED]: 1,
    [INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_FAILED]: 1,
    [INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_COMPLETED]: 2,
    [INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_FAILED]: 2,
    [INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_COMPLETED]: 3,
    [INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_FAILED]: 3,
    [INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_COMPLETED]: 4,
    [INTEREST_FEES_FREEZE_STATUS.FAILED_TO_RECREATE_SOME_TRANSACTION]: 4,

    // Rollback process status
    [INTEREST_FEES_FREEZE_STATUS.TRANSACTION_RECREATION_ROLLBACK_FAILED]: 4,
    [INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_ROLLBACK_FAILED]: 3.5,
    [INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_FAILED]: 3,
    [INTEREST_FEES_FREEZE_STATUS.ADJUSTMENT_PROCESS_ROLLBACK_FAILED]: 2,
    [INTEREST_FEES_FREEZE_STATUS.TRANSACTION_RECREATION_ROLLBACK_DONE]: 3.5, // rare possibility
    [INTEREST_FEES_FREEZE_STATUS.UPDATE_ZERO_INTEREST_ROLLBACK_DONE]: 3, // rare possibility
    [INTEREST_FEES_FREEZE_STATUS.ACCRUED_INTEREST_ROLLBACK_DONE]: 2, // rare possibility
};

export const MANDATE_SLEEP_TIME_IN_MILLISECONDS = 1000 * 60 * 2; // 2min - this is to reproduce prod like conditions when we don't get MandateUpserted immediately

export const WRITE_OFF_TYPE = {
    FULL: "FULL",
    PARTIAL: "PARTIAL",
} as const;

export type WRITE_OFF_TYPE = (typeof WRITE_OFF_TYPE)[keyof typeof WRITE_OFF_TYPE];

export const REPAYMENT_COLLECTED_ARCHIVED_BUCKET_FOLDER = `${process.env.ENVIRONMENT}-account-service-repaymentCollectedListener/onmo-business-events-stream-${process.env.ENVIRONMENT}`;
export const DD_RETRY_NAME_PREFIX = "dd-retry";
export const BACKDATE_TRANSACTION_INITIATED_BY = "repaymentCollected-excess-repayment-retry";
export const CLM_UPDATE_EVENT_INITIATED_BY = `dynamodb:${process.env.CLM_TABLE}`;

/** Feature Flags */
export const SMART_PAYMENTS_FLAG = "2026_03_16_mobile_smart_payments";
