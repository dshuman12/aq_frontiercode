import { defineConfig, type Options } from "tsdown";
import { glob } from "glob";

const folders = await glob("src/functions/*", { nodir: false });

const files = folders.map((folder) => {
    const folderName = folder.split("/").pop()!;
    return `${folder}/${folderName}.ts`;
});

const config: Options[] = files.map((file) => {
    const folder = file.split("/").pop()!.replace(".ts", "");
    return {
        entry: file,
        platform: "node",
        format: "esm",
        target: "es2022",
        noExternal: [/.*/],
        external: [/@aws-sdk\/*/, /getSecrets/],
        outDir: `build/${folder}`,
        outExtensions: () => ({
            js: ".mjs",
        }),
        // tsdown 0.15's top-level `define` is silently dropped by rolldown rc-15
        // (rolldown moved define under `transform`). Pass it via inputOptions instead.
        inputOptions: (opts) => ({
            ...opts,
            transform: {
                ...opts.transform,
                define: { __HANDLER_NAME__: JSON.stringify(folder) },
            },
        }),
        outputOptions: {
            inlineDynamicImports: true,
        },
    };
});

export default defineConfig(config);
