# Account Service Implementation

Contains implementation of the Account Service, which is part of the service layer.

## API Contract

For details on the API endpoints and their specifications, please refer to the [API contract documentation](https://onmo-swagger-ui-staging.s3.eu-west-1.amazonaws.com/openapi/openapi-onmo-account-service/index.html#/).

## Tech Stack

- **Terraform** for IAC, utilising these [custom terraform modules](https://github.com/onmoapp/terraform-aws-modules) as much as possible
- **Typescript** as the core language
- **Vitest** for API tests
- **Prettier** for linting
- **AWS** as the IAAS

## Setup local tests

In order to be able to run the test locally, you first need to extract the environment variables from the GitHub workflow file into your local .env.
This is done in the `generate-env-file`.
Make sure you installed the dotEnv CLI globally.

1. `npm install -g dotenv-cli` -> to do only once
2. `npm run test-local` -> this will make sure your .env file is up to date then feed it to `npm run test`
