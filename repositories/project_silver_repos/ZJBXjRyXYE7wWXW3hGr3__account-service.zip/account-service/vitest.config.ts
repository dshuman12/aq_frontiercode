import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
    define: { __HANDLER_NAME__: '"test-handler"' },
    plugins: [tsconfigPaths()],
    test: {
        setupFiles: ["./src/test-setup.ts"],
        testTimeout: 120_000,
        hookTimeout: 120_000,
        env: { SUPPRESS_LOGS: "true" },
    },
});
