package shard

import "testing"

func TestManager_ShardForKey(t *testing.T) {
	m := NewManager(16)
	id := m.ShardForKey("hello")
	if id < 0 || id >= 16 { t.Fatalf("shard out of range: %d", id) }
}

func TestManager_Consistency(t *testing.T) {
	m := NewManager(16)
	id1 := m.ShardForKey("key")
	id2 := m.ShardForKey("key")
	if id1 != id2 { t.Fatal("should be consistent") }
}

func TestManager_AssignAndOwner(t *testing.T) {
	m := NewManager(4)
	m.AssignNode(0, "node-a")
	m.AssignNode(1, "node-b")
	owner := m.OwnerForKey("test")
	_ = owner
}

func TestManager_Rebalance(t *testing.T) {
	m := NewManager(12)
	m.Rebalance([]string{"n1", "n2", "n3"})
	dist := m.Distribution()
	for _, count := range dist {
		if count != 4 { t.Fatalf("expected 4 shards each, got %v", dist) }
	}
}

func TestManager_Transfer(t *testing.T) {
	m := NewManager(4)
	m.Rebalance([]string{"n1", "n2"})
	err := m.TransferShard(0, "n1", "n3")
	if err != nil { t.Fatal(err) }
	s := m.GetShard(0)
	if s.Owner != "n3" { t.Fatal("should be n3") }
}

func TestManager_TransferWrongOwner(t *testing.T) {
	m := NewManager(4)
	m.Rebalance([]string{"n1"})
	err := m.TransferShard(0, "n2", "n3")
	if err == nil { t.Fatal("should fail for wrong owner") }
}

func TestManager_ShardCount(t *testing.T) {
	m := NewManager(32)
	if m.ShardCount() != 32 { t.Fatal("wrong count") }
}

func TestManager_ShardsForNode(t *testing.T) {
	m := NewManager(6)
	m.Rebalance([]string{"n1", "n2"})
	s := m.ShardsForNode("n1")
	if len(s) != 3 { t.Fatalf("expected 3, got %d", len(s)) }
}

func TestManager_NodeCount(t *testing.T) {
	m := NewManager(4)
	m.Rebalance([]string{"n1", "n2"})
	if m.NodeCount() != 2 { t.Fatal("expected 2") }
}

func TestManager_GetShard(t *testing.T) {
	m := NewManager(8)
	s := m.GetShard(0)
	if s == nil { t.Fatal("should return shard") }
	if s.ID != 0 { t.Fatal("wrong ID") }
}
