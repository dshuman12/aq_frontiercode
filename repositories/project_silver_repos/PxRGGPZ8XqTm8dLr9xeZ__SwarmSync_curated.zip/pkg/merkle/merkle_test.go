package merkle

import (
	"fmt"
	"testing"
)

func TestTree_Empty(t *testing.T) {
	tree := NewTree()
	if tree.Len() != 0 {
		t.Fatal("expected empty tree")
	}
	if tree.RootHash() != ([32]byte{}) {
		t.Fatal("empty tree should have zero root hash")
	}
}

func TestTree_PutGet(t *testing.T) {
	tree := NewTree()
	tree.Put("key1", []byte("value1"))
	v, ok := tree.Get("key1")
	if !ok || string(v) != "value1" {
		t.Fatal("expected (value1, true)")
	}
}

func TestTree_GetMissing(t *testing.T) {
	tree := NewTree()
	_, ok := tree.Get("missing")
	if ok {
		t.Fatal("expected false")
	}
}

func TestTree_PutUpdatesHash(t *testing.T) {
	tree := NewTree()
	tree.Put("k", []byte("v1"))
	h1 := tree.RootHash()
	tree.Put("k", []byte("v2"))
	h2 := tree.RootHash()
	if h1 == h2 {
		t.Fatal("hash should change on update")
	}
}

func TestTree_Delete(t *testing.T) {
	tree := NewTree()
	tree.Put("k", []byte("v"))
	tree.Delete("k")
	_, ok := tree.Get("k")
	if ok {
		t.Fatal("expected false after delete")
	}
	if tree.Len() != 0 {
		t.Fatal("expected empty after delete")
	}
}

func TestTree_Keys(t *testing.T) {
	tree := NewTree()
	tree.Put("c", []byte("3"))
	tree.Put("a", []byte("1"))
	tree.Put("b", []byte("2"))
	keys := tree.Keys()
	if len(keys) != 3 || keys[0] != "a" || keys[1] != "b" || keys[2] != "c" {
		t.Fatalf("expected sorted [a,b,c], got %v", keys)
	}
}

func TestTree_IdenticalTreesSameHash(t *testing.T) {
	a := NewTree()
	b := NewTree()
	for i := 0; i < 10; i++ {
		k := fmt.Sprintf("key-%d", i)
		v := []byte(fmt.Sprintf("val-%d", i))
		a.Put(k, v)
		b.Put(k, v)
	}
	if a.RootHash() != b.RootHash() {
		t.Fatal("identical trees should have same root hash")
	}
}

func TestTree_DifferentTreesDifferentHash(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k", []byte("v1"))
	b.Put("k", []byte("v2"))
	if a.RootHash() == b.RootHash() {
		t.Fatal("different trees should have different root hash")
	}
}

func TestTree_SingleElement(t *testing.T) {
	tree := NewTree()
	tree.Put("only", []byte("one"))
	if tree.Len() != 1 {
		t.Fatal("expected 1")
	}
	h := tree.RootHash()
	if h == ([32]byte{}) {
		t.Fatal("single element tree should not have zero hash")
	}
}

// --- Diff tests ---

func TestDiff_IdenticalTrees(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("v1"))
	b.Put("k1", []byte("v1"))
	d := Diff(a, b)
	if d.HasDifferences() {
		t.Fatal("identical trees should have no differences")
	}
}

func TestDiff_OnlyLocal(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("v1"))
	a.Put("k2", []byte("v2"))
	b.Put("k1", []byte("v1"))
	d := Diff(a, b)
	if len(d.OnlyLocal) != 1 || d.OnlyLocal[0] != "k2" {
		t.Fatalf("expected onlyLocal=[k2], got %v", d.OnlyLocal)
	}
}

func TestDiff_OnlyRemote(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("v1"))
	b.Put("k1", []byte("v1"))
	b.Put("k2", []byte("v2"))
	d := Diff(a, b)
	if len(d.OnlyRemote) != 1 || d.OnlyRemote[0] != "k2" {
		t.Fatalf("expected onlyRemote=[k2], got %v", d.OnlyRemote)
	}
}

func TestDiff_DifferentValues(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("old"))
	b.Put("k1", []byte("new"))
	d := Diff(a, b)
	if len(d.Different) != 1 || d.Different[0] != "k1" {
		t.Fatalf("expected different=[k1], got %v", d.Different)
	}
}

func TestDiff_BothEmpty(t *testing.T) {
	d := Diff(NewTree(), NewTree())
	if d.HasDifferences() {
		t.Fatal("two empty trees should match")
	}
}

func TestDiff_TotalDiffs(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("v1"))
	a.Put("k2", []byte("v2"))
	b.Put("k2", []byte("v2-changed"))
	b.Put("k3", []byte("v3"))
	d := Diff(a, b)
	if d.TotalDiffs() != 3 { // k1 onlyLocal, k2 different, k3 onlyRemote
		t.Fatalf("expected 3 total diffs, got %d", d.TotalDiffs())
	}
}

// --- FastDiff tests ---

func TestFastDiff_IdenticalTrees(t *testing.T) {
	a := NewTree()
	b := NewTree()
	for i := 0; i < 20; i++ {
		k := fmt.Sprintf("key-%02d", i)
		v := []byte(fmt.Sprintf("val-%d", i))
		a.Put(k, v)
		b.Put(k, v)
	}
	d := FastDiff(a, b)
	if d.HasDifferences() {
		t.Fatal("identical trees should have no differences with FastDiff")
	}
}

func TestFastDiff_FewDiffs(t *testing.T) {
	a := NewTree()
	b := NewTree()
	for i := 0; i < 100; i++ {
		k := fmt.Sprintf("key-%03d", i)
		v := []byte(fmt.Sprintf("val-%d", i))
		a.Put(k, v)
		b.Put(k, v)
	}
	// Change 3 values in b
	b.Put("key-010", []byte("changed-10"))
	b.Put("key-050", []byte("changed-50"))
	b.Put("key-090", []byte("changed-90"))

	d := FastDiff(a, b)
	if len(d.Different) != 3 {
		t.Fatalf("expected 3 different, got %d", len(d.Different))
	}
}

func TestFastDiff_MatchesDiff(t *testing.T) {
	a := NewTree()
	b := NewTree()
	a.Put("k1", []byte("v1"))
	a.Put("k2", []byte("v2"))
	a.Put("k3", []byte("v3-local"))
	b.Put("k2", []byte("v2"))
	b.Put("k3", []byte("v3-remote"))
	b.Put("k4", []byte("v4"))

	d1 := Diff(a, b)
	d2 := FastDiff(a, b)

	if d1.TotalDiffs() != d2.TotalDiffs() {
		t.Fatalf("Diff=%d vs FastDiff=%d", d1.TotalDiffs(), d2.TotalDiffs())
	}
}

// --- Serialization tests ---

func TestSerializeRootHash_Roundtrip(t *testing.T) {
	tree := NewTree()
	tree.Put("k", []byte("v"))
	h := tree.RootHash()
	data := SerializeRootHash(h)
	parsed, err := DeserializeRootHash(data)
	if err != nil {
		t.Fatalf("deserialize error: %v", err)
	}
	if parsed != h {
		t.Fatal("roundtrip mismatch")
	}
}

func TestDeserializeRootHash_ShortData(t *testing.T) {
	_, err := DeserializeRootHash([]byte{1, 2, 3})
	if err == nil {
		t.Fatal("expected error for short data")
	}
}

func TestSerializeDiffResult(t *testing.T) {
	d := DiffResult{
		OnlyLocal:  []string{"a", "b"},
		OnlyRemote: []string{"c"},
		Different:  []string{"d", "e", "f"},
	}
	data := SerializeDiffResult(d)
	if len(data) == 0 {
		t.Fatal("serialization should produce non-empty output")
	}
}

// --- Proof tests ---

func TestProof_SingleElement(t *testing.T) {
	tree := NewTree()
	tree.Put("key", []byte("value"))
	rootHash := tree.RootHash()

	proof := &Proof{
		Key:      "key",
		Value:    []byte("value"),
		Siblings: nil,
		Sides:    nil,
	}
	if !proof.Verify(rootHash) {
		t.Fatal("single element proof should verify")
	}
}

func TestProof_WrongValue(t *testing.T) {
	tree := NewTree()
	tree.Put("key", []byte("value"))
	rootHash := tree.RootHash()

	proof := &Proof{
		Key:      "key",
		Value:    []byte("wrong"),
		Siblings: nil,
		Sides:    nil,
	}
	if proof.Verify(rootHash) {
		t.Fatal("wrong value should not verify")
	}
}

// --- Lazy rebuild tests ---

func TestTree_LazyRebuild_MultiPut(t *testing.T) {
	tree := NewTree()
	for i := 0; i < 100; i++ {
		tree.Put(fmt.Sprintf("key-%03d", i), []byte(fmt.Sprintf("val-%d", i)))
	}
	if tree.Len() != 100 {
		t.Fatalf("expected 100, got %d", tree.Len())
	}
	h := tree.RootHash()
	if h == ([32]byte{}) {
		t.Fatal("should have non-zero root hash after puts")
	}
}

func TestTree_LazyRebuild_ConsistentWithEager(t *testing.T) {
	lazy := NewTree()
	eager := NewTree()
	entries := map[string][]byte{
		"alpha": []byte("1"),
		"beta":  []byte("2"),
		"gamma": []byte("3"),
		"delta": []byte("4"),
	}
	for k, v := range entries {
		lazy.Put(k, v)
	}
	eager.PutBatch(entries)

	if lazy.RootHash() != eager.RootHash() {
		t.Fatal("lazy and eager rebuild should produce identical root hashes")
	}
}

func TestTree_LazyRebuild_DeleteThenRead(t *testing.T) {
	tree := NewTree()
	tree.Put("a", []byte("1"))
	tree.Put("b", []byte("2"))
	tree.Put("c", []byte("3"))
	h1 := tree.RootHash()

	tree.Delete("b")
	h2 := tree.RootHash()
	if h1 == h2 {
		t.Fatal("hash should change after delete")
	}
	if tree.Len() != 2 {
		t.Fatalf("expected 2 after delete, got %d", tree.Len())
	}
}

// --- PutBatch tests ---

func TestTree_PutBatch_Empty(t *testing.T) {
	tree := NewTree()
	tree.PutBatch(map[string][]byte{})
	if tree.Len() != 0 {
		t.Fatal("expected empty tree after empty batch")
	}
}

func TestTree_PutBatch_MatchesSequentialPuts(t *testing.T) {
	sequential := NewTree()
	batch := NewTree()
	for i := 0; i < 50; i++ {
		k := fmt.Sprintf("key-%02d", i)
		v := []byte(fmt.Sprintf("val-%d", i))
		sequential.Put(k, v)
	}
	entries := make(map[string][]byte, 50)
	for i := 0; i < 50; i++ {
		k := fmt.Sprintf("key-%02d", i)
		entries[k] = []byte(fmt.Sprintf("val-%d", i))
	}
	batch.PutBatch(entries)

	if sequential.RootHash() != batch.RootHash() {
		t.Fatal("PutBatch should produce same tree as sequential Puts")
	}
	if sequential.Len() != batch.Len() {
		t.Fatal("length mismatch")
	}
}

func TestTree_PutBatch_Overwrite(t *testing.T) {
	tree := NewTree()
	tree.Put("k", []byte("old"))
	tree.PutBatch(map[string][]byte{"k": []byte("new")})
	v, ok := tree.Get("k")
	if !ok || string(v) != "new" {
		t.Fatal("PutBatch should overwrite existing keys")
	}
}

func TestDiff_AfterLazyRebuild(t *testing.T) {
	a := NewTree()
	b := NewTree()
	for i := 0; i < 20; i++ {
		k := fmt.Sprintf("key-%02d", i)
		a.Put(k, []byte("v"))
		b.Put(k, []byte("v"))
	}
	a.Put("extra-a", []byte("x"))
	b.Put("extra-b", []byte("y"))

	d := Diff(a, b)
	if len(d.OnlyLocal) != 1 || d.OnlyLocal[0] != "extra-a" {
		t.Fatalf("expected onlyLocal=[extra-a], got %v", d.OnlyLocal)
	}
	if len(d.OnlyRemote) != 1 || d.OnlyRemote[0] != "extra-b" {
		t.Fatalf("expected onlyRemote=[extra-b], got %v", d.OnlyRemote)
	}
}

func TestFastDiff_AfterLazyRebuild(t *testing.T) {
	a := NewTree()
	b := NewTree()
	entries := make(map[string][]byte, 50)
	for i := 0; i < 50; i++ {
		k := fmt.Sprintf("key-%02d", i)
		entries[k] = []byte("v")
	}
	a.PutBatch(entries)
	b.PutBatch(entries)

	b.Put("key-10", []byte("changed"))
	d := FastDiff(a, b)
	if len(d.Different) != 1 || d.Different[0] != "key-10" {
		t.Fatalf("expected different=[key-10], got %v", d.Different)
	}
}
// --- Proof generation tests ---

func TestTree_GenerateProof(t *testing.T) {
	tree := NewTree()
	tree.Put("a", []byte("1"))
	tree.Put("b", []byte("2"))
	tree.Put("c", []byte("3"))
	rootHash := tree.RootHash()

	proof := tree.GenerateProof("b")
	if proof == nil { t.Fatal("should generate proof for existing key") }
	if !proof.Verify(rootHash) { t.Fatal("proof should verify against root hash") }
}

func TestTree_GenerateProof_Missing(t *testing.T) {
	tree := NewTree()
	tree.Put("a", []byte("1"))
	proof := tree.GenerateProof("missing")
	if proof != nil { t.Fatal("should return nil for missing key") }
}

func TestTree_GenerateProof_AllKeys(t *testing.T) {
	tree := NewTree()
	for i := 0; i < 16; i++ {
		tree.Put(fmt.Sprintf("key-%02d", i), []byte(fmt.Sprintf("val-%d", i)))
	}
	rootHash := tree.RootHash()
	for i := 0; i < 16; i++ {
		key := fmt.Sprintf("key-%02d", i)
		proof := tree.GenerateProof(key)
		if proof == nil { t.Fatalf("no proof for %s", key) }
		if !proof.Verify(rootHash) { t.Fatalf("proof failed for %s", key) }
	}
}

func TestBatchVerify(t *testing.T) {
	tree := NewTree()
	tree.Put("x", []byte("1"))
	tree.Put("y", []byte("2"))
	rootHash := tree.RootHash()
	p1 := tree.GenerateProof("x")
	p2 := tree.GenerateProof("y")
	invalid := BatchVerify([]*Proof{p1, p2}, rootHash)
	if len(invalid) != 0 { t.Fatalf("expected no invalid, got %v", invalid) }
}

func TestVerifyProof_Nil(t *testing.T) {
	if VerifyProof(nil, [32]byte{}) { t.Fatal("nil proof should not verify") }
}

func TestProofSize(t *testing.T) {
	tree := NewTree()
	tree.Put("key", []byte("value"))
	proof := tree.GenerateProof("key")
	size := ProofSize(proof)
	if size < 3+5 { t.Fatalf("proof size too small: %d", size) }
}

func TestHashLeaf(t *testing.T) {
	h := HashLeaf("key", []byte("value"))
	if h == ([32]byte{}) { t.Fatal("hash should not be zero") }
}
