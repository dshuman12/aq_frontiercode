"""Tests for solver attribute setup."""
from logistics_planner.solvers.simplex import Simplex
from logistics_planner.solvers.dual_simplex import DualSimplex
from logistics_planner.solvers.big_m_simplex import BigMSimplex


def test_simplex_dimensions():
    s = Simplex([1, 2], [[1, 1]], [3])
    assert s.m == 1
    assert s.n == 2


def test_dual_simplex_dimensions():
    ds = DualSimplex([1, 2, 0], [[1, 1, 1]], [5])
    assert ds.m == 1
    assert ds.n == 3


def test_big_m_default_M():
    bm = BigMSimplex([1, 1], [[1, 1]], [2])
    assert bm.M > 0


def test_big_m_custom_M():
    bm = BigMSimplex([1, 1], [[1, 1]], [2], M=999)
    assert bm.M == 999
