from logistics_planner.solvers.lp_solver import make_binary_vars


def test_returns_list():
    out = make_binary_vars("y", 3)
    assert len(out) == 3


def test_zero_count():
    assert make_binary_vars("y", 0) == []


def test_variable_names():
    out = make_binary_vars("z", 2)
    names = [v.name for v in out]
    assert names == ["z1", "z2"]
