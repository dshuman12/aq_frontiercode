import numpy as np
import pytest

from logistics_planner.problems.transportation_problem import TransportationProblem
from logistics_planner.benchmark import random_transportation_instance


@pytest.mark.parametrize("seed", [10, 20, 30, 40, 50])
def test_transportation_random_balanced(seed):
    s, d, c = random_transportation_instance(3, 4, seed=seed)
    sol = TransportationProblem(s, d, c).solve()
    assert sol.status == "Optimal"


@pytest.mark.parametrize("m,n", [(2, 2), (2, 3), (3, 2), (3, 4), (4, 3)])
def test_transportation_various_sizes(m, n):
    s, d, c = random_transportation_instance(m, n, seed=42)
    sol = TransportationProblem(s, d, c).solve()
    assert sol.shipments.shape == (m, n)


def test_transportation_balanced_supply_equals_demand():
    s, d, c = random_transportation_instance(4, 5, seed=100)
    sol = TransportationProblem(s, d, c).solve()
    np.testing.assert_array_almost_equal(sol.shipments.sum(axis=1), s)


def test_transportation_total_cost_nonneg_for_nonneg_costs():
    s = [10, 10]
    d = [10, 10]
    c = [[2, 3], [4, 1]]
    sol = TransportationProblem(s, d, c).solve()
    assert sol.total_cost >= 0


def test_transportation_zero_demand_returns_zero_cost():
    s = [10, 10]
    d = [0, 0]
    c = [[1, 2], [3, 4]]
    sol = TransportationProblem(s, d, c).solve()
    if sol.status == "Optimal":
        np.testing.assert_array_almost_equal(sol.shipments.sum(axis=0), [0, 0])


def test_transportation_diagonal_costs():
    # cheaper diagonal should be selected
    s = [10, 10]
    d = [10, 10]
    c = [[1, 100], [100, 1]]
    sol = TransportationProblem(s, d, c).solve()
    if sol.status == "Optimal":
        # diagonal heavy
        assert sol.shipments[0, 0] >= 5
        assert sol.shipments[1, 1] >= 5


def test_transportation_large_supply_node():
    s = [100, 5]
    d = [50, 50, 5]
    c = [[1, 2, 3], [4, 5, 6]]
    sol = TransportationProblem(s, d, c).solve()
    assert sol.status == "Optimal"


def test_transportation_attributes_stored():
    p = TransportationProblem([10, 20], [15, 15], [[1, 2], [3, 4]])
    assert p.m == 2
    assert p.n == 2
