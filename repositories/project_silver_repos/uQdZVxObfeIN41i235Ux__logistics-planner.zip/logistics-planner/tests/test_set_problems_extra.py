import pytest
import numpy as np

from logistics_planner.problems.set_covering_problem import SetCoveringProblem
from logistics_planner.problems.set_partitioning_problem import SetPartitioningProblem
from logistics_planner.benchmark import random_set_covering_instance


@pytest.mark.parametrize("seed", [1, 2, 3, 4])
def test_set_covering_random_seeds(seed):
    costs, cov = random_set_covering_instance(5, 8, seed=seed)
    sol = SetCoveringProblem(costs, cov).solve()
    assert sol.status in ("Optimal", "Infeasible")


@pytest.mark.parametrize("n_elements,n_sets", [(3, 5), (5, 5), (5, 8), (8, 10)])
def test_set_covering_various_sizes(n_elements, n_sets):
    costs, cov = random_set_covering_instance(n_elements, n_sets, seed=42)
    sol = SetCoveringProblem(costs, cov).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_set_covering_attributes():
    p = SetCoveringProblem(costs=[1, 2], coverage_matrix=[[1, 0], [0, 1]])
    assert p.m == 2
    assert p.n == 2


def test_set_covering_one_set_covers_all():
    sol = SetCoveringProblem(
        costs=[10, 1],
        coverage_matrix=[[0, 1], [0, 1], [0, 1]],
    ).solve()
    if sol.status == "Optimal":
        assert 1 in sol.selected_sets


def test_set_covering_greedy_returns_sorted():
    sol = SetCoveringProblem(
        costs=[1, 1, 1],
        coverage_matrix=[[1, 0, 1], [1, 1, 0], [0, 1, 1]],
    ).greedy()
    assert sol.selected_sets == sorted(sol.selected_sets)


def test_set_partitioning_attributes():
    p = SetPartitioningProblem(costs=[1, 2], coverage_matrix=[[1, 0], [0, 1]])
    assert p.m == 2
    assert p.n == 2


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_set_partitioning_random(seed):
    rng = np.random.default_rng(seed)
    n_elem = 4
    n_sets = 6
    cov = rng.integers(0, 2, size=(n_elem, n_sets))
    costs = rng.integers(1, 10, size=n_sets).tolist()
    sol = SetPartitioningProblem(costs, cov.tolist()).solve()
    assert sol.status in ("Optimal", "Infeasible", "Unbounded")
