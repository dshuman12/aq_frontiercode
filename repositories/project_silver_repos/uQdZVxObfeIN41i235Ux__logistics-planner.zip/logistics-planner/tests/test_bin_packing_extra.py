import pytest

from logistics_planner.problems.bin_packing_problem import BinPackingProblem


@pytest.mark.parametrize("n_items", [3, 5, 8, 10])
def test_bin_packing_various_sizes(n_items):
    sizes = [3] * n_items
    sol = BinPackingProblem(sizes, bin_capacity=10).solve_first_fit_decreasing()
    assert all(0 <= k for _, k in sol.assignment)


def test_bin_packing_ffd_perfect_pack():
    # 4 items of size 5 in bins of capacity 10 -> exactly 2 bins
    sol = BinPackingProblem([5, 5, 5, 5], bin_capacity=10).solve_first_fit_decreasing()
    assert sol.bins_used == 2


def test_bin_packing_ffd_one_bin_per_item():
    # items as big as bin
    sol = BinPackingProblem([10, 10, 10], bin_capacity=10).solve_first_fit_decreasing()
    assert sol.bins_used == 3


def test_bin_packing_ffd_assignment_completeness():
    sizes = [3, 5, 2, 1, 4, 6, 2]
    sol = BinPackingProblem(sizes, bin_capacity=10).solve_first_fit_decreasing()
    items = {i for i, _ in sol.assignment}
    assert items == set(range(len(sizes)))


def test_bin_packing_ffd_capacity_per_bin():
    sizes = [4, 4, 4, 5, 5, 6]
    cap = 10
    sol = BinPackingProblem(sizes, bin_capacity=cap).solve_first_fit_decreasing()
    bins = {}
    for i, b in sol.assignment:
        bins.setdefault(b, []).append(sizes[i])
    for items in bins.values():
        assert sum(items) <= cap


def test_bin_packing_n_attribute():
    p = BinPackingProblem([1, 2, 3], bin_capacity=10)
    assert p.n == 3


def test_bin_packing_capacity_stored():
    p = BinPackingProblem([1, 2], bin_capacity=15.5)
    assert p.bin_capacity == 15.5


def test_bin_packing_max_bins_default():
    p = BinPackingProblem([1, 2, 3, 4], bin_capacity=10)
    assert p.max_bins == 4


def test_bin_packing_oversize_raises():
    with pytest.raises(ValueError):
        BinPackingProblem([5, 15], bin_capacity=10)
