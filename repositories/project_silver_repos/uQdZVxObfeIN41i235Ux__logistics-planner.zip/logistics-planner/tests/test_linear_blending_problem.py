import pytest

from logistics_planner.problems.linear_blending_problem import (
    LinearBlending,
    BlendSolution,
)


def test_solve_runs():
    sol = LinearBlending(
        materials=["A", "B"],
        costs=[10, 15],
        property_matrix=[[6, 10]],
        lower_bounds=[6],
        upper_bounds=[10],
        output_quantity=1,
    ).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_returns_solution_object():
    sol = LinearBlending(
        materials=["x", "y"],
        costs=[1, 1],
        property_matrix=[[1, 1]],
        lower_bounds=[0.5],
        upper_bounds=[1.0],
        output_quantity=1,
    ).solve()
    assert isinstance(sol, BlendSolution)


def test_total_output_constraint_for_unit_quantity():
    sol = LinearBlending(
        materials=["x", "y"],
        costs=[1, 1],
        property_matrix=[[1, 1]],
        lower_bounds=[0.5],
        upper_bounds=[1.0],
        output_quantity=1,
    ).solve()
    if sol.status == "Optimal":
        assert sum(sol.proportions) == pytest.approx(1.0)


def test_dimension_mismatch_raises():
    with pytest.raises(ValueError):
        LinearBlending(
            materials=["a", "b", "c"],
            costs=[1, 2, 3],
            property_matrix=[[1, 2]],
            lower_bounds=[0],
            upper_bounds=[10],
            output_quantity=50,
        )


def test_no_negative_proportions():
    sol = LinearBlending(
        materials=["a", "b"],
        costs=[1, 2],
        property_matrix=[[1, 2]],
        lower_bounds=[0.5],
        upper_bounds=[2],
        output_quantity=1,
    ).solve()
    if sol.status == "Optimal":
        for p in sol.proportions:
            assert p >= -1e-9


def test_attributes_stored():
    p = LinearBlending(
        materials=["x", "y", "z"],
        costs=[1, 2, 3],
        property_matrix=[[1, 2, 3], [4, 5, 6]],
        lower_bounds=[0, 0],
        upper_bounds=[10, 10],
        output_quantity=5,
    )
    assert p.m == 3
    assert p.k == 2
    assert p.output_quantity == 5
