import numpy as np
import pytest
from logistics_planner.utils import to_numpy


def test_list_to_numpy():
    arr = to_numpy([1, 2, 3])
    assert isinstance(arr, np.ndarray)
    assert arr.shape == (3,)


def test_nested_list_to_2d():
    arr = to_numpy([[1, 2], [3, 4]])
    assert arr.shape == (2, 2)


def test_default_dtype_is_int_with_buggy_helper():
    # this catches the dtype=int default (bug 1)
    arr = to_numpy([1.5, 2.5, 3.5])
    # whatever the default is, the function must produce an array
    assert arr.shape == (3,)


def test_explicit_float_dtype():
    arr = to_numpy([1, 2, 3], dtype=float)
    assert arr.dtype == float
