import pytest

from logistics_planner.benchmark import (
    random_tsp_instance, random_assignment_instance, random_knapsack_instance,
    random_facility_location_instance, random_transportation_instance,
)


@pytest.mark.parametrize("n", [3, 5, 8, 10])
def test_tsp_seed_reproducibility(n):
    c1, D1 = random_tsp_instance(n, seed=42)
    c2, D2 = random_tsp_instance(n, seed=42)
    assert (c1 == c2).all()
    assert (D1 == D2).all()


@pytest.mark.parametrize("n", [2, 4, 6])
def test_assignment_seed_reproducibility(n):
    M1 = random_assignment_instance(n, seed=42)
    M2 = random_assignment_instance(n, seed=42)
    assert (M1 == M2).all()


def test_different_seeds_yield_different_instances():
    M1 = random_assignment_instance(5, seed=1)
    M2 = random_assignment_instance(5, seed=2)
    assert not (M1 == M2).all()


@pytest.mark.parametrize("n", [3, 5])
def test_knapsack_seed_reproducible(n):
    a = random_knapsack_instance(n, seed=99)
    b = random_knapsack_instance(n, seed=99)
    assert a == b
