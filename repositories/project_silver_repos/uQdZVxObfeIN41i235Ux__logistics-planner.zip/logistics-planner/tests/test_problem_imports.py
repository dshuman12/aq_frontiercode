"""Sanity test - all problem classes can be imported and instantiated."""
import pytest


def test_facility_class_exists():
    from logistics_planner.problems.capacitated_facility_location import (
        CapacitatedFacilityLocation, CFLPSolution,
    )
    assert CapacitatedFacilityLocation is not None
    assert CFLPSolution is not None


def test_transportation_class_exists():
    from logistics_planner.problems.transportation_problem import (
        TransportationProblem, TransportSolution,
    )
    assert TransportationProblem is not None


def test_lot_sizing_class_exists():
    from logistics_planner.problems.capacitated_lot_sizing_problem import (
        CapacitatedLotSizing, LotSizingSolution,
    )
    assert CapacitatedLotSizing is not None


def test_blending_class_exists():
    from logistics_planner.problems.linear_blending_problem import (
        LinearBlending, BlendSolution,
    )
    assert LinearBlending is not None


def test_diet_class_exists():
    from logistics_planner.problems.stiglers_diet_problem import (
        StiglersDiet, DietSolution,
    )
    assert StiglersDiet is not None


def test_tsp_class_exists():
    from logistics_planner.problems.traveling_salesman_problem import (
        TravelingSalesman, TourSolution,
    )
    assert TravelingSalesman is not None


def test_assignment_class_exists():
    from logistics_planner.problems.assignment_problem import (
        AssignmentProblem, AssignmentSolution,
    )
    assert AssignmentProblem is not None


def test_knapsack_class_exists():
    from logistics_planner.problems.zero_one_knapsack import (
        ZeroOneKnapsack, KnapsackSolution,
    )
    assert ZeroOneKnapsack is not None


def test_set_covering_exists():
    from logistics_planner.problems.set_covering_problem import (
        SetCoveringProblem, SetCoveringSolution,
    )
    assert SetCoveringProblem is not None


def test_vrp_exists():
    from logistics_planner.problems.vehicle_routing_problem import VehicleRoutingProblem
    assert VehicleRoutingProblem is not None


def test_job_shop_exists():
    from logistics_planner.problems.job_shop_scheduling import JobShopScheduling
    assert JobShopScheduling is not None


def test_qap_exists():
    from logistics_planner.problems.quadratic_assignment_problem import (
        QuadraticAssignmentProblem,
    )
    assert QuadraticAssignmentProblem is not None
