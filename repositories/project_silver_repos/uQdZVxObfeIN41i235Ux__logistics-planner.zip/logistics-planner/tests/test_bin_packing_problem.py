import pytest

from logistics_planner.problems.bin_packing_problem import (
    BinPackingProblem,
    BinPackingSolution,
)


def test_solve_basic():
    sol = BinPackingProblem(item_sizes=[3, 5, 2, 1, 4], bin_capacity=8).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    sol = BinPackingProblem(item_sizes=[1, 1], bin_capacity=2).solve()
    assert isinstance(sol, BinPackingSolution)


def test_item_too_large_raises():
    with pytest.raises(ValueError):
        BinPackingProblem(item_sizes=[10, 5], bin_capacity=8)


def test_ffd_packs_all_items():
    sizes = [3, 5, 2, 1, 4, 6]
    sol = BinPackingProblem(item_sizes=sizes, bin_capacity=10).solve_first_fit_decreasing()
    packed_items = {i for i, _ in sol.assignment}
    assert packed_items == set(range(len(sizes)))


def test_ffd_respects_capacity():
    sizes = [3, 5, 2, 1, 4]
    cap = 8
    sol = BinPackingProblem(item_sizes=sizes, bin_capacity=cap).solve_first_fit_decreasing()

    # group items by bin and check totals
    bins_to_items = {}
    for i, k in sol.assignment:
        bins_to_items.setdefault(k, []).append(i)
    for k, items in bins_to_items.items():
        total = sum(sizes[i] for i in items)
        assert total <= cap + 1e-9
