import pytest
import numpy as np

from logistics_planner.problems.stiglers_diet_problem import StiglersDiet


@pytest.mark.parametrize("n_foods", [1, 2, 3, 5])
def test_diet_various_food_counts(n_foods):
    foods = [f"food_{i}" for i in range(n_foods)]
    costs = [1.0] * n_foods
    nutrients = [[1.0] * n_foods]
    sol = StiglersDiet(foods, costs, nutrients, [1.0]).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


@pytest.mark.parametrize("n_nutrients", [1, 2, 3, 5])
def test_diet_various_nutrient_counts(n_nutrients):
    foods = ["a", "b"]
    costs = [1.0, 2.0]
    nutrients = [[1.0, 1.0]] * n_nutrients
    requirements = [1.0] * n_nutrients
    sol = StiglersDiet(foods, costs, nutrients, requirements).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_diet_quantities_dict_size_matches_foods():
    sol = StiglersDiet(
        foods=["a", "b", "c"],
        costs=[1, 2, 3],
        nutrient_matrix=[[1, 1, 1]],
        requirements=[5],
    ).solve()
    if sol.status == "Optimal":
        assert len(sol.quantities) == 3


def test_diet_attributes_stored():
    p = StiglersDiet(
        foods=["a", "b"],
        costs=[1, 2],
        nutrient_matrix=[[1, 2]],
        requirements=[5],
    )
    assert p.n_foods == 2
    assert p.n_nutrients == 1


def test_diet_costs_stored_as_array():
    p = StiglersDiet(
        foods=["a"],
        costs=[10],
        nutrient_matrix=[[1]],
        requirements=[1],
    )
    assert isinstance(p.costs, np.ndarray)


def test_diet_food_list_stored():
    p = StiglersDiet(
        foods=["bread", "milk"],
        costs=[1, 2],
        nutrient_matrix=[[1, 1]],
        requirements=[1],
    )
    assert p.foods == ["bread", "milk"]


def test_diet_zero_requirements():
    sol = StiglersDiet(
        foods=["a", "b"],
        costs=[1, 2],
        nutrient_matrix=[[1, 1]],
        requirements=[0],
    ).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_diet_dimension_mismatch_too_few_columns():
    with pytest.raises(ValueError):
        StiglersDiet(
            foods=["a", "b"],
            costs=[1, 2],
            nutrient_matrix=[[1]],  # 1 col but 2 foods
            requirements=[1],
        )
