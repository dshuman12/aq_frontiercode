import numpy as np
import pytest

from logistics_planner.problems.quadratic_assignment_problem import (
    QuadraticAssignmentProblem,
    QAPSolution,
)


def test_local_search_runs():
    flow = np.array([[0, 5, 2], [5, 0, 3], [2, 3, 0]])
    dist = np.array([[0, 1, 4], [1, 0, 2], [4, 2, 0]])
    sol = QuadraticAssignmentProblem(flow, dist).solve_local_search(seed=42)
    assert isinstance(sol, QAPSolution)
    assert len(sol.permutation) == 3


def test_evaluate_permutation():
    flow = [[0, 1], [1, 0]]
    dist = [[0, 5], [5, 0]]
    qap = QuadraticAssignmentProblem(flow, dist)
    cost = qap.evaluate([0, 1])
    assert cost == pytest.approx(10.0)  # f01 * d_perm0_perm1 + f10 * d_perm1_perm0 = 1*5 + 1*5


def test_shape_validation():
    with pytest.raises(ValueError):
        QuadraticAssignmentProblem([[1, 2], [3, 4]], [[1, 2, 3], [4, 5, 6]])


def test_non_square_raises():
    with pytest.raises(ValueError):
        QuadraticAssignmentProblem([[1, 2, 3], [4, 5, 6]],
                                   [[1, 2, 3], [4, 5, 6]])
