import pytest

from logistics_planner.problems.set_covering_problem import (
    SetCoveringProblem,
    SetCoveringSolution,
)


def test_basic_covering():
    coverage = [[1, 0, 1, 0],
                [0, 1, 1, 0],
                [1, 0, 0, 1],
                [0, 1, 0, 1]]
    sol = SetCoveringProblem(costs=[1, 1, 1, 1], coverage_matrix=coverage).solve()
    assert sol.status == "Optimal"
    assert len(sol.selected_sets) >= 1


def test_returns_solution_object():
    sol = SetCoveringProblem(costs=[1], coverage_matrix=[[1]]).solve()
    assert isinstance(sol, SetCoveringSolution)


def test_costs_length_validation():
    with pytest.raises(ValueError):
        SetCoveringProblem(costs=[1, 2], coverage_matrix=[[1, 0, 0], [0, 1, 0]])


def test_greedy_returns_solution():
    coverage = [[1, 0, 1], [1, 1, 0], [0, 1, 1]]
    sol = SetCoveringProblem(costs=[1, 1, 1], coverage_matrix=coverage).greedy()
    assert sol.status in ("Heuristic", "Infeasible")
