from logistics_planner.problems.capacitated_lot_sizing_problem import (
    CapacitatedLotSizing,
    LotSizingSolution,
)


def test_solve_returns_status():
    sol = CapacitatedLotSizing(
        demand=[20, 30, 25],
        setup_costs=[100, 100, 100],
        holding_costs=[1, 1, 1],
        production_costs=[5, 5, 5],
        capacity=200,
    ).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_returns_solution_object():
    sol = CapacitatedLotSizing(
        demand=[10, 10],
        setup_costs=[50, 50],
        holding_costs=[1, 1],
        production_costs=[1, 1],
        capacity=100,
    ).solve()
    assert isinstance(sol, LotSizingSolution)


def test_capacity_constraint_holds_when_optimal():
    sol = CapacitatedLotSizing(
        demand=[5, 5, 5],
        setup_costs=[10, 10, 10],
        holding_costs=[1, 1, 1],
        production_costs=[2, 2, 2],
        capacity=100,
    ).solve(initial_inventory=200)
    if sol.status == "Optimal":
        for x in sol.production:
            assert x <= 100 + 1e-6


def test_setup_only_when_producing():
    sol = CapacitatedLotSizing(
        demand=[0, 30, 0],
        setup_costs=[200, 200, 200],
        holding_costs=[1, 1, 1],
        production_costs=[5, 5, 5],
        capacity=100,
    ).solve()
    if sol.status == "Optimal":
        for t in range(3):
            if sol.production[t] > 1e-6:
                assert sol.setup[t] is True


def test_per_period_capacity_array():
    sol = CapacitatedLotSizing(
        demand=[5, 5, 5],
        setup_costs=[10, 10, 10],
        holding_costs=[1, 1, 1],
        production_costs=[2, 2, 2],
        capacity=[20, 30, 40],
    ).solve(initial_inventory=200)
    if sol.status == "Optimal":
        caps = [20, 30, 40]
        for t, x in enumerate(sol.production):
            assert x <= caps[t] + 1e-6


def test_n_periods_attribute():
    p = CapacitatedLotSizing(
        demand=[1, 2, 3, 4],
        setup_costs=[1, 1, 1, 1],
        holding_costs=[0, 0, 0, 0],
        production_costs=[1, 1, 1, 1],
        capacity=10,
    )
    assert p.n_periods == 4
