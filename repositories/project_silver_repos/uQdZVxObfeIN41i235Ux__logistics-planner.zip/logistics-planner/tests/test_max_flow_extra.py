import numpy as np
import pytest

from logistics_planner.problems.max_flow_problem import MaxFlowProblem
from logistics_planner.benchmark import random_max_flow_instance


@pytest.mark.parametrize("n", [3, 4, 5, 6])
def test_max_flow_various_sizes(n):
    cap = random_max_flow_instance(n, density=0.4, seed=42)
    sol = MaxFlowProblem(cap, source=0, sink=n-1).solve()
    assert sol.status == "Optimal"
    assert sol.max_flow_value >= 0


@pytest.mark.parametrize("seed", [10, 20, 30])
def test_max_flow_random_seeds(seed):
    cap = random_max_flow_instance(5, seed=seed)
    sol = MaxFlowProblem(cap, 0, 4).solve()
    assert sol.max_flow_value >= 0


def test_max_flow_chain():
    # 0 -> 1 -> 2, both edges capacity 5
    cap = [[0, 5, 0], [0, 0, 5], [0, 0, 0]]
    sol = MaxFlowProblem(cap, 0, 2).solve()
    assert sol.max_flow_value == pytest.approx(5.0)


def test_max_flow_parallel_edges():
    # 0 -> 1 cap 3, 0 -> 2 cap 4, 1 -> 3 cap 3, 2 -> 3 cap 4
    cap = [[0, 3, 4, 0],
           [0, 0, 0, 3],
           [0, 0, 0, 4],
           [0, 0, 0, 0]]
    sol = MaxFlowProblem(cap, 0, 3).solve()
    assert sol.max_flow_value == pytest.approx(7.0)


def test_max_flow_attributes():
    p = MaxFlowProblem([[0, 3], [0, 0]], source=0, sink=1)
    assert p.n == 2
    assert p.source == 0
    assert p.sink == 1


def test_max_flow_capacity_array_stored():
    p = MaxFlowProblem([[0, 1], [0, 0]], 0, 1)
    assert isinstance(p.capacity, np.ndarray)


def test_max_flow_zero_capacity_means_zero_flow():
    cap = [[0, 0], [0, 0]]
    sol = MaxFlowProblem(cap, 0, 1).solve()
    assert sol.max_flow_value == pytest.approx(0.0)


def test_max_flow_self_capacity_ignored():
    # diagonal entries (self-loops) should not count
    cap = [[5, 3, 0], [0, 7, 4], [0, 0, 0]]
    sol = MaxFlowProblem(cap, 0, 2).solve()
    assert sol.max_flow_value == pytest.approx(3.0)
