import pytest

from logistics_planner.problems.multi_dimensional_knapsack import (
    MultiDimensionalKnapsack,
    MultiDimKnapsackSolution,
)


def test_solve_basic():
    sol = MultiDimensionalKnapsack(
        values=[10, 20, 30],
        weight_matrix=[[2, 3, 4], [3, 2, 5]],
        capacities=[6, 7],
    ).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    sol = MultiDimensionalKnapsack(
        values=[5, 10],
        weight_matrix=[[1, 2]],
        capacities=[2],
    ).solve()
    assert isinstance(sol, MultiDimKnapsackSolution)


def test_shape_validation_raises():
    with pytest.raises(ValueError):
        MultiDimensionalKnapsack(
            values=[1, 2, 3],
            weight_matrix=[[1, 2]],
            capacities=[5],
        )


def test_no_capacity_means_no_items():
    sol = MultiDimensionalKnapsack(
        values=[10, 20],
        weight_matrix=[[1, 2]],
        capacities=[0],
    ).solve()
    if sol.status == "Optimal":
        assert sol.selected == []
