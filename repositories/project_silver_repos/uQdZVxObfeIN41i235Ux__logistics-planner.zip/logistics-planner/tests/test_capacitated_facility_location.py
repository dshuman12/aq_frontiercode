import numpy as np
import pytest

from logistics_planner.problems.capacitated_facility_location import (
    CapacitatedFacilityLocation,
    CFLPSolution,
)


def test_solver_returns_solution_object():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 150]),
        max_amounts=np.array([50, 50]),
        cost_suppliers=np.array([[4, 6], [5, 3]]),
        annual_demands=np.array([30, 20]),
    ).solve()
    assert sol.status == "Optimal"
    assert isinstance(sol, CFLPSolution)


def test_demand_satisfied():
    cost_facilities = np.array([200, 200, 200])
    max_amounts = np.array([100, 100, 100])
    cost_suppliers = np.array([
        [3, 5, 4, 6],
        [4, 3, 5, 5],
        [6, 5, 3, 4],
    ])
    annual_demands = np.array([30, 40, 50, 60])

    sol = CapacitatedFacilityLocation(
        cost_facilities, max_amounts, cost_suppliers, annual_demands
    ).solve()
    assert sol.status == "Optimal"
    column_sums = sol.allocation.sum(axis=0)
    np.testing.assert_array_almost_equal(column_sums, annual_demands)


def test_capacity_respected():
    cost_facilities = np.array([50, 60])
    max_amounts = np.array([40, 50])
    cost_suppliers = np.array([[2, 3], [4, 1]])
    annual_demands = np.array([30, 40])

    sol = CapacitatedFacilityLocation(
        cost_facilities, max_amounts, cost_suppliers, annual_demands
    ).solve()
    assert sol.status == "Optimal"
    row_sums = sol.allocation.sum(axis=1)
    for i, total in enumerate(row_sums):
        if total > 0:
            assert total <= max_amounts[i] + 1e-6


def test_open_facilities_returned_as_list():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 100]),
        max_amounts=np.array([60, 60]),
        cost_suppliers=np.array([[2, 3], [4, 1]]),
        annual_demands=np.array([30, 30]),
    ).solve()
    assert isinstance(sol.open_facilities, list)
    for i in sol.open_facilities:
        assert 0 <= i < 2


def test_allocation_shape_matches_inputs():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 200, 150]),
        max_amounts=np.array([50, 50, 50]),
        cost_suppliers=np.array([
            [2, 3, 4, 5],
            [3, 2, 5, 4],
            [4, 5, 2, 3],
        ]),
        annual_demands=np.array([20, 20, 20, 20]),
    ).solve()
    assert sol.allocation.shape == (3, 4)


def test_no_negative_shipments():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 100]),
        max_amounts=np.array([100, 100]),
        cost_suppliers=np.array([[1, 2], [2, 1]]),
        annual_demands=np.array([50, 50]),
    ).solve()
    assert (sol.allocation >= -1e-9).all()


def test_z_min_is_finite():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([10]),
        max_amounts=np.array([100]),
        cost_suppliers=np.array([[1, 2, 3]]),
        annual_demands=np.array([10, 20, 30]),
    ).solve()
    assert sol.status == "Optimal"
    assert sol.z_min == pytest.approx(sol.z_min)
    assert np.isfinite(sol.z_min)
