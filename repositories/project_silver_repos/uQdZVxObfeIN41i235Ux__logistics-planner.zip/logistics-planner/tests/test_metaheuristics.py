import numpy as np
import pytest

from logistics_planner.metaheuristics import (
    GeneticAlgorithm, GAConfig,
    SimulatedAnnealing, SAConfig,
    TabuSearch, TabuConfig,
    order_crossover, swap_mutation,
    reverse_segment_neighbor, bit_flip_neighbor,
    two_opt_neighbors,
    solve_tsp_with_ga, solve_tsp_with_sa, solve_tsp_with_tabu,
    solve_knapsack_with_ga, solve_knapsack_with_sa,
)


def test_ga_runs_and_returns_result():
    def init():
        return [1, 2, 3, 4]

    def fit(ind):
        return sum(ind)

    ga = GeneticAlgorithm(
        init_individual=init,
        fitness=fit,
        crossover=lambda a, b: list(a),
        mutate=lambda x: list(x),
        config=GAConfig(population_size=10, generations=5, seed=42),
    )
    result = ga.run()
    assert result.generations_run == 5
    assert len(result.history) == 5


def test_sa_runs_and_returns_result():
    initial = [3, 1, 4, 1, 5]
    sa = SimulatedAnnealing(
        initial=initial,
        cost=lambda s: sum(s),
        neighbor=lambda s: s[::-1],
        config=SAConfig(initial_temp=10.0, max_iterations=100, seed=42),
    )
    result = sa.run()
    assert result.best_cost is not None


def test_tabu_runs_and_returns_result():
    initial = [1, 2, 3, 4, 5]
    ts = TabuSearch(
        initial=initial,
        cost=lambda s: sum(abs(a - b) for a, b in zip(s, sorted(s))),
        neighbors=two_opt_neighbors,
        config=TabuConfig(max_iterations=20, seed=42),
    )
    result = ts.run()
    assert result.best_cost is not None


def test_tsp_metaheuristics_run():
    rng = np.random.default_rng(42)
    coords = rng.uniform(0, 10, size=(8, 2))
    D = np.zeros((8, 8))
    for i in range(8):
        for j in range(8):
            if i != j:
                D[i, j] = np.linalg.norm(coords[i] - coords[j])

    tour_ga, dist_ga = solve_tsp_with_ga(D, seed=42,
                                         config=GAConfig(generations=20, seed=42))
    assert len(set(tour_ga)) == 8

    tour_sa, dist_sa = solve_tsp_with_sa(D, seed=42)
    assert len(set(tour_sa)) == 8


def test_knapsack_metaheuristics_run():
    values = [60, 100, 120, 80, 50]
    weights = [10, 20, 30, 15, 8]
    capacity = 50

    bits, val = solve_knapsack_with_ga(values, weights, capacity, seed=42,
                                       config=GAConfig(generations=20, seed=42))
    assert len(bits) == 5

    bits2, val2 = solve_knapsack_with_sa(values, weights, capacity, seed=42)
    assert len(bits2) == 5


def test_order_crossover_preserves_genes():
    parent1 = [1, 2, 3, 4, 5]
    parent2 = [5, 4, 3, 2, 1]
    child = order_crossover(parent1, parent2)
    assert set(child) == set(parent1)


def test_swap_mutation_preserves_length():
    s = [1, 2, 3, 4, 5]
    m = swap_mutation(s)
    assert len(m) == 5
    assert set(m) == set(s)
