import pytest

from logistics_planner.problems.zero_one_knapsack import ZeroOneKnapsack
from logistics_planner.problems.set_covering_problem import SetCoveringProblem


def test_knapsack_negative_values_allowed():
    # negative values would never be selected
    sol = ZeroOneKnapsack([-5, 10], [1, 1], 1).solve()
    assert sol.status == "Optimal"


def test_set_covering_attribute_count_matches_inputs():
    p = SetCoveringProblem(costs=[1, 2, 3], coverage_matrix=[[1, 0, 1], [0, 1, 1]])
    assert p.n == 3
    assert p.m == 2
