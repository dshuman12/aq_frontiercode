import numpy as np
import pytest

from logistics_planner.problems.p_median_problem import (
    PMedianProblem,
    PMedianSolution,
)


def test_solve_simple():
    D = np.array([[0, 5, 10], [5, 0, 5], [10, 5, 0]])
    demands = [3, 4, 5]
    sol = PMedianProblem(D, demands, p=1).solve()
    assert isinstance(sol, PMedianSolution)


def test_p_facilities_opened():
    D = np.array([[0, 5, 10, 8], [5, 0, 5, 4], [10, 5, 0, 3], [8, 4, 3, 0]])
    demands = [1, 1, 1, 1]
    sol = PMedianProblem(D, demands, p=2).solve()
    if sol.status == "Optimal":
        assert len(sol.open_facilities) == 2


def test_each_demand_assigned():
    D = np.array([[0, 1, 2], [1, 0, 1], [2, 1, 0]])
    demands = [1, 1, 1]
    sol = PMedianProblem(D, demands, p=1).solve()
    if sol.status == "Optimal":
        assigned = {i for i, _ in sol.assignment}
        assert assigned == {0, 1, 2}


def test_invalid_p_raises():
    D = [[0, 1], [1, 0]]
    with pytest.raises(ValueError):
        PMedianProblem(D, demands=[1, 1], p=5)


def test_demand_length_mismatch():
    D = [[0, 1], [1, 0]]
    with pytest.raises(ValueError):
        PMedianProblem(D, demands=[1, 1, 1], p=1)
