"""Single-import smoke tests for top-level submodules."""


def test_metaheuristics_importable():
    import logistics_planner.metaheuristics
    assert logistics_planner.metaheuristics is not None


def test_benchmark_importable():
    import logistics_planner.benchmark
    assert logistics_planner.benchmark is not None


def test_analysis_importable():
    import logistics_planner.analysis
    assert logistics_planner.analysis is not None


def test_game_theory_importable():
    import logistics_planner.game_theory
    assert logistics_planner.game_theory is not None


def test_visualization_importable():
    import logistics_planner.visualization
    assert logistics_planner.visualization is not None
