import numpy as np
import pytest

from logistics_planner.problems.shortest_path_problem import ShortestPathProblem


INF = float("inf")


def _line_graph(n):
    """0 - 1 - 2 - ... - n-1 with unit weights."""
    cost = np.full((n, n), INF)
    for i in range(n):
        cost[i, i] = 0
    for i in range(n - 1):
        cost[i, i + 1] = 1
        cost[i + 1, i] = 1
    return cost


@pytest.mark.parametrize("n", [3, 5, 8, 10])
def test_shortest_path_line_graph(n):
    cost = _line_graph(n)
    sol = ShortestPathProblem(cost, 0, n - 1).solve_dijkstra()
    assert sol.status == "Optimal"
    assert sol.distance == pytest.approx(n - 1)
    assert len(sol.path) == n


def test_shortest_path_same_source_target():
    cost = _line_graph(5)
    sol = ShortestPathProblem(cost, 2, 2).solve_dijkstra()
    assert sol.status == "Optimal"
    assert sol.distance == pytest.approx(0)


def test_shortest_path_attributes():
    cost = _line_graph(3)
    p = ShortestPathProblem(cost, 0, 2)
    assert p.source == 0
    assert p.target == 2


@pytest.mark.parametrize("source,target", [(0, 1), (1, 2), (0, 2)])
def test_shortest_path_various_endpoints(source, target):
    cost = _line_graph(4)
    sol = ShortestPathProblem(cost, source, target).solve()
    assert sol.status == "Optimal"


def test_shortest_path_isolated_node():
    n = 4
    cost = np.full((n, n), INF)
    for i in range(n):
        cost[i, i] = 0
    cost[0, 1] = 5
    cost[1, 0] = 5
    # node 2 and 3 are isolated
    sol = ShortestPathProblem(cost, 0, 2).solve()
    assert sol.status == "Infeasible"


def test_shortest_path_distance_matrix_stored():
    cost = _line_graph(3)
    p = ShortestPathProblem(cost, 0, 2)
    assert isinstance(p.cost, np.ndarray)


def test_shortest_path_lp_gives_finite_result():
    cost = _line_graph(4)
    sol = ShortestPathProblem(cost, 0, 3).solve_lp()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")
