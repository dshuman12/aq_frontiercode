import json
import tempfile
import os

import numpy as np

from logistics_planner.data.loaders import (
    load_facility_instance,
    load_transportation_instance,
    load_lot_sizing_instance,
    load_blending_instance,
    load_diet_instance,
    load_tsp_instance,
)


def _write_json(payload):
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w") as f:
        json.dump(payload, f)
    return path


def test_load_facility_instance():
    path = _write_json({
        "cost_facilities": [100, 200],
        "max_amounts": [50, 60],
        "cost_suppliers": [[1, 2], [3, 4]],
        "annual_demands": [10, 20],
    })
    cf, ma, cs, ad = load_facility_instance(path)
    assert cf.shape == (2,)
    assert cs.shape == (2, 2)
    np.testing.assert_array_equal(ad, [10, 20])
    os.remove(path)


def test_load_transportation_instance():
    path = _write_json({
        "supply": [10, 20],
        "demand": [5, 5, 20],
        "cost_matrix": [[1, 2, 3], [4, 5, 6]],
    })
    s, d, c = load_transportation_instance(path)
    assert c.shape == (2, 3)
    os.remove(path)


def test_load_lot_sizing_instance():
    path = _write_json({
        "demand": [1, 2, 3],
        "setup_costs": [10, 10, 10],
        "holding_costs": [1, 1, 1],
        "production_costs": [2, 2, 2],
        "capacity": 100,
    })
    d, s, h, p, cap = load_lot_sizing_instance(path)
    assert cap == 100
    assert d.shape == (3,)
    os.remove(path)


def test_load_blending_instance():
    path = _write_json({
        "materials": ["A", "B"],
        "costs": [10, 20],
        "property_matrix": [[1, 2]],
        "lower_bounds": [0],
        "upper_bounds": [10],
        "output_quantity": 100,
    })
    mats, costs, P, lo, hi, Q = load_blending_instance(path)
    assert mats == ["A", "B"]
    assert Q == 100
    os.remove(path)


def test_load_diet_instance():
    path = _write_json({
        "foods": ["bread", "milk"],
        "costs": [1, 2],
        "nutrient_matrix": [[3, 5]],
        "requirements": [10],
    })
    foods, costs, N, req = load_diet_instance(path)
    assert foods == ["bread", "milk"]
    assert N.shape == (1, 2)
    os.remove(path)


def test_load_tsp_instance():
    path = _write_json({"distance_matrix": [[0, 1, 2], [1, 0, 3], [2, 3, 0]]})
    D = load_tsp_instance(path)
    assert D.shape == (3, 3)
    os.remove(path)
