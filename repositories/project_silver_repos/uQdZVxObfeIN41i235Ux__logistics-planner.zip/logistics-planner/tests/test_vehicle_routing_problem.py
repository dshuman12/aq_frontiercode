import numpy as np
import pytest

from logistics_planner.problems.vehicle_routing_problem import (
    VehicleRoutingProblem,
    VRPSolution,
)


def _simple_instance():
    D = np.array([
        [0, 4, 6, 8],
        [4, 0, 3, 5],
        [6, 3, 0, 4],
        [8, 5, 4, 0],
    ])
    demands = [0, 5, 4, 3]
    return D, demands


def test_clarke_wright_runs():
    D, demands = _simple_instance()
    sol = VehicleRoutingProblem(D, demands, num_vehicles=2, capacity=10).solve()
    assert isinstance(sol, VRPSolution)
    assert sol.status == "Heuristic"


def test_all_customers_visited():
    D, demands = _simple_instance()
    sol = VehicleRoutingProblem(D, demands, num_vehicles=2, capacity=10).solve()
    visited = set()
    for r in sol.routes:
        for c in r[1:-1]:
            visited.add(c)
    assert visited == {1, 2, 3}


def test_capacity_respected():
    D, demands = _simple_instance()
    capacity = 10
    sol = VehicleRoutingProblem(D, demands, num_vehicles=3, capacity=capacity).solve()
    for r in sol.routes:
        load = sum(demands[c] for c in r[1:-1])
        assert load <= capacity + 1e-6


def test_depot_demand_must_be_zero():
    D = [[0, 1], [1, 0]]
    with pytest.raises(ValueError):
        VehicleRoutingProblem(D, demands=[5, 3], num_vehicles=1, capacity=10)


def test_demand_length_matches_n():
    D = [[0, 1], [1, 0]]
    with pytest.raises(ValueError):
        VehicleRoutingProblem(D, demands=[0, 1, 2], num_vehicles=1, capacity=10)
