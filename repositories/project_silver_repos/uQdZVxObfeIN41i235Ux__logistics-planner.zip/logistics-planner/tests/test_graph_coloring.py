import pytest
import numpy as np

from logistics_planner.problems.graph_coloring_problem import (
    GraphColoringProblem,
    GraphColoringSolution,
)


def _triangle():
    return [[0, 1, 1], [1, 0, 1], [1, 1, 0]]


def test_greedy_runs():
    sol = GraphColoringProblem(_triangle()).solve_greedy()
    assert isinstance(sol, GraphColoringSolution)
    assert sol.chromatic_number >= 3


def test_adjacent_vertices_differ_in_greedy():
    adj = _triangle()
    sol = GraphColoringProblem(adj).solve_greedy()
    n = len(adj)
    for u in range(n):
        for v in range(u + 1, n):
            if adj[u][v]:
                assert sol.coloring[u] != sol.coloring[v]


def test_mip_solves_triangle():
    sol = GraphColoringProblem(_triangle()).solve_mip()
    assert sol.status == "Optimal"
    assert sol.chromatic_number == 3


def test_non_square_adjacency_raises():
    with pytest.raises(ValueError):
        GraphColoringProblem([[0, 1, 0], [1, 0, 1]])


def test_diagonal_zeroed():
    adj = [[1, 1], [1, 1]]
    p = GraphColoringProblem(adj)
    assert p.adjacency[0, 0] == 0
    assert p.adjacency[1, 1] == 0
