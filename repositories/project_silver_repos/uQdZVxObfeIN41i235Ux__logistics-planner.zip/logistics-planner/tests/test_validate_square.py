import pytest
import numpy as np
from logistics_planner.utils import validate_square_matrix


def test_returns_size():
    n = validate_square_matrix("x", np.zeros((3, 3)))
    assert n == 3


def test_raises_on_1d():
    with pytest.raises(ValueError):
        validate_square_matrix("x", [1, 2, 3])


@pytest.mark.parametrize("size", [1, 2, 5, 10])
def test_various_sizes(size):
    n = validate_square_matrix("x", np.zeros((size, size)))
    assert n == size
