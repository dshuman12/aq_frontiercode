import numpy as np
import pytest

from logistics_planner.solvers.simplex import Simplex


def test_simplex_init_validates_dims():
    with pytest.raises(ValueError):
        Simplex(c=[1, 2, 3], A=[[1, 2]], b=[1])


def test_simplex_returns_arrays():
    c = [-3, -5]
    A = [[1, 0], [0, 2], [3, 2]]
    b = [4, 12, 18]
    s = Simplex(c, A, b)
    assert s.m == 3
    assert s.n == 2


def test_simplex_attributes_stored_as_numpy():
    s = Simplex([1, 2], [[1, 1]], [5])
    assert isinstance(s.A, np.ndarray)
