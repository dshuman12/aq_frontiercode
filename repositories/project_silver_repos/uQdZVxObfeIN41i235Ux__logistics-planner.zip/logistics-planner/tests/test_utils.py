import numpy as np
import pytest

from logistics_planner.utils import to_numpy, check_dimensions


def test_to_numpy_returns_array():
    arr = to_numpy([1, 2, 3])
    assert isinstance(arr, np.ndarray)
    assert arr.shape == (3,)


def test_to_numpy_2d():
    arr = to_numpy([[1, 2], [3, 4]])
    assert arr.shape == (2, 2)


def test_check_dimensions_passes():
    check_dimensions("foo", [[1, 2], [3, 4]], (2, 2))


def test_check_dimensions_raises_on_mismatch():
    with pytest.raises(ValueError):
        check_dimensions("foo", [1, 2, 3], (5,))


def test_check_dimensions_handles_1d():
    check_dimensions("vec", [1, 2, 3], (3,))
