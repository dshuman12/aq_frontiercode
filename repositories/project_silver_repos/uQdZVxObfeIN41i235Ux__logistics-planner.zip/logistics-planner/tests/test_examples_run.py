"""Smoke test that example modules can be imported without error."""
import importlib.util
import os
import pytest


EXAMPLES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "examples")


@pytest.mark.parametrize("filename", sorted(
    f for f in os.listdir(EXAMPLES_DIR) if f.endswith(".py")
))
def test_example_can_be_loaded(filename):
    path = os.path.join(EXAMPLES_DIR, filename)
    spec = importlib.util.spec_from_file_location(filename[:-3], path)
    assert spec is not None
