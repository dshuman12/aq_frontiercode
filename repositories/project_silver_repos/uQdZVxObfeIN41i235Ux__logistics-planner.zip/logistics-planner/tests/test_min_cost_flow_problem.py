import numpy as np
import pytest

from logistics_planner.problems.min_cost_flow_problem import (
    MinCostFlowProblem,
    MinCostFlowSolution,
)


def test_solve_basic():
    cost = [[0, 1, 2, 0],
            [0, 0, 1, 3],
            [0, 0, 0, 1],
            [0, 0, 0, 0]]
    cap = [[0, 5, 5, 0],
           [0, 0, 5, 5],
           [0, 0, 0, 5],
           [0, 0, 0, 0]]
    supplies = [4, 0, 0, -4]
    sol = MinCostFlowProblem(cost, cap, supplies).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    cost = [[0, 1], [0, 0]]
    cap = [[0, 5], [0, 0]]
    supplies = [3, -3]
    sol = MinCostFlowProblem(cost, cap, supplies).solve()
    assert isinstance(sol, MinCostFlowSolution)


def test_unbalanced_supplies_raises():
    with pytest.raises(ValueError):
        MinCostFlowProblem([[0, 1], [0, 0]], [[0, 1], [0, 0]], [3, 5])


def test_shape_validation():
    with pytest.raises(ValueError):
        MinCostFlowProblem([[0, 1, 0], [0, 0, 0]], [[0, 1, 0], [0, 0, 0]], [1, -1])
