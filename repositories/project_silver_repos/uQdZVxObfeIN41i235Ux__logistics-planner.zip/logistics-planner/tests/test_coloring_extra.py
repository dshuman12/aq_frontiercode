import pytest

from logistics_planner.problems.graph_coloring_problem import GraphColoringProblem


def test_empty_graph_one_color():
    adj = [[0, 0], [0, 0]]
    sol = GraphColoringProblem(adj).solve_greedy()
    assert sol.chromatic_number == 1


def test_complete_graph_chromatic():
    n = 4
    adj = [[0 if i == j else 1 for j in range(n)] for i in range(n)]
    sol = GraphColoringProblem(adj).solve_greedy()
    assert sol.chromatic_number == n


def test_path_graph_two_colors():
    adj = [[0, 1, 0, 0], [1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0]]
    sol = GraphColoringProblem(adj).solve_greedy()
    assert sol.chromatic_number == 2


@pytest.mark.parametrize("n", [3, 4, 5, 6])
def test_complete_n_coloring(n):
    adj = [[0 if i == j else 1 for j in range(n)] for i in range(n)]
    sol = GraphColoringProblem(adj).solve_greedy()
    assert sol.chromatic_number == n
