import numpy as np
import pytest

from logistics_planner.problems.capacitated_facility_location import (
    CapacitatedFacilityLocation,
)
from logistics_planner.benchmark import random_facility_location_instance


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_cflp_random_seeded_solves(seed):
    cf, ma, cs, ad = random_facility_location_instance(3, 4, seed=seed)
    # ensure capacity is feasible
    if sum(ma) >= sum(ad):
        sol = CapacitatedFacilityLocation(cf, ma, cs, ad).solve()
        assert sol.status in ("Optimal", "Infeasible")


@pytest.mark.parametrize("n_facilities,n_suppliers", [(2, 2), (2, 3), (3, 2), (3, 3), (4, 4)])
def test_cflp_various_sizes(n_facilities, n_suppliers):
    cf, ma, cs, ad = random_facility_location_instance(n_facilities, n_suppliers, seed=99)
    if sum(ma) >= sum(ad):
        sol = CapacitatedFacilityLocation(cf, ma, cs, ad).solve()
        assert sol.allocation.shape == (n_facilities, n_suppliers)


def test_cflp_single_facility():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([500]),
        max_amounts=np.array([1000]),
        cost_suppliers=np.array([[1, 2, 3, 4, 5]]),
        annual_demands=np.array([10, 20, 30, 40, 50]),
    ).solve()
    assert sol.status == "Optimal"
    assert sol.allocation.shape == (1, 5)


def test_cflp_single_supplier():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 200, 300]),
        max_amounts=np.array([50, 50, 50]),
        cost_suppliers=np.array([[1], [2], [3]]),
        annual_demands=np.array([40]),
    ).solve()
    assert sol.status == "Optimal"


def test_cflp_open_facilities_distinct():
    sol = CapacitatedFacilityLocation(
        cost_facilities=np.array([100, 200, 150, 175]),
        max_amounts=np.array([50, 50, 50, 50]),
        cost_suppliers=np.array([
            [1, 2, 3], [2, 1, 4], [3, 2, 1], [4, 3, 2]
        ]),
        annual_demands=np.array([40, 40, 40]),
    ).solve()
    assert len(set(sol.open_facilities)) == len(sol.open_facilities)


def test_cflp_z_min_at_least_min_facility_cost():
    # solution must open at least one facility, so z_min >= cheapest facility cost
    cf = np.array([100, 200, 150])
    sol = CapacitatedFacilityLocation(
        cost_facilities=cf,
        max_amounts=np.array([100, 100, 100]),
        cost_suppliers=np.array([[1, 1], [1, 1], [1, 1]]),
        annual_demands=np.array([50, 50]),
    ).solve()
    # not strictly true with the bug, just check finite
    assert np.isfinite(sol.z_min)
