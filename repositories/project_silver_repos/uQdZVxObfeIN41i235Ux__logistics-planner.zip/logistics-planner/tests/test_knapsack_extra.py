import pytest
import numpy as np

from logistics_planner.problems.zero_one_knapsack import ZeroOneKnapsack
from logistics_planner.problems.multi_dimensional_knapsack import MultiDimensionalKnapsack
from logistics_planner.benchmark import random_knapsack_instance


@pytest.mark.parametrize("n", [3, 5, 8, 10])
def test_knapsack_various_sizes(n):
    v, w, c = random_knapsack_instance(n, seed=42)
    sol = ZeroOneKnapsack(v, w, c).solve()
    assert sol.status == "Optimal"
    assert sol.total_value >= 0


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_knapsack_random_seeds(seed):
    v, w, c = random_knapsack_instance(6, seed=seed)
    sol = ZeroOneKnapsack(v, w, c).solve()
    assert sol.total_value >= 0


def test_knapsack_attributes():
    p = ZeroOneKnapsack([1, 2, 3], [1, 2, 3], 5)
    assert p.n == 3
    assert p.capacity == 5


def test_knapsack_no_items():
    sol = ZeroOneKnapsack([10], [100], capacity=5).solve()
    assert sol.total_value == 0


def test_knapsack_single_item_fits():
    sol = ZeroOneKnapsack([10], [3], capacity=5).solve()
    assert sol.total_value == 10
    assert sol.selected == [0]


def test_knapsack_arrays_stored_as_numpy():
    p = ZeroOneKnapsack([1, 2], [1, 2], 5)
    assert isinstance(p.values, np.ndarray)
    assert isinstance(p.weights, np.ndarray)


@pytest.mark.parametrize("k,n", [(1, 3), (2, 3), (3, 4), (2, 5)])
def test_multi_dim_knapsack_shapes(k, n):
    rng = np.random.default_rng(42)
    values = rng.integers(1, 10, size=n).tolist()
    W = rng.integers(1, 10, size=(k, n)).tolist()
    caps = rng.integers(10, 30, size=k).tolist()
    sol = MultiDimensionalKnapsack(values, W, caps).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_multi_dim_knapsack_attributes():
    p = MultiDimensionalKnapsack([1, 2, 3], [[1, 2, 3]], [5])
    assert p.n == 3
    assert p.k == 1
