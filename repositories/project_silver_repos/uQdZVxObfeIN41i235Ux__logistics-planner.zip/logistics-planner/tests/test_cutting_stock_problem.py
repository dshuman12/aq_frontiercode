import pytest

from logistics_planner.problems.cutting_stock_problem import (
    CuttingStockProblem,
    CuttingStockSolution,
)


def test_solve_simple():
    csp = CuttingStockProblem(roll_length=10, item_widths=[3, 4], demands=[5, 3])
    sol = csp.solve()
    assert isinstance(sol, CuttingStockSolution)
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_pattern_enumeration_exists():
    csp = CuttingStockProblem(roll_length=10, item_widths=[3, 4], demands=[1, 1])
    patterns = csp.enumerate_patterns()
    assert len(patterns) > 0


def test_demand_satisfied_when_optimal():
    csp = CuttingStockProblem(roll_length=10, item_widths=[3, 7], demands=[2, 1])
    sol = csp.solve()
    if sol.status == "Optimal":
        # check supplies cover demands
        produced = [0, 0]
        for pattern, count in sol.pattern_counts.items():
            for i in range(2):
                produced[i] += pattern[i] * count
        assert produced[0] >= 2
        assert produced[1] >= 1


def test_oversize_item_raises():
    with pytest.raises(ValueError):
        CuttingStockProblem(roll_length=5, item_widths=[10], demands=[1])


def test_first_fit_decreasing_lower_bound():
    csp = CuttingStockProblem(roll_length=10, item_widths=[6, 3, 4], demands=[1, 1, 1])
    lb = csp.first_fit_decreasing_lower_bound()
    assert lb >= 1
