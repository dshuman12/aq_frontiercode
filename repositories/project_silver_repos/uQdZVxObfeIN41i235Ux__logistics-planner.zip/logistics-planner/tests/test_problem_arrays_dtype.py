"""Sanity test: verify arrays get stored with sensible dtypes."""
import numpy as np

from logistics_planner.problems.transportation_problem import TransportationProblem
from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman


def test_transportation_supply_is_float():
    p = TransportationProblem([10.5, 20.3], [10, 20.8], [[1, 2], [3, 4]])
    assert p.supply.dtype == float


def test_transportation_cost_is_float():
    p = TransportationProblem([10, 20], [15, 15], [[1, 2], [3, 4]])
    assert p.cost_matrix.dtype == float


def test_tsp_distance_matrix_is_float():
    p = TravelingSalesman([[0, 1], [1, 0]])
    assert p.distance_matrix.dtype == float
