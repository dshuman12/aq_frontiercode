import numpy as np
import pytest

from logistics_planner.problems.assignment_problem import AssignmentProblem
from logistics_planner.benchmark import random_assignment_instance


@pytest.mark.parametrize("n", [2, 3, 4, 5])
def test_assignment_various_sizes(n):
    M = random_assignment_instance(n, seed=42)
    sol = AssignmentProblem(M).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


@pytest.mark.parametrize("seed", [11, 22, 33, 44, 55])
def test_assignment_random_seeds(seed):
    M = random_assignment_instance(4, seed=seed)
    sol = AssignmentProblem(M).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_assignment_identity_costs():
    cost = np.eye(4)
    sol = AssignmentProblem(cost).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_assignment_attributes():
    p = AssignmentProblem([[1, 2], [3, 4]])
    assert p.n == 2


def test_hungarian_returns_solution_object():
    sol = AssignmentProblem([[1, 2], [3, 4]]).solve_hungarian()
    assert sol.status in ("Optimal", "Heuristic")


def test_hungarian_5x5_random():
    M = random_assignment_instance(5, seed=42)
    sol = AssignmentProblem(M).solve_hungarian()
    assert sol.status in ("Optimal", "Heuristic")


def test_assignment_3x3_known_instance():
    cost = [[1, 2, 3], [3, 1, 2], [2, 3, 1]]
    sol = AssignmentProblem(cost).solve_hungarian()
    assert sol.status in ("Optimal", "Heuristic")


def test_assignment_costs_array_stored():
    p = AssignmentProblem([[1, 2], [3, 4]])
    assert isinstance(p.cost, np.ndarray)
