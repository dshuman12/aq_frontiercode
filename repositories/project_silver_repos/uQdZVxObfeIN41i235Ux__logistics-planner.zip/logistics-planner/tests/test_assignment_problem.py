import numpy as np
import pytest

from logistics_planner.problems.assignment_problem import (
    AssignmentProblem,
    AssignmentSolution,
)


def test_solve_returns_solution():
    sol = AssignmentProblem([[4, 1, 3], [2, 0, 5], [3, 2, 2]]).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    sol = AssignmentProblem([[1, 2], [3, 4]]).solve()
    assert isinstance(sol, AssignmentSolution)


def test_assignment_is_complete():
    sol = AssignmentProblem([[1, 2, 3], [3, 1, 2], [2, 3, 1]]).solve()
    if sol.status == "Optimal":
        assigned_rows = {i for i, _ in sol.assignment}
        assigned_cols = {j for _, j in sol.assignment}
        assert assigned_rows == {0, 1, 2}
        assert assigned_cols == {0, 1, 2}


def test_2d_required():
    with pytest.raises(ValueError):
        AssignmentProblem([1, 2, 3])


def test_hungarian_runs():
    sol = AssignmentProblem([[4, 1, 3], [2, 0, 5], [3, 2, 2]]).solve_hungarian()
    assert sol.status in ("Optimal", "Heuristic")
