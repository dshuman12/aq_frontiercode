import numpy as np
import pytest

from logistics_planner.solvers.lagrangian import LagrangianRelaxation
from logistics_planner.solvers.column_generation import ColumnGeneration
from logistics_planner.solvers.cutting_planes import CuttingPlanesSolver
from logistics_planner.solvers.dual_simplex import DualSimplex


def test_lagrangian_runs():
    def subproblem(u):
        # toy: minimize 0 over the relaxed multipliers
        return float(u[0]), np.array([0.0]), [0]

    lr = LagrangianRelaxation(
        lagrangian_subproblem=subproblem,
        num_relaxed=1,
        max_iterations=5,
        maximize=False,
    )
    result = lr.run()
    assert result.iterations >= 1


def test_cutting_planes_basic():
    # max x + y  s.t.  x + 2y <= 4, 3x + y <= 5, integer
    c = [-1, -1]    # min of -obj
    A_ub = [[1, 2], [3, 1]]
    b_ub = [4, 5]
    solver = CuttingPlanesSolver(c, A_ub, b_ub, integer_indices=[0, 1],
                                 sense="min", max_iterations=20)
    res = solver.run()
    assert res.status in ("Optimal", "Iteration_Limit", "Infeasible")


def test_column_generation_runs():
    # trivial: rhs = [1], one initial column [1]
    initial_columns = [(1.0, [1.0])]

    def oracle(duals):
        # never improve - just terminate
        return [(0.0, 0.0, [1.0])]

    cg = ColumnGeneration(
        initial_columns=initial_columns,
        rhs=[1.0],
        pricing_oracle=oracle,
        max_iterations=5,
    )
    res = cg.run()
    assert res.status in ("Optimal", "Iteration_Limit")
