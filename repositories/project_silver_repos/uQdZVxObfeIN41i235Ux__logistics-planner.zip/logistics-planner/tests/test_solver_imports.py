"""Sanity test for solver and metaheuristic imports."""
import pytest


def test_simplex_imports():
    from logistics_planner.solvers.simplex import Simplex
    assert Simplex is not None


def test_big_m_imports():
    from logistics_planner.solvers.big_m_simplex import BigMSimplex
    assert BigMSimplex is not None


def test_two_phase_imports():
    from logistics_planner.solvers.two_phase_simplex import TwoPhaseSimplex
    assert TwoPhaseSimplex is not None


def test_dual_simplex_imports():
    from logistics_planner.solvers.dual_simplex import DualSimplex
    assert DualSimplex is not None


def test_branch_and_bound_imports():
    from logistics_planner.solvers.branch_and_bound import branch_and_bound
    assert callable(branch_and_bound)


def test_lagrangian_imports():
    from logistics_planner.solvers.lagrangian import LagrangianRelaxation
    assert LagrangianRelaxation is not None


def test_column_generation_imports():
    from logistics_planner.solvers.column_generation import ColumnGeneration
    assert ColumnGeneration is not None


def test_cutting_planes_imports():
    from logistics_planner.solvers.cutting_planes import CuttingPlanesSolver
    assert CuttingPlanesSolver is not None


def test_metaheuristics_top_level():
    import logistics_planner.metaheuristics as mh
    assert hasattr(mh, "GeneticAlgorithm")
    assert hasattr(mh, "SimulatedAnnealing")
    assert hasattr(mh, "TabuSearch")
