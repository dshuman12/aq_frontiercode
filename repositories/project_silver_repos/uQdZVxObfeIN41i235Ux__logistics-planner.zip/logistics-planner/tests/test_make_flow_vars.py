import pytest

from logistics_planner.solvers.lp_solver import make_flow_vars


def test_make_flow_vars_returns_dict():
    edges = [(0, 1), (1, 2)]
    out = make_flow_vars("x", edges)
    assert isinstance(out, dict)
    assert (0, 1) in out
    assert (1, 2) in out


def test_make_flow_vars_no_capacity_lookup():
    out = make_flow_vars("x", [(0, 1)])
    var = out[0, 1]
    assert var.lowBound == 0


def test_make_flow_vars_with_capacity_lookup():
    cap = {(0, 1): 5, (1, 2): 7}
    out = make_flow_vars("x", list(cap.keys()),
                        capacity_lookup=lambda i, j: cap[i, j])
    assert len(out) == 2
