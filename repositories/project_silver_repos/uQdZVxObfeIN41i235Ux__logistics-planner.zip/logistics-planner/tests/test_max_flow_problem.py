import numpy as np
import pytest

from logistics_planner.problems.max_flow_problem import (
    MaxFlowProblem,
    MaxFlowSolution,
)


def test_simple_max_flow():
    cap = [[0, 3, 2, 0],
           [0, 0, 1, 3],
           [0, 0, 0, 2],
           [0, 0, 0, 0]]
    sol = MaxFlowProblem(cap, 0, 3).solve()
    assert sol.status == "Optimal"
    assert sol.max_flow_value == pytest.approx(5.0)


def test_returns_solution_object():
    cap = [[0, 1], [0, 0]]
    sol = MaxFlowProblem(cap, 0, 1).solve()
    assert isinstance(sol, MaxFlowSolution)


def test_negative_capacity_raises():
    with pytest.raises(ValueError):
        MaxFlowProblem([[0, -1], [0, 0]], 0, 1)


def test_lp_runs():
    cap = [[0, 5, 4, 0],
           [0, 0, 2, 3],
           [0, 0, 0, 4],
           [0, 0, 0, 0]]
    p = MaxFlowProblem(cap, 0, 3)
    lp = p.solve_lp()
    assert lp.status in ("Optimal", "Unbounded", "Infeasible")


def test_no_path_zero_flow():
    cap = [[0, 1, 0], [0, 0, 0], [0, 0, 0]]
    sol = MaxFlowProblem(cap, 0, 2).solve()
    assert sol.max_flow_value == pytest.approx(0.0)
