import numpy as np
import pytest

from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman
from logistics_planner.benchmark import random_tsp_instance


@pytest.mark.parametrize("n", [3, 4, 5, 6])
def test_tsp_various_sizes_nearest_neighbor(n):
    _, D = random_tsp_instance(n, seed=42)
    sol = TravelingSalesman(D).solve_nearest_neighbor(start=0)
    assert sol.tour[0] == 0
    assert sol.tour[-1] == 0
    assert len(set(sol.tour[:-1])) == n


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_tsp_random_seeds_nearest_neighbor(seed):
    _, D = random_tsp_instance(5, seed=seed)
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    assert sol.total_distance >= 0


def test_tsp_two_cities_nearest_neighbor():
    D = np.array([[0, 7], [7, 0]])
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    assert sol.tour == [0, 1, 0]


def test_tsp_symmetric_matrix_property():
    _, D = random_tsp_instance(4, seed=42)
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    # nearest neighbor cost should equal sum of distances along tour
    expected = sum(D[sol.tour[i], sol.tour[i+1]] for i in range(len(sol.tour) - 1))
    assert sol.total_distance == pytest.approx(expected)


def test_tsp_starting_at_different_cities():
    _, D = random_tsp_instance(5, seed=42)
    tsp = TravelingSalesman(D)
    for start in range(5):
        sol = tsp.solve_nearest_neighbor(start=start)
        assert sol.tour[0] == start
        assert sol.tour[-1] == start


def test_tsp_n_attribute_set():
    D = np.zeros((6, 6))
    p = TravelingSalesman(D)
    assert p.n == 6


def test_tsp_distance_matrix_stored_as_numpy():
    D = [[0, 1], [1, 0]]
    p = TravelingSalesman(D)
    assert isinstance(p.distance_matrix, np.ndarray)


def test_tsp_tour_contains_all_unique_cities():
    _, D = random_tsp_instance(7, seed=99)
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    interior = sol.tour[:-1]
    assert len(set(interior)) == 7


def test_tsp_status_is_heuristic_for_nn():
    _, D = random_tsp_instance(4, seed=1)
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    assert sol.status == "Heuristic"
