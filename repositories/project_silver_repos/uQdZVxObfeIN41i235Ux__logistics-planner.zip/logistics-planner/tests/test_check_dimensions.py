import pytest
from logistics_planner.utils import check_dimensions


def test_passes_correct_shape():
    check_dimensions("x", [[1, 2], [3, 4]], (2, 2))


def test_raises_on_wrong_shape():
    with pytest.raises(ValueError):
        check_dimensions("x", [[1, 2]], (2, 2))


def test_raises_includes_name():
    with pytest.raises(ValueError, match="my_array"):
        check_dimensions("my_array", [1], (5,))


@pytest.mark.parametrize("shape", [(3,), (3, 3), (2, 4, 5)])
def test_various_valid_shapes(shape):
    import numpy as np
    arr = np.zeros(shape)
    check_dimensions("x", arr, shape)
