import pytest
import numpy as np

from logistics_planner.game_theory import (
    MatrixGame,
    BimatrixGame,
    dominated_rows,
    dominated_columns,
    reduce_by_dominance,
)


def test_matrix_game_solves():
    sol = MatrixGame([[2, -1], [-1, 1]]).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_pure_saddle_point_detection():
    g = MatrixGame([[3, 5, 2], [4, 6, 4], [1, 7, 0]])
    if g.has_pure_saddle_point():
        sp = g.saddle_point()
        assert sp is not None
        i, j, v = sp
        assert g.payoff[i, j] == v


def test_bimatrix_pure_nash():
    A = [[3, 0], [0, 1]]
    B = [[3, 0], [0, 1]]
    sol = BimatrixGame(A, B).solve()
    assert (0, 0) in sol.pure_nash_equilibria
    assert (1, 1) in sol.pure_nash_equilibria


def test_bimatrix_zero_sum_check():
    g = BimatrixGame([[1, -2], [-3, 4]], [[-1, 2], [3, -4]])
    assert g.is_zero_sum()


def test_bimatrix_shape_mismatch_raises():
    with pytest.raises(ValueError):
        BimatrixGame([[1, 2]], [[1], [2]])


def test_dominated_rows():
    payoff = [[1, 1], [2, 2], [3, 3]]
    dom = dominated_rows(payoff)
    assert 0 in dom
    assert 1 in dom


def test_dominated_columns():
    # col player wants LOW values, so cols with higher values are dominated
    payoff = [[1, 2, 3], [1, 2, 3]]
    dom = dominated_columns(payoff)
    assert 1 in dom
    assert 2 in dom


def test_reduce_by_dominance():
    payoff = np.array([[1, 1], [2, 2], [3, 3]])
    reduced, rows_kept, cols_kept = reduce_by_dominance(payoff)
    assert reduced.shape[0] <= 3
