import numpy as np
import pytest

from logistics_planner.problems.p_median_problem import PMedianProblem


def test_p_median_one_facility():
    D = np.array([[0, 1, 2], [1, 0, 1], [2, 1, 0]])
    sol = PMedianProblem(D, demands=[1, 1, 1], p=1).solve()
    assert sol.status == "Optimal"


def test_p_median_all_facilities():
    D = np.array([[0, 5], [5, 0]])
    sol = PMedianProblem(D, demands=[1, 1], p=2).solve()
    if sol.status == "Optimal":
        assert len(sol.open_facilities) == 2


@pytest.mark.parametrize("p", [1, 2, 3])
def test_p_median_various_p(p):
    D = np.random.default_rng(42).uniform(0, 10, size=(4, 4))
    sol = PMedianProblem(D, demands=[1, 1, 1, 1], p=p).solve()
    if sol.status == "Optimal":
        assert len(sol.open_facilities) == p


def test_p_median_attributes():
    D = [[0, 1], [1, 0]]
    p = PMedianProblem(D, demands=[1, 1], p=1)
    assert p.n_demand == 2
    assert p.n_facility == 2
    assert p.p == 1
