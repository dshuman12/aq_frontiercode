import json
import os
import tempfile

from logistics_planner.cli import build_parser, main


def test_parser_builds():
    parser = build_parser()
    args = parser.parse_args(["facility", "/tmp/foo.json"])
    assert args.command == "facility"


def test_help_runs():
    rc = main([])
    assert rc == 1


def test_lot_sizing_command():
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w") as f:
        json.dump({
            "demand": [10, 10, 10],
            "setup_costs": [50, 50, 50],
            "holding_costs": [1, 1, 1],
            "production_costs": [2, 2, 2],
            "capacity": 100,
        }, f)
    try:
        rc = main(["lot-sizing", path])
        assert rc == 0
    finally:
        os.remove(path)


def test_tsp_method_choice():
    parser = build_parser()
    args = parser.parse_args(["tsp", "/tmp/foo.json", "--method", "nearest"])
    assert args.method == "nearest"
