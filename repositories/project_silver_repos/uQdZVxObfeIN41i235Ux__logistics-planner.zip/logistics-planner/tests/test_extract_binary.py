import pytest

from logistics_planner.solvers.lp_solver import extract_binary_selection


class _MockVar:
    def __init__(self, val):
        self._val = val

    def value(self):
        return self._val


def test_extract_returns_list():
    # use plain values - the helper expects pulp.value() to work, but
    # we test the empty case here
    selected = extract_binary_selection([])
    assert selected == []


def test_threshold_default_below_half():
    # mostly we just want to ensure callable signature
    assert callable(extract_binary_selection)
