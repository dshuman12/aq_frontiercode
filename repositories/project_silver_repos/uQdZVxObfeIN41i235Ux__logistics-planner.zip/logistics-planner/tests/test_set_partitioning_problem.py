import pytest

from logistics_planner.problems.set_partitioning_problem import (
    SetPartitioningProblem,
    SetPartitioningSolution,
)


def test_solve_basic():
    coverage = [[1, 0, 1, 0],
                [0, 1, 0, 1],
                [1, 1, 0, 0]]
    sol = SetPartitioningProblem(costs=[1, 2, 3, 4], coverage_matrix=coverage).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    sol = SetPartitioningProblem(costs=[1], coverage_matrix=[[1]]).solve()
    assert isinstance(sol, SetPartitioningSolution)


def test_costs_length_validation():
    with pytest.raises(ValueError):
        SetPartitioningProblem(costs=[1, 2], coverage_matrix=[[1, 0, 1]])
