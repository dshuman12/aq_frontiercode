import pytest

from logistics_planner.problems.maximum_clique_problem import MaximumCliqueProblem


def test_clique_complete_graph():
    # K_4 - complete graph on 4 vertices, max clique is the whole graph
    adj = [[0, 1, 1, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 0]]
    sol = MaximumCliqueProblem(adj).solve_greedy()
    assert sol.size == 4


def test_clique_path_graph():
    # 0-1-2-3, max clique is 2
    adj = [[0, 1, 0, 0], [1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0]]
    sol = MaximumCliqueProblem(adj).solve_greedy()
    assert sol.size <= 4


def test_clique_single_vertex():
    sol = MaximumCliqueProblem([[0]]).solve_greedy()
    assert sol.size == 1


@pytest.mark.parametrize("n", [3, 4, 5])
def test_clique_complete_n(n):
    adj = [[0 if i == j else 1 for j in range(n)] for i in range(n)]
    sol = MaximumCliqueProblem(adj).solve_greedy()
    assert sol.size == n
