import pytest

from logistics_planner.problems.stiglers_diet_problem import (
    StiglersDiet,
    DietSolution,
)


def test_solve_returns_status():
    sol = StiglersDiet(
        foods=["X", "Y"],
        costs=[2, 3],
        nutrient_matrix=[[1, 0], [0, 1]],
        requirements=[5, 4],
    ).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_solution_object():
    sol = StiglersDiet(
        foods=["a", "b"],
        costs=[1, 1],
        nutrient_matrix=[[1, 2]],
        requirements=[10],
    ).solve()
    assert isinstance(sol, DietSolution)


def test_quantities_keyed_by_food_name():
    sol = StiglersDiet(
        foods=["bread", "milk"],
        costs=[1, 2],
        nutrient_matrix=[[3, 5]],
        requirements=[20],
    ).solve()
    if sol.status == "Optimal":
        assert set(sol.quantities.keys()) == {"bread", "milk"}


def test_dimension_mismatch_raises():
    with pytest.raises(ValueError):
        StiglersDiet(
            foods=["a", "b"],
            costs=[1, 2],
            nutrient_matrix=[[1, 2, 3]],
            requirements=[5],
        )


def test_attributes_stored():
    p = StiglersDiet(
        foods=["a", "b", "c"],
        costs=[1, 2, 3],
        nutrient_matrix=[[1, 1, 1], [2, 2, 2]],
        requirements=[3, 6],
    )
    assert p.n_foods == 3
    assert p.n_nutrients == 2


def test_no_negative_quantities():
    sol = StiglersDiet(
        foods=["a", "b"],
        costs=[1, 1],
        nutrient_matrix=[[1, 1]],
        requirements=[5],
    ).solve()
    if sol.status == "Optimal":
        for q in sol.quantities.values():
            assert q >= -1e-9
