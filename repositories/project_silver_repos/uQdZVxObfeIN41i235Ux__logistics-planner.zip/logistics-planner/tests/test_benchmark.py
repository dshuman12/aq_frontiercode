import time
import numpy as np
import pytest

from logistics_planner.benchmark import (
    timed, time_call, repeat_time,
    TimingReport,
    random_tsp_instance, random_assignment_instance, random_knapsack_instance,
    random_facility_location_instance, random_transportation_instance,
    random_lot_sizing_instance, random_max_flow_instance,
    random_graph_adjacency, random_set_covering_instance,
    compare_methods, format_report,
)


def test_timed_records_duration():
    report = TimingReport()
    with timed("sleep_test", report):
        pass  # near-zero time
    assert len(report.records) == 1


def test_time_call_returns_result_and_duration():
    result, dt = time_call(lambda: 42)
    assert result == 42
    assert dt >= 0


def test_repeat_time_summary():
    result, stats = repeat_time(lambda: 7, repeats=3)
    assert result == 7
    assert stats["min"] <= stats["avg"] <= stats["max"]


def test_random_tsp_instance_shape():
    coords, D = random_tsp_instance(5, seed=42)
    assert coords.shape == (5, 2)
    assert D.shape == (5, 5)


def test_random_assignment_instance_square():
    M = random_assignment_instance(4, seed=42)
    assert M.shape == (4, 4)


def test_random_knapsack_instance():
    v, w, c = random_knapsack_instance(5, seed=42)
    assert len(v) == 5
    assert len(w) == 5
    assert c > 0


def test_random_facility_location_instance():
    cf, ma, cs, ad = random_facility_location_instance(3, 4, seed=42)
    assert len(cf) == 3
    assert len(ma) == 3
    assert len(cs) == 3
    assert len(cs[0]) == 4
    assert len(ad) == 4


def test_random_transportation_instance_balanced():
    s, d, c = random_transportation_instance(3, 4, seed=42)
    assert sum(s) == sum(d)
    assert len(c) == 3
    assert len(c[0]) == 4


def test_random_lot_sizing_instance():
    d, s, h, p, cap = random_lot_sizing_instance(5, seed=42)
    assert len(d) == 5
    assert len(s) == 5
    assert cap > 0


def test_random_max_flow_instance():
    cap = random_max_flow_instance(5, seed=42)
    assert len(cap) == 5
    assert all(len(row) == 5 for row in cap)


def test_random_graph_adjacency_symmetric():
    adj = random_graph_adjacency(6, seed=42)
    n = len(adj)
    for i in range(n):
        for j in range(n):
            assert adj[i][j] == adj[j][i]


def test_random_set_covering_covers_each_element():
    costs, cov = random_set_covering_instance(5, 8, seed=42)
    n = len(cov)
    for i in range(n):
        assert sum(cov[i]) >= 1


def test_compare_methods_runs():
    methods = [
        ("a", lambda: (1.0, {})),
        ("b", lambda: (2.0, {})),
    ]
    report = compare_methods("test", methods, minimize=True)
    assert len(report.results) == 2
    assert report.best_by_objective(minimize=True).name == "a"


def test_format_report_returns_string():
    methods = [("a", lambda: (1.0, {}))]
    report = compare_methods("test", methods)
    text = format_report(report)
    assert "test" in text
    assert "a" in text
