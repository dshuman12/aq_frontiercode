import pytest

from logistics_planner.utils import matrix_edges


def test_returns_list_of_tuples():
    edges = matrix_edges([[0, 1, 2], [3, 0, 4], [5, 6, 0]])
    assert all(isinstance(e, tuple) for e in edges)


def test_excludes_diagonal():
    edges = matrix_edges([[1, 1, 1], [1, 1, 1], [1, 1, 1]])
    for (i, j) in edges:
        assert i != j


def test_threshold_filters():
    edges = matrix_edges([[0, 0, 1], [0, 0, 0], [1, 0, 0]], threshold=0)
    assert (0, 2) in edges
    assert (2, 0) in edges
    assert (0, 1) not in edges
