import pytest

from logistics_planner.solvers.branch_and_bound import (
    branch_and_bound,
    BranchAndBoundResult,
)


def test_returns_result_object():
    res = branch_and_bound(
        c=[1, 2],
        A_ub=[[1, 1]],
        b_ub=[3],
        ub=[5, 5],
        sense="min",
    )
    assert isinstance(res, BranchAndBoundResult)


def test_simple_max_problem():
    # max 3x + 2y  s.t. x + y <= 4, x <= 3, y <= 3, integer
    res = branch_and_bound(
        c=[3, 2],
        A_ub=[[1, 1]],
        b_ub=[4],
        ub=[3, 3],
        sense="max",
    )
    assert res.status in ("Optimal", "Infeasible")


def test_solution_is_integer():
    res = branch_and_bound(
        c=[1, 1, 1],
        A_ub=[[2, 3, 1]],
        b_ub=[7],
        ub=[5, 5, 5],
        sense="max",
    )
    if res.status == "Optimal":
        for name, val in res.solution.items():
            assert abs(val - round(val)) < 1e-6
