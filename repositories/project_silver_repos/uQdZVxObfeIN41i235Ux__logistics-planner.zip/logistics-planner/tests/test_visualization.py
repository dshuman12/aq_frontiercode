import pytest


def test_visualization_lazy_import_message():
    # confirm the visualization submodule loads without matplotlib already imported
    from logistics_planner.visualization import plot_tour, plot_flow_matrix
    assert callable(plot_tour)
    assert callable(plot_flow_matrix)
