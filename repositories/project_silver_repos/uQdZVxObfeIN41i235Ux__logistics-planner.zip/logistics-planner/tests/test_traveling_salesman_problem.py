import numpy as np
import pytest

from logistics_planner.problems.traveling_salesman_problem import (
    TravelingSalesman,
    TourSolution,
)


def test_three_city_triangle_mip():
    D = np.array([
        [0, 1, 2],
        [1, 0, 3],
        [2, 3, 0],
    ])
    sol = TravelingSalesman(D).solve_mip()
    assert sol.status == "Optimal"
    assert sol.total_distance == pytest.approx(6.0)
    assert sol.tour[0] == 0 and sol.tour[-1] == 0
    assert set(sol.tour[:-1]) == {0, 1, 2}


def test_nearest_neighbor_visits_all():
    D = np.array([
        [0, 2, 9, 10],
        [1, 0, 6, 4],
        [15, 7, 0, 8],
        [6, 3, 12, 0],
    ])
    sol = TravelingSalesman(D).solve_nearest_neighbor(start=0)
    assert sol.status == "Heuristic"
    assert sol.tour[0] == 0 and sol.tour[-1] == 0
    assert set(sol.tour[:-1]) == {0, 1, 2, 3}


def test_nearest_neighbor_distance_matches_tour():
    D = np.array([
        [0, 5, 10],
        [5, 0, 7],
        [10, 7, 0],
    ])
    sol = TravelingSalesman(D).solve_nearest_neighbor(start=0)
    expected = sum(D[sol.tour[i], sol.tour[i+1]] for i in range(len(sol.tour) - 1))
    assert sol.total_distance == pytest.approx(expected)


def test_1d_distance_raises():
    with pytest.raises(ValueError):
        TravelingSalesman([1, 2, 3])


def test_returns_tour_solution_object():
    D = np.array([[0, 1, 2], [1, 0, 1], [2, 1, 0]])
    sol = TravelingSalesman(D).solve_nearest_neighbor()
    assert isinstance(sol, TourSolution)


def test_nearest_neighbor_starts_at_given_city():
    D = np.array([[0, 4, 5], [4, 0, 3], [5, 3, 0]])
    sol = TravelingSalesman(D).solve_nearest_neighbor(start=2)
    assert sol.tour[0] == 2
    assert sol.tour[-1] == 2


def test_n_attribute():
    D = np.zeros((5, 5))
    p = TravelingSalesman(D)
    assert p.n == 5
