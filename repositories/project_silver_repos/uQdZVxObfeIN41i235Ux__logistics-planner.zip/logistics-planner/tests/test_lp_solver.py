from pulp import LpProblem, LpVariable

from logistics_planner.solvers.lp_solver import (
    build_problem,
    solve,
    get_value,
)


def test_build_problem_returns_lp_problem():
    p = build_problem("test", sense="min")
    assert isinstance(p, LpProblem)


def test_solve_returns_status_string():
    p = build_problem("trivial", sense="min")
    x = LpVariable("x", lowBound=0)
    p += x
    p += x >= 5
    status = solve(p)
    assert status in ("Optimal", "Unbounded", "Infeasible", "Not Solved")


def test_get_value_returns_number():
    p = build_problem("simple", sense="min")
    x = LpVariable("x", lowBound=0, upBound=10)
    p += x
    p += x >= 3
    solve(p)
    val = get_value(x)
    assert val is None or isinstance(val, (int, float))
