import pytest

from logistics_planner.problems.job_shop_scheduling import (
    JobShopScheduling,
    JobShopSolution,
)


def test_solve_simple():
    times = [[3, 2], [2, 4]]
    machines = [[0, 1], [1, 0]]
    sol = JobShopScheduling(times, machines).solve()
    assert isinstance(sol, JobShopSolution)
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_returns_schedule_when_optimal():
    times = [[2, 3], [4, 1]]
    machines = [[0, 1], [1, 0]]
    sol = JobShopScheduling(times, machines).solve()
    if sol.status == "Optimal":
        assert len(sol.schedule) == 4


def test_mismatched_dimensions_raise():
    with pytest.raises(ValueError):
        JobShopScheduling(processing_times=[[1, 2]], machine_orders=[[0]])


def test_inconsistent_jobs_raise():
    with pytest.raises(ValueError):
        JobShopScheduling(processing_times=[[1, 2], [3, 4]],
                          machine_orders=[[0, 1]])
