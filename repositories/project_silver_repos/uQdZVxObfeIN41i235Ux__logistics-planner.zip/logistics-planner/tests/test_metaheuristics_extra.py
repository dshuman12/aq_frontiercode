import pytest
import numpy as np

from logistics_planner.metaheuristics import (
    GeneticAlgorithm, GAConfig,
    SimulatedAnnealing, SAConfig,
    TabuSearch, TabuConfig,
    solve_tsp_with_ga, solve_tsp_with_sa, solve_tsp_with_tabu,
    solve_knapsack_with_ga, solve_knapsack_with_sa,
    bit_flip_neighbor, swap_move_neighbors, reverse_segment_neighbor,
    bit_flip_mutation, uniform_crossover,
)
from logistics_planner.benchmark import random_tsp_instance, random_knapsack_instance


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_tsp_ga_random_seeds(seed):
    _, D = random_tsp_instance(6, seed=seed)
    tour, dist = solve_tsp_with_ga(D, seed=seed,
                                   config=GAConfig(generations=20, seed=seed))
    assert len(set(tour)) == 6
    assert dist > 0


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_tsp_sa_random_seeds(seed):
    _, D = random_tsp_instance(6, seed=seed)
    tour, dist = solve_tsp_with_sa(
        D, seed=seed,
        config=SAConfig(initial_temp=10, max_iterations=500, seed=seed),
    )
    assert len(set(tour)) == 6


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_knapsack_ga_random_seeds(seed):
    v, w, c = random_knapsack_instance(5, seed=seed)
    bits, val = solve_knapsack_with_ga(v, w, c, seed=seed,
                                       config=GAConfig(generations=15, seed=seed))
    assert len(bits) == 5


def test_ga_config_defaults():
    cfg = GAConfig()
    assert cfg.population_size > 0
    assert cfg.generations > 0
    assert 0 < cfg.crossover_rate <= 1


def test_sa_config_defaults():
    cfg = SAConfig()
    assert cfg.initial_temp > 0
    assert 0 < cfg.cooling_rate < 1


def test_tabu_config_defaults():
    cfg = TabuConfig()
    assert cfg.max_iterations > 0
    assert cfg.tabu_tenure > 0


def test_bit_flip_mutation_changes_or_keeps():
    out = bit_flip_mutation([0, 1, 0, 1])
    assert len(out) == 4
    for v in out:
        assert v in (0, 1)


def test_uniform_crossover_length():
    p1 = [1, 2, 3, 4]
    p2 = [5, 6, 7, 8]
    child = uniform_crossover(p1, p2)
    assert len(child) == 4
