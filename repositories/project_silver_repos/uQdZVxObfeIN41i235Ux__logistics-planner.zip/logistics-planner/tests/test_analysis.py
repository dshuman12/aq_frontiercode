import pytest
import numpy as np

from logistics_planner.analysis import (
    SensitivityReport,
    sensitivity_report,
    DualSolution,
    dual_of_standard_min,
    verify_strong_duality,
    complementary_slackness,
)
from logistics_planner.solvers.lp_solver import build_problem, solve
from pulp import LpVariable, lpSum


def _make_simple_lp():
    p = build_problem("simple_min", sense="min")
    x = LpVariable("x", lowBound=0, upBound=10)
    y = LpVariable("y", lowBound=0, upBound=10)
    p += x + y
    p += x + 2 * y >= 4
    p += x >= 1
    return p


def test_sensitivity_report_returns_correct_type():
    p = _make_simple_lp()
    solve(p)
    report = sensitivity_report(p)
    assert isinstance(report, SensitivityReport)
    assert "x" in report.variable_values
    assert "y" in report.variable_values


def test_sensitivity_report_rejects_non_lp():
    with pytest.raises(TypeError):
        sensitivity_report({"not": "a problem"})


def test_dual_returns_solution():
    sol = dual_of_standard_min(c=[1, 2], A=[[1, 1], [1, 0]], b=[3, 1])
    assert isinstance(sol, DualSolution)


def test_strong_duality_check():
    assert verify_strong_duality(10.0, 10.0)
    assert not verify_strong_duality(10.0, 12.0)


def test_complementary_slackness_satisfied():
    out = complementary_slackness(
        x=[1, 0],
        y=[2, 0],
        A=[[1, 1], [1, 0]],
        b=[1, 1],
        c=[2, 1],
    )
    assert "primal_cs" in out
    assert "dual_cs" in out
