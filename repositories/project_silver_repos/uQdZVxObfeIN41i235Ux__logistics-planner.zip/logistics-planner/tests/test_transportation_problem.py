import numpy as np
import pytest

from logistics_planner.problems.transportation_problem import (
    TransportationProblem,
    TransportSolution,
)


def test_balanced_simple():
    sol = TransportationProblem(
        supply=[20, 30],
        demand=[10, 25, 15],
        cost_matrix=[[4, 6, 8], [5, 3, 7]],
    ).solve()
    assert sol.status == "Optimal"
    assert isinstance(sol, TransportSolution)
    np.testing.assert_array_almost_equal(sol.shipments.sum(axis=1), [20, 30])
    np.testing.assert_array_almost_equal(sol.shipments.sum(axis=0), [10, 25, 15])


def test_is_balanced():
    p = TransportationProblem([10, 20], [15, 15], [[1, 2], [3, 4]])
    assert bool(p.is_balanced()) is True

    p2 = TransportationProblem([10, 20], [10, 15], [[1, 2], [3, 4]])
    assert bool(p2.is_balanced()) is False


def test_excess_supply():
    sol = TransportationProblem(
        supply=[20, 10],
        demand=[15, 5],
        cost_matrix=[[4, 6], [3, 5]],
    ).solve()
    assert sol.status == "Optimal"
    np.testing.assert_array_almost_equal(sol.shipments.sum(axis=0), [15, 5])


def test_known_optimum_2x2():
    sol = TransportationProblem(
        supply=[10, 20],
        demand=[15, 15],
        cost_matrix=[[1, 4], [5, 2]],
    ).solve()
    assert sol.total_cost == pytest.approx(65.0)


def test_shape_validation_rejects_wrong_cost_matrix():
    with pytest.raises(ValueError):
        TransportationProblem(
            supply=[10, 20],
            demand=[5, 5, 5],
            cost_matrix=[[1, 2], [3, 4]],
        )


def test_shipments_array_shape():
    sol = TransportationProblem(
        supply=[10, 10, 10],
        demand=[15, 15],
        cost_matrix=[[1, 2], [3, 4], [5, 6]],
    ).solve()
    assert sol.shipments.shape == (3, 2)


def test_no_negative_shipments():
    sol = TransportationProblem(
        supply=[20, 30],
        demand=[25, 25],
        cost_matrix=[[1, 4], [3, 2]],
    ).solve()
    assert (sol.shipments >= -1e-9).all()
