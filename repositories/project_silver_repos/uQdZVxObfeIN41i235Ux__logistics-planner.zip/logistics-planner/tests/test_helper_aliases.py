"""Verify metaheuristics module re-exports are stable."""
import logistics_planner.metaheuristics as mh


def test_ga_exported():
    assert hasattr(mh, "GeneticAlgorithm")


def test_sa_exported():
    assert hasattr(mh, "SimulatedAnnealing")


def test_tabu_exported():
    assert hasattr(mh, "TabuSearch")


def test_tsp_solvers_exported():
    assert hasattr(mh, "solve_tsp_with_ga")
    assert hasattr(mh, "solve_tsp_with_sa")
    assert hasattr(mh, "solve_tsp_with_tabu")


def test_knapsack_solvers_exported():
    assert hasattr(mh, "solve_knapsack_with_ga")
    assert hasattr(mh, "solve_knapsack_with_sa")
