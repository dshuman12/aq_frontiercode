import numpy as np
import pytest

from logistics_planner.problems.shortest_path_problem import (
    ShortestPathProblem,
    ShortestPathSolution,
)


INF = float("inf")


def test_finds_path_in_simple_graph():
    cost = [[0, 2, INF, 1],
            [2, 0, 3, INF],
            [INF, 3, 0, 1],
            [1, INF, 1, 0]]
    sol = ShortestPathProblem(cost, 0, 2).solve()
    assert sol.status == "Optimal"
    assert sol.distance == pytest.approx(2.0)
    assert sol.path[0] == 0 and sol.path[-1] == 2


def test_returns_solution_object():
    sol = ShortestPathProblem([[0, 1], [1, 0]], 0, 1).solve()
    assert isinstance(sol, ShortestPathSolution)


def test_lp_and_dijkstra_agree():
    cost = [[0, 4, 1, INF],
            [INF, 0, 2, 1],
            [INF, 2, 0, 5],
            [INF, INF, INF, 0]]
    p = ShortestPathProblem(cost, 0, 3)
    djk = p.solve_dijkstra()
    lp = p.solve_lp()
    if djk.status == "Optimal" and lp.status == "Optimal":
        assert djk.distance == pytest.approx(lp.distance)


def test_negative_weight_raises():
    with pytest.raises(ValueError):
        ShortestPathProblem([[0, -1], [-1, 0]], 0, 1).solve_dijkstra()


def test_invalid_endpoints_raise():
    with pytest.raises(ValueError):
        ShortestPathProblem([[0, 1], [1, 0]], 0, 5)


def test_unreachable_target():
    cost = [[0, 1, INF],
            [1, 0, INF],
            [INF, INF, 0]]
    sol = ShortestPathProblem(cost, 0, 2).solve()
    assert sol.status == "Infeasible"
