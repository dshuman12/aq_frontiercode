import pytest

from logistics_planner.problems.linear_blending_problem import LinearBlending


def _simple_blending(Q=1):
    return LinearBlending(
        materials=["A", "B"],
        costs=[10, 15],
        property_matrix=[[6, 10]],
        lower_bounds=[6],
        upper_bounds=[10],
        output_quantity=Q,
    )


@pytest.mark.parametrize("Q", [1, 2, 5, 10])
def test_blending_various_quantities(Q):
    sol = _simple_blending(Q=Q).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_blending_three_materials():
    sol = LinearBlending(
        materials=["x", "y", "z"],
        costs=[5, 10, 15],
        property_matrix=[[1, 2, 3]],
        lower_bounds=[1.5],
        upper_bounds=[2.5],
        output_quantity=1,
    ).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_blending_solution_dimensions():
    sol = _simple_blending(Q=1).solve()
    if sol.status == "Optimal":
        assert sol.proportions.shape == (2,)


def test_blending_attributes():
    p = LinearBlending(
        materials=["a", "b"],
        costs=[1, 2],
        property_matrix=[[1, 2]],
        lower_bounds=[0],
        upper_bounds=[5],
        output_quantity=10,
    )
    assert p.m == 2
    assert p.k == 1
    assert p.output_quantity == 10


def test_blending_multiple_properties():
    sol = LinearBlending(
        materials=["A", "B"],
        costs=[3, 4],
        property_matrix=[[1, 2], [3, 1]],  # two properties
        lower_bounds=[1, 1],
        upper_bounds=[2, 3],
        output_quantity=1,
    ).solve()
    assert sol.status in ("Optimal", "Infeasible")


def test_blending_costs_stored_as_array():
    p = LinearBlending(
        materials=["a"],
        costs=[5],
        property_matrix=[[1]],
        lower_bounds=[0],
        upper_bounds=[10],
        output_quantity=1,
    )
    import numpy as np
    assert isinstance(p.costs, np.ndarray)


def test_blending_invalid_property_matrix():
    with pytest.raises(ValueError):
        LinearBlending(
            materials=["a", "b"],
            costs=[1, 2],
            property_matrix=[[1]],  # 1 col but 2 materials
            lower_bounds=[0],
            upper_bounds=[10],
            output_quantity=1,
        )


def test_blending_zero_cost_materials():
    sol = LinearBlending(
        materials=["a", "b"],
        costs=[0, 0],
        property_matrix=[[1, 2]],
        lower_bounds=[0],
        upper_bounds=[3],
        output_quantity=1,
    ).solve()
    assert sol.status in ("Optimal", "Infeasible")
