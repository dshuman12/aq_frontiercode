import numpy as np
import pytest

from logistics_planner.problems.capacitated_facility_location import CFLPSolution
from logistics_planner.problems.transportation_problem import TransportSolution
from logistics_planner.problems.zero_one_knapsack import KnapsackSolution
from logistics_planner.problems.assignment_problem import AssignmentSolution
from logistics_planner.problems.shortest_path_problem import ShortestPathSolution


def test_cflp_num_open():
    sol = CFLPSolution(status="Optimal", z_min=0.0,
                       open_facilities=[0, 2], allocation=np.zeros((3, 4)))
    assert sol.num_open() == 2


def test_transport_total_shipped():
    sol = TransportSolution(status="Optimal", total_cost=10.0,
                            shipments=np.array([[1, 2], [3, 4]]))
    assert sol.total_shipped() == 10


def test_knapsack_num_selected():
    sol = KnapsackSolution(status="Optimal", total_value=100, selected=[0, 1, 4])
    assert sol.num_selected() == 3


def test_assignment_as_dict():
    sol = AssignmentSolution(status="Optimal", total_cost=10,
                             assignment=[(0, 2), (1, 0), (2, 1)])
    d = sol.as_dict()
    assert d == {0: 2, 1: 0, 2: 1}


def test_shortest_path_num_hops():
    sol = ShortestPathSolution(status="Optimal", distance=10, path=[0, 1, 2, 3])
    assert sol.num_hops() == 3


def test_shortest_path_no_hops_for_empty():
    sol = ShortestPathSolution(status="Infeasible", distance=float("inf"), path=[])
    assert sol.num_hops() == 0
