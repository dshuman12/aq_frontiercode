import numpy as np
import pytest

from logistics_planner.game_theory import (
    MatrixGame, BimatrixGame,
    dominated_rows, dominated_columns, reduce_by_dominance,
)


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_matrix_game_random_solves(seed):
    rng = np.random.default_rng(seed)
    A = rng.integers(-5, 5, size=(3, 3))
    sol = MatrixGame(A).solve()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_matrix_game_pure_saddle_constant_matrix():
    payoff = [[3, 3, 3], [3, 3, 3], [3, 3, 3]]
    g = MatrixGame(payoff)
    assert g.has_pure_saddle_point()
    sp = g.saddle_point()
    assert sp is not None and sp[2] == 3


def test_bimatrix_pure_nash_count():
    A = [[1, 0], [0, 1]]
    B = [[1, 0], [0, 1]]
    g = BimatrixGame(A, B)
    eqs = g.pure_nash_equilibria()
    assert len(eqs) == 2


def test_bimatrix_no_pure_nash_in_matching_pennies():
    A = [[1, -1], [-1, 1]]
    B = [[-1, 1], [1, -1]]
    g = BimatrixGame(A, B)
    eqs = g.pure_nash_equilibria()
    assert len(eqs) == 0


def test_bimatrix_attributes():
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]
    g = BimatrixGame(A, B)
    assert g.m == 2
    assert g.n == 2


def test_bimatrix_best_responses_for_row():
    A = [[3, 1], [2, 4]]
    g = BimatrixGame(A, [[0, 0], [0, 0]])
    # if column player plays 0, row player's best is row 0 (payoff 3)
    assert 0 in g.best_responses_for_row(col_action=0)
    # if column player plays 1, row player's best is row 1 (payoff 4)
    assert 1 in g.best_responses_for_row(col_action=1)


def test_dominance_no_dominated_in_diverse_payoffs():
    payoff = [[1, 5], [3, 2]]
    assert dominated_rows(payoff) == []
    assert dominated_columns(payoff) == []


def test_reduce_by_dominance_returns_smaller_or_equal():
    payoff = np.array([[1, 1, 5], [2, 2, 6], [3, 3, 7]])
    reduced, _, _ = reduce_by_dominance(payoff)
    assert reduced.shape[0] <= payoff.shape[0]
    assert reduced.shape[1] <= payoff.shape[1]
