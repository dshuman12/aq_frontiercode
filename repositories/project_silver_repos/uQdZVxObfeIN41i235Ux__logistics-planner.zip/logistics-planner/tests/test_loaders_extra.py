import json
import os
import tempfile

import pytest
import numpy as np

from logistics_planner.data.loaders import (
    load_facility_instance,
    load_tsp_instance,
)


def _write(path, data):
    with open(path, "w") as f:
        json.dump(data, f)


def test_load_facility_returns_arrays():
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    _write(path, {
        "cost_facilities": [1, 2],
        "max_amounts": [10, 20],
        "cost_suppliers": [[1, 2], [3, 4]],
        "annual_demands": [5, 5],
    })
    try:
        cf, ma, cs, ad = load_facility_instance(path)
        assert isinstance(cf, np.ndarray)
        assert cs.shape == (2, 2)
    finally:
        os.remove(path)


def test_load_tsp_distance_matrix_shape():
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    _write(path, {"distance_matrix": [[0, 1, 2], [1, 0, 3], [2, 3, 0]]})
    try:
        D = load_tsp_instance(path)
        assert D.shape == (3, 3)
    finally:
        os.remove(path)
