import json
import os
import tempfile
from dataclasses import dataclass

import pytest

from logistics_planner.data.output import print_solution, export_csv, export_json


@dataclass
class _SimpleSolution:
    status: str
    total_cost: float


def test_export_json_roundtrip():
    sol = _SimpleSolution(status="Optimal", total_cost=42.5)
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    try:
        export_json(sol, path)
        with open(path) as f:
            data = json.load(f)
        assert data["status"] == "Optimal"
        assert data["total_cost"] == 42.5
    finally:
        os.remove(path)


def test_print_solution_prints_dict(capsys):
    print_solution({"status": "Optimal", "value": 10}, title="test")
    captured = capsys.readouterr()
    assert "test" in captured.out
    assert "Optimal" in captured.out


def test_print_solution_dataclass(capsys):
    sol = _SimpleSolution(status="Optimal", total_cost=10)
    print_solution(sol)
    captured = capsys.readouterr()
    assert "Optimal" in captured.out
