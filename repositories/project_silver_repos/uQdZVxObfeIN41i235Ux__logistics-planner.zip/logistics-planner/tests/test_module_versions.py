"""Sanity tests on the package itself."""
import logistics_planner


def test_version_attribute():
    assert hasattr(logistics_planner, "__version__")
    assert isinstance(logistics_planner.__version__, str)


def test_all_attribute():
    assert hasattr(logistics_planner, "__all__")
    assert "__version__" in logistics_planner.__all__
