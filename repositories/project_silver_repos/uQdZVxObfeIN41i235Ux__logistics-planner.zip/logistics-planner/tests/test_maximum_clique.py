import pytest

from logistics_planner.problems.maximum_clique_problem import (
    MaximumCliqueProblem,
    MaxCliqueSolution,
)


def _triangle_plus_isolated():
    # vertices 0,1,2 form a triangle; 3 is isolated
    return [
        [0, 1, 1, 0],
        [1, 0, 1, 0],
        [1, 1, 0, 0],
        [0, 0, 0, 0],
    ]


def test_greedy_runs():
    sol = MaximumCliqueProblem(_triangle_plus_isolated()).solve_greedy()
    assert isinstance(sol, MaxCliqueSolution)


def test_mip_runs():
    sol = MaximumCliqueProblem(_triangle_plus_isolated()).solve_mip()
    assert sol.status in ("Optimal", "Unbounded", "Infeasible")


def test_non_square_raises():
    with pytest.raises(ValueError):
        MaximumCliqueProblem([[0, 1, 0], [1, 0, 1]])


def test_self_loops_zeroed():
    adj = [[1, 1], [1, 1]]
    p = MaximumCliqueProblem(adj)
    assert p.adjacency[0, 0] == 0


def test_disconnected_graph():
    adj = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    sol = MaximumCliqueProblem(adj).solve_greedy()
    assert sol.size == 1
