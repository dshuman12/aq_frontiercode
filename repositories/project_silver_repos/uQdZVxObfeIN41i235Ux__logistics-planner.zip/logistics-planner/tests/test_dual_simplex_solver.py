import pytest
import numpy as np

from logistics_planner.solvers.dual_simplex import DualSimplex


def test_dual_simplex_init_validates():
    with pytest.raises(ValueError):
        DualSimplex(c=[1, 2, 3], A=[[1, 2]], b=[1])


def test_dual_simplex_attributes():
    ds = DualSimplex([1, 2, 0, 0], [[1, 1, 1, 0], [2, 1, 0, 1]], [4, 6])
    assert ds.m == 2
    assert ds.n == 4


def test_dual_simplex_b_length_check():
    with pytest.raises(ValueError):
        DualSimplex(c=[1, 2], A=[[1, 1]], b=[1, 2])
