import pytest

from logistics_planner.cli import build_parser


def test_facility_subcommand_takes_input():
    parser = build_parser()
    args = parser.parse_args(["facility", "/tmp/x.json"])
    assert args.command == "facility"
    assert args.input == "/tmp/x.json"


def test_transport_subcommand():
    parser = build_parser()
    args = parser.parse_args(["transport", "/tmp/x.json"])
    assert args.command == "transport"


def test_lot_sizing_initial_default():
    parser = build_parser()
    args = parser.parse_args(["lot-sizing", "/tmp/x.json"])
    assert args.initial == 0.0


def test_tsp_default_method():
    parser = build_parser()
    args = parser.parse_args(["tsp", "/tmp/x.json"])
    assert args.method == "mip"
    assert args.start == 0


def test_diet_subcommand():
    parser = build_parser()
    args = parser.parse_args(["diet", "/tmp/x.json"])
    assert args.command == "diet"


def test_blending_subcommand():
    parser = build_parser()
    args = parser.parse_args(["blending", "/tmp/x.json"])
    assert args.command == "blending"
