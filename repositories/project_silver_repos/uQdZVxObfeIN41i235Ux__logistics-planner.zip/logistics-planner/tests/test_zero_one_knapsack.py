import pytest

from logistics_planner.problems.zero_one_knapsack import (
    ZeroOneKnapsack,
    KnapsackSolution,
)


def test_solve_returns_status():
    sol = ZeroOneKnapsack(values=[60, 100, 120], weights=[10, 20, 30], capacity=50).solve()
    assert sol.status == "Optimal"


def test_returns_solution_object():
    sol = ZeroOneKnapsack([1, 2], [1, 1], 1).solve()
    assert isinstance(sol, KnapsackSolution)


def test_empty_capacity():
    sol = ZeroOneKnapsack([10, 20, 30], [1, 1, 1], 0).solve()
    assert sol.total_value == 0
    assert sol.selected == []


def test_returns_status_optimal_for_simple():
    sol = ZeroOneKnapsack([5, 10, 15], [1, 1, 1], 100).solve()
    assert sol.status == "Optimal"
    assert sol.total_value > 0


def test_negative_weights_raise():
    with pytest.raises(ValueError):
        ZeroOneKnapsack([1, 2], [-1, 1], 5)


def test_mip_runs():
    p = ZeroOneKnapsack([10, 20, 30, 40], [2, 3, 5, 7], 10)
    mip = p.solve_mip()
    assert mip.status in ("Optimal", "Unbounded", "Infeasible")
