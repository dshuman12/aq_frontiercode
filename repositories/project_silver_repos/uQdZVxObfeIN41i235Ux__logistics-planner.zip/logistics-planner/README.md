# logistics-planner

LP / MIP / metaheuristic solvers for classic operations research problems.

## What's in here

**Problems** (`logistics_planner.problems`):

- Capacitated facility location
- Transportation (handles unbalanced cases)
- Capacitated lot sizing (multi-period production)
- Linear blending
- Stigler's diet
- Travelling salesman (MIP + nearest neighbor)
- Assignment problem (Hungarian + LP)
- Shortest path (Dijkstra + LP)
- Max flow (Edmonds-Karp + LP)
- Min-cost network flow
- 0/1 knapsack (DP + MIP)
- Multi-dimensional knapsack
- Set covering (MIP + greedy)
- Set partitioning
- Bin packing (MIP + first-fit-decreasing)
- Vehicle routing (MIP + Clarke-Wright)
- Job shop scheduling (disjunctive MIP)
- Quadratic assignment (linearized MIP + 2-swap)
- 1D cutting stock
- p-median facility location
- Graph coloring (MIP + Welsh-Powell)
- Maximum clique (MIP + greedy)

**Metaheuristics** (`logistics_planner.metaheuristics`):

- Generic genetic algorithm framework
- Generic simulated annealing
- Generic tabu search
- TSP and knapsack applications

**Game theory** (`logistics_planner.game_theory`):

- Two-player zero-sum matrix games via LP
- Bimatrix (general-sum) games + pure Nash equilibria
- Iterated dominance reduction

**Solvers** (`logistics_planner.solvers`):

- Pure-Python revised simplex
- Big-M and two-phase simplex
- Dual simplex
- Generic branch-and-bound
- Cutting planes (Gomory-style)
- Column generation framework
- Lagrangian relaxation (subgradient)
- Thin PuLP wrapper

**Analysis** (`logistics_planner.analysis`):

- Sensitivity report (shadow prices, reduced costs, slacks)
- Dual LP construction
- Complementary slackness checks

**Benchmark** (`logistics_planner.benchmark`):

- Random instance generators per problem
- Timing helpers and comparison reports

**Other**:

- `data/` — JSON instance loaders + solution exporters
- `visualization/` — matplotlib helpers for TSP tours and flow networks
- `cli.py` — `python -m logistics_planner.cli ...`

## Setup

```
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Running stuff

```
pytest tests/
python examples/distribution_center_selection.py
python examples/tsp_metaheuristics_comparison.py
python -m logistics_planner.cli lot-sizing my_instance.json
```
