"""Compare GA, SA, and Tabu search on a small TSP instance."""
import numpy as np
from logistics_planner.benchmark import random_tsp_instance, compare_methods, format_report
from logistics_planner.metaheuristics import (
    solve_tsp_with_ga, solve_tsp_with_sa, solve_tsp_with_tabu,
    GAConfig, SAConfig, TabuConfig,
)


coords, D = random_tsp_instance(n=12, seed=42)


def run_ga():
    tour, dist = solve_tsp_with_ga(D, seed=42, config=GAConfig(generations=100, seed=42))
    return dist, {"tour_len": len(tour)}


def run_sa():
    tour, dist = solve_tsp_with_sa(D, seed=42)
    return dist, {"tour_len": len(tour)}


def run_tabu():
    tour, dist = solve_tsp_with_tabu(D, seed=42)
    return dist, {"tour_len": len(tour)}


methods = [
    ("genetic_algorithm", run_ga),
    ("simulated_annealing", run_sa),
    ("tabu_search", run_tabu),
]

report = compare_methods("tsp_n12", methods, minimize=True)
print(format_report(report))

best = report.best_by_objective(minimize=True)
print(f"\nbest method: {best.name} (distance {best.objective:.2f})")
gap = report.gap_to_best(minimize=True)
for name, g in gap.items():
    print(f"  {name}: {g:.1f}% gap")
