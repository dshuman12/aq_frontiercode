"""Assign 4 workers to 4 jobs at minimum total cost."""
import numpy as np
from logistics_planner.problems.assignment_problem import AssignmentProblem


cost = np.array([
    [9, 2, 7, 8],
    [6, 4, 3, 7],
    [5, 8, 1, 8],
    [7, 6, 9, 4],
])

sol = AssignmentProblem(cost).solve()

print(f"Status: {sol.status}")
print(f"Total cost: {sol.total_cost}")
for worker, job in sol.assignment:
    print(f"  worker {worker} -> job {job}  (cost {cost[worker, job]})")
