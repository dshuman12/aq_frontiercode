"""Push as much flow as possible through a 6-node graph."""
import numpy as np
from logistics_planner.problems.max_flow_problem import MaxFlowProblem


# classic CLRS-style network
cap = np.array([
    [0, 16, 13, 0, 0, 0],
    [0, 0, 10, 12, 0, 0],
    [0, 4, 0, 0, 14, 0],
    [0, 0, 9, 0, 0, 20],
    [0, 0, 0, 7, 0, 4],
    [0, 0, 0, 0, 0, 0],
])

sol = MaxFlowProblem(cap, source=0, sink=5).solve()

print(f"Status: {sol.status}")
print(f"Max flow: {sol.max_flow_value}")
print("Flow matrix:")
print(sol.flow_matrix)
