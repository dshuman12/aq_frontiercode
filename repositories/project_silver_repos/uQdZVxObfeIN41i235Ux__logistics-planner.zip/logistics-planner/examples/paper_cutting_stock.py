"""Cutting paper rolls of length 100 to satisfy customer orders."""
from logistics_planner.problems.cutting_stock_problem import CuttingStockProblem


roll_length = 100
item_widths = [22, 25, 35, 40, 45]
demands = [25, 20, 15, 10, 8]

csp = CuttingStockProblem(roll_length, item_widths, demands)
sol = csp.solve()

print(f"Status: {sol.status}")
print(f"Rolls used: {sol.rolls_used}")
print(f"FFD lower bound: {csp.first_fit_decreasing_lower_bound()} rolls")
print("Patterns used:")
for pattern, count in sol.pattern_counts.items():
    parts = []
    for i, c in enumerate(pattern):
        if c > 0:
            parts.append(f"{c} x {item_widths[i]}cm")
    used = sum(c * w for c, w in zip(pattern, item_widths))
    print(f"  x{count}: {' + '.join(parts)}  (uses {used}/{roll_length}cm)")
