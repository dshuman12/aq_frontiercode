"""Tabu search on a small TSP."""
import numpy as np
from logistics_planner.metaheuristics import solve_tsp_with_tabu


D = np.array([
    [0, 10, 15, 20, 25],
    [10, 0, 35, 25, 30],
    [15, 35, 0, 30, 20],
    [20, 25, 30, 0, 15],
    [25, 30, 20, 15, 0],
])

tour, dist = solve_tsp_with_tabu(D, seed=42)
print(f"Tour: {tour}")
print(f"Distance: {dist:.2f}")
