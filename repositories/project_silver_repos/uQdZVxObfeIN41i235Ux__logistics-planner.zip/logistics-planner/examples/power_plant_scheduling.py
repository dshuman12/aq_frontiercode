"""Schedule production for a single facility over a 6-period horizon.

This uses the capacitated lot sizing model. Demand varies by period, capacity is
fixed, and we trade off setup costs vs holding inventory.
"""

import numpy as np
from logistics_planner.problems.capacitated_lot_sizing_problem import CapacitatedLotSizing


demand = np.array([40, 60, 75, 25, 50, 80])
setup_costs = np.array([400] * 6)
holding_costs = np.array([2] * 6)
production_costs = np.array([5] * 6)
capacity = 100

problem = CapacitatedLotSizing(demand, setup_costs, holding_costs, production_costs, capacity)
solution = problem.solve(initial_inventory=10)

print(f"Status: {solution.status}")
print(f"Total cost: {solution.total_cost}")
print(f"Production per period: {solution.production}")
print(f"End-of-period inventory: {solution.inventory}")
print(f"Periods with setup: {[i+1 for i, s in enumerate(solution.setup) if s]}")
