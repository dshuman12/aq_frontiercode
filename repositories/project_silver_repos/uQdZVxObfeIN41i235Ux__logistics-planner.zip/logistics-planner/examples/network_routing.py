"""Find shortest path through a small road network."""
import numpy as np
from logistics_planner.problems.shortest_path_problem import ShortestPathProblem


INF = float("inf")

# 6 cities, distances in km (INF = no direct road)
cost = np.array([
    [0,    7,    9,    INF,  INF,  14],
    [7,    0,    10,   15,   INF,  INF],
    [9,    10,   0,    11,   INF,  2],
    [INF,  15,   11,   0,    6,    INF],
    [INF,  INF,  INF,  6,    0,    9],
    [14,   INF,  2,    INF,  9,    0],
])

sol = ShortestPathProblem(cost, source=0, target=4).solve()

print(f"Status: {sol.status}")
print(f"Distance: {sol.distance} km")
print(f"Path: {' -> '.join(map(str, sol.path))}")
