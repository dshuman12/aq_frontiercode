"""Solve a knapsack with simulated annealing."""
from logistics_planner.metaheuristics import solve_knapsack_with_sa


values = [60, 100, 120, 80, 50, 90, 110, 70]
weights = [10, 20, 30, 15, 8, 25, 28, 12]
capacity = 60

bits, val = solve_knapsack_with_sa(values, weights, capacity, seed=42)
print(f"Total value: {val}")
print(f"Items chosen: {[i for i, b in enumerate(bits) if b]}")
