"""Quadratic assignment - place 4 facilities at 4 locations."""
from logistics_planner.problems.quadratic_assignment_problem import QuadraticAssignmentProblem


# flow between facilities (units transferred per period)
flow = [
    [0, 5, 2, 4],
    [5, 0, 3, 0],
    [2, 3, 0, 0],
    [4, 0, 0, 0],
]

# distance between locations (km)
distance = [
    [0, 22, 53, 53],
    [22, 0, 40, 62],
    [53, 40, 0, 55],
    [53, 62, 55, 0],
]

sol = QuadraticAssignmentProblem(flow, distance).solve_local_search(seed=42)

print(f"Status: {sol.status}")
print(f"Total cost: {sol.total_cost}")
for facility, location in enumerate(sol.permutation):
    print(f"  facility {facility} -> location {location}")
