"""Compute a min-cost daily meal plan."""
from logistics_planner.problems.stiglers_diet_problem import StiglersDiet


foods = ["bread", "milk", "egg", "rice", "chicken", "spinach"]
costs = [1.0, 2.5, 0.4, 1.5, 5.0, 1.8]

# nutrient_matrix[r][j] = amount of nutrient r per unit of food j
# rows: calories, protein, vitamin_a (scaled), iron
nutrient_matrix = [
    [80, 50, 75, 130, 250, 25],
    [3, 9, 6, 2, 30, 3],
    [0, 8, 5, 0, 0, 50],
    [1, 0, 1, 0, 1, 4],
]
requirements = [2000, 50, 30, 8]

sol = StiglersDiet(foods, costs, nutrient_matrix, requirements).solve()

print(f"Status: {sol.status}")
print(f"Daily food cost: {sol.total_cost:.2f}")
for food, qty in sol.quantities.items():
    if qty and qty > 1e-6:
        print(f"  {food}: {qty:.2f}")
