"""Plan the shortest delivery route through 6 stops, returning to the depot.

Compares the exact MIP tour against the nearest-neighbor heuristic.
"""

import numpy as np
from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman


# symmetric distances (km) between depot (0) and 5 stops
distance_matrix = np.array([
    [0, 12, 18, 25, 14, 22],
    [12, 0, 9, 15, 11, 17],
    [18, 9, 0, 8, 13, 10],
    [25, 15, 8, 0, 16, 6],
    [14, 11, 13, 16, 0, 12],
    [22, 17, 10, 6, 12, 0],
])

problem = TravelingSalesman(distance_matrix)

heuristic = problem.solve_nearest_neighbor(start=0)
print("Nearest-neighbor:")
print(f"  distance: {heuristic.total_distance}")
print(f"  tour: {heuristic.tour}")

exact = problem.solve_mip()
print("Exact (MIP):")
print(f"  status: {exact.status}")
print(f"  distance: {exact.total_distance}")
print(f"  tour: {exact.tour}")
