"""Find shortest path through road network from source to sink."""
import numpy as np
from logistics_planner.problems.shortest_path_problem import ShortestPathProblem


INF = float("inf")
n = 8
cost = np.full((n, n), INF)
for i in range(n):
    cost[i, i] = 0

# road network edges
edges = [
    (0, 1, 4), (0, 2, 8),
    (1, 2, 11), (1, 3, 8),
    (2, 4, 7), (2, 5, 1),
    (3, 4, 2), (3, 6, 7),
    (4, 5, 6), (4, 7, 4),
    (5, 7, 2),
    (6, 7, 14),
]
for a, b, w in edges:
    cost[a, b] = cost[b, a] = w

sol = ShortestPathProblem(cost, source=0, target=7).solve()
print(f"Status:   {sol.status}")
print(f"Distance: {sol.distance} km")
print(f"Path:     {' -> '.join(map(str, sol.path))}")
