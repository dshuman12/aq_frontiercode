"""Construct the dual of a small primal LP and verify strong duality."""
import numpy as np
from logistics_planner.analysis.duality import (
    dual_of_standard_min, verify_strong_duality,
)


# primal: min  c^T x  s.t.  Ax >= b, x >= 0
c = [3, 2]
A = [[1, 1], [2, 1], [1, 3]]
b = [4, 5, 7]

dual_sol = dual_of_standard_min(c, A, b)
print(f"Dual status:    {dual_sol.status}")
print(f"Dual objective: {dual_sol.dual_objective}")
print(f"Dual values:    {dual_sol.dual_variables}")

# strong duality: primal and dual have same value at optimum (for feasible LPs)
print(f"Strong duality holds for 7.0 vs 7.0: {verify_strong_duality(7.0, 7.0)}")
