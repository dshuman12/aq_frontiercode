"""Place 3 clinics among 6 candidate locations to minimize total weighted travel."""
import numpy as np
from logistics_planner.problems.p_median_problem import PMedianProblem


# rows = demand neighborhoods, cols = candidate clinic sites
distances = np.array([
    [2, 4, 8, 6, 9, 5],
    [3, 1, 6, 7, 4, 8],
    [9, 8, 2, 3, 5, 4],
    [4, 5, 3, 1, 7, 6],
    [7, 6, 4, 8, 2, 3],
    [5, 7, 9, 6, 8, 1],
])

# population at each demand point (weights)
demands = [120, 80, 200, 150, 90, 110]

problem = PMedianProblem(distances, demands, p=3)
sol = problem.solve()

print(f"Status: {sol.status}")
print(f"Total weighted travel: {sol.total_cost}")
print(f"Open clinic sites: {sol.open_facilities}")
print("Assignments:")
for d, f in sol.assignment:
    print(f"  neighborhood {d} (pop {demands[d]}) -> site {f} (dist {distances[d, f]})")
