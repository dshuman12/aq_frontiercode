"""Multi-vehicle delivery routing using Clarke-Wright savings."""
import numpy as np
from logistics_planner.problems.vehicle_routing_problem import VehicleRoutingProblem


# 0 is depot, 1-7 are customer locations (random-ish coords)
coords = np.array([
    [50, 50],   # depot
    [10, 10],
    [10, 80],
    [80, 80],
    [80, 10],
    [40, 90],
    [60, 20],
    [30, 60],
])

n = len(coords)
D = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        if i != j:
            D[i, j] = float(np.linalg.norm(coords[i] - coords[j]))

demands = [0, 6, 7, 5, 4, 3, 8, 6]

problem = VehicleRoutingProblem(D, demands, num_vehicles=3, capacity=20)
sol = problem.solve()

print(f"Status: {sol.status}")
print(f"Total distance: {sol.total_distance:.2f}")
print(f"Routes: {len(sol.routes)}")
for i, r in enumerate(sol.routes):
    load = sum(demands[c] for c in r[1:-1])
    print(f"  vehicle {i}: {' -> '.join(map(str, r))}  (load={load})")
