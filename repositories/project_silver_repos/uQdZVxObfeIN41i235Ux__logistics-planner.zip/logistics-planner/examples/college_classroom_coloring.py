"""Schedule classes by graph coloring - colors are time slots, edges are
overlapping student rosters."""
from logistics_planner.problems.graph_coloring_problem import GraphColoringProblem


# 6 classes; edge means at least one student is in both classes
adj = [
    [0, 1, 1, 0, 1, 0],
    [1, 0, 0, 1, 0, 1],
    [1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 1],
    [0, 1, 0, 1, 1, 0],
]
classes = ["math", "physics", "english", "art", "history", "biology"]

sol = GraphColoringProblem(adj).solve_greedy()

print(f"Status: {sol.status}")
print(f"Time slots needed: {sol.chromatic_number}")
for v, color in sol.coloring.items():
    print(f"  {classes[v]} -> slot {color}")
