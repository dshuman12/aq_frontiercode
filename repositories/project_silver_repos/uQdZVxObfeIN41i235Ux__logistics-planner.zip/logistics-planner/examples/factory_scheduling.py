"""Job shop scheduling - 3 jobs on 3 machines."""
from logistics_planner.problems.job_shop_scheduling import JobShopScheduling


# job 0: machine 0 (duration 3), machine 1 (2), machine 2 (2)
# job 1: machine 0 (2), machine 2 (1), machine 1 (4)
# job 2: machine 1 (4), machine 2 (3)
processing_times = [
    [3, 2, 2],
    [2, 1, 4],
    [4, 3],
]
machine_orders = [
    [0, 1, 2],
    [0, 2, 1],
    [1, 2],
]

js = JobShopScheduling(processing_times, machine_orders)
sol = js.solve()

print(f"Status: {sol.status}")
print(f"Makespan: {sol.makespan:.2f}")
print("Schedule:")
for job, machine, start, end in sorted(sol.schedule, key=lambda r: r[2]):
    print(f"  job {job} on machine {machine}: [{start:.1f}, {end:.1f}]")
