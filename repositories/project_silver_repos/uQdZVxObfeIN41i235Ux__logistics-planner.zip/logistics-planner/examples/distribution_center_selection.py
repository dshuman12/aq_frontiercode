"""Pick which distribution centers to open and how to route units to retailers.

Three candidate sites with different fixed costs and capacities; four retailers
with annual demand. Solve the CFLP and print the open sites + shipping plan.
"""

import numpy as np
from logistics_planner.problems.capacitated_facility_location import CapacitatedFacilityLocation


cost_facilities = np.array([100000, 80000, 95000])
max_amounts = np.array([800, 600, 700])

# transport cost from site i to retailer j
cost_suppliers = np.array([
    [4, 6, 9, 7],
    [5, 4, 7, 8],
    [6, 5, 6, 6],
])

annual_demands = np.array([300, 250, 400, 200])

problem = CapacitatedFacilityLocation(cost_facilities, max_amounts, cost_suppliers, annual_demands)
solution = problem.solve()

print(f"Status: {solution.status}")
print(f"Total cost: {solution.z_min}")
print(f"Open sites: {solution.open_facilities}")
print("Shipments:")
print(solution.allocation)
