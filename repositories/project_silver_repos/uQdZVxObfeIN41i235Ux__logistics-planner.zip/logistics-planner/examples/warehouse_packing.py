"""Pack items into bins of fixed capacity."""
from logistics_planner.problems.bin_packing_problem import BinPackingProblem


item_sizes = [4, 8, 1, 4, 2, 1, 9, 6, 3, 5]
bin_capacity = 10

p = BinPackingProblem(item_sizes=item_sizes, bin_capacity=bin_capacity)

ffd = p.solve_first_fit_decreasing()
print(f"FFD heuristic: {ffd.bins_used} bins")

opt = p.solve()
print(f"Optimal: {opt.bins_used} bins")
print("Assignment:")
bins_to_items = {}
for item, bin_k in opt.assignment:
    bins_to_items.setdefault(bin_k, []).append(item)
for bin_k, items in sorted(bins_to_items.items()):
    sizes = [item_sizes[i] for i in items]
    print(f"  bin {bin_k}: items {items} (sizes {sizes}, total {sum(sizes)})")
