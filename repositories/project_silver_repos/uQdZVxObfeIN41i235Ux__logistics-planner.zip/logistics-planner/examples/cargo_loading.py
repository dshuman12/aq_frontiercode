"""Maximize value of items loaded into a container."""
from logistics_planner.problems.zero_one_knapsack import ZeroOneKnapsack


items = [
    ("electronics", 60, 10),
    ("books", 100, 20),
    ("furniture", 120, 30),
    ("clothing", 50, 15),
    ("appliances", 90, 25),
]
values = [v for _, v, _ in items]
weights = [w for _, _, w in items]
capacity = 50

sol = ZeroOneKnapsack(values=values, weights=weights, capacity=capacity).solve()

print(f"Status: {sol.status}")
print(f"Total value loaded: {sol.total_value}")
print("Items:")
for i in sol.selected:
    name, v, w = items[i]
    print(f"  {name}  (value={v}, weight={w})")
