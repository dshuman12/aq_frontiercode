"""Solve a 2-player zero-sum matrix game by LP."""
import numpy as np
from logistics_planner.game_theory import MatrixGame


# row player picks a row, column player picks a column.
# entry is row player's payoff (col player loses that amount).
payoff = np.array([
    [3, -1, 4],
    [-2, 5, -3],
    [1, 2, 0],
])

g = MatrixGame(payoff)

if g.has_pure_saddle_point():
    sp = g.saddle_point()
    print(f"Pure saddle point at {sp[:2]} with value {sp[2]}")
else:
    print("No pure saddle point, solving for mixed strategies")
    sol = g.solve()
    print(f"Status: {sol.status}")
    print(f"Game value: {sol.value}")
    print(f"Row strategy: {sol.row_strategy}")
    print(f"Col strategy: {sol.col_strategy}")
