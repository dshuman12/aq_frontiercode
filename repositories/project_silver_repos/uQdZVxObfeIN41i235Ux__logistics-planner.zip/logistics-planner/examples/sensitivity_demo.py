"""Show shadow prices and reduced costs after solving an LP."""
from pulp import LpVariable, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve
from logistics_planner.analysis import sensitivity_report


# min  2x + 3y
# s.t. x + y >= 4    (capacity)
#      x >= 1        (min usage)
#      y >= 0        (non-negativity is automatic)
prob = build_problem("sensitivity_demo", sense="min")
x = LpVariable("x", lowBound=0)
y = LpVariable("y", lowBound=0)
prob += 2 * x + 3 * y
prob += x + y >= 4
prob += x >= 1

solve(prob)
report = sensitivity_report(prob)

print(f"Objective:        {report.objective}")
print(f"Variable values:  {report.variable_values}")
print(f"Shadow prices:    {report.shadow_prices}")
print(f"Reduced costs:    {report.reduced_costs}")
print(f"Slacks:           {report.slacks}")
