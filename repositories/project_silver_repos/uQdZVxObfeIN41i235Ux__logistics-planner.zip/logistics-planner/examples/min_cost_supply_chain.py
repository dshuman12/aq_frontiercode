"""Min-cost flow through a 4-node supply chain network."""
import numpy as np
from logistics_planner.problems.min_cost_flow_problem import MinCostFlowProblem


# nodes: 0 = supplier, 1 = warehouse A, 2 = warehouse B, 3 = retailer
cost = np.array([
    [0, 2, 4, 0],
    [0, 0, 1, 5],
    [0, 0, 0, 3],
    [0, 0, 0, 0],
])
capacity = np.array([
    [0, 50, 50, 0],
    [0, 0, 30, 30],
    [0, 0, 0, 50],
    [0, 0, 0, 0],
])
supplies = [40, 0, 0, -40]

sol = MinCostFlowProblem(cost, capacity, supplies).solve()

print(f"Status: {sol.status}")
print(f"Total cost: {sol.total_cost}")
print("Flows:")
print(sol.flow_matrix)
