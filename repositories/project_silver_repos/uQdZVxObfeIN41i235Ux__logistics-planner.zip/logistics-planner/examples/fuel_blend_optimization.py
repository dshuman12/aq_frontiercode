"""Blend three crude oils to make 1000 units of gasoline.

Each crude has a per-unit cost and known octane / sulfur content. The output
must meet octane >= 90 and sulfur <= 0.5%.
"""

import numpy as np
from logistics_planner.problems.linear_blending_problem import LinearBlending


materials = ["crude_A", "crude_B", "crude_C"]
costs = np.array([45, 60, 50])  # $/unit

# row 0 = octane (higher better), row 1 = sulfur (lower better)
property_matrix = np.array([
    [85, 95, 88],   # octane per unit
    [0.6, 0.3, 0.5],  # sulfur per unit
])

lower_bounds = np.array([90, 0.0])
upper_bounds = np.array([100, 0.5])
output_quantity = 1000

problem = LinearBlending(
    materials, costs, property_matrix, lower_bounds, upper_bounds, output_quantity
)
solution = problem.solve()

print(f"Status: {solution.status}")
print(f"Total cost: {solution.total_cost}")
for name, qty in zip(materials, solution.proportions):
    print(f"  {name}: {qty:.2f}")
