"""Set covering for emergency response coverage."""
from logistics_planner.problems.set_covering_problem import SetCoveringProblem


# columns are candidate fire stations, rows are neighborhoods
# entry = 1 if that station can cover that neighborhood within response time
coverage = [
    [1, 0, 1, 0, 0, 1],
    [1, 1, 0, 0, 0, 0],
    [0, 1, 1, 0, 1, 0],
    [0, 0, 0, 1, 1, 0],
    [0, 0, 1, 1, 0, 1],
    [1, 0, 0, 0, 1, 1],
]
costs = [50, 40, 60, 30, 45, 55]  # building cost per station

sol = SetCoveringProblem(costs, coverage).solve()
print(f"Status: {sol.status}")
print(f"Total building cost: {sol.total_cost}")
print(f"Stations to build: {sol.selected_sets}")
