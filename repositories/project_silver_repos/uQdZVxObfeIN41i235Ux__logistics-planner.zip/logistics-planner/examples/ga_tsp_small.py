"""GA on a small TSP instance."""
import numpy as np
from logistics_planner.metaheuristics import solve_tsp_with_ga, GAConfig


coords = np.array([[0, 0], [1, 5], [4, 7], [9, 2], [6, 6], [3, 3]])
n = len(coords)
D = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        if i != j:
            D[i, j] = np.linalg.norm(coords[i] - coords[j])

tour, dist = solve_tsp_with_ga(D, seed=42, config=GAConfig(generations=80, seed=42))
print(f"Tour: {tour}")
print(f"Distance: {dist:.2f}")
