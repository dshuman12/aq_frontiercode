"""Run every example in examples/ and report pass/fail."""
import subprocess
import os
import sys


def main():
    examples_dir = os.path.join(os.path.dirname(__file__), "..", "examples")
    files = sorted(f for f in os.listdir(examples_dir) if f.endswith(".py"))

    passed = []
    failed = []
    for f in files:
        path = os.path.join(examples_dir, f)
        result = subprocess.run(
            [sys.executable, path],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            passed.append(f)
            print(f"OK   {f}")
        else:
            failed.append((f, result.stderr))
            print(f"FAIL {f}")

    print()
    print(f"{len(passed)}/{len(files)} examples passed")
    if failed:
        print()
        for name, err in failed:
            print(f"--- {name} ---")
            print(err)
        sys.exit(1)


if __name__ == "__main__":
    main()
