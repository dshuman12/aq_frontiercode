"""Sanity-check that all top-level package imports work."""
import importlib
import sys


MODULES = [
    "logistics_planner",
    "logistics_planner.problems.capacitated_facility_location",
    "logistics_planner.problems.transportation_problem",
    "logistics_planner.problems.capacitated_lot_sizing_problem",
    "logistics_planner.problems.linear_blending_problem",
    "logistics_planner.problems.stiglers_diet_problem",
    "logistics_planner.problems.traveling_salesman_problem",
    "logistics_planner.problems.assignment_problem",
    "logistics_planner.problems.shortest_path_problem",
    "logistics_planner.problems.max_flow_problem",
    "logistics_planner.problems.min_cost_flow_problem",
    "logistics_planner.problems.zero_one_knapsack",
    "logistics_planner.problems.multi_dimensional_knapsack",
    "logistics_planner.problems.set_covering_problem",
    "logistics_planner.problems.set_partitioning_problem",
    "logistics_planner.problems.bin_packing_problem",
    "logistics_planner.problems.vehicle_routing_problem",
    "logistics_planner.problems.job_shop_scheduling",
    "logistics_planner.problems.quadratic_assignment_problem",
    "logistics_planner.problems.cutting_stock_problem",
    "logistics_planner.problems.p_median_problem",
    "logistics_planner.problems.graph_coloring_problem",
    "logistics_planner.problems.maximum_clique_problem",
    "logistics_planner.solvers.lp_solver",
    "logistics_planner.solvers.simplex",
    "logistics_planner.solvers.big_m_simplex",
    "logistics_planner.solvers.two_phase_simplex",
    "logistics_planner.solvers.dual_simplex",
    "logistics_planner.solvers.branch_and_bound",
    "logistics_planner.solvers.lagrangian",
    "logistics_planner.solvers.column_generation",
    "logistics_planner.solvers.cutting_planes",
    "logistics_planner.metaheuristics",
    "logistics_planner.game_theory",
    "logistics_planner.analysis",
    "logistics_planner.benchmark",
    "logistics_planner.visualization",
    "logistics_planner.data.loaders",
    "logistics_planner.data.output",
    "logistics_planner.utils",
    "logistics_planner.cli",
]


def main():
    failures = []
    for mod in MODULES:
        try:
            importlib.import_module(mod)
            print(f"OK   {mod}")
        except Exception as e:
            failures.append((mod, e))
            print(f"FAIL {mod}: {e}")

    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
