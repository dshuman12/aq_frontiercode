"""Knapsack benchmark: DP vs MIP vs GA vs SA."""
from logistics_planner.benchmark import (
    random_knapsack_instance, compare_methods, format_report,
)
from logistics_planner.problems.zero_one_knapsack import ZeroOneKnapsack
from logistics_planner.metaheuristics import (
    solve_knapsack_with_ga, solve_knapsack_with_sa, GAConfig,
)


def bench(n=10, seed=42):
    v, w, c = random_knapsack_instance(n, seed=seed)

    methods = [
        ("dp",   lambda: (-ZeroOneKnapsack(v, w, c).solve_dp().total_value, {})),
        ("mip",  lambda: (-ZeroOneKnapsack(v, w, c).solve_mip().total_value, {})),
        ("ga",   lambda: (-solve_knapsack_with_ga(v, w, c, seed=seed,
                                                  config=GAConfig(generations=50, seed=seed))[1], {})),
        ("sa",   lambda: (-solve_knapsack_with_sa(v, w, c, seed=seed)[1], {})),
    ]
    # negative because compare_methods minimizes by default; here we want max value
    report = compare_methods(f"knapsack_n{n}", methods, minimize=True)
    return report


if __name__ == "__main__":
    for n in (5, 8, 12):
        print(format_report(bench(n)))
        print()
