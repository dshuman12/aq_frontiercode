"""Quick TSP benchmark across method types and a few sizes."""
import sys
from logistics_planner.benchmark import (
    random_tsp_instance, compare_methods, format_report,
)
from logistics_planner.metaheuristics import (
    solve_tsp_with_ga, solve_tsp_with_sa, solve_tsp_with_tabu,
    GAConfig, SAConfig, TabuConfig,
)
from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman


def bench(n, seed=42):
    _, D = random_tsp_instance(n, seed=seed)
    methods = [
        ("nearest_neighbor",
            lambda: (TravelingSalesman(D).solve_nearest_neighbor().total_distance, {})),
        ("genetic_algorithm",
            lambda: (solve_tsp_with_ga(D, seed=seed,
                                       config=GAConfig(generations=50, seed=seed))[1], {})),
        ("simulated_annealing",
            lambda: (solve_tsp_with_sa(D, seed=seed)[1], {})),
        ("tabu_search",
            lambda: (solve_tsp_with_tabu(D, seed=seed)[1], {})),
    ]
    return compare_methods(f"tsp_n{n}", methods, minimize=True)


def main():
    sizes = [int(a) for a in sys.argv[1:]] or [6, 8, 10]
    for n in sizes:
        print(format_report(bench(n)))
        print()


if __name__ == "__main__":
    main()
