"""Print all problem class names."""
import importlib
import pkgutil
import logistics_planner.problems as pkg


for mod_info in pkgutil.iter_modules(pkg.__path__):
    mod = importlib.import_module(f"{pkg.__name__}.{mod_info.name}")
    classes = [name for name in dir(mod)
               if name[0].isupper() and not name.endswith("Solution")]
    for c in classes:
        if c not in ("__builtins__",):
            obj = getattr(mod, c)
            if isinstance(obj, type) and obj.__module__ == mod.__name__:
                print(f"{mod_info.name}.{c}")
