"""Quick solve one CFLP instance from JSON file."""
import sys
import json
from logistics_planner.data.loaders import load_facility_instance
from logistics_planner.problems.capacitated_facility_location import CapacitatedFacilityLocation


if len(sys.argv) < 2:
    print("usage: quick_solve.py <cflp.json>")
    sys.exit(1)

cf, ma, cs, ad = load_facility_instance(sys.argv[1])
sol = CapacitatedFacilityLocation(cf, ma, cs, ad).solve()
print(f"status: {sol.status}")
print(f"z_min:  {sol.z_min}")
print(f"open:   {sol.open_facilities}")
