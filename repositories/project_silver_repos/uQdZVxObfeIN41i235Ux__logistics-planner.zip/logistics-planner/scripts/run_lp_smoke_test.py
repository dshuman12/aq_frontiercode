"""Quick smoke test - solve one tiny instance per problem class."""
import numpy as np
import sys

from logistics_planner.problems.capacitated_facility_location import CapacitatedFacilityLocation
from logistics_planner.problems.transportation_problem import TransportationProblem
from logistics_planner.problems.capacitated_lot_sizing_problem import CapacitatedLotSizing
from logistics_planner.problems.linear_blending_problem import LinearBlending
from logistics_planner.problems.stiglers_diet_problem import StiglersDiet
from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman
from logistics_planner.problems.zero_one_knapsack import ZeroOneKnapsack
from logistics_planner.problems.assignment_problem import AssignmentProblem


def main():
    print(f"CFLP:  {CapacitatedFacilityLocation([100], [100], [[1, 2]], [10, 20]).solve().status}")
    print(f"Trans: {TransportationProblem([10], [10], [[1]]).solve().status}")
    print(f"CLSP:  {CapacitatedLotSizing([10, 10], [50, 50], [1, 1], [1, 1], 100).solve(initial_inventory=50).status}")
    print(f"Diet:  {StiglersDiet(['x'], [1], [[1]], [1]).solve().status}")
    print(f"Knap:  {ZeroOneKnapsack([5], [3], 5).solve().status}")
    print(f"Assgn: {AssignmentProblem([[1, 2], [3, 4]]).solve().status}")
    D = np.array([[0, 1, 2], [1, 0, 1], [2, 1, 0]])
    print(f"TSP-NN:{TravelingSalesman(D).solve_nearest_neighbor().status}")


if __name__ == "__main__":
    main()
