"""Print package size summary."""
import os
import subprocess


def lines_in(folder, ext=".py"):
    total = 0
    files = 0
    for root, dirs, fnames in os.walk(folder):
        if "__pycache__" in root:
            continue
        for fn in fnames:
            if fn.endswith(ext):
                files += 1
                with open(os.path.join(root, fn)) as f:
                    total += sum(1 for _ in f)
    return files, total


for path in ("logistics_planner", "tests", "examples", "scripts"):
    f, l = lines_in(path)
    print(f"{path:20s}  {f:4d} files  {l:6d} lines")
