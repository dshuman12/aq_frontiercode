#!/usr/bin/env bash
# Quick lint pass - just runs python imports for now.
set -e
python scripts/check_imports.py
echo "all good"
