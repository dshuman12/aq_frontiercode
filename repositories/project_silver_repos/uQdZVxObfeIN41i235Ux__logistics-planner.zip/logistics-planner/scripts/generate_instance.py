"""Generate a random instance for any problem and dump as JSON."""
import argparse
import json
import sys

from logistics_planner.benchmark import (
    random_facility_location_instance,
    random_transportation_instance,
    random_lot_sizing_instance,
    random_knapsack_instance,
    random_tsp_instance,
    random_max_flow_instance,
    random_set_covering_instance,
    random_assignment_instance,
)


def gen_facility(args):
    cf, ma, cs, ad = random_facility_location_instance(
        args.m, args.n, seed=args.seed,
    )
    return {
        "cost_facilities": cf,
        "max_amounts": ma,
        "cost_suppliers": cs,
        "annual_demands": ad,
    }


def gen_transportation(args):
    s, d, c = random_transportation_instance(args.m, args.n, seed=args.seed)
    return {"supply": s, "demand": d, "cost_matrix": c}


def gen_lot_sizing(args):
    d, s, h, p, cap = random_lot_sizing_instance(args.n, seed=args.seed)
    return {
        "demand": d, "setup_costs": s, "holding_costs": h,
        "production_costs": p, "capacity": cap,
    }


def gen_knapsack(args):
    v, w, c = random_knapsack_instance(args.n, seed=args.seed)
    return {"values": v, "weights": w, "capacity": c}


def gen_tsp(args):
    coords, D = random_tsp_instance(args.n, seed=args.seed)
    return {"distance_matrix": D.tolist()}


def gen_max_flow(args):
    cap = random_max_flow_instance(args.n, seed=args.seed)
    return {"capacity_matrix": cap, "source": 0, "sink": args.n - 1}


def gen_set_covering(args):
    costs, cov = random_set_covering_instance(args.m, args.n, seed=args.seed)
    return {"costs": costs, "coverage_matrix": cov}


def gen_assignment(args):
    M = random_assignment_instance(args.n, seed=args.seed)
    return {"cost_matrix": M.tolist()}


GENERATORS = {
    "facility": gen_facility,
    "transportation": gen_transportation,
    "lot_sizing": gen_lot_sizing,
    "knapsack": gen_knapsack,
    "tsp": gen_tsp,
    "max_flow": gen_max_flow,
    "set_covering": gen_set_covering,
    "assignment": gen_assignment,
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("problem", choices=GENERATORS.keys())
    parser.add_argument("--n", type=int, default=5)
    parser.add_argument("--m", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", default="-")
    args = parser.parse_args()

    payload = GENERATORS[args.problem](args)

    if args.out == "-":
        json.dump(payload, sys.stdout, indent=2, default=int)
        print()
    else:
        with open(args.out, "w") as f:
            json.dump(payload, f, indent=2, default=int)
        print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
