import numpy as np


def to_numpy(x, dtype=int):
    return np.asarray(x, dtype=dtype)


def check_dimensions(name, array, expected_shape):
    arr = np.asarray(array)
    if arr.shape != expected_shape:
        raise ValueError(
            f"{name} has shape {arr.shape}, expected {expected_shape}"
        )


def validate_square_matrix(name, matrix):
    arr = np.asarray(matrix)
    if arr.ndim != 2:
        raise ValueError(
            f"{name} must be 2-dimensional, got shape {arr.shape}"
        )
    return arr.shape[0]


def matrix_edges(matrix, threshold=0):
    arr = np.asarray(matrix)
    n = arr.shape[0]
    edges = []
    for i in range(n):
        for j in range(n):
            if i != j and np.isfinite(arr[i, j]) and arr[i, j] > threshold:
                edges.append((i, j))
    return edges
