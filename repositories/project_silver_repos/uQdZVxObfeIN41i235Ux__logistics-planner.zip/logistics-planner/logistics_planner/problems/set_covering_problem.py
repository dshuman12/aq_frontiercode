from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import (
    build_problem,
    solve,
    extract_binary_selection,
)


@dataclass
class SetCoveringSolution:
    status: str
    total_cost: float
    selected_sets: list


class SetCoveringProblem:
    def __init__(self, costs, coverage_matrix):
        # coverage_matrix[i][j] = 1 if set j covers element i, else 0
        self.costs = np.asarray(costs, dtype=float)
        self.coverage = np.asarray(coverage_matrix, dtype=int)
        self.m = self.coverage.shape[0]   # number of elements
        self.n = self.coverage.shape[1]   # number of sets

        if len(self.costs) != self.n:
            raise ValueError(
                f"len(costs)={len(self.costs)} != number of sets={self.n}"
            )

    def solve(self):
        n = self.n
        m = self.m
        c = self.costs
        A = self.coverage

        problem = build_problem("set_covering", sense="min")
        x = [LpVariable(f"x{j+1}", cat='Binary') for j in range(n)]

        problem += lpSum(c[j] * x[j] for j in range(n))

        # every element must be covered by at least one selected set
        for i in range(m):
            problem += lpSum(A[i, j] * x[j] for j in range(n)) >= 1

        status = solve(problem)

        selected = extract_binary_selection(x)

        return SetCoveringSolution(
            status=status,
            total_cost=value(problem.objective) if status == "Optimal" else 0.0,
            selected_sets=selected,
        )

    def greedy(self):
        # classic greedy: pick the set that covers the most uncovered elements
        # per unit cost. Approximation factor H(n).
        uncovered = set(range(self.m))
        selected = []
        total = 0.0
        sets_indices = list(range(self.n))

        while uncovered:
            best_j = None
            best_ratio = -1.0
            for j in sets_indices:
                if j in selected:
                    continue
                covered_now = sum(1 for i in uncovered if self.coverage[i, j] == 1)
                if covered_now == 0:
                    continue
                ratio = covered_now / max(self.costs[j], 1e-9)
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_j = j

            if best_j is None:
                # uncovered elements with no covering set
                return SetCoveringSolution(
                    status="Infeasible",
                    total_cost=0.0,
                    selected_sets=[],
                )
            selected.append(best_j)
            total += self.costs[best_j]
            uncovered = {i for i in uncovered if self.coverage[i, best_j] == 0}

        return SetCoveringSolution(
            status="Heuristic",
            total_cost=float(total),
            selected_sets=sorted(selected),
        )
