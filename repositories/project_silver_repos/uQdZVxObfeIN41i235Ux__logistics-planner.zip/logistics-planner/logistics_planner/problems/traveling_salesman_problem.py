from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve
from logistics_planner.utils import validate_square_matrix


@dataclass
class TourSolution:
    status: str
    total_distance: float
    tour: list

    def num_cities(self):
        return len(self.tour) - 1


class TravelingSalesman:
    def __init__(self, distance_matrix):
        self.distance_matrix = np.asarray(distance_matrix, dtype=float)
        self.n = validate_square_matrix("distance_matrix", self.distance_matrix)

    def solve_mip(self):
        n = self.n
        D = self.distance_matrix

        problem = build_problem("tsp_mtz", sense="min")

        x = {}
        for i in range(n):
            for j in range(n):
                if i != j:
                    x[i, j] = LpVariable(f"x{i}_{j}", cat='Binary')

        u = [LpVariable(f"u{i}", lowBound=0, upBound=n - 1) for i in range(n)]

        problem += lpSum(D[i, j] * x[i, j] for i in range(n) for j in range(n) if i != j)

        for i in range(n):
            problem += lpSum(x[i, j] for j in range(n) if j != i) == 1

        for j in range(n):
            problem += lpSum(x[i, j] for i in range(n) if i != j) == 1

        # MTZ: u[i] - u[j] + n*x[i,j] <= n-1 for i,j != 0, i != j
        for i in range(1, n):
            for j in range(1, n):
                if i != j:
                    problem += u[i] - u[j] + n * x[i, j] <= n - 1

        status = solve(problem)

        tour = [0]
        current = 0
        for _ in range(n - 1):
            for j in range(n):
                if j != current and value(x[current, j]) > 0.5:
                    tour.append(j)
                    current = j
                    break
        tour.append(0)

        return TourSolution(
            status=status,
            total_distance=value(problem.objective),
            tour=tour,
        )

    def solve_nearest_neighbor(self, start=0):
        n = self.n
        D = self.distance_matrix
        unvisited = set(range(n))
        unvisited.remove(start)

        tour = [start]
        current = start
        total = 0.0

        while unvisited:
            nxt = min(unvisited, key=lambda j: D[current, j])
            total += D[current, nxt]
            tour.append(nxt)
            unvisited.remove(nxt)
            current = nxt

        total += D[current, start]
        tour.append(start)

        return TourSolution(
            status="Heuristic",
            total_distance=total,
            tour=tour,
        )
