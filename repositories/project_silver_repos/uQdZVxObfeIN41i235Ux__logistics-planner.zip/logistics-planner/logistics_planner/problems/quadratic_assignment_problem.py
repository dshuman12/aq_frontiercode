import random
from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class QAPSolution:
    status: str
    total_cost: float
    permutation: list


class QuadraticAssignmentProblem:
    """Linearized QAP (Frieze-Yadegar): assigns n facilities to n locations.

    cost = sum_{i,j} flow[i,j] * distance[perm[i], perm[j]]
    """

    def __init__(self, flow_matrix, distance_matrix):
        self.flow = np.asarray(flow_matrix, dtype=float)
        self.distance = np.asarray(distance_matrix, dtype=float)

        if self.flow.shape != self.distance.shape:
            raise ValueError(
                f"flow {self.flow.shape} != distance {self.distance.shape}"
            )
        if self.flow.shape[0] != self.flow.shape[1]:
            raise ValueError("matrices must be square")

        self.n = self.flow.shape[0]

    def solve_mip(self):
        n = self.n
        F = self.flow
        D = self.distance

        problem = build_problem("qap", sense="min")

        # x[i, k] = 1 if facility i is assigned to location k
        x = {}
        for i in range(n):
            for k in range(n):
                x[i, k] = LpVariable(f"x_{i}_{k}", cat='Binary')

        # y[i,j,k,l] = x[i,k] * x[j,l] (linearization)
        y = {}
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    for l in range(n):
                        if i != j and k != l:
                            y[i, j, k, l] = LpVariable(
                                f"y_{i}_{j}_{k}_{l}", lowBound=0, upBound=1
                            )

        problem += lpSum(F[i, j] * D[k, l] * y[i, j, k, l]
                         for (i, j, k, l) in y)

        # assignment constraints
        for i in range(n):
            problem += lpSum(x[i, k] for k in range(n)) == 1
        for k in range(n):
            problem += lpSum(x[i, k] for i in range(n)) == 1

        # linearization: y_ijkl <= x_ik, y_ijkl <= x_jl
        # and y_ijkl >= x_ik + x_jl - 1 to enforce equality at integers
        for (i, j, k, l), yv in y.items():
            problem += yv <= x[i, k]
            problem += yv <= x[j, l]
            problem += yv >= x[i, k] + x[j, l] - 1

        status = solve(problem)

        permutation = [-1] * n
        if status == "Optimal":
            for i in range(n):
                for k in range(n):
                    if value(x[i, k]) is not None and value(x[i, k]) > 0.5:
                        permutation[i] = k
                        break

        return QAPSolution(
            status=status,
            total_cost=value(problem.objective) if status == "Optimal" else 0.0,
            permutation=permutation,
        )

    def evaluate(self, permutation):
        n = self.n
        F = self.flow
        D = self.distance
        total = 0.0
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                total += F[i, j] * D[permutation[i], permutation[j]]
        return float(total)

    def solve_local_search(self, max_iterations=1000, seed=None):
        if seed is not None:
            random.seed(seed)

        n = self.n
        # start from random permutation
        perm = list(range(n))
        random.shuffle(perm)
        best_cost = self.evaluate(perm)

        for _ in range(max_iterations):
            improved = False
            # try all 2-swaps
            for i in range(n - 1):
                for j in range(i + 1, n):
                    perm[i], perm[j] = perm[j], perm[i]
                    new_cost = self.evaluate(perm)
                    if new_cost < best_cost - 1e-9:
                        best_cost = new_cost
                        improved = True
                    else:
                        perm[i], perm[j] = perm[j], perm[i]
            if not improved:
                break

        return QAPSolution(
            status="Heuristic",
            total_cost=float(best_cost),
            permutation=perm,
        )

    def solve(self):
        return self.solve_local_search()
