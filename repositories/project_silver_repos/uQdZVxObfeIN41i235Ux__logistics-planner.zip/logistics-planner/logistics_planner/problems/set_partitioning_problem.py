from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import (
    build_problem,
    solve,
    extract_binary_selection,
)


@dataclass
class SetPartitioningSolution:
    status: str
    total_cost: float
    selected_sets: list


class SetPartitioningProblem:
    def __init__(self, costs, coverage_matrix):
        # similar to set covering, but EACH element must be covered exactly once
        self.costs = np.asarray(costs, dtype=float)
        self.coverage = np.asarray(coverage_matrix, dtype=int)
        self.m = self.coverage.shape[0]
        self.n = self.coverage.shape[1]

        if len(self.costs) != self.n:
            raise ValueError(
                f"len(costs)={len(self.costs)} != number of sets={self.n}"
            )

    def solve(self):
        n = self.n
        m = self.m
        c = self.costs
        A = self.coverage

        problem = build_problem("set_partitioning", sense="min")
        x = [LpVariable(f"x{j+1}", cat='Binary') for j in range(n)]

        problem += lpSum(c[j] * x[j] for j in range(n))

        # each element covered EXACTLY once
        for i in range(m):
            problem += lpSum(A[i, j] * x[j] for j in range(n)) == 1

        status = solve(problem)

        selected = extract_binary_selection(x)

        return SetPartitioningSolution(
            status=status,
            total_cost=value(problem.objective) if status == "Optimal" else 0.0,
            selected_sets=selected,
        )
