from collections import deque
from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve, make_flow_vars
from logistics_planner.utils import matrix_edges


@dataclass
class MaxFlowSolution:
    status: str
    max_flow_value: float
    flow_matrix: np.ndarray


class MaxFlowProblem:
    def __init__(self, capacity_matrix, source, sink):
        self.capacity = np.asarray(capacity_matrix, dtype=float)
        self.n = self.capacity.shape[0]
        self.source = source
        self.sink = sink

        if self.capacity.shape != (self.n, self.n):
            raise ValueError(
                f"capacity matrix must be square, got {self.capacity.shape}"
            )
        if (self.capacity < 0).any():
            raise ValueError("capacities must be non-negative")

    def _bfs_augmenting_path(self, residual):
        n = self.n
        parent = [-1] * n
        parent[self.source] = self.source
        visited = [False] * n
        visited[self.source] = True
        q = deque([self.source])
        while q:
            u = q.popleft()
            for v in range(n):
                if not visited[v] and residual[u, v] > 1e-9:
                    parent[v] = u
                    visited[v] = True
                    if v == self.sink:
                        return parent
                    q.append(v)
        return None

    def solve_edmonds_karp(self):
        # Edmonds-Karp: BFS-based augmenting paths
        n = self.n
        residual = self.capacity.copy()
        flow = np.zeros((n, n), dtype=float)
        total = 0.0

        while True:
            parent = self._bfs_augmenting_path(residual)
            if parent is None:
                break

            # find bottleneck along the path
            path_flow = float("inf")
            v = self.sink
            while v != self.source:
                u = parent[v]
                path_flow = min(path_flow, residual[u, v])
                v = u

            # update flows and residuals
            v = self.sink
            while v != self.source:
                u = parent[v]
                flow[u, v] += path_flow
                flow[v, u] -= path_flow
                residual[u, v] -= path_flow
                residual[v, u] += path_flow
                v = u

            total += path_flow

        # report only the forward (positive) flow
        flow_pos = np.maximum(flow, 0)

        return MaxFlowSolution(
            status="Optimal",
            max_flow_value=float(total),
            flow_matrix=flow_pos,
        )

    def solve_lp(self):
        n = self.n
        cap = self.capacity
        s, t = self.source, self.sink

        problem = build_problem("max_flow", sense="max")

        edges = matrix_edges(cap, threshold=0)
        x = make_flow_vars("x", edges, capacity_lookup=lambda i, j: cap[i, j])

        # objective: net outflow at source
        problem += (lpSum(x[s, j] for (i, j) in edges if i == s)
                    - lpSum(x[i, s] for (i, j) in edges if j == s))

        # flow conservation at non-terminal nodes
        for v in range(n):
            if v in (s, t):
                continue
            inflow = lpSum(x[i, v] for (i, j) in edges if j == v)
            outflow = lpSum(x[v, j] for (i, j) in edges if i == v)
            problem += inflow == outflow

        status = solve(problem)

        flow_matrix = np.zeros((n, n))
        for (i, j) in edges:
            v = value(x[i, j])
            if v is not None:
                flow_matrix[i, j] = v

        return MaxFlowSolution(
            status=status,
            max_flow_value=value(problem.objective) if status == "Optimal" else 0.0,
            flow_matrix=flow_matrix,
        )

    def solve(self):
        return self.solve_edmonds_karp()
