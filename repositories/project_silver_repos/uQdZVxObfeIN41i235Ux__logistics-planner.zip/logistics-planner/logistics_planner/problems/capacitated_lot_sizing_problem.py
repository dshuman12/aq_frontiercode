from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.utils import to_numpy
from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class LotSizingSolution:
    status: str
    total_cost: float
    production: np.ndarray
    inventory: np.ndarray
    setup: list


class CapacitatedLotSizing:
    def __init__(self, demand, setup_costs, holding_costs, production_costs, capacity):
        self.demand = to_numpy(demand)
        self.setup_costs = to_numpy(setup_costs)
        self.holding_costs = to_numpy(holding_costs)
        self.production_costs = to_numpy(production_costs)
        self.capacity = capacity
        self.n_periods = len(self.demand)

    def solve(self, initial_inventory=0):
        T = self.n_periods
        d = self.demand
        s = self.setup_costs
        h = self.holding_costs
        p = self.production_costs

        # capacity can be scalar or per-period
        if np.isscalar(self.capacity):
            cap = np.full(T, self.capacity, dtype=float)
        else:
            cap = to_numpy(self.capacity)

        problem = build_problem("capacitated_lot_sizing", sense="min")

        y = [LpVariable(f"y{t+1}", cat='Binary') for t in range(T)]
        x = [LpVariable(f"x{t+1}", lowBound=0) for t in range(T)]
        I = [LpVariable(f"I{t+1}", lowBound=0) for t in range(T)]

        problem += (
            lpSum(s[t] * y[t] for t in range(T))
            + lpSum(p[t] * x[t] for t in range(T))
            + lpSum(h[t] * I[t] for t in range(T))
        )

        # inventory balance
        for t in range(T):
            if t == 0:
                problem += I[t] == initial_inventory + x[t] - d[t]
            else:
                problem += I[t] == I[t-1] + x[t] - d[t]

        # capacity link
        for t in range(T):
            problem += x[t] <= cap[t] * y[t]

        status = solve(problem)

        production = np.array([value(x[t]) for t in range(T)])
        inventory = np.array([value(I[t]) for t in range(T)])
        setup = [value(y[t]) > 0.5 for t in range(T)]

        return LotSizingSolution(
            status=status,
            total_cost=value(problem.objective),
            production=production,
            inventory=inventory,
            setup=setup,
        )
