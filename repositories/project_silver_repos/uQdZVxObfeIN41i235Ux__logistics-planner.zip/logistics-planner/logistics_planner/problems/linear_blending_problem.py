from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.utils import to_numpy
from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class BlendSolution:
    status: str
    total_cost: float
    proportions: np.ndarray


class LinearBlending:
    def __init__(self, materials, costs, property_matrix, lower_bounds, upper_bounds, output_quantity):
        self.materials = list(materials)
        self.costs = to_numpy(costs)
        self.property_matrix = to_numpy(property_matrix)
        self.lower_bounds = to_numpy(lower_bounds)
        self.upper_bounds = to_numpy(upper_bounds)
        self.output_quantity = float(output_quantity)
        self.m = len(self.materials)
        self.k = self.property_matrix.shape[0]

        if self.property_matrix.shape != (self.k, self.m):
            raise ValueError(
                f"property_matrix shape {self.property_matrix.shape} does not match "
                f"(properties, materials) = ({self.k}, {self.m})"
            )

    def solve(self):
        m = self.m
        k = self.k
        c = self.costs
        P = self.property_matrix
        lo = self.lower_bounds
        hi = self.upper_bounds
        Q = self.output_quantity

        problem = build_problem("linear_blending", sense="min")

        x = [LpVariable(f"x{i+1}", lowBound=0) for i in range(m)]

        problem += lpSum(c[i] * x[i] for i in range(m))

        # total output equals target quantity
        problem += lpSum(x[i] for i in range(m)) == Q

        # property bounds
        for r in range(k):
            blend_amount = lpSum(P[r, i] * x[i] for i in range(m))
            problem += blend_amount >= lo[r] * Q
            problem += blend_amount <= hi[r] * Q

        status = solve(problem)

        proportions = np.array([value(x[i]) for i in range(m)])

        return BlendSolution(
            status=status,
            total_cost=value(problem.objective),
            proportions=proportions,
        )
