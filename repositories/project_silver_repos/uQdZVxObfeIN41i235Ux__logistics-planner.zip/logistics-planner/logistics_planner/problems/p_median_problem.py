from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class PMedianSolution:
    status: str
    total_cost: float
    open_facilities: list
    assignment: list


class PMedianProblem:
    """Discrete p-median: pick exactly p facility locations from n candidates
    to minimize total weighted distance from each demand point to its nearest
    open facility.
    """

    def __init__(self, distance_matrix, demands, p):
        self.distance = np.asarray(distance_matrix, dtype=float)
        self.demands = np.asarray(demands, dtype=float)
        self.p = int(p)
        self.n_demand = self.distance.shape[0]
        self.n_facility = self.distance.shape[1]

        if len(self.demands) != self.n_demand:
            raise ValueError(
                f"len(demands)={len(self.demands)} != number of demand points"
            )
        if not (1 <= self.p <= self.n_facility):
            raise ValueError(f"p must be in [1, {self.n_facility}]")

    def solve(self):
        n_demand = self.n_demand
        n_facility = self.n_facility
        p = self.p
        D = self.distance
        d = self.demands

        problem = build_problem("p_median", sense="min")

        y = [LpVariable(f"y{j}", cat='Binary') for j in range(n_facility)]
        x = [[LpVariable(f"x{i}_{j}", lowBound=0, upBound=1)
              for j in range(n_facility)]
             for i in range(n_demand)]

        problem += lpSum(d[i] * D[i, j] * x[i][j]
                         for i in range(n_demand) for j in range(n_facility))

        # exactly p facilities open
        problem += lpSum(y[j] for j in range(n_facility)) == p

        # each demand fully assigned
        for i in range(n_demand):
            problem += lpSum(x[i][j] for j in range(n_facility)) == 1

        # x_ij <= y_j (no demand assigned to closed facility)
        for i in range(n_demand):
            for j in range(n_facility):
                problem += x[i][j] <= y[j]

        status = solve(problem)

        if status != "Optimal":
            return PMedianSolution(
                status=status, total_cost=0.0,
                open_facilities=[], assignment=[],
            )

        opened = [j for j in range(n_facility)
                  if value(y[j]) is not None and value(y[j]) > 0.5]

        assignment = []
        for i in range(n_demand):
            for j in range(n_facility):
                if value(x[i][j]) is not None and value(x[i][j]) > 0.5:
                    assignment.append((i, j))
                    break

        return PMedianSolution(
            status=status,
            total_cost=value(problem.objective),
            open_facilities=opened,
            assignment=assignment,
        )
