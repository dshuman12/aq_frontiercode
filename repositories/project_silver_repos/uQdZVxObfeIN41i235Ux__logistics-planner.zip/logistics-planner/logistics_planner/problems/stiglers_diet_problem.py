from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.utils import to_numpy
from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class DietSolution:
    status: str
    total_cost: float
    quantities: dict


class StiglersDiet:
    def __init__(self, foods, costs, nutrient_matrix, requirements):
        self.foods = list(foods)
        self.costs = to_numpy(costs)
        self.nutrient_matrix = to_numpy(nutrient_matrix)
        self.requirements = to_numpy(requirements)
        self.n_foods = len(self.foods)
        self.n_nutrients = len(self.requirements)

        if self.nutrient_matrix.shape != (self.n_nutrients, self.n_foods):
            raise ValueError(
                f"nutrient_matrix shape {self.nutrient_matrix.shape} does not match "
                f"(nutrients, foods) = ({self.n_nutrients}, {self.n_foods})"
            )

    def solve(self):
        n = self.n_foods
        k = self.n_nutrients
        c = self.costs
        N = self.nutrient_matrix
        req = self.requirements

        problem = build_problem("stiglers_diet", sense="min")

        x = [LpVariable(f"x{j+1}", lowBound=0) for j in range(n)]

        problem += lpSum(c[j] * x[j] for j in range(n))

        # nutrient requirements (>=)
        for r in range(k):
            problem += lpSum(N[r, j] * x[j] for j in range(n)) >= req[r]

        status = solve(problem)

        quantities = {self.foods[j]: value(x[j]) for j in range(n)}

        return DietSolution(
            status=status,
            total_cost=value(problem.objective),
            quantities=quantities,
        )
