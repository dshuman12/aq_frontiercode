from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve
from logistics_planner.utils import validate_square_matrix


@dataclass
class AssignmentSolution:
    status: str
    total_cost: float
    assignment: list

    def as_dict(self):
        return dict(self.assignment)


class AssignmentProblem:
    def __init__(self, cost_matrix):
        self.cost = np.asarray(cost_matrix, dtype=float)
        self.n = validate_square_matrix("cost_matrix", self.cost)

    def solve_lp(self):
        n = self.n
        c = self.cost

        problem = build_problem("assignment", sense="min")
        x = [[LpVariable(f"x{i+1}_{j+1}", cat='Binary') for j in range(n)]
             for i in range(n)]

        problem += lpSum(c[i, j] * x[i][j] for i in range(n) for j in range(n))

        # each agent assigned to exactly one task
        for i in range(n):
            problem += lpSum(x[i][j] for j in range(n)) == 1

        # each task assigned to exactly one agent
        for j in range(n):
            problem += lpSum(x[i][j] for i in range(n)) == 1

        status = solve(problem)

        assignment = []
        for i in range(n):
            for j in range(n):
                if value(x[i][j]) > 0.5:
                    assignment.append((i, j))
                    break

        return AssignmentSolution(
            status=status,
            total_cost=value(problem.objective),
            assignment=assignment,
        )

    def solve_hungarian(self):
        # classical Hungarian algorithm (O(n^3))
        n = self.n
        cost = self.cost.copy()

        # row reduction
        cost = cost - cost.min(axis=1, keepdims=True)
        # col reduction
        cost = cost - cost.min(axis=0, keepdims=True)

        # find a matching by greedy on zeros, then iteratively improve
        # this is a simplified form - good enough for small instances
        assignment = [-1] * n
        for i in range(n):
            for j in range(n):
                if cost[i, j] == 0 and j not in assignment:
                    assignment[i] = j
                    break

        # if some rows are unassigned fall back to LP
        if -1 in assignment:
            return self.solve_lp()

        total = sum(self.cost[i, j] for i, j in enumerate(assignment))
        return AssignmentSolution(
            status="Optimal",
            total_cost=float(total),
            assignment=list(enumerate(assignment)),
        )

    def solve(self):
        return self.solve_lp()
