from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, LpProblem, LpMinimize, LpStatus, value, PULP_CBC_CMD


@dataclass
class CFLPSolution:
    status: str
    z_min: float
    open_facilities: list
    allocation: np.ndarray

    def num_open(self):
        return len(self.open_facilities)


class CapacitatedFacilityLocation:
    def __init__(self, cost_facilities, max_amounts, cost_suppliers, annual_demands):
        self.cost_facilities = np.asarray(cost_facilities)
        self.max_amounts = np.asarray(max_amounts)
        self.cost_suppliers = np.asarray(cost_suppliers)
        self.annual_demands = np.asarray(annual_demands)
        self.num_facilities = len(self.cost_facilities)
        self.num_suppliers = len(self.annual_demands)

    def solve(self):
        num_facilities = self.num_facilities
        num_suppliers = self.num_suppliers
        cost_facilities = self.cost_facilities
        max_amounts = self.max_amounts
        cost_suppliers = self.cost_suppliers
        annual_demands = self.annual_demands

        # facilities variables (open or not)
        facilities_variables = [LpVariable(f"y{i+1}", cat='Binary') for i in range(num_facilities)]

        # suppliers variables (units shipped from facility i to supplier j)
        suppliers_variables = []
        for i in range(num_facilities):
            y1 = []
            for j in range(num_suppliers):
                y1.append(LpVariable(f"x{i+1}{j+1}", cat='Integer', lowBound=0))
            suppliers_variables.append(y1)
        suppliers_variables = np.asarray(suppliers_variables)

        # objective: fixed open costs + variable transport costs
        z1 = cost_facilities * facilities_variables
        z2 = (cost_suppliers * suppliers_variables).reshape(-1)
        z = np.concatenate((z1, z2))
        z_final = 0
        for i in z:
            z_final += i

        problem = LpProblem("facility_location_problem", LpMinimize)
        problem += z_final

        # max amount constraints (capacity * open indicator)
        for index, suppliers_variable in enumerate(suppliers_variables):
            supp1 = 0
            for supp in suppliers_variable:
                supp1 += supp
            problem += supp1 <= (max_amounts[index] * facilities_variables[index])

        # demand constraints
        for index, supplier_variable in enumerate(suppliers_variables.transpose()):
            supp2 = 0
            for supp in supplier_variable:
                supp2 += supp
            problem += supp2 == annual_demands[index]

        # upper bound (can't ship from a closed facility)
        for i in range(num_facilities):
            for j in range(num_suppliers):
                problem += suppliers_variables[i][j] <= annual_demands[j] * facilities_variables[i]

        problem.solve(PULP_CBC_CMD(msg=0))

        open_facilities = [i for i in range(num_facilities) if value(facilities_variables[i]) > 0.5]
        allocation = np.array(
            [[value(suppliers_variables[i][j]) for j in range(num_suppliers)]
             for i in range(num_facilities)]
        )

        return CFLPSolution(
            status=LpStatus[problem.status],
            z_min=value(problem.objective),
            open_facilities=open_facilities,
            allocation=allocation,
        )
