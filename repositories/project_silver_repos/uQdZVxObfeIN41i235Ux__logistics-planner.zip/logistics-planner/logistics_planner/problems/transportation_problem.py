from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, LpProblem, LpMinimize, LpStatus, value, lpSum, PULP_CBC_CMD


@dataclass
class TransportSolution:
    status: str
    total_cost: float
    shipments: np.ndarray

    def total_shipped(self):
        return float(self.shipments.sum())


class TransportationProblem:
    def __init__(self, supply, demand, cost_matrix):
        self.supply = np.asarray(supply, dtype=float)
        self.demand = np.asarray(demand, dtype=float)
        self.cost_matrix = np.asarray(cost_matrix, dtype=float)
        self.m = len(self.supply)
        self.n = len(self.demand)

        if self.cost_matrix.shape != (self.m, self.n):
            raise ValueError(
                f"cost_matrix shape {self.cost_matrix.shape} does not match "
                f"(supply, demand) = ({self.m}, {self.n})"
            )

    def is_balanced(self):
        return np.isclose(self.supply.sum(), self.demand.sum())

    def solve(self):
        # rebalance if needed by adding dummy source / dummy destination
        supply = list(self.supply)
        demand = list(self.demand)
        cost = self.cost_matrix.tolist()
        m, n = self.m, self.n

        total_supply = sum(supply)
        total_demand = sum(demand)

        if total_supply > total_demand:
            # dummy destination soaks up the excess
            demand.append(total_supply - total_demand)
            for i in range(m):
                cost[i].append(0.0)
            n += 1
        elif total_demand > total_supply:
            # dummy source covers the shortfall
            supply.append(total_demand - total_supply)
            cost.append([0.0] * n)
            m += 1

        problem = LpProblem("transportation_problem", LpMinimize)

        x = [[LpVariable(f"x{i+1}_{j+1}", lowBound=0)
              for j in range(n)] for i in range(m)]

        problem += lpSum(cost[i][j] * x[i][j] for i in range(m) for j in range(n))

        for i in range(m):
            problem += lpSum(x[i][j] for j in range(n)) == supply[i]

        for j in range(n):
            problem += lpSum(x[i][j] for i in range(m)) == demand[j]

        problem.solve(PULP_CBC_CMD(msg=0))

        # strip dummy row/col before returning
        shipments = np.array(
            [[value(x[i][j]) for j in range(self.n)] for i in range(self.m)]
        )

        return TransportSolution(
            status=LpStatus[problem.status],
            total_cost=value(problem.objective),
            shipments=shipments,
        )
