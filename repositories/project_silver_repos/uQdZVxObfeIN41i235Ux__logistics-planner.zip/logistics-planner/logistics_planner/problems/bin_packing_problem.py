from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class BinPackingSolution:
    status: str
    bins_used: int
    assignment: list


class BinPackingProblem:
    def __init__(self, item_sizes, bin_capacity, max_bins=None):
        self.sizes = np.asarray(item_sizes, dtype=float)
        self.bin_capacity = float(bin_capacity)
        self.n = len(self.sizes)
        # upper bound on number of bins = n (one item per bin worst case)
        self.max_bins = max_bins if max_bins is not None else self.n

        if (self.sizes > self.bin_capacity + 1e-9).any():
            raise ValueError(
                "an item is larger than the bin capacity (infeasible)"
            )

    def solve_mip(self):
        n = self.n
        K = self.max_bins
        s = self.sizes
        C = self.bin_capacity

        problem = build_problem("bin_packing", sense="min")

        # x[i,k] = 1 if item i goes in bin k
        x = [[LpVariable(f"x{i+1}_{k+1}", cat='Binary') for k in range(K)]
             for i in range(n)]
        # y[k] = 1 if bin k is used
        y = [LpVariable(f"y{k+1}", cat='Binary') for k in range(K)]

        problem += lpSum(y[k] for k in range(K))

        # each item assigned to exactly one bin
        for i in range(n):
            problem += lpSum(x[i][k] for k in range(K)) >= 1

        # capacity per bin
        for k in range(K):
            problem += lpSum(s[i] * x[i][k] for i in range(n)) <= C * y[k]

        status = solve(problem)

        if status != "Optimal":
            return BinPackingSolution(
                status=status,
                bins_used=0,
                assignment=[],
            )

        assignment = []
        for i in range(n):
            for k in range(K):
                if value(x[i][k]) > 0.5:
                    assignment.append((i, k))
                    break

        bins_used = int(round(value(problem.objective)))

        return BinPackingSolution(
            status=status,
            bins_used=bins_used,
            assignment=assignment,
        )

    def solve_first_fit_decreasing(self):
        # FFD: sort items decreasing, place each in first bin that fits
        items_sorted = sorted(range(self.n), key=lambda i: -self.sizes[i])
        bins = []  # each bin: list of (item_idx, size)
        for i in items_sorted:
            placed = False
            for b in bins:
                used = sum(sz for _, sz in b)
                if used + self.sizes[i] <= self.bin_capacity + 1e-9:
                    b.append((i, self.sizes[i]))
                    placed = True
                    break
            if not placed:
                bins.append([(i, self.sizes[i])])

        assignment = []
        for k, b in enumerate(bins):
            for (i, _) in b:
                assignment.append((i, k))
        assignment.sort()

        return BinPackingSolution(
            status="Heuristic",
            bins_used=len(bins),
            assignment=assignment,
        )

    def solve(self):
        return self.solve_mip()
