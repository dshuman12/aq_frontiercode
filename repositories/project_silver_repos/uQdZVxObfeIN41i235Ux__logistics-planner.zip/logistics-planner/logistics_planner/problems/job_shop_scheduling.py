from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class JobShopSolution:
    status: str
    makespan: float
    schedule: list  # list of (job, machine, start, end)


class JobShopScheduling:
    """Disjunctive MIP for job shop with makespan objective.

    Each job has an ordered sequence of operations. Each operation runs on a
    designated machine for a given duration. No two operations on the same
    machine can overlap.
    """

    def __init__(self, processing_times, machine_orders):
        # processing_times[j][k] = duration of job j operation k
        # machine_orders[j][k]   = machine index for job j operation k
        self.processing_times = [list(row) for row in processing_times]
        self.machine_orders = [list(row) for row in machine_orders]
        self.n_jobs = len(self.processing_times)

        if len(self.machine_orders) != self.n_jobs:
            raise ValueError("processing_times and machine_orders disagree on job count")

        for j in range(self.n_jobs):
            if len(self.processing_times[j]) != len(self.machine_orders[j]):
                raise ValueError(
                    f"job {j} has mismatched operations between times and machines"
                )

        self.n_ops_per_job = [len(self.processing_times[j]) for j in range(self.n_jobs)]
        self.n_machines = max(max(row) for row in self.machine_orders) + 1

    def solve_mip(self, big_m=None):
        n_jobs = self.n_jobs
        n_machines = self.n_machines
        p = self.processing_times
        machines = self.machine_orders

        # big M: sum of all processing times is a safe upper bound on horizon
        if big_m is None:
            big_m = sum(sum(row) for row in p) + 1

        problem = build_problem("job_shop", sense="min")

        # start[j][k] = start time of job j's k-th operation
        start = [[LpVariable(f"s_{j}_{k}", lowBound=0)
                  for k in range(self.n_ops_per_job[j])]
                 for j in range(n_jobs)]

        makespan = LpVariable("makespan", lowBound=0)

        # disjunctive ordering vars y[j1, j2, m] = 1 if job j1's op on m precedes j2's
        y = {}
        for m in range(n_machines):
            ops_on_m = []
            for j in range(n_jobs):
                for k in range(self.n_ops_per_job[j]):
                    if machines[j][k] == m:
                        ops_on_m.append((j, k))
            for a in range(len(ops_on_m)):
                for b in range(a + 1, len(ops_on_m)):
                    j1, k1 = ops_on_m[a]
                    j2, k2 = ops_on_m[b]
                    y[j1, k1, j2, k2] = LpVariable(
                        f"y_{j1}_{k1}_{j2}_{k2}", cat='Binary'
                    )

        problem += makespan

        # precedence within each job
        for j in range(n_jobs):
            for k in range(self.n_ops_per_job[j] - 1):
                problem += start[j][k + 1] >= start[j][k] + p[j][k]

        # machine non-overlap (disjunctive)
        for (j1, k1, j2, k2), yvar in y.items():
            problem += start[j1][k1] + p[j1][k1] <= start[j2][k2] + big_m * (1 - yvar)
            problem += start[j2][k2] + p[j2][k2] <= start[j1][k1] + big_m * yvar

        # makespan covers each job's last op
        for j in range(n_jobs):
            last = self.n_ops_per_job[j] - 1
            problem += makespan >= start[j][last] + p[j][last]

        status = solve(problem)

        schedule = []
        if status == "Optimal":
            for j in range(n_jobs):
                for k in range(self.n_ops_per_job[j]):
                    s = value(start[j][k]) or 0.0
                    e = s + p[j][k]
                    schedule.append((j, machines[j][k], s, e))

        return JobShopSolution(
            status=status,
            makespan=value(makespan) if status == "Optimal" else 0.0,
            schedule=schedule,
        )

    def solve(self):
        return self.solve_mip()
