from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve, make_flow_vars
from logistics_planner.utils import matrix_edges


@dataclass
class MinCostFlowSolution:
    status: str
    total_cost: float
    flow_matrix: np.ndarray


class MinCostFlowProblem:
    def __init__(self, cost_matrix, capacity_matrix, supplies):
        self.cost = np.asarray(cost_matrix, dtype=float)
        self.capacity = np.asarray(capacity_matrix, dtype=float)
        self.supplies = np.asarray(supplies, dtype=float)
        self.n = len(self.supplies)

        if self.cost.shape != (self.n, self.n):
            raise ValueError(
                f"cost shape {self.cost.shape} does not match n={self.n}"
            )
        if self.capacity.shape != (self.n, self.n):
            raise ValueError(
                f"capacity shape {self.capacity.shape} does not match n={self.n}"
            )
        # supplies should sum to zero (flow conservation across the network)
        if abs(self.supplies.sum()) > 1e-6:
            raise ValueError(
                f"supplies must sum to 0, got {self.supplies.sum()}"
            )

    def solve(self):
        n = self.n
        cost = self.cost
        cap = self.capacity
        b = self.supplies

        problem = build_problem("min_cost_flow", sense="min")

        edges = matrix_edges(cap, threshold=0)
        x = make_flow_vars("x", edges, capacity_lookup=lambda i, j: cap[i, j])

        problem += lpSum(cost[i, j] * x[i, j] for (i, j) in edges)

        # flow conservation: outflow - inflow = supply at each node
        for v in range(n):
            outflow = lpSum(x[v, j] for (i, j) in edges if i == v)
            inflow = lpSum(x[i, v] for (i, j) in edges if j == v)
            problem += outflow - inflow == b[v]

        status = solve(problem)

        flow_matrix = np.zeros((n, n))
        for (i, j) in edges:
            v = value(x[i, j])
            if v is not None:
                flow_matrix[i, j] = v

        return MinCostFlowSolution(
            status=status,
            total_cost=value(problem.objective) if status == "Optimal" else 0.0,
            flow_matrix=flow_matrix,
        )
