import heapq
from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve
from logistics_planner.utils import validate_square_matrix


@dataclass
class ShortestPathSolution:
    status: str
    distance: float
    path: list

    def num_hops(self):
        return max(0, len(self.path) - 1)


class ShortestPathProblem:
    def __init__(self, cost_matrix, source, target):
        self.cost = np.asarray(cost_matrix, dtype=float)
        self.n = validate_square_matrix("cost_matrix", self.cost)
        self.source = source
        self.target = target

        if not (0 <= source < self.n) or not (0 <= target < self.n):
            raise ValueError("source/target out of range")

    def solve_dijkstra(self):
        n = self.n
        c = self.cost
        # standard Dijkstra; treats inf entries as missing edges
        INF = float("inf")
        dist = [INF] * n
        prev = [-1] * n
        dist[self.source] = 0

        heap = [(0.0, self.source)]
        while heap:
            d, u = heapq.heappop(heap)
            if d > dist[u]:
                continue
            if u == self.target:
                break
            for v in range(n):
                if v == u:
                    continue
                w = c[u, v]
                if not np.isfinite(w):
                    continue
                if w < 0:
                    raise ValueError("Dijkstra requires non-negative edge weights")
                nd = d + w
                if nd < dist[v]:
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(heap, (nd, v))

        if dist[self.target] == INF:
            return ShortestPathSolution(status="Infeasible", distance=INF, path=[])

        # reconstruct path
        path = []
        cur = self.target
        while cur != -1:
            path.append(cur)
            cur = prev[cur]
        path.reverse()

        return ShortestPathSolution(
            status="Optimal",
            distance=float(dist[self.target]),
            path=path,
        )

    def solve_lp(self):
        n = self.n
        c = self.cost
        s, t = self.source, self.target

        problem = build_problem("shortest_path", sense="min")

        edges = [(i, j) for i in range(n) for j in range(n)
                 if i != j and np.isfinite(c[i, j])]
        x = {e: LpVariable(f"x{e[0]}_{e[1]}", lowBound=0) for e in edges}

        problem += lpSum(c[i, j] * x[i, j] for (i, j) in edges)

        # flow conservation
        for v in range(n):
            inflow = lpSum(x[i, v] for (i, j) in edges if j == v)
            outflow = lpSum(x[v, j] for (i, j) in edges if i == v)
            if v == s:
                problem += outflow - inflow == 1
            elif v == t:
                problem += outflow - inflow == -1
            else:
                problem += outflow - inflow == 0

        status = solve(problem)

        if status != "Optimal":
            return ShortestPathSolution(status=status, distance=float("inf"), path=[])

        # reconstruct path from x*
        path = [s]
        cur = s
        while cur != t:
            for (i, j) in edges:
                if i == cur and value(x[i, j]) > 0.5:
                    path.append(j)
                    cur = j
                    break
            else:
                break

        return ShortestPathSolution(
            status=status,
            distance=value(problem.objective),
            path=path,
        )

    def solve(self):
        return self.solve_dijkstra()
