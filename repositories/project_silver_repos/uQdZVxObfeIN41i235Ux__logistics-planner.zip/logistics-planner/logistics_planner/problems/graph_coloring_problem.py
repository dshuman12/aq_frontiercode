from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class GraphColoringSolution:
    status: str
    chromatic_number: int
    coloring: dict


class GraphColoringProblem:
    """Vertex coloring: assign colors to vertices so adjacent vertices have
    different colors, minimizing the number of colors used.

    Formulated as a MIP with up to max_colors colors available.
    """

    def __init__(self, adjacency_matrix, max_colors=None):
        self.adjacency = np.asarray(adjacency_matrix, dtype=int)
        self.n = self.adjacency.shape[0]

        if self.adjacency.shape != (self.n, self.n):
            raise ValueError(
                f"adjacency must be square, got {self.adjacency.shape}"
            )
        # symmetrize and zero the diagonal
        self.adjacency = ((self.adjacency + self.adjacency.T) > 0).astype(int)
        np.fill_diagonal(self.adjacency, 0)

        # default upper bound on colors: degree + 1
        self.max_colors = max_colors if max_colors is not None else self.n

    def solve_mip(self):
        n = self.n
        K = self.max_colors
        adj = self.adjacency

        problem = build_problem("graph_coloring", sense="min")

        x = [[LpVariable(f"x{v}_{c}", cat='Binary')
              for c in range(K)] for v in range(n)]
        y = [LpVariable(f"y{c}", cat='Binary') for c in range(K)]

        problem += lpSum(y[c] for c in range(K))

        # each vertex gets exactly one color
        for v in range(n):
            problem += lpSum(x[v][c] for c in range(K)) == 1

        # adjacent vertices must differ
        for u in range(n):
            for v in range(u + 1, n):
                if adj[u, v]:
                    for c in range(K):
                        problem += x[u][c] + x[v][c] <= 1

        # symmetry breaking: y[c] >= y[c+1]
        for c in range(K - 1):
            problem += y[c] >= y[c + 1]

        # link x to y
        for v in range(n):
            for c in range(K):
                problem += x[v][c] <= y[c]

        status = solve(problem)

        if status != "Optimal":
            return GraphColoringSolution(
                status=status, chromatic_number=0, coloring={},
            )

        coloring = {}
        for v in range(n):
            for c in range(K):
                if value(x[v][c]) is not None and value(x[v][c]) > 0.5:
                    coloring[v] = c
                    break

        chromatic = int(round(value(problem.objective)))

        return GraphColoringSolution(
            status=status,
            chromatic_number=chromatic,
            coloring=coloring,
        )

    def solve_greedy(self):
        """Greedy coloring (Welsh-Powell): order vertices by degree, color
        each with the smallest unused color among its neighbors."""
        n = self.n
        adj = self.adjacency

        degrees = adj.sum(axis=1)
        order = sorted(range(n), key=lambda v: -degrees[v])

        coloring = {}
        for v in order:
            forbidden = {coloring[u] for u in range(n)
                         if adj[v, u] and u in coloring}
            c = 0
            while c in forbidden:
                c += 1
            coloring[v] = c

        chromatic = max(coloring.values()) + 1 if coloring else 0
        return GraphColoringSolution(
            status="Heuristic",
            chromatic_number=chromatic,
            coloring=coloring,
        )

    def solve(self):
        return self.solve_greedy()
