import math
from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class CuttingStockSolution:
    status: str
    rolls_used: float
    pattern_counts: dict


class CuttingStockProblem:
    """1D cutting stock: stock rolls of length L, need n_i copies of width w_i.
    Minimize total rolls used.

    For small instances we enumerate all feasible patterns.
    """

    def __init__(self, roll_length, item_widths, demands):
        self.roll_length = float(roll_length)
        self.widths = np.asarray(item_widths, dtype=float)
        self.demands = np.asarray(demands, dtype=int)
        self.m = len(self.widths)

        if len(self.demands) != self.m:
            raise ValueError(
                f"len(demands)={len(self.demands)} != len(widths)={self.m}"
            )
        if (self.widths > self.roll_length + 1e-9).any():
            raise ValueError("at least one item is wider than the roll")

    def enumerate_patterns(self):
        """Generate all maximal patterns by recursion."""
        L = self.roll_length
        widths = self.widths
        m = self.m
        max_counts = [int(L // w) for w in widths]
        patterns = []

        def recurse(idx, remaining, current):
            if idx == m:
                if any(c > 0 for c in current):
                    patterns.append(tuple(current))
                return
            for c in range(min(int(remaining // widths[idx]), max_counts[idx]) + 1):
                current.append(c)
                recurse(idx + 1, remaining - c * widths[idx], current)
                current.pop()

        recurse(0, L, [])

        # filter to maximal: remove patterns dominated component-wise by another
        return patterns

    def solve(self):
        patterns = self.enumerate_patterns()
        n_patterns = len(patterns)
        m = self.m

        problem = build_problem("cutting_stock", sense="min")
        x = [LpVariable(f"p{p}", lowBound=0, cat='Integer')
             for p in range(n_patterns)]

        problem += lpSum(x[p] for p in range(n_patterns))

        for i in range(m):
            problem += lpSum(patterns[p][i] * x[p]
                             for p in range(n_patterns)) >= self.demands[i]

        status = solve(problem)

        pattern_counts = {}
        if status == "Optimal":
            for p in range(n_patterns):
                v = value(x[p])
                if v is not None and v > 1e-6:
                    pattern_counts[patterns[p]] = int(round(v))

        return CuttingStockSolution(
            status=status,
            rolls_used=value(problem.objective) if status == "Optimal" else 0.0,
            pattern_counts=pattern_counts,
        )

    def first_fit_decreasing_lower_bound(self):
        """Lower bound on rolls used: pack items decreasingly into rolls."""
        items = []
        for i, w in enumerate(self.widths):
            for _ in range(int(self.demands[i])):
                items.append(w)
        items.sort(reverse=True)

        rolls = []
        for w in items:
            placed = False
            for r in rolls:
                if r + w <= self.roll_length + 1e-9:
                    rolls.append(r + w)
                    placed = True
                    break
            if not placed:
                rolls.append(w)
        return len(rolls)
