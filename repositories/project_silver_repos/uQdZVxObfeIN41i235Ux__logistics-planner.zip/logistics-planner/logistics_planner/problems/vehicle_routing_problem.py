from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve
from logistics_planner.utils import validate_square_matrix


@dataclass
class VRPSolution:
    status: str
    total_distance: float
    routes: list


class VehicleRoutingProblem:
    """Capacitated VRP: K vehicles, each starting and ending at depot 0.
    Visit each customer exactly once. Sum of demands per route <= capacity.
    """

    def __init__(self, distance_matrix, demands, num_vehicles, capacity):
        self.distance_matrix = np.asarray(distance_matrix, dtype=float)
        self.n = validate_square_matrix("distance_matrix", self.distance_matrix)
        self.demands = np.asarray(demands, dtype=float)
        self.num_vehicles = int(num_vehicles)
        self.capacity = float(capacity)

        if len(self.demands) != self.n:
            raise ValueError(
                f"len(demands)={len(self.demands)} != n={self.n}"
            )
        # depot demand must be zero
        if abs(self.demands[0]) > 1e-9:
            raise ValueError("depot (index 0) must have demand 0")

    def solve_mip(self):
        n = self.n
        K = self.num_vehicles
        D = self.distance_matrix
        d = self.demands
        Q = self.capacity

        problem = build_problem("vrp", sense="min")

        # x[i,j,k] = 1 if vehicle k traverses arc (i, j)
        x = {}
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                for k in range(K):
                    x[i, j, k] = LpVariable(f"x{i}_{j}_{k}", cat='Binary')

        # MTZ-style auxiliary vars per vehicle
        u = [[LpVariable(f"u{i}_{k}", lowBound=0, upBound=Q)
              for k in range(K)]
             for i in range(n)]

        # objective: sum of arc costs
        problem += lpSum(D[i, j] * x[i, j, k]
                         for i in range(n) for j in range(n) for k in range(K)
                         if i != j)

        # each customer visited exactly once across all vehicles
        for j in range(1, n):
            problem += lpSum(x[i, j, k]
                             for i in range(n) if i != j
                             for k in range(K)) == 1

        # flow conservation per vehicle per node
        for k in range(K):
            for v in range(n):
                inflow = lpSum(x[i, v, k] for i in range(n) if i != v)
                outflow = lpSum(x[v, j, k] for j in range(n) if j != v)
                problem += inflow == outflow

        # each vehicle leaves depot at most once
        for k in range(K):
            problem += lpSum(x[0, j, k] for j in range(1, n)) <= 1

        # capacity via subtour elimination: if vehicle k goes i->j, then
        # u[j,k] >= u[i,k] + d[j] (only when both i and j are non-depot)
        for k in range(K):
            for i in range(1, n):
                for j in range(1, n):
                    if i != j:
                        problem += u[j][k] >= u[i][k] + d[j] - Q * (1 - x[i, j, k])

        # initial load >= demand at first stop
        for k in range(K):
            for j in range(1, n):
                problem += u[j][k] >= d[j] * lpSum(x[i, j, k] for i in range(n) if i != j)

        status = solve(problem)

        if status != "Optimal":
            return VRPSolution(status=status, total_distance=0.0, routes=[])

        # reconstruct routes
        routes = []
        for k in range(K):
            route = [0]
            current = 0
            visited = {0}
            while True:
                nxt = None
                for j in range(n):
                    if j != current and j not in visited \
                            and value(x[current, j, k]) is not None \
                            and value(x[current, j, k]) > 0.5:
                        nxt = j
                        break
                if nxt is None:
                    break
                route.append(nxt)
                visited.add(nxt)
                current = nxt
                if len(route) > n:  # safety
                    break
            if len(route) > 1:
                route.append(0)  # close the loop
                routes.append(route)

        return VRPSolution(
            status=status,
            total_distance=value(problem.objective),
            routes=routes,
        )

    def solve_clarke_wright(self):
        """Classical Clarke-Wright savings heuristic (parallel version)."""
        n = self.n
        D = self.distance_matrix
        d = self.demands
        Q = self.capacity

        # initial: one route per customer (0 -> i -> 0)
        routes = {i: [0, i, 0] for i in range(1, n)}
        loads = {i: d[i] for i in range(1, n)}

        # compute savings s_ij = D[0,i] + D[0,j] - D[i,j]
        savings = []
        for i in range(1, n):
            for j in range(i + 1, n):
                s = D[0, i] + D[0, j] - D[i, j]
                savings.append((s, i, j))
        savings.sort(reverse=True)

        # endpoint -> route id mapping
        endpoint_to_route = {i: i for i in range(1, n)}

        for s, i, j in savings:
            r_i = endpoint_to_route.get(i)
            r_j = endpoint_to_route.get(j)
            if r_i is None or r_j is None or r_i == r_j:
                continue
            if r_i not in routes or r_j not in routes:
                continue

            route_i = routes[r_i]
            route_j = routes[r_j]
            if loads[r_i] + loads[r_j] > Q:
                continue

            # i must be at the right end of route_i (just before depot)
            # j must be at the left end of route_j (just after depot)
            if route_i[-2] == i and route_j[1] == j:
                merged = route_i[:-1] + route_j[1:]
                new_load = loads[r_i] + loads[r_j]
                routes[r_i] = merged
                loads[r_i] = new_load
                # mark interior endpoints as merged-in
                for c in route_j[1:-1]:
                    endpoint_to_route.pop(c, None)
                left_end = merged[1]
                right_end = merged[-2]
                endpoint_to_route[left_end] = r_i
                endpoint_to_route[right_end] = r_i
                # remove the merged-in route
                del routes[r_j]
                del loads[r_j]

        final_routes = list(routes.values())
        total = 0.0
        for r in final_routes:
            for k in range(len(r) - 1):
                total += D[r[k], r[k + 1]]

        return VRPSolution(
            status="Heuristic",
            total_distance=float(total),
            routes=final_routes,
        )

    def solve(self):
        return self.solve_clarke_wright()
