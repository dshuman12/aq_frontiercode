from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import (
    build_problem,
    solve,
    extract_binary_selection,
)


@dataclass
class KnapsackSolution:
    status: str
    total_value: float
    selected: list

    def num_selected(self):
        return len(self.selected)


class ZeroOneKnapsack:
    def __init__(self, values, weights, capacity):
        self.values = np.asarray(values, dtype=float)
        self.weights = np.asarray(weights, dtype=float)
        self.capacity = float(capacity)
        self.n = len(self.values)

        if len(self.weights) != self.n:
            raise ValueError(
                f"len(weights)={len(self.weights)} != len(values)={self.n}"
            )
        if (self.weights < 0).any():
            raise ValueError("weights must be non-negative")

    def solve_dp(self):
        # standard O(n * W) DP, requires integer weights and capacity
        n = self.n
        v = self.values
        w = self.weights.astype(int)
        W = int(self.capacity)

        if not np.allclose(w, self.weights):
            # fall back to LP for non-integer weights
            return self.solve_mip()

        dp = np.zeros((n + 1, W + 1))
        for i in range(1, n + 1):
            wi, vi = int(w[i - 1]), v[i - 1]
            for cap in range(W + 1):
                dp[i, cap] = dp[i - 1, cap]
                if wi <= cap and dp[i - 1, cap - wi] + vi > dp[i, cap]:
                    dp[i, cap] = dp[i - 1, cap - wi] + vi

        # backtrack to recover items
        selected = []
        cap = W
        for i in range(n, 0, -1):
            if dp[i, cap] != dp[i - 1, cap]:
                selected.append(i - 1)
                cap -= int(w[i - 1])
        selected.reverse()

        return KnapsackSolution(
            status="Optimal",
            total_value=float(dp[n, W]),
            selected=selected,
        )

    def solve_mip(self):
        n = self.n
        v = self.values
        w = self.weights
        W = self.capacity

        problem = build_problem("zero_one_knapsack", sense="max")
        x = [LpVariable(f"x{i+1}", cat='Binary') for i in range(n)]

        problem += lpSum(v[i] * x[i] for i in range(n))
        problem += lpSum(w[i] * x[i] for i in range(n)) <= W

        status = solve(problem)

        selected = extract_binary_selection(x)

        return KnapsackSolution(
            status=status,
            total_value=value(problem.objective) if status == "Optimal" else 0.0,
            selected=selected,
        )

    def solve(self):
        return self.solve_dp()
