from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import (
    build_problem,
    solve,
    extract_binary_selection,
)


@dataclass
class MultiDimKnapsackSolution:
    status: str
    total_value: float
    selected: list


class MultiDimensionalKnapsack:
    def __init__(self, values, weight_matrix, capacities):
        self.values = np.asarray(values, dtype=float)
        self.weight_matrix = np.asarray(weight_matrix, dtype=float)
        self.capacities = np.asarray(capacities, dtype=float)
        self.n = len(self.values)
        self.k = len(self.capacities)

        if self.weight_matrix.shape != (self.k, self.n):
            raise ValueError(
                f"weight matrix shape {self.weight_matrix.shape} does not match "
                f"(constraints, items) = ({self.k}, {self.n})"
            )

    def solve(self):
        n = self.n
        k = self.k
        v = self.values
        W = self.weight_matrix
        cap = self.capacities

        problem = build_problem("multi_dim_knapsack", sense="max")
        x = [LpVariable(f"x{i+1}", cat='Binary') for i in range(n)]

        problem += lpSum(v[i] * x[i] for i in range(n))

        for r in range(k):
            problem += lpSum(W[r, i] * x[i] for i in range(n)) <= cap[r]

        status = solve(problem)

        selected = extract_binary_selection(x)

        return MultiDimKnapsackSolution(
            status=status,
            total_value=value(problem.objective) if status == "Optimal" else 0.0,
            selected=selected,
        )
