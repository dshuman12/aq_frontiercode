from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class MaxCliqueSolution:
    status: str
    size: int
    clique: list


class MaximumCliqueProblem:
    """Find the largest complete subgraph (clique) in a graph.

    MIP: maximize sum(x_v) s.t. x_u + x_v <= 1 for each non-edge (u, v).
    """

    def __init__(self, adjacency_matrix):
        self.adjacency = np.asarray(adjacency_matrix, dtype=int)
        self.n = self.adjacency.shape[0]

        if self.adjacency.shape != (self.n, self.n):
            raise ValueError(
                f"adjacency must be square, got {self.adjacency.shape}"
            )
        # symmetrize, zero diagonal
        self.adjacency = ((self.adjacency + self.adjacency.T) > 0).astype(int)
        np.fill_diagonal(self.adjacency, 0)

    def solve_mip(self):
        n = self.n
        adj = self.adjacency

        problem = build_problem("max_clique", sense="max")
        x = [LpVariable(f"x{v}", cat='Binary') for v in range(n)]

        problem += lpSum(x[v] for v in range(n))

        # for each non-edge (u, v), at most one of them can be in the clique
        for u in range(n):
            for v in range(u + 1, n):
                if not adj[u, v]:
                    problem += x[u] + x[v] <= 1

        status = solve(problem)

        if status != "Optimal":
            return MaxCliqueSolution(status=status, size=0, clique=[])

        clique = [v for v in range(n)
                  if value(x[v]) is not None and value(x[v]) > 0.5]

        return MaxCliqueSolution(
            status=status,
            size=len(clique),
            clique=clique,
        )

    def solve_greedy(self):
        """Greedy clique: sort by degree, add vertices that connect to all
        already-selected ones."""
        n = self.n
        adj = self.adjacency
        order = sorted(range(n), key=lambda v: -adj[v].sum())

        clique = []
        for v in order:
            if all(adj[v, u] for u in clique):
                clique.append(v)

        return MaxCliqueSolution(
            status="Heuristic",
            size=len(clique),
            clique=sorted(clique),
        )

    def solve(self):
        return self.solve_mip()
