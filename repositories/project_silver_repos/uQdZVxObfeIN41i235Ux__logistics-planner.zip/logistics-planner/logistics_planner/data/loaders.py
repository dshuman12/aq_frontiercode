import json
import numpy as np


def _read_json(path):
    with open(path) as f:
        return json.load(f)


def load_facility_instance(path):
    d = _read_json(path)
    return (
        np.asarray(d["cost_facilities"]),
        np.asarray(d["max_amounts"]),
        np.asarray(d["cost_suppliers"]),
        np.asarray(d["annual_demands"]),
    )


def load_transportation_instance(path):
    d = _read_json(path)
    return (
        np.asarray(d["supply"]),
        np.asarray(d["demand"]),
        np.asarray(d["cost_matrix"]),
    )


def load_lot_sizing_instance(path):
    d = _read_json(path)
    return (
        np.asarray(d["demand"]),
        np.asarray(d["setup_costs"]),
        np.asarray(d["holding_costs"]),
        np.asarray(d["production_costs"]),
        d["capacity"],
    )


def load_blending_instance(path):
    d = _read_json(path)
    return (
        list(d["materials"]),
        np.asarray(d["costs"]),
        np.asarray(d["property_matrix"]),
        np.asarray(d["lower_bounds"]),
        np.asarray(d["upper_bounds"]),
        d["output_quantity"],
    )


def load_diet_instance(path):
    d = _read_json(path)
    return (
        list(d["foods"]),
        np.asarray(d["costs"]),
        np.asarray(d["nutrient_matrix"]),
        np.asarray(d["requirements"]),
    )


def load_tsp_instance(path):
    d = _read_json(path)
    return np.asarray(d["distance_matrix"])
