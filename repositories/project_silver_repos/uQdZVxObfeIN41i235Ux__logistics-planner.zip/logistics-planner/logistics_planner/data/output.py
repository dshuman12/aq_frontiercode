import json
import dataclasses
import numpy as np
import pandas as pd


def _to_serializable(obj):
    if dataclasses.is_dataclass(obj):
        obj = dataclasses.asdict(obj)
    if isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serializable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    return obj


def print_solution(solution, title=None):
    if title:
        print(f"=== {title} ===")
    if dataclasses.is_dataclass(solution):
        d = dataclasses.asdict(solution)
    elif isinstance(solution, dict):
        d = solution
    else:
        print(solution)
        return

    for k, v in d.items():
        if isinstance(v, np.ndarray):
            print(f"{k}:")
            print(v)
        else:
            print(f"{k}: {v}")


def export_csv(solution, path):
    # for solutions whose primary payload is a 2D matrix or a 1D vector
    if dataclasses.is_dataclass(solution):
        d = dataclasses.asdict(solution)
    else:
        d = dict(solution)

    rows = []
    for k, v in d.items():
        if isinstance(v, np.ndarray):
            df = pd.DataFrame(v)
            df.to_csv(path, index=False, header=False)
            return
        rows.append({"field": k, "value": v})

    pd.DataFrame(rows).to_csv(path, index=False)


def export_json(solution, path):
    payload = _to_serializable(solution)
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
