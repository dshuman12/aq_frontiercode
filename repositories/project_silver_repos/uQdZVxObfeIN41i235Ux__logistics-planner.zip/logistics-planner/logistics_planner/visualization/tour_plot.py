def plot_tour(coordinates, tour, title="TSP Tour", show=True, savepath=None):
    # lazy import so matplotlib stays optional
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise RuntimeError("matplotlib is required for plotting; pip install matplotlib")

    coords = list(coordinates)
    fig, ax = plt.subplots()

    xs = [coords[i][0] for i in tour]
    ys = [coords[i][1] for i in tour]
    ax.plot(xs, ys, "-o")

    for idx, (x, y) in enumerate(coords):
        ax.annotate(str(idx), (x, y))

    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.grid(True, alpha=0.3)

    if savepath:
        fig.savefig(savepath, bbox_inches="tight")
    if show:
        plt.show()
    return fig
