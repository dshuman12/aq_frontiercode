import numpy as np


def plot_flow_matrix(flow_matrix, source=None, sink=None,
                     title="Flow", show=True, savepath=None):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise RuntimeError("matplotlib is required for plotting; pip install matplotlib")

    F = np.asarray(flow_matrix, dtype=float)
    n = F.shape[0]

    fig, ax = plt.subplots(figsize=(6, 6))

    # nodes on a circle
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
    xs = np.cos(angles)
    ys = np.sin(angles)

    for i in range(n):
        color = "red" if i == source else ("green" if i == sink else "lightblue")
        ax.scatter(xs[i], ys[i], s=400, c=color, edgecolors="black", zorder=3)
        ax.annotate(str(i), (xs[i], ys[i]), ha="center", va="center", zorder=4)

    max_flow = F.max() if F.max() > 0 else 1
    for i in range(n):
        for j in range(n):
            if F[i, j] > 1e-6:
                width = 0.5 + 3.0 * (F[i, j] / max_flow)
                ax.annotate(
                    "", xy=(xs[j], ys[j]), xytext=(xs[i], ys[i]),
                    arrowprops=dict(arrowstyle="->", lw=width, color="gray"),
                    zorder=2,
                )
                mx, my = (xs[i] + xs[j]) / 2, (ys[i] + ys[j]) / 2
                ax.text(mx, my, f"{F[i, j]:.1f}", fontsize=8,
                        ha="center", va="center", zorder=5,
                        bbox=dict(boxstyle="round", fc="white", alpha=0.7))

    ax.set_title(title)
    ax.set_aspect("equal")
    ax.set_xlim(-1.5, 1.5)
    ax.set_ylim(-1.5, 1.5)
    ax.axis("off")

    if savepath:
        fig.savefig(savepath, bbox_inches="tight")
    if show:
        plt.show()
    return fig
