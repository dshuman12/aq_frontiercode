import numpy as np


class DualSimplex:
    """Dual simplex method.

    Solves: min c^T x  s.t.  A x = b,  x >= 0
    Starts from a dual-feasible basis (objective row >= 0) and iterates by
    selecting a leaving variable with negative b_i and an entering variable
    by the dual ratio test.
    """

    def __init__(self, c, A, b):
        self.c = np.asarray(c, dtype=float)
        self.A = np.asarray(A, dtype=float)
        self.b = np.asarray(b, dtype=float)
        self.m, self.n = self.A.shape

        if len(self.c) != self.n:
            raise ValueError(f"c length {len(self.c)} != n {self.n}")
        if len(self.b) != self.m:
            raise ValueError(f"b length {len(self.b)} != m {self.m}")

    def _pivot(self, tab, row, col):
        tab[row] = tab[row] / tab[row, col]
        for r in range(tab.shape[0]):
            if r != row and abs(tab[r, col]) > 1e-12:
                tab[r] = tab[r] - tab[r, col] * tab[row]

    def _select_leaving_row(self, tab):
        # most negative b_i row leaves
        best_i = None
        best_val = -1e-9
        for i in range(tab.shape[0] - 1):
            if tab[i, -1] < best_val:
                best_val = tab[i, -1]
                best_i = i
        return best_i

    def _select_entering_column(self, tab, leaving_row):
        # ratio test on the leaving row's negative entries
        best_col = None
        best_ratio = float("inf")
        for j in range(tab.shape[1] - 1):
            a_ij = tab[leaving_row, j]
            if a_ij < -1e-9:
                ratio = -tab[-1, j] / a_ij
                if ratio < best_ratio:
                    best_ratio = ratio
                    best_col = j
        return best_col

    def solve(self, max_iter=2000):
        m, n = self.m, self.n

        # build tableau assuming identity basis at columns n..n+m-1 (slack basis)
        # caller is expected to provide A in standard form with that structure
        tab = np.zeros((m + 1, n + 1))
        tab[:m, :n] = self.A
        tab[:m, -1] = self.b
        tab[-1, :n] = self.c

        basis = list(range(n - m, n))  # last m columns assumed identity basis

        for _ in range(max_iter):
            row = self._select_leaving_row(tab)
            if row is None:
                # primal feasible and dual optimal
                break
            col = self._select_entering_column(tab, row)
            if col is None:
                raise ValueError("LP is infeasible (dual unbounded)")
            self._pivot(tab, row, col)
            basis[row] = col

        x = np.zeros(n)
        for i, b_idx in enumerate(basis):
            if 0 <= b_idx < n:
                x[b_idx] = tab[i, -1]

        z = -tab[-1, -1]
        return x, z
