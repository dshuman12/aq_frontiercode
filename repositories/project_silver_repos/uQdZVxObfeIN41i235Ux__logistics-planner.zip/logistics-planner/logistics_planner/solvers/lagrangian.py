from dataclasses import dataclass, field
import numpy as np


@dataclass
class LagrangianResult:
    best_lower_bound: float
    best_upper_bound: float
    multipliers: np.ndarray
    iterations: int
    history: list = field(default_factory=list)


class LagrangianRelaxation:
    """Subgradient-based Lagrangian relaxation.

    Caller provides:
    - lagrangian_subproblem(multipliers) -> (subproblem_value, subgradient, primal_x)
        where subgradient_i = a_i^T x* - b_i for relaxed constraints  a_i^T x <= b_i
    - feasibility_repair(primal_x) -> (is_feasible, primal_value)
        used to obtain valid upper bound (assuming maximization of value)
    """

    def __init__(self, lagrangian_subproblem, feasibility_repair=None,
                 num_relaxed=1, maximize=True,
                 max_iterations=200, initial_step=2.0,
                 step_decay=0.95):
        self.lagrangian_subproblem = lagrangian_subproblem
        self.feasibility_repair = feasibility_repair
        self.num_relaxed = num_relaxed
        self.maximize = maximize
        self.max_iterations = max_iterations
        self.initial_step = initial_step
        self.step_decay = step_decay

    def run(self):
        u = np.zeros(self.num_relaxed, dtype=float)
        step = self.initial_step

        if self.maximize:
            best_lb = -np.inf  # primal feasible value
            best_ub = +np.inf  # Lagrangian dual gives upper bound
        else:
            best_lb = -np.inf  # Lagrangian dual gives lower bound
            best_ub = +np.inf  # primal feasible value

        history = []
        iters = 0

        for it in range(self.max_iterations):
            iters += 1
            sub_value, subgrad, primal = self.lagrangian_subproblem(u)
            history.append(sub_value)

            if self.maximize:
                if sub_value < best_ub:
                    best_ub = sub_value
            else:
                if sub_value > best_lb:
                    best_lb = sub_value

            if self.feasibility_repair is not None:
                feasible, primal_val = self.feasibility_repair(primal)
                if feasible:
                    if self.maximize and primal_val > best_lb:
                        best_lb = primal_val
                    elif (not self.maximize) and primal_val < best_ub:
                        best_ub = primal_val

            # subgradient step on multipliers
            norm_sq = float(np.dot(subgrad, subgrad))
            if norm_sq < 1e-12:
                break

            if self.maximize:
                # min over u >= 0 of sub_value -> step against subgrad
                u = np.maximum(u - step * subgrad, 0)
            else:
                u = np.maximum(u + step * subgrad, 0)

            step *= self.step_decay

        return LagrangianResult(
            best_lower_bound=best_lb,
            best_upper_bound=best_ub,
            multipliers=u,
            iterations=iters,
            history=history,
        )
