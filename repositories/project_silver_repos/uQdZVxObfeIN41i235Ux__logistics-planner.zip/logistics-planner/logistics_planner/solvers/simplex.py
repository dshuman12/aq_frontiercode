import numpy as np


class Simplex:
    def __init__(self, c, A, b):
        self.c = np.asarray(c, dtype=float)
        self.A = np.asarray(A, dtype=float)
        self.b = np.asarray(b, dtype=float)
        self.m, self.n = self.A.shape

        if len(self.c) != self.n:
            raise ValueError(f"c has length {len(self.c)}, expected {self.n}")
        if len(self.b) != self.m:
            raise ValueError(f"b has length {len(self.b)}, expected {self.m}")

    def solve(self, max_iter=1000):
        m, n = self.m, self.n

        # build initial tableau with slacks: [A | I | b]; objective row at bottom
        tableau = np.zeros((m + 1, n + m + 1))
        tableau[:m, :n] = self.A
        tableau[:m, n:n + m] = np.eye(m)
        tableau[:m, -1] = self.b
        tableau[-1, :n] = self.c

        # basis starts as the slack variables
        basis = list(range(n, n + m))

        for _ in range(max_iter):
            col = self._select_pivot_column(tableau)
            if col is None:
                break  # optimal

            row = self._select_pivot_row(tableau, col)
            if row is None:
                raise ValueError("Problem is unbounded")

            self._pivot(tableau, row, col)
            basis[row] = col

        x = np.zeros(n + m)
        for i, b_idx in enumerate(basis):
            x[b_idx] = tableau[i, -1]

        z = -tableau[-1, -1]
        return x[:n], z

    def _pivot(self, tableau, row, col):
        tableau[row] = tableau[row] / tableau[row, col]
        for r in range(tableau.shape[0]):
            if r != row and tableau[r, col] != 0:
                tableau[r] = tableau[r] - tableau[r, col] * tableau[row]

    def _select_pivot_column(self, tableau):
        # Bland's rule: smallest index with negative reduced cost
        last_row = tableau[-1, :-1]
        for j in range(len(last_row)):
            if last_row[j] < -1e-9:
                return j
        return None

    def _select_pivot_row(self, tableau, col):
        # min ratio test
        ratios = []
        for i in range(tableau.shape[0] - 1):
            if tableau[i, col] > 1e-9:
                ratios.append((tableau[i, -1] / tableau[i, col], i))
        if not ratios:
            return None
        return min(ratios)[1]
