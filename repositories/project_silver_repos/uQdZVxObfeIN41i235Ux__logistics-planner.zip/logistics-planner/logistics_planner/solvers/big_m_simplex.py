import numpy as np


BIG_M = 1e6


class BigMSimplex:
    """Big-M method for LPs without obvious initial feasible basis.

    Solves: minimize c^T x  s.t.  A x = b,  x >= 0
    Adds an artificial variable per row penalized by M in the objective.
    """

    def __init__(self, c, A, b, M=BIG_M):
        self.c = np.asarray(c, dtype=float)
        self.A = np.asarray(A, dtype=float)
        self.b = np.asarray(b, dtype=float)
        self.M = M
        self.m, self.n = self.A.shape

        if len(self.c) != self.n:
            raise ValueError(f"c length {len(self.c)} != n {self.n}")
        if len(self.b) != self.m:
            raise ValueError(f"b length {len(self.b)} != m {self.m}")

    def solve(self, max_iter=5000):
        m, n = self.m, self.n
        M = self.M

        # ensure b >= 0 by flipping rows
        A = self.A.copy()
        b = self.b.copy()
        for i in range(m):
            if b[i] < 0:
                A[i] = -A[i]
                b[i] = -b[i]

        # tableau: [A | I | b], add artificial vars one per row
        # objective row: [c | M*1 | 0]
        c_aug = np.concatenate([self.c, np.full(m, M)])
        A_aug = np.hstack([A, np.eye(m)])

        tableau = np.zeros((m + 1, n + m + 1))
        tableau[:m, :n + m] = A_aug
        tableau[:m, -1] = b

        # initial basis is the artificial vars; price out so objective row is reduced
        basis = list(range(n, n + m))
        # objective row starts as c_aug
        tableau[-1, :n + m] = c_aug
        # subtract M times each artificial row to make them basic
        for i in range(m):
            tableau[-1] -= M * tableau[i]

        for _ in range(max_iter):
            # pick entering var (most negative reduced cost, Bland's rule on tie)
            row = tableau[-1, :-1]
            mins = [(j, row[j]) for j in range(len(row)) if row[j] < -1e-9]
            if not mins:
                break
            entering = min(mins, key=lambda p: (p[1], p[0]))[0]

            # min ratio test
            ratios = []
            for i in range(m):
                if tableau[i, entering] > 1e-9:
                    ratios.append((tableau[i, -1] / tableau[i, entering], i))
            if not ratios:
                raise ValueError("LP is unbounded")
            leaving = min(ratios)[1]

            # pivot
            tableau[leaving] = tableau[leaving] / tableau[leaving, entering]
            for r in range(m + 1):
                if r != leaving and abs(tableau[r, entering]) > 1e-12:
                    tableau[r] = tableau[r] - tableau[r, entering] * tableau[leaving]
            basis[leaving] = entering

        x = np.zeros(n + m)
        for i, b_idx in enumerate(basis):
            x[b_idx] = tableau[i, -1]

        # check no artificial vars are positive in optimum (else infeasible)
        for j in range(n, n + m):
            if x[j] > 1e-12:
                raise ValueError("LP is infeasible (artificial variable in basis)")

        z = -tableau[-1, -1]
        return x[:n], z
