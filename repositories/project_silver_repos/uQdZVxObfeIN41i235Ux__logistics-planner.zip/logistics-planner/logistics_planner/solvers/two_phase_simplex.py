import numpy as np


class TwoPhaseSimplex:
    """Two-phase simplex.

    Phase 1: minimize sum of artificial vars to find a feasible basis.
    Phase 2: optimize the original objective from that basis.
    """

    def __init__(self, c, A, b):
        self.c = np.asarray(c, dtype=float)
        self.A = np.asarray(A, dtype=float)
        self.b = np.asarray(b, dtype=float)
        self.m, self.n = self.A.shape

        if len(self.c) != self.n:
            raise ValueError(f"c length {len(self.c)} != n {self.n}")
        if len(self.b) != self.m:
            raise ValueError(f"b length {len(self.b)} != m {self.m}")

    def _pivot(self, tab, row, col):
        tab[row] = tab[row] / tab[row, col]
        for r in range(tab.shape[0]):
            if r != row and abs(tab[r, col]) > 1e-12:
                tab[r] = tab[r] - tab[r, col] * tab[row]

    def _select_pivot_column(self, tab):
        last = tab[-1, :-1]
        for j in range(len(last)):
            if last[j] < -1e-9:
                return j
        return None

    def _select_pivot_row(self, tab, col):
        ratios = []
        for i in range(tab.shape[0] - 1):
            if tab[i, col] > 1e-9:
                ratios.append((tab[i, -1] / tab[i, col], i))
        if not ratios:
            return None
        return min(ratios)[1]

    def _run_simplex(self, tab, basis, max_iter=2000):
        for _ in range(max_iter):
            col = self._select_pivot_column(tab)
            if col is None:
                return tab, basis
            row = self._select_pivot_row(tab, col)
            if row is None:
                raise ValueError("LP is unbounded")
            self._pivot(tab, row, col)
            basis[row] = col
        return tab, basis

    def solve(self, max_iter=2000):
        m, n = self.m, self.n
        A = self.A.copy()
        b = self.b.copy()

        for i in range(m):
            if b[i] < 0:
                A[i] = -A[i]
                b[i] = -b[i]

        # Phase 1: artificial vars added, objective is sum of artificials
        tab = np.zeros((m + 1, n + m + 1))
        tab[:m, :n] = A
        tab[:m, n:n + m] = np.eye(m)
        tab[:m, -1] = b
        tab[-1, n:n + m] = 1.0

        basis = list(range(n, n + m))

        # price out the artificial vars in the objective row
        for i in range(m):
            tab[-1] -= tab[i]

        tab, basis = self._run_simplex(tab, basis, max_iter)

        # if phase-1 objective > 0, infeasible
        if abs(tab[-1, -1]) > 1e-6:
            raise ValueError("LP is infeasible (phase 1 nonzero)")

        # drop artificial columns; switch to phase-2 objective
        tab2 = np.zeros((m + 1, n + 1))
        tab2[:m, :n] = tab[:m, :n]
        tab2[:m, -1] = tab[:m, -1]
        tab2[-1, :n] = self.c

        basis2 = []
        for b_idx in basis:
            if b_idx < n:
                basis2.append(b_idx)
            else:
                # an artificial is still basic at zero level - kick it out
                # by pivoting on any non-zero entry in its row
                row_index = basis.index(b_idx)
                # find any non-artificial non-zero
                replaced = False
                for j in range(n):
                    if abs(tab[row_index, j]) > 1e-9:
                        self._pivot(tab2, row_index, j)
                        basis2.append(j)
                        replaced = True
                        break
                if not replaced:
                    basis2.append(b_idx)  # degenerate row, will be ignored

        # price out the new objective so basis is reduced
        for i, b_idx in enumerate(basis2):
            if b_idx < n and abs(tab2[-1, b_idx]) > 1e-12:
                tab2[-1] -= tab2[-1, b_idx] * tab2[i]

        tab2, basis2 = self._run_simplex(tab2, basis2, max_iter)

        x = np.zeros(n)
        for i, b_idx in enumerate(basis2):
            if b_idx < n:
                x[b_idx] = tab2[i, -1]

        z = -tab2[-1, -1]
        return x, z
