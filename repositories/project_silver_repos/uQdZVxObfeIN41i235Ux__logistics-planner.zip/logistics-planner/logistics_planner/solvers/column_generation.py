from dataclasses import dataclass, field
import numpy as np
from pulp import LpProblem, LpVariable, LpMinimize, LpStatus, value, lpSum, PULP_CBC_CMD


@dataclass
class CGResult:
    status: str
    objective: float
    columns_added: int
    selected_columns: list = field(default_factory=list)
    history: list = field(default_factory=list)


class ColumnGeneration:
    """Generic column generation framework.

    Caller provides:
    - initial_columns: list of (cost, coefficient_vector) — must give a feasible start
    - rhs: array of RHS values (one per element/row constraint)
    - sense: 'min' or 'max'
    - pricing_oracle(duals) -> list of (reduced_cost, cost, coefficient_vector)
        Generates new candidate columns using current dual prices.
        Adds columns with negative reduced cost (for min) or positive (for max).

    Stops when no improving column is found.
    """

    def __init__(self, initial_columns, rhs, pricing_oracle,
                 sense="min", max_iterations=100, tolerance=1e-6):
        self.columns = list(initial_columns)
        self.rhs = np.asarray(rhs, dtype=float)
        self.pricing_oracle = pricing_oracle
        self.sense = sense
        self.max_iterations = max_iterations
        self.tolerance = tolerance

    def _solve_master(self):
        m = len(self.rhs)
        n = len(self.columns)

        prob = LpProblem("master", LpMinimize)
        x = [LpVariable(f"x{j}", lowBound=0) for j in range(n)]

        prob += lpSum(self.columns[j][0] * x[j] for j in range(n))

        constraints = []
        for i in range(m):
            c = lpSum(self.columns[j][1][i] * x[j] for j in range(n)) >= self.rhs[i]
            constraints.append(c)
            prob += c, f"c{i}"

        prob.solve(PULP_CBC_CMD(msg=0))

        status = LpStatus[prob.status]
        if status != "Optimal":
            return status, None, None, None

        x_vals = [value(x[j]) for j in range(n)]
        obj = value(prob.objective)
        duals = []
        for i in range(m):
            pi = prob.constraints[f"c{i}"].pi
            duals.append(pi if pi is not None else 0.0)

        return status, obj, x_vals, np.array(duals)

    def run(self):
        history = []
        added = 0

        for iteration in range(self.max_iterations):
            status, obj, x_vals, duals = self._solve_master()
            if status != "Optimal":
                return CGResult(status=status, objective=0.0, columns_added=added)

            history.append(obj)

            new_cols = self.pricing_oracle(duals)
            improving = []
            for rc, cost, coef in new_cols:
                if self.sense == "min" and rc < -self.tolerance:
                    improving.append((cost, np.asarray(coef, dtype=float)))
                elif self.sense == "max" and rc > self.tolerance:
                    improving.append((cost, np.asarray(coef, dtype=float)))

            if not improving:
                # no improving column - LP-optimal
                selected = [j for j, v in enumerate(x_vals or []) if v and v > self.tolerance]
                return CGResult(
                    status="Optimal",
                    objective=obj,
                    columns_added=added,
                    selected_columns=selected,
                    history=history,
                )

            for cost, coef in improving:
                self.columns.append((cost, coef))
                added += 1

        # ran out of iterations
        status, obj, x_vals, _ = self._solve_master()
        selected = [j for j, v in enumerate(x_vals or []) if v and v > self.tolerance]
        return CGResult(
            status="Iteration_Limit",
            objective=obj or 0.0,
            columns_added=added,
            selected_columns=selected,
            history=history,
        )
