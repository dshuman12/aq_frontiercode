import math
from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, LpStatus, value, lpSum, PULP_CBC_CMD

from logistics_planner.solvers.lp_solver import build_problem


EPS = 1e-6


@dataclass
class BranchAndBoundResult:
    status: str
    objective: float
    solution: dict


def _is_integer(v, tol=EPS):
    return abs(v - round(v)) < tol


def _solve_lp_relaxation(c, A_ub, b_ub, A_eq, b_eq, lb, ub, sense):
    n = len(c)
    problem = build_problem("bnb_lp", sense=sense)
    x = []
    for j in range(n):
        x.append(LpVariable(f"x{j+1}", lowBound=lb[j], upBound=ub[j]))

    problem += lpSum(c[j] * x[j] for j in range(n))

    if A_ub is not None:
        for i, row in enumerate(A_ub):
            problem += lpSum(row[j] * x[j] for j in range(n)) <= b_ub[i]
    if A_eq is not None:
        for i, row in enumerate(A_eq):
            problem += lpSum(row[j] * x[j] for j in range(n)) == b_eq[i]

    problem.solve(PULP_CBC_CMD(msg=0))
    status = LpStatus[problem.status]
    if status != "Optimal":
        return None, status, None

    sol = {f"x{j+1}": value(x[j]) for j in range(n)}
    obj = value(problem.objective)
    return obj, status, sol


def branch_and_bound(c, A_ub, b_ub, A_eq=None, b_eq=None,
                     lb=None, ub=None, integer_indices=None, sense="min"):
    n = len(c)
    if lb is None:
        lb = [0.0] * n
    if ub is None:
        ub = [None] * n
    if integer_indices is None:
        integer_indices = list(range(n))

    integer_set = set(integer_indices)

    # depth-first stack of (lb, ub) pairs
    best_obj = math.inf if sense == "min" else -math.inf
    best_sol = None

    stack = [(list(lb), list(ub))]

    iterations = 0
    max_iters = 5000

    while stack and iterations < max_iters:
        iterations += 1
        cur_lb, cur_ub = stack.pop()

        obj, status, sol = _solve_lp_relaxation(
            c, A_ub, b_ub, A_eq, b_eq, cur_lb, cur_ub, sense
        )
        if status != "Optimal":
            continue

        if sense == "min" and obj >= best_obj - EPS:
            continue
        if sense == "max" and obj <= best_obj + EPS:
            continue

        # find a fractional integer variable
        frac_idx = None
        for j in integer_set:
            v = sol[f"x{j+1}"]
            if not _is_integer(v):
                frac_idx = j
                break

        if frac_idx is None:
            # all integer-required variables are integer -> candidate
            if sense == "min" and obj < best_obj:
                best_obj = obj
                best_sol = sol
            if sense == "max" and obj > best_obj:
                best_obj = obj
                best_sol = sol
            continue

        # branch
        v = sol[f"x{frac_idx+1}"]
        floor_v = math.floor(v)
        ceil_v = math.ceil(v)

        new_ub = list(cur_ub)
        new_ub[frac_idx] = floor_v
        stack.append((list(cur_lb), new_ub))

        new_lb = list(cur_lb)
        new_lb[frac_idx] = ceil_v
        stack.append((new_lb, list(cur_ub)))

    if best_sol is None:
        return BranchAndBoundResult(status="Infeasible", objective=0.0, solution={})

    return BranchAndBoundResult(
        status="Optimal",
        objective=best_obj,
        solution=best_sol,
    )
