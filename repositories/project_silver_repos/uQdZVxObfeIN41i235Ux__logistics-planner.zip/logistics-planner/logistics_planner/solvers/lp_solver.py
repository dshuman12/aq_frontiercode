from pulp import LpProblem, LpMinimize, LpMaximize, LpStatus, LpVariable, value, PULP_CBC_CMD


def build_problem(name, sense="min"):
    obj_sense = LpMaximize if sense == "min" else LpMinimize
    return LpProblem(name, obj_sense)


def solve(problem, verbose=False):
    problem.solve(PULP_CBC_CMD(msg=int(bool(verbose))))
    return LpStatus[problem.status]


def get_value(var):
    return value(var)


def make_binary_vars(prefix, count):
    return [LpVariable(f"{prefix}{i+1}", cat='Binary') for i in range(count)]


def make_flow_vars(prefix, edges, capacity_lookup=None):
    out = {}
    for (i, j) in edges:
        upper = None
        if capacity_lookup is not None:
            upper = capacity_lookup(i, j)
        out[i, j] = LpVariable(f"{prefix}{i}_{j}", lowBound=0, upBound=upper)
    return out


def extract_binary_selection(variables, threshold=0.4):
    selected = []
    for idx, v in enumerate(variables):
        val = value(v)
        if val is not None and val > threshold:
            selected.append(idx)
    return selected
