from dataclasses import dataclass, field
import numpy as np
from pulp import LpProblem, LpVariable, LpStatus, value, lpSum, LpMinimize, LpMaximize, PULP_CBC_CMD


@dataclass
class CuttingPlanesResult:
    status: str
    objective: float
    solution: dict
    cuts_added: int
    iterations: int
    history: list = field(default_factory=list)


def _frac(x):
    return x - np.floor(x)


class CuttingPlanesSolver:
    """Naive cutting-plane method using fractional Gomory-style cuts.

    Solves the LP relaxation, then iteratively adds rounded-down cuts on
    fractional integer variables until an integer optimum is found or the
    iteration limit is reached.
    """

    def __init__(self, c, A_ub, b_ub, integer_indices=None,
                 sense="min", max_iterations=50, frac_tolerance=1e-6):
        self.c = np.asarray(c, dtype=float)
        self.A_ub = np.asarray(A_ub, dtype=float)
        self.b_ub = list(np.asarray(b_ub, dtype=float))
        self.n = len(self.c)
        self.integer_indices = (
            list(range(self.n)) if integer_indices is None else list(integer_indices)
        )
        self.sense = sense
        self.max_iterations = max_iterations
        self.frac_tolerance = frac_tolerance

    def _solve_lp(self):
        n = self.n
        sense = LpMinimize if self.sense == "min" else LpMaximize
        prob = LpProblem("cuts", sense)
        x = [LpVariable(f"x{j}", lowBound=0) for j in range(n)]

        prob += lpSum(self.c[j] * x[j] for j in range(n))

        for i, row in enumerate(self.A_ub):
            prob += lpSum(row[j] * x[j] for j in range(n)) <= self.b_ub[i]

        prob.solve(PULP_CBC_CMD(msg=0))
        status = LpStatus[prob.status]
        if status != "Optimal":
            return status, None, None
        x_vals = [value(x[j]) for j in range(n)]
        return status, value(prob.objective), x_vals

    def _find_fractional(self, x_vals):
        worst = None
        worst_frac = 0.0
        for j in self.integer_indices:
            f = abs(_frac(x_vals[j]) - 0.5)
            actual_frac = _frac(x_vals[j])
            if (actual_frac > self.frac_tolerance
                    and actual_frac < 1 - self.frac_tolerance):
                # closest to 0.5 has biggest impact
                dist_from_int = min(actual_frac, 1 - actual_frac)
                if dist_from_int > worst_frac:
                    worst_frac = dist_from_int
                    worst = j
        return worst

    def _add_floor_cut(self, x_vals, frac_idx):
        # add x[frac_idx] <= floor(x_vals[frac_idx])
        new_row = [0.0] * self.n
        new_row[frac_idx] = 1.0
        rhs = float(np.floor(x_vals[frac_idx]))
        self.A_ub = np.vstack([self.A_ub, new_row])
        self.b_ub.append(rhs)

    def run(self):
        history = []
        cuts = 0
        for iteration in range(self.max_iterations):
            status, obj, x_vals = self._solve_lp()
            if status != "Optimal":
                return CuttingPlanesResult(
                    status=status, objective=0.0, solution={},
                    cuts_added=cuts, iterations=iteration,
                    history=history,
                )

            history.append(obj)
            frac_idx = self._find_fractional(x_vals)
            if frac_idx is None:
                # all integer indices integral
                solution = {f"x{j}": x_vals[j] for j in range(self.n)}
                return CuttingPlanesResult(
                    status="Optimal", objective=obj, solution=solution,
                    cuts_added=cuts, iterations=iteration + 1,
                    history=history,
                )

            self._add_floor_cut(x_vals, frac_idx)
            cuts += 1

        # fell out of loop
        status, obj, x_vals = self._solve_lp()
        solution = {f"x{j}": x_vals[j] for j in range(self.n)} if x_vals else {}
        return CuttingPlanesResult(
            status="Iteration_Limit",
            objective=obj or 0.0,
            solution=solution,
            cuts_added=cuts,
            iterations=self.max_iterations,
            history=history,
        )
