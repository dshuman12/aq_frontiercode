from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class DualSolution:
    status: str
    dual_objective: float
    dual_variables: np.ndarray


def dual_of_standard_min(c, A, b):
    # primal:  min c^T x  s.t.  A x >= b,  x >= 0
    # dual:    max b^T y  s.t.  A^T y <= c, y >= 0
    c = np.asarray(c, dtype=float)
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float)

    m, n = A.shape

    problem = build_problem("dual", sense="max")
    y = [LpVariable(f"y{i+1}", lowBound=0) for i in range(m)]

    problem += lpSum(b[i] * y[i] for i in range(m))
    for j in range(n):
        problem += lpSum(A[i, j] * y[i] for i in range(m)) <= c[j]

    status = solve(problem)
    duals = np.array([value(y[i]) for i in range(m)] if status == "Optimal"
                     else [0.0] * m)

    return DualSolution(
        status=status,
        dual_objective=value(problem.objective) if status == "Optimal" else 0.0,
        dual_variables=duals,
    )


def verify_strong_duality(primal_obj, dual_obj, tol=1e-6):
    return abs(primal_obj - dual_obj) <= tol


def complementary_slackness(x, y, A, b, c, tol=1e-6):
    # check the two complementary slackness conditions:
    #   y_i * (A_i x - b_i) = 0 for all i
    #   x_j * (c_j - A^T_j y) = 0 for all j
    A = np.asarray(A)
    x = np.asarray(x)
    y = np.asarray(y)
    b = np.asarray(b)
    c = np.asarray(c)

    primal_slack = A @ x - b
    dual_slack = c - A.T @ y

    out = {"primal_cs": True, "dual_cs": True, "violations": []}
    for i in range(len(y)):
        if abs(y[i] * primal_slack[i]) > tol:
            out["primal_cs"] = False
            out["violations"].append(("primal", i, y[i] * primal_slack[i]))

    for j in range(len(x)):
        if abs(x[j] * dual_slack[j]) > tol:
            out["dual_cs"] = False
            out["violations"].append(("dual", j, x[j] * dual_slack[j]))

    return out
