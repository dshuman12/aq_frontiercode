from dataclasses import dataclass
import numpy as np
from pulp import LpProblem, value


@dataclass
class SensitivityReport:
    objective: float
    variable_values: dict
    shadow_prices: dict
    reduced_costs: dict
    slacks: dict


def shadow_prices(problem):
    # PuLP exposes constraint duals via .pi after solving (CBC)
    out = {}
    for name, c in problem.constraints.items():
        out[name] = -c.pi if c.pi is not None else 0.0
    return out


def reduced_costs(problem):
    out = {}
    for v in problem.variables():
        out[v.name] = -v.dj if v.dj is not None else 0.0
    return out


def slacks(problem):
    out = {}
    for name, c in problem.constraints.items():
        out[name] = c.slack if c.slack is not None else 0.0
    return out


def sensitivity_report(problem):
    if not isinstance(problem, LpProblem):
        raise TypeError("expected a pulp.LpProblem")

    var_vals = {v.name: value(v) for v in problem.variables()}

    return SensitivityReport(
        objective=value(problem.objective),
        variable_values=var_vals,
        shadow_prices=shadow_prices(problem),
        reduced_costs=reduced_costs(problem),
        slacks=slacks(problem),
    )


def rhs_ranging(problem, constraint_name, delta):
    # crude RHS ranging: re-solve with constraint RHS modified by delta
    # full-on ranging needs the basis matrix; this approximation tells you
    # the new objective for one perturbed RHS
    c = problem.constraints[constraint_name]
    original_rhs = -c.constant   # PuLP stores RHS as negated constant
    c.constant = -(original_rhs + delta)

    problem.solve()
    new_obj = value(problem.objective)

    # restore
    c.constant = -original_rhs
    problem.solve()

    return new_obj
