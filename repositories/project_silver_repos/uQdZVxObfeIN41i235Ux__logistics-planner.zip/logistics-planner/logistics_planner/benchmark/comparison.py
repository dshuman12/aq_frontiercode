import time
from dataclasses import dataclass, field


@dataclass
class MethodResult:
    name: str
    duration: float
    objective: float
    status: str = ""
    extra: dict = field(default_factory=dict)


@dataclass
class ComparisonReport:
    instance_name: str
    results: list = field(default_factory=list)

    def best_by_objective(self, minimize=True):
        if not self.results:
            return None
        if minimize:
            return min(self.results, key=lambda r: r.objective)
        return max(self.results, key=lambda r: r.objective)

    def best_by_time(self):
        if not self.results:
            return None
        return min(self.results, key=lambda r: r.duration)

    def gap_to_best(self, minimize=True):
        best = self.best_by_objective(minimize=minimize)
        if best is None or best.objective == 0:
            return {}
        out = {}
        for r in self.results:
            if minimize:
                gap = (r.objective - best.objective) / max(abs(best.objective), 1e-9)
            else:
                gap = (best.objective - r.objective) / max(abs(best.objective), 1e-9)
            out[r.name] = gap * 100  # percent
        return out


def compare_methods(instance_name, methods, minimize=True):
    """Run a list of (name, callable_returning_(objective, status_dict)) and
    collect timings + objectives in a ComparisonReport."""
    report = ComparisonReport(instance_name=instance_name)
    for name, fn in methods:
        start = time.perf_counter()
        try:
            result = fn()
        except Exception as e:
            elapsed = time.perf_counter() - start
            report.results.append(MethodResult(
                name=name, duration=elapsed, objective=float("inf") if minimize else float("-inf"),
                status=f"error: {e}",
            ))
            continue
        elapsed = time.perf_counter() - start

        if isinstance(result, tuple) and len(result) == 2:
            obj, extra = result
        else:
            obj = result
            extra = {}

        status = extra.pop("status", "ok") if isinstance(extra, dict) else "ok"
        report.results.append(MethodResult(
            name=name, duration=elapsed, objective=float(obj),
            status=status, extra=extra if isinstance(extra, dict) else {},
        ))
    return report


def format_report(report):
    lines = [f"=== {report.instance_name} ==="]
    for r in report.results:
        lines.append(f"  {r.name}: obj={r.objective:.2f}  time={r.duration*1000:.1f}ms  status={r.status}")
    return "\n".join(lines)
