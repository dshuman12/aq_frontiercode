import numpy as np


def random_tsp_instance(n, seed=None, max_coord=100.0):
    rng = np.random.default_rng(seed)
    coords = rng.uniform(0, max_coord, size=(n, 2))
    D = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            if i != j:
                D[i, j] = np.linalg.norm(coords[i] - coords[j])
    return coords, D


def random_assignment_instance(n, seed=None, max_cost=100):
    rng = np.random.default_rng(seed)
    return rng.integers(0, max_cost + 1, size=(n, n)).astype(float)


def random_knapsack_instance(n, capacity_ratio=0.5, seed=None,
                             max_value=100, max_weight=50):
    rng = np.random.default_rng(seed)
    values = rng.integers(1, max_value + 1, size=n)
    weights = rng.integers(1, max_weight + 1, size=n)
    capacity = int(weights.sum() * capacity_ratio)
    return values.tolist(), weights.tolist(), capacity


def random_facility_location_instance(n_facilities, n_suppliers, seed=None):
    rng = np.random.default_rng(seed)
    cost_facilities = rng.integers(50_000, 200_001, size=n_facilities)
    max_amounts = rng.integers(200, 1001, size=n_facilities)
    cost_suppliers = rng.integers(1, 11, size=(n_facilities, n_suppliers))
    annual_demands = rng.integers(50, 301, size=n_suppliers)
    return (
        cost_facilities.tolist(),
        max_amounts.tolist(),
        cost_suppliers.tolist(),
        annual_demands.tolist(),
    )


def random_transportation_instance(m_sources, n_destinations,
                                   seed=None, max_cost=20):
    rng = np.random.default_rng(seed)
    supply = rng.integers(20, 101, size=m_sources)
    demand_total = supply.sum()
    raw = rng.integers(20, 101, size=n_destinations).astype(float)
    demand = (raw / raw.sum() * demand_total).round().astype(int)
    # fix rounding so sums match
    diff = supply.sum() - demand.sum()
    demand[0] += diff
    cost = rng.integers(1, max_cost + 1, size=(m_sources, n_destinations))
    return supply.tolist(), demand.tolist(), cost.tolist()


def random_lot_sizing_instance(n_periods, seed=None):
    rng = np.random.default_rng(seed)
    demand = rng.integers(10, 101, size=n_periods)
    setup_costs = rng.integers(50, 500, size=n_periods)
    holding_costs = rng.integers(1, 5, size=n_periods)
    production_costs = rng.integers(1, 10, size=n_periods)
    capacity = int(demand.max() * 2)
    return (demand.tolist(), setup_costs.tolist(),
            holding_costs.tolist(), production_costs.tolist(), capacity)


def random_max_flow_instance(n, density=0.3, max_capacity=10, seed=None):
    rng = np.random.default_rng(seed)
    cap = np.zeros((n, n), dtype=int)
    for i in range(n):
        for j in range(n):
            if i != j and rng.random() < density:
                cap[i, j] = rng.integers(1, max_capacity + 1)
    return cap.tolist()


def random_graph_adjacency(n, density=0.3, seed=None):
    rng = np.random.default_rng(seed)
    adj = np.zeros((n, n), dtype=int)
    for i in range(n):
        for j in range(i + 1, n):
            if rng.random() < density:
                adj[i, j] = 1
                adj[j, i] = 1
    return adj.tolist()


def random_set_covering_instance(n_elements, n_sets, density=0.3, seed=None):
    rng = np.random.default_rng(seed)
    coverage = np.zeros((n_elements, n_sets), dtype=int)
    for i in range(n_elements):
        for j in range(n_sets):
            if rng.random() < density:
                coverage[i, j] = 1
        # ensure each element is covered by at least one set
        if coverage[i].sum() == 0:
            coverage[i, rng.integers(0, n_sets)] = 1
    costs = rng.integers(1, 11, size=n_sets)
    return costs.tolist(), coverage.tolist()
