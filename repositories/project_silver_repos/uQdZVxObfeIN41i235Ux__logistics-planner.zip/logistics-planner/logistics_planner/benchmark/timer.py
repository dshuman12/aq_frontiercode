import time
from contextlib import contextmanager
from dataclasses import dataclass, field


@dataclass
class TimingRecord:
    name: str
    duration: float
    notes: str = ""


@dataclass
class TimingReport:
    records: list = field(default_factory=list)

    def add(self, name, duration, notes=""):
        self.records.append(TimingRecord(name, duration, notes))

    def summary(self):
        total = sum(r.duration for r in self.records)
        return {
            "total_seconds": total,
            "count": len(self.records),
            "records": [(r.name, r.duration, r.notes) for r in self.records],
        }

    def fastest(self):
        if not self.records:
            return None
        return min(self.records, key=lambda r: r.duration)

    def slowest(self):
        if not self.records:
            return None
        return max(self.records, key=lambda r: r.duration)


@contextmanager
def timed(name, report=None):
    start = time.perf_counter()
    yield
    elapsed = time.perf_counter() - start
    if report is not None:
        report.add(name, elapsed)


def time_call(func, *args, **kwargs):
    start = time.perf_counter()
    result = func(*args, **kwargs)
    elapsed = time.perf_counter() - start
    return result, elapsed


def repeat_time(func, repeats=5, *args, **kwargs):
    times = []
    last_result = None
    for _ in range(repeats):
        start = time.perf_counter()
        last_result = func(*args, **kwargs)
        times.append(time.perf_counter() - start)
    return last_result, {
        "min": min(times),
        "max": max(times),
        "avg": sum(times) / len(times),
        "all": times,
    }
