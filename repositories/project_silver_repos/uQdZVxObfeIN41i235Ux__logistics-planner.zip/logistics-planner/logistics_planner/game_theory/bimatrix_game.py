from dataclasses import dataclass
import numpy as np


@dataclass
class BimatrixSolution:
    row_payoff_matrix: np.ndarray
    col_payoff_matrix: np.ndarray
    pure_nash_equilibria: list


class BimatrixGame:
    def __init__(self, row_payoffs, col_payoffs):
        self.A = np.asarray(row_payoffs, dtype=float)
        self.B = np.asarray(col_payoffs, dtype=float)

        if self.A.shape != self.B.shape:
            raise ValueError(
                f"row payoffs shape {self.A.shape} != col payoffs shape {self.B.shape}"
            )

        self.m, self.n = self.A.shape

    def best_responses_for_row(self, col_action):
        # given column player plays col_action, which row actions are best?
        col = self.A[:, col_action]
        best_value = col.max()
        return [i for i in range(self.m) if col[i] == best_value]

    def best_responses_for_col(self, row_action):
        row = self.B[row_action, :]
        best_value = row.max()
        return [j for j in range(self.n) if row[j] == best_value]

    def pure_nash_equilibria(self):
        eqs = []
        for i in range(self.m):
            for j in range(self.n):
                row_best = self.best_responses_for_row(j)
                col_best = self.best_responses_for_col(i)
                if i in row_best and j in col_best:
                    eqs.append((i, j))
        return eqs

    def is_zero_sum(self):
        return np.allclose(self.A, -self.B)

    def solve(self):
        return BimatrixSolution(
            row_payoff_matrix=self.A,
            col_payoff_matrix=self.B,
            pure_nash_equilibria=self.pure_nash_equilibria(),
        )
