from dataclasses import dataclass
import numpy as np
from pulp import LpVariable, LpStatus, value, lpSum

from logistics_planner.solvers.lp_solver import build_problem, solve


@dataclass
class GameSolution:
    status: str
    value: float
    row_strategy: np.ndarray
    col_strategy: np.ndarray


class MatrixGame:
    def __init__(self, payoff_matrix):
        self.payoff = np.asarray(payoff_matrix, dtype=float)
        self.m, self.n = self.payoff.shape

    def solve(self):
        # solve two-player zero-sum game by LP
        # row player maximizes the security level v subject to:
        #   sum_i p_i * a_ij >= v for all j, sum p_i = 1, p_i >= 0
        # this is reformulated as an LP that maximizes v
        m, n = self.m, self.n
        A = self.payoff

        # shift payoffs to be positive (preserves optimal strategies)
        offset = max(0, -A.min() + 1)
        A_shifted = A + offset

        # row player primal LP:
        # max v   s.t.   p^T A_shifted >= v * 1,  sum(p) = 1,  p >= 0
        # equivalently with x = p / v (scaling):
        # min sum(x)   s.t.   x^T A_shifted >= 1,  x >= 0
        # then v = 1 / sum(x*) and p = x* / sum(x*)
        problem = build_problem("matrix_game_row", sense="min")
        x = [LpVariable(f"x{i+1}", lowBound=0) for i in range(m)]

        problem += lpSum(x[i] for i in range(m))
        for j in range(n):
            problem += lpSum(A_shifted[i, j] * x[i] for i in range(m)) >= 1

        status_row = solve(problem)
        if status_row != "Optimal":
            return GameSolution(status_row, 0.0, np.zeros(m), np.zeros(n))

        x_vals = np.array([value(x[i]) for i in range(m)])
        sum_x = x_vals.sum()
        v_shifted = 1.0 / sum_x
        row_strategy = x_vals / sum_x

        # col player by symmetry (dual LP):
        # max sum(y)   s.t.   A_shifted y <= 1,  y >= 0
        # then col_strategy = y* / sum(y*)
        col_problem = build_problem("matrix_game_col", sense="max")
        y = [LpVariable(f"y{j+1}", lowBound=0) for j in range(n)]
        col_problem += lpSum(y[j] for j in range(n))
        for i in range(m):
            col_problem += lpSum(A_shifted[i, j] * y[j] for j in range(n)) <= 1

        status_col = solve(col_problem)
        if status_col != "Optimal":
            return GameSolution(status_col, 0.0, row_strategy, np.zeros(n))

        y_vals = np.array([value(y[j]) for j in range(n)])
        col_strategy = y_vals / y_vals.sum()

        # unshift the value
        game_value = v_shifted - offset

        return GameSolution(
            status="Optimal",
            value=game_value,
            row_strategy=row_strategy,
            col_strategy=col_strategy,
        )

    def has_pure_saddle_point(self):
        # a pure saddle point exists iff max of row mins equals min of col maxes
        row_mins = self.payoff.min(axis=1)
        col_maxes = self.payoff.max(axis=0)
        return row_mins.max() == col_maxes.min()

    def saddle_point(self):
        if not self.has_pure_saddle_point():
            return None
        row_mins = self.payoff.min(axis=1)
        col_maxes = self.payoff.max(axis=0)
        v = row_mins.max()
        for i in range(self.m):
            for j in range(self.n):
                if self.payoff[i, j] == v and row_mins[i] == v and col_maxes[j] == v:
                    return (i, j, v)
        return None
