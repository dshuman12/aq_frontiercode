import numpy as np


def dominated_rows(payoff):
    A = np.asarray(payoff, dtype=float)
    m = A.shape[0]
    dominated = []
    for i in range(m):
        for k in range(m):
            if i == k or k in dominated:
                continue
            if np.all(A[k] >= A[i]) and np.any(A[k] > A[i]):
                dominated.append(i)
                break
    return dominated


def dominated_columns(payoff):
    A = np.asarray(payoff, dtype=float)
    n = A.shape[1]
    dominated = []
    for j in range(n):
        for k in range(n):
            if j == k or k in dominated:
                continue
            if np.all(A[:, k] <= A[:, j]) and np.any(A[:, k] < A[:, j]):
                dominated.append(j)
                break
    return dominated


def reduce_by_dominance(payoff):
    A = np.asarray(payoff, dtype=float)
    rows_kept = list(range(A.shape[0]))
    cols_kept = list(range(A.shape[1]))

    while True:
        dr = dominated_rows(A)
        dc = dominated_columns(A)
        if not dr and not dc:
            break
        if dr:
            keep = [i for i in range(A.shape[0]) if i not in dr]
            rows_kept = [rows_kept[i] for i in keep]
            A = A[keep, :]
        if dc:
            keep = [j for j in range(A.shape[1]) if j not in dc]
            cols_kept = [cols_kept[j] for j in keep]
            A = A[:, keep]

    return A, rows_kept, cols_kept
