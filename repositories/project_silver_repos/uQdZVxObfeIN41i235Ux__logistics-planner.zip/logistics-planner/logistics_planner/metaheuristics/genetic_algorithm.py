import random
from dataclasses import dataclass, field


@dataclass
class GAConfig:
    population_size: int = 50
    generations: int = 100
    crossover_rate: float = 0.8
    mutation_rate: float = 0.1
    tournament_size: int = 3
    elitism: int = 2
    seed: int = None


@dataclass
class GAResult:
    best_individual: object
    best_fitness: float
    history: list = field(default_factory=list)
    generations_run: int = 0


class GeneticAlgorithm:
    """Generic genetic algorithm framework. Subclasses provide problem-specific
    operators by passing callable functions to __init__."""

    def __init__(self, init_individual, fitness, crossover, mutate,
                 maximize=True, config=None):
        self.init_individual = init_individual
        self.fitness = fitness
        self.crossover = crossover
        self.mutate = mutate
        self.maximize = maximize
        self.config = config or GAConfig()
        if self.config.seed is not None:
            random.seed(self.config.seed)

    def _better(self, a, b):
        return a > b if self.maximize else a < b

    def _tournament(self, population, fitnesses):
        size = self.config.tournament_size
        contenders = random.sample(range(len(population)), min(size, len(population)))
        best_idx = contenders[0]
        for idx in contenders[1:]:
            if self._better(fitnesses[idx], fitnesses[best_idx]):
                best_idx = idx
        return population[best_idx]

    def run(self):
        cfg = self.config
        population = [self.init_individual() for _ in range(cfg.population_size)]
        fitnesses = [self.fitness(ind) for ind in population]

        history = []

        for gen in range(cfg.generations):
            # sort by fitness so we can carry elite
            paired = sorted(zip(fitnesses, range(len(population))),
                            reverse=self.maximize)
            elite_indices = [pair[1] for pair in paired[:cfg.elitism]]
            elite = [population[i] for i in elite_indices]
            elite_fits = [fitnesses[i] for i in elite_indices]

            new_population = list(elite)

            while len(new_population) < cfg.population_size:
                p1 = self._tournament(population, fitnesses)
                p2 = self._tournament(population, fitnesses)
                if random.random() < cfg.crossover_rate:
                    child = self.crossover(p1, p2)
                else:
                    child = list(p1) if isinstance(p1, list) else p1
                if random.random() < cfg.mutation_rate:
                    child = self.mutate(child)
                new_population.append(child)

            population = new_population
            fitnesses = [self.fitness(ind) for ind in population]

            best_idx = max(range(len(population)), key=lambda i: fitnesses[i]) \
                if self.maximize else \
                min(range(len(population)), key=lambda i: fitnesses[i])
            history.append(fitnesses[best_idx])

        # final best
        best_idx = max(range(len(population)), key=lambda i: fitnesses[i]) \
            if self.maximize else \
            min(range(len(population)), key=lambda i: fitnesses[i])

        return GAResult(
            best_individual=population[best_idx],
            best_fitness=fitnesses[best_idx],
            history=history,
            generations_run=cfg.generations,
        )


def order_crossover(parent1, parent2):
    # OX crossover suitable for permutation encoding (TSP)
    n = len(parent1)
    a, b = sorted(random.sample(range(n), 2))
    child = [None] * n
    child[a:b+1] = parent1[a:b+1]
    fill = [g for g in parent2 if g not in child]
    pos = 0
    for i in range(n):
        if child[i] is None:
            child[i] = fill[pos]
            pos += 1
    return child


def swap_mutation(individual):
    ind = list(individual)
    if len(ind) < 2:
        return ind
    i, j = random.sample(range(len(ind)), 2)
    ind[i], ind[j] = ind[j], ind[i]
    return ind


def uniform_crossover(parent1, parent2, p=0.5):
    child = []
    for a, b in zip(parent1, parent2):
        child.append(a if random.random() < p else b)
    return child


def bit_flip_mutation(individual, p=None):
    ind = list(individual)
    if p is None:
        p = 1.0 / max(1, len(ind))
    for i in range(len(ind)):
        if random.random() < p:
            ind[i] = 1 - ind[i] if ind[i] in (0, 1) else not ind[i]
    return ind
