from collections import deque
from dataclasses import dataclass, field
import random


@dataclass
class TabuConfig:
    max_iterations: int = 500
    tabu_tenure: int = 20
    neighborhood_size: int = 30
    seed: int = None


@dataclass
class TabuResult:
    best_solution: object
    best_cost: float
    history: list = field(default_factory=list)


class TabuSearch:
    """Generic tabu search. Caller provides initial, cost, and a neighbor
    generator that yields (move_key, neighbor_state) so we can tabu specific
    moves rather than full states."""

    def __init__(self, initial, cost, neighbors, minimize=True, config=None):
        self.initial = initial
        self.cost = cost
        self.neighbors = neighbors
        self.minimize = minimize
        self.config = config or TabuConfig()
        if self.config.seed is not None:
            random.seed(self.config.seed)

    def _better(self, a, b):
        return a < b if self.minimize else a > b

    def run(self):
        cfg = self.config
        current = self.initial
        current_cost = self.cost(current)
        best = current
        best_cost = current_cost

        tabu = deque(maxlen=cfg.tabu_tenure)
        history = [best_cost]

        for _ in range(cfg.max_iterations):
            best_move = None
            best_neighbor = None
            best_neighbor_cost = None

            count = 0
            for move_key, neighbor in self.neighbors(current):
                cost = self.cost(neighbor)
                # aspiration: allow tabu move if it beats global best
                if move_key in tabu:
                    if not self._better(cost, best_cost):
                        continue
                if best_neighbor_cost is None or self._better(cost, best_neighbor_cost):
                    best_neighbor = neighbor
                    best_neighbor_cost = cost
                    best_move = move_key
                count += 1
                if count >= cfg.neighborhood_size:
                    break

            if best_neighbor is None:
                break

            current = best_neighbor
            current_cost = best_neighbor_cost
            tabu.append(best_move)

            if self._better(current_cost, best_cost):
                best = current
                best_cost = current_cost

            history.append(best_cost)

        return TabuResult(
            best_solution=best,
            best_cost=best_cost,
            history=history,
        )


def swap_move_neighbors(state):
    """Yield neighbors by single-swap move; move_key is the (i, j) pair."""
    s = list(state)
    n = len(s)
    indices = list(range(n))
    random.shuffle(indices)
    for ai in range(len(indices)):
        for bi in range(ai + 1, len(indices)):
            i, j = indices[ai], indices[bi]
            ns = list(s)
            ns[i], ns[j] = ns[j], ns[i]
            yield (tuple(sorted((i, j))), ns)


def two_opt_neighbors(state):
    """2-opt move neighborhood: reverse a segment between i and j."""
    s = list(state)
    n = len(s)
    for i in range(n - 1):
        for j in range(i + 1, n):
            ns = list(s)
            ns[i:j+1] = reversed(ns[i:j+1])
            yield ((i, j), ns)
