import random
import numpy as np

from logistics_planner.metaheuristics.genetic_algorithm import (
    GeneticAlgorithm, GAConfig, uniform_crossover, bit_flip_mutation,
)
from logistics_planner.metaheuristics.simulated_annealing import (
    SimulatedAnnealing, SAConfig, bit_flip_neighbor,
)


def evaluate_knapsack(bits, values, weights, capacity, penalty=1e6):
    bits = np.asarray(bits)
    values = np.asarray(values)
    weights = np.asarray(weights)
    total_value = float(np.dot(bits, values))
    total_weight = float(np.dot(bits, weights))
    if total_weight > capacity:
        # penalize infeasible solutions linearly
        return total_value - penalty * (total_weight - capacity)
    return total_value


def random_bits(n, p=0.5):
    return [1 if random.random() < p else 0 for _ in range(n)]


def solve_knapsack_with_ga(values, weights, capacity, config=None, seed=None):
    n = len(values)

    def init():
        return random_bits(n, p=0.3)

    def fit(bits):
        return evaluate_knapsack(bits, values, weights, capacity)

    cfg = config or GAConfig(population_size=80, generations=150, seed=seed)

    ga = GeneticAlgorithm(
        init_individual=init,
        fitness=fit,
        crossover=uniform_crossover,
        mutate=bit_flip_mutation,
        maximize=True,
        config=cfg,
    )
    result = ga.run()
    return result.best_individual, result.best_fitness


def solve_knapsack_with_sa(values, weights, capacity, config=None, seed=None):
    n = len(values)
    initial = [0] * n

    def cost(bits):
        # minimize negative value
        return -evaluate_knapsack(bits, values, weights, capacity)

    cfg = config or SAConfig(
        initial_temp=100.0,
        cooling_rate=0.99,
        max_iterations=10000,
        iterations_per_temp=30,
        seed=seed,
    )

    sa = SimulatedAnnealing(
        initial=initial,
        cost=cost,
        neighbor=bit_flip_neighbor,
        minimize=True,
        config=cfg,
    )
    result = sa.run()
    return result.best_solution, -result.best_cost
