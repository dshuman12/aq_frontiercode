import math
import random
from dataclasses import dataclass, field


@dataclass
class SAConfig:
    initial_temp: float = 1000.0
    cooling_rate: float = 0.995
    min_temp: float = 1e-3
    max_iterations: int = 10000
    iterations_per_temp: int = 50
    seed: int = None


@dataclass
class SAResult:
    best_solution: object
    best_cost: float
    history: list = field(default_factory=list)
    accepted_moves: int = 0
    rejected_moves: int = 0


class SimulatedAnnealing:
    """Generic simulated annealing. Caller provides initial state, neighbor
    generator, and cost function."""

    def __init__(self, initial, cost, neighbor, minimize=True, config=None):
        self.initial = initial
        self.cost = cost
        self.neighbor = neighbor
        self.minimize = minimize
        self.config = config or SAConfig()
        if self.config.seed is not None:
            random.seed(self.config.seed)

    def _accept(self, current_cost, new_cost, temp):
        if self.minimize:
            delta = new_cost - current_cost
        else:
            delta = current_cost - new_cost
        if delta <= 0:
            return True
        # accept with probability exp(-delta/temp)
        try:
            return random.random() < math.exp(-delta / max(temp, 1e-12))
        except OverflowError:
            return False

    def run(self):
        cfg = self.config
        current = self.initial
        current_cost = self.cost(current)
        best = current
        best_cost = current_cost

        temp = cfg.initial_temp
        history = [best_cost]
        accepted = 0
        rejected = 0
        iterations = 0

        while temp > cfg.min_temp and iterations < cfg.max_iterations:
            for _ in range(cfg.iterations_per_temp):
                if iterations >= cfg.max_iterations:
                    break
                candidate = self.neighbor(current)
                candidate_cost = self.cost(candidate)
                if self._accept(current_cost, candidate_cost, temp):
                    current = candidate
                    current_cost = candidate_cost
                    accepted += 1
                    if self.minimize and current_cost < best_cost:
                        best = current
                        best_cost = current_cost
                    elif not self.minimize and current_cost > best_cost:
                        best = current
                        best_cost = current_cost
                else:
                    rejected += 1
                iterations += 1

            history.append(best_cost)
            temp *= cfg.cooling_rate

        return SAResult(
            best_solution=best,
            best_cost=best_cost,
            history=history,
            accepted_moves=accepted,
            rejected_moves=rejected,
        )


def random_swap_neighbor(state):
    s = list(state)
    if len(s) < 2:
        return s
    i, j = random.sample(range(len(s)), 2)
    s[i], s[j] = s[j], s[i]
    return s


def reverse_segment_neighbor(state):
    s = list(state)
    if len(s) < 3:
        return s
    i, j = sorted(random.sample(range(len(s)), 2))
    s[i:j+1] = reversed(s[i:j+1])
    return s


def bit_flip_neighbor(state):
    s = list(state)
    if not s:
        return s
    idx = random.randrange(len(s))
    s[idx] = 1 - s[idx] if s[idx] in (0, 1) else not s[idx]
    return s
