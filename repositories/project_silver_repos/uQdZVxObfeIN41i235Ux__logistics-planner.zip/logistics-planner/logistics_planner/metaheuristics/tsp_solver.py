import random
import numpy as np

from logistics_planner.metaheuristics.genetic_algorithm import (
    GeneticAlgorithm, GAConfig, order_crossover, swap_mutation,
)
from logistics_planner.metaheuristics.simulated_annealing import (
    SimulatedAnnealing, SAConfig, reverse_segment_neighbor,
)
from logistics_planner.metaheuristics.tabu_search import (
    TabuSearch, TabuConfig, two_opt_neighbors,
)


def tour_length(tour, distance_matrix):
    D = distance_matrix
    n = len(tour)
    total = 0.0
    for i in range(n):
        total += D[tour[i], tour[(i + 1) % n]]
    return total


def random_tour(n, fix_start=0):
    rest = list(range(n))
    rest.remove(fix_start)
    random.shuffle(rest)
    return [fix_start] + rest


def solve_tsp_with_ga(distance_matrix, config=None, seed=None):
    D = np.asarray(distance_matrix, dtype=float)
    n = D.shape[0]

    def init():
        return random_tour(n, fix_start=0)

    def fit(tour):
        # GA maximizes fitness; convert tour length to inverse
        return -tour_length(tour, D)

    cfg = config or GAConfig(population_size=50, generations=200, seed=seed)

    ga = GeneticAlgorithm(
        init_individual=init,
        fitness=fit,
        crossover=order_crossover,
        mutate=swap_mutation,
        maximize=True,
        config=cfg,
    )
    result = ga.run()
    return result.best_individual, -result.best_fitness


def solve_tsp_with_sa(distance_matrix, config=None, seed=None):
    D = np.asarray(distance_matrix, dtype=float)
    n = D.shape[0]

    initial = random_tour(n, fix_start=0)

    def cost(tour):
        return tour_length(tour, D)

    cfg = config or SAConfig(
        initial_temp=100.0,
        cooling_rate=0.995,
        max_iterations=20000,
        iterations_per_temp=50,
        seed=seed,
    )

    sa = SimulatedAnnealing(
        initial=initial,
        cost=cost,
        neighbor=reverse_segment_neighbor,
        minimize=True,
        config=cfg,
    )
    result = sa.run()
    return result.best_solution, result.best_cost


def solve_tsp_with_tabu(distance_matrix, config=None, seed=None):
    D = np.asarray(distance_matrix, dtype=float)
    n = D.shape[0]

    initial = random_tour(n, fix_start=0)

    def cost(tour):
        return tour_length(tour, D)

    cfg = config or TabuConfig(
        max_iterations=200,
        tabu_tenure=15,
        neighborhood_size=20,
        seed=seed,
    )

    ts = TabuSearch(
        initial=initial,
        cost=cost,
        neighbors=two_opt_neighbors,
        minimize=True,
        config=cfg,
    )
    result = ts.run()
    return result.best_solution, result.best_cost
