import argparse
import json
import sys

from logistics_planner.data.loaders import (
    load_facility_instance,
    load_transportation_instance,
    load_lot_sizing_instance,
    load_blending_instance,
    load_diet_instance,
    load_tsp_instance,
)
from logistics_planner.problems.capacitated_facility_location import (
    CapacitatedFacilityLocation,
)
from logistics_planner.problems.transportation_problem import TransportationProblem
from logistics_planner.problems.capacitated_lot_sizing_problem import CapacitatedLotSizing
from logistics_planner.problems.linear_blending_problem import LinearBlending
from logistics_planner.problems.stiglers_diet_problem import StiglersDiet
from logistics_planner.problems.traveling_salesman_problem import TravelingSalesman
from logistics_planner.data.output import print_solution


def cmd_facility(args):
    cf, ma, cs, ad = load_facility_instance(args.input)
    sol = CapacitatedFacilityLocation(cf, ma, cs, ad).solve()
    print_solution(sol, "Facility Location")


def cmd_transport(args):
    s, d, c = load_transportation_instance(args.input)
    sol = TransportationProblem(s, d, c).solve()
    print_solution(sol, "Transportation")


def cmd_lot_sizing(args):
    d, sc, hc, pc, cap = load_lot_sizing_instance(args.input)
    sol = CapacitatedLotSizing(d, sc, hc, pc, cap).solve(initial_inventory=args.initial)
    print_solution(sol, "Lot Sizing")


def cmd_blending(args):
    mats, costs, P, lo, hi, Q = load_blending_instance(args.input)
    sol = LinearBlending(mats, costs, P, lo, hi, Q).solve()
    print_solution(sol, "Blending")


def cmd_diet(args):
    foods, costs, N, req = load_diet_instance(args.input)
    sol = StiglersDiet(foods, costs, N, req).solve()
    print_solution(sol, "Diet")


def cmd_tsp(args):
    D = load_tsp_instance(args.input)
    p = TravelingSalesman(D)
    if args.method == "mip":
        sol = p.solve_mip()
    else:
        sol = p.solve_nearest_neighbor(start=args.start)
    print_solution(sol, "TSP")


def build_parser():
    parser = argparse.ArgumentParser(prog="logistics-planner",
                                     description="Solve LP/MIP problems from JSON files")
    sub = parser.add_subparsers(dest="command")

    p1 = sub.add_parser("facility", help="capacitated facility location")
    p1.add_argument("input", help="path to JSON instance")
    p1.set_defaults(func=cmd_facility)

    p2 = sub.add_parser("transport", help="transportation problem")
    p2.add_argument("input")
    p2.set_defaults(func=cmd_transport)

    p3 = sub.add_parser("lot-sizing", help="capacitated lot sizing")
    p3.add_argument("input")
    p3.add_argument("--initial", type=float, default=0.0,
                    help="initial inventory (default 0)")
    p3.set_defaults(func=cmd_lot_sizing)

    p4 = sub.add_parser("blending", help="linear blending")
    p4.add_argument("input")
    p4.set_defaults(func=cmd_blending)

    p5 = sub.add_parser("diet", help="stigler's diet problem")
    p5.add_argument("input")
    p5.set_defaults(func=cmd_diet)

    p6 = sub.add_parser("tsp", help="traveling salesman")
    p6.add_argument("input")
    p6.add_argument("--method", choices=["mip", "nearest"], default="mip")
    p6.add_argument("--start", type=int, default=0)
    p6.set_defaults(func=cmd_tsp)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
