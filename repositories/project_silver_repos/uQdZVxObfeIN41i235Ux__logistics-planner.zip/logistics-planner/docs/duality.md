# LP Duality

Every LP has a "dual" LP that swaps roles of constraints and variables.

## Primal-dual pair (standard min)

Primal:

```
min  c^T x
s.t. A x ≥ b
     x ≥ 0
```

Dual:

```
max  b^T y
s.t. A^T y ≤ c
     y ≥ 0
```

## Strong duality

If both have feasible solutions, their objectives are equal at the optimum.

## Complementary slackness

- `y_i * (A_i x - b_i) = 0` — for each constraint, either the dual variable
  is zero or the constraint is tight
- `x_j * (c_j - A^T_j y) = 0` — for each primal variable, either the
  variable is zero or the dual constraint is tight

These conditions are useful for verifying optimality and constructing dual
solutions from primal ones.
