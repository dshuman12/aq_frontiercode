# Set Covering Problem

Select a minimum-cost collection of sets that together cover every element.

```
min  sum_j c_j * x_j
s.t. sum_j A_ij * x_j ≥ 1   for every element i
     x_j ∈ {0, 1}
```

`A_ij = 1` means set `j` covers element `i`.

## Greedy heuristic

H(n)-approximation: pick the set with the best coverage-per-cost ratio,
remove covered elements, repeat. Tight in the worst case.
