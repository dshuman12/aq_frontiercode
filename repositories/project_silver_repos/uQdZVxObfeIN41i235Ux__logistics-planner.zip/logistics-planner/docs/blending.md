# Linear Blending

Mix raw materials to produce a target output that satisfies property bounds at
minimum cost.

## Variables

`x_i ≥ 0` — units of material `i` used in the blend.

## Objective

```
min  sum_i c_i * x_i
```

## Constraints

- Total output: `sum_i x_i = Q`
- Property `r` bounds: `lo_r * Q ≤ sum_i P_ri * x_i ≤ hi_r * Q`

Note that `lo_r` and `hi_r` are per-unit concentrations; the `* Q` term is
what makes the constraint correct for any `Q`.
