# Benchmarking

Helpers for timing solvers, generating random instances, and comparing
methods.

## Timing

- `timed(name, report)` — context manager
- `time_call(fn, *args)` — returns (result, seconds)
- `repeat_time(fn, repeats=N, *args)` — returns (last_result, stats)

## Instance generators

One per problem type, all seeded for reproducibility:

- `random_tsp_instance(n, seed)` -> `(coords, distance_matrix)`
- `random_facility_location_instance(m, n, seed)`
- `random_knapsack_instance(n, capacity_ratio, seed)`
- `random_transportation_instance(m, n, seed)` -> always balanced
- ... etc

## Comparison

`compare_methods(name, [(label, fn), ...])` runs each method, captures
timings and objectives, returns a `ComparisonReport` with `gap_to_best()`
and pretty `format_report()`.
