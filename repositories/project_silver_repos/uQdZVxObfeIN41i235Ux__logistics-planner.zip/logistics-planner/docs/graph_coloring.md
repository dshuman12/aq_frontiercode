# Graph Coloring

Color vertices so adjacent vertices get different colors, minimizing the
number of colors used.

## MIP

Variables: `x_vc ∈ {0,1}` (vertex `v` gets color `c`), `y_c ∈ {0,1}` (color
`c` is used). Up to `K` colors available.

```
min  sum_c y_c
s.t. sum_c x_vc = 1                for every vertex v
     x_uc + x_vc ≤ 1                for every edge (u, v) and color c
     x_vc ≤ y_c                     for all v, c
     y_c ≥ y_{c+1}                  symmetry breaking
```

## Greedy (Welsh-Powell)

Order vertices by descending degree. Assign each vertex the smallest color
not used by its already-colored neighbors.
