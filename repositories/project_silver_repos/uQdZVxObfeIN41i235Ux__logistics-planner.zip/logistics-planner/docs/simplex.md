# Simplex Method (revised)

Pure-Python simplex implementation in `solvers/simplex.py`. Solves LPs in
standard form `min c^T x` s.t. `A x = b`, `x ≥ 0`.

Uses tableau form with Bland's rule for cycling prevention.

For LPs without an obvious initial feasible basis, use `big_m_simplex` or
`two_phase_simplex` instead.
