# Minimum Cost Flow

Send specified supplies through a network at minimum cost, respecting edge
capacities.

Each node has a supply value `b_v` (positive = source, negative = sink, zero
= transshipment). Supplies must sum to zero.

```
min  sum_e c_e * x_e
s.t. sum_{e in out(v)} x_e - sum_{e in in(v)} x_e = b_v   for all v
     0 ≤ x_e ≤ cap_e
```
