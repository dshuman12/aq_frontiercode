# References

- Thie, P. R. (1979). *An Introduction to Linear Programming and Game Theory*.
  John Wiley & Sons. (Primary textbook.)
- Wolsey, L. A. (1998). *Integer Programming*. Wiley.
- Cormen, T. H. et al. (2009). *Introduction to Algorithms*. MIT Press
  (network flow chapters).
- Ahuja, Magnanti, Orlin (1993). *Network Flows: Theory, Algorithms, and
  Applications*. Prentice Hall.
- Stigler, G. J. (1945). "The Cost of Subsistence". *Journal of Farm
  Economics*. (The diet problem.)
