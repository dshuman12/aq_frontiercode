# Stigler's Diet Problem

Pick quantities of each food to meet daily nutrient requirements at minimum
cost. Originally posed by George Stigler in 1945.

## Variables

`x_j ≥ 0` — quantity of food `j` consumed.

## Objective

```
min  sum_j c_j * x_j
```

## Constraints

For each nutrient `r`:

```
sum_j N_rj * x_j ≥ requirement_r
```

`N` is the nutrient matrix in `(nutrients, foods)` order — rows are nutrients,
columns are foods.
