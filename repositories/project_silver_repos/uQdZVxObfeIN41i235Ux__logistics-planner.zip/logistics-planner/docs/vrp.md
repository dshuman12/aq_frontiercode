# Vehicle Routing Problem (capacitated)

`K` vehicles, all starting and ending at the depot (node 0). Visit each
customer once. Sum of demands per route ≤ vehicle capacity.

## MIP

Vehicle-indexed binary `x_ijk` arc variables plus per-vehicle MTZ load
variables to enforce both subtour elimination and capacity in one go.

## Clarke-Wright savings

Greedy savings heuristic. Compute `s_ij = d_0i + d_0j - d_ij` for every
customer pair, then merge routes in descending savings order while capacity
allows.
