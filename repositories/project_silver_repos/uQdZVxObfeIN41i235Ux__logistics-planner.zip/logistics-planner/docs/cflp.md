# Capacitated Facility Location

Decide which facilities to open and how much to ship from each open facility
to each customer, minimizing total cost.

## Variables

- `y_i ∈ {0, 1}` — 1 if facility `i` is open
- `x_ij ≥ 0` — units shipped from facility `i` to customer `j`

## Objective

Minimize:

```
sum_i (cost_i * y_i)  +  sum_ij (transport_ij * x_ij)
```

## Constraints

- Capacity: `sum_j x_ij ≤ cap_i * y_i`
- Demand:   `sum_i x_ij = demand_j`
- Linking:  `x_ij ≤ demand_j * y_i`
