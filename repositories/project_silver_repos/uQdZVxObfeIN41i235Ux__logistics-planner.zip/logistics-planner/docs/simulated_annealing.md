# Simulated Annealing

Single-state local search. Accept moves that improve the objective; accept
worsening moves with probability `exp(-delta / T)`. Slowly decrease `T`.

```
while T > T_min:
    for _ in range(iters_per_temp):
        candidate = neighbor(current)
        if acceptable(current, candidate, T):
            current = candidate
    T *= cooling_rate
```

## Tuning

- High initial `T`: too random
- Low initial `T`: gets stuck in local minima
- Slow cooling: better quality, longer runtime
- Fast cooling: shorter runtime, may miss optimum
