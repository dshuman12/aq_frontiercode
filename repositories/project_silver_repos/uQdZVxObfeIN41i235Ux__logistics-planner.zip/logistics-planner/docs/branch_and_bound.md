# Branch and Bound

Generic depth-first B&B for IP/MIP. Solves the LP relaxation at each node;
if integer-feasible, treat as a candidate; otherwise branch on a fractional
integer variable.

## Branching

Pick the first integer-required variable that is fractional. Create two
children: `x_i ≤ floor(v)` and `x_i ≥ ceil(v)`.

## Pruning

Prune nodes whose LP relaxation bound is dominated by the incumbent.
