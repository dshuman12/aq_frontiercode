# CLI

```
python -m logistics_planner.cli <subcommand> <input.json>
```

Subcommands: `facility`, `transport`, `lot-sizing`, `blending`, `diet`, `tsp`.

Each takes a JSON file with the appropriate keys (see `data_samples/`).
