# CLI examples

```bash
python -m logistics_planner.cli facility data_samples/cflp_small.json
python -m logistics_planner.cli transport data_samples/transportation_small.json
python -m logistics_planner.cli lot-sizing data_samples/lot_sizing_small.json
python -m logistics_planner.cli blending data_samples/blending_small.json
python -m logistics_planner.cli diet data_samples/diet_small.json
python -m logistics_planner.cli tsp data_samples/tsp_small.json --method nearest
```
