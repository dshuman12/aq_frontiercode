# FAQ

**Q: Why PuLP and not Pyomo / CVXPY?**
A: PuLP was what I used in coursework; the CBC backend is bundled and the API
is shallow. For specific use cases (quadratic objectives, GAMS-style modeling)
other tools are better.

**Q: Why so many `==` constraints?**
A: Equality is more restrictive but easier to read for textbook-style
formulations. The simplex doesn't care.

**Q: Can I plug in Gurobi/CPLEX?**
A: Yes — `solvers/lp_solver.solve()` calls `problem.solve(PULP_CBC_CMD(...))`
which is easy to swap for `GUROBI_CMD()` or similar if you have a license.
