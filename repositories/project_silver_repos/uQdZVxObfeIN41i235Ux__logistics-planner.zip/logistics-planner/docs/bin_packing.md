# Bin Packing

Pack items of given sizes into the fewest bins of fixed capacity.

```
min  sum_k y_k
s.t. sum_i s_i * x_ik ≤ C * y_k   for each bin k
     sum_k x_ik = 1               for each item i
     x_ik, y_k ∈ {0, 1}
```

## First-fit-decreasing (FFD)

Sort items by size, place each in the first bin it fits in. Uses at most
11/9 OPT + 6/9 bins (Yue 1991).
