# Traveling Salesman Problem

Visit every city exactly once and return to start, minimizing tour length.

## MIP (MTZ formulation)

Variables:

- `x_ij ∈ {0, 1}` — 1 if tour goes from city `i` to city `j`
- `u_i ∈ [0, n-1]` — auxiliary ordering variables (Miller-Tucker-Zemlin)

Objective:

```
min  sum_ij d_ij * x_ij
```

Constraints:

- Leave each city once: `sum_j x_ij = 1` for all `i`
- Enter each city once: `sum_i x_ij = 1` for all `j`
- Subtour elimination: `u_i - u_j + n*x_ij ≤ n-1` for `i, j ≠ 0`, `i ≠ j`

## Heuristic

Nearest-neighbor: at each step, move to the closest unvisited city.
