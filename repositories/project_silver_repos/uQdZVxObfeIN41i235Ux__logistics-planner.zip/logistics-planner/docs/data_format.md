# JSON Instance Format

Each problem class can be loaded from a JSON file via the loaders in
`logistics_planner/data/loaders.py`. See `data_samples/` for examples.

Common rule: the JSON keys match the constructor parameter names.

## Examples

CFLP:
```json
{
  "cost_facilities": [...],
  "max_amounts": [...],
  "cost_suppliers": [[...]],
  "annual_demands": [...]
}
```

TSP:
```json
{"distance_matrix": [[...]]}
```
