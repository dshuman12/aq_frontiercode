# Examples index

| Script | Problem |
|---|---|
| `cargo_loading.py` | 0/1 knapsack |
| `clinic_placement.py` | p-median |
| `college_classroom_coloring.py` | graph coloring |
| `delivery_route_planning.py` | TSP |
| `diet_planner.py` | Stigler's diet |
| `distribution_center_selection.py` | CFLP |
| `dual_lp_demonstration.py` | Duality |
| `factory_scheduling.py` | Job shop |
| `fleet_routing_clarke_wright.py` | VRP |
| `fuel_blend_optimization.py` | Blending |
| `min_cost_path_road_network.py` | Shortest path |
| `min_cost_supply_chain.py` | Min-cost flow |
| `network_max_flow.py` | Max flow |
| `network_routing.py` | Shortest path |
| `paper_cutting_stock.py` | Cutting stock |
| `personnel_assignment.py` | Assignment |
| `power_plant_scheduling.py` | Lot sizing |
| `qap_layout.py` | QAP |
| `sensitivity_demo.py` | Sensitivity |
| `set_covering_facility_siting.py` | Set covering |
| `tsp_metaheuristics_comparison.py` | Metaheuristics |
| `two_player_game.py` | Game theory |
| `warehouse_packing.py` | Bin packing |
