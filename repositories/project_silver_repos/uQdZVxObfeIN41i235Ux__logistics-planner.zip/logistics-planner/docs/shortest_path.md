# Shortest Path

Find the minimum-cost path from `s` to `t` in a directed graph.

## Dijkstra (default)

Standard O(`(V + E) log V`) priority-queue Dijkstra. Requires non-negative
edge weights. Returns `(distance, path)`.

## LP

```
min  sum_e c_e * x_e
s.t. sum_{e in out(v)} x_e - sum_{e in in(v)} x_e =
       +1 if v = s
       -1 if v = t
        0 otherwise
     x_e ≥ 0
```

The LP relaxation is integral here (network constraint matrix is totally
unimodular), so we get integer flows for free.
