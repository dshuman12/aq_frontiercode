# logistics-planner docs

Pick a topic:

- [Quickstart](quickstart.md)
- [CLI usage](cli_usage.md)
- [Architecture](architecture.md)
- [Data format](data_format.md)
- [Testing](testing.md)
- [Glossary](glossary.md)
- [References](references.md)

Per-problem:

- [CFLP](cflp.md), [Transportation](transportation.md), [Lot sizing](lot_sizing.md)
- [Blending](blending.md), [Diet](diet.md), [TSP](tsp.md)
- [Assignment](assignment.md), [Shortest path](shortest_path.md), [Max flow](max_flow.md)
- [Min-cost flow](min_cost_flow.md), [Knapsack](knapsack.md), [Multi-dim knapsack](multi_dim_knapsack.md)
- [Set covering](set_covering.md), [Set partitioning](set_partitioning.md), [Bin packing](bin_packing.md)
- [VRP](vrp.md), [Job shop](job_shop.md), [QAP](qap.md), [Cutting stock](cutting_stock.md)
- [P-median](p_median.md), [Graph coloring](graph_coloring.md), [Max clique](max_clique.md)

Solvers:

- [Simplex](simplex.md), [Big-M](big_m.md), [Two-phase](two_phase.md), [Dual simplex](dual_simplex.md)
- [Branch and bound](branch_and_bound.md), [Cutting planes](cutting_planes.md)
- [Lagrangian](lagrangian.md), [Column generation](column_generation.md)

Other:

- [Sensitivity](sensitivity.md), [Duality](duality.md)
- [Game theory](game_theory.md)
- [Genetic algorithm](genetic_algorithm.md), [Simulated annealing](simulated_annealing.md), [Tabu search](tabu_search.md)
- [Benchmark](benchmark.md)
