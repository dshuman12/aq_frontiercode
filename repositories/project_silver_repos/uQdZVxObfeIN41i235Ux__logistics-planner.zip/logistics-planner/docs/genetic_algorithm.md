# Genetic Algorithm

Evolutionary metaheuristic. Maintain a population of candidate solutions;
breed children via crossover and mutation; select fitter individuals to
survive.

## Operators

- **Initialization** — caller-provided
- **Selection** — tournament (default size 3)
- **Crossover** — caller-provided (e.g. order crossover for permutations)
- **Mutation** — caller-provided (e.g. swap or bit-flip)
- **Elitism** — top `k` always carry over to next generation

## Tuning knobs

`population_size`, `generations`, `crossover_rate`, `mutation_rate`,
`tournament_size`, `elitism`. All in `GAConfig`.
