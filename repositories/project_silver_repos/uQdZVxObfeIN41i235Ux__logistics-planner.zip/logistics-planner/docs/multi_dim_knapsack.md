# Multi-Dimensional Knapsack

Generalization of 0/1 knapsack with multiple resource constraints (e.g.,
weight and volume).

```
max  sum_i v_i * x_i
s.t. sum_i W_ki * x_i ≤ cap_k    for each constraint k
     x_i ∈ {0, 1}
```

No polynomial DP exists in general — solved as MIP.
