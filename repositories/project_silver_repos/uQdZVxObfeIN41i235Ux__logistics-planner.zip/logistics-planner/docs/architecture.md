# Architecture notes

The code grew over a couple of semesters so style is uneven on purpose.

- `problems/` — one file per problem, each exposing a class with `__init__`
  and `solve()` returning a dataclass.
- `solvers/` — generic LP/MIP solvers (simplex variants, branch & bound,
  cutting planes, column generation, Lagrangian).
- `metaheuristics/` — generic GA/SA/tabu and per-problem applications.
- `analysis/` — sensitivity & duality.
- `benchmark/` — random instance generators + comparison harness.
- `data/` — loaders + output formatters.
- `visualization/` — matplotlib helpers.
- `cli.py` — argparse front-end.

Tests live under `tests/`. Each problem has a primary test file plus
`*_extra.py` files for parametrized / random-instance coverage.
