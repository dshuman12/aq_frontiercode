# Tabu Search

Local search with memory. Always move to the best non-tabu neighbor (even if
it worsens the objective). Recently-used moves are forbidden ("tabu") to
escape local minima.

## Aspiration

A tabu move is allowed if it would improve the global best — otherwise we'd
sometimes refuse genuinely better moves.

## Tuning

- `tabu_tenure` — how long a move stays forbidden
- `neighborhood_size` — how many neighbors to scan per step
- `max_iterations` — total iteration budget
