# Cutting Stock

1D cutting stock: stock rolls of length `L`, demand for `n_i` copies of
width `w_i`. Minimize total rolls used.

For small instances we enumerate all maximal patterns and solve directly:

```
min  sum_p x_p
s.t. sum_p A_ip * x_p ≥ d_i   for each item width i
     x_p ∈ Z+
```

`A_ip` = number of width-`i` cuts in pattern `p`.

For large instances, column generation is the standard approach (master
solves the LP over current patterns, pricing oracle generates new ones via a
knapsack).
