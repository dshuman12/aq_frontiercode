# Assignment Problem

Assign `n` agents to `n` tasks one-to-one at minimum total cost.

`x_ij ∈ {0, 1}`, 1 if agent `i` is assigned task `j`.

```
min  sum_ij c_ij * x_ij
s.t. sum_j x_ij = 1  (each agent assigned to one task)
     sum_i x_ij = 1  (each task assigned to one agent)
```

The LP relaxation is integral (totally unimodular), so the LP gives the
optimum. The Hungarian algorithm runs in `O(n^3)` and gives the same answer
without the LP overhead.
