# Two-Phase Simplex

Cleaner alternative to big-M for finding an initial basis.

## Phase 1

Add artificial variables, minimize their sum. If the minimum is zero, drop
artificials and proceed to phase 2. If positive, the original LP is
infeasible.

## Phase 2

Use the basis from phase 1 with the original objective.

Numerically more stable than big-M because there's no large constant.
