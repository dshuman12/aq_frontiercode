# Maximum Clique

Find the largest complete subgraph (clique) of an undirected graph.

## MIP

```
max  sum_v x_v
s.t. x_u + x_v ≤ 1   for every NON-edge (u, v)
     x_v ∈ {0, 1}
```

The non-edge constraint forbids taking both endpoints of any non-edge — i.e.
the selected set must be a clique.

## Greedy

Sort vertices by descending degree, add each vertex if it's adjacent to all
already-selected vertices. Fast but not optimal.
