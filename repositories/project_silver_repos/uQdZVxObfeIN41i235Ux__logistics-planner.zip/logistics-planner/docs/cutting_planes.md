# Cutting Planes

Solve the LP relaxation, find a fractional integer variable, add a cut that
excludes the current LP solution but keeps all integer-feasible points.

## Naive Gomory-style cuts

Pick the integer variable closest to a half-integer value. Add the cut
`x_j ≤ floor(x_j*)`.

This loses optimality of the LP but eventually drives solutions to integers.
For real performance you'd implement proper Gomory mixed-integer cuts derived
from the simplex tableau, but this naive form works for tutorial-sized LPs.
