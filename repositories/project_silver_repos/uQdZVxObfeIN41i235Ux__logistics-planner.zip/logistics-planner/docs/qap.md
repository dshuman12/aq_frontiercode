# Quadratic Assignment Problem

Assign `n` facilities to `n` locations to minimize the sum of flow times
distance over all pairs.

```
min  sum_ij F_ij * D_perm(i),perm(j)
```

The natural formulation is quadratic. We use the Frieze-Yadegar
linearization: introduce `y_ijkl = x_ik * x_jl` with the standard
McCormick-style upper/lower bounds.

For larger instances the local-search 2-swap heuristic is much faster but
gives no optimality guarantee.
