# Maximum Flow

Find the largest flow from source `s` to sink `t` respecting edge capacities.

## Edmonds-Karp

BFS-based augmenting paths. Each augmentation pushes flow along the shortest
augmenting path in the residual graph. Runs in `O(V * E^2)`.

## LP

```
max  sum_{e in out(s)} x_e - sum_{e in in(s)} x_e
s.t. sum_{e in in(v)} x_e = sum_{e in out(v)} x_e   for v != s, t
     0 ≤ x_e ≤ cap_e
```

Both methods give the same optimum. The LP version is convenient when you
want to add side constraints (e.g. min-cost on top of max flow).
