# Set Partitioning Problem

Like set covering but each element must be covered exactly once.

```
min  sum_j c_j * x_j
s.t. sum_j A_ij * x_j = 1   for every element i
     x_j ∈ {0, 1}
```

Often used as the master in column-generation for crew scheduling, vehicle
routing, etc.
