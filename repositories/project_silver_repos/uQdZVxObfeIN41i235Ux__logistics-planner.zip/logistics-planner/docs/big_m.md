# Big-M Simplex

For LPs with no obvious initial feasible basis, add an artificial variable
per constraint, penalize it with a big constant `M` in the objective, and
run simplex.

If any artificial variable is positive in the optimal basis, the LP is
infeasible.

`M` must be large enough that the optimal solution drives all artificials
to zero. Too large amplifies numerical errors; too small risks suboptimal.
