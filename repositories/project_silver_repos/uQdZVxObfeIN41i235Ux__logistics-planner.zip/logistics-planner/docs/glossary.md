# OR Glossary

- **LP** — Linear Program
- **MIP** — Mixed-Integer Program (some vars integer, others continuous)
- **Big-M** — large constant for relaxing constraints, used in artificial-
  variable methods
- **MTZ** — Miller-Tucker-Zemlin: subtour elimination using ordering vars
- **Shadow price** — dual variable on a constraint, marginal cost of RHS
- **Reduced cost** — how much an objective coefficient must change before
  a variable enters the basis
- **Pivoting** — exchange basic and non-basic variables in the simplex
- **Subgradient** — generalized gradient for non-smooth functions, used in
  Lagrangian methods
