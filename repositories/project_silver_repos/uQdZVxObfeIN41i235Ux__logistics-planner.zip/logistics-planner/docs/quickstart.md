# Quickstart

```
make install
make test
python examples/distribution_center_selection.py
```

Or the CLI:

```
python -m logistics_planner.cli lot-sizing data_samples/lot_sizing_small.json
```
