# Job Shop Scheduling

Schedule operations of multiple jobs on a fixed set of machines. Each job has
an ordered sequence of operations, each operation runs on a designated
machine for a given duration. No two operations on the same machine overlap.

## Variables

- `start_jk ≥ 0` — start time of job `j` operation `k`
- `y_{j1k1, j2k2} ∈ {0, 1}` — disjunctive ordering between two operations
  competing for the same machine

## Objective

Minimize makespan: `max_j (end of last operation of j)`.
