# Transportation Problem

Cheapest shipment plan from `m` sources to `n` destinations.

## Variables

`x_ij ≥ 0` — units shipped from source `i` to destination `j`.

## Objective

```
min  sum_ij c_ij * x_ij
```

## Constraints

- Supply: `sum_j x_ij = supply_i`
- Demand: `sum_i x_ij = demand_j`

For unbalanced cases (sum supply ≠ sum demand), we add a dummy source or
destination at zero cost so the LP stays balanced.
