# P-Median

Pick exactly `p` facility locations from `n` candidates to minimize the
total weighted distance from each demand point to its nearest open facility.

```
min  sum_ij d_i * D_ij * x_ij
s.t. sum_j y_j = p
     sum_j x_ij = 1            for every demand point i
     x_ij ≤ y_j                for all i, j
     x_ij ∈ [0, 1], y_j ∈ {0, 1}
```

`d_i` = demand weight at point `i`, `D_ij` = distance.
