# Lagrangian Relaxation

Relax "complicating" constraints by penalizing them in the objective with
multipliers `u`. Solve the simpler subproblem repeatedly while updating `u`
via subgradient steps.

## Update rule

```
u <- max(0, u - alpha * subgradient)     (for max-objective)
alpha <- alpha * decay
```

## Bounds

For a maximization primal:
- Subproblem optimum is an upper bound (dual gives bound on primal)
- A feasibility-repair step gives a lower bound (any feasible primal value)

The two converge from above and below; the gap measures how good the
relaxation is.
