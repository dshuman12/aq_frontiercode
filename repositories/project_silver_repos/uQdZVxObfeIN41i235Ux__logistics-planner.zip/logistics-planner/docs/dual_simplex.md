# Dual Simplex

Useful when the current basis is dual-feasible but primal-infeasible.
Iterates by selecting a leaving variable with negative `b_i` and an entering
variable via the dual ratio test.

Common applications:

- Re-solving an LP after tightening RHS
- Inside cutting-plane methods (each new cut keeps dual feasibility)
- Branch-and-bound child nodes
