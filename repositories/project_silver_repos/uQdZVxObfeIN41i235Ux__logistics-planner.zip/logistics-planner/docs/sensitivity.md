# Sensitivity Analysis

After solving an LP, ask "how sensitive is the optimum to changes in the
inputs?". The PuLP solution exposes:

- **Shadow prices** (constraint duals `pi`) — marginal change in optimum
  per unit change in RHS
- **Reduced costs** (`dj` per variable) — how much the cost coefficient
  must change before the variable enters/leaves the basis
- **Slacks** — how much the LHS differs from the RHS at optimum

Use cases:
- Pricing decisions (shadow prices on capacity = willingness to pay for
  more capacity)
- What-if analysis without re-solving
