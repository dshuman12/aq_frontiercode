# Running tests

```
make test           # verbose
make test-fast      # quiet
pytest tests/<one>  # single file
```

The suite uses pytest's parametrize for tests over multiple seeds and sizes.
