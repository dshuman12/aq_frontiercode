# Capacitated Lot Sizing

Multi-period production planning. Decide how much to produce in each period and
when to incur a setup cost.

## Variables

- `y_t ∈ {0, 1}` — 1 if production happens in period `t`
- `x_t ≥ 0` — units produced in period `t`
- `I_t ≥ 0` — inventory at end of period `t`

## Objective

```
min  sum_t (s_t * y_t  +  p_t * x_t  +  h_t * I_t)
```

## Constraints

- Inventory balance: `I_t = I_{t-1} + x_t - d_t`
- Capacity / setup link: `x_t ≤ cap_t * y_t`
- Initial inventory at `t=0`: `I_0 = init + x_0 - d_0`
