# Column Generation

For LPs with too many columns to enumerate (e.g., cutting stock with all
patterns, set partitioning over all routes).

## Master

Solve a restricted LP using only a subset of columns.

## Pricing

Given the dual prices from the master, search for a column with negative
reduced cost (for min) or positive (for max). Add it to the master and
re-solve.

Stop when no improving column exists — the current solution is LP-optimal
over all columns.
