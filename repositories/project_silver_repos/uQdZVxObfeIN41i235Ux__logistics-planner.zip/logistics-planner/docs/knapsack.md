# 0/1 Knapsack

Pick a subset of items to maximize value subject to a weight capacity.

```
max  sum_i v_i * x_i
s.t. sum_i w_i * x_i ≤ W
     x_i ∈ {0, 1}
```

## DP (default)

Classical bottom-up DP, `O(n * W)` time and memory. Requires integer weights
and integer capacity.

## MIP

Direct PuLP formulation with binary variables. Slower for large `n` but
handles fractional weights.
