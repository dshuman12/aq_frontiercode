# Game Theory

Two-player matrix games supported.

## Zero-sum (minimax via LP)

Row player chooses a mixed strategy `p` over rows; column player chooses
`q` over columns. Game value is the row player's expected payoff:

```
v = max_p min_q  p^T A q
```

By the minimax theorem this equals `min_q max_p p^T A q` and can be solved
by an LP.

## General-sum (bimatrix)

Each player has their own payoff matrix. Pure Nash equilibria can be enum-
erated by checking each cell against best responses on both sides.

## Dominance reduction

A row is dominated if some other row has weakly higher payoff everywhere
and strictly higher somewhere. Iterated removal of dominated rows/columns
shrinks the game.
