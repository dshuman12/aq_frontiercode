# Contributing

This is a personal project I started to solidify my OR / LP coursework, but
PRs and bug reports are welcome.

## Setup

```
make install
make test
```

## Style

- Existing code is uneven — older modules (CFLP) use a more verbose style
  carried over from my Colab notebooks; newer modules use the helpers in
  `solvers/lp_solver.py` and `utils.py`. Don't rewrite older files just for
  style; keep new code in the helper-using style.
- Tests should pass on `pytest tests/`.

## Adding a problem

1. Create `logistics_planner/problems/<name>_problem.py` exposing a class
   with a `solve()` method returning a dataclass solution.
2. Add tests under `tests/test_<name>_problem.py`.
3. Add a usage example under `examples/`.
4. Optionally add a brief math write-up in `docs/<name>.md`.
