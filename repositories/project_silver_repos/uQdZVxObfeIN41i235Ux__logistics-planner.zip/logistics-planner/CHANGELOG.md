# Changelog

## Unreleased

- Vehicle routing (Clarke-Wright + MIP)
- Job shop scheduling
- Quadratic assignment (linearized MIP + 2-swap)
- Cutting stock
- p-median
- Graph coloring
- Maximum clique
- Metaheuristics module (GA, SA, tabu search) with TSP and knapsack apps
- Lagrangian relaxation
- Column generation
- Cutting planes
- Dual simplex
- Benchmark module with random instance generators

## v1.0.0

- 15 core problems (CFLP, transportation, lot sizing, blending, diet,
  TSP, assignment, shortest path, max flow, min cost flow, two knapsacks,
  set covering/partitioning, bin packing)
- Game theory module (matrix games, bimatrix, dominance)
- Sensitivity analysis + dual LP
- Branch and bound, big-M, two-phase simplex
- Pure-Python revised simplex
- JSON loaders + output formatters
- Visualization helpers
- CLI

## v1.1.0 (planned)

- Bug fixes for CFLP, lot sizing, blending, TSP MTZ, and a couple of solver
  helpers
- More tests, more examples, more docs
