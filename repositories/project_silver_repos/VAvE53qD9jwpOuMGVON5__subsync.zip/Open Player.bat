@echo off
REM Opens the in-browser subtitle player/editor.
cd /d "%~dp0"
start "" "player.html"
