"""
Combined Continuity & Spotting List (CCSL) export.

A CCSL is the document a translator / dubbing director / lab uses to localise a
title. It tabulates, in order:

   #   TC IN          TC OUT         SPEAKER       DIALOGUE                 ACTION / NOTES
  001  00:00:01:00    00:00:03:12    CHARACTER A   Line of dialogue here.   Walks toward window
  002  00:00:03:18    00:00:04:22    [Music]                                Score swells

Timecodes are SMPTE non-drop frame (HH:MM:SS:FF) at the user's chosen frame
rate (default 25 fps — broadcast standard outside North America). When a
target language is provided we add an extra column for the translation.
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional, Iterable

from .types import Transcript


def _smpte(t: float, fps: float = 25.0) -> str:
    if t < 0: t = 0.0
    total_frames = int(round(t * fps))
    h = total_frames // (3600 * int(fps))
    rem = total_frames - h * 3600 * int(fps)
    m = rem // (60 * int(fps))
    rem -= m * 60 * int(fps)
    s = rem // int(fps)
    f = rem - s * int(fps)
    return f"{h:02d}:{m:02d}:{s:02d}:{f:02d}"


def write_ccsl(
    t: Transcript,
    path: Path,
    *,
    title: str = "Untitled",
    fps: float = 25.0,
    translation_lang: Optional[str] = None,
    include_events: bool = True,
) -> Path:
    """Write a CCSL DOCX. Falls back to TSV if python-docx is unavailable."""
    try:
        from docx import Document
        from docx.shared import Cm, Pt, RGBColor
        from docx.enum.table import WD_ALIGN_VERTICAL
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        return _write_ccsl_tsv(t, path.with_suffix(".tsv"),
                               title=title, fps=fps,
                               translation_lang=translation_lang,
                               include_events=include_events)

    items = _ccsl_rows(t, include_events=include_events)

    doc = Document()
    section = doc.sections[0]
    section.left_margin = Cm(1.5); section.right_margin = Cm(1.5)
    section.top_margin = Cm(1.5);  section.bottom_margin = Cm(1.5)

    h = doc.add_heading(f"Combined Continuity & Spotting List — {title}", level=1)
    sub = doc.add_paragraph()
    sub.add_run(f"Language: {t.language.upper()}    Duration: {t.duration:.2f} s    "
                f"Frame rate: {fps} fps    Items: {len(items)}").italic = True

    cols = ["#", "TC IN", "TC OUT", "Speaker", "Dialogue", "Action / Notes"]
    if translation_lang:
        cols.insert(5, f"Translation ({translation_lang.upper()})")

    table = doc.add_table(rows=1, cols=len(cols))
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    for i, name in enumerate(cols):
        hdr[i].text = name
        for p in hdr[i].paragraphs:
            for r in p.runs:
                r.bold = True
                r.font.size = Pt(9)

    for n, row in enumerate(items, 1):
        cells = table.add_row().cells
        cells[0].text = f"{n:03d}"
        cells[1].text = _smpte(row["start"], fps)
        cells[2].text = _smpte(row["end"], fps)
        cells[3].text = row.get("speaker", "") or ""
        if translation_lang:
            cells[4].text = row.get("dialogue", "")
            cells[5].text = row.get("translation", {}).get(translation_lang, "")
            cells[6].text = row.get("notes", "")
        else:
            cells[4].text = row.get("dialogue", "")
            cells[5].text = row.get("notes", "")

        for c in cells:
            for p in c.paragraphs:
                for r in p.runs:
                    r.font.size = Pt(9)

    doc.save(str(path))
    return path


def _ccsl_rows(t: Transcript, include_events: bool) -> list[dict]:
    """Merge segments + events into a single chronological list of CCSL rows."""
    rows: list[dict] = []
    for s in t.segments:
        rows.append({
            "kind": "dialogue",
            "start": s.start, "end": s.end,
            "speaker": s.speaker or "",
            "dialogue": s.text,
            "translation": dict(s.translations),
            "notes": "",
        })
    if include_events:
        for e in t.events:
            rows.append({
                "kind": "event",
                "start": e.start, "end": e.end,
                "speaker": "",
                "dialogue": "",
                "translation": {},
                "notes": f"[{e.label}]",
            })
    rows.sort(key=lambda r: (r["start"], 0 if r["kind"] == "dialogue" else 1))
    return rows


def _write_ccsl_tsv(t: Transcript, path: Path, *, title: str, fps: float,
                    translation_lang: Optional[str], include_events: bool) -> Path:
    items = _ccsl_rows(t, include_events=include_events)
    cols = ["#", "TC_IN", "TC_OUT", "SPEAKER", "DIALOGUE"]
    if translation_lang: cols.append(f"TRANSLATION_{translation_lang.upper()}")
    cols.append("NOTES")
    lines = ["\t".join(cols)]
    for n, r in enumerate(items, 1):
        row = [
            f"{n:03d}",
            _smpte(r["start"], fps),
            _smpte(r["end"], fps),
            r.get("speaker", "") or "",
            r.get("dialogue", "") or "",
        ]
        if translation_lang:
            row.append(r.get("translation", {}).get(translation_lang, ""))
        row.append(r.get("notes", "") or "")
        lines.append("\t".join(c.replace("\t", " ").replace("\n", " / ") for c in row))
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
