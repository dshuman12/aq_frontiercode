"""
Speaker diarization with pyannote/speaker-diarization-3.1.

Notes for the operator:
  - pyannote requires a free Hugging Face account, plus accepting the licence
    on https://huggingface.co/pyannote/speaker-diarization-3.1
  - Set the HF_TOKEN env var, or pass --hf-token on the CLI.
  - GPU is strongly recommended; CPU works but is slow on long files.
"""
from __future__ import annotations
import os, sys
from pathlib import Path
from typing import Optional

from .types import Turn, Segment, Word


def diarize(
    audio: Path,
    *,
    hf_token: Optional[str] = None,
    num_speakers: Optional[int] = None,
    min_speakers: Optional[int] = None,
    max_speakers: Optional[int] = None,
    device: str = "auto",
) -> list[Turn]:
    """Return ordered speaker turns over the audio."""
    # Broader than ImportError: in PyInstaller bundles, pytorch_lightning's import
    # chain can raise FileNotFoundError when an optional data file like
    # lightning_fabric/version.info wasn't collected. We don't want any of that
    # to kill the whole pipeline - just skip diarization gracefully.
    try:
        import torch
        from pyannote.audio import Pipeline
    except Exception as e:
        print(f"[subsync] pyannote.audio unavailable ({type(e).__name__}: {e}); "
              f"skipping diarization", file=sys.stderr)
        return []

    token = hf_token or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN")
    if not token:
        print("[subsync] HF_TOKEN not set; skipping diarization", file=sys.stderr)
        return []

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"[subsync] loading diarization pipeline on {device}", file=sys.stderr)
    pipe = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token=token)
    if device == "cuda":
        pipe.to(torch.device("cuda"))

    kwargs: dict = {}
    if num_speakers is not None: kwargs["num_speakers"] = num_speakers
    if min_speakers is not None: kwargs["min_speakers"] = min_speakers
    if max_speakers is not None: kwargs["max_speakers"] = max_speakers

    print("[subsync] diarizing…", file=sys.stderr)
    annotation = pipe(str(audio), **kwargs)

    turns: list[Turn] = []
    for turn, _, label in annotation.itertracks(yield_label=True):
        turns.append(Turn(start=turn.start, end=turn.end, speaker=label))
    turns.sort(key=lambda t: t.start)
    print(f"[subsync] {len(turns)} turn(s), {len({t.speaker for t in turns})} speaker(s)",
          file=sys.stderr)
    return turns


def assign_speakers(segments: list[Segment], turns: list[Turn]) -> list[str]:
    """
    Tag every word and segment with a speaker by maximum overlap.
    Returns the sorted list of unique speakers seen.
    """
    if not turns:
        return []
    seen: set[str] = set()
    for seg in segments:
        # Word-level assignment when we have word timings
        if seg.words:
            for w in seg.words:
                w.speaker = _best_overlap(w.start, w.end, turns)
                if w.speaker: seen.add(w.speaker)
            # Segment speaker = majority vote across words
            counts: dict[str, float] = {}
            for w in seg.words:
                if w.speaker:
                    counts[w.speaker] = counts.get(w.speaker, 0.0) + max(0.0, w.end - w.start)
            if counts:
                seg.speaker = max(counts, key=counts.get)
        else:
            seg.speaker = _best_overlap(seg.start, seg.end, turns)
            if seg.speaker: seen.add(seg.speaker)
    return sorted(seen)


def _best_overlap(s: float, e: float, turns: list[Turn]) -> Optional[str]:
    best, best_amt = None, 0.0
    for t in turns:
        if t.end <= s: continue
        if t.start >= e: break
        overlap = min(e, t.end) - max(s, t.start)
        if overlap > best_amt:
            best, best_amt = t.speaker, overlap
    return best
