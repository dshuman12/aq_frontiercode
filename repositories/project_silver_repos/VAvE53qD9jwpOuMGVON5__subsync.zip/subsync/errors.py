"""Custom exception hierarchy.

CLI and GUI both catch these to render friendly errors. Bare RuntimeError
gets a generic 'something went wrong' message; subclasses get specific
templates and 'try X' hints.
"""

from __future__ import annotations

from typing import List, Optional


class SubsyncError(Exception):
    """Base for everything in this package."""
    def __init__(self, message: str, hint: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self) -> str:
        if self.hint:
            return "{}\nhint: {}".format(self.message, self.hint)
        return self.message


# Input -----------------------------------------------------------------------

class InputError(SubsyncError):
    pass


class MissingFileError(InputError):
    def __init__(self, path: str):
        super().__init__("file does not exist: {}".format(path))
        self.path = path


class UnsupportedMediaError(InputError):
    def __init__(self, ext: str):
        super().__init__("unsupported media: {}".format(ext),
                         hint="we accept audio/video that ffmpeg understands.")
        self.ext = ext


class FfmpegMissingError(InputError):
    def __init__(self):
        super().__init__("ffmpeg not found on PATH",
                         hint="install ffmpeg and ensure it's on your PATH.")


# Pipeline --------------------------------------------------------------------

class PipelineError(SubsyncError):
    pass


class TranscribeError(PipelineError):
    pass


class AlignError(PipelineError):
    pass


class DiarizeError(PipelineError):
    pass


class TranslateError(PipelineError):
    pass


class TagError(PipelineError):
    pass


class ExportError(PipelineError):
    pass


# Output ----------------------------------------------------------------------

class OutputError(SubsyncError):
    pass


class FormatError(OutputError):
    """The format module raised on parse/write."""


class CCSLValidationError(OutputError):
    pass


class TimecodeError(OutputError):
    pass


# Auth / config ---------------------------------------------------------------

class HFTokenError(SubsyncError):
    def __init__(self):
        super().__init__("Hugging Face token required for diarization",
                         hint="set HF_TOKEN env var, accept the pyannote licence.")


class ConfigError(SubsyncError):
    pass


class DependencyError(SubsyncError):
    def __init__(self, name: str, install_hint: Optional[str] = None):
        super().__init__("required dependency missing: {}".format(name),
                         hint=install_hint or "pip install {}".format(name))
        self.name = name


# Aggregates ------------------------------------------------------------------

class MultiError(SubsyncError):
    """Several sub-pipelines failed; we ran the rest."""

    def __init__(self, errors: List[SubsyncError]):
        super().__init__("{} sub-tasks failed".format(len(errors)),
                         hint="see .errors for the full list.")
        self.errors = list(errors)

    def __iter__(self):
        return iter(self.errors)


def map_external(exc: Exception) -> SubsyncError:
    if isinstance(exc, SubsyncError):
        return exc
    name = type(exc).__name__
    msg = str(exc) or name
    if name == "FileNotFoundError":
        return MissingFileError(msg)
    if name in ("PermissionError", "IsADirectoryError"):
        return InputError(msg)
    if "torch" in msg.lower() and "cuda" in msg.lower():
        return PipelineError(msg, hint="set --device cpu to fall back.")
    return PipelineError(msg)
