"""ISO 639 language codes for subtitle file naming and metadata.

Mapping is intentionally conservative - only entries we can sensibly route
through the rest of the pipeline (whisper language detection, translate
target lookup, file suffix conventions).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class Language:
    code_2: str            # ISO 639-1 (e.g. 'en')
    code_3: str            # ISO 639-2/3 (e.g. 'eng')
    name: str              # English name
    rtl: bool = False      # Right-to-left script
    cjk: bool = False      # Chinese/Japanese/Korean wrap rules apply
    notes: str = ""


LANGUAGES: List[Language] = [
    Language("en", "eng", "English"),
    Language("es", "spa", "Spanish"),
    Language("fr", "fra", "French"),
    Language("de", "deu", "German"),
    Language("it", "ita", "Italian"),
    Language("pt", "por", "Portuguese"),
    Language("nl", "nld", "Dutch"),
    Language("sv", "swe", "Swedish"),
    Language("no", "nor", "Norwegian"),
    Language("da", "dan", "Danish"),
    Language("fi", "fin", "Finnish"),
    Language("pl", "pol", "Polish"),
    Language("cs", "ces", "Czech"),
    Language("sk", "slk", "Slovak"),
    Language("hu", "hun", "Hungarian"),
    Language("ro", "ron", "Romanian"),
    Language("bg", "bul", "Bulgarian"),
    Language("el", "ell", "Greek"),
    Language("ru", "rus", "Russian"),
    Language("uk", "ukr", "Ukrainian"),
    Language("tr", "tur", "Turkish"),
    Language("ar", "ara", "Arabic", rtl=True),
    Language("he", "heb", "Hebrew", rtl=True),
    Language("fa", "fas", "Persian", rtl=True),
    Language("ur", "urd", "Urdu", rtl=True),
    Language("hi", "hin", "Hindi"),
    Language("bn", "ben", "Bengali"),
    Language("ta", "tam", "Tamil"),
    Language("te", "tel", "Telugu"),
    Language("ml", "mal", "Malayalam"),
    Language("kn", "kan", "Kannada"),
    Language("mr", "mar", "Marathi"),
    Language("gu", "guj", "Gujarati"),
    Language("pa", "pan", "Punjabi"),
    Language("th", "tha", "Thai", notes="No spaces between words; wrap rules differ."),
    Language("vi", "vie", "Vietnamese"),
    Language("id", "ind", "Indonesian"),
    Language("ms", "msa", "Malay"),
    Language("tl", "tgl", "Tagalog"),
    Language("ja", "jpn", "Japanese", cjk=True),
    Language("ko", "kor", "Korean", cjk=True),
    Language("zh", "zho", "Chinese (Simplified)", cjk=True),
    Language("zt", "zho", "Chinese (Traditional)", cjk=True),
    Language("af", "afr", "Afrikaans"),
    Language("sw", "swa", "Swahili"),
    Language("am", "amh", "Amharic"),
    Language("ha", "hau", "Hausa"),
    Language("yo", "yor", "Yoruba"),
    Language("ig", "ibo", "Igbo"),
    Language("zu", "zul", "Zulu"),
]


_BY_2 = {l.code_2: l for l in LANGUAGES}
_BY_3 = {l.code_3: l for l in LANGUAGES}
_BY_NAME = {l.name.lower(): l for l in LANGUAGES}


def lookup(code_or_name: str) -> Optional[Language]:
    if not code_or_name:
        return None
    s = code_or_name.strip().lower()
    return _BY_2.get(s) or _BY_3.get(s) or _BY_NAME.get(s)


def to_2(code_or_name: str) -> Optional[str]:
    l = lookup(code_or_name)
    return l.code_2 if l else None


def to_3(code_or_name: str) -> Optional[str]:
    l = lookup(code_or_name)
    return l.code_3 if l else None


def is_rtl(code_or_name: str) -> bool:
    l = lookup(code_or_name)
    return bool(l and l.rtl)


def is_cjk(code_or_name: str) -> bool:
    l = lookup(code_or_name)
    return bool(l and l.cjk)


def all_codes() -> List[str]:
    return [l.code_2 for l in LANGUAGES]


def file_suffix(code_or_name: str) -> str:
    """Subtitle naming convention: 'foo.en.srt' / 'foo.zh-Hant.srt'."""
    l = lookup(code_or_name)
    if not l:
        return ""
    if l.code_2 == "zt":
        return ".zh-Hant"
    return "." + l.code_2
