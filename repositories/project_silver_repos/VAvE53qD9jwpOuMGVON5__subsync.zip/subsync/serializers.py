"""JSON / msgpack-friendly serialisers for Transcript & friends.

Used by the GUI's "Save Project" command and by the cache layer that
remembers transcribe results so we don't re-run a 20-minute model pass
when only the wrap rules changed.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict
from typing import Any, Dict
from pathlib import Path

from .types import Transcript, Segment, Word, Event, Turn


PROJECT_VERSION = 1


def transcript_to_dict(t: Transcript) -> Dict[str, Any]:
    return {
        "_type": "Transcript",
        "_version": PROJECT_VERSION,
        "language": t.language,
        "duration": t.duration,
        "speakers": list(t.speakers),
        "events": [asdict(e) for e in t.events],
        "segments": [_segment_to_dict(s) for s in t.segments],
    }


def transcript_from_dict(d: Dict[str, Any]) -> Transcript:
    if d.get("_type") not in (None, "Transcript"):
        raise ValueError("not a Transcript payload")
    t = Transcript(language=d.get("language", ""),
                   duration=float(d.get("duration", 0.0)))
    t.speakers = list(d.get("speakers", []))
    for e in d.get("events", []):
        t.events.append(Event(**e))
    for s in d.get("segments", []):
        t.segments.append(_segment_from_dict(s))
    return t


def _segment_to_dict(s: Segment) -> Dict[str, Any]:
    return {
        "start": s.start, "end": s.end, "text": s.text,
        "avg_logprob": s.avg_logprob, "no_speech_prob": s.no_speech_prob,
        "speaker": s.speaker,
        "translations": dict(s.translations),
        "cps": s.cps,
        "words": [asdict(w) for w in s.words],
    }


def _segment_from_dict(d: Dict[str, Any]) -> Segment:
    s = Segment(start=float(d["start"]), end=float(d["end"]),
                text=d.get("text", ""))
    s.avg_logprob = float(d.get("avg_logprob", 0.0))
    s.no_speech_prob = float(d.get("no_speech_prob", 0.0))
    s.speaker = d.get("speaker")
    s.translations = dict(d.get("translations", {}))
    s.cps = float(d.get("cps", 0.0))
    for w in d.get("words", []):
        s.words.append(Word(**w))
    return s


# -----------------------------------------------------------------------------
# File-based wrappers
# -----------------------------------------------------------------------------

def save_json(t: Transcript, path: str) -> None:
    Path(path).write_text(json.dumps(transcript_to_dict(t), indent=2),
                          encoding="utf-8")


def load_json(path: str) -> Transcript:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return transcript_from_dict(raw)


def save_compact_json(t: Transcript, path: str) -> None:
    """Same as save_json but no indent. Smaller files for caches."""
    Path(path).write_text(json.dumps(transcript_to_dict(t), separators=(",", ":")),
                          encoding="utf-8")


def estimate_size_bytes(t: Transcript) -> int:
    """Quick size estimate for the JSON serialisation. Used to decide
    whether to compress before caching."""
    return len(json.dumps(transcript_to_dict(t)).encode("utf-8"))


def cache_key(input_path: str, model_name: str, language: str) -> str:
    """Deterministic cache key for a transcribe input."""
    import hashlib
    h = hashlib.sha256()
    h.update(input_path.encode("utf-8"))
    h.update(b"\x00")
    h.update(model_name.encode("utf-8"))
    h.update(b"\x00")
    h.update((language or "auto").encode("utf-8"))
    try:
        st = os.stat(input_path)
        h.update("{}:{}".format(int(st.st_mtime), st.st_size).encode("utf-8"))
    except OSError:
        pass
    return h.hexdigest()[:16]
