"""Progress reporting - text bar + tk sink + chained sinks."""

from __future__ import annotations

import sys
import time
import threading
from typing import Callable, Optional, TextIO


class ProgressReporter:
    def __init__(self, total: int = 100,
                 sink: Optional[Callable[[float, str], None]] = None,
                 label: str = ""):
        self.total = max(1, total)
        self.current = 0
        self.label = label
        self.sink = sink
        self._lock = threading.Lock()
        self._start = time.time()

    def advance(self, n: int = 1, message: Optional[str] = None) -> None:
        with self._lock:
            self.current = min(self.total, self.current + n)
            self._notify(message)

    def set(self, n: int, message: Optional[str] = None) -> None:
        with self._lock:
            self.current = max(0, min(self.total, n))
            self._notify(message)

    def set_total(self, n: int) -> None:
        with self._lock:
            self.total = max(1, n)

    def finish(self, message: Optional[str] = None) -> None:
        with self._lock:
            self.current = self.total
            self._notify(message or "done")

    @property
    def fraction(self) -> float:
        return self.current / self.total

    @property
    def elapsed(self) -> float:
        return time.time() - self._start

    def _notify(self, message: Optional[str]) -> None:
        if self.sink is None:
            return
        try:
            self.sink(self.fraction, message or self.label)
        except Exception:
            pass


class TextBar:
    def __init__(self, width: int = 40, stream: Optional[TextIO] = None,
                 fill_char: str = "#", empty_char: str = "-"):
        self.width = max(5, width)
        self.stream = stream or sys.stderr
        self.fill_char = fill_char
        self.empty_char = empty_char
        self._last_len = 0

    def __call__(self, frac: float, message: str = "") -> None:
        frac = max(0.0, min(1.0, frac))
        filled = int(round(frac * self.width))
        bar = self.fill_char * filled + self.empty_char * (self.width - filled)
        line = "[{}] {:6.2f}% {}".format(bar, frac * 100, message)
        if self._last_len > len(line):
            line += " " * (self._last_len - len(line))
        self._last_len = len(line)
        self.stream.write("\r" + line)
        self.stream.flush()

    def newline(self) -> None:
        self.stream.write("\n")
        self.stream.flush()
        self._last_len = 0


def chained(*reporters: ProgressReporter) -> Callable[[float, str], None]:
    def sink(frac: float, message: str = "") -> None:
        for r in reporters:
            r.set(int(round(frac * r.total)), message)
    return sink


def make_tk_sink(progressbar, status_label=None) -> Callable[[float, str], None]:
    """Returns a thread-safe sink that updates a tk.ttk.Progressbar."""
    root = progressbar.winfo_toplevel() if hasattr(progressbar, "winfo_toplevel") else None

    def sink(frac: float, message: str = "") -> None:
        def apply():
            try:
                progressbar["value"] = frac * 100
            except Exception:
                pass
            if status_label is not None:
                try:
                    status_label.config(text=message)
                except Exception:
                    pass
        if root is not None:
            try:
                root.after(0, apply)
                return
            except Exception:
                pass
        apply()
    return sink
