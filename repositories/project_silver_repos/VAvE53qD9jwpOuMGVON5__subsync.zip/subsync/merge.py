"""Merge multiple subtitle files into one transcript.

Useful when you have separate captions for dialogue and forced narrative,
or when a multi-language workflow gives you per-language outputs that
need to be combined for a delivery.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

from .types import Transcript, Segment


def merge_concat(transcripts: Iterable[Transcript],
                 gap_seconds: float = 0.0) -> Transcript:
    """Concatenate transcripts end-to-end, offsetting each by the previous
    duration. Used to stitch together pre-rolls and main content."""
    out = Transcript(language="", duration=0.0)
    offset = 0.0
    for t in transcripts:
        if not out.language and t.language:
            out.language = t.language
        for s in t.segments:
            ns = Segment(start=s.start + offset, end=s.end + offset,
                         text=s.text, speaker=s.speaker)
            out.segments.append(ns)
        offset = max(offset, max((s.end + offset for s in t.segments), default=offset))
        offset += gap_seconds
        out.duration = offset
    return out


def merge_overlay(primary: Transcript,
                  secondary: Transcript,
                  prefer: str = "primary") -> Transcript:
    """Combine two transcripts on the same timeline.

    `prefer` controls which transcript wins for time ranges that contain
    cues from both. 'primary' or 'secondary' or 'both'.
    """
    out = Transcript(language=primary.language, duration=max(primary.duration, secondary.duration))
    if prefer == "both":
        out.segments = sorted(
            list(primary.segments) + list(secondary.segments),
            key=lambda s: s.start,
        )
        return out
    keep = primary.segments if prefer == "primary" else secondary.segments
    other = secondary.segments if prefer == "primary" else primary.segments
    out.segments = list(keep)
    for s in other:
        if not _overlaps_any(s, keep):
            out.segments.append(s)
    out.segments.sort(key=lambda s: s.start)
    return out


def _overlaps_any(seg: Segment, others: List[Segment]) -> bool:
    for o in others:
        if seg.start < o.end and o.start < seg.end:
            return True
    return False


def merge_by_language(by_lang: Dict[str, Transcript],
                      target: str) -> Transcript:
    """Pick one transcript by language code. Errors if not present."""
    if target not in by_lang:
        raise KeyError("no transcript for language: {}".format(target))
    return by_lang[target]


def split_by_speaker(transcript: Transcript) -> Dict[str, Transcript]:
    """Group cues by speaker. Speakers without a label end up in 'unknown'."""
    out: Dict[str, Transcript] = {}
    for s in transcript.segments:
        key = s.speaker or "unknown"
        if key not in out:
            out[key] = Transcript(language=transcript.language, duration=transcript.duration)
        out[key].segments.append(s)
    return out


def deduplicate(transcript: Transcript,
                start_tol: float = 0.05) -> Transcript:
    """Drop segments with the same text + nearly identical start.
    Sometimes happens when re-running transcribe with --align."""
    seen: List[Tuple[float, str]] = []
    out: List[Segment] = []
    for s in transcript.segments:
        key = (round(s.start / max(start_tol, 1e-6)), (s.text or "").strip())
        if any(k == key for k in seen):
            continue
        seen.append(key)
        out.append(s)
    transcript.segments = out
    return transcript
