"""Subcommands beyond `subsync transcribe`.

  - subsync convert IN OUT       : convert one subtitle format to another
  - subsync info FILE            : print summary stats
  - subsync diff A B             : structural diff
  - subsync validate FILE        : run output validators
  - subsync wrap FILE [--max N]  : re-wrap an existing file to a width
  - subsync shift FILE +1.5      : shift all timings by N seconds
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Optional

from .formats import dispatch
from .validate import validate, is_valid


def cmd_convert(in_path: str, out_path: str) -> int:
    try:
        t = dispatch.read(in_path)
    except Exception as exc:
        print("error reading {}: {}".format(in_path, exc), file=sys.stderr)
        return 1
    try:
        dispatch.write(t, out_path)
    except Exception as exc:
        print("error writing {}: {}".format(out_path, exc), file=sys.stderr)
        return 1
    print("wrote {} ({} cues)".format(out_path, len(t.segments)))
    return 0


def cmd_info(path: str) -> int:
    try:
        t = dispatch.read(path)
    except Exception as exc:
        print("error: {}".format(exc), file=sys.stderr)
        return 1
    duration = t.duration or (t.segments[-1].end if t.segments else 0.0)
    total_chars = sum(len(s.text or "") for s in t.segments)
    print("file:        {}".format(path))
    print("language:    {}".format(t.language or "(unknown)"))
    print("cues:        {}".format(len(t.segments)))
    print("duration:    {:.2f}s".format(duration))
    print("total chars: {}".format(total_chars))
    if t.segments:
        avg_dur = sum((s.end - s.start) for s in t.segments) / len(t.segments)
        print("avg cue dur: {:.2f}s".format(avg_dur))
    return 0


def cmd_diff(a: str, b: str) -> int:
    from .diff import structural_diff, text_report
    ta = dispatch.read(a).segments
    tb = dispatch.read(b).segments
    diffs = structural_diff(ta, tb)
    print(text_report(diffs))
    return 0 if not diffs else 1


def cmd_validate(path: str) -> int:
    issues = validate(path)
    if not issues:
        print("ok")
        return 0
    print("invalid:")
    for i in issues:
        print("  - {}".format(i))
    return 1


def cmd_wrap(path: str, max_chars: int = 42, max_lines: int = 2) -> int:
    from .text_utils import wrap_dialogue
    t = dispatch.read(path)
    for seg in t.segments:
        if not seg.text:
            continue
        lines = wrap_dialogue(seg.text, max_chars=max_chars, max_lines=max_lines)
        seg.text = "\n".join(lines)
    dispatch.write(t, path)
    print("re-wrapped {} cues in place".format(len(t.segments)))
    return 0


def cmd_shift(path: str, seconds: float) -> int:
    t = dispatch.read(path)
    for seg in t.segments:
        seg.start = max(0.0, seg.start + seconds)
        seg.end = max(0.0, seg.end + seconds)
    dispatch.write(t, path)
    print("shifted {} cues by {:+.3f}s".format(len(t.segments), seconds))
    return 0


def main(argv: List[str]) -> int:
    if not argv:
        print("usage: subsync_extra.py <convert|info|diff|validate|wrap|shift> ARGS...")
        return 2
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "convert" and len(rest) == 2:
        return cmd_convert(rest[0], rest[1])
    if cmd == "info" and len(rest) == 1:
        return cmd_info(rest[0])
    if cmd == "diff" and len(rest) == 2:
        return cmd_diff(rest[0], rest[1])
    if cmd == "validate" and len(rest) == 1:
        return cmd_validate(rest[0])
    if cmd == "wrap" and len(rest) >= 1:
        max_chars = 42
        max_lines = 2
        i = 1
        while i < len(rest):
            if rest[i] == "--max" and i + 1 < len(rest):
                max_chars = int(rest[i + 1]); i += 2
            elif rest[i] == "--lines" and i + 1 < len(rest):
                max_lines = int(rest[i + 1]); i += 2
            else:
                i += 1
        return cmd_wrap(rest[0], max_chars, max_lines)
    if cmd == "shift" and len(rest) == 2:
        return cmd_shift(rest[0], float(rest[1]))
    print("unknown subcommand or wrong args: {}".format(cmd))
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
