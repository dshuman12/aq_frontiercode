"""High-level cue-retiming helpers built on top of timecode primitives."""

from __future__ import annotations

from typing import List, Optional, Tuple

from .types import Transcript, Segment
from .timecode import quantize_to_frame, RATE_PAL


def shift_all(t: Transcript, seconds: float) -> Transcript:
    """Bulk-shift every cue by `seconds`. Negative values shift earlier."""
    for s in t.segments:
        s.start = max(0.0, s.start + seconds)
        s.end = max(0.0, s.end + seconds)
    return t


def stretch_all(t: Transcript, factor: float) -> Transcript:
    """Linearly scale every timing by `factor`. > 1 makes the show
    longer (slower). Used for NTSC <-> PAL pull-up / pull-down."""
    if factor <= 0:
        raise ValueError("factor must be positive")
    for s in t.segments:
        s.start *= factor
        s.end *= factor
    if t.duration:
        t.duration *= factor
    return t


def clamp_to_range(t: Transcript,
                   min_start: float = 0.0,
                   max_end: Optional[float] = None) -> Transcript:
    """Drop or trim cues that fall outside [min_start, max_end]."""
    out: List[Segment] = []
    for s in t.segments:
        if max_end is not None and s.start >= max_end:
            continue
        if s.end <= min_start:
            continue
        s.start = max(min_start, s.start)
        if max_end is not None:
            s.end = min(max_end, s.end)
        if s.end > s.start:
            out.append(s)
    t.segments = out
    return t


def two_point_resync(t: Transcript,
                     anchor_a: Tuple[float, float],
                     anchor_b: Tuple[float, float]) -> Transcript:
    """Linear stretch given two before/after anchor pairs.

    anchor_a = (cue_time_in_input, target_time_in_output) for an early
    reference, anchor_b = same for a late reference. Useful when the
    transcript is misaligned at both ends, e.g. trimmed bumpers."""
    a_in, a_out = anchor_a
    b_in, b_out = anchor_b
    if abs(b_in - a_in) < 1e-9:
        raise ValueError("anchor_a and anchor_b must be distinct in time")
    factor = (b_out - a_out) / (b_in - a_in)
    offset = a_out - a_in * factor
    for s in t.segments:
        s.start = max(0.0, s.start * factor + offset)
        s.end = max(0.0, s.end * factor + offset)
    return t


def quantize_all(t: Transcript, frame_rate: float = RATE_PAL) -> Transcript:
    for s in t.segments:
        s.start = quantize_to_frame(s.start, frame_rate)
        s.end = quantize_to_frame(s.end, frame_rate)
    return t


def gap_at(t: Transcript, time_seconds: float) -> Optional[Tuple[float, float]]:
    """Return (gap_start, gap_end) if `time_seconds` falls in a gap between cues."""
    for a, b in zip(t.segments, t.segments[1:]):
        if a.end <= time_seconds <= b.start:
            return (a.end, b.start)
    return None


def cue_at(t: Transcript, time_seconds: float) -> Optional[Segment]:
    """Return the active cue at `time_seconds`, or None."""
    for s in t.segments:
        if s.start <= time_seconds <= s.end:
            return s
    return None


def adjacent_pairs(t: Transcript) -> List[Tuple[Segment, Segment]]:
    """Convenience for callers that want sliding window over cue pairs."""
    return list(zip(t.segments, t.segments[1:]))
