"""Subtitle normalisation passes.

These are the cleanups you want to do before delivering subtitles to
spec-conscious platforms (Netflix, BBC, etc.). Each pass takes a
Transcript and returns a Transcript with the requested rule applied.
"""

from __future__ import annotations

import re
from typing import List

from .types import Transcript, Segment
from .text_utils import (
    wrap_dialogue, collapse_whitespace, normalise_punctuation, strip_html,
    DEFAULT_MAX_CHARS_PER_LINE, DEFAULT_MAX_LINES,
)
from .timecode import quantize_segment


def collapse_whitespace_pass(t: Transcript) -> Transcript:
    for s in t.segments:
        s.text = collapse_whitespace(s.text or "")
    return t


def strip_html_pass(t: Transcript) -> Transcript:
    for s in t.segments:
        s.text = strip_html(s.text or "")
    return t


def normalise_punctuation_pass(t: Transcript) -> Transcript:
    for s in t.segments:
        s.text = normalise_punctuation(s.text or "")
    return t


def rewrap_pass(t: Transcript,
                max_chars: int = DEFAULT_MAX_CHARS_PER_LINE,
                max_lines: int = DEFAULT_MAX_LINES) -> Transcript:
    for s in t.segments:
        if not s.text:
            continue
        lines = wrap_dialogue(s.text, max_chars=max_chars, max_lines=max_lines)
        s.text = "\n".join(lines)
    return t


def quantize_to_frames_pass(t: Transcript, frame_rate: float = 25.0) -> Transcript:
    """Snap every cue to whole frames at the supplied rate."""
    for s in t.segments:
        s.start, s.end = quantize_segment(s.start, s.end, frame_rate)
    return t


def enforce_minimum_gap_pass(t: Transcript, min_gap: float = 0.083) -> Transcript:
    """Push later cues forward to keep at least min_gap seconds between
    cue boundaries. Default 2 frames at 24fps."""
    for i in range(1, len(t.segments)):
        prev = t.segments[i - 1]
        curr = t.segments[i]
        if curr.start - prev.end < min_gap:
            curr.start = prev.end + min_gap
            if curr.end < curr.start:
                curr.end = curr.start + min_gap
    return t


def merge_short_adjacent_pass(t: Transcript,
                              max_gap: float = 0.2,
                              max_combined_chars: int = 70) -> Transcript:
    """Merge consecutive cues separated by a tiny gap and below a char
    budget. Helps with one-word cues that arose from transcribe noise."""
    if not t.segments:
        return t
    out: List[Segment] = [t.segments[0]]
    for curr in t.segments[1:]:
        prev = out[-1]
        gap = curr.start - prev.end
        combined = len((prev.text or "") + " " + (curr.text or ""))
        if gap <= max_gap and combined <= max_combined_chars:
            prev.end = curr.end
            prev.text = ((prev.text or "") + " " + (curr.text or "")).strip()
        else:
            out.append(curr)
    t.segments = out
    return t


def drop_empty_pass(t: Transcript) -> Transcript:
    t.segments = [s for s in t.segments if (s.text or "").strip()]
    return t


def round_timings_pass(t: Transcript, decimals: int = 3) -> Transcript:
    for s in t.segments:
        s.start = round(s.start, decimals)
        s.end = round(s.end, decimals)
    return t


def normalise_speaker_labels_pass(t: Transcript) -> Transcript:
    from .text_utils import normalise_speaker_label
    for s in t.segments:
        if s.speaker:
            s.speaker = normalise_speaker_label(s.speaker)
    return t


# -----------------------------------------------------------------------------
# A common, sane pipeline of passes
# -----------------------------------------------------------------------------

def standard_cleanup(t: Transcript,
                     max_chars: int = DEFAULT_MAX_CHARS_PER_LINE,
                     max_lines: int = DEFAULT_MAX_LINES,
                     frame_rate: float = 25.0) -> Transcript:
    """Run the cleanups everybody wants. Operates in place."""
    drop_empty_pass(t)
    strip_html_pass(t)
    normalise_punctuation_pass(t)
    collapse_whitespace_pass(t)
    rewrap_pass(t, max_chars=max_chars, max_lines=max_lines)
    quantize_to_frames_pass(t, frame_rate=frame_rate)
    enforce_minimum_gap_pass(t)
    round_timings_pass(t)
    normalise_speaker_labels_pass(t)
    return t
