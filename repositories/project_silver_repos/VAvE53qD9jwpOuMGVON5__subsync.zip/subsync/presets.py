"""Per-platform style and constraint presets.

These bundle wrap, reading-speed, and timing rules into one named profile.
They're importable from CLI as `--preset netflix-adult`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from .reading_speed import (
    ReadingSpeedRules, NETFLIX_ADULT, NETFLIX_KIDS, BBC, APPLE,
)
from .text_utils import DEFAULT_MAX_CHARS_PER_LINE, DEFAULT_MAX_LINES


@dataclass
class StylePreset:
    name: str
    description: str
    max_chars_per_line: int = DEFAULT_MAX_CHARS_PER_LINE
    max_lines: int = DEFAULT_MAX_LINES
    reading_speed: ReadingSpeedRules = field(default_factory=ReadingSpeedRules)
    frame_rate: float = 25.0
    drop_frame: bool = False
    line_position: int = 90  # vertical %, 90 = near bottom
    text_align: str = "center"
    notes: str = ""


PRESETS: Dict[str, StylePreset] = {
    "default": StylePreset(
        name="default",
        description="Balanced defaults - 42 chars / 2 lines / 17 cps.",
        reading_speed=ReadingSpeedRules(),
    ),
    "netflix-adult": StylePreset(
        name="netflix-adult",
        description="Netflix Timed Text Style Guide, English adult.",
        max_chars_per_line=42,
        max_lines=2,
        reading_speed=NETFLIX_ADULT,
        notes="https://partnerhelp.netflixstudios.com/hc/en-us/articles/215758617",
    ),
    "netflix-kids": StylePreset(
        name="netflix-kids",
        description="Netflix Timed Text Style Guide, English kids/family.",
        max_chars_per_line=32,
        max_lines=2,
        reading_speed=NETFLIX_KIDS,
        notes="Lower cps because audience is younger.",
    ),
    "bbc-online": StylePreset(
        name="bbc-online",
        description="BBC Subtitle Guidelines (online, on-demand).",
        max_chars_per_line=37,
        max_lines=2,
        reading_speed=BBC,
        frame_rate=25.0,
        notes="https://www.bbc.co.uk/accessibility/forproducts/guides/subtitles/",
    ),
    "bbc-broadcast": StylePreset(
        name="bbc-broadcast",
        description="BBC Subtitle Guidelines (live broadcast).",
        max_chars_per_line=37,
        max_lines=3,
        reading_speed=ReadingSpeedRules(target_cps=14.0, max_cps=17.0),
        frame_rate=25.0,
    ),
    "apple-itunes": StylePreset(
        name="apple-itunes",
        description="Apple iTunes Connect subtitle delivery.",
        max_chars_per_line=42,
        max_lines=2,
        reading_speed=APPLE,
        frame_rate=23.976,
        drop_frame=False,
    ),
    "us-broadcast-30df": StylePreset(
        name="us-broadcast-30df",
        description="US broadcast 29.97 drop-frame, line-21.",
        max_chars_per_line=32,
        max_lines=4,
        reading_speed=ReadingSpeedRules(target_cps=15.0, max_cps=18.0),
        frame_rate=29.97,
        drop_frame=True,
    ),
    "youtube": StylePreset(
        name="youtube",
        description="YouTube creator-uploaded captions, defaults.",
        max_chars_per_line=42,
        max_lines=2,
        reading_speed=ReadingSpeedRules(target_cps=20.0, max_cps=25.0),
    ),
}


def get(name: str) -> StylePreset:
    if name not in PRESETS:
        raise KeyError("unknown preset: {}. Available: {}".format(
            name, ", ".join(sorted(PRESETS))))
    return PRESETS[name]


def names() -> list:
    return sorted(PRESETS.keys())
