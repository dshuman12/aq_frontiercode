"""Advanced SubStation Alpha (.ass / .ssa) reader / writer.

ASS is the format anime fansubs use, but it's also the most expressive
plaintext subtitle format - per-cue styling, per-character positioning,
karaoke timing tags. We use a minimal subset:

  - One [V4+ Styles] entry called "Default" with sane defaults.
  - One [Events] block with Dialogue lines per cue.
  - The Style / MarginL / MarginR / MarginV columns are zeros.

That's enough for downstream tools to consume; users who want to hand-edit
in Aegisub can do so without losing structure.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional

from ..types import Transcript, Segment


HEADER_TEMPLATE = """[Script Info]
Title: subsync export
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
Collisions: Normal
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,48,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,1,2,40,40,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def write(transcript: Transcript, output_path) -> None:
    Path(output_path).write_text(write_string(transcript), encoding="utf-8")


def write_string(transcript: Transcript) -> str:
    parts = [HEADER_TEMPLATE]
    for seg in transcript.segments:
        parts.append(_dialogue_line(seg))
    return "\n".join(parts) + "\n"


def _dialogue_line(seg: Segment) -> str:
    text = (seg.text or "").replace("\n", "\\N")
    name = seg.speaker or ""
    return "Dialogue: 0,{},{},Default,{},0,0,0,,{}".format(
        _ass_time(seg.start), _ass_time(seg.end), name, text)


def _ass_time(seconds: float) -> str:
    """ASS uses H:MM:SS.cc (centiseconds), single-digit hour."""
    if seconds < 0:
        seconds = 0.0
    cs_total = int(round(seconds * 100.0))
    hh = cs_total // 360_000
    rem = cs_total % 360_000
    mm = rem // 6000
    rem %= 6000
    ss = rem // 100
    cs = rem % 100
    return "{}:{:02d}:{:02d}.{:02d}".format(hh, mm, ss, cs)


# -----------------------------------------------------------------------------
# Reader
# -----------------------------------------------------------------------------

DIALOGUE_RE = re.compile(r"^Dialogue:\s*(.*)", flags=re.IGNORECASE)


def read(path) -> Transcript:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    segments = parse(text)
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)


def parse(text: str) -> List[Segment]:
    body = text.replace("\r\n", "\n")
    out: List[Segment] = []
    fmt: Optional[List[str]] = None
    for line in body.split("\n"):
        if line.lower().startswith("format:") and "[events]" in body.lower().split(line.lower())[0][-200:]:
            fmt = [c.strip().lower() for c in line.split(":", 1)[1].split(",")]
            continue
        m = DIALOGUE_RE.match(line)
        if not m:
            continue
        seg = _parse_dialogue(m.group(1).strip(), fmt)
        if seg is not None:
            out.append(seg)
    return out


def _parse_dialogue(payload: str, fmt: Optional[List[str]]) -> Optional[Segment]:
    if not fmt:
        # Assume the standard order Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
        cols = payload.split(",", 9)
    else:
        cols = payload.split(",", len(fmt) - 1)
    if len(cols) < 4:
        return None
    if fmt:
        idx = {name: i for i, name in enumerate(fmt)}
        try:
            start = _ass_to_seconds(cols[idx["start"]])
            end = _ass_to_seconds(cols[idx["end"]])
            text = cols[idx["text"]] if "text" in idx else cols[-1]
            speaker = cols[idx["name"]] if "name" in idx else ""
        except (KeyError, ValueError):
            return None
    else:
        try:
            start = _ass_to_seconds(cols[1])
            end = _ass_to_seconds(cols[2])
            speaker = cols[4]
            text = cols[9] if len(cols) >= 10 else ""
        except (IndexError, ValueError):
            return None
    text = text.replace("\\N", "\n").replace("\\n", "\n").strip()
    return Segment(start=start, end=end, text=text, speaker=speaker.strip() or None)


def _ass_to_seconds(timecode: str) -> float:
    parts = timecode.strip().split(":")
    if len(parts) != 3:
        raise ValueError("bad ASS timecode: {!r}".format(timecode))
    hh = int(parts[0])
    mm = int(parts[1])
    ss = float(parts[2])
    return hh * 3600 + mm * 60 + ss


def detect(text: str) -> bool:
    head = text[:512].lower()
    return "[script info]" in head or "[v4+ styles]" in head
