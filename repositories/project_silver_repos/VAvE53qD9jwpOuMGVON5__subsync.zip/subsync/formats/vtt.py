"""WebVTT reader / writer.

WebVTT differs from SRT in three ways that matter for us:
  - File starts with the literal header "WEBVTT".
  - Time separator is '.' not ',' for the millisecond part.
  - Cues can carry voice spans like <v Speaker> ... </v>.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional

from ..types import Transcript, Segment
from ..timecode import seconds_to_vtt, srt_to_seconds


HEADER_LINE = "WEBVTT"
TIMING_RE = re.compile(
    r"(\d+:\d{2}:\d{2}\.\d{3}|\d{2}:\d{2}\.\d{3})\s*-->\s*(\d+:\d{2}:\d{2}\.\d{3}|\d{2}:\d{2}\.\d{3})(.*)"
)
VOICE_RE = re.compile(r"<v(?:\s+([^>]+))?>(.*?)(?:</v>|$)", flags=re.DOTALL)


def write(transcript: Transcript, output_path,
          include_speakers: bool = True) -> None:
    p = Path(output_path)
    p.write_text(write_string(transcript, include_speakers), encoding="utf-8")


def write_string(transcript: Transcript, include_speakers: bool = True) -> str:
    out: List[str] = [HEADER_LINE, ""]
    for i, seg in enumerate(transcript.segments, start=1):
        out.append(str(i))
        out.append("{} --> {}".format(seconds_to_vtt(seg.start),
                                       seconds_to_vtt(seg.end)))
        text = (seg.text or "").strip()
        if include_speakers and seg.speaker:
            text = "<v {}>{}".format(seg.speaker, text)
        out.append(text or " ")
        out.append("")
    return "\n".join(out)


def read(path) -> Transcript:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    segments = parse_blocks(text)
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)


def parse_blocks(text: str) -> List[Segment]:
    body = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if body.startswith(HEADER_LINE):
        body = body[len(HEADER_LINE):].lstrip("\n")
    blocks = re.split(r"\n\s*\n", body)
    out: List[Segment] = []
    for block in blocks:
        seg = _parse_block(block)
        if seg is not None:
            out.append(seg)
    return out


def _parse_block(block: str) -> Optional[Segment]:
    if not block.strip():
        return None
    if block.lstrip().startswith("NOTE"):
        return None
    lines = block.strip().split("\n")
    # optional cue identifier
    i = 0
    if "-->" not in lines[0]:
        i = 1
    if i >= len(lines):
        return None
    m = TIMING_RE.search(lines[i])
    if m is None:
        return None
    start = _vtt_to_seconds(m.group(1))
    end = _vtt_to_seconds(m.group(2))
    text = "\n".join(lines[i + 1:]).strip()
    speaker = None
    vm = VOICE_RE.search(text)
    if vm:
        speaker = (vm.group(1) or "").strip() or None
        text = vm.group(2).strip()
    return Segment(start=start, end=end, text=text, speaker=speaker)


def _vtt_to_seconds(timecode: str) -> float:
    cleaned = timecode.replace(",", ".")
    parts = cleaned.split(":")
    if len(parts) == 3:
        return srt_to_seconds(cleaned.replace(".", ","))
    if len(parts) == 2:
        # MM:SS.mmm
        mm, ss_ms = parts
        return int(mm) * 60 + float(ss_ms)
    raise ValueError("invalid VTT timecode: {!r}".format(timecode))


def detect(text: str) -> bool:
    return text.lstrip().startswith(HEADER_LINE)


# -----------------------------------------------------------------------------
# Convenience: convert from/to SRT (round-trip helper used by export.py)
# -----------------------------------------------------------------------------

def from_srt(srt_text: str) -> Transcript:
    from . import srt as srt_mod
    segments = srt_mod.parse_blocks(srt_text)
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)


def to_srt(transcript: Transcript) -> str:
    from . import srt as srt_mod
    return srt_mod.write_string(transcript)
