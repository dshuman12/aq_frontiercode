"""TTML / IMSC1.1 reader / writer.

TTML is the modern broadcast standard - Netflix, BBC, and Apple all accept
some flavour of it. IMSC1.1 is the constrained subset we target.

We emit a single <div xml:lang="..."> with one <p begin=... end=...>tag per
cue. Inline styling is left to the destination platform.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional
from xml.sax.saxutils import escape as xml_escape

from ..types import Transcript, Segment
from ..timecode import seconds_to_srt


XML_HEADER = '<?xml version="1.0" encoding="UTF-8"?>'
TT_NS = "http://www.w3.org/ns/ttml"
TT_PARAM_NS = "http://www.w3.org/ns/ttml#parameter"
TT_STYLE_NS = "http://www.w3.org/ns/ttml#styling"


def write(transcript: Transcript, output_path,
          frame_rate: float = 25.0) -> None:
    Path(output_path).write_text(write_string(transcript, frame_rate),
                                  encoding="utf-8")


def write_string(transcript: Transcript, frame_rate: float = 25.0) -> str:
    lang = transcript.language or "en"
    parts: List[str] = [XML_HEADER]
    parts.append('<tt xmlns="{}" xmlns:tts="{}" xmlns:ttp="{}" '
                 'xml:lang="{}" ttp:frameRate="{}" ttp:tickRate="10000000">'
                 .format(TT_NS, TT_STYLE_NS, TT_PARAM_NS, lang, int(frame_rate)))
    parts.append("<head><styling>")
    parts.append('<style xml:id="default" tts:fontFamily="Arial" tts:fontSize="100%" '
                 'tts:textAlign="center" tts:color="#FFFFFF" tts:backgroundColor="transparent"/>')
    parts.append("</styling></head>")
    parts.append('<body><div xml:lang="{}">'.format(lang))
    for seg in transcript.segments:
        text = xml_escape((seg.text or "").replace("\n", " "))
        parts.append('<p begin="{}" end="{}" style="default">{}</p>'.format(
            _ttml_time(seg.start), _ttml_time(seg.end), text))
    parts.append("</div></body></tt>")
    return "\n".join(parts)


def _ttml_time(seconds: float) -> str:
    """TTML default 'media time' form: HH:MM:SS.mmm."""
    return seconds_to_srt(seconds).replace(",", ".")


# -----------------------------------------------------------------------------
# Reader
# -----------------------------------------------------------------------------

P_RE = re.compile(
    r'<p\b([^>]*?)>(.*?)</p>', flags=re.IGNORECASE | re.DOTALL
)
ATTR_RE = re.compile(r'(\w[\w:.-]*)\s*=\s*"([^"]*)"')


def read(path) -> Transcript:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    segments = parse(text)
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)


def parse(text: str) -> List[Segment]:
    out: List[Segment] = []
    for m in P_RE.finditer(text):
        attrs = dict(ATTR_RE.findall(m.group(1)))
        begin = _ttml_to_seconds(attrs.get("begin", "0"))
        end = _ttml_to_seconds(attrs.get("end", "0"))
        body = re.sub(r"<br\s*/?>", "\n", m.group(2), flags=re.IGNORECASE)
        body = re.sub(r"<[^>]+>", "", body).strip()
        body = body.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")
        out.append(Segment(start=begin, end=end, text=body))
    return out


def _ttml_to_seconds(value: str) -> float:
    s = value.strip()
    if not s:
        return 0.0
    if s.endswith("s"):
        return float(s[:-1])
    if s.endswith("ms"):
        return float(s[:-2]) / 1000.0
    if s.endswith("h"):
        return float(s[:-1]) * 3600.0
    parts = s.split(":")
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    return 0.0


def detect(text: str) -> bool:
    return "<tt" in text[:1024].lower() and "ttml" in text[:1024].lower()
