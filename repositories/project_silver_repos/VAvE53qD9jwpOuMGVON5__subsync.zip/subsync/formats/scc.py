"""Scenarist Closed Caption (.scc) writer.

SCC is the wire-level format for line-21 closed captions in North American
broadcast (CEA-608). Each event is a SMPTE-29.97 drop-frame timecode
followed by hex byte pairs to clock into the caption decoder.

We don't aim for full CEA-608 compliance here - that's a project on its
own. We emit pop-on captions with a clear-and-display sequence per cue,
which is the lowest common denominator most ingest tools accept.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Tuple

from ..types import Transcript, Segment
from ..timecode import seconds_to_smpte, RATE_NTSC_DF


HEADER = "Scenarist_SCC V1.0"

# Common control codes
CC_RESUME_CAPTION = 0x9420
CC_ERASE_DISPLAYED = 0x942C
CC_END_OF_CAPTION = 0x942F
CC_ERASE_NON_DISPLAY = 0x94AE
CC_PREAMBLE_ROW15_WHITE = 0x9470  # row 15, white, no underline


# Odd-parity table for low 7 bits
def _odd_parity(b: int) -> int:
    """Set the high bit so the byte has odd parity."""
    p = b & 0x7F
    parity = 0
    x = p
    while x:
        parity ^= x & 1
        x >>= 1
    if parity == 0:
        return p | 0x80
    return p


# CEA-608 character to byte mapping for printable ASCII subset
def _char_to_byte(ch: str) -> int:
    code = ord(ch)
    if 0x20 <= code <= 0x7F:
        return _odd_parity(code)
    # Fallback - replace with '?'
    return _odd_parity(ord("?"))


def write(transcript: Transcript, output_path) -> None:
    Path(output_path).write_text(write_string(transcript), encoding="utf-8")


def write_string(transcript: Transcript) -> str:
    lines: List[str] = [HEADER, ""]
    for seg in transcript.segments:
        in_tc = seconds_to_smpte(seg.start, RATE_NTSC_DF)
        out_tc = seconds_to_smpte(seg.end, RATE_NTSC_DF)
        # Pop-on caption sequence
        codes = _pop_on_sequence(seg.text or "")
        lines.append("{}\t{}".format(in_tc, _format_codes(codes)))
        # Clear at end-of-cue
        lines.append("{}\t{}".format(out_tc, _format_codes([CC_ERASE_DISPLAYED])))
        lines.append("")
    return "\n".join(lines) + "\n"


def _pop_on_sequence(text: str) -> List[int]:
    """Build a CC code stream that pops the text into the visible plane."""
    codes = [CC_RESUME_CAPTION, CC_ERASE_NON_DISPLAY, CC_PREAMBLE_ROW15_WHITE]
    payload = _text_to_codes(text)
    codes.extend(payload)
    codes.append(CC_END_OF_CAPTION)
    return codes


def _text_to_codes(text: str) -> List[int]:
    """Pack ASCII characters into 16-bit code words (two odd-parity bytes)."""
    payload: List[int] = []
    flat = (text or "").replace("\n", " ")
    cleaned = re.sub(r"\s+", " ", flat).strip()
    for i in range(0, len(cleaned), 2):
        chunk = cleaned[i:i + 2]
        if len(chunk) == 1:
            chunk += " "
        word = (_char_to_byte(chunk[0]) << 8) | _char_to_byte(chunk[1])
        payload.append(word)
    return payload


def _format_codes(codes: List[int]) -> str:
    return " ".join("{:04X}".format(c) for c in codes)


def detect(text: str) -> bool:
    return text.strip().startswith(HEADER)


# -----------------------------------------------------------------------------
# Read - very limited, returns timing only (we don't decode the CC payload)
# -----------------------------------------------------------------------------

TIMING_LINE_RE = re.compile(r"^(\d\d:\d\d:\d\d[;:]\d\d)\t(.*)$")


def read(path) -> Transcript:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    segments: List[Segment] = []
    last_in: float = 0.0
    for line in text.splitlines():
        m = TIMING_LINE_RE.match(line)
        if not m:
            continue
        from ..timecode import smpte_to_seconds
        t = smpte_to_seconds(m.group(1), RATE_NTSC_DF)
        # Heuristic: if the codes contain CC_END_OF_CAPTION (0x942F),
        # treat as an "in" marker. Anything else we treat as "out".
        codes = m.group(2).strip()
        if "942F" in codes.upper():
            last_in = t
        else:
            segments.append(Segment(start=last_in, end=t, text=""))
            last_in = 0.0
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)
