"""SRT (SubRip) reader / writer.

The most boring and most reliable format. One block per cue:

    1
    00:00:00,500 --> 00:00:02,000
    First line.
    Second line.

We accept both ',mmm' and '.mmm' separators and either '\\n' or '\\r\\n'.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

from ..types import Transcript, Segment, Word
from ..timecode import seconds_to_srt, srt_to_seconds


HEADER_RE = re.compile(
    r"(\d+:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d+:\d{2}:\d{2}[,.]\d{1,3})"
)


def write(transcript: Transcript, output_path) -> None:
    """Emit transcript as SRT to output_path. Existing file is overwritten."""
    p = Path(output_path)
    parts: List[str] = []
    for i, seg in enumerate(transcript.segments, start=1):
        parts.append(str(i))
        parts.append("{} --> {}".format(seconds_to_srt(seg.start),
                                         seconds_to_srt(seg.end)))
        text = seg.text.strip() if seg.text else ""
        parts.append(text or " ")
        parts.append("")  # blank line between cues
    p.write_text("\n".join(parts), encoding="utf-8")


def write_string(transcript: Transcript) -> str:
    parts: List[str] = []
    for i, seg in enumerate(transcript.segments, start=1):
        parts.append(str(i))
        parts.append("{} --> {}".format(seconds_to_srt(seg.start),
                                         seconds_to_srt(seg.end)))
        parts.append((seg.text or "").strip() or " ")
        parts.append("")
    return "\n".join(parts)


def read(path) -> Transcript:
    """Parse an SRT file into a Transcript with no audio metadata."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    segments = parse_blocks(text)
    duration = max((s.end for s in segments), default=0.0)
    return Transcript(language="", duration=duration, segments=segments)


def parse_blocks(text: str) -> List[Segment]:
    """Tokenise a raw SRT body into Segment objects."""
    body = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = re.split(r"\n\s*\n", body.strip())
    out: List[Segment] = []
    for block in blocks:
        seg = _parse_block(block)
        if seg is not None:
            out.append(seg)
    return out


def _parse_block(block: str) -> Optional[Segment]:
    if not block.strip():
        return None
    lines = block.strip().split("\n")
    # Optional numeric ID at the top - skip.
    i = 0
    if lines[i].strip().isdigit():
        i += 1
    if i >= len(lines):
        return None
    m = HEADER_RE.search(lines[i])
    if m is None:
        return None
    start = srt_to_seconds(m.group(1))
    end = srt_to_seconds(m.group(2))
    text = "\n".join(lines[i + 1:]).strip()
    return Segment(start=start, end=end, text=text)


def detect(text: str) -> bool:
    """Quick heuristic: does the head of `text` look like SRT?"""
    head = text[:512].lstrip()
    if not head:
        return False
    return bool(HEADER_RE.search(head))


# -----------------------------------------------------------------------------
# Helpers for editorial workflows
# -----------------------------------------------------------------------------

def shift(transcript: Transcript, seconds: float) -> Transcript:
    """Return a copy of transcript with all timings shifted by `seconds`."""
    out = Transcript(language=transcript.language, duration=transcript.duration + seconds)
    for s in transcript.segments:
        ns = Segment(start=max(0.0, s.start + seconds),
                     end=max(0.0, s.end + seconds),
                     text=s.text)
        out.segments.append(ns)
    return out


def split_long_cues(transcript: Transcript, max_seconds: float = 7.0) -> Transcript:
    """Break overlong cues into chunks <= max_seconds. Text is split on
    sentence boundaries when possible, else evenly."""
    out = Transcript(language=transcript.language, duration=transcript.duration)
    for s in transcript.segments:
        dur = s.end - s.start
        if dur <= max_seconds:
            out.segments.append(s)
            continue
        n = int(-(-dur // max_seconds))  # ceil divide
        sentences = re.split(r"(?<=[.!?])\s+", s.text or "")
        sentences = [x for x in sentences if x]
        if len(sentences) >= n:
            chunk = max(1, len(sentences) // n)
            t0 = s.start
            for i in range(0, len(sentences), chunk):
                piece = " ".join(sentences[i:i + chunk])
                t1 = min(s.end, t0 + max_seconds)
                out.segments.append(Segment(start=t0, end=t1, text=piece))
                t0 = t1
        else:
            slice_dur = dur / n
            for k in range(n):
                t0 = s.start + k * slice_dur
                t1 = s.start + (k + 1) * slice_dur
                out.segments.append(Segment(start=t0, end=t1, text=s.text or ""))
    return out
