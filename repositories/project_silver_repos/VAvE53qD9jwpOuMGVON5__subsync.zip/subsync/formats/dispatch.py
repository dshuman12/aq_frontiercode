"""Pick the right reader/writer by extension or content sniff."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from . import srt, vtt, ass, ttml, scc
from ..types import Transcript


_BY_EXT = {
    ".srt": srt,
    ".vtt": vtt,
    ".webvtt": vtt,
    ".ass": ass,
    ".ssa": ass,
    ".ttml": ttml,
    ".dfxp": ttml,
    ".xml": ttml,
    ".scc": scc,
}


def reader_for(path) -> "object":
    """Pick a reader module by file extension or content sniff."""
    p = Path(path)
    ext = p.suffix.lower()
    if ext in _BY_EXT:
        return _BY_EXT[ext]
    # Fallback - sniff the head of the file.
    try:
        head = p.read_text(encoding="utf-8", errors="replace")[:512]
    except OSError:
        return srt
    for mod in (vtt, ttml, ass, scc, srt):
        try:
            if mod.detect(head):
                return mod
        except AttributeError:
            continue
    return srt


def writer_for(path) -> "object":
    """Same as reader_for but for the writer side. Always picks by extension."""
    p = Path(path)
    ext = p.suffix.lower()
    return _BY_EXT.get(ext, srt)


def read(path) -> Transcript:
    return reader_for(path).read(path)


def write(transcript: Transcript, path) -> None:
    return writer_for(path).write(transcript, path)


def supported_extensions() -> list:
    return sorted(_BY_EXT.keys())
