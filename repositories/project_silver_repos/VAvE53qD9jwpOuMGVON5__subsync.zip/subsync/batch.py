"""Batch transcription / re-export.

Walks a directory and runs the pipeline on every supported media file or
existing subtitle file.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Callable, List, Optional


SUPPORTED_MEDIA = (".mp3", ".m4a", ".wav", ".flac", ".ogg",
                   ".mp4", ".mkv", ".mov", ".avi", ".webm")
SUPPORTED_SUBS = (".srt", ".vtt", ".ass", ".ssa", ".ttml", ".dfxp", ".scc")


class BatchResult:
    def __init__(self, src: str, dst: str, ok: bool, elapsed: float, message: str = ""):
        self.src = src
        self.dst = dst
        self.ok = ok
        self.elapsed = elapsed
        self.message = message

    def to_dict(self) -> dict:
        return {"src": self.src, "dst": self.dst, "ok": self.ok,
                "elapsed": round(self.elapsed, 3), "message": self.message}


class BatchRunner:
    def __init__(self, input_dir: str, output_dir: str,
                 patterns: Optional[List[str]] = None,
                 recursive: bool = True,
                 stop_on_error: bool = False,
                 progress_cb: Optional[Callable[[int, int, str], None]] = None):
        self.input_dir = os.path.abspath(input_dir)
        self.output_dir = os.path.abspath(output_dir)
        self.patterns = patterns or list(SUPPORTED_MEDIA + SUPPORTED_SUBS)
        self.recursive = recursive
        self.stop_on_error = stop_on_error
        self.progress_cb = progress_cb
        self._lock = threading.Lock()
        self._cancelled = False
        self.results: List[BatchResult] = []
        self.logger = logging.getLogger("subsync.batch")

    def discover(self) -> List[str]:
        found: List[str] = []
        if self.recursive:
            for dirpath, _dirs, files in os.walk(self.input_dir):
                for n in files:
                    if self._matches(n):
                        found.append(os.path.join(dirpath, n))
        else:
            for n in os.listdir(self.input_dir):
                full = os.path.join(self.input_dir, n)
                if os.path.isfile(full) and self._matches(n):
                    found.append(full)
        found.sort()
        return found

    def _matches(self, name: str) -> bool:
        n = name.lower()
        for p in self.patterns:
            if p.startswith("."):
                if n.endswith(p):
                    return True
        return False

    def output_for(self, src: str, target_ext: str = ".srt") -> str:
        rel = os.path.relpath(src, self.input_dir)
        base, _ = os.path.splitext(rel)
        return os.path.join(self.output_dir, base + target_ext)

    def cancel(self) -> None:
        with self._lock:
            self._cancelled = True

    @property
    def cancelled(self) -> bool:
        with self._lock:
            return self._cancelled

    def run(self,
            convert_fn: Callable[[str, str], bool],
            target_ext: str = ".srt") -> List[BatchResult]:
        self.results = []
        files = self.discover()
        total = len(files)
        if total == 0:
            self.logger.warning("no files in %s", self.input_dir)
            return self.results
        self.logger.info("starting batch: %d file(s)", total)
        for i, src in enumerate(files):
            if self.cancelled:
                self.logger.info("cancelled at %d/%d", i, total)
                break
            dst = self.output_for(src, target_ext)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            t0 = time.time()
            try:
                ok = convert_fn(src, dst)
                self.results.append(BatchResult(src, dst, ok, time.time() - t0,
                                                "ok" if ok else "convert returned False"))
            except Exception as exc:
                self.results.append(BatchResult(src, dst, False, time.time() - t0, str(exc)))
                self.logger.exception("error on %s", src)
                if self.stop_on_error:
                    break
            if self.progress_cb is not None:
                try:
                    self.progress_cb(i + 1, total, src)
                except Exception:
                    pass
        return self.results

    @property
    def success_count(self) -> int:
        return sum(1 for r in self.results if r.ok)

    @property
    def failure_count(self) -> int:
        return sum(1 for r in self.results if not r.ok)

    def write_report(self, path: str) -> None:
        body = {
            "input_dir": self.input_dir,
            "output_dir": self.output_dir,
            "patterns": self.patterns,
            "results": [r.to_dict() for r in self.results],
            "summary": {"total": len(self.results),
                        "ok": self.success_count,
                        "failed": self.failure_count},
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(body, f, indent=2)

    def write_csv(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            f.write("status,elapsed_s,src,dst,message\n")
            for r in self.results:
                msg = r.message.replace(",", ";").replace("\n", " ")
                f.write("{},{:.3f},{},{},{}\n".format(
                    "ok" if r.ok else "fail", r.elapsed, r.src, r.dst, msg))
