"""
Subtitle file exporters: SRT, WebVTT, JSON.

Speakers and non-speech events can be embedded:
  * speaker_prefix=True       prefixes spoken cues with "SPEAKER_01: "
  * with_events=True          interleaves "[Music]" / "[Applause]" cues at the
                              right timecodes
  * lang=None / "en" / ...    pick which translation track to write (or the
                              original transcript when None)
"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Optional, Iterable

from .types import Transcript, Segment, Event


# ---------- timestamp helpers ----------

def fmt_srt(t: float) -> str:
    if t < 0: t = 0.0
    h = int(t // 3600); m = int((t % 3600) // 60); s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000: s += 1; ms = 0
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def fmt_vtt(t: float) -> str:
    return fmt_srt(t).replace(",", ".")


# ---------- text composition ----------

def _cue_text(seg: Segment, *, speaker_prefix: bool, lang: Optional[str]) -> str:
    body = seg.translations.get(lang, seg.text) if lang else seg.text
    if speaker_prefix and seg.speaker:
        return f"{seg.speaker}: {body}"
    return body


def _event_text(ev: Event) -> str:
    return f"[{ev.label}]"


def _interleave(segments: list[Segment], events: list[Event]) -> list[tuple]:
    """Yield (start, end, kind, payload) sorted by time. kind in {'seg','event'}."""
    items: list[tuple] = []
    for s in segments:
        items.append((s.start, s.end, "seg", s))
    for e in events:
        items.append((e.start, e.end, "event", e))
    items.sort(key=lambda x: (x[0], 0 if x[2] == "event" else 1))
    return items


# ---------- writers ----------

def write_srt(t: Transcript, path: Path, *,
              speaker_prefix: bool = False,
              with_events: bool = True,
              lang: Optional[str] = None) -> Path:
    items = _interleave(t.segments, t.events if with_events else [])
    out: list[str] = []
    idx = 1
    for start, end, kind, payload in items:
        if kind == "seg":
            text = _cue_text(payload, speaker_prefix=speaker_prefix, lang=lang)
        else:
            text = _event_text(payload)
        if not text.strip(): continue
        out.append(f"{idx}\n{fmt_srt(start)} --> {fmt_srt(end)}\n{text}\n")
        idx += 1
    path.write_text("\n".join(out), encoding="utf-8")
    return path


def write_vtt(t: Transcript, path: Path, *,
              speaker_prefix: bool = False,
              with_events: bool = True,
              lang: Optional[str] = None) -> Path:
    items = _interleave(t.segments, t.events if with_events else [])
    out: list[str] = ["WEBVTT", ""]
    for start, end, kind, payload in items:
        if kind == "seg":
            text = _cue_text(payload, speaker_prefix=speaker_prefix, lang=lang)
        else:
            text = _event_text(payload)
        if not text.strip(): continue
        out.append(f"{fmt_vtt(start)} --> {fmt_vtt(end)}\n{text}\n")
    path.write_text("\n".join(out), encoding="utf-8")
    return path


def write_json(t: Transcript, path: Path) -> Path:
    path.write_text(json.dumps(t.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def write_translations(t: Transcript, out_dir: Path, stem: str,
                       *, speaker_prefix: bool = False,
                       with_events: bool = True) -> list[Path]:
    """Write a separate <stem>.<lang>.srt + .vtt for every translation present."""
    paths: list[Path] = []
    langs = sorted({lang for s in t.segments for lang in s.translations})
    for lang in langs:
        srt = out_dir / f"{stem}.{lang}.srt"
        vtt = out_dir / f"{stem}.{lang}.vtt"
        write_srt(t, srt, speaker_prefix=speaker_prefix, with_events=with_events, lang=lang)
        write_vtt(t, vtt, speaker_prefix=speaker_prefix, with_events=with_events, lang=lang)
        paths.extend([srt, vtt])
    return paths
