"""Lightweight audio helpers.

Most of the heavy lifting (resample, transcribe, VAD) is done by the
underlying libraries (ffmpeg, faster-whisper, pyannote). What's here is
the bookkeeping around them: sample-rate normalisation hints, gap
detection, simple energy-based silence detection used as a fallback
when the model VAD isn't available.
"""

from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from typing import Iterable, List, Optional, Tuple


# Common sample rates we care about
SR_TELEPHONY = 8000
SR_AUDIOBOOK = 16000
SR_BROADCAST = 48000
SR_HIRES = 96000
WHISPER_SR = 16000   # what faster-whisper resamples to internally


@dataclass
class SilenceSpan:
    start: float
    end: float
    rms: float

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


def detect_silence_from_rms(samples: Iterable[float],
                            sr: int = WHISPER_SR,
                            window_ms: int = 50,
                            threshold_dbfs: float = -45.0) -> List[SilenceSpan]:
    """Greedy energy-based silence detection.

    Walks through `samples` in fixed windows. Any window whose RMS is
    below `threshold_dbfs` joins the current silence span; anything above
    closes it.

    Returns a list of SilenceSpan in seconds.
    """
    window_n = max(1, int(sr * window_ms / 1000))
    threshold_lin = 10 ** (threshold_dbfs / 20.0)
    out: List[SilenceSpan] = []
    cur_start: Optional[float] = None
    cur_rms_sum = 0.0
    cur_rms_n = 0

    buf: List[float] = []
    t = 0.0
    for s in samples:
        buf.append(s)
        if len(buf) < window_n:
            continue
        sq = sum(v * v for v in buf) / len(buf)
        rms = math.sqrt(sq)
        if rms <= threshold_lin:
            if cur_start is None:
                cur_start = t
                cur_rms_sum = 0.0
                cur_rms_n = 0
            cur_rms_sum += rms
            cur_rms_n += 1
        else:
            if cur_start is not None:
                avg = cur_rms_sum / max(1, cur_rms_n)
                out.append(SilenceSpan(cur_start, t, avg))
                cur_start = None
        t += len(buf) / sr
        buf = []
    if cur_start is not None:
        avg = cur_rms_sum / max(1, cur_rms_n)
        out.append(SilenceSpan(cur_start, t, avg))
    return out


def gaps_between_segments(segments,
                          min_gap: float = 0.25) -> List[Tuple[float, float]]:
    """Return (start, end) gaps between transcript segments where
    end - start >= min_gap. Inputs must be sorted by .start."""
    out: List[Tuple[float, float]] = []
    for a, b in zip(segments, segments[1:]):
        gap = b.start - a.end
        if gap >= min_gap:
            out.append((a.end, b.start))
    return out


def coverage_ratio(segments, total_duration: float) -> float:
    """Fraction of the timeline covered by speech segments. Useful for
    quality dashboards: 0.6 is normal, < 0.3 suggests transcribe missed
    a chunk; > 0.95 may mean cues are running together."""
    if total_duration <= 0:
        return 0.0
    covered = sum(max(0.0, s.end - s.start) for s in segments)
    return min(1.0, covered / total_duration)


def overlap_count(segments) -> int:
    """How many adjacent pairs overlap. Should be zero on clean output."""
    n = 0
    for a, b in zip(segments, segments[1:]):
        if b.start < a.end:
            n += 1
    return n


# -----------------------------------------------------------------------------
# Wave header inspection - parse a 44-byte RIFF/WAVE header without scipy.
# -----------------------------------------------------------------------------

def parse_wav_header(blob: bytes) -> Optional[dict]:
    """Return {sr, channels, bit_depth, frames} or None on bad header."""
    if len(blob) < 44 or blob[:4] != b"RIFF" or blob[8:12] != b"WAVE":
        return None
    # fmt chunk
    if blob[12:16] != b"fmt ":
        return None
    fmt_chunk_size = struct.unpack("<I", blob[16:20])[0]
    audio_format = struct.unpack("<H", blob[20:22])[0]
    channels = struct.unpack("<H", blob[22:24])[0]
    sr = struct.unpack("<I", blob[24:28])[0]
    bit_depth = struct.unpack("<H", blob[34:36])[0]
    # data chunk
    data_idx = 36
    if blob[data_idx:data_idx + 4] != b"data":
        # Some WAVs have additional chunks before 'data'; scan for it.
        found = blob.find(b"data", 36)
        if found == -1:
            return None
        data_idx = found
    data_size = struct.unpack("<I", blob[data_idx + 4:data_idx + 8])[0]
    bytes_per_sample = max(1, bit_depth // 8) * max(1, channels)
    frames = data_size // bytes_per_sample
    return {
        "sr": sr, "channels": channels, "bit_depth": bit_depth,
        "frames": frames, "format_code": audio_format,
        "duration_seconds": frames / sr if sr > 0 else 0.0,
    }


def best_resample_target(input_sr: int) -> int:
    """Recommend a target sample rate for a given input.

    The pipeline downstream resamples to 16 kHz for whisper. For passthrough
    storage / playback we keep whatever's closest to the original.
    """
    if input_sr <= SR_TELEPHONY:
        return SR_TELEPHONY
    if input_sr <= SR_AUDIOBOOK:
        return SR_AUDIOBOOK
    if input_sr <= SR_BROADCAST:
        return SR_BROADCAST
    return SR_HIRES
