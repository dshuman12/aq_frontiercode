"""Smoke-check validators for the various subtitle outputs.

Used by tests as a sanity gate, by the CLI to surface 'output looks
broken' messages without re-opening the file in the destination editor.
"""

from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List


# SRT --------------------------------------------------------------------

SRT_TIMING_RE = re.compile(
    r"\d+:\d{2}:\d{2}[,.]\d{1,3}\s*-->\s*\d+:\d{2}:\d{2}[,.]\d{1,3}"
)


def validate_srt(path: str) -> List[str]:
    issues: List[str] = []
    if not os.path.exists(path):
        return ["file does not exist"]
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    if not text.strip():
        return ["file is empty"]
    if not SRT_TIMING_RE.search(text):
        issues.append("no SRT timing line found")
    blocks = re.split(r"\n\s*\n", text.strip())
    for i, block in enumerate(blocks, start=1):
        if not SRT_TIMING_RE.search(block):
            issues.append("block {} has no timing line".format(i))
            if len(issues) > 10:
                issues.append("(stopping after 10 issues)")
                break
    return issues


# VTT --------------------------------------------------------------------

def validate_vtt(path: str) -> List[str]:
    issues: List[str] = []
    if not os.path.exists(path):
        return ["file does not exist"]
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    if not text.lstrip().startswith("WEBVTT"):
        issues.append("missing WEBVTT header on first line")
    if "-->" not in text:
        issues.append("no timing arrows found")
    return issues


# ASS --------------------------------------------------------------------

def validate_ass(path: str) -> List[str]:
    issues: List[str] = []
    if not os.path.exists(path):
        return ["file does not exist"]
    text = Path(path).read_text(encoding="utf-8", errors="replace").lower()
    if "[script info]" not in text:
        issues.append("missing [Script Info] section")
    if "[v4+ styles]" not in text and "[v4 styles]" not in text:
        issues.append("missing [V4+ Styles] section")
    if "[events]" not in text:
        issues.append("missing [Events] section")
    if "dialogue:" not in text:
        issues.append("no Dialogue lines found")
    return issues


# TTML -------------------------------------------------------------------

def validate_ttml(path: str) -> List[str]:
    issues: List[str] = []
    if not os.path.exists(path):
        return ["file does not exist"]
    try:
        tree = ET.parse(path)
    except ET.ParseError as exc:
        return ["xml parse error: {}".format(exc)]
    root = tree.getroot()
    if not root.tag.endswith("}tt") and root.tag != "tt":
        issues.append("root element is not <tt>")
    body_count = 0
    for elem in root.iter():
        tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if tag == "body":
            body_count += 1
    if body_count == 0:
        issues.append("no <body> element")
    return issues


# SCC --------------------------------------------------------------------

def validate_scc(path: str) -> List[str]:
    issues: List[str] = []
    if not os.path.exists(path):
        return ["file does not exist"]
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    if not text.strip().startswith("Scenarist_SCC V1.0"):
        issues.append("missing 'Scenarist_SCC V1.0' header")
    timing_found = re.search(r"\d\d:\d\d:\d\d[;:]\d\d\t", text)
    if not timing_found:
        issues.append("no SMPTE-tab timing lines found")
    return issues


# Dispatcher -------------------------------------------------------------

def validate(path: str) -> List[str]:
    p = path.lower()
    if p.endswith(".srt"):
        return validate_srt(path)
    if p.endswith(".vtt") or p.endswith(".webvtt"):
        return validate_vtt(path)
    if p.endswith(".ass") or p.endswith(".ssa"):
        return validate_ass(path)
    if p.endswith(".ttml") or p.endswith(".dfxp") or p.endswith(".xml"):
        return validate_ttml(path)
    if p.endswith(".scc"):
        return validate_scc(path)
    return ["unknown file extension: {}".format(os.path.splitext(p)[1])]


def is_valid(path: str) -> bool:
    return len(validate(path)) == 0
