"""Reading speed metrics and constraints.

Subtitles need to give viewers enough time to read them. Standards vary:

  - Netflix English: <= 17 chars/sec for adult content, <= 13 for kids
  - BBC: <= 15 cps target, soft cap at 17
  - General editorial: <= 20 cps absolute upper bound

This module gives one place to compute and enforce those constraints.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from .text_utils import chars_no_spaces, chars_visible
from .types import Segment, Transcript


@dataclass
class ReadingSpeedReport:
    cps: float
    chars: int
    duration_seconds: float
    over_target: bool
    over_max: bool


@dataclass
class ReadingSpeedRules:
    """Per-platform reading-speed targets."""
    target_cps: float = 17.0
    max_cps: float = 20.0
    min_duration_seconds: float = 0.833        # 5 frames at 6 fps perceptual floor
    max_duration_seconds: float = 7.0
    measure: str = "visible"                   # 'visible', 'no_spaces', 'all'

    def measure_chars(self, text: str) -> int:
        if self.measure == "no_spaces":
            return chars_no_spaces(text)
        if self.measure == "all":
            return len(text or "")
        return chars_visible(text or "")


# Convenience presets - exposed via presets.py too.
NETFLIX_ADULT = ReadingSpeedRules(target_cps=17.0, max_cps=20.0, max_duration_seconds=7.0)
NETFLIX_KIDS = ReadingSpeedRules(target_cps=13.0, max_cps=17.0, max_duration_seconds=7.0)
BBC = ReadingSpeedRules(target_cps=15.0, max_cps=17.0)
APPLE = ReadingSpeedRules(target_cps=20.0, max_cps=25.0)


def compute(seg: Segment, rules: Optional[ReadingSpeedRules] = None) -> ReadingSpeedReport:
    """Score one segment. seg.cps is also populated as a side effect."""
    rules = rules or ReadingSpeedRules()
    duration = max(0.0, seg.end - seg.start)
    chars = rules.measure_chars(seg.text or "")
    if duration <= 0:
        cps = float("inf") if chars > 0 else 0.0
    else:
        cps = chars / duration
    seg.cps = cps if cps != float("inf") else 999.0
    return ReadingSpeedReport(
        cps=cps,
        chars=chars,
        duration_seconds=duration,
        over_target=cps > rules.target_cps,
        over_max=cps > rules.max_cps,
    )


def annotate(transcript: Transcript, rules: Optional[ReadingSpeedRules] = None) -> Transcript:
    """Compute cps for every segment in place."""
    rules = rules or ReadingSpeedRules()
    for s in transcript.segments:
        compute(s, rules)
    return transcript


def violations(transcript: Transcript,
               rules: Optional[ReadingSpeedRules] = None) -> List[Segment]:
    """Return segments that exceed the configured max_cps."""
    rules = rules or ReadingSpeedRules()
    out: List[Segment] = []
    for s in transcript.segments:
        r = compute(s, rules)
        if r.over_max:
            out.append(s)
    return out


def histogram(transcript: Transcript, bin_width: float = 1.0) -> dict:
    """Bucket segments by cps. Useful for editorial dashboards."""
    rules = ReadingSpeedRules()
    buckets: dict = {}
    for s in transcript.segments:
        r = compute(s, rules)
        if r.cps == float("inf"):
            key = "inf"
        else:
            key = "{:.0f}".format((r.cps // bin_width) * bin_width)
        buckets[key] = buckets.get(key, 0) + 1
    return buckets


def stretch_to_max(transcript: Transcript,
                   rules: Optional[ReadingSpeedRules] = None,
                   max_extension_seconds: float = 1.5) -> Transcript:
    """Extend cues that exceed max_cps until they fit, up to a cap.

    Operates in place. Returns the same transcript for convenience.
    Adjacent cue starts are not pushed - if there's no room ahead, we leave
    the cue alone (the editor will need to re-time).
    """
    rules = rules or ReadingSpeedRules()
    segs = transcript.segments
    for i, seg in enumerate(segs):
        r = compute(seg, rules)
        if not r.over_max or r.duration_seconds <= 0:
            continue
        target_dur = r.chars / rules.max_cps
        needed = target_dur - r.duration_seconds
        if needed <= 0:
            continue
        room_ahead = float("inf")
        if i + 1 < len(segs):
            room_ahead = max(0.0, segs[i + 1].start - seg.end)
        extension = min(needed, max_extension_seconds, room_ahead)
        if extension > 0:
            seg.end += extension
    return transcript
