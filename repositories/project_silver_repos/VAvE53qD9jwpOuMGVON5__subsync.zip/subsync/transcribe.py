"""Whisper transcription with word-level timestamps."""
from __future__ import annotations
import os, sys
from pathlib import Path
from typing import Optional, Tuple

from .types import Word, Segment


def _cuda_runtime_available() -> bool:
    """
    Cheaply check whether ctranslate2's CUDA backend will actually work.
    On Windows that means cublas + cudnn DLLs must be loadable. Trying to
    use the GPU when they aren't crashes deep inside model.encode() with
    'cublas64_12.dll is not found'. Probe up front so we can fall back.
    """
    if os.name != "nt":
        # On Linux/macOS let ctranslate2 try; failures there usually surface earlier.
        return True
    try:
        import ctypes
        # Either of these missing means the CUDA path is dead.
        ctypes.WinDLL("cublas64_12.dll")
    except OSError:
        return False
    return True


def transcribe(
    audio: Path,
    *,
    model_name: str = "large-v3",
    language: Optional[str] = None,
    vad: bool = True,
    beam_size: int = 5,
    compute_type: str = "auto",
    device: str = "auto",
) -> Tuple[list[Segment], str]:
    """
    Run faster-whisper. Returns (segments, detected_language).
    """
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        sys.exit("error: faster-whisper not installed. → pip install faster-whisper")

    # If the caller asked for "auto" (the default) but the CUDA runtime isn't
    # actually usable on this machine, quietly downgrade to CPU. Saves users
    # from cryptic 'cublas64_12.dll not found' crashes when they don't have
    # an NVIDIA stack installed.
    if device == "auto" and not _cuda_runtime_available():
        print("[subsync] no CUDA runtime detected; running on CPU (slower but works)",
              file=sys.stderr)
        device = "cpu"
        if compute_type == "auto":
            compute_type = "int8"

    print(f"[subsync] loading whisper model: {model_name} (device={device}, compute={compute_type})",
          file=sys.stderr)
    try:
        model = WhisperModel(model_name, device=device, compute_type=compute_type)
    except (RuntimeError, ValueError) as e:
        msg = str(e).lower()
        if device != "cpu" and ("cuda" in msg or "cublas" in msg or "cudnn" in msg):
            print(f"[subsync] CUDA load failed ({e}); falling back to CPU", file=sys.stderr)
            model = WhisperModel(model_name, device="cpu", compute_type="int8")
        else:
            raise

    print(f"[subsync] transcribing (vad={vad}, lang={language or 'auto'})", file=sys.stderr)
    seg_iter, info = model.transcribe(
        str(audio),
        language=language,
        beam_size=beam_size,
        word_timestamps=True,
        vad_filter=vad,
        vad_parameters=dict(min_silence_duration_ms=500) if vad else None,
        condition_on_previous_text=True,
    )
    print(f"[subsync] detected language: {info.language} (p={info.language_probability:.2f})", file=sys.stderr)

    out: list[Segment] = []
    for s in seg_iter:
        words = [
            Word(start=w.start or 0.0, end=w.end or 0.0,
                 text=(w.word or "").strip(),
                 prob=getattr(w, "probability", 1.0) or 1.0)
            for w in (s.words or []) if (w.word or "").strip()
        ]
        out.append(Segment(
            start=s.start, end=s.end,
            text=(s.text or "").strip(),
            words=words,
            avg_logprob=getattr(s, "avg_logprob", 0.0) or 0.0,
            no_speech_prob=getattr(s, "no_speech_prob", 0.0) or 0.0,
        ))
        print(f"  [{s.start:7.2f}s → {s.end:7.2f}s] {s.text.strip()[:80]}", file=sys.stderr)

    return out, info.language
