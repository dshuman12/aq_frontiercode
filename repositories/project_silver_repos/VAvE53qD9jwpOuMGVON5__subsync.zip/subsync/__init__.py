"""subsync — high-grade video/audio subtitling pipeline."""
from .version import VERSION as __version__
