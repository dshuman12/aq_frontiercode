"""ffmpeg subtitle burn-in with style presets."""
from __future__ import annotations
import sys
from pathlib import Path
from .media import require, run

# ASS style strings for ffmpeg's subtitles filter (force_style=)
STYLES: dict[str, str] = {
    "cinema": "FontName=Inter,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H40000000,BorderStyle=1,Outline=1.5,Shadow=0.5,Alignment=2,MarginV=60",
    "clean":  "FontName=Inter,FontSize=20,PrimaryColour=&H00FFFFFF,OutlineColour=&HC0000000,BorderStyle=3,Outline=2,Shadow=0,Alignment=2,MarginV=40",
    "bold":   "FontName=Inter,FontSize=26,Bold=1,PrimaryColour=&H0000FFFF,OutlineColour=&HFF000000,BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=70",
    "broadcast": "FontName=Arial,FontSize=20,PrimaryColour=&H00FFFFFF,OutlineColour=&HFF000000,BorderStyle=1,Outline=1.2,Shadow=0,Alignment=2,MarginV=40",
}


def burn(video: Path, srt: Path, out: Path, style: str = "cinema",
         crf: int = 18, preset: str = "medium") -> Path:
    ffmpeg = require("ffmpeg")
    style_str = STYLES.get(style, STYLES["cinema"])
    # ffmpeg's subtitles filter wants forward slashes and escaped colons on Windows
    srt_arg = str(srt).replace("\\", "/").replace(":", r"\:")
    vf = f"subtitles='{srt_arg}':force_style='{style_str}'"
    print(f"[subsync] burning subtitles → {out.name}", file=sys.stderr)
    run([
        ffmpeg, "-y", "-i", str(video),
        "-vf", vf,
        "-c:v", "libx264", "-crf", str(crf), "-preset", preset,
        "-c:a", "copy",
        "-loglevel", "error", "-stats",
        str(out),
    ])
    return out
