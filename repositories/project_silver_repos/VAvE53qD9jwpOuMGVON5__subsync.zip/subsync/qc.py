"""Quality-control checks for delivery.

Used by --qc and by the GUI's "Check before delivery" button. Each check
returns a list of issues (empty list = clean). Checks are independent so
you can run a subset.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from .types import Transcript, Segment
from .reading_speed import compute, ReadingSpeedRules
from .text_utils import chars_visible


@dataclass
class QcIssue:
    severity: str          # 'info', 'warning', 'error'
    code: str              # short stable identifier
    message: str
    cue_index: Optional[int] = None
    seg_start: Optional[float] = None
    seg_end: Optional[float] = None


@dataclass
class QcReport:
    issues: List[QcIssue]
    rules: Optional[Dict] = None

    @property
    def errors(self) -> List[QcIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> List[QcIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def is_clean(self) -> bool:
        return all(i.severity != "error" for i in self.issues)

    def text_report(self) -> str:
        lines = ["{} issue(s) found".format(len(self.issues))]
        for issue in self.issues:
            lines.append("  [{}] {} cue#{} ({}-{}) {}".format(
                issue.severity, issue.code, issue.cue_index,
                "{:.2f}".format(issue.seg_start) if issue.seg_start is not None else "-",
                "{:.2f}".format(issue.seg_end) if issue.seg_end is not None else "-",
                issue.message,
            ))
        return "\n".join(lines)


# -----------------------------------------------------------------------------
# Individual checks
# -----------------------------------------------------------------------------

def check_overlapping_cues(t: Transcript) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i in range(1, len(t.segments)):
        prev = t.segments[i - 1]
        curr = t.segments[i]
        if curr.start < prev.end:
            issues.append(QcIssue(
                severity="error", code="overlap",
                message="cue {} starts before previous ends ({} < {})".format(
                    i, curr.start, prev.end),
                cue_index=i, seg_start=curr.start, seg_end=curr.end,
            ))
    return issues


def check_minimum_duration(t: Transcript, min_seconds: float = 0.833) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        if (s.end - s.start) < min_seconds:
            issues.append(QcIssue(
                severity="warning", code="short_cue",
                message="cue duration {:.3f}s below minimum {:.3f}s".format(
                    s.end - s.start, min_seconds),
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


def check_maximum_duration(t: Transcript, max_seconds: float = 7.0) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        if (s.end - s.start) > max_seconds:
            issues.append(QcIssue(
                severity="warning", code="long_cue",
                message="cue duration {:.3f}s above max {:.3f}s".format(
                    s.end - s.start, max_seconds),
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


def check_reading_speed(t: Transcript,
                        rules: Optional[ReadingSpeedRules] = None) -> List[QcIssue]:
    rules = rules or ReadingSpeedRules()
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        r = compute(s, rules)
        if r.over_max:
            issues.append(QcIssue(
                severity="error", code="reading_speed",
                message="cps {:.1f} above max {:.1f}".format(r.cps, rules.max_cps),
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
        elif r.over_target:
            issues.append(QcIssue(
                severity="warning", code="reading_speed_soft",
                message="cps {:.1f} above target {:.1f}".format(r.cps, rules.target_cps),
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


def check_line_length(t: Transcript, max_chars: int = 42) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        text = s.text or ""
        for line in text.split("\n"):
            if chars_visible(line) > max_chars:
                issues.append(QcIssue(
                    severity="warning", code="line_too_long",
                    message="line {} chars > max {}".format(chars_visible(line), max_chars),
                    cue_index=i, seg_start=s.start, seg_end=s.end,
                ))
                break
    return issues


def check_max_lines(t: Transcript, max_lines: int = 2) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        n_lines = (s.text or "").count("\n") + (1 if (s.text or "").strip() else 0)
        if n_lines > max_lines:
            issues.append(QcIssue(
                severity="warning", code="too_many_lines",
                message="cue has {} lines, max {}".format(n_lines, max_lines),
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


def check_empty_text(t: Transcript) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        if not (s.text or "").strip():
            issues.append(QcIssue(
                severity="warning", code="empty_text",
                message="cue text is empty",
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


def check_negative_or_inverted_timings(t: Transcript) -> List[QcIssue]:
    issues: List[QcIssue] = []
    for i, s in enumerate(t.segments):
        if s.start < 0 or s.end < 0:
            issues.append(QcIssue(
                severity="error", code="negative_time",
                message="cue has negative timing",
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
        if s.end < s.start:
            issues.append(QcIssue(
                severity="error", code="inverted_time",
                message="cue end before start",
                cue_index=i, seg_start=s.start, seg_end=s.end,
            ))
    return issues


# -----------------------------------------------------------------------------
# Run-all + per-preset wrappers
# -----------------------------------------------------------------------------

def run_all(t: Transcript,
            max_chars: int = 42,
            max_lines: int = 2,
            min_seconds: float = 0.833,
            max_seconds: float = 7.0,
            speed_rules: Optional[ReadingSpeedRules] = None) -> QcReport:
    issues: List[QcIssue] = []
    issues += check_overlapping_cues(t)
    issues += check_minimum_duration(t, min_seconds)
    issues += check_maximum_duration(t, max_seconds)
    issues += check_reading_speed(t, speed_rules)
    issues += check_line_length(t, max_chars)
    issues += check_max_lines(t, max_lines)
    issues += check_empty_text(t)
    issues += check_negative_or_inverted_timings(t)
    return QcReport(issues=issues)


def run_for_preset(t: Transcript, preset_name: str) -> QcReport:
    """Run the QC checks using a named preset's constraints."""
    from .presets import get
    p = get(preset_name)
    return run_all(
        t,
        max_chars=p.max_chars_per_line,
        max_lines=p.max_lines,
        min_seconds=p.reading_speed.min_duration_seconds,
        max_seconds=p.reading_speed.max_duration_seconds,
        speed_rules=p.reading_speed,
    )
