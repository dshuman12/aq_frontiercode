"""
Broadcast and legacy subtitle exporters.

Formats covered:
  - TTML / IMSC1.1   XML, modern broadcast standard (Netflix, BBC submissions)
  - EBU-STL          binary, European broadcast standard (EBU Tech 3264)
  - SCC              Scenarist Closed Caption, US broadcast (line-21 CEA-608)
  - SBV              YouTube's old upload format
  - SAMI             Microsoft's legacy synchronized accessible media

Each writer takes a Transcript and a Path and emits the file. Specs are
followed where it matters (EBU-STL block structure, SCC timecode + character
encoding); presentation-only details (font, colour styling) use sensible
defaults the destination platform will override.
"""
from __future__ import annotations

import datetime
import struct
from pathlib import Path
from typing import Iterable, Optional
from xml.sax.saxutils import escape as xml_escape

from .types import Transcript, Segment, Event


# ---------------------------------------------------------------- helpers

def _hms_ms(t: float) -> str:
    if t < 0: t = 0.0
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000:
        s += 1; ms = 0
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def _smpte_ndf(t: float, fps: int) -> str:
    """Non-drop-frame SMPTE timecode HH:MM:SS:FF for fps in {24,25,30,50,60}."""
    if t < 0: t = 0.0
    total_frames = int(round(t * fps))
    h = total_frames // (3600 * fps)
    rem = total_frames - h * 3600 * fps
    m = rem // (60 * fps)
    rem -= m * 60 * fps
    s = rem // fps
    f = rem - s * fps
    return f"{h:02d}:{m:02d}:{s:02d}:{f:02d}"


def _smpte_df_2997(t: float) -> str:
    """Drop-frame timecode for 29.97 fps (HH:MM:SS;FF). SMPTE 12M algorithm."""
    if t < 0: t = 0.0
    fps_int = 30
    actual_fps = 30000.0 / 1001.0
    frame_no = int(round(t * actual_fps))
    drop_frames = 2
    frames_per_minute = fps_int * 60 - drop_frames     # 1798
    frames_per_10min = frames_per_minute * 10 + drop_frames  # 17982
    d = frame_no // frames_per_10min
    m = frame_no % frames_per_10min
    if m > drop_frames:
        frame_no += drop_frames * 9 * d + drop_frames * ((m - drop_frames) // frames_per_minute)
    else:
        frame_no += drop_frames * 9 * d
    H = (frame_no // (3600 * fps_int)) % 24
    M = (frame_no // (60 * fps_int)) % 60
    S = (frame_no // fps_int) % 60
    F = frame_no % fps_int
    return f"{H:02d}:{M:02d}:{S:02d};{F:02d}"


def _interleave(t: Transcript, with_events: bool) -> list[tuple]:
    items: list[tuple] = []
    for s in t.segments:
        items.append((s.start, s.end, "seg", s))
    if with_events:
        for e in t.events:
            items.append((e.start, e.end, "event", e))
    items.sort(key=lambda x: (x[0], 0 if x[2] == "event" else 1))
    return items


def _cue_text(item, *, speaker_prefix: bool, lang: Optional[str]) -> str:
    kind = item[2]
    if kind == "event":
        return f"[{item[3].label}]"
    s: Segment = item[3]
    body = s.translations.get(lang, s.text) if lang else s.text
    if speaker_prefix and s.speaker:
        return f"{s.speaker}: {body}"
    return body


# ---------------------------------------------------------------- SBV

def write_sbv(t: Transcript, path: Path, *,
              speaker_prefix: bool = False,
              with_events: bool = True,
              lang: Optional[str] = None) -> Path:
    """YouTube's SubViewer-derived format: H:MM:SS.mmm,H:MM:SS.mmm + lines."""
    out: list[str] = []
    for it in _interleave(t, with_events):
        text = _cue_text(it, speaker_prefix=speaker_prefix, lang=lang)
        if not text.strip(): continue
        # SBV uses single-digit hours (H:MM:SS.mmm)
        def f(x: float) -> str:
            ts = _hms_ms(x)
            # Strip a leading zero from hours
            if ts.startswith("0"): ts = ts[1:]
            return ts
        out.append(f"{f(it[0])},{f(it[1])}\n{text}\n")
    path.write_text("\n".join(out), encoding="utf-8")
    return path


# ---------------------------------------------------------------- SAMI

_SAMI_HEAD = """<SAMI>
<HEAD>
<TITLE>{title}</TITLE>
<STYLE TYPE="text/css">
<!--
P {{ margin-left: 8pt; margin-right: 8pt; margin-bottom: 2pt; margin-top: 2pt;
     text-align: center; font-size: 18pt; font-family: Arial, sans-serif;
     font-weight: normal; color: #FFFFFF; background-color: #000000; }}
.{lang_class} {{ Name: "{lang_name}"; lang: {lang_tag}; SAMIType: CC; }}
#Source {{ display: none; }}
-->
</STYLE>
</HEAD>
<BODY>
"""


def write_sami(t: Transcript, path: Path, *,
               title: str = "Subsync output",
               speaker_prefix: bool = False,
               with_events: bool = True,
               lang: Optional[str] = None,
               lang_name: str = "English") -> Path:
    """Microsoft SAMI (.smi). Each cue: <SYNC Start=ms><P Class=...>text</P>."""
    lang_tag = (lang or t.language or "en").lower()
    lang_class = f"{lang_tag.upper()}CC"
    out = [_SAMI_HEAD.format(title=xml_escape(title),
                             lang_class=lang_class,
                             lang_name=xml_escape(lang_name),
                             lang_tag=lang_tag)]
    for it in _interleave(t, with_events):
        text = _cue_text(it, speaker_prefix=speaker_prefix, lang=lang)
        if not text.strip(): continue
        start_ms = int(it[0] * 1000)
        end_ms   = int(it[1] * 1000)
        text_html = xml_escape(text).replace("\n", "<BR>")
        out.append(f"<SYNC Start={start_ms}><P Class={lang_class}>{text_html}</P>")
        out.append(f"<SYNC Start={end_ms}><P Class={lang_class}>&nbsp;</P>")
    out.append("</BODY>\n</SAMI>\n")
    path.write_text("\n".join(out), encoding="utf-8")
    return path


# ---------------------------------------------------------------- TTML / IMSC

def write_ttml(t: Transcript, path: Path, *,
               imsc: bool = True,
               speaker_prefix: bool = False,
               with_events: bool = True,
               lang: Optional[str] = None,
               frame_rate: int = 25) -> Path:
    """
    W3C TTML2 / IMSC 1.1 text profile.
    The default profile (imsc=True) embeds the IMSC 1.1 text profile attribute
    so it round-trips through Netflix and BBC delivery checkers.
    """
    xml_lang = (lang or t.language or "en")
    out = ['<?xml version="1.0" encoding="UTF-8"?>']
    profile = ('xmlns:itts="http://www.w3.org/ns/ttml/profile/imsc1#styling" '
               'ttp:contentProfiles="http://www.w3.org/ns/ttml/profile/imsc1.1/text" '
               if imsc else '')
    out.append(f'<tt xmlns="http://www.w3.org/ns/ttml" '
               f'xmlns:tts="http://www.w3.org/ns/ttml#styling" '
               f'xmlns:ttp="http://www.w3.org/ns/ttml#parameter" '
               f'{profile}'
               f'xml:lang="{xml_lang}" '
               f'ttp:timeBase="media" ttp:frameRate="{frame_rate}">')
    out.append('<head>')
    out.append('  <styling>')
    out.append('    <style xml:id="default" tts:fontFamily="proportionalSansSerif" '
               'tts:fontSize="80%" tts:textAlign="center" tts:color="white" '
               'tts:backgroundColor="rgba(0,0,0,0.55)"/>')
    out.append('  </styling>')
    out.append('  <layout>')
    out.append('    <region xml:id="bottom" tts:origin="10% 80%" tts:extent="80% 20%" '
               'tts:displayAlign="after" tts:textAlign="center"/>')
    out.append('  </layout>')
    out.append('</head>')
    out.append('<body region="bottom" style="default">')
    out.append('  <div>')
    for it in _interleave(t, with_events):
        text = _cue_text(it, speaker_prefix=speaker_prefix, lang=lang)
        if not text.strip(): continue
        start = _hms_ms(it[0])
        end   = _hms_ms(it[1])
        body = xml_escape(text).replace("\n", "<br/>")
        out.append(f'    <p begin="{start}" end="{end}">{body}</p>')
    out.append('  </div>')
    out.append('</body>')
    out.append('</tt>')
    path.write_text("\n".join(out), encoding="utf-8")
    return path


# ---------------------------------------------------------------- EBU-STL

# ISO 6937 has a base mapping that's largely Latin-1 for printable ASCII.
# For diacritics it uses two-byte non-spacing accent prefixes which we don't
# need for plain transcription text; we map common Latin chars and replace
# the rest with '?'. Good enough for English / Spanish / French / Portuguese.
_ISO6937_DIACRITICS = {
    "à": b"\xc1a", "á": b"\xc2a", "â": b"\xc3a", "ã": b"\xc4a", "ä": b"\xc8a", "å": b"\xcaa",
    "è": b"\xc1e", "é": b"\xc2e", "ê": b"\xc3e", "ë": b"\xc8e",
    "ì": b"\xc1i", "í": b"\xc2i", "î": b"\xc3i", "ï": b"\xc8i",
    "ò": b"\xc1o", "ó": b"\xc2o", "ô": b"\xc3o", "õ": b"\xc4o", "ö": b"\xc8o",
    "ù": b"\xc1u", "ú": b"\xc2u", "û": b"\xc3u", "ü": b"\xc8u",
    "ý": b"\xc2y", "ÿ": b"\xc8y", "ç": b"\xcbc", "ñ": b"\xc4n",
    "À": b"\xc1A", "Á": b"\xc2A", "Â": b"\xc3A", "Ä": b"\xc8A",
    "É": b"\xc2E", "È": b"\xc1E",
    "Ñ": b"\xc4N",
}


def _to_iso6937(text: str) -> bytes:
    out = bytearray()
    for ch in text:
        if ch in _ISO6937_DIACRITICS:
            out += _ISO6937_DIACRITICS[ch]
        elif 0x20 <= ord(ch) <= 0x7E:
            out.append(ord(ch))
        elif ch == "\n":
            out.append(0x8A)  # CRLF in EBU-STL
        elif ch in "¡¿":  # ¡ ¿
            out.append({"¡": 0xA1, "¿": 0xBF}[ch])
        else:
            out.append(0x3F)  # '?'
    return bytes(out)


def _gsi_block(t: Transcript, *, title: str, fps: int, language: str,
               n_subtitles: int) -> bytes:
    def pad(s: str, n: int, fillchar: str = " ") -> bytes:
        return s.encode("ascii", "replace")[:n].ljust(n, fillchar.encode("ascii"))

    cpn = b"850"            # code page
    dfc = f"STL{fps:02d}.01".encode()    # disk format code
    dsc = b"0"              # display std open
    cct = b"00"             # latin
    lc  = (language[:2] or "00").upper().encode("ascii", "replace")[:2].ljust(2, b"0")
    opt = pad(title, 32)
    oet = pad("", 32)
    tpt = pad("", 32)
    tet = pad("", 32)
    tn  = pad("subsync", 32)
    tcd = pad("", 32)
    slr = pad("", 16)
    today = datetime.datetime.utcnow().strftime("%y%m%d").encode("ascii")
    cd  = today
    rd  = today
    rn  = b"01"
    tnb = f"{n_subtitles:05d}".encode("ascii")
    tns = f"{n_subtitles:05d}".encode("ascii")
    tng = b"001"
    mnc = b"40"             # max chars per row
    mnr = b"23"             # max rows
    tcs = b"1"              # time code intended for use
    tcp = b"00000000"       # start of programme
    tcf = b"00000000"
    tnd = b"1"
    dsn = b"1"
    co  = b"GBR"
    pub = pad("subsync", 32)
    en  = pad("", 32)
    ecd = pad("", 32)
    spare = b" " * 75
    uda = b" " * 576

    block = (cpn + dfc + dsc + cct + lc + opt + oet + tpt + tet + tn + tcd + slr +
             cd + rd + rn + tnb + tns + tng + mnc + mnr + tcs + tcp + tcf +
             tnd + dsn + co + pub + en + ecd + spare + uda)
    assert len(block) == 1024, f"GSI block must be 1024 bytes, got {len(block)}"
    return block


def _tcp_bytes(t: float, fps: int) -> bytes:
    if t < 0: t = 0.0
    total_frames = int(round(t * fps))
    h = total_frames // (3600 * fps)
    rem = total_frames - h * 3600 * fps
    m = rem // (60 * fps)
    rem -= m * 60 * fps
    s = rem // fps
    f = rem - s * fps
    return bytes([min(h, 23), min(m, 59), min(s, 59), min(f, fps - 1)])


def write_ebu_stl(t: Transcript, path: Path, *,
                  title: str = "Subsync output",
                  fps: int = 25,
                  speaker_prefix: bool = False,
                  with_events: bool = True,
                  lang: Optional[str] = None) -> Path:
    """EBU Tech 3264 STL (.stl)."""
    items = _interleave(t, with_events)
    cues = []
    for it in items:
        text = _cue_text(it, speaker_prefix=speaker_prefix, lang=lang)
        if not text.strip(): continue
        cues.append((it[0], it[1], text))

    gsi = _gsi_block(t, title=title, fps=fps,
                     language=(lang or t.language or "en"),
                     n_subtitles=len(cues))

    tti_blocks = bytearray()
    for sn, (start, end, text) in enumerate(cues, 1):
        sgn = bytes([0])                      # group number
        sn_b = struct.pack("<H", sn)          # subtitle number little-endian
        ebn = bytes([0xFF])                   # last extension block
        cs  = bytes([0])                      # cumulative status
        tci = _tcp_bytes(start, fps)
        tco = _tcp_bytes(end, fps)
        vp  = bytes([20])                     # vertical position (row 20)
        jc  = bytes([2])                      # justification: centre
        cf  = bytes([0])                      # comment flag: 0 = text
        tf_raw = _to_iso6937(text[:112])
        tf = tf_raw[:112].ljust(112, b"\x8F")  # 0x8F = end of text fill
        block = sgn + sn_b + ebn + cs + tci + tco + vp + jc + cf + tf
        assert len(block) == 128, f"TTI must be 128 bytes, got {len(block)}"
        tti_blocks += block

    path.write_bytes(gsi + bytes(tti_blocks))
    return path


# ---------------------------------------------------------------- SCC (CEA-608)

# CEA-608 ASCII to CC1 byte mapping (printable subset). Each pair of bytes
# represents two characters in the line-21 captioning channel. Most ASCII
# maps directly; a few special characters (©, ®, ½, …) have replacement codes.
_SCC_ODD_PARITY = {}
def _odd(b: int) -> int:
    """Return b with odd parity in bit 7 (CEA-608 requirement)."""
    if b in _SCC_ODD_PARITY: return _SCC_ODD_PARITY[b]
    p = b & 0x7F
    parity = bin(p).count("1") & 1
    out = p if parity else (p | 0x80)
    _SCC_ODD_PARITY[b] = out
    return out


def _scc_word(c1: int, c2: int) -> str:
    """Encode two characters as a 4-hex-digit word with odd parity."""
    return f"{_odd(c1):02x}{_odd(c2):02x}"


def _scc_text_words(text: str) -> list[str]:
    """Break text into character pairs encoded as hex words."""
    chars = []
    for ch in text:
        b = ord(ch)
        if 0x20 <= b <= 0x7E:
            chars.append(b)
        elif ch == "\n":
            # Inside one cue we just space; row break would need extra control codes
            chars.append(0x20)
        else:
            chars.append(0x3F)
    if len(chars) % 2 == 1:
        chars.append(0x80)  # null fill
    return [_scc_word(chars[i], chars[i+1]) for i in range(0, len(chars), 2)]


def write_scc(t: Transcript, path: Path, *,
              speaker_prefix: bool = False,
              with_events: bool = True,
              lang: Optional[str] = None,
              row: int = 14) -> Path:
    """
    Scenarist .scc (CEA-608, line 21, 29.97 drop-frame).
    Generates RCL (Resume Caption Loading 0x9420) + PAC (preamble for the row)
    + character bytes + EOC (End Of Caption 0x942F) per cue, plus EDM at out-time.
    """
    pac_table = {  # row → preamble code (white, no underline)
        11: 0x9152, 12: 0x9172, 13: 0x9252, 14: 0x9272, 15: 0x9452,
    }
    pac = pac_table.get(row, 0x9272)
    RCL = "9420"
    EOC = "942f"
    EDM = "942c"
    PAC = f"{pac:04x}"

    out = ["Scenarist_SCC V1.0\n"]
    for it in _interleave(t, with_events):
        text = _cue_text(it, speaker_prefix=speaker_prefix, lang=lang)
        if not text.strip(): continue
        text = " ".join(text.split())  # collapse internal whitespace
        words = [RCL, RCL, PAC, PAC] + _scc_text_words(text) + [EOC, EOC]
        out.append(f"{_smpte_df_2997(it[0])}\t{' '.join(words)}\n")
        out.append(f"{_smpte_df_2997(it[1])}\t{EDM} {EDM}\n")
    path.write_text("\n".join(out), encoding="utf-8")
    return path


# ---------------------------------------------------------------- registry

WRITERS = {
    "sbv":  write_sbv,
    "sami": write_sami,
    "smi":  write_sami,
    "ttml": write_ttml,
    "dfxp": write_ttml,
    "xml":  write_ttml,
    "stl":  write_ebu_stl,
    "ebu":  write_ebu_stl,
    "scc":  write_scc,
}


def export_format(t: Transcript, fmt: str, path: Path, **kwargs) -> Path:
    """Dispatch by file extension or short name."""
    fmt = fmt.lower().lstrip(".")
    if fmt not in WRITERS:
        raise ValueError(f"Unknown format {fmt!r}. Known: {sorted(WRITERS)}")
    return WRITERS[fmt](t, path, **kwargs)
