"""
Non-speech audio event tagging via AST (MIT/ast-finetuned-audioset-10-10-0.4593).
Restricted to gaps in Whisper's word coverage so the classifier doesn't fight speech.
Override the model with the SUBSYNC_AST_MODEL env var (path or HF id).
"""
from __future__ import annotations
import os
import sys
from pathlib import Path
from typing import Optional

from .types import Event, Segment

LABEL_MAP: dict[str, str] = {
    "Music": "Music", "Musical instrument": "Music",
    "Singing": "Singing", "Whispering": "Whispering",
    "Laughter": "Laughter", "Baby laughter": "Baby laughs",
    "Giggle": "Laughter", "Snicker": "Laughter", "Belly laugh": "Laughter",
    "Crying, sobbing": "Crying", "Baby cry, infant cry": "Baby cries",
    "Sigh": "Sigh", "Cough": "Coughs", "Sneeze": "Sneezes",
    "Snoring": "Snoring", "Gasp": "Gasp",
    "Applause": "Applause", "Cheering": "Cheering",
    "Crowd": "Crowd noise",
    "Hubbub, speech noise, speech babble": "Background chatter",
    "Children shouting": "Children shouting", "Screaming": "Screaming",
    "Whistle": "Whistling",
    "Telephone bell ringing": "Phone rings", "Ringtone": "Phone rings", "Telephone": "Phone",
    "Door": "Door", "Knock": "Knocking", "Doorbell": "Doorbell",
    "Footsteps": "Footsteps",
    "Vehicle": "Vehicle", "Engine": "Engine",
    "Car passing by": "Car passing", "Siren": "Siren",
    "Gunshot, gunfire": "Gunshot", "Explosion": "Explosion",
    "Alarm": "Alarm", "Bell": "Bell",
    "Wind": "Wind", "Rain": "Rain", "Thunder": "Thunder", "Water": "Water",
    "Animal": "Animal sound", "Dog": "Dog barks", "Cat": "Cat meows", "Bird": "Bird sounds",
    "Pink noise": "Noise", "White noise": "Noise", "Noise": "Noise",
    "Sine wave": "Tone", "Beep, bleep": "Beep",
}


def _gaps(segments: list[Segment], duration: float, min_gap: float = 0.7) -> list[tuple[float, float]]:
    spans: list[tuple[float, float]] = []
    cursor = 0.0
    starts = sorted(((s.words[0].start if s.words else s.start),
                     (s.words[-1].end if s.words else s.end))
                    for s in segments if s.end > s.start)
    for s, e in starts:
        if s - cursor >= min_gap:
            spans.append((cursor, s))
        cursor = max(cursor, e)
    if duration - cursor >= min_gap:
        spans.append((cursor, duration))
    return spans


def detect(
    audio: Path,
    segments: list[Segment],
    duration: float,
    *,
    threshold: float = 0.30,
    min_gap: float = 0.7,
    device: str = "auto",
) -> list[Event]:
    try:
        import torch
        import torchaudio
        from transformers import AutoFeatureExtractor, AutoModelForAudioClassification
    except ImportError:
        print("[subsync] tagging deps missing (torch/transformers/torchaudio); skipping", file=sys.stderr)
        return []

    gaps = _gaps(segments, duration, min_gap=min_gap)
    if not gaps:
        print("[subsync] no non-speech gaps to tag", file=sys.stderr)
        return []

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    model_id = os.environ.get("SUBSYNC_AST_MODEL", "MIT/ast-finetuned-audioset-10-10-0.4593")
    print(f"[subsync] loading audio tagger (AST) on {device} from {model_id}", file=sys.stderr)
    extractor = AutoFeatureExtractor.from_pretrained(model_id)
    model = AutoModelForAudioClassification.from_pretrained(model_id).to(device).eval()
    id2label = model.config.id2label

    waveform, sr = torchaudio.load(str(audio))
    if sr != 16000:
        waveform = torchaudio.functional.resample(waveform, sr, 16000); sr = 16000
    if waveform.size(0) > 1:
        waveform = waveform.mean(dim=0, keepdim=True)
    waveform = waveform.squeeze(0)

    events: list[Event] = []
    print(f"[subsync] tagging {len(gaps)} non-speech gap(s)", file=sys.stderr)
    for gs, ge in gaps:
        win = 10.0
        stride = 5.0
        t = gs
        while t < ge:
            wend = min(t + win, ge)
            if wend - t < 1.5:
                t = wend
                continue
            i0 = int(t * sr)
            i1 = int(wend * sr)
            clip = waveform[i0:i1]
            if clip.numel() < sr // 2:
                t += stride
                continue
            inputs = extractor(clip.numpy(), sampling_rate=sr, return_tensors="pt").to(device)
            with torch.no_grad():
                logits = model(**inputs).logits
            probs = torch.sigmoid(logits)[0].cpu().tolist()
            best_label = None
            best_prob = 0.0
            for idx, p in enumerate(probs):
                lbl = id2label[idx]
                if lbl in LABEL_MAP and p > best_prob and p >= threshold:
                    best_label = LABEL_MAP[lbl]
                    best_prob = p
            if best_label:
                if events and events[-1].label == best_label and t - events[-1].end < 1.0:
                    events[-1].end = wend
                    events[-1].confidence = max(events[-1].confidence, best_prob)
                else:
                    events.append(Event(start=t, end=wend, label=best_label, confidence=best_prob))
            t += stride
    print(f"[subsync] detected {len(events)} non-speech event(s)", file=sys.stderr)
    return events
