"""On-disk transcribe cache.

Avoids re-running the 20-minute whisper pass when the wrap rules or the
target export format change. Cache key is sha-256 of the input path +
model name + language + mtime/size.
"""

from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path
from typing import Optional

from .types import Transcript
from .serializers import (
    transcript_to_dict, transcript_from_dict, cache_key,
)


DEFAULT_CACHE_DIR_ENV = "SUBSYNC_CACHE_DIR"
DEFAULT_CACHE_DIR = "~/.cache/subsync"


def cache_dir() -> Path:
    base = os.environ.get(DEFAULT_CACHE_DIR_ENV, DEFAULT_CACHE_DIR)
    return Path(os.path.expanduser(base))


def ensure_cache_dir() -> Path:
    p = cache_dir()
    p.mkdir(parents=True, exist_ok=True)
    return p


def lookup(input_path: str, model_name: str, language: str) -> Optional[Transcript]:
    """Return a cached Transcript or None if there's no hit."""
    key = cache_key(input_path, model_name, language)
    target = cache_dir() / "{}.json".format(key)
    if not target.exists():
        return None
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return transcript_from_dict(raw)


def store(input_path: str, model_name: str, language: str,
          transcript: Transcript) -> Path:
    ensure_cache_dir()
    key = cache_key(input_path, model_name, language)
    target = cache_dir() / "{}.json".format(key)
    payload = transcript_to_dict(transcript)
    payload["_cached_at"] = int(time.time())
    target.write_text(json.dumps(payload), encoding="utf-8")
    return target


def clear() -> int:
    """Drop every entry. Returns number of files removed."""
    p = cache_dir()
    if not p.exists():
        return 0
    n = 0
    for f in p.glob("*.json"):
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    return n


def stats() -> dict:
    p = cache_dir()
    if not p.exists():
        return {"entries": 0, "size_bytes": 0, "path": str(p)}
    total = 0
    n = 0
    for f in p.glob("*.json"):
        try:
            total += f.stat().st_size
            n += 1
        except OSError:
            continue
    return {"entries": n, "size_bytes": total, "path": str(p)}


def vacuum(max_entries: int = 100) -> int:
    """Drop oldest entries until we're below max_entries. Returns removed."""
    p = cache_dir()
    if not p.exists():
        return 0
    files = sorted(p.glob("*.json"), key=lambda f: f.stat().st_mtime)
    if len(files) <= max_entries:
        return 0
    removed = 0
    for f in files[:len(files) - max_entries]:
        try:
            f.unlink()
            removed += 1
        except OSError:
            pass
    return removed
