"""Compare two transcripts.

Used to verify a refactor didn't change visible output, and as the
foundation for `subsync diff a.srt b.srt`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from .types import Transcript, Segment


@dataclass
class DiffEntry:
    KIND_ADDED = "added"
    KIND_REMOVED = "removed"
    KIND_CHANGED = "changed"
    kind: str
    index: int
    a: Optional[Segment] = None
    b: Optional[Segment] = None
    reasons: Optional[List[str]] = None

    def __post_init__(self):
        if self.reasons is None:
            self.reasons = []


def structural_diff(a: List[Segment], b: List[Segment],
                    pos_tol: float = 0.1,
                    text_tol: float = 0.0) -> List[DiffEntry]:
    """Pair segments by closest start time, then compare."""
    out: List[DiffEntry] = []
    used_b = [False] * len(b)
    matches: List[Tuple[int, int]] = []

    for i, sa in enumerate(a):
        best = -1
        best_d = float("inf")
        for j, sb in enumerate(b):
            if used_b[j]:
                continue
            d = abs(sa.start - sb.start)
            if d < best_d:
                best_d = d
                best = j
        if best != -1 and best_d <= max(pos_tol * 4, 0.5):
            used_b[best] = True
            matches.append((i, best))

    matched_a = {i for i, _ in matches}
    matched_b = {j for _, j in matches}

    for i, sa in enumerate(a):
        if i not in matched_a:
            out.append(DiffEntry(DiffEntry.KIND_REMOVED, i, a=sa))

    for j, sb in enumerate(b):
        if j not in matched_b:
            out.append(DiffEntry(DiffEntry.KIND_ADDED, j, b=sb))

    for i, j in matches:
        sa = a[i]
        sb = b[j]
        reasons = _compare(sa, sb, pos_tol, text_tol)
        if reasons:
            out.append(DiffEntry(DiffEntry.KIND_CHANGED, i, a=sa, b=sb, reasons=reasons))

    return out


def _compare(a: Segment, b: Segment, pos_tol: float, text_tol: float) -> List[str]:
    reasons: List[str] = []
    if abs(a.start - b.start) > pos_tol:
        reasons.append("start")
    if abs(a.end - b.end) > pos_tol:
        reasons.append("end")
    if (a.text or "").strip() != (b.text or "").strip():
        reasons.append("text")
    if (a.speaker or "") != (b.speaker or ""):
        reasons.append("speaker")
    return reasons


def summarize(diffs: List[DiffEntry]) -> Dict[str, int]:
    out = {DiffEntry.KIND_ADDED: 0, DiffEntry.KIND_REMOVED: 0, DiffEntry.KIND_CHANGED: 0}
    for d in diffs:
        out[d.kind] += 1
    return out


def is_clean(diffs: List[DiffEntry]) -> bool:
    return len(diffs) == 0


def text_report(diffs: List[DiffEntry]) -> str:
    lines: List[str] = []
    s = summarize(diffs)
    lines.append("Diff summary: {a} added, {r} removed, {c} changed.".format(
        a=s[DiffEntry.KIND_ADDED], r=s[DiffEntry.KIND_REMOVED], c=s[DiffEntry.KIND_CHANGED]
    ))
    for d in diffs:
        if d.kind == DiffEntry.KIND_CHANGED:
            lines.append("  CHG idx={} ({}) {}".format(
                d.index, ", ".join(d.reasons or []), (d.a.text or "")[:60]))
        elif d.kind == DiffEntry.KIND_ADDED:
            lines.append("  ADD idx={} {}".format(d.index, (d.b.text or "")[:60] if d.b else ""))
        elif d.kind == DiffEntry.KIND_REMOVED:
            lines.append("  RM  idx={} {}".format(d.index, (d.a.text or "")[:60] if d.a else ""))
    return "\n".join(lines)
