"""CEA-608 / CEA-708 caption colour codes.

Used by the SCC and TTML writers when a downstream platform asks for
non-default text colour. All values are 6-digit hex (#RRGGBB).
"""

from __future__ import annotations

# CEA-608 standard 8-color palette
WHITE = "#FFFFFF"
GREEN = "#00FF00"
BLUE = "#0000FF"
CYAN = "#00FFFF"
RED = "#FF0000"
YELLOW = "#FFFF00"
MAGENTA = "#FF00FF"
BLACK = "#000000"

# Common roles
SPEAKER_DEFAULT = WHITE
NARRATOR = YELLOW
SOUND_EFFECT = CYAN
NON_SPEECH = MAGENTA
LYRIC = GREEN
TRANSLATION = WHITE


# CEA-608 control-code mapping. The byte values aren't used here; the
# names are exposed so downstream writers can look them up.
CEA_608_FG_CODES = {
    "white":   0x9020,
    "green":   0x9022,
    "blue":    0x9024,
    "cyan":    0x9026,
    "red":     0x9028,
    "yellow":  0x902A,
    "magenta": 0x902C,
}


def name_to_hex(name: str) -> str:
    return {
        "white": WHITE, "green": GREEN, "blue": BLUE, "cyan": CYAN,
        "red": RED, "yellow": YELLOW, "magenta": MAGENTA, "black": BLACK,
    }.get((name or "").lower(), WHITE)


def hex_to_nearest_name(hex_value: str) -> str:
    """Snap to the nearest of the 8-color CEA-608 palette."""
    h = (hex_value or "").upper()
    table = {
        "WHITE": WHITE, "GREEN": GREEN, "BLUE": BLUE, "CYAN": CYAN,
        "RED": RED, "YELLOW": YELLOW, "MAGENTA": MAGENTA, "BLACK": BLACK,
    }
    if h in table.values():
        for k, v in table.items():
            if v == h:
                return k.lower()

    def rgb(s: str):
        s = s.lstrip("#")
        return int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)

    try:
        target = rgb(h)
    except ValueError:
        return "white"

    best_name = "white"
    best_dist = 10**9
    for name, hex_v in table.items():
        c = rgb(hex_v)
        d = sum((a - b) ** 2 for a, b in zip(target, c))
        if d < best_dist:
            best_dist = d
            best_name = name.lower()
    return best_name
