"""Single source of truth for the version string."""
__all__ = ("VERSION", "version_tuple", "is_prerelease")

VERSION = "0.2.0"


def version_tuple() -> tuple:
    core = VERSION.split("-", 1)[0].split("+", 1)[0]
    parts = core.split(".")
    while len(parts) < 3:
        parts.append("0")
    return tuple(int(p) if p.isdigit() else 0 for p in parts[:3])


def is_prerelease() -> bool:
    return "-" in VERSION
