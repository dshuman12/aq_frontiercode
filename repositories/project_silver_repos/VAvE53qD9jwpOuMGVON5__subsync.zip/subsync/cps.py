"""
Reading-rate guards and timing constraints.

Industry references applied here:
  - BBC Subtitle Guidelines       max 17 cps for adult viewers
  - Netflix Timed Text Style Guide  <=17 cps adults / 13 cps children, max 7s
  - DCMP                          max 2 lines, ~32-42 chars/line
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import replace
from typing import Optional

from .types import Segment, Word


def char_count(text: str) -> int:
    """CPS uses characters including spaces and punctuation per BBC guidelines."""
    return len(text.replace("\n", " "))


def update_cps(seg: Segment) -> None:
    dur = max(seg.end - seg.start, 1e-3)
    seg.cps = char_count(seg.text) / dur


def _split_segment_at_word(seg: Segment, idx: int) -> tuple[Segment, Segment]:
    """Split a segment after `idx` words. Falls back to mid-time split if no words."""
    if not seg.words or idx <= 0 or idx >= len(seg.words):
        mid = (seg.start + seg.end) / 2
        a = replace(seg, end=mid, words=[], translations={})
        b = replace(seg, start=mid, words=[], translations={})
        return a, b
    left = seg.words[:idx]
    right = seg.words[idx:]
    a = Segment(
        start=seg.start, end=left[-1].end,
        text=" ".join(w.text for w in left).strip(),
        words=left, speaker=seg.speaker,
    )
    b = Segment(
        start=right[0].start, end=seg.end,
        text=" ".join(w.text for w in right).strip(),
        words=right, speaker=seg.speaker,
    )
    return a, b


def _midpoint_word(words: list[Word]) -> int:
    """Word index closest to the cue's midpoint by total characters."""
    total = sum(len(w.text) + 1 for w in words)
    target = total / 2
    running = 0
    for i, w in enumerate(words):
        running += len(w.text) + 1
        if running >= target:
            return max(1, i)
    return max(1, len(words) // 2)


def _greedy_lines(words: list[str], nlines: int, max_chars: int) -> list[str]:
    """Distribute words into roughly equal lines (visual balance)."""
    total = sum(len(w) for w in words) + len(words) - 1
    target = total / nlines
    out, cur = [], ""
    for w in words:
        if len(out) == nlines - 1:
            cur = (cur + " " + w).strip() if cur else w
            continue
        candidate = (cur + " " + w).strip() if cur else w
        if cur and len(candidate) > target:
            out.append(cur); cur = w
        else:
            cur = candidate
    if cur: out.append(cur)
    return out


def _wrap(text: str, max_chars: int, max_lines: int) -> str:
    """Word-boundary line wrap that prefers visually balanced lines."""
    text = " ".join(text.split())
    if len(text) <= max_chars:
        return text
    words = text.split(" ")
    best: Optional[list[str]] = None
    best_score = float("inf")
    for nlines in range(1, max_lines + 1):
        lines = _greedy_lines(words, nlines, max_chars)
        if not lines: continue
        if any(len(l) > max_chars for l in lines): continue
        diff = max(len(l) for l in lines) - min(len(l) for l in lines)
        if diff < best_score:
            best, best_score = lines, diff
    if best is None:
        out, cur = [], ""
        for w in words:
            if len(cur) + len(w) + 1 > max_chars:
                if cur: out.append(cur); cur = w
                else: out.append(w[:max_chars]); cur = w[max_chars:]
            else:
                cur = (cur + " " + w).strip()
        if cur: out.append(cur)
        best = out[:max_lines]
    return "\n".join(best)


def enforce(
    segments: list[Segment],
    *,
    max_cps: float = 17.0,
    max_duration: float = 7.0,
    min_duration: float = 0.83,
    max_chars: int = 42,
    max_lines: int = 2,
    min_gap: float = 0.04,
) -> list[Segment]:
    """Enforce reading-rate / duration / line-wrap / overlap constraints."""
    out: list[Segment] = []
    queue = [deepcopy(s) for s in segments]

    while queue:
        seg = queue.pop(0)
        update_cps(seg)
        dur = seg.end - seg.start

        if (seg.cps > max_cps or dur > max_duration) and seg.words and len(seg.words) > 1:
            half_idx = _midpoint_word(seg.words)
            a, b = _split_segment_at_word(seg, half_idx)
            queue.insert(0, b)
            queue.insert(0, a)
            continue

        seg.text = _wrap(seg.text, max_chars=max_chars, max_lines=max_lines)

        if dur < min_duration and queue:
            need = min_duration - dur
            nxt = queue[0]
            avail = max(0.0, nxt.start - seg.end - min_gap)
            grab = min(need, avail)
            seg.end += grab

        update_cps(seg)
        out.append(seg)

    # Trim overlaps and clamp word boundaries to the new segment end.
    for i in range(len(out) - 1):
        if out[i].end > out[i+1].start - min_gap:
            new_end = max(out[i].start + 0.1, out[i+1].start - min_gap)
            out[i].end = new_end
            for w in out[i].words:
                if w.end > new_end: w.end = new_end
                if w.start > new_end: w.start = new_end
            update_cps(out[i])

    # Defensive clamp for any edge case
    for s in out:
        for w in s.words:
            if w.start < s.start: w.start = s.start
            if w.end > s.end: w.end = s.end
            if w.end < w.start: w.end = w.start

    return out
