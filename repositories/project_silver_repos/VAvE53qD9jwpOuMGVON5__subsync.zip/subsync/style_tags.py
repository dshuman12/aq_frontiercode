"""Inline styling tag helpers for VTT / TTML / ASS.

Each writer has its own way of tagging emphasis / italics / colour, and
the IR (`Segment.text`) is plain text. This module is the single
translation table.
"""

from __future__ import annotations

import re
from typing import Optional, Tuple


# Sentinel inline-tag forms we accept in plain text. The pipeline keeps
# them invisible until a writer turns them into format-specific tags.
ITALIC_OPEN = "[[i]]"
ITALIC_CLOSE = "[[/i]]"
BOLD_OPEN = "[[b]]"
BOLD_CLOSE = "[[/b]]"
UNDERLINE_OPEN = "[[u]]"
UNDERLINE_CLOSE = "[[/u]]"


def to_vtt(text: str) -> str:
    """Plain-text + sentinel tags -> VTT inline tags."""
    return _replace(text, {
        ITALIC_OPEN: "<i>", ITALIC_CLOSE: "</i>",
        BOLD_OPEN: "<b>", BOLD_CLOSE: "</b>",
        UNDERLINE_OPEN: "<u>", UNDERLINE_CLOSE: "</u>",
    })


def to_ttml(text: str) -> str:
    """Plain-text + sentinel tags -> TTML inline tags."""
    return _replace(text, {
        ITALIC_OPEN: '<span tts:fontStyle="italic">',
        ITALIC_CLOSE: "</span>",
        BOLD_OPEN: '<span tts:fontWeight="bold">',
        BOLD_CLOSE: "</span>",
        UNDERLINE_OPEN: '<span tts:textDecoration="underline">',
        UNDERLINE_CLOSE: "</span>",
    })


def to_ass(text: str) -> str:
    """Plain-text + sentinel tags -> ASS override block ({\\i1}/{\\i0})."""
    return _replace(text, {
        ITALIC_OPEN: r"{\i1}", ITALIC_CLOSE: r"{\i0}",
        BOLD_OPEN: r"{\b1}", BOLD_CLOSE: r"{\b0}",
        UNDERLINE_OPEN: r"{\u1}", UNDERLINE_CLOSE: r"{\u0}",
    })


def to_plain(text: str) -> str:
    """Strip our sentinel tags, leaving only the visible text."""
    out = text
    for sentinel in (ITALIC_OPEN, ITALIC_CLOSE, BOLD_OPEN, BOLD_CLOSE,
                     UNDERLINE_OPEN, UNDERLINE_CLOSE):
        out = out.replace(sentinel, "")
    return out


def from_vtt(text: str) -> str:
    """Reverse of to_vtt - strip <i>/<b>/<u> tags into sentinel form."""
    return _replace(text, {
        "<i>": ITALIC_OPEN, "</i>": ITALIC_CLOSE,
        "<b>": BOLD_OPEN, "</b>": BOLD_CLOSE,
        "<u>": UNDERLINE_OPEN, "</u>": UNDERLINE_CLOSE,
    })


def from_ass(text: str) -> str:
    """Reverse of to_ass."""
    out = text
    for src, dst in {
        r"{\i1}": ITALIC_OPEN, r"{\i0}": ITALIC_CLOSE,
        r"{\b1}": BOLD_OPEN, r"{\b0}": BOLD_CLOSE,
        r"{\u1}": UNDERLINE_OPEN, r"{\u0}": UNDERLINE_CLOSE,
    }.items():
        out = out.replace(src, dst)
    # Drop any other override blocks we don't model.
    out = re.sub(r"\{[^}]*\}", "", out)
    return out


# -----------------------------------------------------------------------------
# Color span tagging
# -----------------------------------------------------------------------------

COLOR_OPEN_RE = re.compile(r"\[\[c=(#?[A-Za-z0-9]+)\]\]")
COLOR_CLOSE = "[[/c]]"


def open_color(text: str, color: str) -> str:
    return "[[c={}]]".format(color) + text + COLOR_CLOSE


def color_to_vtt(text: str) -> str:
    """[[c=red]]text[[/c]] -> <c.red>text</c>"""
    def repl(m):
        return "<c." + _color_class(m.group(1)) + ">"
    out = COLOR_OPEN_RE.sub(repl, text)
    out = out.replace(COLOR_CLOSE, "</c>")
    return out


def color_to_ass(text: str) -> str:
    """[[c=red]] -> {\\c&H0000FF&} (BGR order in ASS)"""
    def repl(m):
        bgr = _hex_to_ass_bgr(m.group(1))
        return r"{\c&H" + bgr + r"&}"
    out = COLOR_OPEN_RE.sub(repl, text)
    out = out.replace(COLOR_CLOSE, r"{\c}")
    return out


def color_to_ttml(text: str) -> str:
    def repl(m):
        return '<span tts:color="{}">'.format(_color_html(m.group(1)))
    out = COLOR_OPEN_RE.sub(repl, text)
    out = out.replace(COLOR_CLOSE, "</span>")
    return out


def _color_class(value: str) -> str:
    """For VTT, named CSS classes are easier to style at the player end."""
    if value.startswith("#"):
        return "x" + value[1:].lower()
    return value.lower()


def _hex_to_ass_bgr(value: str) -> str:
    if value.startswith("#"):
        h = value[1:]
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        if len(h) >= 6:
            r, g, b = h[0:2], h[2:4], h[4:6]
            return (b + g + r).upper()
    # Named colour; do a best-effort lookup.
    from .color_codes import name_to_hex
    return _hex_to_ass_bgr(name_to_hex(value))


def _color_html(value: str) -> str:
    if value.startswith("#"):
        return value
    from .color_codes import name_to_hex
    return name_to_hex(value)


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def _replace(text: str, table: dict) -> str:
    out = text
    for k, v in table.items():
        out = out.replace(k, v)
    return out


def has_styling(text: str) -> bool:
    return bool(COLOR_OPEN_RE.search(text)) or any(
        sentinel in text for sentinel in (
            ITALIC_OPEN, ITALIC_CLOSE, BOLD_OPEN, BOLD_CLOSE,
            UNDERLINE_OPEN, UNDERLINE_CLOSE,
        )
    )
