"""Tiny benchmarking helpers."""

from __future__ import annotations

import gc
import json
import statistics
import time
from typing import Any, Callable, Dict, List, Optional


class BenchmarkResult:
    def __init__(self, name: str, runs: List[float],
                 step_runs: Optional[Dict[str, List[float]]] = None):
        self.name = name
        self.runs = sorted(runs)
        self.step_runs = step_runs or {}

    @property
    def total(self) -> float:
        return sum(self.runs)

    @property
    def mean(self) -> float:
        return statistics.fmean(self.runs) if self.runs else 0.0

    @property
    def median(self) -> float:
        return statistics.median(self.runs) if self.runs else 0.0

    @property
    def p95(self) -> float:
        if not self.runs:
            return 0.0
        idx = max(0, int(len(self.runs) * 0.95) - 1)
        return self.runs[idx]

    @property
    def stdev(self) -> float:
        return statistics.stdev(self.runs) if len(self.runs) > 1 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name, "runs": self.runs,
            "total": self.total, "mean": self.mean, "median": self.median,
            "p95": self.p95, "stdev": self.stdev,
        }

    def report(self) -> str:
        return ("{name}: runs={n} total={total:.3f}s mean={mean:.3f}s "
                "median={med:.3f}s p95={p95:.3f}s sd={sd:.3f}").format(
            name=self.name, n=len(self.runs), total=self.total,
            mean=self.mean, med=self.median, p95=self.p95, sd=self.stdev)


def benchmark(fn: Callable[[], Any], runs: int = 5,
              name: Optional[str] = None,
              warmup: int = 1) -> BenchmarkResult:
    name = name or getattr(fn, "__name__", "anon")
    for _ in range(max(0, warmup)):
        try:
            fn()
        except Exception:
            pass
    samples: List[float] = []
    for _ in range(runs):
        gc.collect()
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return BenchmarkResult(name, samples)


def benchmark_many(funcs: Dict[str, Callable[[], Any]],
                   runs: int = 5, warmup: int = 1) -> List[BenchmarkResult]:
    return [benchmark(fn, runs=runs, name=n, warmup=warmup) for n, fn in funcs.items()]


def write_report(results: List[BenchmarkResult], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([r.to_dict() for r in results], f, indent=2)


def print_table(results: List[BenchmarkResult]) -> None:
    rows = [("name", "runs", "median (s)", "p95 (s)", "total (s)")]
    for r in results:
        rows.append((r.name, str(len(r.runs)),
                     "{:.3f}".format(r.median), "{:.3f}".format(r.p95),
                     "{:.3f}".format(r.total)))
    widths = [max(len(row[c]) for row in rows) for c in range(5)]
    for i, row in enumerate(rows):
        cells = ["{:<{w}}".format(row[c], w=widths[c]) for c in range(5)]
        print(" | ".join(cells))
        if i == 0:
            print("-+-".join("-" * w for w in widths))
