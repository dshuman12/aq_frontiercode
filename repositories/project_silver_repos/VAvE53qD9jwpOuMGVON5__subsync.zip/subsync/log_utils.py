"""Shared logger setup.

We avoid `logging.basicConfig()` because the GUI installs its own
handlers and basicConfig would silently no-op afterward.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import List, Optional

DEFAULT_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
DEFAULT_DATEFMT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str = "subsync") -> logging.Logger:
    log = logging.getLogger(name)
    if not getattr(log, "_subsync_configured", False):
        _configure(log)
        log._subsync_configured = True  # type: ignore
    return log


def _configure(log: logging.Logger) -> None:
    if log.handlers:
        return
    h = logging.StreamHandler(sys.stderr)
    h.setFormatter(logging.Formatter(DEFAULT_FORMAT, DEFAULT_DATEFMT))
    log.addHandler(h)
    level = os.environ.get("SUBSYNC_LOG", "INFO").upper()
    log.setLevel(getattr(logging, level, logging.INFO))
    log.propagate = False


def add_file_handler(path: str, level: str = "DEBUG",
                     logger: Optional[logging.Logger] = None) -> logging.Handler:
    log = logger or get_logger()
    h = logging.FileHandler(path)
    h.setFormatter(logging.Formatter(DEFAULT_FORMAT, DEFAULT_DATEFMT))
    h.setLevel(getattr(logging, level.upper(), logging.DEBUG))
    log.addHandler(h)
    return h


def remove_handler(handler: logging.Handler,
                   logger: Optional[logging.Logger] = None) -> None:
    log = logger or get_logger()
    log.removeHandler(handler)


def set_level(level: str, logger: Optional[logging.Logger] = None) -> None:
    log = logger or get_logger()
    log.setLevel(getattr(logging, level.upper(), logging.INFO))


class CapturedRecords:
    def __init__(self, logger_name: str = "subsync",
                 level: int = logging.WARNING):
        self.logger_name = logger_name
        self.level = level
        self.records: List[logging.LogRecord] = []
        self._handler: Optional[logging.Handler] = None
        self._previous_level: Optional[int] = None

    def __enter__(self) -> "CapturedRecords":
        log = logging.getLogger(self.logger_name)
        self._previous_level = log.level
        log.setLevel(min(log.level, self.level))
        records_ref = self.records

        class _CaptureHandler(logging.Handler):
            def emit(self, rec):
                records_ref.append(rec)

        self._handler = _CaptureHandler(level=self.level)
        log.addHandler(self._handler)
        return self

    def __exit__(self, *exc):
        log = logging.getLogger(self.logger_name)
        if self._handler is not None:
            log.removeHandler(self._handler)
        if self._previous_level is not None:
            log.setLevel(self._previous_level)

    def messages(self) -> List[str]:
        return [r.getMessage() for r in self.records]

    def has_message(self, snippet: str) -> bool:
        return any(snippet in m for m in self.messages())
