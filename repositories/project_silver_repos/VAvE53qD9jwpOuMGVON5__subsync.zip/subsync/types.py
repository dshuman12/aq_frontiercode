"""Core data types shared across the pipeline."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Word:
    start: float
    end: float
    text: str
    prob: float = 1.0
    speaker: Optional[str] = None


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)
    avg_logprob: float = 0.0
    no_speech_prob: float = 0.0
    speaker: Optional[str] = None
    translations: dict[str, str] = field(default_factory=dict)  # {lang_code: text}
    cps: float = 0.0  # characters per second

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Event:
    """A non-speech audio event such as music, laughter, applause."""
    start: float
    end: float
    label: str          # e.g. "Music", "Laughter", "Applause"
    confidence: float


@dataclass
class Turn:
    """A speaker turn from diarization."""
    start: float
    end: float
    speaker: str        # e.g. "SPEAKER_01"


@dataclass
class Transcript:
    language: str
    duration: float
    segments: list[Segment] = field(default_factory=list)
    events: list[Event] = field(default_factory=list)
    speakers: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "language": self.language,
            "duration": self.duration,
            "speakers": self.speakers,
            "events": [asdict(e) for e in self.events],
            "segments": [s.to_dict() for s in self.segments],
        }
