"""Package transcripts for delivery to a platform.

Each delivery target is a small recipe: which formats to emit, what file
naming convention to use, what QC rules to enforce before allowing the
package to be written.
"""

from __future__ import annotations

import os
import json
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .types import Transcript
from .formats import dispatch, srt, vtt, ass, ttml, scc
from .qc import run_for_preset, QcReport
from .language_codes import file_suffix


@dataclass
class DeliveryRecipe:
    name: str
    description: str
    formats: List[str] = field(default_factory=lambda: ["srt"])
    naming: str = "{stem}{lang_suffix}.{ext}"
    preset: str = "default"
    require_qc_clean: bool = False


RECIPES: Dict[str, DeliveryRecipe] = {
    "netflix-adult": DeliveryRecipe(
        name="netflix-adult",
        description="Netflix English (adult): TTML primary + SRT companion.",
        formats=["ttml", "srt"],
        preset="netflix-adult",
        require_qc_clean=True,
    ),
    "netflix-kids": DeliveryRecipe(
        name="netflix-kids",
        description="Netflix kids variant.",
        formats=["ttml", "srt"],
        preset="netflix-kids",
        require_qc_clean=True,
    ),
    "bbc-online": DeliveryRecipe(
        name="bbc-online",
        description="BBC iPlayer / online: TTML 1.0.",
        formats=["ttml", "srt"],
        preset="bbc-online",
    ),
    "youtube": DeliveryRecipe(
        name="youtube",
        description="YouTube creator upload: SRT + VTT.",
        formats=["srt", "vtt"],
        preset="youtube",
    ),
    "us-broadcast": DeliveryRecipe(
        name="us-broadcast",
        description="US broadcast: SCC + TTML for backup.",
        formats=["scc", "ttml"],
        preset="us-broadcast-30df",
    ),
    "general": DeliveryRecipe(
        name="general",
        description="One-of-everything for archival.",
        formats=["srt", "vtt", "ass", "ttml"],
        preset="default",
    ),
}


def get_recipe(name: str) -> DeliveryRecipe:
    if name not in RECIPES:
        raise KeyError("no recipe named {!r}; have: {}".format(
            name, ", ".join(sorted(RECIPES))))
    return RECIPES[name]


def build_package(transcript: Transcript,
                  output_dir: str,
                  recipe_name: str,
                  stem: str,
                  language: Optional[str] = None) -> Dict[str, str]:
    """Write all the recipe's formats into output_dir. Returns a dict of
    {format: path} for the files actually produced."""
    recipe = get_recipe(recipe_name)
    rpt = run_for_preset(transcript, recipe.preset)
    if recipe.require_qc_clean and not rpt.is_clean:
        raise RuntimeError("QC failed for recipe {}: {} error(s)".format(
            recipe_name, len(rpt.errors)))
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    lang_suffix = file_suffix(language or transcript.language) if (language or transcript.language) else ""
    produced: Dict[str, str] = {}
    for fmt in recipe.formats:
        ext = "." + fmt
        name = recipe.naming.format(stem=stem, lang_suffix=lang_suffix, ext=fmt)
        target = out / name
        _write_format(transcript, target, fmt)
        produced[fmt] = str(target)
    _write_manifest(out, stem, language or transcript.language, recipe, produced, rpt)
    return produced


def _write_format(t: Transcript, path: Path, fmt: str) -> None:
    fmt = fmt.lower()
    if fmt == "srt":
        srt.write(t, str(path))
    elif fmt in ("vtt", "webvtt"):
        vtt.write(t, str(path))
    elif fmt in ("ass", "ssa"):
        ass.write(t, str(path))
    elif fmt in ("ttml", "dfxp"):
        ttml.write(t, str(path))
    elif fmt == "scc":
        scc.write(t, str(path))
    else:
        raise ValueError("unknown format: {}".format(fmt))


def _write_manifest(out_dir: Path, stem: str, language: str,
                    recipe: DeliveryRecipe, produced: Dict[str, str],
                    rpt: QcReport) -> None:
    manifest = {
        "stem": stem,
        "language": language,
        "recipe": recipe.name,
        "preset": recipe.preset,
        "files": {fmt: os.path.basename(p) for fmt, p in produced.items()},
        "qc": {
            "errors": len(rpt.errors),
            "warnings": len(rpt.warnings),
            "is_clean": rpt.is_clean,
        },
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))


def package_to_zip(transcript: Transcript,
                   zip_path: str,
                   recipe_name: str,
                   stem: str,
                   language: Optional[str] = None) -> str:
    """Build the package in a temp dir and zip it. Returns the zip path."""
    tmp = Path(zip_path).with_suffix(".tmp.dir")
    if tmp.exists():
        shutil.rmtree(tmp)
    try:
        produced = build_package(transcript, str(tmp), recipe_name, stem, language)
        with zipfile.ZipFile(zip_path, "w") as z:
            for p in tmp.iterdir():
                z.write(str(p), arcname=p.name)
    finally:
        if tmp.exists():
            shutil.rmtree(tmp)
    return zip_path


def list_recipes() -> List[str]:
    return sorted(RECIPES.keys())
