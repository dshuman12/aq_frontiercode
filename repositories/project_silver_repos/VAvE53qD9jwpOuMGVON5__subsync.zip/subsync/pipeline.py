"""End-to-end orchestrator: media → transcript → enrichments → exports."""
from __future__ import annotations
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Sequence

from .types import Transcript
from . import media, transcribe as _trans, align as _align, tag as _tag
from . import diarize as _diar, translate as _tr, cps as _cps
from . import export as _ex, ccsl as _ccsl, broadcast as _bc


@dataclass
class Options:
    input: Path
    out_dir: Path
    stem: str
    model: str = "large-v3"
    language: Optional[str] = None
    vad: bool = True
    align: bool = False
    beam: int = 5
    compute: str = "auto"
    device: str = "auto"
    diarize: bool = False
    hf_token: Optional[str] = None
    num_speakers: Optional[int] = None
    min_speakers: Optional[int] = None
    max_speakers: Optional[int] = None
    tag_events: bool = False
    tag_threshold: float = 0.30
    translate_to: list[str] = field(default_factory=list)
    translate_model: str = "facebook/nllb-200-distilled-600M"
    apply_cps: bool = True
    max_cps: float = 17.0
    max_dur: float = 7.0
    min_dur: float = 0.83
    max_chars: int = 42
    max_lines: int = 2
    speaker_prefix: bool = True
    write_ccsl: bool = False
    ccsl_fps: float = 25.0
    extra_formats: list[str] = field(default_factory=list)   # ttml, ebu, scc, sbv, sami
    fps: int = 25
    keep_audio: bool = False
    title: str = ""


def run(opts: Options) -> Transcript:
    src = opts.input.resolve()
    if not src.exists():
        sys.exit(f"error: input not found: {src}")
    opts.out_dir.mkdir(parents=True, exist_ok=True)

    work_audio = opts.out_dir / f"{opts.stem}.subsync.wav"
    media.extract_audio(src, work_audio)
    duration = media.duration(src) or media.duration(work_audio)

    segments, language = _trans.transcribe(
        work_audio,
        model_name=opts.model, language=opts.language,
        vad=opts.vad, beam_size=opts.beam,
        compute_type=opts.compute, device=opts.device,
    )

    if opts.align:
        segments = _align.align(work_audio, segments, language=language, model_name=opts.model)

    speakers: list[str] = []
    if opts.diarize:
        try:
            turns = _diar.diarize(
                work_audio,
                hf_token=opts.hf_token,
                num_speakers=opts.num_speakers,
                min_speakers=opts.min_speakers,
                max_speakers=opts.max_speakers,
                device=opts.device,
            )
            speakers = _diar.assign_speakers(segments, turns)
        except Exception as e:
            # Diarization is optional - never let it kill an otherwise-successful run.
            print(f"[subsync] diarization crashed ({type(e).__name__}: {e}); "
                  f"continuing without speaker labels", file=sys.stderr)
            speakers = []

    events = []
    if opts.tag_events:
        events = _tag.detect(
            work_audio, segments, duration,
            threshold=opts.tag_threshold,
            device=opts.device,
        )

    if opts.apply_cps:
        segments = _cps.enforce(
            segments,
            max_cps=opts.max_cps, max_duration=opts.max_dur, min_duration=opts.min_dur,
            max_chars=opts.max_chars, max_lines=opts.max_lines,
        )
    for s in segments:
        _cps.update_cps(s)

    if opts.translate_to:
        _tr.translate(
            segments,
            source=language,
            targets=opts.translate_to,
            model_name=opts.translate_model,
            device=opts.device,
        )

    transcript = Transcript(
        language=language, duration=duration,
        segments=segments, events=events, speakers=speakers,
    )

    base = opts.out_dir / opts.stem
    _ex.write_srt(transcript, base.with_suffix(".srt"),
                  speaker_prefix=opts.speaker_prefix, with_events=True)
    _ex.write_vtt(transcript, base.with_suffix(".vtt"),
                  speaker_prefix=opts.speaker_prefix, with_events=True)
    _ex.write_json(transcript, base.parent / f"{opts.stem}.subs.json")

    if opts.translate_to:
        _ex.write_translations(transcript, opts.out_dir, opts.stem,
                               speaker_prefix=opts.speaker_prefix, with_events=True)

    # Broadcast / legacy formats
    title = opts.title or src.stem
    for fmt in opts.extra_formats:
        fmt = fmt.lower().lstrip(".")
        suffix_map = {"ttml":"ttml","dfxp":"dfxp","xml":"xml",
                      "ebu":"stl","stl":"stl","scc":"scc","sbv":"sbv","sami":"smi","smi":"smi"}
        ext = suffix_map.get(fmt, fmt)
        out_path = base.parent / f"{opts.stem}.{ext}"
        kwargs: dict = {"speaker_prefix": opts.speaker_prefix, "with_events": True}
        if fmt in ("ttml","dfxp","xml"): kwargs["frame_rate"] = opts.fps
        if fmt in ("ebu","stl"): kwargs.update(title=title, fps=opts.fps)
        if fmt in ("sami","smi"): kwargs["title"] = title
        _bc.export_format(transcript, fmt, out_path, **kwargs)

    if opts.write_ccsl:
        _ccsl.write_ccsl(transcript, base.parent / f"{opts.stem}.ccsl.docx",
                         title=title, fps=opts.ccsl_fps,
                         translation_lang=opts.translate_to[0] if opts.translate_to else None)

    if not opts.keep_audio:
        try: work_audio.unlink()
        except OSError: pass

    return transcript
