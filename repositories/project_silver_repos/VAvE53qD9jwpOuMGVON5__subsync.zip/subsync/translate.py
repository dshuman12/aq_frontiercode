"""
Local translation via Meta NLLB-200 (No Language Left Behind).

Default model: facebook/nllb-200-distilled-600M  (~2.4 GB on disk).
For higher quality on CPU/GPU you can switch to:
  - facebook/nllb-200-distilled-1.3B
  - facebook/nllb-200-3.3B
"""
from __future__ import annotations
import sys
from typing import Iterable, Optional

from .types import Segment

# ISO 639-1 → NLLB BCP-47-like script tag (the most common pairs)
NLLB_LANG: dict[str, str] = {
    "en": "eng_Latn", "es": "spa_Latn", "fr": "fra_Latn", "de": "deu_Latn",
    "it": "ita_Latn", "pt": "por_Latn", "nl": "nld_Latn", "pl": "pol_Latn",
    "ru": "rus_Cyrl", "uk": "ukr_Cyrl", "tr": "tur_Latn", "ar": "arb_Arab",
    "he": "heb_Hebr", "fa": "pes_Arab", "ur": "urd_Arab", "hi": "hin_Deva",
    "bn": "ben_Beng", "ta": "tam_Taml", "te": "tel_Telu", "ml": "mal_Mlym",
    "mr": "mar_Deva", "gu": "guj_Gujr", "pa": "pan_Guru", "kn": "kan_Knda",
    "zh": "zho_Hans", "zh-tw": "zho_Hant", "ja": "jpn_Jpan", "ko": "kor_Hang",
    "vi": "vie_Latn", "th": "tha_Thai", "id": "ind_Latn", "ms": "zsm_Latn",
    "tl": "tgl_Latn", "sw": "swh_Latn", "yo": "yor_Latn", "ig": "ibo_Latn",
    "ha": "hau_Latn", "zu": "zul_Latn", "am": "amh_Ethi",
    "el": "ell_Grek", "cs": "ces_Latn", "sk": "slk_Latn", "sl": "slv_Latn",
    "ro": "ron_Latn", "hu": "hun_Latn", "fi": "fin_Latn", "sv": "swe_Latn",
    "da": "dan_Latn", "no": "nob_Latn", "is": "isl_Latn", "et": "est_Latn",
    "lv": "lvs_Latn", "lt": "lit_Latn", "bg": "bul_Cyrl", "sr": "srp_Cyrl",
    "hr": "hrv_Latn", "bs": "bos_Latn", "mk": "mkd_Cyrl", "sq": "als_Latn",
    "ca": "cat_Latn", "gl": "glg_Latn", "eu": "eus_Latn", "ga": "gle_Latn",
    "cy": "cym_Latn",
}


def _resolve(code: str) -> str:
    code = code.lower().replace("_", "-")
    if code in NLLB_LANG: return NLLB_LANG[code]
    if "-" in code and code.split("-")[0] in NLLB_LANG: return NLLB_LANG[code.split("-")[0]]
    raise ValueError(f"Unsupported language code: {code!r}. See subsync/translate.py for options.")


def translate(
    segments: list[Segment],
    *,
    source: str,
    targets: Iterable[str],
    model_name: str = "facebook/nllb-200-distilled-600M",
    batch_size: int = 16,
    max_length: int = 512,
    device: str = "auto",
) -> list[Segment]:
    """
    Translate each segment's text into every target language.
    Mutates and returns the same segments list (segment.translations[lang] = text).
    """
    targets = list(targets)
    if not targets:
        return segments
    try:
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
    except ImportError:
        print("[subsync] transformers not installed; skipping translation", file=sys.stderr)
        return segments

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    src_tag = _resolve(source)
    tgt_tags = {t: _resolve(t) for t in targets}

    print(f"[subsync] loading translator: {model_name} on {device}", file=sys.stderr)
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(device).eval()

    texts = [s.text for s in segments]

    for tgt_code, tgt_tag in tgt_tags.items():
        print(f"[subsync] translating → {tgt_code} ({tgt_tag})", file=sys.stderr)
        tok.src_lang = src_tag
        bos = tok.convert_tokens_to_ids(tgt_tag)
        results: list[str] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i+batch_size]
            inputs = tok(batch, return_tensors="pt", padding=True, truncation=True,
                         max_length=max_length).to(device)
            with torch.no_grad():
                out = model.generate(
                    **inputs,
                    forced_bos_token_id=bos,
                    max_length=max_length,
                    num_beams=4,
                    no_repeat_ngram_size=3,
                )
            results.extend(tok.batch_decode(out, skip_special_tokens=True))
        for seg, txt in zip(segments, results):
            seg.translations[tgt_code] = txt.strip()

    return segments
