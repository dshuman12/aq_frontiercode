"""SMPTE timecode helpers.

Subtitling pipelines bounce between three time representations:

  - **seconds**             float, what the model outputs
  - **HH:MM:SS,mmm**        SRT / EBU-style fractional second
  - **HH:MM:SS:FF**         SMPTE non-drop frame (NDF), needed for CCSL,
                            broadcast specs, and most editorial workflows.
                            Also a drop-frame (DF) variant for 29.97/59.94.

The conversions look trivial but the corner cases (drop-frame counts, NDF
rollovers near integer seconds, frame rounding) are exactly what trips up
hand-rolled converters in the wild. Test coverage is in
tests/test_timecode.py.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Optional


# Common broadcast frame rates. Drop-frame applies to 29.97 and 59.94.
RATE_FILM = 24.0
RATE_PAL = 25.0
RATE_NTSC_NDF = 30.0
RATE_NTSC_DF = 30000.0 / 1001.0   # 29.97
RATE_HFR_NTSC_DF = 60000.0 / 1001.0  # 59.94
RATE_HFR_FILM = 48.0


def is_drop_frame(rate: float) -> bool:
    """True if a frame rate uses SMPTE drop-frame counting."""
    if abs(rate - RATE_NTSC_DF) < 1e-3:
        return True
    if abs(rate - RATE_HFR_NTSC_DF) < 1e-3:
        return True
    return False


def total_frames(seconds: float, rate: float) -> int:
    """Convert seconds to a frame count rounded to nearest frame."""
    if seconds < 0:
        seconds = 0.0
    return int(round(seconds * rate))


def seconds_to_smpte(seconds: float, rate: float = RATE_PAL,
                     drop: Optional[bool] = None) -> str:
    """seconds -> 'HH:MM:SS:FF'. drop_frame inferred from rate if None."""
    if drop is None:
        drop = is_drop_frame(rate)
    frames = total_frames(seconds, rate)
    if drop:
        return _frames_to_df_smpte(frames, rate)
    return _frames_to_ndf_smpte(frames, rate)


def smpte_to_seconds(timecode: str, rate: float = RATE_PAL,
                     drop: Optional[bool] = None) -> float:
    """'HH:MM:SS:FF' or 'HH:MM:SS;FF' -> seconds (the ';' implies drop-frame)."""
    if drop is None:
        drop = is_drop_frame(rate) or ";" in timecode
    parts = re.split(r"[:;]", timecode.strip())
    if len(parts) != 4:
        raise ValueError("invalid SMPTE timecode: {!r}".format(timecode))
    hh, mm, ss, ff = (int(p) for p in parts)
    if drop:
        frames = _df_smpte_to_frames(hh, mm, ss, ff, rate)
    else:
        per_sec = int(round(rate))
        frames = ff + per_sec * (ss + 60 * (mm + 60 * hh))
    return frames / rate


def seconds_to_srt(seconds: float) -> str:
    """seconds -> 'HH:MM:SS,mmm' as used by SRT and SBV."""
    if seconds < 0:
        seconds = 0.0
    ms_total = int(round(seconds * 1000.0))
    hh = ms_total // 3_600_000
    rem = ms_total % 3_600_000
    mm = rem // 60_000
    rem %= 60_000
    ss = rem // 1000
    ms = rem % 1000
    return "{:02d}:{:02d}:{:02d},{:03d}".format(hh, mm, ss, ms)


def seconds_to_vtt(seconds: float) -> str:
    """seconds -> 'HH:MM:SS.mmm' as used by WebVTT."""
    return seconds_to_srt(seconds).replace(",", ".")


def srt_to_seconds(s: str) -> float:
    """'HH:MM:SS,mmm' or 'HH:MM:SS.mmm' -> seconds."""
    cleaned = s.strip().replace(",", ".")
    parts = cleaned.split(":")
    if len(parts) != 3:
        raise ValueError("invalid SRT timecode: {!r}".format(s))
    hh, mm, ss_ms = parts
    return int(hh) * 3600 + int(mm) * 60 + float(ss_ms)


# -----------------------------------------------------------------------------
# Internal: drop-frame and NDF conversions
# -----------------------------------------------------------------------------

def _frames_to_ndf_smpte(frames: int, rate: float) -> str:
    per_sec = int(round(rate))
    if per_sec <= 0:
        per_sec = 1
    ff = frames % per_sec
    seconds_total = frames // per_sec
    hh = seconds_total // 3600
    mm = (seconds_total % 3600) // 60
    ss = seconds_total % 60
    return "{:02d}:{:02d}:{:02d}:{:02d}".format(hh, mm, ss, ff)


def _frames_to_df_smpte(frames: int, rate: float) -> str:
    """SMPTE 12M drop-frame counting. Used at 29.97 / 59.94."""
    df_per_min = 2 if abs(rate - RATE_NTSC_DF) < 1.0 else 4
    frames_per_10min = int(round(rate * 60 * 10))
    frames_per_min = int(round(rate * 60)) - df_per_min
    d = frames // frames_per_10min
    m = frames % frames_per_10min
    if m > df_per_min:
        frames += df_per_min * 9 * d + df_per_min * ((m - df_per_min) // frames_per_min)
    else:
        frames += df_per_min * 9 * d
    per_sec = int(round(rate))
    ff = frames % per_sec
    seconds_total = frames // per_sec
    hh = seconds_total // 3600
    mm = (seconds_total % 3600) // 60
    ss = seconds_total % 60
    return "{:02d}:{:02d}:{:02d};{:02d}".format(hh, mm, ss, ff)


def _df_smpte_to_frames(hh: int, mm: int, ss: int, ff: int, rate: float) -> int:
    df_per_min = 2 if abs(rate - RATE_NTSC_DF) < 1.0 else 4
    per_sec = int(round(rate))
    total_minutes = hh * 60 + mm
    frames = (per_sec * 3600 * hh) + (per_sec * 60 * mm) + (per_sec * ss) + ff
    frames -= df_per_min * (total_minutes - total_minutes // 10)
    return frames


# -----------------------------------------------------------------------------
# Frame-aware rounding utilities
# -----------------------------------------------------------------------------

def quantize_to_frame(seconds: float, rate: float = RATE_PAL) -> float:
    """Snap seconds to the nearest frame boundary. Stops sub-frame drift."""
    return total_frames(seconds, rate) / rate


def quantize_segment(start: float, end: float,
                     rate: float = RATE_PAL,
                     min_frames: int = 1) -> tuple:
    """Snap (start, end) and ensure end >= start + min_frames frames."""
    s = quantize_to_frame(start, rate)
    e = quantize_to_frame(end, rate)
    min_dur = min_frames / rate
    if e - s < min_dur:
        e = s + min_dur
    return (s, e)


def add_offset(seconds: float, offset_frames: int, rate: float = RATE_PAL) -> float:
    return seconds + offset_frames / rate


# -----------------------------------------------------------------------------
# Frame range helpers
# -----------------------------------------------------------------------------

@dataclass
class FrameRange:
    start_frame: int
    end_frame: int   # exclusive
    rate: float

    def duration_seconds(self) -> float:
        return (self.end_frame - self.start_frame) / self.rate

    def overlaps(self, other: "FrameRange") -> bool:
        return self.start_frame < other.end_frame and other.start_frame < self.end_frame

    def contains(self, frame: int) -> bool:
        return self.start_frame <= frame < self.end_frame

    def union(self, other: "FrameRange") -> "FrameRange":
        return FrameRange(min(self.start_frame, other.start_frame),
                          max(self.end_frame, other.end_frame), self.rate)


def merge_frame_ranges(ranges: list) -> list:
    """Merge overlapping/touching FrameRanges. Output is sorted."""
    if not ranges:
        return []
    items = sorted(ranges, key=lambda r: r.start_frame)
    merged = [items[0]]
    for r in items[1:]:
        last = merged[-1]
        if r.start_frame <= last.end_frame:
            merged[-1] = FrameRange(last.start_frame,
                                    max(last.end_frame, r.end_frame),
                                    last.rate)
        else:
            merged.append(r)
    return merged
