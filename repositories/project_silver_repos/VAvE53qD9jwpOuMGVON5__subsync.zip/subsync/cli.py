"""Command-line entry point."""
from __future__ import annotations
import argparse, sys
from pathlib import Path
from typing import Optional

from . import media, burn as _burn
from .pipeline import Options, run as run_pipeline
from .ccsl import write_ccsl
from .types import Transcript


def cmd_transcribe(args: argparse.Namespace) -> int:
    src = Path(args.input).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve() if args.out_dir else src.parent
    targets = [t.strip() for t in (args.translate or "").split(",") if t.strip()]
    extra_fmts = [f.strip() for f in (args.formats or "").split(",") if f.strip()]

    opts = Options(
        input=src, out_dir=out_dir, stem=src.stem,
        model=args.model, language=None if args.lang == "auto" else args.lang,
        vad=args.vad, align=args.align, beam=args.beam, compute=args.compute, device=args.device,
        diarize=args.diarize, hf_token=args.hf_token,
        num_speakers=args.num_speakers, min_speakers=args.min_speakers, max_speakers=args.max_speakers,
        tag_events=args.tag, tag_threshold=args.tag_threshold,
        translate_to=targets, translate_model=args.translate_model,
        apply_cps=not args.no_cps,
        max_cps=args.max_cps, max_dur=args.max_dur, min_dur=args.min_dur,
        max_chars=args.max_chars, max_lines=args.max_lines,
        speaker_prefix=args.speaker_prefix,
        write_ccsl=args.ccsl, ccsl_fps=args.ccsl_fps, title=args.title or "",
        extra_formats=extra_fmts, fps=args.fps,
        keep_audio=args.keep_audio,
    )
    t = run_pipeline(opts)

    print(f"\n[subsync] done — {len(t.segments)} cues, {len(t.events)} events, {len(t.speakers)} speakers", file=sys.stderr)
    base = out_dir / src.stem
    print(f"  SRT  → {base.with_suffix('.srt')}")
    print(f"  VTT  → {base.with_suffix('.vtt')}")
    print(f"  JSON → {base.parent / (src.stem + '.subs.json')}")
    if targets:
        for tgt in targets:
            print(f"  {tgt.upper()} SRT → {out_dir / (src.stem + f'.{tgt}.srt')}")
    if extra_fmts:
        for f in extra_fmts:
            print(f"  {f.upper()} → wrote (see folder)")
    if args.ccsl:
        print(f"  CCSL → {base.parent / (src.stem + '.ccsl.docx')}")
    return 0


def cmd_burn(args: argparse.Namespace) -> int:
    video = Path(args.video).expanduser().resolve()
    srt = Path(args.srt).expanduser().resolve()
    if not video.exists(): sys.exit(f"error: video not found: {video}")
    if not srt.exists(): sys.exit(f"error: srt not found: {srt}")
    out = (Path(args.out).expanduser().resolve()
           if args.out else video.with_name(f"{video.stem}.subbed{video.suffix}"))
    _burn.burn(video, srt, out, style=args.style, crf=args.crf, preset=args.preset)
    print(f"[subsync] wrote {out}")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    src = Path(args.input).expanduser().resolve()
    data = media.probe(src)
    fmt = data.get("format", {})
    streams = data.get("streams", [])
    print(f"file:     {src.name}")
    print(f"duration: {float(fmt.get('duration', 0)):.2f} s")
    print(f"size:     {int(fmt.get('size', 0)) / 1_000_000:.2f} MB")
    for s in streams:
        if s.get("codec_type") == "video":
            print(f"video:    {s.get('codec_name')} {s.get('width')}x{s.get('height')} @ {s.get('r_frame_rate')}")
        elif s.get("codec_type") == "audio":
            print(f"audio:    {s.get('codec_name')} {s.get('sample_rate')}Hz {s.get('channels')}ch")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="subsync",
        description="High-grade video/audio subtitling pipeline.")
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("transcribe", help="Transcribe + enrich + export")
    t.add_argument("input")
    t.add_argument("--out-dir", default=None)
    t.add_argument("--title", default=None)

    g = t.add_argument_group("transcription")
    g.add_argument("--model", default="large-v3")
    g.add_argument("--lang", default="auto")
    g.add_argument("--vad", action="store_true", default=True)
    g.add_argument("--no-vad", dest="vad", action="store_false")
    g.add_argument("--align", action="store_true")
    g.add_argument("--beam", type=int, default=5)
    g.add_argument("--compute", default="auto")
    g.add_argument("--device", default="auto")

    g = t.add_argument_group("speakers")
    g.add_argument("--diarize", action="store_true")
    g.add_argument("--hf-token", default=None)
    g.add_argument("--num-speakers", type=int, default=None)
    g.add_argument("--min-speakers", type=int, default=None)
    g.add_argument("--max-speakers", type=int, default=None)
    g.add_argument("--no-speaker-prefix", dest="speaker_prefix", action="store_false", default=True)

    g = t.add_argument_group("non-speech events")
    g.add_argument("--tag", action="store_true")
    g.add_argument("--tag-threshold", type=float, default=0.30)

    g = t.add_argument_group("translation")
    g.add_argument("--translate", default=None,
                   help="Comma-separated target languages, e.g. 'es,fr,yo'")
    g.add_argument("--translate-model", default="facebook/nllb-200-distilled-600M")

    g = t.add_argument_group("reading-rate guards")
    g.add_argument("--no-cps", action="store_true")
    g.add_argument("--max-cps", type=float, default=17.0)
    g.add_argument("--max-dur", type=float, default=7.0)
    g.add_argument("--min-dur", type=float, default=0.83)
    g.add_argument("--max-chars", type=int, default=42)
    g.add_argument("--max-lines", type=int, default=2)

    g = t.add_argument_group("broadcast / extra formats")
    g.add_argument("--formats", default=None,
                   help="Comma-separated extra formats: ttml, ebu, scc, sbv, sami "
                        "(srt, vtt, json are always written)")
    g.add_argument("--fps", type=int, default=25,
                   help="Frame rate for SMPTE-timecoded formats (TTML, EBU-STL). "
                        "SCC always uses 29.97 drop-frame.")

    g = t.add_argument_group("ccsl")
    g.add_argument("--ccsl", action="store_true")
    g.add_argument("--ccsl-fps", type=float, default=25.0)

    t.add_argument("--keep-audio", action="store_true")
    t.set_defaults(func=cmd_transcribe)

    b = sub.add_parser("burn", help="Burn an SRT into a video")
    b.add_argument("video")
    b.add_argument("srt")
    b.add_argument("--out", default=None)
    b.add_argument("--style", choices=list(_burn.STYLES), default="cinema")
    b.add_argument("--crf", type=int, default=18)
    b.add_argument("--preset", default="medium")
    b.set_defaults(func=cmd_burn)

    i = sub.add_parser("info", help="ffprobe summary")
    i.add_argument("input")
    i.set_defaults(func=cmd_info)

    return p


_KNOWN_CMDS = {"transcribe", "burn", "info", "gui", "-h", "--help"}


def _looks_like_a_media_file(arg: str) -> bool:
    """Heuristic: is this a path to an existing file? Used to detect drag-onto-exe."""
    if not arg or arg.startswith("-"):
        return False
    try:
        return Path(arg).expanduser().is_file()
    except OSError:
        return False


def main(argv: Optional[list[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    # Double-clicked exe (no args) -> launch GUI.
    if not argv:
        from .gui import launch_gui
        return launch_gui()

    # Explicit GUI launch.
    if argv[0] == "gui":
        from .gui import launch_gui
        return launch_gui(initial_file=argv[1] if len(argv) > 1 else None)

    # First arg is a known subcommand -> CLI mode.
    if argv[0] in _KNOWN_CMDS:
        args = build_parser().parse_args(argv)
        return args.func(args)

    # First arg looks like a dragged file -> launch GUI pre-populated with it.
    if _looks_like_a_media_file(argv[0]):
        from .gui import launch_gui
        return launch_gui(initial_file=argv[0])

    # Anything else -> let argparse complain in the normal way.
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
