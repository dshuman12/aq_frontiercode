"""Helpers for the editorial workflow - hand-tweaks between automation passes."""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from .types import Transcript, Segment


def find_text(t: Transcript, query: str,
              case_sensitive: bool = False) -> List[Tuple[int, Segment]]:
    """Return [(index, segment), ...] for cues whose text contains query."""
    out: List[Tuple[int, Segment]] = []
    flags = 0 if case_sensitive else re.IGNORECASE
    pat = re.compile(re.escape(query), flags)
    for i, s in enumerate(t.segments):
        if pat.search(s.text or ""):
            out.append((i, s))
    return out


def replace_text(t: Transcript, before: str, after: str,
                 case_sensitive: bool = False) -> int:
    """Replace `before` with `after` across all cues. Returns count."""
    flags = 0 if case_sensitive else re.IGNORECASE
    pat = re.compile(re.escape(before), flags)
    n = 0
    for s in t.segments:
        new_text, count = pat.subn(after, s.text or "")
        if count:
            s.text = new_text
            n += count
    return n


def insert_cue(t: Transcript, index: int, seg: Segment) -> None:
    """Insert a new cue at position `index`. Adjacent cues are not retimed."""
    t.segments.insert(index, seg)


def delete_cue(t: Transcript, index: int) -> Segment:
    return t.segments.pop(index)


def split_cue(t: Transcript, index: int, at_seconds: float) -> None:
    """Split a cue at an absolute timestamp. The text is duplicated; clean
    up by hand afterwards."""
    if not (0 <= index < len(t.segments)):
        raise IndexError("cue index out of range")
    s = t.segments[index]
    if not (s.start < at_seconds < s.end):
        raise ValueError("split point must fall inside the cue")
    left = Segment(start=s.start, end=at_seconds, text=s.text, speaker=s.speaker)
    right = Segment(start=at_seconds, end=s.end, text=s.text, speaker=s.speaker)
    t.segments[index:index + 1] = [left, right]


def join_cues(t: Transcript, indices: List[int],
              joiner: str = " ") -> None:
    """Join two or more consecutive cues into one. `indices` must be
    contiguous."""
    if len(indices) < 2:
        raise ValueError("need at least two indices to join")
    indices = sorted(indices)
    for i in range(1, len(indices)):
        if indices[i] != indices[i - 1] + 1:
            raise ValueError("indices must be contiguous")
    first_idx = indices[0]
    last_idx = indices[-1]
    pieces = [(t.segments[i].text or "").strip() for i in indices]
    new_text = joiner.join(p for p in pieces if p)
    speaker = t.segments[first_idx].speaker
    new_seg = Segment(
        start=t.segments[first_idx].start,
        end=t.segments[last_idx].end,
        text=new_text,
        speaker=speaker,
    )
    t.segments[first_idx:last_idx + 1] = [new_seg]


def renumber(t: Transcript) -> None:
    """No-op for now - placeholder for when we add cue numbers."""
    pass


def find_overlaps(t: Transcript) -> List[Tuple[int, int]]:
    """Return [(i, j)] for adjacent cue indices that overlap."""
    out: List[Tuple[int, int]] = []
    for i in range(1, len(t.segments)):
        if t.segments[i].start < t.segments[i - 1].end:
            out.append((i - 1, i))
    return out


def find_short_cues(t: Transcript, min_duration: float = 0.833) -> List[int]:
    return [i for i, s in enumerate(t.segments)
            if (s.end - s.start) < min_duration]


def find_long_cues(t: Transcript, max_duration: float = 7.0) -> List[int]:
    return [i for i, s in enumerate(t.segments)
            if (s.end - s.start) > max_duration]


def cps_per_cue(t: Transcript) -> List[float]:
    out = []
    for s in t.segments:
        dur = max(1e-9, s.end - s.start)
        out.append(len((s.text or "")) / dur)
    return out


def speakers_in_use(t: Transcript) -> List[str]:
    seen = []
    for s in t.segments:
        if s.speaker and s.speaker not in seen:
            seen.append(s.speaker)
    return seen


def rename_speaker(t: Transcript, before: str, after: str) -> int:
    n = 0
    for s in t.segments:
        if s.speaker == before:
            s.speaker = after
            n += 1
    return n


def offset_speaker(t: Transcript, speaker: str, seconds: float) -> int:
    """Shift only cues belonging to `speaker`. Used when one mic was
    consistently off by a known amount."""
    n = 0
    for s in t.segments:
        if s.speaker == speaker:
            s.start = max(0.0, s.start + seconds)
            s.end = max(0.0, s.end + seconds)
            n += 1
    return n
