"""python -m subsync entry point."""
from .cli import main
raise SystemExit(main())
