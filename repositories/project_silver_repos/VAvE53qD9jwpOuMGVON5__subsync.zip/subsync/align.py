"""Optional forced re-alignment using stable-ts for tighter word boundaries."""
from __future__ import annotations
import sys
from pathlib import Path
from .types import Segment, Word


def align(audio: Path, segments: list[Segment], language: str,
          model_name: str = "large-v3") -> list[Segment]:
    """
    Re-align word boundaries against the audio. Returns new segments with
    tightened timestamps. Falls back to the input list if stable-ts is missing.
    """
    try:
        import stable_whisper  # type: ignore
    except ImportError:
        print("[subsync] stable-ts not installed; skipping alignment", file=sys.stderr)
        return segments

    print("[subsync] forced alignment (stable-ts)…", file=sys.stderr)
    model = stable_whisper.load_faster_whisper(model_name)
    text = " ".join(s.text for s in segments).strip()
    if not text:
        return segments
    result = model.align(str(audio), text, language=language)

    out: list[Segment] = []
    for s in result.segments:
        words = [Word(start=w.start, end=w.end, text=(w.word or "").strip(), prob=1.0)
                 for w in (s.words or []) if (w.word or "").strip()]
        out.append(Segment(start=s.start, end=s.end,
                           text=(s.text or "").strip(),
                           words=words))
    return out
