"""Subtitle text helpers.

Wrap, clean, and constrain dialogue lines to broadcast/streaming spec.
Most platforms specify max chars-per-line and max lines-per-cue; this
module gives one place to enforce those without each format writer
duplicating the logic.
"""

from __future__ import annotations

import re
import unicodedata
from typing import List, Optional


# Default constraints. Most platforms slot somewhere in this range.
DEFAULT_MAX_CHARS_PER_LINE = 42
DEFAULT_MAX_LINES = 2

# Words we never want as the dangling end-of-line word - keep them with
# the next clause for readability.
NEVER_BREAK_BEFORE = {
    "the", "a", "an",
    "of", "to", "in", "on", "at", "by", "for", "with", "from",
    "and", "or", "but", "nor",
    "is", "are", "was", "were", "be", "been", "being",
}


def wrap_dialogue(text: str,
                  max_chars: int = DEFAULT_MAX_CHARS_PER_LINE,
                  max_lines: int = DEFAULT_MAX_LINES) -> List[str]:
    """Greedy word wrap with a few subtitling-specific tweaks.

    - Avoids leaving small "trailing" words alone on a line.
    - Tries to balance the lines (split closer to the middle when easy).
    - Honours max_lines: if the text won't fit, the last line is trimmed
      with an ellipsis rather than expanding past the limit.
    """
    text = collapse_whitespace(text)
    if not text:
        return [""]
    words = text.split(" ")
    lines: List[List[str]] = [[]]
    line_len = 0

    for w in words:
        if not w:
            continue
        # +1 for the space separator unless this is the first word on the line.
        extra = (len(w) + (1 if lines[-1] else 0))
        if line_len + extra > max_chars:
            if len(lines) >= max_lines:
                lines[-1].append(w)
                line_len += extra
            else:
                lines.append([w])
                line_len = len(w)
        else:
            lines[-1].append(w)
            line_len += extra

    out = [" ".join(parts) for parts in lines if parts]
    out = _balance(out, max_chars)
    if any(len(line) > max_chars for line in out):
        # Last-resort: hard-truncate the longest line.
        out = [_hard_truncate(line, max_chars) for line in out]
    if len(out) > max_lines:
        out = out[:max_lines]
        out[-1] = _hard_truncate(out[-1], max_chars, ellipsis=True)
    return out


def collapse_whitespace(text: str) -> str:
    """Replace any run of whitespace with a single space, strip ends."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def normalise_punctuation(text: str) -> str:
    """Normalise smart quotes / dashes that some platforms hate."""
    if not text:
        return ""
    repl = {
        "“": '"', "”": '"',
        "‘": "'", "’": "'",
        "–": "-", "—": "-",
        "…": "...",
        " ": " ",  # nbsp -> regular space
    }
    out = text
    for k, v in repl.items():
        out = out.replace(k, v)
    return out


def strip_html(text: str) -> str:
    """Drop any inline tags. Useful when promoting from styled formats to plain."""
    if not text:
        return ""
    out = re.sub(r"<[^>]+>", "", text)
    return collapse_whitespace(out)


def detect_language_hints(text: str) -> dict:
    """Cheap script-detection for routing to the right wrap rules."""
    counts = {"latin": 0, "cyrillic": 0, "cjk": 0, "arabic": 0, "thai": 0, "other": 0}
    for ch in text:
        if not ch.strip():
            continue
        cat = unicodedata.name(ch, "").split(" ")[0]
        cp = ord(ch)
        if 0x0000 <= cp <= 0x024F:
            counts["latin"] += 1
        elif 0x0400 <= cp <= 0x04FF:
            counts["cyrillic"] += 1
        elif 0x0600 <= cp <= 0x06FF:
            counts["arabic"] += 1
        elif 0x0E00 <= cp <= 0x0E7F:
            counts["thai"] += 1
        elif 0x4E00 <= cp <= 0x9FFF or 0x3040 <= cp <= 0x30FF or 0xAC00 <= cp <= 0xD7AF:
            counts["cjk"] += 1
        else:
            counts["other"] += 1
    return counts


def break_count(text: str) -> int:
    """Count line breaks. \\n and \\r\\n both count as one."""
    return text.count("\n") + text.count("\r\n") - text.count("\r\n")


def _balance(lines: List[str], max_chars: int) -> List[str]:
    """Try to even-out two lines if the difference is ugly."""
    if len(lines) != 2:
        return lines
    a, b = lines
    if abs(len(a) - len(b)) <= 4:
        return lines
    # Move trailing words from the longer line to the shorter where it fits.
    if len(a) > len(b):
        words = a.split()
        for i in range(len(words) - 1, 0, -1):
            candidate_a = " ".join(words[:i])
            tail = " ".join(words[i:])
            candidate_b = (tail + " " + b).strip()
            if len(candidate_a) <= max_chars and len(candidate_b) <= max_chars and abs(len(candidate_a) - len(candidate_b)) < abs(len(a) - len(b)):
                a, b = candidate_a, candidate_b
    return [a, b]


def _hard_truncate(s: str, n: int, ellipsis: bool = False) -> str:
    if len(s) <= n:
        return s
    if ellipsis and n >= 4:
        return s[: n - 1].rstrip() + "…"
    return s[:n].rstrip()


# -----------------------------------------------------------------------------
# Censoring / profanity
# -----------------------------------------------------------------------------

DEFAULT_BLEEP = "[bleep]"


def censor(text: str, words: list, replacement: str = DEFAULT_BLEEP) -> str:
    """Case-insensitive whole-word replace. Used by --no-profanity in the CLI."""
    if not words:
        return text
    pattern = r"\b(?:" + "|".join(re.escape(w) for w in words) + r")\b"
    return re.sub(pattern, replacement, text, flags=re.IGNORECASE)


def mask_pii(text: str) -> str:
    """Light PII masking. Phone-like and email-like patterns. Conservative."""
    out = re.sub(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", "[email]", text)
    out = re.sub(r"\+?\d[\d\s().-]{7,}\d", "[phone]", out)
    return out


# -----------------------------------------------------------------------------
# Speaker labels
# -----------------------------------------------------------------------------

def normalise_speaker_label(raw: str) -> str:
    """Tidy 'SPEAKER_03' or 'speaker 03' to 'Speaker 3'."""
    if not raw:
        return ""
    m = re.match(r"speaker[_\s]*0*(\d+)", raw.strip(), flags=re.IGNORECASE)
    if m:
        return "Speaker {}".format(int(m.group(1)))
    return raw.strip()


def insert_speaker_prefix(text: str, speaker: str, fmt: str = "{}: {}") -> str:
    if not speaker:
        return text
    return fmt.format(speaker, text)


# -----------------------------------------------------------------------------
# Reading-speed friendly cleanups
# -----------------------------------------------------------------------------

def chars_no_spaces(text: str) -> int:
    return sum(1 for c in text if not c.isspace())


def chars_visible(text: str) -> int:
    """Counts code points minus combining marks. Closer to perceived length."""
    n = 0
    for ch in text:
        if unicodedata.category(ch).startswith("M"):
            continue
        n += 1
    return n


def split_long_segment(text: str, target_chars: int = 100) -> List[str]:
    """Roughly split very long text on punctuation boundaries."""
    if len(text) <= target_chars:
        return [text]
    pieces = re.split(r"(?<=[.!?])\s+", text)
    out: List[str] = []
    buf = ""
    for p in pieces:
        if not buf:
            buf = p
        elif len(buf) + 1 + len(p) <= target_chars:
            buf = buf + " " + p
        else:
            out.append(buf.strip())
            buf = p
    if buf:
        out.append(buf.strip())
    return out
