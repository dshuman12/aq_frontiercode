"""ffmpeg / ffprobe helpers."""
from __future__ import annotations
import json, os, shutil, subprocess, sys
from pathlib import Path


# Cache resolved binary paths so we don't re-scan the filesystem every call.
_BIN_CACHE: dict[str, str] = {}


def _candidate_dirs() -> list[Path]:
    """Folders to search for a bundled ffmpeg/ffprobe before falling back to PATH.

    Order:
      1. SUBSYNC_FFMPEG_DIR env var, if set
      2. PyInstaller one-file extraction dir (sys._MEIPASS)
      3. Folder containing the running exe (frozen build) or this source file
      4. A sibling 'ffmpeg/' or 'bin/' folder under #3
    """
    out: list[Path] = []
    env = os.environ.get("SUBSYNC_FFMPEG_DIR")
    if env:
        out.append(Path(env))
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        out.append(Path(meipass))
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
    else:
        exe_dir = Path(__file__).resolve().parent.parent
    out.append(exe_dir)
    out.append(exe_dir / "ffmpeg")
    out.append(exe_dir / "bin")
    return out


def require(binary: str) -> str:
    """Locate a binary, preferring a bundled copy over the system PATH."""
    cached = _BIN_CACHE.get(binary)
    if cached and Path(cached).exists():
        return cached

    exe_name = binary + (".exe" if os.name == "nt" and not binary.lower().endswith(".exe") else "")
    for d in _candidate_dirs():
        cand = d / exe_name
        if cand.is_file():
            p = str(cand)
            _BIN_CACHE[binary] = p
            return p

    p = shutil.which(binary) or shutil.which(exe_name)
    if not p:
        sys.exit(
            f"error: '{binary}' not found.\n"
            f"  Looked in: {', '.join(str(d) for d in _candidate_dirs())}\n"
            f"  And on PATH. Install ffmpeg or place {exe_name} next to subsync.exe."
        )
    _BIN_CACHE[binary] = p
    return p


def run(cmd: list[str], capture: bool = False) -> subprocess.CompletedProcess:
    if capture:
        return subprocess.run(cmd, check=True, capture_output=True, text=True)
    return subprocess.run(cmd, check=True)


def extract_audio(src: Path, dst: Path) -> Path:
    """Extract a 16 kHz mono PCM WAV — Whisper-native input format."""
    ffmpeg = require("ffmpeg")
    run([
        ffmpeg, "-y", "-i", str(src),
        "-vn", "-ac", "1", "-ar", "16000",
        "-acodec", "pcm_s16le",
        "-loglevel", "error",
        str(dst),
    ])
    return dst


def probe(src: Path) -> dict:
    ffprobe = require("ffprobe")
    out = run([
        ffprobe, "-v", "error",
        "-show_format", "-show_streams",
        "-of", "json", str(src),
    ], capture=True).stdout
    return json.loads(out)


def duration(src: Path) -> float:
    try:
        return float(probe(src).get("format", {}).get("duration", 0.0))
    except Exception:
        return 0.0
