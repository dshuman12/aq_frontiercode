"""
Tkinter GUI for subsync.

Launched automatically when subsync.exe is double-clicked (no CLI args), or
when a media file is dragged onto the .exe (single arg = path to a file).

Design:
  - Single window, dark-ish theme that matches player.html.
  - Pick video + options + click "Make Subtitles".
  - Pipeline runs on a worker thread; UI stays responsive.
  - Stderr from pipeline gets piped into a log textbox on the UI thread via Queue.
  - When done: "Open output folder", "Edit / re-sync captions" buttons appear.
    "Edit / re-sync" launches a temp copy of player.html with the .subs.json
    pre-injected so the editor opens with everything already loaded.
"""
from __future__ import annotations

import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional

from . import media
from .pipeline import Options, run as run_pipeline


# ---------- locating bundled assets ----------------------------------------

def _bundle_dir() -> Path:
    """Folder where the running exe sits (frozen) or the source-tree root (dev)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _find_player_html() -> Optional[Path]:
    candidates = [
        _bundle_dir() / "player.html",
        Path(getattr(sys, "_MEIPASS", "")) / "player.html" if getattr(sys, "_MEIPASS", None) else None,
        Path(__file__).resolve().parent.parent / "player.html",
    ]
    for c in candidates:
        if c and c.is_file():
            return c
    return None


# ---------- redirect stderr/stdout into a queue while the pipeline runs ----

class _QueueWriter:
    """File-like object that pushes writes into a queue."""

    def __init__(self, q: "queue.Queue[str]") -> None:
        self.q = q
        self._buf = ""

    def write(self, s: str) -> int:
        if not s:
            return 0
        self._buf += s
        # flush full lines
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            self.q.put(line + "\n")
        return len(s)

    def flush(self) -> None:
        if self._buf:
            self.q.put(self._buf)
            self._buf = ""


# ---------- main app -------------------------------------------------------

LANGS = [
    ("auto detect", "auto"),
    ("English (en)", "en"), ("Spanish (es)", "es"), ("French (fr)", "fr"),
    ("German (de)", "de"), ("Italian (it)", "it"), ("Portuguese (pt)", "pt"),
    ("Dutch (nl)", "nl"), ("Polish (pl)", "pl"), ("Russian (ru)", "ru"),
    ("Arabic (ar)", "ar"), ("Hindi (hi)", "hi"), ("Mandarin (zh)", "zh"),
    ("Japanese (ja)", "ja"), ("Korean (ko)", "ko"), ("Yoruba (yo)", "yo"),
    ("Igbo (ig)", "ig"), ("Hausa (ha)", "ha"),
]

MODELS = [
    ("Auto — pick the best one for this file", "auto"),
    ("Tiny — fastest, less accurate (~75 MB)", "tiny"),
    ("Base — fast (~140 MB)", "base"),
    ("Small — balanced (~460 MB)", "small"),
    ("Medium — accurate (~1.5 GB)", "medium"),
    ("Large v3 — most accurate (~3 GB)", "large-v3"),
]

# Rough CPU runtime as a multiple of audio duration. Tuned from real benchmarks
# on a midrange laptop CPU; bigger machines are faster, GPU much faster.
SPEED_FACTOR = {
    "tiny":     0.08,
    "base":     0.20,
    "small":    0.50,
    "medium":   1.00,
    "large-v3": 2.50,
}


def _auto_pick_model(duration_seconds: float) -> str:
    """Choose the largest model that finishes in roughly under an hour of CPU time."""
    minutes = duration_seconds / 60.0
    if minutes <= 10:
        return "large-v3"
    elif minutes <= 30:
        return "medium"
    elif minutes <= 90:
        return "small"
    else:
        return "base"


def _format_duration(seconds: float) -> str:
    """Format seconds as H:MM:SS or M:SS depending on length."""
    if seconds <= 0:
        return "—"
    total = int(round(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _format_eta(seconds: float) -> str:
    """Format an ETA into a friendly 'about X min' / 'X hours'."""
    if seconds <= 0:
        return "—"
    if seconds < 90:
        return "under 2 min"
    if seconds < 60 * 60:
        return f"about {int(round(seconds / 60))} min"
    hours = seconds / 3600.0
    if hours < 2:
        return f"about {hours:.1f} hours"
    return f"about {int(round(hours))} hours"

# tkinter dark-ish palette
BG = "#14181d"
PANEL = "#1b2128"
TEXT = "#e9eef3"
MUTED = "#8a96a3"
ACCENT = "#6ea8fe"
LINE = "#232a32"


class SubsyncGUI:
    def __init__(self, root: tk.Tk, initial_file: Optional[str] = None) -> None:
        self.root = root
        self.root.title("Subsync — make subtitles")
        self.root.geometry("780x620")
        self.root.minsize(680, 540)
        self.root.configure(bg=BG)

        self._configure_style()

        self.input_path: Optional[Path] = None
        self.output_dir: Optional[Path] = None
        self.duration_seconds: float = 0.0
        self.last_result_stem: Optional[str] = None
        self.last_result_dir: Optional[Path] = None
        self.worker: Optional[threading.Thread] = None
        self.log_q: "queue.Queue[str]" = queue.Queue()

        self._build_layout()
        self._poll_log()

        if initial_file:
            try:
                p = Path(initial_file).resolve()
                if p.is_file():
                    self._set_input(p)
            except Exception:
                pass

    # ---- styling ----
    def _configure_style(self) -> None:
        s = ttk.Style(self.root)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, foreground=TEXT, fieldbackground=PANEL,
                    bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL)
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("Card.TLabel", background=PANEL, foreground=TEXT)
        s.configure("Muted.TLabel", background=BG, foreground=MUTED)
        s.configure("Title.TLabel", background=BG, foreground=TEXT,
                    font=("Segoe UI", 14, "bold"))
        s.configure("TButton", background=PANEL, foreground=TEXT, borderwidth=1,
                    focusthickness=0, padding=8)
        s.map("TButton",
              background=[("active", LINE), ("disabled", PANEL)],
              foreground=[("disabled", MUTED)])
        s.configure("Accent.TButton", background=ACCENT, foreground="#0b0d10",
                    font=("Segoe UI", 11, "bold"), padding=10)
        s.map("Accent.TButton", background=[("active", "#88b8ff"), ("disabled", LINE)],
              foreground=[("disabled", MUTED)])
        s.configure("TCheckbutton", background=BG, foreground=TEXT,
                    focuscolor=BG, indicatorcolor=PANEL)
        s.map("TCheckbutton", background=[("active", BG)],
              indicatorcolor=[("selected", ACCENT)])
        s.configure("TCombobox", fieldbackground=PANEL, background=PANEL,
                    foreground=TEXT, selectbackground=PANEL, selectforeground=TEXT)
        s.configure("TEntry", fieldbackground=PANEL, foreground=TEXT)
        s.configure("Horizontal.TProgressbar", background=ACCENT,
                    troughcolor=PANEL, bordercolor=LINE, lightcolor=ACCENT,
                    darkcolor=ACCENT)

    # ---- layout ----
    def _build_layout(self) -> None:
        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Subsync", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="Make subtitles for any video or audio file.",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 12))

        # --- file picker row ---
        row = ttk.Frame(outer)
        row.pack(fill="x", pady=(0, 4))
        ttk.Label(row, text="Video / audio file:").pack(side="left", padx=(0, 8))
        self.file_label = ttk.Label(row, text="No file selected", style="Muted.TLabel")
        self.file_label.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Choose…", command=self._pick_file).pack(side="right")

        # --- duration line, populated after a file is picked ---
        self.duration_var = tk.StringVar(value="")
        ttk.Label(outer, textvariable=self.duration_var,
                  style="Muted.TLabel").pack(anchor="w", pady=(0, 8))

        # --- output folder picker row (above the options card so it's obvious) ---
        out_row = ttk.Frame(outer)
        out_row.pack(fill="x", pady=(0, 12))
        ttk.Label(out_row, text="Save captions to:").pack(side="left", padx=(0, 8))
        self.outdir_label = ttk.Label(out_row, text="(same folder as the video)",
                                      style="Muted.TLabel")
        self.outdir_label.pack(side="left", fill="x", expand=True)
        ttk.Button(out_row, text="Change…", command=self._pick_outdir).pack(side="right")

        # --- options card ---
        card = ttk.Frame(outer, style="Card.TFrame", padding=14)
        card.pack(fill="x", pady=(0, 12))

        opts = ttk.Frame(card, style="Card.TFrame")
        opts.pack(fill="x")
        opts.columnconfigure(1, weight=1)
        opts.columnconfigure(3, weight=1)

        # model
        ttk.Label(opts, text="Model:", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        self.model_var = tk.StringVar(value=MODELS[0][0])  # default to "Auto"
        self.model_cb = ttk.Combobox(opts, textvariable=self.model_var,
                                     values=[m[0] for m in MODELS], state="readonly", width=38)
        self.model_cb.grid(row=0, column=1, columnspan=3, sticky="ew", pady=4)
        self.model_cb.bind("<<ComboboxSelected>>", lambda _e: self._refresh_eta())

        # ETA line right under the model dropdown
        self.eta_var = tk.StringVar(value="")
        ttk.Label(opts, textvariable=self.eta_var,
                  style="Card.TLabel", foreground=MUTED).grid(
                  row=5, column=0, columnspan=4, sticky="w", pady=(6, 0))

        # language
        ttk.Label(opts, text="Language:", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        self.lang_var = tk.StringVar(value=LANGS[0][0])
        self.lang_cb = ttk.Combobox(opts, textvariable=self.lang_var,
                                    values=[l[0] for l in LANGS], state="readonly", width=22)
        self.lang_cb.grid(row=1, column=1, sticky="w", pady=4)

        # translate to
        ttk.Label(opts, text="Translate to (optional):", style="Card.TLabel").grid(row=1, column=2, sticky="w", padx=(20, 8), pady=4)
        self.translate_var = tk.StringVar(value="")
        self.translate_entry = ttk.Entry(opts, textvariable=self.translate_var, width=18)
        self.translate_entry.grid(row=1, column=3, sticky="ew", pady=4)
        ttk.Label(opts, text="e.g. es, fr, yo  (comma-separated codes)",
                  style="Card.TLabel", foreground=MUTED).grid(row=2, column=2, columnspan=2, sticky="w", padx=(20, 0))

        # checkboxes
        self.tag_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Tag non-speech events (laughter, music, applause…)",
                        variable=self.tag_var).grid(row=3, column=0, columnspan=4, sticky="w", pady=(10, 2))
        self.diarize_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Detect speakers  (slower; requires a Hugging Face token below)",
                        variable=self.diarize_var,
                        command=self._on_diarize_toggle).grid(row=4, column=0, columnspan=4, sticky="w", pady=2)

        # HF token entry (only meaningful if diarize is on; pre-filled from env)
        ttk.Label(opts, text="HF Token:", style="Card.TLabel").grid(row=6, column=0, sticky="w", padx=(0, 8), pady=(8, 4))
        self.hf_token_var = tk.StringVar(value=os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN") or "")
        self.hf_token_entry = ttk.Entry(opts, textvariable=self.hf_token_var, show="•", width=42)
        self.hf_token_entry.grid(row=6, column=1, columnspan=3, sticky="ew", pady=(8, 4))
        # If we found a token in env, hint that it's loaded; if not, hint how to get one.
        hint = ("HF_TOKEN env var loaded — leave as-is, or paste a different token."
                if self.hf_token_var.get() else
                "Get one free at huggingface.co/settings/tokens (only needed for speaker detection).")
        ttk.Label(opts, text=hint, style="Card.TLabel",
                  foreground=MUTED).grid(row=7, column=0, columnspan=4, sticky="w")

        # --- big action button ---
        self.go_btn = ttk.Button(outer, text="Make Subtitles", style="Accent.TButton",
                                 command=self._on_go, state="disabled")
        self.go_btn.pack(fill="x", pady=(0, 10))

        # --- progress + status ---
        self.progress = ttk.Progressbar(outer, mode="indeterminate",
                                        style="Horizontal.TProgressbar")
        self.progress.pack(fill="x")
        self.status_var = tk.StringVar(value="Choose a file to start.")
        ttk.Label(outer, textvariable=self.status_var, style="Muted.TLabel").pack(anchor="w", pady=(4, 8))

        # --- log textbox ---
        log_frame = ttk.Frame(outer)
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, height=10, bg=PANEL, fg=TEXT,
                           insertbackground=TEXT, relief="flat",
                           borderwidth=0, font=("Consolas", 9), state="disabled",
                           wrap="word")
        self.log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(log_frame, command=self.log.yview)
        sb.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=sb.set)

        # --- post-run actions (hidden until a run completes) ---
        self.actions_row = ttk.Frame(outer)
        # not packed yet
        self.open_btn = ttk.Button(self.actions_row, text="Open output folder",
                                   command=self._open_output)
        self.open_btn.pack(side="left", padx=(0, 8))
        self.edit_btn = ttk.Button(self.actions_row, text="Edit / re-sync captions",
                                   command=self._open_editor)
        self.edit_btn.pack(side="left", padx=(0, 8))
        self.again_btn = ttk.Button(self.actions_row, text="Caption another video",
                                    command=self._reset_for_next)
        self.again_btn.pack(side="left")

    # ---- file picking ----
    def _pick_file(self) -> None:
        types = [
            ("Video / audio files",
             "*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.mp3 *.m4a *.wav *.flac *.ogg *.opus *.aac"),
            ("All files", "*.*"),
        ]
        path = filedialog.askopenfilename(title="Choose video or audio", filetypes=types)
        if path:
            self._set_input(Path(path))

    def _pick_outdir(self) -> None:
        d = filedialog.askdirectory(title="Choose output folder")
        if d:
            self.output_dir = Path(d)
            self.outdir_label.configure(text=str(self.output_dir), foreground=TEXT)

    def _set_input(self, p: Path) -> None:
        self.input_path = p
        self.duration_seconds = 0.0
        self.file_label.configure(text=str(p), foreground=TEXT)
        if not self.output_dir:
            self.outdir_label.configure(text="(same folder as the video)", foreground=MUTED)
        self.go_btn.configure(state="normal")
        self.status_var.set(f"Ready to caption {p.name}.")
        self.duration_var.set("Reading file…")
        self.eta_var.set("")
        # Probe duration in a background thread so the UI stays responsive even
        # if ffprobe takes a beat (e.g. very large file on a slow disk).
        threading.Thread(target=self._probe_duration_async,
                         args=(p,), daemon=True).start()

    def _probe_duration_async(self, p: Path) -> None:
        try:
            seconds = media.duration(p)
        except SystemExit as e:
            # media.duration -> probe -> require('ffprobe') which calls sys.exit
            # if ffprobe is missing. Don't crash the GUI; just leave duration empty.
            seconds = 0.0
            self.log_q.put(f"[subsync] could not read duration: {e}\n")
        except Exception as e:
            seconds = 0.0
            self.log_q.put(f"[subsync] duration probe failed: {e}\n")

        # Marshal back onto the UI thread to update the labels.
        self.root.after(0, lambda: self._on_duration_probed(p, seconds))

    def _on_duration_probed(self, p: Path, seconds: float) -> None:
        # Make sure the user hasn't switched files while we were probing.
        if self.input_path != p:
            return
        self.duration_seconds = seconds
        if seconds > 0:
            self.duration_var.set(f"Length: {_format_duration(seconds)}")
        else:
            self.duration_var.set("Length: unknown (couldn't read file)")
        self._refresh_eta()

    def _resolve_model(self) -> str:
        """Convert the current dropdown selection into a real model name."""
        code = next((c for n, c in MODELS if n == self.model_var.get()), "auto")
        if code == "auto":
            if self.duration_seconds > 0:
                return _auto_pick_model(self.duration_seconds)
            return "medium"  # safe default when duration is unknown
        return code

    def _on_diarize_toggle(self) -> None:
        """Warn the user if they tick speakers without a token in sight."""
        if self.diarize_var.get() and not self.hf_token_var.get().strip():
            try:
                self.hf_token_entry.focus_set()
            except Exception:
                pass

    def _refresh_eta(self) -> None:
        if self.duration_seconds <= 0:
            self.eta_var.set("")
            return
        model = self._resolve_model()
        factor = SPEED_FACTOR.get(model, 1.0)
        eta = self.duration_seconds * factor
        label = f"Estimated wait: {_format_eta(eta)} on CPU"
        if self.model_var.get().startswith("Auto"):
            label += f"  (auto-picked: {model})"
        self.eta_var.set(label)

    # ---- run pipeline ----
    def _on_go(self) -> None:
        if not self.input_path:
            return
        if self.worker and self.worker.is_alive():
            return

        # Lock UI
        self.go_btn.configure(state="disabled", text="Working…")
        self.actions_row.pack_forget()
        self._clear_log()
        self.progress.start(12)
        self.status_var.set("Starting…")

        model = self._resolve_model()
        lang = next((c for n, c in LANGS if n == self.lang_var.get()), "auto")
        targets = [t.strip() for t in self.translate_var.get().split(",") if t.strip()]
        out_dir = self.output_dir if self.output_dir else self.input_path.parent

        opts = Options(
            input=self.input_path,
            out_dir=out_dir,
            stem=self.input_path.stem,
            model=model,
            language=None if lang == "auto" else lang,
            tag_events=self.tag_var.get(),
            diarize=self.diarize_var.get(),
            hf_token=(self.hf_token_var.get().strip()
                      or os.environ.get("HF_TOKEN")
                      or os.environ.get("HUGGINGFACE_TOKEN")),
            translate_to=targets,
        )
        self.last_result_stem = self.input_path.stem
        self.last_result_dir = out_dir

        self.worker = threading.Thread(target=self._run_pipeline, args=(opts,), daemon=True)
        self.worker.start()

    def _run_pipeline(self, opts: Options) -> None:
        # Redirect Python-level stdout/stderr into the GUI log queue.
        old_out, old_err = sys.stdout, sys.stderr
        writer = _QueueWriter(self.log_q)
        sys.stdout = writer  # type: ignore[assignment]
        sys.stderr = writer  # type: ignore[assignment]
        try:
            print(f"[subsync] starting pipeline on: {opts.input.name}", file=sys.stderr)
            run_pipeline(opts)
            self.log_q.put("__done__\n")
        except SystemExit as e:
            self.log_q.put(f"__error__ pipeline aborted: {e}\n")
        except Exception as e:
            import traceback
            self.log_q.put("__error__ " + str(e) + "\n")
            self.log_q.put(traceback.format_exc())
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # ---- log polling on UI thread ----
    def _poll_log(self) -> None:
        try:
            while True:
                line = self.log_q.get_nowait()
                if line.startswith("__done__"):
                    self._on_done(success=True)
                elif line.startswith("__error__"):
                    msg = line[len("__error__"):].strip()
                    self._append_log(f"ERROR: {msg}\n")
                    self._on_done(success=False, error=msg)
                else:
                    self._append_log(line)
                    self._maybe_update_status(line)
        except queue.Empty:
            pass
        self.root.after(80, self._poll_log)

    def _append_log(self, s: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", s)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _clear_log(self) -> None:
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def _maybe_update_status(self, line: str) -> None:
        # Pull the most informative status from pipeline log lines.
        L = line.strip().lower()
        if not L:
            return
        if "loading" in L and ("whisper" in L or "model" in L):
            self.status_var.set("Loading speech model… (first run downloads ~1.5 GB)")
        elif "transcrib" in L:
            self.status_var.set("Transcribing audio…")
        elif "diariz" in L:
            self.status_var.set("Detecting speakers…")
        elif "translat" in L:
            self.status_var.set("Translating…")
        elif "tag" in L and "event" in L:
            self.status_var.set("Tagging non-speech events…")
        elif line.lstrip().startswith("[subsync] starting"):
            self.status_var.set("Starting…")

    # ---- post-run ----
    def _on_done(self, success: bool, error: Optional[str] = None) -> None:
        self.progress.stop()
        self.go_btn.configure(state="normal", text="Make Subtitles")
        if success:
            out_dir = self.last_result_dir or Path(".")
            self.status_var.set(f"Done. Files saved to {out_dir}")
            self.actions_row.pack(fill="x", pady=(8, 0))
            self._notify_done()
        else:
            self.status_var.set(f"Failed: {error or 'see log above'}")
            try:
                self.root.bell()
            except Exception:
                pass

    def _notify_done(self) -> None:
        """Audible + visual + dialog notification when a run completes."""
        # 1. Audible bell + Windows "asterisk" sound for emphasis
        try:
            self.root.bell()
            if os.name == "nt":
                import winsound
                winsound.MessageBeep(winsound.MB_ICONASTERISK)
        except Exception:
            pass
        # 2. Bring the window to the front (and flash the taskbar on Windows)
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            self.root.attributes("-topmost", True)
            self.root.after(400, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass
        # 3. Modal "captions ready" dialog with the obvious next steps
        out_dir = self.last_result_dir or Path(".")
        msg = (f"Captions are ready.\n\n"
               f"Saved to:\n  {out_dir}\n\n"
               f"Open the editor now? You'll be able to play the video, "
               f"see captions sync, fix wrong words, and nudge timing.")
        try:
            choice = messagebox.askyesno(
                title="Subsync — done",
                message=msg,
                detail="Choose No to stay here. The editor button is also "
                       "available below.",
                icon="info",
                default="yes",
            )
        except Exception:
            choice = False
        if choice:
            self._open_editor()

    def _open_output(self) -> None:
        if not self.last_result_dir:
            return
        try:
            os.startfile(str(self.last_result_dir))  # type: ignore[attr-defined]
        except Exception:
            # Non-Windows fallback
            subprocess.run(["xdg-open", str(self.last_result_dir)], check=False)

    def _open_editor(self) -> None:
        """Launch player.html in the default browser, with captions and the video src injected."""
        if not (self.last_result_dir and self.last_result_stem):
            return
        json_path = self.last_result_dir / f"{self.last_result_stem}.subs.json"
        if not json_path.exists():
            messagebox.showerror("Editor",
                                 f"Could not find {json_path.name} — was the run successful?")
            return
        player = _find_player_html()
        if not player:
            messagebox.showerror("Editor",
                                 "player.html is missing from the bundle. The .subs.json is at:\n\n"
                                 f"{json_path}")
            return
        try:
            subs_data = json_path.read_text(encoding="utf-8")
        except Exception as e:
            messagebox.showerror("Editor", f"Could not read {json_path.name}: {e}")
            return

        html = player.read_text(encoding="utf-8")

        # 1. Inject the JSON into the <script id="prefill"> slot.
        json_marker = '<script id="prefill" type="application/json"></script>'
        replaced_json = f'<script id="prefill" type="application/json">{subs_data}</script>'
        if json_marker in html:
            html = html.replace(json_marker, replaced_json)
        else:
            # Old player.html that lacks the prefill slot — graceful degrade.
            html = html.replace("</body>", f"{replaced_json}\n</body>")

        # 2. Inject the video src as a file:// URL so the editor opens playable.
        if self.input_path:
            try:
                video_uri = self.input_path.resolve().as_uri()
            except Exception:
                video_uri = ""
            if video_uri:
                video_marker = '<meta id="prefill-video" data-src="" />'
                replaced_meta = f'<meta id="prefill-video" data-src="{video_uri}" />'
                if video_marker in html:
                    html = html.replace(video_marker, replaced_meta)
                else:
                    html = html.replace("</body>", f"{replaced_meta}\n</body>")

        # Write the prefilled html to a temp folder we own.
        tmp_dir = Path(tempfile.mkdtemp(prefix="subsync_editor_"))
        out = tmp_dir / "player.html"
        out.write_text(html, encoding="utf-8")
        webbrowser.open(out.as_uri())
        self._append_log(
            f"[subsync] editor: opened {out}\n"
            f"[subsync] if the video doesn't auto-play, click 'load video' in the "
            f"editor and pick the same file. Some browsers block file:// videos.\n"
        )

    def _reset_for_next(self) -> None:
        self.input_path = None
        self.output_dir = None
        self.duration_seconds = 0.0
        self.last_result_stem = None
        self.last_result_dir = None
        self.file_label.configure(text="No file selected", foreground=MUTED)
        self.outdir_label.configure(text="(same folder as the video)", foreground=MUTED)
        self.duration_var.set("")
        self.eta_var.set("")
        self.model_var.set(MODELS[0][0])  # back to "Auto"
        self.translate_var.set("")
        self.tag_var.set(False)
        self.diarize_var.set(False)
        self.actions_row.pack_forget()
        self.go_btn.configure(state="disabled")
        self._clear_log()
        self.status_var.set("Choose a file to start.")


# ---------- entry point ----------------------------------------------------

def launch_gui(initial_file: Optional[str] = None) -> int:
    # Hide the parent console window if we have one (PyInstaller console=True bundle).
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            user32 = ctypes.windll.user32
            hwnd = kernel32.GetConsoleWindow()
            if hwnd:
                user32.ShowWindow(hwnd, 0)  # SW_HIDE
        except Exception:
            pass

    root = tk.Tk()
    SubsyncGUI(root, initial_file=initial_file)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(launch_gui(sys.argv[1] if len(sys.argv) > 1 else None))
