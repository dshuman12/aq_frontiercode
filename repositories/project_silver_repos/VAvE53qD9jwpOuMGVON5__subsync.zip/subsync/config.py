"""Layered config: defaults < toml/json file < env vars < explicit overrides."""

from __future__ import annotations

import json
import os
import logging
from typing import Any, Dict, Optional

try:
    import tomllib  # py 3.11+
except Exception:
    tomllib = None  # type: ignore

DEFAULTS: Dict[str, Any] = {
    "transcribe": {
        "model": "large-v3",
        "device": "auto",
        "compute": "auto",
        "beam": 5,
        "vad": True,
    },
    "wrap": {
        "max_chars": 42,
        "max_lines": 2,
    },
    "speed": {
        "target_cps": 17.0,
        "max_cps": 20.0,
    },
    "frame_rate": {
        "default": 25.0,
        "drop_frame_for_29_97": True,
    },
    "diarize": {
        "default_off": True,
        "min_speakers": None,
        "max_speakers": None,
    },
    "translate": {
        "model": "facebook/m2m100_418M",
    },
    "logging": {
        "level": "INFO",
    },
}

DEFAULT_NAMES = (
    "subsync.toml", "subsync.json", ".subsync.toml", ".subsync.json",
)


class Config:
    def __init__(self, data: Optional[Dict[str, Any]] = None):
        self._data: Dict[str, Any] = _deep_copy(DEFAULTS)
        if data:
            _deep_merge(self._data, data)
        self.logger = logging.getLogger("subsync.config")

    @classmethod
    def load(cls, path: Optional[str] = None) -> "Config":
        cfg = cls()
        path = path or _find()
        if path:
            try:
                cfg.merge_file(path)
            except Exception:
                cfg.logger.warning("failed to load %s", path, exc_info=True)
        cfg.merge_env()
        return cfg

    def merge_file(self, path: str) -> None:
        with open(path, "rb") as f:
            blob = f.read()
        if path.lower().endswith(".toml"):
            if tomllib is None:
                raise RuntimeError("tomllib not available")
            data = tomllib.loads(blob.decode("utf-8"))
        else:
            data = json.loads(blob.decode("utf-8"))
        _deep_merge(self._data, data)

    def merge_env(self) -> None:
        prefix = "SUBSYNC_"
        for k, v in os.environ.items():
            if not k.startswith(prefix):
                continue
            tail = k[len(prefix):].lower()
            if "_" not in tail:
                continue
            section, sub = tail.split("_", 1)
            if section in self._data and sub in self._data[section]:
                target = self._data[section][sub]
                self._data[section][sub] = _coerce(v, type(target))

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self._data
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def set(self, dotted: str, value: Any) -> None:
        parts = dotted.split(".")
        node: Any = self._data
        for part in parts[:-1]:
            if part not in node or not isinstance(node[part], dict):
                node[part] = {}
            node = node[part]
        node[parts[-1]] = value

    def section(self, name: str) -> Dict[str, Any]:
        return dict(self._data.get(name, {}))

    def as_dict(self) -> Dict[str, Any]:
        return _deep_copy(self._data)

    def save_json(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)


def _find() -> Optional[str]:
    here = os.path.abspath(os.getcwd())
    home = os.path.expanduser("~")
    while True:
        for n in DEFAULT_NAMES:
            full = os.path.join(here, n)
            if os.path.isfile(full):
                return full
        parent = os.path.dirname(here)
        if parent == here or here == home:
            break
        here = parent
    return None


def _deep_copy(d):
    if isinstance(d, dict):
        return {k: _deep_copy(v) for k, v in d.items()}
    if isinstance(d, list):
        return [_deep_copy(v) for v in d]
    return d


def _deep_merge(target: Dict[str, Any], extra: Dict[str, Any]) -> None:
    for k, v in extra.items():
        if k in target and isinstance(target[k], dict) and isinstance(v, dict):
            _deep_merge(target[k], v)
        else:
            target[k] = v


def _coerce(value: str, target_type: type) -> Any:
    if target_type is bool:
        return value.lower() in ("1", "true", "yes", "on")
    if target_type is int:
        try:
            return int(value)
        except ValueError:
            return value
    if target_type is float:
        try:
            return float(value)
        except ValueError:
            return value
    return value


_global: Optional[Config] = None


def get_config() -> Config:
    global _global
    if _global is None:
        _global = Config.load()
    return _global


def reset_config() -> None:
    global _global
    _global = None
