# Verifying the portable bundle

Run these checks after `build_exe.bat` finishes. Each one takes <2 minutes.

## 1. The exe launches at all

Open Command Prompt (not PowerShell — the quoting differs slightly):

```cmd
"C:\Users\aa\Documents\subsync\dist\subsync\subsync.exe" --help
```

Expected: usage screen listing `transcribe`, `burn`, `info`. If you see
"is not recognized" or a missing-DLL error, PyInstaller misfired — re-run
`build_exe.bat` with internet on.

## 2. ffmpeg is found from inside the exe (the whole point of bundling)

The clean way to prove the bundled ffmpeg is the one being used is to
temporarily hide the system one:

```cmd
set "PATH=C:\Windows\System32;C:\Windows"
"C:\Users\aa\Documents\subsync\dist\subsync\subsync.exe" info "C:\path\to\some_video.mp4"
```

That sets PATH to Windows-only directories — no Python, no system ffmpeg.
If `info` prints duration/codec details, the bundled ffmpeg is being picked
up correctly. If it errors with "ffmpeg not found", the post-build copy
didn't run — verify `dist\subsync\ffmpeg.exe` exists.

Reset PATH afterwards by closing the cmd window.

## 3. Drag-and-drop captioning works

Open `dist\subsync\` in File Explorer, drag a short video onto
`Make Subtitles.bat`. Expected:

- Console window opens, shows "Processing: <yourvideo>".
- First time: downloads Whisper model (~1.5 GB to `%USERPROFILE%\.cache\huggingface`).
- After a minute or two: console says `[subsync] done — N cues`, and
  `<yourvideo>.srt`, `.vtt`, `.subs.json` appear next to the video.

Pick a 30-second clip for the verification — full-length runs take real time.

## 4. Clean-machine smoke test

The strongest test: copy `dist\subsync\` (or unzip `dist\subsync.zip`) to a
USB stick. Take it to any other Windows PC — ideally one that doesn't have
Python or ffmpeg. Drag a video onto `Make Subtitles.bat`. If captions land
next to the video, you've verified end-to-end portability.

If you don't have a second machine handy, simulate one by creating a fresh
Windows user account, logging in as that user, and running from there.
That user has no PATH inheritance from your main account.

## What to send a friend

Send them `dist\subsync.zip` (~1–1.5 GB compressed). They need:

- A Windows 10 or 11 PC with at least 6 GB free disk space
- Internet for the one-time model download (~1.5 GB)

Tell them: "Right-click the zip → Extract All. Open the folder. Drag a
video onto Make Subtitles.bat." The file `READ ME FIRST.txt` in the bundle
covers the rest, including the SmartScreen warning they'll hit on first run.
