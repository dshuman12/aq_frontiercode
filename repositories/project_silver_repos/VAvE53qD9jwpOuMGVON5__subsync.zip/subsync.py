#!/usr/bin/env python3
"""Thin entry-point shim. Equivalent to `python -m subsync ...`.
The real code lives in the `subsync/` package next to this file.
"""
from subsync.cli import main
raise SystemExit(main())
