# Contributing

Personal project. Patches welcome.

## Setup

    pip install -r requirements.txt
    pytest tests/ -v

## House style

- Lowercase commit messages.
- Type hints where they help; not where they hurt readability.
- Tests live in `tests/`. Each module gets a sibling `test_<name>.py`.
