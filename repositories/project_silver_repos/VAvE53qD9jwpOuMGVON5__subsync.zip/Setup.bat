@echo off
REM ============================================================================
REM  Subsync — first-time setup. Double-click this once.
REM  Installs Python (if missing), ffmpeg (if missing), and all dependencies.
REM ============================================================================

setlocal EnableDelayedExpansion
title Subsync setup
cd /d "%~dp0"

echo.
echo  Subsync — one-time setup
echo  ==========================
echo.

REM ---- 1. Python check --------------------------------------------------------
echo [1/4] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo       Python not found. Installing via winget...
    winget install --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo       ERROR: Could not install Python automatically.
        echo       Install it manually from https://python.org and re-run Setup.bat.
        echo.
        pause & exit /b 1
    )
    echo       Python installed. You may need to close and reopen this window once.
    echo       Press any key to continue...
    pause >nul
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo       Python !PYVER! OK

REM ---- 2. ffmpeg check --------------------------------------------------------
echo [2/4] Checking ffmpeg...
ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo       ffmpeg not found. Installing via winget...
    winget install --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo       ERROR: Could not install ffmpeg automatically.
        echo       Install it manually from https://ffmpeg.org and re-run Setup.bat.
        echo.
        pause & exit /b 1
    )
    echo       ffmpeg installed. You may need to close and reopen this window once.
    echo       Press any key to continue...
    pause >nul
)
echo       ffmpeg OK

REM ---- 3. Python dependencies -------------------------------------------------
echo [3/4] Installing Python dependencies (this can take 5-10 minutes the first time)...
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo       ERROR: Dependency install failed. Check the messages above.
    echo.
    pause & exit /b 1
)
echo       Dependencies OK

REM ---- 4. First-run model download (optional, prompts user) -------------------
echo [4/4] Pre-downloading the Whisper model (~1.5 GB) so the first job is fast?
choice /C YN /M "       Download now"
if errorlevel 2 (
    echo       Skipped. Models will download on first run.
) else (
    python -c "from faster_whisper import WhisperModel; WhisperModel('large-v3', compute_type='int8')"
)

echo.
echo  ==========================================================================
echo   Setup complete.
echo.
echo   To make subtitles for a video or audio file:
echo     1. Drag the file onto  "Make Subtitles.bat"
echo     2. Output appears next to the file ^(.srt, .vtt, .json^)
echo.
echo   To review or edit subtitles, double-click  "Open Player.bat"
echo  ==========================================================================
echo.
pause
