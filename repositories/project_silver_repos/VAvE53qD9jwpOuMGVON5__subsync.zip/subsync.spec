# PyInstaller spec for subsync — produces dist/subsync/subsync.exe
# Build with:  python -m PyInstaller subsync.spec --clean --noconfirm
# (or just run build_exe.bat which does the same)

# -*- mode: python ; coding: utf-8 -*-

import os, sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_data_files, copy_metadata

block_cipher = None

# Heavy ML libs that need their data files / metadata bundled
hidden = []
datas = []
binaries = []
for pkg in (
    "faster_whisper",
    "ctranslate2",
    "tokenizers",
    "transformers",
    "torch",
    "torchaudio",
    "stable_whisper",
    "pyannote.audio",
    "pyannote.core",
    "pyannote.database",
    "pyannote.pipeline",
    "lightning",
    "lightning_fabric",
    "pytorch_lightning",
    "asteroid_filterbanks",
    "torch_audiomentations",
    "torch_pitch_shift",
    "librosa",
    "soundfile",
    "soxr",
    "sentencepiece",
    "huggingface_hub",
    "safetensors",
    "docx",
):
    try:
        d, b, h = collect_all(pkg)
        datas += d
        binaries += b
        hidden += h
    except Exception as e:
        print(f"[spec] could not collect {pkg}: {e}")
    try:
        datas += copy_metadata(pkg)
    except Exception:
        pass

# Bundle the player.html alongside the exe so users can open it from the same folder
datas += [("player.html", "."), ("README.md", "."), ("requirements.txt", ".")]

# Belt-and-braces: pytorch_lightning + lightning_fabric load a 'version.info'
# file at import time. If PyInstaller's auto-collect misses it, the bundle
# crashes the moment pyannote is imported. Force-add it.
import importlib.util
for pkg_name in ("lightning_fabric", "pytorch_lightning", "lightning"):
    spec = importlib.util.find_spec(pkg_name)
    if spec and spec.origin:
        pkg_root = Path(spec.origin).parent
        for fname in ("version.info", "VERSION", "_version.py"):
            f = pkg_root / fname
            if f.is_file():
                datas.append((str(f), pkg_name))

a = Analysis(
    ["subsync.py"],
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden + [
        "subsync.cli",
        "subsync.gui",
        "subsync.pipeline",
        "subsync.transcribe",
        "subsync.align",
        "subsync.tag",
        "subsync.diarize",
        "subsync.translate",
        "subsync.cps",
        "subsync.export",
        "subsync.ccsl",
        "subsync.burn",
        "subsync.media",
        "subsync.types",
        "subsync.broadcast",
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=["matplotlib", "tests", "test"],
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="subsync",
    debug=False,
    strip=False,
    upx=False,         # UPX often breaks torch/numpy binaries
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="subsync",
)
