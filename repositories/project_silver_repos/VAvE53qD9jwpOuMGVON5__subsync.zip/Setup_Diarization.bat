@echo off
REM ============================================================================
REM  Subsync diarization setup (one-time).
REM
REM  What this does:
REM    1. Installs Python 3.11 if missing (via winget).
REM    2. Creates a Python 3.11 virtual env at .venv311\
REM    3. Installs the pinned torch/torchaudio/pyannote stack into it.
REM    4. Prints HF_TOKEN setup instructions.
REM
REM  After this finishes you can:
REM    - Run build_exe.bat -> bundle now uses the diarization-capable env.
REM    - Or test in dev: .venv311\Scripts\python subsync.py transcribe ... --diarize
REM ============================================================================

setlocal EnableDelayedExpansion
title Subsync - diarization setup
cd /d "%~dp0"

set "VENV=%~dp0.venv311"
set "PYREQ=%~dp0requirements_pyannote.txt"

echo.
echo ============================================================================
echo  Subsync diarization setup
echo ============================================================================
echo.

REM ---- 1. Python 3.11 -----------------------------------------------
echo [1/3] Checking for Python 3.11...
where py >nul 2>&1
if errorlevel 1 (
    echo       Python launcher 'py' not on PATH. Installing Python 3.11 via winget...
    winget install --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo       ERROR: winget install failed. Install Python 3.11 manually from:
        echo         https://www.python.org/downloads/release/python-3119/
        echo       Then re-run this script.
        pause & exit /b 1
    )
    echo.
    echo       Python 3.11 installed. CLOSE THIS WINDOW and re-run Setup_Diarization.bat
    echo       so the new PATH takes effect.
    pause & exit /b 0
)

py -3.11 --version >nul 2>&1
if errorlevel 1 (
    echo       Python launcher works but no 3.11 is installed. Installing via winget...
    winget install --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo       ERROR: winget install failed. Install Python 3.11 manually from:
        echo         https://www.python.org/downloads/release/python-3119/
        echo       Then re-run this script.
        pause & exit /b 1
    )
    echo       Python 3.11 installed. CLOSE THIS WINDOW and re-run Setup_Diarization.bat
    pause & exit /b 0
)
for /f "tokens=2" %%v in ('py -3.11 --version 2^>^&1') do set PYVER=%%v
echo       Python !PYVER! OK

REM ---- 2. Create venv -----------------------------------------------
echo.
echo [2/3] Setting up the Python 3.11 virtual env at .venv311\
if not exist "%VENV%\Scripts\python.exe" (
    py -3.11 -m venv "%VENV%"
    if errorlevel 1 (
        echo       ERROR: venv creation failed.
        pause & exit /b 1
    )
    echo       venv created.
) else (
    echo       venv already exists - reusing it.
)

REM ---- 3. Install deps ----------------------------------------------
echo.
echo [3/3] Installing pinned dependencies (this takes 5-10 min the first time)...
echo       Pulling torch 2.4 + torchaudio 2.4 + pyannote.audio + faster-whisper.
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip --quiet
if errorlevel 1 (
    echo       ERROR: pip upgrade failed.
    pause & exit /b 1
)
"%VENV%\Scripts\python.exe" -m pip install -r "%PYREQ%"
if errorlevel 1 (
    echo.
    echo       ERROR: dependency install failed. See messages above.
    echo       Common cause: no internet, or pip cache is corrupted.
    echo       Try:  "%VENV%\Scripts\python.exe" -m pip cache purge
    echo       Then re-run Setup_Diarization.bat.
    pause & exit /b 1
)

REM ---- 4. Sanity check ----------------------------------------------
echo.
echo [check] Verifying pyannote.audio imports cleanly...
"%VENV%\Scripts\python.exe" -c "import pyannote.audio; print('pyannote.audio', pyannote.audio.__version__, 'OK')" 2>&1
if errorlevel 1 (
    echo.
    echo       Warning: pyannote.audio import failed. The build can still proceed,
    echo       but diarization may not work until this is resolved.
)

echo.
echo ============================================================================
echo  DEPENDENCY SETUP COMPLETE
echo.
echo  Two more things you need to do ONCE before diarization actually runs:
echo.
echo   1. Get a free Hugging Face token:
echo        Visit  https://huggingface.co/settings/tokens
echo        Click  "Create new token"  -^>  pick the "Read" preset  -^>  copy it.
echo.
echo   2. Accept the pyannote model licence (it's free, just a click):
echo        Visit  https://huggingface.co/pyannote/speaker-diarization-3.1
echo        Click  "Agree and access repository"  while logged in.
echo.
echo   3. Save your token as an environment variable (one-time, replace the
echo      placeholder with your actual token):
echo        setx HF_TOKEN "hf_your_real_token_here"
echo      Open a NEW cmd window after running setx for the new env var to apply.
echo.
echo  Once those three are done, re-run build_exe.bat. The new bundle will use
echo  this Python 3.11 env, which means subsync.exe will support speaker
echo  detection ("Detect speakers" checkbox in the GUI).
echo ============================================================================
echo.
pause
