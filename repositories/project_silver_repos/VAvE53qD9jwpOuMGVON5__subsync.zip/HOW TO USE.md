# How to use Subsync

Three ways to use this, from simplest to most flexible.

---

## Option 1 — drag-and-drop (recommended)

You don't touch a terminal after the one-time setup.

**One-time setup**

1. Double-click `Setup.bat`. Wait. It will install Python, ffmpeg, and all dependencies, then optionally pre-download the Whisper model.

That's it. From now on you have these icons:

| Icon | Drop on it |
|---|---|
| `Make Subtitles.bat` | Any video or audio file → outputs `.srt`, `.vtt`, `.subs.json` next to the file |
| `Make Subtitles (full pipeline).bat` | Same but also runs speaker diarization, non-speech tags, Spanish + French translation, and CCSL DOCX |
| `Burn Subtitles into Video.bat` | A video file (it finds the matching `.srt` automatically) → outputs `<video>.subbed.mp4` with hardcoded captions |
| `Open Player.bat` | Opens the in-browser player/editor. Load video + `.subs.json` to review and edit |

**Multi-file drop:** select multiple files in Explorer and drag them all onto `Make Subtitles.bat`. They're processed one after another.

**Speaker diarization needs a token:** open PowerShell once and run
```
setx HF_TOKEN "hf_xxxxxxxxxxxxxxxxxxxxx"
```
Get the token at huggingface.co/settings/tokens, and accept the model licence at huggingface.co/pyannote/speaker-diarization-3.1. Restart any open windows after `setx`.

---

## Option 2 — command line

If you prefer typing.

```powershell
cd C:\Users\aa\Documents\subsync

# Basic
python subsync.py transcribe "C:\videos\episode01.mp4"

# Speaker labels
python subsync.py transcribe "video.mp4" --diarize

# Non-speech events
python subsync.py transcribe "video.mp4" --tag

# Translate
python subsync.py transcribe "video.mp4" --translate es,fr,de

# Build a CCSL DOCX (for translators / dubbing)
python subsync.py transcribe "video.mp4" --ccsl --title "Episode 01"

# All of the above at once
python subsync.py transcribe "video.mp4" --diarize --tag --translate es --ccsl

# Burn an SRT into a video
python subsync.py burn "video.mp4" "video.srt" --style cinema

# Inspect a media file
python subsync.py info "video.mp4"

# Help
python subsync.py transcribe --help
```

---

## Option 3 — single .exe (portable)

If you want one self-contained executable to copy onto another machine.

1. Run `Setup.bat` first so dependencies are installed.
2. Double-click `build_exe.bat`. It runs PyInstaller and produces `dist\subsync\subsync.exe` plus a folder of bundled libraries.
3. Copy the entire `dist\subsync\` folder to the target machine. ffmpeg + ffprobe must still be on PATH there.

The `.exe` will be ~3 GB because torch + transformers + pyannote bundled is huge. First run on a new machine still downloads model weights (~5 GB total to HuggingFace cache).

---

## Output files explained

For input `video.mp4`, you get next to it:

| File | What it is |
|---|---|
| `video.srt` | Standard subtitle file — works in VLC, YouTube, Premiere, anything |
| `video.vtt` | WebVTT — for HTML5 video players |
| `video.subs.json` | Rich source data: language, duration, speakers, events, segments with word-level `{start, end, text, prob, speaker}`, plus CPS readings. Load this in `player.html` for the karaoke editor |
| `video.es.srt`, `video.fr.srt`, … | One per requested target language (when `--translate` is used) |
| `video.ccsl.docx` | Combined Continuity & Spotting List — Word doc with TC In/Out (SMPTE), Speaker, Dialogue, optional Translation column. Used by translators/dubbing |
| `video.subbed.mp4` | Only when you run the burn step — original video with captions hardcoded into the picture |

---

## Browser editor

Double-click `Open Player.bat` (or just open `player.html` in any browser).

1. Click "load video" → pick your video
2. Click "load .subs.json" → pick the matching JSON

You get:

- Word-level karaoke highlighting in real time
- Speaker badges and CPS (characters-per-second) badges (red when too fast)
- Non-speech events shown in italic purple
- Track switcher at the top — original or any translation
- Inline edits: double-click any segment text to edit, click any timestamp to seek, ±100 ms timing nudge, merge ↑ and split @ playhead
- Search box across the transcript
- Re-export to SRT / VTT / JSON for whichever track you have selected

---

## Common quick recipes

**Subtitles for a YouTube upload:** drag the file onto `Make Subtitles.bat`, then drag the resulting .srt next to your video into YouTube's subtitle editor.

**Translated copy for a foreign release:** `Make Subtitles (full pipeline).bat` (or `--translate es` on the CLI). You get `video.es.srt` to embed.

**Hardcoded captions for social media:** `Make Subtitles.bat` first, then drag the same video onto `Burn Subtitles into Video.bat`. Result: `video.subbed.mp4` with the captions baked in.

**Translator handoff for dubbing:** add `--ccsl --title "Episode 01"` and you get a styled DOCX they can fill in.

**Tighter sync at the cost of speed:** add `--align` for sub-100 ms word boundaries (uses stable-ts).

---

## Troubleshooting

- **"python is not recognized"** — run `Setup.bat` again, then close and reopen any open PowerShell/terminal windows. Python's PATH isn't picked up by sessions that were already open.
- **Diarization is skipped silently** — your `HF_TOKEN` isn't set, or you haven't accepted the licence at huggingface.co/pyannote/speaker-diarization-3.1. Set the token with `setx HF_TOKEN "..."` and restart your terminal.
- **First run is very slow** — Whisper downloads ~1.5 GB on first use, NLLB-200 another 2.4 GB if you translate, AST another 340 MB if you tag, pyannote 75 MB if you diarize. All cached after that.
- **CPS pass shreds short cues into single words** — pass `--no-cps` to keep the original Whisper segmentation untouched.
- **Burned-in subtitles look wrong / use the wrong font** — the `cinema` style asks for Inter; if it's not on your system, libass falls back to Liberation Sans. Edit `STYLES` in `subsync/burn.py` to change.
- **Out of memory** — drop to a smaller Whisper model: `--model medium` or `--model small` (or even `tiny.en` for English-only).
