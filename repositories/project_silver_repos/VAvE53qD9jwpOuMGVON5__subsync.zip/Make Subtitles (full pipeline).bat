@echo off
REM ============================================================================
REM  Like Make Subtitles.bat but with the works:
REM    - Speaker diarization (SPEAKER_01, SPEAKER_02, ...)
REM    - Non-speech tags ([Music], [Applause], [Laughter])
REM    - Spanish + French translations
REM    - CCSL DOCX (translator-ready document)
REM
REM  Set your HF_TOKEN once (PowerShell: setx HF_TOKEN "hf_xxxxx") for diarize.
REM  Edit TARGET_LANGS below to change which languages you want translations for.
REM ============================================================================

setlocal EnableDelayedExpansion
title Subsync — full pipeline
cd /d "%~dp0"

set "TARGET_LANGS=es,fr"
set "TITLE=Project"

if "%~1"=="" (
    echo.
    echo  Subsync — Full Pipeline
    echo  =======================
    echo.
    echo  Drag a video or audio file onto this icon.
    echo  This run will transcribe, diarize, tag events,
    echo  translate to !TARGET_LANGS!, and write a CCSL DOCX.
    echo.
    echo  Diarization needs HF_TOKEN. Set it once in PowerShell:
    echo      setx HF_TOKEN "hf_xxxxx"
    echo  ...then close and reopen this window.
    echo.
    pause
    exit /b 0
)

:loop
if "%~1"=="" goto done
set "INPUT=%~1"
set "OUTDIR=%~dp1"
echo.
echo --------------------------------------------------------------------------
echo  Processing: !INPUT!
echo --------------------------------------------------------------------------
python subsync.py transcribe "!INPUT!" --out-dir "!OUTDIR!" ^
    --diarize --tag --translate "!TARGET_LANGS!" ^
    --ccsl --title "!TITLE!"
shift
goto loop
:done
echo.
echo  Done.
pause
