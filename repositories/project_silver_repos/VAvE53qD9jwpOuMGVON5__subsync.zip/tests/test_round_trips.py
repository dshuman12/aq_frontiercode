"""Cross-format round-trip integration tests."""

import os
import pytest
from pathlib import Path
from subsync.types import Transcript, Segment
from subsync.formats import srt, vtt, ass, ttml, scc, dispatch
from subsync.normalize import standard_cleanup
from subsync.qc import run_all
from subsync.delivery import build_package
from subsync.diff import structural_diff, is_clean
from subsync.timing import shift_all, stretch_all


def _build_t(n=5):
    t = Transcript(language="en", duration=float(n * 3))
    for i in range(n):
        seg = Segment(
            start=float(i * 3),
            end=float(i * 3 + 2),
            text="cue {} body text".format(i),
        )
        if i % 2 == 0:
            seg.speaker = "Anna"
        else:
            seg.speaker = "Ben"
        t.segments.append(seg)
    return t


def test_srt_round_trip_preserves_text(tmp_path):
    t = _build_t(5)
    p = tmp_path / "x.srt"
    srt.write(t, str(p))
    rt = srt.read(str(p))
    assert len(rt.segments) == 5
    assert rt.segments[0].text == t.segments[0].text


def test_vtt_round_trip_preserves_speakers(tmp_path):
    t = _build_t(3)
    p = tmp_path / "x.vtt"
    vtt.write(t, str(p), include_speakers=True)
    rt = vtt.read(str(p))
    assert rt.segments[0].speaker == "Anna"


def test_ass_round_trip_text(tmp_path):
    t = _build_t(3)
    p = tmp_path / "x.ass"
    ass.write(t, str(p))
    rt = ass.read(str(p))
    assert rt.segments[0].text == t.segments[0].text


def test_ttml_round_trip_count(tmp_path):
    t = _build_t(4)
    p = tmp_path / "x.ttml"
    ttml.write(t, str(p))
    rt = ttml.read(str(p))
    assert len(rt.segments) == 4


def test_format_inter_convert_via_dispatch(tmp_path):
    t = _build_t(3)
    src = tmp_path / "in.srt"
    dst = tmp_path / "out.vtt"
    dispatch.write(t, str(src))
    rt_src = dispatch.read(str(src))
    dispatch.write(rt_src, str(dst))
    rt_dst = dispatch.read(str(dst))
    assert len(rt_dst.segments) == 3


def test_normalize_then_round_trip_no_data_loss(tmp_path):
    t = _build_t(5)
    standard_cleanup(t, max_chars=100, max_lines=4)
    p = tmp_path / "x.srt"
    srt.write(t, str(p))
    rt = srt.read(str(p))
    assert len(rt.segments) == 5


def test_qc_after_normalize_still_finds_overlap():
    t = _build_t(3)
    t.segments[1].start = t.segments[0].start + 0.5  # overlap
    rpt = run_all(t)
    assert any(i.code == "overlap" for i in rpt.issues)


def test_delivery_build_package_creates_each_format(tmp_path):
    t = _build_t(3)
    out = build_package(t, str(tmp_path / "out"), "youtube",
                        stem="show", language="en")
    assert "srt" in out
    assert "vtt" in out
    for path in out.values():
        assert os.path.exists(path)


def test_delivery_general_recipe(tmp_path):
    t = _build_t(3)
    out = build_package(t, str(tmp_path / "out"), "general",
                        stem="show", language="en")
    assert set(out.keys()) >= {"srt", "vtt", "ass", "ttml"}


def test_shift_then_diff_against_original():
    a = _build_t(3)
    b = _build_t(3)
    shift_all(b, 0.05)
    diffs = structural_diff(a.segments, b.segments)
    # Position changes within tolerance shouldn't trigger 'changed'.
    assert is_clean(diffs) or all(d.kind != "added" and d.kind != "removed"
                                   for d in diffs)


def test_stretch_changes_durations():
    a = _build_t(3)
    stretch_all(a, 2.0)
    assert a.segments[0].end == 4.0


def test_scc_writer_emits_for_every_cue(tmp_path):
    t = _build_t(3)
    p = tmp_path / "x.scc"
    scc.write(t, str(p))
    body = p.read_text()
    in_lines = [ln for ln in body.split("\n") if "942F" in ln.upper()]
    out_lines = [ln for ln in body.split("\n") if "942C" in ln.upper()]
    assert len(in_lines) == 3
    assert len(out_lines) == 3


def test_dispatch_supported_extensions_includes_all_built():
    exts = set(dispatch.supported_extensions())
    for e in (".srt", ".vtt", ".ass", ".ssa", ".ttml", ".scc"):
        assert e in exts


def test_full_pipeline_smoke(tmp_path):
    """Build, normalize, run QC, write each format, read each back."""
    t = _build_t(4)
    standard_cleanup(t)
    rpt = run_all(t)
    for ext in (".srt", ".vtt", ".ass", ".ttml"):
        p = tmp_path / ("test" + ext)
        dispatch.write(t, str(p))
        rt = dispatch.read(str(p))
        assert len(rt.segments) == 4
