"""Tests for delivery and editorial modules."""

import json
import os
import zipfile
import pytest
from subsync.types import Transcript, Segment


def _t(*segs):
    t = Transcript(language="en", duration=max((s.end for s in segs), default=0.0))
    t.segments.extend(segs)
    return t


def _s(start, end, text="hi", speaker=None):
    return Segment(start=start, end=end, text=text, speaker=speaker)


# delivery ---------------------------------------------------------------

from subsync.delivery import (
    DeliveryRecipe, RECIPES, get_recipe, build_package, package_to_zip,
    list_recipes,
)


def test_recipes_present():
    assert "netflix-adult" in RECIPES
    assert "youtube" in RECIPES


def test_get_recipe_returns():
    r = get_recipe("youtube")
    assert r.name == "youtube"


def test_get_recipe_unknown_raises():
    with pytest.raises(KeyError):
        get_recipe("not-a-recipe")


def test_list_recipes_sorted():
    assert list_recipes() == sorted(list_recipes())


def test_build_package_writes_files(tmp_path):
    t = _t(_s(0, 1, text="hi"), _s(2, 3, text="there"))
    out = build_package(t, str(tmp_path), "youtube", stem="show", language="en")
    assert "srt" in out
    assert os.path.exists(out["srt"])
    manifest = json.loads((tmp_path / "manifest.json").read_text())
    assert manifest["recipe"] == "youtube"


def test_build_package_qc_failure_raises(tmp_path):
    # netflix-adult requires QC clean - feed it a bad cue
    t = _t(_s(0, 0.05, text="x" * 100))
    with pytest.raises(RuntimeError):
        build_package(t, str(tmp_path), "netflix-adult", stem="movie")


def test_package_to_zip(tmp_path):
    t = _t(_s(0, 1, text="hi"))
    zip_path = tmp_path / "out.zip"
    package_to_zip(t, str(zip_path), "youtube", stem="show", language="en")
    assert zip_path.exists()
    with zipfile.ZipFile(str(zip_path)) as z:
        names = z.namelist()
    assert any(n.endswith(".srt") for n in names)


def test_recipe_invalid_format_caught():
    bad = DeliveryRecipe(name="bad", description="bad", formats=["zzz"])
    RECIPES["__test_bad"] = bad
    try:
        with pytest.raises(ValueError):
            from subsync.delivery import build_package as _bp
            _bp(_t(_s(0, 1)), "/tmp/zzz_test", "__test_bad", "x")
    finally:
        del RECIPES["__test_bad"]


# editorial --------------------------------------------------------------

from subsync.editorial import (
    find_text, replace_text, insert_cue, delete_cue, split_cue, join_cues,
    find_overlaps, find_short_cues, find_long_cues, cps_per_cue,
    speakers_in_use, rename_speaker, offset_speaker,
)


def test_find_text_case_insensitive():
    t = _t(_s(0, 1, text="Hello world"), _s(2, 3, text="other"))
    found = find_text(t, "hello")
    assert len(found) == 1


def test_find_text_case_sensitive():
    t = _t(_s(0, 1, text="Hello"), _s(2, 3, text="hello"))
    found = find_text(t, "Hello", case_sensitive=True)
    assert len(found) == 1


def test_replace_text():
    t = _t(_s(0, 1, text="cat"), _s(2, 3, text="cat"))
    n = replace_text(t, "cat", "dog")
    assert n == 2
    assert all(s.text == "dog" for s in t.segments)


def test_insert_cue():
    t = _t(_s(0, 1, text="a"), _s(2, 3, text="b"))
    insert_cue(t, 1, _s(1.5, 1.8, text="middle"))
    assert t.segments[1].text == "middle"


def test_delete_cue():
    t = _t(_s(0, 1, text="a"), _s(2, 3, text="b"))
    removed = delete_cue(t, 0)
    assert removed.text == "a"
    assert len(t.segments) == 1


def test_split_cue():
    t = _t(_s(0, 4, text="long"))
    split_cue(t, 0, 2.0)
    assert len(t.segments) == 2
    assert t.segments[0].end == 2.0


def test_split_cue_invalid_position():
    t = _t(_s(0, 4))
    with pytest.raises(ValueError):
        split_cue(t, 0, 5.0)


def test_join_cues():
    t = _t(_s(0, 1, text="a"), _s(1, 2, text="b"), _s(2, 3, text="c"))
    join_cues(t, [0, 1, 2])
    assert len(t.segments) == 1
    assert t.segments[0].text == "a b c"


def test_join_cues_non_contiguous_raises():
    t = _t(_s(0, 1), _s(2, 3), _s(4, 5))
    with pytest.raises(ValueError):
        join_cues(t, [0, 2])


def test_join_cues_too_few():
    t = _t(_s(0, 1))
    with pytest.raises(ValueError):
        join_cues(t, [0])


def test_find_overlaps():
    t = _t(_s(0, 2), _s(1, 3))
    assert find_overlaps(t) == [(0, 1)]


def test_find_short_cues():
    t = _t(_s(0, 0.1), _s(1, 5))
    assert 0 in find_short_cues(t)


def test_find_long_cues():
    t = _t(_s(0, 1), _s(2, 100))
    assert 1 in find_long_cues(t)


def test_cps_per_cue():
    t = _t(_s(0, 1, text="abcdefghij"))
    assert cps_per_cue(t) == [10.0]


def test_speakers_in_use():
    t = _t(_s(0, 1, speaker="A"), _s(2, 3, speaker="B"), _s(4, 5, speaker="A"))
    assert speakers_in_use(t) == ["A", "B"]


def test_rename_speaker():
    t = _t(_s(0, 1, speaker="A"), _s(2, 3, speaker="B"))
    n = rename_speaker(t, "A", "Anna")
    assert n == 1
    assert t.segments[0].speaker == "Anna"


def test_offset_speaker_shifts_only_target():
    t = _t(_s(0, 1, speaker="A"), _s(2, 3, speaker="B"))
    offset_speaker(t, "A", 0.5)
    assert t.segments[0].start == 0.5
    assert t.segments[1].start == 2.0
