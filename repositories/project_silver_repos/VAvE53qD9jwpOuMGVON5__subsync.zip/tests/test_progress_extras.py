"""More progress reporter tests."""

import io
import threading
import time
import pytest
from subsync.progress import ProgressReporter, TextBar, chained, make_tk_sink


def test_progress_initial_zero():
    rp = ProgressReporter(total=10)
    assert rp.fraction == 0.0
    assert rp.current == 0


def test_progress_advance_zero_no_op():
    rp = ProgressReporter(total=10)
    rp.advance(0)
    assert rp.fraction == 0.0


def test_progress_advance_clamps_at_total():
    rp = ProgressReporter(total=10)
    rp.advance(15)
    assert rp.current == 10


def test_progress_set_clamps_low():
    rp = ProgressReporter(total=10)
    rp.set(-5)
    assert rp.current == 0


def test_progress_set_clamps_high():
    rp = ProgressReporter(total=10)
    rp.set(50)
    assert rp.current == 10


def test_progress_set_total_minimum_one():
    rp = ProgressReporter(total=10)
    rp.set_total(0)
    assert rp.total == 1


def test_progress_thread_safe():
    rp = ProgressReporter(total=100)
    def worker():
        for _ in range(50):
            rp.advance()
    threads = [threading.Thread(target=worker) for _ in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert rp.current == 100


def test_progress_elapsed_increases():
    rp = ProgressReporter(total=10)
    e0 = rp.elapsed
    time.sleep(0.05)
    assert rp.elapsed > e0


def test_text_bar_full_progress():
    buf = io.StringIO()
    bar = TextBar(width=10, stream=buf)
    bar(1.0)
    out = buf.getvalue()
    assert "100" in out


def test_text_bar_zero_progress():
    buf = io.StringIO()
    bar = TextBar(width=10, stream=buf)
    bar(0.0)
    out = buf.getvalue()
    assert "0" in out


def test_text_bar_clamps_negative():
    buf = io.StringIO()
    bar = TextBar(width=10, stream=buf)
    bar(-0.5)
    out = buf.getvalue()
    assert "0" in out


def test_text_bar_newline_resets():
    buf = io.StringIO()
    bar = TextBar(width=10, stream=buf)
    bar(0.5)
    bar.newline()
    assert buf.getvalue().count("\n") == 1


def test_chained_distributes_to_multiple():
    a = ProgressReporter(total=10)
    b = ProgressReporter(total=100)
    c = ProgressReporter(total=200)
    sink = chained(a, b, c)
    sink(0.25, "x")
    assert a.current == 2 or a.current == 3
    assert b.current == 25
    assert c.current == 50


def test_make_tk_sink_requires_tkinter_class():
    """If the user passes a non-Tk object, the sink should still be callable
    (it just won't actually update anything)."""
    class FakeBar:
        def __setitem__(self, k, v):
            self.set_value = v

    fake = FakeBar()
    sink = make_tk_sink(fake)
    sink(0.5, "msg")
    # No exception means we're good
