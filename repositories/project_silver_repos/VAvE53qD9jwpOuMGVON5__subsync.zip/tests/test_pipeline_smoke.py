"""Smoke tests for the existing pipeline orchestrator + media wrapper."""

import os
import pytest


def test_pipeline_options_defaults():
    from subsync.pipeline import Options
    from pathlib import Path
    o = Options(input=Path("/tmp/x.mp3"),
                out_dir=Path("/tmp"),
                stem="x")
    assert o.model
    assert o.beam > 0


def test_pipeline_imports():
    from subsync import pipeline
    assert hasattr(pipeline, "run")
    assert hasattr(pipeline, "Options")


def test_media_imports():
    from subsync import media
    # require / run might not exist but module should at least import
    assert media is not None


def test_transcribe_module_imports():
    from subsync import transcribe
    assert transcribe is not None


def test_align_module_imports():
    from subsync import align
    assert align is not None


def test_diarize_module_imports():
    from subsync import diarize
    assert diarize is not None


def test_translate_module_imports():
    from subsync import translate
    assert translate is not None


def test_tag_module_imports():
    from subsync import tag
    assert tag is not None


def test_export_module_imports():
    from subsync import export
    assert export is not None


def test_burn_module_imports():
    from subsync import burn
    assert burn is not None


def test_cli_module_imports():
    from subsync import cli
    assert hasattr(cli, "main")


def test_broadcast_module_has_helpers():
    from subsync import broadcast
    assert hasattr(broadcast, "_hms_ms")


def test_ccsl_has_writer():
    from subsync import ccsl
    assert hasattr(ccsl, "write_ccsl")


def test_cps_module_imports():
    from subsync import cps
    assert cps is not None


def test_subsync_package_version():
    import subsync as pkg
    assert hasattr(pkg, "__version__")
