"""Extended tests for cli_extra subcommands."""

import json
import os
import pytest
from pathlib import Path
from subsync.cli_extra import (
    main as cli_main, cmd_convert, cmd_info, cmd_diff, cmd_validate,
    cmd_wrap, cmd_shift,
)


def _write_srt(path, n_cues=3):
    parts = []
    for i in range(1, n_cues + 1):
        parts.append(str(i))
        parts.append("00:00:0{},000 --> 00:00:0{},500".format(i, i))
        parts.append("cue {}".format(i))
        parts.append("")
    Path(path).write_text("\n".join(parts))


def test_convert_srt_to_vtt(tmp_path):
    src = tmp_path / "in.srt"
    dst = tmp_path / "out.vtt"
    _write_srt(str(src))
    rc = cmd_convert(str(src), str(dst))
    assert rc == 0
    assert dst.read_text().startswith("WEBVTT")


def test_convert_srt_to_ass(tmp_path):
    src = tmp_path / "in.srt"
    dst = tmp_path / "out.ass"
    _write_srt(str(src))
    rc = cmd_convert(str(src), str(dst))
    assert rc == 0
    assert "[Script Info]" in dst.read_text()


def test_convert_srt_to_ttml(tmp_path):
    src = tmp_path / "in.srt"
    dst = tmp_path / "out.ttml"
    _write_srt(str(src))
    rc = cmd_convert(str(src), str(dst))
    assert rc == 0
    assert "<tt" in dst.read_text()


def test_convert_missing_source(tmp_path, capsys):
    rc = cmd_convert("/no/such.srt", str(tmp_path / "x.vtt"))
    cap = capsys.readouterr()
    assert rc == 1
    assert "error reading" in cap.err


def test_info_prints_summary(tmp_path, capsys):
    src = tmp_path / "in.srt"
    _write_srt(str(src), n_cues=5)
    rc = cmd_info(str(src))
    cap = capsys.readouterr()
    assert rc == 0
    assert "cues:" in cap.out
    assert "5" in cap.out


def test_info_missing_file(capsys):
    rc = cmd_info("/no/such.srt")
    cap = capsys.readouterr()
    assert rc == 1


def test_diff_clean(tmp_path):
    a = tmp_path / "a.srt"
    b = tmp_path / "b.srt"
    _write_srt(str(a))
    _write_srt(str(b))
    rc = cmd_diff(str(a), str(b))
    assert rc == 0


def test_diff_dirty(tmp_path):
    a = tmp_path / "a.srt"
    b = tmp_path / "b.srt"
    _write_srt(str(a), n_cues=3)
    _write_srt(str(b), n_cues=5)
    rc = cmd_diff(str(a), str(b))
    assert rc == 1


def test_validate_ok(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src))
    rc = cmd_validate(str(src))
    assert rc == 0


def test_validate_unknown_ext(tmp_path):
    src = tmp_path / "in.xyz"
    src.write_text("hi")
    rc = cmd_validate(str(src))
    assert rc == 1


def test_wrap_in_place(tmp_path):
    src = tmp_path / "in.srt"
    Path(src).write_text("1\n00:00:00,000 --> 00:00:01,000\n" + ("hello " * 30) + "\n")
    rc = cmd_wrap(str(src), max_chars=20, max_lines=4)
    assert rc == 0
    assert "\n" in Path(src).read_text()


def test_shift_positive(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src), n_cues=2)
    rc = cmd_shift(str(src), 1.0)
    assert rc == 0
    body = Path(src).read_text()
    # The first cue should now start at 00:00:02
    assert "00:00:02,000" in body or "00:00:02.000" in body


def test_shift_negative_clamped(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src), n_cues=2)
    rc = cmd_shift(str(src), -100.0)
    assert rc == 0


def test_main_dispatch_convert(tmp_path):
    src = tmp_path / "in.srt"
    dst = tmp_path / "out.vtt"
    _write_srt(str(src))
    rc = cli_main(["convert", str(src), str(dst)])
    assert rc == 0


def test_main_dispatch_info(tmp_path, capsys):
    src = tmp_path / "in.srt"
    _write_srt(str(src))
    rc = cli_main(["info", str(src)])
    assert rc == 0


def test_main_dispatch_diff(tmp_path):
    a = tmp_path / "a.srt"
    b = tmp_path / "b.srt"
    _write_srt(str(a))
    _write_srt(str(b))
    rc = cli_main(["diff", str(a), str(b)])
    assert rc == 0


def test_main_dispatch_validate(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src))
    rc = cli_main(["validate", str(src)])
    assert rc == 0


def test_main_dispatch_wrap_with_flags(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src))
    rc = cli_main(["wrap", str(src), "--max", "30", "--lines", "3"])
    assert rc == 0


def test_main_dispatch_shift(tmp_path):
    src = tmp_path / "in.srt"
    _write_srt(str(src))
    rc = cli_main(["shift", str(src), "0.5"])
    assert rc == 0


def test_main_dispatch_unknown(capsys):
    rc = cli_main(["unknown"])
    assert rc == 2


def test_main_dispatch_no_args(capsys):
    rc = cli_main([])
    assert rc == 2
