"""Tests for serializers and cache."""

import json
import os
import time
import pytest
from subsync.types import Transcript, Segment, Word, Event


def _t():
    t = Transcript(language="en", duration=10.0)
    t.speakers = ["A", "B"]
    t.events.append(Event(start=1.0, end=2.0, label="Music", confidence=0.8))
    s = Segment(start=0.0, end=2.0, text="hello", speaker="A")
    s.words.append(Word(start=0.0, end=0.5, text="hello", prob=0.99))
    s.translations = {"es": "hola"}
    s.cps = 5.0
    t.segments.append(s)
    return t


# Serializers ------------------------------------------------------------

from subsync.serializers import (
    transcript_to_dict, transcript_from_dict,
    save_json, load_json, save_compact_json,
    estimate_size_bytes, cache_key, PROJECT_VERSION,
)


def test_to_dict_round_trip():
    t = _t()
    d = transcript_to_dict(t)
    assert d["_type"] == "Transcript"
    assert d["_version"] == PROJECT_VERSION
    rt = transcript_from_dict(d)
    assert rt.language == t.language
    assert len(rt.segments) == 1
    assert rt.segments[0].text == "hello"
    assert rt.segments[0].words[0].text == "hello"
    assert rt.segments[0].translations == {"es": "hola"}


def test_from_dict_rejects_other_types():
    with pytest.raises(ValueError):
        transcript_from_dict({"_type": "NotATranscript"})


def test_save_load_json_round_trip(tmp_path):
    t = _t()
    p = tmp_path / "out.json"
    save_json(t, str(p))
    rt = load_json(str(p))
    assert rt.duration == t.duration
    assert rt.segments[0].speaker == "A"


def test_save_compact_json_smaller(tmp_path):
    t = _t()
    a = tmp_path / "indented.json"
    b = tmp_path / "compact.json"
    save_json(t, str(a))
    save_compact_json(t, str(b))
    assert os.path.getsize(b) <= os.path.getsize(a)


def test_estimate_size_bytes():
    t = _t()
    n = estimate_size_bytes(t)
    assert n > 0


def test_cache_key_deterministic():
    a = cache_key("/tmp/x.mp3", "tiny", "en")
    b = cache_key("/tmp/x.mp3", "tiny", "en")
    assert a == b


def test_cache_key_changes_with_inputs():
    a = cache_key("/tmp/x.mp3", "tiny", "en")
    b = cache_key("/tmp/x.mp3", "tiny", "es")
    c = cache_key("/tmp/y.mp3", "tiny", "en")
    assert a != b
    assert a != c


def test_cache_key_handles_missing_file():
    # Even when input doesn't exist, key generation works (no stat info appended).
    k = cache_key("/no/such/file", "tiny", "en")
    assert isinstance(k, str)
    assert len(k) >= 8


# Cache ------------------------------------------------------------------

from subsync.cache import (
    cache_dir, ensure_cache_dir, lookup, store, clear, stats, vacuum,
    DEFAULT_CACHE_DIR_ENV,
)


@pytest.fixture
def isolated_cache(tmp_path, monkeypatch):
    monkeypatch.setenv(DEFAULT_CACHE_DIR_ENV, str(tmp_path))
    yield tmp_path


def test_cache_dir_uses_env(isolated_cache):
    assert cache_dir() == isolated_cache


def test_ensure_cache_dir_creates(isolated_cache):
    p = ensure_cache_dir()
    assert p.exists()


def test_store_and_lookup(isolated_cache):
    t = _t()
    store("/tmp/audio.mp3", "tiny", "en", t)
    rt = lookup("/tmp/audio.mp3", "tiny", "en")
    assert rt is not None
    assert rt.segments[0].text == "hello"


def test_lookup_miss_returns_none(isolated_cache):
    assert lookup("/nope.mp3", "tiny", "en") is None


def test_clear_removes_entries(isolated_cache):
    t = _t()
    store("/a.mp3", "tiny", "en", t)
    store("/b.mp3", "tiny", "en", t)
    n = clear()
    assert n >= 2
    assert lookup("/a.mp3", "tiny", "en") is None


def test_stats_reports_count(isolated_cache):
    s0 = stats()
    assert s0["entries"] == 0
    store("/a.mp3", "tiny", "en", _t())
    s1 = stats()
    assert s1["entries"] == 1
    assert s1["size_bytes"] > 0


def test_stats_handles_missing_dir(tmp_path, monkeypatch):
    nonexistent = tmp_path / "no_subdir"
    monkeypatch.setenv(DEFAULT_CACHE_DIR_ENV, str(nonexistent))
    s = stats()
    assert s["entries"] == 0


def test_vacuum_drops_oldest(isolated_cache):
    for i in range(5):
        store("/file_{}.mp3".format(i), "tiny", "en", _t())
        time.sleep(0.01)
    n = vacuum(max_entries=2)
    assert n == 3
    s = stats()
    assert s["entries"] == 2


def test_vacuum_no_op_below_threshold(isolated_cache):
    store("/a.mp3", "tiny", "en", _t())
    n = vacuum(max_entries=10)
    assert n == 0


def test_clear_returns_zero_when_empty(isolated_cache):
    assert clear() == 0
