"""Tests for batch and log_utils."""

import json
import logging
import os
import pytest
from subsync.batch import BatchRunner, BatchResult, SUPPORTED_MEDIA, SUPPORTED_SUBS
from subsync.log_utils import (
    get_logger, add_file_handler, remove_handler, set_level, CapturedRecords,
)


def test_supported_media_constants():
    assert ".mp3" in SUPPORTED_MEDIA
    assert ".mp4" in SUPPORTED_MEDIA
    assert ".srt" in SUPPORTED_SUBS


def test_batch_discover_recursive(tmp_path):
    (tmp_path / "in" / "a").mkdir(parents=True)
    (tmp_path / "in" / "a" / "b.srt").write_text("x")
    (tmp_path / "in" / "c.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"), recursive=True)
    files = r.discover()
    assert len(files) == 2


def test_batch_discover_non_recursive(tmp_path):
    (tmp_path / "in" / "a").mkdir(parents=True)
    (tmp_path / "in" / "a" / "b.srt").write_text("x")
    (tmp_path / "in" / "c.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"), recursive=False)
    files = r.discover()
    assert len(files) == 1


def test_batch_output_for_mirrors_layout(tmp_path):
    (tmp_path / "in" / "x").mkdir(parents=True)
    src = tmp_path / "in" / "x" / "y.mp4"
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))
    out = r.output_for(str(src), ".vtt")
    assert out.endswith(os.path.join("x", "y.vtt"))


def test_batch_run_success(tmp_path):
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "a.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))

    def fake(src, dst):
        with open(dst, "w") as f:
            f.write("ok")
        return True

    r.run(fake)
    assert r.success_count == 1
    assert r.failure_count == 0


def test_batch_progress_callback(tmp_path):
    (tmp_path / "in").mkdir()
    for n in ("a.srt", "b.srt", "c.srt"):
        (tmp_path / "in" / n).write_text("x")
    seen = []
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"),
                    progress_cb=lambda i, total, src: seen.append(i))
    r.run(lambda src, dst: True)
    assert seen == [1, 2, 3]


def test_batch_cancel_mid_run(tmp_path):
    (tmp_path / "in").mkdir()
    for n in ("a.srt", "b.srt", "c.srt"):
        (tmp_path / "in" / n).write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))

    def conv(src, dst):
        r.cancel()
        return True

    r.run(conv)
    assert r.success_count <= 1


def test_batch_stop_on_error(tmp_path):
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "a.srt").write_text("x")
    (tmp_path / "in" / "b.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"),
                    stop_on_error=True)
    def boom(src, dst):
        raise RuntimeError("nope")
    r.run(boom)
    assert r.failure_count == 1


def test_batch_write_json_report(tmp_path):
    r = BatchRunner(str(tmp_path), str(tmp_path / "out"))
    r.results.append(BatchResult("a.srt", "a.srt", True, 0.05, "ok"))
    r.results.append(BatchResult("b.srt", "b.srt", False, 0.10, "boom"))
    p = tmp_path / "r.json"
    r.write_report(str(p))
    body = json.loads(p.read_text())
    assert body["summary"]["ok"] == 1
    assert body["summary"]["failed"] == 1


def test_batch_write_csv_report(tmp_path):
    r = BatchRunner(str(tmp_path), str(tmp_path / "out"))
    r.results.append(BatchResult("a.srt", "a.srt", True, 0.05, "ok"))
    p = tmp_path / "r.csv"
    r.write_csv(str(p))
    body = p.read_text()
    assert "status,elapsed_s" in body
    assert "a.srt" in body


def test_get_logger_idempotent():
    a = get_logger("subsync.t1")
    b = get_logger("subsync.t1")
    assert a is b


def test_set_level_rejects_unknown_uses_default():
    log = get_logger("subsync.t2")
    set_level("INFO", log)
    assert log.level == logging.INFO


def test_captured_records_filters_by_level():
    log = logging.getLogger("subsync.t3")
    with CapturedRecords("subsync.t3", level=logging.WARNING) as cap:
        log.info("ignored")
        log.warning("seen")
    assert cap.has_message("seen")
    assert not cap.has_message("ignored")


def test_add_remove_file_handler(tmp_path):
    log = get_logger("subsync.t4")
    p = str(tmp_path / "log.txt")
    h = add_file_handler(p, level="DEBUG", logger=log)
    log.info("written")
    h.flush()
    remove_handler(h, log)
    h.close()
    assert "written" in open(p).read()
