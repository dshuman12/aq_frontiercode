"""Tests for errors and version modules."""

import pytest
from subsync.errors import (
    SubsyncError, InputError, MissingFileError, UnsupportedMediaError,
    FfmpegMissingError, PipelineError, TranscribeError, AlignError,
    DiarizeError, TranslateError, TagError, ExportError,
    OutputError, FormatError, CCSLValidationError, TimecodeError,
    HFTokenError, ConfigError, DependencyError, MultiError, map_external,
)
from subsync.version import VERSION, version_tuple, is_prerelease


# errors ------------------------------------------------------------------

def test_subsync_error_basic():
    e = SubsyncError("oops")
    assert "oops" in str(e)


def test_subsync_error_with_hint():
    e = SubsyncError("oops", hint="try X")
    assert "try X" in str(e)


def test_inheritance_chain():
    assert issubclass(MissingFileError, InputError)
    assert issubclass(InputError, SubsyncError)
    assert issubclass(TranscribeError, PipelineError)
    assert issubclass(AlignError, PipelineError)
    assert issubclass(DiarizeError, PipelineError)
    assert issubclass(TranslateError, PipelineError)
    assert issubclass(TagError, PipelineError)
    assert issubclass(ExportError, PipelineError)
    assert issubclass(FormatError, OutputError)
    assert issubclass(CCSLValidationError, OutputError)
    assert issubclass(TimecodeError, OutputError)


def test_missing_file_records_path():
    e = MissingFileError("/tmp/x")
    assert e.path == "/tmp/x"


def test_unsupported_media_records_ext():
    e = UnsupportedMediaError(".bmp")
    assert e.ext == ".bmp"


def test_ffmpeg_missing_has_default_hint():
    e = FfmpegMissingError()
    assert e.hint is not None
    assert "ffmpeg" in e.hint.lower()


def test_hf_token_hint_mentions_token():
    e = HFTokenError()
    assert "HF_TOKEN" in str(e)


def test_dependency_default_hint():
    e = DependencyError("foo")
    assert "pip install foo" in str(e)


def test_dependency_custom_hint():
    e = DependencyError("pywin32", install_hint="install pywin32 manually")
    assert "install pywin32 manually" in str(e)


def test_multi_error_iteration():
    e = MultiError([InputError("a"), InputError("b")])
    items = list(e)
    assert len(items) == 2


def test_multi_error_message_includes_count():
    e = MultiError([InputError("x"), InputError("y"), InputError("z")])
    assert "3" in str(e)


def test_map_external_passthrough_for_subsync():
    src = MissingFileError("x")
    assert map_external(src) is src


def test_map_external_filenotfound():
    out = map_external(FileNotFoundError("x"))
    assert isinstance(out, MissingFileError)


def test_map_external_permissionerror():
    out = map_external(PermissionError("x"))
    assert isinstance(out, InputError)


def test_map_external_isadirectoryerror():
    out = map_external(IsADirectoryError("x"))
    assert isinstance(out, InputError)


def test_map_external_torch_cuda_hint():
    out = map_external(RuntimeError("torch CUDA error: out of memory"))
    assert isinstance(out, PipelineError)
    assert out.hint and "cpu" in out.hint.lower()


def test_map_external_generic():
    out = map_external(ValueError("x"))
    assert isinstance(out, SubsyncError)


# version -----------------------------------------------------------------

def test_version_string_format():
    assert isinstance(VERSION, str)
    assert VERSION.count(".") >= 2


def test_version_tuple_three_ints():
    t = version_tuple()
    assert len(t) == 3
    assert all(isinstance(x, int) for x in t)


def test_is_prerelease_consistent():
    if "-" in VERSION:
        assert is_prerelease()
    else:
        assert not is_prerelease()
