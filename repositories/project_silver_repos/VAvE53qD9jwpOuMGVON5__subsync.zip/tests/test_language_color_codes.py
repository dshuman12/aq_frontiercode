"""Tests for language_codes and color_codes."""

import pytest
from subsync.language_codes import (
    LANGUAGES, lookup, to_2, to_3, is_rtl, is_cjk, all_codes, file_suffix,
    Language,
)
from subsync.color_codes import (
    WHITE, GREEN, BLUE, CYAN, RED, YELLOW, MAGENTA, BLACK,
    SPEAKER_DEFAULT, NARRATOR, SOUND_EFFECT,
    name_to_hex, hex_to_nearest_name, CEA_608_FG_CODES,
)


# language_codes ----------------------------------------------------------

def test_all_languages_have_codes():
    for l in LANGUAGES:
        assert l.code_2
        assert l.code_3
        assert l.name


def test_lookup_handles_case():
    assert lookup("EN") is not None
    assert lookup("eng") is not None
    assert lookup("english") is not None
    assert lookup("English") is not None


def test_lookup_strips_whitespace():
    assert lookup("  en  ") is not None


def test_lookup_empty_returns_none():
    assert lookup("") is None
    assert lookup(None) is None


def test_to_2_roundtrip_via_3():
    assert to_2("eng") == "en"
    assert to_2("spa") == "es"


def test_to_3_roundtrip_via_2():
    assert to_3("en") == "eng"
    assert to_3("es") == "spa"


def test_is_rtl_arabic():
    assert is_rtl("ar")


def test_is_rtl_hebrew():
    assert is_rtl("he")


def test_is_rtl_urdu():
    assert is_rtl("ur")


def test_is_rtl_negative():
    assert not is_rtl("en")
    assert not is_rtl("es")


def test_is_cjk_japanese():
    assert is_cjk("ja")


def test_is_cjk_korean():
    assert is_cjk("ko")


def test_is_cjk_chinese():
    assert is_cjk("zh")
    assert is_cjk("zt")


def test_is_cjk_negative():
    assert not is_cjk("en")


def test_all_codes_unique():
    codes = all_codes()
    assert len(codes) == len(set(codes))


def test_file_suffix_zh_traditional():
    assert file_suffix("zt") == ".zh-Hant"


def test_file_suffix_simple_codes():
    for code in ("en", "es", "fr", "ja"):
        assert file_suffix(code) == "." + code


def test_file_suffix_unknown_returns_empty():
    assert file_suffix("xx") == ""


def test_language_dataclass_frozen():
    l = Language("xx", "xxx", "Test")
    with pytest.raises(Exception):
        l.code_2 = "yy"


# color_codes -------------------------------------------------------------

def test_palette_constants():
    assert WHITE == "#FFFFFF"
    assert RED == "#FF0000"
    assert BLACK == "#000000"


def test_role_aliases_match_palette():
    assert SPEAKER_DEFAULT == WHITE
    assert NARRATOR == YELLOW


def test_name_to_hex_all():
    for name in ("white", "green", "blue", "cyan", "red",
                 "yellow", "magenta", "black"):
        assert name_to_hex(name).startswith("#")


def test_name_to_hex_default_white():
    assert name_to_hex("not-a-color") == WHITE
    assert name_to_hex("") == WHITE
    assert name_to_hex(None) == WHITE


def test_hex_to_nearest_name_exact():
    assert hex_to_nearest_name("#FFFFFF") == "white"
    assert hex_to_nearest_name("#000000") == "black"
    assert hex_to_nearest_name("#FFFF00") == "yellow"


def test_hex_to_nearest_name_approx():
    # near-red snaps to red
    assert hex_to_nearest_name("#F00505") == "red"


def test_hex_to_nearest_name_invalid_returns_white():
    assert hex_to_nearest_name("not a hex") == "white"


def test_cea_608_fg_codes_present():
    assert "white" in CEA_608_FG_CODES
    assert "red" in CEA_608_FG_CODES
    # All values are 16-bit codes
    for code in CEA_608_FG_CODES.values():
        assert 0 <= code <= 0xFFFF
