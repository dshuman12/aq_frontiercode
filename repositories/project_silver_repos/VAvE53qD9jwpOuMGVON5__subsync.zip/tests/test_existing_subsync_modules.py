"""Smoke tests for the existing subsync modules (types, ccsl, cps,
broadcast). Light coverage just to exercise the public surface."""

import os
import tempfile
import pytest
from subsync.types import Transcript, Segment, Word, Event, Turn


def test_word_dataclass():
    w = Word(start=0.0, end=1.0, text="hi", prob=0.9, speaker="A")
    assert w.text == "hi"
    assert w.prob == 0.9


def test_segment_to_dict_includes_words():
    s = Segment(start=0.0, end=1.0, text="hi")
    s.words.append(Word(0.0, 0.5, "hi"))
    d = s.to_dict()
    assert "words" in d
    assert d["text"] == "hi"


def test_event_dataclass():
    e = Event(start=0.0, end=1.0, label="Music", confidence=0.8)
    assert e.label == "Music"


def test_turn_dataclass():
    t = Turn(start=0.0, end=1.0, speaker="SPEAKER_01")
    assert t.speaker == "SPEAKER_01"


def test_transcript_to_dict_keys():
    t = Transcript(language="en", duration=5.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="hi"))
    d = t.to_dict()
    assert d["language"] == "en"
    assert d["duration"] == 5.0
    assert len(d["segments"]) == 1


# cps module (existing) --------------------------------------------------

def test_cps_module_imports():
    from subsync import cps as cps_mod
    assert hasattr(cps_mod, "__name__")


# ccsl module (existing) -------------------------------------------------

def test_ccsl_module_imports():
    from subsync import ccsl as ccsl_mod
    assert hasattr(ccsl_mod, "write_ccsl")


# broadcast module (existing) --------------------------------------------

def test_broadcast_module_imports():
    from subsync import broadcast
    assert hasattr(broadcast, "_hms_ms")


# Smoke-check: build a tiny transcript and try our writers + readers ------

from subsync.formats import dispatch


def test_full_round_trip_smoke(tmp_path):
    t = Transcript(language="en", duration=5.0)
    t.segments.append(Segment(start=0.0, end=2.0, text="hello"))
    t.segments.append(Segment(start=3.0, end=5.0, text="world"))

    for ext in (".srt", ".vtt", ".ass", ".ttml"):
        out = tmp_path / ("test" + ext)
        dispatch.write(t, str(out))
        assert out.exists()
        rt = dispatch.read(str(out))
        assert len(rt.segments) >= 1


def test_dispatch_unknown_writer_falls_back(tmp_path):
    """Unknown extension falls back to SRT."""
    t = Transcript(language="en", duration=2.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="hi"))
    out = tmp_path / "weird.xyz"
    dispatch.write(t, str(out))
    assert out.exists()
