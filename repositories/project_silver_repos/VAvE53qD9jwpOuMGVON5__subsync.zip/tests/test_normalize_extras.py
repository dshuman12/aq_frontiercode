"""Extra coverage for normalize.py."""

import pytest
from subsync.types import Transcript, Segment
from subsync.normalize import (
    collapse_whitespace_pass, strip_html_pass, normalise_punctuation_pass,
    rewrap_pass, quantize_to_frames_pass, enforce_minimum_gap_pass,
    merge_short_adjacent_pass, drop_empty_pass, round_timings_pass,
    normalise_speaker_labels_pass, standard_cleanup,
)


def _t(*pairs):
    t = Transcript(language="en", duration=10.0)
    for p in pairs:
        if len(p) == 2:
            start, end = p
            text = "x"
        else:
            start, end, text = p
        t.segments.append(Segment(start=start, end=end, text=text))
    return t


def test_collapse_whitespace_handles_tab():
    t = _t((0, 1, "a\tb\tc"))
    collapse_whitespace_pass(t)
    assert t.segments[0].text == "a b c"


def test_collapse_whitespace_idempotent():
    t = _t((0, 1, "a b c"))
    collapse_whitespace_pass(t)
    collapse_whitespace_pass(t)
    assert t.segments[0].text == "a b c"


def test_strip_html_keeps_plain_text():
    t = _t((0, 1, "no html here"))
    strip_html_pass(t)
    assert t.segments[0].text == "no html here"


def test_strip_html_handles_self_closing():
    t = _t((0, 1, "before<br/>after"))
    strip_html_pass(t)
    assert "<br" not in t.segments[0].text


def test_normalise_punctuation_em_dash():
    t = _t((0, 1, "a—b"))
    normalise_punctuation_pass(t)
    assert "-" in t.segments[0].text


def test_normalise_punctuation_smart_quotes():
    t = _t((0, 1, "“hi”"))
    normalise_punctuation_pass(t)
    assert '"' in t.segments[0].text


def test_rewrap_no_change_for_short_text():
    t = _t((0, 1, "hi"))
    rewrap_pass(t, max_chars=42, max_lines=2)
    assert t.segments[0].text == "hi"


def test_rewrap_creates_newlines():
    t = _t((0, 1, "word " * 30))
    rewrap_pass(t, max_chars=20, max_lines=4)
    assert "\n" in t.segments[0].text


def test_quantize_snaps_to_25fps():
    t = _t((0.123, 0.567))
    quantize_to_frames_pass(t, frame_rate=25.0)
    f = round(t.segments[0].start * 25)
    assert abs(t.segments[0].start - f / 25.0) < 1e-9


def test_enforce_minimum_gap_pushes_forward():
    t = _t((0, 1), (1.05, 2))
    enforce_minimum_gap_pass(t, min_gap=0.5)
    assert t.segments[1].start >= 1.5


def test_merge_short_adjacent_keeps_far_apart():
    t = _t((0, 1, "a"), (5, 6, "b"))
    merge_short_adjacent_pass(t, max_gap=0.2, max_combined_chars=70)
    assert len(t.segments) == 2


def test_merge_short_adjacent_merges_close():
    t = _t((0, 1, "hi"), (1.05, 2, "there"))
    merge_short_adjacent_pass(t, max_gap=0.2)
    assert len(t.segments) == 1


def test_drop_empty_handles_whitespace_only():
    t = _t((0, 1, "   "), (2, 3, "real"))
    drop_empty_pass(t)
    assert len(t.segments) == 1


def test_round_timings_default_decimals():
    t = _t((0.123456789, 0.987654321))
    round_timings_pass(t)
    assert t.segments[0].start == 0.123


def test_round_timings_custom_decimals():
    t = _t((0.123456789, 0.987654321))
    round_timings_pass(t, decimals=1)
    assert t.segments[0].start == 0.1


def test_normalise_speaker_labels_unknown_passthrough():
    t = _t((0, 1, "hi"))
    t.segments[0].speaker = "Anna"
    normalise_speaker_labels_pass(t)
    assert t.segments[0].speaker == "Anna"


def test_normalise_speaker_labels_pyannote_form():
    t = _t((0, 1, "hi"))
    t.segments[0].speaker = "SPEAKER_07"
    normalise_speaker_labels_pass(t)
    assert t.segments[0].speaker == "Speaker 7"


def test_standard_cleanup_returns_transcript():
    t = _t((0, 1, "<i>  hi  there  </i>"))
    out = standard_cleanup(t)
    assert out is t
    assert "<" not in out.segments[0].text


def test_standard_cleanup_drops_empty():
    t = _t((0, 1, ""), (2, 3, "real"))
    standard_cleanup(t)
    assert len(t.segments) == 1
