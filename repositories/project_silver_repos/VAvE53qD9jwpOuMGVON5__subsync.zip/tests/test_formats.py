"""Tests for the formats subpackage."""

import os
import re
import tempfile
import pytest
from subsync.types import Transcript, Segment
from subsync.formats import srt, vtt, ass, ttml, scc, dispatch


def _t(language="en"):
    t = Transcript(language=language, duration=10.0)
    t.segments.extend([
        Segment(start=0.0, end=2.0, text="hello world"),
        Segment(start=3.0, end=5.5, text="line two"),
        Segment(start=6.0, end=10.0, text="line three"),
    ])
    return t


# srt --------------------------------------------------------------------

def test_srt_write_and_read_round_trip(tmp_path):
    t = _t()
    p = tmp_path / "out.srt"
    srt.write(t, str(p))
    text = p.read_text()
    assert "00:00:00,000" in text
    assert "00:00:02,000" in text
    assert "hello world" in text
    rt = srt.read(str(p))
    assert len(rt.segments) == 3
    assert rt.segments[0].text == "hello world"


def test_srt_write_string():
    out = srt.write_string(_t())
    assert "1\n" in out
    assert "hello world" in out


def test_srt_parse_blocks():
    body = "1\n00:00:00,000 --> 00:00:02,000\nhi\n\n2\n00:00:02,500 --> 00:00:04,000\nthere\n"
    segs = srt.parse_blocks(body)
    assert len(segs) == 2
    assert segs[0].text == "hi"


def test_srt_detect():
    assert srt.detect("00:00:00,000 --> 00:00:01,000")
    assert not srt.detect("WEBVTT\n")


def test_srt_shift():
    t = _t()
    shifted = srt.shift(t, 1.0)
    assert shifted.segments[0].start == 1.0
    assert shifted.segments[0].end == 3.0


def test_srt_split_long_cues():
    t = Transcript(language="en", duration=20.0)
    t.segments.append(Segment(start=0.0, end=20.0, text="A. B. C. D. E."))
    out = srt.split_long_cues(t, max_seconds=4.0)
    assert len(out.segments) >= 2


def test_srt_dot_separator_accepted():
    body = "1\n00:00:00.000 --> 00:00:01.000\nx\n"
    segs = srt.parse_blocks(body)
    assert len(segs) == 1


# vtt --------------------------------------------------------------------

def test_vtt_round_trip(tmp_path):
    t = _t()
    p = tmp_path / "out.vtt"
    vtt.write(t, str(p))
    text = p.read_text()
    assert text.startswith("WEBVTT")
    assert "00:00:00.000 --> 00:00:02.000" in text
    rt = vtt.read(str(p))
    assert len(rt.segments) == 3


def test_vtt_voice_span_round_trip(tmp_path):
    t = Transcript(language="en", duration=2.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="hi", speaker="Anna"))
    p = tmp_path / "out.vtt"
    vtt.write(t, str(p), include_speakers=True)
    text = p.read_text()
    assert "<v Anna>" in text
    rt = vtt.read(str(p))
    assert rt.segments[0].speaker == "Anna"


def test_vtt_detect():
    assert vtt.detect("WEBVTT\n\n00:00.000 --> 00:01.000\nhi")
    assert not vtt.detect("1\n00:00:00,000 --> 00:00:01,000\nhi")


def test_vtt_from_srt_helper():
    body = "1\n00:00:00,500 --> 00:00:01,500\nhi\n"
    t = vtt.from_srt(body)
    assert len(t.segments) == 1


# ass --------------------------------------------------------------------

def test_ass_round_trip(tmp_path):
    t = _t()
    t.segments[0].speaker = "Anna"
    p = tmp_path / "out.ass"
    ass.write(t, str(p))
    text = p.read_text()
    assert "[Script Info]" in text
    assert "Dialogue:" in text
    rt = ass.read(str(p))
    assert len(rt.segments) == 3
    assert rt.segments[0].speaker == "Anna"


def test_ass_detect():
    assert ass.detect("[Script Info]\nTitle: x\n[V4+ Styles]\n")
    assert not ass.detect("WEBVTT\n")


def test_ass_text_with_newline_escaped(tmp_path):
    t = Transcript(language="en", duration=2.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="line1\nline2"))
    p = tmp_path / "out.ass"
    ass.write(t, str(p))
    assert "\\N" in p.read_text()


# ttml -------------------------------------------------------------------

def test_ttml_round_trip(tmp_path):
    t = _t()
    p = tmp_path / "out.ttml"
    ttml.write(t, str(p))
    text = p.read_text()
    assert text.startswith("<?xml")
    assert "<tt" in text
    assert "<p" in text
    rt = ttml.read(str(p))
    assert len(rt.segments) == 3


def test_ttml_xml_escapes_special_chars(tmp_path):
    t = Transcript(language="en", duration=1.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="2 < 3 & 4 > 1"))
    p = tmp_path / "out.ttml"
    ttml.write(t, str(p))
    text = p.read_text()
    assert "&lt;" in text
    assert "&amp;" in text
    assert "&gt;" in text


def test_ttml_detect():
    assert ttml.detect('<?xml version="1.0"?>\n<tt xmlns="http://www.w3.org/ns/ttml">')
    assert not ttml.detect("WEBVTT\n")


# scc --------------------------------------------------------------------

def test_scc_writer_emits_header(tmp_path):
    p = tmp_path / "out.scc"
    scc.write(_t(), str(p))
    text = p.read_text()
    assert text.startswith("Scenarist_SCC V1.0")


def test_scc_writer_per_cue_lines(tmp_path):
    p = tmp_path / "out.scc"
    scc.write(_t(), str(p))
    text = p.read_text()
    # Each cue produces an in-line and an out-line.
    timing_lines = [ln for ln in text.split("\n") if "\t" in ln]
    assert len(timing_lines) >= 2 * 3


def test_scc_detect():
    assert scc.detect("Scenarist_SCC V1.0\n")


# dispatch ---------------------------------------------------------------

def test_dispatch_picks_writer_by_ext(tmp_path):
    out = tmp_path / "x.vtt"
    dispatch.write(_t(), str(out))
    assert out.read_text().startswith("WEBVTT")


def test_dispatch_picks_reader_by_ext(tmp_path):
    out = tmp_path / "x.srt"
    srt.write(_t(), str(out))
    rt = dispatch.read(str(out))
    assert len(rt.segments) == 3


def test_dispatch_supported_extensions():
    exts = dispatch.supported_extensions()
    assert ".srt" in exts
    assert ".vtt" in exts
    assert ".ass" in exts
    assert ".ttml" in exts
    assert ".scc" in exts


def test_dispatch_falls_back_to_srt_for_unknown(tmp_path):
    p = tmp_path / "weird.xyz"
    p.write_text("1\n00:00:00,000 --> 00:00:01,000\nhi\n")
    rt = dispatch.read(str(p))
    assert len(rt.segments) == 1
