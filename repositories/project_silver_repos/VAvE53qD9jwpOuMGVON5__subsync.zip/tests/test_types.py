"""Tests for the core types."""
from subsync.types import Transcript, Segment, Word, Event, Turn


def test_word_default():
    w = Word(start=0.0, end=1.0, text='hi')
    assert w.text == 'hi'


def test_segment_to_dict():
    s = Segment(start=0.0, end=1.0, text='hi')
    d = s.to_dict()
    assert d['text'] == 'hi'


def test_transcript_to_dict():
    t = Transcript(language='en', duration=2.0)
    t.segments.append(Segment(start=0.0, end=1.0, text='x'))
    d = t.to_dict()
    assert d['language'] == 'en'
    assert len(d['segments']) == 1
