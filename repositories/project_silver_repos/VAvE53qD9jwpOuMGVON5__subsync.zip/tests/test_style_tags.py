"""Tests for style_tags module."""

import pytest
from subsync.style_tags import (
    ITALIC_OPEN, ITALIC_CLOSE, BOLD_OPEN, BOLD_CLOSE,
    UNDERLINE_OPEN, UNDERLINE_CLOSE, COLOR_CLOSE,
    to_vtt, to_ttml, to_ass, to_plain, from_vtt, from_ass,
    open_color, color_to_vtt, color_to_ass, color_to_ttml,
    has_styling,
)


def test_to_vtt_italic():
    out = to_vtt(ITALIC_OPEN + "hi" + ITALIC_CLOSE)
    assert out == "<i>hi</i>"


def test_to_vtt_bold():
    out = to_vtt(BOLD_OPEN + "x" + BOLD_CLOSE)
    assert out == "<b>x</b>"


def test_to_ttml_italic():
    out = to_ttml(ITALIC_OPEN + "hi" + ITALIC_CLOSE)
    assert "fontStyle" in out


def test_to_ttml_bold():
    out = to_ttml(BOLD_OPEN + "x" + BOLD_CLOSE)
    assert "fontWeight" in out


def test_to_ass_italic():
    out = to_ass(ITALIC_OPEN + "hi" + ITALIC_CLOSE)
    assert r"\i1" in out and r"\i0" in out


def test_to_plain_strips_sentinels():
    out = to_plain(ITALIC_OPEN + "hi" + ITALIC_CLOSE)
    assert out == "hi"


def test_from_vtt_normalises():
    out = from_vtt("<i>x</i>")
    assert ITALIC_OPEN in out
    assert ITALIC_CLOSE in out


def test_from_ass_normalises_and_drops_unknown():
    out = from_ass(r"{\i1}hi{\i0}{\an8}")
    assert ITALIC_OPEN in out
    assert "{\\an8}" not in out


def test_open_color_hex():
    out = open_color("hi", "#FF0000")
    assert "[[c=#FF0000]]" in out
    assert COLOR_CLOSE in out


def test_open_color_named():
    out = open_color("hi", "red")
    assert "[[c=red]]" in out


def test_color_to_vtt_named():
    out = color_to_vtt("[[c=red]]hi[[/c]]")
    assert "<c.red>" in out
    assert "</c>" in out


def test_color_to_vtt_hex():
    out = color_to_vtt("[[c=#FF0000]]hi[[/c]]")
    assert "<c.x" in out


def test_color_to_ttml():
    out = color_to_ttml("[[c=red]]hi[[/c]]")
    assert 'tts:color="' in out
    assert "</span>" in out


def test_color_to_ass_hex():
    out = color_to_ass("[[c=#FF0000]]hi[[/c]]")
    assert r"\c&H" in out


def test_has_styling_detects_sentinel():
    assert has_styling(ITALIC_OPEN + "hi" + ITALIC_CLOSE)


def test_has_styling_detects_color():
    assert has_styling("[[c=red]]hi[[/c]]")


def test_has_styling_negative():
    assert not has_styling("plain text")


def test_underline_round_trip():
    s = "[[u]]hi[[/u]]"
    out = to_vtt(s)
    assert "<u>hi</u>" == out
    back = from_vtt(out)
    assert back == s


def test_to_plain_strips_underline_too():
    s = UNDERLINE_OPEN + "hi" + UNDERLINE_CLOSE
    assert to_plain(s) == "hi"
