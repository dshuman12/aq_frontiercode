"""Tests for text_utils."""

import pytest
from subsync.text_utils import (
    DEFAULT_MAX_CHARS_PER_LINE, DEFAULT_MAX_LINES,
    wrap_dialogue, collapse_whitespace, normalise_punctuation, strip_html,
    detect_language_hints, censor, mask_pii,
    normalise_speaker_label, insert_speaker_prefix,
    chars_no_spaces, chars_visible, split_long_segment,
)


def test_collapse_whitespace_multiple_spaces():
    assert collapse_whitespace("hello   world") == "hello world"


def test_collapse_whitespace_strips_ends():
    assert collapse_whitespace("  hi  ") == "hi"


def test_collapse_whitespace_empty():
    assert collapse_whitespace("") == ""
    assert collapse_whitespace(None) == ""


def test_normalise_punctuation_quotes():
    assert normalise_punctuation("“hi”") == '"hi"'


def test_normalise_punctuation_emdash():
    assert normalise_punctuation("a—b") == "a-b"


def test_normalise_punctuation_ellipsis():
    assert normalise_punctuation("wait…") == "wait..."


def test_strip_html_tags():
    assert strip_html("<i>hello</i>") == "hello"


def test_strip_html_nested():
    assert strip_html("<b><i>hi</i></b> there") == "hi there"


def test_wrap_short_text_one_line():
    out = wrap_dialogue("hello world")
    assert out == ["hello world"]


def test_wrap_long_text_two_lines():
    out = wrap_dialogue("a " * 50, max_chars=20, max_lines=4)
    assert all(len(line) <= 20 for line in out)


def test_wrap_respects_max_lines():
    out = wrap_dialogue("word " * 100, max_chars=10, max_lines=2)
    assert len(out) <= 2


def test_wrap_truncates_with_ellipsis():
    out = wrap_dialogue("word " * 100, max_chars=10, max_lines=2)
    assert out[-1].endswith("…") or len(out[-1]) <= 10


def test_detect_language_hints_latin():
    counts = detect_language_hints("hello world")
    assert counts["latin"] > 0
    assert counts["cjk"] == 0


def test_detect_language_hints_cjk():
    counts = detect_language_hints("你好")
    assert counts["cjk"] >= 2


def test_detect_language_hints_arabic():
    counts = detect_language_hints("السلام")
    assert counts["arabic"] >= 1


def test_censor_replaces_words():
    out = censor("damn that hurts", ["damn"], replacement="[bleep]")
    assert out == "[bleep] that hurts"


def test_censor_case_insensitive():
    out = censor("Damn that hurts", ["damn"])
    assert out.startswith("[bleep]")


def test_censor_empty_list_passthrough():
    assert censor("hello", []) == "hello"


def test_mask_pii_email():
    out = mask_pii("contact me at jane@example.com")
    assert "[email]" in out


def test_mask_pii_phone():
    out = mask_pii("call +1 415 555 1234 today")
    assert "[phone]" in out


def test_normalise_speaker_label_underscore():
    assert normalise_speaker_label("SPEAKER_03") == "Speaker 3"


def test_normalise_speaker_label_passthrough():
    assert normalise_speaker_label("Anna") == "Anna"


def test_insert_speaker_prefix():
    assert insert_speaker_prefix("hi", "Anna") == "Anna: hi"


def test_chars_no_spaces():
    assert chars_no_spaces("a b c") == 3


def test_chars_visible_strips_combining():
    assert chars_visible("ab") == 2


def test_split_long_segment_short_passthrough():
    assert split_long_segment("hi", target_chars=100) == ["hi"]


def test_split_long_segment_breaks():
    text = "Sentence one. Sentence two. Sentence three."
    out = split_long_segment(text, target_chars=20)
    assert len(out) >= 2


def test_default_constants():
    assert DEFAULT_MAX_CHARS_PER_LINE > 0
    assert DEFAULT_MAX_LINES > 0
