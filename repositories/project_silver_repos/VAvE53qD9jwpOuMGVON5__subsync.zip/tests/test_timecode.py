"""Tests for the timecode module."""

import pytest
from subsync.timecode import (
    is_drop_frame, total_frames, seconds_to_smpte, smpte_to_seconds,
    seconds_to_srt, seconds_to_vtt, srt_to_seconds,
    quantize_to_frame, quantize_segment, add_offset,
    FrameRange, merge_frame_ranges,
    RATE_FILM, RATE_PAL, RATE_NTSC_NDF, RATE_NTSC_DF, RATE_HFR_NTSC_DF,
)


def test_is_drop_frame_ntsc():
    assert is_drop_frame(RATE_NTSC_DF)
    assert not is_drop_frame(RATE_PAL)
    assert not is_drop_frame(RATE_NTSC_NDF)


def test_total_frames_basic():
    assert total_frames(1.0, 25.0) == 25
    assert total_frames(2.5, 25.0) == 62
    assert total_frames(0.04, 25.0) == 1


def test_total_frames_clamp_negative():
    assert total_frames(-1.0, 25.0) == 0


def test_seconds_to_srt_basic():
    assert seconds_to_srt(0.0) == "00:00:00,000"
    assert seconds_to_srt(1.5) == "00:00:01,500"
    assert seconds_to_srt(3661.123) == "01:01:01,123"


def test_seconds_to_vtt_uses_dot():
    s = seconds_to_vtt(1.5)
    assert s == "00:00:01.500"


def test_srt_to_seconds_round_trip():
    for v in [0.0, 0.5, 1.234, 3661.987]:
        assert abs(srt_to_seconds(seconds_to_srt(v)) - v) < 0.002


def test_srt_to_seconds_accepts_dot():
    assert srt_to_seconds("00:00:01.500") == 1.5


def test_smpte_pal_round_trip():
    for v in [0.0, 1.0, 2.5, 60.04, 3600.0]:
        rt = smpte_to_seconds(seconds_to_smpte(v, RATE_PAL), RATE_PAL)
        assert abs(rt - v) <= 1.0 / RATE_PAL


def test_smpte_ndf_round_trip():
    for v in [0.0, 0.5, 12.4]:
        rt = smpte_to_seconds(seconds_to_smpte(v, RATE_NTSC_NDF), RATE_NTSC_NDF)
        assert abs(rt - v) <= 1.0 / RATE_NTSC_NDF


def test_smpte_df_uses_semicolon():
    s = seconds_to_smpte(1.0, RATE_NTSC_DF)
    assert ";" in s


def test_smpte_invalid_format():
    with pytest.raises(ValueError):
        smpte_to_seconds("not a timecode")


def test_quantize_to_frame_snaps():
    assert abs(quantize_to_frame(0.123, 25.0) - 0.12) < 1e-6


def test_quantize_segment_enforces_min():
    s, e = quantize_segment(0.0, 0.0, 25.0, min_frames=2)
    assert e - s >= 2 / 25.0


def test_add_offset():
    assert add_offset(1.0, 25, 25.0) == 2.0


def test_frame_range_basic():
    r = FrameRange(0, 25, 25.0)
    assert r.duration_seconds() == 1.0
    assert r.contains(0)
    assert r.contains(24)
    assert not r.contains(25)


def test_frame_range_overlaps():
    a = FrameRange(0, 25, 25.0)
    b = FrameRange(20, 50, 25.0)
    c = FrameRange(60, 100, 25.0)
    assert a.overlaps(b)
    assert not a.overlaps(c)


def test_frame_range_union():
    a = FrameRange(0, 25, 25.0)
    b = FrameRange(20, 50, 25.0)
    u = a.union(b)
    assert u.start_frame == 0
    assert u.end_frame == 50


def test_merge_frame_ranges():
    rs = [
        FrameRange(0, 10, 25.0),
        FrameRange(8, 20, 25.0),
        FrameRange(30, 40, 25.0),
    ]
    merged = merge_frame_ranges(rs)
    assert len(merged) == 2
    assert merged[0].start_frame == 0
    assert merged[0].end_frame == 20
    assert merged[1].start_frame == 30


def test_merge_frame_ranges_empty():
    assert merge_frame_ranges([]) == []
