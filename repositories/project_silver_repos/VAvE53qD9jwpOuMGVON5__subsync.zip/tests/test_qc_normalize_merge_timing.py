"""Tests for qc, normalize, merge, timing, audio_utils."""

import pytest
from subsync.types import Transcript, Segment


def _seg(start, end, text="hi", speaker=None):
    return Segment(start=start, end=end, text=text, speaker=speaker)


def _t(*segs):
    t = Transcript(language="en", duration=max((s.end for s in segs), default=0.0))
    t.segments.extend(segs)
    return t


# qc tests ----------------------------------------------------------------

from subsync.qc import (
    QcIssue, QcReport, run_all, run_for_preset,
    check_overlapping_cues, check_minimum_duration, check_maximum_duration,
    check_reading_speed, check_line_length, check_max_lines,
    check_empty_text, check_negative_or_inverted_timings,
)


def test_overlap_detected():
    t = _t(_seg(0, 2), _seg(1, 3))
    issues = check_overlapping_cues(t)
    assert issues
    assert issues[0].code == "overlap"


def test_no_overlap_clean():
    t = _t(_seg(0, 2), _seg(3, 5))
    assert check_overlapping_cues(t) == []


def test_minimum_duration_flagged():
    t = _t(_seg(0, 0.1))
    issues = check_minimum_duration(t)
    assert issues


def test_maximum_duration_flagged():
    t = _t(_seg(0, 100))
    issues = check_maximum_duration(t)
    assert issues


def test_reading_speed_flagged():
    t = _t(_seg(0, 1, text="x" * 200))
    issues = check_reading_speed(t)
    assert any(i.code in ("reading_speed", "reading_speed_soft") for i in issues)


def test_line_length_flagged():
    long_line = "x" * 100
    t = _t(_seg(0, 1, text=long_line))
    issues = check_line_length(t, max_chars=42)
    assert issues


def test_max_lines_flagged():
    t = _t(_seg(0, 1, text="a\nb\nc\nd"))
    issues = check_max_lines(t, max_lines=2)
    assert issues


def test_empty_text_flagged():
    t = _t(_seg(0, 1, text=""))
    issues = check_empty_text(t)
    assert issues


def test_negative_time_flagged():
    t = _t(_seg(-1, 0))
    issues = check_negative_or_inverted_timings(t)
    assert any(i.code == "negative_time" for i in issues)


def test_inverted_time_flagged():
    t = _t(_seg(2, 1))
    issues = check_negative_or_inverted_timings(t)
    assert any(i.code == "inverted_time" for i in issues)


def test_run_all_combines_checks():
    t = _t(_seg(0, 0.1, text=""))
    rpt = run_all(t)
    assert rpt.warnings or rpt.errors
    assert "issue" in rpt.text_report()


def test_run_for_preset_uses_preset_constraints():
    t = _t(_seg(0, 1, text="x" * 100))
    rpt = run_for_preset(t, "netflix-adult")
    assert any(i.code == "reading_speed" for i in rpt.issues)


def test_run_for_unknown_preset_raises():
    t = _t(_seg(0, 1))
    with pytest.raises(KeyError):
        run_for_preset(t, "no-such")


def test_qc_report_clean_when_empty():
    rpt = QcReport(issues=[])
    assert rpt.is_clean


# normalize tests ---------------------------------------------------------

from subsync.normalize import (
    collapse_whitespace_pass, strip_html_pass, normalise_punctuation_pass,
    rewrap_pass, quantize_to_frames_pass, enforce_minimum_gap_pass,
    merge_short_adjacent_pass, drop_empty_pass, round_timings_pass,
    normalise_speaker_labels_pass, standard_cleanup,
)


def test_collapse_whitespace_pass():
    t = _t(_seg(0, 1, text="a   b  c"))
    collapse_whitespace_pass(t)
    assert t.segments[0].text == "a b c"


def test_strip_html_pass():
    t = _t(_seg(0, 1, text="<i>hi</i>"))
    strip_html_pass(t)
    assert t.segments[0].text == "hi"


def test_normalise_punctuation_pass():
    t = _t(_seg(0, 1, text="“hi”"))
    normalise_punctuation_pass(t)
    assert '"' in t.segments[0].text


def test_rewrap_pass():
    t = _t(_seg(0, 1, text="word " * 30))
    rewrap_pass(t, max_chars=20, max_lines=3)
    assert "\n" in t.segments[0].text


def test_quantize_to_frames_pass():
    t = _t(_seg(0.123, 0.567))
    quantize_to_frames_pass(t, frame_rate=25.0)
    # Either start or end should snap to frame boundaries
    assert abs(t.segments[0].start * 25.0 - round(t.segments[0].start * 25.0)) < 1e-6


def test_enforce_minimum_gap_pass():
    t = _t(_seg(0, 1), _seg(1, 2))
    enforce_minimum_gap_pass(t, min_gap=0.5)
    assert t.segments[1].start >= 1.5


def test_merge_short_adjacent_pass():
    t = _t(_seg(0, 0.5, text="hi"), _seg(0.6, 1.2, text="there"))
    merge_short_adjacent_pass(t, max_gap=0.2, max_combined_chars=70)
    assert len(t.segments) == 1


def test_drop_empty_pass():
    t = _t(_seg(0, 1, text=""), _seg(2, 3, text="ok"))
    drop_empty_pass(t)
    assert len(t.segments) == 1


def test_round_timings_pass():
    t = _t(_seg(0.123456, 1.234567))
    round_timings_pass(t, decimals=3)
    assert t.segments[0].start == 0.123


def test_normalise_speaker_labels_pass():
    t = _t(_seg(0, 1, speaker="SPEAKER_03"))
    normalise_speaker_labels_pass(t)
    assert t.segments[0].speaker == "Speaker 3"


def test_standard_cleanup_runs():
    t = _t(_seg(0, 1, text="<i>hi   there</i>"))
    standard_cleanup(t)
    assert "<" not in t.segments[0].text


# merge tests -------------------------------------------------------------

from subsync.merge import (
    merge_concat, merge_overlay, merge_by_language,
    split_by_speaker, deduplicate,
)


def test_merge_concat_offsets():
    a = _t(_seg(0, 1, text="a1"))
    b = _t(_seg(0, 1, text="b1"))
    out = merge_concat([a, b])
    assert len(out.segments) == 2
    assert out.segments[1].start >= 1.0


def test_merge_overlay_prefer_primary():
    a = _t(_seg(0, 1, text="a"))
    b = _t(_seg(0, 1, text="b"), _seg(2, 3, text="bonus"))
    out = merge_overlay(a, b, prefer="primary")
    # primary "a" wins on overlap, but bonus from b included
    texts = [s.text for s in out.segments]
    assert "a" in texts
    assert "bonus" in texts


def test_merge_overlay_both():
    a = _t(_seg(0, 1, text="a"))
    b = _t(_seg(0, 1, text="b"))
    out = merge_overlay(a, b, prefer="both")
    assert len(out.segments) == 2


def test_merge_by_language_pick():
    out = merge_by_language({"en": _t(_seg(0, 1, text="hi"))}, "en")
    assert out.segments[0].text == "hi"


def test_merge_by_language_missing():
    with pytest.raises(KeyError):
        merge_by_language({}, "en")


def test_split_by_speaker():
    t = _t(_seg(0, 1, speaker="A"), _seg(2, 3, speaker="B"), _seg(4, 5))
    out = split_by_speaker(t)
    assert "A" in out
    assert "B" in out
    assert "unknown" in out


def test_deduplicate():
    t = _t(_seg(0, 1, text="hi"), _seg(0.01, 1, text="hi"))
    deduplicate(t)
    assert len(t.segments) == 1


# timing tests ------------------------------------------------------------

from subsync.timing import (
    shift_all, stretch_all, clamp_to_range, two_point_resync,
    quantize_all, gap_at, cue_at, adjacent_pairs,
)


def test_shift_all_positive():
    t = _t(_seg(1, 2))
    shift_all(t, 1.0)
    assert t.segments[0].start == 2.0


def test_shift_all_clamped_at_zero():
    t = _t(_seg(0.5, 1.5))
    shift_all(t, -2.0)
    assert t.segments[0].start == 0.0


def test_stretch_all():
    t = _t(_seg(0, 1))
    stretch_all(t, 2.0)
    assert t.segments[0].end == 2.0


def test_stretch_all_invalid_factor():
    with pytest.raises(ValueError):
        stretch_all(_t(_seg(0, 1)), 0.0)


def test_clamp_to_range_drops_out_of_range():
    t = _t(_seg(0, 1), _seg(5, 10), _seg(20, 30))
    clamp_to_range(t, max_end=15.0)
    assert len(t.segments) == 2


def test_two_point_resync():
    t = _t(_seg(10, 11), _seg(50, 51))
    two_point_resync(t, anchor_a=(10, 0), anchor_b=(50, 40))
    assert t.segments[0].start == 0.0
    assert t.segments[1].start == 40.0


def test_two_point_resync_distinct_anchors_required():
    with pytest.raises(ValueError):
        two_point_resync(_t(_seg(0, 1)), (1.0, 0.0), (1.0, 5.0))


def test_quantize_all_snaps_to_frame():
    t = _t(_seg(0.123, 0.567))
    quantize_all(t, frame_rate=25.0)
    assert abs(t.segments[0].start * 25.0 - round(t.segments[0].start * 25.0)) < 1e-6


def test_gap_at_finds_gap():
    t = _t(_seg(0, 1), _seg(3, 4))
    assert gap_at(t, 2.0) == (1.0, 3.0)


def test_gap_at_returns_none_when_in_cue():
    t = _t(_seg(0, 1))
    assert gap_at(t, 0.5) is None


def test_cue_at_finds_active():
    t = _t(_seg(0, 1), _seg(3, 4))
    assert cue_at(t, 0.5).text == "hi"


def test_adjacent_pairs():
    t = _t(_seg(0, 1), _seg(2, 3), _seg(4, 5))
    pairs = adjacent_pairs(t)
    assert len(pairs) == 2


# audio_utils tests -------------------------------------------------------

from subsync.audio_utils import (
    detect_silence_from_rms, gaps_between_segments, coverage_ratio,
    overlap_count, parse_wav_header, best_resample_target,
    SR_AUDIOBOOK, SR_BROADCAST, WHISPER_SR,
)


def test_detect_silence_all_silent():
    silence = detect_silence_from_rms([0.0] * 1600, sr=16000, window_ms=50)
    assert silence


def test_gaps_between_segments():
    segs = [_seg(0, 1), _seg(2, 3)]
    gaps = gaps_between_segments(segs, min_gap=0.5)
    assert gaps == [(1.0, 2.0)]


def test_coverage_ratio():
    segs = [_seg(0, 5), _seg(5, 10)]
    assert coverage_ratio(segs, 10.0) == 1.0


def test_coverage_ratio_zero_duration():
    assert coverage_ratio([], 0) == 0.0


def test_overlap_count():
    segs = [_seg(0, 2), _seg(1, 3), _seg(4, 5)]
    assert overlap_count(segs) == 1


def test_parse_wav_header_invalid():
    assert parse_wav_header(b"NOTRIFF") is None


def test_best_resample_target():
    assert best_resample_target(8000) == 8000
    assert best_resample_target(44100) == SR_BROADCAST
    assert best_resample_target(96000) == 96000
