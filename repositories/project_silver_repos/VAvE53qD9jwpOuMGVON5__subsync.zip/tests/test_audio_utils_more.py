"""Extra coverage for audio_utils."""

import struct
import pytest
from subsync.audio_utils import (
    SilenceSpan, detect_silence_from_rms, gaps_between_segments,
    coverage_ratio, overlap_count, parse_wav_header, best_resample_target,
    SR_TELEPHONY, SR_AUDIOBOOK, SR_BROADCAST, SR_HIRES, WHISPER_SR,
)
from subsync.types import Segment


def _seg(s, e):
    return Segment(start=s, end=e, text="x")


def test_silence_span_duration():
    sp = SilenceSpan(0.0, 1.0, 0.001)
    assert sp.duration == 1.0


def test_silence_span_negative_duration_clamped():
    sp = SilenceSpan(2.0, 1.0, 0.001)
    assert sp.duration == 0.0


def test_detect_silence_from_speech_only():
    # All loud samples - no silence detected
    samples = [0.5] * 8000
    out = detect_silence_from_rms(samples, sr=16000, window_ms=50,
                                   threshold_dbfs=-90.0)
    assert out == []


def test_detect_silence_mixed():
    silent = [0.0] * 1600
    loud = [0.5] * 1600
    silent2 = [0.0] * 1600
    out = detect_silence_from_rms(silent + loud + silent2, sr=16000,
                                   window_ms=50, threshold_dbfs=-30.0)
    # Two silent regions
    assert len(out) >= 1


def test_gaps_between_segments_empty():
    assert gaps_between_segments([]) == []


def test_gaps_between_segments_below_threshold():
    segs = [_seg(0, 1), _seg(1.05, 2)]
    assert gaps_between_segments(segs, min_gap=0.5) == []


def test_gaps_between_segments_above_threshold():
    segs = [_seg(0, 1), _seg(2, 3)]
    assert gaps_between_segments(segs, min_gap=0.5) == [(1.0, 2.0)]


def test_coverage_ratio_partial():
    segs = [_seg(0, 5)]
    assert coverage_ratio(segs, 10.0) == 0.5


def test_coverage_ratio_capped_at_one():
    segs = [_seg(0, 100)]
    assert coverage_ratio(segs, 10.0) == 1.0


def test_coverage_ratio_zero_total():
    assert coverage_ratio([_seg(0, 1)], 0.0) == 0.0


def test_overlap_count_no_overlap():
    segs = [_seg(0, 1), _seg(2, 3), _seg(4, 5)]
    assert overlap_count(segs) == 0


def test_overlap_count_single_overlap():
    segs = [_seg(0, 2), _seg(1, 3)]
    assert overlap_count(segs) == 1


def test_overlap_count_chained():
    segs = [_seg(0, 5), _seg(1, 6), _seg(2, 7)]
    assert overlap_count(segs) == 2


def test_parse_wav_header_too_short():
    assert parse_wav_header(b"") is None
    assert parse_wav_header(b"x" * 30) is None


def test_parse_wav_header_wrong_magic():
    blob = b"NOTRIFF" + b"\x00" * 100
    assert parse_wav_header(blob) is None


def test_parse_wav_header_minimal_valid():
    # Hand-craft a minimal RIFF/WAVE header with one data chunk
    header = (
        b"RIFF" + struct.pack("<I", 44 - 8) +
        b"WAVE" +
        b"fmt " + struct.pack("<I", 16) +
        struct.pack("<H", 1) +     # PCM
        struct.pack("<H", 1) +     # mono
        struct.pack("<I", 16000) + # sr
        struct.pack("<I", 32000) + # byte rate
        struct.pack("<H", 2) +     # block align
        struct.pack("<H", 16) +    # bit depth
        b"data" + struct.pack("<I", 0)
    )
    info = parse_wav_header(header)
    assert info is not None
    assert info["sr"] == 16000
    assert info["channels"] == 1
    assert info["bit_depth"] == 16


def test_best_resample_target_telephony():
    assert best_resample_target(8000) == SR_TELEPHONY


def test_best_resample_target_audiobook():
    assert best_resample_target(16000) == SR_AUDIOBOOK


def test_best_resample_target_broadcast():
    assert best_resample_target(48000) == SR_BROADCAST


def test_best_resample_target_high():
    assert best_resample_target(192000) == SR_HIRES


def test_whisper_sample_rate_constant():
    assert WHISPER_SR == 16000
