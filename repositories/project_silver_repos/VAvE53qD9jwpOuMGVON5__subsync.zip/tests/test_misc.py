"""Tests for reading_speed, presets, language_codes, color_codes,
errors, validate, diff, progress, batch, config, cli_extra, benchmark,
log_utils, version."""

import io
import json
import logging
import os
import tempfile
import pytest

from subsync.types import Transcript, Segment


def _t():
    t = Transcript(language="en", duration=10.0)
    t.segments.extend([
        Segment(start=0.0, end=2.0, text="hello world"),
        Segment(start=2.5, end=5.0, text="line two has more text in it"),
    ])
    return t


# reading_speed -----------------------------------------------------------

from subsync.reading_speed import (
    ReadingSpeedRules, NETFLIX_ADULT, NETFLIX_KIDS, BBC, APPLE,
    compute, annotate, violations, histogram, stretch_to_max,
)


def test_compute_cps_basic():
    s = Segment(start=0.0, end=1.0, text="abcdefghij")
    r = compute(s)
    assert r.chars == 10
    assert r.cps == 10.0


def test_compute_cps_zero_duration():
    s = Segment(start=1.0, end=1.0, text="x")
    r = compute(s)
    assert r.cps == float("inf")


def test_annotate_writes_back_to_segment():
    t = _t()
    annotate(t)
    assert t.segments[0].cps > 0


def test_violations_under_loose_rules():
    t = _t()
    rules = ReadingSpeedRules(target_cps=1.0, max_cps=2.0)
    bads = violations(t, rules)
    assert len(bads) >= 1


def test_violations_under_strict_rules():
    t = _t()
    rules = ReadingSpeedRules(target_cps=100.0, max_cps=200.0)
    bads = violations(t, rules)
    assert bads == []


def test_histogram_returns_buckets():
    t = _t()
    h = histogram(t)
    assert isinstance(h, dict)
    assert sum(h.values()) == len(t.segments)


def test_stretch_extends_when_room():
    t = Transcript(language="en", duration=20.0)
    t.segments.append(Segment(start=0.0, end=1.0, text="x" * 100))
    t.segments.append(Segment(start=10.0, end=12.0, text="y"))
    stretch_to_max(t, ReadingSpeedRules(max_cps=10.0))
    assert t.segments[0].end > 1.0


def test_preset_constants_present():
    assert NETFLIX_ADULT.max_cps > 0
    assert NETFLIX_KIDS.max_cps > 0
    assert BBC.max_cps > 0
    assert APPLE.max_cps > 0


# presets -----------------------------------------------------------------

from subsync.presets import PRESETS, get, names


def test_presets_has_defaults():
    assert "default" in PRESETS
    assert "netflix-adult" in PRESETS


def test_presets_get():
    p = get("netflix-adult")
    assert p.name == "netflix-adult"
    assert p.max_chars_per_line > 0


def test_presets_get_unknown_raises():
    with pytest.raises(KeyError):
        get("not-a-preset")


def test_presets_names_sorted():
    assert names() == sorted(names())


# language_codes ----------------------------------------------------------

from subsync.language_codes import (
    LANGUAGES, lookup, to_2, to_3, is_rtl, is_cjk, all_codes, file_suffix,
)


def test_lookup_by_2():
    l = lookup("en")
    assert l is not None
    assert l.name == "English"


def test_lookup_by_3():
    l = lookup("eng")
    assert l is not None
    assert l.code_2 == "en"


def test_lookup_by_name():
    l = lookup("Spanish")
    assert l is not None
    assert l.code_2 == "es"


def test_lookup_unknown_returns_none():
    assert lookup("klingon") is None


def test_to_2_and_to_3():
    assert to_2("Spanish") == "es"
    assert to_3("Spanish") == "spa"


def test_is_rtl():
    assert is_rtl("ar")
    assert not is_rtl("en")


def test_is_cjk():
    assert is_cjk("ja")
    assert is_cjk("zh")
    assert not is_cjk("en")


def test_file_suffix_zh_traditional():
    assert file_suffix("zt") == ".zh-Hant"


def test_file_suffix_simple():
    assert file_suffix("en") == ".en"


def test_all_codes_includes_common():
    codes = all_codes()
    assert "en" in codes
    assert "es" in codes


# color_codes -------------------------------------------------------------

from subsync.color_codes import (
    WHITE, GREEN, RED, BLACK, name_to_hex, hex_to_nearest_name,
)


def test_name_to_hex_basic():
    assert name_to_hex("white") == WHITE
    assert name_to_hex("green") == GREEN
    assert name_to_hex("red") == RED


def test_name_to_hex_unknown_defaults_white():
    assert name_to_hex("polkadot") == WHITE


def test_hex_to_nearest_name_exact():
    assert hex_to_nearest_name("#FF0000") == "red"
    assert hex_to_nearest_name("#00FF00") == "green"


def test_hex_to_nearest_name_approx():
    assert hex_to_nearest_name("#FE0202") == "red"


# errors ------------------------------------------------------------------

from subsync.errors import (
    SubsyncError, MissingFileError, UnsupportedMediaError, FfmpegMissingError,
    HFTokenError, DependencyError, MultiError, map_external,
)


def test_subsync_error_with_hint():
    e = SubsyncError("oops", hint="try X")
    assert "try X" in str(e)


def test_missing_file_records_path():
    e = MissingFileError("/no/such")
    assert e.path == "/no/such"


def test_unsupported_media_records_ext():
    e = UnsupportedMediaError(".bmp")
    assert e.ext == ".bmp"


def test_ffmpeg_missing_has_hint():
    e = FfmpegMissingError()
    assert e.hint is not None


def test_hf_token_has_hint():
    e = HFTokenError()
    assert "HF_TOKEN" in str(e)


def test_dependency_default_pip_hint():
    e = DependencyError("pyfoo")
    assert "pip install pyfoo" in str(e)


def test_multi_error_iter():
    me = MultiError([MissingFileError("a"), MissingFileError("b")])
    assert len(list(me)) == 2


def test_map_external_passthrough():
    src = MissingFileError("x")
    assert map_external(src) is src


def test_map_external_filenotfound():
    out = map_external(FileNotFoundError("x"))
    assert isinstance(out, MissingFileError)


def test_map_external_generic():
    out = map_external(RuntimeError("oops"))
    assert isinstance(out, SubsyncError)


# validate ----------------------------------------------------------------

from subsync.validate import (
    validate_srt, validate_vtt, validate_ass, validate_ttml, validate_scc,
    validate, is_valid,
)


def test_validate_srt_ok(tmp_path):
    p = tmp_path / "x.srt"
    p.write_text("1\n00:00:00,000 --> 00:00:01,000\nhi\n")
    assert validate_srt(str(p)) == []


def test_validate_srt_missing_file():
    assert validate_srt("/no/such.srt") == ["file does not exist"]


def test_validate_vtt_missing_header(tmp_path):
    p = tmp_path / "x.vtt"
    p.write_text("00:00:00.000 --> 00:00:01.000\nhi\n")
    issues = validate_vtt(str(p))
    assert any("WEBVTT" in i for i in issues)


def test_validate_ass_missing_sections(tmp_path):
    p = tmp_path / "x.ass"
    p.write_text("nonsense\n")
    issues = validate_ass(str(p))
    assert len(issues) >= 1


def test_validate_ttml_invalid_xml(tmp_path):
    p = tmp_path / "x.ttml"
    p.write_text("<not closed")
    issues = validate_ttml(str(p))
    assert any("xml parse" in i for i in issues)


def test_validate_scc_no_header(tmp_path):
    p = tmp_path / "x.scc"
    p.write_text("garbage\n")
    issues = validate_scc(str(p))
    assert any("Scenarist" in i for i in issues)


def test_validate_dispatcher_unknown(tmp_path):
    p = tmp_path / "x.xyz"
    p.write_text("hi")
    issues = validate(str(p))
    assert any("unknown" in i for i in issues)


def test_is_valid_false_for_garbage(tmp_path):
    p = tmp_path / "x.srt"
    p.write_text("not srt")
    assert not is_valid(str(p))


# diff --------------------------------------------------------------------

from subsync.diff import structural_diff, summarize, is_clean, text_report, DiffEntry


def _seg(start, end, text, speaker=None):
    return Segment(start=start, end=end, text=text, speaker=speaker)


def test_diff_clean_when_identical():
    a = [_seg(0, 1, "hi")]
    b = [_seg(0, 1, "hi")]
    diffs = structural_diff(a, b)
    assert is_clean(diffs)


def test_diff_added():
    a = [_seg(0, 1, "hi")]
    b = [_seg(0, 1, "hi"), _seg(2, 3, "yo")]
    diffs = structural_diff(a, b)
    assert summarize(diffs)[DiffEntry.KIND_ADDED] == 1


def test_diff_removed():
    a = [_seg(0, 1, "hi"), _seg(2, 3, "yo")]
    b = [_seg(0, 1, "hi")]
    diffs = structural_diff(a, b)
    assert summarize(diffs)[DiffEntry.KIND_REMOVED] == 1


def test_diff_changed_text():
    a = [_seg(0, 1, "hi")]
    b = [_seg(0, 1, "yo")]
    diffs = structural_diff(a, b)
    assert summarize(diffs)[DiffEntry.KIND_CHANGED] == 1


def test_diff_changed_speaker():
    a = [_seg(0, 1, "hi", speaker="A")]
    b = [_seg(0, 1, "hi", speaker="B")]
    diffs = structural_diff(a, b)
    assert summarize(diffs)[DiffEntry.KIND_CHANGED] == 1


def test_diff_text_report_format():
    a = [_seg(0, 1, "hi")]
    b = [_seg(2, 3, "yo")]
    diffs = structural_diff(a, b)
    rpt = text_report(diffs)
    assert "Diff summary" in rpt


# progress ----------------------------------------------------------------

from subsync.progress import ProgressReporter, TextBar, chained


def test_progress_advance():
    seen = []
    rp = ProgressReporter(total=10, sink=lambda f, m: seen.append(f))
    rp.advance(5)
    assert seen[-1] == 0.5


def test_progress_finish():
    rp = ProgressReporter(total=10)
    rp.finish()
    assert rp.fraction == 1.0


def test_progress_set_total():
    rp = ProgressReporter(total=10)
    rp.set_total(20)
    assert rp.total == 20


def test_text_bar_emits_percent():
    buf = io.StringIO()
    bar = TextBar(width=10, stream=buf)
    bar(0.5, "msg")
    assert "%" in buf.getvalue()


def test_chained_pushes_to_all():
    a = ProgressReporter(total=10)
    b = ProgressReporter(total=20)
    sink = chained(a, b)
    sink(0.5, "x")
    assert a.current == 5
    assert b.current == 10


# batch -------------------------------------------------------------------

from subsync.batch import BatchRunner, BatchResult, SUPPORTED_MEDIA, SUPPORTED_SUBS


def test_batch_discover_finds_supported(tmp_path):
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "a.srt").write_text("x")
    (tmp_path / "in" / "b.mp3").write_text("x")
    (tmp_path / "in" / "ignore.txt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))
    files = r.discover()
    assert len(files) == 2


def test_batch_run_records_success(tmp_path):
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "a.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))
    def fake(src, dst):
        with open(dst, "w") as f:
            f.write("ok")
        return True
    r.run(fake)
    assert r.success_count == 1


def test_batch_handles_failure(tmp_path):
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "a.srt").write_text("x")
    r = BatchRunner(str(tmp_path / "in"), str(tmp_path / "out"))
    def boom(src, dst):
        raise RuntimeError("nope")
    r.run(boom)
    assert r.failure_count == 1


def test_batch_report_json(tmp_path):
    r = BatchRunner(str(tmp_path), str(tmp_path / "out"))
    r.results.append(BatchResult("a.srt", "a.srt", True, 0.1, "ok"))
    out = tmp_path / "r.json"
    r.write_report(str(out))
    assert json.loads(out.read_text())["summary"]["ok"] == 1


def test_batch_supported_inputs():
    assert ".srt" in SUPPORTED_SUBS
    assert ".mp4" in SUPPORTED_MEDIA


# config ------------------------------------------------------------------

from subsync.config import Config, get_config, reset_config


def test_config_defaults():
    cfg = Config()
    assert cfg.get("transcribe.model") == "large-v3"


def test_config_set_get():
    cfg = Config()
    cfg.set("transcribe.model", "tiny")
    assert cfg.get("transcribe.model") == "tiny"


def test_config_get_missing_default():
    cfg = Config()
    assert cfg.get("a.b.c", 42) == 42


def test_config_load_json(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"transcribe": {"model": "small"}}))
    cfg = Config.load(str(p))
    assert cfg.get("transcribe.model") == "small"


def test_config_singleton():
    reset_config()
    a = get_config()
    b = get_config()
    assert a is b
    reset_config()


# cli_extra ---------------------------------------------------------------

from subsync.cli_extra import main as cli_main


def test_cli_extra_no_args(capsys):
    rc = cli_main([])
    out = capsys.readouterr()
    assert rc == 2
    assert "usage" in out.out


def test_cli_extra_unknown(capsys):
    rc = cli_main(["wat"])
    assert rc == 2


def test_cli_extra_validate_unknown_ext(capsys, tmp_path):
    f = tmp_path / "x.xyz"
    f.write_text("hi")
    rc = cli_main(["validate", str(f)])
    assert rc == 1


def test_cli_extra_convert_round_trip(tmp_path):
    src = tmp_path / "in.srt"
    src.write_text("1\n00:00:00,000 --> 00:00:01,000\nhi\n")
    dst = tmp_path / "out.vtt"
    rc = cli_main(["convert", str(src), str(dst)])
    assert rc == 0
    assert dst.read_text().startswith("WEBVTT")


def test_cli_extra_info(tmp_path, capsys):
    src = tmp_path / "in.srt"
    src.write_text("1\n00:00:00,000 --> 00:00:01,000\nhi\n")
    rc = cli_main(["info", str(src)])
    out = capsys.readouterr()
    assert rc == 0
    assert "cues:" in out.out


# benchmark ---------------------------------------------------------------

from subsync.benchmark import (
    BenchmarkResult, benchmark, benchmark_many, write_report, print_table,
)


def test_benchmark_runs():
    r = benchmark(lambda: None, runs=3, warmup=0)
    assert len(r.runs) == 3


def test_benchmark_result_stats():
    r = BenchmarkResult("x", [0.1, 0.2, 0.3])
    assert r.median == pytest.approx(0.2)


def test_benchmark_many():
    rs = benchmark_many({"a": lambda: None, "b": lambda: None}, runs=2, warmup=0)
    assert len(rs) == 2


def test_write_report_json(tmp_path):
    r = benchmark(lambda: None, runs=2, warmup=0)
    out = tmp_path / "r.json"
    write_report([r], str(out))
    data = json.loads(out.read_text())
    assert data[0]["name"]


def test_print_table(capsys):
    r = benchmark(lambda: None, runs=2, warmup=0)
    print_table([r])
    cap = capsys.readouterr()
    assert "name" in cap.out


# log_utils ---------------------------------------------------------------

from subsync.log_utils import (
    get_logger, add_file_handler, remove_handler, set_level, CapturedRecords,
)


def test_get_logger_singleton():
    a = get_logger("subsync.test1")
    b = get_logger("subsync.test1")
    assert a is b


def test_add_remove_file_handler(tmp_path):
    log = get_logger("subsync.test2")
    p = str(tmp_path / "log.txt")
    h = add_file_handler(p, level="DEBUG", logger=log)
    log.info("hello")
    remove_handler(h, log)
    h.close()
    assert "hello" in open(p).read()


def test_set_level():
    log = get_logger("subsync.test3")
    set_level("WARNING", log)
    assert log.level == logging.WARNING


def test_captured_records():
    log = logging.getLogger("subsync.test_cap")
    with CapturedRecords("subsync.test_cap", level=logging.WARNING) as cap:
        log.warning("oh no")
    assert cap.has_message("oh no")


# version -----------------------------------------------------------------

from subsync.version import VERSION, version_tuple, is_prerelease


def test_version_string():
    assert isinstance(VERSION, str)
    assert "." in VERSION


def test_version_tuple_three_ints():
    t = version_tuple()
    assert len(t) == 3
    assert all(isinstance(x, int) for x in t)


def test_is_prerelease_basic():
    assert isinstance(is_prerelease(), bool)
