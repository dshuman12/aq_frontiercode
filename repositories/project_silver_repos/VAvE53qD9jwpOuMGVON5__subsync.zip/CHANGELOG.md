# Changelog

## v0.3.0 - 2026-02-28

Delivery recipes (Netflix, BBC, Apple, YouTube), per-cue QC, editorial
helpers, on-disk cache.

## v0.2.0 - 2025-11-29

Full whisper pipeline: tag, diarize, translate, cps. CCSL spotting list
export for translators.

## v0.1.0 - 2025-08-30

Subtitle format readers + writers: SRT, VTT, ASS, TTML.
