# Architecture

The pipeline is a chain of optional steps:

```
  media -> transcribe -> [align] -> [tag] -> [diarize] -> [translate]
                                                   |
                                                   v
                                                 [qc] -> [normalize] -> writers
```

## Intermediate representation (IR)

`subsync/types.py` defines:

- `Word` - one timed token from whisper
- `Segment` - one cue (text + start/end + words[] + speaker?)
- `Event` - non-speech audio (music, applause, laughter)
- `Turn` - speaker diarization output
- `Transcript` - top-level container

Everything in the pipeline talks `Transcript` so backends and writers
plug in without coupling.

## Backends

- `transcribe.py`  - faster-whisper
- `align.py`       - stable-ts forced alignment
- `tag.py`         - AST non-speech tagging
- `diarize.py`     - pyannote speaker turns
- `translate.py`   - m2m100 multi-language

Each backend is optional. The CLI flags pick them.

## Writers

`formats/` has reader+writer pairs for srt, vtt, ass, ttml, scc.
`broadcast.py` has the legacy stuff (EBU-STL, SBV, SAMI).
`delivery.py` packages combinations into per-platform recipes.

## Quality control

`qc.py` runs per-platform constraints (line length, max cps, max
duration, overlap detection) and reports issues. `delivery.py` can
require QC to be clean before writing the package.
