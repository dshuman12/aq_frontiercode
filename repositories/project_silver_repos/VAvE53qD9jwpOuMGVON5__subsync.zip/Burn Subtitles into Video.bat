@echo off
REM ============================================================================
REM  Drag BOTH a video file AND its .srt onto this icon at the same time.
REM  (Or just the video — it will look for a .srt with the same name.)
REM  Output: <video>.subbed.mp4 with subtitles hardcoded into the video.
REM ============================================================================

setlocal EnableDelayedExpansion
title Subsync — burn subtitles
cd /d "%~dp0"

set "VIDEO="
set "SRT="

:argloop
if "%~1"=="" goto run
set "EXT=%~x1"
if /I "!EXT!"==".srt" (
    set "SRT=%~1"
) else (
    set "VIDEO=%~1"
)
shift
goto argloop

:run
if "!VIDEO!"=="" (
    echo Drag a video file ^(and optionally its .srt^) onto this icon.
    pause & exit /b 1
)
if "!SRT!"=="" (
    REM Try to find a matching .srt next to the video
    set "SRT=%~dpn1.srt"
    if not exist "!SRT!" (
        echo No .srt provided and none found at "!SRT!".
        echo Run "Make Subtitles.bat" first, or drop both files at once.
        pause & exit /b 1
    )
)
echo Burning "!SRT!" into "!VIDEO!" ...
python subsync.py burn "!VIDEO!" "!SRT!" --style cinema
echo.
echo Done. Look for the .subbed.mp4 next to your video.
pause
