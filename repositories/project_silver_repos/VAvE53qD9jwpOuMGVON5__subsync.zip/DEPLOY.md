# Deploying Subsync — pick one path

You don't have to "deploy" anything to use it on your own computer. "Deploy" means making it available in some other place. Three places people typically deploy this kind of tool:

1. **Just your own machine.** Easiest. You're already there if you ran `Setup.bat`.
2. **A USB stick / portable folder you can carry to other machines.** Single-folder install, no admin rights needed. Build a portable EXE.
3. **A friend, a client, or a team — over the internet.** Either send them the EXE or run it as a web service.

Pick the one that matches what you're trying to do, then follow only that section. Skip the rest.

---

## Path 1 — your own machine (you're done)

If you already ran `Setup.bat`, you're deployed. Drag a video onto `Make Subtitles.bat` whenever you need captions. There is nothing else to do.

If you want a Start-menu / Desktop shortcut so it feels like an app:

1. Right-click `Make Subtitles.bat` → **Send to → Desktop (create shortcut)**.
2. Right-click the new desktop shortcut → **Properties → Change Icon…** → pick something that looks like a film-strip icon.
3. Rename the shortcut to something nice like "Subsync".

That's it. Drop video onto the desktop icon, get subtitles next to the video.

---

## Path 2 — make a portable EXE you can carry on a USB stick or send to anyone

**What this gives you:** a `subsync.exe` plus a folder of bundled libraries. Copy that folder onto a USB stick, take it to another Windows PC, and run it without installing Python.

**The catch:** the resulting folder is ~3 GB because torch + transformers + pyannote bundled together is huge. PyInstaller can't make this smaller — it's the cost of bundling the ML stack. Put it on a 16 GB+ stick.

**Steps (do these once, on the Windows machine where you've already run Setup.bat):**

1. Open File Explorer, go into `C:\Users\aa\Documents\subsync\`.
2. Double-click `build_exe.bat`.
3. Wait 5–15 minutes. PyInstaller chugs through every dependency, bundles them, and writes the result to `dist\subsync\`.
4. When it finishes, you'll see a new folder: `C:\Users\aa\Documents\subsync\dist\subsync\`. Inside it is `subsync.exe` and a couple thousand bundled `.dll`/`.pyd` files.
5. Copy the **whole `dist\subsync\` folder** to your USB stick. The exe alone won't work without the rest of the folder next to it.
6. On the target machine, the user double-clicks `subsync.exe` from inside that folder. First run downloads the Whisper model (~1.5 GB) into the user's HuggingFace cache.

**One thing the target machine still needs:** ffmpeg.exe and ffprobe.exe must be on their PATH. The simplest way:

- On the target PC, open PowerShell as admin and run: `winget install Gyan.FFmpeg`
- Or copy `ffmpeg.exe` + `ffprobe.exe` into the same folder as `subsync.exe`.

I can also bundle ffmpeg into the dist folder for you so it's truly self-contained. Say the word and I'll add that to the build.

**To make the dropped-file workflow work with the EXE,** create a `Make Subtitles (exe).bat` next to the .exe with this content:
```bat
@echo off
"%~dp0subsync.exe" transcribe "%~1" --out-dir "%~dp1"
pause
```
Drop a video onto that .bat → captions appear next to the video. Works on machines that don't have Python installed.

---

## Path 3 — deploy as a web service (anyone with a browser can use it)

**When to choose this:** you want clients, teammates, or yourself-from-a-phone to upload a video to a webpage and download captions, without installing anything.

**The catch:** running ML models in the cloud costs money. Whisper + NLLB on a CPU box is slow (real-time-ish). Whisper on a GPU box is fast but a GPU instance is roughly $0.50–$2 per hour depending on provider.

There are three realistic ways to do this. Pick one:

### 3a. Self-hosted on a $5–$20/month VPS — most control, slowest

Good for: low volume, not in a hurry, want privacy.

Provider: Hetzner, Linode, DigitalOcean, OVH. Get a CX22 (Hetzner) or similar — 2 vCPU, 4 GB RAM, ~$5/month.

1. SSH into the VPS.
2. Install Python 3.10+, ffmpeg, and the dependencies from `requirements.txt`.
3. Add a small FastAPI wrapper (I can write this for you — say the word). Something like:
   ```python
   from fastapi import FastAPI, UploadFile
   from subsync.cli import main as subsync_main
   app = FastAPI()
   @app.post("/transcribe")
   async def transcribe(file: UploadFile):
       # save file, run subsync, return SRT
   ```
4. Put nginx in front, point a domain at it, get a free Let's Encrypt cert with `certbot`.

Result: a `https://yourdomain.com/transcribe` endpoint that takes a file POST and returns SRT.

### 3b. Hugging Face Spaces (free, public, easy)

Good for: prototypes, free hosting, public-facing.

1. Make an account at huggingface.co.
2. Create a new Space, choose **Gradio** as the SDK and **CPU basic** (free).
3. Push the project. Add a `app.py` with:
   ```python
   import gradio as gr
   import subprocess
   def transcribe(video):
       subprocess.run(["python", "subsync.py", "transcribe", video])
       srt_path = video.rsplit(".", 1)[0] + ".srt"
       return srt_path
   gr.Interface(fn=transcribe, inputs="file", outputs="file").launch()
   ```
4. HF spawns the URL automatically: `https://huggingface.co/spaces/<your-user>/<your-space>`.

Cost: free on CPU (slow, ~10 min wait per video). $0.60/hour if you upgrade to a GPU.

### 3c. Modal / Replicate / RunPod — pay-per-use GPU, fastest

Good for: customers who pay per job, real-time delivery.

Modal (https://modal.com) has the easiest Python-native API:

1. Sign up, install: `pip install modal`
2. Wrap subsync in a Modal stub:
   ```python
   import modal
   image = modal.Image.debian_slim().pip_install_from_requirements("requirements.txt").apt_install("ffmpeg")
   stub = modal.Stub("subsync", image=image)
   @stub.function(gpu="T4", timeout=900)
   def transcribe(video_bytes: bytes) -> str:
       # write to /tmp, run subsync, return SRT
   ```
3. Deploy: `modal deploy subsync_modal.py`
4. Modal gives you an HTTP endpoint. Pay only for seconds the GPU runs (~$0.0006/sec on T4).

Cost: roughly $0.03 per minute of audio transcribed on a T4 GPU. For one hour of video, ~$1.80. You can charge clients $5–$10 per file and pocket the difference.

---

## My recommendation for what to do *right now*

I don't know which of those three matches your situation. But based on what you've said so far ("upload video and get subs back"), the order I'd think about:

1. **First:** confirm Path 1 works on your own machine. Run `Setup.bat`, drag a real video onto `Make Subtitles.bat`, see captions appear. If that's all you needed, you're done.

2. **Second:** if you want to charge people for this as a service (the gig copy you pasted earlier suggests that), Path 3c (Modal) is by far the cleanest. I can write the Modal wrapper in one go.

3. **Third:** if you want to give it to one specific person without them installing anything, Path 2 (USB EXE) is fine but ~3 GB.

Tell me which path matches your situation and I'll do the next step concretely:
- "Set me up on my own machine" → I'll talk you through running `Setup.bat` step-by-step.
- "Build me the EXE" → I'll write you a richer build that bundles ffmpeg too.
- "Put it on the web" → I'll write the FastAPI / Modal / Gradio wrapper.

If you don't know what you want, just say what you actually want to do with it (record videos and caption them yourself? caption other people's videos for a fee? something else?) and I'll pick.
