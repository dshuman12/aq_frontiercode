@echo off
REM ============================================================================
REM  Drag any video or audio file onto this icon to generate subtitles.
REM  Output (.srt, .vtt, .subs.json) lands next to the input file.
REM ============================================================================

setlocal EnableDelayedExpansion
title Subsync — making subtitles
cd /d "%~dp0"

if "%~1"=="" (
    echo.
    echo  Subsync — Make Subtitles
    echo  ========================
    echo.
    echo  Drag a video or audio file onto this icon to start.
    echo.
    echo  Or drop multiple files at once — they'll be processed one by one.
    echo.
    pause
    exit /b 0
)

REM Process each dropped file (drag-and-drop sends multiple args)
:loop
if "%~1"=="" goto done
set "INPUT=%~1"
set "OUTDIR=%~dp1"
echo.
echo --------------------------------------------------------------------------
echo  Processing: !INPUT!
echo  Output to:  !OUTDIR!
echo --------------------------------------------------------------------------
python subsync.py transcribe "!INPUT!" --out-dir "!OUTDIR!"
if errorlevel 1 (
    echo.
    echo  ERROR processing "!INPUT!" — see messages above.
    echo.
)
shift
goto loop
:done

echo.
echo  Done. Output files are next to your video/audio.
echo  Drop the .subs.json into the player ^(Open Player.bat^) to review and edit.
echo.
pause
