@echo off
REM ============================================================================
REM  Build a self-contained Windows bundle of subsync.
REM
REM  Output:  dist\subsync\           <- portable folder, ~3 GB
REM           dist\subsync.zip        <- same folder, zipped, for sharing
REM
REM  Bundles: subsync.exe + Python + torch + transformers + faster-whisper +
REM           pyannote + ffmpeg.exe + ffprobe.exe + helper .bat files +
REM           READ ME FIRST.txt + player.html
REM
REM  Target machines need NOTHING pre-installed. Just unzip + double-click.
REM
REM  Run this on Windows AFTER Setup.bat has installed the dev dependencies.
REM  Takes 10-25 minutes the first time (PyInstaller + ffmpeg download).
REM ============================================================================

setlocal EnableDelayedExpansion EnableExtensions
title Building subsync portable bundle
cd /d "%~dp0"

set "BUILD_DIR=%~dp0"
set "DIST=%BUILD_DIR%dist\subsync"
set "ASSETS=%BUILD_DIR%bundle_assets"
set "FFMPEG_CACHE=%BUILD_DIR%_ffmpeg_cache"
set "FFMPEG_ZIP=%FFMPEG_CACHE%\ffmpeg.zip"
set "FFMPEG_URL=https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"

REM Prefer the diarization-capable Python 3.11 venv if it exists (created by
REM Setup_Diarization.bat). Falls back to whatever 'python' is on PATH.
if exist "%BUILD_DIR%.venv311\Scripts\python.exe" (
    set "PYTHON=%BUILD_DIR%.venv311\Scripts\python.exe"
    echo Using diarization-capable Python at %BUILD_DIR%.venv311\Scripts\python.exe
) else (
    set "PYTHON=python"
    echo Using system Python ^(no .venv311 found - run Setup_Diarization.bat to enable speaker detection^).
)

echo.
echo ============================================================================
echo  Subsync portable build
echo ============================================================================
echo.

REM ---- 0. sanity ---------------------------------------------------------------
REM (Python check happens after we've selected venv311 vs system python below.)
where powershell >nul 2>&1
if errorlevel 1 (
    echo ERROR: powershell not on PATH. This script needs PowerShell ^(ships with Windows^).
    pause & exit /b 1
)

REM ---- 1. install pyinstaller --------------------------------------------------
echo [1/5] Installing PyInstaller...
"%PYTHON%" -m pip install --quiet --upgrade pyinstaller
if errorlevel 1 (
    echo PyInstaller install failed. & pause & exit /b 1
)

REM ---- 2. download a portable ffmpeg, once -------------------------------------
echo [2/5] Fetching ffmpeg.exe + ffprobe.exe ^(once, cached in _ffmpeg_cache\^)...
if not exist "%FFMPEG_CACHE%" mkdir "%FFMPEG_CACHE%"
if exist "%FFMPEG_CACHE%\ffmpeg.exe" if exist "%FFMPEG_CACHE%\ffprobe.exe" (
    echo       cached - skipping download
    goto ffmpeg_ready
)
REM Try multiple sources. PowerShell on some boxes still defaults to TLS 1.0 and
REM Gyan's CDN refuses it - so prefer curl.exe (Win10 1803+) and force TLS 1.2 in
REM the powershell fallback. If gyan fails entirely, fall back to BtbN's GitHub.
set "FFMPEG_URL_2=https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"

REM Discard any cached zip < 10 MB - that's a leftover partial from a prior crash.
if exist "%FFMPEG_ZIP%" (
    for %%S in ("%FFMPEG_ZIP%") do if %%~zS LSS 10485760 (
        echo       cached zip looks truncated ^(%%~zS bytes^); deleting and re-downloading.
        del /Q "%FFMPEG_ZIP%"
    )
)

set "DL_OK="
if not exist "%FFMPEG_ZIP%" (
    echo       downloading from gyan.dev ^(~80 MB^)...
    call :download_ffmpeg "%FFMPEG_URL%"
    if exist "%FFMPEG_ZIP%" set "DL_OK=1"
)
if not defined DL_OK if not exist "%FFMPEG_ZIP%" (
    echo       gyan.dev unreachable; trying GitHub mirror...
    call :download_ffmpeg "%FFMPEG_URL_2%"
    if exist "%FFMPEG_ZIP%" set "DL_OK=1"
)
if not defined DL_OK if not exist "%FFMPEG_ZIP%" (
    echo.
    echo       BOTH downloads failed. Manual workaround:
    echo         1. Open https://www.gyan.dev/ffmpeg/builds/ in your browser
    echo         2. Download ffmpeg-release-essentials.zip
    echo         3. Save it as: %FFMPEG_ZIP%
    echo         4. Re-run build_exe.bat
    echo.
    pause & exit /b 1
)
echo       extracting...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -Path '%FFMPEG_ZIP%' -DestinationPath '%FFMPEG_CACHE%\extracted'"
if errorlevel 1 (
    echo       Extract failed. & pause & exit /b 1
)
REM Gyan's release zip extracts to ffmpeg-X.X.X-essentials_build\bin\{ffmpeg,ffprobe}.exe
for /r "%FFMPEG_CACHE%\extracted" %%F in (ffmpeg.exe) do (
    copy /Y "%%F" "%FFMPEG_CACHE%\ffmpeg.exe" >nul
)
for /r "%FFMPEG_CACHE%\extracted" %%F in (ffprobe.exe) do (
    copy /Y "%%F" "%FFMPEG_CACHE%\ffprobe.exe" >nul
)
REM Grab the FFmpeg LICENSE so we ship licence text with the redistributed binary.
for /r "%FFMPEG_CACHE%\extracted" %%F in (LICENSE.txt) do (
    if not exist "%FFMPEG_CACHE%\FFMPEG_LICENSE.txt" copy /Y "%%F" "%FFMPEG_CACHE%\FFMPEG_LICENSE.txt" >nul
)
if not exist "%FFMPEG_CACHE%\ffmpeg.exe" (
    echo ERROR: ffmpeg.exe not found inside the zip. Extract was malformed.
    pause & exit /b 1
)
if not exist "%FFMPEG_CACHE%\ffprobe.exe" (
    echo ERROR: ffprobe.exe not found inside the zip.
    pause & exit /b 1
)
REM clean up the unpacked tree but keep the zip + the two exes
rmdir /S /Q "%FFMPEG_CACHE%\extracted" 2>nul
:ffmpeg_ready
echo       OK - ffmpeg + ffprobe ready in _ffmpeg_cache\

REM ---- 3. PyInstaller build ----------------------------------------------------
echo.
echo [3/5] Running PyInstaller ^(this is the slow part - 5 to 15 minutes^)...
"%PYTHON%" -m PyInstaller subsync.spec --clean --noconfirm
if errorlevel 1 (
    echo PyInstaller build failed. See output above. & pause & exit /b 1
)
if not exist "%DIST%\subsync.exe" (
    echo ERROR: PyInstaller finished but %DIST%\subsync.exe is missing.
    pause & exit /b 1
)

REM ---- 4. drop ffmpeg + helper bats + readme into the dist folder --------------
echo.
echo [4/5] Adding ffmpeg + helper .bat files to dist\subsync\ ...
copy /Y "%FFMPEG_CACHE%\ffmpeg.exe"  "%DIST%\ffmpeg.exe"  >nul
copy /Y "%FFMPEG_CACHE%\ffprobe.exe" "%DIST%\ffprobe.exe" >nul
if exist "%FFMPEG_CACHE%\FFMPEG_LICENSE.txt"     copy /Y "%FFMPEG_CACHE%\FFMPEG_LICENSE.txt"     "%DIST%\FFMPEG_LICENSE.txt" >nul
if exist "%ASSETS%\Make Subtitles.bat"           copy /Y "%ASSETS%\Make Subtitles.bat"           "%DIST%\" >nul
if exist "%ASSETS%\Edit Subtitles.bat"           copy /Y "%ASSETS%\Edit Subtitles.bat"           "%DIST%\" >nul
if exist "%ASSETS%\Burn Subtitles into Video.bat" copy /Y "%ASSETS%\Burn Subtitles into Video.bat" "%DIST%\" >nul
if exist "%ASSETS%\READ ME FIRST.txt"            copy /Y "%ASSETS%\READ ME FIRST.txt"            "%DIST%\" >nul
if exist "%BUILD_DIR%player.html"                copy /Y "%BUILD_DIR%player.html"                "%DIST%\" >nul
echo       OK

REM ---- 5. zip up dist\subsync\ for shipping -----------------------------------
echo.
echo [5/5] Zipping the bundle for distribution ^(this can take a few minutes^)...
echo       Skip with Ctrl+C if you only want the unzipped folder.
choice /T 6 /D Y /C YN /M "       Create dist\subsync.zip now [Y/n, default Y]"
if errorlevel 2 goto skip_zip
if exist "%BUILD_DIR%dist\subsync.zip" del /Q "%BUILD_DIR%dist\subsync.zip"
REM Use the .NET ZipFile API instead of Compress-Archive: it handles >2GB folders.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('%DIST%','%BUILD_DIR%dist\subsync.zip',[System.IO.Compression.CompressionLevel]::Fastest, $false)"
if errorlevel 1 (
    echo       Zip failed. The unzipped folder at %DIST% still works - you can zip it manually
    echo       ^(right-click the folder -^> Send to -^> Compressed folder^).
) else (
    for %%S in ("%BUILD_DIR%dist\subsync.zip") do echo       wrote dist\subsync.zip ^(%%~zS bytes^)
)
goto done
:skip_zip
echo       Skipped zip step.

:done
echo.
echo ============================================================================
echo  BUILD COMPLETE
echo ============================================================================
echo.
echo  Portable bundle: %DIST%
if exist "%BUILD_DIR%dist\subsync.zip" echo  Shareable zip:   %BUILD_DIR%dist\subsync.zip
echo.
echo  To test locally:
echo    cd /d "%DIST%"
echo    Drag any video file onto "Make Subtitles.bat"
echo.
echo  To send to a friend:
echo    Send them dist\subsync.zip. They unzip it and drag a video onto
echo    "Make Subtitles.bat" - that's it. They need nothing pre-installed.
echo.
echo ============================================================================
echo.
pause
goto :eof


REM ---- subroutines -------------------------------------------------------------
:download_ffmpeg
REM %1 = URL.  Tries curl first, then PowerShell with TLS 1.2 forced.
REM On success leaves %FFMPEG_ZIP% on disk; on failure removes any partial.
set "URL=%~1"
if exist "%FFMPEG_ZIP%" del /Q "%FFMPEG_ZIP%" >nul 2>&1
where curl.exe >nul 2>&1
if not errorlevel 1 (
    echo       trying curl: %URL%
    curl.exe -L --fail --silent --show-error -o "%FFMPEG_ZIP%" "%URL%"
    if not errorlevel 1 if exist "%FFMPEG_ZIP%" goto :eof
    echo       curl failed; trying PowerShell ^(TLS 1.2^)...
    if exist "%FFMPEG_ZIP%" del /Q "%FFMPEG_ZIP%" >nul 2>&1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; $ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%URL%' -OutFile '%FFMPEG_ZIP%' -UseBasicParsing -MaximumRedirection 5 } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    if exist "%FFMPEG_ZIP%" del /Q "%FFMPEG_ZIP%" >nul 2>&1
)
goto :eof
