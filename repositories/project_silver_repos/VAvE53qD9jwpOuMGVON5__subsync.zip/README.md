# subsync

A high-grade video/audio subtitling pipeline. Single operator, local execution, no cloud round-trips. Transcription, forced alignment, speaker diarization, non-speech event tagging, multi-language translation, accessibility-grade reading-rate enforcement, CCSL export, and a single-file in-browser player/editor.

## What's in the box

| Stage | What it does | Engine |
|---|---|---|
| 1. Audio | Extract clean 16 kHz mono PCM | ffmpeg |
| 2. Transcribe | Word-level timestamps + confidence | faster-whisper (CTranslate2) |
| 3. Align (opt.) | Tighten word boundaries to ~50 ms | stable-ts |
| 4. Diarize (opt.) | "Who said what" speaker labels | pyannote/speaker-diarization-3.1 |
| 5. Tag (opt.) | `[Music]`, `[Applause]`, `[Laughter]`, … in non-speech gaps | AST (MIT/ast-finetuned-audioset) |
| 6. CPS | Split fast cues, merge flashes, line-wrap, gap-trim | BBC / Netflix subtitle rules |
| 7. Translate (opt.) | 200 languages, local | NLLB-200 |
| 8. Export | SRT, VTT, JSON (rich), CCSL DOCX | — |
| 9. Burn (opt.) | Hardcode subs into the video | ffmpeg |

The browser player loads the JSON and renders word-level karaoke highlighting, speaker badges, event cues, and a translation track switcher.

## Requirements

- Python 3.10+
- ffmpeg + ffprobe on PATH
- A modern browser for the player
- For diarization: a HuggingFace account, accept the model licence on `pyannote/speaker-diarization-3.1`, set `HF_TOKEN`

## Install

```bash
pip install -r requirements.txt
```

Heavy deps (torch, transformers, pyannote.audio) are needed only for the optional stages. If you skip them, the modules fail soft — the pipeline runs the stages it can and prints what it skipped.

## CLI

The shim `subsync.py` exposes the same surface as `python -m subsync`.

```bash
# Basic transcription
python subsync.py transcribe clip.mp4

# Tighten word boundaries
python subsync.py transcribe clip.mp4 --align

# Speaker diarization (HF_TOKEN required)
python subsync.py transcribe clip.mp4 --diarize
python subsync.py transcribe clip.mp4 --diarize --num-speakers 3

# Non-speech event tagging
python subsync.py transcribe clip.mp4 --tag

# Translation to multiple languages
python subsync.py transcribe clip.mp4 --translate es,fr,yo,pt

# CCSL DOCX export, with the first translation as a column
python subsync.py transcribe clip.mp4 --diarize --tag --translate es --ccsl --title "Episode 01"

# Custom reading-rate guards (BBC default = 17 cps, Netflix kids = 13)
python subsync.py transcribe clip.mp4 --max-cps 13 --max-chars 38

# Burn an SRT into the video
python subsync.py burn clip.mp4 clip.srt --style cinema

# Inspect a media file
python subsync.py info clip.mp4
```

Run the full pipeline:

```bash
python subsync.py transcribe clip.mp4 \
  --align --diarize --tag \
  --translate es,fr \
  --ccsl --title "Episode 01" \
  --max-cps 17 --max-chars 42 --max-lines 2
```

## Outputs

For input `clip.mp4` you get:

- `clip.srt` — original-language SRT, optional speaker prefix, event cues interleaved
- `clip.vtt` — WebVTT equivalent
- `clip.subs.json` — lossless source: language, duration, speakers, events, segments with word-level `{start,end,text,prob,speaker}`, plus `translations` and `cps`
- `clip.es.srt`, `clip.es.vtt`, `clip.fr.srt`, … — one pair per requested target language
- `clip.ccsl.docx` — Combined Continuity & Spotting List with TC In/Out (SMPTE), Speaker, Dialogue, optional Translation column, Action/Notes
- `clip.subbed.mp4` — only when you run `subsync burn`

## Player / editor

Open `player.html` in any browser, drop in the video and the matching `.subs.json`. You get:

- word-level karaoke highlighting, driven by `requestAnimationFrame` for 60 Hz smoothness
- speaker badges + cps badges (red when too fast)
- non-speech events shown as italic purple cues
- track switcher: original or any translation
- inline edits: text, timing shifts (±100 ms), merge ↑, split @ playhead
- search across the transcript
- export back to SRT / VTT / JSON for the currently selected track

Keyboard:

- `Space` — play / pause
- `↑` / `↓` — previous / next segment
- `←` / `→` — seek 1 s

## Reading-rate guards

Defaults follow BBC and Netflix subtitle guidelines:

| Constraint | Default |
|---|---|
| `--max-cps` | 17 chars/sec (use 13 for younger audiences) |
| `--max-dur` | 7 s |
| `--min-dur` | 0.83 s (~20 frames at 24 fps) |
| `--max-chars` | 42 per line |
| `--max-lines` | 2 |

The CPS pass splits any cue exceeding cps or duration at the closest word boundary, line-wraps for visual balance, pads sub-minimum cues into trailing silence when available, and trims overlaps so two cues never strobe.

## Sync strategy

1. ffmpeg → 16 kHz mono PCM (Whisper-native).
2. faster-whisper with `word_timestamps=True` and Silero VAD to suppress hallucinations on silence.
3. Optional `--align`: stable-ts re-runs forced alignment on the same audio + the transcribed text, tightening word boundaries to roughly 50 ms.
4. Diarization runs in parallel on the same WAV; words are mapped to speakers by max temporal overlap, segment speakers by majority duration vote.
5. The player uses word-level timestamps for highlighting; it never relies on cue-level interpolation, so highlights stay glued to playback even with frame-accurate scrubbing.

## File layout

```
subsync.py              # entry-point shim → subsync.cli.main
subsync/
  __init__.py
  __main__.py
  cli.py                # argparse + dispatch
  pipeline.py           # orchestrator (Options + run)
  media.py              # ffmpeg / ffprobe helpers
  transcribe.py         # faster-whisper
  align.py              # stable-ts wrapper (optional)
  diarize.py            # pyannote 3.1 (optional)
  tag.py                # AST audio event detection (optional)
  translate.py          # NLLB-200 (optional)
  cps.py                # reading-rate / timing constraints
  export.py             # SRT / VTT / JSON
  ccsl.py               # CCSL DOCX (optional, falls back to TSV)
  burn.py               # ffmpeg subtitle burn-in
  types.py              # dataclasses
player.html             # standalone player / editor
requirements.txt
README.md
```

## Notes

- Whisper models: `tiny`, `base`, `small`, `medium`, `large-v3`. Quality ↑ and speed ↓ as you climb. `large-v3` is the default. CPU users on low-RAM machines should pick `medium --compute int8`.
- NLLB-200 distilled-600M is the default translator; switch to `--translate-model facebook/nllb-200-distilled-1.3B` for higher quality if you have GPU.
- AudioSet labels are mapped to a curated list of accessibility-grade tags. To add or rename labels, edit `LABEL_MAP` in `subsync/tag.py`.
- All language codes accepted by Whisper and NLLB-200 are supported. Whisper auto-detects; if confident detection fails, pass `--lang xx`.
