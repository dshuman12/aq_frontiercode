# Contributing to Pebble

Thanks for your interest. A few notes before opening a PR:

1. Run the test suite locally with `pytest` and make sure it stays green.
2. Keep changes scoped — small, focused PRs are easier to review.
3. New features need tests. Bug fixes should come with a regression test.
4. Match the existing code style; we use `ruff` for linting and formatting.

Install pre-commit hooks once with `pre-commit install` so checks run on every commit.

## Commit messages

Use imperative mood ("Add X" not "Added X"). Keep the subject under ~70 characters and reference the area at the start when it helps.
