from __future__ import annotations

import random
import string
from dataclasses import dataclass


@dataclass
class Schema:
    table: str
    columns: list[tuple[str, str]]  # (name, type)


def make_default_schema() -> Schema:
    return Schema(
        table="bench_t",
        columns=[
            ("id", "INT"),
            ("name", "TEXT"),
            ("amount", "DOUBLE"),
            ("flag", "BOOL"),
        ],
    )


def random_word(rng: random.Random, *, max_len: int = 12) -> str:
    n = rng.randint(3, max_len)
    return "".join(rng.choice(string.ascii_lowercase) for _ in range(n))


def generate_row(rng: random.Random, *, row_id: int) -> tuple[int, str, float, bool]:
    return (
        row_id,
        random_word(rng),
        rng.uniform(0, 1000),
        rng.random() < 0.5,
    )


def render_insert(schema: Schema, row: tuple[int, str, float, bool]) -> str:
    return (
        f"INSERT INTO {schema.table} VALUES ("
        f"{row[0]}, '{row[1]}', {row[2]:.4f}, "
        f"{'TRUE' if row[3] else 'FALSE'})"
    )


def generate_insert_stream(*, rows: int, seed: int = 0) -> list[str]:
    rng = random.Random(seed)
    schema = make_default_schema()
    out = [
        f"DROP TABLE IF EXISTS {schema.table}",
        "CREATE TABLE {} ({})".format(
            schema.table,
            ", ".join(f"{n} {t}" for n, t in schema.columns),
        ),
    ]
    for i in range(rows):
        out.append(render_insert(schema, generate_row(rng, row_id=i)))
    return out
