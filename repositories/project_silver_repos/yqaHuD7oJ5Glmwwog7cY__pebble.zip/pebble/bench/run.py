from __future__ import annotations

import argparse
import statistics
import tempfile
import time
from contextlib import contextmanager
from typing import Iterator

from pebble.server.embedded import open_embedded


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pebble micro-benchmarks")
    p.add_argument("--rows", type=int, default=10_000)
    p.add_argument("--warmup", type=int, default=200)
    p.add_argument("--iterations", type=int, default=3)
    return p.parse_args()


@contextmanager
def timed(label: str) -> Iterator[list[float]]:
    samples: list[float] = []
    start = time.perf_counter()
    yield samples
    samples.append(time.perf_counter() - start)
    print(f"{label:<24} {samples[-1] * 1000:8.2f} ms")


def main() -> None:
    args = parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        conn = open_embedded(tmp)
        try:
            conn.execute("CREATE TABLE bench_t (id INT PRIMARY KEY, v INT)")
            durations: list[float] = []
            for trial in range(args.iterations):
                with timed(f"insert {args.rows} rows"):
                    for i in range(args.rows):
                        conn.execute(f"INSERT INTO bench_t VALUES ({i + trial * args.rows}, {i})")
                with timed("count(*)") as samples:
                    conn.execute("SELECT COUNT(*) FROM bench_t")
                durations.append(samples[-1])
                with timed("filter scan"):
                    conn.execute("SELECT id FROM bench_t WHERE v > 5000")
            print(f"\ncount(*) median: {statistics.median(durations) * 1000:.2f} ms")
        finally:
            conn.close()


if __name__ == "__main__":
    main()
