# Changelog

All notable changes to Pebble will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0a4] - 2026-04-21

## [0.1.0a3] - 2026-03-19

### Added
- Test suite, docs, examples, Dockerfile, micro-benchmarks.

## [0.1.0a2] - 2026-01-29

## [0.1.0a1] - 2025-12-17

### Added
- SqlType lattice, Value with 3VL semantics, hand-written tokenizer.
- Recursive-descent parser for SELECT/INSERT/UPDATE/DELETE/DDL/txn/EXPLAIN.
- Slotted pages with CRC, heap files, FSM, LRU buffer pool.
- B+tree node format, search/insert/delete, range scan, root growth.
- ARIES-style WAL (analyse/redo/undo), MVCC snapshot visibility, multi-granularity locks.
- Logical/physical algebra, predicate/projection/limit pushdown, DP join reorder.
- Expression evaluator (3VL), LIKE→regex, volcano-style operators, hash join/aggregate, merge join.
- Framed wire protocol, threaded TCP server, embedded API, REPL with dump/check/explain/init/serve.
- Catalog bootstrap/migrations, statistics, plan printers, network client, property tests.
- Result formatter, sequence helpers, basic auth, plan-printer dispatcher; expanded docs.
- Engine metadata, recovery and arithmetic test coverage; format tests.
- CLI init idempotence and dump-helper edge-case tests.

### Changed
- Dropped module docstrings and section banners across the codebase.
- Pinned `pebble==0.1.0` in the runtime image install.
