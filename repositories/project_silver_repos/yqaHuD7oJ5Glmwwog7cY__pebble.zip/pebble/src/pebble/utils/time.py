from __future__ import annotations

import time
from datetime import date, datetime, timedelta, timezone


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def to_micros(dt: datetime) -> int:
    """Convert an aware datetime to microseconds since the Unix epoch (UTC)."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = dt.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return int(delta.total_seconds() * 1_000_000)


def from_micros(micros: int) -> datetime:
    return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=micros)


def to_days(d: date) -> int:
    return (d - date(1970, 1, 1)).days


def from_days(days: int) -> date:
    return date(1970, 1, 1) + timedelta(days=days)


def monotonic_ms() -> float:
    """Wall-clock-independent millisecond counter, useful in latency logs."""
    return time.monotonic() * 1000.0


def parse_iso(value: str) -> datetime:
    """Parse a subset of ISO-8601 -- enough for our SQL TIMESTAMP literal."""
    s = value.strip().replace(" ", "T")
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError as exc:
        raise ValueError(f"could not parse timestamp {value!r}: {exc}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def parse_date(value: str) -> date:
    return date.fromisoformat(value.strip())
