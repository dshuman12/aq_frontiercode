from __future__ import annotations

import os
from pathlib import Path


def ensure_directory(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def fsync_directory(path: str) -> None:
    """Crash-safe directory metadata flush.

    Required after creating / renaming files inside the directory; the
    rename is durable only after the directory inode is fsynced.
    """
    fd = os.open(path, os.O_DIRECTORY | os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write_bytes(path: str, payload: bytes) -> None:
    """Write ``payload`` then rename atomically into place.

    Avoids the 'half-written file after crash' failure mode at the
    cost of one extra fsync.
    """
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(payload)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def heap_file_path(data_dir: str, oid: int) -> str:
    return os.path.join(data_dir, "heaps", f"{oid:010d}.pdb")


def wal_dir(data_dir: str) -> str:
    return os.path.join(data_dir, "wal")


def snapshot_path(data_dir: str, lsn: int) -> str:
    return os.path.join(data_dir, "snapshots", f"{lsn:020d}.snap")
