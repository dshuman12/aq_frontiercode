from __future__ import annotations

import hashlib
import struct
import zlib
from typing import Any


def name_hash(name: str) -> int:
    """Stable 32-bit hash of a name. Used by the catalog and the locker."""
    digest = hashlib.blake2b(name.encode("utf-8"), digest_size=4).digest()
    return int.from_bytes(digest, "little")


def fingerprint(values: tuple[Any, ...]) -> int:
    """64-bit fingerprint of a tuple of small values.

    We round-trip through ``repr`` because the values we feed in are
    already canonical (ints, strings, bytes); ``repr`` gives us a
    deterministic byte sequence to feed into BLAKE2b.
    """
    payload = "|".join(repr(v) for v in values).encode("utf-8")
    digest = hashlib.blake2b(payload, digest_size=8).digest()
    return int.from_bytes(digest, "little")


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def encode_u64(value: int) -> bytes:
    return struct.pack("<Q", value)


def decode_u64(buf: bytes) -> int:
    return struct.unpack("<Q", buf)[0]
