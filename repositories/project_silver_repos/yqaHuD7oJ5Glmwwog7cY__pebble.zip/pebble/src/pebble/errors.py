from __future__ import annotations

from typing import Any


class PebbleError(Exception):
    """Base class for everything Pebble raises internally."""

    code: str = "PE0000"

    def __init__(
        self,
        message: str = "",
        *,
        code: str | None = None,
        hint: str | None = None,
        position: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        if code is not None:
            self.code = code
        self.hint: str | None = hint
        self.position: int | None = position
        self.context: dict[str, Any] = dict(context or {})

    def with_position(self, position: int) -> "PebbleError":
        self.position = position
        return self

    def __str__(self) -> str:
        base = super().__str__() or self.code
        if self.position is not None:
            base = f"{base} (at offset {self.position})"
        return base


class LexerError(PebbleError):
    code = "PE1001"


class ParseError(PebbleError):
    code = "PE1100"


class SemanticError(PebbleError):
    """Raised by analysis -- valid SQL syntactically, wrong meaning."""

    code = "PE1200"


class TableNotFound(SemanticError):
    code = "PE1201"

    def __init__(self, name: str) -> None:
        super().__init__(f"table {name!r} does not exist", context={"table": name})


class ColumnNotFound(SemanticError):
    code = "PE1202"

    def __init__(self, name: str, *, table: str | None = None) -> None:
        msg = f"column {name!r} does not exist"
        if table:
            msg = f"{msg} on table {table!r}"
        super().__init__(msg, context={"column": name, "table": table})


class DuplicateName(SemanticError):
    code = "PE1203"


class TypeMismatch(SemanticError):
    code = "PE1300"


class NullViolation(SemanticError):
    code = "PE1301"


class CheckViolation(SemanticError):
    code = "PE1302"


class UniqueViolation(SemanticError):
    code = "PE1303"


class ForeignKeyViolation(SemanticError):
    code = "PE1304"


class StorageError(PebbleError):
    code = "PE2000"


class CorruptPage(StorageError):
    code = "PE2001"


class CorruptWal(StorageError):
    code = "PE2002"


class PageFull(StorageError):
    code = "PE2003"


class BtreeError(StorageError):
    code = "PE2100"


class BtreeKeyTooLarge(BtreeError):
    code = "PE2101"


class RecoveryError(PebbleError):
    code = "PE2200"


class TransactionError(PebbleError):
    code = "PE3000"


class TransactionAborted(TransactionError):
    code = "PE3001"


class SerializationFailure(TransactionError):
    code = "PE3002"


class DeadlockDetected(TransactionError):
    code = "PE3003"


class LockTimeout(TransactionError):
    code = "PE3004"


class IsolationViolation(TransactionError):
    code = "PE3005"


class PlanError(PebbleError):
    code = "PE4000"


class ExecutionError(PebbleError):
    code = "PE5000"


class DivisionByZero(ExecutionError):
    code = "PE5001"


class NumericOverflow(ExecutionError):
    code = "PE5002"


class NetworkError(PebbleError):
    code = "PE6000"


class AuthError(PebbleError):
    code = "PE6100"


class QueryCanceled(PebbleError):
    code = "PE6200"
