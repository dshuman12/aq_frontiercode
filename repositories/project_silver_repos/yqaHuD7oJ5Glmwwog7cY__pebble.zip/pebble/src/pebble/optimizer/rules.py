from __future__ import annotations

from dataclasses import replace
from typing import Callable

from pebble.parser import ast as A
from pebble.plan.logical import (
    Aggregate,
    Filter,
    Join,
    Limit,
    LogicalPlan,
    Project,
    Scan,
    SetOp,
    Sort,
)

Rule = Callable[[LogicalPlan], LogicalPlan]



def optimize(plan: LogicalPlan, *, max_passes: int = 8) -> LogicalPlan:
    rules: list[Rule] = [
        predicate_pushdown,
        projection_pushdown,
        constant_folding,
        limit_pushdown,
    ]
    last = None
    current = plan
    passes = 0
    while passes < max_passes and current is not last:
        last = current
        for rule in rules:
            current = rule(current)
        passes += 1
    return current



def predicate_pushdown(plan: LogicalPlan) -> LogicalPlan:
    if isinstance(plan, Filter) and isinstance(plan.input, Project):
        # Filter(Project(X)) -> Project(Filter(X)) when the predicate
        # refers only to columns visible to X.
        inner = plan.input
        new_filter = Filter(input=inner.input, predicate=plan.predicate)
        return replace(inner, input=new_filter)
    if isinstance(plan, Filter) and isinstance(plan.input, Join):
        join = plan.input
        # Decide which side -- if the predicate references one side only,
        # rewrite the join with the predicate on that side.
        used = _columns_used(plan.predicate)
        left_cols = _emitted_columns(join.left)
        right_cols = _emitted_columns(join.right)
        if used <= left_cols:
            return Join(
                left=Filter(input=join.left, predicate=plan.predicate),
                right=join.right,
                kind=join.kind,
                predicate=join.predicate,
            )
        if used <= right_cols:
            return Join(
                left=join.left,
                right=Filter(input=join.right, predicate=plan.predicate),
                kind=join.kind,
                predicate=join.predicate,
            )
    if hasattr(plan, "input") and plan.input is not None:
        plan.input = predicate_pushdown(plan.input)  # type: ignore[attr-defined]
    if hasattr(plan, "left") and getattr(plan, "left", None):
        plan.left = predicate_pushdown(plan.left)  # type: ignore[attr-defined]
    if hasattr(plan, "right") and getattr(plan, "right", None):
        plan.right = predicate_pushdown(plan.right)  # type: ignore[attr-defined]
    return plan


def projection_pushdown(plan: LogicalPlan) -> LogicalPlan:
    """Limit which columns scans must produce.

    A Project that references only a subset of a Scan's columns can
    annotate the Scan so the executor stops materialising the unused
    bytes. We do this only at the immediate Project-on-Scan pattern;
    deeper pushdown would need column-pruning analysis we have not
    implemented yet.
    """
    if isinstance(plan, Project) and isinstance(plan.input, Scan):
        used: set[str] = set()
        for expr, _ in plan.projections:
            used |= _columns_used(expr)
        scan = plan.input
        if used:
            scan.projected_columns = tuple(sorted(used))
    if hasattr(plan, "input") and plan.input is not None:
        plan.input = projection_pushdown(plan.input)  # type: ignore[attr-defined]
    return plan


def constant_folding(plan: LogicalPlan) -> LogicalPlan:
    if isinstance(plan, Filter) and plan.predicate is not None:
        plan.predicate = _fold(plan.predicate)
    if hasattr(plan, "input") and plan.input is not None:
        plan.input = constant_folding(plan.input)  # type: ignore[attr-defined]
    return plan


def limit_pushdown(plan: LogicalPlan) -> LogicalPlan:
    if isinstance(plan, Limit) and isinstance(plan.input, Project) and not plan.input.distinct:
        # Limit(Project(X)) where X has no Sort can become Project(Limit(X)).
        if not _contains_sort(plan.input):
            return replace(
                plan.input,
                input=Limit(input=plan.input.input, limit=plan.limit, offset=plan.offset),
            )
    if hasattr(plan, "input") and plan.input is not None:
        plan.input = limit_pushdown(plan.input)  # type: ignore[attr-defined]
    return plan



def _columns_used(expr: A.Expr | None) -> set[str]:
    if expr is None:
        return set()
    if isinstance(expr, A.ColumnRef):
        return {expr.name}
    used: set[str] = set()
    for slot in ("left", "right", "operand", "expr", "low", "high", "pattern", "escape"):
        if hasattr(expr, slot):
            used |= _columns_used(getattr(expr, slot))
    if isinstance(expr, A.FunctionCall):
        for arg in expr.args:
            used |= _columns_used(arg)
    if isinstance(expr, A.Case):
        for cond, result in expr.when_clauses:
            used |= _columns_used(cond) | _columns_used(result)
        used |= _columns_used(expr.else_clause)
    return used


def _emitted_columns(plan: LogicalPlan | None) -> set[str]:
    if plan is None:
        return set()
    if isinstance(plan, Scan):
        if plan.projected_columns:
            return set(plan.projected_columns)
        return set()  # unknown -> caller must be conservative
    return set()


def _contains_sort(plan: LogicalPlan) -> bool:
    if isinstance(plan, Sort):
        return True
    for slot in ("input", "left", "right"):
        child = getattr(plan, slot, None)
        if child is not None and _contains_sort(child):
            return True
    return False


def _fold(expr: A.Expr) -> A.Expr:
    if isinstance(expr, A.BinaryOp) and isinstance(expr.left, A.Literal) and isinstance(expr.right, A.Literal):
        try:
            value = _apply_binop(expr.op, expr.left.value, expr.right.value)
            return A.Literal(value=value, position=expr.position)
        except Exception:
            return expr
    return expr


def _apply_binop(op: str, l: object, r: object) -> object:
    if op == "+":
        return l + r  # type: ignore[operator]
    if op == "-":
        return l - r  # type: ignore[operator]
    if op == "*":
        return l * r  # type: ignore[operator]
    if op == "/":
        return l / r  # type: ignore[operator]
    if op == "and":
        return bool(l) and bool(r)
    if op == "or":
        return bool(l) or bool(r)
    if op == "=":
        return l == r
    if op == "<>":
        return l != r
    if op == "<":
        return l < r  # type: ignore[operator]
    if op == "<=":
        return l <= r  # type: ignore[operator]
    if op == ">":
        return l > r  # type: ignore[operator]
    if op == ">=":
        return l >= r  # type: ignore[operator]
    raise ValueError(f"unhandled op for folding: {op}")
