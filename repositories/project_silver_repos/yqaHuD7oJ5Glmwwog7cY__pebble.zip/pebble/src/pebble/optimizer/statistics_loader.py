from __future__ import annotations

from dataclasses import dataclass

from pebble.catalog import Catalog, ColumnStats, Table


@dataclass
class TableSummary:
    name: str
    row_count: int
    page_count: int
    columns: dict[str, ColumnStats]

    @classmethod
    def from_table(cls, table: Table) -> "TableSummary":
        return cls(
            name=table.name,
            row_count=max(table.stats.row_count, 1),
            page_count=max(table.stats.page_count, 1),
            columns=dict(table.stats.columns),
        )

    def column(self, name: str) -> ColumnStats:
        return self.columns.get(name, ColumnStats())


class StatisticsView:
    """Read-only snapshot of the catalog statistics for the optimizer."""

    def __init__(self, catalog: Catalog) -> None:
        self._summaries: dict[str, TableSummary] = {
            t.name: TableSummary.from_table(t) for t in catalog.tables()
        }

    def summary(self, table: str) -> TableSummary:
        if table not in self._summaries:
            return TableSummary(name=table, row_count=1, page_count=1, columns={})
        return self._summaries[table]

    def selectivity(self, table: str, column: str, op: str, value: object) -> float:
        s = self.summary(table).column(column)
        if not s.histogram_bounds and not s.most_common_values:
            return 0.1
        if op == "=":
            if value in s.most_common_values:
                return 1.0 / max(s.distinct_count, 1)
            return 1.0 / max(s.distinct_count, 1)
        if op in {"<", "<=", ">", ">="}:
            if not s.histogram_bounds:
                return 0.5
            try:
                bounds = list(s.histogram_bounds)
                position = sum(1 for b in bounds if b < value) / max(len(bounds), 1)
            except TypeError:
                return 0.5
            if op in {"<", "<="}:
                return max(0.0, min(1.0, position))
            return max(0.0, min(1.0, 1.0 - position))
        if op in {"<>", "!="}:
            return 1.0 - self.selectivity(table, column, "=", value)
        return 0.5
