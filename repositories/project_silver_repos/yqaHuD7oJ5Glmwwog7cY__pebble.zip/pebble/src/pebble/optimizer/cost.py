from __future__ import annotations

import itertools
from dataclasses import dataclass

from pebble.catalog import Catalog, Table
from pebble.config import OptimizerConfig

DEFAULT_SELECTIVITY: float = 0.1


@dataclass
class CostModel:
    cfg: OptimizerConfig

    def scan_cost(self, table: Table) -> tuple[float, float]:
        rows = max(table.stats.row_count, 1)
        pages = max(table.stats.page_count, 1)
        cost = pages * self.cfg.cost_seq_page + rows * self.cfg.cost_cpu_tuple
        return rows, cost

    def index_scan_cost(self, table: Table, *, selectivity: float) -> tuple[float, float]:
        rows = max(int(table.stats.row_count * selectivity), 1)
        pages = max(int(table.stats.page_count * selectivity), 1)
        cost = pages * self.cfg.cost_index_page + rows * self.cfg.cost_cpu_tuple
        return rows, cost

    def hash_join_cost(self, build_rows: float, probe_rows: float) -> tuple[float, float]:
        rows = build_rows + probe_rows
        cost = (build_rows + probe_rows) * self.cfg.cost_cpu_operator * 2
        return rows, cost

    def nested_loop_cost(self, outer_rows: float, inner_rows: float) -> tuple[float, float]:
        rows = outer_rows * inner_rows * DEFAULT_SELECTIVITY
        cost = outer_rows * inner_rows * self.cfg.cost_cpu_operator
        return rows, cost

    def merge_join_cost(self, left_rows: float, right_rows: float) -> tuple[float, float]:
        rows = max(left_rows, right_rows)
        cost = (left_rows + right_rows) * self.cfg.cost_cpu_operator
        return rows, cost


def reorder_joins(
    *,
    tables: list[str],
    catalog: Catalog,
    cost_model: CostModel,
    cap: int,
) -> list[str]:
    """DP over subsets to find a low-cost left-deep join order.

    The classic algorithm: for each subset, try all (subset - {x}, x)
    splits and keep the cheapest.
    """
    if len(tables) > cap:
        return tables  # too many tables -- punt to the input order
    if len(tables) <= 1:
        return list(tables)

    # Estimate per-table cardinality once.
    base_cost: dict[frozenset[str], tuple[float, float, list[str]]] = {}
    for t in tables:
        rows, cost = cost_model.scan_cost(catalog.get_table(t))
        base_cost[frozenset({t})] = (rows, cost, [t])

    for size in range(2, len(tables) + 1):
        for subset in itertools.combinations(tables, size):
            best: tuple[float, float, list[str]] | None = None
            for split in subset:
                lhs = frozenset(s for s in subset if s != split)
                if lhs not in base_cost:
                    continue
                left_rows, left_cost, left_order = base_cost[lhs]
                right_rows, right_cost, _ = base_cost[frozenset({split})]
                rows, join_cost = cost_model.hash_join_cost(right_rows, left_rows)
                total = left_cost + right_cost + join_cost
                if best is None or total < best[1]:
                    best = (rows, total, left_order + [split])
            if best is not None:
                base_cost[frozenset(subset)] = best
    return base_cost[frozenset(tables)][2]
