from __future__ import annotations

from typing import Sequence

from pebble.catalog import Catalog
from pebble.config import OptimizerConfig
from pebble.errors import PlanError, TableNotFound
from pebble.optimizer import rules as rule_mod
from pebble.optimizer.cost import CostModel
from pebble.parser import ast as A
from pebble.plan import logical as L
from pebble.plan import physical as P


class Builder:
    """Translate AST -> logical -> physical."""

    def __init__(self, *, catalog: Catalog, cfg: OptimizerConfig | None = None) -> None:
        self.catalog = catalog
        self.cfg = cfg or OptimizerConfig()
        self.cost = CostModel(self.cfg)

    def build(self, stmt: A.Stmt) -> P.PhysicalPlan:
        logical_plan = self._logical(stmt)
        optimized = rule_mod.optimize(logical_plan)
        return self._physical(optimized)

    def _logical(self, stmt: A.Stmt) -> L.LogicalPlan:
        if isinstance(stmt, A.SelectStmt):
            return self._logical_select(stmt)
        if isinstance(stmt, A.InsertStmt):
            return L.Insert(
                table=stmt.table,
                columns=tuple(stmt.columns),
                rows=[list(row) for row in stmt.values],
                select=self._logical(stmt.select) if stmt.select else None,
            )
        if isinstance(stmt, A.UpdateStmt):
            return L.Update(
                table=stmt.table,
                assignments=[(a.column, a.value) for a in stmt.assignments],
                predicate=stmt.where,
            )
        if isinstance(stmt, A.DeleteStmt):
            return L.Delete(table=stmt.table, predicate=stmt.where)
        raise PlanError(f"cannot build logical plan for {type(stmt).__name__}")

    def _logical_select(self, stmt: A.SelectStmt) -> L.LogicalPlan:
        node: L.LogicalPlan = self._table_expr(stmt.from_clause) if stmt.from_clause else L.Scan(table="")
        if stmt.where is not None:
            node = L.Filter(input=node, predicate=stmt.where)
        if stmt.group_by or _contains_aggregate(stmt.projections):
            aggregates = _collect_aggregates(stmt.projections)
            node = L.Aggregate(
                input=node,
                group_keys=list(stmt.group_by),
                aggregates=aggregates,
                having=stmt.having,
            )
        # Project after aggregate so HAVING can reference outputs.
        node = L.Project(
            input=node,
            projections=[(item.expr, item.alias) for item in stmt.projections],
            distinct=stmt.distinct,
        )
        if stmt.order_by:
            node = L.Sort(
                input=node,
                order=[(o.expr, o.descending) for o in stmt.order_by],
            )
        if stmt.limit is not None or stmt.offset is not None:
            node = L.Limit(input=node, limit=stmt.limit, offset=stmt.offset)
        if stmt.set_op and stmt.set_op_right is not None:
            node = L.SetOp(
                left=node,
                right=self._logical_select(stmt.set_op_right),
                op=stmt.set_op,
            )
        return node

    def _table_expr(self, table: A.TableExpr) -> L.LogicalPlan:
        if isinstance(table, A.TableRef):
            if not self.catalog.has_table(table.name):
                raise TableNotFound(table.name)
            return L.Scan(table=table.name, alias=table.alias)
        if isinstance(table, A.JoinClause):
            return L.Join(
                left=self._table_expr(table.left),
                right=self._table_expr(table.right),
                kind=table.kind,
                predicate=table.on,
                using=tuple(table.using) if table.using else None,
            )
        if isinstance(table, A.SubqueryRef):
            return self._logical_select(table.query)
        raise PlanError(f"unsupported table expression: {type(table).__name__}")

    def _physical(self, plan: L.LogicalPlan) -> P.PhysicalPlan:
        if isinstance(plan, L.Scan):
            tbl = self.catalog.get_table(plan.table) if plan.table else None
            if tbl:
                rows, cost = self.cost.scan_cost(tbl)
            else:
                rows, cost = (1, 1.0)
            return P.SeqScan(
                table=plan.table,
                alias=plan.alias,
                projected_columns=tuple(plan.projected_columns),
                estimated_rows=rows,
                estimated_cost=cost,
            )
        if isinstance(plan, L.Filter):
            inner = self._physical(plan.input) if plan.input else None
            rows = (inner.estimated_rows if inner else 1) * 0.5
            cost = (inner.estimated_cost if inner else 0) + (rows * self.cfg.cost_cpu_operator)
            return P.FilterNode(
                input=inner, predicate=plan.predicate,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Project):
            inner = self._physical(plan.input) if plan.input else None
            rows = inner.estimated_rows if inner else 1
            cost = inner.estimated_cost if inner else 0
            return P.ProjectNode(
                input=inner, projections=plan.projections, distinct=plan.distinct,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Join):
            left = self._physical(plan.left) if plan.left else None
            right = self._physical(plan.right) if plan.right else None
            rows, cost = self.cost.hash_join_cost(
                right.estimated_rows if right else 1,
                left.estimated_rows if left else 1,
            )
            return P.HashJoin(
                build=right, probe=left,
                build_keys=[], probe_keys=[],
                residual=plan.predicate, join_kind=plan.kind,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Aggregate):
            inner = self._physical(plan.input) if plan.input else None
            rows = max(int((inner.estimated_rows if inner else 1) ** 0.5), 1)
            cost = (inner.estimated_cost if inner else 0) + rows * self.cfg.cost_cpu_operator
            return P.HashAggregate(
                input=inner, group_keys=list(plan.group_keys),
                aggregates=list(plan.aggregates), having=plan.having,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Sort):
            inner = self._physical(plan.input) if plan.input else None
            rows = inner.estimated_rows if inner else 1
            cost = (inner.estimated_cost if inner else 0) + rows * self.cfg.cost_cpu_operator * 2
            return P.SortNode(
                input=inner, order=plan.order,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Limit):
            inner = self._physical(plan.input) if plan.input else None
            rows = inner.estimated_rows if inner else 1
            cost = inner.estimated_cost if inner else 0
            return P.LimitNode(
                input=inner, limit=plan.limit, offset=plan.offset,
                estimated_rows=rows, estimated_cost=cost,
            )
        if isinstance(plan, L.Insert):
            source = self._physical(plan.select) if plan.select else None
            return P.InsertNode(
                table=plan.table, columns=plan.columns, rows=plan.rows, source=source,
                estimated_rows=len(plan.rows), estimated_cost=len(plan.rows),
            )
        if isinstance(plan, L.Update):
            return P.UpdateNode(
                table=plan.table, assignments=plan.assignments, predicate=plan.predicate,
            )
        if isinstance(plan, L.Delete):
            return P.DeleteNode(table=plan.table, predicate=plan.predicate)
        raise PlanError(f"cannot build physical plan for {type(plan).__name__}")



_AGGREGATE_NAMES = {"COUNT", "SUM", "AVG", "MIN", "MAX"}


def _contains_aggregate(items: Sequence[A.SelectItem]) -> bool:
    for item in items:
        if isinstance(item.expr, A.FunctionCall) and item.expr.name.upper() in _AGGREGATE_NAMES:
            return True
    return False


def _collect_aggregates(
    items: Sequence[A.SelectItem],
) -> list[tuple[A.FunctionCall, str | None]]:
    out: list[tuple[A.FunctionCall, str | None]] = []
    for item in items:
        if isinstance(item.expr, A.FunctionCall) and item.expr.name.upper() in _AGGREGATE_NAMES:
            out.append((item.expr, item.alias))
    return out
