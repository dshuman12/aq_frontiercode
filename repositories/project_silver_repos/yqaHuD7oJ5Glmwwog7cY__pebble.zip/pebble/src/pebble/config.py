from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from pebble.constants import (
    DEFAULT_BUFFER_POOL_PAGES,
    DEFAULT_HOST,
    DEFAULT_LOCK_TIMEOUT_MS,
    DEFAULT_PORT,
    DEFAULT_RING_BUFFER_PAGES,
    DEFAULT_STATEMENT_TIMEOUT_MS,
    PAGE_SIZE,
    WAL_DEFAULT_SEGMENT_SIZE,
)


@dataclass(frozen=True)
class StorageConfig:
    page_size: int = PAGE_SIZE
    buffer_pool_pages: int = DEFAULT_BUFFER_POOL_PAGES
    ring_buffer_pages: int = DEFAULT_RING_BUFFER_PAGES
    fsync_on_commit: bool = True
    direct_io: bool = False


@dataclass(frozen=True)
class WalConfig:
    segment_size: int = WAL_DEFAULT_SEGMENT_SIZE
    group_commit_window_us: int = 200
    checkpoint_interval_seconds: int = 60
    archive_segments: bool = False


@dataclass(frozen=True)
class TxnConfig:
    default_isolation: str = "snapshot"
    statement_timeout_ms: int = DEFAULT_STATEMENT_TIMEOUT_MS
    lock_timeout_ms: int = DEFAULT_LOCK_TIMEOUT_MS
    deadlock_detect_interval_ms: int = 1_000
    autovacuum_threshold: int = 50_000


@dataclass(frozen=True)
class OptimizerConfig:
    enable_index_scan: bool = True
    enable_hash_join: bool = True
    enable_merge_join: bool = True
    enable_nested_loop: bool = True
    join_reorder_limit: int = 6
    cost_seq_page: float = 1.0
    cost_index_page: float = 4.0
    cost_cpu_tuple: float = 0.01
    cost_cpu_operator: float = 0.0025


@dataclass(frozen=True)
class ServerConfig:
    host: str = DEFAULT_HOST
    port: int = DEFAULT_PORT
    max_connections: int = 32
    auth_required: bool = False


@dataclass(frozen=True)
class Config:
    data_dir: Path = field(default_factory=lambda: Path(os.environ.get("PEBBLE_DATA", "./pebble_data")))
    storage: StorageConfig = field(default_factory=StorageConfig)
    wal: WalConfig = field(default_factory=WalConfig)
    txn: TxnConfig = field(default_factory=TxnConfig)
    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    server: ServerConfig = field(default_factory=ServerConfig)

    def with_overrides(self, **sections: Any) -> "Config":
        kwargs: dict[str, Any] = {}
        for name, override in sections.items():
            current = getattr(self, name)
            if isinstance(override, dict):
                kwargs[name] = replace(current, **override)
            else:
                kwargs[name] = override
        return replace(self, **kwargs)


_cached: Config | None = None


def get_config() -> Config:
    global _cached
    if _cached is None:
        _cached = _from_env()
    return _cached


def set_config(cfg: Config) -> None:
    global _cached
    _cached = cfg


def reset_config() -> None:
    global _cached
    _cached = None


def _from_env() -> Config:
    cfg = Config()
    overrides: dict[str, dict[str, Any]] = {}
    if v := os.environ.get("PEBBLE_PORT"):
        overrides.setdefault("server", {})["port"] = int(v)
    if v := os.environ.get("PEBBLE_HOST"):
        overrides.setdefault("server", {})["host"] = v
    if v := os.environ.get("PEBBLE_BUFFER_POOL_PAGES"):
        overrides.setdefault("storage", {})["buffer_pool_pages"] = int(v)
    if v := os.environ.get("PEBBLE_FSYNC"):
        overrides.setdefault("storage", {})["fsync_on_commit"] = v.lower() in {"1", "true", "yes"}
    if v := os.environ.get("PEBBLE_ISOLATION"):
        overrides.setdefault("txn", {})["default_isolation"] = v
    if overrides:
        return cfg.with_overrides(**overrides)
    return cfg
