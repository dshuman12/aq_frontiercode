from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from pebble.errors import TypeMismatch
from pebble.types.sqltype import (
    BIGINT,
    BLOB,
    BOOL,
    DATE,
    DOUBLE,
    INT,
    NULL,
    TEXT,
    TIMESTAMP,
    SqlType,
    TypeCode,
)


@dataclass(frozen=True)
class Value:
    """A typed value at execution time."""

    type: SqlType
    payload: Any

    @classmethod
    def null(cls) -> "Value":
        return cls(NULL, None)

    @classmethod
    def of(cls, payload: Any) -> "Value":
        """Best-effort wrap a Python value into a :class:`Value`."""
        if payload is None:
            return cls.null()
        if isinstance(payload, bool):
            return cls(BOOL, payload)
        if isinstance(payload, int):
            return cls(BIGINT if abs(payload) > 2_147_483_647 else INT, payload)
        if isinstance(payload, float):
            return cls(DOUBLE, payload)
        if isinstance(payload, str):
            return cls(TEXT, payload)
        if isinstance(payload, (bytes, bytearray)):
            return cls(BLOB, bytes(payload))
        if isinstance(payload, _dt.datetime):
            return cls(TIMESTAMP, payload)
        if isinstance(payload, _dt.date):
            return cls(DATE, payload)
        if isinstance(payload, Decimal):
            return cls(DOUBLE, float(payload))
        raise TypeMismatch(f"cannot wrap python value of type {type(payload).__name__}")

    @property
    def is_null(self) -> bool:
        return self.payload is None

    @property
    def is_true(self) -> bool:
        return self.payload is True

    @property
    def is_false(self) -> bool:
        return self.payload is False

    def equals(self, other: "Value") -> "Value":
        """SQL ``=`` -- null in either side yields NULL, not BOOL(False)."""
        if self.is_null or other.is_null:
            return self.null()
        return Value(BOOL, _coerce_compare(self, other) == 0)

    def less_than(self, other: "Value") -> "Value":
        if self.is_null or other.is_null:
            return self.null()
        return Value(BOOL, _coerce_compare(self, other) < 0)

    def cmp(self, other: "Value") -> int | None:
        """Three-way compare. Returns -1/0/1 or None for NULL."""
        if self.is_null or other.is_null:
            return None
        return _coerce_compare(self, other)

    def to_python(self) -> Any:
        return self.payload

    def render(self) -> str:
        if self.is_null:
            return "NULL"
        if self.type.code == TypeCode.TEXT:
            return self.payload
        if self.type.code == TypeCode.BLOB:
            return f"\\x{self.payload.hex()}"
        return repr(self.payload)

    def __repr__(self) -> str:
        return f"Value({self.type.render()}, {self.payload!r})"


def _coerce_compare(a: Value, b: Value) -> int:
    # Integer-compare the all-integer case to avoid float precision loss on big numbers.
    ac, bc = a.type.code, b.type.code
    if ac == bc:
        return _three_way(a.payload, b.payload)
    if a.type.is_numeric and b.type.is_numeric:
        if a.type.is_integer and b.type.is_integer:
            return _three_way(int(a.payload), int(b.payload))
        return _three_way(float(a.payload), float(b.payload))
    if ac == TypeCode.DATE and bc == TypeCode.TIMESTAMP:
        return _three_way(_to_datetime(a.payload), b.payload)
    if ac == TypeCode.TIMESTAMP and bc == TypeCode.DATE:
        return _three_way(a.payload, _to_datetime(b.payload))
    if a.type.is_string and b.type.is_string:
        return _three_way(a.payload, b.payload)
    raise TypeMismatch(f"cannot compare {a.type} and {b.type}")


def _three_way(a: Any, b: Any) -> int:
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


def _to_datetime(d: _dt.date) -> _dt.datetime:
    return _dt.datetime(d.year, d.month, d.day)


def add(a: Value, b: Value) -> Value:
    if a.is_null or b.is_null:
        return Value.null()
    if a.type.is_numeric and b.type.is_numeric:
        return Value.of(_promote_num(a) + _promote_num(b))
    if a.type.is_string and b.type.is_string:
        return Value(TEXT, a.payload + b.payload)
    raise TypeMismatch(f"cannot add {a.type} and {b.type}")


def sub(a: Value, b: Value) -> Value:
    if a.is_null or b.is_null:
        return Value.null()
    if a.type.is_numeric and b.type.is_numeric:
        return Value.of(_promote_num(a) - _promote_num(b))
    raise TypeMismatch(f"cannot subtract {a.type} and {b.type}")


def mul(a: Value, b: Value) -> Value:
    if a.is_null or b.is_null:
        return Value.null()
    if a.type.is_numeric and b.type.is_numeric:
        return Value.of(_promote_num(a) * _promote_num(b))
    raise TypeMismatch(f"cannot multiply {a.type} and {b.type}")


def div(a: Value, b: Value) -> Value:
    if a.is_null or b.is_null:
        return Value.null()
    if a.type.is_numeric and b.type.is_numeric:
        right = _promote_num(b)
        if right == 0:
            from pebble.errors import DivisionByZero

            raise DivisionByZero("division by zero")
        if a.type.is_integer and b.type.is_integer:
            return Value.of(int(_promote_num(a)) // int(right))
        return Value.of(_promote_num(a) / right)
    raise TypeMismatch(f"cannot divide {a.type} and {b.type}")


def neg(v: Value) -> Value:
    if v.is_null:
        return Value.null()
    if v.type.is_numeric:
        return Value.of(-v.payload)
    raise TypeMismatch(f"cannot negate {v.type}")


def boolean_and(a: Value, b: Value) -> Value:
    if a.is_false or b.is_false:
        return Value(BOOL, False)
    if a.is_null or b.is_null:
        return Value.null()
    return Value(BOOL, True)


def boolean_or(a: Value, b: Value) -> Value:
    if a.is_true or b.is_true:
        return Value(BOOL, True)
    if a.is_null or b.is_null:
        return Value.null()
    return Value(BOOL, False)


def boolean_not(v: Value) -> Value:
    if v.is_null:
        return Value.null()
    return Value(BOOL, not v.payload)


def _promote_num(v: Value) -> Any:
    if v.type.is_integer:
        return int(v.payload)
    return float(v.payload)
