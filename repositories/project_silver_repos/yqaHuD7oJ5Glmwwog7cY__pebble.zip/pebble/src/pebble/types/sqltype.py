from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Final


class TypeCode(enum.IntEnum):
    NULL = 0
    BOOL = 1
    INT = 2          # 32-bit signed
    BIGINT = 3       # 64-bit signed
    DOUBLE = 4
    TEXT = 5
    BLOB = 6
    DATE = 7
    TIMESTAMP = 8
    NUMERIC = 9      # arbitrary precision (TODO)


@dataclass(frozen=True)
class SqlType:
    """Type tag plus optional length / scale for parameterised types."""

    code: TypeCode
    length: int | None = None
    scale: int | None = None
    nullable: bool = True

    def __post_init__(self) -> None:
        if self.code in {TypeCode.TEXT, TypeCode.BLOB} and self.length is not None:
            if self.length <= 0:
                raise ValueError(f"length for {self.code.name} must be positive")
        if self.code == TypeCode.NUMERIC:
            if self.length is None or self.scale is None:
                raise ValueError("NUMERIC requires precision and scale")
            if self.length <= 0 or not (0 <= self.scale <= self.length):
                raise ValueError("invalid NUMERIC(precision, scale)")

    @property
    def is_integer(self) -> bool:
        return self.code in {TypeCode.INT, TypeCode.BIGINT}

    @property
    def is_numeric(self) -> bool:
        return self.code in {TypeCode.INT, TypeCode.BIGINT, TypeCode.DOUBLE, TypeCode.NUMERIC}

    @property
    def is_string(self) -> bool:
        return self.code == TypeCode.TEXT

    @property
    def is_temporal(self) -> bool:
        return self.code in {TypeCode.DATE, TypeCode.TIMESTAMP}

    @property
    def is_variable_length(self) -> bool:
        return self.code in {TypeCode.TEXT, TypeCode.BLOB}

    def with_nullable(self, nullable: bool) -> "SqlType":
        return SqlType(self.code, self.length, self.scale, nullable=nullable)

    def render(self) -> str:
        base = self.code.name
        if self.code == TypeCode.NUMERIC:
            return f"NUMERIC({self.length},{self.scale})"
        if self.length is not None:
            return f"{base}({self.length})"
        return base

    def __str__(self) -> str:
        out = self.render()
        if not self.nullable:
            out = f"{out} NOT NULL"
        return out


NULL: Final[SqlType] = SqlType(TypeCode.NULL)
BOOL: Final[SqlType] = SqlType(TypeCode.BOOL)
INT: Final[SqlType] = SqlType(TypeCode.INT)
BIGINT: Final[SqlType] = SqlType(TypeCode.BIGINT)
DOUBLE: Final[SqlType] = SqlType(TypeCode.DOUBLE)
TEXT: Final[SqlType] = SqlType(TypeCode.TEXT)
BLOB: Final[SqlType] = SqlType(TypeCode.BLOB)
DATE: Final[SqlType] = SqlType(TypeCode.DATE)
TIMESTAMP: Final[SqlType] = SqlType(TypeCode.TIMESTAMP)


# Numeric coercion lattice: INT -> BIGINT -> NUMERIC -> DOUBLE.
# DATE and TIMESTAMP coerce to TIMESTAMP for comparison; TEXT does not
# implicitly coerce to anything else (callers must CAST).
_NUMERIC_RANK: Final[dict[TypeCode, int]] = {
    TypeCode.INT: 1,
    TypeCode.BIGINT: 2,
    TypeCode.NUMERIC: 3,
    TypeCode.DOUBLE: 4,
}


def common_type(a: SqlType, b: SqlType) -> SqlType:
    """Return the type both ``a`` and ``b`` can coerce to."""
    if a.code == TypeCode.NULL:
        return b.with_nullable(True)
    if b.code == TypeCode.NULL:
        return a.with_nullable(True)
    if a == b:
        return a
    if a.is_numeric and b.is_numeric:
        ra = _NUMERIC_RANK[a.code]
        rb = _NUMERIC_RANK[b.code]
        promoted_code = next(c for c, r in _NUMERIC_RANK.items() if r == max(ra, rb))
        return SqlType(promoted_code, nullable=a.nullable or b.nullable)
    if a.is_temporal and b.is_temporal:
        return TIMESTAMP.with_nullable(a.nullable or b.nullable)
    if a.code == TypeCode.BOOL and b.code == TypeCode.BOOL:
        return BOOL
    if a.is_string and b.is_string:
        # Pick the longer of the two; absent length means "unbounded".
        if a.length is None or b.length is None:
            return TEXT.with_nullable(a.nullable or b.nullable)
        return SqlType(TypeCode.TEXT, length=max(a.length, b.length),
                       nullable=a.nullable or b.nullable)
    raise TypeError(f"cannot find common type for {a} and {b}")


def can_coerce(src: SqlType, dst: SqlType) -> bool:
    """Return ``True`` iff ``src`` can be implicitly coerced to ``dst``."""
    if src.code == TypeCode.NULL:
        return dst.nullable
    if src == dst:
        return True
    try:
        return common_type(src, dst) == dst.with_nullable(True)
    except TypeError:
        return False


def parse_type(name: str, *, length: int | None = None,
               scale: int | None = None,
               nullable: bool = True) -> SqlType:
    """Map a SQL type keyword (``"int"``, ``"varchar"``) to a :class:`SqlType`."""
    norm = name.strip().upper()
    aliases = {
        "INTEGER": TypeCode.INT,
        "INT": TypeCode.INT,
        "INT4": TypeCode.INT,
        "BIGINT": TypeCode.BIGINT,
        "INT8": TypeCode.BIGINT,
        "FLOAT": TypeCode.DOUBLE,
        "DOUBLE": TypeCode.DOUBLE,
        "REAL": TypeCode.DOUBLE,
        "BOOL": TypeCode.BOOL,
        "BOOLEAN": TypeCode.BOOL,
        "TEXT": TypeCode.TEXT,
        "VARCHAR": TypeCode.TEXT,
        "CHAR": TypeCode.TEXT,
        "STRING": TypeCode.TEXT,
        "BLOB": TypeCode.BLOB,
        "BYTEA": TypeCode.BLOB,
        "DATE": TypeCode.DATE,
        "TIMESTAMP": TypeCode.TIMESTAMP,
        "TIMESTAMPTZ": TypeCode.TIMESTAMP,
        "NUMERIC": TypeCode.NUMERIC,
        "DECIMAL": TypeCode.NUMERIC,
    }
    if norm not in aliases:
        raise ValueError(f"unknown SQL type: {name!r}")
    return SqlType(aliases[norm], length=length, scale=scale, nullable=nullable)
