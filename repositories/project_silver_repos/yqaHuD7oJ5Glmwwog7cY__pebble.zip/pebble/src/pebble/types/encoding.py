from __future__ import annotations

# Tuple layout on disk:
#   [u16 column count]
#   [null bitmap, ceil(N/8) bytes]
#   [for each non-null column: type-specific payload]
# Fixed-width types use their natural byte representation;
# variable-width types are length-prefixed (varint). Strings are UTF-8.

import io
import struct
from datetime import date, datetime, timezone
from typing import Iterable

from pebble.errors import StorageError
from pebble.types.sqltype import SqlType, TypeCode
from pebble.types.value import Value

# struct format characters per fixed-width type.
_FIXED: dict[TypeCode, str] = {
    TypeCode.BOOL: "?",
    TypeCode.INT: "<i",
    TypeCode.BIGINT: "<q",
    TypeCode.DOUBLE: "<d",
    TypeCode.DATE: "<i",         # days since epoch
    TypeCode.TIMESTAMP: "<q",    # microseconds since epoch
}


def encode_tuple(types: list[SqlType], values: list[Value]) -> bytes:
    """Serialize a row into a flat bytes object."""
    if len(types) != len(values):
        raise StorageError(
            f"encode mismatch: {len(types)} types vs {len(values)} values"
        )
    bitmap = _build_null_bitmap(values)
    buf = io.BytesIO()
    buf.write(struct.pack("<H", len(types)))
    buf.write(bitmap)
    for ty, val in zip(types, values):
        if val.is_null:
            continue
        _encode_value(buf, ty, val)
    return buf.getvalue()


def decode_tuple(types: list[SqlType], blob: bytes) -> list[Value]:
    """Inverse of :func:`encode_tuple`."""
    buf = io.BytesIO(blob)
    (count,) = _read_struct(buf, "<H")
    if count != len(types):
        raise StorageError(
            f"decode count mismatch: schema has {len(types)} columns, payload has {count}"
        )
    bitmap_len = (count + 7) // 8
    bitmap = buf.read(bitmap_len)
    out: list[Value] = []
    for i, ty in enumerate(types):
        if _bit_set(bitmap, i):
            out.append(Value.null())
        else:
            out.append(_decode_value(buf, ty))
    return out


def _encode_value(buf: io.BytesIO, ty: SqlType, val: Value) -> None:
    code = ty.code
    if code in _FIXED:
        payload = _to_fixed_payload(code, val.payload)
        buf.write(struct.pack(_FIXED[code], payload))
        return
    if code == TypeCode.TEXT:
        encoded = val.payload.encode("utf-8")
        _write_varint(buf, len(encoded))
        buf.write(encoded)
        return
    if code == TypeCode.BLOB:
        _write_varint(buf, len(val.payload))
        buf.write(val.payload)
        return
    if code == TypeCode.NUMERIC:
        # Encode as a length-prefixed UTF-8 decimal literal.
        s = format(val.payload, "f")
        encoded = s.encode("ascii")
        _write_varint(buf, len(encoded))
        buf.write(encoded)
        return
    raise StorageError(f"cannot encode type {ty}")


def _decode_value(buf: io.BytesIO, ty: SqlType) -> Value:
    code = ty.code
    if code in _FIXED:
        (payload,) = _read_struct(buf, _FIXED[code])
        return Value(ty, _from_fixed_payload(code, payload))
    if code == TypeCode.TEXT:
        n = _read_varint(buf)
        return Value(ty, buf.read(n).decode("utf-8"))
    if code == TypeCode.BLOB:
        n = _read_varint(buf)
        return Value(ty, buf.read(n))
    if code == TypeCode.NUMERIC:
        n = _read_varint(buf)
        from decimal import Decimal

        return Value(ty, Decimal(buf.read(n).decode("ascii")))
    raise StorageError(f"cannot decode type {ty}")


def _to_fixed_payload(code: TypeCode, payload: object) -> object:
    if code == TypeCode.DATE:
        epoch = date(1970, 1, 1)
        return (payload - epoch).days  # type: ignore[operator]
    if code == TypeCode.TIMESTAMP:
        if payload.tzinfo is None:  # type: ignore[union-attr]
            payload = payload.replace(tzinfo=timezone.utc)  # type: ignore[union-attr]
        delta = payload - datetime(1970, 1, 1, tzinfo=timezone.utc)  # type: ignore[operator]
        return int(delta.total_seconds() * 1_000_000)
    return payload


def _from_fixed_payload(code: TypeCode, payload: object) -> object:
    if code == TypeCode.DATE:
        epoch = date(1970, 1, 1)
        from datetime import timedelta

        return epoch + timedelta(days=payload)  # type: ignore[arg-type]
    if code == TypeCode.TIMESTAMP:
        from datetime import timedelta

        return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=payload)  # type: ignore[arg-type]
    return payload


def _build_null_bitmap(values: Iterable[Value]) -> bytes:
    bits: list[int] = []
    for v in values:
        bits.append(1 if v.is_null else 0)
    bitmap = bytearray((len(bits) + 7) // 8)
    for i, bit in enumerate(bits):
        if bit:
            bitmap[i >> 3] |= 1 << (i & 7)
    return bytes(bitmap)


def _bit_set(bitmap: bytes, index: int) -> bool:
    return bool(bitmap[index >> 3] & (1 << (index & 7)))


def _write_varint(buf: io.BytesIO, value: int) -> None:
    if value < 0:
        raise StorageError("varint cannot encode negative values")
    while True:
        if value < 0x80:
            buf.write(bytes([value]))
            return
        buf.write(bytes([(value & 0x7F) | 0x80]))
        value >>= 7


def _read_varint(buf: io.BytesIO) -> int:
    shift = 0
    result = 0
    while True:
        b = buf.read(1)
        if not b:
            raise StorageError("varint truncated")
        byte = b[0]
        result |= (byte & 0x7F) << shift
        if byte < 0x80:
            return result
        shift += 7
        if shift > 63:
            raise StorageError("varint too long")


def _read_struct(buf: io.BytesIO, fmt: str) -> tuple:
    size = struct.calcsize(fmt)
    raw = buf.read(size)
    if len(raw) != size:
        raise StorageError(f"truncated read: needed {size} bytes, got {len(raw)}")
    return struct.unpack(fmt, raw)
