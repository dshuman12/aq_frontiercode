from __future__ import annotations

import io
import os
from dataclasses import dataclass
from typing import IO, Iterator

from pebble.constants import HEAP_PAGE_KIND, PAGE_SIZE
from pebble.errors import StorageError
from pebble.storage.page import HeapPage, empty_page


@dataclass(frozen=True)
class TupleId:
    """``(page_id, slot)`` pair, stored in indexes and visibility cache."""

    page_id: int
    slot: int

    def pack(self) -> bytes:
        return self.page_id.to_bytes(4, "little") + self.slot.to_bytes(2, "little")

    @classmethod
    def unpack(cls, raw: bytes) -> "TupleId":
        if len(raw) != 6:
            raise StorageError("tid must be 6 bytes")
        return cls(
            page_id=int.from_bytes(raw[:4], "little"),
            slot=int.from_bytes(raw[4:], "little"),
        )

    def __repr__(self) -> str:
        return f"({self.page_id}, {self.slot})"


class HeapFile:
    """Page-addressable file. Callers should go through the buffer pool, not this directly."""

    def __init__(self, path: str, *, readonly: bool = False) -> None:
        self.path = path
        self.readonly = readonly
        flags = "rb" if readonly else "r+b"
        if not os.path.exists(path):
            if readonly:
                raise FileNotFoundError(path)
            with open(path, "wb"):
                pass
        self._fh: IO[bytes] = open(path, flags)
        self._fh.seek(0, io.SEEK_END)
        self._page_count = self._fh.tell() // PAGE_SIZE

    def close(self) -> None:
        if not self._fh.closed:
            self._fh.flush()
            self._fh.close()

    def __enter__(self) -> "HeapFile":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @property
    def page_count(self) -> int:
        return self._page_count

    def read_page(self, page_id: int) -> HeapPage:
        if page_id >= self._page_count:
            raise StorageError(f"read past end-of-file: page {page_id}")
        self._fh.seek(page_id * PAGE_SIZE)
        raw = self._fh.read(PAGE_SIZE)
        if len(raw) != PAGE_SIZE:
            raise StorageError(
                f"short read for page {page_id}: got {len(raw)} of {PAGE_SIZE}"
            )
        return HeapPage.thaw(raw)

    def write_page(self, page: HeapPage) -> None:
        if self.readonly:
            raise StorageError("cannot write to a readonly heap file")
        self._fh.seek(page.header.page_id * PAGE_SIZE)
        self._fh.write(page.freeze())
        page.mark_clean()

    def allocate_page(self) -> HeapPage:
        if self.readonly:
            raise StorageError("cannot allocate in a readonly heap file")
        new_id = self._page_count
        page = empty_page(new_id)
        self._fh.seek(new_id * PAGE_SIZE)
        self._fh.write(page.freeze())
        self._page_count += 1
        return page

    def fsync(self) -> None:
        self._fh.flush()
        os.fsync(self._fh.fileno())

    def iter_pages(self) -> Iterator[HeapPage]:
        for page_id in range(self._page_count):
            yield self.read_page(page_id)

    def iter_tuples(self) -> Iterator[tuple[TupleId, bytes]]:
        for page in self.iter_pages():
            for i, slot in enumerate(page.slots()):
                if slot.is_empty:
                    continue
                yield TupleId(page.header.page_id, i), page.read(i)


class FreeSpaceMap:
    """In-memory cache of ``page_id -> free bytes``."""

    # Note: this FSM lives entirely in memory and rebuilds on startup; that
    # makes a cold boot O(pages) but keeps the storage layer simple.

    def __init__(self) -> None:
        self._map: dict[int, int] = {}

    def update(self, page_id: int, free_bytes: int) -> None:
        if free_bytes <= 0:
            self._map.pop(page_id, None)
        else:
            self._map[page_id] = free_bytes

    def find_with_space(self, needed: int) -> int | None:
        for pid, free in self._map.items():
            if free >= needed:
                return pid
        return None

    def remove(self, page_id: int) -> None:
        self._map.pop(page_id, None)

    def rebuild_from(self, heap: HeapFile) -> None:
        self._map.clear()
        for page in heap.iter_pages():
            self.update(page.header.page_id, page.free_space())
