from __future__ import annotations

import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator


@dataclass
class _LatchState:
    rwlock: threading.RLock = field(default_factory=threading.RLock)
    readers: int = 0
    writer: int | None = None
    cond: threading.Condition = field(init=False)

    def __post_init__(self) -> None:
        self.cond = threading.Condition(self.rwlock)


class PageLatchTable:
    """Per-page latch registry."""

    def __init__(self) -> None:
        self._latches: dict[int, _LatchState] = {}
        self._table_lock = threading.Lock()

    @contextmanager
    def shared(self, page_id: int) -> Iterator[None]:
        state = self._get_state(page_id)
        with state.cond:
            while state.writer is not None and state.writer != threading.get_ident():
                state.cond.wait()
            state.readers += 1
        try:
            yield
        finally:
            with state.cond:
                state.readers -= 1
                if state.readers == 0:
                    state.cond.notify_all()

    @contextmanager
    def exclusive(self, page_id: int) -> Iterator[None]:
        state = self._get_state(page_id)
        me = threading.get_ident()
        with state.cond:
            while state.writer is not None and state.writer != me or state.readers:
                state.cond.wait()
            state.writer = me
        try:
            yield
        finally:
            with state.cond:
                state.writer = None
                state.cond.notify_all()

    def _get_state(self, page_id: int) -> _LatchState:
        with self._table_lock:
            state = self._latches.get(page_id)
            if state is None:
                state = _LatchState()
                self._latches[page_id] = state
            return state

    def reset(self) -> None:
        """Drop every latch -- for tests only."""
        with self._table_lock:
            self._latches.clear()
