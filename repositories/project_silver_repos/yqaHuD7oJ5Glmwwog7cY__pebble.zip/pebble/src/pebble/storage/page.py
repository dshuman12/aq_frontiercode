from __future__ import annotations

# Page header layout (little-endian, 32 bytes total):
#   0  4  magic ("PBL1")
#   4  1  kind
#   5  1  version
#   6  2  reserved
#   8  4  page id
#  12  8  lsn
#  20  2  slot count
#  22  2  free space upper bound
#  24  4  CRC32 over the rest of the page
#  28  4  reserved
# Slot directory grows up from offset 32; tuple payloads grow down from the end.
# Slot length 0xFFFF marks a slot whose payload was collected by VACUUM.

import struct
import zlib
from dataclasses import dataclass

from pebble.constants import (
    HEAP_PAGE_KIND,
    INVALID_PAGE_ID,
    PAGE_HEADER_SIZE,
    PAGE_MAGIC,
    PAGE_SIZE,
)
from pebble.errors import CorruptPage, PageFull, StorageError

_HEADER_STRUCT = struct.Struct("<4sBBHIQHH I I")  # 32 bytes total


@dataclass
class PageHeader:
    kind: int
    version: int
    page_id: int
    lsn: int
    slot_count: int
    free_upper: int  # offset of the first byte of free space from start of page
    crc: int

    def pack(self) -> bytes:
        return _HEADER_STRUCT.pack(
            PAGE_MAGIC,
            self.kind,
            self.version,
            0,  # reserved
            self.page_id,
            self.lsn,
            self.slot_count,
            self.free_upper,
            self.crc,
            0,  # reserved
        )

    @classmethod
    def unpack(cls, raw: bytes) -> "PageHeader":
        if len(raw) < PAGE_HEADER_SIZE:
            raise CorruptPage("page header too short")
        magic, kind, version, _reserved, page_id, lsn, slot_count, free_upper, crc, _r2 = (
            _HEADER_STRUCT.unpack_from(raw, 0)
        )
        if magic != PAGE_MAGIC:
            raise CorruptPage(f"bad page magic: {magic!r}")
        return cls(
            kind=kind, version=version, page_id=page_id, lsn=lsn,
            slot_count=slot_count, free_upper=free_upper, crc=crc,
        )


SLOT_FORMAT = struct.Struct("<HH")  # offset, length
EMPTY_SLOT_LENGTH = 0xFFFF


@dataclass
class Slot:
    offset: int
    length: int

    @property
    def is_empty(self) -> bool:
        return self.length == EMPTY_SLOT_LENGTH


class HeapPage:
    """In-memory wrapper around a page-sized bytearray."""

    def __init__(self, page_id: int, kind: int = HEAP_PAGE_KIND) -> None:
        self.buf = bytearray(PAGE_SIZE)
        self.header = PageHeader(
            kind=kind, version=1, page_id=page_id, lsn=0,
            slot_count=0, free_upper=PAGE_SIZE, crc=0,
        )
        self._dirty = True

    def freeze(self) -> bytes:
        """Return a serialised, CRC-stamped copy of the page."""
        self.header.crc = 0
        out = bytearray(self.buf)
        out[: PAGE_HEADER_SIZE] = self.header.pack()
        crc = zlib.crc32(bytes(out[PAGE_HEADER_SIZE:]))
        self.header.crc = crc
        out[: PAGE_HEADER_SIZE] = self.header.pack()
        return bytes(out)

    @classmethod
    def thaw(cls, raw: bytes) -> "HeapPage":
        if len(raw) != PAGE_SIZE:
            raise CorruptPage(f"page size mismatch: expected {PAGE_SIZE}, got {len(raw)}")
        header = PageHeader.unpack(raw)
        # CRC is computed over the body only; the stored CRC sits in the header.
        body = bytearray(raw)
        body_view = bytes(body[PAGE_HEADER_SIZE:])
        header_no_crc = PageHeader(
            kind=header.kind, version=header.version, page_id=header.page_id,
            lsn=header.lsn, slot_count=header.slot_count,
            free_upper=header.free_upper, crc=0,
        )
        recomputed = zlib.crc32(body_view)
        if header.crc != recomputed:
            raise CorruptPage(
                f"page {header.page_id} CRC mismatch: stored=0x{header.crc:08x}, "
                f"computed=0x{recomputed:08x}"
            )
        page = cls(page_id=header.page_id, kind=header.kind)
        page.header = header
        page.buf = bytearray(raw)
        page._dirty = False
        return page

    def free_space(self) -> int:
        directory_end = PAGE_HEADER_SIZE + self.header.slot_count * SLOT_FORMAT.size
        return self.header.free_upper - directory_end

    def insert(self, payload: bytes) -> int:
        if not payload:
            raise StorageError("cannot insert empty tuple")
        size_needed = len(payload) + SLOT_FORMAT.size
        if size_needed > self.free_space():
            raise PageFull(
                f"page {self.header.page_id} full: need {size_needed}, "
                f"have {self.free_space()}"
            )
        new_upper = self.header.free_upper - len(payload)
        self.buf[new_upper: new_upper + len(payload)] = payload
        slot_index = self.header.slot_count
        slot_offset = PAGE_HEADER_SIZE + slot_index * SLOT_FORMAT.size
        SLOT_FORMAT.pack_into(self.buf, slot_offset, new_upper, len(payload))
        self.header.free_upper = new_upper
        self.header.slot_count += 1
        self._dirty = True
        return slot_index

    def read(self, slot_index: int) -> bytes:
        slot = self._slot(slot_index)
        if slot.is_empty:
            raise StorageError(f"slot {slot_index} on page {self.header.page_id} is empty")
        return bytes(self.buf[slot.offset: slot.offset + slot.length])

    def update_in_place(self, slot_index: int, payload: bytes) -> bool:
        """Overwrite a slot if the new payload fits; return False if it does not."""
        slot = self._slot(slot_index)
        if slot.is_empty:
            raise StorageError("cannot update empty slot")
        if len(payload) > slot.length:
            return False
        self.buf[slot.offset: slot.offset + len(payload)] = payload
        if len(payload) < slot.length:
            # Zero padding is not required for correctness, only for deterministic test diffs.
            self.buf[slot.offset + len(payload): slot.offset + slot.length] = bytes(
                slot.length - len(payload)
            )
        self._dirty = True
        return True

    def delete(self, slot_index: int) -> None:
        slot = self._slot(slot_index)
        slot_offset = PAGE_HEADER_SIZE + slot_index * SLOT_FORMAT.size
        SLOT_FORMAT.pack_into(self.buf, slot_offset, slot.offset, EMPTY_SLOT_LENGTH)
        # Zero the payload so logical readers cannot see stale bytes.
        self.buf[slot.offset: slot.offset + slot.length] = bytes(slot.length)
        self._dirty = True

    def vacuum(self) -> int:
        """Compact tuple storage to reclaim space from deleted slots."""
        live: list[tuple[int, bytes]] = []
        for i in range(self.header.slot_count):
            slot = self._slot(i)
            if slot.is_empty:
                continue
            live.append((i, bytes(self.buf[slot.offset: slot.offset + slot.length])))
        self.buf[PAGE_HEADER_SIZE + self.header.slot_count * SLOT_FORMAT.size:] = bytes(
            PAGE_SIZE - PAGE_HEADER_SIZE - self.header.slot_count * SLOT_FORMAT.size
        )
        # Re-insert preserving original slot order at the upper end.
        upper = PAGE_SIZE
        before_upper = self.header.free_upper
        for slot_index, payload in live:
            upper -= len(payload)
            self.buf[upper: upper + len(payload)] = payload
            slot_offset = PAGE_HEADER_SIZE + slot_index * SLOT_FORMAT.size
            SLOT_FORMAT.pack_into(self.buf, slot_offset, upper, len(payload))
        self.header.free_upper = upper
        self._dirty = True
        return upper - before_upper

    def slots(self) -> list[Slot]:
        return [self._slot(i) for i in range(self.header.slot_count)]

    @property
    def dirty(self) -> bool:
        return self._dirty

    def mark_clean(self) -> None:
        self._dirty = False

    def mark_dirty(self) -> None:
        self._dirty = True

    def _slot(self, slot_index: int) -> Slot:
        if slot_index < 0 or slot_index >= self.header.slot_count:
            raise StorageError(
                f"slot index {slot_index} out of range (have {self.header.slot_count})"
            )
        offset = PAGE_HEADER_SIZE + slot_index * SLOT_FORMAT.size
        slot_off, slot_len = SLOT_FORMAT.unpack_from(self.buf, offset)
        return Slot(offset=slot_off, length=slot_len)


def empty_page(page_id: int) -> HeapPage:
    return HeapPage(page_id=page_id)


def is_invalid(page_id: int) -> bool:
    return page_id == INVALID_PAGE_ID
