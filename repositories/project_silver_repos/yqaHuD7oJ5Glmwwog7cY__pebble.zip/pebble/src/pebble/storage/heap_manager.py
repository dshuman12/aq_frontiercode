from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator

from pebble.buffer.pool import BufferPool, PinnedPage
from pebble.errors import PageFull
from pebble.storage.heap import FreeSpaceMap, HeapFile, TupleId

log = logging.getLogger(__name__)


class HeapManager:
    """Read / write tuples in a heap file via the buffer pool."""

    def __init__(self, heap: HeapFile, pool: BufferPool) -> None:
        self.heap = heap
        self.pool = pool
        self.fsm = FreeSpaceMap()
        self.fsm.rebuild_from(heap)

    def insert(self, payload: bytes) -> TupleId:
        page_id = self.fsm.find_with_space(len(payload) + 4)
        if page_id is None:
            with self.pool.pin_new() as page:
                slot = page.insert(payload)
                self.fsm.update(page.header.page_id, page.free_space())
                page.mark_dirty()
                return TupleId(page.header.page_id, slot)
        with self.pool.pin(page_id) as page:
            try:
                slot = page.insert(payload)
            except PageFull:
                self.fsm.remove(page_id)
                # Retry on a fresh page.
                with self.pool.pin_new() as new_page:
                    slot = new_page.insert(payload)
                    self.fsm.update(new_page.header.page_id, new_page.free_space())
                    new_page.mark_dirty()
                    return TupleId(new_page.header.page_id, slot)
            self.fsm.update(page_id, page.free_space())
            page.mark_dirty()
            return TupleId(page_id, slot)

    def read(self, tid: TupleId) -> bytes:
        with self.pool.pin(tid.page_id) as page:
            return page.read(tid.slot)

    def update(self, tid: TupleId, payload: bytes) -> None:
        """In-place update if the new payload is the same size or smaller.

        For larger payloads, callers should treat update as
        delete + insert and update any indexes accordingly. We expose
        ``update_in_place`` rather than picking the policy here.
        """
        with self.pool.pin(tid.page_id) as page:
            if not page.update_in_place(tid.slot, payload):
                raise PageFull("update would exceed slot length")
            page.mark_dirty()

    def delete(self, tid: TupleId) -> None:
        with self.pool.pin(tid.page_id) as page:
            page.delete(tid.slot)
            self.fsm.update(tid.page_id, page.free_space())
            page.mark_dirty()

    def iter_tuples(self) -> Iterator[tuple[TupleId, bytes]]:
        for page_id in range(self.heap.page_count):
            with self.pool.pin(page_id, ring=True) as page:
                for slot_index, slot in enumerate(page.slots()):
                    if slot.is_empty:
                        continue
                    yield TupleId(page_id, slot_index), page.read(slot_index)

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """Ensure pages are flushed when the block exits cleanly."""
        try:
            yield
        finally:
            self.pool.flush_all()
