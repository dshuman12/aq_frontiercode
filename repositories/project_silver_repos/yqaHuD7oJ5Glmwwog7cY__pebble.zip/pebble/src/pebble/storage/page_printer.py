from __future__ import annotations

from typing import Iterable

from pebble.constants import PAGE_HEADER_SIZE, PAGE_SIZE
from pebble.storage.page import HeapPage, PageHeader


def hex_dump(buf: bytes, *, width: int = 16, max_rows: int = 32) -> str:
    """Render ``buf`` as a hex + ASCII grid."""
    lines: list[str] = []
    for row, offset in enumerate(range(0, len(buf), width)):
        if row >= max_rows:
            lines.append(f"... {len(buf) - offset} more bytes")
            break
        chunk = buf[offset: offset + width]
        hex_part = " ".join(f"{b:02x}" for b in chunk)
        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f"{offset:08x}  {hex_part:<{width * 3}}  {ascii_part}")
    return "\n".join(lines)


def render_page(page: HeapPage) -> str:
    """Long-form description of a page suitable for an error report."""
    h = page.header
    lines = [
        f"page {h.page_id} (kind={h.kind}, version={h.version})",
        f"  lsn         : {h.lsn}",
        f"  slot_count  : {h.slot_count}",
        f"  free_upper  : {h.free_upper}",
        f"  free_space  : {page.free_space()}",
        f"  crc         : 0x{h.crc:08x}",
        "  slots:",
    ]
    for i, slot in enumerate(page.slots()):
        marker = "DELETED" if slot.is_empty else f"{slot.length}b @ {slot.offset}"
        lines.append(f"    [{i:3d}] {marker}")
    lines.append("  body:")
    lines.append(hex_dump(bytes(page.buf[PAGE_HEADER_SIZE: PAGE_HEADER_SIZE + 64])))
    return "\n".join(lines)


def render_summary(pages: Iterable[HeapPage]) -> str:
    """One-line-per-page summary suitable for ``pebble check`` output."""
    out: list[str] = []
    for p in pages:
        live = sum(0 if s.is_empty else 1 for s in p.slots())
        deleted = p.header.slot_count - live
        out.append(
            f"page {p.header.page_id:8d}  kind={p.header.kind}  "
            f"slots={p.header.slot_count:4d}  "
            f"live={live}  deleted={deleted}  free={p.free_space()}"
        )
    return "\n".join(out)
