from __future__ import annotations

import threading
from dataclasses import dataclass


@dataclass
class Sequence:
    name: str
    start: int = 1
    increment: int = 1
    _value: int = 0
    _lock: threading.Lock = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self._value = self.start - self.increment
        self._lock = threading.Lock()

    def next(self) -> int:
        with self._lock:
            self._value += self.increment
            return self._value

    def peek(self) -> int:
        return self._value + self.increment

    def reset(self, *, to: int | None = None) -> None:
        with self._lock:
            self._value = (to if to is not None else self.start) - self.increment

    def reserve(self, count: int) -> tuple[int, int]:
        """Reserve ``count`` consecutive values, return (first, last)."""
        if count <= 0:
            raise ValueError("count must be > 0")
        with self._lock:
            first = self._value + self.increment
            self._value += count * self.increment
            return first, self._value


class SequenceRegistry:
    """Named sequences -- looked up by string name."""

    def __init__(self) -> None:
        self._sequences: dict[str, Sequence] = {}
        self._lock = threading.Lock()

    def get_or_create(self, name: str, *, start: int = 1, increment: int = 1) -> Sequence:
        with self._lock:
            if name not in self._sequences:
                self._sequences[name] = Sequence(name=name, start=start, increment=increment)
            return self._sequences[name]

    def drop(self, name: str) -> None:
        with self._lock:
            self._sequences.pop(name, None)
