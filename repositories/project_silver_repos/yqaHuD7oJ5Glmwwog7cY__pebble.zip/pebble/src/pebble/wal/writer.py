from __future__ import annotations

import io
import logging
import os
import threading
from typing import IO

from pebble.constants import (
    WAL_DEFAULT_SEGMENT_SIZE,
    WAL_MAGIC,
    WAL_REC_BEGIN,
    WAL_REC_COMMIT,
    WAL_REC_ABORT,
    LSN_INVALID,
)
from pebble.errors import CorruptWal
from pebble.wal.record import WalRecord, abort_payload, begin_payload, commit_payload

log = logging.getLogger(__name__)


class WalWriter:
    """Append-only writer rotating across fixed-size segments."""

    def __init__(
        self,
        directory: str,
        *,
        segment_size: int = WAL_DEFAULT_SEGMENT_SIZE,
        fsync: bool = True,
    ) -> None:
        os.makedirs(directory, exist_ok=True)
        self.directory = directory
        self.segment_size = segment_size
        self.fsync_enabled = fsync
        self._lock = threading.Lock()
        self._segment_index = self._latest_segment_index()
        self._fh: IO[bytes] = self._open_segment(self._segment_index, append=True)
        self._lsn = self._compute_initial_lsn()

    def close(self) -> None:
        with self._lock:
            self._fh.flush()
            if self.fsync_enabled:
                os.fsync(self._fh.fileno())
            self._fh.close()

    def append(self, *, type: int, txn_id: int, prev_lsn: int, payload: bytes) -> int:
        """Append a record. Returns the new LSN."""
        with self._lock:
            self._lsn += 1
            record = WalRecord(
                type=type, lsn=self._lsn, prev_lsn=prev_lsn,
                txn_id=txn_id, payload=payload,
            )
            data = record.encode()
            self._maybe_rotate(len(data))
            self._fh.write(data)
            return self._lsn

    def commit(self, txn_id: int, prev_lsn: int) -> int:
        lsn = self.append(type=WAL_REC_COMMIT, txn_id=txn_id,
                          prev_lsn=prev_lsn, payload=commit_payload())
        self.flush()
        return lsn

    def abort(self, txn_id: int, prev_lsn: int) -> int:
        return self.append(type=WAL_REC_ABORT, txn_id=txn_id,
                           prev_lsn=prev_lsn, payload=abort_payload())

    def begin(self, txn_id: int) -> int:
        return self.append(type=WAL_REC_BEGIN, txn_id=txn_id,
                           prev_lsn=LSN_INVALID, payload=begin_payload())

    def flush(self) -> None:
        """Force pending writes to disk -- needed before reporting commit."""
        with self._lock:
            self._fh.flush()
            if self.fsync_enabled:
                os.fsync(self._fh.fileno())

    @property
    def current_lsn(self) -> int:
        return self._lsn

    def _latest_segment_index(self) -> int:
        existing = sorted(
            int(f.split(".")[0]) for f in os.listdir(self.directory)
            if f.endswith(".pblog") and f.split(".")[0].isdigit()
        )
        return existing[-1] if existing else 1

    def _open_segment(self, index: int, *, append: bool) -> IO[bytes]:
        path = self._segment_path(index)
        flags = "ab" if append else "wb"
        if not os.path.exists(path):
            with open(path, "wb") as fh:
                fh.write(WAL_MAGIC)
        fh = open(path, "ab+")
        fh.seek(0, io.SEEK_END)
        return fh

    def _segment_path(self, index: int) -> str:
        return os.path.join(self.directory, f"{index:010d}.pblog")

    def _maybe_rotate(self, incoming_bytes: int) -> None:
        current_size = self._fh.tell()
        if current_size + incoming_bytes <= self.segment_size:
            return
        self._fh.flush()
        if self.fsync_enabled:
            os.fsync(self._fh.fileno())
        self._fh.close()
        self._segment_index += 1
        self._fh = self._open_segment(self._segment_index, append=False)

    def _compute_initial_lsn(self) -> int:
        # Re-read the active segment to find the highest LSN observed.
        path = self._segment_path(self._segment_index)
        try:
            with open(path, "rb") as fh:
                magic = fh.read(len(WAL_MAGIC))
                if magic != WAL_MAGIC:
                    raise CorruptWal(f"bad WAL magic in {path}: {magic!r}")
                last_lsn = LSN_INVALID
                while True:
                    header = fh.read(WalRecord.HEADER_SIZE)
                    if len(header) < WalRecord.HEADER_SIZE:
                        break
                    import struct as _s

                    rec_type, _r, length, lsn, *_ = _s.unpack("<BBIQQQI", header)
                    fh.seek(length - WalRecord.HEADER_SIZE, 1)
                    last_lsn = lsn
                return last_lsn
        except FileNotFoundError:
            return LSN_INVALID
