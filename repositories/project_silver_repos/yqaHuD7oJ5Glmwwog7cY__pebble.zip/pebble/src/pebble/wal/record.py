from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass
from typing import ClassVar

from pebble.constants import (
    WAL_REC_ABORT,
    WAL_REC_BEGIN,
    WAL_REC_BTREE_MERGE,
    WAL_REC_BTREE_SPLIT,
    WAL_REC_CHECKPOINT_BEGIN,
    WAL_REC_CHECKPOINT_END,
    WAL_REC_COMMIT,
    WAL_REC_DELETE,
    WAL_REC_INSERT,
    WAL_REC_PAGE_ALLOC,
    WAL_REC_PAGE_FREE,
    WAL_REC_UPDATE,
)
from pebble.errors import CorruptWal

_HEADER = struct.Struct("<BBIQQQI")  # type, _, length, lsn, prev_lsn, txn_id, crc


@dataclass
class WalRecord:
    type: int
    lsn: int
    prev_lsn: int
    txn_id: int
    payload: bytes

    HEADER_SIZE: ClassVar[int] = _HEADER.size

    def encode(self) -> bytes:
        length = self.HEADER_SIZE + len(self.payload)
        # CRC over everything except the CRC field itself.
        body = struct.pack(
            "<BBIQQQ",
            self.type, 0, length, self.lsn, self.prev_lsn, self.txn_id,
        ) + self.payload
        crc = zlib.crc32(body)
        header = _HEADER.pack(
            self.type, 0, length, self.lsn, self.prev_lsn, self.txn_id, crc,
        )
        return header + self.payload

    @classmethod
    def decode(cls, raw: bytes) -> "WalRecord":
        if len(raw) < cls.HEADER_SIZE:
            raise CorruptWal("record header truncated")
        rec_type, _, length, lsn, prev_lsn, txn_id, crc = _HEADER.unpack_from(raw, 0)
        if length > len(raw):
            raise CorruptWal("record length exceeds buffer")
        payload = bytes(raw[cls.HEADER_SIZE:length])
        body = struct.pack(
            "<BBIQQQ",
            rec_type, 0, length, lsn, prev_lsn, txn_id,
        ) + payload
        if zlib.crc32(body) != crc:
            raise CorruptWal(f"record CRC mismatch at lsn={lsn}")
        return cls(type=rec_type, lsn=lsn, prev_lsn=prev_lsn, txn_id=txn_id, payload=payload)

    @property
    def length(self) -> int:
        return self.HEADER_SIZE + len(self.payload)



def begin_payload() -> bytes:
    return b""


def commit_payload() -> bytes:
    return b""


def abort_payload() -> bytes:
    return b""


def insert_payload(*, page_id: int, slot: int, tuple_bytes: bytes) -> bytes:
    return struct.pack("<IH", page_id, slot) + tuple_bytes


def update_payload(
    *, page_id: int, slot: int, before: bytes, after: bytes
) -> bytes:
    return (
        struct.pack("<IHHH", page_id, slot, len(before), len(after))
        + before
        + after
    )


def delete_payload(*, page_id: int, slot: int, tuple_bytes: bytes) -> bytes:
    return struct.pack("<IHH", page_id, slot, len(tuple_bytes)) + tuple_bytes


def btree_split_payload(*, left_page: int, right_page: int, sep_key: bytes) -> bytes:
    return struct.pack("<IIH", left_page, right_page, len(sep_key)) + sep_key


def btree_merge_payload(*, left_page: int, right_page: int) -> bytes:
    return struct.pack("<II", left_page, right_page)


def page_alloc_payload(page_id: int) -> bytes:
    return struct.pack("<I", page_id)


def page_free_payload(page_id: int) -> bytes:
    return struct.pack("<I", page_id)


def checkpoint_begin_payload(active_txns: list[int]) -> bytes:
    return struct.pack("<H", len(active_txns)) + b"".join(
        t.to_bytes(8, "little") for t in active_txns
    )


def checkpoint_end_payload(min_dirty_lsn: int) -> bytes:
    return struct.pack("<Q", min_dirty_lsn)



def is_terminal(record_type: int) -> bool:
    """Whether the record marks the end of a transaction."""
    return record_type in {WAL_REC_COMMIT, WAL_REC_ABORT}


def describe(record_type: int) -> str:
    return {
        WAL_REC_BEGIN: "begin",
        WAL_REC_COMMIT: "commit",
        WAL_REC_ABORT: "abort",
        WAL_REC_INSERT: "insert",
        WAL_REC_UPDATE: "update",
        WAL_REC_DELETE: "delete",
        WAL_REC_BTREE_SPLIT: "btree_split",
        WAL_REC_BTREE_MERGE: "btree_merge",
        WAL_REC_PAGE_ALLOC: "page_alloc",
        WAL_REC_PAGE_FREE: "page_free",
        WAL_REC_CHECKPOINT_BEGIN: "checkpoint_begin",
        WAL_REC_CHECKPOINT_END: "checkpoint_end",
    }.get(record_type, f"unknown(0x{record_type:02x})")
