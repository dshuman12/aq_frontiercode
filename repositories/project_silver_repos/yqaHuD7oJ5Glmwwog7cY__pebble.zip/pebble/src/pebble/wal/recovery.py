from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Iterator

from pebble.constants import (
    WAL_REC_ABORT,
    WAL_REC_BEGIN,
    WAL_REC_BTREE_SPLIT,
    WAL_REC_CHECKPOINT_BEGIN,
    WAL_REC_CHECKPOINT_END,
    WAL_REC_COMMIT,
    WAL_REC_DELETE,
    WAL_REC_INSERT,
    WAL_REC_UPDATE,
)
from pebble.errors import RecoveryError
from pebble.wal.reader import WalReader
from pebble.wal.record import WalRecord, describe

log = logging.getLogger(__name__)


@dataclass
class RecoveryReport:
    last_checkpoint_lsn: int = 0
    redone_records: int = 0
    undone_txns: int = 0
    active_txns_at_crash: list[int] = field(default_factory=list)
    dirty_pages_at_crash: list[int] = field(default_factory=list)


def recover(
    *,
    wal_reader: WalReader,
    apply_redo,
    apply_undo,
) -> RecoveryReport:
    """Drive the three passes against the supplied WAL.

    ``apply_redo(record)`` is called for each record that needs to be
    re-applied; ``apply_undo(record)`` is called for each loser record
    in reverse LSN order.
    """
    report = RecoveryReport()

    # ----- Analyze ----------------------------------------------------
    att: dict[int, _TxnState] = {}
    dpt: dict[int, int] = {}  # page_id -> recoveryLSN
    last_checkpoint = 0

    records: list[WalRecord] = list(wal_reader.iter_records())
    for rec in records:
        if rec.type == WAL_REC_CHECKPOINT_BEGIN:
            last_checkpoint = rec.lsn
        elif rec.type == WAL_REC_BEGIN:
            att[rec.txn_id] = _TxnState(last_lsn=rec.lsn)
        elif rec.type in {WAL_REC_COMMIT, WAL_REC_ABORT}:
            att.pop(rec.txn_id, None)
        elif rec.type in _DATA_RECORDS:
            page_id = _record_page_id(rec)
            att.setdefault(rec.txn_id, _TxnState(last_lsn=rec.lsn)).last_lsn = rec.lsn
            dpt.setdefault(page_id, rec.lsn)
    report.last_checkpoint_lsn = last_checkpoint
    report.active_txns_at_crash = sorted(att)
    report.dirty_pages_at_crash = sorted(dpt)

    # ----- Redo -------------------------------------------------------
    for rec in records:
        if rec.type in _DATA_RECORDS:
            page_id = _record_page_id(rec)
            if page_id in dpt and rec.lsn >= dpt[page_id]:
                apply_redo(rec)
                report.redone_records += 1

    # ----- Undo -------------------------------------------------------
    for txn_id in sorted(att, reverse=True):
        report.undone_txns += 1
        for rec in _walk_undo_chain(records, txn_id):
            if rec.type in _DATA_RECORDS:
                apply_undo(rec)

    return report



_DATA_RECORDS = {
    WAL_REC_INSERT,
    WAL_REC_UPDATE,
    WAL_REC_DELETE,
    WAL_REC_BTREE_SPLIT,
}


def _record_page_id(rec: WalRecord) -> int:
    if rec.type in {WAL_REC_INSERT, WAL_REC_UPDATE, WAL_REC_DELETE}:
        return int.from_bytes(rec.payload[0:4], "little")
    if rec.type == WAL_REC_BTREE_SPLIT:
        return int.from_bytes(rec.payload[0:4], "little")
    raise RecoveryError(f"unhandled record type for page lookup: {describe(rec.type)}")


def _walk_undo_chain(records: list[WalRecord], txn_id: int) -> Iterator[WalRecord]:
    """Yield records belonging to ``txn_id`` in reverse LSN order."""
    chain = [r for r in records if r.txn_id == txn_id]
    for r in reversed(chain):
        yield r


@dataclass
class _TxnState:
    last_lsn: int = 0
