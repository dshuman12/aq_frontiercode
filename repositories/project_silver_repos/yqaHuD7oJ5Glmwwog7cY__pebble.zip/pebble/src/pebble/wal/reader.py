from __future__ import annotations

import io
import os
from typing import Iterator

from pebble.constants import WAL_MAGIC
from pebble.errors import CorruptWal
from pebble.wal.record import WalRecord


class WalReader:
    """Iterate records in append order across all segments in a directory."""

    def __init__(self, directory: str) -> None:
        self.directory = directory

    def iter_records(self) -> Iterator[WalRecord]:
        for segment in self._segments():
            yield from self._iter_segment(segment)

    def last_lsn(self) -> int:
        last = 0
        for record in self.iter_records():
            last = record.lsn
        return last

    def _segments(self) -> list[str]:
        out: list[str] = []
        for name in sorted(os.listdir(self.directory)):
            if name.endswith(".pblog") and name.split(".")[0].isdigit():
                out.append(os.path.join(self.directory, name))
        return out

    def _iter_segment(self, path: str) -> Iterator[WalRecord]:
        with open(path, "rb") as fh:
            magic = fh.read(len(WAL_MAGIC))
            if magic != WAL_MAGIC:
                raise CorruptWal(f"bad WAL magic in {path}: {magic!r}")
            while True:
                header = fh.read(WalRecord.HEADER_SIZE)
                if not header:
                    return
                if len(header) < WalRecord.HEADER_SIZE:
                    raise CorruptWal(f"trailing garbage in {path}")
                import struct as _s

                _t, _r, length, *_ = _s.unpack("<BBIQQQI", header)
                payload = fh.read(length - WalRecord.HEADER_SIZE)
                if len(payload) != length - WalRecord.HEADER_SIZE:
                    raise CorruptWal(f"truncated record in {path}")
                yield WalRecord.decode(header + payload)
