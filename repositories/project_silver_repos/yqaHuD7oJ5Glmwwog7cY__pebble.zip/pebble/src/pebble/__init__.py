from __future__ import annotations

__version__ = "0.1.0"


def connect(data_dir: str, *, readonly: bool = False) -> "object":
    """Open a database connection backed by ``data_dir``."""
    # Imported lazily so ``import pebble`` does not pay the price of the
    # storage layer for callers that only want the version string.
    from pebble.server.embedded import open_embedded

    return open_embedded(data_dir, readonly=readonly)


__all__ = ["__version__", "connect"]
