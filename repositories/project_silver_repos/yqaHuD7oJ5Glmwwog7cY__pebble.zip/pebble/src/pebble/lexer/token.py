from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Final


class TokenKind(enum.Enum):
    INT = "int"
    FLOAT = "float"
    STRING = "string"
    BLOB = "blob"
    IDENT = "ident"
    QUOTED_IDENT = "quoted_ident"

    # All keywords share a single kind; the text disambiguates.
    KEYWORD = "keyword"

    LPAREN = "("
    RPAREN = ")"
    COMMA = ","
    SEMICOLON = ";"
    DOT = "."
    STAR = "*"

    PLUS = "+"
    MINUS = "-"
    SLASH = "/"
    PERCENT = "%"
    EQ = "="
    NE = "<>"
    LT = "<"
    LE = "<="
    GT = ">"
    GE = ">="
    CONCAT = "||"

    EOF = "eof"


@dataclass(frozen=True)
class Token:
    kind: TokenKind
    text: str
    position: int          # byte offset into the source
    line: int
    column: int

    def is_keyword(self, *names: str) -> bool:
        if self.kind != TokenKind.KEYWORD:
            return False
        return self.text.upper() in {n.upper() for n in names}

    def __repr__(self) -> str:
        return f"Token({self.kind.name}, {self.text!r}, line={self.line}, col={self.column})"


KEYWORDS: Final[frozenset[str]] = frozenset(
    {
        "ABORT", "ALL", "ALTER", "AND", "ANALYZE", "AS", "ASC", "BEGIN", "BETWEEN",
        "BLOB", "BOOL", "BOOLEAN", "BY", "CASE", "CAST", "CHAR", "CHECK", "COLUMN",
        "COMMIT", "CONSTRAINT", "CREATE", "CROSS", "DATE", "DECIMAL", "DEFAULT",
        "DELETE", "DESC", "DISTINCT", "DOUBLE", "DROP", "ELSE", "END", "ESCAPE",
        "EXCEPT", "EXISTS", "EXPLAIN", "FALSE", "FLOAT", "FOREIGN", "FROM", "FULL",
        "GROUP", "HAVING", "IF", "IN", "INDEX", "INNER", "INSERT", "INT", "INTEGER",
        "INTERSECT", "INTO", "IS", "ISOLATION", "JOIN", "KEY", "LEFT", "LIKE",
        "LIMIT", "NOT", "NULL", "OFFSET", "ON", "OR", "ORDER", "OUTER", "PRIMARY",
        "REAL", "RECURSIVE", "REFERENCES", "RIGHT", "ROLLBACK", "SAVEPOINT",
        "SELECT", "SET", "SOME", "TABLE", "TEXT", "THEN", "TIMESTAMP", "TO",
        "TRUE", "UNION", "UNIQUE", "UPDATE", "USING", "VACUUM", "VALUES", "VARCHAR",
        "VIEW", "WHEN", "WHERE", "WITH",
    }
)


def is_keyword(text: str) -> bool:
    return text.upper() in KEYWORDS
