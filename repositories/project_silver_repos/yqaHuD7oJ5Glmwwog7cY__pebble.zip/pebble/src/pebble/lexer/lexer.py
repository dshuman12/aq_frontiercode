from __future__ import annotations

from typing import Iterator

from pebble.errors import LexerError
from pebble.lexer.token import KEYWORDS, Token, TokenKind, is_keyword


class Lexer:
    """A pull-based lexer."""

    def __init__(self, source: str) -> None:
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1

    def tokenize(self) -> list[Token]:
        return list(iter(self))

    def __iter__(self) -> Iterator[Token]:
        while True:
            tok = self._next_token()
            yield tok
            if tok.kind == TokenKind.EOF:
                return

    def _next_token(self) -> Token:
        self._skip_trivia()
        start = self.pos
        line, column = self.line, self.column
        if self.pos >= len(self.source):
            return Token(TokenKind.EOF, "", start, line, column)
        ch = self.source[self.pos]
        if ch.isalpha() or ch == "_":
            return self._read_identifier(start, line, column)
        if ch == '"':
            return self._read_quoted_ident(start, line, column)
        if ch.isdigit() or (ch == "." and self._peek(1).isdigit()):
            return self._read_number(start, line, column)
        if ch == "'":
            return self._read_string(start, line, column)
        if ch in {"x", "X"} and self._peek(1) == "'":
            return self._read_blob(start, line, column)
        return self._read_operator(start, line, column)

    def _skip_trivia(self) -> None:
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch in " \t\r":
                self._advance()
            elif ch == "\n":
                self._advance()
            elif ch == "-" and self._peek(1) == "-":
                # Line comment
                while self.pos < len(self.source) and self.source[self.pos] != "\n":
                    self._advance()
            elif ch == "/" and self._peek(1) == "*":
                # Block comment is non-nesting per SQL spec.
                self._advance(); self._advance()
                while self.pos < len(self.source):
                    if self.source[self.pos] == "*" and self._peek(1) == "/":
                        self._advance(); self._advance()
                        break
                    self._advance()
                else:
                    raise LexerError(
                        "unterminated block comment", position=self.pos
                    )
            else:
                return

    def _read_identifier(self, start: int, line: int, column: int) -> Token:
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch.isalnum() or ch == "_":
                self._advance()
            else:
                break
        text = self.source[start: self.pos]
        if is_keyword(text):
            return Token(TokenKind.KEYWORD, text, start, line, column)
        return Token(TokenKind.IDENT, text, start, line, column)

    def _read_quoted_ident(self, start: int, line: int, column: int) -> Token:
        self._advance()  # opening "
        chars: list[str] = []
        while True:
            if self.pos >= len(self.source):
                raise LexerError("unterminated quoted identifier", position=start)
            ch = self.source[self.pos]
            if ch == '"':
                if self._peek(1) == '"':
                    chars.append('"')
                    self._advance(); self._advance()
                    continue
                self._advance()  # closing "
                break
            chars.append(ch)
            self._advance()
        text = "".join(chars)
        return Token(TokenKind.QUOTED_IDENT, text, start, line, column)

    def _read_number(self, start: int, line: int, column: int) -> Token:
        seen_dot = False
        seen_exp = False
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch.isdigit():
                self._advance()
                continue
            if ch == "." and not seen_dot and not seen_exp:
                seen_dot = True
                self._advance()
                continue
            if ch in {"e", "E"} and not seen_exp:
                seen_exp = True
                self._advance()
                if self.pos < len(self.source) and self.source[self.pos] in "+-":
                    self._advance()
                continue
            break
        text = self.source[start: self.pos]
        if seen_dot or seen_exp:
            return Token(TokenKind.FLOAT, text, start, line, column)
        return Token(TokenKind.INT, text, start, line, column)

    def _read_string(self, start: int, line: int, column: int) -> Token:
        self._advance()  # opening '
        chars: list[str] = []
        while True:
            if self.pos >= len(self.source):
                raise LexerError("unterminated string literal", position=start)
            ch = self.source[self.pos]
            if ch == "'":
                if self._peek(1) == "'":
                    chars.append("'")
                    self._advance(); self._advance()
                    continue
                self._advance()
                break
            chars.append(ch)
            self._advance()
        return Token(TokenKind.STRING, "".join(chars), start, line, column)

    def _read_blob(self, start: int, line: int, column: int) -> Token:
        self._advance()  # x or X
        self._advance()  # opening '
        chars: list[str] = []
        while True:
            if self.pos >= len(self.source):
                raise LexerError("unterminated blob literal", position=start)
            ch = self.source[self.pos]
            if ch == "'":
                self._advance()
                break
            if ch not in "0123456789abcdefABCDEF":
                raise LexerError(f"invalid hex digit {ch!r} in blob literal",
                                 position=self.pos)
            chars.append(ch)
            self._advance()
        if len(chars) % 2 != 0:
            raise LexerError("blob literal has odd number of hex digits", position=start)
        return Token(TokenKind.BLOB, "".join(chars), start, line, column)

    def _read_operator(self, start: int, line: int, column: int) -> Token:
        ch = self.source[self.pos]
        # Match two-character operators before single-character ones.
        two = self.source[self.pos: self.pos + 2]
        if two == "<=":
            self._advance(); self._advance()
            return Token(TokenKind.LE, two, start, line, column)
        if two == ">=":
            self._advance(); self._advance()
            return Token(TokenKind.GE, two, start, line, column)
        if two == "<>":
            self._advance(); self._advance()
            return Token(TokenKind.NE, two, start, line, column)
        if two == "!=":
            self._advance(); self._advance()
            return Token(TokenKind.NE, two, start, line, column)
        if two == "||":
            self._advance(); self._advance()
            return Token(TokenKind.CONCAT, two, start, line, column)
        single = {
            "(": TokenKind.LPAREN,
            ")": TokenKind.RPAREN,
            ",": TokenKind.COMMA,
            ";": TokenKind.SEMICOLON,
            ".": TokenKind.DOT,
            "*": TokenKind.STAR,
            "+": TokenKind.PLUS,
            "-": TokenKind.MINUS,
            "/": TokenKind.SLASH,
            "%": TokenKind.PERCENT,
            "=": TokenKind.EQ,
            "<": TokenKind.LT,
            ">": TokenKind.GT,
        }
        if ch in single:
            self._advance()
            return Token(single[ch], ch, start, line, column)
        raise LexerError(f"unexpected character {ch!r}", position=start)

    def _advance(self) -> None:
        if self.pos >= len(self.source):
            return
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1

    def _peek(self, offset: int) -> str:
        idx = self.pos + offset
        if 0 <= idx < len(self.source):
            return self.source[idx]
        return ""


def tokenize(source: str) -> list[Token]:
    return Lexer(source).tokenize()
