from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Final

from pebble.constants import DEFAULT_LOCK_TIMEOUT_MS
from pebble.errors import DeadlockDetected, LockTimeout

log = logging.getLogger(__name__)


# Lock modes encoded as ints so we can index into the matrix.
LOCK_S: Final[int] = 0
LOCK_X: Final[int] = 1
LOCK_IS: Final[int] = 2
LOCK_IX: Final[int] = 3
LOCK_SIX: Final[int] = 4

_LOCK_NAMES = {
    LOCK_S: "S", LOCK_X: "X", LOCK_IS: "IS", LOCK_IX: "IX", LOCK_SIX: "SIX",
}

_COMPAT: list[list[bool]] = [
    # rows: holder, columns: requestor
    # S    X     IS    IX    SIX
    [True,  False, True,  False, False],  # S
    [False, False, False, False, False],  # X
    [True,  False, True,  True,  True ],  # IS
    [False, False, True,  True,  False],  # IX
    [False, False, True,  False, False],  # SIX
]


def is_compatible(holder: int, requestor: int) -> bool:
    return _COMPAT[holder][requestor]


@dataclass
class _LockRequest:
    txn_id: int
    mode: int
    granted: bool = False
    event: threading.Event = field(default_factory=threading.Event)


@dataclass
class _LockEntry:
    granted: list[_LockRequest] = field(default_factory=list)
    waiters: list[_LockRequest] = field(default_factory=list)


class LockManager:
    """Single in-memory lock table keyed by ``(table, key)``.

    ``key`` is opaque -- callers pass a TID, a row id, or ``None`` for
    table-level locks.
    """

    def __init__(self, *, timeout_ms: int = DEFAULT_LOCK_TIMEOUT_MS) -> None:
        self._timeout = timeout_ms / 1000.0
        self._lock = threading.RLock()
        self._table: dict[tuple[str, object], _LockEntry] = {}
        self._waits_for: dict[int, set[int]] = {}

    def acquire(self, txn_id: int, table: str, key: object, mode: int) -> None:
        request = _LockRequest(txn_id=txn_id, mode=mode)
        with self._lock:
            entry = self._table.setdefault((table, key), _LockEntry())
            if self._can_grant_locked(entry, request):
                request.granted = True
                entry.granted.append(request)
                return
            entry.waiters.append(request)
            self._update_waits_for_locked(request, entry)
            if self._has_cycle_locked(txn_id):
                entry.waiters.remove(request)
                self._waits_for.pop(txn_id, None)
                raise DeadlockDetected(
                    f"deadlock detected acquiring {_LOCK_NAMES[mode]} on {table}/{key!r}"
                )
        # Wait outside the lock.
        if not request.event.wait(self._timeout):
            with self._lock:
                # Failed to acquire in time -- remove ourselves from waiters.
                entry = self._table.get((table, key))
                if entry and request in entry.waiters:
                    entry.waiters.remove(request)
                self._waits_for.pop(txn_id, None)
            raise LockTimeout(
                f"timed out waiting for {_LOCK_NAMES[mode]} on {table}/{key!r}",
                context={"txn_id": txn_id},
            )

    def release_all(self, txn_id: int) -> None:
        with self._lock:
            for (key, entry) in list(self._table.items()):
                kept = [r for r in entry.granted if r.txn_id != txn_id]
                if len(kept) != len(entry.granted):
                    entry.granted = kept
                    self._wake_waiters_locked(entry)
                if not entry.granted and not entry.waiters:
                    self._table.pop(key, None)
            self._waits_for.pop(txn_id, None)
            for waiters in self._waits_for.values():
                waiters.discard(txn_id)

    def _can_grant_locked(self, entry: _LockEntry, req: _LockRequest) -> bool:
        for held in entry.granted:
            if held.txn_id == req.txn_id:
                continue  # ignore self
            if not is_compatible(held.mode, req.mode):
                return False
        return True

    def _update_waits_for_locked(self, req: _LockRequest, entry: _LockEntry) -> None:
        for held in entry.granted:
            if held.txn_id == req.txn_id:
                continue
            self._waits_for.setdefault(req.txn_id, set()).add(held.txn_id)

    def _has_cycle_locked(self, start: int) -> bool:
        seen: set[int] = set()
        stack = [start]
        while stack:
            cur = stack.pop()
            if cur in seen:
                if cur == start:
                    return True
                continue
            seen.add(cur)
            stack.extend(self._waits_for.get(cur, ()))
        return False

    def _wake_waiters_locked(self, entry: _LockEntry) -> None:
        promoted: list[_LockRequest] = []
        for waiter in entry.waiters:
            if self._can_grant_locked(entry, waiter):
                waiter.granted = True
                promoted.append(waiter)
                entry.granted.append(waiter)
        for w in promoted:
            entry.waiters.remove(w)
            self._waits_for.pop(w.txn_id, None)
            w.event.set()
