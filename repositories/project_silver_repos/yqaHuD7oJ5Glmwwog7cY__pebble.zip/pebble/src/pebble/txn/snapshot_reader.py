from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from pebble.txn.manager import Snapshot, TxnState


@dataclass(frozen=True)
class TupleVisibility:
    """Per-tuple visibility metadata fetched from the heap layer."""

    xmin: int
    xmax: int

    def is_visible(self, snapshot: Snapshot) -> bool:
        return snapshot.is_visible(xmin=self.xmin, xmax=self.xmax)


def filter_visible(
    items: Iterable[tuple[TupleVisibility, object]],
    *,
    snapshot: Snapshot,
) -> list[object]:
    """Return only the payloads whose visibility passes the snapshot test."""
    return [payload for vis, payload in items if vis.is_visible(snapshot)]


def is_self_writable(state: TxnState, vis: TupleVisibility) -> bool:
    """Whether the current txn may write over this tuple.

    Required by UPDATE: a tuple is writable iff it is visible to our
    snapshot AND no other transaction has it under modification.
    """
    if not state.snapshot:
        return False
    if vis.xmax != 0 and vis.xmax != state.txn_id:
        return False
    return vis.is_visible(state.snapshot)
