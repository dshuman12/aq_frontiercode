from __future__ import annotations

import itertools
import logging
import threading
from dataclasses import dataclass, field
from typing import Iterable

from pebble.constants import (
    BOOTSTRAP_TXN_ID,
    FIRST_NORMAL_TXN_ID,
    INVALID_TXN_ID,
)
from pebble.errors import IsolationViolation, SerializationFailure, TransactionAborted

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Snapshot:
    """A point-in-time view of the visible txn ids."""

    xmin_horizon: int
    xmax_horizon: int
    active_txns: frozenset[int]

    def is_visible(self, *, xmin: int, xmax: int) -> bool:
        if xmin == INVALID_TXN_ID:
            return False
        if xmin >= self.xmax_horizon:
            return False
        if xmin in self.active_txns:
            return False
        if xmax == INVALID_TXN_ID:
            return True
        if xmax >= self.xmax_horizon:
            return True
        if xmax in self.active_txns:
            return True
        return False


@dataclass
class TxnState:
    txn_id: int
    isolation: str
    snapshot: Snapshot | None = None
    last_lsn: int = 0
    aborted: bool = False
    read_set: set[tuple[int, int]] = field(default_factory=set)
    write_set: set[tuple[int, int]] = field(default_factory=set)


class TxnManager:
    """Issues transaction ids, tracks active txns, computes snapshots."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._next_id = itertools.count(FIRST_NORMAL_TXN_ID)
        self._active: dict[int, TxnState] = {}
        self._committed: set[int] = set()
        # Watermarks updated lazily to avoid recomputing each begin.
        self._oldest_active: int = INVALID_TXN_ID

    def begin(self, *, isolation: str = "snapshot") -> TxnState:
        if isolation not in {"read_committed", "snapshot", "repeatable_read", "serializable"}:
            raise IsolationViolation(f"unknown isolation level: {isolation!r}")
        with self._lock:
            txn_id = next(self._next_id)
            state = TxnState(txn_id=txn_id, isolation=isolation)
            state.snapshot = self._build_snapshot_locked()
            self._active[txn_id] = state
            self._oldest_active = min(self._active)
            return state

    def commit(self, state: TxnState) -> None:
        with self._lock:
            if state.aborted:
                raise TransactionAborted(f"txn {state.txn_id} already aborted")
            self._active.pop(state.txn_id, None)
            self._committed.add(state.txn_id)
            self._refresh_oldest_active_locked()

    def abort(self, state: TxnState) -> None:
        with self._lock:
            self._active.pop(state.txn_id, None)
            state.aborted = True
            self._refresh_oldest_active_locked()

    def refresh_snapshot(self, state: TxnState) -> Snapshot:
        if state.isolation == "read_committed":
            with self._lock:
                state.snapshot = self._build_snapshot_locked()
        assert state.snapshot is not None
        return state.snapshot

    def is_visible(self, state: TxnState, *, xmin: int, xmax: int) -> bool:
        if state.isolation == "read_committed":
            with self._lock:
                snap = self._build_snapshot_locked()
        else:
            assert state.snapshot is not None
            snap = state.snapshot
        return snap.is_visible(xmin=xmin, xmax=xmax)

    def detect_write_conflict(
        self, state: TxnState, *, xmin: int, xmax: int
    ) -> None:
        """Raise ``SerializationFailure`` on a w/w conflict.

        We treat any ``xmax == 0`` row whose ``xmin`` is invisible to the
        snapshot as a conflict if the writer is not the same as us.
        """
        with self._lock:
            if xmin in self._active and xmin != state.txn_id:
                raise SerializationFailure(
                    f"write/write conflict with active txn {xmin}",
                    context={"snapshot_xmin": state.snapshot.xmin_horizon
                             if state.snapshot else None},
                )

    def record_read(self, state: TxnState, page_id: int, slot: int) -> None:
        state.read_set.add((page_id, slot))

    def record_write(self, state: TxnState, page_id: int, slot: int) -> None:
        state.write_set.add((page_id, slot))

    def active_count(self) -> int:
        with self._lock:
            return len(self._active)

    def active_txn_ids(self) -> list[int]:
        with self._lock:
            return sorted(self._active)

    def oldest_active_txn(self) -> int:
        return self._oldest_active

    def _build_snapshot_locked(self) -> Snapshot:
        active_set = frozenset(self._active)
        xmax = next(self._peek_next_id())
        xmin = min(active_set, default=xmax)
        return Snapshot(
            xmin_horizon=xmin,
            xmax_horizon=xmax,
            active_txns=active_set,
        )

    def _peek_next_id(self) -> Iterable[int]:
        # Peek at counter without advancing it. ``itertools.count`` is
        # not peekable; we rebuild a one-shot iterator. Caller takes
        # only the first element.
        cursor = itertools.tee(self._next_id, 2)
        self._next_id = cursor[1]
        return cursor[0]

    def _refresh_oldest_active_locked(self) -> None:
        self._oldest_active = (
            min(self._active) if self._active else INVALID_TXN_ID
        )


# Sentinel used by storage code that needs to bootstrap a database
# before the txn manager exists (e.g. catalog seeding).
BOOTSTRAP_STATE: TxnState = TxnState(txn_id=BOOTSTRAP_TXN_ID, isolation="snapshot")
