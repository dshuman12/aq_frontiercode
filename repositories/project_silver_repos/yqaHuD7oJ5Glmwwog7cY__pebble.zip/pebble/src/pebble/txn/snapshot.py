from __future__ import annotations

from typing import Iterable

from pebble.constants import FIRST_NORMAL_TXN_ID
from pebble.txn.manager import Snapshot


def empty() -> Snapshot:
    return Snapshot(
        xmin_horizon=FIRST_NORMAL_TXN_ID,
        xmax_horizon=FIRST_NORMAL_TXN_ID,
        active_txns=frozenset(),
    )


def for_committed_only(min_committed: int, max_committed: int) -> Snapshot:
    """Snapshot that sees every committed txn in the inclusive range."""
    return Snapshot(
        xmin_horizon=min_committed,
        xmax_horizon=max_committed + 1,
        active_txns=frozenset(),
    )


def with_active(active: Iterable[int], horizon: int) -> Snapshot:
    actives = frozenset(active)
    return Snapshot(
        xmin_horizon=min(actives, default=horizon),
        xmax_horizon=horizon,
        active_txns=actives,
    )
