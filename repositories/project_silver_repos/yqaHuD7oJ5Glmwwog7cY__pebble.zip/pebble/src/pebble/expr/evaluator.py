from __future__ import annotations

import re
from typing import Any, Mapping

from pebble.errors import ExecutionError, TypeMismatch
from pebble.parser import ast as A
from pebble.types import value as V
from pebble.types.value import Value


class Evaluator:
    def __init__(self, *, params: Mapping[str, Value] | None = None) -> None:
        self.params = dict(params or {})

    def evaluate(self, expr: A.Expr, row: Mapping[str, Value]) -> Value:
        return self._dispatch(expr, row)

    def _dispatch(self, expr: A.Expr, row: Mapping[str, Value]) -> Value:
        if isinstance(expr, A.Literal):
            return Value.of(expr.value)
        if isinstance(expr, A.NullLiteral):
            return Value.null()
        if isinstance(expr, A.BoolLiteral):
            return Value.of(expr.value)
        if isinstance(expr, A.ColumnRef):
            return self._column_ref(expr, row)
        if isinstance(expr, A.BinaryOp):
            return self._binary(expr, row)
        if isinstance(expr, A.UnaryOp):
            return self._unary(expr, row)
        if isinstance(expr, A.IsNull):
            inner = self._dispatch(expr.expr, row)
            result = inner.is_null
            return Value.of(not result if expr.negated else result)
        if isinstance(expr, A.Between):
            return self._between(expr, row)
        if isinstance(expr, A.InList):
            return self._in_list(expr, row)
        if isinstance(expr, A.Like):
            return self._like(expr, row)
        if isinstance(expr, A.Case):
            return self._case(expr, row)
        if isinstance(expr, A.FunctionCall):
            return self._function(expr, row)
        if isinstance(expr, A.Cast):
            inner = self._dispatch(expr.expr, row)
            return _cast(inner, expr.target_type)
        raise ExecutionError(f"unsupported expression node: {type(expr).__name__}")

    def _column_ref(self, expr: A.ColumnRef, row: Mapping[str, Value]) -> Value:
        key = expr.name
        if expr.table:
            qualified = f"{expr.table}.{expr.name}"
            if qualified in row:
                return row[qualified]
        if key in row:
            return row[key]
        raise ExecutionError(f"column {key!r} not in row", context={"available": list(row)})

    def _binary(self, expr: A.BinaryOp, row: Mapping[str, Value]) -> Value:
        left = self._dispatch(expr.left, row)
        right = self._dispatch(expr.right, row)
        op = expr.op
        if op == "+":
            return V.add(left, right)
        if op == "-":
            return V.sub(left, right)
        if op == "*":
            return V.mul(left, right)
        if op == "/":
            return V.div(left, right)
        if op == "||":
            if left.is_null or right.is_null:
                return Value.null()
            return Value.of(str(left.payload) + str(right.payload))
        if op == "and":
            return V.boolean_and(left, right)
        if op == "or":
            return V.boolean_or(left, right)
        if op in {"=", "<>", "<", "<=", ">", ">="}:
            return _comparison(op, left, right)
        raise ExecutionError(f"unsupported binary operator: {op}")

    def _unary(self, expr: A.UnaryOp, row: Mapping[str, Value]) -> Value:
        operand = self._dispatch(expr.operand, row)
        if expr.op == "-":
            return V.neg(operand)
        if expr.op == "not":
            return V.boolean_not(operand)
        raise ExecutionError(f"unsupported unary operator: {expr.op}")

    def _between(self, expr: A.Between, row: Mapping[str, Value]) -> Value:
        target = self._dispatch(expr.expr, row)
        low = self._dispatch(expr.low, row)
        high = self._dispatch(expr.high, row)
        if target.is_null or low.is_null or high.is_null:
            return Value.null()
        result = (target.cmp(low) is not None and target.cmp(low) >= 0
                  and target.cmp(high) is not None and target.cmp(high) <= 0)
        return Value.of(not result if expr.negated else result)

    def _in_list(self, expr: A.InList, row: Mapping[str, Value]) -> Value:
        target = self._dispatch(expr.expr, row)
        if target.is_null:
            return Value.null()
        any_null = False
        for v in expr.values:
            candidate = self._dispatch(v, row)
            if candidate.is_null:
                any_null = True
                continue
            cmp = target.cmp(candidate)
            if cmp == 0:
                return Value.of(not False if expr.negated else True)
        if any_null:
            return Value.null()
        return Value.of(expr.negated)

    def _like(self, expr: A.Like, row: Mapping[str, Value]) -> Value:
        target = self._dispatch(expr.expr, row)
        pattern = self._dispatch(expr.pattern, row)
        if target.is_null or pattern.is_null:
            return Value.null()
        regex = _like_to_regex(pattern.payload)
        return Value.of(bool(regex.match(target.payload)) ^ expr.negated)

    def _case(self, expr: A.Case, row: Mapping[str, Value]) -> Value:
        operand_value = self._dispatch(expr.operand, row) if expr.operand else None
        for cond, result in expr.when_clauses:
            cond_v = self._dispatch(cond, row)
            if operand_value is not None:
                if cond_v.cmp(operand_value) == 0:
                    return self._dispatch(result, row)
            elif cond_v.is_true:
                return self._dispatch(result, row)
        if expr.else_clause is not None:
            return self._dispatch(expr.else_clause, row)
        return Value.null()

    def _function(self, expr: A.FunctionCall, row: Mapping[str, Value]) -> Value:
        name = expr.name.upper()
        args = [self._dispatch(a, row) for a in expr.args]
        if name == "COALESCE":
            for v in args:
                if not v.is_null:
                    return v
            return Value.null()
        if name == "NULLIF":
            if len(args) != 2:
                raise ExecutionError("NULLIF takes exactly 2 arguments")
            if args[0].cmp(args[1]) == 0:
                return Value.null()
            return args[0]
        if name == "ABS":
            if args[0].is_null:
                return Value.null()
            return Value.of(abs(args[0].payload))
        if name == "LENGTH":
            if args[0].is_null:
                return Value.null()
            return Value.of(len(args[0].payload))
        if name == "LOWER":
            if args[0].is_null:
                return Value.null()
            return Value.of(args[0].payload.lower())
        if name == "UPPER":
            if args[0].is_null:
                return Value.null()
            return Value.of(args[0].payload.upper())
        if name == "SUBSTR":
            if len(args) < 2:
                raise ExecutionError("SUBSTR takes at least 2 arguments")
            s = args[0].payload
            start = int(args[1].payload) - 1  # SQL is 1-indexed
            if len(args) >= 3:
                length = int(args[2].payload)
                return Value.of(s[start: start + length])
            return Value.of(s[start:])
        raise ExecutionError(f"unknown function: {name}")



def _comparison(op: str, left: Value, right: Value) -> Value:
    cmp = left.cmp(right)
    if cmp is None:
        return Value.null()
    if op == "=":
        return Value.of(cmp == 0)
    if op == "<>":
        return Value.of(cmp != 0)
    if op == "<":
        return Value.of(cmp < 0)
    if op == "<=":
        return Value.of(cmp <= 0)
    if op == ">":
        return Value.of(cmp > 0)
    if op == ">=":
        return Value.of(cmp >= 0)
    raise ExecutionError(f"unsupported comparison operator: {op}")


def _like_to_regex(pattern: str) -> "re.Pattern[str]":
    out = ["^"]
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "%":
            out.append(".*")
        elif ch == "_":
            out.append(".")
        elif ch in r".^$*+?{}|()[]\\":
            out.append("\\" + ch)
        else:
            out.append(ch)
        i += 1
    out.append("$")
    return re.compile("".join(out), re.DOTALL)


def _cast(value: Value, target: str) -> Value:
    if value.is_null:
        return Value.null()
    name = target.upper()
    if name in {"INT", "INTEGER", "BIGINT"}:
        return Value.of(int(value.payload))
    if name in {"DOUBLE", "FLOAT", "REAL"}:
        return Value.of(float(value.payload))
    if name in {"TEXT", "VARCHAR", "STRING"}:
        return Value.of(str(value.payload))
    if name in {"BOOL", "BOOLEAN"}:
        return Value.of(bool(value.payload))
    raise TypeMismatch(f"cannot cast to {target!r}")
