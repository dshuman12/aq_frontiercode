from __future__ import annotations

import os

import click

from pebble.errors import CorruptPage, CorruptWal
from pebble.storage.heap import HeapFile
from pebble.wal.reader import WalReader


@click.command()
@click.option("--data", "data_dir", default="./pebble_data", show_default=True)
def check(data_dir: str) -> None:
    """Validate every page CRC and walk the WAL end-to-end."""
    heaps_dir = os.path.join(data_dir, "heaps")
    wal_dir = os.path.join(data_dir, "wal")
    errors: list[str] = []
    if os.path.isdir(heaps_dir):
        for name in sorted(os.listdir(heaps_dir)):
            path = os.path.join(heaps_dir, name)
            try:
                with HeapFile(path, readonly=True) as heap:
                    for page in heap.iter_pages():
                        if page.header.slot_count > 4096:
                            errors.append(f"{name}/{page.header.page_id}: implausible slot count")
            except CorruptPage as exc:
                errors.append(f"{name}: {exc}")
    if os.path.isdir(wal_dir):
        try:
            count = 0
            for _ in WalReader(wal_dir).iter_records():
                count += 1
            click.echo(f"WAL OK ({count} records)")
        except CorruptWal as exc:
            errors.append(f"WAL: {exc}")
    if errors:
        for e in errors:
            click.echo(f"ERROR: {e}")
        raise click.exceptions.Exit(1)
    click.echo("check passed.")
