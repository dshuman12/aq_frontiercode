from __future__ import annotations

import click

from pebble.config import get_config
from pebble.server.engine import Engine
from pebble.server.tcp import TcpServer


@click.command()
@click.option("--host", default=None)
@click.option("--port", type=int, default=None)
def serve(host: str | None, port: int | None) -> None:
    """Start the network server."""
    cfg = get_config()
    if host or port:
        overrides: dict = {}
        if host:
            overrides["host"] = host
        if port:
            overrides["port"] = port
        cfg = cfg.with_overrides(server=overrides)
    engine = Engine(config=cfg)
    engine.open()
    server = TcpServer(engine=engine, config=cfg)
    try:
        server.serve_forever()
    finally:
        server.stop()
        engine.close()
