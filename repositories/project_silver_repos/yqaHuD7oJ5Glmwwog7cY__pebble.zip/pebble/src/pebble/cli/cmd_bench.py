from __future__ import annotations

import time

import click

from pebble.server.embedded import open_embedded


@click.command()
@click.option("--data", "data_dir", default="./pebble_data", show_default=True)
@click.option("--rows", default=10_000, show_default=True)
def bench(data_dir: str, rows: int) -> None:
    """Time INSERT and SELECT round-trips."""
    conn = open_embedded(data_dir)
    try:
        conn.execute("DROP TABLE IF EXISTS bench_t")
        conn.execute(
            "CREATE TABLE bench_t (id INT PRIMARY KEY, payload TEXT)"
        )
        start = time.monotonic()
        for i in range(rows):
            conn.execute(f"INSERT INTO bench_t VALUES ({i}, 'r{i}')")
        insert_elapsed = time.monotonic() - start
        click.echo(
            f"insert {rows} rows: {insert_elapsed:.3f}s "
            f"({rows / insert_elapsed:,.0f} rows/s)"
        )
        start = time.monotonic()
        result = conn.execute("SELECT COUNT(*) FROM bench_t")
        click.echo(
            f"count(*): {result.rows[0][0].payload} in "
            f"{(time.monotonic() - start) * 1000:.2f}ms"
        )
    finally:
        conn.close()
