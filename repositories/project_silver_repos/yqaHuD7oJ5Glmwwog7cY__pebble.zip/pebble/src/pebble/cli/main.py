from __future__ import annotations

import logging
import os

import click

from pebble import __version__
from pebble.cli.cmd_repl import repl as _repl
from pebble.cli.cmd_dump import dump as _dump
from pebble.cli.cmd_check import check as _check
from pebble.cli.cmd_bench import bench as _bench
from pebble.cli.cmd_explain import explain as _explain
from pebble.cli.cmd_init import init as _init
from pebble.cli.cmd_serve import serve as _serve


@click.group()
@click.option("--data", "data_dir", type=click.Path(), default=None,
              help="Database data directory.")
@click.option("--quiet", "-q", is_flag=True, default=False)
@click.version_option(version=__version__)
@click.pass_context
def main(ctx: click.Context, data_dir: str | None, quiet: bool) -> None:
    """Pebble -- a small SQL database engine."""
    if data_dir:
        os.environ["PEBBLE_DATA"] = data_dir
    level = logging.WARNING if quiet else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    ctx.ensure_object(dict)


main.add_command(_init, name="init")
main.add_command(_repl, name="repl")
main.add_command(_dump, name="dump")
main.add_command(_check, name="check")
main.add_command(_bench, name="bench")
main.add_command(_explain, name="explain")
main.add_command(_serve, name="serve")


if __name__ == "__main__":
    main()
