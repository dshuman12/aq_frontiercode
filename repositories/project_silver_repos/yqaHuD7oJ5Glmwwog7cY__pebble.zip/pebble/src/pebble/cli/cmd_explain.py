from __future__ import annotations

import click

from pebble.plan import render_plan
from pebble.server.embedded import open_embedded


@click.command()
@click.option("--data", "data_dir", default="./pebble_data", show_default=True)
@click.argument("sql")
def explain(data_dir: str, sql: str) -> None:
    """Print the optimized plan for SQL."""
    conn = open_embedded(data_dir)
    try:
        result = conn.execute(f"EXPLAIN {sql}")
        for row in result.rows:
            click.echo(row[0].payload)
    finally:
        conn.close()
