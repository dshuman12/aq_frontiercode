from __future__ import annotations

import os

import click


@click.command()
@click.argument("path", type=click.Path())
def init(path: str) -> None:
    """Create an empty Pebble data directory at PATH."""
    os.makedirs(path, exist_ok=True)
    os.makedirs(os.path.join(path, "wal"), exist_ok=True)
    os.makedirs(os.path.join(path, "heaps"), exist_ok=True)
    click.echo(f"initialised pebble data dir at {path}")
