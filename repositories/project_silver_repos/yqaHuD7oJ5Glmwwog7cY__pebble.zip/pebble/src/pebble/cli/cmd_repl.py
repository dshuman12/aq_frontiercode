from __future__ import annotations

import sys

import click
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from rich.console import Console
from rich.table import Table

from pebble.errors import PebbleError
from pebble.server.embedded import open_embedded


@click.command()
@click.option("--data", "data_dir", default="./pebble_data", show_default=True)
@click.option("--history", "history_path", default="~/.pebble_history", show_default=True)
def repl(data_dir: str, history_path: str) -> None:
    """Start an interactive REPL against the database in DATA."""
    console = Console()
    session: PromptSession[str] = PromptSession(history=FileHistory(history_path))
    conn = open_embedded(data_dir)
    console.print(f"[bold]pebble[/bold] connected to {data_dir}")
    buffer: list[str] = []
    try:
        while True:
            try:
                prompt = "pebble> " if not buffer else "  ...  > "
                line = session.prompt(prompt)
            except (KeyboardInterrupt, EOFError):
                console.print("bye.")
                return
            if not line.strip() and not buffer:
                continue
            buffer.append(line)
            joined = "\n".join(buffer)
            if not joined.rstrip().endswith(";"):
                continue
            statement = joined.rstrip().rstrip(";")
            buffer = []
            try:
                result = conn.execute(statement)
            except PebbleError as exc:
                console.print(f"[red]{type(exc).__name__}[/red]: {exc}")
                continue
            if result.columns:
                table = Table(*result.columns)
                for row in result.rows:
                    table.add_row(*[("NULL" if v.is_null else str(v.payload)) for v in row])
                console.print(table)
                console.print(f"({len(result.rows)} row{'s' if len(result.rows) != 1 else ''})")
            else:
                console.print(f"{result.tag} {result.rows_affected}".strip())
    finally:
        conn.close()
