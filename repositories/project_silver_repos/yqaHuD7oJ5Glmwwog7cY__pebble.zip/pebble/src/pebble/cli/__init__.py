from pebble.cli.main import main

__all__ = ["main"]
