from __future__ import annotations

import click

from pebble.server.embedded import open_embedded


@click.command()
@click.option("--data", "data_dir", default="./pebble_data", show_default=True)
@click.option("--output", "output_path", default="-",
              help="File path or '-' for stdout.")
def dump(data_dir: str, output_path: str) -> None:
    """Print every CREATE TABLE + INSERT statement in DATA."""
    conn = open_embedded(data_dir)
    out = open(output_path, "w", encoding="utf-8") if output_path != "-" else click.get_text_stream("stdout")
    try:
        for table in conn.engine.catalog.tables():
            cols = []
            for c in table.columns:
                line = f"{c.name} {c.type.render()}"
                if not c.nullable:
                    line += " NOT NULL"
                if c.is_primary_key:
                    line += " PRIMARY KEY"
                cols.append(line)
            out.write(f"CREATE TABLE {table.name} ({', '.join(cols)});\n")
        for table_name, rows in conn.engine.exec_ctx.rows.items():
            for row in rows:
                values = ", ".join(
                    "NULL" if v.is_null else _quote(v.payload)
                    for k, v in row.items() if "." not in k
                )
                cols = ", ".join(k for k in row if "." not in k)
                out.write(f"INSERT INTO {table_name} ({cols}) VALUES ({values});\n")
    finally:
        if output_path != "-":
            out.close()
        conn.close()


def _quote(value):
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    if isinstance(value, bytes):
        return f"x'{value.hex()}'"
    return repr(value)
