from __future__ import annotations

from typing import Sequence

from pebble.parser import ast as A


def render(node: A.Stmt | A.Expr) -> str:
    if isinstance(node, A.Stmt):
        return _render_stmt(node)
    return _render_expr(node)



def _render_stmt(stmt: A.Stmt) -> str:
    if isinstance(stmt, A.SelectStmt):
        return _render_select(stmt)
    if isinstance(stmt, A.InsertStmt):
        return _render_insert(stmt)
    if isinstance(stmt, A.UpdateStmt):
        return _render_update(stmt)
    if isinstance(stmt, A.DeleteStmt):
        return _render_delete(stmt)
    if isinstance(stmt, A.CreateTableStmt):
        return _render_create_table(stmt)
    if isinstance(stmt, A.CreateIndexStmt):
        return _render_create_index(stmt)
    if isinstance(stmt, A.DropStmt):
        ie = "IF EXISTS " if stmt.if_exists else ""
        return f"DROP {stmt.kind.upper()} {ie}{stmt.name}"
    if isinstance(stmt, A.TxnControlStmt):
        return stmt.kind.upper()
    return type(stmt).__name__


def _render_select(stmt: A.SelectStmt) -> str:
    parts: list[str] = []
    if stmt.ctes:
        parts.append("WITH " + ", ".join(_render_cte(c) for c in stmt.ctes))
    head = "SELECT DISTINCT" if stmt.distinct else "SELECT"
    proj = ", ".join(_render_projection(p) for p in stmt.projections) or "*"
    parts.append(f"{head} {proj}")
    if stmt.from_clause is not None:
        parts.append("FROM " + _render_from(stmt.from_clause))
    if stmt.where is not None:
        parts.append("WHERE " + _render_expr(stmt.where))
    if stmt.group_by:
        parts.append("GROUP BY " + ", ".join(_render_expr(g) for g in stmt.group_by))
    if stmt.having is not None:
        parts.append("HAVING " + _render_expr(stmt.having))
    if stmt.order_by:
        parts.append("ORDER BY " + ", ".join(_render_order(o) for o in stmt.order_by))
    if stmt.limit is not None:
        parts.append("LIMIT " + _render_expr(stmt.limit))
    if stmt.offset is not None:
        parts.append("OFFSET " + _render_expr(stmt.offset))
    rendered = " ".join(parts)
    if stmt.set_op and stmt.set_op_right:
        op = stmt.set_op.replace("_all", " ALL").upper()
        rendered = f"{rendered} {op} {_render_select(stmt.set_op_right)}"
    return rendered


def _render_insert(stmt: A.InsertStmt) -> str:
    cols = ""
    if stmt.columns:
        cols = " (" + ", ".join(stmt.columns) + ")"
    if stmt.select is not None:
        return f"INSERT INTO {stmt.table}{cols} {_render_select(stmt.select)}"
    rows = ", ".join(
        "(" + ", ".join(_render_expr(v) for v in row) + ")"
        for row in stmt.values
    )
    return f"INSERT INTO {stmt.table}{cols} VALUES {rows}"


def _render_update(stmt: A.UpdateStmt) -> str:
    sets = ", ".join(f"{a.column} = {_render_expr(a.value)}" for a in stmt.assignments)
    where = f" WHERE {_render_expr(stmt.where)}" if stmt.where is not None else ""
    return f"UPDATE {stmt.table} SET {sets}{where}"


def _render_delete(stmt: A.DeleteStmt) -> str:
    where = f" WHERE {_render_expr(stmt.where)}" if stmt.where is not None else ""
    return f"DELETE FROM {stmt.table}{where}"


def _render_create_table(stmt: A.CreateTableStmt) -> str:
    cols = ", ".join(_render_column_def(c) for c in stmt.columns)
    if stmt.primary_key_columns:
        cols += ", PRIMARY KEY (" + ", ".join(stmt.primary_key_columns) + ")"
    ie = "IF NOT EXISTS " if stmt.if_not_exists else ""
    return f"CREATE TABLE {ie}{stmt.name} ({cols})"


def _render_create_index(stmt: A.CreateIndexStmt) -> str:
    unique = "UNIQUE " if stmt.unique else ""
    cols = ", ".join(stmt.columns)
    ie = "IF NOT EXISTS " if stmt.if_not_exists else ""
    return f"CREATE {unique}INDEX {ie}{stmt.name} ON {stmt.table} ({cols})"



def _render_cte(cte: A.CteDecl) -> str:
    cols = ""
    if cte.column_aliases:
        cols = "(" + ", ".join(cte.column_aliases) + ") "
    rec = "RECURSIVE " if cte.recursive else ""
    return f"{rec}{cte.name} {cols}AS ({_render_select(cte.query)})"


def _render_projection(item: A.SelectItem) -> str:
    base = _render_expr(item.expr)
    if item.alias:
        return f"{base} AS {item.alias}"
    return base


def _render_from(table: A.TableExpr) -> str:
    if isinstance(table, A.TableRef):
        return f"{table.name}" + (f" AS {table.alias}" if table.alias else "")
    if isinstance(table, A.JoinClause):
        kind = table.kind.upper()
        join_sql = "JOIN" if kind == "INNER" else f"{kind} JOIN"
        on = ""
        if table.on is not None:
            on = " ON " + _render_expr(table.on)
        elif table.using is not None:
            on = " USING (" + ", ".join(table.using) + ")"
        return f"{_render_from(table.left)} {join_sql} {_render_from(table.right)}{on}"
    if isinstance(table, A.SubqueryRef):
        return f"({_render_select(table.query)}) AS {table.alias}"
    return repr(table)


def _render_order(o: A.OrderItem) -> str:
    out = _render_expr(o.expr)
    if o.descending:
        out += " DESC"
    return out


def _render_column_def(col: A.ColumnDef) -> str:
    parts = [col.name, col.type_name.upper()]
    if col.type_length is not None:
        parts[-1] = f"{col.type_name.upper()}({col.type_length})"
    if not col.nullable:
        parts.append("NOT NULL")
    if col.primary_key:
        parts.append("PRIMARY KEY")
    if col.unique:
        parts.append("UNIQUE")
    if col.default is not None:
        parts.append("DEFAULT " + _render_expr(col.default))
    if col.check is not None:
        parts.append(f"CHECK ({_render_expr(col.check)})")
    return " ".join(parts)



def _render_expr(expr: A.Expr) -> str:
    if isinstance(expr, A.Literal):
        return _render_literal(expr.value)
    if isinstance(expr, A.NullLiteral):
        return "NULL"
    if isinstance(expr, A.BoolLiteral):
        return "TRUE" if expr.value else "FALSE"
    if isinstance(expr, A.ColumnRef):
        if expr.table:
            return f"{expr.table}.{expr.name}"
        return expr.name
    if isinstance(expr, A.FunctionCall):
        if expr.is_star:
            return f"{expr.name}(*)"
        args = ", ".join(_render_expr(a) for a in expr.args)
        prefix = "DISTINCT " if expr.distinct else ""
        return f"{expr.name}({prefix}{args})"
    if isinstance(expr, A.BinaryOp):
        op = expr.op.upper() if expr.op in {"and", "or"} else expr.op
        return f"({_render_expr(expr.left)} {op} {_render_expr(expr.right)})"
    if isinstance(expr, A.UnaryOp):
        op = expr.op.upper() if expr.op == "not" else expr.op
        return f"({op} {_render_expr(expr.operand)})"
    if isinstance(expr, A.IsNull):
        kw = "IS NOT NULL" if expr.negated else "IS NULL"
        return f"({_render_expr(expr.expr)} {kw})"
    if isinstance(expr, A.Between):
        kw = "NOT BETWEEN" if expr.negated else "BETWEEN"
        return f"({_render_expr(expr.expr)} {kw} {_render_expr(expr.low)} AND {_render_expr(expr.high)})"
    if isinstance(expr, A.InList):
        kw = "NOT IN" if expr.negated else "IN"
        items = ", ".join(_render_expr(v) for v in expr.values)
        return f"({_render_expr(expr.expr)} {kw} ({items}))"
    if isinstance(expr, A.Like):
        kw = "NOT LIKE" if expr.negated else "LIKE"
        return f"({_render_expr(expr.expr)} {kw} {_render_expr(expr.pattern)})"
    if isinstance(expr, A.Cast):
        ty = expr.target_type.upper()
        if expr.target_length is not None:
            ty = f"{ty}({expr.target_length})"
        return f"CAST({_render_expr(expr.expr)} AS {ty})"
    if isinstance(expr, A.Case):
        parts = ["CASE"]
        if expr.operand is not None:
            parts.append(_render_expr(expr.operand))
        for cond, result in expr.when_clauses:
            parts.append(f"WHEN {_render_expr(cond)} THEN {_render_expr(result)}")
        if expr.else_clause is not None:
            parts.append("ELSE " + _render_expr(expr.else_clause))
        parts.append("END")
        return " ".join(parts)
    if isinstance(expr, A.Star):
        return f"{expr.table}.*" if expr.table else "*"
    if isinstance(expr, A.Subquery):
        return "(" + _render_select(expr.query) + ")"
    return repr(expr)


def _render_literal(value: object) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, bytes):
        return "x'" + value.hex() + "'"
    return repr(value)
