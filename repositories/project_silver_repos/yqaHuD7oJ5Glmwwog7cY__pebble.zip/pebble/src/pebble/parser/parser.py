from __future__ import annotations

# Expression precedence (low to high):
#   OR < AND < NOT < comparison < + - || < * / % < unary < primary

from typing import Any, Sequence

from pebble.errors import ParseError
from pebble.lexer import Lexer, Token, TokenKind
from pebble.parser import ast as A


class Parser:
    def __init__(self, source: str) -> None:
        self._tokens: list[Token] = list(Lexer(source))
        self._pos = 0

    def parse(self) -> list[A.Stmt]:
        statements: list[A.Stmt] = []
        while not self._at_eof():
            stmt = self._statement()
            statements.append(stmt)
            if self._match(TokenKind.SEMICOLON):
                continue
            if not self._at_eof():
                raise self._error("expected ; or end of input")
        return statements

    def parse_one(self) -> A.Stmt:
        stmts = self.parse()
        if not stmts:
            raise self._error("empty input")
        if len(stmts) > 1:
            raise self._error("expected a single statement")
        return stmts[0]

    def _statement(self) -> A.Stmt:
        tok = self._peek()
        if tok.is_keyword("WITH", "SELECT"):
            return self._select_statement()
        if tok.is_keyword("INSERT"):
            return self._insert_statement()
        if tok.is_keyword("UPDATE"):
            return self._update_statement()
        if tok.is_keyword("DELETE"):
            return self._delete_statement()
        if tok.is_keyword("CREATE"):
            return self._create_statement()
        if tok.is_keyword("DROP"):
            return self._drop_statement()
        if tok.is_keyword("BEGIN", "START"):
            return self._begin_statement()
        if tok.is_keyword("COMMIT", "END"):
            self._advance()
            return A.TxnControlStmt(kind="commit", position=tok.position)
        if tok.is_keyword("ROLLBACK", "ABORT"):
            self._advance()
            name: str | None = None
            if self._consume_keyword("TO"):
                self._consume_keyword("SAVEPOINT")
                name = self._expect_ident()
            return A.TxnControlStmt(kind="rollback", name=name, position=tok.position)
        if tok.is_keyword("SAVEPOINT"):
            self._advance()
            return A.TxnControlStmt(kind="savepoint", name=self._expect_ident(),
                                    position=tok.position)
        if tok.is_keyword("EXPLAIN"):
            return self._explain_statement()
        if tok.is_keyword("ANALYZE"):
            self._advance()
            target = self._expect_ident() if self._peek().kind in {TokenKind.IDENT,
                                                                   TokenKind.QUOTED_IDENT} else None
            return A.AnalyzeStmt(table=target, position=tok.position)
        if tok.is_keyword("VACUUM"):
            self._advance()
            target = self._expect_ident() if self._peek().kind in {TokenKind.IDENT,
                                                                   TokenKind.QUOTED_IDENT} else None
            return A.VacuumStmt(table=target, position=tok.position)
        raise self._error(f"unexpected start of statement {tok.text!r}")

    def _select_statement(self) -> A.SelectStmt:
        ctes = self._optional_with_clause()
        select = self._select_core()
        select.ctes = ctes
        if self._peek().is_keyword("UNION", "INTERSECT", "EXCEPT"):
            kind_tok = self._advance()
            all_kw = self._consume_keyword("ALL")
            right = self._select_core()
            select.set_op = (kind_tok.text.lower() + ("_all" if all_kw else ""))
            select.set_op_right = right
        return select

    def _optional_with_clause(self) -> list[A.CteDecl]:
        if not self._consume_keyword("WITH"):
            return []
        recursive = self._consume_keyword("RECURSIVE")
        ctes: list[A.CteDecl] = []
        while True:
            name = self._expect_ident()
            aliases: list[str] | None = None
            if self._match(TokenKind.LPAREN):
                aliases = []
                while True:
                    aliases.append(self._expect_ident())
                    if not self._match(TokenKind.COMMA):
                        break
                self._expect(TokenKind.RPAREN, "expected ) after CTE column list")
            self._expect_keyword("AS")
            self._expect(TokenKind.LPAREN, "expected (")
            inner = self._select_statement()
            self._expect(TokenKind.RPAREN, "expected )")
            ctes.append(A.CteDecl(name=name, column_aliases=aliases, query=inner,
                                  recursive=recursive))
            if not self._match(TokenKind.COMMA):
                break
        return ctes

    def _select_core(self) -> A.SelectStmt:
        kw = self._expect_keyword("SELECT")
        distinct = bool(self._consume_keyword("DISTINCT"))
        if self._consume_keyword("ALL"):
            distinct = False
        projections = self._projection_list()
        from_clause = None
        if self._consume_keyword("FROM"):
            from_clause = self._from_clause()
        where = None
        if self._consume_keyword("WHERE"):
            where = self._expression()
        group_by: list[A.Expr] = []
        if self._consume_keyword("GROUP"):
            self._expect_keyword("BY")
            group_by = self._comma_list(self._expression)
        having = None
        if self._consume_keyword("HAVING"):
            having = self._expression()
        order_by: list[A.OrderItem] = []
        if self._consume_keyword("ORDER"):
            self._expect_keyword("BY")
            order_by = self._comma_list(self._order_item)
        limit = None
        offset = None
        if self._consume_keyword("LIMIT"):
            limit = self._expression()
        if self._consume_keyword("OFFSET"):
            offset = self._expression()
        return A.SelectStmt(
            projections=projections,
            from_clause=from_clause,
            where=where,
            group_by=group_by,
            having=having,
            order_by=order_by,
            limit=limit,
            offset=offset,
            distinct=distinct,
            position=kw.position,
        )

    def _projection_list(self) -> list[A.SelectItem]:
        items: list[A.SelectItem] = []
        while True:
            if self._match(TokenKind.STAR):
                items.append(A.SelectItem(A.Star()))
            else:
                expr = self._expression()
                alias: str | None = None
                if self._consume_keyword("AS"):
                    alias = self._expect_ident()
                elif self._peek().kind in {TokenKind.IDENT, TokenKind.QUOTED_IDENT} \
                        and not self._peek().is_keyword(*_RESERVED_FOLLOWERS):
                    alias = self._advance().text
                items.append(A.SelectItem(expr, alias=alias))
            if not self._match(TokenKind.COMMA):
                return items

    def _from_clause(self) -> A.TableExpr:
        first = self._table_primary()
        return self._maybe_join(first)

    def _table_primary(self) -> A.TableExpr:
        if self._match(TokenKind.LPAREN):
            inner = self._select_statement()
            self._expect(TokenKind.RPAREN, "expected )")
            self._consume_keyword("AS")
            alias = self._expect_ident()
            return A.SubqueryRef(query=inner, alias=alias)
        name = self._expect_ident()
        alias: str | None = None
        if self._consume_keyword("AS"):
            alias = self._expect_ident()
        elif self._peek().kind in {TokenKind.IDENT, TokenKind.QUOTED_IDENT} \
                and not self._peek().is_keyword(*_RESERVED_FOLLOWERS):
            alias = self._advance().text
        return A.TableRef(name=name, alias=alias)

    def _maybe_join(self, left: A.TableExpr) -> A.TableExpr:
        while True:
            join_kind = self._peek_join_kind()
            if join_kind is None:
                if self._match(TokenKind.COMMA):
                    right = self._table_primary()
                    left = A.JoinClause(kind="cross", left=left, right=right)
                    continue
                return left
            self._consume_join_kind()
            self._expect_keyword("JOIN")
            right = self._table_primary()
            on: A.Expr | None = None
            using: list[str] | None = None
            if self._consume_keyword("ON"):
                on = self._expression()
            elif self._consume_keyword("USING"):
                self._expect(TokenKind.LPAREN, "expected (")
                using = self._comma_list(self._expect_ident)
                self._expect(TokenKind.RPAREN, "expected )")
            left = A.JoinClause(kind=join_kind, left=left, right=right, on=on, using=using)

    def _peek_join_kind(self) -> str | None:
        save = self._pos
        if self._consume_keyword("INNER"):
            self._pos = save
            return "inner"
        if self._consume_keyword("CROSS"):
            self._pos = save
            return "cross"
        if self._consume_keyword("LEFT"):
            self._consume_keyword("OUTER")
            self._pos = save
            return "left"
        if self._consume_keyword("RIGHT"):
            self._consume_keyword("OUTER")
            self._pos = save
            return "right"
        if self._consume_keyword("FULL"):
            self._consume_keyword("OUTER")
            self._pos = save
            return "full"
        if self._peek().is_keyword("JOIN"):
            return "inner"
        return None

    def _consume_join_kind(self) -> None:
        for kw in ("INNER", "CROSS"):
            if self._consume_keyword(kw):
                return
        if self._consume_keyword("LEFT") or self._consume_keyword("RIGHT") \
                or self._consume_keyword("FULL"):
            self._consume_keyword("OUTER")
            return
        # plain JOIN: nothing to consume

    def _order_item(self) -> A.OrderItem:
        expr = self._expression()
        descending = False
        if self._consume_keyword("DESC"):
            descending = True
        elif self._consume_keyword("ASC"):
            descending = False
        nulls_first: bool | None = None
        if self._consume_keyword("NULLS"):
            if self._consume_keyword("FIRST"):
                nulls_first = True
            elif self._consume_keyword("LAST"):
                nulls_first = False
        return A.OrderItem(expr=expr, descending=descending, nulls_first=nulls_first)

    def _insert_statement(self) -> A.InsertStmt:
        kw = self._expect_keyword("INSERT")
        self._expect_keyword("INTO")
        table = self._expect_ident()
        cols: list[str] = []
        if self._match(TokenKind.LPAREN):
            cols = self._comma_list(self._expect_ident)
            self._expect(TokenKind.RPAREN, "expected )")
        if self._consume_keyword("VALUES"):
            rows: list[list[A.Expr]] = []
            while True:
                self._expect(TokenKind.LPAREN, "expected (")
                row = self._comma_list(self._expression)
                self._expect(TokenKind.RPAREN, "expected )")
                rows.append(row)
                if not self._match(TokenKind.COMMA):
                    break
            return A.InsertStmt(table=table, columns=cols, values=rows, position=kw.position)
        sel = self._select_statement()
        return A.InsertStmt(table=table, columns=cols, select=sel, position=kw.position)

    def _update_statement(self) -> A.UpdateStmt:
        kw = self._expect_keyword("UPDATE")
        table = self._expect_ident()
        self._expect_keyword("SET")
        assignments: list[A.UpdateAssignment] = []
        while True:
            col = self._expect_ident()
            self._expect(TokenKind.EQ, "expected =")
            val = self._expression()
            assignments.append(A.UpdateAssignment(column=col, value=val))
            if not self._match(TokenKind.COMMA):
                break
        where: A.Expr | None = None
        if self._consume_keyword("WHERE"):
            where = self._expression()
        return A.UpdateStmt(table=table, assignments=assignments, where=where,
                            position=kw.position)

    def _delete_statement(self) -> A.DeleteStmt:
        kw = self._expect_keyword("DELETE")
        self._expect_keyword("FROM")
        table = self._expect_ident()
        where = None
        if self._consume_keyword("WHERE"):
            where = self._expression()
        return A.DeleteStmt(table=table, where=where, position=kw.position)

    def _create_statement(self) -> A.Stmt:
        kw = self._expect_keyword("CREATE")
        unique = bool(self._consume_keyword("UNIQUE"))
        if self._consume_keyword("INDEX"):
            return self._create_index(kw.position, unique=unique)
        if self._consume_keyword("TABLE"):
            return self._create_table(kw.position)
        raise self._error("expected TABLE or INDEX after CREATE")

    def _create_table(self, pos: int) -> A.CreateTableStmt:
        if_not_exists = False
        if self._consume_keyword("IF"):
            self._expect_keyword("NOT")
            self._expect_keyword("EXISTS")
            if_not_exists = True
        name = self._expect_ident()
        self._expect(TokenKind.LPAREN, "expected (")
        cols: list[A.ColumnDef] = []
        pk_cols: list[str] = []
        while True:
            if self._consume_keyword("PRIMARY"):
                self._expect_keyword("KEY")
                self._expect(TokenKind.LPAREN, "expected (")
                pk_cols = self._comma_list(self._expect_ident)
                self._expect(TokenKind.RPAREN, "expected )")
            else:
                cols.append(self._column_def())
            if not self._match(TokenKind.COMMA):
                break
        self._expect(TokenKind.RPAREN, "expected )")
        return A.CreateTableStmt(
            name=name, columns=cols, if_not_exists=if_not_exists,
            primary_key_columns=pk_cols, position=pos,
        )

    def _column_def(self) -> A.ColumnDef:
        name = self._expect_ident()
        type_token = self._advance()
        type_name = type_token.text
        type_length: int | None = None
        type_scale: int | None = None
        if self._match(TokenKind.LPAREN):
            type_length = int(self._expect(TokenKind.INT, "expected integer length").text)
            if self._match(TokenKind.COMMA):
                type_scale = int(self._expect(TokenKind.INT, "expected integer scale").text)
            self._expect(TokenKind.RPAREN, "expected )")
        nullable = True
        primary_key = False
        unique = False
        default: A.Expr | None = None
        check: A.Expr | None = None
        references: tuple[str, str] | None = None
        while True:
            if self._consume_keyword("NOT"):
                self._expect_keyword("NULL")
                nullable = False
            elif self._consume_keyword("NULL"):
                nullable = True
            elif self._consume_keyword("PRIMARY"):
                self._expect_keyword("KEY")
                primary_key = True
                nullable = False
            elif self._consume_keyword("UNIQUE"):
                unique = True
            elif self._consume_keyword("DEFAULT"):
                default = self._expression()
            elif self._consume_keyword("CHECK"):
                self._expect(TokenKind.LPAREN, "expected (")
                check = self._expression()
                self._expect(TokenKind.RPAREN, "expected )")
            elif self._consume_keyword("REFERENCES"):
                ref_table = self._expect_ident()
                self._expect(TokenKind.LPAREN, "expected (")
                ref_col = self._expect_ident()
                self._expect(TokenKind.RPAREN, "expected )")
                references = (ref_table, ref_col)
            else:
                break
        return A.ColumnDef(
            name=name,
            type_name=type_name,
            type_length=type_length,
            type_scale=type_scale,
            nullable=nullable,
            primary_key=primary_key,
            unique=unique,
            default=default,
            check=check,
            references=references,
        )

    def _create_index(self, pos: int, *, unique: bool) -> A.CreateIndexStmt:
        if_not_exists = False
        if self._consume_keyword("IF"):
            self._expect_keyword("NOT")
            self._expect_keyword("EXISTS")
            if_not_exists = True
        name = self._expect_ident()
        self._expect_keyword("ON")
        table = self._expect_ident()
        self._expect(TokenKind.LPAREN, "expected (")
        cols = self._comma_list(self._expect_ident)
        self._expect(TokenKind.RPAREN, "expected )")
        return A.CreateIndexStmt(
            name=name, table=table, columns=cols, unique=unique,
            if_not_exists=if_not_exists, position=pos,
        )

    def _drop_statement(self) -> A.DropStmt:
        kw = self._expect_keyword("DROP")
        if self._consume_keyword("TABLE"):
            kind = "table"
        elif self._consume_keyword("INDEX"):
            kind = "index"
        else:
            raise self._error("expected TABLE or INDEX after DROP")
        if_exists = False
        if self._consume_keyword("IF"):
            self._expect_keyword("EXISTS")
            if_exists = True
        name = self._expect_ident()
        return A.DropStmt(kind=kind, name=name, if_exists=if_exists, position=kw.position)

    def _begin_statement(self) -> A.TxnControlStmt:
        kw = self._advance()
        self._consume_keyword("TRANSACTION")
        isolation: str | None = None
        if self._consume_keyword("ISOLATION"):
            self._expect_keyword("LEVEL")
            parts: list[str] = []
            while self._peek().kind == TokenKind.KEYWORD and not self._peek().is_keyword("BEGIN", "READ"):
                parts.append(self._advance().text.upper())
                if not self._peek().is_keyword("READ", "REPEATABLE", "SERIALIZABLE", "SNAPSHOT"):
                    break
            isolation = " ".join(parts).lower()
        return A.TxnControlStmt(kind="begin", isolation=isolation, position=kw.position)

    def _explain_statement(self) -> A.ExplainStmt:
        kw = self._expect_keyword("EXPLAIN")
        analyze = bool(self._consume_keyword("ANALYZE"))
        inner = self._statement()
        return A.ExplainStmt(inner=inner, analyze=analyze, position=kw.position)

    def _expression(self) -> A.Expr:
        return self._or()

    def _or(self) -> A.Expr:
        left = self._and()
        while self._consume_keyword("OR"):
            right = self._and()
            left = A.BinaryOp(op="or", left=left, right=right, position=left.position)
        return left

    def _and(self) -> A.Expr:
        left = self._not()
        while self._consume_keyword("AND"):
            right = self._not()
            left = A.BinaryOp(op="and", left=left, right=right, position=left.position)
        return left

    def _not(self) -> A.Expr:
        if self._consume_keyword("NOT"):
            inner = self._not()
            return A.UnaryOp(op="not", operand=inner, position=inner.position)
        return self._comparison()

    def _comparison(self) -> A.Expr:
        left = self._concat()
        while True:
            tok = self._peek()
            if tok.kind in {TokenKind.EQ, TokenKind.NE, TokenKind.LT, TokenKind.LE,
                            TokenKind.GT, TokenKind.GE}:
                op_map = {
                    TokenKind.EQ: "=", TokenKind.NE: "<>",
                    TokenKind.LT: "<", TokenKind.LE: "<=",
                    TokenKind.GT: ">", TokenKind.GE: ">=",
                }
                self._advance()
                right = self._concat()
                left = A.BinaryOp(op=op_map[tok.kind], left=left, right=right,
                                  position=left.position)
                continue
            if tok.is_keyword("IS"):
                self._advance()
                negated = bool(self._consume_keyword("NOT"))
                self._expect_keyword("NULL")
                left = A.IsNull(expr=left, negated=negated, position=left.position)
                continue
            if tok.is_keyword("BETWEEN"):
                self._advance()
                low = self._concat()
                self._expect_keyword("AND")
                high = self._concat()
                left = A.Between(expr=left, low=low, high=high, position=left.position)
                continue
            if tok.is_keyword("NOT") and self._peek_offset(1).is_keyword("BETWEEN"):
                self._advance(); self._advance()
                low = self._concat()
                self._expect_keyword("AND")
                high = self._concat()
                left = A.Between(expr=left, low=low, high=high, negated=True,
                                 position=left.position)
                continue
            if tok.is_keyword("LIKE"):
                self._advance()
                pat = self._concat()
                escape: A.Expr | None = None
                if self._consume_keyword("ESCAPE"):
                    escape = self._concat()
                left = A.Like(expr=left, pattern=pat, escape=escape, position=left.position)
                continue
            if tok.is_keyword("IN"):
                self._advance()
                self._expect(TokenKind.LPAREN, "expected (")
                if self._peek().is_keyword("SELECT"):
                    sub = self._select_statement()
                    self._expect(TokenKind.RPAREN, "expected )")
                    left = A.InSubquery(expr=left, subquery=sub, position=left.position)
                else:
                    items = self._comma_list(self._expression)
                    self._expect(TokenKind.RPAREN, "expected )")
                    left = A.InList(expr=left, values=items, position=left.position)
                continue
            return left

    def _concat(self) -> A.Expr:
        left = self._addsub()
        while self._peek().kind == TokenKind.CONCAT:
            self._advance()
            right = self._addsub()
            left = A.BinaryOp(op="||", left=left, right=right, position=left.position)
        return left

    def _addsub(self) -> A.Expr:
        left = self._muldiv()
        while True:
            tok = self._peek()
            if tok.kind == TokenKind.PLUS:
                self._advance()
                right = self._muldiv()
                left = A.BinaryOp(op="+", left=left, right=right, position=left.position)
            elif tok.kind == TokenKind.MINUS:
                self._advance()
                right = self._muldiv()
                left = A.BinaryOp(op="-", left=left, right=right, position=left.position)
            else:
                return left

    def _muldiv(self) -> A.Expr:
        left = self._unary()
        while True:
            tok = self._peek()
            if tok.kind == TokenKind.STAR:
                self._advance()
                right = self._unary()
                left = A.BinaryOp(op="*", left=left, right=right, position=left.position)
            elif tok.kind == TokenKind.SLASH:
                self._advance()
                right = self._unary()
                left = A.BinaryOp(op="/", left=left, right=right, position=left.position)
            elif tok.kind == TokenKind.PERCENT:
                self._advance()
                right = self._unary()
                left = A.BinaryOp(op="%", left=left, right=right, position=left.position)
            else:
                return left

    def _unary(self) -> A.Expr:
        tok = self._peek()
        if tok.kind == TokenKind.MINUS:
            self._advance()
            inner = self._unary()
            return A.UnaryOp(op="-", operand=inner, position=tok.position)
        if tok.kind == TokenKind.PLUS:
            self._advance()
            return self._unary()
        return self._primary()

    def _primary(self) -> A.Expr:
        tok = self._peek()
        if tok.kind == TokenKind.INT:
            self._advance()
            return A.Literal(value=int(tok.text), position=tok.position)
        if tok.kind == TokenKind.FLOAT:
            self._advance()
            return A.Literal(value=float(tok.text), position=tok.position)
        if tok.kind == TokenKind.STRING:
            self._advance()
            return A.Literal(value=tok.text, position=tok.position)
        if tok.kind == TokenKind.BLOB:
            self._advance()
            return A.Literal(value=bytes.fromhex(tok.text), position=tok.position)
        if tok.is_keyword("NULL"):
            self._advance()
            return A.NullLiteral(position=tok.position)
        if tok.is_keyword("TRUE"):
            self._advance()
            return A.BoolLiteral(value=True, position=tok.position)
        if tok.is_keyword("FALSE"):
            self._advance()
            return A.BoolLiteral(value=False, position=tok.position)
        if tok.is_keyword("CAST"):
            return self._cast_expression()
        if tok.is_keyword("CASE"):
            return self._case_expression()
        if tok.kind == TokenKind.LPAREN:
            self._advance()
            if self._peek().is_keyword("SELECT"):
                inner = self._select_statement()
                self._expect(TokenKind.RPAREN, "expected )")
                return A.Subquery(query=inner, position=tok.position)
            expr = self._expression()
            self._expect(TokenKind.RPAREN, "expected )")
            return expr
        if tok.kind == TokenKind.STAR:
            self._advance()
            return A.Star(position=tok.position)
        if tok.kind in {TokenKind.IDENT, TokenKind.QUOTED_IDENT}:
            return self._ident_or_call()
        raise self._error(f"unexpected token {tok.text!r}")

    def _ident_or_call(self) -> A.Expr:
        name_tok = self._advance()
        if self._match(TokenKind.LPAREN):
            return self._function_call(name_tok)
        if self._match(TokenKind.DOT):
            second = self._advance()
            return A.ColumnRef(name=second.text, table=name_tok.text, position=name_tok.position)
        return A.ColumnRef(name=name_tok.text, position=name_tok.position)

    def _function_call(self, name_tok: Token) -> A.Expr:
        distinct = bool(self._consume_keyword("DISTINCT"))
        if self._match(TokenKind.STAR):
            self._expect(TokenKind.RPAREN, "expected )")
            return A.FunctionCall(name=name_tok.text, args=(), is_star=True,
                                  position=name_tok.position)
        args: list[A.Expr] = []
        if self._peek().kind != TokenKind.RPAREN:
            args = self._comma_list(self._expression)
        self._expect(TokenKind.RPAREN, "expected )")
        return A.FunctionCall(name=name_tok.text, args=args, distinct=distinct,
                              position=name_tok.position)

    def _cast_expression(self) -> A.Expr:
        kw = self._expect_keyword("CAST")
        self._expect(TokenKind.LPAREN, "expected (")
        expr = self._expression()
        self._expect_keyword("AS")
        ttok = self._advance()
        target = ttok.text
        length = None
        if self._match(TokenKind.LPAREN):
            length = int(self._expect(TokenKind.INT, "expected integer length").text)
            self._expect(TokenKind.RPAREN, "expected )")
        self._expect(TokenKind.RPAREN, "expected )")
        return A.Cast(expr=expr, target_type=target, target_length=length, position=kw.position)

    def _case_expression(self) -> A.Expr:
        kw = self._expect_keyword("CASE")
        operand: A.Expr | None = None
        if not self._peek().is_keyword("WHEN"):
            operand = self._expression()
        whens: list[tuple[A.Expr, A.Expr]] = []
        while self._consume_keyword("WHEN"):
            cond = self._expression()
            self._expect_keyword("THEN")
            result = self._expression()
            whens.append((cond, result))
        else_clause: A.Expr | None = None
        if self._consume_keyword("ELSE"):
            else_clause = self._expression()
        self._expect_keyword("END")
        return A.Case(operand=operand, when_clauses=whens, else_clause=else_clause,
                      position=kw.position)

    def _at_eof(self) -> bool:
        return self._peek().kind == TokenKind.EOF

    def _peek(self) -> Token:
        return self._tokens[self._pos]

    def _peek_offset(self, n: int) -> Token:
        idx = min(self._pos + n, len(self._tokens) - 1)
        return self._tokens[idx]

    def _advance(self) -> Token:
        tok = self._tokens[self._pos]
        if self._pos < len(self._tokens) - 1:
            self._pos += 1
        return tok

    def _match(self, kind: TokenKind) -> bool:
        if self._peek().kind == kind:
            self._advance()
            return True
        return False

    def _expect(self, kind: TokenKind, message: str) -> Token:
        if self._peek().kind == kind:
            return self._advance()
        raise self._error(message)

    def _expect_ident(self) -> str:
        tok = self._peek()
        if tok.kind in {TokenKind.IDENT, TokenKind.QUOTED_IDENT}:
            self._advance()
            return tok.text
        raise self._error("expected identifier")

    def _consume_keyword(self, name: str) -> bool:
        tok = self._peek()
        if tok.kind == TokenKind.KEYWORD and tok.text.upper() == name.upper():
            self._advance()
            return True
        return False

    def _expect_keyword(self, name: str) -> Token:
        tok = self._peek()
        if tok.kind == TokenKind.KEYWORD and tok.text.upper() == name.upper():
            return self._advance()
        raise self._error(f"expected keyword {name!r}, got {tok.text!r}")

    def _comma_list(self, parser: Any) -> list[Any]:
        items = [parser()]
        while self._match(TokenKind.COMMA):
            items.append(parser())
        return items

    def _error(self, message: str) -> ParseError:
        tok = self._peek()
        return ParseError(message, position=tok.position,
                          context={"token": tok.text, "line": tok.line, "col": tok.column})


_RESERVED_FOLLOWERS: tuple[str, ...] = (
    "FROM", "WHERE", "GROUP", "HAVING", "ORDER", "LIMIT", "OFFSET",
    "UNION", "INTERSECT", "EXCEPT", "ON", "USING", "WITH", "JOIN",
    "INNER", "LEFT", "RIGHT", "FULL", "CROSS", "AS",
)


def parse(source: str) -> list[A.Stmt]:
    return Parser(source).parse()


def parse_one(source: str) -> A.Stmt:
    return Parser(source).parse_one()
