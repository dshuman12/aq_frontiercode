from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence


@dataclass
class Expr:
    position: int = field(default=0, repr=False)


@dataclass
class Literal(Expr):
    value: Any = None


@dataclass
class NullLiteral(Expr):
    pass


@dataclass
class BoolLiteral(Expr):
    value: bool = False


@dataclass
class ColumnRef(Expr):
    name: str = ""
    table: str | None = None  # qualified ref: table.column


@dataclass
class FunctionCall(Expr):
    name: str = ""
    args: Sequence[Expr] = ()
    distinct: bool = False
    is_star: bool = False  # COUNT(*) shortcut


@dataclass
class BinaryOp(Expr):
    op: str = ""
    left: Expr | None = None
    right: Expr | None = None


@dataclass
class UnaryOp(Expr):
    op: str = ""
    operand: Expr | None = None


@dataclass
class Cast(Expr):
    expr: Expr | None = None
    target_type: str = ""
    target_length: int | None = None


@dataclass
class IsNull(Expr):
    expr: Expr | None = None
    negated: bool = False


@dataclass
class Between(Expr):
    expr: Expr | None = None
    low: Expr | None = None
    high: Expr | None = None
    negated: bool = False


@dataclass
class InList(Expr):
    expr: Expr | None = None
    values: Sequence[Expr] = ()
    negated: bool = False


@dataclass
class InSubquery(Expr):
    expr: Expr | None = None
    subquery: "SelectStmt | None" = None
    negated: bool = False


@dataclass
class Like(Expr):
    expr: Expr | None = None
    pattern: Expr | None = None
    escape: Expr | None = None
    negated: bool = False


@dataclass
class Case(Expr):
    operand: Expr | None = None
    when_clauses: Sequence[tuple[Expr, Expr]] = ()
    else_clause: Expr | None = None


@dataclass
class Subquery(Expr):
    query: "SelectStmt | None" = None


@dataclass
class Star(Expr):
    table: str | None = None


@dataclass
class SelectItem:
    expr: Expr
    alias: str | None = None


@dataclass
class TableRef:
    name: str
    alias: str | None = None


@dataclass
class JoinClause:
    kind: str  # "inner", "left", "right", "full", "cross"
    left: "TableExpr"
    right: "TableExpr"
    on: Expr | None = None
    using: Sequence[str] | None = None


@dataclass
class SubqueryRef:
    query: "SelectStmt"
    alias: str


TableExpr = TableRef | JoinClause | SubqueryRef


@dataclass
class OrderItem:
    expr: Expr
    descending: bool = False
    nulls_first: bool | None = None


@dataclass
class CteDecl:
    name: str
    column_aliases: Sequence[str] | None
    query: "SelectStmt"
    recursive: bool = False


@dataclass
class Stmt:
    position: int = field(default=0, repr=False)


@dataclass
class SelectStmt(Stmt):
    projections: Sequence[SelectItem] = ()
    from_clause: TableExpr | None = None
    where: Expr | None = None
    group_by: Sequence[Expr] = ()
    having: Expr | None = None
    order_by: Sequence[OrderItem] = ()
    limit: Expr | None = None
    offset: Expr | None = None
    distinct: bool = False
    set_op: str | None = None  # "union", "union_all", "intersect", "except"
    set_op_right: "SelectStmt | None" = None
    ctes: Sequence[CteDecl] = ()


@dataclass
class InsertStmt(Stmt):
    table: str = ""
    columns: Sequence[str] = ()
    values: Sequence[Sequence[Expr]] = ()  # VALUES rows
    select: SelectStmt | None = None       # INSERT ... SELECT


@dataclass
class UpdateAssignment:
    column: str
    value: Expr


@dataclass
class UpdateStmt(Stmt):
    table: str = ""
    assignments: Sequence[UpdateAssignment] = ()
    where: Expr | None = None


@dataclass
class DeleteStmt(Stmt):
    table: str = ""
    where: Expr | None = None


@dataclass
class ColumnDef:
    name: str
    type_name: str
    type_length: int | None = None
    type_scale: int | None = None
    nullable: bool = True
    primary_key: bool = False
    unique: bool = False
    default: Expr | None = None
    check: Expr | None = None
    references: tuple[str, str] | None = None  # (table, column)


@dataclass
class CreateTableStmt(Stmt):
    name: str = ""
    columns: Sequence[ColumnDef] = ()
    if_not_exists: bool = False
    primary_key_columns: Sequence[str] = ()


@dataclass
class CreateIndexStmt(Stmt):
    name: str = ""
    table: str = ""
    columns: Sequence[str] = ()
    unique: bool = False
    if_not_exists: bool = False


@dataclass
class DropStmt(Stmt):
    kind: str = ""  # "table" or "index"
    name: str = ""
    if_exists: bool = False


@dataclass
class TxnControlStmt(Stmt):
    kind: str = ""  # "begin", "commit", "rollback", "savepoint", "release"
    name: str | None = None
    isolation: str | None = None  # for BEGIN with isolation clause


@dataclass
class ExplainStmt(Stmt):
    inner: Stmt | None = None
    analyze: bool = False


@dataclass
class AnalyzeStmt(Stmt):
    table: str | None = None  # None means "every table"


@dataclass
class VacuumStmt(Stmt):
    table: str | None = None
