from __future__ import annotations

# A single re-entrant lock guards the whole pool. Per-page latches live
# in the btree/storage layers above, so this lock is only held briefly
# during lookup and eviction.

import threading
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Callable

from pebble.constants import DEFAULT_BUFFER_POOL_PAGES, DEFAULT_RING_BUFFER_PAGES
from pebble.errors import StorageError
from pebble.storage.heap import HeapFile
from pebble.storage.page import HeapPage


@dataclass
class _Frame:
    page: HeapPage
    pin_count: int = 0
    is_ring: bool = False
    last_used: int = 0

    @property
    def dirty(self) -> bool:
        return self.page.dirty


class BufferPool:
    """LRU buffer pool over a single heap file."""

    # Sequential scans use the ``ring=True`` mode so a large SELECT *
    # does not flush the working set.

    def __init__(
        self,
        heap: HeapFile,
        *,
        capacity: int = DEFAULT_BUFFER_POOL_PAGES,
        ring_capacity: int = DEFAULT_RING_BUFFER_PAGES,
    ) -> None:
        if capacity < 4:
            raise ValueError("capacity must be at least 4 pages")
        self.heap = heap
        self.capacity = capacity
        self.ring_capacity = ring_capacity
        self._frames: OrderedDict[int, _Frame] = OrderedDict()
        self._lock = threading.RLock()
        self._tick = 0
        self._stats = BufferPoolStats()

    def pin(self, page_id: int, *, ring: bool = False) -> "PinnedPage":
        with self._lock:
            self._tick += 1
            frame = self._frames.get(page_id)
            if frame is not None:
                self._stats.hits += 1
                frame.pin_count += 1
                frame.last_used = self._tick
                self._frames.move_to_end(page_id)
                return PinnedPage(self, page_id, frame.page)
            self._stats.misses += 1
            self._evict_if_needed(ring=ring)
            page = self.heap.read_page(page_id)
            frame = _Frame(page=page, pin_count=1, is_ring=ring, last_used=self._tick)
            self._frames[page_id] = frame
            return PinnedPage(self, page_id, page)

    def pin_new(self) -> "PinnedPage":
        """Allocate a new page and return it pinned."""
        with self._lock:
            page = self.heap.allocate_page()
            frame = _Frame(page=page, pin_count=1, last_used=self._tick)
            self._frames[page.header.page_id] = frame
            return PinnedPage(self, page.header.page_id, page)

    def unpin(self, page_id: int, *, dirty: bool = False) -> None:
        with self._lock:
            frame = self._frames.get(page_id)
            if frame is None:
                raise StorageError(f"unpin of unknown page {page_id}")
            if frame.pin_count <= 0:
                raise StorageError(f"unbalanced unpin on page {page_id}")
            frame.pin_count -= 1
            if dirty:
                frame.page.mark_dirty()

    def flush(self, page_id: int) -> None:
        with self._lock:
            frame = self._frames.get(page_id)
            if frame is None:
                return
            if frame.dirty:
                self.heap.write_page(frame.page)
                self._stats.flushes += 1

    def flush_all(self) -> None:
        with self._lock:
            for frame in self._frames.values():
                if frame.dirty:
                    self.heap.write_page(frame.page)
                    self._stats.flushes += 1

    def stats(self) -> "BufferPoolStats":
        with self._lock:
            return BufferPoolStats(
                hits=self._stats.hits, misses=self._stats.misses,
                flushes=self._stats.flushes, evictions=self._stats.evictions,
                size=len(self._frames),
            )

    def close(self) -> None:
        self.flush_all()

    def _evict_if_needed(self, *, ring: bool) -> None:
        ceiling = self.capacity if not ring else self.ring_capacity
        if len(self._frames) < self.capacity:
            return
        # When pinning a ring scan, evict ring frames first so the working
        # set stays protected.
        candidates = []
        if ring:
            candidates = [pid for pid, f in self._frames.items()
                          if f.pin_count == 0 and f.is_ring]
        if not candidates:
            candidates = [pid for pid, f in self._frames.items() if f.pin_count == 0]
        if not candidates:
            raise StorageError(
                "buffer pool exhausted: every page is pinned and no eviction is possible"
            )
        # _frames is in LRU order; pick the first matching candidate.
        chosen = next(pid for pid in self._frames if pid in candidates)
        frame = self._frames.pop(chosen)
        if frame.dirty:
            self.heap.write_page(frame.page)
            self._stats.flushes += 1
        self._stats.evictions += 1


class PinnedPage:
    """Context manager that automatically unpins on ``__exit__``."""

    __slots__ = ("pool", "page_id", "page", "_dirty_on_exit")

    def __init__(self, pool: BufferPool, page_id: int, page: HeapPage) -> None:
        self.pool = pool
        self.page_id = page_id
        self.page = page
        self._dirty_on_exit = False

    def mark_dirty(self) -> None:
        self._dirty_on_exit = True
        self.page.mark_dirty()

    def __enter__(self) -> HeapPage:
        return self.page

    def __exit__(self, *_: object) -> None:
        self.pool.unpin(self.page_id, dirty=self._dirty_on_exit)


@dataclass
class BufferPoolStats:
    hits: int = 0
    misses: int = 0
    flushes: int = 0
    evictions: int = 0
    size: int = 0

    @property
    def hit_ratio(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total else 0.0
