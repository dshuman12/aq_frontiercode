from __future__ import annotations

import logging
from dataclasses import dataclass

from pebble.catalog import Catalog, Column
from pebble.errors import ColumnNotFound, DuplicateName, TableNotFound
from pebble.types import SqlType, parse_type

log = logging.getLogger(__name__)


@dataclass
class MigrationStep:
    description: str

    def apply(self, catalog: Catalog) -> None:
        raise NotImplementedError


@dataclass
class AddColumn(MigrationStep):
    table: str = ""
    name: str = ""
    type: SqlType | None = None
    nullable: bool = True

    def apply(self, catalog: Catalog) -> None:
        tbl = catalog.get_table(self.table)
        if tbl.has_column(self.name):
            raise DuplicateName(f"column {self.name!r} already exists on {self.table!r}")
        ordinal = max((c.ordinal for c in tbl.columns), default=-1) + 1
        if self.type is None:
            raise ValueError("AddColumn requires a type")
        tbl.columns.append(
            Column(
                name=self.name, type=self.type, ordinal=ordinal, nullable=self.nullable,
            )
        )


@dataclass
class DropColumn(MigrationStep):
    table: str = ""
    name: str = ""

    def apply(self, catalog: Catalog) -> None:
        tbl = catalog.get_table(self.table)
        before = len(tbl.columns)
        tbl.columns = [c for c in tbl.columns if c.name != self.name]
        if len(tbl.columns) == before:
            raise ColumnNotFound(self.name, table=self.table)


@dataclass
class RenameTable(MigrationStep):
    from_name: str = ""
    to_name: str = ""

    def apply(self, catalog: Catalog) -> None:
        if not catalog.has_table(self.from_name):
            raise TableNotFound(self.from_name)
        if catalog.has_table(self.to_name):
            raise DuplicateName(self.to_name)
        tbl = catalog._tables.pop(self.from_name)  # noqa: SLF001
        tbl.name = self.to_name
        catalog._tables[self.to_name] = tbl  # noqa: SLF001


@dataclass
class Migration:
    name: str
    steps: list[MigrationStep]

    def apply(self, catalog: Catalog) -> None:
        for step in self.steps:
            log.info("migration %s: %s", self.name, step.description)
            step.apply(catalog)


def from_yaml(payload: dict) -> Migration:
    """Build a migration from a YAML/JSON-like payload.

    Keeps tests simple -- a single dict can describe a whole migration.
    """
    name = payload.get("name", "anonymous")
    steps: list[MigrationStep] = []
    for raw in payload.get("steps", []):
        kind = raw["kind"]
        if kind == "add_column":
            steps.append(AddColumn(
                description=f"add {raw['table']}.{raw['name']}",
                table=raw["table"], name=raw["name"],
                type=parse_type(raw["type"]),
                nullable=raw.get("nullable", True),
            ))
        elif kind == "drop_column":
            steps.append(DropColumn(
                description=f"drop {raw['table']}.{raw['name']}",
                table=raw["table"], name=raw["name"],
            ))
        elif kind == "rename_table":
            steps.append(RenameTable(
                description=f"rename {raw['from']} -> {raw['to']}",
                from_name=raw["from"], to_name=raw["to"],
            ))
        else:
            raise ValueError(f"unknown migration step kind: {kind}")
    return Migration(name=name, steps=steps)
