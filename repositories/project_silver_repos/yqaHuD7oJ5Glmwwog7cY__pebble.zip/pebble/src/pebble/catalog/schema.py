from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from pebble.constants import MAX_COLUMNS_PER_TABLE
from pebble.errors import ColumnNotFound, DuplicateName, TableNotFound
from pebble.types import SqlType


@dataclass
class Column:
    name: str
    type: SqlType
    ordinal: int
    nullable: bool = True
    default_sql: str | None = None
    is_primary_key: bool = False


@dataclass
class IndexInfo:
    name: str
    table: str
    columns: tuple[str, ...]
    unique: bool = False
    root_page_id: int = 0


@dataclass
class ColumnStats:
    null_fraction: float = 0.0
    distinct_count: int = 0
    most_common_values: tuple[object, ...] = ()
    histogram_bounds: tuple[object, ...] = ()


@dataclass
class TableStats:
    row_count: int = 0
    page_count: int = 0
    columns: dict[str, ColumnStats] = field(default_factory=dict)


@dataclass
class Table:
    name: str
    oid: int
    columns: list[Column]
    primary_key: tuple[str, ...] = ()
    indexes: list[IndexInfo] = field(default_factory=list)
    stats: TableStats = field(default_factory=TableStats)
    heap_file: str = ""

    @property
    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]

    def column(self, name: str) -> Column:
        for c in self.columns:
            if c.name == name:
                return c
        raise ColumnNotFound(name, table=self.name)

    def has_column(self, name: str) -> bool:
        return any(c.name == name for c in self.columns)


class Catalog:
    """In-memory catalog cache."""

    def __init__(self) -> None:
        self._tables: dict[str, Table] = {}
        self._next_oid = 16384

    def create_table(
        self,
        *,
        name: str,
        columns: list[Column],
        primary_key: Iterable[str] = (),
        heap_file: str = "",
    ) -> Table:
        if name in self._tables:
            raise DuplicateName(f"table {name!r} already exists")
        if len(columns) > MAX_COLUMNS_PER_TABLE:
            raise DuplicateName(f"too many columns: max {MAX_COLUMNS_PER_TABLE}")
        seen: set[str] = set()
        for c in columns:
            if c.name in seen:
                raise DuplicateName(f"column {c.name!r} declared twice")
            seen.add(c.name)
        table = Table(
            name=name,
            oid=self._next_oid,
            columns=list(columns),
            primary_key=tuple(primary_key),
            heap_file=heap_file,
        )
        self._next_oid += 1
        self._tables[name] = table
        return table

    def drop_table(self, name: str) -> Table:
        if name not in self._tables:
            raise TableNotFound(name)
        return self._tables.pop(name)

    def get_table(self, name: str) -> Table:
        if name not in self._tables:
            raise TableNotFound(name)
        return self._tables[name]

    def has_table(self, name: str) -> bool:
        return name in self._tables

    def tables(self) -> list[Table]:
        return list(self._tables.values())

    def create_index(
        self,
        *,
        name: str,
        table: str,
        columns: Iterable[str],
        unique: bool = False,
        root_page_id: int = 0,
    ) -> IndexInfo:
        tbl = self.get_table(table)
        for col in columns:
            tbl.column(col)  # raises if missing
        if any(idx.name == name for idx in tbl.indexes):
            raise DuplicateName(f"index {name!r} already exists on {table}")
        idx = IndexInfo(
            name=name, table=table, columns=tuple(columns),
            unique=unique, root_page_id=root_page_id,
        )
        tbl.indexes.append(idx)
        return idx

    def drop_index(self, table: str, name: str) -> None:
        tbl = self.get_table(table)
        before = len(tbl.indexes)
        tbl.indexes = [idx for idx in tbl.indexes if idx.name != name]
        if len(tbl.indexes) == before:
            raise TableNotFound(f"{table}.{name}")

    def find_index(self, table: str, name: str) -> IndexInfo | None:
        tbl = self.get_table(table)
        for idx in tbl.indexes:
            if idx.name == name:
                return idx
        return None

    def update_stats(self, table: str, stats: TableStats) -> None:
        tbl = self.get_table(table)
        tbl.stats = stats
