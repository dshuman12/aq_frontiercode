from __future__ import annotations

from pebble.catalog.schema import Catalog, Column
from pebble.constants import (
    CATALOG_COLUMNS_OID,
    CATALOG_INDEXES_OID,
    CATALOG_STATS_OID,
    CATALOG_TABLES_OID,
)
from pebble.types import BIGINT, BOOL, INT, TEXT


def bootstrap(catalog: Catalog) -> None:
    """Populate ``catalog`` with the system tables.

    The function is idempotent: calling it twice on the same catalog
    is a no-op as long as the existing tables match the expected
    shape.
    """
    if not catalog.has_table("pebble_tables"):
        catalog.create_table(
            name="pebble_tables",
            columns=[
                Column(name="oid", type=INT, ordinal=0, is_primary_key=True),
                Column(name="name", type=TEXT, ordinal=1, nullable=False),
                Column(name="row_count", type=BIGINT, ordinal=2, nullable=False),
                Column(name="page_count", type=INT, ordinal=3, nullable=False),
            ],
        )
        catalog.get_table("pebble_tables").oid = CATALOG_TABLES_OID
    if not catalog.has_table("pebble_columns"):
        catalog.create_table(
            name="pebble_columns",
            columns=[
                Column(name="table_oid", type=INT, ordinal=0, nullable=False),
                Column(name="ordinal", type=INT, ordinal=1, nullable=False),
                Column(name="name", type=TEXT, ordinal=2, nullable=False),
                Column(name="type", type=TEXT, ordinal=3, nullable=False),
                Column(name="is_nullable", type=BOOL, ordinal=4, nullable=False),
                Column(name="is_primary_key", type=BOOL, ordinal=5, nullable=False),
            ],
        )
        catalog.get_table("pebble_columns").oid = CATALOG_COLUMNS_OID
    if not catalog.has_table("pebble_indexes"):
        catalog.create_table(
            name="pebble_indexes",
            columns=[
                Column(name="oid", type=INT, ordinal=0, is_primary_key=True),
                Column(name="table_oid", type=INT, ordinal=1, nullable=False),
                Column(name="name", type=TEXT, ordinal=2, nullable=False),
                Column(name="columns", type=TEXT, ordinal=3, nullable=False),
                Column(name="unique", type=BOOL, ordinal=4, nullable=False),
            ],
        )
        catalog.get_table("pebble_indexes").oid = CATALOG_INDEXES_OID
    if not catalog.has_table("pebble_stats"):
        catalog.create_table(
            name="pebble_stats",
            columns=[
                Column(name="table_oid", type=INT, ordinal=0, nullable=False),
                Column(name="column_name", type=TEXT, ordinal=1, nullable=False),
                Column(name="distinct_count", type=BIGINT, ordinal=2, nullable=False),
                Column(name="null_fraction", type=TEXT, ordinal=3, nullable=False),
            ],
        )
        catalog.get_table("pebble_stats").oid = CATALOG_STATS_OID


def is_system_table(name: str) -> bool:
    return name.startswith("pebble_")
