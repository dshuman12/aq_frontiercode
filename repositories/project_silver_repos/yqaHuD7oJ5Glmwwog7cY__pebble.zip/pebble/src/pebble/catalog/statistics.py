from __future__ import annotations

import bisect
import math
from collections import Counter
from dataclasses import dataclass
from typing import Iterable, Sequence

from pebble.catalog.schema import ColumnStats
from pebble.types.value import Value


DEFAULT_HISTOGRAM_BUCKETS: int = 10
MAX_MCV: int = 8


@dataclass
class HistogramSummary:
    """Equal-frequency histogram bounds + most-common-values list."""

    bounds: tuple[object, ...]
    mcv: tuple[tuple[object, int], ...]
    null_count: int
    total: int

    @property
    def null_fraction(self) -> float:
        return self.null_count / self.total if self.total else 0.0

    def estimate_selectivity(self, *, op: str, value: object) -> float:
        """Estimate how many rows would satisfy ``column op value``."""
        if op == "=":
            for v, count in self.mcv:
                if v == value:
                    return count / max(self.total, 1)
            distinct = max(len(self.bounds), 1)
            return 1.0 / distinct
        if op in {"<", "<=", ">", ">="}:
            return self._range_selectivity(op, value)
        if op in {"<>", "!="}:
            return 1.0 - self.estimate_selectivity(op="=", value=value)
        return 0.5  # unknown -> assume 50%

    def _range_selectivity(self, op: str, value: object) -> float:
        if not self.bounds:
            return 0.5
        try:
            idx = bisect.bisect_left(self.bounds, value)
        except TypeError:
            return 0.5
        position = idx / len(self.bounds)
        if op in {"<", "<="}:
            return max(0.0, min(1.0, position))
        return max(0.0, min(1.0, 1.0 - position))


def gather(values: Iterable[Value]) -> HistogramSummary:
    samples: list[object] = []
    null_count = 0
    counter: Counter = Counter()
    for v in values:
        if v.is_null:
            null_count += 1
            continue
        samples.append(v.payload)
        counter[v.payload] += 1
    samples.sort()
    bounds = _equal_frequency_bounds(samples)
    mcv = tuple(counter.most_common(MAX_MCV))
    return HistogramSummary(
        bounds=tuple(bounds),
        mcv=mcv,
        null_count=null_count,
        total=null_count + len(samples),
    )


def _equal_frequency_bounds(values: Sequence[object]) -> list[object]:
    if not values:
        return []
    n = len(values)
    buckets = min(DEFAULT_HISTOGRAM_BUCKETS, max(1, n - 1))
    step = max(1, math.ceil(n / buckets))
    bounds: list[object] = []
    for i in range(step, n, step):
        bounds.append(values[i])
    return bounds


def to_column_stats(summary: HistogramSummary) -> ColumnStats:
    """Convert a sample-based summary into a ``ColumnStats`` for the catalog."""
    return ColumnStats(
        null_fraction=summary.null_fraction,
        distinct_count=max(len({v for v, _ in summary.mcv} | set(summary.bounds)), 1),
        most_common_values=tuple(v for v, _ in summary.mcv),
        histogram_bounds=summary.bounds,
    )
