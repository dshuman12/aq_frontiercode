from __future__ import annotations

from typing import Sequence

from pebble.types.value import Value


def render_table(columns: Sequence[str], rows: Sequence[Sequence[Value]]) -> str:
    """Render a result set as an ASCII table.

    Each column is padded to the widest cell. Numeric columns are
    right-aligned; everything else is left-aligned.
    """
    if not columns:
        return "(empty result)"
    str_rows = [[_render(v) for v in row] for row in rows]
    widths = [len(c) for c in columns]
    for row in str_rows:
        for i, cell in enumerate(row):
            if len(cell) > widths[i]:
                widths[i] = len(cell)
    align = [_align_for_column(rows, i) for i in range(len(columns))]
    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    header_cells = [
        f" {col.ljust(widths[i])} " for i, col in enumerate(columns)
    ]
    out = [sep, "|" + "|".join(header_cells) + "|", sep]
    for row in str_rows:
        cells = []
        for i, cell in enumerate(row):
            if align[i] == "right":
                cells.append(f" {cell.rjust(widths[i])} ")
            else:
                cells.append(f" {cell.ljust(widths[i])} ")
        out.append("|" + "|".join(cells) + "|")
    out.append(sep)
    out.append(f"({len(rows)} row{'s' if len(rows) != 1 else ''})")
    return "\n".join(out)


def _align_for_column(rows: Sequence[Sequence[Value]], idx: int) -> str:
    for row in rows:
        if idx >= len(row):
            continue
        v = row[idx]
        if v.is_null:
            continue
        if isinstance(v.payload, (int, float)):
            return "right"
        return "left"
    return "left"


def _render(value: Value) -> str:
    if value.is_null:
        return "NULL"
    payload = value.payload
    if isinstance(payload, bytes):
        return f"\\x{payload.hex()}"
    return str(payload)


def render_csv(columns: Sequence[str], rows: Sequence[Sequence[Value]]) -> str:
    """Render rows as RFC-4180-flavoured CSV."""
    out = [",".join(_csv_escape(c) for c in columns)]
    for row in rows:
        out.append(",".join(_csv_escape(_render(v)) for v in row))
    return "\n".join(out)


def _csv_escape(value: str) -> str:
    if any(ch in value for ch in ',"\n\r'):
        return '"' + value.replace('"', '""') + '"'
    return value
