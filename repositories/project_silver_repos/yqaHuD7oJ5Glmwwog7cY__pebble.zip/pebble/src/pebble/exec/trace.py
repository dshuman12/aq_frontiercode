from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Iterator

from pebble.exec.iterators import Row


@dataclass
class TraceNode:
    operator: str
    rows: int = 0
    elapsed_seconds: float = 0.0
    max_row_width: int = 0
    children: list["TraceNode"] = field(default_factory=list)

    def render(self, indent: int = 0) -> str:
        lines = ["  " * indent + (
            f"{self.operator}  rows={self.rows}  "
            f"elapsed={self.elapsed_seconds * 1000:.2f}ms  "
            f"max_width={self.max_row_width}"
        )]
        for child in self.children:
            lines.append(child.render(indent + 1))
        return "\n".join(lines)


def trace_iter(label: str, source: Iterator[Row]) -> tuple[Iterator[Row], TraceNode]:
    """Wrap ``source`` so iterating it populates a returned :class:`TraceNode`."""
    node = TraceNode(operator=label)

    def gen() -> Iterator[Row]:
        start = time.perf_counter()
        try:
            for row in source:
                node.rows += 1
                width = sum(len(str(v.payload)) if not v.is_null else 0 for v in row.values())
                if width > node.max_row_width:
                    node.max_row_width = width
                yield row
        finally:
            node.elapsed_seconds = time.perf_counter() - start

    return gen(), node
