from __future__ import annotations

from typing import Any, Iterable, Sequence

from pebble.exec.iterators import Row
from pebble.types.value import Value


def materialise(iterator: Iterable[Row]) -> list[Row]:
    """Pull every row out of an iterator. Useful in tests and EXPLAIN ANALYZE."""
    return list(iterator)


def take(iterator: Iterable[Row], n: int) -> list[Row]:
    """Pull the first ``n`` rows; safe for unbounded iterators."""
    out: list[Row] = []
    for row in iterator:
        out.append(row)
        if len(out) >= n:
            break
    return out


def column_values(rows: Sequence[Row], column: str) -> list[Value]:
    """Return the slice of one column across many rows."""
    return [row.get(column, Value.null()) for row in rows]


def cross_product(left: Iterable[Row], right: Sequence[Row]) -> Iterable[Row]:
    """Cartesian cross product. Used by NestedLoopJoin when there is no predicate."""
    for l in left:
        for r in right:
            yield {**l, **r}


def deduplicate_rows(rows: Iterable[Row]) -> Iterable[Row]:
    """Yield each row at most once, keyed by sorted (column, payload) pairs."""
    seen: set[tuple[Any, ...]] = set()
    for row in rows:
        sig = tuple(sorted((k, v.payload if not v.is_null else None) for k, v in row.items()))
        if sig in seen:
            continue
        seen.add(sig)
        yield row


def coerce_int(value: Value, *, default: int = 0) -> int:
    """Best-effort coercion to int -- used by LIMIT/OFFSET expressions."""
    if value.is_null:
        return default
    if isinstance(value.payload, bool):
        return int(value.payload)
    if isinstance(value.payload, (int, float)):
        return int(value.payload)
    raise TypeError(f"cannot coerce {value.type} to int")


def coerce_bool(value: Value) -> bool:
    """Truthiness: NULL is False; numeric zero is False; empty string is False."""
    if value.is_null:
        return False
    payload = value.payload
    if isinstance(payload, bool):
        return payload
    if isinstance(payload, (int, float)):
        return payload != 0
    if isinstance(payload, str):
        return payload != ""
    return True
