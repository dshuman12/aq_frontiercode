from __future__ import annotations

import logging
from typing import Any, Iterable, Iterator, Mapping

from pebble.catalog import Catalog
from pebble.errors import ExecutionError, TableNotFound
from pebble.expr.evaluator import Evaluator
from pebble.parser import ast as A
from pebble.plan import physical as P
from pebble.types.value import Value

log = logging.getLogger(__name__)


Row = dict[str, Value]


class ExecutionContext:
    """Holds catalog, expression evaluator, and an in-memory row store.

    Pebble's storage layer is page-based but the integration with the
    executor goes through this single class so tests can swap it out
    for a memory backend without standing up a buffer pool.
    """

    def __init__(self, *, catalog: Catalog, rows: dict[str, list[Row]] | None = None) -> None:
        self.catalog = catalog
        self.rows = rows or {}
        self.evaluator = Evaluator()

    def fetch(self, table: str) -> Iterable[Row]:
        if table not in self.rows:
            if not self.catalog.has_table(table):
                raise TableNotFound(table)
            return []
        return list(self.rows[table])

    def append(self, table: str, row: Row) -> None:
        self.rows.setdefault(table, []).append(row)

    def remove(self, table: str, predicate) -> int:
        if table not in self.rows:
            return 0
        before = len(self.rows[table])
        self.rows[table] = [r for r in self.rows[table] if not predicate(r)]
        return before - len(self.rows[table])



def execute(plan: P.PhysicalPlan, ctx: ExecutionContext) -> Iterator[Row]:
    if isinstance(plan, P.SeqScan):
        return seq_scan(plan, ctx)
    if isinstance(plan, P.IndexScan):
        return index_scan(plan, ctx)
    if isinstance(plan, P.FilterNode):
        return filter_iter(plan, ctx)
    if isinstance(plan, P.ProjectNode):
        return project_iter(plan, ctx)
    if isinstance(plan, P.NestedLoopJoin):
        return nested_loop(plan, ctx)
    if isinstance(plan, P.HashJoin):
        return hash_join(plan, ctx)
    if isinstance(plan, P.MergeJoin):
        return merge_join(plan, ctx)
    if isinstance(plan, P.HashAggregate):
        return hash_aggregate(plan, ctx)
    if isinstance(plan, P.SortNode):
        return sort_iter(plan, ctx)
    if isinstance(plan, P.LimitNode):
        return limit_iter(plan, ctx)
    raise ExecutionError(f"no iterator for {type(plan).__name__}")



def seq_scan(plan: P.SeqScan, ctx: ExecutionContext) -> Iterator[Row]:
    for row in ctx.fetch(plan.table):
        yield _qualify(row, plan.alias or plan.table)


def index_scan(plan: P.IndexScan, ctx: ExecutionContext) -> Iterator[Row]:
    # Simplified: same as seq_scan but with a residual predicate filter.
    for row in ctx.fetch(plan.table):
        if plan.predicate is None or _truthy(ctx.evaluator.evaluate(plan.predicate, row)):
            yield row


def filter_iter(plan: P.FilterNode, ctx: ExecutionContext) -> Iterator[Row]:
    pred = plan.predicate
    if plan.input is None:
        return
    for row in execute(plan.input, ctx):
        if pred is None or _truthy(ctx.evaluator.evaluate(pred, row)):
            yield row


def project_iter(plan: P.ProjectNode, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.input is None:
        return
    seen: set[tuple[Any, ...]] | None = set() if plan.distinct else None
    for row in execute(plan.input, ctx):
        out: Row = {}
        for expr, alias in plan.projections:
            if isinstance(expr, A.Star):
                out.update(row)
                continue
            value = ctx.evaluator.evaluate(expr, row)
            key = alias or _expression_label(expr)
            out[key] = value
        if seen is not None:
            sig = tuple((k, _hash_value(v)) for k, v in sorted(out.items()))
            if sig in seen:
                continue
            seen.add(sig)
        yield out


def nested_loop(plan: P.NestedLoopJoin, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.outer is None or plan.inner is None:
        return
    inner_rows = list(execute(plan.inner, ctx))
    for outer in execute(plan.outer, ctx):
        for inner in inner_rows:
            combined: Row = {**outer, **inner}
            if plan.predicate is None or _truthy(ctx.evaluator.evaluate(plan.predicate, combined)):
                yield combined


def hash_join(plan: P.HashJoin, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.build is None or plan.probe is None:
        return
    table: dict[tuple[Any, ...], list[Row]] = {}
    for row in execute(plan.build, ctx):
        key = tuple(_hash_value(ctx.evaluator.evaluate(k, row)) for k in plan.build_keys)
        table.setdefault(key, []).append(row)
    for row in execute(plan.probe, ctx):
        key = tuple(_hash_value(ctx.evaluator.evaluate(k, row)) for k in plan.probe_keys)
        for build_row in table.get(key, ()):
            combined: Row = {**build_row, **row}
            if plan.residual is None or _truthy(ctx.evaluator.evaluate(plan.residual, combined)):
                yield combined


def merge_join(plan: P.MergeJoin, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.left is None or plan.right is None:
        return
    left = list(execute(plan.left, ctx))
    right = list(execute(plan.right, ctx))
    left.sort(key=lambda r: tuple(_sort_key(ctx.evaluator.evaluate(k, r)) for k in plan.left_keys))
    right.sort(key=lambda r: tuple(_sort_key(ctx.evaluator.evaluate(k, r)) for k in plan.right_keys))
    i = j = 0
    while i < len(left) and j < len(right):
        lkey = tuple(_sort_key(ctx.evaluator.evaluate(k, left[i])) for k in plan.left_keys)
        rkey = tuple(_sort_key(ctx.evaluator.evaluate(k, right[j])) for k in plan.right_keys)
        if lkey < rkey:
            i += 1
        elif lkey > rkey:
            j += 1
        else:
            # Cross-product over equal blocks.
            i_block = i
            while i_block < len(left) and tuple(
                _sort_key(ctx.evaluator.evaluate(k, left[i_block])) for k in plan.left_keys
            ) == lkey:
                j_block = j
                while j_block < len(right) and tuple(
                    _sort_key(ctx.evaluator.evaluate(k, right[j_block])) for k in plan.right_keys
                ) == rkey:
                    yield {**left[i_block], **right[j_block]}
                    j_block += 1
                i_block += 1
            i = i_block
            while j < len(right) and tuple(
                _sort_key(ctx.evaluator.evaluate(k, right[j])) for k in plan.right_keys
            ) == rkey:
                j += 1


def hash_aggregate(plan: P.HashAggregate, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.input is None:
        return
    groups: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in execute(plan.input, ctx):
        key = tuple(_hash_value(ctx.evaluator.evaluate(g, row)) for g in plan.group_keys)
        bucket = groups.setdefault(key, {"_rows": 0, "_first_row": row, "_aggs": {}})
        bucket["_rows"] += 1
        for fn, alias in plan.aggregates:
            label = alias or _expression_label(fn)
            current = bucket["_aggs"].get(label)
            new = _accumulate(fn, current, row, ctx.evaluator)
            bucket["_aggs"][label] = new
    for key_tuple, bucket in groups.items():
        out: Row = {}
        first = bucket["_first_row"]
        for g, key_value in zip(plan.group_keys, key_tuple):
            label = _expression_label(g)
            out[label] = ctx.evaluator.evaluate(g, first)
        for fn, alias in plan.aggregates:
            label = alias or _expression_label(fn)
            out[label] = _finalize(fn, bucket["_aggs"].get(label), bucket["_rows"])
        if plan.having is None or _truthy(ctx.evaluator.evaluate(plan.having, out)):
            yield out


def sort_iter(plan: P.SortNode, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.input is None:
        return
    rows = list(execute(plan.input, ctx))
    rows.sort(
        key=lambda r: tuple(
            (_sort_key(ctx.evaluator.evaluate(expr, r)), -1 if desc else 1)
            for expr, desc in plan.order
        )
    )
    yield from rows


def limit_iter(plan: P.LimitNode, ctx: ExecutionContext) -> Iterator[Row]:
    if plan.input is None:
        return
    limit_value = _const(plan.limit, ctx)
    offset_value = _const(plan.offset, ctx) or 0
    yielded = 0
    skipped = 0
    for row in execute(plan.input, ctx):
        if skipped < offset_value:
            skipped += 1
            continue
        if limit_value is not None and yielded >= limit_value:
            return
        yielded += 1
        yield row



def _truthy(value: Value) -> bool:
    return value.is_true


def _hash_value(value: Value) -> Any:
    if value.is_null:
        return None
    return value.payload


def _sort_key(value: Value) -> Any:
    if value.is_null:
        return ()
    return (1, value.payload)


def _expression_label(expr: A.Expr) -> str:
    if isinstance(expr, A.ColumnRef):
        return expr.name
    if isinstance(expr, A.Literal):
        return repr(expr.value)
    if isinstance(expr, A.FunctionCall):
        return f"{expr.name.lower()}(...)"
    if isinstance(expr, A.Star):
        return "*"
    return type(expr).__name__


def _qualify(row: Row, alias: str) -> Row:
    out: Row = {}
    for k, v in row.items():
        out[k] = v
        out[f"{alias}.{k}"] = v
    return out


def _const(expr: A.Expr | None, ctx: ExecutionContext) -> int | None:
    if expr is None:
        return None
    value = ctx.evaluator.evaluate(expr, {})
    if value.is_null:
        return None
    return int(value.payload)


def _accumulate(
    fn: A.FunctionCall, current: Any, row: Row, evaluator: Evaluator
) -> Any:
    name = fn.name.upper()
    if name == "COUNT":
        if fn.is_star:
            return (current or 0) + 1
        v = evaluator.evaluate(fn.args[0], row)
        if v.is_null:
            return current or 0
        return (current or 0) + 1
    if name == "SUM":
        v = evaluator.evaluate(fn.args[0], row)
        if v.is_null:
            return current
        return (current or 0) + v.payload
    if name == "AVG":
        v = evaluator.evaluate(fn.args[0], row)
        if v.is_null:
            return current
        cur_sum, cur_count = (current or (0, 0))
        return (cur_sum + v.payload, cur_count + 1)
    if name == "MIN":
        v = evaluator.evaluate(fn.args[0], row)
        if v.is_null:
            return current
        if current is None or v.payload < current:
            return v.payload
        return current
    if name == "MAX":
        v = evaluator.evaluate(fn.args[0], row)
        if v.is_null:
            return current
        if current is None or v.payload > current:
            return v.payload
        return current
    raise ExecutionError(f"unsupported aggregate: {name}")


def _finalize(fn: A.FunctionCall, current: Any, total_rows: int) -> Value:
    name = fn.name.upper()
    if name == "AVG" and isinstance(current, tuple):
        cur_sum, cur_count = current
        if cur_count == 0:
            return Value.null()
        return Value.of(cur_sum / cur_count)
    if name == "COUNT":
        return Value.of(int(current or 0))
    if current is None:
        return Value.null()
    return Value.of(current)
