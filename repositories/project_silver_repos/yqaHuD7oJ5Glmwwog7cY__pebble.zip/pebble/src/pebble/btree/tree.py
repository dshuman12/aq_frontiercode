from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Iterator

from pebble.btree.node import (
    NODE_FLAG_LEAF,
    BtreeEntry,
    BtreeNode,
    pack_child,
)
from pebble.buffer.pool import BufferPool
from pebble.constants import (
    BTREE_INTERNAL_KIND,
    BTREE_LEAF_KIND,
    INVALID_PAGE_ID,
    MAX_KEY_SIZE,
    PAGE_HEADER_SIZE,
    PAGE_SIZE,
)
from pebble.errors import BtreeError, BtreeKeyTooLarge
from pebble.storage.heap import TupleId

log = logging.getLogger(__name__)


@dataclass
class BtreeStats:
    height: int = 0
    leaf_count: int = 0
    internal_count: int = 0
    entry_count: int = 0


class Btree:
    """A persistent B+tree backed by the buffer pool.

    Construction does not perform any IO; call :meth:`bootstrap` to
    create an empty root, or :meth:`open_at` to load an existing one.
    """

    def __init__(self, pool: BufferPool, *, root_page_id: int) -> None:
        self.pool = pool
        self.root_page_id = root_page_id
        self._lock = threading.RLock()

    @classmethod
    def bootstrap(cls, pool: BufferPool) -> "Btree":
        """Allocate a fresh empty leaf as the root."""
        with pool.pin_new() as page:
            node = BtreeNode(page_id=page.header.page_id, leaf=True)
            node.is_root = True
            page.header.kind = BTREE_LEAF_KIND
            node.serialize(page.buf)
            page.mark_dirty()
            root_id = page.header.page_id
        return cls(pool=pool, root_page_id=root_id)

    @classmethod
    def open_at(cls, pool: BufferPool, root_page_id: int) -> "Btree":
        return cls(pool=pool, root_page_id=root_page_id)

    def insert(self, key: bytes, value: TupleId) -> None:
        if len(key) > MAX_KEY_SIZE:
            raise BtreeKeyTooLarge(f"key length {len(key)} exceeds {MAX_KEY_SIZE}")
        with self._lock:
            split = self._insert_recursive(self.root_page_id, key, value.pack())
            if split is not None:
                self._grow_root(split)

    def delete(self, key: bytes) -> bool:
        with self._lock:
            return self._delete_recursive(self.root_page_id, key)

    def search(self, key: bytes) -> TupleId | None:
        with self._lock:
            page_id = self._descend_to_leaf(key)
            with self.pool.pin(page_id) as page:
                node = self._load(page_id)
                idx = node.find(key)
                if idx < len(node.entries) and node.entries[idx].key == key:
                    return TupleId.unpack(node.entries[idx].value)
        return None

    def range(
        self,
        *,
        start: bytes | None = None,
        end: bytes | None = None,
        inclusive: bool = True,
    ) -> Iterator[tuple[bytes, TupleId]]:
        """Yield (key, tid) pairs in key order over ``[start, end]``."""
        with self._lock:
            if start is None:
                page_id = self._leftmost_leaf()
            else:
                page_id = self._descend_to_leaf(start)
            while page_id != INVALID_PAGE_ID:
                node = self._load(page_id)
                for entry in node.entries:
                    if start is not None and entry.key < start:
                        continue
                    if end is not None:
                        if inclusive:
                            if entry.key > end:
                                return
                        else:
                            if entry.key >= end:
                                return
                    yield entry.key, TupleId.unpack(entry.value)
                page_id = node.next_leaf

    def stats(self) -> BtreeStats:
        leaves = 0
        internals = 0
        entries = 0
        height = 1
        # Walk down the leftmost path to estimate height.
        cursor = self.root_page_id
        while True:
            node = self._load(cursor)
            if node.is_leaf:
                break
            height += 1
            cursor = node.entries[0].value if node.entries else node.rightmost_child
            cursor = int.from_bytes(cursor, "little") if isinstance(cursor, bytes) else cursor
        # Count leaves via next-pointer walk.
        cursor = self._leftmost_leaf()
        while cursor != INVALID_PAGE_ID:
            node = self._load(cursor)
            leaves += 1
            entries += len(node.entries)
            cursor = node.next_leaf
        return BtreeStats(height=height, leaf_count=leaves, internal_count=internals,
                          entry_count=entries)

    @dataclass
    class _Split:
        sep_key: bytes
        right_page_id: int

    def _insert_recursive(self, page_id: int, key: bytes, value: bytes) -> "Btree._Split | None":
        node = self._load(page_id)
        if node.is_leaf:
            entry = BtreeEntry(key=key, value=value)
            if node.fits(entry):
                node.insert(entry)
                self._save(node)
                return None
            return self._split_leaf(node, entry)
        # Internal node: descend
        child_pid = node.child_for(key)
        split = self._insert_recursive(child_pid, key, value)
        if split is None:
            return None
        # Insert separator into this node.
        new_entry = BtreeEntry(key=split.sep_key, value=pack_child(split.right_page_id))
        if node.fits(new_entry):
            node.insert(new_entry)
            self._save(node)
            return None
        return self._split_internal(node, new_entry)

    def _split_leaf(self, node: BtreeNode, entry: BtreeEntry) -> "Btree._Split":
        # Compose, split halfway, allocate new sibling.
        node.insert(entry)
        mid = len(node.entries) // 2
        right_entries = node.entries[mid:]
        node.entries = node.entries[:mid]
        with self.pool.pin_new() as new_page:
            new_page.header.kind = BTREE_LEAF_KIND
            right = BtreeNode(page_id=new_page.header.page_id, leaf=True)
            right.entries = right_entries
            right.next_leaf = node.next_leaf
            right.prev_leaf = node.page_id
            node.next_leaf = right.page_id
            right.serialize(new_page.buf)
            new_page.mark_dirty()
            new_pid = right.page_id
        # If there was a right sibling before, fix its prev pointer.
        if right.next_leaf != INVALID_PAGE_ID:
            sibling = self._load(right.next_leaf)
            sibling.prev_leaf = new_pid
            self._save(sibling)
        self._save(node)
        return Btree._Split(sep_key=right.entries[0].key, right_page_id=new_pid)

    def _split_internal(self, node: BtreeNode, new_entry: BtreeEntry) -> "Btree._Split":
        node.insert(new_entry)
        mid = len(node.entries) // 2
        sep = node.entries[mid]
        right_entries = node.entries[mid + 1:]
        # The separator becomes the new internal's leftmost subtree key.
        with self.pool.pin_new() as new_page:
            new_page.header.kind = BTREE_INTERNAL_KIND
            right = BtreeNode(page_id=new_page.header.page_id, leaf=False)
            right.entries = right_entries
            right.rightmost_child = node.rightmost_child
            node.rightmost_child = int.from_bytes(sep.value, "little")
            right.serialize(new_page.buf)
            new_page.mark_dirty()
            new_pid = right.page_id
        node.entries = node.entries[:mid]
        self._save(node)
        return Btree._Split(sep_key=sep.key, right_page_id=new_pid)

    def _grow_root(self, split: "Btree._Split") -> None:
        old_root_id = self.root_page_id
        with self.pool.pin_new() as page:
            page.header.kind = BTREE_INTERNAL_KIND
            new_root = BtreeNode(page_id=page.header.page_id, leaf=False)
            new_root.is_root = True
            new_root.entries = [
                BtreeEntry(key=split.sep_key, value=pack_child(old_root_id)),
            ]
            new_root.rightmost_child = split.right_page_id
            new_root.serialize(page.buf)
            page.mark_dirty()
            new_root_id = page.header.page_id
        # Old root loses its root flag.
        old = self._load(old_root_id)
        old.is_root = False
        self._save(old)
        self.root_page_id = new_root_id

    def _delete_recursive(self, page_id: int, key: bytes) -> bool:
        node = self._load(page_id)
        if node.is_leaf:
            removed = node.delete(key)
            if removed:
                self._save(node)
            return removed
        child_pid = node.child_for(key)
        removed = self._delete_recursive(child_pid, key)
        # Underflow handling is intentionally left to a follow-up pass:
        # we mark the parent dirty and rely on a periodic compaction job
        # to merge sparse siblings. Real implementations would trigger
        # merge here.
        return removed

    def _descend_to_leaf(self, key: bytes) -> int:
        page_id = self.root_page_id
        while True:
            node = self._load(page_id)
            if node.is_leaf:
                return page_id
            page_id = node.child_for(key)

    def _leftmost_leaf(self) -> int:
        page_id = self.root_page_id
        while True:
            node = self._load(page_id)
            if node.is_leaf:
                return page_id
            if not node.entries:
                page_id = node.rightmost_child
            else:
                page_id = int.from_bytes(node.entries[0].value, "little")

    def _load(self, page_id: int) -> BtreeNode:
        with self.pool.pin(page_id) as page:
            return BtreeNode.deserialize(page_id, bytes(page.buf))

    def _save(self, node: BtreeNode) -> None:
        with self.pool.pin(node.page_id) as page:
            node.serialize(page.buf)
            page.mark_dirty()
