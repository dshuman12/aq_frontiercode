from __future__ import annotations

# Node layout (after the standard page header):
#   [u8  flags]       0x01=leaf, 0x02=root
#   [u8  reserved]
#   [u16 key_count]
#   [u32 next_leaf]   leaves only; INVALID otherwise
#   [u32 prev_leaf]   doubly-linked for reverse scan
#   N entries: [u16 key_len][key bytes][value bytes]
#   Internal nodes have a trailing "rightmost child page id" (u32).

import struct
from dataclasses import dataclass

from pebble.constants import (
    BTREE_INTERNAL_KIND,
    BTREE_LEAF_KIND,
    INVALID_PAGE_ID,
    PAGE_HEADER_SIZE,
    PAGE_SIZE,
)
from pebble.errors import BtreeError, BtreeKeyTooLarge

NODE_FLAG_LEAF = 0x01
NODE_FLAG_ROOT = 0x02

NODE_HEADER = struct.Struct("<BBHII")  # flags, _, key_count, next, prev
ENTRY_LEN = struct.Struct("<H")        # key length prefix

VALUE_SIZE = 6  # TupleId pack size (page_id u32 + slot u16)


@dataclass
class BtreeEntry:
    key: bytes
    value: bytes  # TupleId.pack() in leaves; child page id (u32) in internal nodes

    @property
    def total_size(self) -> int:
        return ENTRY_LEN.size + len(self.key) + len(self.value)


class BtreeNode:
    """In-memory representation of a btree node."""

    def __init__(self, *, page_id: int, leaf: bool = True) -> None:
        self.page_id = page_id
        self.is_leaf = leaf
        self.is_root = False
        self.next_leaf = INVALID_PAGE_ID
        self.prev_leaf = INVALID_PAGE_ID
        self.entries: list[BtreeEntry] = []
        self.rightmost_child: int = INVALID_PAGE_ID  # internal nodes only

    @property
    def used_bytes(self) -> int:
        body = sum(entry.total_size for entry in self.entries)
        body += NODE_HEADER.size
        if not self.is_leaf:
            body += 4  # rightmost child
        return body

    def free_bytes(self) -> int:
        return PAGE_SIZE - PAGE_HEADER_SIZE - self.used_bytes

    def fits(self, entry: BtreeEntry) -> bool:
        return entry.total_size <= self.free_bytes()

    def find(self, key: bytes) -> int:
        """Return index of first entry with ``entry.key >= key``.

        Returns ``len(entries)`` if every key is smaller -- callers
        decide whether that means "insert at end" or "follow rightmost
        child".
        """
        lo, hi = 0, len(self.entries)
        while lo < hi:
            mid = (lo + hi) // 2
            if self.entries[mid].key < key:
                lo = mid + 1
            else:
                hi = mid
        return lo

    def child_for(self, key: bytes) -> int:
        """For internal nodes: page id of the child that may contain ``key``."""
        if self.is_leaf:
            raise BtreeError("child_for called on leaf node")
        idx = self.find(key)
        if idx == len(self.entries):
            return self.rightmost_child
        return _u32(self.entries[idx].value)

    def insert(self, entry: BtreeEntry) -> None:
        if entry.total_size > PAGE_SIZE - PAGE_HEADER_SIZE - NODE_HEADER.size - 8:
            raise BtreeKeyTooLarge(
                f"entry too large for a btree node: {entry.total_size} bytes"
            )
        idx = self.find(entry.key)
        if idx < len(self.entries) and self.entries[idx].key == entry.key and self.is_leaf:
            # Replace value (unique-key semantics for leaves).
            self.entries[idx] = entry
            return
        self.entries.insert(idx, entry)

    def delete(self, key: bytes) -> bool:
        idx = self.find(key)
        if idx >= len(self.entries) or self.entries[idx].key != key:
            return False
        self.entries.pop(idx)
        return True

    def serialize(self, into: bytearray) -> None:
        """Write the node into ``into`` (a page-sized bytearray).

        We write past the page header, leaving the header to be filled
        in by the page writer.
        """
        flags = 0
        if self.is_leaf:
            flags |= NODE_FLAG_LEAF
        if self.is_root:
            flags |= NODE_FLAG_ROOT
        cursor = PAGE_HEADER_SIZE
        NODE_HEADER.pack_into(
            into, cursor,
            flags, 0, len(self.entries), self.next_leaf, self.prev_leaf,
        )
        cursor += NODE_HEADER.size
        for entry in self.entries:
            ENTRY_LEN.pack_into(into, cursor, len(entry.key))
            cursor += ENTRY_LEN.size
            into[cursor: cursor + len(entry.key)] = entry.key
            cursor += len(entry.key)
            into[cursor: cursor + len(entry.value)] = entry.value
            cursor += len(entry.value)
        if not self.is_leaf:
            into[cursor: cursor + 4] = self.rightmost_child.to_bytes(4, "little")
            cursor += 4
        # Zero the remainder (so freezing produces a deterministic CRC).
        for i in range(cursor, len(into)):
            into[i] = 0

    @classmethod
    def deserialize(cls, page_id: int, raw: bytes, *, leaf_value_size: int = VALUE_SIZE) -> "BtreeNode":
        cursor = PAGE_HEADER_SIZE
        flags, _r, key_count, next_leaf, prev_leaf = NODE_HEADER.unpack_from(raw, cursor)
        cursor += NODE_HEADER.size
        node = cls(page_id=page_id, leaf=bool(flags & NODE_FLAG_LEAF))
        node.is_root = bool(flags & NODE_FLAG_ROOT)
        node.next_leaf = next_leaf
        node.prev_leaf = prev_leaf
        for _ in range(key_count):
            (key_len,) = ENTRY_LEN.unpack_from(raw, cursor)
            cursor += ENTRY_LEN.size
            key = bytes(raw[cursor: cursor + key_len])
            cursor += key_len
            value_size = leaf_value_size if node.is_leaf else 4
            value = bytes(raw[cursor: cursor + value_size])
            cursor += value_size
            node.entries.append(BtreeEntry(key=key, value=value))
        if not node.is_leaf:
            node.rightmost_child = int.from_bytes(raw[cursor: cursor + 4], "little")
        return node


def _u32(b: bytes) -> int:
    return int.from_bytes(b, "little")


def pack_child(page_id: int) -> bytes:
    return page_id.to_bytes(4, "little")
