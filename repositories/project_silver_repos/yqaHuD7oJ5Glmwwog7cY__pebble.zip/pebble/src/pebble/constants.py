from __future__ import annotations

from typing import Final

PAGE_SIZE: Final[int] = 8192          # bytes
PAGE_HEADER_SIZE: Final[int] = 32     # bytes
SLOT_SIZE: Final[int] = 4             # bytes per slot entry (offset+length)

PAGE_MAGIC: Final[bytes] = b"PBL1"    # first 4 bytes of every page
HEAP_PAGE_KIND: Final[int] = 0x01
BTREE_LEAF_KIND: Final[int] = 0x02
BTREE_INTERNAL_KIND: Final[int] = 0x03
META_PAGE_KIND: Final[int] = 0x04
FSM_PAGE_KIND: Final[int] = 0x05

# Tuple flags
TUPLE_FLAG_DELETED: Final[int] = 0x01
TUPLE_FLAG_NULL_BITMAP: Final[int] = 0x02
TUPLE_FLAG_HAS_OID: Final[int] = 0x04

INVALID_PAGE_ID: Final[int] = 0xFFFFFFFF

WAL_MAGIC: Final[bytes] = b"PBLLOG01"
WAL_MAX_RECORD_SIZE: Final[int] = 16 * 1024 * 1024  # 16 MiB
WAL_DEFAULT_SEGMENT_SIZE: Final[int] = 16 * 1024 * 1024
LSN_INVALID: Final[int] = 0

LSN_BYTES: Final[int] = 8

# Record types (uint8)
WAL_REC_BEGIN: Final[int] = 0x01
WAL_REC_COMMIT: Final[int] = 0x02
WAL_REC_ABORT: Final[int] = 0x03
WAL_REC_INSERT: Final[int] = 0x10
WAL_REC_UPDATE: Final[int] = 0x11
WAL_REC_DELETE: Final[int] = 0x12
WAL_REC_BTREE_SPLIT: Final[int] = 0x20
WAL_REC_BTREE_MERGE: Final[int] = 0x21
WAL_REC_CHECKPOINT_BEGIN: Final[int] = 0x30
WAL_REC_CHECKPOINT_END: Final[int] = 0x31
WAL_REC_PAGE_ALLOC: Final[int] = 0x40
WAL_REC_PAGE_FREE: Final[int] = 0x41

INVALID_TXN_ID: Final[int] = 0
BOOTSTRAP_TXN_ID: Final[int] = 1
FIRST_NORMAL_TXN_ID: Final[int] = 100

DEFAULT_BUFFER_POOL_PAGES: Final[int] = 1024  # 8 MiB at 8 KiB pages
DEFAULT_RING_BUFFER_PAGES: Final[int] = 32

CATALOG_TABLES_OID: Final[int] = 1000
CATALOG_COLUMNS_OID: Final[int] = 1001
CATALOG_INDEXES_OID: Final[int] = 1002
CATALOG_STATS_OID: Final[int] = 1003
FIRST_USER_OID: Final[int] = 16384

MAX_IDENTIFIER_LEN: Final[int] = 63
MAX_TABLE_NAME_LEN: Final[int] = 63
MAX_COLUMN_NAME_LEN: Final[int] = 63
MAX_INDEX_NAME_LEN: Final[int] = 63
MAX_COLUMNS_PER_TABLE: Final[int] = 1600

PROTOCOL_VERSION: Final[int] = 1
DEFAULT_PORT: Final[int] = 5440
DEFAULT_HOST: Final[str] = "127.0.0.1"

MSG_KIND_QUERY: Final[bytes] = b"Q"
MSG_KIND_AUTH: Final[bytes] = b"A"
MSG_KIND_ROW: Final[bytes] = b"R"
MSG_KIND_COMPLETE: Final[bytes] = b"C"
MSG_KIND_ERROR: Final[bytes] = b"E"
MSG_KIND_NOTICE: Final[bytes] = b"N"
MSG_KIND_CANCEL: Final[bytes] = b"X"

MAX_QUERY_LEN: Final[int] = 1024 * 1024  # 1 MiB
MAX_TUPLE_SIZE: Final[int] = PAGE_SIZE - PAGE_HEADER_SIZE - SLOT_SIZE
MAX_KEY_SIZE: Final[int] = 2048
MAX_BTREE_FANOUT: Final[int] = 256
DEFAULT_STATEMENT_TIMEOUT_MS: Final[int] = 60_000
DEFAULT_LOCK_TIMEOUT_MS: Final[int] = 5_000
