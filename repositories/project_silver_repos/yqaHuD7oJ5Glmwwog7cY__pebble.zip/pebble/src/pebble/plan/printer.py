from __future__ import annotations

from typing import Any

from pebble.plan import logical as L
from pebble.plan import physical as P
from pebble.plan.logical_printer import render as render_logical
from pebble.plan.physical import render as render_physical


def render(plan: Any) -> str:
    if isinstance(plan, L.LogicalPlan):
        return render_logical(plan)
    if isinstance(plan, P.PhysicalPlan):
        return render_physical(plan)
    raise TypeError(f"unrecognised plan type: {type(plan).__name__}")


__all__ = ["render", "render_logical", "render_physical"]
