from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from pebble.parser import ast as A


@dataclass
class LogicalPlan:
    """Base node."""
    children: list["LogicalPlan"] = field(default_factory=list, init=False)


@dataclass
class Scan(LogicalPlan):
    table: str = ""
    alias: str | None = None
    projected_columns: tuple[str, ...] = ()  # empty = all columns


@dataclass
class Filter(LogicalPlan):
    input: "LogicalPlan | None" = None
    predicate: A.Expr | None = None


@dataclass
class Project(LogicalPlan):
    input: "LogicalPlan | None" = None
    projections: list[tuple[A.Expr, str | None]] = field(default_factory=list)
    distinct: bool = False


@dataclass
class Join(LogicalPlan):
    left: "LogicalPlan | None" = None
    right: "LogicalPlan | None" = None
    kind: str = "inner"
    predicate: A.Expr | None = None
    using: tuple[str, ...] | None = None


@dataclass
class Aggregate(LogicalPlan):
    input: "LogicalPlan | None" = None
    group_keys: list[A.Expr] = field(default_factory=list)
    aggregates: list[tuple[A.FunctionCall, str | None]] = field(default_factory=list)
    having: A.Expr | None = None


@dataclass
class Sort(LogicalPlan):
    input: "LogicalPlan | None" = None
    order: list[tuple[A.Expr, bool]] = field(default_factory=list)  # (expr, desc)


@dataclass
class Limit(LogicalPlan):
    input: "LogicalPlan | None" = None
    limit: A.Expr | None = None
    offset: A.Expr | None = None


@dataclass
class SetOp(LogicalPlan):
    left: "LogicalPlan | None" = None
    right: "LogicalPlan | None" = None
    op: str = "union_all"


@dataclass
class Insert(LogicalPlan):
    table: str = ""
    columns: tuple[str, ...] = ()
    rows: list[list[A.Expr]] = field(default_factory=list)
    select: "LogicalPlan | None" = None


@dataclass
class Update(LogicalPlan):
    table: str = ""
    assignments: list[tuple[str, A.Expr]] = field(default_factory=list)
    predicate: A.Expr | None = None


@dataclass
class Delete(LogicalPlan):
    table: str = ""
    predicate: A.Expr | None = None
