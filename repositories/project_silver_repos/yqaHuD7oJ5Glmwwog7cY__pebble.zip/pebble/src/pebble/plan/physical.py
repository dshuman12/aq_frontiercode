from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from pebble.parser import ast as A
from pebble.plan.logical import LogicalPlan


@dataclass
class PhysicalPlan:
    estimated_rows: float = 0.0
    estimated_cost: float = 0.0
    children: list["PhysicalPlan"] = field(default_factory=list, init=False)


@dataclass
class SeqScan(PhysicalPlan):
    table: str = ""
    alias: str | None = None
    predicate: A.Expr | None = None
    projected_columns: tuple[str, ...] = ()


@dataclass
class IndexScan(PhysicalPlan):
    table: str = ""
    index_name: str = ""
    lower: A.Expr | None = None
    upper: A.Expr | None = None
    inclusive_lower: bool = True
    inclusive_upper: bool = True
    predicate: A.Expr | None = None  # residual after index probe


@dataclass
class FilterNode(PhysicalPlan):
    input: "PhysicalPlan | None" = None
    predicate: A.Expr | None = None


@dataclass
class ProjectNode(PhysicalPlan):
    input: "PhysicalPlan | None" = None
    projections: list[tuple[A.Expr, str | None]] = field(default_factory=list)
    distinct: bool = False


@dataclass
class NestedLoopJoin(PhysicalPlan):
    outer: "PhysicalPlan | None" = None
    inner: "PhysicalPlan | None" = None
    predicate: A.Expr | None = None
    join_kind: str = "inner"


@dataclass
class HashJoin(PhysicalPlan):
    build: "PhysicalPlan | None" = None
    probe: "PhysicalPlan | None" = None
    build_keys: list[A.Expr] = field(default_factory=list)
    probe_keys: list[A.Expr] = field(default_factory=list)
    residual: A.Expr | None = None
    join_kind: str = "inner"


@dataclass
class MergeJoin(PhysicalPlan):
    left: "PhysicalPlan | None" = None
    right: "PhysicalPlan | None" = None
    left_keys: list[A.Expr] = field(default_factory=list)
    right_keys: list[A.Expr] = field(default_factory=list)
    join_kind: str = "inner"


@dataclass
class HashAggregate(PhysicalPlan):
    input: "PhysicalPlan | None" = None
    group_keys: list[A.Expr] = field(default_factory=list)
    aggregates: list[tuple[A.FunctionCall, str | None]] = field(default_factory=list)
    having: A.Expr | None = None


@dataclass
class SortNode(PhysicalPlan):
    input: "PhysicalPlan | None" = None
    order: list[tuple[A.Expr, bool]] = field(default_factory=list)


@dataclass
class LimitNode(PhysicalPlan):
    input: "PhysicalPlan | None" = None
    limit: A.Expr | None = None
    offset: A.Expr | None = None


@dataclass
class InsertNode(PhysicalPlan):
    table: str = ""
    columns: tuple[str, ...] = ()
    rows: list[list[A.Expr]] = field(default_factory=list)
    source: "PhysicalPlan | None" = None


@dataclass
class UpdateNode(PhysicalPlan):
    table: str = ""
    assignments: list[tuple[str, A.Expr]] = field(default_factory=list)
    predicate: A.Expr | None = None


@dataclass
class DeleteNode(PhysicalPlan):
    table: str = ""
    predicate: A.Expr | None = None


def render(plan: PhysicalPlan, indent: int = 0) -> str:
    """Render a physical plan as an indented tree (for EXPLAIN)."""
    name = type(plan).__name__
    out = ["  " * indent + f"{name}  rows={plan.estimated_rows:.0f} cost={plan.estimated_cost:.2f}"]
    for child in _children(plan):
        if child is not None:
            out.append(render(child, indent + 1))
    return "\n".join(out)


def _children(plan: PhysicalPlan) -> list[PhysicalPlan | None]:
    out: list[PhysicalPlan | None] = []
    for attr in ("input", "outer", "inner", "build", "probe", "left", "right", "source"):
        if hasattr(plan, attr):
            out.append(getattr(plan, attr))
    return out
