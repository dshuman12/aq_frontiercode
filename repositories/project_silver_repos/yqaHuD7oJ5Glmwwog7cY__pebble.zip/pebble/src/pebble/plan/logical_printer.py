from __future__ import annotations

from typing import Sequence

from pebble.parser import ast as A
from pebble.parser.printer import render as render_expr
from pebble.plan import logical as L


def render(plan: L.LogicalPlan, indent: int = 0) -> str:
    pad = "  " * indent
    if isinstance(plan, L.Scan):
        proj = (
            "  projected=" + ",".join(plan.projected_columns)
            if plan.projected_columns else ""
        )
        return f"{pad}Scan(table={plan.table}{proj})"
    if isinstance(plan, L.Filter):
        head = f"{pad}Filter({_short_expr(plan.predicate)})"
        return _join(head, plan.input, indent)
    if isinstance(plan, L.Project):
        labels = ", ".join(_proj_label(p, n) for p, n in plan.projections)
        head = f"{pad}Project({labels}{', distinct' if plan.distinct else ''})"
        return _join(head, plan.input, indent)
    if isinstance(plan, L.Join):
        head = f"{pad}Join({plan.kind}, {_short_expr(plan.predicate)})"
        return "\n".join(filter(None, [
            head,
            render(plan.left, indent + 1) if plan.left else "",
            render(plan.right, indent + 1) if plan.right else "",
        ]))
    if isinstance(plan, L.Aggregate):
        groups = ", ".join(_short_expr(g) for g in plan.group_keys) or "<none>"
        aggs = ", ".join(_short_expr(fn) for fn, _ in plan.aggregates)
        head = f"{pad}Aggregate(group=[{groups}], aggregates=[{aggs}])"
        return _join(head, plan.input, indent)
    if isinstance(plan, L.Sort):
        order = ", ".join(
            f"{_short_expr(e)}{' DESC' if d else ''}" for e, d in plan.order
        )
        head = f"{pad}Sort({order})"
        return _join(head, plan.input, indent)
    if isinstance(plan, L.Limit):
        head = f"{pad}Limit({_short_expr(plan.limit)}, offset={_short_expr(plan.offset)})"
        return _join(head, plan.input, indent)
    if isinstance(plan, L.SetOp):
        head = f"{pad}SetOp({plan.op})"
        return "\n".join(filter(None, [
            head,
            render(plan.left, indent + 1) if plan.left else "",
            render(plan.right, indent + 1) if plan.right else "",
        ]))
    if isinstance(plan, L.Insert):
        return f"{pad}Insert(table={plan.table}, rows={len(plan.rows)})"
    if isinstance(plan, L.Update):
        return f"{pad}Update(table={plan.table})"
    if isinstance(plan, L.Delete):
        return f"{pad}Delete(table={plan.table})"
    return f"{pad}{type(plan).__name__}"


def _join(head: str, child: L.LogicalPlan | None, indent: int) -> str:
    if child is None:
        return head
    return head + "\n" + render(child, indent + 1)


def _short_expr(expr: A.Expr | None) -> str:
    if expr is None:
        return "<none>"
    rendered = render_expr(expr)
    return rendered[:60] + ("..." if len(rendered) > 60 else "")


def _proj_label(expr: A.Expr, alias: str | None) -> str:
    text = _short_expr(expr)
    return f"{text} AS {alias}" if alias else text
