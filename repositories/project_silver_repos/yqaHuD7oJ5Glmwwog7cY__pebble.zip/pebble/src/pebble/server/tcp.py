from __future__ import annotations

import logging
import socket
import struct
import threading
from typing import Iterable

from pebble.config import Config, get_config
from pebble.constants import (
    MSG_KIND_CANCEL,
    MSG_KIND_QUERY,
)
from pebble.errors import NetworkError, PebbleError
from pebble.protocol.frame import Frame, _HEADER, encode
from pebble.server.engine import Engine
from pebble.types.value import Value

log = logging.getLogger(__name__)


class TcpServer:
    def __init__(self, *, engine: Engine, config: Config | None = None) -> None:
        self.engine = engine
        self.config = config or get_config()
        self._sock: socket.socket | None = None
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []

    def serve_forever(self) -> None:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.config.server.host, self.config.server.port))
        self._sock.listen(self.config.server.max_connections)
        log.info(
            "pebble listening on %s:%d",
            self.config.server.host, self.config.server.port,
        )
        try:
            while not self._stop.is_set():
                try:
                    conn, addr = self._sock.accept()
                except OSError:
                    return
                t = threading.Thread(target=self._handle, args=(conn, addr), daemon=True)
                t.start()
                self._threads.append(t)
        finally:
            self._sock.close()

    def stop(self) -> None:
        self._stop.set()
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()

    def _handle(self, conn: socket.socket, addr: tuple[str, int]) -> None:
        log.info("connection from %s:%d", *addr)
        try:
            buf = b""
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buf += chunk
                while True:
                    if len(buf) < _HEADER.size:
                        break
                    kind, length = _HEADER.unpack_from(buf, 0)
                    if len(buf) < _HEADER.size + length:
                        break
                    payload = buf[_HEADER.size: _HEADER.size + length]
                    buf = buf[_HEADER.size + length:]
                    self._dispatch(conn, Frame(kind=kind, payload=payload))
        except (OSError, NetworkError) as exc:
            log.warning("client error: %s", exc)
        finally:
            conn.close()

    def _dispatch(self, conn: socket.socket, frame: Frame) -> None:
        if frame.kind == MSG_KIND_CANCEL:
            return
        if frame.kind != MSG_KIND_QUERY:
            self._send(conn, Frame.error("PE6000", f"unsupported frame kind: {frame.kind!r}"))
            return
        sql = frame.payload.decode("utf-8")
        try:
            result = self.engine.execute_sql(sql)
        except PebbleError as exc:
            self._send(conn, Frame.error(exc.code, str(exc)))
            return
        for row in result.rows:
            self._send(conn, Frame.row([_to_jsonable(v) for v in row]))
        self._send(conn, Frame.complete(result.tag, result.rows_affected or result.row_count))

    def _send(self, conn: socket.socket, frame: Frame) -> None:
        try:
            conn.sendall(encode(frame))
        except OSError as exc:
            log.warning("send failed: %s", exc)


def _to_jsonable(value: Value):
    if value.is_null:
        return None
    if isinstance(value.payload, bytes):
        return {"__blob__": value.payload.hex()}
    return value.payload
