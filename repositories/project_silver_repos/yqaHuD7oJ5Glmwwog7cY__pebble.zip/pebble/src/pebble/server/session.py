from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from pebble.txn.manager import TxnState


@dataclass
class PreparedStatement:
    """A parsed + planned statement keyed by SQL text."""

    sql: str
    plan: Any
    use_count: int = 0


class Session:
    """Mutable per-connection state."""

    def __init__(self, *, isolation: str = "snapshot") -> None:
        self.isolation = isolation
        self.txn: TxnState | None = None
        self.prepared: dict[str, PreparedStatement] = {}
        self._lock = threading.Lock()
        self.cancel_requested = False

    def begin(self, txn: TxnState) -> None:
        with self._lock:
            if self.txn is not None:
                raise RuntimeError("session already has an open transaction")
            self.txn = txn

    def commit(self) -> None:
        with self._lock:
            self.txn = None

    def abort(self) -> None:
        with self._lock:
            self.txn = None

    def cache_plan(self, sql: str, plan: Any) -> None:
        with self._lock:
            self.prepared[sql] = PreparedStatement(sql=sql, plan=plan)

    def lookup_plan(self, sql: str) -> Any | None:
        with self._lock:
            cached = self.prepared.get(sql)
            if cached is None:
                return None
            cached.use_count += 1
            return cached.plan

    def evict_plan(self, sql: str) -> None:
        with self._lock:
            self.prepared.pop(sql, None)

    def cache_size(self) -> int:
        with self._lock:
            return len(self.prepared)

    def request_cancel(self) -> None:
        self.cancel_requested = True

    def consume_cancel(self) -> bool:
        if self.cancel_requested:
            self.cancel_requested = False
            return True
        return False
