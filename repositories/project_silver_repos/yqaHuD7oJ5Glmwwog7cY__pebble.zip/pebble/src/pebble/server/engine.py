from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Iterator

from pebble.catalog import Catalog, Column
from pebble.config import Config, get_config
from pebble.errors import PebbleError, PlanError
from pebble.exec.iterators import ExecutionContext, execute
from pebble.lock.manager import LockManager
from pebble.optimizer import Builder
from pebble.parser import ast as A
from pebble.parser.parser import Parser
from pebble.plan import physical as P
from pebble.txn.manager import TxnManager, TxnState
from pebble.types import SqlType, parse_type
from pebble.types.value import Value
from pebble.wal.writer import WalWriter

log = logging.getLogger(__name__)


@dataclass
class QueryResult:
    columns: list[str]
    rows: list[list[Value]]
    rows_affected: int = 0
    tag: str = ""
    plan: P.PhysicalPlan | None = None

    @property
    def row_count(self) -> int:
        return len(self.rows)


class Engine:
    """The top-level entry point.

    The engine is single-process; concurrent statements within the
    process run on the same Python interpreter and share the catalog
    cache and lock table. For multi-process deployments, run the
    server.
    """

    def __init__(self, *, config: Config | None = None) -> None:
        self.config = config or get_config()
        self.catalog = Catalog()
        self.txn_manager = TxnManager()
        self.lock_manager = LockManager(timeout_ms=self.config.txn.lock_timeout_ms)
        self.exec_ctx = ExecutionContext(catalog=self.catalog)
        self.wal: WalWriter | None = None
        self._open: bool = False

    def open(self) -> None:
        if self._open:
            return
        os.makedirs(self.config.data_dir, exist_ok=True)
        wal_dir = os.path.join(self.config.data_dir, "wal")
        self.wal = WalWriter(
            wal_dir,
            segment_size=self.config.wal.segment_size,
            fsync=self.config.storage.fsync_on_commit,
        )
        self._open = True

    def close(self) -> None:
        if not self._open:
            return
        if self.wal is not None:
            self.wal.close()
            self.wal = None
        self._open = False

    def __enter__(self) -> "Engine":
        self.open()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def execute_sql(self, sql: str, *, txn: TxnState | None = None) -> QueryResult:
        stmt = Parser(sql).parse_one()
        return self.execute_stmt(stmt, txn=txn)

    def execute_stmt(self, stmt: A.Stmt, *, txn: TxnState | None = None) -> QueryResult:
        if isinstance(stmt, A.CreateTableStmt):
            return self._do_create_table(stmt)
        if isinstance(stmt, A.DropStmt):
            return self._do_drop(stmt)
        if isinstance(stmt, A.CreateIndexStmt):
            return self._do_create_index(stmt)
        if isinstance(stmt, A.TxnControlStmt):
            return self._do_txn_control(stmt)
        if isinstance(stmt, A.AnalyzeStmt):
            return self._do_analyze(stmt)
        if isinstance(stmt, A.VacuumStmt):
            return QueryResult(columns=[], rows=[], tag="VACUUM")
        if isinstance(stmt, A.ExplainStmt):
            return self._do_explain(stmt)
        builder = Builder(catalog=self.catalog, cfg=self.config.optimizer)
        plan = builder.build(stmt)
        if isinstance(stmt, (A.InsertStmt, A.UpdateStmt, A.DeleteStmt)):
            return self._do_dml(stmt, plan)
        # SELECT path
        rows: list[list[Value]] = []
        columns: list[str] = []
        for row in execute(plan, self.exec_ctx):
            if not columns:
                columns = list(row.keys())
            rows.append([row[c] for c in columns])
        return QueryResult(columns=columns, rows=rows, tag="SELECT", plan=plan)

    def _do_create_table(self, stmt: A.CreateTableStmt) -> QueryResult:
        if self.catalog.has_table(stmt.name):
            if stmt.if_not_exists:
                return QueryResult(columns=[], rows=[], tag="CREATE TABLE")
            from pebble.errors import DuplicateName

            raise DuplicateName(f"table {stmt.name!r} already exists")
        cols: list[Column] = []
        pk: set[str] = set(stmt.primary_key_columns)
        for i, c in enumerate(stmt.columns):
            ty = parse_type(
                c.type_name, length=c.type_length, scale=c.type_scale,
                nullable=c.nullable,
            )
            cols.append(
                Column(
                    name=c.name, type=ty, ordinal=i, nullable=c.nullable,
                    is_primary_key=c.primary_key or c.name in pk,
                )
            )
        self.catalog.create_table(name=stmt.name, columns=cols,
                                  primary_key=tuple(pk) if pk else ())
        return QueryResult(columns=[], rows=[], tag="CREATE TABLE")

    def _do_drop(self, stmt: A.DropStmt) -> QueryResult:
        if stmt.kind == "table":
            try:
                self.catalog.drop_table(stmt.name)
            except PebbleError:
                if not stmt.if_exists:
                    raise
            self.exec_ctx.rows.pop(stmt.name, None)
            return QueryResult(columns=[], rows=[], tag="DROP TABLE")
        if stmt.kind == "index":
            for tbl in self.catalog.tables():
                try:
                    self.catalog.drop_index(tbl.name, stmt.name)
                    return QueryResult(columns=[], rows=[], tag="DROP INDEX")
                except PebbleError:
                    continue
            if not stmt.if_exists:
                from pebble.errors import TableNotFound

                raise TableNotFound(stmt.name)
            return QueryResult(columns=[], rows=[], tag="DROP INDEX")
        raise PlanError(f"unsupported DROP kind: {stmt.kind}")

    def _do_create_index(self, stmt: A.CreateIndexStmt) -> QueryResult:
        self.catalog.create_index(
            name=stmt.name, table=stmt.table, columns=tuple(stmt.columns),
            unique=stmt.unique,
        )
        return QueryResult(columns=[], rows=[], tag="CREATE INDEX")

    def _do_txn_control(self, stmt: A.TxnControlStmt) -> QueryResult:
        return QueryResult(columns=[], rows=[], tag=f"TXN {stmt.kind.upper()}")

    def _do_analyze(self, stmt: A.AnalyzeStmt) -> QueryResult:
        from pebble.catalog import TableStats

        if stmt.table:
            tbl = self.catalog.get_table(stmt.table)
            stats = TableStats(row_count=len(self.exec_ctx.rows.get(stmt.table, [])),
                               page_count=1)
            tbl.stats = stats
            return QueryResult(columns=[], rows=[], tag="ANALYZE")
        for tbl in self.catalog.tables():
            tbl.stats = TableStats(
                row_count=len(self.exec_ctx.rows.get(tbl.name, [])),
                page_count=1,
            )
        return QueryResult(columns=[], rows=[], tag="ANALYZE")

    def _do_explain(self, stmt: A.ExplainStmt) -> QueryResult:
        if stmt.inner is None:
            raise PlanError("EXPLAIN with no inner statement")
        builder = Builder(catalog=self.catalog, cfg=self.config.optimizer)
        plan = builder.build(stmt.inner)
        from pebble.plan import render_plan

        text = render_plan(plan)
        rows = [[Value.of(line)] for line in text.splitlines()]
        return QueryResult(columns=["plan"], rows=rows, tag="EXPLAIN", plan=plan)

    def _do_dml(self, stmt: A.Stmt, plan: P.PhysicalPlan) -> QueryResult:
        from pebble.exec.iterators import Row

        if isinstance(plan, P.InsertNode):
            return self._do_insert(plan)
        if isinstance(plan, P.UpdateNode):
            return self._do_update(plan)
        if isinstance(plan, P.DeleteNode):
            return self._do_delete(plan)
        raise PlanError(f"unsupported DML plan: {type(plan).__name__}")

    def _do_insert(self, plan: P.InsertNode) -> QueryResult:
        from pebble.exec.iterators import Row

        tbl = self.catalog.get_table(plan.table)
        col_names = list(plan.columns) or [c.name for c in tbl.columns]
        for raw_row in plan.rows:
            if len(raw_row) != len(col_names):
                raise PlanError(
                    f"INSERT column count mismatch: have {len(col_names)}, got {len(raw_row)}"
                )
            row: Row = {name: Value.null() for name in tbl.column_names}
            for col_name, expr in zip(col_names, raw_row):
                value = self.exec_ctx.evaluator.evaluate(expr, {})
                row[col_name] = value
            self.exec_ctx.append(plan.table, row)
        return QueryResult(columns=[], rows=[], rows_affected=len(plan.rows), tag="INSERT")

    def _do_update(self, plan: P.UpdateNode) -> QueryResult:
        affected = 0
        for row in self.exec_ctx.rows.get(plan.table, []):
            if plan.predicate is not None:
                if not self.exec_ctx.evaluator.evaluate(plan.predicate, row).is_true:
                    continue
            for col, expr in plan.assignments:
                row[col] = self.exec_ctx.evaluator.evaluate(expr, row)
            affected += 1
        return QueryResult(columns=[], rows=[], rows_affected=affected, tag="UPDATE")

    def _do_delete(self, plan: P.DeleteNode) -> QueryResult:
        if plan.predicate is None:
            removed = len(self.exec_ctx.rows.get(plan.table, []))
            self.exec_ctx.rows[plan.table] = []
            return QueryResult(columns=[], rows=[], rows_affected=removed, tag="DELETE")
        before = len(self.exec_ctx.rows.get(plan.table, []))
        kept = [
            r for r in self.exec_ctx.rows.get(plan.table, [])
            if not self.exec_ctx.evaluator.evaluate(plan.predicate, r).is_true
        ]
        self.exec_ctx.rows[plan.table] = kept
        return QueryResult(columns=[], rows=[],
                           rows_affected=before - len(kept), tag="DELETE")
