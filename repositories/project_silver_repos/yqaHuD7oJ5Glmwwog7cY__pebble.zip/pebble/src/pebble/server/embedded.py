from __future__ import annotations

from typing import Any, Iterator

from pebble.config import Config, get_config
from pebble.server.engine import Engine, QueryResult
from pebble.types.value import Value


class EmbeddedConnection:
    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    def cursor(self) -> "EmbeddedCursor":
        return EmbeddedCursor(self.engine)

    def execute(self, sql: str) -> QueryResult:
        return self.engine.execute_sql(sql)

    def close(self) -> None:
        self.engine.close()

    def __enter__(self) -> "EmbeddedConnection":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class EmbeddedCursor:
    def __init__(self, engine: Engine) -> None:
        self.engine = engine
        self._result: QueryResult | None = None
        self._index: int = 0

    def execute(self, sql: str) -> "EmbeddedCursor":
        self._result = self.engine.execute_sql(sql)
        self._index = 0
        return self

    def fetchone(self) -> list[Value] | None:
        if self._result is None or self._index >= len(self._result.rows):
            return None
        row = self._result.rows[self._index]
        self._index += 1
        return row

    def fetchall(self) -> list[list[Value]]:
        if self._result is None:
            return []
        rows = list(self._result.rows[self._index:])
        self._index = len(self._result.rows)
        return rows

    def __iter__(self) -> Iterator[list[Value]]:
        while True:
            row = self.fetchone()
            if row is None:
                return
            yield row

    @property
    def description(self) -> list[str]:
        return list(self._result.columns) if self._result else []

    @property
    def rowcount(self) -> int:
        return self._result.rows_affected if self._result else -1


def open_embedded(data_dir: str, *, readonly: bool = False) -> EmbeddedConnection:
    cfg = get_config().with_overrides(data_dir=data_dir)
    engine = Engine(config=cfg)
    engine.open()
    return EmbeddedConnection(engine)
