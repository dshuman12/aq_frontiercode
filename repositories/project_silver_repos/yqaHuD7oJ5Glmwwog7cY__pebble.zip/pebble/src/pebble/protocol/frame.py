from __future__ import annotations

import json
import struct
from dataclasses import dataclass
from typing import Any

from pebble.constants import (
    MSG_KIND_AUTH,
    MSG_KIND_CANCEL,
    MSG_KIND_COMPLETE,
    MSG_KIND_ERROR,
    MSG_KIND_NOTICE,
    MSG_KIND_QUERY,
    MSG_KIND_ROW,
)
from pebble.errors import NetworkError

_HEADER = struct.Struct(">cI")  # kind + length


@dataclass
class Frame:
    kind: bytes
    payload: bytes

    def encode(self) -> bytes:
        return _HEADER.pack(self.kind, len(self.payload)) + self.payload

    @classmethod
    def query(cls, sql: str) -> "Frame":
        return cls(MSG_KIND_QUERY, sql.encode("utf-8"))

    @classmethod
    def auth(cls, payload: dict[str, Any]) -> "Frame":
        return cls(MSG_KIND_AUTH, json.dumps(payload).encode("utf-8"))

    @classmethod
    def row(cls, values: list[Any]) -> "Frame":
        return cls(MSG_KIND_ROW, json.dumps(values, default=_json_default).encode("utf-8"))

    @classmethod
    def complete(cls, tag: str, rows: int) -> "Frame":
        return cls(
            MSG_KIND_COMPLETE,
            json.dumps({"tag": tag, "rows": rows}).encode("utf-8"),
        )

    @classmethod
    def error(cls, code: str, message: str) -> "Frame":
        return cls(
            MSG_KIND_ERROR,
            json.dumps({"code": code, "message": message}).encode("utf-8"),
        )

    @classmethod
    def notice(cls, message: str) -> "Frame":
        return cls(
            MSG_KIND_NOTICE,
            json.dumps({"message": message}).encode("utf-8"),
        )

    @classmethod
    def cancel(cls) -> "Frame":
        return cls(MSG_KIND_CANCEL, b"")


def encode(frame: Frame) -> bytes:
    return frame.encode()


def decode_one(buf: bytes) -> tuple[Frame, int]:
    """Decode the next frame from ``buf``. Returns (frame, consumed_bytes)."""
    if len(buf) < _HEADER.size:
        raise NetworkError("frame header truncated")
    kind, length = _HEADER.unpack_from(buf, 0)
    if length > 16 * 1024 * 1024:
        raise NetworkError(f"frame too large: {length} bytes")
    if len(buf) < _HEADER.size + length:
        raise NetworkError("frame payload truncated")
    payload = bytes(buf[_HEADER.size: _HEADER.size + length])
    return Frame(kind=kind, payload=payload), _HEADER.size + length


def _json_default(obj: Any) -> Any:
    if isinstance(obj, bytes):
        return {"__blob__": obj.hex()}
    raise TypeError(f"unhandled type: {type(obj).__name__}")
