from __future__ import annotations

import json
import socket
from contextlib import contextmanager
from typing import Iterator

from pebble.constants import (
    DEFAULT_HOST,
    DEFAULT_PORT,
    MSG_KIND_COMPLETE,
    MSG_KIND_ERROR,
    MSG_KIND_NOTICE,
    MSG_KIND_QUERY,
    MSG_KIND_ROW,
)
from pebble.errors import NetworkError, PebbleError
from pebble.protocol.frame import Frame, decode_one, encode


class Client:
    def __init__(self, *, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> None:
        self.host = host
        self.port = port
        self._sock: socket.socket | None = None

    def connect(self) -> None:
        self._sock = socket.create_connection((self.host, self.port), timeout=10)

    def close(self) -> None:
        if self._sock is not None:
            self._sock.close()
            self._sock = None

    def __enter__(self) -> "Client":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def execute(self, sql: str) -> list[list[object]]:
        if self._sock is None:
            raise NetworkError("client not connected")
        self._send(Frame(kind=MSG_KIND_QUERY, payload=sql.encode("utf-8")))
        rows: list[list[object]] = []
        for frame in self._iter_frames():
            if frame.kind == MSG_KIND_ROW:
                rows.append(json.loads(frame.payload))
            elif frame.kind == MSG_KIND_COMPLETE:
                return rows
            elif frame.kind == MSG_KIND_ERROR:
                body = json.loads(frame.payload)
                raise PebbleError(body.get("message", "?"), code=body.get("code"))
            elif frame.kind == MSG_KIND_NOTICE:
                continue
            else:
                raise NetworkError(f"unexpected frame kind: {frame.kind!r}")
        raise NetworkError("connection closed mid-result")

    def _send(self, frame: Frame) -> None:
        assert self._sock is not None
        self._sock.sendall(encode(frame))

    def _iter_frames(self) -> Iterator[Frame]:
        assert self._sock is not None
        buf = b""
        while True:
            chunk = self._sock.recv(4096)
            if not chunk:
                return
            buf += chunk
            while True:
                try:
                    frame, n = decode_one(buf)
                except NetworkError:
                    break
                buf = buf[n:]
                yield frame
                if frame.kind in {MSG_KIND_COMPLETE, MSG_KIND_ERROR}:
                    return


@contextmanager
def connect(*, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> Iterator[Client]:
    client = Client(host=host, port=port)
    client.connect()
    try:
        yield client
    finally:
        client.close()
