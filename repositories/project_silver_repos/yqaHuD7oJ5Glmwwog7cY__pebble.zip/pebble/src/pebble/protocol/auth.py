from __future__ import annotations

import hashlib
import hmac
import secrets
from dataclasses import dataclass


@dataclass(frozen=True)
class AuthRequest:
    user: str
    method: str = "trust"  # trust | md5
    nonce: str | None = None


@dataclass(frozen=True)
class AuthChallenge:
    salt: str

    @classmethod
    def fresh(cls) -> "AuthChallenge":
        return cls(salt=secrets.token_hex(8))


def md5_response(*, user: str, password: str, salt: str) -> str:
    """Compute ``md5( md5(password+user) + salt )`` -- the Postgres scheme.

    We keep the algorithm in a function so tests can verify a known
    fixture; production deployments should use a stronger scheme.
    """
    inner = hashlib.md5((password + user).encode("utf-8")).hexdigest()
    outer = hashlib.md5((inner + salt).encode("utf-8")).hexdigest()
    return f"md5{outer}"


def verify_md5(*, user: str, password_hash: str, salt: str, response: str) -> bool:
    """Constant-time comparison so a mismatched-length salt does not leak."""
    if not response.startswith("md5"):
        return False
    expected = md5_response(user=user, password=password_hash, salt=salt)
    return hmac.compare_digest(expected, response)


def constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))
