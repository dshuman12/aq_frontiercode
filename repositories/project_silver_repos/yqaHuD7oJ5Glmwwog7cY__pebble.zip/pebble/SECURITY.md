# Security Policy

If you find a security issue, please email the maintainers privately rather than
opening a public issue.

## Supported versions

Only the latest minor release receives security fixes during the alpha phase.
