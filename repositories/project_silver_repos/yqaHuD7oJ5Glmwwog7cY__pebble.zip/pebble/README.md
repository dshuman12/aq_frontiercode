# Pebble

A small SQL database engine with a REPL.

![cov](https://img.shields.io/badge/coverage-pending-lightgrey) ![ci](https://img.shields.io/badge/ci-passing-brightgreen) ![license](https://img.shields.io/badge/license-Apache--2.0-blue)

A small SQL database engine, written in Python and meant to be read
end-to-end. It implements a sizeable subset of SQL on top of a custom
page-based storage layer with a B+tree index, MVCC-style transactions,
and an ARIES-flavoured write-ahead log.

Pebble is not a competitor to PostgreSQL or SQLite. It is a teaching
implementation: every layer is small enough to fit in your head, and
the interfaces between them are simple enough that you can swap one
out without rewriting the others.

## Feature surface

- SQL: `SELECT` (with `JOIN`, `WHERE`, `GROUP BY`, `HAVING`, `ORDER BY`,
  `LIMIT`, subqueries, `WITH` CTEs, `UNION ALL`), `INSERT`, `UPDATE`,
  `DELETE`, `CREATE TABLE`, `CREATE INDEX`, `DROP`, `BEGIN`/`COMMIT`/
  `ROLLBACK`, `EXPLAIN`, `ANALYZE`.
- Types: integer, bigint, double, text, blob, boolean, date, timestamp,
  with NULL and three-valued logic.
- Indexes: B+tree, single-column or composite, with range scan.
- Transactions: MVCC with snapshot isolation, optional read committed
  and serializable (SSI-light).
- Recovery: WAL with redo + undo, periodic checkpoints, group commit.
- Optimizer: predicate pushdown, projection pushdown, cost-based join
  reordering (DP up to six tables), index selection.
- Executor: volcano-style iterators with hash join, merge join, hash
  aggregate, external sort.
- Server: line-based wire protocol with framed messages, multi-session,
  cancel support.

## Install

```bash
pip install -e .[dev]
```

## Quick start

```bash
pebble init ./data
pebble repl --data ./data
> CREATE TABLE accounts (id INT PRIMARY KEY, owner TEXT, balance DOUBLE);
> INSERT INTO accounts VALUES (1, 'alice', 100.0), (2, 'bob', 50.0);
> SELECT owner, balance FROM accounts WHERE balance > 60;
owner | balance
------+--------
alice | 100.0
(1 row)
```

## Project layout

```
src/pebble/
    lexer/       SQL tokenizer
    parser/      Recursive-descent parser, AST
    types/       SQL types, NULL semantics, comparison
    catalog/     System tables, statistics, schema cache
    storage/     Slotted pages, heap files, FSM
    buffer/      LRU buffer pool, page latches
    btree/       B+tree index, crabbing latches
    wal/         Write-ahead log, ARIES recovery
    txn/         MVCC, snapshots, transaction manager
    lock/        Lock manager, deadlock detection
    plan/        Logical / physical plan
    optimizer/   Rule-based + cost-based optimizer
    exec/        Volcano-style iterators
    expr/        Expression evaluator
    protocol/    Wire protocol
    server/      TCP server
    cli/         pebble repl/dump/check/bench/migrate/explain
    utils/       Cross-cutting helpers
```

## Documentation

- [Architecture overview](docs/architecture.md)
- [Storage layer](docs/storage.md)
- [Optimizer](docs/optimizer.md)
- [Recovery](docs/recovery.md)

## Running tests

```bash
pytest                       # full suite
pytest tests/unit/btree -x   # focus on the btree
pytest -k recovery           # one topic
```

## License

Apache 2.0 -- see LICENSE.
