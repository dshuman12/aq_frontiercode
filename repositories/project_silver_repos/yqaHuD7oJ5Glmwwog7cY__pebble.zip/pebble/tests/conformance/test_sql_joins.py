from __future__ import annotations

import pytest


def setup_tables(engine):
    engine.execute_sql("CREATE TABLE customers (id INT, name TEXT)")
    engine.execute_sql("CREATE TABLE orders (id INT, customer_id INT, amount INT)")
    engine.execute_sql("INSERT INTO customers VALUES (1, 'alice'), (2, 'bob'), (3, 'carol')")
    engine.execute_sql(
        "INSERT INTO orders VALUES (10, 1, 50), (11, 1, 75), (12, 2, 200)"
    )


def test_inner_join_on_pk(engine):
    setup_tables(engine)
    result = engine.execute_sql(
        "SELECT customers.name, orders.amount "
        "FROM customers INNER JOIN orders ON customers.id = orders.customer_id "
        "ORDER BY orders.id"
    )
    assert [r[0].payload for r in result.rows] == ["alice", "alice", "bob"]


def test_join_with_filter(engine):
    setup_tables(engine)
    result = engine.execute_sql(
        "SELECT customers.name FROM customers INNER JOIN orders "
        "ON customers.id = orders.customer_id WHERE orders.amount > 100"
    )
    assert [r[0].payload for r in result.rows] == ["bob"]


def test_subquery_in_where(engine):
    setup_tables(engine)
    result = engine.execute_sql(
        "SELECT name FROM customers WHERE id IN (SELECT customer_id FROM orders)"
    )
    assert sorted(r[0].payload for r in result.rows) == ["alice", "bob"]


def test_subquery_in_from(engine):
    setup_tables(engine)
    result = engine.execute_sql(
        "SELECT t.name FROM (SELECT name FROM customers WHERE id = 1) AS t"
    )
    assert result.rows[0][0].payload == "alice"


def test_self_join_pairs(engine):
    engine.execute_sql("CREATE TABLE n (k INT)")
    engine.execute_sql("INSERT INTO n VALUES (1), (2), (3)")
    result = engine.execute_sql(
        "SELECT a.k, b.k FROM n AS a INNER JOIN n AS b ON a.k < b.k ORDER BY a.k, b.k"
    )
    pairs = [(r[0].payload, r[1].payload) for r in result.rows]
    assert pairs == [(1, 2), (1, 3), (2, 3)]


def test_join_using_clause_parses(engine):
    engine.execute_sql("CREATE TABLE a (id INT, x INT)")
    engine.execute_sql("CREATE TABLE b (id INT, y INT)")
    engine.execute_sql("INSERT INTO a VALUES (1, 10)")
    engine.execute_sql("INSERT INTO b VALUES (1, 100)")
    # Just exercise the parse path; the executor falls back to predicate.
    engine.execute_sql("SELECT * FROM a INNER JOIN b ON a.id = b.id")
