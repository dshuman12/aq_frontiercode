from __future__ import annotations

import pytest


def test_create_then_drop_table(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("DROP TABLE t")
    with pytest.raises(Exception):
        engine.execute_sql("DROP TABLE t")  # no longer exists


def test_drop_if_exists_swallows_missing(engine):
    engine.execute_sql("DROP TABLE IF EXISTS missing")  # no error


def test_create_table_with_primary_key(engine):
    engine.execute_sql(
        "CREATE TABLE t ("
        "  id INT PRIMARY KEY,"
        "  name TEXT NOT NULL,"
        "  bio TEXT"
        ")"
    )
    table = engine.catalog.get_table("t")
    assert table.column("id").is_primary_key
    assert not table.column("name").nullable


def test_create_table_with_table_level_pk(engine):
    engine.execute_sql(
        "CREATE TABLE t (id INT, val INT, PRIMARY KEY (id))"
    )
    table = engine.catalog.get_table("t")
    assert "id" in table.primary_key


def test_create_index(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("CREATE INDEX idx_id ON t (id)")
    assert engine.catalog.find_index("t", "idx_id") is not None


def test_create_unique_index(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("CREATE UNIQUE INDEX idx_id ON t (id)")
    idx = engine.catalog.find_index("t", "idx_id")
    assert idx is not None and idx.unique


def test_drop_index(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("CREATE INDEX idx_id ON t (id)")
    engine.execute_sql("DROP INDEX idx_id")
    assert engine.catalog.find_index("t", "idx_id") is None


def test_create_table_with_default(engine):
    engine.execute_sql(
        "CREATE TABLE t (id INT, status TEXT DEFAULT 'pending')"
    )


def test_create_table_with_check_constraint(engine):
    engine.execute_sql(
        "CREATE TABLE t (id INT, age INT CHECK (age >= 0))"
    )
