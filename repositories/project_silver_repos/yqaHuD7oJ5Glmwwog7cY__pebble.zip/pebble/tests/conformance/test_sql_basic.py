from __future__ import annotations

import pytest


def test_select_one_literal(engine):
    result = engine.execute_sql("SELECT 1")
    assert result.rows[0][0].payload == 1


def test_select_arithmetic_literal(engine):
    result = engine.execute_sql("SELECT 1 + 2 * 3")
    assert result.rows[0][0].payload == 7


def test_select_string_literal(engine):
    result = engine.execute_sql("SELECT 'hello'")
    assert result.rows[0][0].payload == "hello"


def test_select_string_with_escape(engine):
    result = engine.execute_sql("SELECT 'it''s'")
    assert result.rows[0][0].payload == "it's"


def test_select_boolean_literal(engine):
    result = engine.execute_sql("SELECT TRUE, FALSE")
    assert result.rows[0][0].is_true
    assert result.rows[0][1].is_false


def test_select_null_literal(engine):
    result = engine.execute_sql("SELECT NULL")
    assert result.rows[0][0].is_null


def test_select_with_alias(engine):
    result = engine.execute_sql("SELECT 1 AS one")
    assert "one" in result.columns


def test_select_with_implicit_alias(engine):
    result = engine.execute_sql("SELECT 1 one")
    assert "one" in result.columns


def test_create_drop_round_trip(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("DROP TABLE t")
    engine.execute_sql("CREATE TABLE t (id INT)")  # works again


def test_insert_into_explicit_columns(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v TEXT)")
    engine.execute_sql("INSERT INTO t (v, id) VALUES ('hi', 7)")
    result = engine.execute_sql("SELECT id FROM t WHERE v = 'hi'")
    assert result.rows[0][0].payload == 7


def test_default_null_for_missing_columns(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v TEXT)")
    engine.execute_sql("INSERT INTO t (id) VALUES (1)")
    result = engine.execute_sql("SELECT v FROM t")
    assert result.rows[0][0].is_null


def test_count_star_against_empty_table(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("SELECT COUNT(*) FROM t")
    assert result.rows[0][0].payload == 0


def test_select_where_string_equality(engine):
    engine.execute_sql("CREATE TABLE t (s TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('a'), ('b')")
    result = engine.execute_sql("SELECT s FROM t WHERE s = 'a'")
    assert result.row_count == 1


def test_or_short_circuit_with_null(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (NULL)")
    result = engine.execute_sql("SELECT v FROM t WHERE v = 1 OR v IS NULL")
    assert result.row_count == 2


def test_arithmetic_with_null_yields_null(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (NULL)")
    result = engine.execute_sql("SELECT v + 1 FROM t WHERE v IS NULL")
    assert result.rows[0][0].is_null


def test_update_only_matching_rows(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 10), (2, 20)")
    engine.execute_sql("UPDATE t SET v = 99 WHERE id = 1")
    result = engine.execute_sql("SELECT v FROM t ORDER BY id")
    assert [r[0].payload for r in result.rows] == [99, 20]


def test_delete_without_where_clears_table(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    engine.execute_sql("DELETE FROM t")
    result = engine.execute_sql("SELECT COUNT(*) FROM t")
    assert result.rows[0][0].payload == 0


def test_order_by_text_descending(engine):
    engine.execute_sql("CREATE TABLE t (s TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('a'), ('b'), ('c')")
    result = engine.execute_sql("SELECT s FROM t ORDER BY s DESC")
    assert [r[0].payload for r in result.rows] == ["c", "b", "a"]


def test_create_table_if_not_exists_idempotent(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("CREATE TABLE IF NOT EXISTS t (id INT)")  # no error
