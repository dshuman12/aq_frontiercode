from __future__ import annotations

import pytest


def setup_table(engine):
    engine.execute_sql("CREATE TABLE sales (region TEXT, dept TEXT, amount INT)")
    engine.execute_sql(
        "INSERT INTO sales VALUES "
        "('east','clothing',100),"
        "('east','clothing',200),"
        "('east','food',150),"
        "('west','clothing',50),"
        "('west','food',75),"
        "('west','food',100)"
    )


def test_count_total_rows(engine):
    setup_table(engine)
    result = engine.execute_sql("SELECT COUNT(*) FROM sales")
    assert result.rows[0][0].payload == 6


def test_count_distinct_regions(engine):
    setup_table(engine)
    result = engine.execute_sql("SELECT COUNT(*) FROM (SELECT DISTINCT region FROM sales) AS r")
    assert result.rows[0][0].payload == 2


def test_sum_filtered(engine):
    setup_table(engine)
    result = engine.execute_sql("SELECT SUM(amount) FROM sales WHERE region = 'east'")
    assert result.rows[0][0].payload == 450


def test_avg_returns_float(engine):
    setup_table(engine)
    result = engine.execute_sql("SELECT AVG(amount) FROM sales")
    assert isinstance(result.rows[0][0].payload, float)


def test_min_max(engine):
    setup_table(engine)
    result = engine.execute_sql("SELECT MIN(amount), MAX(amount) FROM sales")
    assert result.rows[0][0].payload == 50
    assert result.rows[0][1].payload == 200


def test_group_by_single_column(engine):
    setup_table(engine)
    result = engine.execute_sql(
        "SELECT region, SUM(amount) FROM sales GROUP BY region ORDER BY region"
    )
    by_region = {r[0].payload: r[1].payload for r in result.rows}
    assert by_region["east"] == 450
    assert by_region["west"] == 225


def test_group_by_two_columns(engine):
    setup_table(engine)
    result = engine.execute_sql(
        "SELECT region, dept, COUNT(*) FROM sales GROUP BY region, dept "
        "ORDER BY region, dept"
    )
    pairs = {(r[0].payload, r[1].payload): r[2].payload for r in result.rows}
    assert pairs[("east", "clothing")] == 2
    assert pairs[("west", "food")] == 2


def test_having_excludes_small_groups(engine):
    setup_table(engine)
    result = engine.execute_sql(
        "SELECT region FROM sales GROUP BY region HAVING SUM(amount) > 300"
    )
    assert [r[0].payload for r in result.rows] == ["east"]


def test_count_with_null_argument(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (NULL), (2)")
    result = engine.execute_sql("SELECT COUNT(v) FROM t")
    assert result.rows[0][0].payload == 2


def test_aggregate_against_empty_table(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    result = engine.execute_sql("SELECT COUNT(*), SUM(v), AVG(v) FROM t")
    row = result.rows[0]
    assert row[0].payload == 0
    assert row[1].is_null
    assert row[2].is_null
