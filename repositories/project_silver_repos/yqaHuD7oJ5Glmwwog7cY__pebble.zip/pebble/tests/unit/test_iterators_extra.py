from __future__ import annotations

import pytest


def test_select_with_or_predicate(engine):
    engine.execute_sql("CREATE TABLE t (id INT, k INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 10), (2, 20), (3, 30)")
    result = engine.execute_sql("SELECT id FROM t WHERE k = 10 OR k = 30")
    ids = sorted(r[0].payload for r in result.rows)
    assert ids == [1, 3]


def test_select_with_and_chain(engine):
    engine.execute_sql("CREATE TABLE t (a INT, b INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 10), (1, 20), (2, 10)")
    result = engine.execute_sql("SELECT a, b FROM t WHERE a = 1 AND b = 20")
    assert result.row_count == 1


def test_select_with_between(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (5), (10), (15)")
    result = engine.execute_sql("SELECT v FROM t WHERE v BETWEEN 5 AND 10")
    assert sorted(r[0].payload for r in result.rows) == [5, 10]


def test_aggregate_avg_returns_float(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3), (4)")
    result = engine.execute_sql("SELECT AVG(v) FROM t")
    assert result.rows[0][0].payload == 2.5


def test_aggregate_min_max(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (5), (2), (7)")
    result = engine.execute_sql("SELECT MIN(v), MAX(v) FROM t")
    row = result.rows[0]
    assert row[0].payload == 2
    assert row[1].payload == 7


def test_count_star_with_where(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    result = engine.execute_sql("SELECT COUNT(*) FROM t WHERE v > 1")
    assert result.rows[0][0].payload == 2


def test_select_with_function_lower(engine):
    engine.execute_sql("CREATE TABLE t (s TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('Alice'), ('BOB')")
    result = engine.execute_sql("SELECT LOWER(s) FROM t ORDER BY s")
    payloads = [r[0].payload for r in result.rows]
    assert "alice" in payloads and "bob" in payloads


def test_string_concat(engine):
    engine.execute_sql("CREATE TABLE t (a TEXT, b TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('foo', 'bar')")
    result = engine.execute_sql("SELECT a || b FROM t")
    assert result.rows[0][0].payload == "foobar"


def test_is_null_predicate(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (NULL), (2)")
    result = engine.execute_sql("SELECT v FROM t WHERE v IS NULL")
    assert result.row_count == 1


def test_in_list_predicate(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3), (4)")
    result = engine.execute_sql("SELECT v FROM t WHERE v IN (1, 3)")
    assert sorted(r[0].payload for r in result.rows) == [1, 3]
