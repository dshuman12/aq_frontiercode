from __future__ import annotations

from pebble.exec.formatter import render_csv, render_table
from pebble.types.value import Value


def test_render_table_basic():
    text = render_table(
        ["id", "name"],
        [[Value.of(1), Value.of("alice")], [Value.of(2), Value.of("bob")]],
    )
    assert "alice" in text
    assert "(2 rows)" in text


def test_render_table_aligns_numeric_right():
    text = render_table(
        ["id", "name"],
        [[Value.of(1), Value.of("a")], [Value.of(100), Value.of("b")]],
    )
    # Find an id cell rendered as "100" -- it should be right-aligned.
    line = next(l for l in text.splitlines() if "100" in l)
    assert "  100" in line or "100 " not in line[:6]  # not strictly leftmost


def test_render_table_handles_nulls():
    text = render_table(["v"], [[Value.null()], [Value.of(1)]])
    assert "NULL" in text


def test_render_csv_basic():
    text = render_csv(
        ["a", "b"],
        [[Value.of(1), Value.of("x")], [Value.of(2), Value.of("y")]],
    )
    lines = text.splitlines()
    assert lines[0] == "a,b"
    assert lines[1] == "1,x"


def test_render_csv_quotes_when_needed():
    text = render_csv(["a"], [[Value.of('he said, "hi"')]])
    assert '"he said, ""hi"""' in text


def test_render_table_empty_result():
    text = render_table([], [])
    assert "empty" in text
