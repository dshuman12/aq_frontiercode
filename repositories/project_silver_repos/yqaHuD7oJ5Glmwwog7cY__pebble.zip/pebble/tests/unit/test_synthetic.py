from __future__ import annotations

import random

from bench.synthetic import (
    generate_insert_stream,
    generate_row,
    make_default_schema,
    random_word,
    render_insert,
)


def test_random_word_within_bounds():
    rng = random.Random(0)
    for _ in range(50):
        w = random_word(rng, max_len=10)
        assert 3 <= len(w) <= 10


def test_generate_row_matches_schema():
    rng = random.Random(0)
    row = generate_row(rng, row_id=42)
    assert row[0] == 42
    assert isinstance(row[1], str)
    assert isinstance(row[2], float)
    assert isinstance(row[3], bool)


def test_render_insert_yields_valid_sql_shape():
    schema = make_default_schema()
    sql = render_insert(schema, (1, "x", 3.14, True))
    assert sql.startswith("INSERT INTO bench_t")
    assert "(1, 'x', 3.1400, TRUE)" in sql


def test_generate_insert_stream_starts_with_setup():
    statements = generate_insert_stream(rows=5, seed=42)
    assert statements[0].startswith("DROP")
    assert statements[1].startswith("CREATE TABLE")
    assert len(statements) == 7  # drop + create + 5 inserts
