from __future__ import annotations

from datetime import date, datetime, timezone

import pytest

from pebble.utils.hashing import crc32, fingerprint, name_hash
from pebble.utils.time import from_days, from_micros, parse_date, parse_iso, to_days, to_micros


def test_name_hash_is_deterministic():
    a = name_hash("orders")
    b = name_hash("orders")
    assert a == b
    assert a != name_hash("invoices")


def test_fingerprint_collisions_seem_unlikely():
    a = fingerprint(("a", 1))
    b = fingerprint(("a", 2))
    assert a != b


def test_crc32_known_value():
    assert crc32(b"hello") == 907060870


def test_to_micros_round_trip():
    dt = datetime(2024, 6, 1, 12, 30, 45, 123456, tzinfo=timezone.utc)
    assert from_micros(to_micros(dt)) == dt


def test_to_days_round_trip():
    d = date(2024, 6, 15)
    assert from_days(to_days(d)) == d


def test_parse_iso_with_z():
    assert parse_iso("2024-06-01T00:00:00Z").tzinfo is not None


def test_parse_iso_with_space_separator():
    out = parse_iso("2024-06-01 12:00:00")
    assert out.hour == 12


def test_parse_date_basic():
    assert parse_date("2024-06-01") == date(2024, 6, 1)


def test_parse_iso_rejects_garbage():
    with pytest.raises(ValueError):
        parse_iso("not-a-date")
