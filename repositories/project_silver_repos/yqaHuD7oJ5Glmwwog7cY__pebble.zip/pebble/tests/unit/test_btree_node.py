from __future__ import annotations

import pytest

from pebble.btree.node import BtreeEntry, BtreeNode, pack_child
from pebble.errors import BtreeKeyTooLarge


def test_node_insert_keeps_sorted_order():
    node = BtreeNode(page_id=1, leaf=True)
    for k in [b"d", b"b", b"a", b"c"]:
        node.insert(BtreeEntry(key=k, value=b"\x00\x00\x00\x01\x00\x00"))
    assert [e.key for e in node.entries] == [b"a", b"b", b"c", b"d"]


def test_find_returns_position_for_missing_key():
    node = BtreeNode(page_id=1, leaf=True)
    for k in [b"a", b"c", b"e"]:
        node.insert(BtreeEntry(key=k, value=b"x" * 6))
    assert node.find(b"d") == 2


def test_overwrite_existing_key_in_leaf():
    node = BtreeNode(page_id=1, leaf=True)
    node.insert(BtreeEntry(key=b"k", value=b"v" * 6))
    node.insert(BtreeEntry(key=b"k", value=b"V" * 6))
    assert len(node.entries) == 1


def test_too_large_key_raises():
    node = BtreeNode(page_id=1, leaf=True)
    big = b"k" * 9000
    with pytest.raises(BtreeKeyTooLarge):
        node.insert(BtreeEntry(key=big, value=b"x" * 6))


def test_serialize_then_deserialize_round_trip():
    node = BtreeNode(page_id=2, leaf=True)
    for k in [b"a", b"b"]:
        node.insert(BtreeEntry(key=k, value=b"\x00\x00\x00\x01\x00\x00"))
    buf = bytearray(8192)
    node.serialize(buf)
    out = BtreeNode.deserialize(2, bytes(buf))
    assert [e.key for e in out.entries] == [b"a", b"b"]


def test_internal_child_lookup():
    node = BtreeNode(page_id=3, leaf=False)
    node.insert(BtreeEntry(key=b"m", value=pack_child(7)))
    node.rightmost_child = 9
    assert node.child_for(b"a") == 7
    assert node.child_for(b"z") == 9


def test_child_for_on_leaf_raises():
    node = BtreeNode(page_id=4, leaf=True)
    with pytest.raises(Exception):
        node.child_for(b"k")
