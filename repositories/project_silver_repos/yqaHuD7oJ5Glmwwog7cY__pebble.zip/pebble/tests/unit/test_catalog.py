from __future__ import annotations

import pytest

from pebble.catalog import Catalog, Column
from pebble.errors import ColumnNotFound, DuplicateName, TableNotFound
from pebble.types import INT, TEXT


def make_columns() -> list[Column]:
    return [
        Column(name="id", type=INT, ordinal=0, is_primary_key=True),
        Column(name="name", type=TEXT, ordinal=1, nullable=False),
    ]


def test_create_and_get_table():
    cat = Catalog()
    cat.create_table(name="t", columns=make_columns())
    assert cat.has_table("t")
    assert cat.get_table("t").columns[0].name == "id"


def test_duplicate_table_raises():
    cat = Catalog()
    cat.create_table(name="t", columns=make_columns())
    with pytest.raises(DuplicateName):
        cat.create_table(name="t", columns=make_columns())


def test_drop_unknown_raises():
    with pytest.raises(TableNotFound):
        Catalog().drop_table("missing")


def test_column_lookup():
    cat = Catalog()
    cat.create_table(name="t", columns=make_columns())
    tbl = cat.get_table("t")
    assert tbl.column("name").type == TEXT
    with pytest.raises(ColumnNotFound):
        tbl.column("missing")


def test_duplicate_columns_rejected():
    bad = make_columns() + [Column(name="id", type=INT, ordinal=2)]
    cat = Catalog()
    with pytest.raises(DuplicateName):
        cat.create_table(name="t", columns=bad)


def test_create_index():
    cat = Catalog()
    cat.create_table(name="t", columns=make_columns())
    idx = cat.create_index(name="idx_id", table="t", columns=("id",))
    assert idx.name == "idx_id"
