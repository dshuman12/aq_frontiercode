from __future__ import annotations

import pytest

from pebble.lock.manager import (
    LOCK_IS,
    LOCK_IX,
    LOCK_S,
    LOCK_SIX,
    LOCK_X,
    LockManager,
    is_compatible,
)


def test_is_compat_with_is_yes():
    assert is_compatible(LOCK_IS, LOCK_IS)


def test_is_compat_with_x_no():
    assert not is_compatible(LOCK_IS, LOCK_X)


def test_ix_compat_with_ix_yes():
    assert is_compatible(LOCK_IX, LOCK_IX)


def test_ix_compat_with_s_no():
    assert not is_compatible(LOCK_IX, LOCK_S)


def test_six_blocks_x():
    assert not is_compatible(LOCK_SIX, LOCK_X)


def test_x_blocks_everything():
    for mode in (LOCK_S, LOCK_X, LOCK_IS, LOCK_IX, LOCK_SIX):
        assert not is_compatible(LOCK_X, mode)


def test_acquire_releases_in_order():
    mgr = LockManager(timeout_ms=100)
    mgr.acquire(1, "t", None, LOCK_S)
    mgr.acquire(2, "t", None, LOCK_S)  # compatible
    mgr.release_all(1)
    mgr.release_all(2)


def test_x_after_release_unblocks():
    mgr = LockManager(timeout_ms=200)
    mgr.acquire(1, "t", None, LOCK_X)
    mgr.release_all(1)
    mgr.acquire(2, "t", None, LOCK_X)
    mgr.release_all(2)
