from __future__ import annotations

from pebble.plan.physical import (
    FilterNode,
    PhysicalPlan,
    SeqScan,
    render,
)


def test_render_includes_node_name_and_rows():
    scan = SeqScan(table="t", estimated_rows=100, estimated_cost=1.0)
    text = render(scan)
    assert "SeqScan" in text
    assert "rows=100" in text


def test_render_indents_children():
    scan = SeqScan(table="t", estimated_rows=10, estimated_cost=1.0)
    filt = FilterNode(input=scan, predicate=None, estimated_rows=5, estimated_cost=1.5)
    text = render(filt)
    assert "FilterNode" in text
    # Children indented by two spaces.
    lines = text.splitlines()
    assert any(line.startswith("  SeqScan") for line in lines)


def test_render_handles_missing_child():
    plan = FilterNode(input=None, predicate=None, estimated_rows=0, estimated_cost=0.0)
    assert "FilterNode" in render(plan)
