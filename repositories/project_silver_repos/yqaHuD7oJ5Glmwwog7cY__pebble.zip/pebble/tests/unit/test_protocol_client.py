from __future__ import annotations

import socket
import threading
import time

import pytest

from pebble.errors import PebbleError
from pebble.protocol.client import Client
from pebble.protocol.frame import Frame, decode_one, encode


class _FakeServer:
    def __init__(self, *, responses: list[Frame]) -> None:
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.responses = responses
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()

    def _serve(self):
        conn, _ = self.sock.accept()
        try:
            buf = b""
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                buf += chunk
                try:
                    _, n = decode_one(buf)
                except Exception:
                    continue
                buf = buf[n:]
                for frame in self.responses:
                    conn.sendall(encode(frame))
                break
        finally:
            conn.close()

    def stop(self) -> None:
        self.sock.close()


def test_client_returns_rows_then_complete():
    server = _FakeServer(responses=[
        Frame.row([1, "alice"]),
        Frame.row([2, "bob"]),
        Frame.complete("SELECT", 2),
    ])
    try:
        with Client(port=server.port) as client:
            rows = client.execute("SELECT * FROM t")
            assert rows == [[1, "alice"], [2, "bob"]]
    finally:
        server.stop()


def test_client_translates_error_frames():
    server = _FakeServer(responses=[Frame.error("PE9999", "boom")])
    try:
        with Client(port=server.port) as client:
            with pytest.raises(PebbleError):
                client.execute("SELECT 1")
    finally:
        server.stop()


def test_client_handles_notice_frame():
    server = _FakeServer(responses=[
        Frame.notice("hello"),
        Frame.complete("DONE", 0),
    ])
    try:
        with Client(port=server.port) as client:
            rows = client.execute("EXPLAIN")
            assert rows == []
    finally:
        server.stop()
