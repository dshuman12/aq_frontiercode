from __future__ import annotations

import pytest

from pebble.exec.helpers import (
    coerce_bool,
    coerce_int,
    column_values,
    cross_product,
    deduplicate_rows,
    materialise,
    take,
)
from pebble.types.value import Value


def test_materialise_drains_iterator():
    rows = iter([{"a": Value.of(1)}, {"a": Value.of(2)}])
    assert len(materialise(rows)) == 2


def test_take_stops_at_limit():
    rows = iter([{"a": Value.of(i)} for i in range(100)])
    out = take(rows, 5)
    assert len(out) == 5


def test_column_values_returns_per_row():
    rows = [{"a": Value.of(1)}, {"a": Value.of(2)}, {"b": Value.of(3)}]
    out = column_values(rows, "a")
    assert [v.payload for v in out[:2]] == [1, 2]
    assert out[2].is_null


def test_cross_product_returns_pairs():
    left = [{"a": Value.of(1)}, {"a": Value.of(2)}]
    right = [{"b": Value.of(10)}, {"b": Value.of(20)}]
    out = list(cross_product(left, right))
    assert len(out) == 4


def test_deduplicate_rows_drops_duplicates():
    rows = [{"a": Value.of(1)}, {"a": Value.of(1)}, {"a": Value.of(2)}]
    out = list(deduplicate_rows(rows))
    assert len(out) == 2


def test_coerce_int_handles_null():
    assert coerce_int(Value.null(), default=99) == 99


def test_coerce_int_rejects_text():
    with pytest.raises(TypeError):
        coerce_int(Value.of("hello"))


def test_coerce_bool_falsy_cases():
    assert not coerce_bool(Value.null())
    assert not coerce_bool(Value.of(0))
    assert not coerce_bool(Value.of(""))


def test_coerce_bool_truthy_cases():
    assert coerce_bool(Value.of(1))
    assert coerce_bool(Value.of("hello"))
    assert coerce_bool(Value.of(True))
