from __future__ import annotations

from pebble.cli.cmd_dump import _quote


def test_quote_string_doubles_quotes():
    assert _quote("it's") == "'it''s'"


def test_quote_int_passes_through():
    assert _quote(42) == "42"


def test_quote_bytes_emits_x_prefix():
    assert _quote(b"\x00\x01") == "x'0001'"


def test_quote_float():
    assert _quote(3.14) == "3.14"
