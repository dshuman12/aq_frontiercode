from __future__ import annotations

from pebble.txn.manager import Snapshot


def test_xmin_at_horizon_is_invisible():
    snap = Snapshot(xmin_horizon=100, xmax_horizon=200, active_txns=frozenset())
    assert not snap.is_visible(xmin=200, xmax=0)


def test_xmin_below_horizon_visible():
    snap = Snapshot(xmin_horizon=100, xmax_horizon=200, active_txns=frozenset())
    assert snap.is_visible(xmin=50, xmax=0)


def test_xmax_active_keeps_tuple_visible():
    snap = Snapshot(
        xmin_horizon=100, xmax_horizon=200, active_txns=frozenset({150}),
    )
    assert snap.is_visible(xmin=50, xmax=150)


def test_xmin_zero_invisible():
    snap = Snapshot(xmin_horizon=0, xmax_horizon=200, active_txns=frozenset())
    assert not snap.is_visible(xmin=0, xmax=0)
