from __future__ import annotations

from pathlib import Path

import pytest

from pebble.storage.heap import FreeSpaceMap, HeapFile, TupleId


def test_allocate_and_read_back(tmp_path: Path):
    path = tmp_path / "h.pdb"
    with HeapFile(str(path)) as heap:
        page = heap.allocate_page()
        slot = page.insert(b"persisted")
        heap.write_page(page)
        assert heap.page_count == 1
    with HeapFile(str(path)) as heap:
        page = heap.read_page(0)
        assert page.read(slot) == b"persisted"


def test_iter_tuples_yields_tids(tmp_path: Path):
    path = tmp_path / "h.pdb"
    with HeapFile(str(path)) as heap:
        page = heap.allocate_page()
        page.insert(b"r1")
        page.insert(b"r2")
        heap.write_page(page)
        out = list(heap.iter_tuples())
        assert [tid for tid, _ in out] == [TupleId(0, 0), TupleId(0, 1)]


def test_fsm_finds_page_with_space(tmp_path: Path):
    fsm = FreeSpaceMap()
    fsm.update(0, 100)
    fsm.update(1, 5000)
    assert fsm.find_with_space(2000) == 1


def test_fsm_returns_none_when_full():
    fsm = FreeSpaceMap()
    fsm.update(0, 1)
    assert fsm.find_with_space(100) is None


def test_tupleid_pack_round_trip():
    tid = TupleId(123, 4)
    assert TupleId.unpack(tid.pack()) == tid


def test_readonly_rejects_writes(tmp_path: Path):
    path = tmp_path / "h.pdb"
    HeapFile(str(path)).close()  # touch
    heap = HeapFile(str(path), readonly=True)
    try:
        with pytest.raises(Exception):
            heap.allocate_page()
    finally:
        heap.close()
