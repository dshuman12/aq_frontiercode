from __future__ import annotations

import threading
import time

from pebble.storage.concurrency import PageLatchTable


def test_shared_latches_allow_concurrent_readers():
    table = PageLatchTable()
    seen = []

    def reader(idx: int):
        with table.shared(0):
            seen.append(idx)
            time.sleep(0.01)

    threads = [threading.Thread(target=reader, args=(i,)) for i in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert sorted(seen) == [0, 1, 2, 3, 4]


def test_exclusive_blocks_other_exclusive():
    table = PageLatchTable()
    order: list[str] = []

    def writer(label: str):
        with table.exclusive(0):
            order.append(label + "-start")
            time.sleep(0.05)
            order.append(label + "-end")

    a = threading.Thread(target=writer, args=("a",))
    b = threading.Thread(target=writer, args=("b",))
    a.start()
    time.sleep(0.01)
    b.start()
    a.join()
    b.join()
    # Both writers' start/end must be paired without overlap.
    assert order in (
        ["a-start", "a-end", "b-start", "b-end"],
        ["b-start", "b-end", "a-start", "a-end"],
    )


def test_independent_pages_do_not_block():
    table = PageLatchTable()

    def writer(page_id: int, results: list[bool]) -> None:
        with table.exclusive(page_id):
            results.append(True)

    out_a: list[bool] = []
    out_b: list[bool] = []
    a = threading.Thread(target=writer, args=(1, out_a))
    b = threading.Thread(target=writer, args=(2, out_b))
    a.start()
    b.start()
    a.join()
    b.join()
    assert out_a and out_b


def test_reset_drops_state():
    table = PageLatchTable()
    with table.shared(0):
        pass
    table.reset()
