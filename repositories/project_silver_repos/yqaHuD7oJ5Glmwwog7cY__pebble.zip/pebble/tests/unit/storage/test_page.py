from __future__ import annotations

import pytest

from pebble.errors import CorruptPage, PageFull, StorageError
from pebble.storage.page import HeapPage


def test_insert_and_read_round_trip():
    page = HeapPage(page_id=42)
    slot = page.insert(b"hello")
    assert page.read(slot) == b"hello"


def test_insert_then_freeze_then_thaw():
    page = HeapPage(page_id=7)
    page.insert(b"abc")
    page.insert(b"defg")
    raw = page.freeze()
    rehydrated = HeapPage.thaw(raw)
    assert rehydrated.read(0) == b"abc"
    assert rehydrated.read(1) == b"defg"


def test_thaw_rejects_bad_magic():
    raw = bytearray(8192)
    with pytest.raises(CorruptPage):
        HeapPage.thaw(bytes(raw))


def test_delete_marks_slot_empty():
    page = HeapPage(page_id=1)
    slot = page.insert(b"data")
    page.delete(slot)
    with pytest.raises(StorageError):
        page.read(slot)


def test_vacuum_reclaims_space():
    page = HeapPage(page_id=1)
    a = page.insert(b"first")
    b = page.insert(b"second")
    page.delete(a)
    before = page.free_space()
    page.vacuum()
    assert page.free_space() >= before


def test_insert_full_raises_page_full():
    page = HeapPage(page_id=1)
    big = b"x" * (page.free_space() - 4)
    page.insert(big)
    with pytest.raises(PageFull):
        page.insert(b"never fits")


def test_update_in_place_when_smaller():
    page = HeapPage(page_id=1)
    slot = page.insert(b"original_payload")
    assert page.update_in_place(slot, b"smaller")


def test_update_in_place_rejects_larger():
    page = HeapPage(page_id=1)
    slot = page.insert(b"abc")
    assert not page.update_in_place(slot, b"abcdef")
