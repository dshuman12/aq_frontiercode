from __future__ import annotations

import threading

import pytest

from pebble.storage.sequence import Sequence, SequenceRegistry


def test_next_starts_from_start():
    seq = Sequence(name="oid", start=100)
    assert seq.next() == 100
    assert seq.next() == 101


def test_increment_other_than_one():
    seq = Sequence(name="oid", start=10, increment=5)
    assert [seq.next() for _ in range(3)] == [10, 15, 20]


def test_peek_does_not_advance():
    seq = Sequence(name="oid")
    assert seq.peek() == 1
    assert seq.peek() == 1
    seq.next()
    assert seq.peek() == 2


def test_reset_restores_start():
    seq = Sequence(name="oid")
    for _ in range(5):
        seq.next()
    seq.reset()
    assert seq.next() == 1


def test_reset_to_specific_value():
    seq = Sequence(name="oid")
    seq.reset(to=50)
    assert seq.next() == 50


def test_reserve_returns_consecutive_range():
    seq = Sequence(name="oid")
    first, last = seq.reserve(5)
    assert first == 1
    assert last == 5
    assert seq.next() == 6


def test_reserve_zero_rejected():
    with pytest.raises(ValueError):
        Sequence(name="oid").reserve(0)


def test_concurrent_next_yields_unique_values():
    seq = Sequence(name="oid")
    seen: list[int] = []
    lock = threading.Lock()

    def worker():
        for _ in range(50):
            value = seq.next()
            with lock:
                seen.append(value)

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(set(seen)) == len(seen)


def test_registry_get_or_create_caches():
    registry = SequenceRegistry()
    a = registry.get_or_create("oid")
    b = registry.get_or_create("oid")
    assert a is b


def test_registry_drop_removes():
    registry = SequenceRegistry()
    registry.get_or_create("oid")
    registry.drop("oid")
    new_seq = registry.get_or_create("oid")
    assert new_seq.next() == 1
