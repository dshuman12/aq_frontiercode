from __future__ import annotations

from pathlib import Path

import pytest

from pebble.buffer.pool import BufferPool
from pebble.storage.heap import HeapFile
from pebble.storage.heap_manager import HeapManager


@pytest.fixture
def manager(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "h.pdb"))
    pool = BufferPool(heap, capacity=8)
    yield HeapManager(heap, pool)
    pool.close()
    heap.close()


def test_insert_then_read(manager):
    tid = manager.insert(b"first row")
    assert manager.read(tid) == b"first row"


def test_insert_many_spans_pages(manager):
    inserted = []
    for i in range(500):
        tid = manager.insert(f"row {i}".encode())
        inserted.append(tid)
    assert len({tid.page_id for tid in inserted}) > 1


def test_delete_marks_slot_empty(manager):
    tid = manager.insert(b"to delete")
    manager.delete(tid)
    with pytest.raises(Exception):
        manager.read(tid)


def test_update_in_place_smaller_payload(manager):
    tid = manager.insert(b"longer payload here")
    manager.update(tid, b"short")
    assert manager.read(tid).startswith(b"short")


def test_iter_tuples_returns_inserted_rows(manager):
    tids = [manager.insert(f"row {i}".encode()) for i in range(5)]
    out = [(tid, payload) for tid, payload in manager.iter_tuples()]
    assert len(out) == 5
