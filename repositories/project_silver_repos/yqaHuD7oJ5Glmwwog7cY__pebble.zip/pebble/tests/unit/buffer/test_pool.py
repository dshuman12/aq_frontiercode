from __future__ import annotations

from pathlib import Path

import pytest

from pebble.buffer.pool import BufferPool
from pebble.errors import StorageError
from pebble.storage.heap import HeapFile


def test_pin_unpin_balanced(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "h.pdb"))
    try:
        pool = BufferPool(heap, capacity=4)
        with pool.pin_new():
            pass
        stats = pool.stats()
        assert stats.size == 1
    finally:
        heap.close()


def test_lru_eviction_writes_dirty(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "h.pdb"))
    try:
        pool = BufferPool(heap, capacity=4)
        ids = []
        for _ in range(4):
            with pool.pin_new() as page:
                page.insert(b"x")
                ids.append(page.header.page_id)
        # Triggering one more allocation evicts the oldest dirty page.
        with pool.pin_new() as page:
            page.insert(b"y")
        assert pool.stats().flushes >= 1
    finally:
        heap.close()


def test_unbalanced_unpin_raises(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "h.pdb"))
    try:
        pool = BufferPool(heap, capacity=4)
        with pytest.raises(StorageError):
            pool.unpin(999)
    finally:
        heap.close()


def test_capacity_must_be_at_least_4(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "h.pdb"))
    try:
        with pytest.raises(ValueError):
            BufferPool(heap, capacity=2)
    finally:
        heap.close()
