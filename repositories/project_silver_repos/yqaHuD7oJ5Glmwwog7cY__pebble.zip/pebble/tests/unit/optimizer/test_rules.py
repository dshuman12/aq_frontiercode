from __future__ import annotations

from pebble.optimizer.rules import (
    constant_folding,
    limit_pushdown,
    optimize,
    predicate_pushdown,
)
from pebble.parser import ast as A
from pebble.plan.logical import Filter, Limit, Project, Scan


def make_scan(table: str = "t") -> Scan:
    return Scan(table=table)


def test_constant_folding_evaluates_arithmetic():
    expr = A.BinaryOp(op="+", left=A.Literal(value=2), right=A.Literal(value=3))
    plan = Filter(input=make_scan(), predicate=expr)
    optimized = constant_folding(plan)
    assert isinstance(optimized.predicate, A.Literal)
    assert optimized.predicate.value == 5


def test_predicate_pushdown_through_project():
    pred = A.BinaryOp(op="=", left=A.ColumnRef(name="a"), right=A.Literal(value=1))
    plan = Filter(
        input=Project(
            input=make_scan(),
            projections=[(A.ColumnRef(name="a"), None)],
        ),
        predicate=pred,
    )
    out = predicate_pushdown(plan)
    assert isinstance(out, Project)
    assert isinstance(out.input, Filter)


def test_limit_pushdown_through_project():
    plan = Limit(
        input=Project(
            input=make_scan(),
            projections=[(A.ColumnRef(name="a"), None)],
        ),
        limit=A.Literal(value=10),
    )
    out = limit_pushdown(plan)
    assert isinstance(out, Project)
    assert isinstance(out.input, Limit)


def test_optimize_idempotent():
    plan = Filter(
        input=make_scan(),
        predicate=A.Literal(value=True),
    )
    once = optimize(plan)
    twice = optimize(once)
    assert type(once) is type(twice)
