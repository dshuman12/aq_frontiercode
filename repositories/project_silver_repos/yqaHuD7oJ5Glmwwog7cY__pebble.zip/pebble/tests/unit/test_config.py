from __future__ import annotations

import os
from pathlib import Path

import pytest

from pebble.config import Config, OptimizerConfig, StorageConfig, get_config, reset_config


def test_default_storage_page_size():
    cfg = Config()
    assert cfg.storage.page_size > 0


def test_with_overrides_dataclass_section():
    cfg = Config()
    new_cfg = cfg.with_overrides(storage={"buffer_pool_pages": 7})
    assert cfg.storage.buffer_pool_pages != 7
    assert new_cfg.storage.buffer_pool_pages == 7


def test_get_config_caches(tmp_path: Path):
    reset_config()
    a = get_config()
    b = get_config()
    assert a is b


def test_env_overrides_port(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("PEBBLE_PORT", "9999")
    reset_config()
    cfg = get_config()
    assert cfg.server.port == 9999


def test_env_overrides_buffer_pool(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("PEBBLE_BUFFER_POOL_PAGES", "256")
    reset_config()
    cfg = get_config()
    assert cfg.storage.buffer_pool_pages == 256


def test_env_overrides_fsync(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("PEBBLE_FSYNC", "false")
    reset_config()
    cfg = get_config()
    assert not cfg.storage.fsync_on_commit
