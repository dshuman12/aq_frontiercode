from __future__ import annotations

import pytest

from pebble.errors import LexerError
from pebble.lexer import TokenKind, tokenize


def test_negative_number_is_minus_then_int():
    tokens = tokenize("-1")
    assert tokens[0].kind == TokenKind.MINUS
    assert tokens[1].kind == TokenKind.INT


def test_float_with_leading_dot():
    tokens = tokenize(".5")
    assert tokens[0].kind == TokenKind.FLOAT
    assert tokens[0].text == ".5"


def test_float_with_exponent():
    tokens = tokenize("1e10")
    assert tokens[0].kind == TokenKind.FLOAT


def test_float_with_explicit_sign_in_exponent():
    tokens = tokenize("1e-3 1e+5")
    assert tokens[0].text == "1e-3"
    assert tokens[1].text == "1e+5"


def test_identifier_starting_with_underscore():
    tokens = tokenize("_x")
    assert tokens[0].kind == TokenKind.IDENT


def test_identifier_with_digits_after_first_letter():
    tokens = tokenize("col1 col_2")
    assert tokens[0].text == "col1"
    assert tokens[1].text == "col_2"


def test_keyword_versus_identifier_lookup():
    tokens = tokenize("select select_count")
    assert tokens[0].kind == TokenKind.KEYWORD
    assert tokens[1].kind == TokenKind.IDENT


def test_position_increments_with_newline():
    tokens = tokenize("a\n   b")
    assert tokens[1].line == 2
    assert tokens[1].column == 4


def test_unterminated_string_raises():
    with pytest.raises(LexerError):
        tokenize("'never closes")


def test_unterminated_quoted_identifier_raises():
    with pytest.raises(LexerError):
        tokenize('"never closes')


def test_empty_blob_literal_round_trip():
    tokens = tokenize("x''")
    assert tokens[0].kind == TokenKind.BLOB
    assert tokens[0].text == ""


def test_double_pipe_concat():
    tokens = tokenize("|| ||")
    assert tokens[0].kind == TokenKind.CONCAT
    assert tokens[1].kind == TokenKind.CONCAT


def test_multiple_statements_share_lexer():
    tokens = tokenize("SELECT 1; SELECT 2;")
    semicolons = [t for t in tokens if t.kind == TokenKind.SEMICOLON]
    assert len(semicolons) == 2
