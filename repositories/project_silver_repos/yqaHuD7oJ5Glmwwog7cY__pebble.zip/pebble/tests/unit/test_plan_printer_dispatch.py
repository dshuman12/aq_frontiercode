from __future__ import annotations

import pytest

from pebble.plan.logical import Scan as LogicalScan
from pebble.plan.physical import SeqScan
from pebble.plan.printer import render


def test_dispatches_logical():
    text = render(LogicalScan(table="t"))
    assert "Scan" in text


def test_dispatches_physical():
    text = render(SeqScan(table="t", estimated_rows=1, estimated_cost=0.0))
    assert "SeqScan" in text


def test_rejects_other_types():
    with pytest.raises(TypeError):
        render("not a plan")
