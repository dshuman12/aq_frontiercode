from __future__ import annotations

import pytest

from pebble.types.value import Value, add, div, mul, sub


def test_add_int_int():
    assert add(Value.of(2), Value.of(3)).payload == 5


def test_sub_int_int():
    assert sub(Value.of(7), Value.of(2)).payload == 5


def test_mul_int_int():
    assert mul(Value.of(4), Value.of(3)).payload == 12


def test_div_int_int_floor():
    assert div(Value.of(7), Value.of(2)).payload == 3


def test_div_float_yields_float():
    assert div(Value.of(7.0), Value.of(2)).payload == 3.5


def test_arithmetic_with_null_yields_null():
    assert add(Value.of(1), Value.null()).is_null
    assert sub(Value.null(), Value.of(1)).is_null


def test_string_concat_via_add():
    assert add(Value.of("a"), Value.of("b")).payload == "ab"


def test_add_text_int_raises():
    from pebble.errors import TypeMismatch

    with pytest.raises(TypeMismatch):
        add(Value.of("a"), Value.of(1))


def test_compare_int_to_double():
    assert Value.of(1).cmp(Value.of(1.0)) == 0
    assert Value.of(1).cmp(Value.of(2.0)) == -1


def test_compare_text_text():
    assert Value.of("a").cmp(Value.of("b")) == -1


def test_compare_with_null_returns_none():
    assert Value.null().cmp(Value.of(1)) is None
    assert Value.of(1).cmp(Value.null()) is None
