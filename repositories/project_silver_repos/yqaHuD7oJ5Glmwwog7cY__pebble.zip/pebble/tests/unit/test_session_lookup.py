from __future__ import annotations

from pebble.server.session import PreparedStatement, Session


def test_prepared_statement_has_zero_use_count_initially():
    stmt = PreparedStatement(sql="SELECT 1", plan="p")
    assert stmt.use_count == 0


def test_session_default_isolation():
    s = Session()
    assert s.isolation == "snapshot"


def test_explicit_isolation():
    s = Session(isolation="serializable")
    assert s.isolation == "serializable"


def test_evict_unknown_plan_is_noop():
    s = Session()
    s.evict_plan("never seen")
    assert s.cache_size() == 0


def test_lookup_unknown_plan_returns_none():
    s = Session()
    assert s.lookup_plan("never seen") is None
