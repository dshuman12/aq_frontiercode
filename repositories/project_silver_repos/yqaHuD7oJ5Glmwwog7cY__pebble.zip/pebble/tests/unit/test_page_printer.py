from __future__ import annotations

from pebble.storage.page import HeapPage
from pebble.storage.page_printer import hex_dump, render_page, render_summary


def test_hex_dump_basic():
    text = hex_dump(b"\x00\x01\x02hello", width=8)
    assert "00 01 02" in text
    assert "hello" in text


def test_hex_dump_truncates_after_max_rows():
    big = b"\x00" * 4096
    text = hex_dump(big, width=8, max_rows=2)
    assert "more bytes" in text


def test_render_page_includes_header_fields():
    page = HeapPage(page_id=42)
    page.insert(b"hello")
    text = render_page(page)
    assert "page 42" in text
    assert "slot_count" in text
    assert "5b @" in text


def test_render_summary_one_line_per_page():
    pages = [HeapPage(page_id=i) for i in range(3)]
    pages[0].insert(b"a")
    pages[1].insert(b"b")
    pages[1].insert(b"c")
    text = render_summary(pages)
    assert text.count("\n") == 2  # three lines = two newlines
