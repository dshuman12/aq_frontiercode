from __future__ import annotations

import pytest

from pebble.expr.evaluator import Evaluator
from pebble.parser import ast as A
from pebble.types.value import Value


def lit(v):
    return A.Literal(value=v)


def test_arithmetic_with_columns():
    e = Evaluator()
    expr = A.BinaryOp(op="+", left=A.ColumnRef(name="x"), right=lit(3))
    result = e.evaluate(expr, {"x": Value.of(2)})
    assert result.payload == 5


def test_null_propagates_through_addition():
    e = Evaluator()
    expr = A.BinaryOp(op="+", left=A.ColumnRef(name="x"), right=lit(1))
    assert e.evaluate(expr, {"x": Value.null()}).is_null


def test_like_pattern_match():
    e = Evaluator()
    expr = A.Like(expr=A.ColumnRef(name="s"), pattern=lit("a%"))
    assert e.evaluate(expr, {"s": Value.of("abc")}).is_true
    assert e.evaluate(expr, {"s": Value.of("xyz")}).is_false


def test_in_list_with_null_element_returns_null_when_absent():
    e = Evaluator()
    expr = A.InList(expr=A.ColumnRef(name="x"),
                    values=[lit(1), A.NullLiteral()])
    result = e.evaluate(expr, {"x": Value.of(2)})
    assert result.is_null


def test_case_with_else():
    e = Evaluator()
    expr = A.Case(
        when_clauses=[(A.BinaryOp(op="<", left=A.ColumnRef(name="x"), right=lit(0)),
                       lit("neg"))],
        else_clause=lit("nonneg"),
    )
    assert e.evaluate(expr, {"x": Value.of(-1)}).payload == "neg"
    assert e.evaluate(expr, {"x": Value.of(5)}).payload == "nonneg"


def test_function_coalesce():
    e = Evaluator()
    expr = A.FunctionCall(name="COALESCE",
                          args=[A.ColumnRef(name="x"), lit("fallback")])
    assert e.evaluate(expr, {"x": Value.null()}).payload == "fallback"


def test_function_length():
    e = Evaluator()
    expr = A.FunctionCall(name="LENGTH", args=[A.ColumnRef(name="s")])
    assert e.evaluate(expr, {"s": Value.of("abc")}).payload == 3
