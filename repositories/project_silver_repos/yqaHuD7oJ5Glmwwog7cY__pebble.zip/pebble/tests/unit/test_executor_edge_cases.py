from __future__ import annotations

import pytest


def test_empty_table_returns_no_rows(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("SELECT * FROM t")
    assert result.row_count == 0


def test_select_with_unmatched_filter(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1)")
    result = engine.execute_sql("SELECT id FROM t WHERE id = 99")
    assert result.row_count == 0


def test_string_predicate_with_apostrophe(engine):
    engine.execute_sql("CREATE TABLE t (s TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('it''s ok')")
    result = engine.execute_sql("SELECT s FROM t WHERE s = 'it''s ok'")
    assert result.row_count == 1


def test_negative_arithmetic(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (5), (-3)")
    result = engine.execute_sql("SELECT v FROM t WHERE v < 0")
    assert result.rows[0][0].payload == -3


def test_string_function_substr(engine):
    engine.execute_sql("CREATE TABLE t (s TEXT)")
    engine.execute_sql("INSERT INTO t VALUES ('hello')")
    result = engine.execute_sql("SELECT SUBSTR(s, 2, 3) FROM t")
    assert result.rows[0][0].payload == "ell"


def test_function_abs(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (-5)")
    result = engine.execute_sql("SELECT ABS(v) FROM t")
    assert result.rows[0][0].payload == 5


def test_function_coalesce(engine):
    engine.execute_sql("CREATE TABLE t (a INT, b INT)")
    engine.execute_sql("INSERT INTO t VALUES (NULL, 7), (1, 2)")
    result = engine.execute_sql("SELECT COALESCE(a, b) FROM t ORDER BY b")
    payloads = [r[0].payload for r in result.rows]
    assert payloads == [1, 7]


def test_case_simple_with_else(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    result = engine.execute_sql(
        "SELECT CASE v WHEN 1 THEN 'one' WHEN 2 THEN 'two' ELSE 'other' END FROM t ORDER BY v"
    )
    assert [r[0].payload for r in result.rows] == ["one", "two", "other"]


def test_division_by_zero_raises(engine):
    engine.execute_sql("CREATE TABLE t (a INT, b INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 0)")
    with pytest.raises(Exception):
        engine.execute_sql("SELECT a / b FROM t")


def test_float_division_yields_float(engine):
    engine.execute_sql("CREATE TABLE t (a DOUBLE, b DOUBLE)")
    engine.execute_sql("INSERT INTO t VALUES (5.0, 2.0)")
    result = engine.execute_sql("SELECT a / b FROM t")
    assert result.rows[0][0].payload == 2.5
