from __future__ import annotations

import pytest

from pebble.errors import ParseError
from pebble.parser import ast as A
from pebble.parser.parser import parse, parse_one


def test_aliasless_join():
    stmt = parse_one("SELECT * FROM a JOIN b ON a.id = b.id")
    assert isinstance(stmt.from_clause, A.JoinClause)


def test_full_outer_join_keyword():
    stmt = parse_one("SELECT * FROM a FULL OUTER JOIN b ON a.id = b.id")
    assert stmt.from_clause.kind == "full"


def test_cross_join_implicit_via_comma():
    stmt = parse_one("SELECT * FROM a, b")
    assert isinstance(stmt.from_clause, A.JoinClause)
    assert stmt.from_clause.kind == "cross"


def test_select_from_subquery_alias_required():
    with pytest.raises(ParseError):
        parse_one("SELECT * FROM (SELECT 1)")


def test_chained_in_with_subquery():
    stmt = parse_one("SELECT * FROM t WHERE id IN (SELECT id FROM s WHERE x = 1)")
    assert isinstance(stmt.where, A.InSubquery)


def test_having_without_group_by():
    stmt = parse_one("SELECT COUNT(*) FROM t HAVING COUNT(*) > 0")
    assert stmt.having is not None


def test_offset_without_limit():
    stmt = parse_one("SELECT * FROM t ORDER BY id OFFSET 10")
    assert stmt.offset is not None


def test_limit_with_arithmetic_expression():
    stmt = parse_one("SELECT * FROM t LIMIT 10 + 5")
    assert isinstance(stmt.limit, A.BinaryOp)


def test_distinct_keyword_inside_aggregate():
    stmt = parse_one("SELECT COUNT(DISTINCT x) FROM t")
    fn = stmt.projections[0].expr
    assert isinstance(fn, A.FunctionCall)
    assert fn.distinct


def test_select_no_from_clause():
    stmt = parse_one("SELECT 1 + 2")
    assert stmt.from_clause is None


def test_create_table_with_unique_column():
    stmt = parse_one("CREATE TABLE t (id INT UNIQUE)")
    assert stmt.columns[0].unique


def test_column_with_default_literal():
    stmt = parse_one("CREATE TABLE t (id INT DEFAULT 0)")
    assert stmt.columns[0].default is not None


def test_column_with_check_predicate():
    stmt = parse_one("CREATE TABLE t (age INT CHECK (age >= 0))")
    assert stmt.columns[0].check is not None


def test_create_index_with_if_not_exists():
    stmt = parse_one("CREATE INDEX IF NOT EXISTS idx ON t (a)")
    assert stmt.if_not_exists


def test_explain_analyze_inner_select():
    stmt = parse_one("EXPLAIN ANALYZE SELECT 1")
    assert isinstance(stmt, A.ExplainStmt)
    assert stmt.analyze
