from __future__ import annotations

import pytest

from pebble.parser.parser import parse_one
from pebble.parser.printer import render


@pytest.mark.parametrize("sql", [
    "SELECT 1",
    "SELECT 1 + 2 * 3",
    "SELECT id, name FROM t",
    "SELECT * FROM t WHERE id = 5",
    "SELECT a, b FROM t WHERE a IN (1, 2, 3)",
    "SELECT a FROM t WHERE a IS NULL",
    "SELECT a FROM t WHERE a IS NOT NULL",
    "SELECT a FROM t ORDER BY a DESC LIMIT 10 OFFSET 5",
    "SELECT a, COUNT(*) FROM t GROUP BY a HAVING COUNT(*) > 2",
    "SELECT a FROM t WHERE a BETWEEN 1 AND 10",
    "SELECT a FROM t WHERE name LIKE 'a%'",
    "INSERT INTO t (a, b) VALUES (1, 'x')",
    "UPDATE t SET a = 1 WHERE id = 5",
    "DELETE FROM t WHERE id = 5",
    "CREATE TABLE t (id INT NOT NULL, name TEXT)",
])
def test_round_trip(sql: str):
    rendered = render(parse_one(sql))
    # Re-parse the output -- it must yield the same AST.
    rerendered = render(parse_one(rendered))
    assert rerendered == rendered


def test_select_distinct_round_trip():
    out = render(parse_one("SELECT DISTINCT name FROM t"))
    assert "DISTINCT" in out


def test_join_round_trip():
    out = render(parse_one("SELECT * FROM a INNER JOIN b ON a.id = b.id"))
    assert "JOIN" in out


def test_create_index_round_trip():
    out = render(parse_one("CREATE UNIQUE INDEX idx ON t (a, b)"))
    assert "UNIQUE INDEX" in out
