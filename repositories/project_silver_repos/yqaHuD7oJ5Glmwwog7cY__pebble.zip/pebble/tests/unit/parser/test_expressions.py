from __future__ import annotations

import pytest

from pebble.parser import ast as A
from pebble.parser.parser import parse_one


def expr_of_select(sql: str) -> A.Expr:
    stmt = parse_one(sql)
    return stmt.projections[0].expr


def test_arithmetic_precedence_mul_before_add():
    expr = expr_of_select("SELECT 1 + 2 * 3")
    assert isinstance(expr, A.BinaryOp)
    assert expr.op == "+"
    assert isinstance(expr.right, A.BinaryOp)
    assert expr.right.op == "*"


def test_left_associative_subtraction():
    expr = expr_of_select("SELECT 10 - 3 - 2")
    assert isinstance(expr, A.BinaryOp)
    assert expr.op == "-"
    assert isinstance(expr.left, A.BinaryOp)


def test_unary_minus():
    expr = expr_of_select("SELECT -5")
    assert isinstance(expr, A.UnaryOp)
    assert expr.op == "-"


def test_paren_overrides_precedence():
    expr = expr_of_select("SELECT (1 + 2) * 3")
    assert isinstance(expr, A.BinaryOp)
    assert expr.op == "*"


def test_string_concat_with_pipes():
    expr = expr_of_select("SELECT 'a' || 'b'")
    assert isinstance(expr, A.BinaryOp)
    assert expr.op == "||"


def test_function_call_distinct_arg():
    expr = expr_of_select("SELECT COUNT(DISTINCT id) FROM t")
    # Note: expressions like that are extracted from projections of a non-empty FROM.
    stmt = parse_one("SELECT COUNT(DISTINCT id) FROM t")
    fn = stmt.projections[0].expr
    assert isinstance(fn, A.FunctionCall)
    assert fn.distinct


def test_count_star_specific_form():
    fn = expr_of_select("SELECT COUNT(*)")
    assert isinstance(fn, A.FunctionCall)
    assert fn.is_star


def test_chained_or_associates_left():
    stmt = parse_one("SELECT * FROM t WHERE a = 1 OR b = 2 OR c = 3")
    where = stmt.where
    assert isinstance(where, A.BinaryOp)
    assert where.op == "or"


def test_not_then_in():
    stmt = parse_one("SELECT * FROM t WHERE NOT x IN (1, 2)")
    where = stmt.where
    assert isinstance(where, A.UnaryOp)


def test_is_null_followed_by_and():
    stmt = parse_one("SELECT * FROM t WHERE a IS NULL AND b > 1")
    where = stmt.where
    assert isinstance(where, A.BinaryOp)
    assert where.op == "and"


def test_between_within_and():
    stmt = parse_one("SELECT * FROM t WHERE x BETWEEN 1 AND 10 AND y > 0")
    where = stmt.where
    assert isinstance(where, A.BinaryOp)
    assert where.op == "and"


def test_cast_with_length():
    stmt = parse_one("SELECT CAST(x AS VARCHAR(10)) FROM t")
    expr = stmt.projections[0].expr
    assert isinstance(expr, A.Cast)
    assert expr.target_length == 10


def test_case_simple_form():
    stmt = parse_one("SELECT CASE x WHEN 1 THEN 'one' WHEN 2 THEN 'two' END FROM t")
    expr = stmt.projections[0].expr
    assert isinstance(expr, A.Case)
    assert len(expr.when_clauses) == 2
