from __future__ import annotations

import pytest

from pebble.errors import ParseError
from pebble.parser import ast as A
from pebble.parser.parser import parse, parse_one


def test_simple_select():
    stmt = parse_one("SELECT a, b FROM t")
    assert isinstance(stmt, A.SelectStmt)
    assert len(stmt.projections) == 2


def test_select_star():
    stmt = parse_one("SELECT * FROM t")
    assert isinstance(stmt.projections[0].expr, A.Star)


def test_select_with_where():
    stmt = parse_one("SELECT a FROM t WHERE a > 1")
    assert isinstance(stmt.where, A.BinaryOp)
    assert stmt.where.op == ">"


def test_select_with_join_using():
    stmt = parse_one("SELECT * FROM a INNER JOIN b USING (id)")
    assert isinstance(stmt.from_clause, A.JoinClause)
    assert stmt.from_clause.kind == "inner"
    assert stmt.from_clause.using == ["id"]


def test_select_with_left_outer_join():
    stmt = parse_one("SELECT * FROM a LEFT OUTER JOIN b ON a.id = b.id")
    assert isinstance(stmt.from_clause, A.JoinClause)
    assert stmt.from_clause.kind == "left"


def test_group_by_having():
    stmt = parse_one("SELECT k, COUNT(*) FROM t GROUP BY k HAVING COUNT(*) > 1")
    assert len(stmt.group_by) == 1
    assert stmt.having is not None


def test_order_limit_offset():
    stmt = parse_one("SELECT * FROM t ORDER BY a DESC LIMIT 10 OFFSET 20")
    assert stmt.order_by[0].descending
    assert isinstance(stmt.limit, A.Literal)


def test_create_table():
    stmt = parse_one(
        "CREATE TABLE t (id INT PRIMARY KEY, name TEXT NOT NULL)"
    )
    assert isinstance(stmt, A.CreateTableStmt)
    assert stmt.columns[0].primary_key


def test_create_table_if_not_exists():
    stmt = parse_one("CREATE TABLE IF NOT EXISTS t (id INT)")
    assert stmt.if_not_exists


def test_insert_values():
    stmt = parse_one("INSERT INTO t (a, b) VALUES (1, 'x'), (2, 'y')")
    assert isinstance(stmt, A.InsertStmt)
    assert len(stmt.values) == 2


def test_update_set_where():
    stmt = parse_one("UPDATE t SET a = 1 WHERE id = 5")
    assert isinstance(stmt, A.UpdateStmt)
    assert stmt.assignments[0].column == "a"


def test_delete_where():
    stmt = parse_one("DELETE FROM t WHERE id = 1")
    assert isinstance(stmt, A.DeleteStmt)


def test_explain_wraps_inner():
    stmt = parse_one("EXPLAIN SELECT 1")
    assert isinstance(stmt, A.ExplainStmt)
    assert isinstance(stmt.inner, A.SelectStmt)


def test_with_cte():
    stmt = parse_one(
        "WITH x AS (SELECT 1 AS a) SELECT * FROM x"
    )
    assert isinstance(stmt, A.SelectStmt)
    assert len(stmt.ctes) == 1


def test_union_all():
    stmt = parse_one("SELECT 1 UNION ALL SELECT 2")
    assert stmt.set_op == "union_all"


def test_subquery_in_from():
    stmt = parse_one("SELECT * FROM (SELECT 1 AS a) AS s")
    assert isinstance(stmt.from_clause, A.SubqueryRef)


def test_in_list():
    stmt = parse_one("SELECT * FROM t WHERE id IN (1, 2, 3)")
    assert isinstance(stmt.where, A.InList)
    assert len(stmt.where.values) == 3


def test_in_subquery():
    stmt = parse_one("SELECT * FROM t WHERE id IN (SELECT id FROM s)")
    assert isinstance(stmt.where, A.InSubquery)


def test_between():
    stmt = parse_one("SELECT * FROM t WHERE x BETWEEN 1 AND 10")
    assert isinstance(stmt.where, A.Between)


def test_like():
    stmt = parse_one("SELECT * FROM t WHERE name LIKE 'a%'")
    assert isinstance(stmt.where, A.Like)


def test_case_when():
    stmt = parse_one("SELECT CASE WHEN x > 0 THEN 1 ELSE 0 END FROM t")
    expr = stmt.projections[0].expr
    assert isinstance(expr, A.Case)


def test_cast():
    stmt = parse_one("SELECT CAST(x AS TEXT) FROM t")
    expr = stmt.projections[0].expr
    assert isinstance(expr, A.Cast)


def test_drop_if_exists():
    stmt = parse_one("DROP TABLE IF EXISTS t")
    assert stmt.if_exists


def test_begin_commit_rollback():
    assert parse("BEGIN")[0].kind == "begin"
    assert parse("COMMIT")[0].kind == "commit"
    assert parse("ROLLBACK")[0].kind == "rollback"


def test_multi_statement_split_on_semicolon():
    stmts = parse("SELECT 1; SELECT 2;")
    assert len(stmts) == 2


def test_empty_input_raises():
    with pytest.raises(ParseError):
        parse_one(";")
