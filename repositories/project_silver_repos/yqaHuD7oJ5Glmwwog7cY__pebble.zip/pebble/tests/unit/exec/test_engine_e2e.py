from __future__ import annotations

import pytest


def test_create_insert_select(engine):
    engine.execute_sql("CREATE TABLE t (id INT, name TEXT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 'alice'), (2, 'bob')")
    result = engine.execute_sql("SELECT id, name FROM t")
    assert result.row_count == 2


def test_select_with_filter(engine):
    engine.execute_sql("CREATE TABLE t (id INT, name TEXT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 'alice'), (2, 'bob')")
    result = engine.execute_sql("SELECT name FROM t WHERE id = 2")
    assert result.row_count == 1
    assert result.rows[0][0].payload == "bob"


def test_update_assignments(engine):
    engine.execute_sql("CREATE TABLE t (id INT, balance INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 100), (2, 50)")
    engine.execute_sql("UPDATE t SET balance = balance + 10 WHERE id = 1")
    result = engine.execute_sql("SELECT balance FROM t WHERE id = 1")
    assert result.rows[0][0].payload == 110


def test_delete_predicate(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    engine.execute_sql("DELETE FROM t WHERE id = 2")
    result = engine.execute_sql("SELECT id FROM t")
    assert result.row_count == 2


def test_aggregate_count(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    result = engine.execute_sql("SELECT COUNT(*) FROM t")
    assert result.rows[0][0].payload == 3


def test_aggregate_sum(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")
    result = engine.execute_sql("SELECT SUM(id) FROM t")
    assert result.rows[0][0].payload == 6


def test_drop_table(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("DROP TABLE t")
    with pytest.raises(Exception):
        engine.execute_sql("SELECT * FROM t")


def test_drop_if_exists_idempotent(engine):
    engine.execute_sql("DROP TABLE IF EXISTS nonexistent")


def test_explain_returns_plan_text(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("EXPLAIN SELECT id FROM t")
    assert result.row_count > 0
