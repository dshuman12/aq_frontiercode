from __future__ import annotations

from pebble.exec.trace import trace_iter
from pebble.types.value import Value


def test_trace_counts_rows():
    rows = iter([{"a": Value.of(i)} for i in range(5)])
    wrapped, node = trace_iter("SeqScan", rows)
    assert list(wrapped) and node.rows == 5


def test_trace_records_max_row_width():
    rows = iter([{"a": Value.of("hello world")}, {"a": Value.of("hi")}])
    wrapped, node = trace_iter("SeqScan", rows)
    list(wrapped)
    assert node.max_row_width >= len("hello world")


def test_trace_render_has_operator_label():
    rows = iter([{"a": Value.of(1)}])
    wrapped, node = trace_iter("HashJoin", rows)
    list(wrapped)
    assert "HashJoin" in node.render()


def test_trace_skips_null_widths():
    rows = iter([{"a": Value.null()}])
    wrapped, node = trace_iter("SeqScan", rows)
    list(wrapped)
    assert node.max_row_width == 0
