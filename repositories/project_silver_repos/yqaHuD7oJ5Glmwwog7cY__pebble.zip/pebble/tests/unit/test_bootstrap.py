from __future__ import annotations

import pytest

from pebble.catalog import Catalog
from pebble.catalog.bootstrap import bootstrap, is_system_table


def test_bootstrap_creates_system_tables():
    cat = Catalog()
    bootstrap(cat)
    assert cat.has_table("pebble_tables")
    assert cat.has_table("pebble_columns")
    assert cat.has_table("pebble_indexes")
    assert cat.has_table("pebble_stats")


def test_bootstrap_is_idempotent():
    cat = Catalog()
    bootstrap(cat)
    bootstrap(cat)  # would raise on duplicate if non-idempotent
    assert len(cat.tables()) == 4


def test_is_system_table():
    assert is_system_table("pebble_tables")
    assert not is_system_table("orders")


def test_pebble_columns_has_expected_schema():
    cat = Catalog()
    bootstrap(cat)
    cols = cat.get_table("pebble_columns").columns
    names = [c.name for c in cols]
    assert names == ["table_oid", "ordinal", "name", "type", "is_nullable", "is_primary_key"]
