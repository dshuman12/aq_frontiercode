from __future__ import annotations

from pathlib import Path

import pytest

from pebble.btree import Btree
from pebble.buffer.pool import BufferPool
from pebble.storage.heap import HeapFile, TupleId


@pytest.fixture
def tree(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "btree.pdb"))
    pool = BufferPool(heap, capacity=64)
    yield Btree.bootstrap(pool)
    heap.close()


def test_insert_search_round_trip(tree):
    tree.insert(b"alice", TupleId(1, 0))
    assert tree.search(b"alice") == TupleId(1, 0)


def test_missing_key_returns_none(tree):
    assert tree.search(b"missing") is None


def test_inserts_keep_order(tree):
    keys = [b"d", b"b", b"a", b"c"]
    for i, k in enumerate(keys):
        tree.insert(k, TupleId(i, 0))
    out = [k for k, _ in tree.range()]
    assert out == sorted(keys)


def test_range_with_bounds(tree):
    for i in range(10):
        tree.insert(f"k{i:02d}".encode(), TupleId(i, 0))
    out = [k for k, _ in tree.range(start=b"k02", end=b"k05")]
    assert out == [b"k02", b"k03", b"k04", b"k05"]


def test_overwrite_existing_key(tree):
    tree.insert(b"a", TupleId(1, 0))
    tree.insert(b"a", TupleId(2, 0))
    assert tree.search(b"a") == TupleId(2, 0)


def test_delete_removes_key(tree):
    tree.insert(b"a", TupleId(1, 0))
    assert tree.delete(b"a")
    assert tree.search(b"a") is None


def test_split_grows_root(tree):
    # Insert enough small keys to force a leaf split + root growth.
    for i in range(400):
        tree.insert(f"k{i:05d}".encode(), TupleId(i, 0))
    stats = tree.stats()
    assert stats.entry_count == 400
    assert stats.leaf_count >= 2


def test_range_start_only(tree):
    for i in range(5):
        tree.insert(f"k{i}".encode(), TupleId(i, 0))
    out = [k for k, _ in tree.range(start=b"k2")]
    assert out == [b"k2", b"k3", b"k4"]
