from __future__ import annotations

import pytest

from pebble.errors import NetworkError
from pebble.protocol.frame import Frame, decode_one


def test_query_frame_round_trip():
    frame = Frame.query("SELECT 1")
    encoded = frame.encode()
    decoded, n = decode_one(encoded)
    assert decoded.kind == frame.kind
    assert decoded.payload.decode() == "SELECT 1"
    assert n == len(encoded)


def test_complete_frame_payload():
    frame = Frame.complete("SELECT", 5)
    decoded, _ = decode_one(frame.encode())
    import json

    assert json.loads(decoded.payload)["rows"] == 5


def test_error_frame_payload():
    frame = Frame.error("PE9999", "boom")
    decoded, _ = decode_one(frame.encode())
    import json

    body = json.loads(decoded.payload)
    assert body["code"] == "PE9999"


def test_truncated_header_raises():
    with pytest.raises(NetworkError):
        decode_one(b"\x01\x00")  # too short


def test_truncated_payload_raises():
    frame = Frame.query("SELECT 1")
    encoded = frame.encode()
    with pytest.raises(NetworkError):
        decode_one(encoded[:-2])


def test_blob_round_trip():
    frame = Frame.row([{"__blob__": "deadbeef"}])
    encoded = frame.encode()
    decoded, _ = decode_one(encoded)
    import json

    assert json.loads(decoded.payload) == [{"__blob__": "deadbeef"}]
