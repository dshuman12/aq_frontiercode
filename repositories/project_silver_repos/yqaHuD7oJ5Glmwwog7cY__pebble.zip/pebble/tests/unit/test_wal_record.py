from __future__ import annotations

import pytest

from pebble.constants import WAL_REC_INSERT
from pebble.errors import CorruptWal
from pebble.wal.record import WalRecord, insert_payload


def test_record_round_trip():
    record = WalRecord(
        type=WAL_REC_INSERT, lsn=1, prev_lsn=0, txn_id=42,
        payload=insert_payload(page_id=1, slot=0, tuple_bytes=b"hello"),
    )
    encoded = record.encode()
    decoded = WalRecord.decode(encoded)
    assert decoded.lsn == record.lsn
    assert decoded.payload == record.payload


def test_record_crc_failure():
    record = WalRecord(type=WAL_REC_INSERT, lsn=1, prev_lsn=0, txn_id=42, payload=b"abc")
    encoded = bytearray(record.encode())
    encoded[-1] ^= 0xFF  # flip a payload byte
    with pytest.raises(CorruptWal):
        WalRecord.decode(bytes(encoded))
