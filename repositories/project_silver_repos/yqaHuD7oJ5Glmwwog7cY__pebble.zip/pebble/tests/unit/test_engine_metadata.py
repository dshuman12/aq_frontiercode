from __future__ import annotations

import pytest


def test_engine_exposes_catalog(engine):
    assert engine.catalog is not None
    assert hasattr(engine.catalog, "tables")


def test_engine_query_result_columns(engine):
    engine.execute_sql("CREATE TABLE t (id INT, name TEXT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 'alice')")
    result = engine.execute_sql("SELECT id, name FROM t")
    assert result.columns == ["id", "name"]


def test_engine_query_result_tag(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("SELECT id FROM t")
    assert result.tag == "SELECT"


def test_engine_dml_returns_rows_affected(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2)")
    result = engine.execute_sql("UPDATE t SET id = id + 1")
    assert result.rows_affected == 2
