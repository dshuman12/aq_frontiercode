from __future__ import annotations

from pebble.catalog import Catalog, Column, ColumnStats, TableStats
from pebble.optimizer.statistics_loader import StatisticsView, TableSummary
from pebble.types import INT


def make_catalog():
    cat = Catalog()
    cat.create_table(name="t", columns=[
        Column(name="id", type=INT, ordinal=0, is_primary_key=True),
        Column(name="v", type=INT, ordinal=1),
    ])
    cat.get_table("t").stats = TableStats(
        row_count=100, page_count=10,
        columns={"v": ColumnStats(distinct_count=20, histogram_bounds=(10, 50, 90))},
    )
    return cat


def test_summary_returns_table_facts():
    view = StatisticsView(make_catalog())
    summary = view.summary("t")
    assert summary.row_count == 100


def test_summary_for_unknown_table_is_safe():
    view = StatisticsView(make_catalog())
    summary = view.summary("missing")
    assert summary.row_count == 1


def test_equality_selectivity_uses_distinct_count():
    view = StatisticsView(make_catalog())
    sel = view.selectivity("t", "v", "=", 11)
    assert 0 < sel < 1


def test_range_selectivity_monotonic():
    view = StatisticsView(make_catalog())
    low = view.selectivity("t", "v", "<", 10)
    high = view.selectivity("t", "v", "<", 100)
    assert high > low


def test_unknown_op_returns_one_half():
    view = StatisticsView(make_catalog())
    sel = view.selectivity("t", "v", "??", 0)
    assert sel == 0.5
