from __future__ import annotations

from hypothesis import given, settings, strategies as st

from pebble.types.encoding import decode_tuple, encode_tuple
from pebble.types.sqltype import BIGINT, BOOL, DOUBLE, INT, TEXT
from pebble.types.value import Value


@given(values=st.lists(st.integers(min_value=-(2**31), max_value=2**31 - 1), min_size=1, max_size=10))
@settings(deadline=None)
def test_int_tuple_round_trip(values):
    types = [INT] * len(values)
    payloads = [Value.of(v) for v in values]
    decoded = decode_tuple(types, encode_tuple(types, payloads))
    assert [v.payload for v in decoded] == values


@given(text=st.text(min_size=0, max_size=200))
@settings(deadline=None)
def test_text_round_trip(text):
    decoded = decode_tuple([TEXT], encode_tuple([TEXT], [Value.of(text)]))
    assert decoded[0].payload == text


@given(blob=st.binary(min_size=0, max_size=200))
@settings(deadline=None)
def test_blob_round_trip(blob):
    from pebble.types.sqltype import BLOB

    decoded = decode_tuple([BLOB], encode_tuple([BLOB], [Value.of(blob)]))
    assert decoded[0].payload == blob


@given(value=st.floats(allow_nan=False, allow_infinity=False, width=64))
@settings(deadline=None)
def test_double_round_trip(value):
    decoded = decode_tuple([DOUBLE], encode_tuple([DOUBLE], [Value.of(value)]))
    assert decoded[0].payload == value


@given(value=st.booleans())
@settings(deadline=None)
def test_bool_round_trip(value):
    decoded = decode_tuple([BOOL], encode_tuple([BOOL], [Value.of(value)]))
    assert decoded[0].payload is value


@given(values=st.lists(
    st.one_of(
        st.integers(min_value=-(2**31), max_value=2**31 - 1),
        st.none(),
    ),
    min_size=1,
    max_size=20,
))
@settings(deadline=None)
def test_null_bitmap_handles_mixed_rows(values):
    types = [INT] * len(values)
    payloads = [Value.null() if v is None else Value.of(v) for v in values]
    decoded = decode_tuple(types, encode_tuple(types, payloads))
    for original, got in zip(values, decoded):
        if original is None:
            assert got.is_null
        else:
            assert got.payload == original
