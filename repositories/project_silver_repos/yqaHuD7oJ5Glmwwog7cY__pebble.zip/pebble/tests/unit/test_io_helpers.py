from __future__ import annotations

from pathlib import Path

from pebble.utils.io import (
    atomic_write_bytes,
    ensure_directory,
    heap_file_path,
    snapshot_path,
    wal_dir,
)


def test_ensure_directory_creates_missing(tmp_path: Path):
    target = tmp_path / "nested" / "subdir"
    out = ensure_directory(str(target))
    assert out.is_dir()


def test_ensure_directory_idempotent(tmp_path: Path):
    target = tmp_path / "x"
    ensure_directory(str(target))
    ensure_directory(str(target))


def test_atomic_write_bytes_roundtrip(tmp_path: Path):
    path = str(tmp_path / "f.bin")
    atomic_write_bytes(path, b"hello")
    with open(path, "rb") as fh:
        assert fh.read() == b"hello"


def test_heap_file_path_format():
    assert heap_file_path("/var/data", 1).endswith("0000000001.pdb")


def test_snapshot_path_format():
    assert "snapshots" in snapshot_path("/var/data", 100)


def test_wal_dir_format():
    assert wal_dir("/var/data").endswith("wal")
