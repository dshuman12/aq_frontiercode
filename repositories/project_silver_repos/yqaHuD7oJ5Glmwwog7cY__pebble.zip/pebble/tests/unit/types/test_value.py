from __future__ import annotations

import pytest

from pebble.types.value import Value, add, boolean_and, boolean_or, div, sub


def test_null_equality_returns_null():
    a = Value.of(1)
    b = Value.null()
    assert a.equals(b).is_null


def test_equality_true():
    assert Value.of(1).equals(Value.of(1)).is_true


def test_less_than():
    assert Value.of(1).less_than(Value.of(2)).is_true
    assert Value.of(2).less_than(Value.of(1)).is_false


def test_addition_promotes_int_to_float():
    out = add(Value.of(1), Value.of(2.5))
    assert out.payload == 3.5


def test_subtraction_with_null():
    assert sub(Value.of(1), Value.null()).is_null


def test_division_by_zero_raises():
    from pebble.errors import DivisionByZero

    with pytest.raises(DivisionByZero):
        div(Value.of(1), Value.of(0))


def test_boolean_and_short_circuits_on_false():
    assert boolean_and(Value.of(False), Value.null()).is_false


def test_boolean_or_short_circuits_on_true():
    assert boolean_or(Value.of(True), Value.null()).is_true


def test_three_way_compare_handles_null():
    assert Value.null().cmp(Value.of(1)) is None
    assert Value.of(1).cmp(Value.of(1)) == 0


def test_cannot_compare_string_to_int():
    from pebble.errors import TypeMismatch

    with pytest.raises(TypeMismatch):
        Value.of("a").cmp(Value.of(1))
