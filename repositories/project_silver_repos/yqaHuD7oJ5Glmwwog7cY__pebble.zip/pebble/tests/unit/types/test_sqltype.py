from __future__ import annotations

import pytest

from pebble.types.sqltype import (
    BIGINT,
    BOOL,
    DOUBLE,
    INT,
    NULL,
    TEXT,
    TIMESTAMP,
    SqlType,
    can_coerce,
    common_type,
    parse_type,
)


def test_int_lt_bigint_in_lattice():
    assert common_type(INT, BIGINT) == BIGINT


def test_numeric_promotes_to_double():
    assert common_type(INT, DOUBLE) == DOUBLE


def test_null_coercion_keeps_other_type():
    out = common_type(NULL, INT)
    assert out.code == INT.code
    assert out.nullable is True


def test_text_with_length_picks_max():
    a = SqlType(TEXT.code, length=10)
    b = SqlType(TEXT.code, length=20)
    out = common_type(a, b)
    assert out.length == 20


def test_can_coerce_int_to_double():
    assert can_coerce(INT, DOUBLE)


def test_cannot_coerce_text_to_int():
    assert not can_coerce(TEXT, INT)


def test_parse_type_aliases():
    assert parse_type("INTEGER").code == INT.code
    assert parse_type("VARCHAR").code == TEXT.code
    assert parse_type("BOOLEAN").code == BOOL.code


def test_parse_unknown_raises():
    with pytest.raises(ValueError):
        parse_type("WUT")


def test_numeric_requires_precision():
    with pytest.raises(ValueError):
        SqlType(parse_type("NUMERIC", length=10).code)
