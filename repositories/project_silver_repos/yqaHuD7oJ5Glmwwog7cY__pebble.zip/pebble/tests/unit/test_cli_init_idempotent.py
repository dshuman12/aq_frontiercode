from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from pebble.cli.cmd_init import init


def test_init_creates_when_missing(tmp_path: Path):
    runner = CliRunner()
    target = tmp_path / "fresh"
    result = runner.invoke(init, [str(target)])
    assert result.exit_code == 0
    assert (target / "wal").is_dir()


def test_init_succeeds_on_existing_directory(tmp_path: Path):
    runner = CliRunner()
    target = tmp_path / "existing"
    target.mkdir()
    result = runner.invoke(init, [str(target)])
    assert result.exit_code == 0


def test_init_creates_heap_subdir(tmp_path: Path):
    runner = CliRunner()
    target = tmp_path / "demo"
    runner.invoke(init, [str(target)])
    assert (target / "heaps").is_dir()
