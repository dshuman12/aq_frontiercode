from __future__ import annotations

import pytest

from pebble.constants import (
    HEAP_PAGE_KIND,
    PAGE_HEADER_SIZE,
    PAGE_SIZE,
    WAL_REC_COMMIT,
)
from pebble.utils.hashing import name_hash
from pebble.utils.io import heap_file_path, snapshot_path, wal_dir


def test_constants_are_consistent():
    assert PAGE_SIZE > PAGE_HEADER_SIZE
    assert HEAP_PAGE_KIND != WAL_REC_COMMIT


def test_name_hash_is_32_bit():
    h = name_hash("orders")
    assert 0 <= h < 2 ** 32


def test_heap_file_path_includes_oid():
    path = heap_file_path("/tmp/data", 1234)
    assert "1234" in path


def test_snapshot_path_uses_lsn_zero_pad():
    path = snapshot_path("/tmp/data", 7)
    assert path.endswith("0000000000000000.snap" if False else ".snap")


def test_wal_dir_relative_to_data_dir():
    assert wal_dir("/tmp/data").endswith("wal")
