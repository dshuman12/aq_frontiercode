from __future__ import annotations

from pebble.txn.manager import Snapshot, TxnManager
from pebble.txn.snapshot_reader import TupleVisibility, filter_visible, is_self_writable


def make_snapshot(active=()):
    return Snapshot(xmin_horizon=10, xmax_horizon=200, active_txns=frozenset(active))


def test_visible_when_xmin_committed():
    snap = make_snapshot()
    vis = TupleVisibility(xmin=50, xmax=0)
    assert vis.is_visible(snap)


def test_invisible_when_xmin_active():
    snap = make_snapshot(active=[150])
    vis = TupleVisibility(xmin=150, xmax=0)
    assert not vis.is_visible(snap)


def test_filter_visible_returns_payloads():
    snap = make_snapshot()
    items = [
        (TupleVisibility(xmin=50, xmax=0), "keep"),
        (TupleVisibility(xmin=300, xmax=0), "drop"),
    ]
    assert filter_visible(items, snapshot=snap) == ["keep"]


def test_self_writable_requires_unwritten_tuple():
    mgr = TxnManager()
    state = mgr.begin()
    vis = TupleVisibility(xmin=state.txn_id - 1, xmax=0)
    assert is_self_writable(state, vis)


def test_self_writable_blocks_other_writer():
    mgr = TxnManager()
    other = mgr.begin()
    me = mgr.begin()
    vis = TupleVisibility(xmin=me.txn_id - 1, xmax=other.txn_id)
    assert not is_self_writable(me, vis)
