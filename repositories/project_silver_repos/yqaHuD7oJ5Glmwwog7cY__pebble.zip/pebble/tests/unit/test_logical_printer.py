from __future__ import annotations

from pebble.parser import ast as A
from pebble.plan.logical import (
    Aggregate,
    Filter,
    Limit,
    Project,
    Scan,
    Sort,
)
from pebble.plan.logical_printer import render


def test_render_scan_with_projected_columns():
    plan = Scan(table="t", projected_columns=("a", "b"))
    text = render(plan)
    assert "Scan(table=t" in text
    assert "projected=a,b" in text


def test_render_filter_includes_predicate():
    plan = Filter(input=Scan(table="t"),
                  predicate=A.BinaryOp(op="=", left=A.ColumnRef(name="a"),
                                       right=A.Literal(value=1)))
    text = render(plan)
    assert "Filter" in text and "=" in text


def test_render_project_lists_aliases():
    plan = Project(
        input=Scan(table="t"),
        projections=[(A.ColumnRef(name="a"), "out")],
    )
    text = render(plan)
    assert "AS out" in text


def test_render_limit_includes_offset():
    plan = Limit(input=Scan(table="t"),
                 limit=A.Literal(value=10), offset=A.Literal(value=5))
    text = render(plan)
    assert "Limit" in text and "offset" in text


def test_render_sort_marks_descending():
    plan = Sort(input=Scan(table="t"),
                order=[(A.ColumnRef(name="a"), True)])
    text = render(plan)
    assert "DESC" in text


def test_render_aggregate_lists_groups():
    plan = Aggregate(input=Scan(table="t"),
                     group_keys=[A.ColumnRef(name="a")],
                     aggregates=[(A.FunctionCall(name="COUNT", is_star=True), "n")])
    text = render(plan)
    assert "Aggregate" in text
    assert "COUNT" in text
