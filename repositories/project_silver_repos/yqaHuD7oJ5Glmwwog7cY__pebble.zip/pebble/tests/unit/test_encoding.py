from __future__ import annotations

from datetime import date, datetime, timezone

import pytest

from pebble.errors import StorageError
from pebble.types import (
    BIGINT,
    BLOB,
    BOOL,
    DATE,
    DOUBLE,
    INT,
    TEXT,
    TIMESTAMP,
    Value,
    decode_tuple,
    encode_tuple,
)


def test_encode_decode_round_trip_basic():
    types = [INT, TEXT, BOOL]
    values = [Value.of(42), Value.of("hello"), Value.of(True)]
    raw = encode_tuple(types, values)
    decoded = decode_tuple(types, raw)
    assert decoded[0].payload == 42
    assert decoded[1].payload == "hello"
    assert decoded[2].payload is True


def test_encode_handles_null_with_bitmap():
    types = [INT, TEXT, BOOL]
    values = [Value.of(1), Value.null(), Value.of(False)]
    raw = encode_tuple(types, values)
    decoded = decode_tuple(types, raw)
    assert decoded[1].is_null


def test_encode_decode_blob():
    types = [BLOB]
    values = [Value.of(b"\x00\x01\x02")]
    decoded = decode_tuple(types, encode_tuple(types, values))
    assert decoded[0].payload == b"\x00\x01\x02"


def test_encode_decode_double():
    types = [DOUBLE]
    values = [Value.of(3.14159)]
    decoded = decode_tuple(types, encode_tuple(types, values))
    assert abs(decoded[0].payload - 3.14159) < 1e-9


def test_encode_date_round_trip():
    types = [DATE]
    values = [Value.of(date(2024, 6, 1))]
    decoded = decode_tuple(types, encode_tuple(types, values))
    assert decoded[0].payload == date(2024, 6, 1)


def test_encode_timestamp_round_trip():
    types = [TIMESTAMP]
    values = [Value.of(datetime(2024, 6, 1, 12, 30, tzinfo=timezone.utc))]
    decoded = decode_tuple(types, encode_tuple(types, values))
    assert decoded[0].payload.year == 2024


def test_decode_count_mismatch_raises():
    types = [INT, INT]
    raw = encode_tuple(types, [Value.of(1), Value.of(2)])
    with pytest.raises(StorageError):
        decode_tuple([INT, INT, INT], raw)


def test_encode_value_count_mismatch():
    with pytest.raises(StorageError):
        encode_tuple([INT, INT], [Value.of(1)])
