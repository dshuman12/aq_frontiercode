from __future__ import annotations

from pebble.catalog import Catalog, Column, TableStats
from pebble.config import OptimizerConfig
from pebble.optimizer.cost import CostModel, reorder_joins
from pebble.types import INT


def make_catalog(sizes: dict[str, tuple[int, int]]) -> Catalog:
    cat = Catalog()
    for name, (rows, pages) in sizes.items():
        cat.create_table(
            name=name,
            columns=[Column(name="id", type=INT, ordinal=0, is_primary_key=True)],
        )
        cat.get_table(name).stats = TableStats(row_count=rows, page_count=pages)
    return cat


def test_scan_cost_grows_with_pages():
    cat = make_catalog({"t": (1000, 50)})
    cost = CostModel(OptimizerConfig())
    rows, total = cost.scan_cost(cat.get_table("t"))
    assert rows == 1000
    assert total > 0


def test_join_reorder_picks_smaller_first():
    cat = make_catalog({
        "small": (10, 1),
        "medium": (1_000, 10),
        "large": (1_000_000, 5_000),
    })
    cost = CostModel(OptimizerConfig())
    order = reorder_joins(
        tables=["large", "small", "medium"], catalog=cat,
        cost_model=cost, cap=6,
    )
    # The smallest table should appear first in the output order.
    assert order[0] == "small"


def test_reorder_no_op_for_single_table():
    cat = make_catalog({"t": (10, 1)})
    cost = CostModel(OptimizerConfig())
    assert reorder_joins(tables=["t"], catalog=cat, cost_model=cost, cap=6) == ["t"]


def test_reorder_skips_when_too_many_tables():
    cat = make_catalog({f"t{i}": (10, 1) for i in range(10)})
    cost = CostModel(OptimizerConfig())
    tables = list(cat._tables)  # noqa: SLF001 - test internals access
    out = reorder_joins(tables=tables, catalog=cat, cost_model=cost, cap=4)
    assert out == tables  # punt when over the cap
