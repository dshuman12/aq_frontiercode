from __future__ import annotations

from pebble.txn.snapshot import empty, for_committed_only, with_active


def test_empty_snapshot_visible_to_self():
    snap = empty()
    assert not snap.is_visible(xmin=200, xmax=0)


def test_for_committed_only_includes_range():
    snap = for_committed_only(min_committed=100, max_committed=199)
    assert snap.is_visible(xmin=100, xmax=0)
    assert snap.is_visible(xmin=199, xmax=0)
    assert not snap.is_visible(xmin=300, xmax=0)


def test_with_active_blocks_listed_txn():
    snap = with_active([150], horizon=200)
    assert not snap.is_visible(xmin=150, xmax=0)
    assert snap.is_visible(xmin=149, xmax=0)


def test_visibility_treats_xmax_set_to_active_as_live():
    snap = with_active([200], horizon=300)
    assert snap.is_visible(xmin=100, xmax=200)


def test_visibility_treats_xmax_set_to_committed_as_dead():
    snap = with_active([], horizon=300)
    assert not snap.is_visible(xmin=100, xmax=150)
