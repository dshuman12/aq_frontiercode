from __future__ import annotations

import pytest

from pebble.errors import (
    ColumnNotFound,
    DuplicateName,
    LexerError,
    PebbleError,
    SerializationFailure,
    TableNotFound,
)


def test_pebble_error_carries_position():
    err = PebbleError("boom").with_position(42)
    assert "42" in str(err)


def test_table_not_found_message_contains_name():
    err = TableNotFound("orders")
    assert "orders" in str(err)


def test_column_not_found_message_qualified():
    err = ColumnNotFound("x", table="t")
    assert "x" in str(err) and "t" in str(err)


def test_serialization_failure_default_code():
    err = SerializationFailure("conflict")
    assert err.code == "PE3002"


def test_lexer_error_inherits_pebble_error():
    err = LexerError("bad", position=5)
    assert isinstance(err, PebbleError)
    assert err.position == 5


def test_pebble_error_with_context():
    err = PebbleError("msg", context={"a": 1, "b": 2})
    assert err.context["a"] == 1


def test_duplicate_name_default_code():
    assert DuplicateName("dup").code == "PE1203"
