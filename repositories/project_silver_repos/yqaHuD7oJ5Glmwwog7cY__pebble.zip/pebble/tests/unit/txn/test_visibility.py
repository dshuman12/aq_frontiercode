from __future__ import annotations

import pytest

from pebble.errors import IsolationViolation, SerializationFailure
from pebble.txn.manager import TxnManager


def test_begin_assigns_unique_ids():
    mgr = TxnManager()
    a = mgr.begin()
    b = mgr.begin()
    assert a.txn_id != b.txn_id


def test_unknown_isolation_raises():
    mgr = TxnManager()
    with pytest.raises(IsolationViolation):
        mgr.begin(isolation="bizarre")


def test_visibility_old_committed_seen():
    mgr = TxnManager()
    txn = mgr.begin()
    # xmin smaller than xmax_horizon and not active -> visible.
    assert mgr.is_visible(txn, xmin=txn.txn_id - 10, xmax=0)


def test_visibility_active_other_txn_invisible():
    mgr = TxnManager()
    other = mgr.begin()
    txn = mgr.begin()
    assert not mgr.is_visible(txn, xmin=other.txn_id, xmax=0)


def test_visibility_self_visible():
    mgr = TxnManager()
    txn = mgr.begin()
    assert mgr.is_visible(txn, xmin=txn.txn_id - 1, xmax=0)


def test_write_conflict_raises():
    mgr = TxnManager()
    other = mgr.begin()
    me = mgr.begin()
    with pytest.raises(SerializationFailure):
        mgr.detect_write_conflict(me, xmin=other.txn_id, xmax=0)


def test_oldest_active_drops_after_commit():
    mgr = TxnManager()
    a = mgr.begin()
    b = mgr.begin()
    assert mgr.oldest_active_txn() == a.txn_id
    mgr.commit(a)
    assert mgr.oldest_active_txn() == b.txn_id


def test_active_count():
    mgr = TxnManager()
    mgr.begin()
    mgr.begin()
    assert mgr.active_count() == 2
