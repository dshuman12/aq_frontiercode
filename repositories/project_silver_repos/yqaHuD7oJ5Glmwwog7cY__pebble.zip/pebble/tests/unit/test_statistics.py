from __future__ import annotations

from pebble.catalog.statistics import gather, to_column_stats
from pebble.types.value import Value


def values(*payloads):
    return [Value.of(p) if p is not None else Value.null() for p in payloads]


def test_gather_counts_nulls():
    summary = gather(values(1, 2, None, 3, None))
    assert summary.null_count == 2
    assert summary.null_fraction == 2 / 5


def test_mcv_picked_from_repeats():
    summary = gather(values(1, 1, 1, 2, 3))
    assert summary.mcv[0][0] == 1


def test_equality_selectivity_uses_mcv():
    summary = gather(values(1, 1, 1, 2, 3))
    sel = summary.estimate_selectivity(op="=", value=1)
    assert sel >= 0.5


def test_range_selectivity_monotonic():
    summary = gather(values(*range(100)))
    low = summary.estimate_selectivity(op="<", value=10)
    high = summary.estimate_selectivity(op="<", value=90)
    assert high > low


def test_to_column_stats_round_trip():
    summary = gather(values(*range(10)))
    stats = to_column_stats(summary)
    assert stats.distinct_count > 0


def test_unknown_op_falls_back():
    summary = gather(values(1, 2, 3))
    sel = summary.estimate_selectivity(op="??", value=1)
    assert 0.0 <= sel <= 1.0
