from __future__ import annotations

import pytest

from pebble.catalog import Catalog, Column
from pebble.catalog.migrations import (
    AddColumn,
    DropColumn,
    Migration,
    RenameTable,
    from_yaml,
)
from pebble.errors import ColumnNotFound, DuplicateName, TableNotFound
from pebble.types import INT, TEXT


@pytest.fixture
def catalog():
    cat = Catalog()
    cat.create_table(name="t", columns=[
        Column(name="id", type=INT, ordinal=0, is_primary_key=True),
        Column(name="name", type=TEXT, ordinal=1),
    ])
    return cat


def test_add_column(catalog):
    AddColumn(description="add", table="t", name="age", type=INT).apply(catalog)
    assert catalog.get_table("t").has_column("age")


def test_add_column_duplicate_raises(catalog):
    with pytest.raises(DuplicateName):
        AddColumn(description="add", table="t", name="id", type=INT).apply(catalog)


def test_drop_column(catalog):
    DropColumn(description="drop", table="t", name="name").apply(catalog)
    assert not catalog.get_table("t").has_column("name")


def test_drop_unknown_column_raises(catalog):
    with pytest.raises(ColumnNotFound):
        DropColumn(description="drop", table="t", name="missing").apply(catalog)


def test_rename_table(catalog):
    RenameTable(description="rename", from_name="t", to_name="u").apply(catalog)
    assert catalog.has_table("u")
    assert not catalog.has_table("t")


def test_rename_unknown_raises(catalog):
    with pytest.raises(TableNotFound):
        RenameTable(description="x", from_name="missing", to_name="other").apply(catalog)


def test_migration_runs_steps_in_order(catalog):
    migration = Migration(
        name="m",
        steps=[
            AddColumn(description="age", table="t", name="age", type=INT),
            RenameTable(description="rename", from_name="t", to_name="u"),
        ],
    )
    migration.apply(catalog)
    assert catalog.has_table("u")
    assert catalog.get_table("u").has_column("age")


def test_from_yaml_builds_migration():
    payload = {
        "name": "m1",
        "steps": [
            {"kind": "add_column", "table": "t", "name": "age", "type": "INT"},
            {"kind": "rename_table", "from": "t", "to": "u"},
        ],
    }
    migration = from_yaml(payload)
    assert migration.name == "m1"
    assert len(migration.steps) == 2


def test_from_yaml_unknown_kind_raises():
    with pytest.raises(ValueError):
        from_yaml({"name": "x", "steps": [{"kind": "do_something_weird"}]})
