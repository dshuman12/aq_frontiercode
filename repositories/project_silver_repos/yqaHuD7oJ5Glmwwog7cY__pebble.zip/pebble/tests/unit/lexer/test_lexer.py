from __future__ import annotations

import pytest

from pebble.errors import LexerError
from pebble.lexer import Token, TokenKind, tokenize


def kinds(source: str) -> list[TokenKind]:
    return [t.kind for t in tokenize(source)]


def test_empty_source_yields_only_eof():
    toks = tokenize("")
    assert len(toks) == 1
    assert toks[0].kind == TokenKind.EOF


def test_whitespace_is_ignored():
    assert kinds("  \t\n  ") == [TokenKind.EOF]


def test_keyword_recognised():
    toks = tokenize("SELECT * FROM t")
    assert toks[0].is_keyword("SELECT")
    assert toks[1].kind == TokenKind.STAR
    assert toks[2].is_keyword("FROM")


def test_quoted_identifier_preserves_case():
    toks = tokenize('"MyTable"')
    assert toks[0].kind == TokenKind.QUOTED_IDENT
    assert toks[0].text == "MyTable"


def test_quoted_identifier_double_quote_escape():
    toks = tokenize('"a""b"')
    assert toks[0].text == 'a"b'


def test_integer_and_float_literals():
    toks = tokenize("123 4.5 6e7")
    assert toks[0].kind == TokenKind.INT
    assert toks[1].kind == TokenKind.FLOAT
    assert toks[2].kind == TokenKind.FLOAT


def test_string_literal_with_escaped_quote():
    toks = tokenize("'it''s'")
    assert toks[0].kind == TokenKind.STRING
    assert toks[0].text == "it's"


def test_blob_literal_hex():
    toks = tokenize("x'DEADBEEF'")
    assert toks[0].kind == TokenKind.BLOB
    assert toks[0].text.lower() == "deadbeef"


def test_blob_literal_odd_digits_rejected():
    with pytest.raises(LexerError):
        tokenize("x'ABC'")


def test_line_comment_skipped():
    toks = tokenize("SELECT 1 -- comment\n FROM t")
    texts = [t.text for t in toks if t.kind != TokenKind.EOF]
    assert "comment" not in texts


def test_block_comment_skipped():
    toks = tokenize("/* block */ SELECT 1")
    assert toks[0].is_keyword("SELECT")


def test_unterminated_block_comment_raises():
    with pytest.raises(LexerError):
        tokenize("/* never closed")


def test_two_char_operators():
    toks = tokenize(">= <= <> != ||")
    assert [t.kind for t in toks[:5]] == [
        TokenKind.GE, TokenKind.LE, TokenKind.NE, TokenKind.NE, TokenKind.CONCAT,
    ]


def test_unexpected_character_position():
    with pytest.raises(LexerError) as exc:
        tokenize("SELECT @ FROM t")
    assert "@" in str(exc.value)


def test_keyword_case_insensitive():
    assert tokenize("select")[0].is_keyword("SELECT")
    assert tokenize("Select")[0].is_keyword("SELECT")
