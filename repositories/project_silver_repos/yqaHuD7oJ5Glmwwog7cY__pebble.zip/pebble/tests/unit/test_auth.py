from __future__ import annotations

import re

from pebble.protocol.auth import (
    AuthChallenge,
    AuthRequest,
    constant_time_eq,
    md5_response,
    verify_md5,
)


def test_auth_request_default_method():
    req = AuthRequest(user="alice")
    assert req.method == "trust"


def test_auth_challenge_random():
    a = AuthChallenge.fresh()
    b = AuthChallenge.fresh()
    assert a.salt != b.salt


def test_md5_response_format():
    out = md5_response(user="alice", password="hunter2", salt="cafe")
    assert re.match(r"^md5[0-9a-f]{32}$", out)


def test_verify_md5_round_trip():
    salt = "deadbeef"
    response = md5_response(user="alice", password="hunter2", salt=salt)
    assert verify_md5(user="alice", password_hash="hunter2", salt=salt, response=response)


def test_verify_md5_rejects_wrong_password():
    salt = "deadbeef"
    response = md5_response(user="alice", password="hunter2", salt=salt)
    assert not verify_md5(user="alice", password_hash="wrong", salt=salt, response=response)


def test_constant_time_eq_basic():
    assert constant_time_eq("abc", "abc")
    assert not constant_time_eq("abc", "abd")
    assert not constant_time_eq("abc", "abcd")
