from __future__ import annotations

import threading
import time

import pytest

from pebble.errors import DeadlockDetected, LockTimeout
from pebble.lock.manager import LOCK_S, LOCK_X, LockManager, is_compatible


def test_compat_matrix_basics():
    assert is_compatible(LOCK_S, LOCK_S)
    assert not is_compatible(LOCK_X, LOCK_S)
    assert not is_compatible(LOCK_S, LOCK_X)


def test_acquire_compatible_lock():
    mgr = LockManager()
    mgr.acquire(1, "t", "row1", LOCK_S)
    mgr.acquire(2, "t", "row1", LOCK_S)


def test_release_all_unblocks_waiter():
    mgr = LockManager(timeout_ms=2000)
    mgr.acquire(1, "t", "row1", LOCK_X)

    holder_done = threading.Event()

    def waiter():
        mgr.acquire(2, "t", "row1", LOCK_S)
        holder_done.set()

    th = threading.Thread(target=waiter, daemon=True)
    th.start()
    time.sleep(0.05)
    mgr.release_all(1)
    assert holder_done.wait(timeout=2.0)


def test_lock_timeout():
    mgr = LockManager(timeout_ms=50)
    mgr.acquire(1, "t", "row1", LOCK_X)
    with pytest.raises(LockTimeout):
        mgr.acquire(2, "t", "row1", LOCK_X)
