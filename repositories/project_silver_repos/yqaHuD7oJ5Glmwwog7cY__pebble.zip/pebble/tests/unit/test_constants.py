from __future__ import annotations

from pebble.constants import (
    BTREE_INTERNAL_KIND,
    BTREE_LEAF_KIND,
    HEAP_PAGE_KIND,
    LSN_INVALID,
    MAX_KEY_SIZE,
    PAGE_HEADER_SIZE,
    PAGE_MAGIC,
    PAGE_SIZE,
    WAL_MAGIC,
    WAL_REC_BEGIN,
    WAL_REC_COMMIT,
)


def test_page_magic_is_pbl1():
    assert PAGE_MAGIC == b"PBL1"


def test_wal_magic_is_pbllog01():
    assert WAL_MAGIC == b"PBLLOG01"


def test_page_size_is_8k():
    assert PAGE_SIZE == 8192


def test_page_header_is_32_bytes():
    assert PAGE_HEADER_SIZE == 32


def test_kinds_are_distinct():
    kinds = {HEAP_PAGE_KIND, BTREE_LEAF_KIND, BTREE_INTERNAL_KIND}
    assert len(kinds) == 3


def test_wal_record_types_distinct():
    types = {WAL_REC_BEGIN, WAL_REC_COMMIT}
    assert len(types) == 2


def test_invalid_lsn_is_zero():
    assert LSN_INVALID == 0


def test_max_key_size_reasonable():
    assert 1024 <= MAX_KEY_SIZE <= PAGE_SIZE
