from __future__ import annotations

import pytest

from pebble.server.session import Session


def test_default_isolation_is_snapshot():
    s = Session()
    assert s.isolation == "snapshot"


def test_cache_and_lookup_plan():
    s = Session()
    s.cache_plan("SELECT 1", "fake-plan")
    assert s.lookup_plan("SELECT 1") == "fake-plan"
    assert s.cache_size() == 1


def test_lookup_increments_use_count():
    s = Session()
    s.cache_plan("SELECT 1", "p")
    s.lookup_plan("SELECT 1")
    s.lookup_plan("SELECT 1")
    assert s.prepared["SELECT 1"].use_count == 2


def test_evict_plan_removes_entry():
    s = Session()
    s.cache_plan("SELECT 1", "p")
    s.evict_plan("SELECT 1")
    assert s.lookup_plan("SELECT 1") is None


def test_cancel_consume_toggles():
    s = Session()
    assert not s.consume_cancel()
    s.request_cancel()
    assert s.consume_cancel()
    assert not s.consume_cancel()


def test_double_begin_raises():
    s = Session()
    s.begin(object())  # type: ignore[arg-type]
    with pytest.raises(RuntimeError):
        s.begin(object())  # type: ignore[arg-type]


def test_commit_clears_txn():
    s = Session()
    s.begin(object())  # type: ignore[arg-type]
    s.commit()
    assert s.txn is None
