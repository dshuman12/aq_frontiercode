from __future__ import annotations

import io


def test_dump_then_restore_via_sql(engine):
    engine.execute_sql("CREATE TABLE accounts (id INT PRIMARY KEY, owner TEXT, balance DOUBLE)")
    engine.execute_sql("INSERT INTO accounts VALUES (1, 'alice', 100.0)")
    engine.execute_sql("INSERT INTO accounts VALUES (2, 'bob', 50.0)")

    # Dump everything as SQL.
    buf = io.StringIO()
    for table in engine.catalog.tables():
        cols = ", ".join(f"{c.name} {c.type.render()}" for c in table.columns)
        buf.write(f"CREATE TABLE {table.name} ({cols});\n")
    for table_name, rows in engine.exec_ctx.rows.items():
        for row in rows:
            keys = [k for k in row if "." not in k]
            values = ", ".join(
                "NULL" if row[k].is_null else (
                    f"'{row[k].payload}'" if isinstance(row[k].payload, str) else repr(row[k].payload)
                )
                for k in keys
            )
            buf.write(f"INSERT INTO {table_name} ({', '.join(keys)}) VALUES ({values});\n")

    # Wipe the engine and replay.
    engine.execute_sql("DROP TABLE accounts")
    for line in buf.getvalue().splitlines():
        line = line.strip()
        if line and not line.startswith("--"):
            engine.execute_sql(line.rstrip(";"))

    result = engine.execute_sql("SELECT COUNT(*) FROM accounts")
    assert result.rows[0][0].payload == 2
