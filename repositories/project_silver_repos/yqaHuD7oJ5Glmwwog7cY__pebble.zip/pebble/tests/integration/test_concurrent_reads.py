from __future__ import annotations

import threading


def test_two_readers_both_see_committed_rows(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3)")

    results: dict[str, int] = {}

    def reader(label: str) -> None:
        result = engine.execute_sql("SELECT COUNT(*) FROM t")
        results[label] = result.rows[0][0].payload

    a = threading.Thread(target=reader, args=("a",))
    b = threading.Thread(target=reader, args=("b",))
    a.start(); b.start()
    a.join(); b.join()
    assert results == {"a": 3, "b": 3}


def test_writer_then_reader(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    write_done = threading.Event()

    def writer():
        for i in range(50):
            engine.execute_sql(f"INSERT INTO t VALUES ({i})")
        write_done.set()

    th = threading.Thread(target=writer)
    th.start()
    th.join()
    assert write_done.is_set()
    result = engine.execute_sql("SELECT COUNT(*) FROM t")
    assert result.rows[0][0].payload == 50
