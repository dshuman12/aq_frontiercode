from __future__ import annotations

import random
from pathlib import Path

import pytest

from pebble.btree import Btree
from pebble.buffer.pool import BufferPool
from pebble.storage.heap import HeapFile, TupleId


@pytest.fixture
def tree(tmp_path: Path):
    heap = HeapFile(str(tmp_path / "btree.pdb"))
    pool = BufferPool(heap, capacity=128)
    yield Btree.bootstrap(pool)
    heap.close()


def test_random_inserts_and_searches(tree):
    rng = random.Random(0)
    keys = list(range(1000))
    rng.shuffle(keys)
    for k in keys:
        tree.insert(f"k{k:05d}".encode(), TupleId(k, 0))
    rng.shuffle(keys)
    for k in keys[:100]:
        result = tree.search(f"k{k:05d}".encode())
        assert result == TupleId(k, 0)


def test_range_scan_after_random_inserts(tree):
    rng = random.Random(0)
    keys = list(range(200))
    rng.shuffle(keys)
    for k in keys:
        tree.insert(f"k{k:05d}".encode(), TupleId(k, 0))
    out = [k for k, _ in tree.range(start=b"k00050", end=b"k00059")]
    assert out == sorted(out)
    assert all(b"k00050" <= k <= b"k00059" for k in out)


def test_overwrite_then_re_search(tree):
    tree.insert(b"key", TupleId(1, 0))
    tree.insert(b"key", TupleId(2, 0))
    assert tree.search(b"key") == TupleId(2, 0)


def test_delete_after_many_inserts(tree):
    for i in range(50):
        tree.insert(f"k{i:03d}".encode(), TupleId(i, 0))
    assert tree.delete(b"k025")
    assert tree.search(b"k025") is None
    # Other keys still findable.
    assert tree.search(b"k000") == TupleId(0, 0)
    assert tree.search(b"k049") == TupleId(49, 0)
