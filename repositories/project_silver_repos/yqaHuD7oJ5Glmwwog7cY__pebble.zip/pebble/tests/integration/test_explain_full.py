from __future__ import annotations

import pytest


def test_explain_select_includes_filter(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v INT)")
    result = engine.execute_sql("EXPLAIN SELECT v FROM t WHERE id = 5")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "Filter" in text


def test_explain_select_includes_project(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("EXPLAIN SELECT id FROM t")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "ProjectNode" in text


def test_explain_join_uses_hash_join(engine):
    engine.execute_sql("CREATE TABLE a (id INT)")
    engine.execute_sql("CREATE TABLE b (id INT)")
    result = engine.execute_sql(
        "EXPLAIN SELECT * FROM a INNER JOIN b ON a.id = b.id"
    )
    text = "\n".join(r[0].payload for r in result.rows)
    assert "HashJoin" in text


def test_explain_aggregate_uses_hash_aggregate(engine):
    engine.execute_sql("CREATE TABLE t (k INT)")
    result = engine.execute_sql("EXPLAIN SELECT k, COUNT(*) FROM t GROUP BY k")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "HashAggregate" in text


def test_explain_sort_node_added_for_order_by(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    result = engine.execute_sql("EXPLAIN SELECT v FROM t ORDER BY v")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "SortNode" in text


def test_explain_limit_node(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    result = engine.execute_sql("EXPLAIN SELECT v FROM t LIMIT 10")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "LimitNode" in text or "Limit" in text
