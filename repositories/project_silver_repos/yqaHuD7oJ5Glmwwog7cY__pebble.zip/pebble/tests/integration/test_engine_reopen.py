from __future__ import annotations

from pathlib import Path

import pytest

from pebble.config import Config, set_config, reset_config
from pebble.server.engine import Engine


@pytest.fixture
def temporary_config(tmp_path: Path):
    set_config(Config(data_dir=tmp_path))
    yield tmp_path
    reset_config()


def test_open_close_idempotent(temporary_config: Path):
    eng = Engine()
    eng.open()
    eng.close()
    # close-after-close is fine
    eng.close()


def test_two_engines_share_directory(temporary_config: Path):
    a = Engine()
    a.open()
    a.execute_sql("CREATE TABLE t (id INT)")
    a.execute_sql("INSERT INTO t VALUES (1), (2)")
    a.close()

    b = Engine()
    b.open()
    try:
        # Catalog state is in-memory, so the second engine starts empty.
        # That's the documented behaviour; the test just pins it.
        assert not b.catalog.has_table("t")
    finally:
        b.close()


def test_engine_context_manager(temporary_config: Path):
    with Engine() as eng:
        eng.execute_sql("CREATE TABLE t (id INT)")
        result = eng.execute_sql("SELECT COUNT(*) FROM t")
        assert result.rows[0][0].payload == 0
