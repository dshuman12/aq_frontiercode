from __future__ import annotations

from pathlib import Path

import pytest

from pebble.constants import WAL_REC_BEGIN, WAL_REC_COMMIT, WAL_REC_INSERT
from pebble.wal.reader import WalReader
from pebble.wal.recovery import recover
from pebble.wal.record import insert_payload
from pebble.wal.writer import WalWriter


@pytest.fixture
def populated_wal(tmp_path: Path):
    writer = WalWriter(str(tmp_path), fsync=False)
    try:
        # Three transactions: one committed, one aborted-ish, one mid-flight.
        writer.append(type=WAL_REC_BEGIN, txn_id=10, prev_lsn=0, payload=b"")
        writer.append(
            type=WAL_REC_INSERT, txn_id=10, prev_lsn=0,
            payload=insert_payload(page_id=1, slot=0, tuple_bytes=b"r1"),
        )
        writer.append(type=WAL_REC_COMMIT, txn_id=10, prev_lsn=0, payload=b"")

        writer.append(type=WAL_REC_BEGIN, txn_id=11, prev_lsn=0, payload=b"")
        writer.append(
            type=WAL_REC_INSERT, txn_id=11, prev_lsn=0,
            payload=insert_payload(page_id=2, slot=0, tuple_bytes=b"r2"),
        )
        # txn 11 never commits -- recovery should undo it.

        writer.flush()
    finally:
        writer.close()
    return str(tmp_path)


def test_recovery_redoes_committed_records(populated_wal: str):
    redo_calls: list[int] = []
    undo_calls: list[int] = []

    def redo(rec):
        redo_calls.append(rec.txn_id)

    def undo(rec):
        undo_calls.append(rec.txn_id)

    report = recover(
        wal_reader=WalReader(populated_wal),
        apply_redo=redo, apply_undo=undo,
    )
    assert 10 in redo_calls or 11 in redo_calls
    # Loser txn 11 should be in the undone list.
    assert report.undone_txns >= 1


def test_recovery_report_lists_active_txns(populated_wal: str):
    report = recover(
        wal_reader=WalReader(populated_wal),
        apply_redo=lambda r: None,
        apply_undo=lambda r: None,
    )
    assert 11 in report.active_txns_at_crash


def test_recovery_against_empty_wal(tmp_path: Path):
    writer = WalWriter(str(tmp_path), fsync=False)
    writer.close()
    report = recover(
        wal_reader=WalReader(str(tmp_path)),
        apply_redo=lambda r: None,
        apply_undo=lambda r: None,
    )
    assert report.redone_records == 0
    assert report.undone_txns == 0
