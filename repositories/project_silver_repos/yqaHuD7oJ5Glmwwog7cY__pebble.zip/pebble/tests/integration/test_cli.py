from __future__ import annotations

from click.testing import CliRunner

from pebble.cli.cmd_init import init


def test_init_creates_directories(tmp_path):
    runner = CliRunner()
    target = tmp_path / "demo"
    result = runner.invoke(init, [str(target)])
    assert result.exit_code == 0
    assert (target / "wal").is_dir()
    assert (target / "heaps").is_dir()


def test_init_idempotent(tmp_path):
    runner = CliRunner()
    target = tmp_path / "demo"
    runner.invoke(init, [str(target)])
    second = runner.invoke(init, [str(target)])
    assert second.exit_code == 0
