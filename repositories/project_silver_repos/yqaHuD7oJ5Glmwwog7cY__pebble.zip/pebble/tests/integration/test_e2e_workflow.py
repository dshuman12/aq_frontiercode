from __future__ import annotations

import pytest


def test_full_lifecycle_against_engine(engine):
    engine.execute_sql("CREATE TABLE products (id INT, name TEXT, price DOUBLE)")
    engine.execute_sql("CREATE INDEX idx_name ON products (name)")
    engine.execute_sql(
        "INSERT INTO products VALUES "
        "(1, 'apple', 0.50),"
        "(2, 'banana', 0.30),"
        "(3, 'cherry', 0.75)"
    )

    # Update one row.
    engine.execute_sql("UPDATE products SET price = 0.40 WHERE id = 2")
    result = engine.execute_sql("SELECT price FROM products WHERE id = 2")
    assert result.rows[0][0].payload == 0.40

    # Aggregate.
    result = engine.execute_sql("SELECT SUM(price) FROM products")
    assert result.rows[0][0].payload == pytest.approx(0.50 + 0.40 + 0.75)

    # Delete a row.
    engine.execute_sql("DELETE FROM products WHERE id = 1")
    result = engine.execute_sql("SELECT COUNT(*) FROM products")
    assert result.rows[0][0].payload == 2

    # Drop the index.
    engine.execute_sql("DROP INDEX idx_name")
    assert engine.catalog.find_index("products", "idx_name") is None


def test_explain_round_trip(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v INT)")
    result = engine.execute_sql("EXPLAIN SELECT v FROM t WHERE id = 1")
    text = "\n".join(r[0].payload for r in result.rows)
    assert "ProjectNode" in text or "FilterNode" in text


def test_create_table_and_query_from_subselect(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 10), (2, 20)")
    result = engine.execute_sql(
        "SELECT v FROM (SELECT v FROM t WHERE id = 1) AS s"
    )
    assert result.rows[0][0].payload == 10


def test_join_then_aggregate(engine):
    engine.execute_sql("CREATE TABLE a (id INT, region TEXT)")
    engine.execute_sql("CREATE TABLE b (id INT, amount INT)")
    engine.execute_sql("INSERT INTO a VALUES (1, 'east'), (2, 'east'), (3, 'west')")
    engine.execute_sql("INSERT INTO b VALUES (1, 50), (2, 70), (3, 100)")
    result = engine.execute_sql(
        "SELECT a.region, SUM(b.amount) FROM a INNER JOIN b ON a.id = b.id "
        "GROUP BY a.region ORDER BY a.region"
    )
    by_region = {r[0].payload: r[1].payload for r in result.rows}
    assert by_region["east"] == 120
    assert by_region["west"] == 100
