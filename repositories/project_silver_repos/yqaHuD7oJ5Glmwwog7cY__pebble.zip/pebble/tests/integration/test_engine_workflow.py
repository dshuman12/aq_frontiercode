from __future__ import annotations

import pytest


def test_create_index_select(engine):
    engine.execute_sql("CREATE TABLE t (id INT PRIMARY KEY, val INT)")
    engine.execute_sql("CREATE INDEX idx_val ON t (val)")
    engine.execute_sql("INSERT INTO t VALUES (1, 100), (2, 200), (3, 300)")
    result = engine.execute_sql("SELECT id FROM t WHERE val = 200")
    assert result.row_count == 1


def test_aggregate_group_by(engine):
    engine.execute_sql("CREATE TABLE sales (region TEXT, amount INT)")
    engine.execute_sql(
        "INSERT INTO sales VALUES ('east', 100), ('east', 200), "
        "('west', 50), ('west', 75)"
    )
    result = engine.execute_sql(
        "SELECT region, SUM(amount) FROM sales GROUP BY region ORDER BY region"
    )
    rows_by_region = {r[0].payload: r[1].payload for r in result.rows}
    assert rows_by_region == {"east": 300, "west": 125}


def test_having_filters_aggregates(engine):
    engine.execute_sql("CREATE TABLE t (k TEXT, v INT)")
    engine.execute_sql("INSERT INTO t VALUES ('a', 1), ('a', 2), ('b', 1)")
    result = engine.execute_sql(
        "SELECT k FROM t GROUP BY k HAVING COUNT(*) > 1"
    )
    assert [r[0].payload for r in result.rows] == ["a"]


def test_distinct_dedupes(engine):
    engine.execute_sql("CREATE TABLE t (v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (1), (2), (2), (3)")
    result = engine.execute_sql("SELECT DISTINCT v FROM t ORDER BY v")
    assert [r[0].payload for r in result.rows] == [1, 2, 3]


def test_limit_offset(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    engine.execute_sql("INSERT INTO t VALUES (1), (2), (3), (4), (5)")
    result = engine.execute_sql("SELECT id FROM t ORDER BY id LIMIT 2 OFFSET 1")
    assert [r[0].payload for r in result.rows] == [2, 3]


def test_join_inner(engine):
    engine.execute_sql("CREATE TABLE a (id INT, x INT)")
    engine.execute_sql("CREATE TABLE b (id INT, y INT)")
    engine.execute_sql("INSERT INTO a VALUES (1, 10), (2, 20)")
    engine.execute_sql("INSERT INTO b VALUES (1, 100), (2, 200)")
    result = engine.execute_sql(
        "SELECT a.x, b.y FROM a INNER JOIN b ON a.id = b.id"
    )
    assert result.row_count == 2


def test_subquery_in_from(engine):
    engine.execute_sql("CREATE TABLE t (id INT, v INT)")
    engine.execute_sql("INSERT INTO t VALUES (1, 100), (2, 200)")
    result = engine.execute_sql(
        "SELECT s.v FROM (SELECT v FROM t WHERE id = 1) AS s"
    )
    assert result.rows[0][0].payload == 100


def test_explain_returns_text(engine):
    engine.execute_sql("CREATE TABLE t (id INT)")
    result = engine.execute_sql("EXPLAIN SELECT id FROM t WHERE id > 0")
    assert any("SeqScan" in (r[0].payload or "") or "Filter" in (r[0].payload or "")
               for r in result.rows)
