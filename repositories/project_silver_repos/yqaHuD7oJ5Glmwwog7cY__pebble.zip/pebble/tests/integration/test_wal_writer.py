from __future__ import annotations

from pathlib import Path

import pytest

from pebble.constants import WAL_REC_INSERT
from pebble.wal.reader import WalReader
from pebble.wal.record import insert_payload
from pebble.wal.writer import WalWriter


@pytest.fixture
def writer(tmp_path: Path):
    w = WalWriter(str(tmp_path), fsync=False)
    yield w
    w.close()


def test_append_then_read_back(writer, tmp_path: Path):
    writer.append(
        type=WAL_REC_INSERT, txn_id=42, prev_lsn=0,
        payload=insert_payload(page_id=1, slot=0, tuple_bytes=b"hi"),
    )
    writer.flush()
    reader = WalReader(str(tmp_path))
    records = list(reader.iter_records())
    assert len(records) == 1
    assert records[0].txn_id == 42


def test_lsn_monotonically_increases(writer):
    a = writer.append(type=WAL_REC_INSERT, txn_id=1, prev_lsn=0, payload=b"a")
    b = writer.append(type=WAL_REC_INSERT, txn_id=1, prev_lsn=a, payload=b"b")
    assert b > a


def test_close_is_idempotent(tmp_path: Path):
    w = WalWriter(str(tmp_path), fsync=False)
    w.close()
    # Calling close again should not raise.
    w._fh.close()  # type: ignore[attr-defined]


def test_segment_rotation(tmp_path: Path):
    w = WalWriter(str(tmp_path), segment_size=1024, fsync=False)
    try:
        for i in range(50):
            w.append(type=WAL_REC_INSERT, txn_id=i, prev_lsn=0,
                     payload=insert_payload(page_id=1, slot=0, tuple_bytes=b"x" * 64))
        w.flush()
    finally:
        w.close()
    files = sorted(p for p in (tmp_path).iterdir() if p.suffix == ".pblog")
    assert len(files) > 1
