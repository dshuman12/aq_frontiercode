from __future__ import annotations

import os
from pathlib import Path

import pytest


os.environ.setdefault("PEBBLE_DATA", str(Path("./_pytest_pebble").resolve()))


@pytest.fixture
def engine(tmp_path: Path):
    from pebble.config import Config, set_config, reset_config
    from pebble.server.engine import Engine

    set_config(Config(data_dir=tmp_path))
    eng = Engine()
    eng.open()
    try:
        yield eng
    finally:
        eng.close()
        reset_config()
