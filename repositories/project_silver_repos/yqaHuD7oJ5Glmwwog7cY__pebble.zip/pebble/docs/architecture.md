# Pebble architecture

This file is a tour of the moving parts. It assumes you know what a
relational database does and want to understand how the pieces fit
together before you go modify one.

## High-level diagram

```
                +-------------------+
                |       SQL         |
                +---------+---------+
                          |
                  lexer   v
                +---------+---------+
                |     Tokens        |
                +---------+---------+
                          |
                  parser  v
                +---------+---------+
                |       AST         |
                +---------+---------+
                          |
              optimizer   v
                +---------+---------+
                |   Logical plan    |
                | -> Rules pass    |
                | -> Physical plan |
                +---------+---------+
                          |
                          v
                +---------+---------+
                |     Executor      |  (Volcano iterators)
                +----+--------+-----+
                     |        |
              read   v        v   write
              +------+----+ +-+--------+
              | Buffer    | |   WAL    |
              | pool      | |  writer  |
              +-----+-----+ +----+-----+
                    |            |
                    v            v
              +-----+-----+ +----+-----+
              | Heap +    | |  WAL     |
              | B+tree    | | segments |
              | files     | +----------+
              +-----------+
```

## Layers

### SQL front end (`lexer`, `parser`)

The lexer hand-rolls a small DFA over the input bytes. The parser is a
recursive-descent parser: one method per non-terminal, no PEG, no LALR.
Statement separation is the SQL semicolon. Errors carry a precise byte
offset so the REPL can underline the offending token.

### Types (`types`)

Pebble has its own type system rather than reusing Python's. The
lattice is intentionally small:

```
        INT  ->  BIGINT  ->  NUMERIC  ->  DOUBLE
                                    \
                                     -> TEXT (no implicit coercion)
```

NULL is a value of every type. Comparison is three-valued: `NULL = 1`
returns `NULL`, not `FALSE`.

### Catalog (`catalog`)

System tables, columns, indexes, statistics. Stored in dedicated heap
files alongside user data. The in-memory cache is rebuilt at startup;
mutations write through to disk.

### Storage (`storage`, `buffer`, `btree`)

Heap files are sequences of fixed-size pages with a slotted page
layout. Each page carries a CRC; the buffer pool checks it on read.
The B+tree shares the same buffer pool but uses its own node layout
inside each page.

### WAL + recovery (`wal`)

Append-only segment files. Records are length-prefixed with a CRC.
Recovery is ARIES: an analyze pass over the log produces the
active-transaction table and the dirty-page table; redo replays every
record whose page is dirty; undo walks loser transactions in reverse
LSN order.

### Transactions (`txn`, `lock`)

MVCC with snapshot visibility. Snapshots are constructed from the
current active transaction list; tuples are visible iff the rules in
:func:`Snapshot.is_visible` pass. The lock manager handles the
intent-locking matrix and detects deadlocks via a wait-for graph
cycle check.

### Plan + optimizer + executor (`plan`, `optimizer`, `exec`)

Logical algebra (Scan / Filter / Project / Join / Aggregate / Sort /
Limit) goes through a few rule passes before the cost model picks
physical operators (SeqScan / IndexScan / HashJoin / MergeJoin /
HashAggregate / Sort / Limit). The executor walks the physical tree
in the Volcano style: each operator is an iterator that pulls rows
from its child.

### Network (`protocol`, `server`)

A tiny framed protocol over TCP. Each frame is `kind + length +
payload`; payloads are JSON for everything except blobs (encoded as
hex-tagged dicts). Connections are stateless from the protocol's
point of view; the engine attaches a per-connection transaction state.

### CLI (`cli`)

Click command tree:

```
pebble init <dir>
pebble repl --data <dir>
pebble dump --data <dir>
pebble check --data <dir>
pebble bench --data <dir>
pebble explain --data <dir> <sql>
pebble serve --data <dir> [--host --port]
```

## Why these choices

- **In-tree lexer + parser.** External SQL parsers exist but each one
  imposes its own AST shape; we'd spend more code adapting them than
  writing the parser from scratch.
- **Hand-written recovery.** ARIES is famously fiddly. The exposition
  in this file is enough to write a correct toy implementation; a
  production implementation needs CLR records and end-of-redo
  checkpoints which we have left as TODOs.
- **No Celery / external broker.** A single-process server with
  threaded sessions is the right shape for the workloads Pebble
  targets. Distribution is out of scope.
- **Volcano executor.** Iterator-per-operator is simple to read and
  easy to extend; vectorised execution is interesting but a much
  larger commitment.
