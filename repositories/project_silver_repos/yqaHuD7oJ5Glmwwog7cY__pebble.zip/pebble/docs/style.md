# Code style

Pebble's source is meant to be read top-to-bottom. A few conventions
that follow from that, beyond what ``ruff`` enforces:

## Module docstrings

Every module starts with a docstring that explains what the module is
for and how it fits into the rest of the project. Five lines is
plenty; thirty is too many.

## Type annotations

Strict ``mypy`` is on for ``src/``. Tests skip annotations on
fixtures because pytest's typing is weak; everywhere else, annotate.

## Imports

`__future__` first, then stdlib, then third-party, then ``pebble.``.
Inside each block: alphabetical, sorted by ``ruff``'s ``isort``
implementation. Avoid lazy imports unless you have a documented
reason (avoiding a cycle, avoiding a heavy dependency at module load).

## Errors

Every error class lives in ``pebble.errors`` and has a stable
``code`` attribute. Tests that catch a specific error should match on
the code, not the message string.

## Logging

Use ``logging.getLogger(__name__)``. Structured fields go on the
``extra=`` kwarg, not into the format string. The audit log handles
its own structure -- do not log audit-relevant facts through the
generic logger.

## Functions vs classes

Prefer functions. Classes are appropriate for things that hold
mutable state across calls (the buffer pool, the lock manager, the
btree). A class with no instance state and a single method is a
function with bad spelling.

## Unit testing

Each module gets a peer ``test_<module>.py`` file. Tests are not
allowed to mock parts of Pebble that are simple enough to use
directly (the catalog, the type system). Mocks are reserved for the
real-world boundary (sockets, files).

## Comments

Comment the *why*, not the *what*. ``# walk the list`` does not earn
its keep; ``# we walk in reverse so deletes don't invalidate the
index`` does.
