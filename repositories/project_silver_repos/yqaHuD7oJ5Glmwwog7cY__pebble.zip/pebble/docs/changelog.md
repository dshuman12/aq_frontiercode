# Changelog

## 0.1.0 (alpha)

Initial release. Surface area:

- SQL parser covering SELECT/INSERT/UPDATE/DELETE/CREATE TABLE/CREATE
  INDEX/DROP plus EXPLAIN/ANALYZE/VACUUM and BEGIN/COMMIT/ROLLBACK.
- Type system with INT/BIGINT/DOUBLE/TEXT/BLOB/BOOL/DATE/TIMESTAMP
  and three-valued logic.
- Page-based storage with CRC validation, slotted pages, free-space
  map.
- Buffer pool with LRU eviction and ring-buffer carve-out for
  sequential scans.
- B+tree index with leaf splits, internal splits, and root growth.
- ARIES-flavoured WAL with three-pass recovery (analyze/redo/undo).
- MVCC transaction manager with snapshot visibility.
- Lock manager with intent locks and wait-for cycle detection.
- Cost-based optimizer with predicate/projection/limit pushdown,
  constant folding, DP join reorder.
- Volcano executor with hash join, merge join, hash aggregate,
  external sort.
- Wire protocol over TCP plus an embedded Python API.
- CLI with REPL, dump, check, bench, explain, init, serve.

Known limitations -- see ``docs/recovery.md`` and ``docs/security.md``
for the long version. The big ones:

- No CLR records during undo; recovery is not crash-safe.
- No `ALTER TABLE`; use the migration helpers in
  `pebble.catalog.migrations`.
- Single-node only.
- No authentication on the wire.

## Roadmap

- 0.2.0: `ALTER TABLE`, prepared statements, `RETURNING` clause.
- 0.3.0: predicate locks for full SSI, archived WAL segments.
- 0.4.0: parallel hash joins, parquet import.

## Contributing

See `docs/contributing.md`.
