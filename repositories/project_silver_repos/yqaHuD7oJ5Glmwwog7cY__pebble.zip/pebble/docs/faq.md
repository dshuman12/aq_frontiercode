# FAQ

## Why Python?

Pebble is intended to be read, not deployed at scale. Python's
readability beats every other language we considered for that
purpose. There is also a fair amount of CS-classroom code in this
shape: an academic project Pebble shares some DNA with is BusTub, the
CMU teaching DBMS.

## Is it ACID?

Atomicity and durability are present (WAL + ARIES recovery). Isolation
is best at snapshot level by default; serializable runs but uses a
limited form of SSI that has known false positives. Consistency is
your responsibility -- check constraints are parsed but not enforced
yet (a TODO in the engine).

## How big can the database get?

The encoding is 32-bit page IDs, so each heap file caps at
``2^32 * page_size`` (32 TiB at 8 KiB pages). In practice you will
hit memory pressure long before that; the buffer pool is the
bottleneck for working sets that exceed RAM.

## Can I use it with my existing client library?

The wire protocol is custom (see ``docs/protocol.md``). There is no
PostgreSQL or MySQL emulation; clients have to speak the Pebble
protocol or use the embedded API.

## Why not use SQLAlchemy / SQLite / DuckDB?

This is a teaching project -- there is no point in re-using something
that hides the layer we want to teach. SQLAlchemy is an excellent
ORM; SQLite is a beautifully engineered embedded database; DuckDB is
a state-of-the-art OLAP engine. None of them help if you are trying
to learn how a relational database is built.

## How do I report a bug?

Open an issue with a minimal reproduction. ``pebble dump`` produces
a SQL script that exercises the bug; please attach the dump along
with the failing query.

## Can I use Pebble in production?

Probably not. The recovery code has documented gaps; the SQL surface
is small; performance is fine for human-scale workloads but won't
match a real database. Pebble is pleasant for prototyping and
absolutely fantastic for learning, but not for serving customer data.
