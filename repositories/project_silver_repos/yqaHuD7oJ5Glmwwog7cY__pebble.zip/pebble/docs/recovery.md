# Recovery

Pebble recovers from crashes by replaying the WAL. The implementation
is faithful to ARIES in shape: a three-pass scheme using an active
transaction table (ATT) and a dirty page table (DPT). Production
implementations layer additional invariants on top; we have left some
of them out and called them out below.

## The three passes

### Pass 1 -- Analyze

Walk the WAL forward from the last checkpoint and observe records:

- **BEGIN**: add the transaction to the ATT.
- **COMMIT / ABORT**: remove from the ATT.
- **INSERT / UPDATE / DELETE / BTREE_SPLIT**: bump the dirty-page
  table for the target page (set its recoveryLSN if not already set).

After this pass:

- ATT contains every transaction that was running at the time the
  database crashed.
- DPT lists every page that was dirty in the buffer pool at the time
  of the crash.

### Pass 2 -- Redo

Walk forward again, this time from the lowest LSN in the DPT. For
every data record whose page is in the DPT and whose LSN is `>=` the
page's recoveryLSN, re-apply the change. The redo is idempotent: each
record's LSN is compared against the page's `lsn` field, and pages
whose stored LSN is already at-or-past the record's LSN are skipped.

### Pass 3 -- Undo

For each loser transaction (still in the ATT after analyze), walk its
record chain backward and undo each one. Production implementations
write a Compensation Log Record (CLR) for each undo so a crash during
recovery does not undo the same record twice; we have not implemented
CLRs and rely on the WAL writer never being interrupted.

## Group commit

The WAL writer batches concurrent commits into a single fsync. When
several sessions call `commit()` within the configured window, only
the last one actually fsyncs; earlier callers wait for the same
syscall to return.

## Checkpoint

A checkpoint reduces the work analyze must do on the next crash. We
write:

- a `CHECKPOINT_BEGIN` record listing the active transactions;
- the buffer pool flushes every dirty page;
- a `CHECKPOINT_END` record stamping the lowest active LSN.

The next analyze starts from `CHECKPOINT_BEGIN`'s LSN.

## What we have not implemented

- CLR records.
- Resilience to crash-during-recovery.
- Online backup (file copy with WAL replay).
- Archival mode (no segment recycling).

These are the kinds of things that turn a teaching implementation into
a production-grade one. Each is an order of magnitude more code than
the basic three-pass algorithm, and each has its own subtle invariants.
