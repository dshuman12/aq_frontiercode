# Wire protocol

Pebble's wire protocol is intentionally minimal. Every message is a
framed packet:

```
+------+--------+----------+
| kind | length | payload  |
+------+--------+----------+
   1B      4B    `length`
```

`kind` is a single ASCII byte; `length` is a 4-byte big-endian length
prefix; the payload is `length` bytes. JSON is used for structured
content; raw bytes are escaped as `{"__blob__": "<hex>"}`.

## Kinds

| Byte | Name      | Direction         | Payload                  |
|------|-----------|-------------------|--------------------------|
| Q    | query     | client -> server  | UTF-8 SQL                |
| A    | auth      | client -> server  | JSON `{user, password}`  |
| R    | row       | server -> client  | JSON array of values     |
| C    | complete  | server -> client  | JSON `{tag, rows}`       |
| E    | error     | server -> client  | JSON `{code, message}`   |
| N    | notice    | server -> client  | JSON `{message}`         |
| X    | cancel    | client -> server  | empty                    |

## Result streams

When the server runs a SELECT it streams `R` frames followed by exactly
one `C` frame. Errors are reported as a single `E` frame; the client
should treat any `E` as a terminal status. Cancellation flips a flag
inside the engine; in-flight statements observe the flag at the next
operator boundary and abort.

## Authentication

There is no authentication in the alpha release. The `A` frame is
defined for forward compatibility; the server currently accepts any
auth payload (or none). Real deployments should run Pebble behind a
TLS-terminating proxy.

## Versioning

`PROTOCOL_VERSION` is the single number to bump when the on-the-wire
format changes. Clients echo the protocol version they speak in their
first frame; if the server cannot speak that version it sends an `E`
frame with code `PE6001` and closes the connection.
