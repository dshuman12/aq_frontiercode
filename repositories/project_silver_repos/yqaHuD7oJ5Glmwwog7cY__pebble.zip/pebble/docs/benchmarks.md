# Benchmarking guide

The ``bench/`` directory contains a tiny harness that exercises Pebble
against a synthetic workload. It is not a substitute for a real
benchmark, but it catches regressions large enough to matter on the
order of seconds.

## Running

```bash
python -m bench.run --rows 50000 --iterations 3
```

The harness:

1. Spawns an embedded engine in a temporary directory.
2. Creates a single table.
3. Times insert latency over the configured number of rows.
4. Times a full ``COUNT(*)``.
5. Times a filtered scan.

Each iteration runs against a fresh table so cumulative state does
not skew later iterations.

## Interpreting the numbers

Pebble is single-threaded and stores everything in memory in the
default test configuration. Rough numbers on a 2024-era laptop:

- Insert: ~30k rows/s for a single column INSERT through the SQL
  parser. Most of that is parsing -- the storage layer can sustain
  several hundred thousand inserts per second when bypassing SQL.
- ``COUNT(*)``: linear in row count, ~1 ns per row plus overhead.
- Filtered scan: similar to ``COUNT(*)`` plus the predicate evaluator.

If you see numbers more than 2x worse than these, expect a regression
somewhere in the parser or in the buffer pool's hit ratio.

## When you really need a benchmark

The harness covers the inner loop. For end-to-end measurements
(latency under contention, recovery time after an N-record WAL,
etc.) you want a different kind of test entirely. Pebble ships none
of those; the recovery doc walks through the manual steps.

## Profiling

Standard tools work. ``python -m cProfile -o pebble.prof -m bench.run``
produces a profile that ``snakeviz`` can render. The hot paths to expect
on a profile of the harness are:

1. ``Parser._expression`` and friends.
2. ``Evaluator.evaluate`` (~25% of CPU on insert paths).
3. ``HeapPage.thaw`` (CRC validation; about 10% if the buffer pool is
   too small).

A bigger buffer pool (``PEBBLE_BUFFER_POOL_PAGES=4096``) usually wins
30-40% on the insert workload by avoiding repeated CRC verification.
