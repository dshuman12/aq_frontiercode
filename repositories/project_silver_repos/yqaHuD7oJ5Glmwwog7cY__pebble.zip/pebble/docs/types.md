# Type system

Pebble's SQL type system is small on purpose. Every type either has a
fixed width and a natural Python encoding, or it's variable-width with
a length prefix. The full set:

| Code        | Width      | Python repr           | Notes                          |
|-------------|------------|-----------------------|--------------------------------|
| BOOL        | 1 byte     | `bool`                | three-valued (NULL is allowed) |
| INT         | 4 bytes    | `int` (32-bit signed) | overflows raise `NumericOverflow` |
| BIGINT      | 8 bytes    | `int` (64-bit signed) |                                |
| DOUBLE      | 8 bytes    | `float`               | IEEE-754                       |
| TEXT        | variable   | `str` (UTF-8)         | length-prefixed                |
| BLOB        | variable   | `bytes`               | length-prefixed                |
| DATE        | 4 bytes    | `datetime.date`       | days since 1970-01-01          |
| TIMESTAMP   | 8 bytes    | `datetime.datetime`   | µs since 1970-01-01 UTC        |
| NUMERIC(p,s)| variable   | `decimal.Decimal`     | length-prefixed UTF-8 literal  |

NULL is a value of every type. Comparisons involving NULL return NULL;
boolean operators short-circuit (`AND` becomes False if either side is
False even when the other is NULL; `OR` becomes True if either side is
True).

## Coercion lattice

```
        INT  ->  BIGINT  ->  NUMERIC  ->  DOUBLE
        |
        +-> nothing implicit; CAST required to TEXT/BOOL/etc.

        DATE  ->  TIMESTAMP

        TEXT(n)  ->  TEXT(m)   when n <= m
```

`common_type(a, b)` either returns the lattice's join or raises. Most
arithmetic and comparison operators promote silently; everything that
reaches across the bar (numeric to text, text to int) needs a CAST.

## Extending the type system

Adding a type requires:

1. A new ``TypeCode`` enum value.
2. An entry in :func:`common_type` for promotion rules.
3. An encoder + decoder branch in :mod:`pebble.types.encoding`.
4. An entry in :func:`parse_type` for the SQL keyword.
5. Tests in ``tests/unit/types/`` covering the new type's
   round-trips and 3VL behaviour.

We have left UUID, INTERVAL, ARRAY, and JSON out of the v1 surface;
each of them is a meaningful design call (especially indexing JSON)
and they each deserve their own design doc.
