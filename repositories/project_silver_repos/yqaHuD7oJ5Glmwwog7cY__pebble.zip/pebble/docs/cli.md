# Command-line interface

```
pebble init <dir>            initialise a fresh data directory
pebble repl  --data <dir>    interactive SQL prompt
pebble dump  --data <dir>    print every CREATE TABLE + INSERT statement
pebble check --data <dir>    validate page CRCs and walk the WAL
pebble bench --data <dir>    run a tiny micro-benchmark
pebble explain --data <dir> <SQL>  print the optimised plan
pebble serve --host <h> --port <p>  start the network server
```

All commands accept ``--data`` to override the data directory; without
it Pebble reads ``$PEBBLE_DATA`` (default ``./pebble_data``).

## REPL

The REPL accepts multi-line statements. Pebble is liberal about
whitespace; statements are submitted when a line ends with ``;``.
Type ``\q`` (alias for sending EOF) to exit.

## Dump

The dump format is plain SQL: a stream of `CREATE TABLE` and
`INSERT INTO ... VALUES (...)` statements. A dump produced by `pebble
dump` can be fed back into a fresh database with `pebble repl < dump.sql`.

## Check

`pebble check` walks every heap file and the WAL to validate CRCs and
record framing. It exits non-zero if any inconsistency is found,
making it a reasonable smoke-test step in CI.

## Bench

The bench command is intentionally small: a fixed mix of inserts and
SELECTs across a single table. It is not a substitute for a serious
benchmark; treat the output as a sanity check.

## Explain

`pebble explain "SELECT ..."` prints the physical plan tree, including
estimated rows and cost for each node. Pair with `ANALYZE` to populate
statistics first.
