# Pebble docs

This directory is the long-form documentation. Start with
``architecture.md`` if you've never seen the project before; pick a
topic-specific doc once you know which layer you're interested in.

| File                  | Topic                                          |
|-----------------------|------------------------------------------------|
| architecture.md       | Tour of the layers and their interactions.     |
| storage.md            | Page format, heap files, buffer pool, B+tree. |
| wal.md                | Segment files, record format, group commit.   |
| recovery.md           | ARIES analyze/redo/undo passes.                |
| optimizer.md          | Logical → physical plan, rules, cost model.   |
| protocol.md           | Wire format details.                           |
| sql_grammar.md        | EBNF for the SQL surface.                      |
| types.md              | Type system, NULL semantics, coercion.        |
| cli.md                | Command-line tools.                            |
| benchmarks.md         | How to read the bench harness output.          |
| security.md           | Threat model and known gaps.                   |
| contributing.md       | How to send a PR.                              |
| style.md              | Code style conventions.                        |
| changelog.md          | Release notes.                                 |
| faq.md                | Common questions.                              |

The docs are intentionally short. If a topic feels under-served,
that's usually because the source itself is the better reference --
modules carry top-of-file docstrings that explain the *why* in
detail.
