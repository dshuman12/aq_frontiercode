# Storage

This document covers what bytes live where on disk and how the buffer
pool and B+tree consume them.

## Page

A page is :data:`PAGE_SIZE` bytes (default 8 KiB). Every page starts
with a fixed 32-byte header:

```
0    4   magic ("PBL1")
4    1   kind (heap=1, leaf=2, internal=3, meta=4, fsm=5)
5    1   version
6    2   reserved
8    4   page id
12   8   lsn
20   2   slot count
22   2   free space upper bound
24   4   crc32 of body
28   4   reserved
```

Heap pages then layout a *slot directory* immediately after the
header, growing forward. Tuple payloads grow backward from the end of
the page. Free space lives between the directory and the payloads.

Slots are 4 bytes each (offset, length). A length of `0xFFFF` marks a
slot whose tuple has been logically deleted; vacuum reclaims the
space later.

## CRC

The CRC32 covers everything except the CRC field itself. On read, the
buffer pool zeroes the CRC field, recomputes, and compares. A mismatch
raises ``CorruptPage``; recovery then consults the WAL to redo the
last good state.

## Heap file

A heap file is a sequence of pages on disk, addressed by a 32-bit
page id. Files grow page-by-page; no holes are introduced. The
free-space map (FSM) is an in-memory `page_id -> free_bytes` mapping
rebuilt at startup.

Tuples are addressed by a `TupleId(page_id, slot)`. The TID is what
indexes store as their value, and what the executor passes around
internally.

## Buffer pool

The buffer pool caches pages in memory. Each cached page has:

- a pointer to the underlying heap file's bytes;
- a pin count -- how many callers currently hold it;
- a dirty flag -- set when the page has been modified.

Pinned pages are immune to eviction. Eviction picks the least-recently
used unpinned page; if it is dirty, we write it back through the heap
file before discarding it.

Sequential scans flag their pins as `ring=True`. The pool keeps at
most `ring_capacity` ring-flagged pages live at once, so a 100 GB
`SELECT *` does not flush the working set of more selective queries.

## B+tree

The B+tree shares the page format. Each node is one page with the
heap header, a small btree header, and the array of (key, value)
entries.

- Keys are variable-length byte strings; we cap them at
  :data:`MAX_KEY_SIZE` so a single entry always fits in a page.
- Values are fixed-length: 6 bytes for leaves (a packed `TupleId`)
  and 4 bytes for internal nodes (a child page id).
- Leaves are doubly-linked through `next_leaf` / `prev_leaf` pointers
  for forward and reverse range scans.

Splits are eager: when an insert would push the node past its capacity
budget, the node splits in half and the parent receives a separator
key. The split percolates up; if it reaches the root we allocate a
fresh internal node and bump the tree height.

Concurrent access is via *crabbing latches*: each descent grabs the
parent latch before the child, then releases the parent as soon as it
is clear that the child's modification cannot ripple upward (i.e. the
child has space for the new entry).

Underflow handling is intentionally left to a follow-up vacuum pass.
The current implementation marks pages as candidates and a periodic
job merges sparse siblings -- not in the hot path of a single delete.

## Free-space map

The FSM tracks `page_id -> free_bytes` so inserts can find a page with
room in O(n). Real implementations write the FSM to disk; ours rebuilds
it on startup by walking the heap file. That is fine for the workload
sizes Pebble targets and keeps the storage layer easy to read.
