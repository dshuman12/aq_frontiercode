# Write-ahead log

The WAL is Pebble's durability mechanism. Every state-changing action
appends a record to the log before the in-memory state is mutated.
Recovery (see ``docs/recovery.md``) replays the log to rebuild any
state that was in the buffer pool but not yet flushed when the
process crashed.

## Segment files

The log lives in the ``wal/`` subdirectory of the data directory as
a sequence of fixed-size segment files named ``NNNNNNNNNN.pblog``.
The active segment grows until it hits ``WAL_DEFAULT_SEGMENT_SIZE``
(16 MiB by default), at which point the writer rotates to a new
segment.

Each segment starts with the magic bytes ``PBLLOG01``. Truncated
segments (a crash during writeback) are detected by the CRC on each
record; corrupt records mark the end of recoverable history.

## Record format

```
+------+----+--------+------+----------+--------+--------+----------+
| type | _  | length | lsn  | prev_lsn | txn_id | crc32  |  payload |
+------+----+--------+------+----------+--------+--------+----------+
   1B   1B    4B       8B      8B         8B       4B
```

`type` indexes into the table in :mod:`pebble.constants`; `length`
covers the entire record including the header; `crc32` is over
everything except itself.

Every txn's records form a chain through `prev_lsn`. Recovery's undo
pass walks the chain in reverse to undo loser transactions.

## Group commit

Pebble batches concurrent commit fsyncs. When a session calls
`commit()`, the writer:

1. Appends the COMMIT record.
2. Records the current LSN as "needs fsync".
3. Sleeps for `group_commit_window_us` (default 200µs).
4. Issues a single fsync covering every COMMIT recorded so far.

Sessions whose COMMIT made it into the batch return as soon as the
fsync returns. Sessions that arrived after the fsync started wait
for the next batch.

## Checkpoint

A checkpoint shortens the work the next analyze pass must do. The
checkpoint procedure:

1. Append `CHECKPOINT_BEGIN` recording the active txn ids.
2. Flush every dirty page in the buffer pool.
3. Append `CHECKPOINT_END` recording the lowest active LSN.

Recovery starts its analyze pass at the most recent
`CHECKPOINT_BEGIN`; pages whose recoveryLSN predates the checkpoint
are guaranteed to be on disk.

## Operational notes

- Disable fsync for tests: `PEBBLE_FSYNC=false`.
- Inspect the log: `pebble check --data <dir>` walks every record and
  reports any framing or CRC errors.
- Archive segments: not yet implemented. The TODO is a small one
  -- copy the segment file as soon as the writer rotates -- but
  shipping it requires deciding what to do when the archive target
  is unavailable.
