# Security model

This is the threat model Pebble is built against, and where the
boundaries are. The short version: **Pebble is a teaching project
and was not designed for hostile networks**. Don't expose the wire
port to untrusted clients.

## What Pebble protects

- **Data integrity on disk.** Page CRCs catch silent corruption from
  the disk layer. WAL records carry CRCs too; recovery refuses to
  apply a record whose checksum is wrong.
- **Atomic commits.** A crash during a `COMMIT` either commits the
  whole transaction or none of it. Recovery undoes anything from a
  loser transaction that made it to disk.
- **Reasonable concurrency.** The lock manager prevents
  classical concurrency anomalies under read-committed and snapshot
  isolation. Serializable level uses an SSI-light model that has
  documented false positives.

## What Pebble does NOT protect

- **No authentication on the wire.** The `A` frame is wired up but
  the server accepts any payload. Run behind a TLS-terminating proxy
  with mutual auth if you need to expose the port.
- **No authorisation.** Every connected client can do anything.
  There is no `GRANT` / `REVOKE`; the SQL surface is fully open.
- **No SQL-injection protection.** The wire protocol takes raw SQL.
  Application code must parameterise queries on the client side
  (Pebble has no prepared statement syntax in v1).
- **No fuzz-tested storage layer.** We have property tests for the
  encoder and parser; the storage layer is covered by unit tests but
  has not been hammered by AFL or libFuzzer.
- **No transparent encryption.** Pages and WAL records are plaintext
  on disk. Encrypt the underlying volume if you need at-rest
  encryption.

## Reporting issues

Email `security@pebble.local` (placeholder; pin to a real address
before announcing publicly). We aim to acknowledge within 72 hours,
release a fix within 30 days, and credit the reporter unless they
prefer anonymity.

## Future work

- A `GRANT`/`REVOKE` ACL system on top of the catalog.
- TLS termination inside the server, removing the proxy requirement.
- Argon2 password hashing for the auth handshake.

These are tracked in the issue tracker; PRs welcome.
