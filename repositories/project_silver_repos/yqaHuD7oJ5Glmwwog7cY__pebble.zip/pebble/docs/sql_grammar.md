# Pebble SQL grammar

This is the EBNF the parser implements. Anything not described here
is not supported.

```
statement       = select_statement
                | insert_statement
                | update_statement
                | delete_statement
                | create_statement
                | drop_statement
                | txn_statement
                | explain_statement
                | analyze_statement
                | vacuum_statement ;

select_statement = [ with_clause ] select_core
                   { ("UNION" [ "ALL" ] | "INTERSECT" | "EXCEPT") select_core }
                   [ order_clause ] [ "LIMIT" expr ] [ "OFFSET" expr ] ;

with_clause     = "WITH" [ "RECURSIVE" ] cte { "," cte } ;
cte             = identifier [ "(" identifier { "," identifier } ")" ]
                  "AS" "(" select_statement ")" ;

select_core     = "SELECT" [ "DISTINCT" ] projection_list
                  [ "FROM" from_clause ]
                  [ "WHERE" expr ]
                  [ "GROUP" "BY" expr { "," expr } ]
                  [ "HAVING" expr ] ;

projection_list = projection_item { "," projection_item } ;
projection_item = "*" | expr [ [ "AS" ] identifier ] ;

from_clause     = table_primary { join_clause | "," table_primary } ;
table_primary   = identifier [ [ "AS" ] identifier ]
                | "(" select_statement ")" [ "AS" ] identifier ;
join_clause     = [ join_kind ] "JOIN" table_primary
                  ( "ON" expr | "USING" "(" identifier { "," identifier } ")" ) ;
join_kind       = "INNER" | "CROSS"
                | ( "LEFT" | "RIGHT" | "FULL" ) [ "OUTER" ] ;

order_clause    = "ORDER" "BY" order_item { "," order_item } ;
order_item      = expr [ "ASC" | "DESC" ] [ "NULLS" ( "FIRST" | "LAST" ) ] ;

insert_statement = "INSERT" "INTO" identifier [ "(" identifier { "," identifier } ")" ]
                   ( "VALUES" row { "," row } | select_statement ) ;
row              = "(" expr { "," expr } ")" ;

update_statement = "UPDATE" identifier "SET" assignment { "," assignment }
                   [ "WHERE" expr ] ;
assignment       = identifier "=" expr ;

delete_statement = "DELETE" "FROM" identifier [ "WHERE" expr ] ;

create_statement = "CREATE" [ "UNIQUE" ] ( "TABLE" | "INDEX" )
                   create_body ;

drop_statement   = "DROP" ( "TABLE" | "INDEX" ) [ "IF" "EXISTS" ] identifier ;

txn_statement    = "BEGIN" [ isolation_clause ]
                 | "COMMIT" | "ROLLBACK" [ "TO" [ "SAVEPOINT" ] identifier ]
                 | "SAVEPOINT" identifier ;
isolation_clause = "ISOLATION" "LEVEL" ("READ" "COMMITTED" | "REPEATABLE" "READ"
                                       | "SERIALIZABLE" | "SNAPSHOT") ;

explain_statement = "EXPLAIN" [ "ANALYZE" ] statement ;
analyze_statement = "ANALYZE" [ identifier ] ;
vacuum_statement  = "VACUUM" [ identifier ] ;

expr            = or_expr ;
or_expr         = and_expr { "OR" and_expr } ;
and_expr        = not_expr { "AND" not_expr } ;
not_expr        = "NOT" not_expr | comparison ;
comparison      = concat { ( "=" | "<>" | "<" | "<=" | ">" | ">=" ) concat
                          | "IS" [ "NOT" ] "NULL"
                          | [ "NOT" ] "BETWEEN" concat "AND" concat
                          | [ "NOT" ] "LIKE" concat [ "ESCAPE" concat ]
                          | [ "NOT" ] "IN" "(" ( select_statement | expr_list ) ")" } ;
concat          = addsub { "||" addsub } ;
addsub          = muldiv { ( "+" | "-" ) muldiv } ;
muldiv          = unary { ( "*" | "/" | "%" ) unary } ;
unary           = ( "+" | "-" ) unary | primary ;
primary         = literal | column_ref | function_call | "CASE" case_body
                | "CAST" "(" expr "AS" type_name ")"
                | "(" ( expr | select_statement ) ")"
                | "*" ;
```

Productions not shown:

- ``literal`` covers integer, float, string, blob, NULL, TRUE, FALSE.
- ``identifier`` is either an unquoted bare-word (matched against the
  reserved word list) or a double-quoted name.
- ``type_name`` is the SQL type keyword optionally followed by
  ``"(" length [ "," scale ] ")"``.
- ``case_body`` matches both the simple form (``CASE expr WHEN ...``)
  and the searched form (``CASE WHEN cond ...``).

Whitespace and comments are stripped by the lexer; a line comment
starts with ``--`` and runs to end-of-line; a block comment is
``/* ... */`` and does not nest.
