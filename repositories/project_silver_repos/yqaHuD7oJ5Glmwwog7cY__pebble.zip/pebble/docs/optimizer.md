# Optimizer

The optimizer turns an AST into a physical plan in three steps:

1. Build a logical plan tree by recursing into the AST.
2. Apply a few rule-based rewrites until a fixed point.
3. Pick concrete physical operators and estimate their cost.

## Logical algebra

The logical layer uses standard relational algebra:

```
Scan(table)
Filter(child, predicate)
Project(child, expressions, distinct?)
Join(left, right, kind, predicate)
Aggregate(child, group_keys, aggregates, having?)
Sort(child, order)
Limit(child, limit, offset)
SetOp(left, right, op)
```

DML statements have their own logical nodes (`Insert`, `Update`,
`Delete`) that the planner builds directly from the AST.

## Rules

Rules are functions `LogicalPlan -> LogicalPlan`. The driver applies
them in a fixed order until two consecutive passes produce identical
plans (cap at 8 passes to avoid pathological inputs).

### Predicate pushdown

`Filter(Project(X)) -> Project(Filter(X))`.
`Filter(Join(L, R)) -> Join(L, Filter(R))` if the predicate references
only `R`'s columns (or symmetrically for `L`).

### Projection pushdown

When a `Project` references only a subset of a `Scan`'s columns,
annotate the scan with the projected columns so the executor stops
materialising the unused bytes. We do this only at immediate
`Project(Scan)` patterns; deeper pushdown would require column-pruning
analysis we have not yet written.

### Constant folding

Replace binary operators on two literal operands with a single literal.
We only handle obvious cases (arithmetic, comparison, boolean
combinators); CAST / function calls go untouched.

### Limit pushdown

`Limit(Project(X))` becomes `Project(Limit(X))` when `X` does not
contain a `Sort` -- pushing the limit through a sort would change the
result.

## Cost model

Two numbers per physical node:

- **rows** -- expected output cardinality.
- **cost** -- accumulated cost.

Cost components:

- `cost_seq_page` * pages read -- sequential scans.
- `cost_index_page` * pages read -- index probe + leaf walks.
- `cost_cpu_tuple` * rows -- per-row processing.
- `cost_cpu_operator` * comparisons -- expression evaluation.

The defaults come from PostgreSQL's documentation; tweak in
`OptimizerConfig`.

## Join reordering

DP over subsets of the FROM list:

```
for each subset S in size order:
    for each split (S - {x}, x):
        cost = cost(S - {x}) + cost({x}) + join_cost(...)
        keep the cheapest
```

Capped at six tables (`OptimizerConfig.join_reorder_limit`) to keep
the state space manageable. Beyond the cap, we use the order the
parser produced.

## Index selection

For a given scan, the optimizer compares a sequential scan against
each available index that covers the predicate's leftmost column. The
selectivity model is fixed at 10% by default; in practice you should
run `ANALYZE` to populate per-column histograms before relying on the
optimizer's choices.
