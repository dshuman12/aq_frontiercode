-- Analytics demo: feed Pebble a synthetic events table, run a
-- group-by query, and a self-join.

CREATE TABLE events (
    id BIGINT PRIMARY KEY,
    user_id INT NOT NULL,
    action TEXT NOT NULL,
    occurred_at TIMESTAMP NOT NULL
);

CREATE INDEX idx_events_user ON events (user_id);

INSERT INTO events VALUES
    (1, 1, 'login',  '2024-01-01T00:00:00'),
    (2, 1, 'view',   '2024-01-01T00:01:00'),
    (3, 2, 'login',  '2024-01-01T00:02:00'),
    (4, 2, 'purchase','2024-01-01T00:05:00'),
    (5, 1, 'purchase','2024-01-01T00:06:00');

SELECT user_id, COUNT(*) AS events_per_user
FROM events
GROUP BY user_id
ORDER BY events_per_user DESC;

SELECT a.user_id, COUNT(*) AS shared_actions
FROM events a
INNER JOIN events b ON a.user_id = b.user_id AND a.action = b.action
WHERE a.id < b.id
GROUP BY a.user_id;
