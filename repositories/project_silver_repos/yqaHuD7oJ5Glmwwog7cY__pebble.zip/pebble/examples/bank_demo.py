from __future__ import annotations

import tempfile

from pebble.server.embedded import open_embedded


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        conn = open_embedded(tmp)
        conn.execute(
            "CREATE TABLE accounts ("
            "  id INT PRIMARY KEY,"
            "  owner TEXT NOT NULL,"
            "  balance DOUBLE NOT NULL"
            ")"
        )
        conn.execute("CREATE INDEX idx_owner ON accounts (owner)")
        conn.execute(
            "INSERT INTO accounts VALUES "
            "(1, 'alice', 100.0),"
            "(2, 'bob', 50.0),"
            "(3, 'carol', 75.0)"
        )
        result = conn.execute(
            "SELECT owner, balance FROM accounts WHERE balance > 60 ORDER BY balance"
        )
        print("rich accounts:")
        for row in result.rows:
            print(f"  {row[0].payload:<8} {row[1].payload}")
        conn.execute("UPDATE accounts SET balance = balance + 25 WHERE id = 2")
        result = conn.execute("SELECT SUM(balance) AS total FROM accounts")
        print(f"total balance: {result.rows[0][0].payload}")
        conn.execute("DELETE FROM accounts WHERE id = 1")
        result = conn.execute("SELECT COUNT(*) FROM accounts")
        print(f"remaining accounts: {result.rows[0][0].payload}")
        conn.close()


if __name__ == "__main__":
    main()
