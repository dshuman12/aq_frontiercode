# BRISQUE + NIMA Image Quality Assessment System

## System Overview

This system provides real-time image quality assessment using two complementary metrics:
- **BRISQUE**: Technical quality assessment (blur, noise, distortion)
- **NIMA**: Aesthetic quality assessment (visual appeal, composition)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    BRISQUE + NIMA System                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────┐    ┌─────────────────┐    ┌──────────────┐ │
│  │   Frontend UI   │    │   Backend API   │    │   AI Models  │ │
│  │                 │    │                 │    │              │ │
│  │ • Upload Area   │◄──►│ • FastAPI       │◄──►│ • PyIQA      │ │
│  │ • Drag & Drop   │    │ • File Handling │    │ • BRISQUE    │ │
│  │ • Progress Bar  │    │ • Temp Storage  │    │ • NIMA       │ │
│  │ • Results Grid  │    │ • Score Calc    │    │ • Analyzers  │ │
│  │ • Export CSV    │    │ • JSON Response │    │              │ │
│  └─────────────────┘    └─────────────────┘    └──────────────┘ │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                    Optional Components                          │
│                                                                 │
│  ┌─────────────────┐    ┌─────────────────┐    ┌──────────────┐ │
│  │     Redis       │    │     Celery      │    │    Flower    │ │
│  │                 │    │                 │    │              │ │
│  │ • Task Queue    │◄──►│ • Background    │◄──►│ • Monitoring │ │
│  │ • Result Cache  │    │   Processing    │    │ • Task Mgmt  │ │
│  │ • Session Store │    │ • Worker Pools  │    │ • Web UI     │ │
│  └─────────────────┘    └─────────────────┘    └──────────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
brisque+nima/
├── src/
│   ├── backend/
│   │   └── app/
│   │       ├── api.py              # FastAPI application
│   │       ├── analyzer.py         # BRISQUE+NIMA analyzer
│   │       └── ui/                 # Minimal UI (backup)
│   └── frontend/
│       └── exported-assets 1 2/    # Main UI assets
│           ├── index.html          # Upload interface
│           ├── app.js              # Frontend logic
│           ├── style.css           # UI styling
│           └── ...                 # Additional assets
├── docs/
│   ├── SYSTEM_ARCHITECTURE.md     # This document
│   ├── API_REFERENCE.md           # API documentation
│   └── DEPLOYMENT_GUIDE.md        # Setup instructions
├── tests/
│   ├── test_api.py                # API tests
│   ├── test_analyzer.py           # Model tests
│   └── test_integration.py        # End-to-end tests
├── examples/
│   ├── sample_images/             # Test images
│   └── usage_examples.py          # Code examples
├── docker-compose.yml             # Multi-service setup
├── Dockerfile                     # Container definition
├── requirements.txt               # Python dependencies
├── celery_app.py                  # Celery configuration
└── README.md                      # Quick start guide
```

## Core Components

### 1. Frontend UI (`src/frontend/`)
- **Technology**: Vanilla HTML/CSS/JavaScript
- **Features**:
  - Drag-and-drop image upload
  - Real-time progress tracking
  - Interactive results grid with ranking
  - Score visualization with color coding
  - CSV export functionality
  - Responsive design with dark/light mode

### 2. Backend API (`src/backend/app/`)
- **Technology**: FastAPI + Python 3.12
- **Endpoints**:
  - `POST /score_files` - Upload and score images
  - `GET /ui` - Serve frontend interface
  - `GET /health` - Health check
- **Features**:
  - Multipart file upload handling
  - Temporary file management
  - Batch processing
  - JSON response formatting

### 3. AI Models (`analyzer.py`)
- **BRISQUE**: Blind/Referenceless Image Spatial Quality Evaluator
  - Range: 1-100 (lower = better quality)
  - Measures: Blur, noise, compression artifacts
- **NIMA**: Neural Image Assessment
  - Range: 1-10 (higher = better aesthetics)
  - Measures: Composition, color harmony, visual appeal
- **Combined Score**: Weighted combination (BRISQUE 40%, NIMA 60%)

## Data Flow

```
1. User uploads images via frontend
   ↓
2. Frontend sends multipart POST to /score_files
   ↓
3. Backend saves files to temporary directory
   ↓
4. BrisqueNimaAnalyzer processes each image:
   - Loads image with PIL
   - Runs PyIQA BRISQUE model
   - Runs PyIQA NIMA model
   - Calculates combined score
   ↓
5. Backend returns JSON results
   ↓
6. Frontend updates UI with scores and rankings
   ↓
7. Backend cleans up temporary files
```

## Scoring System

### BRISQUE (Technical Quality)
- **Excellent**: 1-25
- **Good**: 26-50
- **Fair**: 51-75
- **Poor**: 76-100

### NIMA (Aesthetic Quality)
- **Excellent**: 8-10
- **Good**: 6-7.9
- **Fair**: 4-5.9
- **Poor**: 1-3.9

### Combined Score
- Formula: `(100 - BRISQUE) / 10 * 0.4 + NIMA * 0.6`
- Range: 0-10 (higher = better overall quality)

## Deployment Options

### 1. Development (Local)
```bash
# Install dependencies
pip install -r requirements.txt

# Run server
uvicorn src.backend.app.api:app --host 0.0.0.0 --port 8080

# Access UI
http://localhost:8080/ui
```

### 2. Production (Docker)
```bash
# Single container
docker build -t brisque-nima .
docker run -p 8080:8000 brisque-nima

# Multi-service with Redis/Celery
docker-compose up -d
```

### 3. Scalable (Kubernetes)
- API pods with horizontal scaling
- Redis cluster for task queuing
- Celery workers for background processing
- Load balancer for traffic distribution

## Performance Characteristics

### Processing Speed
- **Single Image**: ~2-5 seconds
- **Batch (10 images)**: ~15-30 seconds
- **Memory Usage**: ~500MB base + 50MB per image

### Accuracy
- **BRISQUE**: Correlates well with technical quality metrics
- **NIMA**: Trained on human aesthetic preferences
- **Combined**: Balanced technical + aesthetic assessment

## Integration Examples

### REST API Usage
```python
import requests

# Upload images for scoring
files = [('files', open('image1.jpg', 'rb')), 
         ('files', open('image2.jpg', 'rb'))]
response = requests.post('http://localhost:8080/score_files', files=files)
results = response.json()

# Process results
for result in results['results']:
    print(f"{result['file_path']}: BRISQUE={result['brisque_score']}, NIMA={result['nima_aesthetic']}")
```

### Batch Processing
```python
from src.backend.app.analyzer import BrisqueNimaAnalyzer

analyzer = BrisqueNimaAnalyzer()
items = [{'file_path': 'image1.jpg'}, {'file_path': 'image2.jpg'}]
results = analyzer.score_batch(items)
```

## Monitoring & Observability

### Health Checks
- API endpoint: `GET /health`
- Model loading status
- Memory usage tracking

### Metrics (with Celery/Flower)
- Task processing rates
- Queue lengths
- Worker utilization
- Error rates

### Logging
- Request/response logging
- Model inference timing
- Error tracking with stack traces

## Security Considerations

### File Upload Security
- File type validation (images only)
- Size limits (10MB per file)
- Temporary file cleanup
- Path traversal protection

### API Security
- CORS configuration
- Rate limiting (recommended)
- Input validation
- Error message sanitization

## Future Enhancements

### Planned Features
- Cloud storage integration (S3, GCS)
- User authentication and sessions
- Historical results database
- Advanced filtering and search
- Custom model training interface

### Performance Optimizations
- GPU acceleration for models
- Image preprocessing pipeline
- Caching for repeated uploads
- Async processing with WebSockets

## Troubleshooting

### Common Issues
1. **"python-multipart" error**: Install with `pip install python-multipart`
2. **Model loading fails**: Check PyIQA installation and model downloads
3. **UI not loading**: Verify static file mounting in api.py
4. **Slow processing**: Consider GPU acceleration or batch size tuning

### Debug Mode
```bash
# Enable debug logging
export LOG_LEVEL=DEBUG
uvicorn src.backend.app.api:app --reload --log-level debug
```

## License & Credits

- **PyIQA**: Image quality assessment library
- **FastAPI**: Modern web framework for APIs
- **BRISQUE**: Original algorithm by Mittal et al.
- **NIMA**: Neural approach by Google Research
