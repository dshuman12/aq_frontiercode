# Deployment Guide

## Prerequisites

### System Requirements
- **CPU**: 2+ cores recommended
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 2GB for models and dependencies
- **OS**: Linux, macOS, or Windows with Docker

### Software Dependencies
- Python 3.12+
- Docker & Docker Compose (for containerized deployment)
- Git (for cloning repository)

## Local Development Setup

### 1. Clone and Setup
```bash
git clone <repository-url>
cd brisque+nima

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install python-multipart
```

### 2. Run Development Server
```bash
uvicorn src.backend.app.api:app --host 0.0.0.0 --port 8080 --reload
```

### 3. Access Application
- Web UI: http://localhost:8080/ui
- API Docs: http://localhost:8080/docs
- Health Check: http://localhost:8080/health

## Docker Deployment

### Single Container
```bash
# Build image
docker build -t brisque-nima .

# Run container
docker run -d \
  --name brisque-nima \
  -p 8080:8000 \
  -e LOG_LEVEL=INFO \
  brisque-nima
```

### Multi-Service with Docker Compose
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Scale API workers
docker-compose up -d --scale api=3

# Stop services
docker-compose down
```

**Services included:**
- `api`: FastAPI application
- `worker`: Celery background workers
- `redis`: Task queue and caching
- `flower`: Monitoring dashboard (port 5555)

## Production Deployment

### Environment Configuration
Create `.env` file:
```bash
# Logging
LOG_LEVEL=INFO

# Redis Configuration
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0

# Security
CORS_ORIGINS=["https://yourdomain.com"]
MAX_FILE_SIZE=10485760  # 10MB in bytes

# Performance
WORKER_CONCURRENCY=4
API_WORKERS=2
```

### Kubernetes Deployment
```yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: brisque-nima-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: brisque-nima-api
  template:
    metadata:
      labels:
        app: brisque-nima-api
    spec:
      containers:
      - name: api
        image: brisque-nima:latest
        ports:
        - containerPort: 8000
        env:
        - name: LOG_LEVEL
          value: "INFO"
        - name: CELERY_BROKER_URL
          value: "redis://redis-service:6379/0"
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
---
apiVersion: v1
kind: Service
metadata:
  name: brisque-nima-service
spec:
  selector:
    app: brisque-nima-api
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
```

Apply deployment:
```bash
kubectl apply -f k8s-deployment.yaml
```

### Cloud Deployment Options

#### AWS ECS
```bash
# Create task definition
aws ecs register-task-definition --cli-input-json file://task-definition.json

# Create service
aws ecs create-service \
  --cluster production \
  --service-name brisque-nima \
  --task-definition brisque-nima:1 \
  --desired-count 2
```

#### Google Cloud Run
```bash
# Build and push to registry
docker build -t gcr.io/PROJECT_ID/brisque-nima .
docker push gcr.io/PROJECT_ID/brisque-nima

# Deploy to Cloud Run
gcloud run deploy brisque-nima \
  --image gcr.io/PROJECT_ID/brisque-nima \
  --platform managed \
  --region us-central1 \
  --memory 2Gi \
  --cpu 2 \
  --max-instances 10
```

#### Azure Container Instances
```bash
az container create \
  --resource-group myResourceGroup \
  --name brisque-nima \
  --image brisque-nima:latest \
  --cpu 2 \
  --memory 4 \
  --ports 8000 \
  --environment-variables LOG_LEVEL=INFO
```

## Performance Optimization

### GPU Acceleration
```dockerfile
# Dockerfile.gpu
FROM nvidia/cuda:11.8-runtime-ubuntu20.04

# Install PyTorch with CUDA support
RUN pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# Set CUDA environment
ENV CUDA_VISIBLE_DEVICES=0
```

### Load Balancing with Nginx
```nginx
# nginx.conf
upstream brisque_nima {
    server api1:8000;
    server api2:8000;
    server api3:8000;
}

server {
    listen 80;
    server_name yourdomain.com;

    client_max_body_size 50M;

    location / {
        proxy_pass http://brisque_nima;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

### Redis Configuration
```redis
# redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
```

## Monitoring & Observability

### Health Checks
```bash
# Docker health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:8000/health || exit 1
```

### Logging Configuration
```python
# logging_config.py
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        },
    },
    "handlers": {
        "default": {
            "formatter": "default",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "root": {
        "level": "INFO",
        "handlers": ["default"],
    },
}
```

### Prometheus Metrics
```python
# Add to api.py
from prometheus_client import Counter, Histogram, generate_latest

REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

## Security Configuration

### HTTPS Setup
```bash
# Generate SSL certificate with Let's Encrypt
certbot --nginx -d yourdomain.com

# Or use self-signed for testing
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes
```

### API Security
```python
# Add to api.py
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["yourdomain.com", "*.yourdomain.com"]
)
```

### Rate Limiting
```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.post("/score_files")
@limiter.limit("10/minute")
async def score_files(request: Request, files: List[UploadFile]):
    # Implementation
```

## Backup & Recovery

### Data Backup
```bash
# Backup Redis data
docker exec redis redis-cli BGSAVE
docker cp redis:/data/dump.rdb ./backup/

# Backup application logs
docker logs brisque-nima > ./backup/app.log
```

### Disaster Recovery
```bash
# Restore Redis data
docker cp ./backup/dump.rdb redis:/data/
docker restart redis

# Rollback deployment
docker-compose down
docker-compose up -d --scale api=1
```

## Troubleshooting

### Common Issues

1. **Out of Memory**
   ```bash
   # Increase container memory
   docker run -m 4g brisque-nima
   
   # Monitor memory usage
   docker stats
   ```

2. **Model Loading Errors**
   ```bash
   # Check PyIQA installation
   pip install --upgrade pyiqa
   
   # Verify CUDA availability
   python -c "import torch; print(torch.cuda.is_available())"
   ```

3. **High Latency**
   ```bash
   # Enable GPU acceleration
   export CUDA_VISIBLE_DEVICES=0
   
   # Reduce image resolution
   export MAX_IMAGE_SIZE=1024
   ```

### Debug Commands
```bash
# Check container logs
docker logs -f brisque-nima

# Execute commands in container
docker exec -it brisque-nima bash

# Test API endpoints
curl -X POST http://localhost:8080/score_files -F "files=@test.jpg"

# Monitor resource usage
htop
nvidia-smi  # For GPU monitoring
```

## Maintenance

### Updates
```bash
# Update dependencies
pip install --upgrade -r requirements.txt

# Rebuild Docker image
docker build -t brisque-nima:v2 .

# Rolling update
docker-compose up -d --no-deps api
```

### Cleanup
```bash
# Remove unused Docker images
docker image prune -a

# Clean up temporary files
docker exec brisque-nima find /tmp -type f -name "temp_*" -delete

# Rotate logs
logrotate /etc/logrotate.d/brisque-nima
```

This deployment guide covers all major deployment scenarios from development to production-scale deployments.
