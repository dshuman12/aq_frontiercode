# API Reference

## Base URL
```
http://localhost:8080
```

## Endpoints

### POST /score_files
Upload and score multiple images using BRISQUE and NIMA models.

**Request:**
- Method: `POST`
- Content-Type: `multipart/form-data`
- Body: Multiple files with key `files`

**Parameters:**
- `files` (required): One or more image files (JPG, PNG, WebP)
- File size limit: 10MB per file

**Response:**
```json
{
  "count": 2,
  "results": [
    {
      "file_path": "temp_image_001.jpg",
      "brisque_score": 23.45,
      "nima_aesthetic": 7.2
    },
    {
      "file_path": "temp_image_002.jpg", 
      "brisque_score": 45.67,
      "nima_aesthetic": 5.8
    }
  ]
}
```

**Example:**
```bash
curl -X POST "http://localhost:8080/score_files" \
  -F "files=@image1.jpg" \
  -F "files=@image2.jpg"
```

### GET /ui
Serves the web interface for image upload and scoring.

**Response:** HTML page with upload interface

### GET /health
Health check endpoint.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

## Error Responses

### 400 Bad Request
```json
{
  "detail": "No files provided"
}
```

### 413 Payload Too Large
```json
{
  "detail": "File size exceeds 10MB limit"
}
```

### 422 Unprocessable Entity
```json
{
  "detail": "Invalid file format. Only images are supported."
}
```

### 500 Internal Server Error
```json
{
  "detail": "Model inference failed"
}
```

## Rate Limits
- No rate limits currently implemented
- Recommended: 100 requests per minute per IP

## Authentication
- No authentication required
- Recommended for production: API key or JWT tokens
