# BRISQUE + NIMA Microservice

A minimal, cloud‑agnostic microservice for image quality (BRISQUE) and aesthetics (NIMA) scoring.

This service is independent from the full AI Photo Culling system and can be shared/used separately.

## Features

## 📁 Project Structure

```
brisque+nima/
├── src/
│   ├── backend/app/          # FastAPI application & AI models
│   └── frontend/             # Modern web UI with upload interface
├── docs/                     # Comprehensive documentation
├── tests/                    # Test suites for all components
├── examples/                 # Usage examples and sample images
├── docker-compose.yml        # Multi-service deployment
├── Dockerfile               # Container definition
└── requirements.txt         # Python dependencies
```

## 🏃‍♂️ Quick Start

### Local Development

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   pip install python-multipart  # Required for file uploads
   ```

2. **Run the Server**
   ```bash
   uvicorn src.backend.app.api:app --host 0.0.0.0 --port 8080
   ```

3. **Access the UI**
   ```
   http://localhost:8080/ui
   ```

### Docker Deployment

1. **Single Container**
   ```bash
   docker build -t brisque-nima .
   docker run -p 8080:8000 brisque-nima
   ```

2. **Full Stack with Redis/Celery**
   ```bash
   docker-compose up -d
   ```

## 🔌 API Usage

### Upload Images for Scoring

```bash
curl -X POST "http://localhost:8080/score_files" \
  -F "files=@image1.jpg" \
  -F "files=@image2.jpg"
```

### Python Integration

```python
import requests

# Upload images for scoring
files = [('files', open('image1.jpg', 'rb')), 
         ('files', open('image2.jpg', 'rb'))]
response = requests.post('http://localhost:8080/score_files', files=files)
results = response.json()

# Process results
for result in results['results']:
    print(f"{result['file_path']}: BRISQUE={result['brisque_score']}, NIMA={result['nima_aesthetic']}")
```

### Response Format

```json
{
  "count": 2,
  "results": [
    {
      "file_path": "temp_image_001.jpg",
      "brisque_score": 23.45,
      "nima_aesthetic": 7.2,
      "combined_score": 6.8
    }
  ]
}
```

## 📊 Scoring Guide

### BRISQUE (Technical Quality)
- **Range**: 1-100 (lower = better)
- **Measures**: Blur, noise, compression artifacts, distortion
- **Excellent**: 1-25 | **Good**: 26-50 | **Fair**: 51-75 | **Poor**: 76-100

### NIMA (Aesthetic Quality)
- **Range**: 1-10 (higher = better)
- **Measures**: Composition, color harmony, visual appeal
- **Excellent**: 8-10 | **Good**: 6-7.9 | **Fair**: 4-5.9 | **Poor**: 1-3.9

### Combined Score
- **Formula**: `(100 - BRISQUE) / 10 * 0.4 + NIMA * 0.6`
- **Range**: 0-10 (higher = better overall quality)
- **Purpose**: Balanced technical + aesthetic assessment

## 📚 Documentation

- **[System Architecture](docs/SYSTEM_ARCHITECTURE.md)**: Detailed technical documentation
- **[API Reference](docs/API_REFERENCE.md)**: Complete API documentation
- **[Deployment Guide](docs/DEPLOYMENT_GUIDE.md)**: Production deployment instructions

## 🧪 Development

### Running Tests
```bash
pytest tests/ -v
```

### Development Mode
```bash
export LOG_LEVEL=DEBUG
uvicorn src.backend.app.api:app --reload --log-level debug
```

### Adding New Features
1. Backend changes: Modify `src/backend/app/`
2. Frontend changes: Update `src/frontend/`
3. Add tests in `tests/`
4. Update documentation in `docs/`

## 🚀 Production Deployment

### Environment Variables
```bash
LOG_LEVEL=INFO
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0
```

### Performance Optimization
- Use GPU acceleration for faster model inference
- Configure Redis for task queuing and caching
- Set up horizontal scaling with multiple workers
- Enable monitoring with Flower dashboard

### Security
- Configure CORS for production domains
- Set up rate limiting for API endpoints
- Use HTTPS for secure file uploads
- Implement proper error handling and logging

## 🔧 Troubleshooting

### Common Issues

1. **"python-multipart" error**
   ```bash
   pip install python-multipart
   ```

2. **Models not loading**
   ```bash
   pip install pyiqa torch torchvision
   ```

3. **UI not accessible**
   - Verify static file mounting in `src/backend/app/api.py`
   - Check frontend files exist in `src/frontend/`

4. **Slow processing**
   - Consider GPU acceleration
   - Reduce image resolution for faster processing
   - Use batch processing for multiple images

### Debug Commands
```bash
# Check API health
curl http://localhost:8080/health

# Test file upload
curl -X POST http://localhost:8080/score_files -F "files=@test.jpg"

# Monitor logs
docker-compose logs -f api
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Add tests for new functionality
4. Update documentation
5. Commit changes (`git commit -m 'Add amazing feature'`)
6. Push to branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## 📄 License

MIT License - see LICENSE file for details.

## 🙏 Credits

- **[PyIQA](https://github.com/chaofengc/IQA-PyTorch)**: Image quality assessment models
- **[FastAPI](https://fastapi.tiangolo.com/)**: Modern web framework for APIs
- **BRISQUE**: Mittal et al. - "No-Reference Image Quality Assessment in the Spatial Domain"
- **NIMA**: Talebi & Milanfar - "NIMA: Neural Image Assessment"

---

**Built for professional image quality assessment with modern web technologies.**
