#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Iterator, Optional, Dict, Any, Tuple
import os
import tempfile


class StorageAdapter:
    """Cloud-agnostic minimal storage adapter (local + S3).
    - Local: file:// or bare paths
    - S3: s3://bucket/key
    """

    def __init__(self, backend: Optional[str] = None):
        self.backend = (backend or os.getenv("STORAGE_BACKEND", "local")).lower()

    @staticmethod
    def parse_uri(uri: str) -> Tuple[str, Optional[str], Optional[str]]:
        if uri.startswith("s3://"):
            rest = uri[5:]
            bucket, _, key = rest.partition("/")
            return ("s3", bucket, key)
        if uri.startswith("file://"):
            return ("file", None, uri[7:])
        return ("file", None, uri)

    def upload_init(self, customer_id: str, prefix: str = "uploads/", content_type: str = "image/jpeg", expires_in: int = 3600) -> Dict[str, Any]:
        if self.backend == "s3":
            import boto3
            bucket = os.getenv("S3_BUCKET")
            if not bucket:
                raise RuntimeError("S3_BUCKET not configured")
            key_template = f"{prefix}{customer_id}/$FILENAME"
            s3 = boto3.client("s3")
            post = s3.generate_presigned_post(
                Bucket=bucket,
                Key=key_template,
                Fields={"Content-Type": content_type},
                Conditions=[["starts-with", "$Content-Type", "image/"]],
                ExpiresIn=expires_in,
            )
            return {"backend": "s3", "bucket": bucket, "key_template": key_template, "post": post}
        base_dir = Path(os.getenv("LOCAL_UPLOADS_DIR", "./uploads")) / customer_id
        base_dir.mkdir(parents=True, exist_ok=True)
        return {"backend": "local", "upload_dir": str(base_dir)}

    def list_prefix(self, uri_prefix: str) -> Iterator[str]:
        scheme, bucket, key_prefix = self.parse_uri(uri_prefix)
        if scheme == "s3":
            import boto3
            s3 = boto3.client("s3")
            paginator = s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=key_prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    yield f"s3://{bucket}/{key}"
        else:
            p = Path(key_prefix)
            if p.is_dir():
                for f in sorted(p.iterdir()):
                    if f.is_file():
                        yield str(f)

    @staticmethod
    def is_image(name: str) -> bool:
        n = name.lower()
        return n.endswith((".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"))

    def download_to_temp(self, uri: str) -> str:
        scheme, bucket, key = self.parse_uri(uri)
        if scheme == "s3":
            import boto3
            suffix = Path(key).suffix
            fd, tmp_path = tempfile.mkstemp(suffix=suffix)
            os.close(fd)
            s3 = boto3.client("s3")
            s3.download_file(bucket, key, tmp_path)
            return tmp_path
        return key or uri

    # ---------- Writes ----------
    def join_uri(self, prefix: str, filename: str) -> str:
        scheme, bucket, key_prefix = self.parse_uri(prefix)
        if scheme == "s3":
            key_prefix = key_prefix.rstrip("/")
            return f"s3://{bucket}/{key_prefix}/{filename}"
        # local
        base = Path(key_prefix)
        return str(base / filename)

    def put_bytes(self, uri: str, data: bytes, content_type: str | None = None) -> None:
        scheme, bucket, key = self.parse_uri(uri)
        if scheme == "s3":
            import boto3
            s3 = boto3.client("s3")
            extra = {"ContentType": content_type} if content_type else {}
            s3.put_object(Bucket=bucket, Key=key, Body=data, **extra)
            return
        # local write
        path = Path(key or uri)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as f:
            f.write(data)

# add TTL cache eviction

# add GCS storage support stub

# add score export to CSV

# add celery beat schedule
