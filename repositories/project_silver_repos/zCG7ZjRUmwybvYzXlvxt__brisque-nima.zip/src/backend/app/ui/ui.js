(function(){
  const fileInput = document.getElementById('fileInput');
  const pickBtn = document.getElementById('pickBtn');
  const dropzone = document.getElementById('dropzone');
  const progress = document.getElementById('progress');
  const bar = document.getElementById('bar');
  const label = document.getElementById('label');
  const results = document.getElementById('results');
  const tbody = document.getElementById('tbody');
  const exportCsv = document.getElementById('exportCsv');

  function setProgress(pct, text) {
    progress.classList.remove('hidden');
    bar.style.width = `${pct}%`;
    label.textContent = text || `${Math.round(pct)}%`;
  }

  pickBtn.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', async (e) => {
    if (!e.target.files || e.target.files.length === 0) return;
    await scoreFiles(e.target.files);
  });

  ;['dragover','dragleave','drop'].forEach(evt => {
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (evt === 'dragover') dropzone.classList.add('drag');
      else dropzone.classList.remove('drag');
    });
  });

  dropzone.addEventListener('drop', async (e) => {
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;
    await scoreFiles(files);
  });

  async function scoreFiles(files){
    try {
      setProgress(5, 'Uploading…');
      const valid = Array.from(files).filter(f => f.type.startsWith('image/'));
      const form = new FormData();
      valid.forEach(f => form.append('files', f));
      const resp = await fetch('/score_files', { method: 'POST', body: form });
      if (!resp.ok) throw new Error(`Server error: ${resp.status}`);
      setProgress(60, 'Scoring…');
      const data = await resp.json();
      const rows = (data.results || []).map(r => ({
        name: (r.file_path || '').split('/').pop(),
        brisque: Number(r.brisque_score),
        nima: Number(r.nima_aesthetic),
      })).sort((a,b) => a.brisque - b.brisque);
      render(rows);
      setProgress(100, 'Done');
      setTimeout(() => progress.classList.add('hidden'), 600);
    } catch (err) {
      label.textContent = `Error: ${err.message}`;
    }
  }

  function render(rows){
    results.classList.remove('hidden');
    tbody.innerHTML = '';
    rows.forEach(r => {
      const combined = Math.round((((100 - r.brisque)/10)*0.4 + r.nima*0.6)*100)/100;
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${r.name}</td>
        <td class="num">${r.brisque.toFixed(3)}</td>
        <td class="num">${r.nima.toFixed(3)}</td>
        <td class="num">${combined.toFixed(2)}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  exportCsv.addEventListener('click', () => {
    const lines = [['Name','BRISQUE','NIMA','Combined']];
    Array.from(tbody.querySelectorAll('tr')).forEach(tr => {
      const cols = Array.from(tr.querySelectorAll('td')).map(td => td.textContent);
      lines.push(cols);
    });
    const csv = lines.map(a => a.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `brisque_nima_${Date.now()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
})();
