#!/usr/bin/env python3
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Dict

import sys
CURR = Path(__file__).resolve().parent
if str(CURR.parent) not in sys.path:
    sys.path.insert(0, str(CURR.parent))

from app.analyzer import BrisqueNimaAnalyzer
from app.storage_adapter import StorageAdapter


def generate_md_for_prefix(uri_prefix: str, customer_id: str, output_md: Path) -> int:
    adapter = StorageAdapter()
    analyzer = BrisqueNimaAnalyzer()

    items: List[Dict[str, str]] = []
    for p in adapter.list_prefix(uri_prefix):
        if not adapter.is_image(p):
            continue
        items.append({"path": p, "id": f"{customer_id}:{Path(p).name}"})

    if not items:
        print(f"No images found under: {uri_prefix}")
        return 1

    results = analyzer.score_batch(items)

    # Build Markdown
    lines: List[str] = []
    lines.append("# BRISQUE + NIMA Results")
    lines.append("")
    lines.append("| Name | BRISQUE | NIMA |")
    lines.append("|---|---:|---:|")
    for r in results:
        name = Path(r.get("file_path", "")).name
        brisque = r.get("brisque_score", 0.0)
        nima = r.get("nima_aesthetic", 0.0)
        lines.append(f"| {name} | {float(brisque):.3f} | {float(nima):.3f} |")

    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text("\n".join(lines), encoding="utf-8")
    print(f"Markdown written to: {output_md}")
    return 0


if __name__ == "__main__":
    # Default to local desktop images folder used earlier
    uri_prefix = os.environ.get("BN_PREFIX", "/Users/kunjan/Desktop/all_Images")
    customer_id = os.environ.get("BN_CUSTOMER_ID", "demo_all")
    output_md = Path(os.environ.get("BN_OUTPUT_MD", "/Users/kunjan/Desktop/AI_culling_final/outputs/brisque_nima_results.md"))
    raise SystemExit(generate_md_for_prefix(uri_prefix, customer_id, output_md))

# add API endpoints

# add report generator

# add health check endpoint

# fix edge case in percentile

# improve filter request validation

# add Dockerfile
