"""Database storage layer for assessment results using SQLAlchemy."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class AssessmentRecord:
    id: Optional[int]
    path: str
    brisque_raw: float
    brisque_quality: float
    nima_raw: float
    nima_score: float
    combined_score: float
    grade: str
    passed: bool
    reject_reasons: List[str]
    error: Optional[str]
    job_id: Optional[str]
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_result_dict(cls, result: Dict[str, Any], job_id: Optional[str] = None) -> "AssessmentRecord":
        return cls(
            id=None,
            path=result.get("path", ""),
            brisque_raw=result.get("brisque_raw", 0.0),
            brisque_quality=result.get("brisque_quality", 0.0),
            nima_raw=result.get("nima_raw", 0.0),
            nima_score=result.get("nima_score", 0.0),
            combined_score=result.get("combined_score", 0.0),
            grade=result.get("grade", "unknown"),
            passed=bool(result.get("passed", False)),
            reject_reasons=result.get("reject_reasons", []),
            error=result.get("error"),
            job_id=job_id,
            metadata=result.get("metadata", {}),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "path": self.path,
            "brisque_raw": self.brisque_raw,
            "brisque_quality": self.brisque_quality,
            "nima_raw": self.nima_raw,
            "nima_score": self.nima_score,
            "combined_score": self.combined_score,
            "grade": self.grade,
            "passed": self.passed,
            "reject_reasons": self.reject_reasons,
            "error": self.error,
            "job_id": self.job_id,
            "created_at": self.created_at,
        }


class InMemoryAssessmentStore:
    """
    In-memory store for assessment results.
    Suitable for single-process deployments and testing.
    """

    def __init__(self) -> None:
        import threading
        self._records: Dict[int, AssessmentRecord] = {}
        self._next_id = 1
        self._lock = threading.RLock()

    def insert(self, record: AssessmentRecord) -> AssessmentRecord:
        with self._lock:
            record.id = self._next_id
            self._records[self._next_id] = record
            self._next_id += 1
        return record

    def insert_batch(self, records: List[AssessmentRecord]) -> List[AssessmentRecord]:
        return [self.insert(r) for r in records]

    def get(self, record_id: int) -> Optional[AssessmentRecord]:
        with self._lock:
            return self._records.get(record_id)

    def get_by_job(self, job_id: str) -> List[AssessmentRecord]:
        with self._lock:
            return [r for r in self._records.values() if r.job_id == job_id]

    def get_by_path(self, path: str) -> List[AssessmentRecord]:
        with self._lock:
            return [r for r in self._records.values() if r.path == path]

    def get_by_grade(self, grade: str) -> List[AssessmentRecord]:
        with self._lock:
            return [r for r in self._records.values() if r.grade == grade]

    def filter(
        self,
        grade: Optional[str] = None,
        passed: Optional[bool] = None,
        job_id: Optional[str] = None,
        min_combined: Optional[float] = None,
        max_combined: Optional[float] = None,
        limit: int = 1000,
        offset: int = 0,
    ) -> List[AssessmentRecord]:
        with self._lock:
            results = list(self._records.values())

        if grade is not None:
            results = [r for r in results if r.grade == grade]
        if passed is not None:
            results = [r for r in results if r.passed == passed]
        if job_id is not None:
            results = [r for r in results if r.job_id == job_id]
        if min_combined is not None:
            results = [r for r in results if r.combined_score >= min_combined]
        if max_combined is not None:
            results = [r for r in results if r.combined_score <= max_combined]

        results.sort(key=lambda r: r.created_at, reverse=True)
        return results[offset: offset + limit]

    def delete(self, record_id: int) -> bool:
        with self._lock:
            if record_id in self._records:
                del self._records[record_id]
                return True
        return False

    def delete_by_job(self, job_id: str) -> int:
        with self._lock:
            to_delete = [rid for rid, r in self._records.items() if r.job_id == job_id]
            for rid in to_delete:
                del self._records[rid]
        return len(to_delete)

    def count(self) -> int:
        with self._lock:
            return len(self._records)

    def aggregate_stats(self, job_id: Optional[str] = None) -> Dict[str, Any]:
        records = self.get_by_job(job_id) if job_id else list(self._records.values())
        if not records:
            return {"count": 0}

        import numpy as np
        brisque_vals = [r.brisque_quality for r in records]
        nima_vals = [r.nima_score for r in records]
        combined_vals = [r.combined_score for r in records]
        grade_counts: Dict[str, int] = {}
        for r in records:
            grade_counts[r.grade] = grade_counts.get(r.grade, 0) + 1

        return {
            "count": len(records),
            "passed": sum(1 for r in records if r.passed),
            "failed": sum(1 for r in records if not r.passed),
            "brisque_mean": float(np.mean(brisque_vals)),
            "nima_mean": float(np.mean(nima_vals)),
            "combined_mean": float(np.mean(combined_vals)),
            "grade_distribution": grade_counts,
        }

    def top_n(self, n: int = 10, metric: str = "combined_score") -> List[AssessmentRecord]:
        with self._lock:
            records = list(self._records.values())
        records.sort(key=lambda r: getattr(r, metric, 0.0), reverse=True)
        return records[:n]

    def bottom_n(self, n: int = 10, metric: str = "combined_score") -> List[AssessmentRecord]:
        with self._lock:
            records = list(self._records.values())
        records.sort(key=lambda r: getattr(r, metric, 0.0))
        return records[:n]


class SQLiteAssessmentStore:
    """SQLite-backed persistent assessment store."""

    CREATE_TABLE = """
    CREATE TABLE IF NOT EXISTS assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT NOT NULL,
        brisque_raw REAL,
        brisque_quality REAL,
        nima_raw REAL,
        nima_score REAL,
        combined_score REAL,
        grade TEXT,
        passed INTEGER,
        reject_reasons TEXT,
        error TEXT,
        job_id TEXT,
        created_at REAL,
        metadata TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_job_id ON assessments(job_id);
    CREATE INDEX IF NOT EXISTS idx_grade ON assessments(grade);
    CREATE INDEX IF NOT EXISTS idx_passed ON assessments(passed);
    CREATE INDEX IF NOT EXISTS idx_combined ON assessments(combined_score);
    """

    def __init__(self, db_path: str = ":memory:") -> None:
        import sqlite3
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.executescript(self.CREATE_TABLE)
        self._conn.commit()
        import threading
        self._lock = threading.RLock()

    def insert(self, record: AssessmentRecord) -> AssessmentRecord:
        with self._lock:
            cursor = self._conn.execute(
                """INSERT INTO assessments
                   (path, brisque_raw, brisque_quality, nima_raw, nima_score,
                    combined_score, grade, passed, reject_reasons, error,
                    job_id, created_at, metadata)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    record.path, record.brisque_raw, record.brisque_quality,
                    record.nima_raw, record.nima_score, record.combined_score,
                    record.grade, int(record.passed),
                    json.dumps(record.reject_reasons), record.error,
                    record.job_id, record.created_at, json.dumps(record.metadata),
                ),
            )
            self._conn.commit()
            record.id = cursor.lastrowid
        return record

    def insert_batch(self, records: List[AssessmentRecord]) -> List[AssessmentRecord]:
        return [self.insert(r) for r in records]

    def get(self, record_id: int) -> Optional[AssessmentRecord]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM assessments WHERE id=?", (record_id,)
            ).fetchone()
        return self._row_to_record(row) if row else None

    def get_by_job(self, job_id: str) -> List[AssessmentRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM assessments WHERE job_id=? ORDER BY created_at DESC",
                (job_id,),
            ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def aggregate_stats(self, job_id: Optional[str] = None) -> Dict[str, Any]:
        with self._lock:
            if job_id:
                rows = self._conn.execute(
                    "SELECT grade, passed, brisque_quality, nima_score, combined_score "
                    "FROM assessments WHERE job_id=?", (job_id,)
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT grade, passed, brisque_quality, nima_score, combined_score "
                    "FROM assessments"
                ).fetchall()

        if not rows:
            return {"count": 0}

        grades: Dict[str, int] = {}
        passed = 0
        brisque_sum = 0.0
        nima_sum = 0.0
        combined_sum = 0.0
        for grade, p, bq, ns, cs in rows:
            grades[grade] = grades.get(grade, 0) + 1
            passed += p
            brisque_sum += bq or 0
            nima_sum += ns or 0
            combined_sum += cs or 0

        n = len(rows)
        return {
            "count": n,
            "passed": passed,
            "failed": n - passed,
            "brisque_mean": round(brisque_sum / n, 4),
            "nima_mean": round(nima_sum / n, 4),
            "combined_mean": round(combined_sum / n, 4),
            "grade_distribution": grades,
        }

    def close(self) -> None:
        self._conn.close()

    def _row_to_record(self, row: Tuple) -> AssessmentRecord:
        (rid, path, brisque_raw, brisque_quality, nima_raw, nima_score,
         combined_score, grade, passed, reject_reasons_json, error,
         job_id, created_at, metadata_json) = row
        return AssessmentRecord(
            id=rid, path=path,
            brisque_raw=brisque_raw or 0.0, brisque_quality=brisque_quality or 0.0,
            nima_raw=nima_raw or 0.0, nima_score=nima_score or 0.0,
            combined_score=combined_score or 0.0,
            grade=grade or "unknown", passed=bool(passed),
            reject_reasons=json.loads(reject_reasons_json or "[]"),
            error=error, job_id=job_id, created_at=created_at or 0.0,
            metadata=json.loads(metadata_json or "{}"),
        )
