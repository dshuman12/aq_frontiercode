from __future__ import annotations
import math
from typing import List, Optional
from .models import ImageScore, QualityTier


def mean(values: List[float]) -> Optional[float]:
    if not values:
        return None
    return sum(values) / len(values)


def stddev(values: List[float]) -> Optional[float]:
    if len(values) < 2:
        return None
    m = mean(values)
    variance = sum((x - m) ** 2 for x in values) / (len(values) - 1)
    return math.sqrt(variance)


def percentile(values: List[float], p: float) -> Optional[float]:
    if not values:
        return None
    sorted_vals = sorted(values)
    idx = (p / 100.0) * (len(sorted_vals) - 1)
    lower = int(idx)
    upper = min(lower + 1, len(sorted_vals) - 1)
    frac = idx - lower
    return sorted_vals[lower] * (1 - frac) + sorted_vals[upper] * frac


def score_distribution(scores: List[ImageScore]) -> dict:
    composites = [s.composite_score for s in scores if s.composite_score is not None]
    tier_counts = {tier.value: 0 for tier in QualityTier}
    for s in scores:
        if s.quality_tier:
            tier_counts[s.quality_tier.value] += 1

    return {
        "count": len(scores),
        "scored": len(composites),
        "failed": sum(1 for s in scores if s.error),
        "mean_composite": mean(composites),
        "stddev_composite": stddev(composites),
        "p25": percentile(composites, 25),
        "p50": percentile(composites, 50),
        "p75": percentile(composites, 75),
        "p95": percentile(composites, 95),
        "tier_distribution": tier_counts,
    }


def acceptance_rate(scores: List[ImageScore], min_composite: float = 5.0) -> float:
    scored = [s for s in scores if s.composite_score is not None]
    if not scored:
        return 0.0
    accepted = sum(1 for s in scored if s.composite_score >= min_composite)
    return accepted / len(scored)


def top_k(scores: List[ImageScore], k: int) -> List[ImageScore]:
    scored = [s for s in scores if s.composite_score is not None]
    scored.sort(key=lambda x: x.composite_score, reverse=True)
    return scored[:k]

# add error handling

# add timeout config for analysis

# add failed image list in result

# add timestamp to scores
