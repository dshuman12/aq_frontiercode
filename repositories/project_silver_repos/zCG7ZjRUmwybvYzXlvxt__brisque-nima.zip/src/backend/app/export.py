"""Export utilities for quality assessment results."""
from __future__ import annotations

import csv
import io
import json
import zipfile
from dataclasses import asdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Union

from .models import AssessmentResult


class ExportFormat:
    JSON = "json"
    CSV = "csv"
    TSV = "tsv"
    HTML = "html"
    MARKDOWN = "markdown"
    ZIP = "zip"


def _score_to_grade(score: float) -> str:
    if score >= 4.0:
        return "A"
    if score >= 3.0:
        return "B"
    if score >= 2.0:
        return "C"
    return "D"


def to_json(results: List[AssessmentResult], pretty: bool = True) -> str:
    items = []
    for r in results:
        d = asdict(r) if hasattr(r, "__dataclass_fields__") else dict(r.__dict__)
        d["grade"] = _score_to_grade(r.overall_score)
        items.append(d)
    indent = 2 if pretty else None
    return json.dumps({"results": items, "count": len(items), "exported_at": datetime.utcnow().isoformat() + "Z"}, indent=indent, default=str)


def to_csv(results: List[AssessmentResult], delimiter: str = ",") -> str:
    if not results:
        return ""
    buf = io.StringIO()
    fieldnames = [
        "image_id", "filepath", "overall_score", "grade",
        "brisque_score", "nima_score", "sharpness", "noise_level",
        "brightness", "contrast", "width", "height", "file_size",
    ]
    writer = csv.DictWriter(buf, fieldnames=fieldnames, delimiter=delimiter, extrasaction="ignore")
    writer.writeheader()
    for r in results:
        row: Dict[str, Any] = {}
        for f in fieldnames:
            row[f] = getattr(r, f, None)
        row["grade"] = _score_to_grade(r.overall_score)
        writer.writerow(row)
    return buf.getvalue()


def to_tsv(results: List[AssessmentResult]) -> str:
    return to_csv(results, delimiter="\t")


def to_html(results: List[AssessmentResult], title: str = "Quality Report") -> str:
    rows = []
    for r in results:
        grade = _score_to_grade(r.overall_score)
        color = {"A": "#d4edda", "B": "#d1ecf1", "C": "#fff3cd", "D": "#f8d7da"}.get(grade, "white")
        rows.append(
            f'<tr style="background:{color}">'
            f'<td>{r.image_id}</td>'
            f'<td>{r.overall_score:.3f}</td>'
            f'<td><b>{grade}</b></td>'
            f'<td>{getattr(r, "brisque_score", "N/A")}</td>'
            f'<td>{getattr(r, "nima_score", "N/A")}</td>'
            f'<td>{getattr(r, "sharpness", "N/A")}</td>'
            f'</tr>'
        )
    table_rows = "\n".join(rows)
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>{title}</title>
<style>
  body {{ font-family: Arial, sans-serif; padding: 20px; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th, td {{ border: 1px solid #ccc; padding: 8px; text-align: left; }}
  th {{ background: #343a40; color: white; }}
</style>
</head>
<body>
<h1>{title}</h1>
<p>Generated: {datetime.utcnow().isoformat()}Z | Total images: {len(results)}</p>
<table>
<thead>
<tr>
  <th>Image ID</th><th>Overall Score</th><th>Grade</th>
  <th>BRISQUE</th><th>NIMA</th><th>Sharpness</th>
</tr>
</thead>
<tbody>
{table_rows}
</tbody>
</table>
</body>
</html>"""


def to_markdown(results: List[AssessmentResult], title: str = "Quality Report") -> str:
    lines = [
        f"# {title}",
        f"",
        f"Generated: {datetime.utcnow().isoformat()}Z  ",
        f"Total: {len(results)} images",
        f"",
        f"| Image ID | Score | Grade | BRISQUE | NIMA | Sharpness |",
        f"|----------|-------|-------|---------|------|-----------|",
    ]
    for r in results:
        grade = _score_to_grade(r.overall_score)
        brisque = f"{getattr(r, 'brisque_score', 'N/A')}"
        nima = f"{getattr(r, 'nima_score', 'N/A')}"
        sharpness = f"{getattr(r, 'sharpness', 'N/A')}"
        lines.append(
            f"| {r.image_id} | {r.overall_score:.3f} | **{grade}** | {brisque} | {nima} | {sharpness} |"
        )
    return "\n".join(lines)


def to_zip(results: List[AssessmentResult], formats: Optional[List[str]] = None) -> bytes:
    formats = formats or [ExportFormat.JSON, ExportFormat.CSV, ExportFormat.HTML]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if ExportFormat.JSON in formats:
            zf.writestr("results.json", to_json(results))
        if ExportFormat.CSV in formats:
            zf.writestr("results.csv", to_csv(results))
        if ExportFormat.TSV in formats:
            zf.writestr("results.tsv", to_tsv(results))
        if ExportFormat.HTML in formats:
            zf.writestr("report.html", to_html(results))
        if ExportFormat.MARKDOWN in formats:
            zf.writestr("report.md", to_markdown(results))
    return buf.getvalue()


def export(
    results: List[AssessmentResult],
    fmt: str,
    **kwargs: Any,
) -> Union[str, bytes]:
    fmt = fmt.lower()
    if fmt == ExportFormat.JSON:
        return to_json(results, **kwargs)
    if fmt == ExportFormat.CSV:
        return to_csv(results)
    if fmt == ExportFormat.TSV:
        return to_tsv(results)
    if fmt == ExportFormat.HTML:
        return to_html(results, **kwargs)
    if fmt == ExportFormat.MARKDOWN:
        return to_markdown(results, **kwargs)
    if fmt == ExportFormat.ZIP:
        return to_zip(results, **kwargs)
    raise ValueError(f"Unsupported export format: {fmt}")


def summarize_grades(results: List[AssessmentResult]) -> Dict[str, Any]:
    counts: Dict[str, int] = {"A": 0, "B": 0, "C": 0, "D": 0}
    for r in results:
        grade = _score_to_grade(r.overall_score)
        counts[grade] = counts.get(grade, 0) + 1

    total = len(results)
    return {
        "total": total,
        "grade_counts": counts,
        "grade_percentages": {g: (v / total * 100 if total else 0.0) for g, v in counts.items()},
    }
