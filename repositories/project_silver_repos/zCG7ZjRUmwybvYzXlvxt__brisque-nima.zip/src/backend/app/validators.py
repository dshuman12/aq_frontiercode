"""Input validation helpers for quality assessment API."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


SUPPORTED_FORMATS = {"jpeg", "jpg", "png", "bmp", "tiff", "tif", "webp"}
MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024  # 50 MB
MIN_DIMENSION = 8
MAX_DIMENSION = 16384


@dataclass
class ValidationError:
    field: str
    message: str
    code: str = "INVALID"


@dataclass
class ValidationResult:
    valid: bool
    errors: List[ValidationError] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_error(self, field: str, message: str, code: str = "INVALID") -> None:
        self.errors.append(ValidationError(field, message, code))
        self.valid = False

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)


def validate_image_array(image: Any) -> ValidationResult:
    result = ValidationResult(valid=True)

    if not isinstance(image, np.ndarray):
        result.add_error("image", "Expected a numpy ndarray", "TYPE_ERROR")
        return result

    if image.ndim not in (2, 3):
        result.add_error("image", f"Expected 2-D or 3-D array, got {image.ndim}-D", "SHAPE_ERROR")
        return result

    h, w = image.shape[:2]
    if h < MIN_DIMENSION or w < MIN_DIMENSION:
        result.add_error("image", f"Image too small: {w}x{h} (min {MIN_DIMENSION}x{MIN_DIMENSION})", "TOO_SMALL")

    if h > MAX_DIMENSION or w > MAX_DIMENSION:
        result.add_error("image", f"Image too large: {w}x{h} (max {MAX_DIMENSION}x{MAX_DIMENSION})", "TOO_LARGE")

    if image.ndim == 3:
        channels = image.shape[2]
        if channels not in (1, 3, 4):
            result.add_error("image", f"Unsupported channel count: {channels}", "CHANNEL_ERROR")

    if image.dtype not in (np.uint8, np.float32, np.float64):
        result.add_warning(f"Unusual dtype {image.dtype}; consider converting to uint8 or float32")

    if image.dtype == np.float32 or image.dtype == np.float64:
        if image.max() > 1.0 and image.max() <= 255.0:
            result.add_warning("Float image with values in [0,255] range; consider normalizing to [0,1]")

    return result


def validate_file_path(path: str) -> ValidationResult:
    result = ValidationResult(valid=True)

    if not path or not isinstance(path, str):
        result.add_error("path", "Path must be a non-empty string", "REQUIRED")
        return result

    if len(path) > 4096:
        result.add_error("path", "Path exceeds maximum length of 4096 characters", "TOO_LONG")

    forbidden_chars = set('\x00')
    if any(c in path for c in forbidden_chars):
        result.add_error("path", "Path contains forbidden characters", "FORBIDDEN_CHARS")

    ext = os.path.splitext(path)[1].lstrip(".").lower()
    if ext and ext not in SUPPORTED_FORMATS:
        result.add_error("path", f"Unsupported format: .{ext}", "UNSUPPORTED_FORMAT")

    return result


def validate_file_bytes(data: bytes) -> ValidationResult:
    result = ValidationResult(valid=True)

    if not isinstance(data, (bytes, bytearray)):
        result.add_error("data", "Expected bytes or bytearray", "TYPE_ERROR")
        return result

    if len(data) == 0:
        result.add_error("data", "File data is empty", "EMPTY")
        return result

    if len(data) > MAX_FILE_SIZE_BYTES:
        mb = len(data) / (1024 * 1024)
        result.add_error("data", f"File size {mb:.1f} MB exceeds limit of {MAX_FILE_SIZE_BYTES // 1024 // 1024} MB", "TOO_LARGE")

    magic = data[:4]
    detected_format = _detect_format(magic)
    if detected_format is None:
        result.add_warning("Could not detect image format from file signature")

    return result


def _detect_format(magic: bytes) -> Optional[str]:
    if magic[:2] == b'\xff\xd8':
        return "jpeg"
    if magic[:4] == b'\x89PNG':
        return "png"
    if magic[:2] in (b'BM',):
        return "bmp"
    if magic[:4] in (b'II*\x00', b'MM\x00*'):
        return "tiff"
    if magic[:4] == b'RIFF':
        return "webp"
    return None


def validate_score(score: Any, field_name: str = "score") -> ValidationResult:
    result = ValidationResult(valid=True)

    if score is None:
        result.add_error(field_name, "Score is required", "REQUIRED")
        return result

    if not isinstance(score, (int, float)):
        result.add_error(field_name, f"Score must be a number, got {type(score).__name__}", "TYPE_ERROR")
        return result

    if not (1.0 <= float(score) <= 5.0):
        result.add_error(field_name, f"Score {score} out of range [1.0, 5.0]", "OUT_OF_RANGE")

    return result


def validate_batch_request(request: Dict[str, Any]) -> ValidationResult:
    result = ValidationResult(valid=True)

    if "image_ids" not in request:
        result.add_error("image_ids", "image_ids is required", "REQUIRED")
    elif not isinstance(request["image_ids"], list):
        result.add_error("image_ids", "image_ids must be a list", "TYPE_ERROR")
    elif len(request["image_ids"]) == 0:
        result.add_error("image_ids", "image_ids must not be empty", "EMPTY")
    elif len(request["image_ids"]) > 1000:
        result.add_error("image_ids", "Batch size exceeds maximum of 1000", "TOO_LARGE")

    if "config" in request:
        config = request["config"]
        if not isinstance(config, dict):
            result.add_error("config", "config must be an object", "TYPE_ERROR")

    return result


def validate_pagination(page: Any, page_size: Any) -> ValidationResult:
    result = ValidationResult(valid=True)

    try:
        page = int(page)
    except (TypeError, ValueError):
        result.add_error("page", "page must be an integer", "TYPE_ERROR")
        page = None

    try:
        page_size = int(page_size)
    except (TypeError, ValueError):
        result.add_error("page_size", "page_size must be an integer", "TYPE_ERROR")
        page_size = None

    if page is not None and page < 1:
        result.add_error("page", "page must be >= 1", "OUT_OF_RANGE")

    if page_size is not None and (page_size < 1 or page_size > 200):
        result.add_error("page_size", "page_size must be between 1 and 200", "OUT_OF_RANGE")

    return result


def validate_date_range(from_date: Any, to_date: Any) -> ValidationResult:
    result = ValidationResult(valid=True)
    from datetime import datetime

    parsed_from = None
    parsed_to = None

    if from_date is not None:
        try:
            parsed_from = datetime.fromisoformat(str(from_date))
        except (ValueError, TypeError):
            result.add_error("from_date", "Invalid ISO date format", "INVALID_FORMAT")

    if to_date is not None:
        try:
            parsed_to = datetime.fromisoformat(str(to_date))
        except (ValueError, TypeError):
            result.add_error("to_date", "Invalid ISO date format", "INVALID_FORMAT")

    if parsed_from and parsed_to and parsed_from > parsed_to:
        result.add_error("from_date", "from_date must be before to_date", "INVALID_RANGE")

    return result


def validate_image_id(image_id: Any) -> ValidationResult:
    result = ValidationResult(valid=True)

    if not image_id or not isinstance(image_id, str):
        result.add_error("image_id", "image_id must be a non-empty string", "REQUIRED")
        return result

    if len(image_id) > 256:
        result.add_error("image_id", "image_id exceeds maximum length of 256", "TOO_LONG")

    if not re.match(r'^[a-zA-Z0-9_\-./]+$', image_id):
        result.add_error("image_id", "image_id contains invalid characters", "FORBIDDEN_CHARS")

    return result


def combine_results(*results: ValidationResult) -> ValidationResult:
    combined = ValidationResult(valid=True)
    for r in results:
        combined.errors.extend(r.errors)
        combined.warnings.extend(r.warnings)
    combined.valid = len(combined.errors) == 0
    return combined
