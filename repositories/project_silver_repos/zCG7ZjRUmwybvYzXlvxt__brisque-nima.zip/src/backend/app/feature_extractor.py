"""Low-level image feature extraction for quality model input."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageFilter, ImageStat


@dataclass
class BasicFeatures:
    mean_r: float = 0.0
    mean_g: float = 0.0
    mean_b: float = 0.0
    std_r: float = 0.0
    std_g: float = 0.0
    std_b: float = 0.0
    brightness: float = 0.0
    contrast: float = 0.0
    saturation: float = 0.0
    sharpness_laplacian: float = 0.0
    noise_estimate: float = 0.0
    edge_density: float = 0.0
    aspect_ratio: float = 1.0
    megapixels: float = 0.0


@dataclass
class TextureFeatures:
    lbp_mean: float = 0.0
    lbp_std: float = 0.0
    glcm_contrast: float = 0.0
    glcm_homogeneity: float = 0.0
    glcm_energy: float = 0.0
    glcm_entropy: float = 0.0
    gabor_mean: float = 0.0
    gabor_std: float = 0.0


@dataclass
class FrequencyFeatures:
    dct_energy_low: float = 0.0
    dct_energy_mid: float = 0.0
    dct_energy_high: float = 0.0
    spectral_rolloff: float = 0.0
    spectral_flatness: float = 0.0


@dataclass
class ImageFeatureSet:
    basic: BasicFeatures = field(default_factory=BasicFeatures)
    texture: TextureFeatures = field(default_factory=TextureFeatures)
    frequency: FrequencyFeatures = field(default_factory=FrequencyFeatures)
    histogram_rgb: List[float] = field(default_factory=list)
    histogram_hsv: List[float] = field(default_factory=list)

    def to_vector(self) -> np.ndarray:
        basic_vec = [
            self.basic.mean_r, self.basic.mean_g, self.basic.mean_b,
            self.basic.std_r, self.basic.std_g, self.basic.std_b,
            self.basic.brightness, self.basic.contrast, self.basic.saturation,
            self.basic.sharpness_laplacian, self.basic.noise_estimate,
            self.basic.edge_density, self.basic.aspect_ratio, self.basic.megapixels,
        ]
        texture_vec = [
            self.texture.lbp_mean, self.texture.lbp_std,
            self.texture.glcm_contrast, self.texture.glcm_homogeneity,
            self.texture.glcm_energy, self.texture.glcm_entropy,
            self.texture.gabor_mean, self.texture.gabor_std,
        ]
        freq_vec = [
            self.frequency.dct_energy_low, self.frequency.dct_energy_mid,
            self.frequency.dct_energy_high, self.frequency.spectral_rolloff,
            self.frequency.spectral_flatness,
        ]
        return np.array(
            basic_vec + texture_vec + freq_vec + self.histogram_rgb + self.histogram_hsv,
            dtype=np.float32,
        )


class BasicFeatureExtractor:
    """Extracts colour, brightness, sharpness, and noise features."""

    HIST_BINS = 16

    def extract(self, image: Image.Image) -> BasicFeatures:
        rgb = self._ensure_rgb(image)
        arr = np.array(rgb, dtype=np.float32) / 255.0
        w, h = rgb.size

        r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
        gray = 0.299 * r + 0.587 * g + 0.114 * b

        brightness = float(gray.mean())
        contrast = float(gray.std())
        hsv = np.array(rgb.convert("HSV"), dtype=np.float32) / 255.0
        saturation = float(hsv[:, :, 1].mean())

        sharpness = self._laplacian_variance(gray)
        noise = self._noise_estimate(gray)
        edges = self._edge_density(gray)

        return BasicFeatures(
            mean_r=float(r.mean()), mean_g=float(g.mean()), mean_b=float(b.mean()),
            std_r=float(r.std()), std_g=float(g.std()), std_b=float(b.std()),
            brightness=brightness, contrast=contrast, saturation=saturation,
            sharpness_laplacian=sharpness, noise_estimate=noise, edge_density=edges,
            aspect_ratio=w / max(h, 1),
            megapixels=(w * h) / 1_000_000.0,
        )

    @staticmethod
    def _laplacian_variance(gray: np.ndarray) -> float:
        kernel = np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=np.float32)
        try:
            from scipy.ndimage import convolve
            filtered = convolve(gray, kernel)
            return float(np.clip(np.var(filtered) / 1000.0, 0.0, 1.0))
        except ImportError:
            pass
        # Fallback: manual 3x3 Laplacian
        h, w = gray.shape
        pad = np.pad(gray, 1, mode="reflect")
        laplacian = (
            pad[:-2, 1:-1] + pad[2:, 1:-1] + pad[1:-1, :-2] + pad[1:-1, 2:]
            - 4 * gray
        )
        return float(np.clip(np.var(laplacian) / 1000.0, 0.0, 1.0))

    @staticmethod
    def _noise_estimate(gray: np.ndarray) -> float:
        sigma = np.std(gray - np.mean(gray))
        return float(np.clip(sigma / 0.15, 0.0, 1.0))

    @staticmethod
    def _edge_density(gray: np.ndarray) -> float:
        gx = np.abs(np.diff(gray, axis=1, prepend=gray[:, :1]))
        gy = np.abs(np.diff(gray, axis=0, prepend=gray[:1, :]))
        magnitude = np.sqrt(gx**2 + gy**2)
        return float(np.clip(magnitude.mean() * 5.0, 0.0, 1.0))

    @staticmethod
    def _ensure_rgb(image: Image.Image) -> Image.Image:
        return image.convert("RGB") if image.mode != "RGB" else image


class TextureFeatureExtractor:
    """Extracts LBP and GLCM texture features."""

    LBP_OFFSETS = [(-1,-1),(-1,0),(-1,1),(0,1),(1,1),(1,0),(1,-1),(0,-1)]

    def extract(self, image: Image.Image, sample_size: int = 64) -> TextureFeatures:
        gray = np.array(image.convert("L").resize((sample_size, sample_size), Image.LANCZOS), dtype=np.uint8)
        lbp = self._compute_lbp(gray)
        glcm = self._compute_glcm(gray)
        gabor = self._compute_gabor_approx(gray.astype(np.float32) / 255.0)

        return TextureFeatures(
            lbp_mean=float(lbp.mean()),
            lbp_std=float(lbp.std()),
            glcm_contrast=glcm["contrast"],
            glcm_homogeneity=glcm["homogeneity"],
            glcm_energy=glcm["energy"],
            glcm_entropy=glcm["entropy"],
            gabor_mean=float(gabor.mean()),
            gabor_std=float(gabor.std()),
        )

    def _compute_lbp(self, gray: np.ndarray) -> np.ndarray:
        h, w = gray.shape
        lbp = np.zeros((h, w), dtype=np.uint8)
        for r in range(1, h - 1):
            for c in range(1, w - 1):
                center = int(gray[r, c])
                code = 0
                for bit, (dr, dc) in enumerate(self.LBP_OFFSETS):
                    if int(gray[r + dr, c + dc]) >= center:
                        code |= (1 << bit)
                lbp[r, c] = code
        return lbp.astype(np.float32) / 255.0

    def _compute_glcm(self, gray: np.ndarray, levels: int = 16) -> Dict[str, float]:
        quantized = (gray.astype(float) / 256.0 * levels).astype(int).clip(0, levels - 1)
        glcm = np.zeros((levels, levels), dtype=np.float32)
        h, w = quantized.shape
        for r in range(h):
            for c in range(w - 1):
                glcm[quantized[r, c], quantized[r, c + 1]] += 1
        total = glcm.sum()
        if total > 0:
            glcm /= total

        contrast = 0.0
        homogeneity = 0.0
        energy = 0.0
        entropy = 0.0
        for i in range(levels):
            for j in range(levels):
                p = glcm[i, j]
                contrast += (i - j) ** 2 * p
                homogeneity += p / (1 + abs(i - j))
                energy += p ** 2
                if p > 1e-10:
                    entropy -= p * math.log2(p)

        return {
            "contrast": float(np.clip(contrast / (levels ** 2), 0.0, 1.0)),
            "homogeneity": float(np.clip(homogeneity, 0.0, 1.0)),
            "energy": float(np.clip(energy, 0.0, 1.0)),
            "entropy": float(np.clip(entropy / 8.0, 0.0, 1.0)),
        }

    @staticmethod
    def _compute_gabor_approx(gray: np.ndarray) -> np.ndarray:
        """Approximate Gabor using directional Sobel filters."""
        kx = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float32)
        ky = kx.T
        h, w = gray.shape
        pad = np.pad(gray, 1, mode="reflect")
        gx = np.zeros_like(gray)
        gy = np.zeros_like(gray)
        for dr in range(3):
            for dc in range(3):
                gx += kx[dr, dc] * pad[dr:dr + h, dc:dc + w]
                gy += ky[dr, dc] * pad[dr:dr + h, dc:dc + w]
        return np.sqrt(gx**2 + gy**2)


class FrequencyFeatureExtractor:
    """Extracts DCT-based frequency domain features."""

    def extract(self, image: Image.Image, block_size: int = 8) -> FrequencyFeatures:
        gray = np.array(
            image.convert("L").resize((64, 64), Image.LANCZOS),
            dtype=np.float32,
        ) / 255.0
        dct = self._block_dct(gray, block_size)
        h, w = dct.shape
        low = float(np.abs(dct[:h//4, :w//4]).mean())
        mid = float(np.abs(dct[h//4:h//2, w//4:w//2]).mean())
        high = float(np.abs(dct[h//2:, w//2:]).mean())
        rolloff = self._spectral_rolloff(np.abs(dct).flatten())
        flatness = self._spectral_flatness(np.abs(dct).flatten() + 1e-10)
        return FrequencyFeatures(
            dct_energy_low=low, dct_energy_mid=mid, dct_energy_high=high,
            spectral_rolloff=rolloff, spectral_flatness=flatness,
        )

    @staticmethod
    def _block_dct(gray: np.ndarray, block_size: int) -> np.ndarray:
        h, w = gray.shape
        dct_result = np.zeros_like(gray)
        for r in range(0, h - block_size + 1, block_size):
            for c in range(0, w - block_size + 1, block_size):
                block = gray[r:r + block_size, c:c + block_size] - 0.5
                n = block_size
                for u in range(n):
                    for v in range(n):
                        cu = 1.0 / math.sqrt(2) if u == 0 else 1.0
                        cv = 1.0 / math.sqrt(2) if v == 0 else 1.0
                        s = 0.0
                        for x in range(n):
                            for y in range(n):
                                s += block[x, y] * math.cos((2*x+1)*u*math.pi/(2*n)) * math.cos((2*y+1)*v*math.pi/(2*n))
                        dct_result[r + u, c + v] = 0.25 * cu * cv * s
        return dct_result

    @staticmethod
    def _spectral_rolloff(spectrum: np.ndarray, pct: float = 0.85) -> float:
        total = spectrum.sum()
        if total < 1e-10:
            return 0.0
        cumsum = np.cumsum(spectrum)
        idx = np.searchsorted(cumsum, pct * total)
        return float(idx) / max(len(spectrum), 1)

    @staticmethod
    def _spectral_flatness(spectrum: np.ndarray) -> float:
        if len(spectrum) == 0:
            return 0.0
        geo_mean = math.exp(np.log(spectrum + 1e-10).mean())
        arith_mean = spectrum.mean()
        return float(geo_mean / max(arith_mean, 1e-10))


class ColorHistogramExtractor:
    """Extracts normalised RGB and HSV histograms."""

    def __init__(self, bins: int = 16) -> None:
        self.bins = bins

    def extract_rgb(self, image: Image.Image) -> List[float]:
        arr = np.array(image.convert("RGB"))
        hist = []
        for ch in range(3):
            h, _ = np.histogram(arr[:, :, ch], bins=self.bins, range=(0, 256))
            h = h.astype(float)
            if h.sum() > 0:
                h /= h.sum()
            hist.extend(h.tolist())
        return hist

    def extract_hsv(self, image: Image.Image) -> List[float]:
        arr = np.array(image.convert("HSV"))
        hist = []
        for ch in range(3):
            h, _ = np.histogram(arr[:, :, ch], bins=self.bins, range=(0, 256))
            h = h.astype(float)
            if h.sum() > 0:
                h /= h.sum()
            hist.extend(h.tolist())
        return hist


class FullFeatureExtractor:
    """Orchestrates all feature extractors into one ImageFeatureSet."""

    def __init__(
        self,
        basic_extractor: Optional[BasicFeatureExtractor] = None,
        texture_extractor: Optional[TextureFeatureExtractor] = None,
        frequency_extractor: Optional[FrequencyFeatureExtractor] = None,
        histogram_extractor: Optional[ColorHistogramExtractor] = None,
    ) -> None:
        self.basic = basic_extractor or BasicFeatureExtractor()
        self.texture = texture_extractor or TextureFeatureExtractor()
        self.frequency = frequency_extractor or FrequencyFeatureExtractor()
        self.histogram = histogram_extractor or ColorHistogramExtractor(bins=16)

    def extract(self, image: Image.Image) -> ImageFeatureSet:
        rgb = image.convert("RGB")
        return ImageFeatureSet(
            basic=self.basic.extract(rgb),
            texture=self.texture.extract(rgb),
            frequency=self.frequency.extract(rgb),
            histogram_rgb=self.histogram.extract_rgb(rgb),
            histogram_hsv=self.histogram.extract_hsv(rgb),
        )

    def extract_vector(self, image: Image.Image) -> np.ndarray:
        return self.extract(image).to_vector()

    def extract_batch(self, images: List[Image.Image]) -> List[ImageFeatureSet]:
        return [self.extract(img) for img in images]

    def extract_vectors_batch(self, images: List[Image.Image]) -> np.ndarray:
        vecs = [self.extract_vector(img) for img in images]
        return np.vstack(vecs) if vecs else np.empty((0,), dtype=np.float32)
