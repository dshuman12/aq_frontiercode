"""Celery task scheduling and job queue management."""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class JobStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRYING = "retrying"


class JobPriority(int, Enum):
    LOW = 1
    NORMAL = 5
    HIGH = 10
    CRITICAL = 20


@dataclass
class JobSpec:
    job_id: str
    task_name: str
    args: List[Any] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    priority: JobPriority = JobPriority.NORMAL
    max_retries: int = 3
    retry_delay_seconds: float = 5.0
    timeout_seconds: Optional[float] = 300.0
    tags: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)


@dataclass
class JobRecord:
    spec: JobSpec
    status: JobStatus = JobStatus.PENDING
    celery_task_id: Optional[str] = None
    attempt: int = 0
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    progress: float = 0.0

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "job_id": self.spec.job_id,
            "task": self.spec.task_name,
            "status": self.status.value,
            "priority": self.spec.priority.value,
            "attempt": self.attempt,
            "max_retries": self.spec.max_retries,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": self.duration_seconds,
            "progress": self.progress,
            "error": self.error,
            "tags": self.spec.tags,
        }


class InMemoryJobStore:
    """Thread-safe in-memory job registry."""

    def __init__(self) -> None:
        import threading
        self._jobs: Dict[str, JobRecord] = {}
        self._lock = threading.RLock()

    def put(self, record: JobRecord) -> None:
        with self._lock:
            self._jobs[record.spec.job_id] = record

    def get(self, job_id: str) -> Optional[JobRecord]:
        with self._lock:
            return self._jobs.get(job_id)

    def update_status(
        self,
        job_id: str,
        status: JobStatus,
        **kwargs,
    ) -> bool:
        with self._lock:
            record = self._jobs.get(job_id)
            if not record:
                return False
            record.status = status
            for k, v in kwargs.items():
                if hasattr(record, k):
                    setattr(record, k, v)
            return True

    def list_by_status(self, status: JobStatus) -> List[JobRecord]:
        with self._lock:
            return [r for r in self._jobs.values() if r.status == status]

    def list_by_tag(self, tag: str) -> List[JobRecord]:
        with self._lock:
            return [r for r in self._jobs.values() if tag in r.spec.tags]

    def delete(self, job_id: str) -> bool:
        with self._lock:
            if job_id in self._jobs:
                del self._jobs[job_id]
                return True
            return False

    def stats(self) -> Dict[str, int]:
        with self._lock:
            counts: Dict[str, int] = {s.value: 0 for s in JobStatus}
            for r in self._jobs.values():
                counts[r.status.value] += 1
            counts["total"] = len(self._jobs)
            return counts


class JobScheduler:
    """
    High-level job scheduler that wraps Celery task dispatch.
    Falls back to synchronous execution when Celery is unavailable.
    """

    def __init__(
        self,
        store: Optional[InMemoryJobStore] = None,
        celery_app=None,
    ) -> None:
        self._store = store or InMemoryJobStore()
        self._celery_app = celery_app

    def submit(self, spec: JobSpec) -> JobRecord:
        record = JobRecord(spec=spec, status=JobStatus.QUEUED)
        self._store.put(record)

        if self._celery_app is not None:
            try:
                task = self._celery_app.send_task(
                    spec.task_name,
                    args=spec.args,
                    kwargs=spec.kwargs,
                    priority=spec.priority.value,
                    countdown=0,
                    task_id=spec.job_id,
                    soft_time_limit=spec.timeout_seconds,
                )
                self._store.update_status(
                    spec.job_id,
                    JobStatus.QUEUED,
                    celery_task_id=task.id,
                )
            except Exception as e:
                self._store.update_status(
                    spec.job_id, JobStatus.FAILED, error=str(e)
                )

        return record

    def cancel(self, job_id: str) -> bool:
        record = self._store.get(job_id)
        if not record:
            return False
        if record.status in (JobStatus.COMPLETED, JobStatus.FAILED):
            return False
        if self._celery_app and record.celery_task_id:
            try:
                self._celery_app.control.revoke(record.celery_task_id, terminate=True)
            except Exception:
                pass
        return self._store.update_status(job_id, JobStatus.CANCELLED)

    def get_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        record = self._store.get(job_id)
        if not record:
            return None
        return record.to_dict()

    def list_jobs(
        self,
        status: Optional[JobStatus] = None,
        tag: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        if status:
            records = self._store.list_by_status(status)
        elif tag:
            records = self._store.list_by_tag(tag)
        else:
            records = list(self._store._jobs.values())

        records.sort(key=lambda r: r.spec.created_at, reverse=True)
        return [r.to_dict() for r in records[:limit]]

    def queue_stats(self) -> Dict[str, Any]:
        return self._store.stats()

    def submit_batch_assessment(
        self,
        image_paths: List[str],
        batch_id: Optional[str] = None,
        priority: JobPriority = JobPriority.NORMAL,
        tags: Optional[List[str]] = None,
    ) -> List[JobRecord]:
        batch_id = batch_id or str(uuid.uuid4())[:8]
        records = []
        for path in image_paths:
            job_id = str(uuid.uuid4())
            spec = JobSpec(
                job_id=job_id,
                task_name="assess_image",
                args=[path],
                priority=priority,
                tags=(tags or []) + [f"batch:{batch_id}"],
            )
            record = self.submit(spec)
            records.append(record)
        return records


class RetryPolicy:
    """Exponential backoff retry logic."""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        backoff_factor: float = 2.0,
        jitter: bool = True,
    ) -> None:
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter = jitter

    def delay_for_attempt(self, attempt: int) -> float:
        import random
        delay = min(
            self.base_delay * (self.backoff_factor ** attempt),
            self.max_delay,
        )
        if self.jitter:
            delay *= (0.5 + random.random() * 0.5)
        return delay

    def should_retry(self, attempt: int, exception: Exception) -> bool:
        if attempt >= self.max_retries:
            return False
        non_retryable = (ValueError, TypeError, PermissionError)
        return not isinstance(exception, non_retryable)


class RateLimiter:
    """Token bucket rate limiter for job submission."""

    def __init__(self, rate: float = 10.0, burst: int = 20) -> None:
        self.rate = rate
        self.burst = burst
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        import threading
        self._lock = threading.Lock()

    def acquire(self, tokens: int = 1) -> bool:
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_refill
            self._tokens = min(
                self.burst,
                self._tokens + elapsed * self.rate,
            )
            self._last_refill = now
            if self._tokens >= tokens:
                self._tokens -= tokens
                return True
            return False

    def wait_and_acquire(self, tokens: int = 1, timeout: float = 30.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.acquire(tokens):
                return True
            time.sleep(0.05)
        return False


class WorkerHealthMonitor:
    """Polls Celery worker health and reports status."""

    def __init__(self, celery_app=None) -> None:
        self._celery_app = celery_app

    def ping_workers(self, timeout: float = 3.0) -> Dict[str, Any]:
        if self._celery_app is None:
            return {"status": "no_celery", "workers": []}
        try:
            response = self._celery_app.control.ping(timeout=timeout)
            workers = []
            for worker_resp in (response or []):
                for name, status in worker_resp.items():
                    workers.append({"name": name, "status": status})
            return {"status": "ok", "workers": workers, "count": len(workers)}
        except Exception as e:
            return {"status": "error", "error": str(e), "workers": []}

    def active_tasks(self) -> Dict[str, Any]:
        if self._celery_app is None:
            return {}
        try:
            inspect = self._celery_app.control.inspect()
            return inspect.active() or {}
        except Exception:
            return {}

    def queue_lengths(self, queues: Optional[List[str]] = None) -> Dict[str, int]:
        queues = queues or ["celery", "high", "low"]
        lengths = {}
        if self._celery_app is None:
            return {q: 0 for q in queues}
        try:
            connection = self._celery_app.connection()
            for q in queues:
                try:
                    channel = connection.channel()
                    length = channel.queue_declare(q, passive=True).message_count
                    lengths[q] = length
                except Exception:
                    lengths[q] = -1
        except Exception:
            lengths = {q: -1 for q in queues}
        return lengths
