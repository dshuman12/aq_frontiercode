from __future__ import annotations
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum


class QualityTier(str, Enum):
    excellent = "excellent"
    good = "good"
    average = "average"
    poor = "poor"
    reject = "reject"


class ImageScore(BaseModel):
    image_path: str
    brisque_score: Optional[float] = None
    nima_score: Optional[float] = None
    composite_score: Optional[float] = None
    quality_tier: Optional[QualityTier] = None
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)
    error: Optional[str] = None

    @validator("brisque_score")
    def brisque_must_be_non_negative(cls, v):
        if v is not None and v < 0:
            raise ValueError("brisque_score must be non-negative")
        return v

    @validator("nima_score")
    def nima_must_be_in_range(cls, v):
        if v is not None and not (1.0 <= v <= 10.0):
            raise ValueError("nima_score must be between 1.0 and 10.0")
        return v


class BatchRequest(BaseModel):
    image_paths: List[str] = Field(..., min_items=1, max_items=500)
    customer_id: str
    include_brisque: bool = True
    include_nima: bool = True
    min_quality_tier: Optional[QualityTier] = None


class BatchResult(BaseModel):
    customer_id: str
    total: int
    processed: int
    failed: int
    scores: List[ImageScore]
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None


class FilterRequest(BaseModel):
    scores: List[ImageScore]
    min_composite: Optional[float] = None
    max_composite: Optional[float] = None
    min_tier: Optional[QualityTier] = None
    top_n: Optional[int] = None

    @validator("top_n")
    def top_n_positive(cls, v):
        if v is not None and v < 1:
            raise ValueError("top_n must be >= 1")
        return v


class FilterResult(BaseModel):
    total_input: int
    total_output: int
    kept: List[ImageScore]
    rejected: List[ImageScore]

# improve error messages

# add min/max composite filter
