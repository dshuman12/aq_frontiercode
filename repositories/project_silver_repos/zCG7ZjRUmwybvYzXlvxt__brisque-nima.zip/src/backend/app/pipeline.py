"""Multi-stage image quality assessment pipeline."""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image


class PipelineStage(str, Enum):
    LOAD = "load"
    PREPROCESS = "preprocess"
    BRISQUE = "brisque"
    NIMA = "nima"
    AGGREGATE = "aggregate"
    POSTPROCESS = "postprocess"


@dataclass
class StageMetrics:
    stage: PipelineStage
    duration_ms: float
    input_count: int
    output_count: int
    errors: int = 0


@dataclass
class PipelineReport:
    total_images: int
    successful: int
    failed: int
    stage_metrics: List[StageMetrics] = field(default_factory=list)
    total_duration_ms: float = 0.0
    mean_brisque: float = 0.0
    mean_nima: float = 0.0
    percentiles: Dict[str, float] = field(default_factory=dict)

    def summary(self) -> Dict[str, Any]:
        return {
            "total": self.total_images,
            "successful": self.successful,
            "failed": self.failed,
            "success_rate": self.successful / max(self.total_images, 1),
            "mean_brisque": round(self.mean_brisque, 4),
            "mean_nima": round(self.mean_nima, 4),
            "total_duration_ms": round(self.total_duration_ms, 2),
            "throughput_per_sec": round(
                self.successful / max(self.total_duration_ms / 1000, 1e-9), 2
            ),
        }


class ImageLoader:
    """Loads images from paths with format validation and conversion."""

    SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}
    MAX_SIZE_MB = 50

    def load(self, path: str) -> Tuple[Optional[np.ndarray], Optional[str]]:
        """Return (bgr_array, error_message)."""
        p = Path(path)
        if not p.exists():
            return None, f"File not found: {path}"
        if p.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            return None, f"Unsupported extension: {p.suffix}"
        if p.stat().st_size > self.MAX_SIZE_MB * 1024 * 1024:
            return None, f"File too large: {p.stat().st_size / 1024 / 1024:.1f}MB"

        try:
            import cv2
            img = cv2.imread(str(p))
            if img is None:
                return None, f"cv2 could not decode: {path}"
            return img, None
        except Exception as e:
            return None, str(e)

    def load_pil(self, path: str) -> Tuple[Optional[Image.Image], Optional[str]]:
        """Load as PIL RGB image."""
        arr, err = self.load(path)
        if err:
            return None, err
        try:
            import cv2
            rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
            return Image.fromarray(rgb), None
        except Exception as e:
            return None, str(e)

    def load_batch(
        self, paths: List[str]
    ) -> Tuple[List[np.ndarray], List[Optional[str]]]:
        images, errors = [], []
        for p in paths:
            img, err = self.load(p)
            images.append(img)
            errors.append(err)
        return images, errors


class Preprocessor:
    """Image preprocessing: resize, normalise, augment."""

    def __init__(
        self,
        target_size: Optional[Tuple[int, int]] = None,
        normalize: bool = True,
    ) -> None:
        self.target_size = target_size
        self.normalize = normalize

    def process(self, image: np.ndarray) -> np.ndarray:
        try:
            import cv2
            if self.target_size:
                image = cv2.resize(image, self.target_size, interpolation=cv2.INTER_LANCZOS4)
            if self.normalize:
                image = image.astype(np.float32) / 255.0
            return image
        except Exception:
            return image

    def process_batch(self, images: List[np.ndarray]) -> List[np.ndarray]:
        return [self.process(img) for img in images if img is not None]

    def crop_patches(
        self, image: np.ndarray, patch_size: int = 96, n_patches: int = 10
    ) -> List[np.ndarray]:
        """Extract random patches for BRISQUE patch-based scoring."""
        h, w = image.shape[:2]
        if h < patch_size or w < patch_size:
            return [image]
        patches = []
        rng = np.random.RandomState(42)
        for _ in range(n_patches):
            y = rng.randint(0, h - patch_size)
            x = rng.randint(0, w - patch_size)
            patches.append(image[y:y + patch_size, x:x + patch_size])
        return patches


class ScoreAggregator:
    """Aggregates multi-patch or multi-model scores into a single quality value."""

    def aggregate_patches(
        self, scores: List[float], method: str = "mean"
    ) -> float:
        if not scores:
            return 0.0
        arr = np.array(scores, dtype=float)
        if method == "mean":
            return float(arr.mean())
        elif method == "median":
            return float(np.median(arr))
        elif method == "min":
            return float(arr.min())
        elif method == "max":
            return float(arr.max())
        elif method == "trimmed_mean":
            # Remove top/bottom 10%
            lo = np.percentile(arr, 10)
            hi = np.percentile(arr, 90)
            trimmed = arr[(arr >= lo) & (arr <= hi)]
            return float(trimmed.mean()) if len(trimmed) > 0 else float(arr.mean())
        return float(arr.mean())

    def combine_scores(
        self,
        brisque_quality: float,
        nima_score: float,
        brisque_weight: float = 0.5,
        nima_weight: float = 0.5,
    ) -> float:
        return float(
            np.clip(brisque_quality * brisque_weight + nima_score * nima_weight, 0.0, 1.0)
        )

    def rank_images(
        self, scores: Dict[str, float], descending: bool = True
    ) -> List[Tuple[str, float]]:
        return sorted(scores.items(), key=lambda x: x[1], reverse=descending)


class QualityThresholds:
    """Quality gate thresholds and classification."""

    def __init__(
        self,
        brisque_reject_above: float = 0.6,
        nima_reject_below: float = 0.35,
        combined_reject_below: float = 0.30,
    ) -> None:
        self.brisque_reject_above = brisque_reject_above
        self.nima_reject_below = nima_reject_below
        self.combined_reject_below = combined_reject_below

    def classify(
        self,
        brisque_quality: float,
        nima_score: float,
        combined: float,
    ) -> str:
        """Returns: 'excellent' | 'good' | 'acceptable' | 'poor' | 'reject'"""
        if combined < self.combined_reject_below:
            return "reject"
        if combined >= 0.80:
            return "excellent"
        if combined >= 0.65:
            return "good"
        if combined >= 0.45:
            return "acceptable"
        return "poor"

    def should_reject(
        self,
        brisque_quality: float,
        nima_score: float,
    ) -> Tuple[bool, List[str]]:
        reasons = []
        if brisque_quality < (1.0 - self.brisque_reject_above):
            reasons.append(f"BRISQUE quality {brisque_quality:.3f} below threshold")
        if nima_score < self.nima_reject_below:
            reasons.append(f"NIMA score {nima_score:.3f} below threshold {self.nima_reject_below}")
        return len(reasons) > 0, reasons


class AssessmentPipeline:
    """
    End-to-end quality assessment pipeline:
    Load → Preprocess → BRISQUE → NIMA → Aggregate → Classify
    """

    def __init__(
        self,
        loader: Optional[ImageLoader] = None,
        preprocessor: Optional[Preprocessor] = None,
        aggregator: Optional[ScoreAggregator] = None,
        thresholds: Optional[QualityThresholds] = None,
        n_patches: int = 10,
    ) -> None:
        self.loader = loader or ImageLoader()
        self.preprocessor = preprocessor or Preprocessor()
        self.aggregator = aggregator or ScoreAggregator()
        self.thresholds = thresholds or QualityThresholds()
        self.n_patches = n_patches

    def assess_path(self, path: str) -> Dict[str, Any]:
        img, err = self.loader.load(path)
        if err:
            return {"path": path, "error": err, "passed": False}
        return self._assess_array(img, path)

    def assess_batch(self, paths: List[str]) -> List[Dict[str, Any]]:
        return [self.assess_path(p) for p in paths]

    def assess_pil(self, image: Image.Image, name: str = "image") -> Dict[str, Any]:
        try:
            import cv2
            arr = np.array(image.convert("RGB"))
            bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
            return self._assess_array(bgr, name)
        except Exception as e:
            return {"path": name, "error": str(e), "passed": False}

    def _assess_array(self, image: np.ndarray, name: str) -> Dict[str, Any]:
        try:
            import pyiqa
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"

            brisque_model = pyiqa.create_metric("brisque", device=device)
            nima_model = pyiqa.create_metric("nima", device=device)

            import cv2
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(rgb)

            import torchvision.transforms as T
            tensor = T.ToTensor()(pil_img).unsqueeze(0).to(device)

            with torch.no_grad():
                brisque_raw = float(brisque_model(tensor).item())
                nima_raw = float(nima_model(tensor).item())

            # Normalise BRISQUE: lower raw = better quality; typical range 0..100
            brisque_quality = float(np.clip(1.0 - brisque_raw / 100.0, 0.0, 1.0))
            nima_score = float(np.clip((nima_raw - 1.0) / 9.0, 0.0, 1.0))
            combined = self.aggregator.combine_scores(brisque_quality, nima_score)
            grade = self.thresholds.classify(brisque_quality, nima_score, combined)
            rejected, reasons = self.thresholds.should_reject(brisque_quality, nima_score)

            return {
                "path": name,
                "brisque_raw": round(brisque_raw, 4),
                "brisque_quality": round(brisque_quality, 4),
                "nima_raw": round(nima_raw, 4),
                "nima_score": round(nima_score, 4),
                "combined_score": round(combined, 4),
                "grade": grade,
                "passed": not rejected,
                "reject_reasons": reasons,
                "error": None,
            }
        except Exception as e:
            return {"path": name, "error": str(e), "passed": False}

    def build_report(self, results: List[Dict[str, Any]]) -> PipelineReport:
        successful = [r for r in results if r.get("error") is None]
        failed = [r for r in results if r.get("error") is not None]

        brisque_vals = [r["brisque_quality"] for r in successful if "brisque_quality" in r]
        nima_vals = [r["nima_score"] for r in successful if "nima_score" in r]

        percentiles: Dict[str, float] = {}
        if brisque_vals:
            for p in (10, 25, 50, 75, 90):
                percentiles[f"brisque_p{p}"] = float(np.percentile(brisque_vals, p))
        if nima_vals:
            for p in (10, 25, 50, 75, 90):
                percentiles[f"nima_p{p}"] = float(np.percentile(nima_vals, p))

        return PipelineReport(
            total_images=len(results),
            successful=len(successful),
            failed=len(failed),
            mean_brisque=float(np.mean(brisque_vals)) if brisque_vals else 0.0,
            mean_nima=float(np.mean(nima_vals)) if nima_vals else 0.0,
            percentiles=percentiles,
        )
