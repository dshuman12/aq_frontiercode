"""Lightweight model training utilities for image quality regression."""
from __future__ import annotations

import math
import json
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np


@dataclass
class TrainConfig:
    learning_rate: float = 0.001
    epochs: int = 50
    batch_size: int = 32
    val_fraction: float = 0.2
    early_stopping_patience: int = 5
    weight_decay: float = 1e-4
    momentum: float = 0.9
    optimizer: str = "adam"  # "sgd" | "adam" | "rmsprop"
    loss: str = "mse"  # "mse" | "mae" | "huber"
    seed: int = 42
    verbose: bool = False


@dataclass
class EpochLog:
    epoch: int
    train_loss: float
    val_loss: Optional[float]
    lr: float
    grad_norm: float = 0.0


@dataclass
class TrainResult:
    best_val_loss: float
    best_epoch: int
    total_epochs: int
    history: List[EpochLog] = field(default_factory=list)
    final_weights: Optional[List[np.ndarray]] = field(default=None, repr=False)


class LinearLayer:
    """A single fully-connected linear layer with optional bias."""

    def __init__(self, in_features: int, out_features: int, bias: bool = True, seed: int = 0) -> None:
        rng = np.random.default_rng(seed)
        scale = math.sqrt(2.0 / in_features)
        self.W = rng.normal(0.0, scale, (in_features, out_features)).astype(np.float32)
        self.b = np.zeros(out_features, dtype=np.float32) if bias else None
        self.dW: Optional[np.ndarray] = None
        self.db: Optional[np.ndarray] = None
        self._last_input: Optional[np.ndarray] = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        self._last_input = x
        out = x @ self.W
        if self.b is not None:
            out = out + self.b
        return out

    def backward(self, grad_out: np.ndarray) -> np.ndarray:
        if self._last_input is None:
            raise RuntimeError("forward() must be called before backward()")
        self.dW = self._last_input.T @ grad_out
        if self.b is not None:
            self.db = grad_out.sum(axis=0)
        return grad_out @ self.W.T

    def parameters(self) -> List[np.ndarray]:
        if self.b is not None:
            return [self.W, self.b]
        return [self.W]

    def gradients(self) -> List[Optional[np.ndarray]]:
        if self.b is not None:
            return [self.dW, self.db]
        return [self.dW]


class ReLULayer:
    def __init__(self) -> None:
        self._mask: Optional[np.ndarray] = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        self._mask = x > 0
        return x * self._mask

    def backward(self, grad_out: np.ndarray) -> np.ndarray:
        if self._mask is None:
            raise RuntimeError("forward() must be called before backward()")
        return grad_out * self._mask


class BatchNormLayer:
    """Simplified 1-D batch normalization."""

    def __init__(self, features: int, eps: float = 1e-5, momentum: float = 0.1) -> None:
        self.gamma = np.ones(features, dtype=np.float32)
        self.beta = np.zeros(features, dtype=np.float32)
        self.running_mean = np.zeros(features, dtype=np.float32)
        self.running_var = np.ones(features, dtype=np.float32)
        self.eps = eps
        self.momentum = momentum
        self._cache: Optional[Tuple] = None
        self.dgamma: Optional[np.ndarray] = None
        self.dbeta: Optional[np.ndarray] = None
        self.training = True

    def forward(self, x: np.ndarray) -> np.ndarray:
        if self.training:
            mean = x.mean(axis=0)
            var = x.var(axis=0)
            x_norm = (x - mean) / np.sqrt(var + self.eps)
            self._cache = (x, x_norm, mean, var)
            self.running_mean = (1 - self.momentum) * self.running_mean + self.momentum * mean
            self.running_var = (1 - self.momentum) * self.running_var + self.momentum * var
        else:
            x_norm = (x - self.running_mean) / np.sqrt(self.running_var + self.eps)
        return self.gamma * x_norm + self.beta

    def backward(self, grad_out: np.ndarray) -> np.ndarray:
        if self._cache is None:
            raise RuntimeError("forward() must be called before backward()")
        x, x_norm, mean, var = self._cache
        n = x.shape[0]
        self.dgamma = (grad_out * x_norm).sum(axis=0)
        self.dbeta = grad_out.sum(axis=0)
        dx_norm = grad_out * self.gamma
        std_inv = 1.0 / np.sqrt(var + self.eps)
        dx = (dx_norm - dx_norm.mean(axis=0) - x_norm * (dx_norm * x_norm).mean(axis=0)) * std_inv
        return dx

    def parameters(self) -> List[np.ndarray]:
        return [self.gamma, self.beta]

    def gradients(self) -> List[Optional[np.ndarray]]:
        return [self.dgamma, self.dbeta]


class DropoutLayer:
    def __init__(self, p: float = 0.5, seed: int = 0) -> None:
        self.p = p
        self._rng = np.random.default_rng(seed)
        self._mask: Optional[np.ndarray] = None
        self.training = True

    def forward(self, x: np.ndarray) -> np.ndarray:
        if not self.training or self.p == 0.0:
            return x
        self._mask = (self._rng.random(x.shape) > self.p).astype(np.float32) / (1.0 - self.p)
        return x * self._mask

    def backward(self, grad_out: np.ndarray) -> np.ndarray:
        if not self.training or self._mask is None:
            return grad_out
        return grad_out * self._mask


class MSELoss:
    def __init__(self) -> None:
        self._cache: Optional[Tuple] = None

    def forward(self, predictions: np.ndarray, targets: np.ndarray) -> float:
        diff = predictions - targets
        self._cache = diff
        return float(np.mean(diff ** 2))

    def backward(self) -> np.ndarray:
        if self._cache is None:
            raise RuntimeError("forward() must be called before backward()")
        n = self._cache.shape[0]
        return 2.0 * self._cache / n


class MAELoss:
    def __init__(self) -> None:
        self._cache: Optional[Tuple] = None

    def forward(self, predictions: np.ndarray, targets: np.ndarray) -> float:
        diff = predictions - targets
        self._cache = diff
        return float(np.mean(np.abs(diff)))

    def backward(self) -> np.ndarray:
        if self._cache is None:
            raise RuntimeError("forward() must be called before backward()")
        n = self._cache.shape[0]
        return np.sign(self._cache) / n


class HuberLoss:
    def __init__(self, delta: float = 1.0) -> None:
        self.delta = delta
        self._cache: Optional[Tuple] = None

    def forward(self, predictions: np.ndarray, targets: np.ndarray) -> float:
        diff = predictions - targets
        abs_diff = np.abs(diff)
        loss = np.where(
            abs_diff <= self.delta,
            0.5 * diff ** 2,
            self.delta * (abs_diff - 0.5 * self.delta)
        )
        self._cache = diff
        return float(np.mean(loss))

    def backward(self) -> np.ndarray:
        if self._cache is None:
            raise RuntimeError("forward() must be called before backward()")
        diff = self._cache
        n = diff.shape[0]
        grad = np.where(np.abs(diff) <= self.delta, diff, self.delta * np.sign(diff))
        return grad / n


class AdamOptimizer:
    """Adam optimizer with optional weight decay (AdamW)."""

    def __init__(
        self,
        parameters: List[np.ndarray],
        lr: float = 0.001,
        betas: Tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.0,
    ) -> None:
        self.params = parameters
        self.lr = lr
        self.betas = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.m = [np.zeros_like(p) for p in parameters]
        self.v = [np.zeros_like(p) for p in parameters]
        self.t = 0

    def step(self, gradients: List[Optional[np.ndarray]]) -> float:
        self.t += 1
        b1, b2 = self.betas
        grad_norm = 0.0

        for i, (param, grad) in enumerate(zip(self.params, gradients)):
            if grad is None:
                continue
            grad_norm += float(np.sum(grad ** 2))

            if self.weight_decay > 0:
                grad = grad + self.weight_decay * param

            self.m[i] = b1 * self.m[i] + (1 - b1) * grad
            self.v[i] = b2 * self.v[i] + (1 - b2) * grad ** 2

            m_hat = self.m[i] / (1 - b1 ** self.t)
            v_hat = self.v[i] / (1 - b2 ** self.t)
            param -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

        return math.sqrt(grad_norm)


class SGDOptimizer:
    def __init__(
        self,
        parameters: List[np.ndarray],
        lr: float = 0.01,
        momentum: float = 0.9,
        weight_decay: float = 0.0,
    ) -> None:
        self.params = parameters
        self.lr = lr
        self.momentum = momentum
        self.weight_decay = weight_decay
        self.velocity = [np.zeros_like(p) for p in parameters]

    def step(self, gradients: List[Optional[np.ndarray]]) -> float:
        grad_norm = 0.0
        for i, (param, grad) in enumerate(zip(self.params, gradients)):
            if grad is None:
                continue
            if self.weight_decay > 0:
                grad = grad + self.weight_decay * param
            grad_norm += float(np.sum(grad ** 2))
            self.velocity[i] = self.momentum * self.velocity[i] + grad
            param -= self.lr * self.velocity[i]
        return math.sqrt(grad_norm)


class QualityMLP:
    """Multi-layer perceptron for image quality score regression."""

    def __init__(
        self,
        input_dim: int,
        hidden_dims: List[int] = None,
        dropout: float = 0.0,
        use_batchnorm: bool = False,
        seed: int = 42,
    ) -> None:
        hidden_dims = hidden_dims or [256, 128, 64]
        self.layers: List[Any] = []
        dims = [input_dim] + hidden_dims + [1]

        for i in range(len(dims) - 1):
            self.layers.append(LinearLayer(dims[i], dims[i + 1], seed=seed + i))
            if i < len(dims) - 2:
                if use_batchnorm:
                    self.layers.append(BatchNormLayer(dims[i + 1]))
                self.layers.append(ReLULayer())
                if dropout > 0:
                    self.layers.append(DropoutLayer(dropout, seed=seed + i + 100))

    def forward(self, x: np.ndarray) -> np.ndarray:
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def backward(self, grad: np.ndarray) -> np.ndarray:
        for layer in reversed(self.layers):
            if hasattr(layer, "backward"):
                grad = layer.backward(grad)
        return grad

    def parameters(self) -> List[np.ndarray]:
        params = []
        for layer in self.layers:
            if hasattr(layer, "parameters"):
                params.extend(layer.parameters())
        return params

    def gradients(self) -> List[Optional[np.ndarray]]:
        grads = []
        for layer in self.layers:
            if hasattr(layer, "gradients"):
                grads.extend(layer.gradients())
        return grads

    def train_mode(self) -> None:
        for layer in self.layers:
            if hasattr(layer, "training"):
                layer.training = True

    def eval_mode(self) -> None:
        for layer in self.layers:
            if hasattr(layer, "training"):
                layer.training = False

    def predict(self, x: np.ndarray) -> np.ndarray:
        self.eval_mode()
        out = self.forward(x)
        self.train_mode()
        return out.ravel()


def _build_loss(name: str):
    if name == "mse":
        return MSELoss()
    if name == "mae":
        return MAELoss()
    if name == "huber":
        return HuberLoss()
    raise ValueError(f"Unknown loss: {name}")


def _build_optimizer(name: str, params: List[np.ndarray], config: TrainConfig):
    if name == "adam":
        return AdamOptimizer(params, lr=config.learning_rate, weight_decay=config.weight_decay)
    if name == "sgd":
        return SGDOptimizer(params, lr=config.learning_rate, momentum=config.momentum,
                            weight_decay=config.weight_decay)
    raise ValueError(f"Unknown optimizer: {name}")


def train(
    model: QualityMLP,
    X_train: np.ndarray,
    y_train: np.ndarray,
    config: Optional[TrainConfig] = None,
    X_val: Optional[np.ndarray] = None,
    y_val: Optional[np.ndarray] = None,
) -> TrainResult:
    config = config or TrainConfig()
    rng = np.random.default_rng(config.seed)
    loss_fn = _build_loss(config.loss)
    optimizer = _build_optimizer(config.optimizer, model.parameters(), config)

    n = len(X_train)
    best_val_loss = float("inf")
    best_epoch = 0
    patience_counter = 0
    history: List[EpochLog] = []

    for epoch in range(config.epochs):
        model.train_mode()
        perm = rng.permutation(n)
        X_shuffled = X_train[perm]
        y_shuffled = y_train[perm]

        epoch_loss = 0.0
        n_batches = 0

        for start in range(0, n, config.batch_size):
            xb = X_shuffled[start: start + config.batch_size]
            yb = y_shuffled[start: start + config.batch_size].reshape(-1, 1)

            preds = model.forward(xb)
            batch_loss = loss_fn.forward(preds, yb)
            epoch_loss += batch_loss
            n_batches += 1

            grad_output = loss_fn.backward()
            model.backward(grad_output)
            grad_norm = optimizer.step(model.gradients())

        train_loss = epoch_loss / max(n_batches, 1)

        val_loss: Optional[float] = None
        if X_val is not None and y_val is not None:
            model.eval_mode()
            val_preds = model.forward(X_val)
            val_loss = loss_fn.forward(val_preds, y_val.reshape(-1, 1))
            model.train_mode()

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_epoch = epoch
                patience_counter = 0
            else:
                patience_counter += 1

            if config.early_stopping_patience > 0 and patience_counter >= config.early_stopping_patience:
                if config.verbose:
                    print(f"Early stopping at epoch {epoch}")
                break

        log = EpochLog(
            epoch=epoch,
            train_loss=train_loss,
            val_loss=val_loss,
            lr=config.learning_rate,
            grad_norm=grad_norm,
        )
        history.append(log)

        if config.verbose and epoch % 10 == 0:
            msg = f"Epoch {epoch}: train_loss={train_loss:.4f}"
            if val_loss is not None:
                msg += f", val_loss={val_loss:.4f}"
            print(msg)

    return TrainResult(
        best_val_loss=best_val_loss,
        best_epoch=best_epoch,
        total_epochs=len(history),
        history=history,
        final_weights=model.parameters(),
    )


def evaluate(
    model: QualityMLP,
    X: np.ndarray,
    y: np.ndarray,
) -> Dict[str, float]:
    preds = model.predict(X)
    targets = y.ravel()
    mse = float(np.mean((preds - targets) ** 2))
    mae = float(np.mean(np.abs(preds - targets)))
    rmse = math.sqrt(mse)
    residuals = preds - targets
    ss_res = np.sum(residuals ** 2)
    ss_tot = np.sum((targets - targets.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    plcc = float(np.corrcoef(preds, targets)[0, 1]) if len(preds) > 1 else 0.0

    return {"mse": mse, "mae": mae, "rmse": rmse, "r2": r2, "plcc": plcc}


class CrossValidator:
    """K-fold cross validation for QualityMLP."""

    def __init__(self, k: int = 5, config: Optional[TrainConfig] = None) -> None:
        self.k = k
        self.config = config or TrainConfig()

    def run(
        self,
        X: np.ndarray,
        y: np.ndarray,
        input_dim: int,
        hidden_dims: Optional[List[int]] = None,
    ) -> Dict[str, Any]:
        n = len(X)
        fold_size = n // self.k
        rng = np.random.default_rng(self.config.seed)
        perm = rng.permutation(n)

        fold_results = []
        for fold in range(self.k):
            val_idx = perm[fold * fold_size: (fold + 1) * fold_size]
            train_idx = np.concatenate([perm[: fold * fold_size], perm[(fold + 1) * fold_size :]])

            X_train, y_train = X[train_idx], y[train_idx]
            X_val, y_val = X[val_idx], y[val_idx]

            model = QualityMLP(input_dim, hidden_dims, seed=self.config.seed + fold)
            train(model, X_train, y_train, self.config, X_val, y_val)
            metrics = evaluate(model, X_val, y_val)
            fold_results.append(metrics)

        agg: Dict[str, Any] = {}
        for key in fold_results[0]:
            vals = [r[key] for r in fold_results]
            agg[key] = {"mean": float(np.mean(vals)), "std": float(np.std(vals)), "folds": vals}
        return agg


class FeatureScaler:
    """Zero-mean / unit-variance normalization with per-feature stats."""

    def __init__(self) -> None:
        self.mean_: Optional[np.ndarray] = None
        self.std_: Optional[np.ndarray] = None
        self.fitted = False

    def fit(self, X: np.ndarray) -> "FeatureScaler":
        self.mean_ = X.mean(axis=0)
        self.std_ = X.std(axis=0)
        self.std_[self.std_ < 1e-8] = 1.0
        self.fitted = True
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("fit() must be called before transform()")
        return (X - self.mean_) / self.std_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)

    def inverse_transform(self, X: np.ndarray) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("fit() must be called before inverse_transform()")
        return X * self.std_ + self.mean_

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mean": self.mean_.tolist() if self.mean_ is not None else None,
            "std": self.std_.tolist() if self.std_ is not None else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FeatureScaler":
        scaler = cls()
        if data.get("mean") is not None:
            scaler.mean_ = np.array(data["mean"], dtype=np.float32)
            scaler.std_ = np.array(data["std"], dtype=np.float32)
            scaler.fitted = True
        return scaler
