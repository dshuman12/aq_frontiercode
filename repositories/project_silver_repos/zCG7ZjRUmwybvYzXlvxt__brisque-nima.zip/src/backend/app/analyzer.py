#!/usr/bin/env python3
"""
BRISQUE + NIMA analyzer (standalone, fast and minimal)
- BRISQUE: No-reference image quality (lower is worse; we normalize to 0..1 quality)
- NIMA: Aesthetic score (0..1 normalized)

This module uses PyIQA models and standard OpenCV decoding.
"""
from __future__ import annotations

import os
import cv2
import torch
import pyiqa
from dataclasses import dataclass
from typing import Dict, Any, List


@dataclass
class Scores:
    brisque_score: float         # native BRISQUE magnitude (lower better)
    brisque_quality: float       # normalized 0..1 quality (higher better)
    nima_aesthetic: float        # normalized 0..1 aesthetic score


class BrisqueNimaAnalyzer:
    def __init__(self, device: str | None = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        # Limit threads to avoid oversubscription when running many workers
        try:
            cv2.setNumThreads(1)
        except Exception:
            pass
        try:
            torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
        except Exception:
            pass
        # Load PyIQA metrics
        # brisque returns a scalar score; nima returns aesthetic score
        self._brisque = pyiqa.create_metric('brisque', device=self.device)
        # Common NIMA backbones in pyiqa: 'nima' alias uses pretrained weights
        self._nima = pyiqa.create_metric('nima', device=self.device)
        # batching knob
        try:
            self.batch_size = max(1, int(os.getenv("BATCH_SIZE", "16")))
        except Exception:
            self.batch_size = 16

    @staticmethod
    def _read_bgr(path: str):
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            # Retry with any flag in case of format quirks
            img = cv2.imread(path)
        if img is None:
            raise ValueError(f"Could not read image: {path}")
        return img

    @staticmethod
    def _normalize_brisque(brisque_val: float) -> float:
        """Convert BRISQUE magnitude to 0..1 quality (higher better).
        Typical BRISQUE ranges from ~0 to 100+. We'll clamp to [0,100] then map to quality=1 - v/100.
        """
        v = max(0.0, min(100.0, float(brisque_val)))
        return max(0.0, min(1.0, 1.0 - (v / 100.0)))

    def score_one(self, path: str) -> Scores:
        # OpenCV -> RGB tensor for pyiqa
        bgr = self._read_bgr(path)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        # PyIQA expects CHW float tensor in [0,1]
        x = torch.from_numpy(rgb).permute(2, 0, 1).float() / 255.0
        x = x.unsqueeze(0).to(self.device)
        with torch.inference_mode():
            brisque_val = float(self._brisque(x).detach().cpu().item())
            nima_val = float(self._nima(x).detach().cpu().item())
        return Scores(
            brisque_score=brisque_val,
            brisque_quality=self._normalize_brisque(brisque_val),
            nima_aesthetic=max(0.0, min(1.0, nima_val)),
        )

    def score_batch(self, items: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        """Robust scoring for variable-sized images (preserve fidelity).
        Processes images individually to match per-image semantics exactly.
        """
        out: List[Dict[str, Any]] = []
        for it in items:
            p = it['path']
            sid = it.get('id') or os.path.basename(p)
            s = self.score_one(p)
            out.append({
                'photo_id': sid,
                'file_path': p,
                'brisque_score': s.brisque_score,
                'brisque_quality': s.brisque_quality,
                'nima_aesthetic': s.nima_aesthetic,
            })
        return out

# refactor config to use env vars

# add model warmup on startup

# fix import paths
