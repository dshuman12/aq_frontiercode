"""Image augmentation and preprocessing utilities for quality assessment pipelines."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


@dataclass
class AugmentConfig:
    brightness_range: Tuple[float, float] = (0.7, 1.3)
    contrast_range: Tuple[float, float] = (0.7, 1.3)
    saturation_range: Tuple[float, float] = (0.8, 1.2)
    noise_std_range: Tuple[float, float] = (0.0, 0.05)
    blur_radius_range: Tuple[float, float] = (0.0, 2.0)
    rotation_range: Tuple[float, float] = (-15.0, 15.0)
    flip_horizontal: bool = True
    flip_vertical: bool = False
    crop_scale_range: Tuple[float, float] = (0.8, 1.0)
    jpeg_quality_range: Tuple[int, int] = (60, 100)
    seed: Optional[int] = None


@dataclass
class AugmentResult:
    original_shape: Tuple[int, ...]
    augmented_shape: Tuple[int, ...]
    applied: List[str] = field(default_factory=list)
    params: Dict[str, Any] = field(default_factory=dict)


class ImageAugmenter:
    """Apply random augmentations to simulate real-world image quality variations."""

    def __init__(self, config: Optional[AugmentConfig] = None) -> None:
        self.config = config or AugmentConfig()
        self._rng = random.Random(config.seed if config else None)
        self._np_rng = np.random.default_rng(config.seed if config else None)

    def augment(self, image: np.ndarray, p: float = 0.5) -> Tuple[np.ndarray, AugmentResult]:
        result = AugmentResult(
            original_shape=image.shape,
            augmented_shape=image.shape,
        )
        img = image.astype(np.float32)

        if self._rng.random() < p:
            img, applied = self._adjust_brightness(img)
            if applied:
                result.applied.append("brightness")

        if self._rng.random() < p:
            img, applied = self._adjust_contrast(img)
            if applied:
                result.applied.append("contrast")

        if self._rng.random() < p and img.ndim == 3 and img.shape[2] >= 3:
            img, applied = self._adjust_saturation(img)
            if applied:
                result.applied.append("saturation")

        if self._rng.random() < p:
            img = self._add_gaussian_noise(img)
            result.applied.append("gaussian_noise")

        if self._rng.random() < p:
            img = self._apply_blur(img)
            result.applied.append("blur")

        if self.config.flip_horizontal and self._rng.random() < p:
            img = img[:, ::-1].copy()
            result.applied.append("flip_horizontal")

        if self.config.flip_vertical and self._rng.random() < p:
            img = img[::-1, :].copy()
            result.applied.append("flip_vertical")

        img = np.clip(img, 0.0, 255.0)
        result.augmented_shape = img.shape
        return img.astype(np.uint8), result

    def _adjust_brightness(self, img: np.ndarray) -> Tuple[np.ndarray, bool]:
        factor = self._rng.uniform(*self.config.brightness_range)
        if abs(factor - 1.0) < 0.01:
            return img, False
        return img * factor, True

    def _adjust_contrast(self, img: np.ndarray) -> Tuple[np.ndarray, bool]:
        factor = self._rng.uniform(*self.config.contrast_range)
        if abs(factor - 1.0) < 0.01:
            return img, False
        mean = img.mean()
        return (img - mean) * factor + mean, True

    def _adjust_saturation(self, img: np.ndarray) -> Tuple[np.ndarray, bool]:
        factor = self._rng.uniform(*self.config.saturation_range)
        if abs(factor - 1.0) < 0.01:
            return img, False
        gray = 0.299 * img[:, :, 0] + 0.587 * img[:, :, 1] + 0.114 * img[:, :, 2]
        gray = gray[:, :, np.newaxis]
        return gray + factor * (img - gray), True

    def _add_gaussian_noise(self, img: np.ndarray) -> np.ndarray:
        std = self._rng.uniform(*self.config.noise_std_range) * 255.0
        if std < 0.5:
            return img
        noise = self._np_rng.normal(0.0, std, img.shape).astype(np.float32)
        return img + noise

    def _apply_blur(self, img: np.ndarray) -> np.ndarray:
        radius = self._rng.uniform(*self.config.blur_radius_range)
        if radius < 0.1:
            return img
        kernel_size = max(1, int(radius * 2 + 1))
        if kernel_size % 2 == 0:
            kernel_size += 1
        return _gaussian_blur_numpy(img, kernel_size, radius)


def _gaussian_blur_numpy(img: np.ndarray, kernel_size: int, sigma: float) -> np.ndarray:
    """Pure-NumPy separable Gaussian blur."""
    k = _gaussian_kernel_1d(kernel_size, sigma)
    if img.ndim == 2:
        out = _convolve_1d(img, k, axis=0)
        out = _convolve_1d(out, k, axis=1)
    else:
        channels = []
        for c in range(img.shape[2]):
            ch = _convolve_1d(img[:, :, c], k, axis=0)
            ch = _convolve_1d(ch, k, axis=1)
            channels.append(ch)
        out = np.stack(channels, axis=2)
    return out


def _gaussian_kernel_1d(size: int, sigma: float) -> np.ndarray:
    half = size // 2
    x = np.arange(-half, half + 1, dtype=np.float32)
    kernel = np.exp(-0.5 * (x / sigma) ** 2)
    return kernel / kernel.sum()


def _convolve_1d(arr: np.ndarray, kernel: np.ndarray, axis: int) -> np.ndarray:
    pad = len(kernel) // 2
    if axis == 0:
        padded = np.pad(arr, ((pad, pad), (0, 0)), mode="reflect")
        out = np.zeros_like(arr, dtype=np.float32)
        for i, w in enumerate(kernel):
            out += padded[i: i + arr.shape[0], :] * w
    else:
        padded = np.pad(arr, ((0, 0), (pad, pad)), mode="reflect")
        out = np.zeros_like(arr, dtype=np.float32)
        for i, w in enumerate(kernel):
            out += padded[:, i: i + arr.shape[1]] * w
    return out


class JpegSimulator:
    """Simulate JPEG compression artifacts using DCT block processing."""

    def __init__(self, quality: int = 75) -> None:
        self.quality = max(1, min(100, quality))
        self._qtable = self._build_quantization_table(quality)

    def _build_quantization_table(self, quality: int) -> np.ndarray:
        base = np.array([
            [16, 11, 10, 16, 24, 40, 51, 61],
            [12, 12, 14, 19, 26, 58, 60, 55],
            [14, 13, 16, 24, 40, 57, 69, 56],
            [14, 17, 22, 29, 51, 87, 80, 62],
            [18, 22, 37, 56, 68, 109, 103, 77],
            [24, 35, 55, 64, 81, 104, 113, 92],
            [49, 64, 78, 87, 103, 121, 120, 101],
            [72, 92, 95, 98, 112, 100, 103, 99],
        ], dtype=np.float32)

        if quality < 50:
            scale = 5000.0 / quality
        else:
            scale = 200.0 - 2.0 * quality

        table = np.floor((base * scale + 50) / 100)
        return np.clip(table, 1, 255)

    def compress(self, image: np.ndarray) -> np.ndarray:
        """Apply DCT-quantize-dequantize-IDCT cycle per 8x8 block."""
        if image.ndim == 3:
            channels = [self._compress_channel(image[:, :, c]) for c in range(image.shape[2])]
            return np.stack(channels, axis=2)
        return self._compress_channel(image)

    def _compress_channel(self, channel: np.ndarray) -> np.ndarray:
        h, w = channel.shape
        out = np.zeros_like(channel, dtype=np.float32)
        img = channel.astype(np.float32) - 128.0

        for y in range(0, h - 7, 8):
            for x in range(0, w - 7, 8):
                block = img[y: y + 8, x: x + 8]
                dct_block = _dct2d_8x8(block)
                quantized = np.round(dct_block / self._qtable)
                dequantized = quantized * self._qtable
                idct_block = _idct2d_8x8(dequantized)
                out[y: y + 8, x: x + 8] = idct_block + 128.0

        return np.clip(out, 0, 255).astype(np.uint8)


def _dct2d_8x8(block: np.ndarray) -> np.ndarray:
    """2-D DCT-II for an 8×8 block, pure NumPy."""
    n = 8
    result = np.zeros((n, n), dtype=np.float64)
    for u in range(n):
        for v in range(n):
            cu = (1.0 / math.sqrt(2)) if u == 0 else 1.0
            cv = (1.0 / math.sqrt(2)) if v == 0 else 1.0
            s = 0.0
            for x in range(n):
                for y in range(n):
                    s += (block[x, y] *
                          math.cos(math.pi * u * (2 * x + 1) / 16) *
                          math.cos(math.pi * v * (2 * y + 1) / 16))
            result[u, v] = 0.25 * cu * cv * s
    return result


def _idct2d_8x8(block: np.ndarray) -> np.ndarray:
    n = 8
    result = np.zeros((n, n), dtype=np.float64)
    for x in range(n):
        for y in range(n):
            s = 0.0
            for u in range(n):
                for v in range(n):
                    cu = (1.0 / math.sqrt(2)) if u == 0 else 1.0
                    cv = (1.0 / math.sqrt(2)) if v == 0 else 1.0
                    s += (cu * cv * block[u, v] *
                          math.cos(math.pi * u * (2 * x + 1) / 16) *
                          math.cos(math.pi * v * (2 * y + 1) / 16))
            result[x, y] = 0.25 * s
    return result


class ResizeOp:
    """Resize images using bilinear or nearest-neighbor interpolation."""

    def __init__(self, method: str = "bilinear") -> None:
        if method not in ("bilinear", "nearest"):
            raise ValueError(f"Unknown resize method: {method}")
        self.method = method

    def resize(self, image: np.ndarray, target_h: int, target_w: int) -> np.ndarray:
        h, w = image.shape[:2]
        if h == target_h and w == target_w:
            return image

        if self.method == "nearest":
            return self._nearest(image, target_h, target_w)
        return self._bilinear(image, target_h, target_w)

    def _nearest(self, img: np.ndarray, th: int, tw: int) -> np.ndarray:
        h, w = img.shape[:2]
        row_idx = (np.arange(th) * h / th).astype(int)
        col_idx = (np.arange(tw) * w / tw).astype(int)
        return img[np.ix_(row_idx, col_idx)]

    def _bilinear(self, img: np.ndarray, th: int, tw: int) -> np.ndarray:
        h, w = img.shape[:2]
        row_f = np.linspace(0, h - 1, th)
        col_f = np.linspace(0, w - 1, tw)
        r0 = np.floor(row_f).astype(int)
        r1 = np.minimum(r0 + 1, h - 1)
        c0 = np.floor(col_f).astype(int)
        c1 = np.minimum(c0 + 1, w - 1)
        dr = (row_f - r0)[:, np.newaxis]
        dc = col_f - c0

        if img.ndim == 2:
            out = (
                img[r0][:, c0] * (1 - dr) * (1 - dc) +
                img[r1][:, c0] * dr * (1 - dc) +
                img[r0][:, c1] * (1 - dr) * dc +
                img[r1][:, c1] * dr * dc
            )
            return out.astype(img.dtype)

        channels = []
        for c in range(img.shape[2]):
            ch = img[:, :, c]
            out = (
                ch[r0][:, c0] * (1 - dr) * (1 - dc) +
                ch[r1][:, c0] * dr * (1 - dc) +
                ch[r0][:, c1] * (1 - dr) * dc +
                ch[r1][:, c1] * dr * dc
            )
            channels.append(out)
        return np.stack(channels, axis=2).astype(img.dtype)


class NormalizationPipeline:
    """Normalize image arrays to various standard ranges."""

    def __init__(self, mean: Optional[List[float]] = None, std: Optional[List[float]] = None) -> None:
        self.mean = np.array(mean or [0.485, 0.456, 0.406], dtype=np.float32)
        self.std = np.array(std or [0.229, 0.224, 0.225], dtype=np.float32)

    def normalize(self, image: np.ndarray) -> np.ndarray:
        """Normalize to [0,1] then apply mean/std subtraction."""
        img = image.astype(np.float32) / 255.0
        if img.ndim == 3 and img.shape[2] == len(self.mean):
            img = (img - self.mean) / self.std
        return img

    def denormalize(self, image: np.ndarray) -> np.ndarray:
        if image.ndim == 3 and image.shape[2] == len(self.mean):
            img = image * self.std + self.mean
        else:
            img = image.copy()
        return np.clip(img * 255.0, 0, 255).astype(np.uint8)

    @staticmethod
    def to_float(image: np.ndarray) -> np.ndarray:
        return image.astype(np.float32) / 255.0

    @staticmethod
    def to_uint8(image: np.ndarray) -> np.ndarray:
        return np.clip(image * 255.0, 0, 255).astype(np.uint8)

    @staticmethod
    def standardize_zero_mean(image: np.ndarray) -> np.ndarray:
        img = image.astype(np.float32)
        return (img - img.mean()) / (img.std() + 1e-8)


def center_crop(image: np.ndarray, crop_h: int, crop_w: int) -> np.ndarray:
    h, w = image.shape[:2]
    top = max(0, (h - crop_h) // 2)
    left = max(0, (w - crop_w) // 2)
    return image[top: top + crop_h, left: left + crop_w]


def random_crop(
    image: np.ndarray, crop_h: int, crop_w: int, rng: Optional[random.Random] = None
) -> Tuple[np.ndarray, Tuple[int, int]]:
    rng = rng or random.Random()
    h, w = image.shape[:2]
    top = rng.randint(0, max(0, h - crop_h))
    left = rng.randint(0, max(0, w - crop_w))
    return image[top: top + crop_h, left: left + crop_w], (top, left)


def five_crop(image: np.ndarray, crop_h: int, crop_w: int) -> List[np.ndarray]:
    h, w = image.shape[:2]
    crops = []
    positions = [
        (0, 0),
        (0, w - crop_w),
        (h - crop_h, 0),
        (h - crop_h, w - crop_w),
        ((h - crop_h) // 2, (w - crop_w) // 2),
    ]
    for top, left in positions:
        crops.append(image[top: top + crop_h, left: left + crop_w])
    return crops


def pad_to_square(image: np.ndarray, fill: int = 0) -> np.ndarray:
    h, w = image.shape[:2]
    size = max(h, w)
    pad_top = (size - h) // 2
    pad_bottom = size - h - pad_top
    pad_left = (size - w) // 2
    pad_right = size - w - pad_left

    if image.ndim == 2:
        return np.pad(image, ((pad_top, pad_bottom), (pad_left, pad_right)), constant_values=fill)
    return np.pad(image, ((pad_top, pad_bottom), (pad_left, pad_right), (0, 0)), constant_values=fill)


def histogram_equalization(image: np.ndarray) -> np.ndarray:
    """Apply global histogram equalization on a grayscale image."""
    if image.ndim != 2:
        raise ValueError("histogram_equalization expects a 2-D grayscale array")
    flat = image.ravel()
    hist, bins = np.histogram(flat, bins=256, range=(0, 255))
    cdf = hist.cumsum()
    cdf_min = cdf[cdf > 0].min()
    total_pixels = flat.size
    lut = np.round((cdf - cdf_min) / (total_pixels - cdf_min) * 255).astype(np.uint8)
    return lut[image]


def clahe_approximation(image: np.ndarray, clip_limit: float = 2.0, tile_size: int = 8) -> np.ndarray:
    """Approximate CLAHE using tiled histogram equalization with clipping."""
    if image.ndim != 2:
        raise ValueError("clahe_approximation expects a 2-D grayscale array")
    h, w = image.shape
    out = np.zeros_like(image)

    for y in range(0, h, tile_size):
        for x in range(0, w, tile_size):
            tile = image[y: min(y + tile_size, h), x: min(x + tile_size, w)]
            hist, _ = np.histogram(tile.ravel(), bins=256, range=(0, 255))
            clip_val = int(clip_limit * tile.size / 256)
            excess = np.sum(np.maximum(0, hist - clip_val))
            hist = np.minimum(hist, clip_val)
            hist += excess // 256
            cdf = hist.cumsum()
            cdf_min = cdf[cdf > 0].min()
            denom = tile.size - cdf_min
            if denom > 0:
                lut = np.round((cdf - cdf_min) / denom * 255).astype(np.uint8)
            else:
                lut = np.arange(256, dtype=np.uint8)
            out[y: y + tile.shape[0], x: x + tile.shape[1]] = lut[tile]
    return out
