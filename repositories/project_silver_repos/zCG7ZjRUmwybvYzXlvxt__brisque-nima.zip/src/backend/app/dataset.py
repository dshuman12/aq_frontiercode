"""Dataset management and loading utilities for image quality assessment."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import pathlib
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple

import numpy as np


@dataclass
class ImageRecord:
    """A single image record in the dataset."""
    image_id: str
    path: str
    mos_score: Optional[float] = None
    mos_std: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None
    format: Optional[str] = None
    file_size: Optional[int] = None
    split: str = "train"
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    checksum: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImageRecord":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class DatasetStats:
    total: int = 0
    train: int = 0
    val: int = 0
    test: int = 0
    labeled: int = 0
    unlabeled: int = 0
    avg_mos: float = 0.0
    std_mos: float = 0.0
    min_mos: float = 0.0
    max_mos: float = 0.0
    mos_histogram: Dict[str, int] = field(default_factory=dict)


class InMemoryDataset:
    """In-memory dataset with split management and filtering."""

    def __init__(self, name: str = "default") -> None:
        self.name = name
        self._records: Dict[str, ImageRecord] = {}

    def add(self, record: ImageRecord) -> None:
        self._records[record.image_id] = record

    def get(self, image_id: str) -> Optional[ImageRecord]:
        return self._records.get(image_id)

    def remove(self, image_id: str) -> bool:
        return bool(self._records.pop(image_id, None))

    def __len__(self) -> int:
        return len(self._records)

    def __iter__(self):
        return iter(self._records.values())

    def filter(
        self,
        split: Optional[str] = None,
        min_mos: Optional[float] = None,
        max_mos: Optional[float] = None,
        tags: Optional[List[str]] = None,
        labeled_only: bool = False,
    ) -> List[ImageRecord]:
        results = list(self._records.values())
        if split:
            results = [r for r in results if r.split == split]
        if labeled_only:
            results = [r for r in results if r.mos_score is not None]
        if min_mos is not None:
            results = [r for r in results if r.mos_score is not None and r.mos_score >= min_mos]
        if max_mos is not None:
            results = [r for r in results if r.mos_score is not None and r.mos_score <= max_mos]
        if tags:
            results = [r for r in results if any(t in r.tags for t in tags)]
        return results

    def stats(self) -> DatasetStats:
        s = DatasetStats(total=len(self._records))
        mos_values = [r.mos_score for r in self._records.values() if r.mos_score is not None]

        for r in self._records.values():
            if r.split == "train":
                s.train += 1
            elif r.split == "val":
                s.val += 1
            elif r.split == "test":
                s.test += 1
            if r.mos_score is not None:
                s.labeled += 1
            else:
                s.unlabeled += 1

        if mos_values:
            arr = np.array(mos_values)
            s.avg_mos = float(arr.mean())
            s.std_mos = float(arr.std())
            s.min_mos = float(arr.min())
            s.max_mos = float(arr.max())
            bins = np.arange(1.0, 6.5, 0.5)
            hist, edges = np.histogram(arr, bins=bins)
            for i, count in enumerate(hist):
                label = f"{edges[i]:.1f}-{edges[i+1]:.1f}"
                s.mos_histogram[label] = int(count)
        return s

    def split_dataset(
        self,
        train_frac: float = 0.7,
        val_frac: float = 0.15,
        seed: int = 42,
    ) -> None:
        rng = np.random.default_rng(seed)
        ids = list(self._records.keys())
        rng.shuffle(ids)
        n = len(ids)
        n_train = int(n * train_frac)
        n_val = int(n * val_frac)
        for i, image_id in enumerate(ids):
            if i < n_train:
                self._records[image_id].split = "train"
            elif i < n_train + n_val:
                self._records[image_id].split = "val"
            else:
                self._records[image_id].split = "test"

    def to_json(self) -> str:
        return json.dumps([r.to_dict() for r in self._records.values()], default=str)

    @classmethod
    def from_json(cls, data: str, name: str = "loaded") -> "InMemoryDataset":
        ds = cls(name)
        for item in json.loads(data):
            ds.add(ImageRecord.from_dict(item))
        return ds

    def to_csv(self) -> str:
        if not self._records:
            return ""
        fields = list(ImageRecord.__dataclass_fields__.keys())
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fields)
        writer.writeheader()
        for r in self._records.values():
            row = r.to_dict()
            row["tags"] = "|".join(row.get("tags") or [])
            row["metadata"] = json.dumps(row.get("metadata") or {})
            writer.writerow({k: row.get(k, "") for k in fields})
        return buf.getvalue()


class DataLoader:
    """Batch iterator over a dataset."""

    def __init__(
        self,
        dataset: InMemoryDataset,
        batch_size: int = 32,
        shuffle: bool = False,
        split: Optional[str] = None,
        transform: Optional[Callable[[ImageRecord], Any]] = None,
        seed: int = 0,
    ) -> None:
        self.dataset = dataset
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.split = split
        self.transform = transform
        self._rng = np.random.default_rng(seed)

    def _get_records(self) -> List[ImageRecord]:
        if self.split:
            records = self.dataset.filter(split=self.split)
        else:
            records = list(self.dataset)
        if self.shuffle:
            idxs = list(range(len(records)))
            self._rng.shuffle(idxs)
            records = [records[i] for i in idxs]
        return records

    def __iter__(self) -> Generator[List[Any], None, None]:
        records = self._get_records()
        for start in range(0, len(records), self.batch_size):
            batch = records[start: start + self.batch_size]
            if self.transform:
                yield [self.transform(r) for r in batch]
            else:
                yield batch

    def __len__(self) -> int:
        n = len(self.dataset.filter(split=self.split) if self.split else list(self.dataset))
        return math.ceil(n / self.batch_size) if n else 0


import math


class SyntheticDatasetGenerator:
    """Generate synthetic image records with random MOS scores for testing."""

    def __init__(self, seed: int = 42) -> None:
        self._rng = np.random.default_rng(seed)

    def generate(
        self,
        n: int = 100,
        mos_distribution: str = "normal",
        split_fracs: Tuple[float, float, float] = (0.7, 0.15, 0.15),
    ) -> InMemoryDataset:
        ds = InMemoryDataset("synthetic")

        for i in range(n):
            if mos_distribution == "normal":
                mos = float(np.clip(self._rng.normal(3.5, 0.8), 1.0, 5.0))
            elif mos_distribution == "uniform":
                mos = float(self._rng.uniform(1.0, 5.0))
            elif mos_distribution == "bimodal":
                if self._rng.random() < 0.5:
                    mos = float(np.clip(self._rng.normal(2.0, 0.5), 1.0, 3.0))
                else:
                    mos = float(np.clip(self._rng.normal(4.5, 0.3), 3.5, 5.0))
            else:
                mos = float(self._rng.uniform(1.0, 5.0))

            record = ImageRecord(
                image_id=f"syn_{i:06d}",
                path=f"/synthetic/image_{i:06d}.jpg",
                mos_score=mos,
                mos_std=float(self._rng.uniform(0.1, 0.5)),
                width=int(self._rng.integers(256, 2048)),
                height=int(self._rng.integers(256, 2048)),
                format="JPEG",
                file_size=int(self._rng.integers(50_000, 5_000_000)),
                tags=self._rng.choice(["indoor", "outdoor", "portrait", "landscape", "macro"], size=1).tolist(),
            )
            ds.add(record)

        ds.split_dataset(*split_fracs)
        return ds


class DatasetRegistry:
    """Central registry for multiple datasets."""

    def __init__(self) -> None:
        self._datasets: Dict[str, InMemoryDataset] = {}

    def register(self, dataset: InMemoryDataset) -> None:
        self._datasets[dataset.name] = dataset

    def get(self, name: str) -> Optional[InMemoryDataset]:
        return self._datasets.get(name)

    def list_names(self) -> List[str]:
        return list(self._datasets.keys())

    def remove(self, name: str) -> bool:
        return bool(self._datasets.pop(name, None))

    def merge(self, name: str, *dataset_names: str) -> InMemoryDataset:
        merged = InMemoryDataset(name)
        for ds_name in dataset_names:
            ds = self._datasets.get(ds_name)
            if ds:
                for record in ds:
                    merged.add(record)
        self._datasets[name] = merged
        return merged

    def combined_stats(self) -> Dict[str, DatasetStats]:
        return {name: ds.stats() for name, ds in self._datasets.items()}


def compute_checksum(data: bytes, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    h.update(data)
    return h.hexdigest()


def stratified_split(
    records: List[ImageRecord],
    n_bins: int = 5,
    train_frac: float = 0.7,
    val_frac: float = 0.15,
    seed: int = 42,
) -> List[ImageRecord]:
    """Assign split labels ensuring even MOS distribution across splits."""
    labeled = [(r, r.mos_score) for r in records if r.mos_score is not None]
    unlabeled = [r for r in records if r.mos_score is None]

    if not labeled:
        rng = np.random.default_rng(seed)
        rng.shuffle(unlabeled)
        n = len(unlabeled)
        n_train = int(n * train_frac)
        n_val = int(n * val_frac)
        for i, r in enumerate(unlabeled):
            r.split = "train" if i < n_train else ("val" if i < n_train + n_val else "test")
        return unlabeled

    scores = np.array([s for _, s in labeled])
    bins = np.percentile(scores, np.linspace(0, 100, n_bins + 1))
    bins[-1] += 1e-9
    bin_groups: Dict[int, List[ImageRecord]] = {i: [] for i in range(n_bins)}

    for record, score in labeled:
        for b in range(n_bins):
            if bins[b] <= score < bins[b + 1]:
                bin_groups[b].append(record)
                break

    rng = np.random.default_rng(seed)
    for group in bin_groups.values():
        rng.shuffle(group)
        n = len(group)
        n_train = int(n * train_frac)
        n_val = int(n * val_frac)
        for i, r in enumerate(group):
            r.split = "train" if i < n_train else ("val" if i < n_train + n_val else "test")

    for r in unlabeled:
        r.split = "train"

    return records
