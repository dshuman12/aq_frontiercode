from __future__ import annotations
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List, Callable, Optional
from datetime import datetime

from .models import ImageScore, BatchRequest, BatchResult, QualityTier
from .config import AppConfig
from .cache import TTLCache

_score_cache = TTLCache(default_ttl=600.0)


def _tier_from_composite(score: float) -> QualityTier:
    if score >= 8.0:
        return QualityTier.excellent
    elif score >= 6.5:
        return QualityTier.good
    elif score >= 5.0:
        return QualityTier.average
    elif score >= 3.5:
        return QualityTier.poor
    return QualityTier.reject


def _composite(brisque: Optional[float], nima: Optional[float], config: AppConfig) -> Optional[float]:
    if brisque is None and nima is None:
        return None
    # Normalize brisque: 0 (perfect) → 10, 100 (worst) → 0
    b_norm = max(0.0, 10.0 - (brisque / 10.0)) if brisque is not None else None
    n_norm = nima  # already 1–10

    if b_norm is not None and n_norm is not None:
        return config.brisque_weight * b_norm + config.nima_weight * n_norm
    return b_norm if b_norm is not None else n_norm


def _analyze_single(path: str, analyzer, config: AppConfig) -> ImageScore:
    cache_key = f"score:{path}"
    cached = _score_cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        brisque_score = None
        nima_score = None

        if config.brisque_weight > 0:
            brisque_score = analyzer.score_brisque(path)
        if config.nima_weight > 0:
            nima_score = analyzer.score_nima(path)

        composite = _composite(brisque_score, nima_score, config)
        tier = _tier_from_composite(composite) if composite is not None else None

        result = ImageScore(
            image_path=path,
            brisque_score=brisque_score,
            nima_score=nima_score,
            composite_score=composite,
            quality_tier=tier,
        )
        _score_cache.set(cache_key, result)
        return result
    except Exception as exc:
        return ImageScore(image_path=path, error=str(exc))


async def process_batch(
    request: BatchRequest,
    analyzer,
    config: AppConfig,
    progress_cb: Optional[Callable[[int, int], None]] = None,
) -> BatchResult:
    started = datetime.utcnow()
    start_ts = time.monotonic()

    loop = asyncio.get_event_loop()
    scores: List[ImageScore] = []
    failed = 0

    with ThreadPoolExecutor(max_workers=config.max_workers) as pool:
        futures = [
            loop.run_in_executor(pool, _analyze_single, path, analyzer, config)
            for path in request.image_paths
        ]
        for i, future in enumerate(asyncio.as_completed(futures)):
            score = await future
            scores.append(score)
            if score.error:
                failed += 1
            if progress_cb:
                progress_cb(i + 1, len(request.image_paths))

    completed = datetime.utcnow()
    duration = time.monotonic() - start_ts

    return BatchResult(
        customer_id=request.customer_id,
        total=len(request.image_paths),
        processed=len(scores) - failed,
        failed=failed,
        scores=scores,
        started_at=started,
        completed_at=completed,
        duration_seconds=round(duration, 3),
    )


def filter_scores(scores: List[ImageScore], min_composite: Optional[float] = None,
                  max_composite: Optional[float] = None,
                  top_n: Optional[int] = None) -> tuple[List[ImageScore], List[ImageScore]]:
    kept = []
    rejected = []

    for s in scores:
        if s.error or s.composite_score is None:
            rejected.append(s)
            continue
        if min_composite is not None and s.composite_score < min_composite:
            rejected.append(s)
            continue
        if max_composite is not None and s.composite_score > max_composite:
            rejected.append(s)
            continue
        kept.append(s)

    kept.sort(key=lambda x: x.composite_score or 0, reverse=True)
    if top_n is not None:
        rejected.extend(kept[top_n:])
        kept = kept[:top_n]

    return kept, rejected

# add NIMA scoring module

# add config module

# add test for cache

# add image path validation

# add integration test skeleton
