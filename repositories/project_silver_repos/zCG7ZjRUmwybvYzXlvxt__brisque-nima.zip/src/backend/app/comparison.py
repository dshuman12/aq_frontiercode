"""Before/after quality comparison and A/B testing utilities."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ImagePair:
    pair_id: str
    before_path: str
    after_path: str
    before_result: Optional[Dict[str, Any]] = None
    after_result: Optional[Dict[str, Any]] = None


@dataclass
class ComparisonResult:
    pair_id: str
    before_brisque: float
    after_brisque: float
    before_nima: float
    after_nima: float
    brisque_delta: float
    nima_delta: float
    combined_delta: float
    improved: bool
    delta_pct: float
    verdict: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pair_id": self.pair_id,
            "before_brisque": round(self.before_brisque, 4),
            "after_brisque": round(self.after_brisque, 4),
            "before_nima": round(self.before_nima, 4),
            "after_nima": round(self.after_nima, 4),
            "brisque_delta": round(self.brisque_delta, 4),
            "nima_delta": round(self.nima_delta, 4),
            "combined_delta": round(self.combined_delta, 4),
            "improved": self.improved,
            "delta_pct": round(self.delta_pct, 2),
            "verdict": self.verdict,
        }


class QualityComparator:
    """
    Compares quality scores before and after image processing
    (e.g., retouching, upscaling, compression).
    """

    def __init__(
        self,
        brisque_weight: float = 0.5,
        nima_weight: float = 0.5,
        improvement_threshold: float = 0.02,
    ) -> None:
        self.brisque_weight = brisque_weight
        self.nima_weight = nima_weight
        self.improvement_threshold = improvement_threshold

    def compare_pair(self, pair: ImagePair) -> Optional[ComparisonResult]:
        if not pair.before_result or not pair.after_result:
            return None
        if pair.before_result.get("error") or pair.after_result.get("error"):
            return None

        b_bq = pair.before_result.get("brisque_quality", 0.0)
        a_bq = pair.after_result.get("brisque_quality", 0.0)
        b_nima = pair.before_result.get("nima_score", 0.0)
        a_nima = pair.after_result.get("nima_score", 0.0)

        b_combined = b_bq * self.brisque_weight + b_nima * self.nima_weight
        a_combined = a_bq * self.brisque_weight + a_nima * self.nima_weight

        brisque_delta = a_bq - b_bq
        nima_delta = a_nima - b_nima
        combined_delta = a_combined - b_combined
        improved = combined_delta >= self.improvement_threshold
        delta_pct = (combined_delta / max(b_combined, 1e-9)) * 100

        if combined_delta >= 0.1:
            verdict = "significant_improvement"
        elif combined_delta >= self.improvement_threshold:
            verdict = "minor_improvement"
        elif combined_delta >= -self.improvement_threshold:
            verdict = "no_change"
        elif combined_delta >= -0.1:
            verdict = "minor_degradation"
        else:
            verdict = "significant_degradation"

        return ComparisonResult(
            pair_id=pair.pair_id,
            before_brisque=b_bq,
            after_brisque=a_bq,
            before_nima=b_nima,
            after_nima=a_nima,
            brisque_delta=brisque_delta,
            nima_delta=nima_delta,
            combined_delta=combined_delta,
            improved=improved,
            delta_pct=delta_pct,
            verdict=verdict,
        )

    def compare_batch(self, pairs: List[ImagePair]) -> List[ComparisonResult]:
        results = []
        for pair in pairs:
            result = self.compare_pair(pair)
            if result:
                results.append(result)
        return results

    def aggregate(self, comparison_results: List[ComparisonResult]) -> Dict[str, Any]:
        if not comparison_results:
            return {}

        deltas = [r.combined_delta for r in comparison_results]
        improved_count = sum(1 for r in comparison_results if r.improved)
        verdicts: Dict[str, int] = {}
        for r in comparison_results:
            verdicts[r.verdict] = verdicts.get(r.verdict, 0) + 1

        import numpy as np
        return {
            "total_pairs": len(comparison_results),
            "improved": improved_count,
            "improved_pct": round(improved_count / len(comparison_results) * 100, 2),
            "mean_delta": round(float(np.mean(deltas)), 4),
            "median_delta": round(float(np.median(deltas)), 4),
            "std_delta": round(float(np.std(deltas)), 4),
            "verdicts": verdicts,
        }


class ABTestAnalyzer:
    """
    Statistical A/B test analysis for comparing two quality distributions.
    Uses Welch's t-test for unequal variances.
    """

    def __init__(self, alpha: float = 0.05) -> None:
        self.alpha = alpha

    def analyze(
        self,
        group_a: List[float],
        group_b: List[float],
        metric_name: str = "score",
    ) -> Dict[str, Any]:
        if not group_a or not group_b:
            return {"error": "Empty group"}

        import numpy as np

        a = np.array(group_a)
        b = np.array(group_b)

        mean_a = float(a.mean())
        mean_b = float(b.mean())
        std_a = float(a.std(ddof=1)) if len(a) > 1 else 0.0
        std_b = float(b.std(ddof=1)) if len(b) > 1 else 0.0
        n_a = len(a)
        n_b = len(b)

        se_a2 = (std_a ** 2) / n_a
        se_b2 = (std_b ** 2) / n_b
        se = math.sqrt(se_a2 + se_b2) if (se_a2 + se_b2) > 0 else 1e-10

        t_stat = (mean_a - mean_b) / se

        dof_num = (se_a2 + se_b2) ** 2
        dof_den = (se_a2 ** 2 / max(n_a - 1, 1)) + (se_b2 ** 2 / max(n_b - 1, 1))
        df = dof_num / max(dof_den, 1e-10)

        p_value = self._two_tailed_p(t_stat, df)
        significant = p_value < self.alpha

        effect_pooled_std = math.sqrt(((n_a - 1) * std_a**2 + (n_b - 1) * std_b**2) / max(n_a + n_b - 2, 1))
        cohens_d = (mean_a - mean_b) / max(effect_pooled_std, 1e-10)

        return {
            "metric": metric_name,
            "group_a": {"n": n_a, "mean": round(mean_a, 4), "std": round(std_a, 4)},
            "group_b": {"n": n_b, "mean": round(mean_b, 4), "std": round(std_b, 4)},
            "delta": round(mean_a - mean_b, 4),
            "t_stat": round(t_stat, 4),
            "df": round(df, 1),
            "p_value": round(p_value, 6),
            "alpha": self.alpha,
            "significant": significant,
            "cohens_d": round(cohens_d, 4),
            "effect_size": self._interpret_effect(abs(cohens_d)),
            "winner": "A" if (significant and mean_a > mean_b) else ("B" if (significant and mean_b > mean_a) else "tie"),
        }

    @staticmethod
    def _two_tailed_p(t: float, df: float) -> float:
        """Approximate two-tailed p-value using a simple Normal approximation for large df."""
        if df > 30:
            z = abs(t)
            p_one = 0.5 * math.erfc(z / math.sqrt(2))
            return min(2 * p_one, 1.0)
        # Rough approximation for small df
        p = 1.0 / (1.0 + (t * t / df))
        return min(p, 1.0)

    @staticmethod
    def _interpret_effect(d: float) -> str:
        if d < 0.2:
            return "negligible"
        elif d < 0.5:
            return "small"
        elif d < 0.8:
            return "medium"
        else:
            return "large"


class BatchComparisonReport:
    """Generates a structured report from a set of before/after comparisons."""

    def __init__(
        self,
        comparator: Optional[QualityComparator] = None,
        ab_analyzer: Optional[ABTestAnalyzer] = None,
    ) -> None:
        self.comparator = comparator or QualityComparator()
        self.ab_analyzer = ab_analyzer or ABTestAnalyzer()

    def generate(self, pairs: List[ImagePair]) -> Dict[str, Any]:
        comparison_results = self.comparator.compare_batch(pairs)
        aggregate = self.comparator.aggregate(comparison_results)

        before_brisque = [r.before_brisque for r in comparison_results]
        after_brisque = [r.after_brisque for r in comparison_results]
        before_nima = [r.before_nima for r in comparison_results]
        after_nima = [r.after_nima for r in comparison_results]

        brisque_ab = self.ab_analyzer.analyze(after_brisque, before_brisque, "brisque_quality")
        nima_ab = self.ab_analyzer.analyze(after_nima, before_nima, "nima_score")

        return {
            "aggregate": aggregate,
            "statistical_tests": {
                "brisque": brisque_ab,
                "nima": nima_ab,
            },
            "pairs": [r.to_dict() for r in comparison_results],
        }
