#!/usr/bin/env python3
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi import UploadFile, File
from pydantic import BaseModel
import os
from pathlib import Path
from datetime import datetime
import json
import csv

from .storage_adapter import StorageAdapter

app = FastAPI(title="BRISQUE+NIMA API", version="1.0")

# Single analyzer instance per process
_ANALYZER = None


def get_analyzer():
    global _ANALYZER
    if _ANALYZER is None:
        from .analyzer import BrisqueNimaAnalyzer
        _ANALYZER = BrisqueNimaAnalyzer()
    return _ANALYZER


@app.get("/health")
def health():
    return {"status": "healthy"}


class ProcessPrefixRequest(BaseModel):
    uri_prefix: str
    customer_id: str


@app.post("/process_prefix")
def process_prefix(req: ProcessPrefixRequest):
    adapter = StorageAdapter()
    try:
        items = []
        for p in adapter.list_prefix(req.uri_prefix):
            if not adapter.is_image(p):
                continue
            items.append({"path": p, "id": f"{req.customer_id}:{Path(p).name}"})
        if not items:
            raise HTTPException(status_code=400, detail="No images found under prefix")
        analyzer = get_analyzer()
        results = analyzer.score_batch(items)
        return {"count": len(results), "results": results}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# -----------------------------------------
# Upload and score files (multipart form)
# -----------------------------------------
@app.post("/score_files")
async def score_files(files: list[UploadFile] = File(...)):
    """Accept multiple uploaded image files, compute BRISQUE+NIMA, return JSON results."""
    import tempfile
    import shutil
    tmp_dir = Path(tempfile.mkdtemp(prefix="bn_upload_"))
    saved_paths: list[Path] = []
    try:
        # Save uploads to temp
        for uf in files:
            dest = tmp_dir / Path(uf.filename).name
            content = await uf.read()
            with dest.open("wb") as f:
                f.write(content)
            saved_paths.append(dest)

        items = [{"path": str(p), "id": p.name} for p in saved_paths]
        analyzer = get_analyzer()
        results = analyzer.score_batch(items)
        return {"count": len(results), "results": results}
    finally:
        # Cleanup temp files
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

# Serve the frontend UI at /ui
FRONTEND_DIR = Path(__file__).resolve().parents[3] / "src" / "frontend" / "exported-assets 1 2"
if FRONTEND_DIR.exists():
    app.mount("/ui", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="ui")


# -------------------------
# Cloud-agnostic upload init
# -------------------------
class UploadInitRequest(BaseModel):
    customer_id: str
    prefix: str = "uploads/"
    content_type: str = "image/jpeg"
    expires_in: int = 3600


@app.post("/upload_init")
def upload_init(req: UploadInitRequest):
    adapter = StorageAdapter()
    try:
        return adapter.upload_init(req.customer_id, req.prefix, req.content_type, req.expires_in)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------
# Process and write outputs (JSON and CSV)
# ---------------------------------------
class ProcessToOutputRequest(BaseModel):
    uri_prefix: str
    customer_id: str
    output_prefix: str
    formats: list[str] = ["json", "csv"]


@app.post("/process_prefix_to_output")
def process_prefix_to_output(req: ProcessToOutputRequest):
    adapter = StorageAdapter()
    try:
        # gather items
        items = []
        for p in adapter.list_prefix(req.uri_prefix):
            if not adapter.is_image(p):
                continue
            items.append({"path": p, "id": f"{req.customer_id}:{Path(p).name}"})
        if not items:
            raise HTTPException(status_code=400, detail="No images found under prefix")

        # score
        analyzer = get_analyzer()
        results = analyzer.score_batch(items)

        # prepare outputs
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        written = []

        if "json" in req.formats:
            data = json.dumps({"customer_id": req.customer_id, "count": len(results), "results": results}, indent=2).encode("utf-8")
            uri = adapter.join_uri(req.output_prefix, f"brisque_nima_results_{ts}.json")
            adapter.put_bytes(uri, data, content_type="application/json")
            written.append(uri)

        if "csv" in req.formats:
            # Build CSV in-memory
            cols = ["photo_id", "file_path", "brisque_score", "brisque_quality", "nima_aesthetic"]
            from io import StringIO
            sio = StringIO()
            w = csv.writer(sio)
            w.writerow(cols)
            for r in results:
                w.writerow([r.get(c, "") for c in cols])
            uri = adapter.join_uri(req.output_prefix, f"brisque_nima_results_{ts}.csv")
            adapter.put_bytes(uri, sio.getvalue().encode("utf-8"), content_type="text/csv")
            written.append(uri)

        return {"count": len(results), "outputs": written}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# add cache stats endpoint

# add CORS middleware
