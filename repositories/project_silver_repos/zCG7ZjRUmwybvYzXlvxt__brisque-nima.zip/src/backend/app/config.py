from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AppConfig:
    # Storage
    storage_backend: str = "local"
    local_storage_root: str = "/tmp/brisque_nima"
    s3_bucket: Optional[str] = None
    s3_region: str = "us-east-1"

    # Analysis
    brisque_threshold: float = 40.0
    nima_threshold: float = 5.0
    batch_size: int = 32
    max_workers: int = 4

    # Cache
    cache_ttl: float = 600.0
    cache_max_size: int = 2000

    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    debug: bool = False
    cors_origins: list = field(default_factory=lambda: ["*"])

    # Scoring weights
    brisque_weight: float = 0.4
    nima_weight: float = 0.6

    @classmethod
    def from_env(cls) -> "AppConfig":
        return cls(
            storage_backend=os.getenv("STORAGE_BACKEND", "local"),
            local_storage_root=os.getenv("LOCAL_STORAGE_ROOT", "/tmp/brisque_nima"),
            s3_bucket=os.getenv("S3_BUCKET"),
            s3_region=os.getenv("S3_REGION", "us-east-1"),
            brisque_threshold=float(os.getenv("BRISQUE_THRESHOLD", "40.0")),
            nima_threshold=float(os.getenv("NIMA_THRESHOLD", "5.0")),
            batch_size=int(os.getenv("BATCH_SIZE", "32")),
            max_workers=int(os.getenv("MAX_WORKERS", "4")),
            cache_ttl=float(os.getenv("CACHE_TTL", "600.0")),
            cache_max_size=int(os.getenv("CACHE_MAX_SIZE", "2000")),
            api_host=os.getenv("API_HOST", "0.0.0.0"),
            api_port=int(os.getenv("API_PORT", "8000")),
            debug=os.getenv("DEBUG", "false").lower() == "true",
            brisque_weight=float(os.getenv("BRISQUE_WEIGHT", "0.4")),
            nima_weight=float(os.getenv("NIMA_WEIGHT", "0.6")),
        )

    def validate(self) -> list[str]:
        errors = []
        if not 0.0 <= self.brisque_weight <= 1.0:
            errors.append("brisque_weight must be between 0 and 1")
        if not 0.0 <= self.nima_weight <= 1.0:
            errors.append("nima_weight must be between 0 and 1")
        if abs(self.brisque_weight + self.nima_weight - 1.0) > 0.001:
            errors.append("brisque_weight + nima_weight must equal 1.0")
        if self.batch_size < 1:
            errors.append("batch_size must be >= 1")
        if self.max_workers < 1:
            errors.append("max_workers must be >= 1")
        return errors

# add celery task queue

# add quality tier classification

# add top-k filtering

# fix memory leak in model loader

# add QualityTier enum
