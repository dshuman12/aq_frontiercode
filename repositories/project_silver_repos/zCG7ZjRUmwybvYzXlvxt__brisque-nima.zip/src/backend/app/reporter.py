"""Quality report generation: JSON, CSV, HTML, and statistical summaries."""

from __future__ import annotations

import csv
import io
import json
import math
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


class StatsSummary:
    """Computes descriptive statistics over a list of numeric values."""

    def __init__(self, values: List[float]) -> None:
        self.values = [v for v in values if v is not None and not math.isnan(v)]

    def compute(self) -> Dict[str, float]:
        if not self.values:
            return {"count": 0}

        import numpy as np
        arr = np.array(self.values)
        return {
            "count": len(arr),
            "mean": float(arr.mean()),
            "std": float(arr.std()),
            "min": float(arr.min()),
            "max": float(arr.max()),
            "p10": float(np.percentile(arr, 10)),
            "p25": float(np.percentile(arr, 25)),
            "median": float(np.median(arr)),
            "p75": float(np.percentile(arr, 75)),
            "p90": float(np.percentile(arr, 90)),
        }

    def histogram_bins(self, n_bins: int = 10) -> List[Dict[str, float]]:
        if not self.values:
            return []
        import numpy as np
        counts, edges = np.histogram(self.values, bins=n_bins, range=(0.0, 1.0))
        return [
            {"low": float(edges[i]), "high": float(edges[i + 1]), "count": int(counts[i])}
            for i in range(len(counts))
        ]


class GradeDistribution:
    """Tracks distribution of quality grades across a batch."""

    GRADES = ["excellent", "good", "acceptable", "poor", "reject"]

    def __init__(self) -> None:
        self._counts: Dict[str, int] = {g: 0 for g in self.GRADES}
        self._total = 0

    def record(self, grade: str) -> None:
        grade = grade.lower()
        if grade in self._counts:
            self._counts[grade] += 1
        else:
            self._counts["poor"] += 1
        self._total += 1

    def distribution(self) -> Dict[str, Any]:
        result = {}
        for grade in self.GRADES:
            count = self._counts[grade]
            result[grade] = {
                "count": count,
                "pct": round(count / max(self._total, 1) * 100, 2),
            }
        result["total"] = self._total
        return result


class JSONReporter:
    """Serialises assessment results to JSON."""

    def __init__(self, indent: int = 2) -> None:
        self.indent = indent

    def generate(
        self,
        results: List[Dict[str, Any]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        brisque_vals = [r["brisque_quality"] for r in results if "brisque_quality" in r]
        nima_vals = [r["nima_score"] for r in results if "nima_score" in r]
        grade_dist = GradeDistribution()
        for r in results:
            if "grade" in r:
                grade_dist.record(r["grade"])

        payload = {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "metadata": metadata or {},
            "summary": {
                "total": len(results),
                "successful": sum(1 for r in results if r.get("error") is None),
                "failed": sum(1 for r in results if r.get("error") is not None),
                "passed": sum(1 for r in results if r.get("passed")),
                "rejected": sum(1 for r in results if not r.get("passed")),
                "brisque": StatsSummary(brisque_vals).compute(),
                "nima": StatsSummary(nima_vals).compute(),
                "grades": grade_dist.distribution(),
            },
            "results": results,
        }
        return json.dumps(payload, indent=self.indent, default=str)

    def generate_to_buffer(self, results: List[Dict], **kwargs) -> io.BytesIO:
        buf = io.BytesIO()
        buf.write(self.generate(results, **kwargs).encode("utf-8"))
        buf.seek(0)
        return buf


class CSVReporter:
    """Writes assessment results as a flat CSV table."""

    COLUMNS = [
        "path", "brisque_raw", "brisque_quality", "nima_raw",
        "nima_score", "combined_score", "grade", "passed",
        "reject_reasons", "error",
    ]

    def generate(self, results: List[Dict[str, Any]]) -> str:
        output = io.StringIO()
        writer = csv.DictWriter(
            output, fieldnames=self.COLUMNS, extrasaction="ignore"
        )
        writer.writeheader()
        for r in results:
            row = dict(r)
            if "reject_reasons" in row and isinstance(row["reject_reasons"], list):
                row["reject_reasons"] = "; ".join(row["reject_reasons"])
            writer.writerow(row)
        return output.getvalue()

    def generate_to_buffer(self, results: List[Dict]) -> io.BytesIO:
        buf = io.BytesIO()
        buf.write(self.generate(results).encode("utf-8"))
        buf.seek(0)
        return buf


class HTMLReporter:
    """Generates a simple HTML quality report with inline styles."""

    GRADE_COLORS = {
        "excellent": "#22c55e",
        "good": "#86efac",
        "acceptable": "#fbbf24",
        "poor": "#f97316",
        "reject": "#ef4444",
    }

    def generate(
        self,
        results: List[Dict[str, Any]],
        title: str = "Image Quality Report",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        grade_dist = GradeDistribution()
        for r in results:
            if "grade" in r:
                grade_dist.record(r["grade"])
        dist = grade_dist.distribution()

        rows_html = []
        for r in results:
            grade = r.get("grade", "N/A")
            color = self.GRADE_COLORS.get(grade, "#ccc")
            passed = "✓" if r.get("passed") else "✗"
            rows_html.append(f"""
            <tr>
              <td style="font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis" title="{r.get('path','')}">
                {self._basename(r.get('path',''))}</td>
              <td>{r.get('brisque_quality','N/A')}</td>
              <td>{r.get('nima_score','N/A')}</td>
              <td>{r.get('combined_score','N/A')}</td>
              <td style="background:{color};color:#fff;text-align:center">{grade}</td>
              <td style="text-align:center">{passed}</td>
              <td style="font-size:10px;color:#999">{r.get('error','')}</td>
            </tr>""")

        summary_rows = []
        for grade in GradeDistribution.GRADES:
            info = dist.get(grade, {})
            count = info.get("count", 0)
            pct = info.get("pct", 0)
            color = self.GRADE_COLORS.get(grade, "#ccc")
            bar = f'<div style="background:{color};width:{pct}%;height:12px;border-radius:3px"></div>'
            summary_rows.append(
                f"<tr><td>{grade}</td><td>{count}</td><td>{pct}%</td><td>{bar}</td></tr>"
            )

        meta_rows = ""
        if metadata:
            for k, v in metadata.items():
                meta_rows += f"<tr><td><b>{k}</b></td><td>{v}</td></tr>"

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{title}</title>
  <style>
    body {{ font-family: Arial, sans-serif; padding: 20px; color: #333; }}
    h1 {{ color: #1a202c; }}
    table {{ border-collapse: collapse; width: 100%; margin-bottom: 24px; }}
    th, td {{ border: 1px solid #e2e8f0; padding: 6px 10px; font-size: 13px; }}
    th {{ background: #f7fafc; font-weight: 600; }}
    tr:nth-child(even) {{ background: #f9fafb; }}
    .meta {{ font-size: 12px; color: #718096; }}
  </style>
</head>
<body>
  <h1>{title}</h1>
  <p class="meta">Generated: {datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")} UTC
     | Total: {len(results)} images</p>

  <h2>Grade Distribution</h2>
  <table>
    <thead><tr><th>Grade</th><th>Count</th><th>Pct</th><th>Distribution</th></tr></thead>
    <tbody>{"".join(summary_rows)}</tbody>
  </table>

  {"<h2>Metadata</h2><table><tbody>" + meta_rows + "</tbody></table>" if meta_rows else ""}

  <h2>Results</h2>
  <table>
    <thead><tr>
      <th>File</th><th>BRISQUE Q</th><th>NIMA</th><th>Combined</th>
      <th>Grade</th><th>Pass</th><th>Error</th>
    </tr></thead>
    <tbody>{"".join(rows_html)}</tbody>
  </table>
</body>
</html>"""

    @staticmethod
    def _basename(path: str) -> str:
        import os
        return os.path.basename(path) if path else ""

    def generate_to_buffer(self, results: List[Dict], **kwargs) -> io.BytesIO:
        buf = io.BytesIO()
        buf.write(self.generate(results, **kwargs).encode("utf-8"))
        buf.seek(0)
        return buf


class MarkdownReporter:
    """Generates a Markdown quality summary report."""

    def generate(
        self,
        results: List[Dict[str, Any]],
        title: str = "Image Quality Report",
    ) -> str:
        grade_dist = GradeDistribution()
        for r in results:
            if "grade" in r:
                grade_dist.record(r["grade"])
        dist = grade_dist.distribution()

        brisque_vals = [r["brisque_quality"] for r in results if "brisque_quality" in r]
        nima_vals = [r["nima_score"] for r in results if "nima_score" in r]
        b_stats = StatsSummary(brisque_vals).compute()
        n_stats = StatsSummary(nima_vals).compute()

        lines = [
            f"# {title}",
            f"",
            f"> Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC",
            f"",
            f"## Summary",
            f"",
            f"| Metric | Value |",
            f"|--------|-------|",
            f"| Total images | {len(results)} |",
            f"| Successful | {sum(1 for r in results if not r.get('error'))} |",
            f"| Passed | {sum(1 for r in results if r.get('passed'))} |",
            f"| Rejected | {sum(1 for r in results if not r.get('passed'))} |",
            f"| Mean BRISQUE quality | {b_stats.get('mean', 0):.4f} |",
            f"| Mean NIMA score | {n_stats.get('mean', 0):.4f} |",
            f"",
            f"## Grade Distribution",
            f"",
            f"| Grade | Count | % |",
            f"|-------|-------|---|",
        ]
        for grade in GradeDistribution.GRADES:
            info = dist.get(grade, {})
            lines.append(f"| {grade} | {info.get('count',0)} | {info.get('pct',0)}% |")

        lines += [
            f"",
            f"## BRISQUE Quality Statistics",
            f"",
            f"| Stat | Value |",
            f"|------|-------|",
        ]
        for k, v in b_stats.items():
            if k != "count":
                lines.append(f"| {k} | {v:.4f} |")

        lines += [
            f"",
            f"## NIMA Score Statistics",
            f"",
            f"| Stat | Value |",
            f"|------|-------|",
        ]
        for k, v in n_stats.items():
            if k != "count":
                lines.append(f"| {k} | {v:.4f} |")

        return "\n".join(lines)
