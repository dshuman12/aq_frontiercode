#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import json
import argparse
from pathlib import Path

# Ensure local package imports work
CURR = Path(__file__).resolve().parent
if str(CURR.parent) not in sys.path:
    sys.path.insert(0, str(CURR.parent))

from app.analyzer import BrisqueNimaAnalyzer
from app.storage_adapter import StorageAdapter


def main():
    p = argparse.ArgumentParser(description="Run BRISQUE+NIMA on a prefix and print JSON results")
    p.add_argument("--prefix", required=True, help="URI prefix: local dir or s3://bucket/prefix")
    p.add_argument("--customer-id", default="demo", help="Customer ID")
    p.add_argument("--limit", type=int, default=10, help="Limit number of images for demo")
    p.add_argument("--batch-size", type=int, default=int(os.getenv("BATCH_SIZE", "16")))
    args = p.parse_args()

    os.environ.setdefault("BATCH_SIZE", str(args.batch_size))

    adapter = StorageAdapter()
    analyzer = BrisqueNimaAnalyzer()

    items = []
    for pth in adapter.list_prefix(args.prefix):
        if not adapter.is_image(pth):
            continue
        items.append({"path": pth, "id": f"{args.customer_id}:{Path(pth).name}"})
        if len(items) >= args.limit:
            break

    if not items:
        print(json.dumps({"error": "No images found", "prefix": args.prefix}))
        return 1

    results = analyzer.score_batch(items)
    print(json.dumps({"count": len(results), "results": results}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# add BRISQUE implementation

# fix storage adapter S3 support

# fix concurrent batch processing

# add worker count config

# add cache invalidation

# add top_n validation
