# Create a comprehensive Python implementation showing both BRISQUE and NIMA models
# This will complement the web application with actual model implementations

brisque_implementation = """
# BRISQUE Implementation for Image Quality Assessment
import cv2
import numpy as np
from skimage import feature
import pandas as pd

class BRISQUEAssessment:
    def __init__(self):
        self.feature_extractor = BRISQUEFeatureExtractor()
    
    def calculate_brisque_score(self, image_path):
        \"\"\"
        Calculate BRISQUE score for an image
        Lower scores indicate better quality (1-100 scale)
        \"\"\"
        # Load and convert image to grayscale
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Normalize image
        img = img.astype(np.float64)
        img = img / 255.0
        
        # Extract BRISQUE features
        features = self.feature_extractor.extract_features(img)
        
        # Calculate quality score (simplified version)
        # In actual BRISQUE, this would use a trained SVM model
        score = self._calculate_simplified_score(features)
        
        return score
    
    def _calculate_simplified_score(self, features):
        \"\"\"
        Simplified scoring based on image statistics
        \"\"\"
        # Use feature statistics to estimate quality
        # Lower values = better quality
        base_score = np.mean(np.abs(features)) * 100
        
        # Clamp to 1-100 range
        score = max(1, min(100, base_score))
        return score

class BRISQUEFeatureExtractor:
    def extract_features(self, img):
        \"\"\"Extract 36 BRISQUE features from image\"\"\"
        
        # Step 1: Calculate MSCN (Mean Subtracted Contrast Normalized) coefficients
        mu = cv2.GaussianBlur(img, (7, 7), 1.166)
        mu_sq = mu * mu
        sigma = cv2.GaussianBlur(img * img, (7, 7), 1.166)
        sigma = (sigma - mu_sq) ** 0.5
        sigma = sigma + 1.0/255  # avoid division by zero
        
        structdis = (img - mu) / sigma
        
        # Step 2: Calculate features from MSCN coefficients
        features = []
        
        # Features from MSCN image
        features.extend(self._fit_aggd_params(structdis))
        
        # Features from pairwise products
        shifts = [[0,1], [1,0], [1,1], [-1,1]]  # H, V, D1, D2
        
        for shift in shifts:
            shifted_structdis = np.roll(structdis, shift, axis=(0,1))
            pairwise = structdis * shifted_structdis
            features.extend(self._fit_aggd_params(pairwise))
        
        # Repeat for half-sized image
        img_half = cv2.resize(img, None, fx=0.5, fy=0.5)
        features_half = self.extract_features(img_half)
        features.extend(features_half[:18])  # Only take first 18 features
        
        return np.array(features[:36])  # Return exactly 36 features
    
    def _fit_aggd_params(self, data):
        \"\"\"Fit Asymmetric Generalized Gaussian Distribution parameters\"\"\"
        # Simplified parameter estimation
        mean_val = np.mean(data)
        std_val = np.std(data)
        
        # Return simplified parameters
        return [mean_val, std_val]

# Usage example
def analyze_image_brisque(image_path):
    assessor = BRISQUEAssessment()
    score = assessor.calculate_brisque_score(image_path)
    
    quality_level = "Excellent" if score < 30 else "Good" if score < 50 else "Fair" if score < 70 else "Poor"
    
    return {
        'brisque_score': score,
        'quality_level': quality_level,
        'interpretation': f'Lower is better. Score: {score:.2f} indicates {quality_level.lower()} technical quality'
    }
"""

nima_implementation = """
# NIMA Implementation for Aesthetic Image Quality Assessment
import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2
from PIL import Image
import pandas as pd

class NIMAAssessment:
    def __init__(self, model_path=None):
        if model_path:
            self.model = keras.models.load_model(model_path)
        else:
            self.model = self._create_simplified_model()
    
    def _create_simplified_model(self):
        \"\"\"
        Create a simplified NIMA-like model
        In practice, you'd use a pre-trained model on AVA dataset
        \"\"\"
        base_model = keras.applications.MobileNetV2(
            input_shape=(224, 224, 3),
            include_top=False,
            weights='imagenet'
        )
        
        model = keras.Sequential([
            base_model,
            keras.layers.GlobalAveragePooling2D(),
            keras.layers.Dropout(0.2),
            keras.layers.Dense(10, activation='softmax')  # 10 quality levels
        ])
        
        return model
    
    def calculate_nima_score(self, image_path):
        \"\"\"
        Calculate NIMA aesthetic score for an image
        Higher scores indicate better aesthetic quality (1-10 scale)
        \"\"\"
        # Load and preprocess image
        img = self._preprocess_image(image_path)
        
        # Get prediction from model
        predictions = self.model.predict(np.expand_dims(img, axis=0), verbose=0)
        
        # Calculate weighted average score
        scores = np.arange(1, 11)  # 1 to 10
        nima_score = np.sum(predictions[0] * scores)
        
        return nima_score
    
    def _preprocess_image(self, image_path):
        \"\"\"Preprocess image for NIMA model input\"\"\"
        # Load image
        img = Image.open(image_path).convert('RGB')
        
        # Resize to 224x224 (standard input size for many models)
        img = img.resize((224, 224))
        
        # Convert to array and normalize
        img_array = np.array(img) / 255.0
        
        return img_array
    
    def get_aesthetic_features(self, image_path):
        \"\"\"Extract aesthetic features for analysis\"\"\"
        img = cv2.imread(image_path)
        
        # Color harmony analysis
        color_harmony = self._analyze_color_harmony(img)
        
        # Composition analysis
        composition = self._analyze_composition(img)
        
        # Edge density
        edge_density = self._analyze_edge_density(img)
        
        return {
            'color_harmony': color_harmony,
            'composition': composition,
            'edge_density': edge_density
        }
    
    def _analyze_color_harmony(self, img):
        \"\"\"Analyze color harmony in HSV space\"\"\"
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        # Calculate color distribution
        h_std = np.std(hsv[:,:,0])  # Hue standard deviation
        s_mean = np.mean(hsv[:,:,1])  # Saturation mean
        v_mean = np.mean(hsv[:,:,2])  # Value mean
        
        # Simple harmony score (lower hue std + balanced saturation/value)
        harmony = max(0, 10 - h_std/10) * (s_mean/255) * (v_mean/255)
        
        return min(10, harmony)
    
    def _analyze_composition(self, img):
        \"\"\"Analyze image composition\"\"\"
        h, w = img.shape[:2]
        
        # Rule of thirds analysis
        third_h, third_w = h//3, w//3
        
        # Calculate interest points using corner detection
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        corners = cv2.goodFeaturesToTrack(gray, 100, 0.01, 10)
        
        composition_score = 5.0  # Base score
        
        if corners is not None:
            # Check if interest points align with rule of thirds
            thirds_points = [(third_w, third_h), (2*third_w, third_h), 
                           (third_w, 2*third_h), (2*third_w, 2*third_h)]
            
            for corner in corners:
                x, y = corner.ravel()
                for tx, ty in thirds_points:
                    if abs(x-tx) < w/6 and abs(y-ty) < h/6:
                        composition_score += 0.1
        
        return min(10, composition_score)
    
    def _analyze_edge_density(self, img):
        \"\"\"Analyze edge density for texture assessment\"\"\"
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        
        # Calculate edge density
        edge_density = np.sum(edges > 0) / (gray.shape[0] * gray.shape[1])
        
        # Convert to 1-10 scale (moderate edge density is usually better)
        optimal_density = 0.1  # 10% edges is often optimal
        score = 10 * (1 - abs(edge_density - optimal_density) / optimal_density)
        
        return max(1, min(10, score))

# Usage example
def analyze_image_nima(image_path):
    assessor = NIMAAssessment()
    score = assessor.calculate_nima_score(image_path)
    features = assessor.get_aesthetic_features(image_path)
    
    quality_level = "Excellent" if score >= 8 else "Good" if score >= 6 else "Average" if score >= 4 else "Poor"
    
    return {
        'nima_score': score,
        'quality_level': quality_level,
        'aesthetic_features': features,
        'interpretation': f'Higher is better. Score: {score:.2f} indicates {quality_level.lower()} aesthetic quality'
    }
"""

combined_system = """
# Combined Image Quality Assessment System
import os
import pandas as pd
from pathlib import Path

class ImageQualityAssessmentSystem:
    def __init__(self):
        self.brisque_assessor = BRISQUEAssessment()
        self.nima_assessor = NIMAAssessment()
    
    def analyze_images(self, image_paths, output_csv=None):
        \"\"\"
        Analyze multiple images and return ranked results
        \"\"\"
        results = []
        
        for image_path in image_paths:
            try:
                # Calculate BRISQUE score (lower = better, 1-100)
                brisque_score = self.brisque_assessor.calculate_brisque_score(image_path)
                
                # Calculate NIMA score (higher = better, 1-10)
                nima_score = self.nima_assessor.calculate_nima_score(image_path)
                
                # Calculate combined score
                combined_score = self._calculate_combined_score(brisque_score, nima_score)
                
                results.append({
                    'filename': Path(image_path).name,
                    'filepath': image_path,
                    'brisque_score': brisque_score,
                    'nima_score': nima_score,
                    'combined_score': combined_score,
                    'brisque_quality': self._get_quality_level_brisque(brisque_score),
                    'nima_quality': self._get_quality_level_nima(nima_score),
                    'overall_quality': self._get_quality_level_combined(combined_score)
                })
                
            except Exception as e:
                print(f"Error processing {image_path}: {e}")
                continue
        
        # Convert to DataFrame and sort by combined score
        df = pd.DataFrame(results)
        df = df.sort_values('combined_score', ascending=False).reset_index(drop=True)
        df['rank'] = range(1, len(df) + 1)
        
        if output_csv:
            df.to_csv(output_csv, index=False)
            print(f"Results saved to {output_csv}")
        
        return df
    
    def _calculate_combined_score(self, brisque_score, nima_score):
        \"\"\"
        Calculate combined score handling reverse scoring of BRISQUE
        \"\"\"
        # Normalize BRISQUE score (invert since lower is better)
        # Convert from 1-100 scale to 0-10 scale, inverted
        normalized_brisque = (100 - brisque_score) / 10
        normalized_brisque = max(0, min(10, normalized_brisque))
        
        # NIMA is already on 1-10 scale where higher is better
        
        # Weighted combination (40% technical, 60% aesthetic)
        combined = (normalized_brisque * 0.4) + (nima_score * 0.6)
        
        return combined
    
    def _get_quality_level_brisque(self, score):
        \"\"\"Get quality level for BRISQUE score\"\"\"
        if score < 30:
            return "Excellent"
        elif score < 50:
            return "Good"
        elif score < 70:
            return "Fair"
        else:
            return "Poor"
    
    def _get_quality_level_nima(self, score):
        \"\"\"Get quality level for NIMA score\"\"\"
        if score >= 8:
            return "Excellent"
        elif score >= 6:
            return "Good"
        elif score >= 4:
            return "Average"
        else:
            return "Poor"
    
    def _get_quality_level_combined(self, score):
        \"\"\"Get quality level for combined score\"\"\"
        if score >= 8:
            return "Excellent"
        elif score >= 6:
            return "Good"
        elif score >= 4:
            return "Average"
        else:
            return "Poor"
    
    def print_ranking_summary(self, results_df):
        \"\"\"Print a summary of the ranking results\"\"\"
        print("\\n" + "="*60)
        print("IMAGE QUALITY ASSESSMENT RESULTS")
        print("="*60)
        print(f"Total images analyzed: {len(results_df)}")
        print()
        
        print("TOP 5 IMAGES:")
        print("-" * 60)
        for i, row in results_df.head().iterrows():
            print(f"{row['rank']:2d}. {row['filename']}")
            print(f"    Combined Score: {row['combined_score']:.2f} ({row['overall_quality']})")
            print(f"    BRISQUE: {row['brisque_score']:.1f} ({row['brisque_quality']})")
            print(f"    NIMA: {row['nima_score']:.2f} ({row['nima_quality']})")
            print()

# Usage example
def main():
    # Example usage
    image_folder = "path/to/your/images"
    image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
    
    # Initialize assessment system
    quality_system = ImageQualityAssessmentSystem()
    
    # Analyze images
    results = quality_system.analyze_images(image_paths, "image_quality_results.csv")
    
    # Print summary
    quality_system.print_ranking_summary(results)
    
    return results

if __name__ == "__main__":
    results = main()
"""

# Save the implementations to files
with open('brisque_implementation.py', 'w') as f:
    f.write(brisque_implementation)

with open('nima_implementation.py', 'w') as f:
    f.write(nima_implementation)

with open('combined_system.py', 'w') as f:
    f.write(combined_system)

print("Created Python implementation files:")
print("1. brisque_implementation.py - BRISQUE technical quality assessment")
print("2. nima_implementation.py - NIMA aesthetic quality assessment")  
print("3. combined_system.py - Complete ranking system")
print("\nThese files contain the actual implementation logic used in the web application.")
# add graceful shutdown

# improve batch error reporting
