
# NIMA Implementation for Aesthetic Image Quality Assessment
import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2
from PIL import Image
import pandas as pd

class NIMAAssessment:
    def __init__(self, model_path=None):
        if model_path:
            self.model = keras.models.load_model(model_path)
        else:
            self.model = self._create_simplified_model()

    def _create_simplified_model(self):
        """
        Create a simplified NIMA-like model
        In practice, you'd use a pre-trained model on AVA dataset
        """
        base_model = keras.applications.MobileNetV2(
            input_shape=(224, 224, 3),
            include_top=False,
            weights='imagenet'
        )

        model = keras.Sequential([
            base_model,
            keras.layers.GlobalAveragePooling2D(),
            keras.layers.Dropout(0.2),
            keras.layers.Dense(10, activation='softmax')  # 10 quality levels
        ])

        return model

    def calculate_nima_score(self, image_path):
        """
        Calculate NIMA aesthetic score for an image
        Higher scores indicate better aesthetic quality (1-10 scale)
        """
        # Load and preprocess image
        img = self._preprocess_image(image_path)

        # Get prediction from model
        predictions = self.model.predict(np.expand_dims(img, axis=0), verbose=0)

        # Calculate weighted average score
        scores = np.arange(1, 11)  # 1 to 10
        nima_score = np.sum(predictions[0] * scores)

        return nima_score

    def _preprocess_image(self, image_path):
        """Preprocess image for NIMA model input"""
        # Load image
        img = Image.open(image_path).convert('RGB')

        # Resize to 224x224 (standard input size for many models)
        img = img.resize((224, 224))

        # Convert to array and normalize
        img_array = np.array(img) / 255.0

        return img_array

    def get_aesthetic_features(self, image_path):
        """Extract aesthetic features for analysis"""
        img = cv2.imread(image_path)

        # Color harmony analysis
        color_harmony = self._analyze_color_harmony(img)

        # Composition analysis
        composition = self._analyze_composition(img)

        # Edge density
        edge_density = self._analyze_edge_density(img)

        return {
            'color_harmony': color_harmony,
            'composition': composition,
            'edge_density': edge_density
        }

    def _analyze_color_harmony(self, img):
        """Analyze color harmony in HSV space"""
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # Calculate color distribution
        h_std = np.std(hsv[:,:,0])  # Hue standard deviation
        s_mean = np.mean(hsv[:,:,1])  # Saturation mean
        v_mean = np.mean(hsv[:,:,2])  # Value mean

        # Simple harmony score (lower hue std + balanced saturation/value)
        harmony = max(0, 10 - h_std/10) * (s_mean/255) * (v_mean/255)

        return min(10, harmony)

    def _analyze_composition(self, img):
        """Analyze image composition"""
        h, w = img.shape[:2]

        # Rule of thirds analysis
        third_h, third_w = h//3, w//3

        # Calculate interest points using corner detection
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        corners = cv2.goodFeaturesToTrack(gray, 100, 0.01, 10)

        composition_score = 5.0  # Base score

        if corners is not None:
            # Check if interest points align with rule of thirds
            thirds_points = [(third_w, third_h), (2*third_w, third_h), 
                           (third_w, 2*third_h), (2*third_w, 2*third_h)]

            for corner in corners:
                x, y = corner.ravel()
                for tx, ty in thirds_points:
                    if abs(x-tx) < w/6 and abs(y-ty) < h/6:
                        composition_score += 0.1

        return min(10, composition_score)

    def _analyze_edge_density(self, img):
        """Analyze edge density for texture assessment"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)

        # Calculate edge density
        edge_density = np.sum(edges > 0) / (gray.shape[0] * gray.shape[1])

        # Convert to 1-10 scale (moderate edge density is usually better)
        optimal_density = 0.1  # 10% edges is often optimal
        score = 10 * (1 - abs(edge_density - optimal_density) / optimal_density)

        return max(1, min(10, score))

# Usage example
def analyze_image_nima(image_path):
    assessor = NIMAAssessment()
    score = assessor.calculate_nima_score(image_path)
    features = assessor.get_aesthetic_features(image_path)

    quality_level = "Excellent" if score >= 8 else "Good" if score >= 6 else "Average" if score >= 4 else "Poor"

    return {
        'nima_score': score,
        'quality_level': quality_level,
        'aesthetic_features': features,
        'interpretation': f'Higher is better. Score: {score:.2f} indicates {quality_level.lower()} aesthetic quality'
    }

# add customer ID validation
