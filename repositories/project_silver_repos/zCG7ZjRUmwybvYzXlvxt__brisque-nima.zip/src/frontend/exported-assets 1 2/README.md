# Image Quality Assessment System - Installation & Usage Guide

## Overview
This system implements both BRISQUE and NIMA models for comprehensive image quality assessment:
- **BRISQUE**: Technical quality (sharpness, noise, artifacts) - Lower scores = Better quality
- **NIMA**: Aesthetic quality (composition, color harmony) - Higher scores = Better quality

## Installation

### 1. Create Virtual Environment
```bash
python -m venv image_quality_env
source image_quality_env/bin/activate  # Linux/Mac
# or
image_quality_env\Scripts\activate  # Windows
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Alternative Installation (if requirements.txt fails)
```bash
pip install opencv-python numpy scikit-image pandas Pillow tensorflow
```

## Usage Examples

### Basic Usage
```python
from combined_system import ImageQualityAssessmentSystem
import os

# Initialize the system
quality_system = ImageQualityAssessmentSystem()

# Analyze a single image
image_path = "path/to/your/image.jpg"
brisque_score = quality_system.brisque_assessor.calculate_brisque_score(image_path)
nima_score = quality_system.nima_assessor.calculate_nima_score(image_path)

print(f"BRISQUE Score: {brisque_score:.2f} (lower = better)")
print(f"NIMA Score: {nima_score:.2f} (higher = better)")
```

### Batch Processing
```python
# Analyze multiple images
image_folder = "path/to/image/folder"
image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder) 
               if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

# Get ranked results
results = quality_system.analyze_images(image_paths, "results.csv")

# Print summary
quality_system.print_ranking_summary(results)
```

### Understanding the Scores

#### BRISQUE Scoring (1-100, Lower = Better)
- 1-30: Excellent technical quality
- 31-50: Good technical quality  
- 51-70: Fair technical quality
- 71-100: Poor technical quality

#### NIMA Scoring (1-10, Higher = Better)
- 8-10: Excellent aesthetic quality
- 6-7.9: Good aesthetic quality
- 4-5.9: Average aesthetic quality
- 1-3.9: Poor aesthetic quality

#### Combined Scoring
The system combines both scores with proper normalization:
1. BRISQUE is inverted: `normalized_brisque = (100 - brisque_score) / 10`
2. Combined score: `40% technical + 60% aesthetic`
3. Final ranking by combined score (higher = better overall)

## Advanced Features

### Custom Weighting
```python
def custom_combined_score(brisque_score, nima_score, tech_weight=0.5, aesthetic_weight=0.5):
    normalized_brisque = (100 - brisque_score) / 10
    return (normalized_brisque * tech_weight) + (nima_score * aesthetic_weight)
```

### Feature Analysis
```python
# Get detailed aesthetic features
features = quality_system.nima_assessor.get_aesthetic_features(image_path)
print(f"Color Harmony: {features['color_harmony']:.2f}")
print(f"Composition: {features['composition']:.2f}")
print(f"Edge Density: {features['edge_density']:.2f}")
```

## Using Pre-trained Models

### For Production NIMA
Replace the simplified model with a pre-trained one:
```python
# Download pre-trained NIMA weights from:
# https://github.com/idealo/image-quality-assessment/releases

nima_assessor = NIMAAssessment(model_path="path/to/nima_weights.h5")
```

### For Production BRISQUE
Use OpenCV's built-in BRISQUE:
```python
import cv2

# Requires brisque model files
score = cv2.quality.QualityBRISQUE_compute(
    image, 
    "brisque_model_live.yml", 
    "brisque_range_live.yml"
)[0]
```

## Web Application
The included web application provides a user-friendly interface:
1. Open `index.html` in a web browser
2. Upload images via drag-and-drop or file selection
3. View real-time analysis results
4. Switch between different ranking modes
5. Export results as CSV

## Troubleshooting

### Common Issues
1. **OpenCV Import Error**: `pip install opencv-python-headless` if GUI issues
2. **TensorFlow Warnings**: Normal for CPU-only inference
3. **Memory Issues**: Process images in batches for large datasets
4. **Model Loading**: Ensure pre-trained weights are in correct format

### Performance Tips
- Use smaller image sizes for faster processing
- Batch process images for efficiency
- Consider using GPU for NIMA if available
- Cache feature extractions for repeated analysis

## File Structure
```
image_quality_system/
├── brisque_implementation.py    # BRISQUE technical assessment
├── nima_implementation.py       # NIMA aesthetic assessment  
├── combined_system.py          # Complete ranking system
├── requirements.txt            # Dependencies
├── README.md                  # This guide
└── web_app/                   # Web interface
    ├── index.html
    ├── style.css
    └── app.js
```
