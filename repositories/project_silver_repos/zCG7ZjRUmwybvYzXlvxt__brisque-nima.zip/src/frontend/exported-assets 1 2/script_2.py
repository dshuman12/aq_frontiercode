# Create a comprehensive example showing the reverse scoring handling

example_usage = """
# Complete Example: Image Quality Assessment with Proper Score Handling
# This example demonstrates how to properly handle BRISQUE's reverse scoring

import numpy as np
import pandas as pd
from pathlib import Path

def demonstrate_scoring_system():
    \"\"\"
    Demonstrate how the scoring system handles reverse BRISQUE scoring
    \"\"\"
    
    print("="*60)
    print("IMAGE QUALITY ASSESSMENT - SCORING DEMONSTRATION")
    print("="*60)
    
    # Sample data showing different quality scenarios
    sample_images = [
        {"name": "excellent_photo.jpg", "brisque": 15.2, "nima": 8.7},
        {"name": "good_photo.jpg", "brisque": 28.4, "nima": 7.1}, 
        {"name": "average_photo.jpg", "brisque": 45.6, "nima": 5.3},
        {"name": "poor_photo.jpg", "brisque": 72.8, "nima": 3.2},
        {"name": "blurry_but_beautiful.jpg", "brisque": 68.1, "nima": 8.1},  # Technical issues but aesthetically pleasing
        {"name": "sharp_but_ugly.jpg", "brisque": 22.3, "nima": 2.8}         # Technically good but poor aesthetics
    ]
    
    print("\\nRAW SCORES:")
    print("-" * 60)
    print(f"{'Image Name':<25} {'BRISQUE':<10} {'NIMA':<8} {'Quality Interpretation'}")
    print("-" * 60)
    
    results = []
    
    for img in sample_images:
        brisque_score = img["brisque"] 
        nima_score = img["nima"]
        
        # BRISQUE interpretation (lower = better)
        if brisque_score < 30:
            brisque_quality = "Excellent"
        elif brisque_score < 50:
            brisque_quality = "Good"
        elif brisque_score < 70:
            brisque_quality = "Fair"
        else:
            brisque_quality = "Poor"
            
        # NIMA interpretation (higher = better)  
        if nima_score >= 8:
            nima_quality = "Excellent"
        elif nima_score >= 6:
            nima_quality = "Good"
        elif nima_score >= 4:
            nima_quality = "Average"
        else:
            nima_quality = "Poor"
            
        print(f"{img['name']:<25} {brisque_score:<10.1f} {nima_score:<8.1f} Tech:{brisque_quality}, Aest:{nima_quality}")
        
        # Calculate normalized and combined scores
        normalized_brisque = (100 - brisque_score) / 10  # Invert and scale to 0-10
        normalized_brisque = max(0, min(10, normalized_brisque))
        
        # Combined score (40% technical, 60% aesthetic)
        combined_score = (normalized_brisque * 0.4) + (nima_score * 0.6)
        
        results.append({
            'name': img['name'],
            'brisque_raw': brisque_score,
            'nima_raw': nima_score,
            'brisque_normalized': normalized_brisque,
            'combined_score': combined_score,
            'brisque_quality': brisque_quality,
            'nima_quality': nima_quality
        })
    
    # Sort by combined score (highest = best)
    results.sort(key=lambda x: x['combined_score'], reverse=True)
    
    print("\\n\\nNORMALIZATION & RANKING:")
    print("-" * 80)
    print(f"{'Rank':<4} {'Image Name':<25} {'BRISQUE':<12} {'NIMA':<8} {'Combined':<10} {'Overall Quality'}")
    print(f"     {'(lower=better)':<25} {'Raw→Norm':<12} {'Raw':<8} {'Score':<10}")
    print("-" * 80)
    
    for i, result in enumerate(results, 1):
        combined = result['combined_score']
        if combined >= 8:
            overall_quality = "Excellent"
        elif combined >= 6:
            overall_quality = "Good" 
        elif combined >= 4:
            overall_quality = "Average"
        else:
            overall_quality = "Poor"
            
        print(f"{i:<4} {result['name']:<25} {result['brisque_raw']:>4.1f}→{result['brisque_normalized']:>4.1f} "
              f"{result['nima_raw']:<8.1f} {result['combined_score']:<10.2f} {overall_quality}")
    
    print("\\n\\nKEY INSIGHTS:")
    print("-" * 60)
    print("1. BRISQUE scores are INVERTED during normalization:")
    print("   - Raw BRISQUE 15.2 → Normalized 8.48 (excellent technical quality)")
    print("   - Raw BRISQUE 72.8 → Normalized 2.72 (poor technical quality)")
    print()
    print("2. NIMA scores are used directly (higher = better aesthetic quality)")
    print()
    print("3. Combined scoring reveals interesting cases:")
    print("   - 'blurry_but_beautiful.jpg' ranks higher than 'sharp_but_ugly.jpg'")
    print("   - This shows the 60% aesthetic weighting in action")
    print()
    print("4. The ranking properly handles the reverse BRISQUE scoring!")
    
    return results

def create_batch_processing_example():
    \"\"\"
    Create a complete example for batch processing images
    \"\"\"
    
    batch_code = '''
# Complete Batch Processing Example
import os
import cv2
import numpy as np
from datetime import datetime

def process_image_folder(folder_path, output_file="quality_assessment_results.csv"):
    """
    Process all images in a folder and save ranked results
    """
    
    # Initialize the assessment system
    quality_system = ImageQualityAssessmentSystem()
    
    # Find all image files
    image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
    image_files = []
    
    for filename in os.listdir(folder_path):
        if Path(filename).suffix.lower() in image_extensions:
            image_files.append(os.path.join(folder_path, filename))
    
    if not image_files:
        print(f"No image files found in {folder_path}")
        return None
        
    print(f"Found {len(image_files)} images to process...")
    
    results = []
    for i, image_path in enumerate(image_files, 1):
        try:
            print(f"Processing {i}/{len(image_files)}: {Path(image_path).name}")
            
            # Calculate scores
            brisque_score = quality_system.brisque_assessor.calculate_brisque_score(image_path)
            nima_score = quality_system.nima_assessor.calculate_nima_score(image_path)
            
            # Handle reverse scoring properly
            normalized_brisque = (100 - brisque_score) / 10
            normalized_brisque = max(0, min(10, normalized_brisque))
            
            # Combined score with proper weighting
            combined_score = (normalized_brisque * 0.4) + (nima_score * 0.6)
            
            results.append({
                'filename': Path(image_path).name,
                'brisque_score': brisque_score,
                'nima_score': nima_score,
                'normalized_brisque': normalized_brisque,
                'combined_score': combined_score,
                'technical_quality': get_brisque_quality_level(brisque_score),
                'aesthetic_quality': get_nima_quality_level(nima_score),
                'overall_quality': get_combined_quality_level(combined_score)
            })
            
        except Exception as e:
            print(f"Error processing {image_path}: {e}")
            continue
    
    # Create DataFrame and rank
    df = pd.DataFrame(results)
    df = df.sort_values('combined_score', ascending=False).reset_index(drop=True)
    df['rank'] = range(1, len(df) + 1)
    
    # Save results
    df.to_csv(output_file, index=False)
    print(f"\\nResults saved to: {output_file}")
    
    # Print summary
    print("\\n" + "="*60)
    print("BATCH PROCESSING RESULTS SUMMARY")
    print("="*60)
    print(f"Total images processed: {len(df)}")
    print(f"Processing timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    print("\\nTop 5 Images:")
    for _, row in df.head().iterrows():
        print(f"{row['rank']:2d}. {row['filename']} (Combined: {row['combined_score']:.2f})")
    
    print("\\nQuality Distribution:")
    quality_counts = df['overall_quality'].value_counts()
    for quality, count in quality_counts.items():
        percentage = (count / len(df)) * 100
        print(f"  {quality}: {count} images ({percentage:.1f}%)")
    
    return df

def get_brisque_quality_level(score):
    """Get quality level for BRISQUE score (lower = better)"""
    if score < 30: return "Excellent"
    elif score < 50: return "Good"  
    elif score < 70: return "Fair"
    else: return "Poor"

def get_nima_quality_level(score):
    """Get quality level for NIMA score (higher = better)"""
    if score >= 8: return "Excellent"
    elif score >= 6: return "Good"
    elif score >= 4: return "Average"  
    else: return "Poor"

def get_combined_quality_level(score):
    """Get quality level for combined score"""
    if score >= 8: return "Excellent"
    elif score >= 6: return "Good"
    elif score >= 4: return "Average"
    else: return "Poor"

# Usage example:
if __name__ == "__main__":
    folder_path = "path/to/your/images"
    results = process_image_folder(folder_path, "my_image_quality_results.csv")
    '''
    
    return batch_code

# Run the demonstration
print("DEMONSTRATING PROPER SCORE HANDLING:")
results = demonstrate_scoring_system()

print("\n\nBATCH PROCESSING CODE:")
print("="*60)
batch_code = create_batch_processing_example()

# Save the complete example
with open('complete_example.py', 'w') as f:
    f.write("# Complete Image Quality Assessment Example\n")
    f.write("# Demonstrates proper handling of BRISQUE reverse scoring\n\n")
    f.write("from combined_system import *\n")
    f.write("import pandas as pd\nfrom pathlib import Path\n\n")
    f.write(batch_code)

print("\nCreated complete_example.py with comprehensive batch processing code")
print("\nSUMMARY: The system properly handles BRISQUE's reverse scoring by:")
print("1. Inverting BRISQUE scores: normalized = (100 - raw_score) / 10")
print("2. Using NIMA scores directly (higher = better)")  
print("3. Combining with proper weights for final ranking")
print("4. Ranking by combined score where HIGHER = BETTER overall quality")
# add FastAPI app skeleton

# add score caching per customer

# add prefect workflow stub
