# Create a comprehensive example showing the reverse scoring handling

def demonstrate_scoring_system():
    """
    Demonstrate how the scoring system handles reverse BRISQUE scoring
    """
    
    print("="*60)
    print("IMAGE QUALITY ASSESSMENT - SCORING DEMONSTRATION")
    print("="*60)
    
    # Sample data showing different quality scenarios
    sample_images = [
        {"name": "excellent_photo.jpg", "brisque": 15.2, "nima": 8.7},
        {"name": "good_photo.jpg", "brisque": 28.4, "nima": 7.1}, 
        {"name": "average_photo.jpg", "brisque": 45.6, "nima": 5.3},
        {"name": "poor_photo.jpg", "brisque": 72.8, "nima": 3.2},
        {"name": "blurry_but_beautiful.jpg", "brisque": 68.1, "nima": 8.1},  # Technical issues but aesthetically pleasing
        {"name": "sharp_but_ugly.jpg", "brisque": 22.3, "nima": 2.8}         # Technically good but poor aesthetics
    ]
    
    print("\nRAW SCORES:")
    print("-" * 60)
    print(f"{'Image Name':<25} {'BRISQUE':<10} {'NIMA':<8} {'Quality Interpretation'}")
    print("-" * 60)
    
    results = []
    
    for img in sample_images:
        brisque_score = img["brisque"] 
        nima_score = img["nima"]
        
        # BRISQUE interpretation (lower = better)
        if brisque_score < 30:
            brisque_quality = "Excellent"
        elif brisque_score < 50:
            brisque_quality = "Good"
        elif brisque_score < 70:
            brisque_quality = "Fair"
        else:
            brisque_quality = "Poor"
            
        # NIMA interpretation (higher = better)  
        if nima_score >= 8:
            nima_quality = "Excellent"
        elif nima_score >= 6:
            nima_quality = "Good"
        elif nima_score >= 4:
            nima_quality = "Average"
        else:
            nima_quality = "Poor"
            
        print(f"{img['name']:<25} {brisque_score:<10.1f} {nima_score:<8.1f} Tech:{brisque_quality}, Aest:{nima_quality}")
        
        # Calculate normalized and combined scores
        normalized_brisque = (100 - brisque_score) / 10  # Invert and scale to 0-10
        normalized_brisque = max(0, min(10, normalized_brisque))
        
        # Combined score (40% technical, 60% aesthetic)
        combined_score = (normalized_brisque * 0.4) + (nima_score * 0.6)
        
        results.append({
            'name': img['name'],
            'brisque_raw': brisque_score,
            'nima_raw': nima_score,
            'brisque_normalized': normalized_brisque,
            'combined_score': combined_score,
            'brisque_quality': brisque_quality,
            'nima_quality': nima_quality
        })
    
    # Sort by combined score (highest = best)
    results.sort(key=lambda x: x['combined_score'], reverse=True)
    
    print("\n\nNORMALIZATION & RANKING:")
    print("-" * 80)
    print(f"{'Rank':<4} {'Image Name':<25} {'BRISQUE':<12} {'NIMA':<8} {'Combined':<10} {'Overall Quality'}")
    print(f"     {'(lower=better)':<25} {'Raw→Norm':<12} {'Raw':<8} {'Score':<10}")
    print("-" * 80)
    
    for i, result in enumerate(results, 1):
        combined = result['combined_score']
        if combined >= 8:
            overall_quality = "Excellent"
        elif combined >= 6:
            overall_quality = "Good" 
        elif combined >= 4:
            overall_quality = "Average"
        else:
            overall_quality = "Poor"
            
        print(f"{i:<4} {result['name']:<25} {result['brisque_raw']:>4.1f}→{result['brisque_normalized']:>4.1f} "
              f"{result['nima_raw']:<8.1f} {result['combined_score']:<10.2f} {overall_quality}")
    
    print("\n\nKEY INSIGHTS:")
    print("-" * 60)
    print("1. BRISQUE scores are INVERTED during normalization:")
    print("   - Raw BRISQUE 15.2 → Normalized 8.48 (excellent technical quality)")
    print("   - Raw BRISQUE 72.8 → Normalized 2.72 (poor technical quality)")
    print()
    print("2. NIMA scores are used directly (higher = better aesthetic quality)")
    print()
    print("3. Combined scoring reveals interesting cases:")
    print("   - 'blurry_but_beautiful.jpg' ranks higher than 'sharp_but_ugly.jpg'")
    print("   - This shows the 60% aesthetic weighting in action")
    print()
    print("4. The ranking properly handles the reverse BRISQUE scoring!")
    
    return results

# Run the demonstration
print("DEMONSTRATING PROPER SCORE HANDLING:")
results = demonstrate_scoring_system()

print("\n" + "="*60)
print("SUMMARY OF REVERSE SCORING HANDLING")  
print("="*60)
print("✓ BRISQUE: Raw scores (1-100) where LOWER = BETTER quality")
print("✓ Normalization: (100 - brisque_score) / 10 to invert to 0-10 scale") 
print("✓ NIMA: Raw scores (1-10) where HIGHER = BETTER quality")
print("✓ Combined: Weighted average where HIGHER = BETTER overall quality")
print("✓ Final ranking: Sorted by combined score in DESCENDING order")

print("\n" + "="*60)
print("IMPLEMENTATION NOTES")
print("="*60)
print("- The web application correctly implements this reverse scoring")
print("- Both Python implementations handle the inversion properly")
print("- Users see intuitive rankings where higher combined scores = better images")
print("- The system is ready for production use with wedding/event photos")
# initial project setup

# add process_prefix endpoint
