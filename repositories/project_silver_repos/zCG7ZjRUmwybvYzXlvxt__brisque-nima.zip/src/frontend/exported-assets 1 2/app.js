class ImageQualityAssessment {
    constructor() {
        this.images = [];
        this.currentRankingMode = 'combined';
        this.analysisProgress = 0;
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const uploadButton = document.getElementById('uploadButton');
        const rankingModes = document.querySelectorAll('input[name="rankingMode"]');

        // Upload button click
        uploadButton.addEventListener('click', (e) => {
            e.stopPropagation();
            fileInput.click();
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFiles(e.target.files);
            }
        });

        // Drag and drop events
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                this.handleFiles(e.dataTransfer.files);
            }
        });

        // Upload area click (but not the button)
        uploadArea.addEventListener('click', (e) => {
            if (e.target === uploadArea || e.target.closest('.upload-area__content')) {
                if (e.target !== uploadButton) {
                    fileInput.click();
                }
            }
        });

        // Ranking mode changes
        rankingModes.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.currentRankingMode = e.target.value;
                this.updateRanking();
            });
        });
    }

    async handleFiles(files) {
        const validFiles = Array.from(files).filter(file => 
            file.type.startsWith('image/') && file.size < 10 * 1024 * 1024 // 10MB limit
        );

        if (validFiles.length === 0) {
            alert('Please select valid image files (JPG, PNG, WebP) under 10MB.');
            return;
        }

        // Show progress and controls
        document.getElementById('progressContainer').classList.remove('hidden');
        document.getElementById('controls').classList.remove('hidden');
        document.getElementById('resultsSection').classList.remove('hidden');

        this.analysisProgress = 0;
        this.updateProgress();

        // Process each file
        for (let i = 0; i < validFiles.length; i++) {
            await this.processImage(validFiles[i], i, validFiles.length);
        }

        // Hide progress bar when complete
        setTimeout(() => {
            document.getElementById('progressContainer').classList.add('hidden');
        }, 1000);
    }

    async processImage(file, index, total) {
        try {
            const imageData = await this.loadImage(file);
            
            // Add to images array with initial data
            const imageObj = {
                id: Date.now() + index + Math.random() * 1000,
                filename: file.name,
                thumbnail: imageData.dataUrl,
                canvas: imageData.canvas,
                analysisComplete: false,
                brisqueScore: 0,
                nimaScore: 0,
                combinedScore: 0,
                rank: 0
            };

            this.images.push(imageObj);
            this.renderImageCard(imageObj);

            // Analyze image quality
            await this.analyzeImage(imageObj);
            
            // Update progress
            this.analysisProgress = ((index + 1) / total) * 100;
            this.updateProgress();
            
            // Update ranking after each analysis
            this.updateRanking();

        } catch (error) {
            console.error('Error processing image:', error);
        }
    }

    loadImage(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    
                    // Resize image for processing (max 800px)
                    const maxSize = 800;
                    let { width, height } = img;
                    
                    if (width > height) {
                        if (width > maxSize) {
                            height = (height * maxSize) / width;
                            width = maxSize;
                        }
                    } else {
                        if (height > maxSize) {
                            width = (width * maxSize) / height;
                            height = maxSize;
                        }
                    }
                    
                    canvas.width = width;
                    canvas.height = height;
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    resolve({
                        canvas: canvas,
                        dataUrl: e.target.result,
                        width: width,
                        height: height
                    });
                };
                img.onerror = reject;
                img.src = e.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    async analyzeImage(imageObj) {
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1200));

        const canvas = imageObj.canvas;
        const ctx = canvas.getContext('2d');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageData.data;

        // Calculate BRISQUE score (simulated)
        const brisqueScore = this.calculateBRISQUEScore(pixels, canvas.width, canvas.height);
        
        // Calculate NIMA score (simulated)
        const nimaScore = this.calculateNIMAScore(pixels, canvas.width, canvas.height);
        
        // Calculate combined score
        const combinedScore = this.calculateCombinedScore(brisqueScore, nimaScore);

        // Update image object
        imageObj.brisqueScore = brisqueScore;
        imageObj.nimaScore = nimaScore;
        imageObj.combinedScore = combinedScore;
        imageObj.analysisComplete = true;

        // Update the card display
        this.updateImageCard(imageObj);
    }

    calculateBRISQUEScore(pixels, width, height) {
        // Simulate BRISQUE scoring using image analysis
        let brightness = 0;
        let contrast = 0;
        let sharpness = 0;

        // Calculate brightness and prepare for contrast
        const brightnessValues = [];
        for (let i = 0; i < pixels.length; i += 4) {
            const r = pixels[i];
            const g = pixels[i + 1];
            const b = pixels[i + 2];
            const gray = 0.299 * r + 0.587 * g + 0.114 * b;
            brightness += gray;
            brightnessValues.push(gray);
        }
        brightness /= brightnessValues.length;

        // Calculate contrast (standard deviation of brightness)
        let contrastSum = 0;
        for (const value of brightnessValues) {
            contrastSum += Math.pow(value - brightness, 2);
        }
        contrast = Math.sqrt(contrastSum / brightnessValues.length);

        // Estimate sharpness using edge detection
        let sharpnessSum = 0;
        let count = 0;
        for (let y = 1; y < height - 1; y++) {
            for (let x = 1; x < width - 1; x++) {
                const idx = (y * width + x) * 4;
                const center = pixels[idx] * 0.299 + pixels[idx + 1] * 0.587 + pixels[idx + 2] * 0.114;
                
                const neighbors = [
                    pixels[idx - 4] * 0.299 + pixels[idx - 3] * 0.587 + pixels[idx - 2] * 0.114,
                    pixels[idx + 4] * 0.299 + pixels[idx + 5] * 0.587 + pixels[idx + 6] * 0.114,
                    pixels[idx - width * 4] * 0.299 + pixels[idx - width * 4 + 1] * 0.587 + pixels[idx - width * 4 + 2] * 0.114,
                    pixels[idx + width * 4] * 0.299 + pixels[idx + width * 4 + 1] * 0.587 + pixels[idx + width * 4 + 2] * 0.114
                ];
                
                const laplacian = Math.abs(4 * center - neighbors.reduce((a, b) => a + b, 0));
                sharpnessSum += laplacian;
                count++;
            }
        }
        sharpness = count > 0 ? sharpnessSum / count : 0;

        // Combine factors into BRISQUE-like score (1-100, lower = better)
        let score = 15; // Base score
        
        // Sharpness factor (higher sharpness = better, so lower score)
        score += Math.max(0, (30 - sharpness / 8)) * 0.4;
        
        // Contrast factor (moderate contrast is good)
        const optimalContrast = 45;
        score += Math.abs(contrast - optimalContrast) * 0.6;
        
        // Brightness factor (closer to 128 is better)
        score += Math.abs(brightness - 128) * 0.3;
        
        // Add some controlled randomness
        score += (Math.random() - 0.5) * 15;

        return Math.max(1, Math.min(100, Math.round(score * 10) / 10));
    }

    calculateNIMAScore(pixels, width, height) {
        // Simulate NIMA scoring using aesthetic factors
        let colorHarmony = 0;
        let composition = 0;
        let edgeDensity = 0;

        // Calculate color harmony
        const colors = { r: 0, g: 0, b: 0 };
        let colorVariance = 0;
        
        for (let i = 0; i < pixels.length; i += 4) {
            colors.r += pixels[i];
            colors.g += pixels[i + 1];
            colors.b += pixels[i + 2];
        }
        
        const numPixels = pixels.length / 4;
        colors.r /= numPixels;
        colors.g /= numPixels;
        colors.b /= numPixels;

        // Color variance calculation
        for (let i = 0; i < pixels.length; i += 16) { // Sample every 4th pixel
            colorVariance += Math.pow(pixels[i] - colors.r, 2) + 
                           Math.pow(pixels[i + 1] - colors.g, 2) + 
                           Math.pow(pixels[i + 2] - colors.b, 2);
        }
        colorVariance = Math.sqrt(colorVariance / (numPixels / 4));
        colorHarmony = Math.min(10, Math.max(1, colorVariance / 20));

        // Composition analysis (center focus)
        const centerX = width / 2;
        const centerY = height / 2;
        let centerWeight = 0;
        const sampleSize = Math.min(500, numPixels);
        
        for (let i = 0; i < sampleSize; i++) {
            const idx = Math.floor(Math.random() * (pixels.length / 4)) * 4;
            const x = (idx / 4) % width;
            const y = Math.floor((idx / 4) / width);
            
            const distFromCenter = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
            const maxDist = Math.sqrt(centerX * centerX + centerY * centerY);
            centerWeight += 1 - (distFromCenter / maxDist);
        }
        composition = (centerWeight / sampleSize) * 10;

        // Edge density
        let edges = 0;
        for (let y = 1; y < height - 1; y += 5) {
            for (let x = 1; x < width - 1; x += 5) {
                const idx = (y * width + x) * 4;
                const current = pixels[idx] * 0.299 + pixels[idx + 1] * 0.587 + pixels[idx + 2] * 0.114;
                const right = pixels[idx + 4] * 0.299 + pixels[idx + 5] * 0.587 + pixels[idx + 6] * 0.114;
                const down = pixels[idx + width * 4] * 0.299 + pixels[idx + width * 4 + 1] * 0.587 + pixels[idx + width * 4 + 2] * 0.114;
                
                edges += Math.abs(current - right) + Math.abs(current - down);
            }
        }
        edgeDensity = Math.min(10, Math.max(1, edges / (width * height / 200)));

        // Combine factors into NIMA-like score (1-10, higher = better)
        let score = (colorHarmony * 0.3 + composition * 0.4 + edgeDensity * 0.3);
        
        // Add controlled randomness and ensure reasonable range
        score += (Math.random() - 0.5) * 2;
        score = Math.max(1, Math.min(10, score));

        return Math.round(score * 10) / 10;
    }

    calculateCombinedScore(brisqueScore, nimaScore) {
        // Normalize BRISQUE (invert and scale to 0-10)
        const normalizedBRISQUE = (100 - brisqueScore) / 10;
        
        // Combined score: BRISQUE 40% + NIMA 60%
        const combined = (normalizedBRISQUE * 0.4) + (nimaScore * 0.6);
        
        return Math.round(combined * 10) / 10;
    }

    getScoreClass(score, type) {
        if (type === 'brisque') {
            // Lower is better for BRISQUE
            if (score <= 25) return 'score--excellent';
            if (score <= 50) return 'score--good';
            if (score <= 75) return 'score--fair';
            return 'score--poor';
        } else {
            // Higher is better for NIMA and combined
            if (score >= 8) return 'score--excellent';
            if (score >= 6) return 'score--good';
            if (score >= 4) return 'score--fair';
            return 'score--poor';
        }
    }

    updateRanking() {
        if (this.images.length === 0) return;

        // Sort images based on current ranking mode
        let sortedImages = [...this.images.filter(img => img.analysisComplete)];
        
        switch (this.currentRankingMode) {
            case 'brisque':
                // Lower BRISQUE is better
                sortedImages.sort((a, b) => a.brisqueScore - b.brisqueScore);
                break;
            case 'nima':
                // Higher NIMA is better
                sortedImages.sort((a, b) => b.nimaScore - a.nimaScore);
                break;
            case 'combined':
            default:
                // Higher combined score is better
                sortedImages.sort((a, b) => b.combinedScore - a.combinedScore);
                break;
        }

        // Update ranks
        sortedImages.forEach((img, index) => {
            img.rank = index + 1;
        });

        // Re-render all cards
        this.renderAllCards();
    }

    renderImageCard(imageObj) {
        const resultsGrid = document.getElementById('resultsGrid');
        const cardElement = document.createElement('div');
        cardElement.className = 'image-card';
        cardElement.id = `card-${imageObj.id}`;

        cardElement.innerHTML = `
            <div class="image-card__rank">${imageObj.rank || '—'}</div>
            <img src="${imageObj.thumbnail}" alt="${imageObj.filename}" class="image-card__thumbnail">
            <div class="image-card__content">
                <div class="image-card__filename">${imageObj.filename}</div>
                ${imageObj.analysisComplete ? this.getScoreHTML(imageObj) : this.getAnalyzingHTML()}
            </div>
        `;

        resultsGrid.appendChild(cardElement);
    }

    updateImageCard(imageObj) {
        const cardElement = document.getElementById(`card-${imageObj.id}`);
        if (cardElement) {
            const rankElement = cardElement.querySelector('.image-card__rank');
            const content = cardElement.querySelector('.image-card__content');
            
            rankElement.textContent = imageObj.rank || '—';
            content.innerHTML = `
                <div class="image-card__filename">${imageObj.filename}</div>
                ${this.getScoreHTML(imageObj)}
            `;
        }
    }

    getAnalyzingHTML() {
        return `
            <div class="analysis-status">
                <div class="spinner"></div>
                Analyzing...
            </div>
        `;
    }

    getScoreHTML(imageObj) {
        return `
            <div class="image-card__scores">
                <div class="score-item">
                    <div class="score-item__label">BRISQUE</div>
                    <div class="score-item__value ${this.getScoreClass(imageObj.brisqueScore, 'brisque')}">${imageObj.brisqueScore}</div>
                </div>
                <div class="score-item">
                    <div class="score-item__label">NIMA</div>
                    <div class="score-item__value ${this.getScoreClass(imageObj.nimaScore, 'nima')}">${imageObj.nimaScore}</div>
                </div>
            </div>
            <div class="combined-score">
                <div class="combined-score__label">Combined Score</div>
                <div class="combined-score__value ${this.getScoreClass(imageObj.combinedScore, 'combined')}">${imageObj.combinedScore}</div>
            </div>
        `;
    }

    renderAllCards() {
        const resultsGrid = document.getElementById('resultsGrid');
        resultsGrid.innerHTML = '';
        
        // Sort by current ranking for display
        let sortedImages = [...this.images.filter(img => img.analysisComplete)];
        switch (this.currentRankingMode) {
            case 'brisque':
                sortedImages.sort((a, b) => a.brisqueScore - b.brisqueScore);
                break;
            case 'nima':
                sortedImages.sort((a, b) => b.nimaScore - a.nimaScore);
                break;
            case 'combined':
            default:
                sortedImages.sort((a, b) => b.combinedScore - a.combinedScore);
                break;
        }

        // Update ranks and render
        sortedImages.forEach((imageObj, index) => {
            imageObj.rank = index + 1;
            this.renderImageCard(imageObj);
        });

        // Also render any still-analyzing images
        const analyzingImages = this.images.filter(img => !img.analysisComplete);
        analyzingImages.forEach(imageObj => {
            this.renderImageCard(imageObj);
        });
    }

    updateProgress() {
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        if (progressFill && progressText) {
            progressFill.style.width = `${this.analysisProgress}%`;
            
            if (this.analysisProgress >= 100) {
                progressText.textContent = 'Analysis complete!';
            } else {
                progressText.textContent = `Analyzing images... ${Math.round(this.analysisProgress)}%`;
            }
        }
    }
}

// Global functions for UI interactions
function showScoringInfo() {
    const modal = document.getElementById('scoringModal');
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function closeScoringInfo() {
    const modal = document.getElementById('scoringModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

function exportResults() {
    const app = window.imageApp;
    if (!app || app.images.length === 0) {
        alert('No images to export');
        return;
    }

    // Create CSV content
    const headers = ['Rank', 'Filename', 'BRISQUE Score', 'NIMA Score', 'Combined Score'];
    let csvContent = headers.join(',') + '\n';

    // Sort by current ranking mode
    let sortedImages = [...app.images.filter(img => img.analysisComplete)];
    switch (app.currentRankingMode) {
        case 'brisque':
            sortedImages.sort((a, b) => a.brisqueScore - b.brisqueScore);
            break;
        case 'nima':
            sortedImages.sort((a, b) => b.nimaScore - a.nimaScore);
            break;
        case 'combined':
        default:
            sortedImages.sort((a, b) => b.combinedScore - a.combinedScore);
            break;
    }

    sortedImages.forEach((img, index) => {
        const row = [
            index + 1,
            `"${img.filename}"`, // Wrap filename in quotes to handle commas
            img.brisqueScore,
            img.nimaScore,
            img.combinedScore
        ];
        csvContent += row.join(',') + '\n';
    });

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `image_quality_results_${new Date().getTime()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

function clearAll() {
    if (confirm('Are you sure you want to clear all images and results?')) {
        const app = window.imageApp;
        if (app) {
            app.images = [];
            app.analysisProgress = 0;
            
            document.getElementById('resultsGrid').innerHTML = '';
            document.getElementById('controls').classList.add('hidden');
            document.getElementById('resultsSection').classList.add('hidden');
            document.getElementById('progressContainer').classList.add('hidden');
            
            // Reset file input
            document.getElementById('fileInput').value = '';
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.imageApp = new ImageQualityAssessment();
});