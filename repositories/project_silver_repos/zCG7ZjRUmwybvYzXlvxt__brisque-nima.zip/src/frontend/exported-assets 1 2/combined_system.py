
# Combined Image Quality Assessment System
import os
import pandas as pd
from pathlib import Path

class ImageQualityAssessmentSystem:
    def __init__(self):
        self.brisque_assessor = BRISQUEAssessment()
        self.nima_assessor = NIMAAssessment()

    def analyze_images(self, image_paths, output_csv=None):
        """
        Analyze multiple images and return ranked results
        """
        results = []

        for image_path in image_paths:
            try:
                # Calculate BRISQUE score (lower = better, 1-100)
                brisque_score = self.brisque_assessor.calculate_brisque_score(image_path)

                # Calculate NIMA score (higher = better, 1-10)
                nima_score = self.nima_assessor.calculate_nima_score(image_path)

                # Calculate combined score
                combined_score = self._calculate_combined_score(brisque_score, nima_score)

                results.append({
                    'filename': Path(image_path).name,
                    'filepath': image_path,
                    'brisque_score': brisque_score,
                    'nima_score': nima_score,
                    'combined_score': combined_score,
                    'brisque_quality': self._get_quality_level_brisque(brisque_score),
                    'nima_quality': self._get_quality_level_nima(nima_score),
                    'overall_quality': self._get_quality_level_combined(combined_score)
                })

            except Exception as e:
                print(f"Error processing {image_path}: {e}")
                continue

        # Convert to DataFrame and sort by combined score
        df = pd.DataFrame(results)
        df = df.sort_values('combined_score', ascending=False).reset_index(drop=True)
        df['rank'] = range(1, len(df) + 1)

        if output_csv:
            df.to_csv(output_csv, index=False)
            print(f"Results saved to {output_csv}")

        return df

    def _calculate_combined_score(self, brisque_score, nima_score):
        """
        Calculate combined score handling reverse scoring of BRISQUE
        """
        # Normalize BRISQUE score (invert since lower is better)
        # Convert from 1-100 scale to 0-10 scale, inverted
        normalized_brisque = (100 - brisque_score) / 10
        normalized_brisque = max(0, min(10, normalized_brisque))

        # NIMA is already on 1-10 scale where higher is better

        # Weighted combination (40% technical, 60% aesthetic)
        combined = (normalized_brisque * 0.4) + (nima_score * 0.6)

        return combined

    def _get_quality_level_brisque(self, score):
        """Get quality level for BRISQUE score"""
        if score < 30:
            return "Excellent"
        elif score < 50:
            return "Good"
        elif score < 70:
            return "Fair"
        else:
            return "Poor"

    def _get_quality_level_nima(self, score):
        """Get quality level for NIMA score"""
        if score >= 8:
            return "Excellent"
        elif score >= 6:
            return "Good"
        elif score >= 4:
            return "Average"
        else:
            return "Poor"

    def _get_quality_level_combined(self, score):
        """Get quality level for combined score"""
        if score >= 8:
            return "Excellent"
        elif score >= 6:
            return "Good"
        elif score >= 4:
            return "Average"
        else:
            return "Poor"

    def print_ranking_summary(self, results_df):
        """Print a summary of the ranking results"""
        print("\n" + "="*60)
        print("IMAGE QUALITY ASSESSMENT RESULTS")
        print("="*60)
        print(f"Total images analyzed: {len(results_df)}")
        print()

        print("TOP 5 IMAGES:")
        print("-" * 60)
        for i, row in results_df.head().iterrows():
            print(f"{row['rank']:2d}. {row['filename']}")
            print(f"    Combined Score: {row['combined_score']:.2f} ({row['overall_quality']})")
            print(f"    BRISQUE: {row['brisque_score']:.1f} ({row['brisque_quality']})")
            print(f"    NIMA: {row['nima_score']:.2f} ({row['nima_quality']})")
            print()

# Usage example
def main():
    # Example usage
    image_folder = "path/to/your/images"
    image_paths = [os.path.join(image_folder, f) for f in os.listdir(image_folder) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]

    # Initialize assessment system
    quality_system = ImageQualityAssessmentSystem()

    # Analyze images
    results = quality_system.analyze_images(image_paths, "image_quality_results.csv")

    # Print summary
    quality_system.print_ranking_summary(results)

    return results

if __name__ == "__main__":
    results = main()

# add percentile calculation

# fix timezone handling
