#!/usr/bin/env python3
"""
Sample usage examples for BRISQUE + NIMA Image Quality Assessment API
"""

import requests
import json
from pathlib import Path

# API Configuration
API_BASE_URL = "http://localhost:8080"
SCORE_ENDPOINT = f"{API_BASE_URL}/score_files"

def score_single_image(image_path):
    """Score a single image file."""
    print(f"Scoring single image: {image_path}")
    
    with open(image_path, 'rb') as f:
        files = {'files': (image_path.name, f, 'image/jpeg')}
        response = requests.post(SCORE_ENDPOINT, files=files)
    
    if response.status_code == 200:
        data = response.json()
        result = data['results'][0]
        print(f"  BRISQUE: {result['brisque_score']:.2f}")
        print(f"  NIMA: {result['nima_aesthetic']:.2f}")
        return result
    else:
        print(f"  Error: {response.status_code} - {response.text}")
        return None

def score_multiple_images(image_paths):
    """Score multiple images in a single request."""
    print(f"Scoring {len(image_paths)} images...")
    
    files = []
    for path in image_paths:
        files.append(('files', (path.name, open(path, 'rb'), 'image/jpeg')))
    
    try:
        response = requests.post(SCORE_ENDPOINT, files=files)
        
        if response.status_code == 200:
            data = response.json()
            print(f"Successfully scored {data['count']} images:")
            
            for i, result in enumerate(data['results']):
                print(f"  {image_paths[i].name}:")
                print(f"    BRISQUE: {result['brisque_score']:.2f}")
                print(f"    NIMA: {result['nima_aesthetic']:.2f}")
            
            return data['results']
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None
    
    finally:
        # Close all opened files
        for _, (_, file_obj, _) in files:
            file_obj.close()

def batch_process_directory(directory_path, output_file=None):
    """Process all images in a directory and optionally save results."""
    directory = Path(directory_path)
    image_extensions = {'.jpg', '.jpeg', '.png', '.webp'}
    
    image_files = [
        f for f in directory.iterdir() 
        if f.is_file() and f.suffix.lower() in image_extensions
    ]
    
    if not image_files:
        print(f"No images found in {directory}")
        return
    
    print(f"Found {len(image_files)} images in {directory}")
    
    # Process in batches of 10 to avoid overwhelming the server
    batch_size = 10
    all_results = []
    
    for i in range(0, len(image_files), batch_size):
        batch = image_files[i:i + batch_size]
        print(f"\nProcessing batch {i//batch_size + 1}/{(len(image_files)-1)//batch_size + 1}")
        
        results = score_multiple_images(batch)
        if results:
            # Add filename to results
            for j, result in enumerate(results):
                result['filename'] = batch[j].name
            all_results.extend(results)
    
    # Save results if output file specified
    if output_file and all_results:
        with open(output_file, 'w') as f:
            json.dump(all_results, f, indent=2)
        print(f"\nResults saved to {output_file}")
    
    return all_results

def find_best_images(results, metric='combined', top_n=5):
    """Find the best images based on specified metric."""
    if metric == 'brisque':
        # Lower BRISQUE is better
        sorted_results = sorted(results, key=lambda x: x['brisque_score'])
    elif metric == 'nima':
        # Higher NIMA is better
        sorted_results = sorted(results, key=lambda x: x['nima_aesthetic'], reverse=True)
    else:  # combined
        # Calculate combined score: (100 - BRISQUE) / 10 * 0.4 + NIMA * 0.6
        for result in results:
            combined = ((100 - result['brisque_score']) / 10 * 0.4) + (result['nima_aesthetic'] * 0.6)
            result['combined_score'] = combined
        sorted_results = sorted(results, key=lambda x: x['combined_score'], reverse=True)
    
    print(f"\nTop {top_n} images by {metric}:")
    for i, result in enumerate(sorted_results[:top_n]):
        filename = result.get('filename', result.get('file_path', 'Unknown'))
        print(f"  {i+1}. {filename}")
        print(f"     BRISQUE: {result['brisque_score']:.2f}")
        print(f"     NIMA: {result['nima_aesthetic']:.2f}")
        if 'combined_score' in result:
            print(f"     Combined: {result['combined_score']:.2f}")
    
    return sorted_results[:top_n]

def check_api_health():
    """Check if the API is running and healthy."""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ API is healthy and running")
            return True
        else:
            print(f"❌ API health check failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Cannot connect to API: {e}")
        return False

def main():
    """Main example function."""
    print("BRISQUE + NIMA Image Quality Assessment - Usage Examples")
    print("=" * 60)
    
    # Check API health first
    if not check_api_health():
        print("Please start the API server first:")
        print("  uvicorn src.backend.app.api:app --host 0.0.0.0 --port 8080")
        return
    
    # Example 1: Score a single image (you'll need to provide a real image path)
    # single_image_path = Path("path/to/your/image.jpg")
    # if single_image_path.exists():
    #     score_single_image(single_image_path)
    
    # Example 2: Score multiple images
    # image_paths = [Path("image1.jpg"), Path("image2.jpg")]
    # score_multiple_images(image_paths)
    
    # Example 3: Process entire directory
    # results = batch_process_directory("path/to/image/directory", "results.json")
    # if results:
    #     find_best_images(results, metric='combined', top_n=3)
    
    print("\nTo use these examples:")
    print("1. Uncomment the example code above")
    print("2. Replace paths with your actual image files/directories")
    print("3. Run: python examples/sample_usage.py")

if __name__ == "__main__":
    main()

# improve logging

# add markdown generation

# fix celery broker config
