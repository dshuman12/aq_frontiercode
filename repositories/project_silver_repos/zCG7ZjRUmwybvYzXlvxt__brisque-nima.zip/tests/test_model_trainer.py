"""Tests for model_trainer module."""
import math
import pytest
import numpy as np

from src.backend.app.model_trainer import (
    LinearLayer,
    ReLULayer,
    BatchNormLayer,
    DropoutLayer,
    MSELoss,
    MAELoss,
    HuberLoss,
    AdamOptimizer,
    SGDOptimizer,
    QualityMLP,
    TrainConfig,
    train,
    evaluate,
    CrossValidator,
    FeatureScaler,
)


def make_regression_data(n: int = 100, d: int = 20, seed: int = 42):
    rng = np.random.default_rng(seed)
    X = rng.normal(0.0, 1.0, (n, d)).astype(np.float32)
    w = rng.normal(0.0, 1.0, d).astype(np.float32)
    y = X @ w + rng.normal(0.0, 0.1, n).astype(np.float32)
    return X, y


class TestLinearLayer:
    def test_forward_shape(self):
        layer = LinearLayer(10, 5)
        x = np.ones((4, 10), dtype=np.float32)
        out = layer.forward(x)
        assert out.shape == (4, 5)

    def test_backward_grad_shape(self):
        layer = LinearLayer(10, 5)
        x = np.ones((4, 10), dtype=np.float32)
        layer.forward(x)
        grad = np.ones((4, 5), dtype=np.float32)
        dx = layer.backward(grad)
        assert dx.shape == (4, 10)

    def test_dW_shape(self):
        layer = LinearLayer(10, 5)
        x = np.ones((4, 10), dtype=np.float32)
        layer.forward(x)
        layer.backward(np.ones((4, 5), dtype=np.float32))
        assert layer.dW.shape == (10, 5)

    def test_db_shape(self):
        layer = LinearLayer(10, 5)
        x = np.ones((4, 10), dtype=np.float32)
        layer.forward(x)
        layer.backward(np.ones((4, 5), dtype=np.float32))
        assert layer.db.shape == (5,)

    def test_no_bias(self):
        layer = LinearLayer(10, 5, bias=False)
        assert layer.b is None
        x = np.ones((4, 10), dtype=np.float32)
        out = layer.forward(x)
        assert out.shape == (4, 5)

    def test_backward_before_forward_raises(self):
        layer = LinearLayer(4, 2)
        with pytest.raises(RuntimeError):
            layer.backward(np.ones((2, 2), dtype=np.float32))

    def test_parameters_returns_W_and_b(self):
        layer = LinearLayer(4, 2)
        params = layer.parameters()
        assert len(params) == 2
        assert params[0].shape == (4, 2)
        assert params[1].shape == (2,)


class TestReLULayer:
    def test_forward_zeros_negative(self):
        layer = ReLULayer()
        x = np.array([[-1.0, 2.0, -0.5, 3.0]], dtype=np.float32)
        out = layer.forward(x)
        assert out[0, 0] == 0.0
        assert out[0, 1] == 2.0

    def test_backward_masks_gradient(self):
        layer = ReLULayer()
        x = np.array([[1.0, -1.0, 2.0]], dtype=np.float32)
        layer.forward(x)
        grad = np.ones((1, 3), dtype=np.float32)
        dx = layer.backward(grad)
        assert dx[0, 0] == 1.0
        assert dx[0, 1] == 0.0
        assert dx[0, 2] == 1.0

    def test_backward_before_forward_raises(self):
        layer = ReLULayer()
        with pytest.raises(RuntimeError):
            layer.backward(np.ones((2, 4), dtype=np.float32))


class TestBatchNormLayer:
    def test_forward_shape(self):
        bn = BatchNormLayer(8)
        x = np.random.randn(16, 8).astype(np.float32)
        out = bn.forward(x)
        assert out.shape == (16, 8)

    def test_forward_near_zero_mean(self):
        bn = BatchNormLayer(4)
        x = np.random.randn(32, 4).astype(np.float32)
        out = bn.forward(x)
        assert abs(out.mean()) < 0.1

    def test_backward_shape(self):
        bn = BatchNormLayer(4)
        x = np.random.randn(8, 4).astype(np.float32)
        bn.forward(x)
        dx = bn.backward(np.ones((8, 4), dtype=np.float32))
        assert dx.shape == (8, 4)

    def test_eval_mode_uses_running_stats(self):
        bn = BatchNormLayer(4)
        x = np.random.randn(16, 4).astype(np.float32)
        bn.forward(x)
        bn.training = False
        out = bn.forward(np.random.randn(2, 4).astype(np.float32))
        assert out.shape == (2, 4)


class TestDropoutLayer:
    def test_training_zeros_some_activations(self):
        layer = DropoutLayer(p=0.5, seed=0)
        x = np.ones((100, 10), dtype=np.float32)
        out = layer.forward(x)
        zeros = (out == 0.0).sum()
        assert zeros > 0

    def test_eval_mode_no_dropout(self):
        layer = DropoutLayer(p=0.9, seed=0)
        layer.training = False
        x = np.ones((10, 10), dtype=np.float32)
        out = layer.forward(x)
        np.testing.assert_array_equal(out, x)

    def test_backward_shape(self):
        layer = DropoutLayer(p=0.3, seed=1)
        x = np.ones((8, 4), dtype=np.float32)
        layer.forward(x)
        dx = layer.backward(np.ones((8, 4), dtype=np.float32))
        assert dx.shape == (8, 4)


class TestLossFunctions:
    def test_mse_forward(self):
        loss_fn = MSELoss()
        preds = np.array([[2.0], [4.0]], dtype=np.float32)
        targets = np.array([[1.0], [3.0]], dtype=np.float32)
        val = loss_fn.forward(preds, targets)
        assert abs(val - 1.0) < 1e-5

    def test_mse_backward_shape(self):
        loss_fn = MSELoss()
        preds = np.ones((8, 1), dtype=np.float32)
        targets = np.zeros((8, 1), dtype=np.float32)
        loss_fn.forward(preds, targets)
        grad = loss_fn.backward()
        assert grad.shape == (8, 1)

    def test_mae_forward(self):
        loss_fn = MAELoss()
        preds = np.array([[3.0], [5.0]], dtype=np.float32)
        targets = np.array([[1.0], [2.0]], dtype=np.float32)
        val = loss_fn.forward(preds, targets)
        assert abs(val - 2.5) < 1e-5

    def test_huber_quadratic_near_zero(self):
        loss_fn = HuberLoss(delta=1.0)
        preds = np.array([[1.5]], dtype=np.float32)
        targets = np.array([[1.0]], dtype=np.float32)
        val = loss_fn.forward(preds, targets)
        expected = 0.5 * 0.25
        assert abs(val - expected) < 1e-5

    def test_huber_linear_far(self):
        loss_fn = HuberLoss(delta=1.0)
        preds = np.array([[5.0]], dtype=np.float32)
        targets = np.array([[0.0]], dtype=np.float32)
        val = loss_fn.forward(preds, targets)
        expected = 1.0 * (5.0 - 0.5)
        assert abs(val - expected) < 1e-4


class TestOptimizers:
    def test_adam_reduces_loss(self):
        X, y = make_regression_data(50, 5)
        model = QualityMLP(5, [16], seed=0)
        config = TrainConfig(epochs=20, learning_rate=0.01, optimizer="adam")
        result = train(model, X, y, config)
        first_loss = result.history[0].train_loss
        last_loss = result.history[-1].train_loss
        assert last_loss < first_loss

    def test_sgd_step_updates_params(self):
        params = [np.array([1.0, 2.0, 3.0], dtype=np.float32)]
        opt = SGDOptimizer(params, lr=0.1, momentum=0.0)
        grads = [np.ones(3, dtype=np.float32)]
        opt.step(grads)
        assert params[0][0] < 1.0

    def test_adam_step_grad_norm_positive(self):
        params = [np.array([1.0, 2.0], dtype=np.float32)]
        opt = AdamOptimizer(params, lr=0.01)
        grads = [np.ones(2, dtype=np.float32)]
        norm = opt.step(grads)
        assert norm > 0

    def test_none_gradient_skipped(self):
        params = [np.array([1.0], dtype=np.float32), np.array([2.0], dtype=np.float32)]
        opt = SGDOptimizer(params, lr=0.1)
        grads = [None, np.ones(1, dtype=np.float32)]
        opt.step(grads)
        assert params[0][0] == 1.0
        assert params[1][0] < 2.0


class TestQualityMLP:
    def test_forward_output_shape(self):
        model = QualityMLP(20, [64, 32])
        x = np.random.randn(8, 20).astype(np.float32)
        out = model.forward(x)
        assert out.shape == (8, 1)

    def test_predict_output_1d(self):
        model = QualityMLP(10, [32])
        x = np.random.randn(5, 10).astype(np.float32)
        preds = model.predict(x)
        assert preds.shape == (5,)

    def test_train_and_evaluate(self):
        X, y = make_regression_data(100, 10)
        model = QualityMLP(10, [32, 16], seed=0)
        config = TrainConfig(epochs=10, learning_rate=0.005)
        result = train(model, X[:80], y[:80], config, X[80:], y[80:])
        metrics = evaluate(model, X[80:], y[80:])
        assert "mse" in metrics
        assert "r2" in metrics
        assert metrics["mse"] >= 0

    def test_eval_mode_does_not_update_state(self):
        model = QualityMLP(10, [32], dropout=0.5)
        x = np.random.randn(4, 10).astype(np.float32)
        model.eval_mode()
        out1 = model.forward(x)
        out2 = model.forward(x)
        np.testing.assert_allclose(out1, out2)

    def test_with_batchnorm(self):
        model = QualityMLP(10, [32], use_batchnorm=True, seed=0)
        x = np.random.randn(8, 10).astype(np.float32)
        out = model.forward(x)
        assert out.shape == (8, 1)


class TestTrainFunction:
    def test_early_stopping(self):
        X, y = make_regression_data(80, 15)
        model = QualityMLP(15, [32], seed=0)
        config = TrainConfig(epochs=100, early_stopping_patience=3, learning_rate=0.001)
        result = train(model, X[:60], y[:60], config, X[60:], y[60:])
        assert result.total_epochs <= 100

    def test_history_populated(self):
        X, y = make_regression_data(50, 8)
        model = QualityMLP(8, [16])
        config = TrainConfig(epochs=5)
        result = train(model, X, y, config)
        assert len(result.history) == 5
        for log in result.history:
            assert log.train_loss >= 0

    def test_no_val_set(self):
        X, y = make_regression_data(50, 8)
        model = QualityMLP(8, [16])
        config = TrainConfig(epochs=3)
        result = train(model, X, y, config)
        assert result.best_val_loss == float("inf")


class TestCrossValidator:
    def test_k_fold_results(self):
        X, y = make_regression_data(100, 10)
        cv = CrossValidator(k=3, config=TrainConfig(epochs=5))
        results = cv.run(X, y, input_dim=10, hidden_dims=[16])
        assert "mse" in results
        assert len(results["mse"]["folds"]) == 3

    def test_aggregated_mean_in_range(self):
        X, y = make_regression_data(60, 8)
        cv = CrossValidator(k=3, config=TrainConfig(epochs=3))
        results = cv.run(X, y, input_dim=8)
        assert results["mse"]["mean"] >= 0


class TestFeatureScaler:
    def test_fit_transform_zero_mean(self):
        X = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]], dtype=np.float32)
        scaler = FeatureScaler()
        X_scaled = scaler.fit_transform(X)
        np.testing.assert_allclose(X_scaled.mean(axis=0), [0.0, 0.0], atol=1e-5)

    def test_fit_transform_unit_variance(self):
        rng = np.random.default_rng(0)
        X = rng.normal(5.0, 3.0, (100, 4)).astype(np.float32)
        scaler = FeatureScaler()
        X_scaled = scaler.fit_transform(X)
        np.testing.assert_allclose(X_scaled.std(axis=0), np.ones(4), atol=0.05)

    def test_transform_before_fit_raises(self):
        scaler = FeatureScaler()
        with pytest.raises(RuntimeError):
            scaler.transform(np.ones((5, 3), dtype=np.float32))

    def test_inverse_transform_recovers_original(self):
        rng = np.random.default_rng(1)
        X = rng.normal(10.0, 2.0, (50, 5)).astype(np.float32)
        scaler = FeatureScaler()
        X_scaled = scaler.fit_transform(X)
        X_recovered = scaler.inverse_transform(X_scaled)
        np.testing.assert_allclose(X_recovered, X, atol=1e-4)

    def test_to_dict_from_dict_round_trip(self):
        rng = np.random.default_rng(2)
        X = rng.normal(0.0, 1.0, (20, 3)).astype(np.float32)
        scaler = FeatureScaler()
        scaler.fit(X)
        d = scaler.to_dict()
        scaler2 = FeatureScaler.from_dict(d)
        np.testing.assert_allclose(scaler.mean_, scaler2.mean_, atol=1e-6)
        np.testing.assert_allclose(scaler.std_, scaler2.std_, atol=1e-6)

    def test_constant_feature_handled(self):
        X = np.ones((10, 3), dtype=np.float32)
        scaler = FeatureScaler()
        X_scaled = scaler.fit_transform(X)
        assert not np.any(np.isnan(X_scaled))
