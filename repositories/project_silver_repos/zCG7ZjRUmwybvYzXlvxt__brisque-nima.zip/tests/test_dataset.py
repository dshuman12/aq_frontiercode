"""Tests for dataset module."""
import json
import pytest
import numpy as np

from src.backend.app.dataset import (
    ImageRecord,
    DatasetStats,
    InMemoryDataset,
    DataLoader,
    SyntheticDatasetGenerator,
    DatasetRegistry,
    compute_checksum,
    stratified_split,
)


def make_record(i: int, mos: float = 3.0, split: str = "train") -> ImageRecord:
    return ImageRecord(
        image_id=f"img_{i:04d}",
        path=f"/images/img_{i:04d}.jpg",
        mos_score=mos,
        split=split,
    )


class TestImageRecord:
    def test_to_dict_round_trip(self):
        r = make_record(1, mos=4.2)
        d = r.to_dict()
        r2 = ImageRecord.from_dict(d)
        assert r2.image_id == r.image_id
        assert r2.mos_score == r.mos_score
        assert r2.path == r.path

    def test_default_split_is_train(self):
        r = ImageRecord(image_id="x", path="/x.jpg")
        assert r.split == "train"

    def test_optional_fields_default_none(self):
        r = ImageRecord(image_id="y", path="/y.jpg")
        assert r.mos_score is None
        assert r.width is None
        assert r.checksum is None

    def test_tags_default_empty_list(self):
        r = ImageRecord(image_id="z", path="/z.jpg")
        assert r.tags == []

    def test_metadata_default_empty_dict(self):
        r = ImageRecord(image_id="m", path="/m.jpg")
        assert r.metadata == {}


class TestInMemoryDataset:
    def test_add_and_get(self):
        ds = InMemoryDataset("test")
        r = make_record(1)
        ds.add(r)
        found = ds.get("img_0001")
        assert found is not None
        assert found.image_id == "img_0001"

    def test_len(self):
        ds = InMemoryDataset()
        for i in range(5):
            ds.add(make_record(i))
        assert len(ds) == 5

    def test_remove(self):
        ds = InMemoryDataset()
        ds.add(make_record(1))
        removed = ds.remove("img_0001")
        assert removed is True
        assert ds.get("img_0001") is None

    def test_remove_nonexistent(self):
        ds = InMemoryDataset()
        assert ds.remove("nonexistent") is False

    def test_iter(self):
        ds = InMemoryDataset()
        for i in range(3):
            ds.add(make_record(i))
        ids = {r.image_id for r in ds}
        assert len(ids) == 3

    def test_filter_by_split(self):
        ds = InMemoryDataset()
        for i in range(5):
            ds.add(make_record(i, split="train"))
        for i in range(5, 8):
            ds.add(make_record(i, split="val"))
        train = ds.filter(split="train")
        val = ds.filter(split="val")
        assert len(train) == 5
        assert len(val) == 3

    def test_filter_by_mos(self):
        ds = InMemoryDataset()
        for i, mos in enumerate([1.0, 2.5, 3.0, 4.0, 5.0]):
            ds.add(make_record(i, mos=mos))
        result = ds.filter(min_mos=3.0)
        assert all(r.mos_score >= 3.0 for r in result)

    def test_filter_labeled_only(self):
        ds = InMemoryDataset()
        r1 = ImageRecord(image_id="a", path="/a.jpg", mos_score=3.0)
        r2 = ImageRecord(image_id="b", path="/b.jpg", mos_score=None)
        ds.add(r1)
        ds.add(r2)
        labeled = ds.filter(labeled_only=True)
        assert len(labeled) == 1
        assert labeled[0].image_id == "a"

    def test_filter_by_tags(self):
        ds = InMemoryDataset()
        r1 = ImageRecord(image_id="a", path="/a.jpg", tags=["indoor"])
        r2 = ImageRecord(image_id="b", path="/b.jpg", tags=["outdoor"])
        r3 = ImageRecord(image_id="c", path="/c.jpg", tags=["portrait", "indoor"])
        ds.add(r1)
        ds.add(r2)
        ds.add(r3)
        indoor = ds.filter(tags=["indoor"])
        assert len(indoor) == 2

    def test_stats(self):
        ds = InMemoryDataset()
        for i in range(10):
            ds.add(make_record(i, mos=float(i + 1) / 2.0 + 1.0))
        s = ds.stats()
        assert s.total == 10
        assert s.labeled == 10
        assert s.avg_mos > 0

    def test_stats_empty_dataset(self):
        ds = InMemoryDataset()
        s = ds.stats()
        assert s.total == 0
        assert s.avg_mos == 0.0

    def test_split_dataset(self):
        ds = InMemoryDataset()
        for i in range(100):
            ds.add(make_record(i))
        ds.split_dataset(0.7, 0.15, seed=0)
        train = ds.filter(split="train")
        val = ds.filter(split="val")
        test = ds.filter(split="test")
        assert len(train) + len(val) + len(test) == 100
        assert 60 <= len(train) <= 80

    def test_to_json_round_trip(self):
        ds = InMemoryDataset("json_test")
        for i in range(5):
            ds.add(make_record(i, mos=float(i + 1)))
        json_str = ds.to_json()
        ds2 = InMemoryDataset.from_json(json_str, "loaded")
        assert len(ds2) == 5

    def test_to_csv(self):
        ds = InMemoryDataset()
        ds.add(make_record(1, mos=3.5))
        csv_str = ds.to_csv()
        assert "image_id" in csv_str
        assert "img_0001" in csv_str

    def test_to_csv_empty(self):
        ds = InMemoryDataset()
        assert ds.to_csv() == ""


class TestDataLoader:
    def _make_dataset(self, n: int = 50) -> InMemoryDataset:
        ds = InMemoryDataset()
        for i in range(n):
            split = "train" if i < 35 else ("val" if i < 45 else "test")
            ds.add(make_record(i, split=split))
        return ds

    def test_batch_count(self):
        ds = self._make_dataset(50)
        loader = DataLoader(ds, batch_size=10)
        batches = list(loader)
        total = sum(len(b) for b in batches)
        assert total == 50

    def test_split_filter(self):
        ds = self._make_dataset(50)
        loader = DataLoader(ds, batch_size=5, split="val")
        records = [r for batch in loader for r in batch]
        assert all(r.split == "val" for r in records)

    def test_shuffle_changes_order(self):
        ds = self._make_dataset(50)
        loader1 = DataLoader(ds, batch_size=50, shuffle=False, seed=0)
        loader2 = DataLoader(ds, batch_size=50, shuffle=True, seed=123)
        batch1 = list(loader1)[0]
        batch2 = list(loader2)[0]
        ids1 = [r.image_id for r in batch1]
        ids2 = [r.image_id for r in batch2]
        assert ids1 != ids2 or len(ids1) < 2

    def test_transform_applied(self):
        ds = self._make_dataset(10)
        loader = DataLoader(ds, batch_size=5, transform=lambda r: r.image_id)
        for batch in loader:
            for item in batch:
                assert isinstance(item, str)

    def test_len(self):
        ds = self._make_dataset(50)
        loader = DataLoader(ds, batch_size=10)
        assert len(loader) == 5


class TestSyntheticDatasetGenerator:
    def test_generates_correct_count(self):
        gen = SyntheticDatasetGenerator(seed=0)
        ds = gen.generate(n=50)
        assert len(ds) == 50

    def test_mos_in_range(self):
        gen = SyntheticDatasetGenerator(seed=1)
        ds = gen.generate(n=100)
        for r in ds:
            assert r.mos_score is not None
            assert 1.0 <= r.mos_score <= 5.0

    def test_normal_distribution(self):
        gen = SyntheticDatasetGenerator(seed=2)
        ds = gen.generate(n=200, mos_distribution="normal")
        scores = [r.mos_score for r in ds]
        assert abs(np.mean(scores) - 3.5) < 0.5

    def test_uniform_distribution(self):
        gen = SyntheticDatasetGenerator(seed=3)
        ds = gen.generate(n=200, mos_distribution="uniform")
        scores = [r.mos_score for r in ds]
        assert np.std(scores) > 0.8

    def test_bimodal_distribution(self):
        gen = SyntheticDatasetGenerator(seed=4)
        ds = gen.generate(n=200, mos_distribution="bimodal")
        scores = [r.mos_score for r in ds]
        assert len(scores) == 200

    def test_split_fractions(self):
        gen = SyntheticDatasetGenerator(seed=0)
        ds = gen.generate(n=100, split_fracs=(0.6, 0.2, 0.2))
        train = ds.filter(split="train")
        val = ds.filter(split="val")
        test = ds.filter(split="test")
        assert abs(len(train) - 60) <= 2
        assert abs(len(val) - 20) <= 2


class TestDatasetRegistry:
    def test_register_and_get(self):
        reg = DatasetRegistry()
        ds = InMemoryDataset("myds")
        reg.register(ds)
        assert reg.get("myds") is ds

    def test_get_nonexistent(self):
        reg = DatasetRegistry()
        assert reg.get("nope") is None

    def test_list_names(self):
        reg = DatasetRegistry()
        reg.register(InMemoryDataset("a"))
        reg.register(InMemoryDataset("b"))
        names = reg.list_names()
        assert "a" in names
        assert "b" in names

    def test_remove(self):
        reg = DatasetRegistry()
        reg.register(InMemoryDataset("rm"))
        assert reg.remove("rm") is True
        assert reg.get("rm") is None

    def test_merge(self):
        reg = DatasetRegistry()
        ds1 = InMemoryDataset("d1")
        ds2 = InMemoryDataset("d2")
        ds1.add(make_record(1))
        ds2.add(make_record(2))
        reg.register(ds1)
        reg.register(ds2)
        merged = reg.merge("merged", "d1", "d2")
        assert len(merged) == 2

    def test_combined_stats(self):
        reg = DatasetRegistry()
        ds = InMemoryDataset("stat_ds")
        for i in range(5):
            ds.add(make_record(i, mos=float(i + 1)))
        reg.register(ds)
        stats = reg.combined_stats()
        assert "stat_ds" in stats
        assert stats["stat_ds"].total == 5


class TestComputeChecksum:
    def test_sha256_checksum(self):
        data = b"hello world"
        cs = compute_checksum(data, "sha256")
        assert len(cs) == 64
        assert cs == compute_checksum(data, "sha256")

    def test_md5_checksum(self):
        data = b"test data"
        cs = compute_checksum(data, "md5")
        assert len(cs) == 32

    def test_different_data_different_checksum(self):
        cs1 = compute_checksum(b"data1")
        cs2 = compute_checksum(b"data2")
        assert cs1 != cs2


class TestStratifiedSplit:
    def test_all_records_assigned(self):
        records = [make_record(i, mos=float(i % 5 + 1)) for i in range(100)]
        result = stratified_split(records, seed=0)
        splits = {r.split for r in result}
        assert "train" in splits

    def test_approximate_fractions(self):
        records = [make_record(i, mos=float(i % 5 + 1)) for i in range(100)]
        stratified_split(records, train_frac=0.7, val_frac=0.15, seed=42)
        train = sum(1 for r in records if r.split == "train")
        assert 60 <= train <= 80

    def test_unlabeled_goes_to_train(self):
        records = [ImageRecord(image_id=f"u{i}", path=f"/u{i}.jpg") for i in range(10)]
        stratified_split(records, seed=0)
        # unlabeled assigned train by default
        for r in records:
            assert r.split in ("train", "val", "test")
