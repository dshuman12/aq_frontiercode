"""Tests for comparison.py."""

import math
import pytest

from src.backend.app.comparison import (
    ABTestAnalyzer,
    BatchComparisonReport,
    ComparisonResult,
    ImagePair,
    QualityComparator,
)


def make_result(brisque_q=0.7, nima=0.65, passed=True):
    return {
        "brisque_quality": brisque_q,
        "nima_score": nima,
        "combined_score": (brisque_q + nima) / 2,
        "grade": "good",
        "passed": passed,
        "error": None,
    }


def make_pair(pair_id="p1", b_bq=0.5, b_nima=0.5, a_bq=0.7, a_nima=0.7):
    pair = ImagePair(
        pair_id=pair_id,
        before_path="/img/before.jpg",
        after_path="/img/after.jpg",
        before_result=make_result(b_bq, b_nima),
        after_result=make_result(a_bq, a_nima),
    )
    return pair


class TestQualityComparator:
    def test_compare_pair_improvement(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.4, b_nima=0.4, a_bq=0.8, a_nima=0.8)
        result = comp.compare_pair(pair)
        assert result is not None
        assert result.improved is True
        assert result.combined_delta > 0

    def test_compare_pair_degradation(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.8, b_nima=0.8, a_bq=0.4, a_nima=0.4)
        result = comp.compare_pair(pair)
        assert result is not None
        assert result.improved is False
        assert result.combined_delta < 0

    def test_compare_pair_no_change(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.6, b_nima=0.6, a_bq=0.6, a_nima=0.6)
        result = comp.compare_pair(pair)
        assert result is not None
        assert result.verdict == "no_change"

    def test_compare_pair_missing_result(self):
        comp = QualityComparator()
        pair = ImagePair("p0", "/a.jpg", "/b.jpg")
        result = comp.compare_pair(pair)
        assert result is None

    def test_compare_pair_with_error(self):
        comp = QualityComparator()
        pair = ImagePair("p0", "/a.jpg", "/b.jpg")
        pair.before_result = {"error": "decode failed"}
        pair.after_result = make_result()
        result = comp.compare_pair(pair)
        assert result is None

    def test_compare_batch(self):
        comp = QualityComparator()
        pairs = [make_pair(f"p{i}") for i in range(5)]
        results = comp.compare_batch(pairs)
        assert len(results) == 5

    def test_aggregate_keys(self):
        comp = QualityComparator()
        pairs = [make_pair(f"p{i}", b_bq=0.4, b_nima=0.4, a_bq=0.8, a_nima=0.8) for i in range(3)]
        results = comp.compare_batch(pairs)
        agg = comp.aggregate(results)
        assert "total_pairs" in agg
        assert "improved" in agg
        assert "verdicts" in agg

    def test_aggregate_improved_pct(self):
        comp = QualityComparator()
        pairs = [
            make_pair("p1", b_bq=0.3, a_bq=0.9),
            make_pair("p2", b_bq=0.9, a_bq=0.3),
        ]
        results = comp.compare_batch(pairs)
        agg = comp.aggregate(results)
        assert agg["improved"] == 1
        assert abs(agg["improved_pct"] - 50.0) < 1e-9

    def test_delta_pct_computed(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.5, b_nima=0.5, a_bq=0.75, a_nima=0.75)
        result = comp.compare_pair(pair)
        assert result.delta_pct != 0.0

    def test_verdict_significant_improvement(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.2, b_nima=0.2, a_bq=0.9, a_nima=0.9)
        result = comp.compare_pair(pair)
        assert result.verdict == "significant_improvement"

    def test_verdict_significant_degradation(self):
        comp = QualityComparator()
        pair = make_pair(b_bq=0.9, b_nima=0.9, a_bq=0.2, a_nima=0.2)
        result = comp.compare_pair(pair)
        assert result.verdict == "significant_degradation"

    def test_comparison_result_to_dict(self):
        cr = ComparisonResult(
            pair_id="p1",
            before_brisque=0.5, after_brisque=0.8,
            before_nima=0.4, after_nima=0.7,
            brisque_delta=0.3, nima_delta=0.3,
            combined_delta=0.3, improved=True,
            delta_pct=60.0, verdict="significant_improvement",
        )
        d = cr.to_dict()
        assert d["pair_id"] == "p1"
        assert d["improved"] is True
        assert "brisque_delta" in d


class TestABTestAnalyzer:
    def test_basic_analysis(self):
        ab = ABTestAnalyzer()
        a = [0.7, 0.75, 0.8, 0.72, 0.78]
        b = [0.5, 0.55, 0.52, 0.48, 0.51]
        result = ab.analyze(a, b, "score")
        assert "t_stat" in result
        assert "p_value" in result
        assert "significant" in result

    def test_empty_groups(self):
        ab = ABTestAnalyzer()
        result = ab.analyze([], [0.5, 0.6], "score")
        assert "error" in result

    def test_winner_a(self):
        ab = ABTestAnalyzer(alpha=0.05)
        a = [0.9] * 30
        b = [0.3] * 30
        result = ab.analyze(a, b, "score")
        assert result["winner"] == "A"

    def test_winner_b(self):
        ab = ABTestAnalyzer(alpha=0.05)
        a = [0.3] * 30
        b = [0.9] * 30
        result = ab.analyze(a, b, "score")
        assert result["winner"] == "B"

    def test_tie_on_equal_distributions(self):
        ab = ABTestAnalyzer()
        vals = [0.6] * 10
        result = ab.analyze(vals, vals, "score")
        assert result["winner"] == "tie"

    def test_effect_size_negligible(self):
        ab = ABTestAnalyzer()
        a = [0.601] * 20
        b = [0.600] * 20
        result = ab.analyze(a, b, "score")
        assert result["effect_size"] == "negligible"

    def test_effect_size_large(self):
        ab = ABTestAnalyzer()
        a = [0.95] * 20
        b = [0.05] * 20
        result = ab.analyze(a, b, "score")
        assert result["effect_size"] == "large"

    def test_cohens_d_positive_when_a_higher(self):
        ab = ABTestAnalyzer()
        a = [0.8] * 10
        b = [0.2] * 10
        result = ab.analyze(a, b)
        assert result["cohens_d"] > 0

    def test_p_value_range(self):
        ab = ABTestAnalyzer()
        a = [0.6, 0.65, 0.7]
        b = [0.4, 0.45, 0.5]
        result = ab.analyze(a, b)
        assert 0.0 <= result["p_value"] <= 1.0


class TestBatchComparisonReport:
    def test_generate_structure(self):
        report = BatchComparisonReport()
        pairs = [make_pair(f"p{i}") for i in range(3)]
        result = report.generate(pairs)
        assert "aggregate" in result
        assert "statistical_tests" in result
        assert "pairs" in result

    def test_generate_statistical_keys(self):
        report = BatchComparisonReport()
        pairs = [make_pair(f"p{i}") for i in range(5)]
        result = report.generate(pairs)
        assert "brisque" in result["statistical_tests"]
        assert "nima" in result["statistical_tests"]

    def test_pairs_count(self):
        report = BatchComparisonReport()
        pairs = [make_pair(f"p{i}") for i in range(7)]
        result = report.generate(pairs)
        assert len(result["pairs"]) == 7

    def test_empty_pairs(self):
        report = BatchComparisonReport()
        result = report.generate([])
        assert result["aggregate"] == {}
        assert result["pairs"] == []
