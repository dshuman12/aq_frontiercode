import pytest
import io
from PIL import Image
from fastapi.testclient import TestClient
from src.backend.app.api import app

ML_AVAILABLE = True
try:
    import cv2  # noqa: F401
    import torch  # noqa: F401
except ImportError:
    ML_AVAILABLE = False

client = TestClient(app)


def create_test_image():
    img = Image.new('RGB', (100, 100), color='red')
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='JPEG')
    img_bytes.seek(0)
    return img_bytes


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json().get("status") == "healthy"


@pytest.mark.skipif(not ML_AVAILABLE, reason="ML packages not installed")
def test_score_files_single_image():
    test_image = create_test_image()
    files = {"files": ("test.jpg", test_image, "image/jpeg")}
    response = client.post("/score_files", files=files)
    assert response.status_code == 200
    data = response.json()
    assert data["count"] == 1
    result = data["results"][0]
    assert isinstance(result["brisque_score"], (int, float))
    assert isinstance(result["nima_aesthetic"], (int, float))


@pytest.mark.skipif(not ML_AVAILABLE, reason="ML packages not installed")
def test_score_files_multiple_images():
    test_image1 = create_test_image()
    test_image2 = create_test_image()
    files = [
        ("files", ("test1.jpg", test_image1, "image/jpeg")),
        ("files", ("test2.jpg", test_image2, "image/jpeg")),
    ]
    response = client.post("/score_files", files=files)
    assert response.status_code == 200
    assert response.json()["count"] == 2


def test_score_files_no_files():
    response = client.post("/score_files")
    assert response.status_code in [400, 422]


def test_ui_endpoint():
    response = client.get("/ui/")
    assert response.status_code in [200, 404]


if __name__ == "__main__":
    pytest.main([__file__])

# add score distribution stats

# add frontend UI stub

# add retry logic for storage

# add score export to JSON
