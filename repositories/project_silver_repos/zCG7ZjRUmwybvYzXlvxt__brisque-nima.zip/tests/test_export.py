"""Tests for export module."""
import csv
import io
import json
import zipfile
import pytest

from src.backend.app.export import (
    to_json,
    to_csv,
    to_tsv,
    to_html,
    to_markdown,
    to_zip,
    export,
    summarize_grades,
    ExportFormat,
    _score_to_grade,
)


class FakeResult:
    def __init__(self, image_id: str, score: float) -> None:
        self.image_id = image_id
        self.overall_score = score
        self.brisque_score = round(100 - score * 20, 1)
        self.nima_score = score
        self.sharpness = score * 100
        self.noise_level = 0.05
        self.brightness = 128.0
        self.contrast = 50.0
        self.width = 1920
        self.height = 1080
        self.file_size = 512000
        self.filepath = f"/images/{image_id}.jpg"


def make_results(n: int = 5) -> list:
    scores = [1.2, 2.5, 3.0, 4.1, 4.8]
    return [FakeResult(f"img_{i:04d}", scores[i % len(scores)]) for i in range(n)]


class TestScoreToGrade:
    def test_a_grade(self):
        assert _score_to_grade(4.0) == "A"
        assert _score_to_grade(5.0) == "A"
        assert _score_to_grade(4.5) == "A"

    def test_b_grade(self):
        assert _score_to_grade(3.0) == "B"
        assert _score_to_grade(3.9) == "B"

    def test_c_grade(self):
        assert _score_to_grade(2.0) == "C"
        assert _score_to_grade(2.9) == "C"

    def test_d_grade(self):
        assert _score_to_grade(1.0) == "D"
        assert _score_to_grade(1.9) == "D"
        assert _score_to_grade(0.0) == "D"


class TestToJson:
    def test_returns_string(self):
        results = make_results(3)
        out = to_json(results)
        assert isinstance(out, str)

    def test_valid_json(self):
        results = make_results(3)
        out = to_json(results)
        data = json.loads(out)
        assert "results" in data
        assert data["count"] == 3

    def test_includes_grade(self):
        results = make_results(1)
        out = to_json(results)
        data = json.loads(out)
        assert "grade" in data["results"][0]

    def test_exported_at_present(self):
        out = to_json(make_results(1))
        data = json.loads(out)
        assert "exported_at" in data

    def test_compact_json(self):
        out = to_json(make_results(1), pretty=False)
        assert "\n" not in out or out.count("\n") <= 1

    def test_empty_results(self):
        out = to_json([])
        data = json.loads(out)
        assert data["count"] == 0
        assert data["results"] == []


class TestToCsv:
    def test_returns_string(self):
        out = to_csv(make_results(3))
        assert isinstance(out, str)

    def test_has_header(self):
        out = to_csv(make_results(2))
        first_line = out.splitlines()[0]
        assert "image_id" in first_line
        assert "overall_score" in first_line

    def test_row_count(self):
        results = make_results(5)
        out = to_csv(results)
        rows = [r for r in csv.reader(io.StringIO(out))]
        assert len(rows) == 6  # header + 5 data rows

    def test_grade_column(self):
        results = [FakeResult("test", 4.5)]
        out = to_csv(results)
        assert "A" in out

    def test_empty_returns_empty_string(self):
        assert to_csv([]) == ""

    def test_comma_delimiter(self):
        out = to_csv(make_results(1))
        assert "," in out


class TestToTsv:
    def test_tab_delimiter(self):
        out = to_tsv(make_results(2))
        assert "\t" in out

    def test_has_header(self):
        out = to_tsv(make_results(1))
        assert "image_id" in out.splitlines()[0]


class TestToHtml:
    def test_returns_html_string(self):
        out = to_html(make_results(3))
        assert "<!DOCTYPE html>" in out
        assert "<table" in out

    def test_title_in_output(self):
        out = to_html(make_results(1), title="My Report")
        assert "My Report" in out

    def test_grade_colors_present(self):
        out = to_html([FakeResult("a", 4.5), FakeResult("b", 1.0)])
        assert "#d4edda" in out  # A color
        assert "#f8d7da" in out  # D color

    def test_image_count_in_output(self):
        results = make_results(7)
        out = to_html(results)
        assert "7" in out

    def test_empty_results_valid_html(self):
        out = to_html([])
        assert "<table" in out
        assert "0 images" in out


class TestToMarkdown:
    def test_returns_markdown_string(self):
        out = to_markdown(make_results(3))
        assert "# " in out
        assert "|" in out

    def test_header_row(self):
        out = to_markdown(make_results(1))
        assert "Image ID" in out
        assert "Score" in out
        assert "Grade" in out

    def test_separator_row(self):
        out = to_markdown(make_results(1))
        assert "---" in out

    def test_grade_bold(self):
        out = to_markdown([FakeResult("x", 4.0)])
        assert "**A**" in out

    def test_custom_title(self):
        out = to_markdown(make_results(1), title="Assessment Output")
        assert "Assessment Output" in out.splitlines()[0]

    def test_empty_results(self):
        out = to_markdown([])
        assert "0 images" in out


class TestToZip:
    def test_returns_bytes(self):
        out = to_zip(make_results(2))
        assert isinstance(out, bytes)

    def test_valid_zip(self):
        out = to_zip(make_results(2))
        with zipfile.ZipFile(io.BytesIO(out)) as zf:
            names = zf.namelist()
            assert len(names) > 0

    def test_default_formats_included(self):
        out = to_zip(make_results(2))
        with zipfile.ZipFile(io.BytesIO(out)) as zf:
            names = zf.namelist()
            assert "results.json" in names
            assert "results.csv" in names
            assert "report.html" in names

    def test_custom_formats(self):
        out = to_zip(make_results(2), formats=[ExportFormat.CSV, ExportFormat.MARKDOWN])
        with zipfile.ZipFile(io.BytesIO(out)) as zf:
            names = zf.namelist()
            assert "results.csv" in names
            assert "report.md" in names
            assert "results.json" not in names

    def test_zip_content_valid_json(self):
        out = to_zip(make_results(3))
        with zipfile.ZipFile(io.BytesIO(out)) as zf:
            json_content = zf.read("results.json").decode()
            data = json.loads(json_content)
            assert data["count"] == 3


class TestExportDispatch:
    def test_json_dispatch(self):
        out = export(make_results(2), "json")
        assert isinstance(out, str)
        json.loads(out)

    def test_csv_dispatch(self):
        out = export(make_results(2), "csv")
        assert isinstance(out, str)
        assert "image_id" in out

    def test_tsv_dispatch(self):
        out = export(make_results(2), "tsv")
        assert "\t" in out

    def test_html_dispatch(self):
        out = export(make_results(2), "html")
        assert "<!DOCTYPE html>" in out

    def test_markdown_dispatch(self):
        out = export(make_results(2), "markdown")
        assert "# " in out

    def test_zip_dispatch(self):
        out = export(make_results(2), "zip")
        assert isinstance(out, bytes)

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Unsupported export format"):
            export(make_results(1), "pdf")

    def test_case_insensitive(self):
        out = export(make_results(1), "JSON")
        json.loads(out)


class TestSummarizeGrades:
    def test_returns_dict(self):
        results = make_results(5)
        summary = summarize_grades(results)
        assert isinstance(summary, dict)

    def test_total_correct(self):
        results = make_results(5)
        summary = summarize_grades(results)
        assert summary["total"] == 5

    def test_grade_counts_sum_to_total(self):
        results = make_results(10)
        summary = summarize_grades(results)
        total_from_counts = sum(summary["grade_counts"].values())
        assert total_from_counts == 10

    def test_percentages_sum_to_100(self):
        results = make_results(10)
        summary = summarize_grades(results)
        pct_sum = sum(summary["grade_percentages"].values())
        assert abs(pct_sum - 100.0) < 0.1

    def test_empty_results(self):
        summary = summarize_grades([])
        assert summary["total"] == 0
        assert all(v == 0 for v in summary["grade_counts"].values())

    def test_all_high_scores_all_a(self):
        results = [FakeResult(f"img_{i}", 4.5) for i in range(5)]
        summary = summarize_grades(results)
        assert summary["grade_counts"]["A"] == 5
        assert summary["grade_counts"]["D"] == 0
