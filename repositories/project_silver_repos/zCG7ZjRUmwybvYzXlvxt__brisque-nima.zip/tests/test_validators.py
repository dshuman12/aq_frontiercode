"""Tests for validators module."""
import numpy as np
import pytest

from src.backend.app.validators import (
    validate_image_array,
    validate_file_path,
    validate_file_bytes,
    validate_score,
    validate_batch_request,
    validate_pagination,
    validate_date_range,
    validate_image_id,
    combine_results,
    ValidationResult,
    ValidationError,
    SUPPORTED_FORMATS,
    MAX_FILE_SIZE_BYTES,
)


class TestValidateImageArray:
    def test_valid_rgb(self):
        img = np.zeros((64, 64, 3), dtype=np.uint8)
        r = validate_image_array(img)
        assert r.valid

    def test_valid_grayscale(self):
        img = np.zeros((32, 32), dtype=np.uint8)
        r = validate_image_array(img)
        assert r.valid

    def test_invalid_type(self):
        r = validate_image_array([[1, 2], [3, 4]])
        assert not r.valid
        assert r.errors[0].code == "TYPE_ERROR"

    def test_too_small(self):
        img = np.zeros((4, 4, 3), dtype=np.uint8)
        r = validate_image_array(img)
        assert not r.valid
        assert any(e.code == "TOO_SMALL" for e in r.errors)

    def test_too_large(self):
        img = np.zeros((20000, 20000, 3), dtype=np.uint8)
        r = validate_image_array(img)
        assert not r.valid
        assert any(e.code == "TOO_LARGE" for e in r.errors)

    def test_wrong_channels(self):
        img = np.zeros((64, 64, 5), dtype=np.uint8)
        r = validate_image_array(img)
        assert not r.valid
        assert any(e.code == "CHANNEL_ERROR" for e in r.errors)

    def test_4d_array_invalid(self):
        img = np.zeros((2, 64, 64, 3), dtype=np.uint8)
        r = validate_image_array(img)
        assert not r.valid

    def test_float32_warning(self):
        img = np.zeros((64, 64, 3), dtype=np.float32)
        r = validate_image_array(img)
        assert r.valid  # valid shape, just may have warning

    def test_rgba_valid(self):
        img = np.zeros((32, 32, 4), dtype=np.uint8)
        r = validate_image_array(img)
        assert r.valid


class TestValidateFilePath:
    def test_valid_jpeg_path(self):
        r = validate_file_path("/images/photo.jpg")
        assert r.valid

    def test_valid_png_path(self):
        r = validate_file_path("photo.PNG")
        assert r.valid

    def test_empty_path(self):
        r = validate_file_path("")
        assert not r.valid

    def test_none_path(self):
        r = validate_file_path(None)
        assert not r.valid

    def test_unsupported_extension(self):
        r = validate_file_path("/images/photo.pdf")
        assert not r.valid
        assert any(e.code == "UNSUPPORTED_FORMAT" for e in r.errors)

    def test_null_byte_in_path(self):
        r = validate_file_path("/images/photo\x00.jpg")
        assert not r.valid

    def test_no_extension_allowed(self):
        r = validate_file_path("/images/photo")
        assert r.valid  # no extension = no format check

    def test_all_supported_formats(self):
        for fmt in SUPPORTED_FORMATS:
            r = validate_file_path(f"/img/test.{fmt}")
            assert r.valid, f"Format {fmt} should be valid"


class TestValidateFileBytes:
    def test_valid_jpeg_magic(self):
        data = b'\xff\xd8' + b'\x00' * 100
        r = validate_file_bytes(data)
        assert r.valid

    def test_valid_png_magic(self):
        data = b'\x89PNG' + b'\x00' * 100
        r = validate_file_bytes(data)
        assert r.valid

    def test_empty_bytes(self):
        r = validate_file_bytes(b'')
        assert not r.valid
        assert any(e.code == "EMPTY" for e in r.errors)

    def test_too_large(self):
        data = b'\xff\xd8' + b'\x00' * (MAX_FILE_SIZE_BYTES + 1)
        r = validate_file_bytes(data)
        assert not r.valid
        assert any(e.code == "TOO_LARGE" for e in r.errors)

    def test_invalid_type(self):
        r = validate_file_bytes("not bytes")
        assert not r.valid

    def test_unknown_magic_warns(self):
        data = b'\x00\x00\x00\x00' + b'\x00' * 100
        r = validate_file_bytes(data)
        assert r.valid  # valid size, just warning
        assert len(r.warnings) > 0


class TestValidateScore:
    def test_valid_score(self):
        assert validate_score(3.5).valid
        assert validate_score(1.0).valid
        assert validate_score(5.0).valid

    def test_integer_score(self):
        assert validate_score(3).valid

    def test_out_of_range_low(self):
        r = validate_score(0.5)
        assert not r.valid

    def test_out_of_range_high(self):
        r = validate_score(5.5)
        assert not r.valid

    def test_none_score(self):
        r = validate_score(None)
        assert not r.valid
        assert any(e.code == "REQUIRED" for e in r.errors)

    def test_string_score(self):
        r = validate_score("good")
        assert not r.valid

    def test_custom_field_name(self):
        r = validate_score(0.0, "brisque_score")
        assert r.errors[0].field == "brisque_score"


class TestValidateBatchRequest:
    def test_valid_request(self):
        r = validate_batch_request({"image_ids": ["a", "b", "c"]})
        assert r.valid

    def test_missing_image_ids(self):
        r = validate_batch_request({})
        assert not r.valid
        assert any(e.field == "image_ids" for e in r.errors)

    def test_empty_image_ids(self):
        r = validate_batch_request({"image_ids": []})
        assert not r.valid

    def test_non_list_image_ids(self):
        r = validate_batch_request({"image_ids": "single_id"})
        assert not r.valid

    def test_too_many_ids(self):
        r = validate_batch_request({"image_ids": [f"img_{i}" for i in range(1001)]})
        assert not r.valid

    def test_valid_with_config(self):
        r = validate_batch_request({"image_ids": ["a"], "config": {"model": "brisque"}})
        assert r.valid

    def test_invalid_config_type(self):
        r = validate_batch_request({"image_ids": ["a"], "config": "bad"})
        assert not r.valid


class TestValidatePagination:
    def test_valid_page_and_size(self):
        r = validate_pagination(1, 20)
        assert r.valid

    def test_page_zero_invalid(self):
        r = validate_pagination(0, 20)
        assert not r.valid

    def test_negative_page_invalid(self):
        r = validate_pagination(-1, 10)
        assert not r.valid

    def test_page_size_too_large(self):
        r = validate_pagination(1, 201)
        assert not r.valid

    def test_string_page_converts(self):
        r = validate_pagination("2", "10")
        assert r.valid

    def test_invalid_string_page(self):
        r = validate_pagination("abc", 10)
        assert not r.valid

    def test_page_size_zero_invalid(self):
        r = validate_pagination(1, 0)
        assert not r.valid


class TestValidateDateRange:
    def test_valid_range(self):
        r = validate_date_range("2026-01-01T00:00:00", "2026-12-31T23:59:59")
        assert r.valid

    def test_from_only(self):
        r = validate_date_range("2026-01-01", None)
        assert r.valid

    def test_to_only(self):
        r = validate_date_range(None, "2026-12-31")
        assert r.valid

    def test_both_none(self):
        r = validate_date_range(None, None)
        assert r.valid

    def test_reversed_range_invalid(self):
        r = validate_date_range("2026-12-31", "2026-01-01")
        assert not r.valid

    def test_invalid_date_format(self):
        r = validate_date_range("not-a-date", "2026-01-01")
        assert not r.valid


class TestValidateImageId:
    def test_valid_id(self):
        assert validate_image_id("img_001").valid
        assert validate_image_id("abc-123").valid
        assert validate_image_id("folder/image.jpg").valid

    def test_empty_string(self):
        r = validate_image_id("")
        assert not r.valid

    def test_none_id(self):
        r = validate_image_id(None)
        assert not r.valid

    def test_special_chars_invalid(self):
        r = validate_image_id("image with spaces")
        assert not r.valid
        assert any(e.code == "FORBIDDEN_CHARS" for e in r.errors)

    def test_too_long(self):
        r = validate_image_id("x" * 257)
        assert not r.valid


class TestCombineResults:
    def test_all_valid_stays_valid(self):
        r1 = ValidationResult(valid=True)
        r2 = ValidationResult(valid=True)
        combined = combine_results(r1, r2)
        assert combined.valid

    def test_one_invalid_makes_combined_invalid(self):
        r1 = ValidationResult(valid=True)
        r2 = ValidationResult(valid=False)
        r2.errors.append(ValidationError("field", "bad"))
        combined = combine_results(r1, r2)
        assert not combined.valid

    def test_errors_accumulated(self):
        r1 = ValidationResult(valid=False)
        r1.errors.append(ValidationError("f1", "e1"))
        r2 = ValidationResult(valid=False)
        r2.errors.append(ValidationError("f2", "e2"))
        combined = combine_results(r1, r2)
        assert len(combined.errors) == 2

    def test_warnings_accumulated(self):
        r1 = ValidationResult(valid=True)
        r1.warnings.append("warn1")
        r2 = ValidationResult(valid=True)
        r2.warnings.append("warn2")
        combined = combine_results(r1, r2)
        assert len(combined.warnings) == 2
