"""Tests for pipeline.py."""

import io
import math
import pytest
import numpy as np
from PIL import Image
from unittest.mock import MagicMock, patch


def make_pil(width=128, height=128, color=(128, 100, 80)):
    return Image.new("RGB", (width, height), color)


class TestImageLoader:
    def test_load_missing_file(self):
        from src.backend.app.pipeline import ImageLoader
        loader = ImageLoader()
        arr, err = loader.load("/nonexistent/path/img.jpg")
        assert arr is None
        assert "not found" in err.lower() or "not found" in (err or "").lower()

    def test_unsupported_extension(self, tmp_path):
        from src.backend.app.pipeline import ImageLoader
        p = tmp_path / "file.gif"
        p.write_bytes(b"GIF89a")
        loader = ImageLoader()
        arr, err = loader.load(str(p))
        assert err is not None
        assert "Unsupported" in err or "extension" in err.lower()


class TestPreprocessor:
    def test_crop_patches_count(self):
        from src.backend.app.pipeline import Preprocessor
        prep = Preprocessor()
        img = np.random.randint(0, 255, (200, 200, 3), dtype=np.uint8)
        patches = prep.crop_patches(img, patch_size=48, n_patches=5)
        assert len(patches) == 5

    def test_crop_patches_tiny_image(self):
        from src.backend.app.pipeline import Preprocessor
        prep = Preprocessor()
        img = np.zeros((10, 10, 3), dtype=np.uint8)
        patches = prep.crop_patches(img, patch_size=48, n_patches=5)
        assert len(patches) == 1

    def test_process_batch_length(self):
        from src.backend.app.pipeline import Preprocessor
        prep = Preprocessor(normalize=True)
        batch = [np.random.randint(0, 255, (64, 64, 3), dtype=np.uint8) for _ in range(5)]
        results = prep.process_batch(batch)
        assert len(results) == 5


class TestScoreAggregator:
    def test_aggregate_mean(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        assert abs(agg.aggregate_patches([0.4, 0.6, 0.8], "mean") - 0.6) < 1e-9

    def test_aggregate_median(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        assert abs(agg.aggregate_patches([0.1, 0.5, 0.9], "median") - 0.5) < 1e-9

    def test_aggregate_empty(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        assert agg.aggregate_patches([], "mean") == 0.0

    def test_combine_scores(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        combined = agg.combine_scores(0.6, 0.8, 0.5, 0.5)
        assert abs(combined - 0.7) < 1e-9

    def test_combine_scores_clipped(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        combined = agg.combine_scores(2.0, 2.0)
        assert combined == 1.0

    def test_rank_images_descending(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        scores = {"a": 0.3, "b": 0.9, "c": 0.6}
        ranked = agg.rank_images(scores)
        assert ranked[0][0] == "b"
        assert ranked[-1][0] == "a"

    def test_rank_images_ascending(self):
        from src.backend.app.pipeline import ScoreAggregator
        agg = ScoreAggregator()
        scores = {"a": 0.3, "b": 0.9}
        ranked = agg.rank_images(scores, descending=False)
        assert ranked[0][0] == "a"


class TestQualityThresholds:
    def test_classify_excellent(self):
        from src.backend.app.pipeline import QualityThresholds
        t = QualityThresholds()
        assert t.classify(0.9, 0.9, 0.9) == "excellent"

    def test_classify_good(self):
        from src.backend.app.pipeline import QualityThresholds
        t = QualityThresholds()
        assert t.classify(0.7, 0.7, 0.7) == "good"

    def test_classify_reject(self):
        from src.backend.app.pipeline import QualityThresholds
        t = QualityThresholds()
        assert t.classify(0.1, 0.1, 0.1) == "reject"

    def test_should_reject_low_nima(self):
        from src.backend.app.pipeline import QualityThresholds
        t = QualityThresholds(nima_reject_below=0.5)
        rejected, reasons = t.should_reject(0.8, 0.1)
        assert rejected is True
        assert len(reasons) > 0

    def test_should_not_reject_good_image(self):
        from src.backend.app.pipeline import QualityThresholds
        t = QualityThresholds()
        rejected, reasons = t.should_reject(0.8, 0.75)
        assert rejected is False
        assert reasons == []
