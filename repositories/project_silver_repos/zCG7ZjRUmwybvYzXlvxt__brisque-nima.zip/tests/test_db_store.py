"""Tests for db_store.py."""

import time
import pytest

from src.backend.app.db_store import (
    AssessmentRecord,
    InMemoryAssessmentStore,
    SQLiteAssessmentStore,
)


def make_record(path="img.jpg", brisque_q=0.7, nima=0.65, grade="good",
                passed=True, job_id=None, combined=0.675):
    return AssessmentRecord(
        id=None, path=path,
        brisque_raw=30.0, brisque_quality=brisque_q,
        nima_raw=5.8, nima_score=nima,
        combined_score=combined, grade=grade,
        passed=passed, reject_reasons=[],
        error=None, job_id=job_id,
    )


def make_result_dict(path="img.jpg", bq=0.7, nima=0.65):
    return {
        "path": path,
        "brisque_raw": 30.0, "brisque_quality": bq,
        "nima_raw": 5.5, "nima_score": nima,
        "combined_score": (bq + nima) / 2,
        "grade": "good", "passed": True,
        "reject_reasons": [], "error": None,
    }


class TestAssessmentRecord:
    def test_from_result_dict(self):
        d = make_result_dict()
        record = AssessmentRecord.from_result_dict(d, job_id="job_1")
        assert record.path == "img.jpg"
        assert record.job_id == "job_1"

    def test_to_dict_keys(self):
        r = make_record()
        d = r.to_dict()
        for k in ("path", "brisque_quality", "nima_score", "grade", "passed"):
            assert k in d

    def test_default_created_at(self):
        r = make_record()
        assert r.created_at > 0


class TestInMemoryAssessmentStore:
    def test_insert_assigns_id(self):
        store = InMemoryAssessmentStore()
        r = store.insert(make_record())
        assert r.id is not None
        assert r.id >= 1

    def test_ids_increment(self):
        store = InMemoryAssessmentStore()
        r1 = store.insert(make_record())
        r2 = store.insert(make_record())
        assert r2.id == r1.id + 1

    def test_get_existing(self):
        store = InMemoryAssessmentStore()
        r = store.insert(make_record())
        got = store.get(r.id)
        assert got is not None
        assert got.path == "img.jpg"

    def test_get_missing(self):
        store = InMemoryAssessmentStore()
        assert store.get(999) is None

    def test_get_by_job(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(job_id="job_a"))
        store.insert(make_record(job_id="job_a"))
        store.insert(make_record(job_id="job_b"))
        records = store.get_by_job("job_a")
        assert len(records) == 2

    def test_get_by_path(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(path="photo1.jpg"))
        store.insert(make_record(path="photo1.jpg"))
        store.insert(make_record(path="photo2.jpg"))
        assert len(store.get_by_path("photo1.jpg")) == 2

    def test_get_by_grade(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(grade="excellent"))
        store.insert(make_record(grade="excellent"))
        store.insert(make_record(grade="poor"))
        assert len(store.get_by_grade("excellent")) == 2

    def test_filter_passed(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(passed=True))
        store.insert(make_record(passed=False))
        passed = store.filter(passed=True)
        assert all(r.passed for r in passed)

    def test_filter_min_combined(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(combined=0.9))
        store.insert(make_record(combined=0.3))
        results = store.filter(min_combined=0.7)
        assert all(r.combined_score >= 0.7 for r in results)

    def test_filter_max_combined(self):
        store = InMemoryAssessmentStore()
        store.insert(make_record(combined=0.9))
        store.insert(make_record(combined=0.3))
        results = store.filter(max_combined=0.5)
        assert all(r.combined_score <= 0.5 for r in results)

    def test_filter_limit(self):
        store = InMemoryAssessmentStore()
        for _ in range(20):
            store.insert(make_record())
        results = store.filter(limit=5)
        assert len(results) == 5

    def test_delete(self):
        store = InMemoryAssessmentStore()
        r = store.insert(make_record())
        assert store.delete(r.id) is True
        assert store.get(r.id) is None

    def test_delete_missing(self):
        store = InMemoryAssessmentStore()
        assert store.delete(999) is False

    def test_delete_by_job(self):
        store = InMemoryAssessmentStore()
        for _ in range(3):
            store.insert(make_record(job_id="job_x"))
        store.insert(make_record(job_id="job_y"))
        deleted = store.delete_by_job("job_x")
        assert deleted == 3
        assert len(store.get_by_job("job_x")) == 0
        assert len(store.get_by_job("job_y")) == 1

    def test_count(self):
        store = InMemoryAssessmentStore()
        for _ in range(7):
            store.insert(make_record())
        assert store.count() == 7

    def test_aggregate_stats(self):
        store = InMemoryAssessmentStore()
        for _ in range(5):
            store.insert(make_record(brisque_q=0.7, nima=0.65))
        stats = store.aggregate_stats()
        assert stats["count"] == 5
        assert "brisque_mean" in stats
        assert "grade_distribution" in stats

    def test_aggregate_stats_by_job(self):
        store = InMemoryAssessmentStore()
        for _ in range(3):
            store.insert(make_record(job_id="job_1"))
        for _ in range(5):
            store.insert(make_record(job_id="job_2"))
        stats = store.aggregate_stats(job_id="job_1")
        assert stats["count"] == 3

    def test_top_n(self):
        store = InMemoryAssessmentStore()
        for i in range(10):
            store.insert(make_record(combined=i / 10.0))
        top = store.top_n(n=3)
        assert len(top) == 3
        assert top[0].combined_score >= top[1].combined_score

    def test_bottom_n(self):
        store = InMemoryAssessmentStore()
        for i in range(10):
            store.insert(make_record(combined=i / 10.0))
        bottom = store.bottom_n(n=3)
        assert len(bottom) == 3
        assert bottom[0].combined_score <= bottom[1].combined_score

    def test_insert_batch(self):
        store = InMemoryAssessmentStore()
        records = [make_record(f"img_{i}.jpg") for i in range(5)]
        inserted = store.insert_batch(records)
        assert len(inserted) == 5
        assert all(r.id is not None for r in inserted)


class TestSQLiteAssessmentStore:
    def test_insert_and_get(self):
        store = SQLiteAssessmentStore(":memory:")
        r = store.insert(make_record())
        assert r.id is not None
        got = store.get(r.id)
        assert got is not None
        assert got.path == "img.jpg"

    def test_get_missing(self):
        store = SQLiteAssessmentStore(":memory:")
        assert store.get(9999) is None

    def test_get_by_job(self):
        store = SQLiteAssessmentStore(":memory:")
        store.insert(make_record(job_id="j1"))
        store.insert(make_record(job_id="j1"))
        store.insert(make_record(job_id="j2"))
        records = store.get_by_job("j1")
        assert len(records) == 2

    def test_aggregate_stats_empty(self):
        store = SQLiteAssessmentStore(":memory:")
        stats = store.aggregate_stats()
        assert stats["count"] == 0

    def test_aggregate_stats_with_data(self):
        store = SQLiteAssessmentStore(":memory:")
        for _ in range(4):
            store.insert(make_record(brisque_q=0.8, nima=0.7, grade="good"))
        stats = store.aggregate_stats()
        assert stats["count"] == 4
        assert abs(stats["brisque_mean"] - 0.8) < 1e-3

    def test_aggregate_stats_by_job(self):
        store = SQLiteAssessmentStore(":memory:")
        for _ in range(3):
            store.insert(make_record(job_id="j_a"))
        for _ in range(5):
            store.insert(make_record(job_id="j_b"))
        stats = store.aggregate_stats(job_id="j_a")
        assert stats["count"] == 3

    def test_insert_batch(self):
        store = SQLiteAssessmentStore(":memory:")
        records = [make_record(f"img_{i}.jpg") for i in range(6)]
        inserted = store.insert_batch(records)
        assert len(inserted) == 6
        assert all(r.id is not None for r in inserted)

    def test_reject_reasons_serialised(self):
        store = SQLiteAssessmentStore(":memory:")
        r = make_record()
        r.reject_reasons = ["blurry", "dark"]
        inserted = store.insert(r)
        got = store.get(inserted.id)
        assert "blurry" in got.reject_reasons
        assert "dark" in got.reject_reasons

    def test_close_and_no_error(self):
        store = SQLiteAssessmentStore(":memory:")
        store.insert(make_record())
        store.close()
