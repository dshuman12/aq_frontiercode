"""Tests for feature_extractor.py."""

import math
import numpy as np
import pytest
from PIL import Image

from src.backend.app.feature_extractor import (
    BasicFeatureExtractor,
    ColorHistogramExtractor,
    FrequencyFeatureExtractor,
    FullFeatureExtractor,
    ImageFeatureSet,
    TextureFeatureExtractor,
)


def make_image(w=64, h=64, color=(128, 100, 80)):
    return Image.new("RGB", (w, h), color)


def make_noisy_image(w=64, h=64):
    arr = np.random.randint(0, 256, (h, w, 3), dtype=np.uint8)
    return Image.fromarray(arr)


def make_sharp_image(w=64, h=64):
    arr = np.zeros((h, w, 3), dtype=np.uint8)
    arr[::4, :] = 255
    arr[:, ::4] = 255
    return Image.fromarray(arr)


class TestBasicFeatureExtractor:
    def test_extract_returns_features(self):
        ext = BasicFeatureExtractor()
        features = ext.extract(make_image())
        assert features is not None

    def test_brightness_range(self):
        ext = BasicFeatureExtractor()
        f = ext.extract(make_image())
        assert 0.0 <= f.brightness <= 1.0

    def test_contrast_range(self):
        ext = BasicFeatureExtractor()
        f = ext.extract(make_image())
        assert 0.0 <= f.contrast <= 1.0

    def test_megapixels_correct(self):
        ext = BasicFeatureExtractor()
        f = ext.extract(make_image(200, 300))
        assert abs(f.megapixels - 0.06) < 1e-6

    def test_aspect_ratio(self):
        ext = BasicFeatureExtractor()
        f = ext.extract(make_image(200, 100))
        assert abs(f.aspect_ratio - 2.0) < 1e-9

    def test_sharpness_higher_for_sharp(self):
        ext = BasicFeatureExtractor()
        flat = ext.extract(make_image()).sharpness_laplacian
        sharp = ext.extract(make_sharp_image()).sharpness_laplacian
        assert sharp >= flat

    def test_rgba_handled(self):
        ext = BasicFeatureExtractor()
        img = Image.new("RGBA", (64, 64), (100, 100, 100, 255))
        f = ext.extract(img)
        assert f is not None

    def test_edge_density_range(self):
        ext = BasicFeatureExtractor()
        f = ext.extract(make_noisy_image())
        assert 0.0 <= f.edge_density <= 1.0

    def test_channel_means_consistent(self):
        ext = BasicFeatureExtractor()
        img = Image.new("RGB", (64, 64), (200, 100, 50))
        f = ext.extract(img)
        assert f.mean_r > f.mean_g > f.mean_b


class TestTextureFeatureExtractor:
    def test_extract_returns_features(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_image())
        assert f is not None

    def test_lbp_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_image())
        assert 0.0 <= f.lbp_mean <= 1.0
        assert 0.0 <= f.lbp_std <= 1.0

    def test_glcm_contrast_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_noisy_image())
        assert 0.0 <= f.glcm_contrast <= 1.0

    def test_glcm_homogeneity_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_image())
        assert 0.0 <= f.glcm_homogeneity <= 1.0

    def test_glcm_energy_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_image())
        assert 0.0 <= f.glcm_energy <= 1.0

    def test_glcm_entropy_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_noisy_image())
        assert 0.0 <= f.glcm_entropy <= 1.0

    def test_uniform_image_low_contrast(self):
        ext = TextureFeatureExtractor()
        uniform = Image.new("RGB", (64, 64), (128, 128, 128))
        noisy = make_noisy_image()
        f_uniform = ext.extract(uniform)
        f_noisy = ext.extract(noisy)
        assert f_uniform.glcm_contrast <= f_noisy.glcm_contrast + 0.1

    def test_gabor_range(self):
        ext = TextureFeatureExtractor()
        f = ext.extract(make_image())
        assert f.gabor_mean >= 0.0
        assert f.gabor_std >= 0.0


class TestFrequencyFeatureExtractor:
    def test_extract_returns_features(self):
        ext = FrequencyFeatureExtractor()
        f = ext.extract(make_image())
        assert f is not None

    def test_energy_values_non_negative(self):
        ext = FrequencyFeatureExtractor()
        f = ext.extract(make_image())
        assert f.dct_energy_low >= 0.0
        assert f.dct_energy_mid >= 0.0
        assert f.dct_energy_high >= 0.0

    def test_spectral_rolloff_range(self):
        ext = FrequencyFeatureExtractor()
        f = ext.extract(make_noisy_image())
        assert 0.0 <= f.spectral_rolloff <= 1.0

    def test_spectral_flatness_range(self):
        ext = FrequencyFeatureExtractor()
        f = ext.extract(make_noisy_image())
        assert f.spectral_flatness >= 0.0


class TestColorHistogramExtractor:
    def test_rgb_histogram_length(self):
        ext = ColorHistogramExtractor(bins=16)
        hist = ext.extract_rgb(make_image())
        assert len(hist) == 48  # 3 channels × 16 bins

    def test_hsv_histogram_length(self):
        ext = ColorHistogramExtractor(bins=16)
        hist = ext.extract_hsv(make_image())
        assert len(hist) == 48

    def test_rgb_histogram_sums_to_one_per_channel(self):
        ext = ColorHistogramExtractor(bins=8)
        hist = ext.extract_rgb(make_image())
        for ch in range(3):
            channel_bins = hist[ch * 8:(ch + 1) * 8]
            assert abs(sum(channel_bins) - 1.0) < 1e-6

    def test_different_colors_different_histograms(self):
        ext = ColorHistogramExtractor(bins=16)
        h1 = ext.extract_rgb(Image.new("RGB", (64, 64), (255, 0, 0)))
        h2 = ext.extract_rgb(Image.new("RGB", (64, 64), (0, 0, 255)))
        assert h1 != h2


class TestFullFeatureExtractor:
    def test_extract_returns_feature_set(self):
        ext = FullFeatureExtractor()
        fs = ext.extract(make_image())
        assert isinstance(fs, ImageFeatureSet)

    def test_to_vector_is_numpy(self):
        ext = FullFeatureExtractor()
        vec = ext.extract_vector(make_image())
        assert isinstance(vec, np.ndarray)
        assert vec.dtype == np.float32

    def test_to_vector_consistent_length(self):
        ext = FullFeatureExtractor()
        v1 = ext.extract_vector(make_image(64, 64))
        v2 = ext.extract_vector(make_image(128, 128))
        assert len(v1) == len(v2)

    def test_extract_batch_length(self):
        ext = FullFeatureExtractor()
        images = [make_image() for _ in range(5)]
        results = ext.extract_batch(images)
        assert len(results) == 5

    def test_extract_vectors_batch_shape(self):
        ext = FullFeatureExtractor()
        images = [make_image() for _ in range(4)]
        mat = ext.extract_vectors_batch(images)
        assert mat.shape[0] == 4

    def test_different_images_different_vectors(self):
        ext = FullFeatureExtractor()
        v1 = ext.extract_vector(Image.new("RGB", (64, 64), (255, 0, 0)))
        v2 = ext.extract_vector(Image.new("RGB", (64, 64), (0, 0, 255)))
        assert not np.array_equal(v1, v2)

    def test_extract_vectors_empty_returns_empty(self):
        ext = FullFeatureExtractor()
        mat = ext.extract_vectors_batch([])
        assert mat.shape == (0,)
