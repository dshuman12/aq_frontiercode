import pytest
from pydantic import ValidationError
from src.backend.app.models import ImageScore, BatchRequest, FilterRequest, QualityTier


def test_image_score_valid():
    s = ImageScore(image_path="img.jpg", brisque_score=20.0, nima_score=6.5)
    assert s.brisque_score == 20.0


def test_image_score_negative_brisque_invalid():
    with pytest.raises(ValidationError):
        ImageScore(image_path="img.jpg", brisque_score=-1.0)


def test_image_score_nima_out_of_range():
    with pytest.raises(ValidationError):
        ImageScore(image_path="img.jpg", nima_score=11.0)


def test_batch_request_empty_paths():
    with pytest.raises(ValidationError):
        BatchRequest(image_paths=[], customer_id="cust1")


def test_batch_request_valid():
    r = BatchRequest(image_paths=["a.jpg", "b.jpg"], customer_id="cust1")
    assert len(r.image_paths) == 2


def test_filter_request_top_n_zero_invalid():
    scores = [ImageScore(image_path="a.jpg")]
    with pytest.raises(ValidationError):
        FilterRequest(scores=scores, top_n=0)

# add test for metrics

# add markdown report output

# add filter scores by tier
