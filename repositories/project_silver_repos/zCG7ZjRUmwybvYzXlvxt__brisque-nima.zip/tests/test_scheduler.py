"""Tests for scheduler.py."""

import time
import pytest

from src.backend.app.scheduler import (
    InMemoryJobStore,
    JobPriority,
    JobRecord,
    JobScheduler,
    JobSpec,
    JobStatus,
    RateLimiter,
    RetryPolicy,
)


def make_spec(task="assess_image", priority=JobPriority.NORMAL, tags=None):
    import uuid
    return JobSpec(
        job_id=str(uuid.uuid4()),
        task_name=task,
        args=["/tmp/img.jpg"],
        priority=priority,
        tags=tags or [],
    )


class TestInMemoryJobStore:
    def test_put_and_get(self):
        store = InMemoryJobStore()
        spec = make_spec()
        record = JobRecord(spec=spec)
        store.put(record)
        got = store.get(spec.job_id)
        assert got is not None
        assert got.spec.job_id == spec.job_id

    def test_get_missing(self):
        store = InMemoryJobStore()
        assert store.get("nonexistent") is None

    def test_update_status(self):
        store = InMemoryJobStore()
        spec = make_spec()
        store.put(JobRecord(spec=spec))
        result = store.update_status(spec.job_id, JobStatus.RUNNING)
        assert result is True
        record = store.get(spec.job_id)
        assert record.status == JobStatus.RUNNING

    def test_update_status_missing(self):
        store = InMemoryJobStore()
        result = store.update_status("bad_id", JobStatus.RUNNING)
        assert result is False

    def test_list_by_status(self):
        store = InMemoryJobStore()
        for _ in range(3):
            spec = make_spec()
            store.put(JobRecord(spec=spec, status=JobStatus.QUEUED))
        for _ in range(2):
            spec = make_spec()
            store.put(JobRecord(spec=spec, status=JobStatus.RUNNING))
        queued = store.list_by_status(JobStatus.QUEUED)
        assert len(queued) == 3

    def test_list_by_tag(self):
        store = InMemoryJobStore()
        spec1 = make_spec(tags=["batch:abc"])
        spec2 = make_spec(tags=["batch:xyz"])
        store.put(JobRecord(spec=spec1))
        store.put(JobRecord(spec=spec2))
        tagged = store.list_by_tag("batch:abc")
        assert len(tagged) == 1

    def test_delete(self):
        store = InMemoryJobStore()
        spec = make_spec()
        store.put(JobRecord(spec=spec))
        assert store.delete(spec.job_id) is True
        assert store.get(spec.job_id) is None

    def test_delete_missing(self):
        store = InMemoryJobStore()
        assert store.delete("nope") is False

    def test_stats_counts(self):
        store = InMemoryJobStore()
        for _ in range(3):
            spec = make_spec()
            store.put(JobRecord(spec=spec, status=JobStatus.QUEUED))
        for _ in range(2):
            spec = make_spec()
            store.put(JobRecord(spec=spec, status=JobStatus.COMPLETED))
        stats = store.stats()
        assert stats["total"] == 5
        assert stats[JobStatus.QUEUED.value] == 3
        assert stats[JobStatus.COMPLETED.value] == 2

    def test_update_with_extra_fields(self):
        store = InMemoryJobStore()
        spec = make_spec()
        store.put(JobRecord(spec=spec))
        store.update_status(spec.job_id, JobStatus.RUNNING, progress=0.5)
        record = store.get(spec.job_id)
        assert abs(record.progress - 0.5) < 1e-9

    def test_thread_safety(self):
        import threading
        store = InMemoryJobStore()
        errors = []

        def worker(start):
            try:
                for i in range(start, start + 20):
                    spec = make_spec()
                    store.put(JobRecord(spec=spec))
                    store.get(spec.job_id)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i * 20,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert errors == []


class TestJobScheduler:
    def test_submit_returns_record(self):
        sched = JobScheduler()
        spec = make_spec()
        record = sched.submit(spec)
        assert isinstance(record, JobRecord)
        assert record.spec.job_id == spec.job_id

    def test_submit_status_queued(self):
        sched = JobScheduler()
        record = sched.submit(make_spec())
        assert record.status == JobStatus.QUEUED

    def test_get_status_existing(self):
        sched = JobScheduler()
        spec = make_spec()
        sched.submit(spec)
        status = sched.get_status(spec.job_id)
        assert status is not None
        assert status["job_id"] == spec.job_id

    def test_get_status_missing(self):
        sched = JobScheduler()
        assert sched.get_status("nonexistent") is None

    def test_cancel_queued_job(self):
        sched = JobScheduler()
        spec = make_spec()
        sched.submit(spec)
        result = sched.cancel(spec.job_id)
        assert result is True
        status = sched.get_status(spec.job_id)
        assert status["status"] == JobStatus.CANCELLED.value

    def test_cancel_completed_job(self):
        sched = JobScheduler()
        spec = make_spec()
        sched.submit(spec)
        sched._store.update_status(spec.job_id, JobStatus.COMPLETED)
        result = sched.cancel(spec.job_id)
        assert result is False

    def test_cancel_missing_job(self):
        sched = JobScheduler()
        assert sched.cancel("nope") is False

    def test_list_jobs_all(self):
        sched = JobScheduler()
        for _ in range(5):
            sched.submit(make_spec())
        jobs = sched.list_jobs()
        assert len(jobs) == 5

    def test_list_jobs_by_status(self):
        sched = JobScheduler()
        sched.submit(make_spec())
        jobs = sched.list_jobs(status=JobStatus.QUEUED)
        assert len(jobs) == 1

    def test_list_jobs_by_tag(self):
        sched = JobScheduler()
        sched.submit(make_spec(tags=["client:abc"]))
        sched.submit(make_spec(tags=["client:xyz"]))
        jobs = sched.list_jobs(tag="client:abc")
        assert len(jobs) == 1

    def test_queue_stats_keys(self):
        sched = JobScheduler()
        sched.submit(make_spec())
        stats = sched.queue_stats()
        assert "total" in stats

    def test_submit_batch_assessment(self):
        sched = JobScheduler()
        paths = [f"/img/photo_{i}.jpg" for i in range(10)]
        records = sched.submit_batch_assessment(paths, batch_id="testbatch")
        assert len(records) == 10
        for r in records:
            assert "batch:testbatch" in r.spec.tags


class TestJobRecord:
    def test_duration_none_before_finish(self):
        record = JobRecord(spec=make_spec())
        assert record.duration_seconds is None

    def test_duration_computed(self):
        record = JobRecord(spec=make_spec())
        record.started_at = 100.0
        record.finished_at = 115.0
        assert abs(record.duration_seconds - 15.0) < 1e-9

    def test_to_dict_keys(self):
        record = JobRecord(spec=make_spec())
        d = record.to_dict()
        for key in ("job_id", "task", "status", "priority", "attempt", "progress"):
            assert key in d


class TestRetryPolicy:
    def test_should_retry_within_limit(self):
        policy = RetryPolicy(max_retries=3)
        assert policy.should_retry(0, Exception("err")) is True
        assert policy.should_retry(2, Exception("err")) is True

    def test_should_not_retry_over_limit(self):
        policy = RetryPolicy(max_retries=3)
        assert policy.should_retry(3, Exception("err")) is False

    def test_no_retry_for_value_error(self):
        policy = RetryPolicy(max_retries=5)
        assert policy.should_retry(0, ValueError("bad input")) is False

    def test_delay_increases_with_attempts(self):
        policy = RetryPolicy(base_delay=1.0, backoff_factor=2.0, jitter=False)
        d0 = policy.delay_for_attempt(0)
        d1 = policy.delay_for_attempt(1)
        d2 = policy.delay_for_attempt(2)
        assert d1 > d0
        assert d2 > d1

    def test_delay_capped_at_max(self):
        policy = RetryPolicy(base_delay=1.0, max_delay=5.0, backoff_factor=10.0, jitter=False)
        for attempt in range(10):
            assert policy.delay_for_attempt(attempt) <= 5.0


class TestRateLimiter:
    def test_acquire_within_burst(self):
        rl = RateLimiter(rate=100.0, burst=10)
        for _ in range(10):
            assert rl.acquire() is True

    def test_acquire_exceeds_burst(self):
        rl = RateLimiter(rate=0.1, burst=5)
        for _ in range(5):
            rl.acquire()
        assert rl.acquire() is False

    def test_wait_and_acquire_timeout(self):
        rl = RateLimiter(rate=0.001, burst=0)
        result = rl.wait_and_acquire(timeout=0.05)
        assert result is False
