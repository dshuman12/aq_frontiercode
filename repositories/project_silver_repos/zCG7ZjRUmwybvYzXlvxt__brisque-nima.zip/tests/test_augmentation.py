"""Tests for augmentation module."""
import numpy as np
import pytest

from src.backend.app.augmentation import (
    AugmentConfig,
    AugmentResult,
    ImageAugmenter,
    JpegSimulator,
    ResizeOp,
    NormalizationPipeline,
    center_crop,
    random_crop,
    five_crop,
    pad_to_square,
    histogram_equalization,
    clahe_approximation,
    _gaussian_blur_numpy,
    _gaussian_kernel_1d,
)


def make_gray(h: int = 64, w: int = 64) -> np.ndarray:
    return np.random.randint(0, 256, (h, w), dtype=np.uint8)


def make_rgb(h: int = 64, w: int = 64) -> np.ndarray:
    return np.random.randint(0, 256, (h, w, 3), dtype=np.uint8)


class TestImageAugmenter:
    def test_default_config(self):
        aug = ImageAugmenter()
        assert aug.config is not None

    def test_augment_rgb(self):
        aug = ImageAugmenter(AugmentConfig(seed=0))
        img = make_rgb()
        out, result = aug.augment(img, p=1.0)
        assert out.shape == img.shape
        assert out.dtype == np.uint8
        assert isinstance(result, AugmentResult)
        assert len(result.applied) > 0

    def test_augment_grayscale(self):
        aug = ImageAugmenter(AugmentConfig(seed=1))
        img = make_gray()
        out, result = aug.augment(img, p=0.5)
        assert out.shape == img.shape
        assert out.dtype == np.uint8

    def test_deterministic_with_seed(self):
        img = make_rgb(seed=42) if False else make_rgb()
        aug1 = ImageAugmenter(AugmentConfig(seed=99))
        aug2 = ImageAugmenter(AugmentConfig(seed=99))
        out1, _ = aug1.augment(img.copy(), p=0.8)
        out2, _ = aug2.augment(img.copy(), p=0.8)
        np.testing.assert_array_equal(out1, out2)

    def test_output_range(self):
        aug = ImageAugmenter(AugmentConfig(seed=7, noise_std_range=(0.1, 0.2)))
        img = make_rgb()
        out, _ = aug.augment(img, p=1.0)
        assert out.min() >= 0
        assert out.max() <= 255

    def test_no_augmentation_at_p_zero(self):
        aug = ImageAugmenter(AugmentConfig(seed=3))
        img = make_rgb()
        out, result = aug.augment(img.copy(), p=0.0)
        assert len(result.applied) == 0
        np.testing.assert_array_equal(out, img)

    def test_horizontal_flip_shape_preserved(self):
        aug = ImageAugmenter(AugmentConfig(seed=5, flip_horizontal=True, flip_vertical=False))
        img = make_rgb(32, 64)
        out, _ = aug.augment(img, p=1.0)
        assert out.shape == (32, 64, 3)

    def test_result_applied_list(self):
        aug = ImageAugmenter(AugmentConfig(seed=2))
        img = make_rgb()
        _, result = aug.augment(img, p=1.0)
        for name in result.applied:
            assert isinstance(name, str)
            assert len(name) > 0


def make_rgb(h: int = 64, w: int = 64) -> np.ndarray:
    rng = np.random.default_rng(42)
    return rng.integers(0, 256, (h, w, 3), dtype=np.uint8)


def make_gray(h: int = 64, w: int = 64) -> np.ndarray:
    rng = np.random.default_rng(42)
    return rng.integers(0, 256, (h, w), dtype=np.uint8)


class TestGaussianKernel:
    def test_kernel_sums_to_one(self):
        k = _gaussian_kernel_1d(7, 1.5)
        assert abs(k.sum() - 1.0) < 1e-5

    def test_kernel_is_symmetric(self):
        k = _gaussian_kernel_1d(9, 2.0)
        np.testing.assert_allclose(k, k[::-1], atol=1e-6)

    def test_kernel_size_one(self):
        k = _gaussian_kernel_1d(1, 1.0)
        assert len(k) == 1
        assert abs(k[0] - 1.0) < 1e-5


class TestGaussianBlur:
    def test_blur_preserves_shape_2d(self):
        img = make_gray()
        blurred = _gaussian_blur_numpy(img.astype(np.float32), 5, 1.0)
        assert blurred.shape == img.shape

    def test_blur_preserves_shape_3d(self):
        img = make_rgb().astype(np.float32)
        blurred = _gaussian_blur_numpy(img, 5, 1.0)
        assert blurred.shape == img.shape

    def test_uniform_image_unchanged_by_blur(self):
        img = np.ones((32, 32), dtype=np.float32) * 128.0
        blurred = _gaussian_blur_numpy(img, 5, 1.0)
        np.testing.assert_allclose(blurred, img, atol=0.1)


class TestJpegSimulator:
    def test_output_shape_preserved(self):
        js = JpegSimulator(quality=75)
        img = make_rgb(64, 64)
        out = js.compress(img)
        assert out.shape == img.shape

    def test_output_dtype_uint8(self):
        js = JpegSimulator(quality=50)
        img = make_gray(16, 16)
        out = js.compress(img)
        assert out.dtype == np.uint8

    def test_high_quality_closer_to_original(self):
        js_high = JpegSimulator(quality=95)
        js_low = JpegSimulator(quality=10)
        img = make_rgb(64, 64)
        out_high = js_high.compress(img)
        out_low = js_low.compress(img)
        diff_high = np.abs(img.astype(int) - out_high.astype(int)).mean()
        diff_low = np.abs(img.astype(int) - out_low.astype(int)).mean()
        assert diff_high <= diff_low

    def test_quality_range_clamped(self):
        js = JpegSimulator(quality=110)
        assert js.quality == 100
        js2 = JpegSimulator(quality=0)
        assert js2.quality == 1


class TestResizeOp:
    def test_bilinear_resize_rgb(self):
        op = ResizeOp("bilinear")
        img = make_rgb(64, 64)
        out = op.resize(img, 32, 32)
        assert out.shape == (32, 32, 3)

    def test_nearest_resize_gray(self):
        op = ResizeOp("nearest")
        img = make_gray(32, 32)
        out = op.resize(img, 64, 64)
        assert out.shape == (64, 64)

    def test_no_op_when_same_size(self):
        op = ResizeOp("bilinear")
        img = make_rgb(32, 32)
        out = op.resize(img, 32, 32)
        np.testing.assert_array_equal(out, img)

    def test_invalid_method_raises(self):
        with pytest.raises(ValueError):
            ResizeOp("cubic")

    def test_upscale_bilinear(self):
        op = ResizeOp("bilinear")
        img = make_gray(8, 8)
        out = op.resize(img, 32, 32)
        assert out.shape == (32, 32)


class TestNormalizationPipeline:
    def test_normalize_range(self):
        pipe = NormalizationPipeline()
        img = make_rgb()
        normed = pipe.normalize(img)
        assert normed.dtype == np.float32

    def test_round_trip(self):
        pipe = NormalizationPipeline(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        img = make_rgb()
        normed = pipe.normalize(img)
        recovered = pipe.denormalize(normed)
        diff = np.abs(img.astype(float) - recovered.astype(float)).mean()
        assert diff < 2.0

    def test_to_float_range(self):
        img = make_rgb()
        f = NormalizationPipeline.to_float(img)
        assert f.min() >= 0.0
        assert f.max() <= 1.0

    def test_to_uint8(self):
        arr = np.ones((4, 4, 3), dtype=np.float32) * 0.5
        out = NormalizationPipeline.to_uint8(arr)
        assert out.dtype == np.uint8
        assert out[0, 0, 0] == 127

    def test_standardize_zero_mean(self):
        img = make_gray().astype(np.float32)
        s = NormalizationPipeline.standardize_zero_mean(img)
        assert abs(s.mean()) < 0.01
        assert abs(s.std() - 1.0) < 0.01


class TestCropFunctions:
    def test_center_crop_shape(self):
        img = make_rgb(64, 64)
        out = center_crop(img, 32, 32)
        assert out.shape == (32, 32, 3)

    def test_center_crop_grayscale(self):
        img = make_gray(64, 64)
        out = center_crop(img, 20, 30)
        assert out.shape == (20, 30)

    def test_random_crop_shape(self):
        img = make_rgb(64, 64)
        out, pos = random_crop(img, 32, 32)
        assert out.shape == (32, 32, 3)
        assert pos[0] >= 0
        assert pos[1] >= 0

    def test_five_crop_returns_five(self):
        img = make_rgb(64, 64)
        crops = five_crop(img, 32, 32)
        assert len(crops) == 5
        for c in crops:
            assert c.shape == (32, 32, 3)

    def test_pad_to_square_wide(self):
        img = make_rgb(32, 64)
        out = pad_to_square(img)
        assert out.shape[0] == out.shape[1]
        assert out.shape[0] == 64

    def test_pad_to_square_tall(self):
        img = make_gray(64, 32)
        out = pad_to_square(img)
        assert out.shape == (64, 64)

    def test_pad_to_square_already_square(self):
        img = make_rgb(32, 32)
        out = pad_to_square(img)
        np.testing.assert_array_equal(out, img)


class TestHistogramEqualization:
    def test_output_shape(self):
        img = make_gray()
        out = histogram_equalization(img)
        assert out.shape == img.shape

    def test_output_dtype(self):
        img = make_gray()
        out = histogram_equalization(img)
        assert out.dtype == np.uint8

    def test_rejects_rgb(self):
        img = make_rgb()
        with pytest.raises(ValueError):
            histogram_equalization(img)

    def test_uniform_image(self):
        img = np.ones((32, 32), dtype=np.uint8) * 100
        out = histogram_equalization(img)
        assert out.shape == (32, 32)


class TestCLAHE:
    def test_output_shape(self):
        img = make_gray()
        out = clahe_approximation(img)
        assert out.shape == img.shape

    def test_output_dtype(self):
        img = make_gray()
        out = clahe_approximation(img)
        assert out.dtype == np.uint8

    def test_rejects_rgb(self):
        with pytest.raises(ValueError):
            clahe_approximation(make_rgb())

    def test_custom_tile_size(self):
        img = make_gray(64, 64)
        out = clahe_approximation(img, tile_size=16)
        assert out.shape == img.shape
