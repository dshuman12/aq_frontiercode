import pytest
from src.backend.app.models import ImageScore, QualityTier
from src.backend.app.metrics import mean, stddev, percentile, score_distribution, acceptance_rate, top_k


def make_score(composite, tier=None, error=None):
    return ImageScore(image_path="x.jpg", composite_score=composite, quality_tier=tier, error=error)


def test_mean_empty():
    assert mean([]) is None


def test_mean():
    assert mean([2.0, 4.0, 6.0]) == pytest.approx(4.0)


def test_stddev_single():
    assert stddev([5.0]) is None


def test_stddev():
    result = stddev([2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0])
    assert result == pytest.approx(2.0)


def test_percentile_median():
    values = [1.0, 2.0, 3.0, 4.0, 5.0]
    assert percentile(values, 50) == pytest.approx(3.0)


def test_score_distribution():
    scores = [
        make_score(7.5, QualityTier.good),
        make_score(4.0, QualityTier.poor),
        make_score(None, error="failed"),
    ]
    dist = score_distribution(scores)
    assert dist["count"] == 3
    assert dist["scored"] == 2
    assert dist["failed"] == 1
    assert dist["tier_distribution"]["good"] == 1
    assert dist["tier_distribution"]["poor"] == 1


def test_acceptance_rate():
    scores = [make_score(6.0), make_score(4.0), make_score(7.0)]
    rate = acceptance_rate(scores, min_composite=5.0)
    assert rate == pytest.approx(2 / 3)


def test_top_k():
    scores = [make_score(3.0), make_score(8.0), make_score(5.5)]
    result = top_k(scores, 2)
    assert result[0].composite_score == 8.0
    assert result[1].composite_score == 5.5

# add duration tracking in batch

# add docker-compose stub
