"""Tests for reporter.py."""

import io
import json
import pytest

from src.backend.app.reporter import (
    CSVReporter,
    GradeDistribution,
    HTMLReporter,
    JSONReporter,
    MarkdownReporter,
    StatsSummary,
)


def make_result(path="img.jpg", brisque_q=0.7, nima=0.65, grade="good", passed=True, error=None):
    return {
        "path": path,
        "brisque_raw": 30.0,
        "brisque_quality": brisque_q,
        "nima_raw": 5.8,
        "nima_score": nima,
        "combined_score": (brisque_q + nima) / 2,
        "grade": grade,
        "passed": passed,
        "reject_reasons": [],
        "error": error,
    }


class TestStatsSummary:
    def test_compute_basic(self):
        ss = StatsSummary([0.2, 0.5, 0.8])
        stats = ss.compute()
        assert stats["count"] == 3
        assert abs(stats["mean"] - 0.5) < 1e-9
        assert stats["min"] == 0.2
        assert stats["max"] == 0.8

    def test_compute_empty(self):
        ss = StatsSummary([])
        stats = ss.compute()
        assert stats == {"count": 0}

    def test_compute_ignores_nan(self):
        import math
        ss = StatsSummary([0.5, float("nan"), 0.7])
        stats = ss.compute()
        assert stats["count"] == 2

    def test_percentiles_present(self):
        ss = StatsSummary(list(range(1, 101)))
        stats = ss.compute()
        for key in ("p10", "p25", "median", "p75", "p90"):
            assert key in stats

    def test_histogram_bins_count(self):
        ss = StatsSummary([i / 100 for i in range(101)])
        bins = ss.histogram_bins(n_bins=5)
        assert len(bins) == 5

    def test_histogram_bins_empty(self):
        ss = StatsSummary([])
        bins = ss.histogram_bins()
        assert bins == []

    def test_histogram_bin_structure(self):
        ss = StatsSummary([0.3, 0.5, 0.7])
        bins = ss.histogram_bins(n_bins=3)
        for b in bins:
            assert "low" in b and "high" in b and "count" in b


class TestGradeDistribution:
    def test_record_and_count(self):
        gd = GradeDistribution()
        gd.record("excellent")
        gd.record("good")
        gd.record("good")
        dist = gd.distribution()
        assert dist["excellent"]["count"] == 1
        assert dist["good"]["count"] == 2

    def test_percentage(self):
        gd = GradeDistribution()
        for _ in range(4):
            gd.record("good")
        for _ in range(6):
            gd.record("excellent")
        dist = gd.distribution()
        assert abs(dist["good"]["pct"] - 40.0) < 1e-9
        assert abs(dist["excellent"]["pct"] - 60.0) < 1e-9

    def test_unknown_grade_falls_to_poor(self):
        gd = GradeDistribution()
        gd.record("unknown_grade")
        dist = gd.distribution()
        assert dist["poor"]["count"] == 1

    def test_all_grades_present(self):
        gd = GradeDistribution()
        dist = gd.distribution()
        for grade in ("excellent", "good", "acceptable", "poor", "reject"):
            assert grade in dist

    def test_total_count(self):
        gd = GradeDistribution()
        for g in ("excellent", "good", "poor", "reject", "acceptable"):
            gd.record(g)
        dist = gd.distribution()
        assert dist["total"] == 5


class TestJSONReporter:
    def test_generate_valid_json(self):
        rep = JSONReporter()
        results = [make_result(f"img_{i}.jpg") for i in range(3)]
        out = rep.generate(results)
        parsed = json.loads(out)
        assert "results" in parsed
        assert "summary" in parsed
        assert len(parsed["results"]) == 3

    def test_summary_keys(self):
        rep = JSONReporter()
        results = [make_result()]
        parsed = json.loads(rep.generate(results))
        summary = parsed["summary"]
        for key in ("total", "successful", "failed", "passed", "rejected", "brisque", "nima", "grades"):
            assert key in summary

    def test_failed_counted(self):
        rep = JSONReporter()
        results = [make_result(error="load error")]
        parsed = json.loads(rep.generate(results))
        assert parsed["summary"]["failed"] == 1

    def test_metadata_included(self):
        rep = JSONReporter()
        results = [make_result()]
        parsed = json.loads(rep.generate(results, metadata={"job": "test_job"}))
        assert parsed["metadata"]["job"] == "test_job"

    def test_to_buffer_readable(self):
        rep = JSONReporter()
        buf = rep.generate_to_buffer([make_result()])
        content = json.loads(buf.read().decode("utf-8"))
        assert "results" in content

    def test_grade_distribution_in_summary(self):
        rep = JSONReporter()
        results = [make_result(grade="excellent"), make_result(grade="poor")]
        parsed = json.loads(rep.generate(results))
        grades = parsed["summary"]["grades"]
        assert grades["excellent"]["count"] == 1
        assert grades["poor"]["count"] == 1


class TestCSVReporter:
    def test_generate_has_header(self):
        rep = CSVReporter()
        results = [make_result()]
        csv_str = rep.generate(results)
        assert "path" in csv_str
        assert "brisque_quality" in csv_str

    def test_generate_has_data(self):
        rep = CSVReporter()
        results = [make_result("my_photo.jpg")]
        csv_str = rep.generate(results)
        assert "my_photo.jpg" in csv_str

    def test_multiple_results(self):
        rep = CSVReporter()
        results = [make_result(f"img_{i}.jpg") for i in range(5)]
        csv_str = rep.generate(results)
        lines = [l for l in csv_str.strip().split("\n") if l]
        assert len(lines) == 6  # header + 5 rows

    def test_reject_reasons_joined(self):
        rep = CSVReporter()
        r = make_result()
        r["reject_reasons"] = ["blurry", "dark"]
        csv_str = rep.generate([r])
        assert "blurry" in csv_str

    def test_to_buffer_readable(self):
        rep = CSVReporter()
        buf = rep.generate_to_buffer([make_result()])
        content = buf.read().decode("utf-8")
        assert "path" in content

    def test_error_result_included(self):
        rep = CSVReporter()
        r = make_result(error="decode failed")
        csv_str = rep.generate([r])
        assert "decode failed" in csv_str


class TestHTMLReporter:
    def test_generate_valid_html(self):
        rep = HTMLReporter()
        results = [make_result()]
        html = rep.generate(results)
        assert "<!DOCTYPE html>" in html
        assert "<table" in html

    def test_title_in_html(self):
        rep = HTMLReporter()
        html = rep.generate([make_result()], title="My Custom Report")
        assert "My Custom Report" in html

    def test_all_grades_in_table(self):
        rep = HTMLReporter()
        results = [make_result(grade=g) for g in ("excellent", "good", "poor", "reject")]
        html = rep.generate(results)
        for grade in ("excellent", "good", "poor", "reject"):
            assert grade in html

    def test_to_buffer(self):
        rep = HTMLReporter()
        buf = rep.generate_to_buffer([make_result()])
        content = buf.read().decode("utf-8")
        assert "<html" in content

    def test_basename_extraction(self):
        assert HTMLReporter._basename("/path/to/photo.jpg") == "photo.jpg"
        assert HTMLReporter._basename("") == ""


class TestMarkdownReporter:
    def test_generate_has_headers(self):
        rep = MarkdownReporter()
        results = [make_result()]
        md = rep.generate(results)
        assert "# " in md
        assert "## " in md

    def test_title_in_output(self):
        rep = MarkdownReporter()
        md = rep.generate([make_result()], title="Custom Title")
        assert "Custom Title" in md

    def test_grade_table_present(self):
        rep = MarkdownReporter()
        md = rep.generate([make_result(grade="excellent")])
        assert "Grade Distribution" in md
        assert "excellent" in md

    def test_statistics_tables_present(self):
        rep = MarkdownReporter()
        results = [make_result(brisque_q=0.7, nima=0.65) for _ in range(5)]
        md = rep.generate(results)
        assert "BRISQUE" in md
        assert "NIMA" in md

    def test_empty_results(self):
        rep = MarkdownReporter()
        md = rep.generate([])
        assert "# " in md
