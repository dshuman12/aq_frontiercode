import time
import pytest
from src.backend.app.cache import TTLCache


def test_set_and_get():
    cache = TTLCache(default_ttl=10.0)
    cache.set("key1", "value1")
    assert cache.get("key1") == "value1"


def test_missing_key_returns_none():
    cache = TTLCache()
    assert cache.get("nonexistent") is None


def test_expired_entry_returns_none():
    cache = TTLCache(default_ttl=0.05)
    cache.set("k", "v")
    time.sleep(0.1)
    assert cache.get("k") is None


def test_custom_ttl():
    cache = TTLCache(default_ttl=10.0)
    cache.set("k", "v", ttl=0.05)
    assert cache.get("k") == "v"
    time.sleep(0.1)
    assert cache.get("k") is None


def test_delete():
    cache = TTLCache()
    cache.set("k", "v")
    assert cache.delete("k") is True
    assert cache.get("k") is None
    assert cache.delete("k") is False


def test_clear():
    cache = TTLCache()
    cache.set("a", 1)
    cache.set("b", 2)
    cache.clear()
    assert cache.size() == 0


def test_stats():
    cache = TTLCache(default_ttl=0.05)
    cache.set("a", 1)
    cache.set("b", 2, ttl=10.0)
    time.sleep(0.1)
    stats = cache.stats()
    assert stats["total"] == 2
    assert stats["expired"] == 1
    assert stats["active"] == 1

# add storage adapter

# add TTL cache

# add Pydantic models

# add batch processor

# add metrics utilities

# add run_local script

# improve test coverage

# update requirements
