#!/usr/bin/env python3
from __future__ import annotations

from celery import Celery
import os
from typing import List, Dict, Any

from app.analyzer import BrisqueNimaAnalyzer

BROKER = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
BACKEND = os.getenv('CELERY_RESULT_BACKEND', BROKER)

app = Celery('brisque_nima', broker=BROKER, backend=BACKEND)
app.conf.update(
    task_serializer='json',
    result_serializer='json',
    accept_content=['json'],
    timezone='UTC',
    enable_utc=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    worker_disable_rate_limits=True,
)

_ANALYZER = None

def get_analyzer() -> BrisqueNimaAnalyzer:
    global _ANALYZER
    if _ANALYZER is None:
        _ANALYZER = BrisqueNimaAnalyzer()
    return _ANALYZER

@app.task(name='brisque_nima.score_batch')
def score_batch(items: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    analyzer = get_analyzer()
    return analyzer.score_batch(items)

# add test for models

# add validate config method

# add asyncio batch executor

# add static file serving

# add utc datetime fields
