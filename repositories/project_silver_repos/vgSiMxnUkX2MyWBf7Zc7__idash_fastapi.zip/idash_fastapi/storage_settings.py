
import os
import shutil
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB
from hiper_utils.other_utils.redis_util import RedisUtil
from hiper_utils.aws.s3.s3 import S3Bucket
from datetime import datetime,timedelta

# get the current date in iso format
current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def get_current_date():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

seven_days_from_now = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")


def calculate_seven_days(date=None):
    if date is None:
        date = datetime.now()
    return (date + timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")

rds_instance = MySQLDB(
    db_name="new_schema",
    env_var_prefix="MYSQL_DEV"
)

prod_rds_instance = MySQLDB(
    db_name="new_production_schema",
    env_var_prefix="MYSQL"
)





redis_instance = RedisUtil(host='localhost', port=6379, db=0)


# s3 bug init
hiperft_bucket = S3Bucket(
    bucket_name="hiperdatalake"
)

hiperd_lake_bucket = S3Bucket(
    bucket_name="hiperdatalake"
)

AWS_STORAGE_BUCKET_NAME = "hiperftp"



# Define the path for the employees
employees_path = "employees/test/"

# path to feature_tickets in s3
feat_ticket_path = "tickets/test/feature_tickets/"
feat_ticket_attachment_path = "tickets/test/feature_tickets/attachments/"

# path to bug_tickets in s3
bug_ticket_path = "tickets/test/bug_tickets/"
bug_ticket_attachment_path = "tickets/test/bug_tickets/attachments/"

# path to vehicle_health_tickets in s3
vehicle_health_ticket_path = "tickets/test/vehicle_health_tickets/"
vehicle_health_ticket_attachment_path = "tickets/test/vehicle_health_tickets/attachments/"


# path to vehicle_json in s3
vehicle_data_path = "vehicle_data/"

# path to upload images in s3
hw_img = "hardware/imei_number/images/"

# path to upload hw issues
hw_issues = "hardware/hardware_issues.json"

# path to device files
device_files = "devices/device_id/"

# path to device_info
device_info = f"{device_files}device_info_device_id.bin"

# path to log config files
log_config = "make model/m_m_id/log_config/"

# path to imu config file
imu_config = f"{log_config}imu_config_m_m_id.bin"

# path to can config file
can_config = f"{log_config}can_config_m_m_id.bin"

# pre prod path
pre_prod_path = f"devices/pre_prod_edge_inc.bin"

# prod bin path
prod_bin_path = "devices/test/production_dev_6_dec.bin"


# Global temporary directory
GLOBAL_TEMP_DIR = "./temp_files"

# Ensure the global temporary directory exists on startup
if not os.path.exists(GLOBAL_TEMP_DIR):
    os.makedirs(GLOBAL_TEMP_DIR)
    
# function to save a file temporarily
def save_temp_file(file, file_name):
    """
    Save a file temporarily in the global temp directory.

    Args:
        file: The file content (bytes).
        file_name: The name of the file to be saved.

    Returns:
        The full path of the saved file.
    """
    try:
        # Ensure the temp directory exists
        os.makedirs(GLOBAL_TEMP_DIR, exist_ok=True)

        # Define the file path
        temp_file_path = os.path.join(GLOBAL_TEMP_DIR, file_name)

        # Save the file
        with open(temp_file_path, "wb") as temp_file:
            temp_file.write(file)

        print(f"File saved temporarily at: {temp_file_path}")
        return temp_file_path

    except Exception as e:
        raise RuntimeError(f"Error saving temporary file: {str(e)}")



def clean_global_temp_dir():
    """Clean up the global temporary directory."""
    if os.path.exists(GLOBAL_TEMP_DIR):
        shutil.rmtree(GLOBAL_TEMP_DIR)
        print(f"Temporary directory {GLOBAL_TEMP_DIR} cleaned up!")



# edge config path
edge_config_path = "make model/m_m_id/log_config/edge_config_m_m_id.bin"

# hareware reg path 
hw_reg_path = "hardware/hardware_reg.bin"