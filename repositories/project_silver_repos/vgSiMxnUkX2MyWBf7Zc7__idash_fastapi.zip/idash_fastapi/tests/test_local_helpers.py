from datetime import datetime
from pathlib import Path

import pandas as pd
import pytest

from log_processing.log_processing_models import CalculatedSummaryData, DecodeType
from storage_settings import calculate_seven_days, clean_global_temp_dir, save_temp_file
from utils.common_util import update_metadata


def test_update_metadata_mutates_metadata_block_with_user_and_timestamp():
    ticket = {"0": {"updated_by": 1, "updated_on": "old"}}

    updated, bugs = update_metadata(ticket, 42)

    assert bugs == {}
    assert updated is ticket
    assert updated["0"]["updated_by"] == 42
    datetime.strptime(updated["0"]["updated_on"], "%Y-%m-%d %H:%M:%S")


def test_calculate_seven_days_uses_supplied_base_datetime():
    base = datetime(2024, 1, 2, 3, 4, 5)

    assert calculate_seven_days(base) == "2024-01-09 03:04:05"


def test_save_temp_file_writes_bytes_and_cleanup_removes_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    saved_path = Path(save_temp_file(b"abc", "payload.bin"))

    assert saved_path.read_bytes() == b"abc"
    assert saved_path.parent.name == "temp_files"

    clean_global_temp_dir()

    assert not saved_path.parent.exists()


def test_calculated_summary_data_accepts_nested_gps_payload():
    summary = CalculatedSummaryData(
        distance_travelled=12.5,
        gps_data={"start": [12.1, 77.1], "end": [12.2, 77.2]},
        non_idling_seconds=60,
    )

    assert summary.distance_travelled == 12.5
    assert summary.gps_data["start"] == [12.1, 77.1]


def test_decode_type_values_match_log_config_encoding_names():
    assert DecodeType.ASCII.value == "ascii"
    assert DecodeType.DECIMAL.value == "decimal"


def test_vehicle_log_static_pending_file_format():
    vehicle_log_module = pytest.importorskip("log_processing.vehicle_log_process_v2")

    assert vehicle_log_module.VehicleLogProcessor.calculate_pending_files(4, 1) == [
        "l_00002.bin",
        "l_00003.bin",
        "l_00004.bin",
    ]


def test_vehicle_log_static_decoders_handle_ascii_and_big_endian_integer():
    vehicle_log_module = pytest.importorskip("log_processing.vehicle_log_process_v2")

    processor = vehicle_log_module.DeviceLogProcessor

    assert processor.decoded_to_ascii(b"0113") == "0113"
    assert processor.decode_to_decimal(b"\x00\x10") == 16
    assert processor.decode_to_decimal(7) == 7


def test_replace_values_with_nearest_prefers_previous_then_next_values():
    vehicle_log_module = pytest.importorskip("log_processing.vehicle_log_process_v2")
    series = pd.Series([10, 99, 30, 99, 50])
    condition = series == 99

    result = vehicle_log_module.LogProcessorBase.replace_values_with_nearest(series, condition)

    assert result.tolist() == [10, 10, 30, 30, 50]


def test_replace_values_with_nearest_works_for_dataframe_column():
    vehicle_log_module = pytest.importorskip("log_processing.vehicle_log_process_v2")
    df = pd.DataFrame({"speed": [0, -1, -1, 20]})
    condition = df["speed"] < 0

    result = vehicle_log_module.LogProcessorBase.replace_values_with_nearest(
        df,
        condition,
        column_name="speed",
    )

    assert result.tolist() == [0, 0, 0, 20]

