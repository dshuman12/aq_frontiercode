import os
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
VENDOR_ROOT = REPO_ROOT / "vendor"

for path in (REPO_ROOT, REPO_ROOT.parent, VENDOR_ROOT, VENDOR_ROOT / "idash_compat"):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)


DEFAULT_ENV = {
    "_AWS_ACCESS_KEY_ID": "dummy",
    "_AWS_SECRET_ACCESS_KEY": "dummy",
    "REGION_NAME": "us-east-1",
    "MYSQL_HOST": "localhost",
    "MYSQL_PORT": "3306",
    "MYSQL_USER_NAME": "dummy",
    "MYSQL_PASSWORD": "dummy",
    "MYSQL_DEV_HOST": "localhost",
    "MYSQL_DEV_PORT": "3306",
    "MYSQL_DEV_USER_NAME": "dummy",
    "MYSQL_DEV_PASSWORD": "dummy",
    "SECRET_KEY": "dummy",
    "ALGORITHM": "HS256",
}

for key, value in DEFAULT_ENV.items():
    os.environ.setdefault(key, value)

