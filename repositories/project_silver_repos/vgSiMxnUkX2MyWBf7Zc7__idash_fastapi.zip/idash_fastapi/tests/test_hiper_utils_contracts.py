from pydantic import BaseModel

from hiper_utils.Decoraters.exception_handler import (
    append_to_input_data,
    combine_bugs,
    create_bug_instance,
    error_handler,
    serialize_dict,
)
from hiper_utils.data_models.s3_data_models.common_models import (
    ConversationBlock,
    StatusChangeBlock,
    TasksBlock,
)


class InputModel(BaseModel):
    value: int


def test_combine_bugs_appends_local_bugs_after_parent_keys():
    parent = {1: "existing"}
    local = {1: "new"}

    combined = combine_bugs(parent, local)

    assert combined == {1: "existing", 2: "new"}


def test_serialize_dict_preserves_basic_types_and_stringifies_objects():
    payload = {"ok": 1, "model": InputModel(value=3)}

    serialized = serialize_dict(payload)

    assert serialized["ok"] == 1
    assert "value=3" in serialized["model"]


def test_create_bug_instance_builds_code_and_message():
    bugs = create_bug_instance(
        module_code="0701",
        function_code="22",
        error_code="03",
        input_data={"device_id": "DEV"},
        message="bad device",
    )

    bug = bugs[1]
    assert bug.code == "07012203"
    assert bug.input == {"device_id": "DEV"}
    assert bug.message == "bad device"


def test_append_to_input_data_merges_context_into_bug_instances():
    bugs = create_bug_instance("0701", "22", input_data={"device_id": "DEV"})

    append_to_input_data(bugs, {"file_num": "l_00001.bin"})

    assert bugs[1].input == {"device_id": "DEV", "file_num": "l_00001.bin"}


def test_error_handler_returns_result_and_empty_bugs_for_successful_call():
    @error_handler(library_code="9999", function_code="01")
    def add_one(value, bugs={}):
        return value + 1

    result, bugs = add_one(4)

    assert result == 5
    assert bugs == {}


def test_error_handler_converts_exception_to_bug_payload():
    @error_handler(library_code="9999", function_code="02")
    def fail(value):
        raise ValueError(f"bad {value}")

    result, bugs = fail("input")

    assert result is None
    assert list(bugs) == [1]
    assert bugs[1].code == "99990200"
    assert bugs[1].input == {"value": "input"}
    assert "bad input" in bugs[1].message


def test_status_change_block_converts_updater_to_string():
    block = StatusChangeBlock(status_change_description="closed", updated_by=7)

    assert block.type == "4"
    assert block.updated_by == "7"


def test_conversation_block_defaults_attachments_and_notify_users():
    block = ConversationBlock(added_by=1, parent_block=2, text="hello")

    assert block.type == "3"
    assert block.attachments == []
    assert block.users_to_notify == []


def test_tasks_block_defaults_deadline_attachments_and_machine_flag():
    block = TasksBlock(added_by="1", text="follow up")

    assert block.type == "5"
    assert block.attachments == []
    assert block.machine_raised is False
    assert block.deadline

