import importlib
from pathlib import Path


def test_vendored_hiper_utils_snapshot_records_expected_commit():
    commit_file = Path("vendor/hiper_utils/VENDORED_COMMIT")

    assert commit_file.read_text().strip() == "fc8f3c4209e5daa0844038feb5ae73acb5b1a8fe"


def test_core_schema_modules_import_without_live_services():
    modules = [
        "schema.tasks_schema",
        "schema.bug_ticket_schema",
        "schema.feature_ticket_schema",
        "schema.users_schema",
        "schema.vehicle_health_schema",
        "schema.attachments_schema",
        "schema.ops_dash_schema",
        "schema.make_model_schema",
    ]

    for module_name in modules:
        assert importlib.import_module(module_name)


def test_core_local_utility_modules_import_with_dummy_environment():
    modules = [
        "utils.common_util",
        "storage_settings",
        "log_processing.log_processing_models",
    ]

    for module_name in modules:
        assert importlib.import_module(module_name)


def test_approval_compatibility_shims_import():
    assert importlib.import_module("cdash_fastapi.utils.trips_utils")
    assert importlib.import_module("utils.trips_utils")


def test_fastapi_application_imports_with_dummy_environment():
    main = importlib.import_module("main")

    assert main.app is not None
