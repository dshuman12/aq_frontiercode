from datetime import datetime

import pandas as pd
import pytest
from pydantic import ValidationError

from schema.attachments_schema import AddMoreAttachments_Input, DeleteAttachment_Input
from schema.bug_ticket_schema import Close_BugTicket, Transfer_Bug_Block
from schema.feature_ticket_schema import (
    AddPrototype,
    AddSubfeature,
    CloseFeatTicketInput,
    Create_Feature_Ticket_Input,
    EditPrototype,
)
from schema.tasks_schema import AddTask_Input, DeleteTask_Input, UpdateTask_Input
from schema.users_schema import CreateUserModel, LoginUserModel, SignUpModel, Users_Serializer
from schema.vehicle_health_schema import Create_Vehicle_Health_Ticket, TransferAnomalyRequest


def test_add_task_input_applies_default_priority_status_and_machine_flag():
    task = AddTask_Input(
        ticketid=10,
        added_by=4,
        ticket_type=6,
        name="Calibrate edge case",
    )

    assert task.priority == 1
    assert task.status == 1
    assert task.machine_raised is False
    assert task.owner is None


def test_add_task_input_rejects_non_positive_ticket_id():
    with pytest.raises(ValidationError):
        AddTask_Input(ticketid=0, added_by=4, ticket_type=6, name="Bad task")


def test_update_task_input_accepts_false_machine_raised_flag():
    task = UpdateTask_Input(
        ticketid=10,
        ticket_type=6,
        taskid=3,
        updated_by=4,
        machine_raised=False,
    )

    assert task.machine_raised is False


def test_delete_task_input_requires_task_id_list():
    payload = DeleteTask_Input(ticketid=10, ticket_type=6, task_ids=[1, 2], deleted_by=4)

    assert payload.task_ids == [1, 2]


def test_transfer_bug_block_serializes_core_fields():
    transfer = Transfer_Bug_Block(
        source_ticket_id=11,
        target_ticket_id=22,
        block_ids=[3, 4],
        updated_by=5,
    )

    assert transfer.model_dump()["block_ids"] == [3, 4]


def test_close_bug_ticket_keeps_optional_notes_none():
    ticket = Close_BugTicket(ticketid=9, closed_by=2)

    assert ticket.future_imp is None
    assert ticket.learnings is None


def test_feature_ticket_accepts_parseable_requested_eta():
    ticket = Create_Feature_Ticket_Input(
        feature_name="Route replay",
        added_by=4,
        requested_eta="2024-01-09 03:04:05",
    )

    datetime.strptime(ticket.requested_eta, "%Y-%m-%d %H:%M:%S")


def test_feature_ticket_rejects_empty_feature_name():
    with pytest.raises(ValidationError):
        Create_Feature_Ticket_Input(feature_name="", added_by=4)


def test_add_subfeature_requires_non_empty_name_and_description():
    subfeature = AddSubfeature(
        ticketid=5,
        added_by=2,
        sub_feature_name="Trip matching",
        sub_feature_description="Match trips to processed logs",
    )

    assert subfeature.sub_feature_name == "Trip matching"


def test_add_subfeature_rejects_empty_description():
    with pytest.raises(ValidationError):
        AddSubfeature(
            ticketid=5,
            added_by=2,
            sub_feature_name="Trip matching",
            sub_feature_description="",
        )


def test_add_prototype_requires_related_subfeature_block():
    prototype = AddPrototype(
        ticketid=5,
        added_by=2,
        prototype_description="Replay prototype",
        related_sub_feature_block=7,
    )

    assert prototype.related_sub_feature_block == 7


def test_edit_prototype_allows_stage_zero_and_optional_relation():
    prototype = EditPrototype(ticketid=5, updated_by=2, stage=0)

    assert prototype.stage == 0
    assert prototype.related_sub_feature_block is None


def test_edit_prototype_rejects_negative_stage():
    with pytest.raises(ValidationError):
        EditPrototype(ticketid=5, updated_by=2, stage=-1)


def test_close_feature_ticket_optional_summaries_default_to_none():
    payload = CloseFeatTicketInput(ticketid=5, user_id=2)

    assert payload.release_notes is None
    assert payload.future_imp is None
    assert payload.learnings is None


def test_create_user_model_accepts_international_phone_number():
    user = CreateUserModel(
        email="driver@example.com",
        phone_number="+911234567890",
        team_id=3,
        requested_user_id=7,
    )

    assert user.email == "driver@example.com"


def test_create_user_model_rejects_phone_without_country_prefix():
    with pytest.raises(ValidationError):
        CreateUserModel(
            email="driver@example.com",
            phone_number="1234567890",
            team_id=3,
            requested_user_id=7,
        )


def test_signup_model_hashes_password_and_keeps_email_fields():
    signup = SignUpModel(
        username="driver",
        email_id="driver@example.com",
        phone_number="+911234567890",
        first_name="Test",
        last_name="Driver",
        password="plainpassword",
        emergency_contact_name="Dispatch",
        personal_email="personal@example.com",
    )

    assert signup.password != "plainpassword"
    assert signup.password.startswith("$2")
    assert signup.personal_email == "personal@example.com"


def test_login_model_rejects_short_password():
    with pytest.raises(ValidationError):
        LoginUserModel(username="driver", password="short")


def test_users_serializer_builds_fullname_fallbacks_from_dataframe():
    users = pd.DataFrame(
        [
            {"id": 1, "username": "first", "first_name": "First", "last_name": "Last"},
            {"id": 2, "username": "second", "first_name": "Only", "last_name": ""},
            {"id": 3, "username": "third", "first_name": "", "last_name": ""},
        ]
    )

    serialized = Users_Serializer.from_dataframe(users)

    assert serialized.user_id == [1, 2, 3]
    assert serialized.fullname == ["First Last", "Only", "third"]


def test_vehicle_health_ticket_accepts_required_vehicle_fields():
    ticket = Create_Vehicle_Health_Ticket(
        name="Battery drop",
        vehicle_number="TN01AA0001",
        added_by=5,
    )

    assert ticket.vehicle_number == "TN01AA0001"


def test_transfer_anomaly_request_serializes_ids():
    transfer = TransferAnomalyRequest(
        ticketid=1,
        new_ticketid=2,
        anomaly_id=3,
        transferee=4,
    )

    assert transfer.model_dump() == {
        "ticketid": 1,
        "new_ticketid": 2,
        "anomaly_id": 3,
        "transferee": 4,
    }


def test_delete_attachment_input_accepts_vehicle_specific_delete():
    payload = DeleteAttachment_Input(
        presigned_url="https://example.com/bucket/path/file.png",
        deleted_by=9,
        vehicle_num="TN01AA0001",
    )

    assert payload.ticket_type is None
    assert payload.vehicle_num == "TN01AA0001"


def test_add_more_attachments_input_keeps_all_attachment_groups_optional():
    payload = AddMoreAttachments_Input(added_by=9, vehicle_num="TN01AA0001")

    assert payload.attachments is None
    assert payload.obd_location_photo is None
    assert payload.vehicle_num == "TN01AA0001"
