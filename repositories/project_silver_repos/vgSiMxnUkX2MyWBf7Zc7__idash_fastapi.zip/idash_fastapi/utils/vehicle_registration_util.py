# Import inbuilt libraries



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException

# Include repos folder for custom libraries


# Declare variables used 
# Library code for vehicle registration library

lib_code_VRL = "48"
lib_ver_VRL = "00"

lib_code_ver_VRL = f"{lib_code_VRL}{lib_ver_VRL}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance,hiperft_bucket,get_current_date,vehicle_data_path,rds_instance
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.vehicle_health_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from utils.common_util import *
from schema.vehicle_registration_schema import *
from hiper_utils.data_models.s3_data_models.vehicle_json import *
from hiper_utils.data_models.s3_data_models.common_models import *
from utils.attachment_util import upload_attachments_to_s3
from utils.make_model_util import get_make_model_id,get_make_model
from utils.fleets_util import get_fleet_name
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew as VR_RDS,MakeModel as MM_RDS,Fleet



# initialize the logger
logger_1 = LoggerFactory(name="vehicle_registration_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model
# define other funcs

# function to check if the vehicle already exist
@error_handler(library_code=lib_code_ver_VRL, function_code="01")
def check_vehicle_already_registered(vehicle_num : str):

    '''
    
    Function to check if the vehicle already exist

    params
        - vehicle_num : str : vehicle number

    returns
        - vehicle_exist : bool : True if vehicle already exist else False
        - bugs : dict : dict of bugs if any error occurs
    
    
    '''

    vehicle_exist = False

    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        vehicle_fetched = ns.query(VR_RDS).filter(VR_RDS.vehicle_num == vehicle_num).first()

        if vehicle_fetched:
            vehicle_exist = True

        return vehicle_exist
    

# function to create a new vehicle record in the VR_RDS table
@error_handler(library_code=lib_code_ver_VRL, function_code="02")
def create_vehicle_record(reg_no : str, engine_no : str, chassis_no : str, fleet_id : int, mfg_year : int, vehicle_make : str, vehicle_model : str, emission : str,device_id : str,dataset_id : str = None,  bugs = {}):

    '''
    
    Function to create a new vehicle record in the VR_RDS table

    params

        - reg_no : str : vehicle number
        - engine_no : str : engine number
        - chassis_no : str : chassis number
        - fleet_id : int : fleet id
        - mfg_year : int : manufacturing year
        - vehicle_make : str : vehicle make
        - vehicle_model : str : vehicle model
        - emission : str : emission
        - dataset_id : str : dataset id
        - device_id : str : device id

   

    returns
        - vehicle_num : str : vehicle number if vehicle record is created successfully else None
        - bugs : dict : dict of bugs if any error occurs

    
    '''

    # create a record in the vehicle registration table
    session = rds_instance.get_connection()

    with handle_session(session) as ns:

        logger_1.info(f"veh make is {vehicle_make} and veh model is {vehicle_model}")
        
        make_model_id_fetched,bugs_local = get_make_model_id(vehicle_make,vehicle_model,emission)

        if bugs_local:
            logger_1.error(f"Error in fetching make model id: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif make_model_id_fetched is not None:

            logger_1.info(f"make model id fetched is {make_model_id_fetched}")

            new_vehicle_record = VR_RDS(
                vehicle_num = reg_no,
                registration_time = get_current_date(),
                make_model_id = make_model_id_fetched,
                engine_num = engine_no,
                manuf_year = mfg_year,
                fleet_id = fleet_id,
                VIN = chassis_no,
                active_status = 1,
                device_id = device_id
            )

        ns.add(new_vehicle_record)
        ns.commit()
        logger_1.info(f"New vehicle record created in the VR_RDS table")
        # refresh the session
        ns.flush()

        return new_vehicle_record.vehicle_num




@error_handler(library_code=lib_code_ver_VRL, function_code="03")
def update_ecu_details_of_vehicle(ecu_update: Update_ECU_Details, bugs={}):
    '''
    Function to update ecu details of the vehicle

    params
     - reg_no : str : vehicle number
     - user_id : int : user id of the user who is updating the ecu details
     - ecu_no : str : ecu number
     - ecu_make : str : ecu make
     - ecu_model : str : ecu model

    returns
        - success_update : bool : True if ecu details are updated successfully else False
        - bugs : dict : dict of bugs if any error occurs
    '''

    # Log ECU number, ECU make, and ECU model
    logger_1.info(f"ECU number: {ecu_update.ecu_no}, ECU make: {ecu_update.ecu_make}, ECU model: {ecu_update.ecu_model}")

    success_update = False

    # Get the fleet name
    fleet_name, bugs_local = get_fleet_name(ecu_update.reg_no)

    if bugs_local:
        logger_1.error(f"Error in fetching fleet name : {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_update

    elif fleet_name is not None:
        # Get the vehicle JSON path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{ecu_update.reg_no}/Vehicle_JSON.json"

        # Check if vehicle JSON already exists in S3
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

        if bugs_local:
            if "NoSuchKey" in str(bugs_local):  # Specific handling for missing file
                logger_1.warning(f"Vehicle JSON does not exist for {ecu_update.reg_no}. Creating a new one.")
                # Create a new JSON file
                create_vehicle_json_status, bugs_local = create_vehicle_json(ecu_update)
                if not create_vehicle_json_status:
                    logger_1.error(f"Failed to create a new vehicle JSON: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_update
            else:
                logger_1.error(f"Failed to download the vehicle JSON: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_update
            
        elif vehicle_json is not None:
            # Proceed to update the existing or newly created JSON
            status_changes = ""

            # Get the heading block and update ECU details
            heading_block = vehicle_json.get("1")

            # Update the ECU details only if provided, otherwise retain existing values
            if ecu_update.ecu_no is not None:
                heading_block["ecu_number"] = ecu_update.ecu_no
                status_changes += f"ecu number as {ecu_update.ecu_no}, "
            else:
                ecu_update.ecu_no = heading_block.get("ecu_number")  # Retain existing value

            if ecu_update.ecu_make is not None:
                heading_block["ecu_make"] = ecu_update.ecu_make
                status_changes += f"ecu make as {ecu_update.ecu_make}, "
            else:
                ecu_update.ecu_make = heading_block.get("ecu_make")  # Retain existing value

            if ecu_update.ecu_model is not None:
                heading_block["ecu_model"] = ecu_update.ecu_model
                status_changes += f"ecu model as {ecu_update.ecu_model}, "
            else:
                ecu_update.ecu_model = heading_block.get("ecu_model")  # Retain existing value

            # Update the updated_by and updated_on fields
            heading_block["updated_by"] = str(ecu_update.user_id)
            heading_block["updated_on"] = get_current_date()

            # Create a status block
            status_block = {
                "status_change_description": f"ECU details updated  : {status_changes}",
                "updated_by": str(ecu_update.user_id),
            }

            # Serialize the status block
            status = StatusChangeBlock(**status_block)

            # Add the status block to the reports_json
            # Get the last key in the reports_json and increment it by 1
            last_key = sorted(vehicle_json.keys())[-1]

            status_key = str(int(last_key) + 1)

            vehicle_json[status_key] = status.model_dump()

            # Write the updated vehicle json to S3
            updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

            if bugs_local:
                logger_1.error(f"Error in updating ecu details of the vehicle : {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_update

            else:
                logger_1.info(f"Ecu details of the vehicle updated successfully")
                success_update = True
                return success_update
    else:
        logger_1.error(f"No fleet name found for vehicle number {ecu_update.reg_no}")
        return success_update




# function to create a new vehicle installation report json
@error_handler(library_code=lib_code_ver_VRL, function_code="04")
def create_vehicle_json(new_vehicle : Add_New_Vehicle,bugs = {}):

    '''
    
    Function to create a new vehicle installation report json

    params 
        - new_vehicle : Add_New_Vehicle : pydantic model with vehicle details
        - fleet_name : str : fleet name of the vehicle

    returns
        - success_write : bool : True if report json is created successfully else False
        - bugs : dict : dict of bugs if any error occurs
    
    
    
    '''

    success_write = False


    # create metadata for the report json
    metadata = {
        "created_by" : str(new_vehicle.user_id),
        "updated_by" : str(new_vehicle.user_id),
        "vehicle_num" : new_vehicle.reg_no,
        "start_time" : get_current_date(),
    }

    # serialize the metadata of the report
    serialized_metadata = MetadataBlock(**metadata)


    # get make model id from vehicle registration table
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        make_model_id = ns.query(VR_RDS.make_model_id).filter(VR_RDS.vehicle_num == new_vehicle.reg_no).first().make_model_id
        chassis_no = ns.query(VR_RDS.VIN).filter(VR_RDS.vehicle_num == new_vehicle.reg_no).first().VIN
        engine_no = ns.query(VR_RDS.engine_num).filter(VR_RDS.vehicle_num == new_vehicle.reg_no).first().engine_num

        # get vehicle make and model calling get_vehicle_make_model function
        make_model,bugs_local = get_make_model(make_model_id)

        if bugs_local:
            logger_1.error(f"Error in fetching vehicle make and model : {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return success_write
        
        elif make_model != {}:

            # create a heading for the report json
            heading = {
                "created_by" : str(new_vehicle.user_id),
                "updated_by" : str(new_vehicle.user_id),
                "vehicle_make" : make_model.get("vehicle_make"),
                "vehicle_model" : str(make_model.get("vehicle_model")),
                "chassis_number" : chassis_no,
                "engine_number" : engine_no,
            }

            # serialize the heading of the report
            serialized_heading = HeadingBlock(**heading)

            # create a new status block
            status = {
                "status_change_description" : f"Vehicle with {new_vehicle.reg_no} registered",
                "updated_by" : str(new_vehicle.user_id)
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status)

            # create a installation report json
            installation_report = {
                "0" : serialized_metadata.model_dump(),
                "1" : serialized_heading.model_dump(),
                "2" : serialized_status.model_dump()
            }


            # get the fleet name using the get_fleet_name function
            fleet_name,bugs_local = get_fleet_name(new_vehicle.reg_no)

            if bugs_local:
                logger_1.error(f"Error in fetching fleet name : {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return success_write
        
            # get the vehicle_json path
            vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{new_vehicle.reg_no}/Vehicle_JSON.json"

            # write the report to s3
            updated_vehicle_json,bugs_local =  hiperft_bucket.write_json_to_s3(data_dict=installation_report, s3_key=vehicle_json_path)

            if bugs_local:
                logger_1.error(f"Error in creating vehicle installation report json : {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return success_write
        
            else:
                logger_1.info(f"Vehicle json created successfully")
                success_write = True
        
    return success_write



# function to create an installation block
@error_handler(library_code=lib_code_ver_VRL, function_code="05")
def create_installation_block(checklist: Create_Installation_Checklist, bugs={}):
    '''
    Function to create an installation block

    params
     - reg_no : str : vehicle number
     - user_id : int : user id of the user who is creating the installation block
     - battery_voltage : Optional[float] : battery voltage
     - check_can_pins : bool : check CAN pins
     - check_KLINE_pins : bool : check KLINE pins
     - iginiton_affecting_voltage : str : reason for ignition affecting voltage
     - obd_location_photo : list : list of OBD location photos
     - installation_video : list : list of installation videos
     - additional_pins_on_OBD : list : list of additional pins on OBD


    returns
        - success_create : bool : True if installation block is created successfully else False
        - bugs : dict : dict of bugs if any error occurs
    '''

    success_create = False
    
    # Initialize attachment URLs list and video URLs list as empty
    attachment_urls_list = []
    video_urls_list = []

    # get fleet name
    fleet_name, bugs_local = get_fleet_name(checklist.reg_no)

    if bugs_local:
        logger_1.error(f"Error fetching fleet name: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_create
    
    elif fleet_name is not None:

        logger_1.info(f"Fleet name fetched: {fleet_name}")

        # Define paths for vehicle json and attachments
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{checklist.reg_no}/Vehicle_JSON.json"
        attachment_path = f"{vehicle_data_path}{fleet_name}/{checklist.reg_no}/attachments/"

        # Download the existing vehicle json
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)
        
        if bugs_local:
            logger_1.error(f"Failed to download the installation report: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_create

        elif vehicle_json is not None:

            # Get metadata block
            metadata_block = vehicle_json.get("0")

            # log the igintion affecting voltages value
            logger_1.info(f"Ignition affecting voltages in util: {checklist.igniton_affecting_voltage}")

            # Create a new installation block
            installation_block = {
                "battery_voltage": checklist.battery_voltage,
                "can_pins": checklist.check_can_pins,
                "kline_pins": checklist.check_KLINE_pins,
                "ignition_affecting_voltages": checklist.igniton_affecting_voltage,
                "OBD_location_image": [],
                "video_link_of_installation": [],
                "additional_pins_on_OBD": checklist.add_pins_on_obd,
            }

            # Upload OBD location photos if provided
            if checklist.obd_location_photo:

                attachment_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=checklist.obd_location_photo,
                    block_id=f"{checklist.reg_no}",
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.error(f"Error uploading OBD location photos: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif attachment_urls_list is not None:
                    logger_1.info(f"OBD location photos uploaded: {attachment_urls_list}")
                    
                    installation_block["OBD_location_image"] = attachment_urls_list

            # Upload installation videos if provided
            if checklist.installation_video:

                video_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=checklist.installation_video,
                    block_id=f"{checklist.reg_no}",
                    custom_s3_path=attachment_path
                )
                if bugs_local:
                    logger_1.error(f"Error uploading installation videos: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif video_urls_list is not None:
                    logger_1.info(f"Installation videos uploaded: {video_urls_list}")
                    installation_block["video_link_of_installation"] = video_urls_list

            # Add a new status block for the creation
            status_block = {
                "status_change_description": f"Installation block created.",
                "updated_by": str(checklist.user_id),
            }
            
            
            # Serialize the new installation block
            try:
                serialized_installation = InstallationBlock(**installation_block)
            
            except Exception as e:
                logger_1.error(f"Error serializing installation block: {e}")
                return success_create

            # Generate a new key for the new installation block
            new_key = str(int(sorted(vehicle_json.keys())[-1]) + 1)
            vehicle_json[new_key] = serialized_installation.model_dump()
            vehicle_json[str(int(new_key) + 1)] = StatusChangeBlock(**status_block).model_dump()


            
            # Update the metadata block with the new installation block key and status key
            metadata_block["installation_blocks"].append(new_key)
            metadata_block["status_blocks"].append(str(int(new_key) + 1))
            metadata_block["updated_by"] = str(checklist.user_id)
            metadata_block["updated_on"] = get_current_date()

            # Write the updated report to S3
            updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

            if bugs_local:
                logger_1.error(f"Error in creating installation block of the vehicle: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_create

            logger_1.info("Installation block of the vehicle created successfully")
            success_create = True

        return success_create


# function to create a calibration block
@error_handler(library_code=lib_code_ver_VRL, function_code="06")
def add_calibration_block(calibration_block : Create_Calibration_Block, bugs = {}):

    '''
    
    Function to create a calibration block


    params
     - reg_no : str : vehicle number
     - user_id : int : user id of the user who is creating the calibration block
     - puc_certificate : list : list of PUC certificates
     - empty_weight : float : empty weight of the vehicle
     - loaded_weight : float : loaded weight of the vehicle
     - photo_of_number_plate : list : list of photos of number plate
     - photo_of_wheels : list : list of photos of wheels


    returns
        - success_create : bool : True if calibration block is created successfully else False
        - bugs : dict : dict of bugs if any error occurs
    

    '''

    success_create = False

    # Initialize attachment URLs list
    puc_urls_list = []
    number_plate_urls_list = []
    wheels_urls_list = []

    # Get the fleet name
    fleet_name, bugs_local = get_fleet_name(calibration_block.reg_no)

    if bugs_local:
        logger_1.error(f"Error in fetching fleet name : {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_create
    
    elif fleet_name is not None:
        
        logger_1.info(f"Fleet name fetched: {fleet_name}")
        
        
        # Define paths for vehicle json and attachments
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{calibration_block.reg_no}/Vehicle_JSON.json"
        attachment_path = f"{vehicle_data_path}{fleet_name}/{calibration_block.reg_no}/attachments/"

        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.error(f"Failed to download the installation report: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_create
        
        elif vehicle_json is not None:

            # create a calibration block
            calibration_block_to_report = {
                "created_by": str(calibration_block.user_id),
                "updated_by": str(calibration_block.user_id),
                "empty_weight": calibration_block.empty_weight,
                "loaded_weight": calibration_block.loaded_weight,
            }

            # Upload PUC certificates if provided
            if calibration_block.puc_certificate:

                puc_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=calibration_block.puc_certificate,
                    block_id=f"{calibration_block.reg_no}",
                    custom_s3_path=attachment_path
                )

                if bugs_local:
                    logger_1.error(f"Error uploading PUC certificates: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif puc_urls_list is not None:
                    logger_1.info(f"PUC certificates uploaded: {puc_urls_list}")
                    calibration_block_to_report["puc_certificate"] = puc_urls_list


            # Upload photos of number plate if provided
            if calibration_block.photo_of_number_plate:

                number_plate_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=calibration_block.photo_of_number_plate,
                    block_id=f"{calibration_block.reg_no}",
                    custom_s3_path=attachment_path
                )

                if bugs_local:
                    logger_1.error(f"Error uploading photos of number plate: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif number_plate_urls_list is not None:
                    logger_1.info(f"Photos of number plate uploaded: {number_plate_urls_list}")
                    calibration_block_to_report["number_plate_photo"] = number_plate_urls_list

            # Upload photos of wheels if provided
            if calibration_block.photo_of_wheels:

                wheels_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=calibration_block.photo_of_wheels,
                    block_id=f"{calibration_block.reg_no}",
                    custom_s3_path=attachment_path
                )

                if bugs_local:
                    logger_1.error(f"Error uploading photos of wheels: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif wheels_urls_list is not None:
                    logger_1.info(f"Photos of wheels uploaded: {wheels_urls_list}")
                    calibration_block_to_report["wheels_photo"] = wheels_urls_list

            # Upload rc book photos if provided
            if calibration_block.photo_of_rc_book:

                rc_book_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=calibration_block.photo_of_rc_book,
                    block_id=f"{calibration_block.reg_no}",
                    custom_s3_path=attachment_path
                )

                if bugs_local:
                    logger_1.error(f"Error uploading photos of RC book: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif rc_book_urls_list is not None:
                    logger_1.info(f"Photos of RC book uploaded: {rc_book_urls_list}")
                    calibration_block_to_report["rc_book_photo"] = rc_book_urls_list


            # serialize the calibration block
            try:
                serialized_calibration = CalibrationBlock(**calibration_block_to_report)
            
            except Exception as e:
                logger_1.error(f"Error serializing calibration block: {e}")
                return success_create
            

            # get the last key in the reports_json and increment it by 1
            last_key = sorted(vehicle_json.keys())[-1]

            new_key = str(int(last_key) + 1)

            # add the calibration block to the reports_json
            vehicle_json[new_key] = serialized_calibration.model_dump()

            # create a status block
            status_block = {
                "status_change_description": f"Calibration block created.",
                "updated_by": str(calibration_block.user_id),
            }

            # serialize the status block
            status = StatusChangeBlock(**status_block)

            # add the status block to the reports_json
            vehicle_json[str(int(new_key) + 1)] = status.model_dump()

            # update the metadata block with the new calibration block key and status key
            metadata_block = vehicle_json.get("0")
            metadata_block["calibration_blocks"].append(new_key)
            metadata_block["status_blocks"].append(str(int(new_key) + 1))
            metadata_block["updated_by"] = str(calibration_block.user_id)
            metadata_block["updated_on"] = get_current_date()

            # write the updated vehicle json to s3
            updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

            if bugs_local:
                logger_1.error(f"Error in creating calibration block of the vehicle: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_create
            
            else:
                logger_1.info(f"Calibration block of the vehicle created successfully")
                success_create = True
                return success_create

# Function to get all registered vehicles
@error_handler(library_code=lib_code_ver_VRL, function_code="07")
def get_all_registered_vehicles():
    '''
    Function to get all registered vehicles

    params
        - None

    returns
        - all_vehicles : dict : dict of all registered vehicles
    '''

    all_vehicles = {}
    bugs = {}
    
    # get connection
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Filter out vehicles with vehicle_num starting with "TEST_RIG_"
        all_vehicles_fetched = ns.query(VR_RDS).filter(~VR_RDS.vehicle_num.like("TEST_RIG_%")).all()

        for vehicle in all_vehicles_fetched:
            
            # get make model id of the vehicle
            make_model_id = vehicle.make_model_id
            
            logger_1.info(f"Make model id is {make_model_id}")
            
            # Query the make_model_rds to get the emission value for the vehicle
            emission = ns.query(MM_RDS).filter_by(make_model_id=make_model_id).first().emission

            # call get fleet name function to get the fleet name
            fleet_name, bugs_local = get_fleet_name(vehicle.vehicle_num)

            if bugs_local:
                logger_1.error(f"Error in fetching fleet name: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif fleet_name is not None:

                # log the fleet name
                logger_1.info(f"Fleet name fetched: {fleet_name}")

                # get the vehicle json from the s3
                vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle.vehicle_num}/Vehicle_JSON.json"
                
                # log for which vehicle number the json is being fetched
                logger_1.info(f"Fetching vehicle JSON for vehicle number {vehicle.vehicle_num}")

                # download the vehicle json
                vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=f"{vehicle_json_path}")

                if bugs_local and 'NoSuchKey' in str(bugs_local):
                    logger_1.error(f"Vehicle JSON file not found for vehicle number {vehicle.vehicle_num}. Filling fields as None.")
                    vehicle_json = None  # Proceed to fill fields as None
                
                elif bugs_local:
                    logger_1.error(f"Failed to download the vehicle JSON for {vehicle.vehicle_num}: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None  # For other errors, return None

                # Initialize fields to None
                battery_voltage = None
                ignition_affecting_voltage = None
                obd_location_image = None
                video_link_of_installation = None
                puc_certificate = None
                number_plate_photo = None
                wheels_photo = None
                rc_book_photo = None
                empty_weight = None
                loaded_weight = None

                # Handle installation blocks if available
                if vehicle_json and "0" in vehicle_json and vehicle_json["0"].get("installation_blocks"):
                    logger_1.info(f"Installation blocks present for vehicle number {vehicle.vehicle_num}")

                    installation_block = vehicle_json["0"]["installation_blocks"][0]

                    battery_voltage = vehicle_json.get(installation_block, {}).get("battery_voltage")
                    ignition_affecting_voltage = vehicle_json.get(installation_block, {}).get("ignition_affecting_voltages")
                    obd_location_image = vehicle_json.get(installation_block, {}).get("OBD_location_image")
                    video_link_of_installation = vehicle_json.get(installation_block, {}).get("video_link_of_installation")

                # Handle calibration blocks if available
                if vehicle_json and "0" in vehicle_json and vehicle_json["0"].get("calibration_blocks"):
                    logger_1.info(f"Calibration blocks present for vehicle number {vehicle.vehicle_num}")

                    calibration_block = vehicle_json["0"]["calibration_blocks"][-1]

                    puc_certificate = vehicle_json.get(calibration_block, {}).get("puc_certificate")
                    number_plate_photo = vehicle_json.get(calibration_block, {}).get("number_plate_photo")
                    wheels_photo = vehicle_json.get(calibration_block, {}).get("wheels_photo")
                    rc_book_photo = vehicle_json.get(calibration_block, {}).get("rc_book_photo")
                    empty_weight = vehicle_json.get(calibration_block, {}).get("empty_weight")
                    loaded_weight = vehicle_json.get(calibration_block, {}).get("loaded_weight")

                # Add the vehicle information to the dictionary
                all_vehicles[vehicle.vehicle_num] = {
                    "vehicle_num": vehicle.vehicle_num,
                    "device_id" : vehicle.device_id,
                    "vehicle_make": vehicle_json["1"].get("vehicle_make") if vehicle_json else None,
                    "vehicle_model": vehicle_json["1"].get("vehicle_model") if vehicle_json else None,
                    "chassis_number": vehicle_json["1"].get("chassis_number") if vehicle_json else None,
                    "engine_number": vehicle.engine_num,
                    "manufacuring_year": vehicle.manuf_year,
                    "fleet_name": fleet_name,
                    "ecu_number": vehicle_json["1"].get("ecu_number") if vehicle_json else None,
                    "ecu_make": vehicle_json["1"].get("ecu_make") if vehicle_json else None,
                    "ecu_model": vehicle_json["1"].get("ecu_model") if vehicle_json else None,
                    "battery_voltage": battery_voltage,
                    "empty_weight": empty_weight,
                    "loaded_weight": loaded_weight,
                    "ignition_affecting_voltage": ignition_affecting_voltage,
                    "OBD_location_image": obd_location_image,
                    "video_link_of_installation": video_link_of_installation,
                    "puc_certificate": puc_certificate,
                    "number_plate_photo": number_plate_photo,
                    "wheels_photo": wheels_photo,
                    "rc_book_photo": rc_book_photo,
                    "emission": emission
                }

        return all_vehicles




# function to update rds vehicle details
@error_handler(library_code=lib_code_ver_VRL, function_code="08")
def update_rds_vehicle_details(vehicle_num : str, vehicle_make : str, vehicle_model : str, fleet_id : int, mfg_year : int, engine_number : str, chassis_number : str):

    '''
    
    Service function to update vehicle details in the VR_RDS table 

    params
        - vehicle_num : str : vehicle number
        - vehicle_make : str : vehicle make
        - vehicle_model : str : vehicle model
        - fleet_id : int : fleet id
        - mfg_year : int : manufacturing year
        - engine_number : str : engine number
        - chassis_number : str : chassis number

    returns

        - success_update : bool : True if vehicle details are updated successfully else False
        - bugs : dict : dict of bugs if any error occurs
    
    
    '''

    # initi a write success flag
    write_success = False

    # update the related VR_RDS table record
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        vehicle_fetched = ns.query(VR_RDS).filter(VR_RDS.vehicle_num == vehicle_num).first()

        if engine_number is not None:
            vehicle_fetched.engine_num = engine_number

        if chassis_number is not None:
            vehicle_fetched.VIN = chassis_number

        if fleet_id is not None:
            vehicle_fetched.fleet_id = fleet_id

        if mfg_year is not None:
            vehicle_fetched.manuf_year = mfg_year

        # if make or model is updated, update the make_model_id
        if vehicle_make and vehicle_model:
            make_model_record = ns.query(MM_RDS.make_model_id).filter(MM_RDS.vehicle_make == vehicle_make, MM_RDS.vehicle_model == vehicle_model).first()

            if make_model_record:
                vehicle_fetched.make_model_id = make_model_record.make_model_id

        # commit the changes
        ns.commit()
        logger_1.info(f"Vehicle details updated successfully in the VR_RDS table")

        write_success = True

    return write_success




# function to update vehicle details
@error_handler(library_code=lib_code_ver_VRL, function_code="09")
def update_s3_vehicle_details(vehicle_update : Edit_Vehicle_Details, bugs = {}):

    '''

    Function to update vehicle details

    params

        - reg_no : str : vehicle number
        - user_id : int : user id of the user who is updating the vehicle details
        - vehicle_make : str : vehicle make
        - vehicle_model : str : vehicle model
        - emission : str : emission standard
        - chassis_no : str : chassis number
        - engine_no : str : engine number
        - fleet_id : int : fleet id
        - mfg_year : int : manufacturing year

    returns

        - write_success : bool : True if vehicle details are updated successfully else False
        - bugs : dict : dict of bugs if any error occurs     
    
    
    
    '''

    write_success = False

    # get the fleet name
    fleet_name, bugs_local = get_fleet_name(vehicle_update.reg_no)

    if bugs_local:
        logger_1.error(f"Error in fetching fleet name : {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return write_success
    
    elif fleet_name is not None:

        logger_1.info(f"Fleet name fetched: {fleet_name}")

        # get the vehicle json path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_update.reg_no}/Vehicle_JSON.json"

        # download the vehicle json
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.error(f"Failed to download the vehicle json: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_update   
    
        elif vehicle_json is not None:
                
                # get the heading block and update vehicle details
                heading_block = vehicle_json.get("1")
        
                # update the vehicle details
                if vehicle_update.vehicle_make is not None:
                    heading_block["vehicle_make"] = vehicle_update.vehicle_make
        
                if vehicle_update.vehicle_model is not None:
                    heading_block["vehicle_model"] = vehicle_update.vehicle_model

                if vehicle_update.chassis_no is not None:
                    heading_block["chassis_number"] = vehicle_update.chassis_no
        
                if vehicle_update.engine_no is not None:
                    heading_block["engine_number"] = vehicle_update.engine_no
        
                if vehicle_update.fleet_id is not None:
                    heading_block["fleet_id"] = vehicle_update.fleet_id
        
                if vehicle_update.mfg_year is not None:
                    heading_block["manufacturing_year"] = vehicle_update.mfg_year
        
                # update the updated_by and updated_on fields
                heading_block["updated_by"] = str(vehicle_update.user_id)
                heading_block["updated_on"] = get_current_date()
        
                # create a status block
                status_block = {
                    "status_change_description": f"Vehicle details updated.",
                    "updated_by": str(vehicle_update.user_id),
                }
        
                # serialize the status block
                status = StatusChangeBlock(**status_block)
        
                # add the status block to the reports_json
                # get the last key in the reports_json and increment it by 1
                last_key = sorted(vehicle_json.keys())[-1]
        
                status_key = str(int(last_key) + 1)
        
                vehicle_json[status_key] = status.model_dump()


                # if fleet id is updated, update the vehicle json path
                if vehicle_update.fleet_id is not None:

                    # get connection and get the updated fleet name
                    session = rds_instance.get_connection()

                    with handle_session(session) as ns:
                        updated_fleet_name = ns.query(Fleet.fleet_name).filter(Fleet.id == vehicle_update.fleet_id).first().fleet_name

                        # get the updated vehicle
                        vehicle_json_path = f"{vehicle_data_path}{updated_fleet_name}/{vehicle_update.reg_no}/Vehicle_JSON.json"

                        # delete the old vehicle json
                        old_vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_update.reg_no}/Vehicle_JSON.json"

                        # call delete_file_from_s3
                        delete_success, bugs_local = hiperft_bucket.delete_file_from_s3(s3_key=old_vehicle_json_path)

                        if bugs_local:
                            logger_1.error(f"Error in deleting the old vehicle json : {bugs_local}")
                            bugs = c_bugs(bugs, bugs_local)
                            bugs = s_bugs(bugs)
                            return write_success
                        
                        elif delete_success == True:
                            logger_1.info(f"Old vehicle json deleted successfully")
            
                # write the updated vehicle json to s3
                updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)
        
                if bugs_local:
                    logger_1.error(f"Error in updating vehicle details of the vehicle: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_update
                
                else:
                    logger_1.info(f"Vehicle details updated successfully in the vehicle json")
                    success_update = True

        return success_update
    




# function to update s3 electric vehicle details 
@error_handler(library_code=lib_code_ver_VRL, function_code="10")
def update_s3_electrical_details(edit_elec : Update_Electricals, bugs = {}):

    '''

    Function to update s3 electric vehicle details

    params

        - reg_no : str : vehicle number
        - user_id : int : user id of the user who is updating the electrical details

        optional_params
        - battery_voltage : float : battery voltage
        - ignition_affecting_voltage : str : reasons for ignition affecting voltage

    returns
    
            - success_update : bool : True if electrical details are updated successfully else False
            - bugs : dict : dict of bugs if any error occurs     
        
        
    '''

    success_update = False

    # get the fleet_name calling the function get_fleet_name
    fleet_name,bugs_local = get_fleet_name(edit_elec.reg_no)

    if bugs_local:
        logger_1.error(f"Error in fetching fleet name : {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return success_update
    
    # get the vehicle json path
    vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{edit_elec.reg_no}/Vehicle_JSON.json"

    # download the vehicle json
    vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

    if bugs_local:
        logger_1.error(f"Failed to download the vehicle data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_update
    
    elif vehicle_json is not None:

        # get the installation block from metadata and update the battery voltage
        installation_block_key = vehicle_json.get("0").get("installation_blocks")[0]

        installation_block = vehicle_json.get(installation_block_key)
        
        # init a status changes string to store the status changes        
        status_changes = ""


        if edit_elec.battery_voltage:
            # if battery voltage was changed, add it as a status change
            status_changes += f"Battery voltage updated to {edit_elec.battery_voltage}. "
            installation_block["battery_voltage"] = edit_elec.battery_voltage
        
        if edit_elec.ignition_affecting_voltage:
            # if ignition affecting voltage was changed, add it as a status change
            status_changes += f"Ignition affecting voltage updated to {edit_elec.ignition_affecting_voltage}. "
            installation_block["ignition_affecting_voltages"] = edit_elec.ignition_affecting_voltage 

        # create a status block
        status_block = {
            "status_change_description": status_changes,
            "updated_by": str(edit_elec.user_id),
        }

        # serialize the status block
        status = StatusChangeBlock(**status_block)

        # add the status block to the reports_json
        # get the last key in the reports_json and increment it by 1

        last_key = sorted(vehicle_json.keys())[-1]

        status_key = str(int(last_key) + 1)

        vehicle_json[status_key] = status.model_dump()

        # update metadata block with the new status key and also update the updated_by and updated_on fields
        metadata_block = vehicle_json.get("0")
        metadata_block["status_blocks"].append(status_key)
        metadata_block["updated_by"] = str(edit_elec.user_id)
        metadata_block["updated_on"] = get_current_date()


        # write the updated vehicle json to s3
        updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.error(f"Error in updating electrical details of the vehicle: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_update
        
        else:
            logger_1.info(f"Electrical details of the vehicle updated successfully")
            success_update = True
            return success_update



# function to update s3 vehicle electrical details
@error_handler(library_code=lib_code_ver_VRL, function_code="11")
def update_s3_vehicle_calibration_details(edit_calib : Update_Calibration, bugs = {}):

    '''

    Function to update s3 vehicle calibration details

    params

        - reg_no : str : vehicle number
        - user_id : int : user id of the user who is updating the calibration details
        - empty_weight : float : empty weight of the vehicle
        - loaded_weight : float : loaded weight of the vehicle

    returns

        - success_update : bool : True if calibration details are updated successfully else False
        - bugs : dict : dict of bugs if any error occurs     
    
    '''

    success_update = False

    # get the fleet_name calling the function get_fleet_name
    fleet_name,bugs_local = get_fleet_name(edit_calib.reg_no)

    if bugs_local:
        logger_1.error(f"Error in fetching fleet name : {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return success_update
    
    # get the vehicle json path
    vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{edit_calib.reg_no}/Vehicle_JSON.json"

    # download the vehicle json
    vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

    if bugs_local:
        logger_1.error(f"Failed to download the installation report: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_update
    
    elif vehicle_json is not None:

        # get the calibration block from metadata and update the empty and loaded weight
        calibration_block_key = vehicle_json.get("0").get("calibration_blocks")[-1]

        calibration_block = vehicle_json.get(calibration_block_key)

        calibration_block["empty_weight"] = edit_calib.empty_weight
        calibration_block["loaded_weight"] = edit_calib.loaded_weight

        # update the updated_by and updated_on fields
        calibration_block["updated_by"] = str(edit_calib.user_id)
        calibration_block["updated_on"] = get_current_date()

        # create a status block
        status_block = {
            "status_change_description": f"Empty weight updated to {edit_calib.empty_weight} and loaded weight updated to {edit_calib.loaded_weight}",
            "updated_by": str(edit_calib.user_id),
        }

        # serialize the status block
        status = StatusChangeBlock(**status_block)

        # add the status block to the reports_json
        # get the last key in the reports_json and increment it by 1
        last_key = sorted(vehicle_json.keys())[-1]

        status_key = str(int(last_key) + 1)

        vehicle_json[status_key] = status.model_dump()

        # update the metadata block with the new status key and also update the updated_by and updated_on fields
        metadata_block = vehicle_json.get("0")
        metadata_block["status_blocks"].append(status_key)
        metadata_block["updated_by"] = str(edit_calib.user_id)
        metadata_block["updated_on"] = get_current_date()

        # write the updated vehicle json to s3
        updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.error(f"Error in updating calibration details of the vehicle: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_update
        
        else:
            logger_1.info(f"Calibration details of the vehicle updated successfully")
            success_update = True
            return success_update



# function to check if the chassis number is taken
@error_handler(library_code=lib_code_ver_VRL, function_code="12")
def check_chassis_number_taken(chassis_num : str):

    '''
    
    Function to check if the chassis number is taken

    params
        - chassis_num : str : chassis number

    returns
        - taken : bool : True if the chassis number is taken else False
        - bugs : dict : dict of bugs if any error occurs

    
    
    '''

    taken = False

    # get the connection
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        chassis_num_fetched = ns.query(VR_RDS).filter(VR_RDS.VIN == chassis_num).first()

        if chassis_num_fetched:
            taken = True

    return taken


# function to check if the engine number is taken
@error_handler(library_code=lib_code_ver_VRL, function_code="13")
def check_engine_number_taken(engine_num : str):

    '''

    Function to check if the engine number is taken

    params
        - engine_num : str : engine number

    returns
        - taken : bool : True if the engine number is taken else False
        - bugs : dict : dict of bugs if any error occurs

    '''

    taken = False

    # get the connection
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        engine_num_fetched = ns.query(VR_RDS).filter(VR_RDS.engine_num == engine_num).first()

        if engine_num_fetched:
            taken = True

    return taken


# function to check if the chassis number is valid
@error_handler(library_code=lib_code_ver_VRL, function_code="14")
def check_valid_engine_number(engine_num : str):

    '''
    

    Function to check if the engine number is valid

    params
        - engine_num : str : engine number

    returns
        - valid : bool : True if the engine number is valid else False
        - bugs : dict : dict of bugs if any error occurs
    
    
    '''

    valid = False

    # check if the engine number is alphanumeric AND has a length of 17
    if engine_num.isalnum() and len(engine_num) == 17:
        valid = True

    return valid



# function to check if a valid chassis number
@error_handler(library_code=lib_code_ver_VRL, function_code="15")
def check_valid_chassis_number(chassis_num : str):

    '''

    Function to check if a valid chassis number

    params
        - chassis_num : str : chassis number

    returns

        - valid : bool : True if the chassis number is valid else False
        - bugs : dict : dict of bugs if any error occurs

    '''

    valid = False

    # check if the chassis number is alphanumeric AND has a length of 17
    if chassis_num.isalnum() and len(chassis_num) == 17:
        valid = True

    return valid




# function to check if installation block already exists
@error_handler(library_code=lib_code_ver_VRL, function_code="16")
def check_installation_block_exists(reg_no : str):

    '''
    
    Function to check if installation block already exists

    params
        - reg_no : str : vehicle number

    returns
        - installation_block_exist : bool : True if installation block already exist else False
        - bugs : dict : dict of bugs if any error occurs
    

    '''

    installation_block_exist = False

    # get the fleet name
    fleet_name, bugs_local = get_fleet_name(reg_no)

    if bugs_local:
        logger_1.error(f"Error fetching fleet name: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return installation_block_exist
    
    elif fleet_name is not None:
        
        # get the vehicle json path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{reg_no}/Vehicle_JSON.json"

        # download the vehicle json
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.error(f"Failed to download the installation report: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return installation_block_exist
        
        elif vehicle_json is not None:

            # get the metadata block
            metadata_block = vehicle_json.get("0")

            # check if there are any installation blocks
            installation_blocks = metadata_block.get("installation_blocks")

            if installation_blocks:
                installation_block_exist = True

            return installation_block_exist


