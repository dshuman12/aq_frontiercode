

from hiper_utils.Decoraters.exception_handler import error_handler
from datetime import datetime

# Library Code for Users Module
lib_code_CT = "42"
lib_ver_CT = "00"

lib_code_ver_CT = f"{lib_code_CT}{lib_ver_CT}"



@error_handler(library_code='lib_code_ver_CT', function_code="06")
def update_metadata(ticket: dict, user_id: int):

    '''
    Function to update the metadata of a feature ticket.

    params: ticket, user_id
    returns: Updated ticket data
    
    '''
    
    metadata = ticket['0']
    metadata['updated_by'] = user_id
    metadata['updated_on'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    return ticket 
