# Import inbuilt libraries
import json
import time
import pandas as pd
from json import JSONEncoder
from datetime import datetime, timedelta
import pandas as pd
from pandas import Timestamp

from utils.attachment_util import upload_attachments_to_s3
from utils.feature_tickets_util import fetch_and_cache_ticket, handle_ticket_update_for_s3
from utils.users_utils import get_user_team
from hiper_utils.data_models.s3_data_models.common_models import StatusChangeBlock, TasksBlock



# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException



# Include repos folder for custom libraries




# Library Code for Users Module
lib_code_TM = "26"
lib_ver_TM = "00"

lib_code_ver_TM = f"{lib_code_TM}{lib_ver_TM}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import calculate_seven_days, rds_instance,redis_instance
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.data_models.rds_data_models.ticket_rds_models import Task_RDS
from schema.tasks_schema import *




# initialize the logger
logger_1 = LoggerFactory(name="task_utils", file_name="message.log").get_logger()



# Define Helper class used with the pydantic model

# define other funcs


class CustomEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime, Timestamp)):
            return obj.isoformat()
        return JSONEncoder.default(self, obj)


# function to fetch all tasks
@error_handler(library_code=lib_code_ver_TM, function_code="01")
def all_task_records(bugs={}):
    '''
    
    Function to fetch all tasks records

    params: None

    return :
     - df with all tasks records
     - None 
    
    
    '''

    # Try to fetch the tasks from the cache
    all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")

    if all_tasks_from_cache:
        logger_1.info(f"All tasks fetched from cache")

        # Deserialize the tasks from the cache
        all_tasks = pd.DataFrame.from_dict(json.loads(all_tasks_from_cache), orient='index')

        return all_tasks
    

    # if tasks are not fetched from the cache, fetch the tasks from the RDS and store them in the cache 
    # else:

    # call query table function by passing table name as Task_RDS to get all tasks records
    all_tasks, bugs_local = rds_instance.query_table(Task_RDS)


    if bugs_local:
        logger_1.error(f"Error in fetching all tasks records: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    

    elif all_tasks is not None:

        if 'id' not in all_tasks.columns:
            logger_1.error("'id' column is missing from the tasks data.")
            return None

        # Create a dictionary where 'id' is explicitly used as the key
        tasks_dict = {int(row['id']): row.to_dict() for index, row in all_tasks.iterrows()}

        # Serialize the dictionary using the custom encoder
        serialized_tasks = json.dumps(tasks_dict, cls=CustomEncoder)

        # set the serialized tasks to the cache
        redis_instance.set_key("all_tasks_cached", serialized_tasks, ex=3600)

        return all_tasks





# function to fetch the next child id given a ticket id 
@error_handler(library_code=lib_code_ver_TM, function_code="02")
def next_child_id(ticket_id : int ,ticket_type : int, bugs={}) -> str:
    '''
    
    Function to fetch the next child id given a ticket id 

    params: 
     - ticket_id : int

    return :
     - next_child_id : int
     - None 
    
    
    '''

    # call fetch and cache function from features_tickets_utils
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket_id,ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching ticket data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # retrieve the tasks blocks from metadata
        tasks_block_list = ticket_s3_data['0']['tasks_blocks']

        # get the last task block
        next_task_block = len(tasks_block_list) + 1 

        return next_task_block
    


# function to create a new task record
@error_handler(library_code=lib_code_ver_TM, function_code="03")
def create_task_record(Task : AddTask_Input,next_child_id : int, bugs={}) -> str:
    '''
    
    Function to create a new task record

    params: 
     - task_data : dict

    return :
     - task_id : int
     - None 
    
    
    '''

    
    # call the get_user_team function from users_utils
    owner_team, bugs_local = get_user_team(Task.owner)

    if bugs_local:
        logger_1.error(f"Error in fetching owner team: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif owner_team is not None:
        # call create record function from rds_instance
        new_task, bugs_local = rds_instance.create_record_in_table(
            table_model=Task_RDS,
            type=Task.ticket_type,
            master_id=Task.ticketid,
            name=Task.name,
            added_by_id=Task.added_by,
            added_on=datetime.now(),
            owner=Task.owner,
            deadline=Task.deadline if Task.deadline else datetime.now() + timedelta(days=7),
            priority=Task.priority,
            status=Task.status,
            machine_raised=Task.machine_raised,
            team_id = owner_team,
            child_id = next_child_id
        )

        if bugs_local:
            logger_1.error(f"Error in adding new task: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        return new_task


# function to insert a new task record to the exisitng tasks cache
@error_handler(library_code=lib_code_ver_TM, function_code="04")
def insert_record_to_task_cache(task_id : int, bugs={}) -> str:
    '''

    Function to insert a new task record to the exisitng tasks cache

    params: 
     - task_id : int

    return :
        - bool : True if successful, False otherwise 
        
        
    '''

    # call the query table function from rds_instance
    all_tasks, bugs_local = rds_instance.query_table(Task_RDS)

    if bugs_local:
        logger_1.error(f"Error in fetching task record: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return False
    
    elif all_tasks is not None:

        # get then newly created task record
        new_task_record = all_tasks[all_tasks['id'] == int(task_id)]

        # Convert the DataFrame to a dictionary with task_id as the key
        new_task_dict = {str(row['id']): row.to_dict() for index, row in new_task_record.iterrows()}

        # Serialize the updated cache for storage (if needed)
        serialized_new_task = json.dumps(new_task_dict, cls=CustomEncoder) 

        logger_1.info(f"New task record fetched: {serialized_new_task}")        

        # fetch the tasks from the cache
        all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")
        
        logger_1.info(f"Current tasks fetched from cache: {all_tasks_from_cache}")

        if all_tasks_from_cache:

            # Deserialize the existing cache into a dictionary
            tasks_dict = json.loads(all_tasks_from_cache)

            # Update the dictionary with the new task record
            tasks_dict.update(new_task_dict)

            # Serialize the updated dictionary back to a JSON string
            serialized_tasks = json.dumps(tasks_dict, cls=CustomEncoder)

            # Save the updated cache back to Redis
            redis_instance.set_key("all_tasks_cached", serialized_tasks)

            logger_1.info("Task record added to cache successfully.")
            return True
        
        else:
            logger_1.error("Failed to fetch current tasks from cache.")
            return False
        


# function to add a new task block to a ticket
@error_handler(library_code=lib_code_ver_TM, function_code="05")
def add_task_to_ticket(task : AddTask_Input, task_id : int,next_child_id : int, bugs={}) -> dict:
    '''

    Function to add a new task block to a ticket

    params: 
     - ticket_id : int
     - ticket_type : int
     - task : dict

    return :
        - ticket_s3_data if successful
        - None

    '''

    # call fetch and cache function from features_tickets_utils
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid=task.ticketid,ticket_type=task.ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching ticket data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:
        logger_1.info(f"Ticket data fetched successfully, {ticket_s3_data}")
        
        # fetch the last key in the ticket data
        last_key = list(ticket_s3_data.keys())[-1]

        next_key_for_task_block = str(int(last_key) + 1)

        attachment_urls_list = []

        if task.attachments is not None:

            logger_1.info(f"Attachments are {task.attachments}")

            # call the upload_attachments_to_s3 function to upload the attachments to s3
            attachment_urls_list, bugs_local = upload_attachments_to_s3(attachments=task.attachments,ticket_type=6, ticket_master_id=task.ticketid,block_id=next_key_for_task_block)

            if bugs_local:
                logger_1.error(f"Failed to upload attachments, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif attachment_urls_list is not None:
                logger_1.info(f"Attachment urls are {attachment_urls_list}")


        # create a new task block
        new_task_block = {
            "added_by": str(task.added_by),
            "text": task.name,
            "owner": None if task.owner is None else str(task.owner),
            "deadline": calculate_seven_days() if task.deadline is None else task.deadline,
            "task_id": str(task_id),
            "priority": str(task.priority),
            "status": str(task.status),
            "child_id": str(next_child_id),
            "machine_raised": task.machine_raised,
            "attachments": attachment_urls_list
        }


        # serialize the new task block
        serialized_new_task_block = TasksBlock(**new_task_block)

        # add the new task block to the ticket data
        ticket_s3_data[next_key_for_task_block] = serialized_new_task_block.model_dump()
        
        # get the tasks blocks from metadata
        tasks_block_dict = ticket_s3_data['0']['tasks_blocks']

        # append the new task block to the tasks blocks
        tasks_block_dict[str(next_key_for_task_block)] = int(task_id)  

        # update the tasks blocks in the metadata
        ticket_s3_data['0']['tasks_blocks'] = tasks_block_dict

        # fetch the last key in the ticket data
        last_key_for_status = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key_for_status) + 1

        # create a new status block
        status_block = {
            'status_change_description': f'Task named {task.name} added',
            'updated_by': task.added_by
        }

        # serialize the new status block using StatusChangeBlock from the s3_data_models
        serialized_status_block = StatusChangeBlock(**status_block)

        # add the new status block to the ticket data
        ticket_s3_data[str(status_block_id)] = serialized_status_block.model_dump()

        # update the status block in the metadata
        ticket_s3_data['0']['status_blocks'].append(str(status_block_id))


        # call handle_ticket_update_for_s3 function from features_tickets_utils
        ticket_queued, bugs_local = handle_ticket_update_for_s3(task.ticketid, ticket_s3_data, task.added_by)

        if bugs_local:
            logger_1.error(f"Error in updating ticket data: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif ticket_queued is not None:
            return ticket_queued
        
    else:
        return None





# function to update a task record in the RDS cache
@error_handler(library_code=lib_code_ver_TM, function_code="06")
def push_updates_to_task_rds_cache(task_id: int, updates: dict, bugs={}) -> bool:
    """
    Updates task records in cache and queues the update for later RDS synchronization.

    Parameters:
    - task_id (int): ID of the task to be updated.
    - updates (dict): Dictionary of fields to be updated.

    Returns:
    - bool: True if the operation was successful, False otherwise.
    """

    # Fetch the current tasks from the cache
    all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")


    # fallback mechanism if the cache is empty, call the all_task_records function to fetch all tasks
    if not all_tasks_from_cache:
        all_tasks = all_task_records()
        if all_tasks is not None:
            all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")
        else:
            logger_1.error(f"Could not fetch task with {task_id} from cache")
            return False

    if all_tasks_from_cache:
        # Deserialize the existing tasks cache into a dictionary
        tasks_dict = json.loads(all_tasks_from_cache)

        # Check if the task exists in the cache
        if str(task_id) in tasks_dict:
            # Update the task with the new values provided in `updates`
            for key, value in updates.items():
                tasks_dict[str(task_id)][key] = value

            # Serialize the updated tasks dictionary back to a JSON string
            serialized_tasks = json.dumps(tasks_dict, cls=CustomEncoder)

            # Save the updated cache back to Redis
            redis_instance.set_key("all_tasks_cached", serialized_tasks) 

            # Add the task ID to the Redis queue for later RDS update
            redis_instance.lpush("task_update_queue", task_id)

            logger_1.info(f"Task ID {task_id} updated in cache and added to update queue.")
            return True
        else:
            logger_1.error(f"Task ID {task_id} not found in cache.")
            return False
    else:
        logger_1.error("Failed to fetch tasks from cache.")
        return False
    




# function to update a task record from the queue
@error_handler(library_code=lib_code_ver_TM, function_code="07")
def write_updates_to_task_rds(bugs={}):

    '''
    Function to write changes to RDS from the queue at five-minute intervals.

    Parameters:
    None

    Returns:
    None
    '''

    while True:
        time.sleep(60)  # Wait for 1 minute before processing the queue again
        
        # logger_1.info("Checking for changes to write to Task RDS")   

        try:
            # Process updates from the queue until empty
            while True:
                # Pop a task ID from the queue
                task_id = redis_instance.rpop('task_update_queue')
                if not task_id:
                    break  # Exit loop if the queue is empty

                task_id = task_id.decode('utf-8')  # Decode bytes to string if necessary
                logger_1.info(f"Processing task {task_id} update from queue")

                # Fetch the task data from the cache
                all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")

                if not all_tasks_from_cache:

                    # fallback mechanism if the cache is empty, call the all_task_records function to fetch all tasks
                    all_tasks,bugs_local = all_task_records()

                    if bugs_local:
                        logger_1.error(f"Write updates to cache, failed in setting the cache : {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)

                    elif all_tasks is not None:
                        all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")

                # Deserialize the tasks from the cache
                tasks_dict = json.loads(all_tasks_from_cache)

                # Check if the task exists in the cache
                if task_id in tasks_dict:
                    task_data_json = json.dumps(tasks_dict[task_id])

                    # Deserialize the task data into a dictionary
                    task_data = json.loads(task_data_json)

                    # Update the task record in the RDS
                    updated_task, bugs_local = rds_instance.update_record_in_table(Task_RDS,int(task_id), **task_data)

                    if bugs_local:
                        logger_1.error(f"Error in updating task record: {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        continue
                    
                    elif updated_task is not None:
                        logger_1.info(f"Task ID {task_id} updated in RDS successfully.")
               
        except Exception as e:
            logger_1.error(f"Error processing task updates: {e}")



# function to update the task in the ticket
@error_handler(library_code=lib_code_ver_TM, function_code="08")
def update_task_in_ticket(Task : UpdateTask_Input, bugs={}):

    '''

    Function to update the task in the ticket

    Parameters:
    - Task (dict): Dictionary containing the updated task data.

    Returns:
    - dict: Updated ticket data if successful, None otherwise.

    
    '''    

    # call the fetch and cache ticket function to update the ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid=Task.ticketid,ticket_type=Task.ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching ticket data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # get the tasks blocks from metadata
        tasks_block_list = ticket_s3_data['0']['tasks_blocks']

        logger_1.info(f"Tasks block list is {tasks_block_list}")

        # fetch the key that has str(Task.task_id)
        task_block_key = [key for key in tasks_block_list if int(tasks_block_list[key]) == int(Task.taskid)][0]

        logger_1.info(f"Task block key is {task_block_key}")

        # get the task block
        task_block = ticket_s3_data.get(task_block_key)

        if task_block is not None:
            logger_1.info(f"Task block is {task_block}")

            # # update the task block with the new values
            task_block['text'] = Task.name if Task.name else task_block['text']
            task_block['owner'] = str(Task.owner) if Task.owner else task_block['owner']
            task_block['deadline'] = Task.deadline if Task.deadline else task_block['deadline']
            task_block['priority'] = str(Task.priority) if Task.priority else task_block['priority']
            task_block['status'] = str(Task.status) if Task.status else task_block['status']
            task_block['machine_raised'] = Task.machine_raised if Task.machine_raised else task_block['machine_raised']

            # serialize the updated task block
            serialized_task_block = TasksBlock(**task_block)

            # update the task block in the ticket data
            ticket_s3_data[task_block_key] = serialized_task_block.model_dump()

            # fetch the last key in the ticket data
            last_key_for_status = list(ticket_s3_data.keys())[-1]

            status_block_id = int(last_key_for_status) + 1

            # create a new status block
            status_block = {
                'status_change_description': f'Task with id {task_block_key} updated',
                'updated_by': Task.updated_by
            }

            # serialize the new status block using StatusChangeBlock from the s3_data_models
            serialized_status_block = StatusChangeBlock(**status_block)

            # add the new status block to the ticket data
            ticket_s3_data[str(status_block_id)] = serialized_status_block.model_dump()

            # update the status block in the metadata
            ticket_s3_data['0']['status_blocks'].append(str(status_block_id))

            # call handle_ticket_update_for_s3 function from features_tickets_utils
            ticket_queued, bugs_local = handle_ticket_update_for_s3(ticketid=Task.ticketid,ticket_with_updation=ticket_s3_data, user_id=Task.updated_by)

            if bugs_local:
                logger_1.error(f"Error in updating ticket data: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif ticket_queued is not None:
                return ticket_queued
                                                        

        else:
            logger_1.info(f"Task block is not found")
            return None
        

# function to delete the task for the rds cache
@error_handler(library_code=lib_code_ver_TM, function_code="09")
def delete_task_service(Task : DeleteTask_Input, bugs={}) -> bool:
    '''
    
    Function to delete the task for the rds cache

    Parameters:
    - Task (dict): Dictionary containing the task data to be deleted.

    Returns:
    - bool: True if the operation was successful, False otherwise.
    
    '''

    # keep an array for tracking success or failure of task deletion
    deletion_status = []


    # fetch the task from the RDS cache
    all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")

    if not all_tasks_from_cache:
        all_tasks,bugs_local = all_task_records()
        
        if bugs_local:
            logger_1.error(f"Delete task from cache, failed in setting the cache : {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
        
        elif all_tasks is not None:
            all_tasks_from_cache = redis_instance.get_key("all_tasks_cached")

    # Deserialize the tasks from the cache
    all_tasks_dict = json.loads(all_tasks_from_cache)


    for task_id in Task.task_ids:

        # Check if the task exists in the cache
        if str(task_id) in all_tasks_dict:
            # Delete the task from the cache
            del all_tasks_dict[str(task_id)]

            # Serialize the updated tasks dictionary back to a JSON string
            serialized_tasks = json.dumps(all_tasks_dict, cls=CustomEncoder)

            # Save the updated cache back to Redis
            redis_instance.set_key("all_tasks_cached", serialized_tasks)

            logger_1.info(f"Task ID {task_id} deleted from cache.")

            # call the delete_task_from_ticket function from tasks_utils
            ticket_s3_data, bugs_local = delete_task_from_ticket(ticket_id=Task.ticketid,ticket_type=Task.ticket_type,task_id=task_id,deleted_by=Task.deleted_by)

            if bugs_local:
                logger_1.error(f"Error in deleting task from ticket: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                deletion_status.append(False)
                continue

            elif ticket_s3_data is not None:
                logger_1.info(f"Task ID {task_id} deleted from ticket successfully.")

                # add it to the queue for deletion from RDS
                redis_instance.lpush("task_delete_queue", task_id)

                deletion_status.append(True)
        
        else:
            logger_1.error(f"Task ID {task_id} not found in cache.")
            deletion_status.append(False)

    return all(deletion_status)



# function to process the task deletion queue
@error_handler(library_code=lib_code_ver_TM, function_code="10")
def process_task_deletion_queue(bugs={}):

    '''
    
    Function to process the task deletion queue

    Parameters:
    None

    Returns:
    None
    
    '''

    while True:
        time.sleep(60)  # Wait for 1 minute before processing the queue again

        # logger_1.info("Checking for tasks to delete from RDS")

        try:
            # Process deletions from the queue until empty
            while True:
                # Pop a task ID from the queue
                task_id = redis_instance.rpop('task_delete_queue')
                if not task_id:
                    break  # Exit loop if the queue is empty

                task_id = task_id.decode('utf-8')  # Decode bytes to string if necessary
                logger_1.info(f"Processing task {task_id} deletion from queue")

                # Delete the task record from the RDS
                deleted, bugs_local = rds_instance.delete_record_from_table(Task_RDS, int(task_id))

                if bugs_local:
                    logger_1.error(f"Error deleting task record: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    continue
                
                elif deleted == True:
                    logger_1.info(f"Task ID {task_id} deleted from RDS successfully.")

                elif deleted == False:
                    logger_1.error(f"Task ID {task_id} not found in RDS.")
                    continue

        except Exception as e:
            logger_1.error(f"Error processing task deletions: {e}")



# function to delete the task from the ticket
@error_handler(library_code=lib_code_ver_TM, function_code="11")
def delete_task_from_ticket(ticket_id : int, ticket_type : int, task_id : int, deleted_by : int, bugs={}) -> dict:

    '''

    Function to delete the task from the ticket

    Parameters:
    - ticket_id (int): ID of the ticket to be updated.
    - ticket_type (int): Type of the ticket.
    - task_id (int): ID of the task to be deleted.

    Returns:
    - dict: Updated ticket data if successful, None otherwise.

    
    '''

    # call fetch and cache ticket function from features_tickets_utils
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket_id,ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching ticket data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:
            
            # get the tasks blocks from metadata
            tasks_block_list = ticket_s3_data['0']['tasks_blocks']
    
            # fetch the key that has str(Task.task_id)
            task_block_key = [key for key in tasks_block_list if int(tasks_block_list[key]) == int(task_id)][0]
    
            # delete the task block from the ticket data
            del ticket_s3_data[str(task_block_key)]
    
            # delete the task from the tasks blocks 
            del tasks_block_list[task_block_key]
    
            # update the tasks blocks in the metadata
            ticket_s3_data['0']['tasks_blocks'] = tasks_block_list
    
            # fetch the last key in the ticket data
            last_key_for_status = list(ticket_s3_data.keys())[-1]
    
            status_block_id = int(last_key_for_status) + 1
    
            # create a new status block
            status_block = {
                'status_change_description': f'Task with id {task_block_key} deleted',
                'updated_by': deleted_by
            }
    
            # serialize the new status block using StatusChangeBlock from the s3_data_models
            serialized_status_block = StatusChangeBlock(**status_block)
    
            # add the new status block to the ticket data
            ticket_s3_data[str(status_block_id)] = serialized_status_block.model_dump()
    
            # update the status block in the metadata
            ticket_s3_data['0']['status_blocks'].append(str(status_block_id))

            # call handle_ticket_update_for_s3 function from features_tickets_utils
            ticket_queued, bugs_local = handle_ticket_update_for_s3(ticket_id, ticket_s3_data, deleted_by)

            if bugs_local:
                logger_1.error(f"Error in updating ticket data: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif ticket_queued is not None:
                return ticket_queued