# Import inbuilt libraries



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
from datetime import datetime, timedelta
import json
import random
import time
from fastapi.responses import JSONResponse
import numpy as np
import pandas as pd
from collections import deque

# Include repos folder for custom libraries


# Declare variables used 
# Library code for make model library
lib_code_MM = "49"
lib_ver_MM = "00"

lib_code_ver_MM = f"{lib_code_MM}{lib_ver_MM}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance,hiperft_bucket,get_current_date,redis_instance,rds_instance,prod_rds_instance
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.make_model_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import MakeModel as MM



# initialize the logger
logger_1 = LoggerFactory(name="make_model_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model
# define other funcs

# function to get make model table
@error_handler(library_code=lib_code_ver_MM, function_code="01")

def get_make_model_data_as_df():
    
    """
    
    Function to fetch all the data from the MakeModel table
    
    params:
        - None
        
    returns:
        - df: pandas dataframe with MakeModel data, None if failed to fetch data or no data found
        - bugs_dict: dictionary with error message if any error occurs
    

    """
    
    # init a session
    session = prod_rds_instance.get_connection()
    
    with handle_session(session) as ns:
        data = ns.query(MM).all()
    
        # Convert the data to a list of dictionaries for DataFrame conversion
        data_list = [
                {
                'make_model_id': item.make_model_id,
                'vehicle_make': item.vehicle_make,
                'vehicle_model': item.vehicle_model,
                'emission': item.emission,
                'ecu_make': item.ecu_make,
                'ecu_model': item.ecu_model,
                'ecu_software_id': item.ecu_software_id,
                'gvw': item.gvw,
                'cylinders': item.cylinders,
                'num_of_gears': item.num_of_gears,
                'engine_capacity': item.engine_capacity,
                'power': item.power,
                'max_torque_nm': item.max_torque_nm,
                'rpm_min_for_max_torque': item.rpm_min_for_max_torque,
                'rpm_max_for_max_torque': item.rpm_max_for_max_torque,
                'max_rpm': item.max_rpm,
                'oe_front_tyre_type': item.oe_front_tyre_type,
                'oe_rear_tyre_type': item.oe_rear_tyre_type,
                'wheel_radius': item.wheel_radius,
                'gear_1': item.gear_1,
                'gear_2': item.gear_2,
                'gear_3': item.gear_3,
                'gear_4': item.gear_4,
                'gear_5': item.gear_5,
                'gear_6': item.gear_6,
                'gear_7': item.gear_7,
                'gear_8': item.gear_8,
                'gear_9': item.gear_9,
                'crawler': item.crawler,
                'rear_axle_ratio': item.rear_axle_ratio,
                'reverse': item.reverse,
                'injector_part_number': item.injector_part_number,
                'fuel_pump_make': item.fuel_pump_make,
                'fuel_pump_model': item.fuel_pump_model,
                'pp_flag': item.pp_flag,
                'algo_flag': item.algo_flag,
                'broadcast_flag': item.broadcast_flag,
                'request_flag': item.request_flag,
                'exec_command_flag': item.exec_command_flag,
                'flashing_flag': item.flashing_flag,
                'dataset_flag': item.dataset_flag,
                'bb_flag': item.bb_flag,
                'dtc_flag': item.dtc_flag,
                'pairs': item.pairs,
                'req_id': item.req_id,
                'resp_id': item.resp_id,
                'dataset_id': item.dataset_id
            }
            for item in data
            ]
    
        # Convert the list of dictionaries into a DataFrame
        df = pd.DataFrame(data_list)
        return df
            
            
            
# function to add make model to rds
@error_handler(library_code=lib_code_ver_MM, function_code="02")
def add_make_model_to_rds(make_model : AddMakeModel):
    
    """
    
    Function to add make model to the MakeModel table
    
    params:
        - make_model_id : str
        - vehicle_make : str
        - vehicle_model : str
        - emission : str
        - ecu_make : str
        - ecu_model : str
        - ecu_software_id : str
        - gvw : int
        - cylinders : int
        - num_of_gears : int
        - engine_capacity : int
        - power : int
        - max_torque_nm : int
        - rpm_min_for_max_torque : int
        - rpm_max_for_max_torque : int
        - max_rpm : int
        - oe_front_tyre_type : int
        - oe_rear_tyre_type : int
        - wheel_radius : float
        - gear_1 : float
        - gear_2 : float
        - gear_3 : float
        - gear_4 : float
        - gear_5 : float
        - gear_6 : float
        - gear_7 : str
        - gear_8 : str
        - gear_9 : str
        - crawler : str
        - rear_axle_ratio : float
        - reverse : float
        - injector_part_number : str
        - fuel_pump_make : str
        - fuel_pump_model : str
        - pp_flag : str
        - algo_flag : str
        - broadcast_flag : int
        - request_flag : int
        - exec_command_flag : int
        - flashing_flag : int
        - dataset_flag : int
        - bb_flag : str
        - dtc_flag : int
        - pairs : int
        - req_id : str
        - resp_id : str
        - dataset_id : str
    returns:
        - success: bool
        - bugs_dict: dictionary with error message if any error occurs
    
    """ 
    
    
    # init a boolean variable to check if the operation was successful
    success = False
    
    # init a session
    session = rds_instance.get_connection()
    
    with handle_session(session) as ns:
        # create a new MakeModel object
        ns.add(MM(
            make_model_id = make_model.make_model_id,
            vehicle_make = make_model.vehicle_make,
            vehicle_model = make_model.vehicle_model,
            emission = make_model.emission,
            ecu_make = make_model.ecu_make,
            ecu_model = make_model.ecu_model,
            ecu_software_id = make_model.ecu_software_id,
            gvw = make_model.gvw,
            cylinders = make_model.cylinders,
            num_of_gears = make_model.num_of_gears,
            engine_capacity = make_model.engine_capacity,
            power = make_model.power,
            max_torque_nm = make_model.max_torque_nm,
            rpm_min_for_max_torque = make_model.rpm_min_for_max_torque,
            rpm_max_for_max_torque = make_model.rpm_max_for_max_torque,
            max_rpm = make_model.max_rpm,
            oe_front_tyre_type = make_model.oe_front_tyre_type,
            oe_rear_tyre_type = make_model.oe_rear_tyre_type,
            wheel_radius = make_model.wheel_radius,
            gear_1 = make_model.gear_1,
            gear_2 = make_model.gear_2,
            gear_3 = make_model.gear_3,
            gear_4 = make_model.gear_4,
            gear_5 = make_model.gear_5,
            gear_6 = make_model.gear_6,
            gear_7 = make_model.gear_7,
            gear_8 = make_model.gear_8,
            gear_9 = make_model.gear_9,
            crawler = make_model.crawler,
            rear_axle_ratio = make_model.rear_axle_ratio,
            reverse = make_model.reverse,
            injector_part_number = make_model.injector_part_number,
            fuel_pump_make = make_model.fuel_pump_make,
            fuel_pump_model = make_model.fuel_pump_model,
            pp_flag = make_model.pp_flag,
            algo_flag = make_model.algo_flag,
            broadcast_flag = make_model.broadcast_flag,
            request_flag = make_model.request_flag,
            exec_command_flag = make_model.exec_command_flag,
            flashing_flag = make_model.flashing_flag,
            dataset_flag = make_model.dataset_flag,
            bb_flag = make_model.bb_flag,
            dtc_flag = make_model.dtc_flag,
            pairs = make_model.pairs,
            req_id = make_model.req_id,
            resp_id = make_model.resp_id,
            dataset_id = make_model.dataset_id
            
            ))
        
        # commit the session
        ns.commit()
        
        # set the success flag to True
        success = True
        
    return success
        
        
        
@error_handler(library_code=lib_code_ver_MM, function_code="03")
def update_make_model_in_rds(make_model: UpdateMakeModel):
    """
    Function to update make model in the MakeModel table
    
    params:
    
        - make_model_id : str (required)
        - Other fields are optional and will only update if provided
    
    returns:
        - success: bool
        - bugs_dict: dictionary with error message if any error occurs
    """

    # Init a boolean variable to check if the operation was successful
    success = False
    
    # Init a session
    session = rds_instance.get_connection()
    
    with handle_session(session) as ns:
        # Get the make model object from the database
        make_model_obj = ns.query(MM).filter(MM.make_model_id == make_model.make_model_id).first()
        
        # Check if the object exists
        if make_model_obj is not None:
            # Only update fields that are provided (not None)
            if make_model.vehicle_make is not None:
                make_model_obj.vehicle_make = make_model.vehicle_make
            if make_model.vehicle_model is not None:
                make_model_obj.vehicle_model = make_model.vehicle_model
            if make_model.emission is not None:
                make_model_obj.emission = make_model.emission
            if make_model.ecu_make is not None:
                make_model_obj.ecu_make = make_model.ecu_make
            if make_model.ecu_model is not None:
                make_model_obj.ecu_model = make_model.ecu_model
            if make_model.ecu_software_id is not None:
                make_model_obj.ecu_software_id = make_model.ecu_software_id
            if make_model.gvw is not None:
                make_model_obj.gvw = make_model.gvw
            if make_model.cylinders is not None:
                make_model_obj.cylinders = make_model.cylinders
            if make_model.num_of_gears is not None:
                make_model_obj.num_of_gears = make_model.num_of_gears
            if make_model.engine_capacity is not None:
                make_model_obj.engine_capacity = make_model.engine_capacity
            if make_model.power is not None:
                make_model_obj.power = make_model.power
            if make_model.max_torque_nm is not None:
                make_model_obj.max_torque_nm = make_model.max_torque_nm
            if make_model.rpm_min_for_max_torque is not None:
                make_model_obj.rpm_min_for_max_torque = make_model.rpm_min_for_max_torque
            if make_model.rpm_max_for_max_torque is not None:
                make_model_obj.rpm_max_for_max_torque = make_model.rpm_max_for_max_torque
            if make_model.max_rpm is not None:
                make_model_obj.max_rpm = make_model.max_rpm
            if make_model.oe_front_tyre_type is not None:
                make_model_obj.oe_front_tyre_type = make_model.oe_front_tyre_type
            if make_model.oe_rear_tyre_type is not None:
                make_model_obj.oe_rear_tyre_type = make_model.oe_rear_tyre_type
            if make_model.wheel_radius is not None:
                make_model_obj.wheel_radius = make_model.wheel_radius
            if make_model.gear_1 is not None:
                make_model_obj.gear_1 = make_model.gear_1
            if make_model.gear_2 is not None:
                make_model_obj.gear_2 = make_model.gear_2
            if make_model.gear_3 is not None:
                make_model_obj.gear_3 = make_model.gear_3
            if make_model.gear_4 is not None:
                make_model_obj.gear_4 = make_model.gear_4
            if make_model.gear_5 is not None:
                make_model_obj.gear_5 = make_model.gear_5
            if make_model.gear_6 is not None:
                make_model_obj.gear_6 = make_model.gear_6
            if make_model.gear_7 is not None:
                make_model_obj.gear_7 = make_model.gear_7
            if make_model.gear_8 is not None:
                make_model_obj.gear_8 = make_model.gear_8
            if make_model.gear_9 is not None:
                make_model_obj.gear_9 = make_model.gear_9
            if make_model.crawler is not None:
                make_model_obj.crawler = make_model.crawler
            if make_model.rear_axle_ratio is not None:
                make_model_obj.rear_axle_ratio = make_model.rear_axle_ratio
            if make_model.reverse is not None:
                make_model_obj.reverse = make_model.reverse
            if make_model.injector_part_number is not None:
                make_model_obj.injector_part_number = make_model.injector_part_number
            if make_model.fuel_pump_make is not None:
                make_model_obj.fuel_pump_make = make_model.fuel_pump_make
            if make_model.fuel_pump_model is not None:
                make_model_obj.fuel_pump_model = make_model.fuel_pump_model
            if make_model.pp_flag is not None:
                make_model_obj.pp_flag = make_model.pp_flag
            if make_model.algo_flag is not None:
                make_model_obj.algo_flag = make_model.algo_flag
            if make_model.broadcast_flag is not None:
                make_model_obj.broadcast_flag = make_model.broadcast_flag
            if make_model.request_flag is not None:
                make_model_obj.request_flag = make_model.request_flag
            if make_model.exec_command_flag is not None:
                make_model_obj.exec_command_flag = make_model.exec_command_flag
            if make_model.flashing_flag is not None:
                make_model_obj.flashing_flag = make_model.flashing_flag
            if make_model.dataset_flag is not None:
                make_model_obj.dataset_flag = make_model.dataset_flag
            if make_model.bb_flag is not None:
                make_model_obj.bb_flag = make_model.bb_flag
            if make_model.dtc_flag is not None:
                make_model_obj.dtc_flag = make_model.dtc_flag
            if make_model.pairs is not None:
                make_model_obj.pairs = make_model.pairs
            if make_model.req_id is not None:
                make_model_obj.req_id = make_model.req_id
            if make_model.resp_id is not None:
                make_model_obj.resp_id = make_model.resp_id
            if make_model.dataset_id is not None:
                make_model_obj.dataset_id = make_model.dataset_id
                
            # Commit the session after updating only the non-None fields
            ns.commit()
            
            # Set the success flag to True
            success = True

    return success


# function to delete make model from rds
@error_handler(library_code=lib_code_ver_MM, function_code="04")
def delete_from_make_model_rds(make_model : DeleteMakeModel):
    
    """
    
    Function to delete make model from the MakeModel table
    
    params:
        - make_model_id : str
        
    returns:
        - success: bool
        - bugs_dict: dictionary with error message if any error occurs
    
    """
    
    # init a boolean variable to check if the operation was successful
    success = False
    
    # init a session
    session = rds_instance.get_connection()
    
    with handle_session(session) as ns:
        # get the make model object from the database
        make_model_obj = ns.query(MM).filter(MM.make_model_id == make_model.make_model_id).first()
        
        # check if the object exists
        if make_model_obj is not None:
            # delete the object
            ns.delete(make_model_obj)
            
            # commit the session
            ns.commit()
            
            # set the success flag to True
            success = True
            
    return success


# function to fetch make_model_id provided make and model
@error_handler(library_code=lib_code_ver_MM, function_code="05")
def get_make_model_id(make : str, model : str, emission : str):

    '''

    Function to fetch make model id provided make and model

    params

        - make : str : vehicle make
        - model : str : vehicle model

    returns

        - make_model_id : int : make model id
    
    '''

    make_model_id = None

    session = rds_instance.get_connection()

    # use filter to fetch the make model id from make model table
    with handle_session(session) as ns:
        make_model_id = ns.query(MM.make_model_id).filter(MM.vehicle_make == make, MM.vehicle_model == model, MM.emission == emission).first().make_model_id        

    return make_model_id




# function to fetch vehicle make and model provided make_model_id
@error_handler(library_code=lib_code_ver_MM, function_code="06")
def get_make_model(make_model_id : int):

    '''

    Function to fetch vehicle make and model provided make_model_id

    params

        - make_model_id : int : make model id

    returns

        - make_model : dict : dict of vehicle make and model
    
    '''

    make_model = {}

    session = rds_instance.get_connection()

    # use filter to fetch the make model from make model table
    with handle_session(session) as ns:
        vehicle_make = ns.query(MM).filter(MM.make_model_id == make_model_id).first().vehicle_make
        vehicle_model = ns.query(MM).filter(MM.make_model_id == make_model_id).first().vehicle_model        

        make_model = {"vehicle_make" : vehicle_make, "vehicle_model" : vehicle_model}

    return make_model


# function to retrieve and cache all vehicle makes
@error_handler(library_code=lib_code_ver_MM, function_code="07")
def get_all_make_dict():

    '''
    Function to retrieve and cache all vehicle makes

    params 
        - None

    returns
        - all_makes : dict : dict where key would be the make_id and value would be the vehicle_make
    
    
    '''

    # if make_list is cached return it
    make_dict_cached = redis_instance.get_key("all_vehicle_make")

    if make_dict_cached:
        return json.loads(make_dict_cached)
    
    elif make_dict_cached is None:

        # Use a set to store unique vehicle makes
        make_set = set()

        # get connection
        session = rds_instance.get_connection()

        # get all vehicle makes
        with handle_session(session) as ns:
            make_models = ns.query(MM).distinct().all()

            # Populate make_set with unique vehicle makes
            for make in make_models:
                if str(make.vehicle_make) != "":
                    make_set.add(make.vehicle_make)
            
            # Convert set to a dictionary with indexed keys
            make_dict = {f"{index+1}": vehicle_make for index, vehicle_make in enumerate(sorted(make_set))}

            # cache the make_dict
            redis_instance.set_key("all_vehicle_make", json.dumps(make_dict), ex=300)

            return make_dict


@error_handler(library_code=lib_code_ver_MM, function_code="08")
def get_all_models_to_make(make_name):
    '''
    Function to retrieve and cache all vehicle models

    params 
        - make_name : str : vehicle make name

    returns
        - all_models : dict : dict where key would be the make_model_id and value would be the vehicle_model    
    '''

    # if model_list is cached return it
    model_list_cached = redis_instance.get_key(f"all_vehicle_model_{make_name}")

    if model_list_cached:
        return json.loads(model_list_cached)
    
    elif model_list_cached is None:
            
        # Initialize an empty dictionary to store all vehicle models
        all_models = {}
    
        # get connection
        session = rds_instance.get_connection()
    
        # get all vehicle models
        with handle_session(session) as ns:
            make_models = ns.query(MM).filter(MM.vehicle_make == make_name).distinct().all()
    
            # get make_model_id and vehicle_model column and populate all_models
            for make_model in make_models:
                # Filter out models where vehicle_model is 0, None, or an empty string
                if make_model.vehicle_model and make_model.vehicle_model != 0 and str(make_model.vehicle_model).strip() != "":
                    all_models[make_model.make_model_id] = make_model.vehicle_model

            # cache the all_models
            redis_instance.set_key(f"all_vehicle_model_{make_name}", json.dumps(all_models), ex=300)

            return all_models   

        
@error_handler(library_code=lib_code_ver_MM, function_code="09")
def get_all_ecu_make_dict():
    '''
    Function to retrieve and cache all ECU makes

    params 
        - None

    returns
        - ecu_make_dict : dict : dictionary of all ECU makes with numeric keys
        - bugs : dict : dict of bugs if any error occurs
    '''

    # if ecu_make_list is cached return it
    ecu_make_dict_cached = redis_instance.get_key("all_ecu_makes")

    if ecu_make_dict_cached:
        return json.loads(ecu_make_dict_cached)
    
    elif ecu_make_dict_cached is None:
        
        # Initialize an empty dictionary to store all ECU makes
        ecu_make_dict = {}

        # get connection
        session = rds_instance.get_connection()

        # get all ECU makes
        with handle_session(session) as ns:
            ecu_makes = ns.query(MM.ecu_make).distinct().all()

            # get ecu_make column and populate ecu_make_dict without duplicates
            unique_makes = set()
            for row in ecu_makes:
                if row.ecu_make and row.ecu_make.strip() != "": 
                    unique_makes.add(row.ecu_make)

            # Convert the set to a dictionary with numbered keys
            ecu_make_dict = {index + 1: make for index, make in enumerate(sorted(unique_makes))}

            # cache the ecu_make_dict
            redis_instance.set_key("all_ecu_makes", json.dumps(ecu_make_dict), ex=300)

            return ecu_make_dict           


@error_handler(library_code=lib_code_ver_MM, function_code="10")
def get_all_ecu_model_dict_to_make(ecu_make_name):
    '''
    Function to retrieve and cache all ECU models for a given ECU make

    params 
        - ecu_make_name : str : ECU make name

    returns
        - ecu_model_dict : dict : dictionary of all ECU models with numeric keys
        - bugs : dict : dict of bugs if any error occurs
    '''

    # if ecu_model_list is cached return it
    ecu_model_dict_cached = redis_instance.get_key(f"all_ecu_model_{ecu_make_name}")

    if ecu_model_dict_cached:
        return json.loads(ecu_model_dict_cached)
    
    elif ecu_model_dict_cached is None:

        # Initialize an empty dictionary to store all ECU models
        ecu_model_dict = {}

        # get connection
        session = rds_instance.get_connection()

        # get all ECU models for the specified make
        with handle_session(session) as ns:
            ecu_models = ns.query(MM.ecu_model).filter(MM.ecu_make == ecu_make_name).distinct().all()

            # get ecu_model column and populate ecu_model_dict without duplicates
            unique_models = set()
            for row in ecu_models:
                if row.ecu_model and row.ecu_model.strip() != "":
                    unique_models.add(row.ecu_model)

            # Convert the set to a dictionary with numbered keys
            ecu_model_dict = {index + 1: model for index, model in enumerate(sorted(unique_models))}

            # cache the ecu_model_dict
            redis_instance.set_key(f"all_ecu_model_{ecu_make_name}", json.dumps(ecu_model_dict), ex=300)

            return ecu_model_dict
        

# function to fetch the emission for a given make and model 
@error_handler(library_code=lib_code_ver_MM, function_code="11")
def get_emissions_to_make_model(make : str, model : str):
    
    """
    
    Function to fetch the emission for a given make and model
    
    params:
        - make : str
        - model : str
        
    returns:
        - list of emissions for the given make and model
        - bugs_dict: dictionary with error message if any error occurs
    
    
    
    """
    
    # init a list to store the emissions
    emissions_list = []
    
    # init a session
    session = rds_instance.get_connection()
    
    with handle_session(session) as ns:
        # get the emissions for the given make and model
        make_model_record = ns.query(MM.emission).filter(MM.vehicle_make == make, MM.vehicle_model == model).distinct().all()
        
        # populate the emissions_list with the emissions
        for emission in make_model_record:
            emissions_list.append(emission.emission)
            
            
    return emissions_list


            