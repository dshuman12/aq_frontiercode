# Import inbuilt libraries


# Import third party libraries
from geopy.geocoders import Nominatim



# Include repos folder for custom libraries


# Declare variables used 
# Library code for automated trips library
lib_code_ATL = "54"
lib_ver_ATL = "00"

lib_code_ver_ATL = f"{lib_code_ATL}{lib_ver_ATL}"



# Include custom libraries
import pandas as pd
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs,error_handler
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.auto_trips_schema import *
from storage_settings import rds_instance, prod_rds_instance,rds_instance
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import create_trips_table_class
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from utils.fleets_util import get_fleet_name



# Initialize the logger
logger_1 = LoggerFactory(name="auto_trips_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model




# define other funcs
@error_handler(library_code=lib_code_ATL, function_code="03")
def get_filtered_trips(vehicle_number: str, start_time: str, end_time: str):
    '''
    Function to retrieve trips from the trips table filtered by start_time and end_time.

    Parameters:
        - vehicle_number : str
        - start_time : str (format: YYYY-MM-DD HH:MM:SS)
        - end_time : str (format: YYYY-MM-DD HH:MM:SS)

    Returns:
        - filtered_trips : List of dicts
        - bugs : dict
    '''

    logger_1.info(f"Fetching trips for vehicle {vehicle_number} between {start_time} and {end_time}")

    bugs = {}
  
    filtered_trips = []


    # Start a database session
    session = rds_instance.get_connection()

    # Get the trips table for the specified vehicle
    vehicle_trips_table = create_trips_table_class(vehicle_number)

    # Query trips filtered by start_time and end_time
    trips_query = session.query(vehicle_trips_table).filter(
        vehicle_trips_table.start_time >= start_time,
        vehicle_trips_table.end_time <= end_time
    ).all()
    

    # log the trips query
    logger_1.info(F"Trips queried are {trips_query}")

    # Convert results to a list of dictionaries
    for trip in trips_query:
        trip_dict = {column.name: getattr(trip, column.name) for column in vehicle_trips_table.__table__.columns}
        filtered_trips.append(trip_dict)

    logger_1.info(f"Retrieved {len(filtered_trips)} trips for vehicle {vehicle_number}")

    # Close the session
    session.close()
    
    # pass the filtered trips to update_location_names and return the result
    updated_trips_with_location_names, bugs_local = update_location_names(filtered_trips)

    if bugs_local:
        logger_1.error(f"Error updating location names: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    return updated_trips_with_location_names



# function to get all cateogories for a vehicle
# @error_handler(library_code=lib_code_ATL, function_code="02")
# def get_all_categories_service(vehicle_number: str):
#     '''
#     Function to get all categories for a vehicle

#     Parameters:
#      - vehicle_number : str

#     Returns:
    
#     - all_categories : List
#     - bugs : dict
    
#     '''
    
        
#     # get the fleet name using the vehicle number
#     fleet_name,bugs_local = get_fleet_name(vehicle_number)
    
#     if bugs_local:
#         logger_1.info(f"Unable to fetch fleet name for {vehicle_number}, {bugs_local}")
#         bugs = c_bugs(bugs, bugs_local)
#         bugs = s_bugs(bugs)
#         return None
    
#     elif fleet_name is not None:
    
#         # Define paths for vehicle json and attachments
#         vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_number}/{vehicle_number}.json"

#         vehicle_json, bugs_local = hiperd_lake_bucket.download_json(s3_key=vehicle_json_path)
        
#         if bugs_local:
#             logger_1.error(f"Error downloading vehicle json: {bugs_local}")
#             bugs = c_bugs(bugs, bugs_local)
#             bugs = s_bugs(bugs)
#             return None
        
#         # Extract benchmark blocks from the vehicle json 0 block, benchmark_blocks will be a dict. get all the values and return
#         all_categories = vehicle_json["0"]["benchmark_blocks"].values()
        
#         return all_categories
    
#     else:
#         logger_1.info(f"Unable to fetch fleet name for {vehicle_number}")
#         return None
        
        
# function to update a trip
@error_handler(library_code=lib_code_ATL, function_code="03")
def update_trip_record(vehicle_number : str,trip_id : int, remark : str = None, category : str = None, verified : bool = None):
    '''
    Function to update a trip record in the trips table.

    Parameters:
        - vehicle_number : str
        - trip_id : int
        
    Optional parameters:
        - remark : str
        - category : str
        - verified : bool

    Returns:
        - status : bool
        - bugs : dict
    '''

    bugs = {}
    
    status = False

    # Start a database session
    session = rds_instance.get_connection()

    # Get the trips table
    trips_table = create_trips_table_class(vehicle_number)

    # Query the trip record by trip_id
    trip_record = session.query(trips_table).filter(trips_table.id == trip_id).first()

    # Update the trip record
    if trip_record:
        
        if remark is not None:
            trip_record.remarks = remark
        
        if category is not None:
            trip_record.category = category
            
        if verified is not None:
            trip_record.verified = verified

        # Commit the changes
        session.commit()

        logger_1.info(f"Updated trip record with trip_id {trip_id}")

        status = True
    
    
    else:
        logger_1.error(f"Trip record with trip_id {trip_id} not found")
        bugs = c_bugs(bugs, {"trip_id": "Trip record not found"})

    # Close the session
    session.close()

    return status


@error_handler(library_code=lib_code_ATL, function_code="04")
def update_location_names(trips_data):
    """
    Update the start_location_name and end_location_name fields of trips data using Geopy.
    
    Parameters:
        - trips_data : list of dict
          List of trips containing 'start_location' and 'end_location' as lat,long strings.
    
    Returns:
        - updated_trips : list of dict
          List of trips with location names updated.
    """
    # Initialize the geolocator
    geolocator = Nominatim(user_agent="auto_trips_routes")
    
    for trip in trips_data:
        try:
            # Extract start and end coordinates
            start_coords = tuple(map(float, trip['start_location'].split(','))) if trip['start_location'] else None
            end_coords = tuple(map(float, trip['end_location'].split(','))) if trip['end_location'] else None

            # Update start location name
            if start_coords:
                start_location = geolocator.reverse(start_coords, timeout=10)
                trip['start_location_name'] = start_location.address if start_location else "Unknown Location"
            else:
                trip['start_location_name'] = "Unknown Location"

            # Update end location name
            if end_coords:
                end_location = geolocator.reverse(end_coords, timeout=10)
                trip['end_location_name'] = end_location.address if end_location else "Unknown Location"
            else:
                trip['end_location_name'] = "Unknown Location"

        except Exception as e:
            # Log errors and set default values
            print(f"Error retrieving location for trip ID {trip['id']}: {e}")
            trip['start_location_name'] = "Geocoding Error"
            trip['end_location_name'] = "Geocoding Error"

    return trips_data
