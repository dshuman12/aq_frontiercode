


# Import inbuilt libraries



# Import third party libraries
from typing import Dict, Optional, Tuple
from fastapi.responses import JSONResponse
import pandas as pd



# Include repos folder for custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.benchmark_testing_schema import AddToTest
from storage_settings import redis_instance,rds_instance, get_current_date
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew,DeviceRegistrationNew
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs as c_bugs, serialize_bug_instance as s_bugs
from fastapi import status as http_status

# Declare variables used 

# Library Code for Benchmark Testing Module
lib_code_BTE = "44"
lib_ver_BTE = "00"

lib_code_ver_BTE = f"{lib_code_BTE}{lib_ver_BTE}"


# initialize the logger
logger_1 = LoggerFactory(name="benchmark_testing_utils",file_name="message.log").get_logger()


# Function to get all test rigs after filtering out the test rigs already on test
@error_handler(library_code=lib_code_ver_BTE, function_code="01")
def get_available_test_rigs():
    '''
    Function to fetch all available test rigs from the Vehicle Registration table where the device_id is NULL.

    Returns:
        - Success: list : List of available test rigs
        - Failure: error message with status code 500
    '''
    # Establish the database connection
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Query the Vehicle Registration table for test rigs with vehicle_num like "TEST_RIG_%"
        # and device_id as NULL
        available_test_rigs = (
            ns.query(VehicleRegistrationNew.vehicle_num)
            .filter(VehicleRegistrationNew.vehicle_num.like("TEST_RIG_%"))
            .filter(VehicleRegistrationNew.device_id.is_(None))
            .all()
        )

        # Extract test rig names from query results
        test_rig_names = [rig.vehicle_num for rig in available_test_rigs]

        # Log the available test rigs
        logger_1.info(f"Available test rigs: {test_rig_names}")

        return test_rig_names

    
@error_handler(library_code=lib_code_ver_BTE, function_code="02")
def fetch_devices():
    '''
    Function to fetch all the devices from the device registration table that are not connected to any vehicle.

    returns:
        - Success : list : List of devices not connected to any vehicle
        - Failure : error message with status code 500
    '''
    session = rds_instance.get_connection()

    all_devices = []

    with handle_session(session) as ns:
        # Query to fetch devices not connected to any vehicle
        devices = ns.query(DeviceRegistrationNew.device_id).\
            outerjoin(VehicleRegistrationNew, DeviceRegistrationNew.device_id == VehicleRegistrationNew.device_id).\
            filter(VehicleRegistrationNew.device_id == None).all()

        # append the device_id to the list
        for device in devices:
            all_devices.append(device.device_id)

        return all_devices
    
    
@error_handler(library_code=lib_code_ver_BTE, function_code="03")
def add_to_vehicle_registration(vehicle_number: str, device_id: str) -> JSONResponse:
    """
    Adds or updates a test rig in the Vehicle Registration table.
    When the test rig is registered, a device will be attached, and active status will be set to 1.

    Args:
        vehicle_number (str): ID of the test rig.
        device_id (str): ID of the device.

    Returns:
        JSONResponse: Indicates success or failure.
    """
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        try:
            # Check if the test rig is already registered and in use
            vehicle = ns.query(VehicleRegistrationNew).filter(
                VehicleRegistrationNew.vehicle_num == vehicle_number
            ).first()

            if vehicle and vehicle.device_id:
                return JSONResponse(
                    {"error": "Test Rig is not available"},
                    status_code=http_status.HTTP_400_BAD_REQUEST,
                )

            if vehicle:
                # If the record exists, update it
                vehicle.device_id = device_id
                vehicle.registration_time = get_current_date()
                vehicle.active_status = 0
                ns.commit()
                logger_1.info(f"Updated existing record for vehicle number: {vehicle_number}")
                return JSONResponse(
                    {"message": "Test rig updated successfully."},
                    status_code=http_status.HTTP_200_OK,
                )

            # If the record doesn't exist, create a new one
            vehicle = VehicleRegistrationNew(
                vehicle_num=vehicle_number,
                device_id=device_id,
                registration_time=get_current_date(),
                active_status=0,
            )
            ns.add(vehicle)
            ns.commit()
            logger_1.info(f"Added new record for vehicle number: {vehicle_number}")
            return JSONResponse(
                {"message": "Test rig added successfully."},
                status_code=http_status.HTTP_201_CREATED,
            )

        except Exception as e:
            logger_1.error(f"Error while adding/updating test rig: {e}")
            return JSONResponse(
                {"error": "Failed to add or update test rig."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


@error_handler(library_code=lib_code_ver_BTE, function_code="04")
def get_table_data():
    """
    Function to fetch the table data from the database and return the table data as a pandas DataFrame.

    Returns:
        - Success: pd.DataFrame: DataFrame with columns ['device_id', 'test_rig', 'testing_status']
        - Failure: error message with status code 500
    """
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Fetch test rigs from vehicle_registration with active_status = 1
        table_data = ns.query(VehicleRegistrationNew).filter(
            VehicleRegistrationNew.vehicle_num.like("TEST_RIG_%"),
            VehicleRegistrationNew.device_id.isnot(None),  # Ensure device_id is not null
            VehicleRegistrationNew.active_status == 1  # Only active test rigs
        ).all()

        records = []

        for test_rig in table_data:
            device_id = test_rig.device_id

            # Default testing status if no device is associated
            testing_status = None

            if device_id:
                # Fetch status from DeviceRegistrationNew
                device_record = (
                    ns.query(DeviceRegistrationNew)
                    .filter(DeviceRegistrationNew.device_id == device_id)
                    .first()
                )

                if device_record:
                    testing_status = device_record.QA  # Use the integer value directly

                    logger_1.info(
                        f"Device {device_id} associated with test rig {test_rig.vehicle_num} "
                        f"has testing status {testing_status}"
                    )

            # Append the test rig data
            records.append({
                "device_id": device_id,
                "test_rig": test_rig.vehicle_num,
                "testing_status": testing_status,
            })

        # Convert the records list to a pandas DataFrame
        df = pd.DataFrame(records, columns=["device_id", "test_rig", "testing_status"])

        return df



@error_handler(library_code=lib_code_ver_BTE, function_code="05")
def update_device_qa_status(device_id: str, qa_status: int) -> JSONResponse:
    """
    Updates the QA field of a device in the Device Registration table.

    Args:
        device_id (str): The ID of the device to update.
        qa_status (int): The new QA status to set (e.g., 0 for testing).

    Returns:
        JSONResponse: Indicates success or failure.
    """
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        try:
            # Fetch the device record
            device_record = ns.query(DeviceRegistrationNew).filter(
                DeviceRegistrationNew.device_id == device_id
            ).first()

            if not device_record:
                logger_1.error(f"Device with ID {device_id} not found in Device Registration table.")
                return JSONResponse(
                    {"error": f"Device with ID {device_id} not found."},
                    status_code=http_status.HTTP_404_NOT_FOUND,
                )

            # Update the QA status
            device_record.QA = qa_status
            ns.commit()

            logger_1.info(f"Updated QA status of device {device_id} to {qa_status}.")
            return JSONResponse(
                {"message": f"QA status updated for device {device_id}."},
                status_code=http_status.HTTP_200_OK,
            )

        except Exception as e:
            logger_1.error(f"Error while updating QA status: {e}")
            return JSONResponse(
                {"error": "Failed to update QA status."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
        
    


def release_test_rig_service(test_rig: str) -> JSONResponse:
    """
    Service function to release a test rig.

    Params:
        - test_rig (str): The name of the test rig to be released.

    Returns:
        - JSONResponse: Response with the status of the operation.
    """
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        
        try:
            
            # Fetch the test rig's associated device_id
            vehicle_record = (
                ns.query(VehicleRegistrationNew)
                .filter(VehicleRegistrationNew.vehicle_num == test_rig)
                .first()
            )

            if not vehicle_record or not vehicle_record.device_id:
                return JSONResponse(
                    {"error": f"Test rig '{test_rig}' is not associated with any device."},
                    status_code=http_status.HTTP_400_BAD_REQUEST,
                )

            device_id = vehicle_record.device_id

            # Fetch the device status from the device_registration table
            device_record = (
                ns.query(DeviceRegistrationNew)
                .filter(DeviceRegistrationNew.device_id == device_id)
                .first()
            )

            if not device_record:
                return JSONResponse(
                    {"error": f"Device '{device_id}' not found in the database."},
                    status_code=http_status.HTTP_400_BAD_REQUEST,
                )

            # if device_record.QA not in [3, 4]:
            #     return JSONResponse(
            #         {"error": f"Test rig '{test_rig}' cannot be released. Device status is still undergoing test."},
            #         status_code=http_status.HTTP_400_BAD_REQUEST,
            #     )

            # Update the test rig to release it
            vehicle_record.device_id = None
            ns.commit()

            logger_1.info(f"Test rig '{test_rig}' released successfully.")
            return JSONResponse(
                {"message": f"Test rig '{test_rig}' released successfully."},
                status_code=http_status.HTTP_200_OK,
            )
            
        except Exception as e:
            logger_1.error(f"Error while releasing test rig: {e}")
            return JSONResponse(
                {"error": "Unknown error occurred."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


@error_handler(library_code=lib_code_ver_BTE, function_code="07")
def get_devices_with_qa_status() -> tuple:
    """
    Fetches devices with a QA status that is not None.

    Returns:
        tuple: A DataFrame containing device_id and QA status, and bugs if any.
    """
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        try:
            
            # Fetch devices with QA as 2 or 3
            devices = ns.query(DeviceRegistrationNew.device_id, DeviceRegistrationNew.QA).filter(
                DeviceRegistrationNew.QA.in_([2, 3])  # Check for QA values 2 or 3
            ).all()
            
            # Create a DataFrame for the result
            records = [{"device_id": device_id, "qa_status": qa_status} for device_id, qa_status in devices]
            df = pd.DataFrame(records, columns=["device_id", "qa_status"])

            logger_1.info(f"Fetched devices with QA status: {len(df)} records found.")
            return df

        except Exception as e:
            logger_1.error(f"Error while fetching devices with QA status: {e}")
            return None

def update_active_status(test_rig_id : str, device_id : str,status : int):
    
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
    
        # Fetch the test rig record
        test_rig_record = ns.query(VehicleRegistrationNew).filter(
            VehicleRegistrationNew.vehicle_num == test_rig_id, VehicleRegistrationNew.device_id == device_id
        ).first()

        # Update the QA status
        test_rig_record.active_status = status
        ns.commit()
