# Import inbuilt libraries
import os
import json
from datetime import timedelta,datetime
import pickle

import shutil
import tempfile
import requests


# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
from twilio.rest import Client
from dotenv import load_dotenv
from geopy.geocoders import Nominatim
from scipy.interpolate import interp1d
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Include repos folder for custom libraries



# Declare variables used 

load_dotenv()




# Library Code for Customer comms Automation Module
lib_code_C_COM = "79"
lib_ver_C_COM = "00"

lib_code_ver_C_COM = f"{lib_code_C_COM}{lib_ver_C_COM}"

# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import prod_rds_instance,rds_instance,hiperd_lake_bucket
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import create_event_table_class
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew as VR_RDS, Fleet as FL_RDS
from hiper_utils.data_models.rds_data_models.users_rds_models import CustomerList as CL_RDS, Employee as EL_RDS
from hiper_utils.other_utils.resource_util import CRUDBase, S3ResourceBase    



# initialize the logger
logger_1 = LoggerFactory(name="customer_comms_utils", file_name="message.log").get_logger()

customer_json_pth = "users/fleet_customers/customer_id/customer_id.json"
auto_alerts = os.getenv("auto_alert")
customer_comms_channel = os.getenv("customer_comms_channel")
fuel_calib_model = "vehicle_data/fleet_name/vehicle_number/fuel_calibration_model.pkl"

# Define Helper class used with the pydantic model


@error_handler(library_code=lib_code_C_COM, function_code="01")
def get_trip_metrics(vehicle_number: str, date: str, bugs={}):
    '''
    Fetches trip metrics (distance, fuel consumed, etc.) for a vehicle for a given date in IST.
    Also extracts unique DTC codes from event type 2.

    Parameters:
        - vehicle_number: str
        - date: str (YYYY-MM-DD, in IST)

    Returns:
        - trip_metrics: dict or None
        - bugs: dict
    '''

    # Initialize geolocator
    geolocator = Nominatim(user_agent="vehicle_trip_metrics")

    def resolve_location(lat, lon):
        try:
            location = geolocator.reverse((lat, lon), timeout=10)
            return location.address if location else "Unknown Location"
        except Exception as e:
            logger_1.error(f"Error resolving location for coordinates ({lat}, {lon}): {e}")
            return "Unknown Location"

    # Convert IST date to UTC range
    ist_end = datetime.strptime(date, "%Y-%m-%d").replace(hour=12, minute=0, second=0, microsecond=0)
    ist_start = ist_end - timedelta(days=1)
    utc_start = ist_start - timedelta(hours=5, minutes=30)
    utc_end = ist_end - timedelta(hours=5, minutes=30)

    session = prod_rds_instance.get_connection()
    vehicle_event_table = create_event_table_class(vehicle_number)

    events_table = session.query(vehicle_event_table).filter(
        vehicle_event_table.server_time.between(utc_start, utc_end)
    ).all()

    if not events_table:
        logger_1.info(f"No events found for vehicle {vehicle_number} in the specified UTC range.")
        return None

    events_table_dict = {
        event.id: {key: value for key, value in event.__dict__.items() if key != '_sa_instance_state'}
        for event in events_table
    }
    events_table_df = pd.DataFrame.from_dict(events_table_dict, orient="index")

    if events_table_df.empty:
        logger_1.info(f"No events found after filtering for vehicle {vehicle_number}.")
        return None

    logger_1.info(f"Processing {len(events_table_df)} events for vehicle {vehicle_number}.")
    
    # Sort events based on server_time
    events_table_df = events_table_df.sort_values(by="server_time")

    logger_1.info(f"Processing events df after sorting {len(events_table_df)}")

    # Filter out rows without latitude and longitude
    valid_gps_events = events_table_df.dropna(subset=["latitude", "longitude"])

    # **Handling GPS Initialization Delay** - Skip (0,0) coordinates
    for index, row in valid_gps_events.iterrows():
        if row["latitude"] != 0.0 or row["longitude"] != 0.0:
            start_coordinates = (row["latitude"], row["longitude"])
            break
    else:
        start_coordinates = (None, None)

    end_coordinates = (valid_gps_events.iloc[-1]["latitude"], valid_gps_events.iloc[-1]["longitude"]) if not valid_gps_events.empty else (None, None)

    # Compute total distance using Haversine formula
    total_distance = sum(
        haversine(valid_gps_events.iloc[i]["latitude"], valid_gps_events.iloc[i]["longitude"],
                valid_gps_events.iloc[i + 1]["latitude"], valid_gps_events.iloc[i + 1]["longitude"])
        for i in range(len(valid_gps_events) - 1)
    )

    # Fuel Calculation
    total_fuel = 0
    filtered_fuel_events = events_table_df[events_table_df["event_type"] == 25]
    for _, event in filtered_fuel_events.iterrows():
        try:
            data_values = str(event["data"]).split(',')
            if data_values:
                total_fuel += float(data_values[0])
        except ValueError as e:
            logger_1.error(f"Error processing fuel for event {event['id']}: {e}")
            return None
            
    # Engine Idle Running Time Calculation
    total_idle_time = 0
    filtered_idle_events = events_table_df[events_table_df["event_type"] == 24]

    for _, event in filtered_idle_events.iterrows():
        data_values = str(event["data"]).split(',')
        if data_values:
            total_idle_time += float(data_values[0])  # Extract first value and sum

    logger_1.info(f"First valid event record is {valid_gps_events.iloc[0]['id']}")

    logger_1.info(f"Start coordinates after handling GPS delay: {start_coordinates}")
    
    start_location = resolve_location(*start_coordinates) if start_coordinates != (None, None) else "Unknown Location"
    end_location = resolve_location(*end_coordinates) if end_coordinates != (None, None) else "Unknown Location"
    
    # Calculate mileage
    mileage = total_distance / total_fuel if total_fuel > 0 else 0
    
    # Format trip period in IST
    ist_start = ist_start.strftime("%d-%B-%Y %I:%M %p")
    ist_end = ist_end.strftime("%d-%B-%Y %I:%M %p")
    
    # Format JSON Output
    trip_metrics = {
        "vehicle_number": vehicle_number,
        "trip_period": f"{ist_start} to {ist_end}",
        "distance": f"{total_distance:.2f}",
        "fuel_consumed": f"{total_fuel:.2f}",
        "mileage": f"{mileage:.2f}",
        "start_location": start_location,
        "end_location": end_location,
        "average_speed": "0",
        "engine_idle_running": f"{total_idle_time:.2f}",  # Add idle time in minutes
    }

    return trip_metrics



# Twilio function for sending messages
def send_whatsapp_twilio(message_body, whatsapp_number, template_sid):
    account_sid = os.getenv('TWILIO_ACCOUNT_SID', 'your_account_sid')
    auth_token = os.getenv('TWILIO_AUTH_TOKEN', 'your_auth_token')
    company_number = os.getenv('COMPANY_WHATSAPP_NUMBER')
    
    # logger_1.info(f"account sid is {account_sid} and auth token is {auth_token} and company number is {company_number}")
    
    # logger_1.info(f"Sending message to {whatsapp_number} with body: {message_body}")

    client = Client(account_sid, auth_token)
    
    # log the message body after converting it to json
    logger_1.info(f"message body is {json.dumps(message_body)}")
    

    message = client.messages.create(
        content_sid=template_sid,
        from_=f'whatsapp:{company_number}',
        to=f'whatsapp:{whatsapp_number}',
        content_variables=json.dumps(message_body),
        messaging_service_sid="MG1260fd41558bedd909f13b4a602fce98"
    )

    if message.status in ["queued", "sent", "accepted"]:
        print(f"Message sent successfully. Status: {message.status} and SID: {message.sid}")
    else:
        print(f"Failed to send message. Status: {message.status}")

    return message.sid




# Fumction to retrieve the phone nummbers of the hiper employees relatedd to the vehicle
@error_handler(library_code=lib_code_C_COM, function_code="02")
def get_employee_phone_numbers_by_vehicle_number(vehicle_number : str):
    """
    Fetches phone numbers of customers associated with the vehicle's fleet.

    Parameters:
        - vehicle_number: str - The registration number of the vehicle.

    Returns:
        - list[str]: List of customer phone numbers associated with the fleet.
    """
    
    phone_numbers = []

    session = rds_instance.get_connection()  
    
    logger_1.info(f"vehicle number is {vehicle_number}")

    with handle_session(session) as ns:
        
        # join the vehicle registration table with the customer list table and append the phone numbers to the list
        fleet_id = ns.query(VR_RDS).filter(VR_RDS.vehicle_num == vehicle_number).first().fleet_id
        
        #logger_1.info(f"fleet id is {fleet_id}")
        
        # get all employee phone numbers associated with the fleet
        employee_numbers = ns.query(EL_RDS).filter(EL_RDS.fleet_id == fleet_id).all()
        
        for number in employee_numbers:
            phone_numbers.append(number.phone_number)        
    
    return phone_numbers
        
        
    


def parse_dtcs(dtc_string: str) -> pd.DataFrame:
    """
    Parses a single hex string containing:
      - A leading '01' to indicate DTCs found by the application.
      - '58' (0x58) as the response service from the ECU.
      - A hex byte that tells how many DTC entries follow.
      - Then 'n' DTC entries, each 6 hex chars (3 bytes).
    
    Returns a DataFrame with columns:
      - 'DTC': The decoded DTC code (e.g. "P1206")
      - 'Active': 1 if the DTC is active, 0 if inactive.
    """

    # 1) Clean up input (remove spaces, make uppercase for consistency).
    dtc_string = dtc_string.replace(" ", "").upper()

    # 2) Basic sanity check for "01" prefix that indicates "DTC found".
    if not dtc_string.startswith("01"):
        raise ValueError("String does not start with '01' (DTC found). "
                         "Check if you have the right input format.")

    # 3) Next two bytes after '01' should be '58' (response SID).
    #    dtc_string[2:4] = '58' (optionally you could check if it is '58').

    # 4) The byte after that indicates how many DTCs we have (dtc_count).
    #    This should be at dtc_string[4:6].
    dtc_count_hex = dtc_string[4:6]
    dtc_count = int(dtc_count_hex, 16)

    # 5) Define a helper to decode one 3-byte (6-hex-char) DTC slice.
    def decode_dtc(dtc_hex: str):
        """
        Given a 6-hex-char DTC string (e.g. '120626'),
        returns (dtc_code, active_flag), for example ('P1206', 0).
        """
        # First byte (two hex chars): used for 'active' bit and the code nibble.
        first_byte = int(dtc_hex[0:2], 16)
        # Check if active (bit 7 set?)
        active = 1 if ((first_byte & 0x80) != 0) else 0

        # Determine P-code prefix from bits 4..5 (0x30).
        # Example: 0x12 => (0x12 & 0x30) = 0x10 => >> 4 = 1 => "P1"
        p_first = str((first_byte & 0x30) >> 4)[-1]  # keep only last digit
        # Low nibble => next digit in the code
        # Example: 0x12 => (0x12 & 0x0F) = 0x02 => hex(2) => '0x2' => strip '0x'
        p_second = hex(first_byte & 0x0F)[2:].upper()

        # Next 2 hex chars => dtc_hex[2:4]
        # If dtc_hex = "120626", dtc_hex[2:4] = "06"
        dtc_fourth_part = dtc_hex[2:4]  # "06" in this example

        # Construct final code: e.g. "P1206"
        dtc_code = f"P{p_first}{p_second}{dtc_fourth_part}"
        return dtc_code, active

    # 6) Extract all DTC slices after the "01 58 xx" portion.
    #    We have: 2 bytes for '01' + 2 bytes for '58' + 2 bytes for dtc_count = 6 hex chars total used.
    #    The actual DTC data starts at dtc_string[6: ].
    dtc_data_start = 6
    dtc_hex_len = 6  # each DTC is 3 bytes = 6 hex chars

    dtc_list = []
    for i in range(dtc_count):
        start = dtc_data_start + i * dtc_hex_len
        end = start + dtc_hex_len
        dtc_slice = dtc_string[start:end]
        if len(dtc_slice) < dtc_hex_len:
            # Not enough data for a full DTC entry
            break
        dtc_code, active_flag = decode_dtc(dtc_slice)
        dtc_list.append((dtc_code, active_flag))

    # 7) Build a DataFrame of all DTCs.
    df = pd.DataFrame(dtc_list, columns=["DTC", "Active"])
    return df


def get_desc_to_p_codes(dtc_codes: list[dict]) -> list[dict]:
    """
    Fetches the description and severity of the provided P-codes from a Parquet file.

    Parameters:
        - dtc_codes: List of dictionaries with "DTC" and "Active".

    Returns:
        - List of dictionaries with "Description" and "Severity" added.
    """

    # S3 Parquet Path
    dtc_parquet_path = "make model/dtc_pcodes_BS4.parquet"

    # Download Parquet file from S3
    dtc_file, bugs_local = hiperd_lake_bucket.download_parquet(dtc_parquet_path)

    if bugs_local:
        logger_1.error(f"Error downloading DTC Parquet file from S3: {bugs_local}")
        return dtc_codes

    # Ensure dtc_file is a DataFrame
    if not isinstance(dtc_file, pd.DataFrame) or dtc_file.empty:
        logger_1.error("DTC Parquet file is empty or could not be loaded from S3.")
        return dtc_codes

    logger_1.info("Loaded DTC Parquet file from S3.")

    # Convert DTC descriptions and severity into dictionaries for fast lookup
    dtc_lookup = dict(zip(dtc_file["P codes"], dtc_file["Description"]))
    severity_lookup = dict(zip(dtc_file["P codes"], dtc_file["Severity"]))

    # Add descriptions and severity to DTC codes (NO MAPPING APPLIED)
    for dtc in dtc_codes:
        dtc_code = dtc["DTC"]
        dtc["Description"] = dtc_lookup.get(dtc_code, "Unknown DTC Code")
        dtc["Severity"] = severity_lookup.get(dtc_code, "Unknown")  # Keeping original severity

    logger_1.info(f"DTC codes with descriptions and severity added: {dtc_codes}")

    return dtc_codes






# function to send dtc alerts
@error_handler(library_code=lib_code_C_COM, function_code="03")
def send_dtc_alerts(vehicle_list= None, force_full_scan = False,  bugs={}):
    """
    Sends DTC alerts to customers associated with the vehicle's fleet.

    Returns:
        - bool: True if all messages are sent successfully, False otherwise.
    """

    crud_instance = CRUDBase(db_instance=rds_instance, model=VR_RDS)
    
    # Determine whether to process all vehicles or only specific ones
    if force_full_scan or vehicle_list is None:
        all_vehicle_numbers, bugs_local = crud_instance.read(columns=["vehicle_num"])
        
        if bugs_local:
            logger_1.error(f"Failed to fetch all vehicles: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            return False
        
        if all_vehicle_numbers is None:
            return False

        vehicles_df = all_vehicle_numbers[~all_vehicle_numbers["vehicle_num"].str.startswith("TEST_RIG")]
    else:
        vehicles_df = pd.DataFrame(vehicle_list, columns=["vehicle_num"])  # Convert list to DataFrame

    # If no vehicles need processing, exit early
    if vehicles_df.empty:
        logger_1.info("No vehicles to process. Exiting function.")
        return False

    overall_success = True  

    for vehicle in vehicles_df["vehicle_num"]:
        logger_1.info(f"Processing vehicle: {vehicle}")

        date_today = datetime.now().strftime("%Y-%m-%d")
        formatted_date = datetime.strptime(date_today, "%Y-%m-%d").strftime("%d-%B-%Y")

        ist_end = datetime.strptime(date_today, "%Y-%m-%d").replace(hour=12, minute=0, second=0, microsecond=0)
        utc_start = ist_end - timedelta(days=1, hours=5, minutes=30)
        utc_end = ist_end - timedelta(hours=5, minutes=30)

        #logger_1.info(f"Querying for UTC range: {utc_start} to {utc_end} (User input: {date_today} IST)")

        session = prod_rds_instance.get_connection()
        vehicle_event_table = create_event_table_class(vehicle)

        events_table = session.query(vehicle_event_table).filter(
            vehicle_event_table.server_time.between(utc_start, utc_end)
        ).all()

        if not events_table:
            logger_1.info(f"No events found for vehicle {vehicle}.")
            continue  

        events_table_df = pd.DataFrame([
            {key: value for key, value in event.__dict__.items() if key != '_sa_instance_state'}
            for event in events_table
        ])

        if events_table_df.empty:
            logger_1.info(f"No events found after filtering for vehicle {vehicle}.")
            continue  

        #logger_1.info(f"Processing {len(events_table_df)} events for vehicle {vehicle}.")

        filtered_dtc_events = events_table_df[events_table_df["event_type"] == 2].drop_duplicates(subset=["data"])
        #logger_1.info(f"Filtered DTC events: {filtered_dtc_events}")

        dtc_codes_list = []
        for _, event in filtered_dtc_events.iterrows():
            dtc_data = str(event["data"]).strip()
            dtc_df = parse_dtcs(dtc_data)  
            dtc_codes_list.extend(dtc_df.to_dict(orient="records"))

        #logger_1.info(f"DTC codes list: {dtc_codes_list}")

        if not dtc_codes_list:
            continue  
        
        # dtc codes under this list should be exempted
        dtc_codes_to_exempt = ["P0501", "P0504", "P1533", "P1636", "P1637", "P1638"]
        
        dtc_codes_list = [dtc for dtc in dtc_codes_list if dtc["DTC"] not in dtc_codes_to_exempt]

        dtc_codes_list = get_desc_to_p_codes(dtc_codes_list)
        df_with_description = pd.DataFrame(dtc_codes_list)

        severity_mapping = {
            "very low": "Minor Issue (No Immediate Action Needed)",
            "low": "Warning (Check at Convenience)",
            "high": "Urgent Attention Required",
            "very high": "Critical Issue (Immediate Action Required!)"
        }
        
        # group each dtc code by severity
        df_with_description["Severity"] = df_with_description["Severity"].map(severity_mapping)
        df_with_description["Status"] = df_with_description["Active"].map({0: "Inactive", 1: "Active"})

        grouped_dtc = df_with_description.groupby("Severity")

        structured_data = []
        for severity, group in grouped_dtc:
            structured_data.append({"DTC": f"Severity: {severity}", "Description": "", "Status": ""})
            structured_data.extend(group.drop(columns=["Severity", "Active"]).to_dict(orient="records"))

        df_structured_dtc = pd.DataFrame(structured_data)
        #logger_1.info(f"Structured DTC data: {df_structured_dtc}")

        image_path = generate_dtc_table_image(df_structured_dtc)
        image_name = f"{vehicle}_{datetime.now()}.png"
        image_path_to_push = f"vehicle_data/dtc_alerts/{image_name}"

        #logger_1.info(f"Image path: {image_path_to_push}")

        image_url = hiperd_lake_bucket.upload_file_to_s3_and_get_presigned_url(
            image_path, image_path_to_push, expiration=604800
        )

        #logger_1.info(f"Image uploaded to S3: {image_url}")
        
        phone_numbers = []

        emp_phone_numbers, bugs_local = get_employee_phone_numbers_by_vehicle_number(vehicle)

        if bugs_local:
            logger_1.error(f"Failed to fetch customers related to the vehicle: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            print(f"Failed to fetch employees related to the vehicle")
            return False

        # logger_1.info(f"Phone numbers fetched for vehicle {vehicle}: {phone_numbers}")
                
        phone_numbers.extend(emp_phone_numbers)
        
        # customer_phone_numbers, bugs_local = get_customer_phone_numbers_by_vehicle_number(vehicle)
        
        # if bugs_local:
        #     logger_1.error(f"Failed to fetch customers related to the vehicle: {bugs_local}")
        #     bugs = c_bugs(bugs, bugs_local)
        #     bugs = s_bugs(bugs)
        #     print(f"Failed to fetch customers related to the vehicle")
        #     return False

        # logger_1.info(f"Phone numbers fetched for vehicle {vehicle}: {phone_numbers}")
        
        # phone_numbers.extend(customer_phone_numbers)

        template_sid = "HX2d4f31594c07ec105258b443396817e5"
        stripped_url = image_url.split("https://hiperdatalake.s3.amazonaws.com/")[1]

        message_body = {
            "1": formatted_date,
            "2": vehicle,
            "3": stripped_url 
        }
        
        
        # Prepare Slack message blocks
        slack_message = [
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": f"*Vehicle Alerts for {vehicle}*"}
                },
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": f"*Date:* {datetime.now().strftime('%d-%B-%Y')}"}
                },
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": "*Current Active and Inactive DTCs:*"}
                }
            ]

        # Only add an image block if there is an image URL
        if image_url:
            slack_message.append(
                {
                    "type": "image",
                    "image_url": image_url,
                    "alt_text": "DTC Alert Image"
                }
            )
             
        # sent the messaage to the slack channel first
        # slack_send_status = send_slack_alert(slack_message,auto_alert_webhook)
        
        # if not slack_send_status:
        #     logger_1.error(f"Failed to send the messsge for {vehicle} to slack channel ")
            
            
        vehicle_success = True
        
        if phone_numbers != []:
            
            for phone_number in phone_numbers:
                try:
                    logger_1.info(f"Sending message to {phone_number} for vehicle {vehicle}...")
                    
                    message_sid = send_whatsapp_twilio(message_body, phone_number, template_sid)
                    logger_1.info(f"Message sent to {phone_number} for vehicle {vehicle}, SID: {message_sid}")
                        
                except Exception as e:
                    logger_1.error(f"Error sending message to {phone_number}: {e}")
                    vehicle_success = False

            if not vehicle_success:
                overall_success = False
        
    print(f"Send dtc alerts completed {'Successfully' if overall_success else 'failed'}")        
    return overall_success  



def generate_dtc_table_image(df):
    """
    Generates a tabular image from a DataFrame and saves it as a temporary file.
    Adds the current date and time as a title on top of the image.
    Formats the "Severity" row to be bold.

    Parameters:
        - df (DataFrame): The DataFrame containing DTC codes and descriptions.

    Returns:
        - str: Path to the temporary image file.
    """

    fig, ax = plt.subplots(figsize=(8, 4))  # Increased height for title space
    ax.axis('tight')
    ax.axis('off')

    # 🔹 Get current date and time in a readable format
    current_datetime = datetime.now().strftime("%d-%B-%Y %H:%M:%S")

    # 🔹 Add the title with Date & Time
    plt.title(f"Health Alerts - {current_datetime}", fontsize=12, fontweight="bold", pad=15)

    # 🔹 Prepare table data
    table_data = []
    severity_rows = []

    for index, row in df.iterrows():
        if row["DTC"].startswith("Severity:"):  
            # Store index of severity row for bold formatting
            severity_rows.append(len(table_data))
        table_data.append(row.tolist())

    # 🔹 Convert back to DataFrame for display
    table_df = pd.DataFrame(table_data, columns=df.columns)

    # 🔹 Generate the table
    table = ax.table(cellText=table_df.values, colLabels=df.columns, cellLoc='left', loc='center')

    # 🔹 Set font size and adjust column width
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.auto_set_column_width([0, 1, 2])

    # 🔹 Make Severity Row Bold
    for row_idx in severity_rows:
        for col_idx in range(len(df.columns)):  # Apply bold to all columns in that row
            table[(row_idx + 1, col_idx)].set_text_props(fontweight='bold')

    # 🔹 Save the image
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
    temp_path = temp_file.name

    plt.savefig(temp_path, format='png', bbox_inches='tight', dpi=300)
    plt.close()

    return temp_path


# function to send trip metrics alerts except dtc alerts to the customers
@error_handler(library_code=lib_code_C_COM, function_code="04")
def send_trip_metrics_util(bugs = {}):
    
    '''
    
    Sends trip metrics alerts to customers associated with the vehicle's fleet.
    
    Returns:
        - bool: True if all messages are sent successfully, False otherwise.
    
    
    '''
    
    crud_instance = CRUDBase(db_instance=rds_instance, model=VR_RDS)
    all_vehicle_numbers, bugs_local = crud_instance.read(columns=["vehicle_num"])
    
    if bugs_local:
        logger_1.error(f"Failed to fetch all vehicles: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return False
    
    elif all_vehicle_numbers is None:
        logger_1.error(f"No vehicles found in the database")
        return False
    
    vehicles_df = all_vehicle_numbers[~all_vehicle_numbers["vehicle_num"].str.startswith("TEST_RIG")]
    
    overall_success = True
    
    for vehicle in vehicles_df["vehicle_num"]:
        logger_1.info(f"Processing vehicle: {vehicle}")
        
        date_today = datetime.now().strftime("%Y-%m-%d")
        
        trip_metrics, bugs_local = get_trip_metrics(vehicle, date_today)
        
        
        if bugs_local:
            logger_1.error(f"Failed to fetch trip metrics for vehicle {vehicle}: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            continue
        
        
        if trip_metrics is None:
            logger_1.info(f"No trip metrics found for vehicle {vehicle}.")
            continue
        
        logger_1.info(f"Trip metrics found for vehicle {vehicle}: {trip_metrics}")
        
    
        phone_numbers, bugs_local = get_employee_phone_numbers_by_vehicle_number(vehicle)
        
        if bugs_local:
            logger_1.error(f"Failed to fetch customers related to the vehicle: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            continue
        
        logger_1.info(f"Phone numbers fetched for vehicle {vehicle}: {phone_numbers}")
        
        template_sid = "HX659fcbf977313b9113878b51ac9c4a07"
        
        message_body = {
            "1": trip_metrics.get("vehicle_number"),
            "2": trip_metrics.get("trip_period"),
            "3": trip_metrics.get("start_location"),
            "4": trip_metrics.get("end_location"),
            "5": trip_metrics.get("distance"),
            "6": trip_metrics.get("fuel_consumed"),
            "7": trip_metrics.get("mileage"),
            "8": trip_metrics.get("average_speed"),
            "9": trip_metrics.get("engine_idle_running")
        }
        
        
        # Prepare Slack message blocks
        slack_message = [
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Trip Metrics for {vehicle}*"}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Date:* {trip_metrics.get('trip_period')}"}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "*Trip Metrics Summary:*"}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": 
                    f"- *Start Location:* {trip_metrics.get('start_location')}\n"
                    f"- *End Location:* {trip_metrics.get('end_location')}\n"
                    f"- *Distance:* {trip_metrics.get('distance')} km\n"
                    f"- *Fuel Consumed:* {trip_metrics.get('fuel_consumed')} L\n"
                    f"- *Mileage:* {trip_metrics.get('mileage')} km/L\n"
                    f"- *Avg Speed:* {trip_metrics.get('average_speed')} km/h\n"
                    f"- *Idle Running:* {trip_metrics.get('engine_idle_running')} min"
                }
            }
        ]

        # Send Slack alert
        slack_send_status = send_slack_alert(slack_message,customer_comms_channel)

        if not slack_send_status:
            logger_1.error(f"Failed to send Slack message for {vehicle}")
        
        
        vehicle_success = True
        
        for phone_number in phone_numbers:
            try:
                logger_1.info(f"Sending message to {phone_number} for vehicle {vehicle}...")
                message_sid = send_whatsapp_twilio(message_body, phone_number, template_sid)
                logger_1.info(f"Message sent to {phone_number} for vehicle {vehicle}, SID: {message_sid}")
            except Exception as e:
                logger_1.error(f"Error sending message to {phone_number}: {e}")
                vehicle_success = False
                
        if not vehicle_success:
            overall_success = False
            
    return overall_success


# function to check what dtc's are present in the vehicle prior 24 hrs, if there's a change in the dtc's then add it to the list
@error_handler(library_code=lib_code_C_COM, function_code="05")
def check_if_dtc_changed():
    """
    Checks if there is a difference in the most recent DTC event data string
    in the last 24 hours compared to the previous 24-hour period. If the 
    current DTC event exists and differs from the previous one, the vehicle 
    is added to the alert list.

    Returns:
        - List of vehicle numbers that need alerts.
    """

    vehicle_list = []
    crud_instance = CRUDBase(db_instance=prod_rds_instance, model=VR_RDS)

    # Fetch all active vehicles excluding TEST_RIG and process-prefixed vehicles
    all_vehicle_numbers, bugs_local = crud_instance.read(columns=["vehicle_num"])

    if bugs_local:
        logger_1.error(f"Failed to fetch vehicle list: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return []

    if all_vehicle_numbers is None:
        return []

    vehicles_df = all_vehicle_numbers[
        ~all_vehicle_numbers["vehicle_num"].str.startswith("TEST_RIG") & 
        ~all_vehicle_numbers["vehicle_num"].str.contains("process", case=False, na=False)
    ]

    # Get the current date and define time ranges
    ist_now = datetime.now().replace(hour=12, minute=0, second=0, microsecond=0)  # Today's 12 PM
    utc_now = ist_now - timedelta(hours=5, minutes=30)  # Convert IST to UTC

    t_1_day_ago = utc_now - timedelta(days=1)  # 1 day ago in UTC
    t_2_days_ago = utc_now - timedelta(days=2)  # 2 days ago in UTC


    for vehicle in vehicles_df["vehicle_num"]:
        logger_1.info(f"Checking DTC changes for vehicle: {vehicle}")

        session = prod_rds_instance.get_connection()
        vehicle_event_table = create_event_table_class(vehicle)

        # Fetch the latest DTC event (sorted by server_time desc) where data starts with '01'
        previous_dtc_event = session.query(vehicle_event_table).filter(
            vehicle_event_table.server_time.between(t_2_days_ago, t_1_day_ago),
            vehicle_event_table.event_type == 2,
            vehicle_event_table.data.like("01%")
        ).order_by(vehicle_event_table.server_time.desc()).first()

        current_dtc_event = session.query(vehicle_event_table).filter(
            vehicle_event_table.server_time.between(t_1_day_ago, utc_now),
            vehicle_event_table.event_type == 2,
            vehicle_event_table.data.like("01%")
        ).order_by(vehicle_event_table.server_time.desc()).first()

        # Handle None cases safely
        previous_dtc_data = previous_dtc_event.data.strip() if previous_dtc_event else None
        current_dtc_data = current_dtc_event.data.strip() if current_dtc_event else None

        logger_1.info(f"Previous DTC event for {vehicle}: {previous_dtc_data}")
        logger_1.info(f"Current DTC event for {vehicle}: {current_dtc_data}")

        # **Comparison Logic**:
        if previous_dtc_data and not current_dtc_data:
            # Case 1: Previous DTC event exists, but current DTC is None → Do nothing
            logger_1.info(f"Skipping {vehicle}, as current DTC event is missing.")
            continue

        if current_dtc_data and (previous_dtc_data is None or previous_dtc_data != current_dtc_data):
            # Case 2: Current DTC event exists and is **different** from the previous → Add vehicle
            logger_1.info(f"DTC event changed for vehicle: {vehicle}")
            vehicle_list.append(vehicle)

    logger_1.info(f"Vehicles with changed DTCs: {vehicle_list}")
    return vehicle_list



    

def send_slack_alert(message_blocks, slack_webhook_url):
    """
    Sends a formatted alert to the Slack channel using Incoming Webhook.

    Parameters:
        - message_blocks (list): List of formatted Slack blocks (structured message content)
    """
    payload = {"blocks": message_blocks}
    headers = {"Content-Type": "application/json"}

    response = requests.post(slack_webhook_url, json=payload, headers=headers)

    if response.status_code == 200:
        logger_1.info("Successfully sent Slack alert.")
        return True
    else:
        logger_1.error(f"Failed to send Slack alert: {response.text}")
        return False
    
    
# function to retrieve the phone numbers of the customers related to the vehicle
@error_handler(library_code=lib_code_C_COM, function_code="07")
def get_customer_phone_numbers_by_vehicle_number(vehicle_number: str):
    """
    Fetches phone numbers of customers associated with the vehicle's fleet.

    Parameters:
        - vehicle_number: str - The registration number of the vehicle.

    Returns:
        - list[str]: List of customer phone numbers associated with the fleet.
    """
    
    phone_numbers = []

    session = rds_instance.get_connection()  
    
    logger_1.info(f"vehicle number is {vehicle_number}")

    with handle_session(session) as ns:
        
        # join the vehicle registration table with the customer list table and append the phone numbers to the list
        fleet_id = ns.query(VR_RDS).filter(VR_RDS.vehicle_num == vehicle_number).first().fleet_id
        
        #logger_1.info(f"fleet id is {fleet_id}")
        
        # get all customer phone numbers associated with the fleet
        customer_numbers = ns.query(CL_RDS).filter(CL_RDS.fleet_id == fleet_id).all()
        
        ''''
        each of the customer will have a JSON named as customer_id.json 
        
        this json will have vehicle blocks where key would the vehicle number and value would be the block id 
        
        add the phone number only if the vehicle number is present in the vehicle block as the key
        
        '''
        for number in customer_numbers:
            
            # get the customer json
            customer_json_path = customer_json_pth.replace("customer_id", str(number.id).zfill(5))
            
            #logger_1.info(f"customer json path is {customer_json_path}")
        
            
            S3_instance = S3ResourceBase(s3_key=customer_json_path)
            
            # print(f"s3 buket is {S3_instance.s3_bucket.bucket_name},Resource exists , {S3_instance.resource_exists}")

            # Check if file exists before accessing data
            if S3_instance.resource_exists:
                customer_json = S3_instance.data  # Use `.data` instead of calling `read()`
                #logger_1.info(f"Customer JSON: {customer_json}")
                
                # fetch the vehicle block
                vehicle_keys = customer_json.get('0', {}).get('vehicle_block', {}).keys()
                
                # if vehicle number in vehicle keys, add the phone number
                if vehicle_number in vehicle_keys:
                    phone_numbers.append(number.phone_number)
                
            else:
                logger_1.info("Customer JSON file not found in S3")
                customer_json = None
    
    return phone_numbers



def lookup_fuel_level(voltage, model_file="model.pkl"):
    """
    Lookup fuel level for a given voltage using an exported model.

    Args:
        voltage (float): The input voltage.
        model_file (str): Path to the exported model file.

    Returns:
        float: The corresponding fuel level in liters.
    """
    with open(model_file, 'rb') as f:
        model = pickle.load(f)
    
    voltages = np.array(model["voltages"])
    levels = np.array(model["levels"])
    
    # Create interpolation function
    interp_func = interp1d(voltages, levels, kind='linear', fill_value="extrapolate")
    
    # Interpolate fuel level for the given voltage
    if voltage <= min(voltages):
        return levels[0]  # Clamp to minimum level
    elif voltage >= max(voltages):
        return levels[-1]  # Clamp to maximum level
    else:
        return float(interp_func(voltage))
    
 
 # Define a global temporary directory
GLOBAL_TEMP_DIR = "./temp_files"

# Ensure the directory exists
os.makedirs(GLOBAL_TEMP_DIR, exist_ok=True)

def save_temp_file(file_content, file_name):
    """
    Save a file temporarily in the global temp directory.

    Args:
        file_content (bytes): The file content to be saved.
        file_name (str): The name of the file to be saved.

    Returns:
        str: The full path of the saved file.
    """
    try:
        temp_file_path = os.path.join(GLOBAL_TEMP_DIR, file_name)
        with open(temp_file_path, "wb") as temp_file:
            temp_file.write(file_content)
        return temp_file_path
    except Exception as e:
        raise RuntimeError(f"Error saving temporary file: {str(e)}")   
    
    
def clean_temp_file(file_path):
    """Deletes a temporary file if it exists."""
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        print(f"Error deleting temp file {file_path}: {str(e)}")
        

def clean_global_temp_dir():
    """Cleans up the entire global temporary directory."""
    try:
        if os.path.exists(GLOBAL_TEMP_DIR):
            shutil.rmtree(GLOBAL_TEMP_DIR)
    except Exception as e:
        print(f"Error cleaning temp directory: {str(e)}")
        
        

    

@error_handler(library_code=lib_code_C_COM, function_code="08")
def fuel_volt_to_liters(vehicle_number : str, fuel_in_voltage : float):
    
    '''
    
    Function to get the fuel liters given the vehicle number and fuel in voltage
    
    params :
        - vehicle_number : str
        - fuel_in_voltage : float
        
    returns :
        - fuel in liters
    
    '''
    
    # fuel calibration path 
    session = prod_rds_instance.get_connection()
    
    with handle_session(session) as ns:
        # join the fleet id with fleet and vehicle registration to get the fleet name
        fleet_name = ns.query(FL_RDS.fleet_name).join(VR_RDS, FL_RDS.id == VR_RDS.fleet_id).filter(VR_RDS.vehicle_num == vehicle_number).first().fleet_name       
        
        # reconstruct the fuel_calibration_model path with fleet_name and vehicle number
        fuel_calib_model_pth = fuel_calib_model.replace('fleet_name', fleet_name).replace('vehicle_number',vehicle_number)
        
        # download the fie 
        model_file_bytes = hiperd_lake_bucket.download_file_from_s3(s3_key=fuel_calib_model_pth)
        
        # save the file temporary
        temp_model_file = save_temp_file(model_file_bytes, "fuel_model.pkl")

        try:
            # Use the lookup function to get the fuel level
            fuel_level = lookup_fuel_level(fuel_in_voltage, temp_model_file)
        finally:
            # Ensure temp file is cleaned up
            clean_temp_file(temp_model_file)

        return fuel_level
    
    
# New method using Haversine formula
from math import radians, sin, cos, sqrt, atan2

# Haversine function to calculate the great-circle distance
def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0  # Earth's radius in km
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c  # Distance in km
