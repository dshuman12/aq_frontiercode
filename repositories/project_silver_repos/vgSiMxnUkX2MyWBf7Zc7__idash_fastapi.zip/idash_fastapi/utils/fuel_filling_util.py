import os
from datetime import datetime, timedelta
import sys
import json
from typing import List
import threading
import io
import zipfile
import pytz

sys.path.append("../../")

from hiper_utils.aws.s3.s3 import S3Bucket
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB, handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistration, ActiveVehicle, Fleet, \
    DriverMaster, VehicleRegistrationNew, \
    create_pings_table_class, HWUno2, DeviceRegistrationNew, DeviceRegistrationNew, VehicleDeviceLogs
from hiper_utils.other_utils.vehicles_util import get_location_from_lat_lon
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path

from schema.ops_dash_schema import *

from sqlalchemy import and_
from sqlalchemy import text, update
from sqlalchemy.orm import aliased
import pandas as pd
import numpy as np
from sqlalchemy import func

lib_code = '30'
lib_ver = '00'
lib_code_ver = f"{lib_code}{lib_ver}"

hiperdatalake = S3Bucket(
    bucket_name="hiperdatalake"
)

new_prod_schema = MySQLDB(
    db_name="new_production_schema",
    env_var_prefix="MYSQL"
)


class FuelFilling:
    fuel_filling_file_location = ResourceS3Path.FUEL_FILLING_FILE_PTH.value
    fuel_slip_file_location = ResourceS3Path.FUEL_FILLING_SLIP_IMAGE_PTH.value

    print(fuel_filling_file_location)
    print(type(fuel_filling_file_location))

    def __init__(self, fleet_name: str, vehicle_num: str):
        self.fleet_name = fleet_name
        self.vehicle_num = vehicle_num
        self.fuel_filling_s3_key = self.fuel_filling_file_location.format(vehicle_num=self.vehicle_num,
                                                                          fleet_name=self.fleet_name)
        self.fuel_filling_slip_s3_key = self.fuel_slip_file_location.format(vehicle_num=vehicle_num,
                                                                            fleet_name=fleet_name)

    def get_fuel_filling_file(self):
        fuel_filling_df, download_bug = hiperdatalake.download_parquet(s3_key=self.fuel_filling_s3_key)

        return fuel_filling_df, download_bug

    @error_handler(library_code=lib_code_ver, function_code="17")
    def insert_fuel_filling_record(self, fuel_filling_record: FuelFillingRecord, slip_image=None,
                                   slip_image_extension=None):

        fuel_filling_df, download_bug = self.get_fuel_filling_file()



        if fuel_filling_df is None and "NoSuchKey" in str(download_bug):

            next_id = 1

        elif not fuel_filling_df.empty:

            next_id = fuel_filling_df["fuel_filling_id"].max() + 1

        else:

            return None, download_bug

        fuel_filling_record.fuel_filling_id = next_id

        new_record = fuel_filling_record.model_dump()

        if slip_image is not None:
            s3_key = f"{self.fuel_filling_slip_s3_key}{next_id}.{slip_image_extension}"  # Define your S3 key structure
            print(s3_key)
            upload_status, img_upload_bug = hiperdatalake.upload_obj_to_s3(slip_image, s3_key)

            if img_upload_bug:
                return None, img_upload_bug

        fuel_filling_df = pd.concat(
            [fuel_filling_df, pd.DataFrame([new_record])],
            ignore_index=True
        )

        _, upload_bug = hiperdatalake.upload_dataframe_to_s3_parquet(
            dataframe=fuel_filling_df,
            s3_key=self.fuel_filling_s3_key

        )

        if upload_bug:
            return None, upload_bug

        return f"Fuel filling record : {next_id} added, vehicle number {self.vehicle_num}"
