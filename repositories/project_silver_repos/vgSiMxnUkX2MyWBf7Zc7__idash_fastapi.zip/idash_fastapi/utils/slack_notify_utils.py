# Import inbuilt libraries
import requests
import os
from dotenv import load_dotenv




# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException



# Include repos folder for custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# Declare variables used 
env = load_dotenv()


# Library Code for Users Module
lib_code_SU = "52"
lib_ver_SU = "00"

lib_code_ver_SU = f"{lib_code_SU}{lib_ver_SU}"




# Include custom libraries




# initialize the logger
# logger_1 = LoggerFactory(name="slack_notify_utils", file_name="message.log").get_logger()



# Define Helper class used with the pydantic model

# define other funcs

# Define the slack webhook url
internal_dash_notfiy_slack_webhook_url = os.getenv("INTERNAL_DASH_WEBHOOK_URL")
internal_dash_bot_token = os.getenv("INTERNAL_DASH_BOT")
internal_dash_chnl_id = os.getenv("INTERNAL_DASH_CHANNEL_ID")


def get_slack_user_id(email):
    """
    Fetch the Slack user ID for the given email.
    If the user ID is not found, return None.
    """
    client = WebClient(token=internal_dash_bot_token)

    try:
        # Look up the user by email
        response = client.users_lookupByEmail(email=email)
        user_id = response["user"]["id"]

        print(f"Slack user ID found for email '{email}': {user_id}")
        
        return user_id
    
    
    except SlackApiError as e:
        if e.response["error"] == "users_not_found":
            print(f"No Slack user found for email: {email}")
        else:
            print(f"Error fetching user ID: {e.response['error']}")
        return None
    


def notify_slack(ticket_title, assigned_to_email, assigned_by_email, ticket_url, ticket_type="Ticket"):
    """
    Notify Slack about ticket/task assignment.
    If the Slack user ID is not found, fall back to using the email address in the message.
    """
    client = WebClient(token=internal_dash_bot_token)

    # Try to get Slack user ID
    user_id = get_slack_user_id(assigned_to_email)

    # Construct the "Assigned To" part
    assigned_to = f"<@{user_id}>" if user_id else assigned_to_email

    # get assigned by email 
    user_id_assigned_by = get_slack_user_id(assigned_by_email)
    
    assigned_by = f"<@{user_id_assigned_by}>" if user_id_assigned_by else assigned_by_email

    try:
        # Construct the message
        message = (
            f":tada: *[{ticket_type}] {ticket_title}* has been assigned!\n"
            f":pushpin: *Assigned To:* {assigned_to}\n"
            f":round_pushpin: *Assigned By:* {assigned_by}\n"
            f":link: <{ticket_url}|View {ticket_type}>"
        )

        # Send the message to the Slack channel
        response = client.chat_postMessage(
            channel=internal_dash_chnl_id,
            text=message  # Fallback text for notification
        )

        if response["ok"]:
            print(f"{ticket_type} notification sent successfully!")
            return True
        
        else:
            print("Failed to send notification:", response["error"])
            return False
        
    except SlackApiError as e:
        print(f"Error sending Slack notification: {e.response['error']}")





# Example usage
# notify_slack(
#     ticket_title="Fix Login Bug",
#     assigned_to_email="sarathk@hiperautomotive.com",
#     assigned_by="Jane Smith",
#     ticket_url="https://dashboard.example.com/tickets/123",
#     ticket_type="Ticket"
# )


