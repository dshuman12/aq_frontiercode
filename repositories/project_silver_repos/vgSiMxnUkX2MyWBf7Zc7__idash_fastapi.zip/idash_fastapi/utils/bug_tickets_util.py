# Import inbuilt libraries



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
import json
import random
import time
import pandas as pd
from starlette.responses import JSONResponse
from sqlalchemy.exc import NoResultFound
from fastapi import status as http_status



# Include repos folder for custom libraries


# Declare variables used 
# Library Code for Bugs Module
lib_code_BT = "41"
lib_ver_BT = "00"

lib_code_ver_BT = f"{lib_code_BT}{lib_ver_BT}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance,hiperft_bucket,bug_ticket_path,get_current_date,redis_instance,rds_instance
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.other_utils.bug_util import add_bug
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.bug_ticket_schema import *
from schema.common_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.ticket_rds_models import Bug_Ticket as BT_RDS,Libraries, FunctionList as FL_RDS
from utils.common_util import *
from schema.bug_ticket_schema import *
from hiper_utils.data_models.s3_data_models.bug_ticket import *
from hiper_utils.data_models.s3_data_models.common_models import *
from utils.attachment_util import upload_attachments_to_s3
from utils.common_util import *
from hiper_utils.other_utils.bug_util import add_bug 

# initialize the logger
logger_1 = LoggerFactory(name="bug_ticket_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model

# define other funcs
@error_handler(library_code=lib_code_ver_BT, function_code="01")
def all_bug_ticket_records():
    '''
    Function to get all the bug ticket records from BUG_TICKET RDS or Redis cache if available

    params:
        - None
    
    Returns:
        - pd DataFrame with all the bug ticket records, or
        - pd.DataFrame() (empty DataFrame) if no records are found
    '''
    columns_order = [
        "id", "name", "added_on", "added_by_id", "libraries", "assigned_to", "approver", 
        "bug_code", "count", "group_id", "status", "last_active", "type", "priority", 
        "assigned_team", "vehicle_num", "device_id", "machine_raised"
    ]

    cached_data = redis_instance.get_key('rds_bug_tickets_cached')

    if cached_data:
        try:
            cached_data = cached_data.decode('utf-8')
            cached_data = json.loads(cached_data)

            data_list = []
            for key, value in cached_data.items():
                value['id'] = int(key)  # Add the 'id' field
                data_list.append(value)

            all_bug_tickets_df = pd.DataFrame(data_list)

            if all_bug_tickets_df.empty or 'id' not in all_bug_tickets_df.columns:
                logger_1.error("Cached DataFrame is empty or missing 'id' column.")
                return pd.DataFrame()  # Return an empty DataFrame

            all_bug_tickets_df = all_bug_tickets_df.fillna('')
            datetime_columns = ['added_on', 'last_active']
            for col in datetime_columns:
                all_bug_tickets_df[col] = pd.to_datetime(all_bug_tickets_df[col], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
                all_bug_tickets_df[col] = all_bug_tickets_df[col].replace('NaT', '')

            all_bug_tickets_df = all_bug_tickets_df[columns_order]
            return all_bug_tickets_df

        except Exception as e:
            logger_1.error(f"Error while deserializing cached data: {e}")
            return pd.DataFrame()  # Return an empty DataFrame in case of error

    else:
        session = rds_instance.get_connection()
        with handle_session(session) as ns:
            all_bug_tickets = ns.query(BT_RDS).all()
            if not all_bug_tickets:
                logger_1.error("No bug tickets retrieved from the database.")
                return pd.DataFrame()  # Return an empty DataFrame

            all_bug_tickets_df = pd.DataFrame([{c.name: getattr(ticket, c.name) for c in ticket.__table__.columns} for ticket in all_bug_tickets])
            all_bug_tickets_df.reset_index(drop=True, inplace=True)

            if all_bug_tickets_df.empty or 'id' not in all_bug_tickets_df.columns:
                logger_1.error("RDS DataFrame is empty or missing 'id' column.")
                return pd.DataFrame()  # Return an empty DataFrame

            all_bug_tickets_json = all_bug_tickets_df.set_index('id').T.to_dict()
            redis_instance.set_key('rds_bug_tickets_cached', json.dumps(all_bug_tickets_json), ex=60)
            return all_bug_tickets_df




@error_handler(library_code=lib_code_ver_BT, function_code="02")
def fetch_and_cache_bug_ticket(ticketid : int , bugs={}):
    '''
    
    Function to fetch and cache the bug ticket data from S3

    params:
        - ticket_id : int : ticket id of the bug ticket to fetch and cache

    returns:
        - ticket_data : dict : dictionary containing the bug ticket data
        - None if the function fails

    '''

    logger_1.info(f"ticket id is {ticketid}")

    # Check if the data is cached
    cached_ticket = redis_instance.get_key(f'bug_ticket_{ticketid}')

    if cached_ticket:
        try:
            # Deserialize cached data
            ticket_data = json.loads(cached_ticket.decode('utf-8'))
            logger_1.info(f"Retrieved ticket from cache")
            return ticket_data
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached ticket: {str(e)}")
            raise Exception("Failed to retrieve cached ticket data.") from e

    # fetch the ticket data from S3
    ticket_data,bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticketid).zfill(5)}.json")

    if bugs_local:
        logger_1.info(f"Failed in downloading bug ticket with ticket id {ticketid} from S3, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    if ticket_data is not None:
        try:
            # Serialize data to JSON before caching
            serialized_ticket = json.dumps(ticket_data)
            redis_instance.set_key(f'bug_ticket_{ticketid}', serialized_ticket, ex=60)
            return ticket_data
        except Exception as e:
            logger_1.error(f"Failed to cache the bug ticket, {e}")
            raise Exception("Failed to cache bug ticket.") from e









# function to add the newly created ticket to the RDS cache
@error_handler(library_code=lib_code_ver_BT,function_code="03")
def add_bug_ticket_to_rds_cache(ticketid, bugs={}):

    '''
    
    Function to add a newly created ticket to the RDS cache

    params : ticketid
    returns : bool

    
    '''

    logger_1.info(f"Adding newly created bug ticket with ticket id {ticketid} to RDS cache")

    result = False

    # get the connection
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        newly_added_bug_ticket = ns.query(BT_RDS).filter(BT_RDS.id == ticketid).first()
        
        if newly_added_bug_ticket:
            logger_1.info(f"Newly created bug ticket: {newly_added_bug_ticket}")

            # serialize the newly created bug ticket
            serialized_bug_ticket_record = sqlalchemy_obj_to_dict(newly_added_bug_ticket)

            # Fetch the existing tickets from Redis
            try:
                existing_tickets_json = redis_instance.get_key('rds_bug_tickets_cached')
                if existing_tickets_json:
                    existing_tickets = json.loads(existing_tickets_json)
                else:
                    existing_tickets = {}

            except Exception as e:
                logger_1.error(f"Error fetching existing tickets from Redis: {e}")
                return result

            # Add or update the ticket in the dictionary
            existing_tickets[ticketid] = serialized_bug_ticket_record

            # Write the updated dictionary back to Redis
            try:
                redis_instance.set_key('rds_bug_tickets_cached', json.dumps(existing_tickets))
                logger_1.info(f"Bug Ticket with ID {ticketid} added/updated in cache.")
                result = True

            except Exception as e:
                print(f"Error updating tickets in cache: {e}")
                return result

        else:
            logger_1.error(f"No bug ticket found with ID: {ticketid}")


    return result
   
            
    






# function to create a bug ticket in s3
@error_handler(library_code=lib_code_ver_BT,function_code="04")
def create_ticket_in_s3(ticket_to_rds : int,ticket : Create_Bug_Ticket,bugs={}):
    '''
    Function to create a bug ticket in S3

    params:
        - ticket_to_rds : int : ticket id of the bug ticket to create
        - ticket : Create_Bug_Ticket : object containing the bug ticket data

    returns:
        - ticket_data : dict : dictionary containing the bug ticket data
        - None if the function fails   

    '''

     
    # create metadata block
    metadata = {
            'type': '0',
            'created_by': str(ticket.added_by),  
            'updated_by': str(ticket.added_by),
            'status_blocks': [2],
            'summary_block': [],
            'status': "0" if ticket.owner is not None else "2",
        }
    
    # serialize the metadata
    metadata_serialized = MetadataBlock(**metadata)

    attachment_urls_list = []

    if ticket.attachments is not None:

        logger_1.info(f"Attachments are {ticket.attachments}")

        # call the upload_attachments_to_s3 function to upload the attachments to s3
        attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket_to_rds,block_id=1)

        if bugs_local:
            logger_1.error(f"Failed to upload attachments, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif attachment_urls_list is not None:
            logger_1.info(f"Attachment urls are {attachment_urls_list}")
    
    # create a heading block
    heading = {
        'ticket_master_id': str(ticket_to_rds), 
        'ticket_name': ticket.bug_name,  
        'ticket_description': ticket.bug_description,  
        'owner' : str(ticket.owner),
        'priority': str(ticket.priority),  
        'scope': ticket.modules,
        'attachments' : attachment_urls_list
    }

    # serialize the heading
    heading_serialized = HeadingBlock(**heading)

    # create a status block
    status_block = {
        "status_change_description": f"Bug ticket named {ticket.bug_name} created successfully",
        "updated_by": str(ticket.added_by),
    }

    # serialize the status block
    status = StatusChangeBlock(**status_block)
       
    # ticket object 
    ticket_data = {
        "0" : metadata_serialized.model_dump(),
        "1" : heading_serialized.model_dump(),
        "2" : status.model_dump()
    }
            

    ticket_data,bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket_to_rds).zfill(5)}.json", data_dict=ticket_data)

    if bugs_local:
        logger_1.info(f"Failed in writing bug ticket {ticket.bug_name} to S3, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

    else:
        logger_1.info(f"Bug ticket {ticket.bug_name} written to S3 successfully")

        # call fetch and cache ticket to cache the ticket
        ticket_cached, bugs_local = fetch_and_cache_bug_ticket(ticket_to_rds)

        if bugs_local:
            logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif ticket_cached is not None:
            return ticket_cached








# function to update the ticket to rds cache.
@error_handler(library_code='lib_code_ver_FT', function_code="05")
def push_updates_to_bug_ticket_rds_cache(update, bugs={}):
    '''
    Function to update a specific feature ticket in the Redis cache related to rds records.

    params: update - the update model containing the ticket id and fields to update
    returns: True if the ticket was updated successfully, False otherwise

    '''

    logger_1.info(f"update is {update}")

    # try to retrieve all feat records from the cache
    all_ticket_record = redis_instance.get_key('rds_bug_tickets_cached')

    # if cache does not exist, call the all_feat_records function to set the cache
    if all_ticket_record is None:
        cache_set, bugs_local = all_bug_ticket_records()

        if bugs_local:
            logger_1.error(f"Fetching bug tickets failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)

        elif cache_set is not None:
            # call the retrieve all feat records function again
            all_ticket_record = redis_instance.get_key('rds_bug_tickets_cached')

    # Decode bytes to string if necessary
    if isinstance(all_ticket_record, bytes):
        all_ticket_record = all_ticket_record.decode('utf-8')
    
    # Deserialize the data
    if isinstance(all_ticket_record, str):
        all_ticket_record = json.loads(all_ticket_record)

    # Handle both Pydantic model and Pandas Series
    if isinstance(update, pd.Series):
        ticket_id = str(update['id'])
        update_data = update.to_dict()
    else:
        ticket_id = str(update.ticketid)
        update_data = update.dict(exclude_unset=True)
        update_data.pop('ticketid', None)


    logger_1.info(f"ticket id is {ticket_id}")

    logger_1.info(f"all ticket record is {all_ticket_record}")    

    # Check if the specific ticket exists
    if ticket_id not in all_ticket_record:
        logger_1.error(f"Bug ticket with id {ticket_id} not found in the cache")
        return False

   # Map input fields to cached object fields
    field_map = {
        "bug_name": "name",
        "priority": "priority",
        "team": "assigned_team",
        "owner": "assigned_to",
        "modules": "libraries",
        "status": "status",
        "type" : "type"
    }

  

    # Update the specific ticket
    for key, value in update_data.items():
        if key in field_map:
            mapped_key = field_map[key]
            if key == "deadline" and value is not None:
                # Convert datetime to string
                value = value.strftime('%Y-%m-%d %H:%M:%S')
            if key == "libraries" and value is not None:
                # Convert list to string
                value = json.dumps(value)
            all_ticket_record[ticket_id][mapped_key] = value

    # Serialize the updated data
    updated_data = json.dumps(all_ticket_record,cls=DateTimeEncoder)

    # Save the updated records back to the cache
    redis_instance.set_key('rds_bug_tickets_cached', updated_data)

    # Add the ticket id to the queue for later processing
    redis_instance.lpush('bug_ticket_update_queue', ticket_id)

    return True






# Background task to write changes to RDS
@error_handler(library_code='lib_code_ver_BT', function_code="06")
def write_changes_to_bug_ticket_rds():

    '''
    Function to write changes to RDS in the background.

    params: None
    returns: None
    
    '''


    while True:

        # Sleep for the specified interval (e.g., 1 minute for testing)
        time.sleep(60)

        # logger_1.info("Checking for changes to write to Bug Ticket RDS")

        try:
            while True:
                # Pop a ticket ID from the queue
                ticket_id = redis_instance.rpop('bug_ticket_update_queue')
                if not ticket_id:
                    break  # No more items in the queue

                ticket_id = ticket_id.decode('utf-8')
                logger_1.info(f"Writing changes for ticket {ticket_id} to RDS")

                # Retrieve all ticket records from the cache
                all_ticket_record = redis_instance.get_key('rds_bug_tickets_cached')
                if all_ticket_record is None:
                    logger_1.error("Failed to retrieve all feature tickets from cache")
                    continue  # Skip if no records found

                # Decode bytes to string if necessary
                if isinstance(all_ticket_record, bytes):
                    all_ticket_record = all_ticket_record.decode('utf-8')
                
                logger_1.info(f"All ticket record (type: {type(all_ticket_record)}): {all_ticket_record}")

                # Deserialize the data
                if isinstance(all_ticket_record, str):
                    all_ticket_record = json.loads(all_ticket_record)
                
                logger_1.info(f"Deserialized all ticket record (type: {type(all_ticket_record)}): {all_ticket_record}")

                # Get the ticket data
                ticket_data = all_ticket_record.get(ticket_id)
                if not ticket_data:
                    logger_1.error(f"Ticket with id {ticket_id} not found in the cache")
                    continue  # Skip if the ticket data is not found

                logger_1.info(f"Ticket data (type: {type(ticket_data)}): {ticket_data}")

                # Check if the ticket exists in the RDS 

                session = rds_instance.get_connection()

                with handle_session(session) as ns:
                    existing_ticket = ns.query(BT_RDS).filter(BT_RDS.id == int(ticket_id)).first()

                    # logger_1.info(f"Exisitng ticket is {existing_ticket}") 

                    libraries_str = ','.join(map(str, ticket_data['libraries']))

                    if existing_ticket:
                        existing_ticket.name = ticket_data['name']
                        existing_ticket.libraries = libraries_str   
                        existing_ticket.priority = ticket_data['priority']
                        existing_ticket.assigned_team = ticket_data['assigned_team']
                        existing_ticket.assigned_to = ticket_data['assigned_to']
                
                    logger_1.info("Changes written to RDS successfully")

        except Exception as e:
            logger_1.error(f"Error writing changes to RDS: {e}")


@error_handler(library_code='lib_code_ver_BT', function_code="07")
def update_bug_ticket_fields(ticket: Update_Bug_Ticket, bugs={}):
    '''
    Function that updates the related bug ticket s3 object in cache.

    params: ticket
    returns: updated ticket data
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:
        # perform the manipulation to heading block here and serialize it
        heading = ticket_s3_data['1']

        # update the heading block
        heading['ticket_name'] = ticket.bug_name if ticket.bug_name is not None else heading['ticket_name']
        heading['ticket_description'] = ticket.bug_description if ticket.bug_description is not None else heading['ticket_description']
        heading['priority'] = ticket.priority if ticket.priority is not None else heading['priority']
        heading['owner'] = ticket.owner if ticket.owner is not None else heading['owner']
        
        # Convert requested_eta to string
        if ticket.requested_eta is not None:
            heading['requested_eta'] = ticket.requested_eta.strftime('%Y-%m-%d %H:%M:%S')


        heading['scope'] = ticket.modules if ticket.modules is not None else heading['scope']


        # fetch the last key in the ticket_data
        last_key = list(ticket_s3_data.keys())[-1]

        # create a new status block saying that the ticket is updated
        status_block_id = int(last_key) + 1

        status_block = {
            'status_change_description': f'Ticket updated',
            'updated_by': ticket.updated_by
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

        # update the metadata
        updated_ticket_data, bugs_local = update_metadata(ticket_s3_data, ticket.updated_by)

        if bugs_local:
            logger_1.error(f"Failed to update metadata, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        elif updated_ticket_data is not None:
            ticket_pushed, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=updated_ticket_data, s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

            if bugs_local:
                logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            else:
                logger_1.info(f"Downloading the updated ticket")

                # call download_json to download the updated ticket
                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif latest_ticket_data is not None:
                    logger_1.info(f"Ticket updated successfully")
                    return latest_ticket_data



    




@error_handler(library_code='lib_code_ver_FT', function_code="08")
def handle_bug_ticket_update_for_s3(ticketid : int, ticket_with_updation, user_id: int, bugs={}):

    '''
    Function to handle the update of a bug ticket in S3. It will create a queue for the updates and write the changes to S3 in the background.

    params: ticketid, ticket_with_updation, user_id
    returns: Updated ticket data
    
    
    '''

    # Update metadata
    updated_ticket, bugs_local = update_metadata(ticket_with_updation, user_id)

    if bugs_local:
        logger_1.error(f"Failed to update metadata for ticket {ticketid}: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    elif updated_ticket is not None:
        logger_1.info(f"Metadata updated for ticket {ticketid}")

    # Serialize the updated ticket data to a JSON string
    updated_ticket_data = json.dumps(ticket_with_updation, cls=DateTimeEncoder)

    # Save the updated ticket data back to the cache (if needed)
    redis_instance.set_key(f'bug_ticket_{ticketid}', updated_ticket_data,ex=1200)

    # Add the ticket id to the S3 update queue for later processing
    redis_instance.lpush('bug_ticket_s3_update_queue', str(ticketid))

    return ticket_with_updation


@error_handler(library_code='lib_code_ver_BT', function_code="09")
def write_bug_ticket_changes_to_s3():

    '''
    Function to write bug ticket changes to S3 in the background.

    params: None
    returns: None
    
    '''


    while True:
        # Sleep for the specified interval (e.g., 1 minute for testing)
        time.sleep(60)

        # logger_1.info("Checking for changes to write to S3")

        try:
            while True:
                # Pop a ticket ID from the S3 update queue
                ticket_id = redis_instance.rpop('bug_ticket_s3_update_queue')
                if not ticket_id:
                    break  # No more items in the queue

                ticket_id = ticket_id.decode('utf-8')
                logger_1.info(f"Writing changes for ticket {ticket_id} to S3")

                # Retrieve the updated ticket data from the cache (if needed)
                ticket_data = redis_instance.get_key(f'bug_ticket_{ticket_id}')
                if ticket_data is None:
                    logger_1.error(f"Failed to retrieve ticket data for ticket ID {ticket_id} from cache")
                    continue

                # Decode bytes to string if necessary
                if isinstance(ticket_data, bytes):
                    ticket_data = ticket_data.decode('utf-8')

                # Deserialize the data
                ticket_data = json.loads(ticket_data)

                # Write the ticket data to S3
                s3_path = bug_ticket_path
                s3_key = f"{s3_path}{str(ticket_id).zfill(5)}.json"
                
                
                updated_ticket,bugs_local = hiperft_bucket.write_json_to_s3(data_dict=ticket_data, s3_key=s3_key)

                if bugs_local:
                    logger_1.error(f"Error writing changes to S3: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                
                elif updated_ticket is not None:
                    logger_1.info(f"Changes written to S3 successfully")

        except Exception as e:
            logger_1.error(f"Error writing changes to S3: {e}")



# function to add a cause block to the bug ticket
@error_handler(library_code=lib_code_ver_BT,function_code="10")
def add_cause_block(ticket : Add_Cause_Block,bugs = {}):
    
    '''
    Function that services add cause block to bug ticket

    params:
        - ticket : Add_Cause_Block : object containing the cause block data
    
    returns:
        - updated_ticket : dict : updated ticket data
        - None if the function fails
    
    '''

    # get the ticket using the fetch_and_cache_bug_ticket
    ticket_s3_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching ticket,{bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:            

        # initialize a unique cause code with zfill 5
        cause_code = str(random.randint(1,99999)).zfill(5)

        logger_1.info(f"related bug block list is {ticket.bug_blocks}")

        # create a cause block 
        cause_block = {
            'version' : "0",
            'cause_code' : cause_code,
            'module_id' : ticket.modules,
            'function_code' : ticket.function_code if ticket.function_code is not None else "",
            'added_by' : ticket.added_by,
            'name' : ticket.cause_name,
            'description' : ticket.description,
            'related_bug_blocks' : ticket.bug_blocks,
        }

        # fetch the last available key in the ticket
        last_key = list(ticket_s3_data.keys())[-1]

        logger_1.info(f"Last key is {last_key}")

        next_available_block_id = int(last_key) + 1

        logger_1.info(f"Next available block id is {next_available_block_id}") 

        attachment_urls_list = []

        if ticket.attachments is not None:

            logger_1.info(f"Attachments are {ticket.attachments}")

            # call the upload_attachments_to_s3 function to upload the attachments to s3
            attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket.ticketid,block_id=next_available_block_id)

            if bugs_local:
                logger_1.error(f"Failed to upload attachments, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif attachment_urls_list is not None:
                logger_1.info(f"Attachment urls are {attachment_urls_list}")
                cause_block['attachments'] = attachment_urls_list


        # serialize the cause block
        serialized_cause_block = CauseBlock(**cause_block)

        ticket_s3_data[str(next_available_block_id)] = serialized_cause_block.model_dump()

        # fetch the next key in the ticket after next_available_block_id
        last_key = list(ticket_s3_data.keys())[-1]

        next_available_key_for_status = int(last_key) + 1

        # add a status block to the ticket with status description as cause block added
        new_status_data = {
            "status_change_description": f"Cause block named {ticket.cause_name} added ",
            "updated_by": str(ticket.added_by),
        }

        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**new_status_data)
        
        # add the new status block to the ticket
        ticket_s3_data[str(next_available_key_for_status)] = status_serialized.model_dump()

        # update the metadata
        metadata = ticket_s3_data['0']
        # metadata['cause_blocks'].append(next_available_block_id)
        metadata['status_blocks'].append(next_available_key_for_status)

        # cause block will be a dict, key will be the related bug block id and value will be the list of cause block ids
        cause_block_dict = metadata['cause_blocks']

        for bug_block in ticket.bug_blocks:
            if bug_block in cause_block_dict:
                # append the cause block id to the existing list without duplicates
                if next_available_block_id not in cause_block_dict[bug_block]:
                    cause_block_dict[bug_block].append(next_available_block_id)
            else:
                cause_block_dict[bug_block] = [next_available_block_id]

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, ticket.added_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:
            
            # call the write_json_to_s3 function to write the updated ticket to s3
            updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

            if bugs_local:
                logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            else:
                logger_1.info(f"Cause block added successfully, downloading the updated ticket")
                
                # download the updated ticket
                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif latest_ticket_data is not None:
                    return latest_ticket_data
       


        


# function to update a cause block to the bug ticket
@error_handler(library_code=lib_code_ver_BT,function_code="11")
def update_cause_block(ticket : Update_Cause_Block, bugs = {}):
    
    # call fetch_and_cache_bug_ticket 
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif ticket_data is not None:
            
        cause_block_id = ticket.cause_block_id            

        # optional fields
        cause_name = ticket.cause_name
        description = ticket.description
        module_id = ticket.modules
        function_code = ticket.function_code

        # get the cause block from the ticket
        cause_block = ticket_data[str(cause_block_id)]

        present_cause_name = cause_block['name']
        present_description = cause_block['description']
        present_libraries = cause_block['module_id']
        present_function_code = cause_block['function_code']
        present_bug_blocks = cause_block['related_bug_blocks']

        status_change_text = f"Cause block named {present_cause_name} edited : "

        # update the cause block
        if cause_name is not None:
            cause_block['name'] = cause_name
            status_change_text += f"Cause name changed from {present_cause_name} to {cause_name} "

        if description is not None:
            cause_block['description'] = description
            status_change_text += f"Description changed from {present_description} to {description} "

        if ticket.related_bug_blocks is not None:
            cause_block['related_bug_blocks'] = ticket.related_bug_blocks
            status_change_text += f"Related bug blocks updated from {present_bug_blocks} to {ticket.related_bug_blocks} "


        if module_id is not None:

            # get the library name
            old_libraires = []

            # get the new library names
            new_libraries = []

            session = rds_instance.get_connection()

            with handle_session(session) as ns:

                for library in present_libraries:
                    library_name = session.query(Libraries).filter(Libraries.id == library).first().name
                    old_libraires.append(library_name)

                for library in module_id:
                    library_name = session.query(Libraries).filter(Libraries.id == library).first().name
                    new_libraries.append(library_name)

            
            cause_block['module_id'] = module_id
            status_change_text += f"Libraries updated from {old_libraires} to {new_libraries}"

        if function_code is not None:
            cause_block['function_code'] = function_code
            status_change_text += f"Function code updated from {present_function_code} to {function_code} "

        # update the cause block in the ticket
        ticket_data[str(cause_block_id)] = cause_block

        # get the last key in the ticket
        last_key = list(ticket_data.keys())[-1]

        # fetch the next key in the ticket
        next_available_key = int(last_key) + 1

        # add a status block to the ticket with status description as cause block edited
        new_status_data = {
            "status_change_description": status_change_text,
            "updated_by": str(ticket.updated_by),
        }

        # Serialize the new status data and log it
        status_serializer = StatusChangeBlock(**new_status_data)

        # add the new status block to the ticket
        ticket_data[str(next_available_key)] = status_serializer.model_dump()

        # update the metadata
        metadata = ticket_data['0']
        metadata['status_blocks'].append(next_available_key)

        # update the cause block in the metadata
        cause_blocks_in_ticket = metadata['cause_blocks']


        if ticket.related_bug_blocks is not None:
            for bug_block in ticket.related_bug_blocks:
                logger_1.info(f"Bug block is {bug_block}")

                # if the bug block exists as a key in the cause_blocks_in_ticket dict, append the cause_block_id to the list
                if bug_block in cause_blocks_in_ticket:
                    if cause_block_id not in cause_blocks_in_ticket[bug_block]:
                        cause_blocks_in_ticket[bug_block].append(cause_block_id)
                else:
                    cause_blocks_in_ticket[bug_block] = [cause_block_id]


            # Iterate over all the keys in cause_blocks (these are related_bug_block_ids)
            for bug_block_id in list(cause_blocks_in_ticket.keys()):  # Use list to avoid modifying dictionary during iteration
                # If the bug_block_id is not in the new related_bug_blocks
                if int(bug_block_id) not in ticket.related_bug_blocks:
                    # Check if cause_block_id is in the list and remove it
                    if cause_block_id in cause_blocks_in_ticket[bug_block_id]:
                        cause_blocks_in_ticket[bug_block_id].remove(cause_block_id)
                        
                        # If the list is empty after removal, optionally remove the key
                        if not cause_blocks_in_ticket[bug_block_id]:
                            del cause_blocks_in_ticket[bug_block_id]
                        

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_data, ticket.updated_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:

            logger_1.info(f"Updated ticket is {updated_ticket}")

            # call the write_json_to_s3 function to write the updated ticket to s3
            updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

            if bugs_local:
                logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            else:
                logger_1.info(f"Cause block updated successfully, downloading the updated ticket")

                # download the updated ticket
                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif latest_ticket_data is not None:
                    return latest_ticket_data





# function to add a solution block to the bug ticket
@error_handler(library_code=lib_code_ver_BT,function_code="12")
def add_solution_block(ticket : Add_Solution_Block,bugs={}):

    '''
    Function that services add solution block to bug ticket

    params:
        - ticket : Add_Solution_Block : object containing the solution block data

    returns:
        - updated_ticket : dict : updated ticket data
        - None if the function fails

    '''

    # call fetch_and_cache_bug_ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with ticket from S3, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:
        solution_block = {
            'related_cause_blocks' : ticket.related_cause_blocks,
            'added_by' : ticket.added_by,
            'name' : ticket.solution_name,
            'solution_steps' : ticket.solution_steps
        }

        # fetch last key in the ticket
        last_key = list(ticket_data.keys())[-1]

        next_available_block_id = int(last_key) + 1


        attachment_urls_list = []

        if ticket.attachments is not None:
                
                logger_1.info(f"Attachments are {ticket.attachments}")
    
                # call the upload_attachments_to_s3 function to upload the attachments to s3
                attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket.ticketid,block_id=next_available_block_id)
    
                if bugs_local:
                    logger_1.error(f"Failed to upload attachments, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif attachment_urls_list is not None:
                    logger_1.info(f"Attachment urls are {attachment_urls_list}")
                    solution_block['attachments'] = attachment_urls_list


        # serialize the solution block
        serialized_solution_block = SolutionBlock(**solution_block)            
    
        ticket_data[str(next_available_block_id)] = serialized_solution_block.model_dump()

        # add a new status 
        new_status_data = {
            "status_change_description": f"Solution block named {ticket.solution_name} added ",
            "updated_by": str(ticket.added_by),
        }

        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**new_status_data)

        # fetch the next key in the ticket
        next_available_key = int(next_available_block_id) + 1
        
        # add the new status block to the ticket
        ticket_data[str(next_available_key)] = status_serialized.model_dump()

        # append the next available key to the status blocks list
        metadata = ticket_data['0']
        metadata['status_blocks'].append(next_available_key)

        # unpack the related cause blocks from the ticket.related_cause_blocks
        for related_cause_block_id in ticket.related_cause_blocks:

            # add the solution block to the metadata
            # check if the related cause block exists in the solution_blocks dict
            if str(related_cause_block_id) not in ticket_data['0']['solution_blocks']:
                # add a new key to the solution_blocks dict where key is the related_cause_block_id and value is a list appending next_available_block_id.
                metadata['solution_blocks'][str(related_cause_block_id)] = [next_available_block_id]

            else:
                # append the next_available_block_id to the list of the related_cause_block_id.if the next_available_block_id exists in the list, skip
                if next_available_block_id not in ticket_data['0']['solution_blocks'][str(related_cause_block_id)]:
                    metadata['solution_blocks'][str(related_cause_block_id)].append(next_available_block_id)
                     
        
        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_data, ticket.added_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:
                    
            # call the write_json_to_s3 function to write the updated ticket to s3
            updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

            if bugs_local:
                logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            else:
                logger_1.info(f"Solution block added successfully, downloading the updated ticket")

                # download the updated ticket
                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif latest_ticket_data is not None:
                    return latest_ticket_data




# function to update the solution block
@error_handler(library_code=lib_code_ver_BT,function_code="13")
def update_solution_block(ticket : Update_Solution_Block,bugs = {}):
    '''
    
    Function that services update solution block to bug ticket

    params:
        - ticket : Update_Solution_Block : object containing the solution block data

    returns:
        - updated_ticket : dict : updated ticket data
        - None if the function fails

    
    
    '''

    # call fetch_and_cache_bug_ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in downloading bug ticket with ticket from S3")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        
    elif ticket_data is not None:

        solution_block_id = ticket.solution_block_id

        # optional fields
        related_cause_blocks = ticket.related_cause_blocks
        solution_name = ticket.solution_name
        steps = ticket.steps

        # get the solution block from metadata
        solution_blocks_in_ticket = ticket_data['0']['solution_blocks']

        # get the solution block from the ticket
        solution_block = ticket_data[str(solution_block_id)]

        # logging.info(f"solution block is {solution_block}")

        status_change_text = f"Solution block named {solution_block['name']} edited : "

        # update the solution block
        if related_cause_blocks is not None:      

            solution_block['related_cause_blocks'] = related_cause_blocks
            status_change_text += f"Related cause blocks updated "

            # Collect keys that need to be removed
            keys_to_remove = []

            # remove the solution block id from the related_cause_blocks in the solution_blocks_in_ticket dict
            key_to_delete = int(solution_block_id)

            logger_1.info(f"key to delete is {key_to_delete}")

            for key,value in solution_blocks_in_ticket.items():
                logger_1.info(f"key is {key} and value is {value}")
                # values will be list of solution block ids, remove the key to delete from the list
                if key_to_delete in value:
                    value.remove(key_to_delete)
                    logger_1.info(f"Value after removing is {value}")

                # Check if the list is now empty, and mark the key for removal
                if not value:  # Empty list evaluates to False
                    keys_to_remove.append(key)
            
            # Second pass: Remove the identified keys with empty lists
            for key in keys_to_remove:
                logger_1.info(f"Removing key {key} as its value list is empty")
                del solution_blocks_in_ticket[key]


            for related_cause_block in related_cause_blocks:
                # add a new key to the solution_blocks_in_ticket dict where key is the modified related_cause_blocks and value is the list of solution_block_id
                solution_blocks_in_ticket[str(related_cause_block)] = [solution_block_id]                
            

            if solution_name is not None:
                solution_block['name'] = solution_name
                status_change_text += f"Solution name changed to {solution_name} "

            if steps is not None:
                solution_block['solution_steps'] = steps
                status_change_text += f"Steps updated to {steps} "

            # add a status block to the ticket with status description as solution block edited
            new_status_data = {
                "status_change_description": status_change_text,
                "updated_by": ticket.updated_by,
            }

            # Serialize the new status data and log it
            status_serialized = StatusChangeBlock(**new_status_data)

            # fetch the last key in the ticket
            last_key = list(ticket_data.keys())[-1]

            # fetch the next key in the ticket
            next_available_key = int(last_key) + 1

            # add the new status block to the ticket
            ticket_data[str(next_available_key)] = status_serialized.model_dump()


            # update the metadata
            metadata = ticket_data['0']
            metadata['status_blocks'].append(next_available_key)

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_data, ticket.updated_by)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                        
                # call the write_json_to_s3 function to write the updated ticket to s3
                updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

                if bugs_local:
                    logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                else:
                    logger_1.info(f"Solution block updated successfully, downloading the updated ticket")

                    # download the updated ticket
                    latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                    if bugs_local:
                        logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    
                    elif latest_ticket_data is not None:
                        return latest_ticket_data


# add result function
@error_handler(library_code=lib_code_ver_BT,function_code="14")
def add_result_block(ticket : Add_Result_Block,bugs = {}):
    '''
    Function that services add result block to bug ticket

    params:
        - ticket : Add_Result_Block : object containing the result block data

    returns:
        - updated_ticket : dict : updated ticket data
        - None if the function fails
    
    '''
    
    # call fetch_and_cache_bug_ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in downloading bug ticket with ticket from S3")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:
    
        result_block = {
            'related_solution_blocks' : ticket.related_solution_blocks,
            'added_by' : ticket.added_by,
            'name' : ticket.result_name,
            'result_summary' : ticket.result_summary
        }

        # fetch the next available key in the ticket

        last_key = list(ticket_data.keys())[-1]

        next_available_block_id = int(last_key) + 1


        attachment_urls_list = []

        if ticket.attachments is not None:
            
            logger_1.info(f"Attachments are {ticket.attachments}")

            # call the upload_attachments_to_s3 function to upload the attachments to s3
            attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket.ticketid,block_id=next_available_block_id)

            if bugs_local:
                logger_1.error(f"Failed to upload attachments, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif attachment_urls_list is not None:
                logger_1.info(f"Attachment urls are {attachment_urls_list}")
                result_block['attachments'] = attachment_urls_list

        # serialize the result block
        serialized_result_block = ResultBlock(**result_block)

        ticket_data[str(next_available_block_id)] = serialized_result_block.model_dump()

    
        # add a new status 
        new_status_data = {
            "status_change_description": f"Result block named {ticket.result_name} added",
            "updated_by": str(ticket.added_by),
        }

        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**new_status_data)

        # fetch the next key in the ticket
        next_available_key = int(next_available_block_id) + 1
      
        # add the new status block to the ticket
        ticket_data[str(next_available_key)] = status_serialized.model_dump()

        # update the metadata
        metadata = ticket_data['0']

        for related_solution_block in ticket.related_solution_blocks:
            # if the related solution block key exists, then append the next_available_block_id to the list
            if str(related_solution_block) in metadata['result_blocks']:
                metadata['result_blocks'][str(related_solution_block)].append(next_available_block_id)
            
            else:
                # create a new key value pair in the result_blocks dict
                metadata['result_blocks'][str(related_solution_block)] = [next_available_block_id]

        metadata['status_blocks'].append(next_available_key)

        # call the update metadata function to update the updated_by field  
        updated_ticket, bugs_local = update_metadata(ticket_data, ticket.added_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:
            # call the write_json_to_s3 function to write the updated ticket to s3
            updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

            if bugs_local:
                logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            else:
                logger_1.info(f"Result block added successfully, downloading the updated ticket")

                # download the updated ticket
                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif latest_ticket_data is not None:
                    return latest_ticket_data
            



# function to update the result block
@error_handler(library_code=lib_code_ver_BT,function_code="15")
def update_result_block(ticket : Update_Result_Block,bugs = {}):

    # call fetch_and_cache_bug_ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in downloading bug ticket with ticket from S3")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
        
    elif ticket_data is not None:
        result_block_id = ticket.result_block_id

        # optional fields
        related_solution_blocks = ticket.related_solution_blocks
        result_name = ticket.result_name
        result_summary = ticket.result_summary

        # fetch the result block dictionary
        result_blocks = ticket_data['0']['result_blocks']

        # maintain a list to keep track of the empty keys
        keys_to_remove = []

        # itterate through the result_blocks dict and remove the result_block_id from the related_solution_blocks list
        for key,value in result_blocks.items():
            logger_1.info(f"key is {key} and value is {value}")
            # remove the result_block_id from the list of related_solution_blocks which is not mentioned in ticket.related_solution_blocks
            if result_block_id in value:
                value.remove(result_block_id)
                logger_1.info(f"key is {key} and Value after removing is {value}")

            # Check if the list is now empty, and mark the key for removal
            if not value:  # Empty list evaluates to False
                keys_to_remove.append(key)

        
        # Second pass: Remove the identified keys with empty lists
        for key in keys_to_remove:
            logger_1.info(f"Removing key {key} as its value list is empty")
            del result_blocks[key]

        logger_1.info(f"Reached here")

        # get the result block from the ticket
        result_block = ticket_data[str(result_block_id)]

        status_change_text = f"Result block named {result_block['name']} edited : "

        # update the result block
        if result_name is not None:
            old_result_name = result_block['name']
            result_block['name'] = result_name
            status_change_text += f"Result name changed from {old_result_name} to {result_name} "

        if result_summary is not None:
            result_block['result_summary'] = result_summary
            status_change_text += f"Result summary updated to {result_summary} "

        if related_solution_blocks is not None:
            # update the related solution block in the result block
            result_block['related_solution_blocks'] = related_solution_blocks

            # delete if there is any key value pair in the result_blocks with value as result_block_id
            duplicate_result_blocks = {key:value for key,value in result_blocks.items() if value == int(result_block_id)}

            # delete the key value pair from the result_blocks
            for key in duplicate_result_blocks.keys():
                del result_blocks[key]
            
            for related_solution_block in related_solution_blocks:
                # if the related solution block key exists, then append the next_available_block_id to the list. if the next_available_block_id is already present in the list, then skip
                if str(related_solution_block) in result_blocks:
                    if result_block_id not in result_blocks[str(related_solution_block)]:
                        result_blocks[str(related_solution_block)].append(result_block_id)

                else:
                    # create a new key value pair in the result_blocks dict
                    result_blocks[str(related_solution_block)] = [result_block_id]
             
            # add a new status
            new_status_data = {
                "status_change_description": status_change_text,
                "updated_by": str(ticket.updated_by),
            }

            # Serialize the new status data and log it
            status_serialized = StatusChangeBlock(**new_status_data)

            # fetch the last key in the ticket
            last_key = list(ticket_data.keys())[-1]

            # fetch the next key in the ticket
            next_available_key = int(last_key) + 1

            # add the new status block to the ticket
            ticket_data[str(next_available_key)] = status_serialized.model_dump()

            # update the metadata
            metadata = ticket_data['0']
            metadata['status_blocks'].append(next_available_key)

          
            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_data, ticket.updated_by)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                # call the write_json_to_s3 function to write the updated ticket to s3
                updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

                if bugs_local:
                    logger_1.error(f"Failed to write the updated ticket to s3, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                else:
                    logger_1.info(f"Result block updated successfully, downloading the updated ticket")

                    # download the updated ticket
                    latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                    if bugs_local:
                        logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    
                    elif latest_ticket_data is not None:
                        return latest_ticket_data


# function to delete the bug block 
@error_handler(library_code=lib_code_ver_BT,function_code="31")
def delete_bug_block_service(ticket : Delete_Bug_Block,bugs = {}):


    # call fetch_and_cache_bug_ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

        
    elif ticket_data is not None:
        # itterate through the bug block ids and check if they are in the ticket
        for bug_block_id in ticket.bug_block_ids:
            if str(bug_block_id) not in ticket_data.keys():
                logger_1.info(f"Bug block with block id {bug_block_id} not found in the ticket")
        
            else:

                logger_1.info(f"logging bug block, {ticket_data[str(bug_block_id)]}")

                # get the bug code of the bug block
                bug_code = ticket_data[str(bug_block_id)]['bug_code']

                logger_1.info(f"Deleting bug block with block id {bug_block_id} from the ticket")
                logger_1.info(f"Bug code of the bug block is {bug_code}")

                vehicle_num = ticket_data[str(bug_block_id)]['vehicle_num']

                logger_1.info(f"Vehicle number of the bug block is {vehicle_num}")

                vehicle_num = "no-veh-number" if vehicle_num is None else vehicle_num

                # fetch the bug blocks dictionary from the ticket
                bug_blocks = ticket_data['0']['bug_blocks']
                
                logger_1.info(f"bug blocks in the ticket are, {bug_blocks}")

                # fetch the bug block related to the bug code and vehicle number
                bug_block_list = bug_blocks[str(bug_code)][str(vehicle_num)]

                # remove the bug block id from the bug block list
                bug_block_list.remove(bug_block_id)

                # if the bug block list is empty, remove the key from the bug blocks dictionary
                if len(bug_block_list) == 0:
                    del bug_blocks[str(bug_code)][str(vehicle_num)]

                # if the bug blocks dictionary is empty, remove the key from the ticket
                if len(bug_blocks[str(bug_code)]) == 0:
                    del bug_blocks[str(bug_code)]

                # delete the bug block from the ticket
                del ticket_data[str(bug_block_id)]

                # add a new status
                new_status_data = {
                    "status_change_description": f"Bug block with bug code {bug_code} and vehicle number {vehicle_num} deleted",
                    "updated_by": ticket.deleted_by,
                }

                # Serialize the new status data and log it
                status_serialized = StatusChangeBlock(**new_status_data)

                # fetch the last key from the ticket
                last_key = list(ticket_data.keys())[-1]

                # fetch the next key in the ticket
                next_available_key = int(last_key) + 1

                # add the new status block to the ticket
                ticket_data[str(next_available_key)] = status_serialized.model_dump()

                # append the next available key to the status blocks list
                ticket_data['0']['status_blocks'].append(next_available_key)

                # call update metadata function
                updated_ticket, bugs_local = update_metadata(ticket_data, ticket.deleted_by)

                if bugs_local:
                    logger_1.error(f"Updating metadata failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif updated_ticket is not None:
                    # call the write_json_to_s3 function to write the updated ticket to s3
                    updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

                    if bugs_local:
                        logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    
                    else:
                        # download the updated ticket
                        logger_1.info(f"Bug block deleted successfully, downloading the updated ticket")

                        latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                        if bugs_local:
                            logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                            bugs = c_bugs(bugs, bugs_local)
                            bugs = s_bugs(bugs)
                            return None
                        
                        elif latest_ticket_data is not None:
                            return latest_ticket_data




# function to spilt the bug block
@error_handler(library_code=lib_code_ver_BT,function_code="32")
def split_bug_block_service(ticket : Split_Bug_Block,bugs = {}):
    """
    Service function to handle the logic of splitting bug block instances into a new bug block.

    params:
        - ticket : object containing the necessary data (ticket_id, instances, added_by, bug_block_id)

    returns:
        - tuple: (status, ticket_data, bugs)
        - status: HTTP status code
        - ticket_data: updated ticket data if successful, else None
        - bugs: dictionary of any encountered bugs
    """
    bugs = {}

    # call fetch_and_cache_bug_ticket
    ticket_data, bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in downloading ticket from S3, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    # Get the bug block from the ticket
    bug_block = ticket_data[str(ticket.bug_block_id)]
    bug_block_instances = bug_block['bug_instances']

    logger_1.info(f"Bug block instances: {bug_block_instances}")

    # Create a new bug block
    new_bug_block = {
        "type": "2",
        "bug_code": str(bug_block['bug_code']),
        "vehicle_num": str(bug_block['vehicle_num']),
        "device_id": str(bug_block['device_id']),
        "instance_count": 0,
        "added_by": bug_block['added_by'],
        "added_on": get_current_date(),
        "last_active": get_current_date(),
        "remarks": None,
        "attachment": None,
        "bug_instance": {}
    }

    # Iterate through the instances and move them to the new bug block
    for instance in ticket.instances:
        logger_1.info(f"Instance: {instance}")
        if str(instance) not in bug_block_instances:
            logger_1.info(f"Instance {instance} not found in bug block instances")

        new_bug_block['bug_instance'][str(instance)] = bug_block_instances[str(instance)]
        new_bug_block['instance_count'] += 1
        del bug_block_instances[str(instance)]
        bug_block['instance_count'] -= 1

    # Update the ticket with the new bug block
    ticket_last_key = list(ticket_data.keys())[-1]
    next_available_key = int(ticket_last_key) + 1
    ticket_data[str(next_available_key)] = new_bug_block

    # Handle vehicle number
    vehicle_num = "no-veh-number" if bug_block['vehicle_num'] is None else bug_block['vehicle_num']
    ticket_data['0']['bug_blocks'][str(new_bug_block['bug_code'])][str(vehicle_num)].append(next_available_key)

    # Add a new status
    new_status_data = {
        "status_change_description": f"Bug block with {bug_block['bug_code']}, vehicle number {bug_block['vehicle_num']} and device id {bug_block['device_id']} split to a new bug block",
        "updated_by": str(ticket.added_by),
    }

    status_serialized = StatusChangeBlock(**new_status_data)
    status_key = next_available_key + 1
    ticket_data[str(status_key)] = status_serialized.model_dump()
    ticket_data['0']['status_blocks'].append(int(status_key))

    # call update metadata function
    updated_ticket, bugs_local = update_metadata(ticket_data, ticket.added_by)

    if bugs_local:
        logger_1.error(f"Updating metadata failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif updated_ticket is not None:
        # call the write_json_to_s3 function to write the updated ticket to s3
        updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        else:
            # download the updated ticket
            logger_1.info(f"Bug block split successfully, downloading the updated ticket")

            latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

            if bugs_local:
                logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif latest_ticket_data is not None:
                return latest_ticket_data



# function to close the bug ticket
@error_handler(library_code=lib_code_ver_BT,function_code="33")
def checK_if_ticket_is_closed(ticket : Close_BugTicket):
    '''
    
    Service function to check if the ticket is closed

    params:
        - ticket : object containing the necessary data (ticket_id, closed_by etc)

    returns:
        - bool : True if the ticket is closed, else False
        - None if the function fails
    '''

    # call fetch and cache bug ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:

        # if ticket status is 4, return an error saying ticket is already closed
        ticket_status = ticket_data['0']['status']

        logger_1.info(f"Ticket status is {ticket_status}")

        if int(ticket_status) == 4:
            logger_1.info(f"Ticket with id {ticket.ticketid} is already closed")
            return True
        
        else:
            logger_1.info(f"Ticket with id {ticket.ticketid} is not closed")
            return False
        

# function to check if all cause blocks have solution blocks
@error_handler(library_code=lib_code_ver_BT,function_code="34")
def check_if_all_cause_blocks_have_solution_blocks(ticket : Close_BugTicket):
    '''
    
    Service function to check if all cause blocks have solution blocks

    params:
        - ticket : object containing the necessary data (ticket_id, closed_by etc)

    returns:
        - bool : True if all cause blocks have solution blocks, else False
        - None if the function fails
    
    
    '''


    # call fetch and cache bug ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:

         # get all cause blocks
        cause_blocks = ticket_data['0']['cause_blocks']

        # get all solution blocks
        solution_blocks = ticket_data['0']['solution_blocks']

        # cause blocks will be nested dict, where the key is the bug block id and the value is the list of cause block ids
        # gather all the cause block ids in a list without duplicates
        cause_block_ids = []

        for cause_block_list in cause_blocks.values():
            for value in cause_block_list:
                if value not in cause_block_ids:
                    cause_block_ids.extend(cause_block_list)


        # solution blocks will be nested dict, where the key is the cause block id and the value is the list of solution block ids
        # check if all the cause block ids appear to be keys in the solution blocks
        for cause_block_id in cause_block_ids:
            if str(cause_block_id) not in list(solution_blocks.keys()):
                return False
            
        return True


# function to check if all the solution blocks have result blocks
@error_handler(library_code=lib_code_ver_BT,function_code="35")
def check_if_all_solution_blocks_have_result_blocks(ticket : Close_BugTicket):
    '''
    
    Service function to check if all solution blocks have result blocks

    params:
        - ticket : object containing the necessary data (ticket_id, closed_by etc)

    returns:
        - bool : True if all solution blocks have result blocks, else False
        - None if the function fails

    '''

    # call fetch and cache bug ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:

        # get all solution blocks
        solution_blocks = ticket_data['0']['solution_blocks']

        # solution blocks will be nested dict, where the key is the cause block id and the value is the list of solution block ids
        # gather all the solution block ids in a list without duplicates
        solution_block_ids = []

        for solution_block_list in solution_blocks.values():
            for value in solution_block_list:
                if value not in solution_block_ids:
                    solution_block_ids.extend(solution_block_list)


        # get all result blocks
        result_blocks = ticket_data['0']['result_blocks']

        # result blocks would be a dictionary with key as solution block id and value as result block id
        # check if all solution blocks ids appear to be keys in the result blocks
        for solution_block_id in solution_block_ids:
            if str(solution_block_id) not in list(result_blocks.keys()):
                return False
            
        return True

# function to check if all tasks closed
@error_handler(library_code=lib_code_ver_BT,function_code="36")
def check_if_all_tasks_are_closed(ticket : Close_BugTicket):
    '''
    
    Service function to check if all tasks are closed

    params:
        - ticket : object containing the necessary data (ticket_id, closed_by etc)

    returns:
        - bool : True if all tasks are closed, else False
        - None if the function fails
    '''

    # call fetch and cache bug ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:
        
        # get all tasks_blocks 
        task_blocks = ticket_data['0']['tasks_blocks']

        task_block_values = [value for value in task_blocks.values()]

        # task blocks would be a dictionary with key as task master rds id and value as task block id
        # get each task block id, itterate through the ticket and check if the task status is 4

        for task_block in task_block_values:
            task_status = ticket_data[str(task_block)]['status']
            if int(task_status) < 4:
                return False
            
        return True



# function to close the bug ticket
@error_handler(library_code=lib_code_ver_BT,function_code="37")
def update_close_ticket_object(ticket : Close_BugTicket,bugs={}):
    '''
    Function that modifies the related s3 object and rds record to mark the ticket as closed

    params:
        - ticket : Close_BugTicket : object containing the necessary data (ticket_id, closed_by etc)

    returns:
        - updated_ticket : dict : updated ticket data if successful
        - None if the function fails
    '''

    # call fetch and cache bug ticket
    ticket_data,bugs_local = fetch_and_cache_bug_ticket(ticket.ticketid)

    if bugs_local:
        logger_1.info(f"Failed in fetching bug ticket with id {ticket.ticketid}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:
    
        summary_block = {
            "added_by" : ticket.closed_by,
            "added_on" : get_current_date(),
            "future_imp" : ticket.future_imp,
            "learnings" : ticket.learnings
        }
            
        last_key = list(ticket_data.keys())[-1]

        next_available_key_for_summary = int(last_key) + 1

        # serialize the summary block
        serialized_summary_block = SummaryBlock(**summary_block)

        # add the summary block to the ticket data
        ticket_data[str(next_available_key_for_summary)] = serialized_summary_block.model_dump()

    
        # add a new status
        new_status_data = {
            "status_change_description": f"Ticket closed by {ticket.closed_by}",
            "updated_by": str(ticket.closed_by)
        }

        # Serialize the new status data
        status_serialized = StatusChangeBlock(**new_status_data)

        # fetch the last key in the ticket
        last_key = list(ticket_data.keys())[-1]

        # fetch the next key
        next_key_for_status = int(last_key) + 1

        # add the new status block to the ticket
        ticket_data[str(next_key_for_status)] = status_serialized.model_dump()

        # update the metadata
        metadata = ticket_data['0']
        metadata['summary_block'].append(next_available_key_for_summary)
        metadata['status_blocks'].append(next_key_for_status)

        # update the status of the ticket
        metadata['status'] = 4

        # call update metadata function
        updated_ticket, bugs_local = update_metadata(ticket_data, ticket.closed_by)

        if bugs_local:
            logger_1.error(f"Updating metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:

            # update the BT_RDS record
            session = rds_instance.get_session()

            with handle_session(session) as ns:
                ticket = ns.query(BT_RDS).filter(BT_RDS.ticketid == ticket.ticketid).first()

                ticket.status = 4

                ns.commit()

            # call the write_json_to_s3 function to write the updated ticket to s3
            updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=updated_ticket)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                # download the updated ticket
                logger_1.info(f"Ticket closed successfully, downloading the updated ticket")

                latest_ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{bug_ticket_path}{str(ticket.ticketid).zfill(5)}.json")

                if bugs_local:
                    logger_1.error(f"Failed to download the updated ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif latest_ticket_data is not None:
                    return latest_ticket_data
            
       
@error_handler(library_code=lib_code_ver_BT,function_code="39")
def push_to_bug_dict(bug: dict):
    # Retrieve the existing bug dictionary from Redis (if it exists)
    cached_bug_dict = redis_instance.get_key("bug_dict")

    if cached_bug_dict:
        # Deserialize the cached dictionary
        bug_dict = json.loads(cached_bug_dict.decode('utf-8'))
    else:
        # Initialize the bug dictionary if it's not already in Redis
        bug_dict = {}

    # The bug dict is coming in the form of {'1': {...}} so we need to extract the inner value
    for key, value in bug.items():
        # Add the value directly to the bug_dict with the next available key
        next_key = str(int(max(bug_dict.keys(), key=int)) + 1) if bug_dict else '1'
        bug_dict[next_key] = value

    logger_1.info(f"Updated bug_dict: {bug_dict}")

    # Serialize the updated bug dictionary and cache it in Redis
    serialized_bug_dict = json.dumps(bug_dict)
    redis_instance.set_key("bug_dict", serialized_bug_dict)
    


# function to update the rds bug ticket record
@error_handler(library_code=lib_code_ver_BT,function_code="40")
def update_rds_bug_ticket_record(ticket: Update_Bug_Ticket, bugs={}):
    '''
    Function to update the BT_RDS record with the new ticket data

    params:
        - ticket : dict : updated ticket data
        - bugs : dict : dictionary to store any encountered bugs

    returns:
        - updated sqlalchemy object if successful, else None
    
    '''

    # get the session
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # fetch the ticket record
        ticket_record = ns.query(BT_RDS).filter(BT_RDS.id == ticket.ticketid).first()

        # update the record
        if ticket.bug_name:
            ticket_record.name = ticket.bug_name

        if ticket.priority:
            ticket_record.priority = ticket.priority

        if ticket.owner:
            ticket_record.assigned_to = ticket.owner

        if ticket.modules:
            ticket_record.libraries = ticket.modules

        # commit the changes
        ns.commit()

        return ticket_record


# func to combine and serialize the bug blocks
@error_handler(library_code=lib_code_ver_BT,function_code="41")
def handle_bugs(existing_bugs, new_bugs):
    """
    Combine and serialize bug instances.
    
    Parameters:
    - existing_bugs: dict - Existing tracked bugs.
    - new_bugs: dict - Newly encountered bugs.

    Returns:
    - dict: Combined and serialized bugs.
    """
    # Combine the bugs
    combined_bugs = c_bugs(existing_bugs, new_bugs)
    
    # Serialize the bugs
    serialized_bugs = s_bugs(combined_bugs)
    
    return serialized_bugs


# func to transfer one bug block to another
@error_handler(library_code=lib_code_ver_BT, function_code="42")
def get_bug_block_to_transfer(input: Transfer_Bug_Block, bugs={}):
    """
    Function to fetch the complete bug block dictionary structure from the source ticket.

    Parameters:
        - input: Transfer_Bug_Block object containing source_ticket_id, target_ticket_id, block_ids, updated_by.
        - bugs: Dictionary to collect errors, if any.

    Returns:
        - matched_blocks: dict : Bug blocks with their metadata.
        - bugs: dict : Dictionary to store encountered bugs.
    """
  
    bugs = {}
    
    matched_blocks = {}
  
    # Fetch the source ticket
    source_ticket_data, bugs_local = fetch_and_cache_bug_ticket(input.source_ticket_id)

    if bugs_local:
        logger_1.error(f"Failed in fetching bug ticket with ID {input.source_ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        return matched_blocks

    elif source_ticket_data is not None:
        
        # Iterate through block_ids from input
        for block_id in input.block_ids:
            block_found = False
            bug_blocks = source_ticket_data["0"]["bug_blocks"]

            for bug_code, vehicles in bug_blocks.items():
                for vehicle_num, block_list in vehicles.items():
                    if block_id in block_list:
                        logger_1.info(f"Found block ID {block_id} under bug code {bug_code} and vehicle {vehicle_num}")
                        matched_blocks[block_id] = {
                            "bug_code": bug_code,
                            "vehicle_num": vehicle_num,
                            "block_data": source_ticket_data[str(block_id)],
                        }
                        block_found = True
                        break
                    
                if block_found:
                    break

            if not block_found:
                logger_1.error(f"Block ID {block_id} not found in the source ticket.")
                

    return matched_blocks

    
    
@error_handler(library_code=lib_code_ver_BT, function_code="43")
def fetch_function_rds_table(bugs={}):
    '''
    Function to fetch the function rds table and form a DataFrame.

    Params:
        - ticket_id : int : Ticket ID of the bug ticket
        - bugs : dict : Dictionary to store any encountered bugs

    Returns:
        - function_df : pd.DataFrame : DataFrame containing the function RDS records, else an empty DataFrame
    '''
    
    # Initialize an empty DataFrame
    function_df = pd.DataFrame()

    # Get the session
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Fetch the function RDS records
        all_funcs = ns.query(FL_RDS).all()
        
        logger_1.info(f"Function RDS records: {all_funcs}")
        
        # Extract the required data and form a list of dictionaries
        data = [
            {
                "bug_code": f"{str(record.library_id).zfill(2)}{record.library_version.zfill(2)}"
                            f"{record.function_code.zfill(2)}{record.error_type.zfill(2)}",
                "function_name": record.function_name,
                "team_id": record.team_id
            }
            for record in all_funcs
        ]

        # Create a DataFrame
        function_df = pd.DataFrame(data)

    return function_df
        


def update_function_record(bug_code: str, new_function_name: str = None, new_team_id: int = None) -> JSONResponse:
    """
    Updates the function_name, team_id, or both fields in FUNCTION_LIST for a given bug code.

    Args:
        bug_code (str): Unique bug code (e.g., '07020702') to identify the record.
        new_function_name (str): The new function name to update (optional).
        new_team_id (int): The new team ID to update (optional).

    Returns:
        JSONResponse: Standardized success or error response.
    """
    if len(bug_code) != 8:
        return JSONResponse(
            {"error": "Invalid bug code format. Must be 8 characters."},
            status_code=400
        )

    # Parse the bug code
    library_id = int(bug_code[:2])
    library_version = bug_code[2:4]
    function_code = bug_code[4:6]
    error_type = bug_code[6:8]

    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        try:
            # Fetch the record matching the composite primary key
            record = ns.query(FL_RDS).filter(
                FL_RDS.library_id == library_id,
                FL_RDS.library_version == library_version,
                FL_RDS.function_code == function_code,
                FL_RDS.error_type == error_type
            ).one()

            # Update fields
            if new_function_name:
                record.function_name = new_function_name
            
            if new_team_id is not None:
                record.team_id = None if new_team_id == 0 else new_team_id
            
            ns.commit()

            return JSONResponse(
                {"message": "Function updated successfully."},
                status_code=200
            )

        except NoResultFound:
            return JSONResponse(
                {"error": f"No record found for bug code {bug_code}."},
                status_code=404
            )

        except Exception as e:
            logger_1.error(f"Error updating the record: {str(e)}")
            ns.rollback()
            return JSONResponse(
                {"error": f"Unknown error occured: {str(e)}"},
                status_code=500
            )



# Function to add the bug block to the target ticket and update the metadata
@error_handler(library_code=lib_code_ver_BT, function_code="44")
def add_bug_block_to_target_ticket(matched_blocks: dict, input: Transfer_Bug_Block, bugs={}):
    """
    Function to add the retrieved bug blocks to the target ticket.

    Parameters:
        - matched_blocks: dict : Retrieved bug blocks from the source ticket.
        - input: Transfer_Bug_Block object containing source_ticket_id, target_ticket_id, block_ids, updated_by.
        - bugs: Dictionary to collect errors, if any.

    Returns:
        - updated_target_ticket: dict : The updated target ticket data with all bug blocks.
        - bugs: dict : Dictionary to store encountered bugs.
    """
    # Fetch the target ticket
    target_ticket_data, bugs_local = fetch_and_cache_bug_ticket(input.target_ticket_id)

    if bugs_local:
        logger_1.error(f"Failed to fetch target ticket with ID {input.target_ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None, bugs

    elif target_ticket_data is None:
        logger_1.error(f"Target ticket with ID {input.target_ticket_id} not found.")
        return None, {"error": f"Target ticket {input.target_ticket_id} not found."}

    #  Extract the heading block
    heading_block = target_ticket_data.get("1", {})

    #  Extract affected vehicles from heading block
    affected_vehicles = set(heading_block.get("affected_vehicles", []))

    #  Get the last key in the target ticket to determine the next available key
    last_key = max(map(int, target_ticket_data.keys()))
    next_available_key = last_key + 1

    #  Iterate through the matched blocks and add them to the target ticket
    for block_id, block_details in matched_blocks.items():
        bug_code = block_details["bug_code"]
        vehicle_num = block_details["vehicle_num"]
        block_data = block_details["block_data"]
        device_id = block_data["device_id"]

        #  Add the bug block to the target ticket
        target_ticket_data[str(next_available_key)] = block_data

        #  Update the metadata block's bug_blocks field
        if bug_code not in target_ticket_data["0"]["bug_blocks"]:
            target_ticket_data["0"]["bug_blocks"][bug_code] = {}

        if vehicle_num not in target_ticket_data["0"]["bug_blocks"][bug_code]:
            target_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num] = []

        target_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num].append(next_available_key)

        #  Add vehicle to affected_vehicles if not already present
        affected_vehicles.add(vehicle_num)

        #  Update the metadata block's timestamp and updated_by field
        target_ticket_data["0"]["updated_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        target_ticket_data["0"]["updated_by"] = input.updated_by

        logger_1.info(f"Added block ID {block_id} to target ticket with new key {next_available_key}")

        #  Add a new status
        new_status_data = {
            "status_change_description": f"Bug block with bug code {bug_code} and vehicle number {vehicle_num} added",
            "updated_by": input.updated_by,
        }

        #  Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**new_status_data)

        #  Increment the next available key
        next_available_key_for_status = next_available_key + 1

        #  Add the new status block to the ticket
        target_ticket_data[str(next_available_key_for_status)] = status_serialized.model_dump()

        #  Append the next available key to the status blocks list
        target_ticket_data["0"]["status_blocks"].append(next_available_key_for_status)

        #  Update the heading block with the new affected vehicles
        heading_block["affected_vehicles"] = list(affected_vehicles)
        target_ticket_data["1"] = heading_block

        #  Write the updated ticket to S3 after adding the block
        result, bugs_local = hiperft_bucket.write_json_to_s3(
            data_dict=target_ticket_data,
            s3_key=f"{bug_ticket_path}{str(input.target_ticket_id).zfill(5)}.json",
        )

        if bugs_local:
            logger_1.error(f"Failed to write target ticket back to S3 after adding block ID {block_id}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        logger_1.info(f"Target ticket {input.target_ticket_id} updated successfully with block ID {block_id}")

        #  Increment the next available key
        next_available_key = next_available_key_for_status + 1
        
        # Update the RDS Ticket Without Duplicates
        session = rds_instance.get_connection()
        with handle_session(session) as ns:
            # Get the target ticket RDS record
            target_ticket_rds = ns.query(BT_RDS).filter(BT_RDS.id == input.target_ticket_id).first()

            if not target_ticket_rds:
                logger_1.error(f"RDS record for target ticket {input.target_ticket_id} not found.")
                return None

            # Convert the existing values into sets for easy comparison
            existing_bug_codes = set(target_ticket_rds.bug_code.split(",")) if target_ticket_rds.bug_code else set()
            existing_vehicles = set(target_ticket_rds.vehicle_num.split(",")) if target_ticket_rds.vehicle_num else set()
            existing_device_ids = set(target_ticket_rds.device_id.split(",")) if target_ticket_rds.device_id else set()
            
            logger_1.info(f"Existing bug codes {existing_bug_codes} and existing vehicles are {existing_vehicles}")

            # Add the new bug code & vehicle number if they don’t exist
            if bug_code not in existing_bug_codes:
                existing_bug_codes.add(bug_code)
                logger_1.info(f"Added bug code {bug_code} to ticket {input.target_ticket_id}")

            if vehicle_num not in existing_vehicles:
                existing_vehicles.add(vehicle_num)
                logger_1.info(f"Added vehicle number {vehicle_num} to ticket {input.target_ticket_id}")

            if device_id not in existing_device_ids:
                existing_device_ids.add(device_id)
                logger_1.info(f"Added device ID {device_id} to ticket {input.target_ticket_id}")

            # Convert back to comma-separated strings and update RDS
            target_ticket_rds.bug_code = ",".join(sorted(existing_bug_codes))
            target_ticket_rds.vehicle_num = ",".join(sorted(existing_vehicles))
            target_ticket_rds.device_id = ",".join(sorted(existing_device_ids))
            
            logger_1.info(f"Updated bug codes are {target_ticket_rds.bug_code} and {target_ticket_rds.vehicle_num} and {target_ticket_rds.device_id}")

            ns.commit()

            # remove the cached ticket
            redis_instance.delete_key(f"bug_ticket_{input.target_ticket_id}")


    #  Return the updated target ticket with all added blocks
    return target_ticket_data


@error_handler(library_code=lib_code_ver_BT, function_code="45")
def clean_source_ticket(matched_blocks: dict, input: Transfer_Bug_Block, bugs={}) -> bool:
    """
    Function to clean the source ticket after transferring bug blocks.

    Parameters:
        - matched_blocks: dict : Retrieved bug blocks that were transferred.
        - input: Transfer_Bug_Block object containing source_ticket_id, target_ticket_id, block_ids, updated_by.
        - bugs: Dictionary to collect errors, if any.

    Returns:
        - bool: True if cleaning was successful, False otherwise.
    """
    # Fetch the source ticket
    source_ticket_data, bugs_local = fetch_and_cache_bug_ticket(input.source_ticket_id)

    if bugs_local:
        logger_1.error(f"Failed to fetch source ticket with ID {input.source_ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return False

    if source_ticket_data is not None:
        
        # get the next available key
        last_key = max(map(int, source_ticket_data.keys()))
        next_available_key = last_key + 1
        
        for block_id, block_details in matched_blocks.items():
            bug_code = block_details["bug_code"]
            vehicle_num = block_details["vehicle_num"]

            # Remove the block from the source ticket
            if str(block_id) in source_ticket_data:
                del source_ticket_data[str(block_id)]
                logger_1.info(f"Removed block ID {block_id} from source ticket.")

            # Update the metadata block's bug_blocks field
            if bug_code in source_ticket_data["0"]["bug_blocks"]:
                if vehicle_num in source_ticket_data["0"]["bug_blocks"][bug_code]:
                    if block_id in source_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num]:
                        source_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num].remove(block_id)
                        logger_1.info(f"Removed block ID {block_id} from bug_blocks metadata in source ticket.")

                    # Remove vehicle_num if its block list is empty
                    if not source_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num]:
                        del source_ticket_data["0"]["bug_blocks"][bug_code][vehicle_num]
                        logger_1.info(f"Removed vehicle number {vehicle_num} from bug_blocks metadata in source ticket.")

                # Remove bug_code if no vehicle numbers are associated with it
                if not source_ticket_data["0"]["bug_blocks"][bug_code]:
                    del source_ticket_data["0"]["bug_blocks"][bug_code]
                    logger_1.info(f"Removed bug code {bug_code} from bug_blocks metadata in source ticket.")

        # Update metadata in the source ticket
        source_ticket_data["0"]["updated_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        source_ticket_data["0"]["updated_by"] = input.updated_by
        
        # Add a new status
        new_status_data = {
            "status_change_description": f"Bug blocks with bug code {bug_code} and vehicle number {vehicle_num} removed",
            "updated_by": input.updated_by,
        }
        
        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**new_status_data)
        
        # Add the new status block to the ticket
        source_ticket_data[str(next_available_key)] = status_serialized.model_dump()
        
        # Append the next available key to the status blocks list
        source_ticket_data["0"]["status_blocks"].append(next_available_key)
        
        # Extract the heading block
        heading_block = source_ticket_data.get("1", {})

        # Extract affected vehicles from heading block
        affected_vehicles = set(heading_block.get("affected_vehicles", []))

        # Check if the vehicle can be removed
        vehicle_can_be_removed = check_if_vehicle_can_be_removed(source_ticket_data, matched_blocks)

        # Remove vehicle from affected_vehicles if it is no longer associated with any bug block
        if vehicle_can_be_removed and vehicle_num in affected_vehicles:
            affected_vehicles.remove(vehicle_num)
            logger_1.info(f"Removed {vehicle_num} from affected_vehicles in source ticket.")

        # Update the heading block with the modified affected vehicles
        heading_block["affected_vehicles"] = list(affected_vehicles)
        source_ticket_data["1"] = heading_block

        # Write the updated source ticket back to the database or storage
        result, bugs_local = hiperft_bucket.write_json_to_s3(
            data_dict=source_ticket_data,
            s3_key=f"{bug_ticket_path}{str(input.source_ticket_id).zfill(5)}.json",
        )

        if bugs_local:
            logger_1.error(f"Failed to write updated source ticket back to S3, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return False

        logger_1.info(f"Source ticket {input.source_ticket_id} cleaned successfully.")

        # Checking for RDS cleanup
        logger_1.info(f"Checking for RDS cleanup")

        #  Call the new function to clean RDS
        return clean_source_ticket_rds(input.source_ticket_id, source_ticket_data, matched_blocks, bug_code, vehicle_num)

        
    logger_1.error(f"Source ticket with ID {input.source_ticket_id} not found.")
    return False






def check_if_same_bug_code_exists_in_another_bug_block(source_ticket : dict , matched_blocks : dict):
    
    """
    Function to check if a bug code already exists in another bug block.
    
    Params:
        - source_ticket: BugTicket object containing the details of the source ticket.
        
    Returns:
        - status : bool
        
        
    """
    
    # check how many bug blocks exists in the source ticket
    
    
    # if any other bug block doesn't exist in the source ticket other than the matched blocks, return False
    
    # else check if other bug blocks contain the same bug code, if so return True
    
    metadata = source_ticket.get("0")  # Get metadata block
    bug_blocks = metadata.get("bug_blocks")  # Extract "bug_blocks"

    for block_id, block_details in matched_blocks.items():
        bug_code = block_details["bug_code"]

        # If the bug code exists and has more than one vehicle, another bug block exists
        if bug_code in bug_blocks and len(bug_blocks[bug_code]) > 1:
            return True  # Another bug block exists

    return False  # No other bug blocks exist



def check_if_vehicle_can_be_removed(source_ticket: dict, matched_blocks: dict) -> bool:
    """
    Function to check if the vehicle number can be removed from the RDS record.
    
    Parameters:
        - source_ticket (dict): The source ticket JSON data.
        - matched_blocks (dict): The bug blocks being transferred.

    Returns:
        - bool: True if the vehicle number can be removed, False otherwise.
    """

    metadata = source_ticket.get("0", {})  # Get metadata block
    bug_blocks = metadata.get("bug_blocks", {})  # Extract bug_blocks

    for block_id, block_details in matched_blocks.items():
        bug_code = block_details["bug_code"]
        vehicle_num = block_details["vehicle_num"]

        # Check if vehicle exists under another bug code
        for other_bug_code, vehicles in bug_blocks.items():
            if other_bug_code != bug_code and vehicle_num in vehicles:
                return False  # Vehicle exists under another bug code, so do not remove it.

    return True  # Vehicle can be removed since it's not in any other bug code.



@error_handler(library_code=lib_code_ver_BT, function_code="50")
def clean_source_ticket_rds(source_ticket_id: int, source_ticket_data: dict, matched_blocks: dict, bug_code: str, vehicle_num: str, bugs={}) -> bool:
    """
    Function to clean the RDS record of the source ticket after transferring bug blocks.

    Parameters:
        - source_ticket_id (int): The ID of the source ticket.
        - source_ticket_data (dict): The source ticket JSON data.
        - matched_blocks (dict): The bug blocks being transferred.
        - bug_code (str): The bug code being removed.
        - vehicle_num (str): The vehicle number being removed.
        - bugs (dict): Dictionary to collect errors, if any.

    Returns:
        - bool: True if cleaning was successful, False otherwise.
    """
    
    logger_1.info(f"Checking for RDS cleanup for ticket {source_ticket_id}")

    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        #  Fetch the RDS record
        source_ticket_rds_record = ns.query(BT_RDS).filter(BT_RDS.id == source_ticket_id).first()

        if not source_ticket_rds_record:
            logger_1.error(f"Source ticket {source_ticket_id} not found in RDS.")
            return False

        #  Extract the device ID from matched blocks (only one device ID per block)
        device_id_to_remove = next(iter(matched_blocks.values()))["block_data"].get("device_id", None)

        #  Check if another bug block with the same bug code exists
        other_bug_blocks_exist = check_if_same_bug_code_exists_in_another_bug_block(source_ticket=source_ticket_data, matched_blocks=matched_blocks)

        logger_1.info(f"Status of other bug blocks exist: {other_bug_blocks_exist}")

        if not other_bug_blocks_exist:
            #  Remove the bug code from the RDS record
            existing_bug_codes = set(source_ticket_rds_record.bug_code.split(",")) if source_ticket_rds_record.bug_code else set()

            if bug_code in existing_bug_codes:
                existing_bug_codes.remove(bug_code)
                source_ticket_rds_record.bug_code = ",".join(existing_bug_codes)  # Convert back to string

                logger_1.info(f"Removed bug code {bug_code} from RDS record.")

        #  Check if the vehicle number should be removed
        vehicle_can_be_removed = check_if_vehicle_can_be_removed(source_ticket_data, matched_blocks)

        #  Fetch the existing vehicle numbers from RDS
        existing_vehicles = set(source_ticket_rds_record.vehicle_num.split(",")) if source_ticket_rds_record.vehicle_num else set()

        #  If the vehicle is not used in any other bug code, remove it from RDS
        if vehicle_can_be_removed and vehicle_num in existing_vehicles:
            existing_vehicles.remove(vehicle_num)
            source_ticket_rds_record.vehicle_num = ",".join(existing_vehicles)

            logger_1.info(f"Removed vehicle number {vehicle_num} from RDS record.")

        #  Remove device ID if it exists in RDS
        existing_device_ids = set(source_ticket_rds_record.device_id.split(",")) if source_ticket_rds_record.device_id else set()

        if device_id_to_remove and device_id_to_remove in existing_device_ids:
            existing_device_ids.remove(device_id_to_remove)
            source_ticket_rds_record.device_id = ",".join(existing_device_ids)

            logger_1.info(f"Removed device ID {device_id_to_remove} from RDS record.")

        # Commit the changes
        ns.commit()

        # remove the cached ticket
        redis_instance.delete_key(f"bug_ticket_{source_ticket_id}")

        
    
    return True



def report_bug_service(inputs: Report_Bug):
    """
    Function to add a bug block for a reported bug.

    Params:
    - inputs: Report_Bug object containing the details of the reported bug.

    Returns:
    - JSONResponse with success or failure message.
    """
    try:
        # Fetch the ticket from S3
        ticket_data, bugs_local = fetch_and_cache_bug_ticket(ticketid=inputs.ticketid)
        if bugs_local:
            logger_1.error(f"Failed to fetch ticket ID {inputs.ticketid}, {bugs_local}")
            return JSONResponse(
                {"error": "Failed to fetch ticket, cannot report the bug."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        if ticket_data is None:
            logger_1.error(f"Ticket ID {inputs.ticketid} does not exist.")
            return JSONResponse(
                {"error": f"Ticket ID {inputs.ticketid} does not exist."},
                status_code=http_status.HTTP_404_NOT_FOUND
            )

        # Extract metadata and bug blocks
        metadata = ticket_data["0"]
        existing_bug_blocks = metadata.get("bug_blocks", {})

        # Determine the new bug code
        ticket_id_str = str(inputs.ticketid).zfill(2)  # Ensure 2 characters for ticket ID
        last_bug_count = max(
            [int(block_id[-2:]) for block_id in existing_bug_blocks.keys() if block_id.startswith("UD")],
            default=0
        )
        new_bug_count = last_bug_count + 1
        new_bug_code = f"UD{ticket_id_str}00{str(new_bug_count).zfill(2)}"  # Ensure 8 characters

        # Use user-provided vehicle number or fallback to "no_veh_number"
        vehicle_num = inputs.vehicle_num if inputs.vehicle_num else "no-veh-number"
        dvc_id = inputs.device_id if inputs.device_id else "no-device-id"

        # Prepare the new bug block
        bug_block = BugBlock(
            type="2",
            bug_code=new_bug_code,
            vehicle_num=vehicle_num,
            device_id=dvc_id,
            instance_count=0,
            added_by=inputs.reported_by,
            machine_raised=False,
            last_active=get_current_date(),
            user_defined_bug=inputs.bug_noted
        )

        # Serialize and add the new bug block
        last_key = max(map(int, ticket_data.keys()))
        next_available_key = last_key + 1  # Ensure `block_id` is an integer
        ticket_data[str(next_available_key)] = bug_block.model_dump()

        # Update metadata with the new bug block
        if "bug_blocks" not in metadata:
            metadata["bug_blocks"] = {}

        # Format: bug_code -> { vehicle_number: [block_ids] }
        if new_bug_code not in metadata["bug_blocks"]:
            metadata["bug_blocks"][new_bug_code] = {vehicle_num: [next_available_key]}
        else:
            if vehicle_num in metadata["bug_blocks"][new_bug_code]:
                metadata["bug_blocks"][new_bug_code][vehicle_num].append(next_available_key)
            else:
                metadata["bug_blocks"][new_bug_code][vehicle_num] = [next_available_key]
                
                
        # add a new status
        new_status_data = {
            "status_change_description": f"Bug block with bug code {new_bug_code} added",
            "updated_by": str(inputs.reported_by),
        }
        
        # Serialize the new status data
        status_serialized = StatusChangeBlock(**new_status_data)
        
        # fetch the last key in the ticket
        next_available_key_for_status = next_available_key + 1
        
        # add the new status block to the ticket
        ticket_data[str(next_available_key_for_status)] = status_serialized.model_dump()
        
        # append the next available key to the status blocks list
        metadata["status_blocks"].append(next_available_key_for_status)


        # Update the ticket in S3
        updated_ticket, bugs_local = hiperft_bucket.write_json_to_s3(
            s3_key=f"{bug_ticket_path}{str(inputs.ticketid).zfill(5)}.json",
            data_dict=ticket_data
        )

        if bugs_local:
            logger_1.error(f"Failed to update ticket in S3, {bugs_local}")
            return JSONResponse(
                {"error": "Failed to update the ticket with the new bug."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # Success response
        logger_1.info(f"Bug reported successfully for ticket ID {inputs.ticketid}")
        
        # Delete the cached bug ticket
        redis_instance.delete_key(f"bug_ticket_{inputs.ticketid}")
        
        # get the latest ticket now
        latest_bug_ticket, bugs_local = fetch_and_cache_bug_ticket(inputs.ticketid)
        
        if bugs_local:
            logger_1.error(f"Failed to fetch the latest ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                {"error": "Failed to fetch the latest ticket."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )
            
        elif latest_bug_ticket is not None:
            return JSONResponse(
                {"message": "Bug reported successfully.", "ticket": latest_bug_ticket},
                status_code=http_status.HTTP_200_OK
            )
            
        else:
            return JSONResponse(
                {"error": "Failed to fetch the latest ticket."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    except Exception as e:
        logger_1.error(f"Error occurred while reporting bug: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred while reporting bug."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )

