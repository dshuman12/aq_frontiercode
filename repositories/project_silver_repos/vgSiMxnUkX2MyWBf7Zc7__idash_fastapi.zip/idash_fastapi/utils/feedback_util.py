# Import inbuilt libraries


# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
import pandas as pd
from utils.feature_tickets_util import fetch_and_cache_ticket, handle_ticket_update_for_s3, update_metadata

# Include repos folder for custom libraries


# Declare variables used 
# Library Code for Feedback Module
lib_code_FM = "28"
lib_ver_FM = "00"

lib_code_ver_FM = f"{lib_code_FM}{lib_ver_FM}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.feedback_util import *
from utils.attachment_util import *
from schema.feedback_schema import *
from hiper_utils.data_models.s3_data_models.common_models import StatusChangeBlock, TasksBlock



# initialize the logger
logger_1 = LoggerFactory(name="feedback_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model


# define other funcs



@error_handler(library_code=lib_code_ver_FM,function_code="01")
def add_feedback_service(feedback: AddFeedback_Input, bugs={}):
    '''
    Service function to add a feedback

    params: feedback object

    return : ticket object with feedback added, else None in case of error

    '''

    # call the fetch_and_cache_ticket to get the ticket details
    ticket_s3_data,bugs_local = fetch_and_cache_ticket(ticketid=feedback.ticket_id,ticket_type=feedback.ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching ticket details, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None


    elif ticket_s3_data is not None:
                         
            # add the feedback block to the ticket
            last_key_in_ticket = list(ticket_s3_data.keys())[-1]

            block_id_for_feedback = int(last_key_in_ticket) + 1

            attachment_list = []

            if feedback.attachments is not None:

                # upload the attachments to s3
                attachment_list, bugs_local = upload_attachments_to_s3(attachments=feedback.attachments,ticket_type=feedback.ticket_type,ticket_master_id=int(feedback.ticket_id),block_id=block_id_for_feedback)

                if bugs_local:
                    logger_1.error(f"Error in uploading attachments, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif attachment_list is not None:
                    logger_1.info(f"Attachments uploaded successfully, {attachment_list}")
                
            
            # add a feedback block
            new_feedback_block = {
                    'type': '8',
                    'added_by': feedback.added_by,
                    'related_prototype_block': feedback.related_prototype_block,
                    'result_summary': feedback.result_summary,
                    'attachments': attachment_list 
                }

            # serialize the feedback block
            serialized_feedback_block = FeedbackBlock(**new_feedback_block)

            ticket_s3_data[block_id_for_feedback] = serialized_feedback_block.model_dump()

            # in the metadata, update the feedback_block where the key is the related_prototype_block and value is the list of feedback blocks
            metadata = ticket_s3_data['0']

            feedback_block = metadata.get('feedback_block', {})
            
            # if there is key value pair in the feedback block, add related prototype block as key and value as a list of feedback block_ids
            if str(feedback.related_prototype_block) in feedback_block:
                feedback_block[str(feedback.related_prototype_block)].append(str(block_id_for_feedback))
            else:
                feedback_block[str(feedback.related_prototype_block)] = [str(block_id_for_feedback)]

            
            # fetch the key for status block
            status_block_id = int(block_id_for_feedback) + 1

            status_block = {
                'status_change_description': f'Feedback added for prototype block {feedback.related_prototype_block}',
                'updated_by': feedback.added_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the status block to the ticket_data
            ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()
            
            metadata['status_blocks'].append(str(status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, feedback.added_by)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                
                # call the handle ticket for s3 function
                updated_ticket, bugs_local = handle_ticket_update_for_s3(feedback.ticket_id, ticket_s3_data, feedback.added_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif updated_ticket is not None:
                    logger_1.info(f"Ticket updated successfully")
                    return updated_ticket
                

                