# Import inbuilt libraries
import os
from datetime import datetime
from typing import Optional, Tuple, List, Dict



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException


# Include repos folder for custom libraries


# Declare variables used 
# Library code for device onboarding
lib_code_DOL = "55"
lib_ver_DOL = "00"

lib_code_ver_DOL = f"{lib_code_DOL}{lib_ver_DOL}"



# Path to storage_settings.py
storage_settings_path = "storage_settings.py"


# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler
from storage_settings import rds_instance, hiperft_bucket, hw_img, get_current_date, GLOBAL_TEMP_DIR,device_info,imu_config,can_config,pre_prod_path,prod_bin_path,edge_config_path,hw_reg_path
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import HWUno2, DeviceRegistrationNew as DR
from utils.bug_tickets_util import handle_bugs
from schema.device_onboarding_schema import *




# initialize the logger
logger_1 = LoggerFactory(name="device_onboarding_routes", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model

# define other funcs


# Define the function to process hardware images
@error_handler(library_code=lib_code_ver_DOL, function_code="01")
def process_hw_images(imei_no: str, images: List, bugs={}) -> Tuple[bool, Dict]:
    """
    Processes hardware images and uploads them to S3.

    Parameters:
    - imei_no: str - IMEI number of the hardware device.
    - images: List[UploadFile] - List of images to be uploaded.

    Returns:
    - Tuple[bool, Dict]:
        - bool: True if all images are uploaded successfully, False otherwise.
        - Dict: Contains error details if any images fail to upload.
    """
    upload_success = True  # Aggregate success flag
    upload_path = hw_img.replace("imei_number", imei_no)  # Predefined S3 path
    count = 1  # Initialize the counter for naming files

    for image in images:
        try:
            # Generate S3 key based on timestamp, count, and IMEI
            timestamp = get_current_date()
            s3_key = f"{upload_path}{timestamp}_{count}"
            count += 1  # Increment the counter

            # Save the image temporarily to the global directory
            temp_path = os.path.join(GLOBAL_TEMP_DIR, image.filename)
            with open(temp_path, "wb") as temp_file:
                temp_file.write(image.file.read())  # Directly read and save the file

            # Upload the file to S3
            upld_status = hiperft_bucket.upload_file_to_s3(temp_path, s3_key)

            if not upld_status:
                logger_1.error(f"Error occurred during image upload: {image.filename}")
                upload_success = False  # Mark aggregate as False

        except Exception as e:
            logger_1.error(f"Error occurred during image upload: {e}")
            upload_success = False  # Mark aggregate as False

        finally:
            # Clean up the temporary file
            if os.path.exists(temp_path):
                os.remove(temp_path)

    return upload_success



# func to download the files for device preparation
@error_handler(library_code=lib_code_ver_DOL, function_code="04")
def get_all_files(device_id: str, make_model: str, bugs={}) -> dict:
    """
    Fetch all required files.
    
    params : 
        - device_id : id of the device
        - make_model : make and model of the device
        
    return :
        - zip_file : zip file containing all the required files
        - bugs : in case of bugs
    
    """
    
    files = {}
    
    # call get_device_info func to get the device info bin
    dev_info_bin, bugs_local = get_device_info(device_id)
    
    if bugs_local:
        logger_1.error(f"Failed to download device bin file")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    files["device_info.bin"] = dev_info_bin
    
    # call fetch_imu_config func to get the imu config file
    imu_config_file, bugs_local = fetch_imu_config(make_model)
    
    if bugs_local:
        logger_1.error(f"Failed to download imu config file")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    files["imu_cfg.bin"] = imu_config_file
    
    # call fetch_can_config func to get the can config file
    can_config_file, bugs_local = fetch_can_config(make_model)
    
    if bugs_local:
        logger_1.error(f"Failed to download can config file")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    files["can_cfg.bin"] = can_config_file
    
    # call fetch_pre_prod_file func to get the pre prod file
    pre_prod_file, bugs_local = fetch_pre_prod_file()
    
    if bugs_local:
        logger_1.error(f"Failed to download pre prod file")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    files["pre_prod.bin"] = pre_prod_file
    
    
    # call fetch_edge_config file to get the edge config file
    edge_config_file, bugs_local = fetch_edge_config(make_model)
    
    if bugs_local:
        logger_1.error(f"Failed to download edge config file")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    files["edge_cfg.bin"] = edge_config_file
    
    #logger_1.info(f"files are {files}")
    
    # create a zip file
    zipped_file,bugs_local = hiperft_bucket.create_zip_file(files)
    
    if bugs_local:
        logger_1.error(f"Failed to create zip file, {bugs_local}")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    return zipped_file
    
    

# func to get the device info
@error_handler(library_code=lib_code_ver_DOL, function_code="05")
def get_device_info(device_id: str, bugs={}) -> str:
    """
    
    Fetch the device info file.
    
    params : 
        - device_id : id of the device 
    
    return :
        - bin_file : device info file   
    """
    
    # path to device info 
    dev_info_pth = device_info.replace("device_id", device_id)
    
    logger_1.info(f"Device info path is {dev_info_pth}")
    
    # download the file
    dev_inf_file = hiperft_bucket.download_file_from_s3(dev_info_pth)
    
    #logger_1.info(f"Device info file is {dev_inf_file}")
        
    return dev_inf_file



    
# func to download the imu config file
@error_handler(library_code=lib_code_ver_DOL, function_code="06")
def fetch_imu_config(make_model : str, bugs={}):
    """
    Fetch the imu config file.
    
    params : 
        - make_model : make and model of the device
    
    return :
        - imu_config : imu config file
        - bugs : in case of bugs
    """
    
    # path to imu config file
    imu_config_pth = imu_config.replace("m_m_id", make_model)
    
    # download the file
    imu_config_file = hiperft_bucket.download_file_from_s3(imu_config_pth)
    
    return imu_config_file


# func to download the can config file
@error_handler(library_code=lib_code_ver_DOL, function_code="07")
def fetch_can_config(make_model : str, bugs={}):
    
    """
    
    Fetch the can config file.
    
    params : 
        - make_model : make and model of the device
        
    return :
        - can_config : can config file
    
    """
    
    # path to can config file
    can_config_pth = can_config.replace("m_m_id", make_model)
    
    # download the file
    can_config_file = hiperft_bucket.download_file_from_s3(can_config_pth)
    
    return can_config_file

# func to download the pre prod file
@error_handler(library_code=lib_code_ver_DOL, function_code="08")
def fetch_pre_prod_file(bugs={}) -> str:
    """
    Fetch the pre prod file.
    
    return :
        - pre_prod_file : pre prod file
        - bugs : in case of bugs
    """
    
    # download the pre prod file
    pre_prod_file = hiperft_bucket.download_file_from_s3(pre_prod_path)
    
    return pre_prod_file

# Function to download the production bin file
@error_handler(library_code=lib_code_ver_DOL, function_code="09")
def fetch_prod_bin():
    """
    Fetch the production bin file.

    Returns:
        - prod_bin_zip : production bin file as a zip
    """
    files = {}

    # Extract and normalize the filename from the prod_bin_path
    prod_bin_filename = os.path.basename(prod_bin_path).replace(" ", "_")

    # Download the production bin file from S3
    prod_bin_file = hiperft_bucket.download_file_from_s3(prod_bin_path)

    # Use the normalized filename in the files dictionary
    files[prod_bin_filename] = prod_bin_file

    # Create a zip file containing the production binary
    prod_bin_zip, bugs_local = hiperft_bucket.create_zip_file(files)

    if bugs_local:
        logger_1.error(f"Failed to create zip file, {bugs_local}")
        bugs = handle_bugs(bugs, bugs_local)
        return None

    return prod_bin_zip



@error_handler(library_code=lib_code_ver_DOL, function_code="02")
def check_onboard_stage(device_id: str) -> Optional[int]:
    """
    Check the onboard status of the hardware device.
    
    Args:
        device_id (str): The unique device ID to query.
        
    Returns:
        Optional[int]: The onboarding stage of the hardware device, or None if not found.
    """
    session = rds_instance.get_connection()

    try:
        with handle_session(session) as ns:
            # Join DeviceRegistration (DR) and HWUno2 tables on hw_serial
            result = (
                ns.query(HWUno2.onboarding_stage)
                .join(DR, DR.hw_serial == HWUno2.hw_serial)
                .filter(DR.device_id == device_id)
                .first()
            )
            
            if result:
                logger_1.info(f"Onboarding stage for device ID {device_id} is {result.onboarding_stage}")
                return result.onboarding_stage
            else:
                logger_1.warning(f"No onboarding stage found for device ID {device_id}")
                return None

    except Exception as e:
        logger_1.error(f"Error occurred while fetching onboarding stage for device ID {device_id}: {e}")
        return None


    

def check_hw_registered_or_register(imei_no: str) -> bool:
    """
    Checks if the hardware device is registered. If not, registers it.

    Parameters:
        - imei_no: str: IMEI number of the hardware device.

    Returns:
        - tuple: (bool, dict): Registration status and bugs dictionary.
            - True: Device is registered and can proceed.
            - False: Device is marked with issues and cannot be registered.
            - dict: Bugs encountered during the operation.
    """
    
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Check if the device exists in the database
        device = ns.query(HWUno2).filter(HWUno2.imei == imei_no).first()

        if device:
            logger_1.info(f"Device {imei_no} found in the database with QA status: {device.QA}")
            if device.QA in (0, 2):
                # Device is marked with issues
                return False
            else:
                # Device exists and is valid
                return True

        # Register the device if it does not exist
        new_device = HWUno2(imei=imei_no, QA=1)  # Assuming `1` indicates valid registration
        ns.add(new_device)
        ns.commit()
        logger_1.info(f"Device {imei_no} successfully registered.")
        return True
    
    
# function to mark the qa as 0
def mark_qa_as_failed(imei_no: str) -> bool:
    """
    Marks the QA status of a hardware device as failed (0).

    Parameters:
        - imei_no: str: IMEI number of the hardware device.

    Returns:
        - tuple: (bool, dict): Update status and bugs dictionary.
            - True: If the QA status was successfully updated.
            - False: If the operation failed.
    """
    
    session = rds_instance.get_connection()

    try:
        with handle_session(session) as ns:
            # Find the device in the database
            device = ns.query(HWUno2).filter(HWUno2.imei == imei_no).first()

            if not device:
                logger_1.error(f"Device with IMEI {imei_no} not found.")
                return False, {"error": f"Device with IMEI {imei_no} not found."}

            # Update the QA status to 0
            device.QA = 0
            ns.commit()
            logger_1.info(f"QA status for device {imei_no} marked as failed.")
            return True

    except Exception as e:
        logger_1.error(f"Error during QA status update for IMEI {imei_no}: {e}")
        return False

def check_hw_status(imei_no: str) -> int:
    """
    Checks the QA status of a hardware device.

    Parameters:
        - imei_no: str: IMEI number of the hardware device.

    Returns:
        - tuple: (int, dict): QA status of the device and bugs dictionary.
            - Value: The integer value of the QA status (e.g., 0, 1, 2).
            - Bugs: A dictionary with errors encountered during the query.
    """
    
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # Query the QA status
        result = ns.query(HWUno2.QA).filter(HWUno2.imei == imei_no).first()

        if not result:
            logger_1.error(f"No record found for IMEI {imei_no}.")
            return None

        qa_status = result[0]
        logger_1.info(f"QA status for IMEI {imei_no} is {qa_status}")
        return qa_status


# func to fetch edge config file
@error_handler(library_code=lib_code_ver_DOL, function_code="10")
def fetch_edge_config(make_model,bugs={}) -> str:
    """
    Fetch the edge config file.
    
    return :
        - edge_config_file : edge config file
        - bugs : in case of bugs
    """
    
    # replace the m_m_id with make_model
    edge_config_pth = edge_config_path.replace("m_m_id", make_model)
    
    try:
        # download the edge config file
        edge_config_file = hiperft_bucket.download_file_from_s3(edge_config_pth)
        
        return edge_config_file
        
    except Exception as e:
        logger_1.error(f"Error occurred during edge config file download: {e}")
        return None



# function to download the hw files
@error_handler(library_code=lib_code_ver_DOL, function_code="11")
def get_hw_files(bugs={}) -> zip:
    
    """
    
    Fetch the required hardware files.
    
    return :
        - hw_files : hardware file zip
    
    """
    
    files = {}
    
    # downlooad the hw flash file
    hw_flash_file = hiperft_bucket.download_file_from_s3(hw_reg_path)
    
    files['hardware_reg.bin'] = hw_flash_file
    
    # create a zip file
    hw_files,bugs_local = hiperft_bucket.create_zip_file(files)
    
    if bugs_local:
        logger_1.error(f"Failed to create zip file, {bugs_local}")
        bugs = handle_bugs(bugs,bugs_local)
        return None
    
    return hw_files



def upload_file_to_s3(file_path: str, s3_key: str):
    """
    Uploads a file to S3.

    Parameters:
    - file_path: The local path to the file to be uploaded.
    - s3_key: The key (path) where the file will be stored in the S3 bucket.

    Returns:
    - True if the upload is successful.
    """
    try:
        upld_sts = hiperft_bucket.upload_file_to_s3(file_path, s3_key)
        
        if upld_sts:
            logger_1.info(f"File uploaded successfully to S3: {s3_key}")
            
        return True
    
    except Exception as e:
        logger_1.error(f"Failed to upload file to S3: {str(e)}")
        return False


def update_storage_settings(new_path: str):
    """
    Update the production file path in storage_settings.py.

    Parameters:
    - new_path: The new S3 path to be set for the production file.
    """
    try:
        # Read the current storage_settings.py
        with open(storage_settings_path, "r") as file:
            lines = file.readlines()

        # Update the prod_bin_path line
        with open(storage_settings_path, "w") as file:
            for line in lines:
                if line.startswith("prod_bin_path ="):
                    file.write(f'prod_bin_path = "{new_path}"\n')
                else:
                    file.write(line)

        print(f"Updated storage_settings.py with new prod_bin_path: {new_path}")

        return True
    
    except Exception as e:
        logger_1.error(f"Failed to update storage_settings.py: {str(e)}")
        return False
    
    
