import unittest
from unittest.mock import patch, MagicMock
from hiper_utils.data_models.s3_data_models.bug_ticket import MetadataBlock, HeadingBlock, BugBlock
from hiper_utils.other_utils.bug_util_up import BugHandler, BugTicket, hiperft_bucket,db




class TestBugHandler(unittest.TestCase):
    @patch(hiperft_bucket)
    @patch(db)
    def test_add_bug_creates_new_ticket(self, mock_db, mock_s3):
        # Mock S3 interactions
        mock_s3.download_json.return_value = ({}, {})  # Simulate no existing ticket
        mock_s3.write_json_to_s3.return_value = (True, {})  # Simulate successful S3 write

        # Mock database interactions
        session_mock = MagicMock()
        mock_db.get_connection.return_value = session_mock
        mock_bt_rds = MagicMock()
        session_mock.query.return_value.filter.return_value.first.return_value = None  # Simulate no matching ticket

        # Simulate new ticket creation in RDS
        new_ticket = MagicMock()
        new_ticket.id = 1001
        session_mock.add.return_value = None
        session_mock.flush.return_value = None
        session_mock.commit.return_value = None
        session_mock.query.return_value.filter.return_value.first.return_value = new_ticket

        # Instantiate the BugHandler
        bug_handler = BugHandler()

        # Input data
        bug_obj = {
            "BUG123": {"message": "Example bug message", "input_data": {"key": "value"}}
        }
        raised_by = 1
        ticket_name = "Test Bug Ticket"
        assigned_team = "Team Alpha"
        vehicle_num = "VEH001"
        device_id = "DEV001"

        # Call add_bug
        adding_succeeded, bugs = bug_handler.add_bug(
            bug_obj=bug_obj,
            raised_by=raised_by,
            ticket_name=ticket_name,
            assigned_team=assigned_team,
            vehicle_num=vehicle_num,
            device_id=device_id
        )

        # Assertions
        self.assertTrue(adding_succeeded)
        self.assertEqual(bugs, {})  # No bugs encountered
        mock_s3.write_json_to_s3.assert_called_once()  # Ensure ticket was saved to S3

    @patch(hiperft_bucket)
    @patch(db)
    def test_add_bug_updates_existing_ticket(self, mock_db, mock_s3):
        # Mock S3 interactions
        mock_s3.download_json.return_value = ({
            "0": MetadataBlock(
                type="0",
                created_by=1,
                bug_blocks={"BUG123": {"VEH001": [2]}}
            ).model_dump(),
            "1": HeadingBlock(
                ticket_master_id=1001,
                ticket_name="Existing Ticket",
                affected_vehicles=["VEH001"]
            ).model_dump(),
            "2": BugBlock(
                type="2",
                bug_code="BUG123",
                vehicle_num="VEH001",
                device_id="DEV001",
                instance_count=1,
                added_by=1,
                machine_raised=True,
                last_active="2024-11-26"
            ).model_dump()
        }, {})  # Simulate existing ticket
        mock_s3.write_json_to_s3.return_value = (True, {})  # Simulate successful S3 write

        # Mock database interactions
        session_mock = MagicMock()
        mock_db.get_connection.return_value = session_mock
        mock_bt_rds = MagicMock()
        session_mock.query.return_value.filter.return_value.first.return_value = mock_bt_rds

        # Instantiate the BugHandler
        bug_handler = BugHandler()

        # Input data
        bug_obj = {
            "BUG123": {"message": "Updated bug message", "input_data": {"key": "new_value"}}
        }
        raised_by = 1
        vehicle_num = "VEH001"
        device_id = "DEV001"

        # Call add_bug
        adding_succeeded, bugs = bug_handler.add_bug(
            bug_obj=bug_obj,
            raised_by=raised_by,
            vehicle_num=vehicle_num,
            device_id=device_id
        )

        # Assertions
        self.assertTrue(adding_succeeded)
        self.assertEqual(bugs, {})  # No bugs encountered
        mock_s3.write_json_to_s3.assert_called_once()  # Ensure updated ticket was saved to S3


if __name__ == "__main__":
    unittest.main()

