import sys

sys.path.append("../../")

from idash_fastapi.storage_settings import prod_rds_instance


from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleDeviceLogs
from hiper_utils.other_utils.vehicles_util import VehicleSummary
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.Decoraters.exception_handler import error_handler

class TripClassificationUtil:

    def __init__(self, vehicle_id: str, fleet_name: str):
        self.vehicle_id = vehicle_id
        self.fleet_name = fleet_name


    @error_handler(library_code="01", function_code="01")
    def find_active_device_during_time(self, timestamp: str):
        """
        Finds the active device during the given timestamp by checking the vehicle_device_logs for specific vehicle records.
        
        Each vehicle can have multiple device entries.
        
        Attempts to find the entry where the current given date-time is less than the nearest last_ping_time entry.
        
        If the given timestamp is smaller than two or more entries in vehicle_device_logs, it will return the nearest device entry
        with the smallest difference between last_ping_time and the given timestamp.
        """
        session = prod_rds_instance.get_connection()
        with handle_session(session) as ns:
            query = (
                ns.query(VehicleDeviceLogs.device_id)
                .filter(
                    VehicleDeviceLogs.vehicle_num == self.vehicle_id,
                    VehicleDeviceLogs.last_ping_time >= timestamp
                )
                .order_by(VehicleDeviceLogs.last_ping_time.asc())  # Get earliest matching record
                .limit(1)
                .first()
            )
            return query[0] if query else None

    @error_handler(library_code="01", function_code="02")
    def get_trip_metrics_from_log_file(self, trip_start_time: str, start_file_number: int, end_file_number: int):


        active_device_during_trip, bug = self.find_active_device_during_time(trip_start_time)

        if active_device_during_trip is None:
            raise Exception(f"No active device found for vehicle {self.vehicle_id} at timestamp {trip_start_time}")
        
        print(f"Active device during trip: {active_device_during_trip}")
        
        summary_file = VehicleSummary(vehicle_num=self.vehicle_id, fleet_name=self.fleet_name)

        trip_metrics, bugs = summary_file.get_trip_metrics(device_id=active_device_during_trip, start_file=start_file_number, end_file=end_file_number)

        return trip_metrics






if __name__ == "__main__":

    trip_classification_util = TripClassificationUtil("TN30BR9702","Tharai")
    # device_id = trip_classification_util.find_device_id_for_vehicle("2022-01-10 11:20:17")

    # print(device_id)

    trip_metrics, bugs = trip_classification_util.get_trip_metrics_from_log_file("2025-03-13 16:27:09", 63, 66)

    print(trip_metrics)
    print(bugs)
