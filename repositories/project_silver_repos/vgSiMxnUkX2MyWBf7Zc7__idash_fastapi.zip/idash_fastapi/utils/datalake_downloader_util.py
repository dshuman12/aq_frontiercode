# Import inbuilt libraries


# Import third party libraries
import io
import json
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List
import pandas as pd
from sqlalchemy import inspect
from sqlalchemy import Table, MetaData, select
from sqlalchemy.orm import sessionmaker

# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for datalake downloader library
lib_code_DDL = "22"
lib_ver_DDL = "00"

lib_code_ver_DDL = f"{lib_code_DDL}{lib_ver_DDL}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.datalake_downloader_schema import *
from hiper_utils.other_utils.resource_util import S3ResourceBase, CRUDBase
from storage_settings import prod_rds_instance
from hiper_utils.data_models.rds_data_models import *
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import Base
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session

# Initialize the logger
logger_1 = LoggerFactory(name="datalake_downloader_util", file_name="message.log").get_logger()


# function to get file
@error_handler(library_code=lib_code_ver_DDL, function_code="01")
def get_file(pth : str):
    
    S3_Instance = S3ResourceBase(pth)

    # Check if file exists before accessing data
    if S3_Instance.resource_exists:
        file = S3_Instance.data  # Use `.data` instead of calling `read()`
        return file
    
    else:
        logger_1.error("File not found")    
        return None