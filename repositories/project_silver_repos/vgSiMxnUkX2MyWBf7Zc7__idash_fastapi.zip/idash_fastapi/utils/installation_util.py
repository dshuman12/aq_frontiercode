import sys

sys.path.append("../")

import csv
from typing import List, Dict
from datetime import datetime
import struct
import math
import pandas as pd
import cbor2
import json

from hiper_utils.aws.s3.s3 import S3Bucket
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB, handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import DeviceSoftwareVersions

from sqlalchemy import func

from schema.insatllation_dash_schema import *


def calculate_checksum(data):
    """Calculate checksum by summing all bytes modulo 256."""
    return sum(data) % 256


class LogConfig:
    MASTER_PID_COLUMN = 'master_pid'
    PARAM_NAME_COLUMN = 'vehicle_param_name'

    def __init__(self, make_model: str, remark_by_user: str = ""):

        self.hiperdatalake = S3Bucket(
            bucket_name="hiperdatalake"
        )

        self.new_prod_schema = MySQLDB(
            db_name="new_production_schema",
            env_var_prefix="MYSQL"
        )

        self.make_model = make_model
        self.remark_by_user = datetime.now().strftime("%Y-%m-%d %H:%M:%S") if not remark_by_user else remark_by_user
        self.req_param_pth = f'make model/{make_model}/PARAM_LIST_REQ_{make_model}.csv'
        self.broad_param_pth = f'make model/{make_model}/PARAM_LIST_BRD_{make_model}.csv'
        self.master_param_pth = f'make model/MASTER_PARAM_LIST.csv'

        self.server_log_config: ServerLogConfigFile = None
        self.device_log_config_binary: DeviceConfigBinary = None
        self.device_log_config: DeviceLogConfigFile = None

        self.version_to_assign = self.get_version_for_config()

    def get_version_for_config(self):

        session = self.new_prod_schema.get_connection()

        with handle_session(session) as ns:
            max_version = ns.query(func.max(DeviceSoftwareVersions.version)).filter(
                DeviceSoftwareVersions.software_type == "CAN_CONFIG",
                DeviceSoftwareVersions.make_model == self.make_model
            ).scalar()

            next_version = (max_version or 0) + 1

            print(f"*** Next Version to assign {next_version}")

            return next_version

    def update_new_config_version(self):
        session = self.new_prod_schema.get_connection()
        with handle_session(session) as ns:
            new_record = DeviceSoftwareVersions(
                software_type="CAN_CONFIG",
                version=self.version_to_assign,
                added_by=28,
                added_on=datetime.utcnow(),
                git_commit=self.remark_by_user,
                make_model=self.make_model
            )

            ns.add(new_record)
            ns.commit()

            print(f"*** Updated CAN CONFIG for {self.make_model} to version {self.version_to_assign}")

    def create_can_data_server_format(self, user_selected_req_param, user_selected_broad_param):

        formatted_can_params = []

        can_param_data = self.fetch_can_param_list()

        if can_param_data is not None:

            req_param_df, broad_param_df = can_param_data
            req_param_df.set_index(self.MASTER_PID_COLUMN, inplace=True)
            broad_param_df.set_index(self.MASTER_PID_COLUMN, inplace=True)

            response_id, request_id = req_param_df['response_id'].iloc[0], req_param_df['request_id'].iloc[0]
            for req_param in user_selected_req_param:
                param_info = req_param_df.loc[req_param.master_pid]
                can_param = self.create_can_param(
                    req_param,
                    param_info,
                    {
                        "type": "REQ",
                        "service_id": int(param_info['service_id']),
                        "low_byte": param_info['low_byte'],
                        "high_byte": int(param_info['high_byte'])
                    }
                )

                formatted_can_params.append(can_param)

            for broad_param in user_selected_broad_param:
                param_info = broad_param_df.loc[broad_param.master_pid]
                can_param = self.create_can_param(
                    broad_param,
                    param_info,
                    {
                        "type": "BRD",
                        "pgn_id": param_info['pgn'],
                        "start_byte": int(param_info['start_byte']),
                        "start_bit": int(param_info['start_bit'])
                    }
                )
                formatted_can_params.append(can_param)

            return formatted_can_params, request_id, response_id

    @staticmethod
    def create_can_param(param, param_info, device_params):
        can_param = CANParam(
            **dict(param),
            multiplier=param_info['multiplier'],
            offset=param_info['offset'],
            min=param_info['min'],
            max=param_info['max'],
            device_params=device_params
        )

        protocol = param_info['protocol']
        if protocol == 1:
            can_param.endian = Endian.BIG
        elif protocol == 0:
            can_param.endian = Endian.LITTLE
        elif protocol == 2:
            can_param.endian = Endian.BIG
            can_param.is_signed = True

        can_param.units = param_info['unit']
        can_param.length = float(param_info['size_in_bytes'])
        return can_param

    @staticmethod
    def parse_can_params_for_device_config(server_log_config_file: ServerLogConfigFile, req_id: str, resp_id: str,
                                           user_submitted_data: UserLogConfigForm) -> CANConfig:
        server_log_config_file = server_log_config_file.model_dump()
        can_params = server_log_config_file['CAN']

        # Create a dictionary to group broadcast parameters by PGN ID
        pgn_dict = {}
        request_params_list = []

        for param in can_params:
            if param['device_params']['type'] == 'BRD':
                pgn_id = param['device_params']['pgn_id']
                broadcast_param = BroadcastParam(
                    length=param['length'],
                    start_byte=param['device_params']['start_byte'],

                )
                if pgn_id not in pgn_dict:
                    pgn_dict[pgn_id] = PGNCfg(pgn_id=pgn_id, broadcast_param=[])
                pgn_dict[pgn_id].broadcast_param.append(broadcast_param)

            elif param['device_params']['type'] == 'REQ':
                request_param = RequestParamCfg(
                    service_id=param['device_params']['service_id'],
                    pid1=param['device_params']['low_byte'],
                    pid2=param['device_params']['high_byte'],
                    length=param['length']
                )
                request_params_list.append(request_param)

        # Convert dictionary to list
        pgn_cfg_list = list(pgn_dict.values())
        request_resp_cfg = [
            RequestRespCfg(request_id=req_id, response_id=resp_id, request_param_cfg=request_params_list)]
        can_config = CANConfig(data_mode=user_submitted_data.can_data_mode, baud_rate=user_submitted_data.can_baud_rate,
                               pgn_cfg=pgn_cfg_list, request_resp_cfg=request_resp_cfg)

        return can_config

    def create_device_log_config(self, server_log_config_file: ServerLogConfigFile,
                                 user_submitted_data: UserLogConfigForm, req_id, res_id):

        can_source = DeviceCANSource(
            can_cfg=self.parse_can_params_for_device_config(
                server_log_config_file=server_log_config_file,
                req_id=req_id,
                resp_id=res_id,
                user_submitted_data=user_submitted_data
            )
        )

        gps_config = DeviceGPSConfig(
            num_param_log=user_submitted_data.GPS
        )

        gps_source = DeviceGPSSource(gps_cfg=gps_config)

        i2c_data = user_submitted_data.i2c

        ax_info = i2c_data[0]
        ay_info = i2c_data[1]
        az_info = i2c_data[2]
        gyro_info = i2c_data[3]

        acc_bucket = AccBucket(
            ax_bucket_config=[[ax_info.bucket_range_low[ind], ax_info.bucket_range_high[ind]] for ind in
                              range(ax_info.num_buckets)],
            ay_bucket_config=[[ay_info.bucket_range_low[ind], ay_info.bucket_range_high[ind]] for ind in
                              range(ay_info.num_buckets)],
            az_bucket_config=[[az_info.bucket_range_low[ind], az_info.bucket_range_high[ind]] for ind in
                              range(az_info.num_buckets)],
        )

        gyro_bucket = GyroBucket(
            gyro_bucket_config=[[gyro_info.bucket_range_low[ind], gyro_info.bucket_range_high[ind]] for ind in
                                range(gyro_info.num_buckets)]
        )

        imu_cfg = IMUConfig(odr=user_submitted_data.imu_data_range,
                            acc_fs=user_submitted_data.acc_full_scale, gyro_fs=user_submitted_data.gyro_full_scale,
                            accel_bucket_count=ax_info.num_buckets, gyro_bucket_count=gyro_info.num_buckets)

        imu_source = DeviceIMUSource(imu_cfg=imu_cfg, gyro_bucket=gyro_bucket, acc_bucket=acc_bucket)

        analog_channel_cfgs = []
        for anlog_prm in user_submitted_data.analog:
            chnl_config = ChannelCfg(
                channel_id=anlog_prm.channel,
                multiplier=anlog_prm.multiplier
            )
            analog_channel_cfgs.append(chnl_config)
        analog_config = AnalogConfig(channel_cfg=analog_channel_cfgs)

        analog_source = DeviceAnalogSource(analog_cfg=analog_config)

        device_log_config = DeviceLogConfigFile(
            source_cfg=[gps_source, imu_source, can_source, analog_source]
        )

        self.device_log_config = device_log_config

        return device_log_config

    def encode_device_config_binary(self, device_log_config: DeviceLogConfigFile) -> DeviceConfigBinary:

        can_config = device_log_config.source_cfg[2]
        imu_config = device_log_config.source_cfg[1]

        can_config, can_pgns, can_req, can_req_params = self.parse_can_dict_for_encoding(
            can_dict=can_config.model_dump())

        encoded_can_config = self.encode_can_config(can_config, can_pgns, can_req, can_req_params)
        encoded_imu_config = self.encode_imu_data(imu_data=imu_config.model_dump())

        device_log_config_binary = DeviceConfigBinary(
            encoded_can_cfg=encoded_can_config,
            encoded_imu_cfg=encoded_imu_config
        )

        self.device_log_config_binary = device_log_config_binary

        return device_log_config_binary

    def create_log_config_file(self, user_submitted_data: UserLogConfigForm):

        metadata = LogConfigMetaData(
            created_on=str(datetime.now()),
            sources=[SourceEnum.CAN, SourceEnum.GPS]
        )

        gps_params = [GPSParam(name=GPS_PARAMS[gps]) for gps in user_submitted_data.GPS]
        i2c_params = [I2CParam(**i2c.model_dump()) for i2c in user_submitted_data.i2c]
        analog_params = [AnalogParam(**analog.model_dump()) for analog in user_submitted_data.analog]
        # digital_params = [DigitalParam(**digital.model_dump()) for digital in user_submited_data.digital]

        can_info = self.create_can_data_server_format(user_selected_broad_param=user_submitted_data.can_broad,
                                                      user_selected_req_param=user_submitted_data.can_req)

        can_params, request_id, resposne_id = can_info
        print(resposne_id, request_id)
        server_log_config_file = ServerLogConfigFile(
            metadata=metadata,
            GPS=gps_params,
            CAN=can_params,
            I2C=i2c_params,
            analog=analog_params,
        )

        device_log_config = self.create_device_log_config(
            server_log_config_file=server_log_config_file,
            user_submitted_data=user_submitted_data,
            req_id=request_id,
            res_id=resposne_id
        )

        device_log_config_binary = self.encode_device_config_binary(device_log_config=device_log_config)

        self.server_log_config = server_log_config_file

        self.save_config_files_to_s3()

        return server_log_config_file, device_log_config, device_log_config_binary

    def fetch_master_param_list(self) -> List[Dict[str, str]]:
        df = self.hiperdatalake.download_excel(self.master_param_pth)[0]
        df.fillna('', inplace=True)
        return df

    def fetch_can_param_list(self):

        master_param_df = self.fetch_master_param_list()

        if master_param_df is None:
            return None

        broad_param_df, broad_download_bug = self.hiperdatalake.download_excel(s3_key=self.broad_param_pth,
                                                                               save_local=True)
        req_param_df, req_download_bug = self.hiperdatalake.download_excel(s3_key=self.req_param_pth,
                                                                           save_local=True)
        print(broad_download_bug, req_download_bug)
        if broad_param_df is not None and req_param_df is not None:
            # Remove duplicates from broad_param_df based on Master PID
            broad_param_df = broad_param_df.drop_duplicates(subset=self.MASTER_PID_COLUMN, keep='first')

            # Remove Master PID from req_param_df if present in broad_param_df
            req_param_df = req_param_df[
                ~req_param_df[self.MASTER_PID_COLUMN].isin(broad_param_df[self.MASTER_PID_COLUMN])]

            # Remove duplicates from req_param_df based on Master PID
            req_param_df = req_param_df.drop_duplicates(subset=self.MASTER_PID_COLUMN, keep='first')

            # Left join broad_param_df and req_param_df with master_param_df
            req_X_master_param_df = pd.merge(req_param_df, master_param_df, on=self.MASTER_PID_COLUMN, how='left')
            broad_X_master_param_df = pd.merge(broad_param_df, master_param_df, on=self.MASTER_PID_COLUMN, how='left')

            return req_X_master_param_df, broad_X_master_param_df

        else:
            return None

    @staticmethod
    def encode_can_config(can_config, can_pgns, can_req, can_req_params):
        buffer = bytearray()

        # Encode CAN config structure
        buffer.append(can_config['baud_rate'])
        buffer.append(can_config['can_standard'])
        buffer.append(can_config['num_pgns'])

        # Encode CAN PGNs
        for pgn in can_pgns:
            buffer.extend(struct.pack('>I', pgn['pgn_id']))  # 4 bytes for PGN ID
            buffer.append(pgn['num_of_brd_params'])
            for param in pgn['brd_params']:
                buffer.append(param['length'])
                buffer.append(param['start_byte'])

        # Encode CAN REQ structure
        buffer.extend(struct.pack('>I', can_req['request_id']))  # 4 bytes for request_id
        buffer.extend(struct.pack('>I', can_req['response_id']))  # 4 bytes for response_id
        buffer.append(can_req['num_of_req_params'])
        # buffer.append(can_req['filter_id'])

        # Encode CAN REQ params
        for req_param in can_req_params:
            print(req_param['param_id1'])
            buffer.append(req_param['service_id'])
            buffer.append(req_param['param_id1'])
            buffer.append(req_param['param_id2'])
            buffer.append(req_param['can_ext_param'])
            buffer.append(req_param['length'])

        # Calculate checksum and append to buffer
        checksum = calculate_checksum(buffer)
        buffer.append(checksum)

        return bytes(buffer)

    @staticmethod
    def parse_can_dict_for_encoding(can_dict: dict):
        can_config = {
            'baud_rate': can_dict['can_cfg']['baud_rate'],
            'can_standard': can_dict['can_cfg'].get('data_mode', 0),
            'num_pgns': len(can_dict['can_cfg']['pgn_cfg'])
        }

        can_pgns = []
        for pgn in can_dict['can_cfg']['pgn_cfg']:
            pgn_id = int(pgn['pgn_id'], 16)
            brd_params = [{'length': math.ceil(param['length']), 'start_byte': int(param['start_byte'])}
                          for param in pgn['broadcast_param']]
            can_pgns.append({
                'pgn_id': pgn_id,
                'num_of_brd_params': len(brd_params),
                'brd_params': brd_params
            })

        can_req = {
            'request_id': int(can_dict['can_cfg']['request_resp_cfg'][0]['request_id'], 16),
            'response_id': int(can_dict['can_cfg']['request_resp_cfg'][0]['response_id'], 16),
            'num_of_req_params': len(can_dict['can_cfg']['request_resp_cfg'][0]['request_param_cfg']),
            # 'filter_id': 0x09  # Assuming a constant filter_id as example
        }

        can_req_params = []
        for req_param in can_dict['can_cfg']['request_resp_cfg'][0]['request_param_cfg']:
            param_id1 = int(req_param['pid1'], 16)
            param_id2 = int(req_param['pid2'], 16) if isinstance(req_param['pid2'], str) else int(req_param['pid2'])
            can_ext_param = int(req_param['can_ext_param'], 16) if req_param['can_ext_param'] is not None else 0x00
            can_req_params.append({
                'service_id': int(str(req_param['service_id']), 16),
                'param_id1': param_id1,
                'param_id2': param_id2,
                'can_ext_param': can_ext_param,
                'length': math.ceil(req_param['length'])
            })

        return can_config, can_pgns, can_req, can_req_params

    @staticmethod
    def encode_imu_data(imu_data):
        buffer = bytearray()

        imu_cfg = imu_data['imu_cfg']
        acc_bucket = imu_data['acc_bucket']
        gyro_bucket = imu_data['gyro_bucket']

        # Encode IMU config structure
        buffer.append(imu_cfg['odr'])
        buffer.append(imu_cfg['acc_fs'])
        buffer.append(imu_cfg['gyro_fs'])
        buffer.append(imu_cfg['accel_bucket_count'])
        buffer.append(imu_cfg['gyro_bucket_count'])

        # Encode Accelerometer Bucket Configurations
        for config in acc_bucket['ax_bucket_config']:
            buffer.extend(struct.pack('>H', config[0]))  # 2 bytes for lower bound
            buffer.extend(struct.pack('>H', config[1]))  # 2 bytes for upper bound

        for config in acc_bucket['ay_bucket_config']:
            buffer.extend(struct.pack('>H', config[0]))  # 2 bytes for lower bound
            buffer.extend(struct.pack('>H', config[1]))  # 2 bytes for upper bound

        for config in acc_bucket['az_bucket_config']:
            buffer.extend(struct.pack('>H', config[0]))  # 2 bytes for lower bound
            buffer.extend(struct.pack('>H', config[1]))  # 2 bytes for upper bound

        # Encode Gyroscope Bucket Configurations
        for config in gyro_bucket['gyro_bucket_config']:
            buffer.extend(struct.pack('>H', config[0]))  # 2 bytes for lower bound
            buffer.extend(struct.pack('>H', config[1]))  # 2 bytes for upper bound

        # Calculate checksum and append to buffer
        checksum = calculate_checksum(buffer)
        buffer.append(checksum)

        return bytes(buffer)

    def save_config_files_to_s3(self):

        version = str(self.version_to_assign).zfill(2)

        make_model_pth = f"make model/{self.make_model}/log_config/{version}/"

        can_config_pth = make_model_pth + f"can_config_{self.make_model}_{version}.bin"
        imu_config_pth = make_model_pth + f"imu_config_{self.make_model}_{version}.bin"

        server_log_config_pth = make_model_pth + f"server_log_config_{self.make_model}_{version}.json"
        device_log_config_pth = make_model_pth + f"device_log_config_{self.make_model}_{version}.json"

        server_log_upload, server_log_bug = self.hiperdatalake.upload_obj_to_s3(
            obj=json.dumps(self.server_log_config.model_dump(), indent=4),
            s3_key=server_log_config_pth)
        device_log_upload, device_log_bug = self.hiperdatalake.upload_obj_to_s3(
            obj=json.dumps(self.device_log_config.model_dump(), indent=4),
            s3_key=device_log_config_pth)

        can_config_upload, can_config_bug = self.hiperdatalake.upload_obj_to_s3(
            obj=self.device_log_config_binary.encoded_can_cfg, s3_key=can_config_pth)

        imu_config_upload, imu_config_bug = self.hiperdatalake.upload_obj_to_s3(
            obj=self.device_log_config_binary.encoded_imu_cfg, s3_key=imu_config_pth)

        print(server_log_bug)

        print(device_log_bug)

        self.update_new_config_version()

        print("==========================")
