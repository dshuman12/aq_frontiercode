# Import inbuilt libraries
import os
from typing import Dict, Tuple, Union
import jwt
import time




# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
import pandas as pd
from passlib.context import CryptContext
from dotenv import load_dotenv



# Include repos folder for custom libraries
from storage_settings import rds_instance,redis_instance


# Declare variables used 
env = load_dotenv()


JWT_SECRET = os.getenv("SECRET_KEY")
JWT_ALGORITHM = os.getenv("ALGORITHM")



# password context for hashing
password_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Library Code for Users Module
lib_code_UM = "25"
lib_ver_UM = "00"

lib_code_ver_UM = f"{lib_code_UM}{lib_ver_UM}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.data_models.rds_data_models.users_rds_models import Employee,Team 
from schema.users_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session



# initialize the logger
logger_1 = LoggerFactory(name="user_utils", file_name="message.log").get_logger()



# Define Helper class used with the pydantic model

# define other funcs

def add_user_group_service():
    pass


@error_handler(library_code=lib_code_ver_UM, function_code="01")
def all_user_records(bugs={}) -> pd.DataFrame:
    '''
    Function to get all user records

    params : None
    return : df of all users
    '''
    # Check if the data is cached
    cached_users = redis_instance.get_key('all_users_cached')

    if cached_users:
        try:
            # Deserialize cached data into DataFrame format
            all_users = pd.read_json(cached_users.decode('utf-8'), orient='records')
            return all_users
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached all_users DataFrame: {str(e)}")
            raise Exception("Failed to retrieve cached users data.") from e

    # If not cached or deserialization failed, query from the database
    session = rds_instance.get_connection()
    
    with handle_session(session) as ns:
        all_users = ns.query(
            Employee.id,  # Ensure 'id' is included in the query
            Employee.username,
            Employee.email_id,
            Employee.first_name,
            Employee.last_name,
            Employee.password,
            Employee.phone_number,
            Employee.user_team,
            Employee.is_superuser,
        ).filter(Employee.is_active == 1).all()

        if not all_users:
            return None

        # Convert query results to DataFrame
        users_data = [{
            'id': user.id,
            'username': user.username,
            'email_id': user.email_id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'password' : user.password,
            'phone_number': user.phone_number,
            'user_team' : user.user_team,
            'is_superuser': user.is_superuser,
        } for user in all_users]

        all_users_df = pd.DataFrame(users_data)

        # Serialize DataFrame before caching
        if all_users_df is not None:
            try:
                serialized_users = all_users_df.to_json(orient='records')  # Example serialization to JSON
                redis_instance.set_key('all_users_cached', serialized_users, ex=300)
            except Exception as e:
                logger_1.error(f"Failed to serialize all_users DataFrame: {str(e)}")
                raise Exception("Failed to cache user data.") from e

        return all_users_df


@error_handler(library_code=lib_code_ver_UM, function_code="02")
def all_teams_records(bugs={}) -> pd.DataFrame:
    """
    Function to retrieve all user teams, using caching if available.

    params : None
    return : pd.DataFrame: DataFrame containing all user teams.

    """
    # Check if the data is cached
    cached_teams = redis_instance.get_key('all_teams_cached')
 
    if cached_teams:
        try:
            # Deserialize cached data into DataFrame format
            all_teams = pd.read_json(cached_teams.decode('utf-8'), orient='records')
            logger_1.info("Retrieved cached team data.")
            return all_teams
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached all_teams DataFrame: {str(e)}")
            raise Exception("Failed to retrieve cached team data.") from e

    # If not cached or deserialization failed, query from the database
    user_teams, bugs_local = rds_instance.query_table(Team)

    if bugs_local:
        logger_1.error(f"Querying Team table failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    # Serialize DataFrame before caching
    if user_teams is not None:
        try:
            serialized_teams = user_teams.to_json(orient='records')  # Example serialization to JSON
            redis_instance.set_key('all_teams_cached', serialized_teams,ex=21600)
            return user_teams
        except Exception as e:
            logger_1.error(f"Failed to serialize all_teams DataFrame: {str(e)}")
            raise Exception("Failed to cache team data.") from e

    # Return the queried team data or None if no data was retrieved
    return user_teams



@error_handler(library_code=lib_code_ver_UM, function_code="03")
def check_if_superuser(user_id: int,bugs={}) -> bool:
    """
    Function to retrieve the is_superuser value for a given user_id.

    params : user_id
    return : bool: is_superuser value for the user with the given user_id.

    """
    # Get all user records
    all_users,bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif all_users is not None:

        # Iterate through user records to find the user with the given user_id
        for user in all_users.to_dict(orient="records"):
            if user["id"] == user_id:
                return user["is_superuser"]

        # If user_id is not found, raise it as an exception
        raise Exception(f"User with user_id {user_id} not found in user records.")
    



@error_handler(library_code=lib_code_ver_UM, function_code="04")
def check_user_exists(phone_number : str, email : str, bugs={}) -> Optional[dict]:
    """
    Function to check if a user exists based on provided email and/or phone number.

    params:
    - phone_number: str
    - email: str

    returns:
    - dict: The user record if a user matching the provided parameters is found.
    - None: If no user matches the provided parameters.

    """

    # Get all user records
    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    elif all_users is not None:
        # Find the user record based on email and/or phone number
        user_record = None
        if email and phone_number:
            for user in all_users.to_dict(orient="records"):
                if user["email_id"] == email and user["phone_number"] == phone_number:
                    user_record = user
                    break

        return user_record



@error_handler(library_code=lib_code_ver_UM, function_code="05")
def check_username_taken(username: str, bugs={}) -> bool:
    '''
    Function to check if a username exists.

    params : username
    return : bool - True if the username exists, otherwise False.
    '''

    # Get all user records
    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Failed to get all user records: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    # Check if the username exists in the user records
    for user in all_users.to_dict(orient="records"):
        if user["username"] == username:
            return True
        
    return False

@error_handler(library_code=lib_code_ver_UM, function_code="06")
def check_user_already_signed_up(user_id: int,bugs={}) -> bool:
    """
    Function to check if a user is already signed up.

    params: user_id
    return: result, bugs
    """

    result = False
    bugs = {}

    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        raise ValueError(f"Error retrieving user records: {bugs_local}")

    if all_users is not None:
        for user in all_users.to_dict(orient="records"):
            if user["id"] == user_id and user["username"] != user["email_id"]:
                result = True
                break

    return result





@error_handler(library_code=lib_code_ver_UM, function_code="07")
def check_credentials_are_valid(username: str, password: str,bugs={}) -> bool:
    """
    Function to check if the provided credentials (username and password) are valid.

    Parameters:
    - username (str): The username of the user.
    - password (str): The plain text password of the user.

    Returns:
    - bool: True if the credentials are valid, False otherwise.
    """
    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return False

    elif all_users is not None:
        for user in all_users.to_dict(orient="records"):
            if user["username"] == username:
                hashed_password = user["password"]

                if password_context.verify(password, hashed_password):
                    logger_1.info("Password matches")
                    return True
                    
    logger_1.info("Password does not match")
    return False





@error_handler(library_code=lib_code_ver_UM, function_code="08")
def sign_jwt(username: str) -> Dict[str, str]:
    payload = {
        "user_name": username,
        "expires": time.time() + 1800 # 30 minutes
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

    return token





@error_handler(library_code=lib_code_ver_UM, function_code="09")
def get_user_details(username: str,bugs={}) -> Tuple[Union[Dict[str, Union[str, int]], None], Dict]:
    """
    Function to get the details of the user such as username, id, and team id.

    Parameters:
    - username (str): The username of the user.

    Returns:
    - Tuple: A tuple containing the user details as a dictionary if found, otherwise None, 
             and a dictionary containing any bugs encountered.
    """
    # Get all user records
    all_users, bugs_local = all_user_records()

    # Initialize bugs dictionary
    bugs = {}
    
    if bugs_local:
        logger_1.error(f"Getting all user records failed: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None, bugs

    if all_users is not None:
        for user in all_users.to_dict(orient="records"):
            if user["username"] == username:
                user_details = {
                    "username": user["username"],
                    "id": user["id"],
                    "team_id": user["user_team"]
                }
                return user_details

    logger_1.info(f"User {username} not found")
    return None


# function to fetch the users team given the user id
@error_handler(library_code=lib_code_ver_UM, function_code="10")
def get_user_team(user_id: int, bugs={}) -> Optional[int]:
    """
    Function to get the team id of a user given the user id.

    Parameters:
    - user_id (int): The id of the user.

    Returns:
    - int: The team id of the user if found, otherwise None.
    """
    # Get all user records
    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    if all_users is not None:
        for user in all_users.to_dict(orient="records"):
            if user["id"] == user_id:
                return user["user_team"]

    return None



@error_handler(library_code=lib_code_ver_UM, function_code="11")
def sign_refresh_token(username: str) -> Dict[str, str]:
    payload = {
        "user_name": username,
        "expires": time.time() + 86400 # 24 hours
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

    return token


# function to check if an access token is about to expire in the next 5 minutes
@error_handler(library_code=lib_code_ver_UM, function_code="12")
def check_token_expiry(token):
    
    payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    expires = payload["expires"]
    current_time = time.time()
    
    # log the expiry time
    logger_1.info(f"Token expires at {expires}.")
    
    # log the current time
    logger_1.info(f"Current time is {current_time}.")
    
    # log the pending time for the token to expire
    logger_1.info(f"Token expires in {expires - current_time} seconds.")
    
    # if in seconds, show me the time in minutes and seconds in human readable format
    logger_1.info(f"Token expires in {divmod(expires - current_time, 60)} minutes.")
    
    # if the token is about to expire in the next 5 minutes
    if expires - current_time <= 300:
        return True
    
    return False


# function to return the email id of a user given the user id
def return_emaiL(user_id: int, bugs={}) -> Optional[str]:
    """
    Function to get the email id of a user given the user id.

    Parameters:
    - user_id (int): The id of the user.

    Returns:
    - str: The email id of the user if found, otherwise None.
    """
    # Get all user records
    all_users, bugs_local = all_user_records()

    if bugs_local:
        logger_1.error(f"Getting all user records failed: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    if all_users is not None:
        for user in all_users.to_dict(orient="records"):
            if user["id"] == user_id:
                return user["email_id"]

    return None