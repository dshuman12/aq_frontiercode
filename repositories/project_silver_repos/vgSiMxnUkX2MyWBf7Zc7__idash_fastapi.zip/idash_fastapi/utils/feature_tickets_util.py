# Import inbuilt libraries
from fastapi import status as http_status
from fastapi.responses import JSONResponse



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
import json
import time
import pandas as pd




# Include repos folder for custom libraries


# Declare variables used 
# Library Code for Users Module
lib_code_FT = "26"
lib_ver_FT = "00"

lib_code_ver_FT = f"{lib_code_FT}{lib_ver_FT}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance,hiperft_bucket,feat_ticket_path,current_date,AWS_STORAGE_BUCKET_NAME,redis_instance
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.data_models.rds_data_models.ticket_rds_models import Feature_Ticket as FT_RDS
from hiper_utils.data_models.s3_data_models.feature_ticket import *
from hiper_utils.data_models.s3_data_models.common_models import *
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.feature_ticket_schema import *
from schema.common_schema import *
from utils.users_utils import *
import boto3
from utils.attachment_util import upload_attachments_to_s3
from utils.common_util import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from schema.tasks_schema import DeleteTask_Input

# initialize the logger
logger_1 = LoggerFactory(name="feature_ticket_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model


# define other funcs

# function to push the object to s3 and get the s3 key
@error_handler(library_code=lib_code_ver_FT,function_code="19")
async def push_object_to_s3_and_get_s3_key(obj, s3_path, ticket_master_id, block_id, count):


    s3_bucket = AWS_STORAGE_BUCKET_NAME

    # Create an S3 client
    s3_client = boto3.client('s3')

    # Determine the file extension
    file_extension = obj.content_type.split('/')[-1]

    # Generate the full file name
    file_name = f"{str(ticket_master_id).zfill(5)}_{str(block_id).zfill(3)}_{str(count).zfill(2)}.{file_extension}"

   # Read the contents of the uploaded file
    file_contents = await obj.read()

    # Now you can pass file_contents to the put_object method
    s3_client.put_object(Bucket=s3_bucket, Key=s3_path + file_name, Body=file_contents, ContentType=obj.content_type)

    # The S3 key is the path and file name where the file is stored in the bucket
    s3_key = s3_path + file_name

    return s3_key


###############
@error_handler(library_code=lib_code_ver_FT, function_code="01")
def all_feat_records(bugs={}):
    '''
    Function to fetch all feature tickets from the RDS database and cache the data in Redis.

    params: None
    returns: DataFrame containing all feature tickets or None if no data was retrieved
    '''

    # Check if the data is cached
    cached_tickets = redis_instance.get_key('rds_feat_tickets_cached')

    if cached_tickets:
        try:
            # Deserialize cached data into dictionary format
            cached_tickets_dict = json.loads(cached_tickets.decode('utf-8'))
            # Convert the dictionary back to DataFrame
            all_ticket_records = pd.DataFrame.from_dict(cached_tickets_dict, orient='index').reset_index()
            all_ticket_records.rename(columns={'index': 'id'}, inplace=True)
            logger_1.info("Retrieved cached feature tickets rds records.")
            return all_ticket_records
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached all_feature tickets DataFrame: {str(e)}")
            raise Exception("Failed to retrieve cached feature tickets.") from e

    # If not cached or deserialization failed, query from the database
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        feature_tickets = ns.query(FT_RDS).all()
        logger_1.info(f"All feature tickets are {feature_tickets}")

        # Convert the queried result to a DataFrame if not empty
        if feature_tickets:
            try:
                # Convert the list of SQLAlchemy objects to a list of dictionaries
                feature_tickets_dict = [
                    {
                        column.name: getattr(ticket, column.name)
                        for column in ticket.__table__.columns
                    }
                    for ticket in feature_tickets
                ]

                # Convert the list of dictionaries to a DataFrame
                feature_tickets_df = pd.DataFrame(feature_tickets_dict)

                # Convert all datetime columns to string format
                for column in feature_tickets_df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns:
                    feature_tickets_df[column] = feature_tickets_df[column].dt.strftime('%Y-%m-%d %H:%M:%S')

                # Prepare data for caching
                tickets_dict = feature_tickets_df.set_index('id').to_dict(orient='index')
                serialized_tickets = json.dumps(tickets_dict)
                redis_instance.set_key('rds_feat_tickets_cached', serialized_tickets, ex=300)

                return feature_tickets_df

            except Exception as e:
                logger_1.error(f"Failed to serialize all feature tickets DataFrame: {str(e)}")
                raise Exception("Failed to cache feature tickets.") from e
        else:
            logger_1.info("No feature tickets found.")
            return None







@error_handler(library_code=lib_code_ver_FT,function_code="02")
def fetch_and_cache_ticket(ticketid: int, ticket_type: int, bugs={}):

    '''
    Function to fetch a specific feature ticket from S3 and cache the data in Redis.

    params: ticketid - the id of the ticket to fetch, ticket_type - the type of ticket to fetch
    returns: Dictionary containing the feature ticket data or None if no data was retrieved
    
    '''


    if ticket_type == 6:
        s3_path = feat_ticket_path

    # Check if the data is cached
    cached_ticket = redis_instance.get_key(f'feat_ticket_{ticketid}')

    if cached_ticket:
        try:
            # Deserialize cached data
            ticket_data = json.loads(cached_ticket.decode('utf-8'))
            logger_1.info(f"Retrieved ticket from cache")
            return ticket_data
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached ticket: {str(e)}")
            raise Exception("Failed to retrieve cached ticket data.") from e

    # If not cached or deserialization failed, download from S3
    ticket_data, bugs_local = hiperft_bucket.download_json(s3_key=f"{s3_path}{str(ticketid).zfill(5)}.json")

    if bugs_local:
        logger_1.info(f"Failed to download the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_data is not None:
        try:
            # Serialize data to JSON before caching
            serialized_ticket = json.dumps(ticket_data)
            redis_instance.set_key(f'feat_ticket_{ticketid}', serialized_ticket, ex=300)
            return ticket_data
        except Exception as e:
            logger_1.error(f"Failed to cache the feature ticket, {e}")
            raise Exception("Failed to cache feature ticket.") from e

    return ticket_data


@error_handler(library_code=lib_code_ver_FT,function_code="03")
def create_ticket_in_s3(ticket_to_rds : int ,ticket : Create_Feature_Ticket_Input,added_by_superuser : bool,bugs={}) -> dict:
    '''
    
    Function to create a feature ticket in s3

    params : ticket_to_rds, ticket
    returns : updated ticket data
    
    
    '''

    # Organize the input data into metadata and heading sections
    metadata = {
        'created_by': str(ticket.added_by),
        'updated_by': str(ticket.added_by),
        'req_blocks': ['2'],
        'status_blocks': ["4"],
        'status': "0" if ticket.owner is None else "2",
        'approved': False
    }

    # serialize the metadata
    metadata_serialized = MetadataBlock(**metadata)

    # call all_teams_records function to get all teams
    all_teams, bugs_local = all_teams_records()

    if bugs_local:
        logger_1.error(f"Failed to fetch all teams, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
    
    elif all_teams is not None:

        # get the l2 manager of the team
        team_l2_manager = all_teams[all_teams['id'] == int(ticket.team)]['l2_manager'].values[0]

    heading = {
        'ticket_master_id': str(ticket_to_rds),
        'ticket_name': ticket.feature_name,  # Feature name as ticket name
        'ticket_description': ticket.description,  # Description as ticket description
        'team': str(ticket.team),  # Team from input
        'requested_eta': ticket.requested_eta,
        'priority': str(ticket.priority),  # Priority from input
        'scope': ticket.modules,  # Modules from input
        'approver': str(team_l2_manager),
        'owner': str(ticket.owner) if ticket.owner is not None else None,
        'group_id': None,
        'user_security_type': False,
        'attachment': []
    }

    # serialize the heading
    heading_serialized = HeadingBlock(**heading)


       
    attachment_urls_list = []

    if ticket.attachments is not None:

        logger_1.info(f"Attachments are {ticket.attachments}")

        # call the upload_attachments_to_s3 function to upload the attachments to s3
        attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket_to_rds,block_id=2)

        if bugs_local:
            logger_1.error(f"Failed to upload attachments, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif attachment_urls_list is not None:
            logger_1.info(f"Attachment urls are {attachment_urls_list}")

    requirement = {
    "added_by": str(ticket.added_by),
    "requirement_text": str(ticket.requirement),
    "attachments" : attachment_urls_list
    }

    # serialize the requirement
    requirement_serialized = RequirementBlock(**requirement)

    # create a status block
    status_block = {
        "status_change_description": f"Feature ticket named {ticket.feature_name} created successfully",
        "updated_by": str(ticket.added_by),
    }

    # serialize the status block
    status = StatusChangeBlock(**status_block)

    # create the ticket 
    feat_ticket = {
        "0": metadata_serialized.model_dump(),
        "1": heading_serialized.model_dump(),
        "2": requirement_serialized.model_dump(),
        "3": status.model_dump()
    }

    
    # push the ticket to s3 using write json 
    ticket_path = f"{feat_ticket_path}{str(ticket_to_rds).zfill(5)}.json"

    result, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=feat_ticket, s3_key=ticket_path)

    if bugs_local:
        logger_1.error(f"push failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    else:
        # call fetch and cache ticket to cache the ticket
        ticket_cached, bugs_local = fetch_and_cache_ticket(ticket_to_rds, 6)

        if bugs_local:
            logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif ticket_cached is not None:
            return ticket_cached



# function to check if a user has permission to modify a ticket given ticket id and user id
@error_handler(library_code=lib_code_ver_FT,function_code="03")
def check_user_has_permissions(ticketid : int, userid : int, ticket_type : int, bugs={}):

    '''
    Function to check if a user has permission to modify a ticket given the ticket id and user id.

    params: ticketid, userid,ticket_type
    returns: True if the user has permission, False otherwise

    '''
    
    logger_1.info(f"User id is {userid}")

    # fetch the ticket using fetch_and_cache_ticket function
    ticket_data,bugs_local = fetch_and_cache_ticket(ticketid=ticketid,ticket_type=ticket_type)

    if bugs_local:
        logger_1.error(f"Fetching ticket failed, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

    if ticket_data is not None:
        
        # check if the user is the owner, approver, creator of the ticket or the user is a superuser
        metadata = ticket_data['0']
        creator = metadata['created_by']
        
        heading = ticket_data['1']
        owner = heading['owner']
        approver = heading['approver']
        
        logger_1.info(f"Creator is {creator}, Owner is {owner}, Approver is {approver} ")

        if int(userid) == int(creator) or int(userid) == int(approver):
            return True
        
        if owner is not None:
            if int(userid) == int(owner):
                return True
        
        
        # check if the user is a superuser
        check_superuser, bugs_local = check_if_superuser(user_id = userid)

        if bugs_local:
            logger_1.error(f"Checking if user is superuser failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
        
        elif check_superuser:
            return True

    return False

        






# function to update the ticket to rds cache.
@error_handler(library_code='lib_code_ver_FT', function_code="04")
def push_updates_to_rds_cache(update, bugs={}):
    '''
    Function to update a specific feature ticket in the Redis cache related to rds records.

    params: update - the update model containing the ticket id and fields to update
    returns: True if the ticket was updated successfully, False otherwise

    '''

    # try to retrieve all feat records from the cache
    all_ticket_record = redis_instance.get_key('rds_feat_tickets_cached')

    # if cache does not exist, call the all_feat_records function to set the cache
    if all_ticket_record is None:
        cache_set, bugs_local = all_feat_records()

        if bugs_local:
            logger_1.error(f"Fetching feat tickets failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)

        elif cache_set is not None:
            # call the retrieve all feat records function again
            all_ticket_record = redis_instance.get_key('rds_feat_tickets_cached')

    # Decode bytes to string if necessary
    if isinstance(all_ticket_record, bytes):
        all_ticket_record = all_ticket_record.decode('utf-8')
    
    # Deserialize the data
    if isinstance(all_ticket_record, str):
        all_ticket_record = json.loads(all_ticket_record)

    # Handle both Pydantic model and Pandas Series
    if isinstance(update, pd.Series):
        ticket_id = str(update['id'])
        update_data = update.to_dict()
    else:
        ticket_id = str(update.ticketid)
        update_data = update.dict(exclude_unset=True)
        update_data.pop('ticketid', None)

    # Check if the specific ticket exists
    if ticket_id not in all_ticket_record:
        logger_1.error(f"Ticket with id {ticket_id} not found in the cache")
        return False

   # Map input fields to cached object fields
    field_map = {
        "feature_name": "ticket_name",
        "priority": "priority",
        "team": "assigned_team",
        "owner": "assigned_to",
        "requested_eta": "deadline",
        "modules": "libraries",
        "status": "status",
        "approved": "approved_status"
    }

  

    # Update the specific ticket
    for key, value in update_data.items():
        if key in field_map:
            mapped_key = field_map[key]
            if key == "deadline" and value is not None:
                # Convert datetime to string
                value = value.strftime('%Y-%m-%d %H:%M:%S')
            if key == "libraries" and value is not None:
                # Convert list to string
                value = json.dumps(value)
            all_ticket_record[ticket_id][mapped_key] = value

    # Serialize the updated data
    updated_data = json.dumps(all_ticket_record,cls=DateTimeEncoder)

    # Save the updated records back to the cache
    redis_instance.set_key('rds_feat_tickets_cached', updated_data)

    # Add the ticket id to the queue for later processing
    redis_instance.lpush('update_queue', ticket_id)

    return True




# Background task to write changes to RDS
@error_handler(library_code='lib_code_ver_FT', function_code="05")
def write_changes_to_rds():

    '''
    Function to write changes to RDS in the background.

    params: None
    returns: None
    
    '''


    while True:
        # Sleep for the specified interval (e.g., 1 minute for testing)
        time.sleep(60)

        # logger_1.info("Checking for changes to write to RDS")

        try:
            while True:
                # Pop a ticket ID from the queue
                ticket_id = redis_instance.rpop('update_queue')
                if not ticket_id:
                    break  # No more items in the queue

                ticket_id = ticket_id.decode('utf-8')
                logger_1.info(f"Writing changes for ticket {ticket_id} to RDS")

                # Retrieve all ticket records from the cache
                all_ticket_record = redis_instance.get_key('rds_feat_tickets_cached')
                if all_ticket_record is None:
                    logger_1.error("Failed to retrieve all feature tickets from cache")
                    continue  # Skip if no records found

                # Decode bytes to string if necessary
                if isinstance(all_ticket_record, bytes):
                    all_ticket_record = all_ticket_record.decode('utf-8')
                
                logger_1.info(f"All ticket record (type: {type(all_ticket_record)}): {all_ticket_record}")

                # Deserialize the data
                if isinstance(all_ticket_record, str):
                    all_ticket_record = json.loads(all_ticket_record)
                
                logger_1.info(f"Deserialized all ticket record (type: {type(all_ticket_record)}): {all_ticket_record}")

                # Get the ticket data
                ticket_data = all_ticket_record.get(ticket_id)
                if not ticket_data:
                    logger_1.error(f"Ticket with id {ticket_id} not found in the cache")
                    continue  # Skip if the ticket data is not found

                logger_1.info(f"Ticket data (type: {type(ticket_data)}): {ticket_data}")

                # Check if the ticket exists in the RDS
                existing_ticket = rds_instance.query_table(FT_RDS)
                if isinstance(existing_ticket, pd.DataFrame):
                    existing_ticket = existing_ticket[existing_ticket['id'] == int(ticket_id)]

                logger_1.info(f"Existing ticket (type: {type(existing_ticket)}): {existing_ticket}")

                if isinstance(existing_ticket, pd.DataFrame) and existing_ticket.empty:
                    # Create a new record
                    rds_instance.create_record_in_table(FT_RDS, **ticket_data)
                else:
                    # Update the existing record
                    rds_instance.update_record_in_table(FT_RDS, int(ticket_id), **ticket_data)
                
                logger_1.info("Changes written to RDS successfully")

        except Exception as e:
            logger_1.error(f"Error writing changes to RDS: {e}")




@error_handler(library_code='lib_code_ver_FT', function_code="07")
def handle_ticket_update_for_s3(ticketid : int, ticket_with_updation, user_id: int, bugs={}):

    '''
    Function to handle the update of a feature ticket in S3.

    params: ticketid, ticket_with_updation, user_id
    returns: Updated ticket data
    
    
    '''

    # Update metadata
    updated_ticket, bugs_local = update_metadata(ticket_with_updation, user_id)

    if bugs_local:
        logger_1.error(f"Failed to update metadata for ticket {ticketid}: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    elif updated_ticket is not None:
        logger_1.info(f"Metadata updated for ticket {ticketid}")

    logger_1.info("ticket with updation is",ticket_with_updation)

    # Serialize the updated ticket data to a JSON string
    updated_ticket_data = json.dumps(ticket_with_updation)

    # Save the updated ticket data back to the cache (if needed)
    redis_instance.set_key(f'feat_ticket_{ticketid}', updated_ticket_data,ex=1200)

    # Add the ticket id to the S3 update queue for later processing
    redis_instance.lpush('s3_update_queue', str(ticketid))

    return ticket_with_updation


@error_handler(library_code='lib_code_ver_FT', function_code="08")
def write_changes_to_s3():

    '''
    Function to write changes to S3 in the background.

    params: None
    returns: None
    
    '''


    while True:
        # Sleep for the specified interval (e.g., 1 minute for testing)
        time.sleep(60)

        # logger_1.info("Checking for changes to write to S3")

        try:
            while True:
                # Pop a ticket ID from the S3 update queue
                ticket_id = redis_instance.rpop('s3_update_queue')
                if not ticket_id:
                    break  # No more items in the queue

                ticket_id = ticket_id.decode('utf-8')
                logger_1.info(f"Writing changes for ticket {ticket_id} to S3")

                # Retrieve the updated ticket data from the cache (if needed)
                ticket_data = redis_instance.get_key(f'feat_ticket_{ticket_id}')
                if ticket_data is None:
                    logger_1.error(f"Failed to retrieve ticket data for ticket ID {ticket_id} from cache")
                    continue

                # Decode bytes to string if necessary
                if isinstance(ticket_data, bytes):
                    ticket_data = ticket_data.decode('utf-8')

                # Deserialize the data
                ticket_data = json.loads(ticket_data)

                # Write the ticket data to S3
                s3_path = feat_ticket_path
                s3_key = f"{s3_path}{str(ticket_id).zfill(5)}.json"
                
                
                updated_ticket,bugs_local = hiperft_bucket.write_json_to_s3(data_dict=ticket_data, s3_key=s3_key)

                if bugs_local:
                    logger_1.error(f"Error writing changes to S3: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                
                elif updated_ticket is not None:
                    logger_1.info(f"Changes written to S3 successfully")

        except Exception as e:
            logger_1.error(f"Error writing changes to S3: {e}")


@error_handler(library_code='lib_code_ver_FT', function_code="09")
def update_feat_ticket_fields(ticket):

    '''
    Function that services update feature ticket API.

    params: ticket
    returns: updated ticket data
    
    
    '''


    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:
        # perform the manipulation to heading block here and serialize it
        heading = ticket_s3_data['1']
        metadata = ticket_s3_data['0']

        # update the heading block
        heading['ticket_name'] = ticket.feature_name if ticket.feature_name is not None else heading['ticket_name']
        heading['ticket_description'] = ticket.description if ticket.description is not None else heading['ticket_description']
        heading['priority'] = ticket.priority if ticket.priority is not None else heading['priority']
        heading['owner'] = ticket.owner if ticket.owner is not None else heading['owner']
        heading['requested_eta'] = ticket.requested_eta if ticket.requested_eta is not None else heading['requested_eta']
        heading['scope'] = ticket.modules if ticket.modules is not None else heading['scope']
        
        metadata['approved'] = True if ticket.approved == 1 else False

        # update the status in metadata
        metadata['status'] = ticket.status if ticket.status is not None else metadata['status']

        # fetch the last key in the ticket_data
        last_key = list(ticket_s3_data.keys())[-1]

        # create a new status block saying that the ticket is updated
        status_block_id = int(last_key) + 1

        status_block = {
            'status_change_description': f'Ticket updated',
            'updated_by': ticket.updated_by
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

        # call the handle ticket for s3 function
        updated_ticket, bugs_local = handle_ticket_update_for_s3(ticket.ticketid, ticket_s3_data, ticket.updated_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        elif updated_ticket is not None:
            logger_1.info(f"Ticket updated successfully")
            return updated_ticket
        



@error_handler(library_code='lib_code_ver_FT', function_code="10")
def check_ticket_is_approved(ticketid: int, ticket_type: int):

    '''
    Function to check if a ticket is approved.

    params : ticketid, ticket_type
    returns : True if the ticket is approved, False otherwise
    
    
    '''
    # call fetch and cache ticket function to get the ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid=ticketid, ticket_type=ticket_type)

    if bugs_local:
        logger_1.error(f"Fetching ticket failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif ticket_s3_data is not None:
        # get the metadata of the ticket
        metadata = ticket_s3_data['0']
        return metadata['approved']


           


### Requirement related functions ###

# function to edit requirement in a ticket
@error_handler(library_code=lib_code_ver_FT,function_code="11")
def edit_requirement_in_s3(blockid : int, requirement : EditRequirement ,bugs={}):

    '''
    Service function to edit a requirement in a feature ticket.
    
    params : blockid, requirement
    returns : updated ticket data
    
    
    '''
    
    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(requirement.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:

        block = ticket_s3_data[str(blockid)]
        previous_blocks = ticket_s3_data['0']['req_blocks']
        pre_block_list = []
        pre_block_list.extend(previous_blocks)     

        # fetch the last key in the ticket data and name it as last_key_for_req
        last_key_in_ticket = list(ticket_s3_data.keys())[-1]

        # get the next block id
        next_block_id = int(last_key_in_ticket) + 1

        edited_requirement_block = {
            'requirement_text': requirement.requirement_text or block['requirement_text'],
            'added_by': str(requirement.updated_by),
            'previous_blocks': pre_block_list
        }

        # serialize the edited requirement block
        serialized_edited_requirement = RequirementBlock(**edited_requirement_block)

        # add the edited requirement block to the ticket data
        ticket_s3_data[str(next_block_id)] = serialized_edited_requirement.model_dump()

        # update the metadata of the ticket
        metadata = ticket_s3_data['0']
        metadata["req_blocks"].append(str(next_block_id))

        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key_in_ticket_for_status = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key_in_ticket_for_status) + 1

        status_block = {
            'status_change_description': f'Requirement updated',
            'updated_by': requirement.updated_by,
            'ticket_status': metadata['status'] if 'status' in metadata else None,
            'parent_block_id': status_block_id - 1  # Assuming the parent block is the previous status block
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()
        
        metadata['status_blocks'].append(str(status_block_id))

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, requirement.updated_by)

        if bugs_local:
            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:
            
            # call the handle ticket for s3 function
            updated_ticket, bugs_local = handle_ticket_update_for_s3(requirement.ticketid, ticket_s3_data, requirement.updated_by)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif updated_ticket is not None:
                logger_1.info(f"Ticket updated successfully")
                return updated_ticket
            


           

### Subfeature Related Functions ###

# function to update ticket object with subfeature
@error_handler(library_code=lib_code_ver_FT,function_code="12")
def add_subfeature_to_ticket(subfeature : AddSubfeature,  bugs={}):

   # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(subfeature.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:

        # get the last key in the ticket_data and add 1 to it to get the block_id
        last_key_in_ticket = list(ticket_s3_data.keys())[-1]

        next_block_id = int(last_key_in_ticket) + 1  
                
        attachment_urls_list = []

        if subfeature.attachments is not None:

            logger_1.info(f"Attachments are {subfeature.attachments}")

            # call the upload_attachments_to_s3 function to upload the attachments to s3
            attachment_urls_list, bugs_local = upload_attachments_to_s3(subfeature.attachments,ticket_type=6, ticket_master_id=subfeature.ticketid,block_id=next_block_id)

            if bugs_local:
                logger_1.error(f"Failed to upload attachments, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif attachment_urls_list is not None:
                logger_1.info(f"Attachment urls are {attachment_urls_list}")

        
        # Create a new subfeature block and add it to the ticket_data
        new_subfeature_block = {
            'type': '6',
            'added_by': subfeature.added_by,
            'added_on': current_date,
            'sub_feature_name': subfeature.sub_feature_name,
            'sub_feature_description': subfeature.sub_feature_description,
            'module_id': subfeature.modules,
            'attachments': attachment_urls_list,
        }

        # serialize the new subfeature block
        serialized_subfeature = SubfeatureBlock(**new_subfeature_block)

        # add the subfeature block to the ticket_data
        ticket_s3_data[str(next_block_id)] = serialized_subfeature.model_dump()

        # Update the metadata of the ticket
        metadata = ticket_s3_data['0']
        metadata['sub_feature_blocks'].append(str(next_block_id))


        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key_in_ticket_for_status = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key_in_ticket_for_status) + 1

        status_block = {
                'status_change_description': f'Subfeature with id {next_block_id} added',
                'updated_by': subfeature.added_by
            }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

        metadata['status_blocks'].append(str(status_block_id))

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, subfeature.added_by)

        if bugs_local:
            logger_1.error(f"Updating metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        elif updated_ticket is not None:

            # call the handle ticket for s3 function
            ticket_cached, bugs_local = handle_ticket_update_for_s3(subfeature.ticketid, ticket_s3_data, subfeature.added_by)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif ticket_cached is not None:
                return ticket_cached




   
# function to edit a subfeature in a ticket
@error_handler(library_code=lib_code_ver_FT,function_code="13")
def edit_subfeature_in_ticket(block_id : int, subfeature : EditSubfeature,bugs={}): 
    '''
    Service function to edit a subfeature in a feature ticket.

    params : block_id (query), subfeature
    returns : updated ticket data
    
    
    '''
    
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(subfeature.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # get the subfeature block using the block_id
        subfeature_block = ticket_s3_data.get(str(block_id))

        if subfeature_block is None:
            logger_1.info(f"Subfeature block not found")
            return None

        elif subfeature_block is not None:

            status_change_description = ""

            subfeature_block['module_id'] = subfeature.modules if subfeature.modules is not None else subfeature_block['module_id']
            status_change_description += f"Modules updated "

            # update the subfeature block with the new data
            if subfeature.sub_feature_name is not None:
                old_sub_name = subfeature_block['sub_feature_name']
                subfeature_block['sub_feature_name'] = subfeature.sub_feature_name
                status_change_description += f"Subfeature name updated from {old_sub_name} to {subfeature.sub_feature_name}. "

            if subfeature.sub_feature_description is not None:
                old_sub_desc = subfeature_block['sub_feature_description']
                subfeature_block['sub_feature_description'] = subfeature.sub_feature_description
                status_change_description += f"Subfeature description updated from {old_sub_desc} to {subfeature.sub_feature_description}. "

            # update the metadata of the ticket
            metadata = ticket_s3_data['0']

            # fetch the last key in the ticket_data and add 1 to it to get the status block id
            last_key_in_ticket_for_status = list(ticket_s3_data.keys())[-1]

            status_block_id = int(last_key_in_ticket_for_status) + 1

            status_block = {
                'status_change_description': f'' + status_change_description,
                'updated_by': subfeature.updated_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the status block to the ticket_data
            ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

            # update the status block id in the metadata
            metadata['status_blocks'].append(str(status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, subfeature.updated_by)

            if bugs_local:
                logger_1.error(f"Updating metadata failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif updated_ticket is not None:
                    
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(subfeature.ticketid, updated_ticket, subfeature.updated_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif ticket_cached is not None:
                    return ticket_cached



            
                



# delete subfeature block
@error_handler(library_code=lib_code_ver_FT,function_code="14")
def delete_subfeature_from_ticket(subfeature : DeleteSubfeature,bugs={}):

    '''
    Service function to delete a subfeature from a feature ticket.

    params : subfeature
    returns : updated ticket data
    
    '''

  
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(subfeature.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:
    
        # itterate over the block ids and delete the subfeature block.
        blocks_to_delete = subfeature.block_ids

        for block_id in blocks_to_delete:

            # check if the block id exists in the ticket data
            if str(block_id) not in ticket_s3_data:
                logger_1.error(f"Subfeature block with id {block_id} not found")
                return None

            # delete the subfeature block
            del ticket_s3_data[str(block_id)]

            # update the metadata of the ticket
            metadata = ticket_s3_data['0']

            # remove the block id from the sub_feature_blocks
            metadata['sub_feature_blocks'].remove(str(block_id))

            # fetch the last key in the ticket_data and add 1 to it to get the status block id
            last_key_in_ticket_for_status = list(ticket_s3_data.keys())[-1]

            status_block_id = int(last_key_in_ticket_for_status) + 1

            status_block = {
            'status_change_description': f'Subfeature with id {block_id} deleted.',
            'updated_by': subfeature.deleted_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the status block to the ticket_data
            ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()
            
            # update the status block id in the metadata
            metadata['status_blocks'].append(str(status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, subfeature.deleted_by)

            if bugs_local:
                logger_1.error(f"Updating metadata failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif updated_ticket is not None:
                logger_1.info(f"Subfeature block with id {block_id} deleted successfully")
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(subfeature.ticketid, updated_ticket, subfeature.deleted_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif ticket_cached is not None:
                    return ticket_cached



# function to add a prototype block to a ticket
@error_handler(library_code=lib_code_ver_FT,function_code="15")
def add_prototype_to_ticket(prototype : AddPrototype,bugs={}):

    '''
    Service function to add a prototype block to a feature ticket.

    params : prototype
    returns : updated ticket data
    
    '''
   
    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(prototype.ticketid, 6)


    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:

        # block id would be the last key in the ticket_data + 1
        last_key = list(ticket_s3_data.keys())[-1]

        block_id = int(last_key) + 1

        # check if there is actually a subfeature block for the ticket by cross checking the value received in related_sub_feature_block
        if str(prototype.related_sub_feature_block) not in ticket_s3_data['0']['sub_feature_blocks']:
            logger_1.error(f"Subfeature block with id {prototype.related_sub_feature_block} not found")
            return None

        else:
     
            modules = prototype.modules

                           
            attachment_urls_list = []

            if prototype.attachments is not None:

                logger_1.info(f"Attachments are {prototype.attachments}")

                # call the upload_attachments_to_s3 function to upload the attachments to s3
                attachment_urls_list, bugs_local = upload_attachments_to_s3(prototype.attachments,ticket_type=6, ticket_master_id=prototype.ticketid,block_id=block_id)

                if bugs_local:
                    logger_1.error(f"Failed to upload attachments, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif attachment_urls_list is not None:
                    logger_1.info(f"Attachment urls are {attachment_urls_list}")


            # Create a new prototype feature block and add it to the ticket_data
            prototype_block = {
                'added_by': prototype.added_by,
                'prototype_description': prototype.prototype_description,
                'stage': 1,
                'module_id': modules,
                'related_sub_feature_block': int(prototype.related_sub_feature_block),
                'attachments': attachment_urls_list,
                'itterations': 0
            }

            # serialize the new prototype block
            serialized_prototype = PrototypeBlock(**prototype_block)

            # add the prototype block to the ticket_data
            ticket_s3_data[str(block_id)] = serialized_prototype.model_dump()

            # Update the metadata of the ticket 
            metadata = ticket_s3_data['0']
            metadata['proto_blocks'].append(str(block_id))

            status_block_id = int(block_id) + 1

            status_block = {
                'status_change_description': f"Prototype block with id {block_id} added.",
                'updated_by': prototype.added_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the status block to the ticket_data
            ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

            metadata['status_blocks'].append(str(status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, prototype.added_by)

            if bugs_local:
                logger_1.error(f"Updating metadata failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                    
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(prototype.ticketid, updated_ticket, prototype.added_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif ticket_cached is not None:
                    return ticket_cached
                

# function to edit a prototype block in a ticket
@error_handler(library_code=lib_code_ver_FT,function_code="16")
def edit_prototype_in_ticket(blockid : int ,prototype : EditPrototype,bugs={}):

    '''
    Service function to edit a prototype block in a feature ticket.

    params : blockid, prototype
    returns : updated ticket data

    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(prototype.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # Get the prototype block to update
        block = ticket_s3_data[str(blockid)]

        if block['type'] == "7":

            status_change_description = ""

            # Update the prototype block if the fields are present in the input
            if prototype.prototype_description is not None:
                old_desc = block['prototype_description']
                block['prototype_description'] = prototype.prototype_description
                status_change_description += f"Prototype description updated from {old_desc} to {prototype.prototype_description}. "

    
            status_change_description += f"Modules updated."

            if prototype.stage is not None:
                proto_switcher = {
                    1: "Under Development",
                    2: "Testing",
                    3: "Tested Not Ok",
                    4: "Tested Ok"
                }

                old_stage = proto_switcher.get(block['stage'])
                new_stage = proto_switcher.get(prototype.stage)

                block['stage'] = prototype.stage
                status_change_description += f"Stage updated from {old_stage} to {new_stage}. "

            if prototype.related_sub_feature_block is not None:

                # get the related subfeature name
                related_sub_feature_name = ticket_s3_data[str(block['related_sub_feature_block'])]['sub_feature_name']

                # check if the new related subfeature block is in the subfeature blocks and exists. else log it
                if str(prototype.related_sub_feature_block) not in ticket_s3_data['0']['sub_feature_blocks']:
                    logger_1.error(f"Subfeature block with id {prototype.related_sub_feature_block} not found")

                else:
                    new_sub_feature_name = ticket_s3_data[str(prototype.related_sub_feature_block)]['sub_feature_name']
                    block['related_sub_feature_block'] = prototype.related_sub_feature_block
                    status_change_description += f"Related subfeature updated from {related_sub_feature_name} to {new_sub_feature_name}. "

            if prototype.iterations is not None:
                block['iterations'] = prototype.iterations

            # fetch the last key in the ticket_data and add 1 to it to get the prototype block id and status block id
            last_key_in_ticket = list(ticket_s3_data.keys())[-1]
            new_status_block_id = int(last_key_in_ticket) + 1


            # new status block
            status_block = {
                'status_change_description': f'Prototype with description {block["prototype_description"]} edited as ' + status_change_description,
                'updated_by': prototype.updated_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the new status block to the ticket_data
            ticket_s3_data[str(new_status_block_id)] = serialized_status.model_dump()

            # update the metadata of the ticket
            metadata = ticket_s3_data['0']
            metadata['status_blocks'].append(str(new_status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, prototype.updated_by)

            if bugs_local:
                logger_1.error(f"Updating metadata failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                    
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(prototype.ticketid, updated_ticket, prototype.updated_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif ticket_cached is not None:
                    return ticket_cached


# function to delete a prototype block from a ticket
@error_handler(library_code=lib_code_ver_FT,function_code="17")
def delete_prototype_from_ticket(prototype : DeletePrototype,bugs={}):

    '''
    Service function to delete a prototype block from a feature ticket.

    params : prototype
    returns : updated ticket data
    
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(prototype.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_s3_data is not None:

        # once ticket is fetched, try to itterate through the block ids
        for block_id in prototype.block_ids:

            # delete the block id from the ticket data
            ticket_s3_data.pop(str(block_id))

            # delete the block id from the prototype blocks list
            ticket_s3_data['0']['proto_blocks'].remove(str(block_id))

            # fetch the last key in the ticket data
            last_key = list(ticket_s3_data.keys())[-1]

            # create a new status block to the ticket saying that the prototype block is deleted
            status_block_id = int(last_key) + 1

            status_block = {
                'status_change_description': f"Prototype block with id as {block_id} deleted",
                'updated_by': prototype.deleted_by
            }

            # serialize the status block
            serialized_status = StatusChangeBlock(**status_block)

            # add the status block to the ticket_data
            ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

            # update the metadata
            metadata = ticket_s3_data['0']
            metadata['status_blocks'].append(str(status_block_id))

            # call the update metadata function to update the updated_by field
            updated_ticket, bugs_local = update_metadata(ticket_s3_data, prototype.deleted_by)

            if bugs_local:
                logger_1.error(f"Updating metadata failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif updated_ticket is not None:
                
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(prototype.ticketid, updated_ticket, prototype.deleted_by)

                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif ticket_cached is not None:
                    return ticket_cached
            



# function to check if a user is superuser or manager to approve or reject a ticket
@error_handler(library_code=lib_code_ver_FT, function_code="18")
def check_if_user_has_approval_rights(ticketid: int,userid: int) -> bool:

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return False
    
    if ticket_s3_data is not None:
        # get the team of the ticket
        team = ticket_s3_data['1']['team']

        # logger_1.info(f"Team: {team} and type is {type(team)}")

        # call the all_teams_records function to get all the teams
        all_teams, bugs_local = all_teams_records()

        if bugs_local:
            logger_1.error(f"Failed to fetch the teams, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return False

        if all_teams is not None:
            # logger_1.info(f"All teams: {all_teams}")

            # filter the team from all_teams pd df using the team id
            team_df = all_teams[all_teams['id'] == int(team)]

            # logger_1.info(f"Team df: {team_df}")

            # get the l1 manager
            l1_manager = team_df['l1_manager'].values[0]
            # get the l2 manager
            l2_manager = team_df['l2_manager'].values[0]

            # Convert numpy.int64 to int
            l1_manager = int(l1_manager)
            l2_manager = int(l2_manager)

            # logger_1.info(f"L1 manager: {l1_manager} and type is {type(l1_manager)} l2 manager: {l2_manager} and type is {type(l2_manager)}. user is {userid} and type of user is {type(userid)}")

            # check if the user is l1 manager or l2 manager
            if userid == l1_manager or userid == l2_manager:
                logger_1.info(f"user is l1 or l2 manager")
                return True
            else:
                
                # check if the same user is a superuser
                is_superuser,bugs_local = check_if_superuser(user_id=userid)

                if bugs_local:
                    logger_1.error(f"Failed to check if user is superuser, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                
                return is_superuser

    return False





# function to approve ticket
@error_handler(library_code=lib_code_ver_FT, function_code="19")
def mark_ticket_as_approved(ticketid: int, approver_id: int, bugs={}):
    '''
    Service function to approve a feature ticket.

    params : ticketid
    returns : updated ticket data
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:
        # update the status of the ticket to 5
        ticket_s3_data['0']['status'] = "5"

        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key) + 1

        status_block = {
            'status_change_description': "Ticket approved and closed",
            'updated_by': approver_id
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_s3_data[str(status_block_id)] = serialized_status.model_dump()

        # update the metadata
        metadata = ticket_s3_data['0']
        metadata['status_blocks'].append(str(status_block_id))

        # call update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, approver_id)

        if bugs_local:
            logger_1.error(f"Updating metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:

            # call the handle ticket for s3 function
            ticket_cached, bugs_local = handle_ticket_update_for_s3(ticketid, updated_ticket, approver_id)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif ticket_cached is not None:

                # Update the ticket in RDS
                all_feat_tickets, bugs_local = all_feat_records()

                if bugs_local:
                    logger_1.error(f"Failed to fetch the feature tickets, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif all_feat_tickets is not None:
                    logger_1.info(f"All feature tickets: {all_feat_tickets}")

                    # Ensure the 'id' column is of type int
                    all_feat_tickets['id'] = all_feat_tickets['id'].astype(int)

                    # filter the ticket from all_feat_tickets pd df using the ticket id
                    ticket_df = all_feat_tickets[all_feat_tickets['id'] == int(ticketid)]

                    logger_1.info(f"Filtered ticket DataFrame: {ticket_df}")

                    # Update the status of the ticket
                    ticket_df.loc[ticket_df.index[0], 'status'] = 5

                    # Push the updated ticket to the RDS cache
                    update_series = ticket_df.iloc[0]
                    updated_ticket, bugs_local = push_updates_to_rds_cache(update_series)

                    if bugs_local:
                        logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None

                    elif updated_ticket is not None:
                        logger_1.info(f"Ticket approved and closed successfully")
                        return ticket_s3_data
            


# function to check if a ticket is closed
@error_handler(library_code=lib_code_ver_FT,function_code="20")
def check_if_ticket_is_closed(ticketid : int, ticket_type : int,bugs={}):
    '''
    Service function to check if a feature ticket is closed.
    
    params : ticketid, ticket_type
    returns : boolean
    
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    elif ticket_s3_data is not None:
        # get the status of the ticket
        ticket_status = ticket_s3_data['0']['status']

        # check if the ticket is closed
        if ticket_status == "5":
            return True
        else:
            return False
        


# function to reject a ticket with notes
@error_handler(library_code=lib_code_ver_FT,function_code="21")
def mark_ticket_as_rejected(ticket : RejectFeatTicketInput, bugs={}):

    '''
    Service function to reject a feature ticket.

    params : ticket
    returns : updated ticket data

    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:
        
        # create a feedback block with result_summary as the feedback in the request
        rejection_block = {
            "rejected_by": ticket.user_id,
            "rejection_notes": ticket.notes
        }

        # serialize the rejection block
        rejection_serialized = RejectionBlock(**rejection_block)

        # fetch the last key from the ticket data
        last_key = list(ticket_s3_data.keys())[-1]

        # get the next block id
        next_block_id = int(last_key) + 1

        # add the rejection block to the ticket data
        ticket_s3_data[str(next_block_id)] = rejection_serialized.model_dump()

    
        # rejection_block will not be there in the ticket data, so add it a key as rejection_block in metadata
        if 'rejection_block' not in ticket_s3_data['0']:
            ticket_s3_data['0']['rejection_block'] = []
            ticket_s3_data['0']['rejection_block'].append(str(int(next_block_id)))

        else:
            ticket_s3_data['0']['rejection_block'].append(str(int(next_block_id)))


        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key_for_status = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key_for_status) + 1

        # Create a new status with status description and update by the requested user id
        status_block = {
            "status_change_description": "Ticket rejected with feedback",
            "updated_by": ticket.user_id,
        }

        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**status_block)            

        # add the status block to the ticket
        ticket_s3_data[str(status_block_id)] = status_serialized.model_dump()

        # update the status of the ticket to 3
        ticket_s3_data['0']['status'] = "3"

        # update the metadata
        metadata = ticket_s3_data['0']
        metadata['status_blocks'].append(str(status_block_id))

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, ticket.user_id)

        if bugs_local:
            logger_1.error(f"Updating metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif updated_ticket is not None:

            # call the handle ticket for s3 function
            ticket_cached, bugs_local = handle_ticket_update_for_s3(ticket.ticketid, updated_ticket, ticket.user_id)

            if bugs_local:
                logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            elif ticket_cached is not None:
                
                # Update the ticket in RDS
                all_feat_tickets, bugs_local = all_feat_records()

                if bugs_local:
                    logger_1.error(f"Failed to fetch the feature tickets, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None

                elif all_feat_tickets is not None:
                    logger_1.info(f"All feature tickets: {all_feat_tickets}")

                    # Ensure the 'id' column is of type int
                    all_feat_tickets['id'] = all_feat_tickets['id'].astype(int)

                    # filter the ticket from all_feat_tickets pd df using the ticket id
                    ticket_df = all_feat_tickets[all_feat_tickets['id'] == int(ticket.ticketid)]

                    logger_1.info(f"Filtered ticket DataFrame: {ticket_df}")

                    # Update the status of the ticket
                    ticket_df.loc[ticket_df.index[0], 'status'] = 3

                    # Push the updated ticket to the RDS cache
                    update_series = ticket_df.iloc[0]
                    updated_ticket, bugs_local = push_updates_to_rds_cache(update_series)

                    if bugs_local:
                        logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None

                    elif updated_ticket is not None:
                        logger_1.info(f"Ticket rejected successfully")
                        return ticket_s3_data
                    

@error_handler(library_code=lib_code_ver_FT,function_code="22")
def has_subfeature_blocks(ticketid: int, bugs={}) -> bool:
    """
    Check if there is at least one subfeature block for a feature request ticket.

    params: ticketid

    returns: bool: True if there is at least one subfeature block, False otherwise.

    """
   
    # Fetch ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)
    
    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif ticket_s3_data is not None:
        logger_1.info(f"ticket data, {ticket_s3_data}")

        # Check if there are subfeature blocks
        sub_feat_blocks = ticket_s3_data['0']['sub_feature_blocks']

        if len(sub_feat_blocks) > 0:
            return True
        
        else:
            return False


@error_handler(library_code=lib_code_ver_FT,function_code="23")
def validate_subfeatures_have_prototypes(ticketid: int, bugs={}) -> bool:
    """
    Check if each subfeature of a feature ticket has at least one prototype.

    params: ticketid
    returns: bool: True if all subfeatures have at least one prototype, False otherwise.

    """
   
    # Fetch ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid,6)
    
    # Handle any errors encountered during fetch
    if bugs_local:
        logger_1.error(f"Failed to fetch ticket data: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif ticket_s3_data is not None:
    
        # Get subfeature and prototype blocks
        subfeature_blocks = ticket_s3_data['0']['sub_feature_blocks']
        prototoype_blocks = ticket_s3_data['0']['proto_blocks']
                
        for subfeature in subfeature_blocks:
                
            subfeature_block = ticket_s3_data[str(subfeature)]
            subfeature_name = subfeature_block['sub_feature_name']  

            #fetch all the prototype blocks in the ticket where prototype block's related subfeature block is equal to the current subfeature name
            related_prototoype_blocks = [proto for proto in prototoype_blocks]

            if len(related_prototoype_blocks) == 0:
                logger_1.error(f"Subfeature {subfeature_name} does not have any prototypes")
                return False
            
        return True
    

@error_handler(library_code=lib_code_ver_FT,function_code="24")
def validate_prototype_stages(ticketid : int, bugs={}) -> bool:
    '''
    Function to check if no prototypes are existing in a ticket that is either in development or testing stage.

    params : ticketid
    returns : bool
    
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

    elif ticket_s3_data is not None:

        prototoype_blocks = ticket_s3_data['0']['proto_blocks']

        #fetch all the prototype blocks in the ticket where prototype block's related subfeature block is equal to the current subfeature name
        related_prototoype_blocks = [proto for proto in prototoype_blocks]

        for proto in related_prototoype_blocks:

            if ticket_s3_data[str(proto)]['stage'] not in [3,4]:
                logger_1.error(f"Prototype with id {proto} is in development or testing stage")
                return False
            
        return True
    
@error_handler(library_code=lib_code_ver_FT,function_code="25")
def verify_tasks_are_completed(ticketid : int, bugs={}) -> bool:

    ''''
    
    Function to check if all the tasks in a ticket are completed.

    params : ticketid
    returns : bool

    
    '''

    # call the fetch and cache ticket
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
    
    elif ticket_s3_data is not None:

        # get the task id from the task block
        ticket_task_master_id = ticket_s3_data['1']['ticket_master_id']

        logger_1.info(f"ticket_task_master_id is {ticket_task_master_id}")


        # query the task rds 
        all_tasks,bugs_local = rds_instance.query_table(Task_RDS)

        if bugs_local:
            logger_1.error(f"Failed to fetch the tasks, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
        
        elif all_tasks is not None:
            logger_1.info(f"all tasks are {all_tasks}")

            # from the pd df filter the tasks to the ticket by type as 6 and master id as the ticket_task_master_id
            ticket_tasks = all_tasks[(all_tasks['type'] == 6) & (all_tasks['master_id'] == int(ticket_task_master_id))]

            logger_1.info(f"ticket tasks are {ticket_tasks}")

            # loop through each task and check if the status of any task is less than 4
            for index,task in ticket_tasks.iterrows():

                # log the task name
                logger_1.info(f"task name is {task['name']}")

                if task['status'] < 4:
                    logger_1.error(f"Task with id {task['id']} is not completed")
                    return False
                
            return True

# function to mark a ticket as closed
@error_handler(library_code=lib_code_ver_FT,function_code="26")
def mark_ticket_as_closed(ticket : CloseFeatTicketInput,bugs={}) -> dict:

    # fetch the ticket from s3
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket.ticketid, 6)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # create a summary block 
        summary_block = {
            "release_notes": ticket.release_notes,
            "future_imp": ticket.future_imp,
            "learnings": ticket.learnings
        }

        # Use SummaryBlock.create to handle None values
        summary_serialized = SummaryBlock.create(**summary_block)

        # get the last key in the ticket data
        last_key = list(ticket_s3_data.keys())[-1]

        # get the next block id
        summary_block_id = int(last_key) + 1

        ticket_s3_data[str(summary_block_id)] = summary_serialized.model_dump()

    
        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key_for_status = list(ticket_s3_data.keys())[-1]

        status_block_id = int(last_key_for_status) + 1

        
        # create a new status block to the ticket saying that the ticket is closed
        status_block = {
            "status_change_description": "Ticket marked as completed.",
            "updated_by": ticket.user_id,
        }

    
        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**status_block)         

        # add the status block to the ticket
        ticket_s3_data[str(status_block_id)] = status_serialized.model_dump()

        # update the status of the ticket to 4
        ticket_s3_data['0']['status'] = "4"

        # update the metadata
        metadata = ticket_s3_data['0']
        metadata['status_blocks'].append(str(status_block_id))
        metadata['summary_block'].append(str(summary_block_id))

        # call the update metadata function to update the updated_by field
        updated_ticket, bugs_local = update_metadata(ticket_s3_data, ticket.user_id)

        if bugs_local:
            logger_1.error(f"Updating metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        

        elif updated_ticket is not None:
                
                # call the handle ticket for s3 function
                ticket_cached, bugs_local = handle_ticket_update_for_s3(ticket.ticketid, updated_ticket, ticket.user_id)
    
                if bugs_local:
                    logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                elif ticket_cached is not None:
                    
                    # Update the ticket in RDS
                    all_feat_tickets, bugs_local = all_feat_records()

                    if bugs_local:
                        logger_1.error(f"Failed to fetch the feature tickets, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None

                    elif all_feat_tickets is not None:
                        logger_1.info(f"All feature tickets: {all_feat_tickets}")

                        # Ensure the 'id' column is of type int
                        all_feat_tickets['id'] = all_feat_tickets['id'].astype(int)

                        # filter the ticket from all_feat_tickets pd df using the ticket id
                        ticket_df = all_feat_tickets[all_feat_tickets['id'] == int(ticket.ticketid)]

                        logger_1.info(f"Filtered ticket DataFrame: {ticket_df}")

                        # Update the status of the ticket
                        ticket_df.loc[ticket_df.index[0], 'status'] = 4

                        # Push the updated ticket to the RDS cache
                        update_series = ticket_df.iloc[0]
                        updated_ticket, bugs_local = push_updates_to_rds_cache(update_series)

                        if bugs_local:
                            logger_1.error(f"Updating the ticket object to cache failed, {bugs_local}")
                            bugs = c_bugs(bugs, bugs_local)
                            bugs = s_bugs(bugs)
                            return None

                        elif updated_ticket is not None:
                            logger_1.info(f"Ticket rejected successfully")
                            return ticket_s3_data





# function to create the ticket object for rds cache
@error_handler(library_code=lib_code_ver_FT, function_code="28")
def create_ticket_object_from_df(ticket_df):
    if ticket_df.empty:
        print("The DataFrame is empty. No ticket data available to cache.")
        return None

    # Assuming there's exactly one row that matches, or you are only interested in the first match
    ticket_data = ticket_df.iloc[0].to_dict()

    def format_date(date):
        # Helper function to format the date, checks if the date is not NaT
        return date.strftime('%Y-%m-%d %H:%M:%S') if not pd.isnull(date) else None

    # Convert DataFrame types to appropriate cache format
    ticket_object = {
        "ticket_name": ticket_data.get("ticket_name"),
        "added_by": int(ticket_data.get("added_by")),
        "assigned_to": int(ticket_data.get("assigned_to")),
        "added_on": format_date(ticket_data.get("added_on")),
        "priority": int(ticket_data.get("priority")),
        "approved_status": ticket_data.get("approved_status"),
        "approved_on": format_date(ticket_data.get("approved_on")),
        "deadline": format_date(ticket_data.get("deadline")),
        "assigned_team": int(ticket_data.get("assigned_team")),
        "status": int(ticket_data.get("status")),
        "group_id": ticket_data.get("group_id"),
        "libraries": ticket_data.get("libraries")
    }

    return ticket_object


# function to add the newly created ticket to the RDS cache
@error_handler(library_code=lib_code_ver_FT,function_code="29")
def add_ticket_to_rds_cache(ticketid, bugs={}):

    '''
    
    Function to add a newly created ticket to the RDS cache

    params : ticketid
    returns : bool

    
    '''

    result = False

    # fetch the ticket using query table function 
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        all_ticket_records = ns.query(FT_RDS).all()
            
        # Ensure the 'id' column is of type int
        all_ticket_records['id'] = all_ticket_records['id'].astype(int)

        logger_1.info(f"All feature tickets: {all_ticket_records}")

        # filter the ticket from all_ticket_records pd df using the ticket id
        ticket_df = all_ticket_records[all_ticket_records['id'] == int(ticketid)]

        logger_1.info(f"Filtered ticket DataFrame: {ticket_df}")

        # call the create ticket object from df function to create the ticket object
        ticket_object,bugs_local = create_ticket_object_from_df(ticket_df)

        if bugs_local:
            logger_1.error(f"Failed to create the ticket object, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return result
        
        elif ticket_object is not None:

            # Fetch the existing tickets from Redis
            try:
                existing_tickets_json = redis_instance.get_key('rds_feat_tickets_cached')
                if existing_tickets_json:
                    existing_tickets = json.loads(existing_tickets_json)
                else:
                    existing_tickets = {}
            except Exception as e:
                print(f"Error fetching existing tickets from Redis: {e}")
                return result

            # Add or update the ticket in the dictionary
            existing_tickets[ticketid] = ticket_object

            # Write the updated dictionary back to Redis
            try:
                redis_instance.set_key('rds_feat_tickets_cached', json.dumps(existing_tickets))
                print(f"Ticket with ID {ticketid} added/updated in cache.")
                result = True

            except Exception as e:
                print(f"Error updating tickets in cache: {e}")
                return result

    return result
    


async def process_delete_feature_ticket(delete_request: DeleteFeatureTicket):
    
    ### importing task utils here to avoid circular imports ###
    from utils.tasks_utils import delete_task_service
    
    
    """
    Function to process the deletion of one or multiple feature tickets.

    Params:
    - delete_request: DeleteFeatureTicket object containing ticket_ids and deleted_by.

    Returns:
    - JSONResponse with success or failure message.
    """
    
    
    
    bugs = {}

    for ticket_id in delete_request.ticket_ids:
        try:
            # Check user permissions for the ticket
            has_permission, bugs_local = check_user_has_permissions(
                ticketid=ticket_id,
                userid=delete_request.deleted_by,
                ticket_type=6
            )

            if bugs_local:
                logger_1.error(f"Permission check failed for ticket ID {ticket_id}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to delete ticket, unknown error occurred."},
                                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            elif not has_permission:
                # Fetch ticket data to get the ticket name for the error message
                ticket_data, bugs_local = fetch_and_cache_ticket(ticketid=ticket_id, ticket_type=6)
                
                
                if bugs_local:
                    logger_1.error(f"Failed to fetch ticket data for ticket ID {ticket_id}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return JSONResponse({"error": "Failed to delete ticket, unknown error occurred."},
                                        status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
                    
                elif ticket_data is not None:
                
                    ticket_name = ticket_data["1"]["ticket_name"] if ticket_data else "Unknown"
                    
                    logger_1.info(f"Ticket named {ticket_name}")
                    
                    error_message = f"You don't have sufficient permission to delete the ticket named {ticket_name}"
                    logger_1.info(error_message)
                    return JSONResponse({"error": error_message}, status_code=http_status.HTTP_401_UNAUTHORIZED)
                
            
            # get the task_blocks from metadata
            task_blocks_in_ticket = ticket_data['0']['task_blocks']
            
            # only get the keys from the task_blocks
            task_blocks_to_delete = [str(values) for task,values in task_blocks_in_ticket]
            
            logger_1.info(f"Task blocks to delete: {task_blocks_to_delete}")
            
            # Delete related tasks
            task_delete_input = DeleteTask_Input(
                ticketid=ticket_id,
                ticket_type=6,
                task_ids=task_blocks_to_delete,
                deleted_by=delete_request.deleted_by
            )

            # before removing ticket cache, delete the tasks associated with the ticket
            tasks_deleted, bugs_local = delete_task_service(task_delete_input)

            if not tasks_deleted:
                logger_1.error(f"Failed to delete tasks related to ticket ID {ticket_id}.")
                return JSONResponse({"error": f"Failed to delete tasks related to ticket ID {ticket_id}."},
                                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Delete the ticket from RDS
            session = rds_instance.get_connection()
            with handle_session(session) as ns:
                ticket_record = ns.query(FT_RDS).filter(FT_RDS.id == ticket_id).first()

                if not ticket_record:
                    logger_1.info(f"Ticket with ID {ticket_id} does not exist in RDS.")
                    return JSONResponse({"error": f"Ticket with ID {ticket_id} does not exist in RDS."},
                                        status_code=http_status.HTTP_404_NOT_FOUND)

                ns.delete(ticket_record)
                ns.commit()
                logger_1.info(f"Ticket with ID {ticket_id} deleted from RDS.")

            # Delete the ticket from S3
            delete_s3_key = f"{feat_ticket_path}{str(ticket_id).zfill(5)}.json"
            deletion_success, bugs_local = hiperft_bucket.delete_file_from_s3(delete_s3_key)

            if bugs_local:
                logger_1.error(f"Failed to delete ticket with ID {ticket_id} from S3, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": f"Failed to delete ticket with ID {ticket_name} from S3."},
                                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


            if not deletion_success:
                logger_1.error(f"Failed to delete ticket with ID {ticket_id} from S3.")
                return JSONResponse({"error": f"Failed to delete ticket with ID {ticket_id} from S3."},
                                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            

            # Remove individual S3 ticket cache
            feat_ticket_cache_key = f"feat_ticket_{ticket_id}"
            redis_instance.delete_key(feat_ticket_cache_key)
            logger_1.info(f"Removed cache for ticket ID {ticket_id} from Redis: {feat_ticket_cache_key}")

        except Exception as ticket_error:
            logger_1.error(f"Error occurred while processing ticket ID {ticket_id}, {ticket_error}")
            return JSONResponse({"error": f"Failed to delete ticket ID {ticket_id}. {str(ticket_error)}"},
                                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    # Update RDS feature tickets cache after successful deletion
    logger_1.info("Updating RDS feature tickets cache after deletion.")
    redis_instance.delete_key("rds_feat_tickets_cached")
    all_feat_records()  # Refresh cache by calling the function that fetches and stores tickets in Redis.

    return JSONResponse({"message": "Feature tickets deleted successfully"}, status_code=http_status.HTTP_200_OK)


