# Import inbuilt libraries
import os
from datetime import datetime, timedelta
import pandas as pd
from sqlalchemy import not_



# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException



# Include repos folder for custom libraries



# Declare variables used 



# Library Code for TRIP Automation Module
lib_code_TAM = "53"
lib_ver_TAM = "00"

lib_code_ver_TAM = f"{lib_code_TAM}{lib_ver_TAM}"

api_key=os.getenv("OPENC_api_key")


# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import prod_rds_instance
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import create_event_table_class,create_trips_table_class, VehicleRegistrationNew as VR_RDS
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.other_utils.vehicles_util import calculate_trip_metrics
from hiper_utils.other_utils.resource_util import ResourceUtil


# initialize the logger
logger_1 = LoggerFactory(name="trip_automation_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model

# define other funcs


# func to fetch the events table and update the trips 
@error_handler(library_code=lib_code_TAM, function_code="01")
def fetch_events_table_and_update_trips(vehicle_number: str = None, bugs={}):
    """
    Fetches the events table and updates the trips table based on new logic.

    Args:
        vehicle_number: Optional[str] - If provided, only process this vehicle. Otherwise, process all vehicles.

    Returns:
        bool: overall_success indicating if all vehicles were processed successfully
        bugs: dict containing any errors encountered
    """

    vehicle_number = "TN30BR9702"
    
    # Start a session
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        if vehicle_number:
            all_vehicles = [vehicle_number]
        else:
            all_vehicles = [
                veh.vehicle_num
                for veh in ns.query(VR_RDS)
                .filter(
                    not_(VR_RDS.vehicle_num.startswith("PROCESS")),
                    not_(VR_RDS.vehicle_num.startswith("TEST_RIG"))
                ).all()
            ]

        logger_1.info(f"Processing vehicles: {all_vehicles}")

        for vehicle_number in all_vehicles:
            try:
                vehicle_event_table = create_event_table_class(vehicle_number)
                vehicle_trips_table = create_trips_table_class(vehicle_number)

                ensure_trips_table_exists(vehicle_number, prod_rds_instance.engine)

                trips_exists = session.query(vehicle_trips_table).count() > 0

                if not trips_exists:
                    logger_1.info(f"Trips table for vehicle {vehicle_number} is empty. Querying all events.")
                    events_query = session.query(vehicle_event_table)
                    events_table = events_query.all()
                else:
                    last_trip = session.query(vehicle_trips_table).order_by(
                        vehicle_trips_table.end_time.desc()).first()
                    
                    last_trip_end_time = last_trip.end_time if last_trip else None

                    if last_trip_end_time:
                        logger_1.info(f"Querying events after {last_trip_end_time} for vehicle {vehicle_number}.")
                        events_query = session.query(vehicle_event_table).filter(
                            vehicle_event_table.server_time > last_trip_end_time
                        )
                    else:
                        events_query = session.query(vehicle_event_table)

                    events_table = events_query.all()

                events_table_dict = {
                    event.id: {key: value for key, value in event.__dict__.items() if key != '_sa_instance_state'}
                    for event in events_table
                }
                events_table_df = pd.DataFrame.from_dict(events_table_dict, orient="index")

                if events_table_df.empty:
                    logger_1.info(f"No new events found for vehicle {vehicle_number}. Skipping.")
                    continue

                logger_1.info(f"Processing events table for vehicle {vehicle_number}")

                # # **Process events and form trips**
                trips_table, bugs_local = form_and_update_trips(events_table_df, vehicle_number)

                if bugs_local:
                    logger_1.error(f"Forming trips for {vehicle_number} failed, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return False

                # logger_1.info(f"Trips table formed for {vehicle_number} , {trips_table}")
                
                # Add new trips to the database
                if not trips_table.empty:
                    logger_1.info(f"Trips table formed successfully for vehicle {vehicle_number}. Adding new trips.")

                    for _, trip in trips_table.iterrows():
                        # Remove 'id' column if present before inserting into the database
                        trip_dict = trip.to_dict()
                        trip_dict.pop("id", None)  # Safely remove the 'id' key
                        new_trip = vehicle_trips_table(**trip_dict)
                        session.add(new_trip)
                    session.commit()
                
            except Exception as e:
                logger_1.error(f"Exception occurred while processing vehicle {vehicle_number}: {e}")
                
                # **Stop execution immediately**
                return False  

    return True # If everything succeeded, return success





def serialize_location(location):
    """Convert a tuple (latitude, longitude) into a string 'lat,lon'."""
    if isinstance(location, tuple) and len(location) == 2:
        return f"{location[0]},{location[1]}"

@error_handler(library_code=lib_code_TAM, function_code="02")
def form_and_update_trips(events_table: pd.DataFrame, vehicle_number: str, bugs={}):
    '''
    Forms trips based on events data and updates the trips table.

    Parameters:
        - events_table : pd.DataFrame
        - vehicle_number: str

    Returns:
        - trips_table : pd.DataFrame
        - trip_event_mapping : list of dicts mapping trip_id to event_ids
        - bugs : dict
    '''

    # Initialize variables
    trips = []
    
    # Ensure events_table is sorted by server_time
    events_table['server_time'] = pd.to_datetime(events_table['server_time'])
    events_table = events_table.sort_values(by="server_time").reset_index(drop=True)

    # Variables to track trip formation
    trip = []
    trip_ids = []
    last_engine_off_time = None

    # Calculate fuel and distance for trips
    total_fuel = 0
    total_distance = 0

    for idx, event in events_table.iterrows():
        event_time = event['server_time']
        event_type = event['event_type']

        if event_type == 4:  # Engine On
            if last_engine_off_time and (event_time - last_engine_off_time > timedelta(minutes=60)):
                # End the current trip and start a new one
                trips.append({
                    'events': trip,
                    'ids': trip_ids,
                    'fuel_consumed': total_fuel,
                    'distance': total_distance
                })
                trip = []
                trip_ids = []
                total_fuel = 0
                total_distance = 0

            # Add the Engine On event to the trip
            trip.append(event)
            trip_ids.append(event['id'])
            last_engine_off_time = None  # Reset engine off time

        elif event_type == 5 or event_type == 15:  # Engine Off or Device Sleep
            if trip:
                trip.append(event)
                trip_ids.append(event['id'])
                last_engine_off_time = event_time

        # Accumulate fuel and distance if available
        if not pd.isna(event.get('data')):  # Assuming 'data' holds fuel and distance information
            data_values = str(event['data']).split(',')
            if len(data_values) >= 2:
                try:
                    total_fuel += float(data_values[0])
                    total_distance += float(data_values[1])
                except ValueError:
                    pass

    # Add the last trip if it exists
    if trip:
        trips.append({
            'events': trip,
            'ids': trip_ids,
            'fuel_consumed': total_fuel,
            'distance': total_distance
        })

    # Convert trips to DataFrame
    trips_table = pd.DataFrame(
        [
            {
                "id": idx + 1,
                "start_time": trip['events'][0]['server_time'],
                "end_time": trip['events'][-1]['server_time'],
                "start_event_id": trip['events'][0]['id'],
                "end_event_id": trip['events'][-1]['id'],
                "start_file_num": trip['events'][0]['data'],
                "end_file_num": (
                    trip['events'][-1]['data'] if trip['events'][-1]['data'] != ""
                    else str(get_file_number_from_file_overflow_event(events_table, trip['events'][0]['id'], trip['events'][-1]['id']))
                ),
                "total_fuel_consumed": 0,  # Placeholder
                "distance": 0,  # Placeholder
                "idle_time": 0,  # Placeholder
                "start_location": serialize_location((trip['events'][0]['latitude'], trip['events'][0]['longitude'])),
                "end_location": serialize_location((trip['events'][-1]['latitude'], trip['events'][-1]['longitude'])),
                "remarks": None,
                "verified": None
            }
            for idx, trip in enumerate(trips)
        ]
    )

    # **Pass each trip to `calculate_trip_metrics` and update metrics**
    for index, row in trips_table.iterrows():
        start_event_id = row["start_event_id"]
        end_event_id = row["end_event_id"]

        metrics, bugs_local = calculate_trip_metrics(start_event_id, end_event_id, vehicle_number)

        if bugs_local:
            logger_1.error(f"Error calculating trip metrics for vehicle {vehicle_number} (start: {start_event_id}, end: {end_event_id})")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
            
        # **Update the DataFrame row with computed metrics**
        trips_table.loc[index, "total_fuel_consumed"] = metrics.get("total_fuel_consumed", 0)
        trips_table.loc[index, "distance"] = metrics.get("distance", 0)
        trips_table.loc[index, "idle_time"] = metrics.get("idle_time", 0)

    return trips_table



from sqlalchemy import inspect

def ensure_trips_table_exists(vehicle_number, engine):
    """
    Ensure the trips table exists for the given vehicle number.

    Args:
        vehicle_number (str): The vehicle number for which the trips table is created.
        engine: The SQLAlchemy engine instance.
    """
    # Dynamically create the trips table class
    TripsRDS = create_trips_table_class(vehicle_number)

    # Get the table name
    table_name = TripsRDS.__tablename__

    # Check if the table exists
    inspector = inspect(engine)
    if table_name not in inspector.get_table_names():
        # Create the table
        TripsRDS.__table__.create(bind=engine)
        print(f"Table '{table_name}' created successfully.")
    else:
        print(f"Table '{table_name}' already exists.")
        
        


def get_vehicle_summary(cls, vehicle_num: str, start_date: str, end_date: str, bugs={}):
    print(f"Getting Vehicle Summary for {vehicle_num} from {start_date} to {end_date}")

    start_date_dt = datetime.strptime(start_date, "%Y-%m-%d")
    end_date_dt = datetime.strptime(end_date, "%Y-%m-%d")

    df, summary_download_bug = ResourceUtil().get_vehicle_summary(vehicle_num=vehicle_num)
    
    if summary_download_bug:
        logger_1.error("Failed to download the summary parquet")
        bugs = c_bugs(bugs,summary_download_bug)
        bugs = s_bugs(bugs)
        return None
    
    df['start_date_obj'] = pd.to_datetime(df['start_date'])
    filtered_df = df[(df['start_date_obj'] >= start_date_dt) & (df['start_date_obj'] <= end_date_dt)]
    filtered_df.drop(columns=['start_date_obj'], inplace=True)
    
    
    
# func to calculate distance and fuel consumed from log data
def calculate_trip_metrics_using_log_file(start_file_number , end_file_number):
    
    '''
    
    Calculate trip metrics using the log file 
    
    params:
        - start_file_number : log file number
        - end_file_number : log file number
        
    returns 
    
    '''
    
    pass


# func to get the file overflow value if the event type engine off data is empty
def get_file_number_from_file_overflow_event(events_df: pd.DataFrame, start_event_id: int, end_event_id: int) -> int:
    """
    Function to fetch the file number from the most recent file overflow event.

    Parameters:
        events_df : pd.DataFrame - DataFrame containing events
        start_event_id : int - Start event ID of the trip
        end_event_id : int - End event ID of the trip

    Returns:
        end_file_number : int - The new file ID from the latest file overflow event, or None if not found.
    """

    # Filter events of type 20 (File Overflow) within the event ID range
    file_overflow_events = events_df[
        (events_df["event_type"] == 20) &
        (events_df["id"] >= start_event_id) &
        (events_df["id"] <= end_event_id)
    ]

    # Check if there are any file overflow events in the given range
    if not file_overflow_events.empty:
        # Get the last (most recent) file overflow event
        last_event = file_overflow_events.iloc[-1]

        # Extract the second value (new file ID) from the 'data' column
        data_values = str(last_event["data"]).split(",")
        if len(data_values) > 1:
            try:
                return int(data_values[1])  # Convert to integer and return the new file number
            except ValueError:
                pass  # If conversion fails, return None

    # Return None if no valid file number was found
    return None