# Import inbuilt libraries


# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException





# Include repos folder for custom libraries


# Declare variables used 
# Library Code for Conversation Module
lib_code_CM = "48"
lib_ver_CM = "00"

lib_code_ver_CM = f"{lib_code_CM}{lib_ver_CM}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import hiperft_bucket,feat_ticket_path,current_date,bug_ticket_path
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.data_models.s3_data_models.feature_ticket import *
from hiper_utils.data_models.s3_data_models.common_models import *
from hiper_utils.other_utils.bug_util import add_bug
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.feature_ticket_schema import *
from schema.common_schema import *
from utils.users_utils import *
from utils.common_util import *
from schema.conversation_schema import *

# initialize the logger
logger_1 = LoggerFactory(name="feature_ticket_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model


# define other funcs





# function to add a conversation to a ticket s3 object
@error_handler(library_code=lib_code_ver_CM,function_code="01")
def add_conversation_to_ticket(conversation : Add_Conversation_Model,ticket_location, bugs={}):

    # download the ticket data from s3
    ticket_data, bugs_local = hiperft_bucket.download_json(
        s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json")

    if bugs_local:
        logger_1.error(f"Retrieving the feat ticket from s3 failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_data is not None:

        # create a new conversation block
        conversation_block = {
            'added_by': conversation.added_by,
            'text': conversation.text,
            'parent_block': conversation.parent_block,
        }

        # serialize the conversation block
        serialized_conversation = ConversationBlock(**conversation_block)

        # get the last key in the ticket_data
        last_key = list(ticket_data.keys())[-1]

        # get the next block id
        block_id = int(last_key) + 1

        # add the conversation block to the ticket_data
        ticket_data[str(block_id)] = serialized_conversation.model_dump()

        # create a new status block to the ticket saying that the conversation is added
        status_block_id = int(block_id) + 1

        status_block = {
            'status_change_description': f'Conversation added',
            'updated_by': conversation.added_by
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_data[str(status_block_id)] = serialized_status.model_dump()

        # update the metadata of the ticket
        metadata = ticket_data['0']
        metadata['updated_by'] = conversation.added_by
        metadata['updated_on'] = current_date
        metadata['status_blocks'].append(str(status_block_id))

        # add a key value pair to the conv blocks with key as parent block and value as block id
        related_convo_block = metadata['conv_blocks']

        if str(conversation.parent_block) not in related_convo_block:

            # create a new key value pair in the conv blocks with key as parent block and list as value with block id as the first element
            related_convo_block[str(conversation.parent_block)] = [str(block_id)]

        else:
            # append the block id to the list of block ids
            related_convo_block[str(conversation.parent_block)].append(str(block_id))

        # push the updated ticket to s3
        result, bugs_local = hiperft_bucket.write_json_to_s3(
            s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json", data_dict=ticket_data)

        if bugs_local:
            logger_1.error(f"Adding conversation to ticket failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        else:
            # download the updated ticket data
            ticket_data, bugs_local = hiperft_bucket.download_json(
                s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json")

            if bugs_local:
                logger_1.error(f"Retrieving the feat ticket from s3 failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)

            elif ticket_data is not None:
                logger_1.info(f"Conversation added successfully")

    return ticket_data


# function to delete a conversation in a ticket s3 object
@error_handler(library_code=lib_code_ver_CM,function_code="02")
def delete_conversation_from_ticket(conversation : Delete_Conversation_Model):
    
    logger_1.info(f"conversation block to delete is {conversation.convo_id}")

    ticket_location = feat_ticket_path

    if conversation.ticket_type == 1:
        ticket_location = bug_ticket_path 

    # download the ticket data from s3
    ticket_data, bugs_local = hiperft_bucket.download_json(
        s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json")

    if bugs_local:
        logger_1.error(f"Retrieving the feat ticket from s3 failed, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_data is not None:

        # get the conversation block from the ticket_data
        conversation_block = ticket_data[str(conversation.convo_id)]

        # get the parent block of the conversation block
        parent_block = conversation_block['parent_block']

        convo_block_text = conversation_block['text']

        # delete the conversation block from the ticket_data
        del ticket_data[str(conversation.convo_id)]

        # convo block with parent
        related_convo_block = ticket_data['0']['conv_blocks'][str(parent_block)]

        # itterate over the list to find the block id and delete it
        for con_id in related_convo_block:
            logger_1.info(f"con id is {con_id}")
            if str(con_id) == str(conversation.convo_id):
                related_convo_block.remove(str(conversation.convo_id))
                break

        # after deleting if the list is empty, delete the key from the conv blocks
        if len(related_convo_block) == 0:
            del ticket_data['0']['conv_blocks'][str(parent_block)]

        # fetch the last key in the ticket_data
        last_key = list(ticket_data.keys())[-1]

        # create a new status block saying that the conversation is deleted
        status_block_id = int(last_key) + 1

        status_block = {
            'status_change_description': f'Conversation named {convo_block_text} deleted',
            'updated_by': conversation.deleted_by
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_data[str(status_block_id)] = serialized_status.model_dump()

        # update the metadata of the ticket
        metadata = ticket_data['0']
        metadata['updated_by'] = conversation.deleted_by
        metadata['updated_on'] = current_date
        metadata['status_blocks'].append(str(status_block_id))

        # push the updated ticket to s3
        result, bugs_local = hiperft_bucket.write_json_to_s3(
            s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json", data_dict=ticket_data)

        if bugs_local:
            logger_1.error(f"Deleting conversation from ticket failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        else:
            # download the updated ticket data
            ticket_data, bugs_local = hiperft_bucket.download_json(
                s3_key=f"{ticket_location}{str(conversation.ticketid).zfill(5)}.json")

            if bugs_local:
                logger_1.error(f"Retrieving the feat ticket from s3 failed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif ticket_data is not None:
                logger_1.info(f"Conversation deleted successfully")

    return ticket_data

