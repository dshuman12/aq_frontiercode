# Import inbuilt libraries



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
from datetime import datetime, timedelta
import json
import random
import time
from fastapi.responses import JSONResponse
import numpy as np
import pandas as pd
from collections import deque

# Include repos folder for custom libraries


# Declare variables used 
# Library code for fleets library

lib_code_FL = "50"
lib_ver_FL = "00"

lib_code_ver_FL = f"{lib_code_FL}{lib_ver_FL}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import prod_rds_instance,hiperft_bucket,get_current_date,redis_instance,rds_instance
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.fleets_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import Fleet, VehicleRegistrationNew as VR_RDS



# initialize the logger
logger_1 = LoggerFactory(name="fleet_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model
# define other funcs

@error_handler(library_code=lib_code_ver_FL, function_code="01")
def get_fleet_rds_df():
    '''
    Function to fetch all the fleets from the database or from the cache

    params:
        - None

    returns:
        - fleet_df: pandas dataframe with fleet data, None if failed to fetch data or no data found
        - bugs_dict: dictionary with error message if any error occurs
    '''

    # Check if the data is present in the cache
    fleet_df_json = redis_instance.get_key("fleets_cached")

    if fleet_df_json:
        fleet_dict = json.loads(fleet_df_json)  # Load the cached JSON string as a dictionary
        logger_1.info(f"Fleets fetched from the cache, {fleet_dict}")
        return pd.DataFrame.from_dict(fleet_dict, orient='index')  # Convert back to DataFrame if needed
    
    # Init a session
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        # Fetch all the fleets
        fleets = ns.query(Fleet).all()

        logger_1.info(f"Fleets fetched from the database, {fleets}")

        # Create a dictionary to store the fleet data with fleet ID as key
        fleet_dict = {}

        for fleet in fleets:
            fleet_dict[fleet.id] = {
                "id" : fleet.id,
                "fleet_name": fleet.fleet_name,
                "number_of_vehicles": fleet.num_of_vehicles,
                "distributor_id": fleet.distributor_id
            }

        # Store the data in the cache as a dict of dicts
        redis_instance.set_key("fleets_cached", json.dumps(fleet_dict), ex=10800)  # Convert to JSON string

        return pd.DataFrame.from_dict(fleet_dict, orient='index') 
    

# function to add a new fleet
@error_handler(library_code=lib_code_ver_FL, function_code="02")
def add_new_fleet_to_rds(fleet : Add_Fleet):

    '''
    
    Function to add a new fleet to the database

    params:
        - fleet : Add_Fleet : pydantic model with fleet data

    returns:
        - success: success message
        - bugs_dict: dictionary with error message if any error occurs
    
    
    '''

    # init a boolean flag named success
    success = False

    # Init a session
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        # Create a Fleet object
        new_fleet = Fleet(
            fleet_name=fleet.fleet_name,
            num_of_vehicles=fleet.number_of_vehicles,
            distributor_id=fleet.distributor_id,
            created_at=get_current_date(),
        )

        # Add the new fleet to the database
        ns.add(new_fleet)
        ns.commit()

        logger_1.info(f"New fleet added to the database, {new_fleet}")

        # delete the cached data
        redis_instance.delete_key("fleets_cached")

        success = True

    return success


# function to update fleet details
@error_handler(library_code=lib_code_ver_FL, function_code="03")
def update_fleet_in_fleet_rds(fleet : Update_Fleet):

    '''
    
    Function to update fleet details in the database

    params:
        - fleet : Update_Fleet : pydantic model with fleet data

    returns:
        - success: success message
        - bugs_dict: dictionary with error message if any error occurs
    
    
    '''

    # init a boolean flag named success
    success = False

    # Init a session
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        # Fetch the fleet object
        fleet_obj = ns.query(Fleet).filter(Fleet.id == fleet.fleet_id).first()

        # Update the fleet details
        if fleet.fleet_name:
            fleet_obj.fleet_name = fleet.fleet_name
        
        if fleet.number_of_vehicles:
            fleet_obj.num_of_vehicles = fleet.number_of_vehicles
        
        if fleet.distributor_id:
            fleet_obj.distributor_id = fleet.distributor_id

        # Commit the changes
        ns.commit()

        logger_1.info(f"Fleet details updated in the database, {fleet_obj}")

        # delete the cached data
        redis_instance.delete_key("fleets_cached")

        success = True

    return success


# function to delete a fleet
@error_handler(library_code=lib_code_ver_FL, function_code="04")
def delete_fleet_from_rds(fleet : Delete_Fleet):

    '''
    
    Function to delete a fleet from the database

    params:
        - fleet : Delete_Fleet : pydantic model with fleet data

    returns:
        - success: success message
        - bugs_dict: dictionary with error message if any error occurs
    
    
    '''

    # init a boolean flag named success
    success = False

    # Init a session
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        # Fetch the fleet object
        fleet_obj = ns.query(Fleet).filter(Fleet.id == fleet.fleet_id).first()

        # Delete the fleet
        ns.delete(fleet_obj)
        ns.commit()

        logger_1.info(f"Fleet deleted from the database, {fleet_obj}")

        # delete the cached data
        redis_instance.delete_key("fleets_cached")

        success = True

    return success



# function to fetch fleet name provided reg_no 
@error_handler(library_code=lib_code_ver_FL, function_code="05")
def get_fleet_name(reg_no : str):

    '''

    Function to fetch fleet name provided fleet id

    params

        - reg_no : str : vehicle number

    returns

        - fleet_name : str : fleet name
    
    '''

    fleet_name = None

    session = prod_rds_instance.get_connection()

    # use join and filter to fetch the fleet name from vehicle regisration table
    with handle_session(session) as ns:
        fleet_name = ns.query(Fleet.fleet_name).join(VR_RDS, Fleet.id == VR_RDS.fleet_id).filter(VR_RDS.vehicle_num == reg_no).first().fleet_name        

    return fleet_name
