import os
from datetime import datetime, timedelta
import sys
import json
from typing import List
import threading
import io
import zipfile
import pytz
import struct

sys.path.append("../../")

from hiper_utils.aws.s3.s3 import S3Bucket
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB, handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistration, ActiveVehicle, Fleet, \
    DriverMaster, VehicleRegistrationNew, \
    create_pings_table_class, HWUno2, DeviceRegistrationNew, DeviceRegistrationNew, VehicleDeviceLogs, \
    DeviceSoftwareVersions, TestRequestTicket, TestRigTracker, DsmStatus
from hiper_utils.other_utils.vehicles_util import get_location_from_lat_lon
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path

from schema.ops_dash_schema import *

from sqlalchemy import and_
from sqlalchemy import text, update
from sqlalchemy.orm import aliased
import pandas as pd
import numpy as np
from sqlalchemy import func

lib_code = '30'
lib_ver = '00'
lib_code_ver = f"{lib_code}{lib_ver}"

hiperdatalake = S3Bucket(
    bucket_name="hiperdatalake"
)

new_prod_schema = MySQLDB(
    db_name="new_production_schema",
    env_var_prefix="MYSQL"
)


class VehicleStatus:
    prod_rds = MySQLDB(
        db_name="lite_db",
        env_var_prefix="MYSQL"
    )

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="01")
    def get_vehicle_status(cls):
        session = new_prod_schema.get_connection()

        query_to_copy_data = """
        UPDATE new_production_schema.vehicle_device_logs vd
        JOIN lite_db.ACTIVE_VEHICLES av
          ON vd.vehicle_num = av.vehicle_num AND vd.device_id = av.device_id
        SET 
          vd.latitude = av.latitude,
          vd.longitude = av.longitude,
          vd.last_ping_time = av.last_ping_time;
        """  ###  COPY FROM ACTIVE VEHICLE , TO VEHICEL DEVICE LOGS

        print("========  Copying complete")
        # with handle_session(session) as ns:

        with handle_session(session) as ns:
            ns.execute(text(query_to_copy_data))

            VehicleRegAlias = aliased(VehicleRegistrationNew)
            VehicleDeviceLogsAlias = aliased(VehicleDeviceLogs)
            FleetAlias = aliased(Fleet)

            query = ns.query(
                VehicleRegAlias.vehicle_num,
                VehicleRegAlias.fleet_id,
                VehicleRegAlias.active_status,
                VehicleDeviceLogsAlias.device_id,
                VehicleDeviceLogsAlias.latitude,
                VehicleDeviceLogsAlias.longitude,
                VehicleDeviceLogsAlias.last_log_file_s3,
                VehicleDeviceLogsAlias.last_processed_file,
                VehicleDeviceLogsAlias.last_ping_time,
                VehicleDeviceLogsAlias.last_processed_file_time,
                FleetAlias.fleet_name
            ).join(
                VehicleDeviceLogsAlias,
                and_(
                    VehicleRegAlias.vehicle_num == VehicleDeviceLogsAlias.vehicle_num,
                    VehicleRegAlias.device_id == VehicleDeviceLogsAlias.device_id
                )
            ).join(
                FleetAlias,
                VehicleRegAlias.fleet_id == FleetAlias.id
            ).filter(
                VehicleRegAlias.active_status == 1
            )

            result = query.all()

            result_list = [
                {
                    "vehicle_num": row.vehicle_num,
                    "active_status": row.active_status,
                    "device_id": row.device_id,
                    "latitude": row.latitude,
                    "longitude": row.longitude,
                    "last_log_file_s3": row.last_log_file_s3,
                    "last_processed_file": row.last_processed_file,
                    "fleet_name": row.fleet_name,
                    'last_processed_file_time': row.last_processed_file_time,
                    "last_ping_time": row.last_ping_time
                }
                for row in result
            ]

            vehicle_status_df = pd.DataFrame(result_list)

            vehicle_status_df['last_ping_time'] = pd.to_datetime(vehicle_status_df['last_ping_time'])
            # Add 5 hours and 30 minutes to each last_ping_time to convert to IST
            vehicle_status_df['last_ping_time'] = vehicle_status_df['last_ping_time'] + pd.Timedelta(hours=5,
                                                                                                     minutes=30)
            vehicle_status_df['last_ping_time'] = vehicle_status_df['last_ping_time'].dt.strftime('%Y-%m-%dT%H:%M:%S')

            vehicle_status_df = vehicle_status_df[~vehicle_status_df['vehicle_num'].str.contains("TEST")]
            vehicle_status_df['location'] = vehicle_status_df.apply(
                lambda row: get_location_from_lat_lon(row['latitude'], row['longitude'])[0],
                axis=1)
            vehicle_status_df['location'] = vehicle_status_df['location'].apply(
                lambda x: "" if x is None else x[0] + " ," + x[1])
            # print(vehicle_status_df['location'])
            vehicle_status_df['last_processed_file_time'] = pd.to_datetime(
                vehicle_status_df['last_processed_file_time'])

            vehicle_status_df['Data Loss (days)'] = (
                    (datetime.now() + timedelta(hours=5, minutes=30)) - vehicle_status_df['last_processed_file_time']
            ).dt.days

            vehicle_status_df['last_processed_file_time'] = vehicle_status_df[
                                                                'last_processed_file_time'] + pd.Timedelta(hours=5,
                                                                                                           minutes=30)
            vehicle_status_df['last_processed_file_time'] = vehicle_status_df['last_processed_file_time'].dt.strftime(
                '%Y-%m-%dT%H:%M:%S')

            vehicle_status_df['last_log_file'] = vehicle_status_df['device_id'].apply(
                lambda device_id: 0)

            vehicle_status_df.fillna('', inplace=True)
            vehicle_status_json = vehicle_status_df.to_dict(orient='list')

            return vehicle_status_json

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="17")
    def get_last_log_file_from_pings(cls, device_id):
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            pings_table = create_pings_table_class(device_id=device_id)

            latest_record = ns.query(pings_table.data) \
                .filter(pings_table.type == 19) \
                .order_by(pings_table.time_at_server.desc()) \
                .first()

            return int(latest_record[0])

    @staticmethod
    @error_handler('30', '12')
    def get_benchmark(trips):
        """
        Get the benchmark for the trips

        here payload refer to Category (i.e chennai dharmapuri )
        """

        benchmark_driver = {}
        benchmark = {}
        payload_lst = list(trips[trips['strat'].astype(int) == 0]['payload'].unique())
        driver_lst = list(trips[trips['strat'].astype(int) == 0]['driver_id'].unique())

        for payload in payload_lst:
            if payload != '0':
                benchmark_driver[payload] = {'distance': {}, 'fc': {}, 'kmpl': {}}

                for driver in driver_lst:
                    df = trips[(trips['payload'] == payload) & (trips['driver_id'] == driver) & (
                            trips['strat'].astype(int) == 0)]
                    distance_sum = sum(df['distance'])
                    fc_sum = sum(df['fc'])

                    if fc_sum != 0:
                        kmpl = distance_sum / fc_sum
                    else:
                        df = trips[(trips['payload'] == payload) & (trips['strat'].astype(int) == 0)]
                        distance_sum = sum(df['distance'])
                        fc_sum = sum(df['fc'])
                        kmpl = distance_sum / fc_sum

                    benchmark_driver[payload]['distance'][driver] = distance_sum
                    benchmark_driver[payload]['fc'][driver] = fc_sum
                    benchmark_driver[payload]['kmpl'][driver] = kmpl

                benchmark[payload] = sum(df['distance']) / sum(df['fc'])

        return benchmark_driver, benchmark

    @classmethod
    @error_handler('30', '11')
    def get_improvement(cls, trips, sdate=None, edate=None, fuel_cost=95, bugs={}):

        """ Calculate the improvement in Mileage
        1. Get the benchmark for the trips
        2. Calculate the improvement and savings for each trip
        3. Calculate the improvement and savings for each strategy

        ### Input:
            trips: trips table
            fuel_cost: Fuel cost
            sdate: Start date
            edate: End date

        ### Output:
            improvement_table: Improvement table
            strat_savings: Strategy savings
            improvement_overall: Improvement overall
            improvement_date: Improvement in the queried period
        """

        # Get Benchmark
        result, bugs_local = cls.get_benchmark(trips)
        if result is not None:
            benchmark_driver, benchmark = result
        else:
            benchmark_driver, benchmark = None, None

        combine_bugs(bugs, bugs_local)

        if benchmark is None:
            return None

        ## Calculate Trip level Improvement
        payload_lst = trips['payload'].unique().tolist()
        trips['impr'] = 0
        for j in payload_lst:
            if j in benchmark.keys():
                trips.loc[trips['payload'] == j, 'benchmark'] = benchmark[j]
                trips.loc[trips['payload'] == j, 'impr'] = (trips.loc[trips['payload'] == j, 'kmpl'] / benchmark[
                    j] - 1) * 100
                trips.loc[trips['payload'] == j, 'savings'] = trips.loc[trips['payload'] == j, 'impr'].astype(float) * \
                                                              trips.loc[trips['payload'] == j, 'fc'].astype(
                                                                  float) * float(fuel_cost) / 100
            else:
                trips.loc[trips['payload'] == j, 'savings'] = 0
                trips.loc[trips['payload'] == j, 'impr'] = 0
                trips.loc[trips['payload'] == j, 'benchmark'] = None

        trips.loc[trips['strat'].astype(int) == 0, 'savings'] = 0
        trips.loc[trips['health_flag'] == 1, 'savings'] = 0

        # Round distance, fc, kmpl, impr, savings to 2 decimal places
        trips['distance'] = trips['distance'].round(2)
        trips['fc'] = trips['fc'].round(2)
        trips['kmpl'] = trips['kmpl'].round(2)
        trips['impr'] = trips['impr'].round(2)
        trips['savings'] = trips['savings'].round(2)

        improvement_table = trips
        improvement_table['strat'] = improvement_table['strat'].astype(int)
        # Date wise improvement
        strat_savings = pd.pivot_table(improvement_table, index='start_date',
                                       values=['savings', 'strat', 'health_flag'],
                                       aggfunc={'savings': 'sum', 'strat': 'median', 'health_flag': 'max'})

        strat_savings['cumulative_savings'] = strat_savings['savings'].cumsum()

        # Get All unique values in remarks for each start_date in strat_cum and add it to strat_cum
        strat_savings['remarks'] = ''
        for i in strat_savings.index:
            remarks = ''
            for j in trips[trips['start_date'] == i]['remarks'].unique():
                remarks = remarks + j + ',\n'
            strat_savings.loc[i, 'remarks'] = remarks[:-2]

        # Overall improvement and date wise improvement
        impr_fil = improvement_table[
            (improvement_table['strat'].astype(int) != 0) & (improvement_table['payload'] != '0') & (
                    improvement_table['health_flag'] != 1)]
        if (len(impr_fil) > 0) and (impr_fil['distance'].sum() > 0):
            improvement_overall = round(np.average(impr_fil['impr'], weights=impr_fil['distance']), 2)

            if (sdate is not None) and (edate is not None):
                # Convert sdate and edate from string to datetime
                sdate = datetime.strptime(sdate, "%Y-%m-%d").date()
                edate = datetime.strptime(edate, "%Y-%m-%d").date()
                impr_fil = impr_fil[(impr_fil['start_date'] >= sdate) & (impr_fil['start_date'] <= edate)]
                if (len(impr_fil) > 0) and (impr_fil['distance'].sum() > 0):
                    improvement_date = round(np.average(impr_fil['impr'], weights=impr_fil['distance']), 2)
                else:
                    improvement_date = 0

            else:
                improvement_date = improvement_overall

        else:
            improvement_overall = 0
            improvement_date = 0

        return improvement_table, strat_savings, improvement_overall, improvement_date

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="09")
    def get_optimization_table(cls, bugs={}):
        opti_list: List[OptimizationData] = []
        vehicles_list, vehicle_lst_bug = TripClassification.get_vehicle_list()
        combine_bugs(bugs, vehicle_lst_bug)

        opti_list_lock = threading.Lock()
        bugs_lock = threading.Lock()
        semaphore = threading.Semaphore(4)  # Limit to 4 concurrent threads

        def process_and_collect(veh):
            with semaphore:  # Acquire the semaphore before processing
                opti_data, opt_bug = cls.process_vehicle(veh)
                with bugs_lock:
                    combine_bugs(bugs, opt_bug)
                if opti_data is not None:
                    print(" ==== OPTIMIZATION DATA ==========")
                    print(opti_data)
                    with opti_list_lock:
                        opti_list.append(opti_data)
                    print(f'{veh} done')
                else:
                    print(opt_bug)

        threads = []
        for veh in vehicles_list:
            thread = threading.Thread(target=process_and_collect, args=(veh,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        opt_df = pd.DataFrame([data.dict() for data in opti_list])
        opt_df.fillna('', inplace=True)
        return opt_df.to_dict('records')

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="10")
    def process_vehicle(cls, vehicle_num):

        sum_df, summ_download_bug = ResourceUtil().get_vehicle_summary(vehicle_num=vehicle_num)
        if not isinstance(sum_df, pd.DataFrame):
            return OptimizationData(vehicle_number=vehicle_num)

        sum_df = sum_df[sum_df['proc_flag'] == 0]
        total_distance = round(sum_df['distance'].sum())

        trip_summary_df, trip_summ_bug = ResourceUtil().get_trips_summary(vehicle=vehicle_num)

        if not isinstance(trip_summary_df, pd.DataFrame):
            return OptimizationData(vehicle_number=vehicle_num, total_distance=total_distance)

        improvement_result, bugs_local = cls.get_improvement(trip_summary_df)

        print("=========== Improvement result ==================")

        savings_overall = None
        if improvement_result is not None:
            improvement_table, strat_savings, improvement_overall, improvement_date = improvement_result
            savings_overall = strat_savings['cumulative_savings'].iloc[-1]

        strat_latest = trip_summary_df.iloc[-1]['strat']
        trip_strat = trip_summary_df[
            (trip_summary_df['strat'] == strat_latest) | (trip_summary_df['strat'].astype(int) == 0)]

        latest_strat_imp, latest_strat_bug = cls.get_improvement(trip_strat)
        if latest_strat_imp is not None:
            improvement_table, strat_savings, improvement_strat, improvement_date = latest_strat_imp
            improvement_strat = round(improvement_strat, 2)
            distance_strat = round(trip_summary_df[trip_summary_df['strat'] == strat_latest]['distance'].sum(), 0)

            sum_fil = sum_df[
                (sum_df['start_date'] >= datetime.strptime('2021-01-01', "%Y-%m-%d").date()) &
                (sum_df['start_date'] <= datetime.strptime('2027-01-01', "%Y-%m-%d").date())
                ].sort_values(by='id', ascending=True)

            last_file_date = sum_fil.iloc[-1]['start_date']
            sum_fil = sum_fil[sum_fil['start_date'] >= last_file_date - timedelta(days=60)]
            first_file_date = sum_fil.iloc[0]['start_date']
            days = len(sum_fil['start_date'].unique())
            trips_fil = trip_summary_df[
                (trip_summary_df['start_date'] >= first_file_date) & (trip_summary_df['payload'] != '0')]
            fuel = trips_fil['fc'].sum()
            avg_fuel = fuel / days if days != 0 else 0
            projected_savings = round(avg_fuel * 30 * improvement_strat * 0.01 * 95, 0)

            improvement_table.loc[improvement_table['strat'].astype(int) == 0, 'impr'] = 0
            last_week = datetime.now().date() - timedelta(days=7)
            improvement_table_fil = improvement_table[
                (improvement_table['start_date'] >= last_week) & (improvement_table['payload'] != '0')
                ]

            overall_improvement_table = improvement_table[improvement_table['payload'] != '0']

            last_week_savings = improvement_table_fil['savings'].sum()
            last_week_improvement = round(
                np.average(improvement_table_fil['impr'], weights=improvement_table_fil['fc']),
                2) if improvement_table_fil['fc'].sum() != 0 else 0

            overall_improvement = round(
                np.average(overall_improvement_table['impr'], weights=overall_improvement_table['fc']),
                2) if overall_improvement_table['fc'].sum() != 0 else 0

            return OptimizationData(
                vehicle_number=vehicle_num,
                improvement_latest_strat=improvement_strat,
                last_week_improvement=last_week_improvement,
                distance_latest_strat=distance_strat,
                projected_monthly_savings=projected_savings,
                last_week_savings=last_week_savings,
                overall_savings=savings_overall,
                total_distance=total_distance,
                overall_improvement=overall_improvement
            )


class TripClassification:
    hiperftp_bucket = S3Bucket(
        bucket_name="hiperftp"
    )

    prod_rds = MySQLDB(
        db_name="lite_db",
        env_var_prefix="MYSQL"
    )

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="02")
    def get_vehicle_summary(cls, vehicle_num: str, start_date: str, end_date: str, bugs={}):
        print(f"Getting Vehicle Summary for {vehicle_num} from {start_date} to {end_date}")

        start_date_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_date_dt = datetime.strptime(end_date, "%Y-%m-%d")

        df, summary_download_bug = ResourceUtil().get_vehicle_summary(vehicle_num=vehicle_num)
        combine_bugs(bugs, summary_download_bug)

        df['start_date_obj'] = pd.to_datetime(df['start_date'])
        filtered_df = df[(df['start_date_obj'] >= start_date_dt) & (df['start_date_obj'] <= end_date_dt)]
        filtered_df.drop(columns=['start_date_obj'], inplace=True)

        return json.loads(filtered_df.to_json(orient="records", date_format="iso"))

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='03')
    def get_vehicle_list(cls) -> List[str]:
        session = cls.prod_rds.get_connection()

        print("==== Getting Vehicle List... ")
        with handle_session(session) as ns:
            query = ns.query(
                VehicleRegistration.vehicle_num,

            ).filter(
                VehicleRegistration.active_status == 1
            )

            result = query.all()

            vehicle_list = [row.vehicle_num for row in result if "TEST" not in row.vehicle_num]

            return vehicle_list

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='03')
    def get_vehicle_list_new(cls) -> List[str]:
        session = new_prod_schema.get_connection()

        print("==== Getting Vehicle List... ")
        with handle_session(session) as ns:
            query = ns.query(
                VehicleRegistrationNew.vehicle_num
            )

            result = query.all()

            vehicle_list = [row.vehicle_num for row in result]

            return vehicle_list

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='04')
    def get_trip_data(cls, vehicle_num, bugs) -> List[str]:
        print(f"Getting Vehicle Summary for {vehicle_num}")

        trip_df, trip_download_bug = ResourceUtil().get_trips(vehicle_num=vehicle_num)
        combine_bugs(bugs, trip_download_bug)

        if trip_df is not None:
            payload = list(trip_df['payload'].unique())
            payload.append('0')
            trips_json = json.loads(trip_df.to_json(orient="records", date_format="iso"))
            trips_json = [TripRecord(**trip_record) for trip_record in trips_json]

            trip_data = {
                "trips": trips_json,
                "payloads": payload
            }

        else:
            trip_data = {
                "trips": [],
                "payloads": ['0']
            }

        return trip_data

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='05')
    def add_trip_to_trip_df(cls, trips_df: pd.DataFrame, new_trip_record: TripRecord, vehicle_num: str, bugs={}):
        """
        Update trip record to trip table ,
        returns updated trip table if updated successfully
        """
        if new_trip_record.trip_id is None:
            if trips_df.empty:
                new_trip_id = 1
            else:
                new_trip_id = trips_df['trip_id'].max() + 1
            new_trip_record = new_trip_record.copy(update={"trip_id": new_trip_id})

        new_trip_dict = new_trip_record.model_dump()
        new_trip_df = pd.DataFrame([new_trip_dict])
        trips_df = pd.concat([trips_df, new_trip_df], ignore_index=True)

        trips_file_pth = ResourceS3Path.VEHICLE_TRIPS_PTH.value.replace("{vehicle_num}", vehicle_num)
        update_trip_file, update_bug = cls.hiperftp_bucket.upload_dataframe_to_s3_parquet(dataframe=trips_df,
                                                                                          s3_key=trips_file_pth)
        combine_bugs(bugs, update_bug)
        if update_trip_file:
            return trips_df

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='06')
    def delete_trips_from_trip_df(cls, trips_df: pd.DataFrame, trip_ids_to_delete: List[int], vehicle_num: str,
                                  bugs={}) -> pd.DataFrame:
        """
        Delete trip record from trip table
        returns updated trip table if deleted and updated successfully
        """
        trips_df = trips_df[~trips_df['trip_id'].isin(trip_ids_to_delete)]

        trips_file_pth = ResourceS3Path.VEHICLE_TRIPS_PTH.value.replace("{vehicle_num}", vehicle_num)
        update_trip_file, update_bug = cls.hiperftp_bucket.upload_dataframe_to_s3_parquet(dataframe=trips_df,
                                                                                          s3_key=trips_file_pth)
        combine_bugs(bugs, update_bug)
        if update_trip_file:
            return trips_df

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='07')
    def update_trip_df(cls, trips_df: pd.DataFrame, vehicle_num: str,
                       bugs={}) -> pd.DataFrame:
        """
        Delete trip record from trip table
        returns updated trip table if deleted and updated successfully
        """

        trips_file_pth = ResourceS3Path.VEHICLE_TRIPS_PTH.value.replace("{vehicle_num}", vehicle_num)
        update_trip_file, update_bug = cls.hiperftp_bucket.upload_dataframe_to_s3_parquet(dataframe=trips_df,
                                                                                          s3_key=trips_file_pth)
        combine_bugs(bugs, update_bug)
        if update_trip_file:
            return trips_df

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='08')
    def update_vehicle_summary_df(cls, vehicle_num: str, summ_ids_to_update: List[int], column_value,
                                  column_name: str = 'proc_flag',
                                  bugs={}) -> pd.DataFrame:

        print(f"Getting Vehicle Summary for {vehicle_num} ")

        summary_df, summary_download_bug = ResourceUtil().get_vehicle_summary(vehicle_num=vehicle_num)
        combine_bugs(bugs, summary_download_bug)

        if summary_df is not None:
            summary_df.loc[summary_df['id'].isin(summ_ids_to_update), column_name] = column_value
            summary_pth = ResourceS3Path.VEHICLE_SUMMARY_PTH.value.replace("{vehicle_num}", vehicle_num)

            update_summary, update_bug = cls.hiperftp_bucket.upload_dataframe_to_s3_parquet(dataframe=summary_df,
                                                                                            s3_key=summary_pth)

            combine_bugs(bugs, update_bug)

            if update_bug == {}:
                return f"{vehicle_num} summary table updated {column_name} : {column_value} successfully!!"
            else:
                raise ValueError


class StratTable:
    hiperftp_bucket = S3Bucket(
        bucket_name="hiperftp"
    )

    @classmethod
    @error_handler('30', '13')
    def update_start_value(cls, vehicle_num: str, file_num: int, strat: int, prev_strat: int, bugs={}):
        start_table_df, start_table_bug = ResourceUtil().get_start_table()

        if start_table_df is not None:
            # Check if the vehicle exists in the dataframe
            if vehicle_num in start_table_df['vehicle_num'].values:
                start_table_df.loc[start_table_df['vehicle_num'] == vehicle_num, 'log_file'] = file_num
                start_table_df.loc[start_table_df['vehicle_num'] == vehicle_num, 'strat'] = strat
                start_table_df.loc[start_table_df['vehicle_num'] == vehicle_num, 'prev_strat'] = prev_strat
            else:
                # Create a new DataFrame for the new entry
                new_entry = pd.DataFrame([{
                    'vehicle_num': vehicle_num,
                    'log_file': file_num,
                    'strat': strat,
                    'prev_strat': prev_strat
                }])
                # Concatenate the new entry to the original dataframe
                start_table_df = pd.concat([start_table_df, new_entry], ignore_index=True)

            # Save the updated dataframe back to the resource (if required)
            update_start_table, update_bug = cls.hiperftp_bucket.upload_dataframe_to_s3_parquet(
                dataframe=start_table_df, s3_key=ResourceS3Path.STRAT_TABLE_PTH.value
            )
            combine_bugs(bugs, update_bug)

            if update_bug:
                return {"status": "error", "message": "Failed to update strat table"}

            return {"status": "success", "message": "Strat table updated!"}
        else:
            combine_bugs(bugs, start_table_bug)
            return {"status": "error", "message": "Failed to retrieve start table"}


class RawPing:

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code='03')
    def get_vehicle_device_mapping(cls) -> List[str]:
        session = new_prod_schema.get_connection()

        print("==== Getting Vehicle List... ")
        with handle_session(session) as ns:
            query = ns.query(
                VehicleRegistrationNew.vehicle_num, VehicleRegistrationNew.device_id
            )

            result = query.all()

            vehicle_device_list = {row.device_id: row.vehicle_num for row in result}

            return vehicle_device_list


class DeviceRegistration:
    prod_rds = MySQLDB(
        db_name="new_production_schema",
        env_var_prefix="MYSQL"
    )

    @classmethod
    @error_handler('30', '16')
    def get_registered_hw_and_devices(cls):
        session = new_prod_schema.get_connection()

        with handle_session(session) as ns:

            hw_list = []
            hw_data = ns.query(HWUno2).all()
            for row in hw_data:
                row_dict = {column.name: getattr(row, column.name) for column in HWUno2.__table__.columns}
                hw_list.append(row_dict)

            hw_data_df = pd.DataFrame(hw_list)
            hw_data_df.fillna('', inplace=True)

            device_list = []
            device_data = ns.query(DeviceRegistrationNew).all()
            for row in device_data:
                row_dict = {column.name: getattr(row, column.name) for column in
                            DeviceRegistrationNew.__table__.columns}
                device_list.append(row_dict)

            device_data_df = pd.DataFrame(device_list)
            device_data_df.fillna('', inplace=True)

            return {
                "hw_info": hw_data_df.to_dict(orient='list'),
                "device_info": device_data_df.to_dict(orient='list')
            }

    @classmethod
    @error_handler('30', '16')
    def get_hardware_serial_number(cls):
        """
        :return: hardware serial numbers which are not currently in use, i.e., hw_serial with active != 1
        """
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            # Get all hw_serial from HWUno2
            all_hw_serial = ns.query(HWUno2.hw_serial).all()
            all_hw_serial_set = set(serial for serial, in all_hw_serial)

            # Get all hw_serial from DeviceRegistrationNew where active = 1
            active_hw_serial = ns.query(DeviceRegistrationNew.hw_serial).filter(DeviceRegistrationNew.active == 1).all()
            active_hw_serial_set = set(serial for serial, in active_hw_serial)

            # Calculate hw_serial that are not in use
            unused_hw_serial = all_hw_serial_set - active_hw_serial_set

            return list(unused_hw_serial)

    @classmethod
    @error_handler('30', '16')
    def fetch_device_ids(cls):
        """
        :return: hardware serial numbers which are not currently in use, i.e., hw_serial with active != 1
        """
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            active_devices = ns.query(DeviceRegistrationNew.device_id).filter(DeviceRegistrationNew.active == 1).all()
            active_device_ids = set(serial for serial, in active_devices)

            return list(active_device_ids)

    @classmethod
    @error_handler('30', '16')
    def insert_hardware(cls, data: HWUno2Input):
        session = cls.prod_rds.get_connection()
        part_number = data.part_number
        batch_number_in_str = str(data.batch_number).zfill(2)

        hw_serial, hw_serial_bug = cls.create_hw_serial(
            part_number=part_number,
            batch_number=batch_number_in_str
        )
        print(hw_serial_bug)

        if hw_serial is None:
            raise ValueError("Unable to generate hardware serial number.")

        with handle_session(session) as ns:
            # Check if record exists
            existing_entry = ns.query(HWUno2).filter_by(imei=data.imei).first()

            if existing_entry:
                # Perform explicit update query
                update_query = update(HWUno2).where(HWUno2.imei == data.imei).values(
                    hw_serial=hw_serial,
                    stm_id=data.stm_id,
                    iccid_1=data.iccid_1,
                    iccid_2=data.iccid_2,
                    imsi_1=data.imsi_1,
                    imsi_2=data.imsi_2,
                    gps_serial_number=data.gps_serial_number,
                    QA=data.QA,
                    year_of_production=data.year_of_production,
                    batch_number=data.batch_number,
                    onboarding_stage=1
                )
                ns.execute(update_query)

                return f"Hardware Successfully Updated with IMEI {data.imei}"

            new_entry = HWUno2(
                hw_serial=hw_serial,
                stm_id=data.stm_id,
                imei=data.imei,
                iccid_1=data.iccid_1,
                iccid_2=data.iccid_2,
                imsi_1=data.imsi_1,
                imsi_2=data.imsi_2,
                gps_serial_number=data.gps_serial_number,
                QA=data.QA,
                year_of_production=data.year_of_production,
                batch_number=data.batch_number,
                onboarding_stage=1
            )
            ns.add(new_entry)

            return f"Hardware Successfully Registered with hw serial {hw_serial}"

    @classmethod
    @error_handler(library_code='30', function_code="01")
    def create_hw_serial(cls, part_number: str, batch_number: str):
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            hw_serial_pattern = f"{part_number}_{batch_number}_%"

            # Query the count of records that match the pattern
            count = ns.query(func.count(HWUno2.hw_serial)) \
                .filter(HWUno2.hw_serial.like(hw_serial_pattern)).scalar()

            print("==> Already Registered with same batch and and part nuber ", count)
            # Create new device ID
            new_count = str(count + 1).zfill(3)
            new_hw_serial = f"{part_number}_{batch_number}_{new_count}"

            return new_hw_serial


class DriverClassification:
    hiperdatalake = S3Bucket(
        bucket_name="hiperdatalake"
    )

    prod_rds = MySQLDB(
        db_name="lite_db",
        env_var_prefix="MYSQL"
    )

    DRIVER_IMG_PTH = "users/drivers/{fleet_name}/{driver_id} Training Image"

    @classmethod
    @error_handler('30', '14')
    def get_fleet_and_vehicle(cls):
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            VehicleRegAlias = aliased(VehicleRegistration)
            FleetAlias = aliased(Fleet)

            query = ns.query(
                VehicleRegAlias.vehicle_num,
                VehicleRegAlias.fleet_id,
                FleetAlias.fleet_name
            ).join(
                FleetAlias,
                VehicleRegAlias.fleet_id == FleetAlias.id
            ).filter(
                VehicleRegAlias.active_status == 1
            )

            results = query.all()

            df = pd.DataFrame(results, columns=['vehicle_num', 'fleet_id', 'fleet_name'])
            pivot_df = df.groupby(['fleet_id', 'fleet_name'])['vehicle_num'].apply(list).reset_index()

            return pivot_df.to_dict(orient='list')

    @classmethod
    @error_handler('30', '15')
    def get_driver_ids(cls):
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            query = ns.query(DriverMaster.id, DriverMaster.first_name, DriverMaster.last_name)

            results = query.all()

            driver_data = {
                "driver_name": [f"{result.first_name} {result.last_name}".replace(" None", "") for result in results],
                "driver_id": [result.id for result in results],
            }

            return driver_data

    @classmethod
    @error_handler('30', '16')
    def insert_driver(cls, vehicle_num, first_name, contact, fleet_id, last_name):
        session = cls.prod_rds.get_connection()

        with handle_session(session) as ns:
            new_driver = DriverMaster(
                vehicle_num=vehicle_num,
                first_name=first_name,
                contact=contact,
                fleet_id=fleet_id,
                last_name=last_name
            )

            ns.add(new_driver)

            return True

    @classmethod
    @error_handler('30', '16')
    def map_images_to_log_file(cls, vehicle_num: str, image_file_name: List[str]):

        # image_file_name = [f.replace("test/", "") for f in os.listdir('test')]
        image_file_name = [img_fl_nm for img_fl_nm in image_file_name if ".jpeg" in img_fl_nm]
        image_df = pd.DataFrame(image_file_name, columns=['filename'])

        def extract_timestamp(filename):
            try:
                return datetime.strptime(filename[:13], '%H%M%S_%d%m%y')
            except ValueError:
                return None

        image_df['timestamp'] = image_df['filename'].apply(extract_timestamp)
        image_df.dropna(subset=['timestamp'], inplace=True)

        current_year = datetime.now().year

        # Filter rows to include only those with the current year in the timestamp to filter out corrupted timestamp
        image_df = image_df[image_df['timestamp'].dt.year == current_year]

        min_timestamp = image_df['timestamp'].min()
        max_timestamp = image_df['timestamp'].max()

        summary_df, summary_download_bug = ResourceUtil().get_vehicle_summary(vehicle_num=vehicle_num)

        if summary_df is None:
            return None
        summary_df.dropna(subset=['start_time'], inplace=True)
        summary_df['start_date'] = summary_df['start_date'].astype(str)
        summary_df['start_time'] = summary_df['start_time'].astype(str)
        summary_df.dropna(subset=['start_time'], inplace=True)
        summary_df['start_datetime'] = pd.to_datetime(summary_df['start_date'] + ' ' + summary_df['start_time'])
        summary_df['end_datetime'] = summary_df['start_datetime'] + summary_df['run_time'].apply(
            lambda x: timedelta(seconds=x))

        filtered_summary_df = summary_df[
            (summary_df['start_datetime'] >= min_timestamp) & (summary_df['start_datetime'] <= max_timestamp)]

        file_image_mapping = {
            "file_num": [],
            "summary_id": [],
            "images": [],
            "driver_id": []
        }

        for ind, row in filtered_summary_df.iterrows():
            images_for_log_file = image_df.loc[
                (image_df['timestamp'] >= row['start_datetime']) &
                (image_df['timestamp'] <= row['end_datetime']),
                'filename'
            ].tolist()

            file_image_mapping['file_num'].append(row['file_num'])
            file_image_mapping['summary_id'].append(row['id'])
            file_image_mapping['images'].append(images_for_log_file)
            file_image_mapping['driver_id'].append(
                row['driver_id']
            )

        return file_image_mapping

    @classmethod
    async def upload_driver_images(cls, driver_images, fleet_name, driver_id, bugs={}):
        driver_id = str(driver_id).zfill(3)
        upload_s3_key = cls.DRIVER_IMG_PTH.replace("{fleet_name}", fleet_name).replace("{driver_id}", str(driver_id))
        for file in driver_images:
            file_bytes = await file.read()
            s3_key = f"{upload_s3_key}/{file.filename}"  # Define your S3 key structure
            upload_status, upload_bug = cls.hiperdatalake.upload_obj_to_s3(file_bytes, s3_key)
            combine_bugs(bugs, upload_bug)

        return True


class DeviceConfigFiles:
    imu_config_pth = "make model/{make_model}/log_config/imu_config_{make_model}.bin"
    can_config_pth = "make model/{make_model}/log_config/can_config_{make_model}.bin"

    @classmethod
    @error_handler('30', '22')
    def download_device_config_files(cls, make_model: str):
        imu_pth = cls.imu_config_pth.format(make_model=make_model)
        can_pth = cls.can_config_pth.format(make_model=make_model)

        imu_bin, imu_bug = hiperdatalake.download_bin_file(s3_key=imu_pth)
        can_bin, can_bug = hiperdatalake.download_bin_file(s3_key=can_pth)

        print(imu_bug, can_bug)
        if imu_bug != {} or can_bug != {}:
            return None
        # Create a BytesIO object to hold the zip file
        zip_buffer = io.BytesIO()

        # Create a ZIP file in memory
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr(imu_pth.split('/')[-1], imu_bin)
            zip_file.writestr(can_pth.split('/')[-1], can_bin)

        # Reset buffer position to the beginning
        zip_buffer.seek(0)

        return zip_buffer


class RawLogFiles:
    RAW_LOG_FILE_PTH = "devices/{device_id}/raw_logs"

    @classmethod
    async def upload_raw_log_file(cls, raw_log_files, device_id, bugs={}):
        upload_s3_key = cls.RAW_LOG_FILE_PTH.replace("{device_id}", device_id)

        file_nums = [int(file.filename.replace("l_", "").replace(".bin", "")) for file in raw_log_files if
                     "l_" in file.filename]

        file_nums = sorted(file_nums)

        latest_file_num = file_nums[-1] if len(file_nums) else ""

        for file in raw_log_files:
            file_bytes = await file.read()
            s3_key = f"{upload_s3_key}/{file.filename}"  # Define your S3 key structure
            upload_status, upload_bug = hiperdatalake.upload_obj_to_s3(file_bytes, s3_key)
            combine_bugs(bugs, upload_bug)

        if latest_file_num != "":
            print(cls.update_last_file_s3(device_id=device_id, file_number=latest_file_num))

        return True

    @staticmethod
    def update_last_file_s3(device_id, file_number: int):
        session = new_prod_schema.get_connection()

        with handle_session(session) as ns:
            ns.execute(
                update(VehicleDeviceLogs)
                .where(VehicleDeviceLogs.device_id == device_id)
                .values(last_log_file_s3=file_number)
            )

            ns.commit()
            print(f"Successfully updated last_processed_file to {file_number} for device_id {device_id}")


class DeviceSoftwareVersioning:

    @classmethod
    @error_handler('30', '22')
    def insert_software_versio_record(cls, software_version_record: SoftwareVersionRecord):
        session = new_prod_schema.get_connection()
        with handle_session(session) as ns:
            max_version = ns.query(func.max(DeviceSoftwareVersions.version)).filter_by(
                software_type=software_version_record.software_type.value).scalar()

            new_version = (max_version or 0) + 1

            software_type = software_types_mapping[software_version_record.software_type]

            print("================")

            print(software_type)
            print(software_types_mapping)

            new_record = DeviceSoftwareVersions(
                software_type=software_type,
                version=new_version,
                added_by=software_version_record.added_by,
                added_on=datetime.utcnow(),
                git_commit=software_version_record.git_commit,
                git_url=software_version_record.git_url,
            )

            ns.add(new_record)
            ns.commit()

    @classmethod
    @error_handler('30', '22')
    def fetch_software_versioning_table(cls):
        session = new_prod_schema.get_connection()
        with handle_session(session) as ns:
            software_version_list = []
            software_version_data = ns.query(DeviceSoftwareVersions).all()
            for row in software_version_data:
                row_dict = {column.name: getattr(row, column.name) for column in
                            DeviceSoftwareVersions.__table__.columns}
                software_version_list.append(row_dict)

            df = pd.DataFrame(software_version_list)
            return df.to_dict(orient="list")


class SysLog:
    def __init__(self, device_id: str):  # Fixed __int__ to __init__
        self.device_id = device_id
        self.sys_log_base_pth = f"devices/{device_id}/syslogs/"

    def _download_required_syslog(self, dates_to_fetch_for: List[str]):
        required_syslog_df = pd.DataFrame()  # Initialize an empty DataFrame

        for date in dates_to_fetch_for:
            syslog_file_pth = self.sys_log_base_pth + f"syslog_{date}.parquet"
            syslog_df, download_bug = hiperdatalake.download_parquet(s3_key=syslog_file_pth)
            print(download_bug)
            if syslog_df is not None:
                required_syslog_df = pd.concat([required_syslog_df, syslog_df],
                                               ignore_index=True)  # Use ignore_index for clean merging

        required_syslog_df.fillna('', inplace=True)

        return required_syslog_df.to_dict(orient='list')

    @staticmethod
    def _get_date_range(start_datetime_ist: str, end_datetime_ist: str) -> List[str]:
        """
        Convert IST datetime to UTC and get the date range between start and end datetimes.
        :param start_datetime_ist: Start datetime in IST (format: 'YYYY-MM-DD HH:MM:SS')
        :param end_datetime_ist: End datetime in IST (format: 'YYYY-MM-DD HH:MM:SS')
        :return: List of dates in the format 'YYYY-MM-DD' for the date range.
        """
        # Define IST and UTC timezones
        ist = pytz.timezone("Asia/Kolkata")
        utc = pytz.UTC

        # Parse input datetimes and localize to IST
        start_ist = ist.localize(datetime.strptime(start_datetime_ist, "%Y-%m-%d %H:%M:%S"))
        end_ist = ist.localize(datetime.strptime(end_datetime_ist, "%Y-%m-%d %H:%M:%S"))

        # Convert to UTC
        start_utc = start_ist.astimezone(utc)
        end_utc = end_ist.astimezone(utc)

        # Generate date range in UTC
        date_range = []
        current_date = start_utc
        while current_date.date() <= end_utc.date():
            date_range.append(current_date.strftime("%d-%m-%Y"))
            current_date += timedelta(days=1)

        return date_range

    def fetch_syslogs(self, start_datetime: str, end_datetime: str):
        """
        Fetch syslogs for a given date range in IST.
        :param start_datetime: Start datetime(format: 'YYYY-MM-DD HH:MM:SS')
        :param end_datetime: End datetimeformat: 'YYYY-MM-DD HH:MM:SS')
        :return: A DataFrame containing all required syslogs.
        """
        # Get date range
        dates_to_fetch_for = self._get_date_range(start_datetime, end_datetime)

        print(dates_to_fetch_for)

        return self._download_required_syslog(dates_to_fetch_for)


class TestRequirementUtil:

    # @staticmethod
    # def get_available_test_process_for_production():
    #     return hiperdatalake.list_files_in_s3(
    #         s3_key=ResourceS3Path.TEST_PROCESS_FILE_PTH.value.format(software_type=SoftwareTypes.PRODUCTION.value))

    @staticmethod
    def get_test_process_list():
        test_process_list_pth = ResourceS3Path.TR_META_DATA_FILE_PTH.value.format(
            software_type=SoftwareTypes.PRODUCTION.value)
        test_process_df, download_bug = hiperdatalake.download_excel(s3_key=test_process_list_pth)
        return test_process_df, download_bug

    def insert_to_test_process_list(self, test_process_name: str):
        test_process_df, download_bug = self.get_test_process_list()

        if test_process_df is None:
            print("No existing test process list found. Creating a new one.")
            test_process_df = pd.DataFrame(columns=["test_process_name"])

        new_record = {"test_process_name": test_process_name}
        new_record_df = pd.DataFrame([new_record])

        updated_df = pd.concat([test_process_df, new_record_df], ignore_index=True)

        updated_df['id'] = updated_df.index

        test_process_list_pth = ResourceS3Path.TR_META_DATA_FILE_PTH.value.format(
            software_type=SoftwareTypes.PRODUCTION.value)

        _, upload_bug = hiperdatalake.upload_dataframe_to_s3_csv(dataframe=updated_df,
                                                                 s3_key=test_process_list_pth)

        if upload_bug:
            return False

        return True

    @staticmethod
    def get_available_config_version():
        session = new_prod_schema.get_connection()

        print("==== Getting Vehicle List... ")
        with handle_session(session) as ns:
            query = ns.query(
                DeviceSoftwareVersions.software_type,
                DeviceSoftwareVersions.make_model,
                DeviceSoftwareVersions.version,
                DeviceSoftwareVersions.git_commit,
            ).filter(
                DeviceSoftwareVersions.software_type.in_(["CAN_CONFIG", "EDGE_CONFIG"])
            )

            result = query.all()

            config_versions = [
                {
                    "software_type": row.software_type,
                    "make_model": row.make_model,
                    "version": row.version,
                    "git_commit": row.git_commit,
                }
                for row in result
            ]

            return config_versions

    @error_handler('30', '22')
    def insert_production_test_requirement(self, test_requirement: TestRequirement):
        test_req_name = test_requirement.test_requirement_name

        test_req_s3_key = ResourceS3Path.TEST_REQUIREMENT_FILE_PTH.value.format(
            software_type=SoftwareTypes.PRODUCTION.value) + f"{test_req_name}.csv"

        test_req_dict = test_requirement.model_dump()

        df = pd.DataFrame(test_req_dict['test_requirements'])
        _, upload_bug = hiperdatalake.upload_dataframe_to_s3_csv(dataframe=df, s3_key=test_req_s3_key)

        insertion_to_list = self.insert_to_test_process_list(test_process_name=test_req_name)

        print(upload_bug)

        if not upload_bug and insertion_to_list:
            return True


class EmulatorCycle:
    emulator_cycle_bin_s3_location = ResourceS3Path.EMULATOR_CYCLE_FILE_PTH.value

    def __init__(self, scenario_data: List[List[int]], emulator_cycle_name: str, added_by: int):

        self.scenario_data = scenario_data
        self.emulator_cycle_name = emulator_cycle_name
        self.added_by = added_by

    @staticmethod
    def get_emulator_cycles_csv():
        ec_metadata_pth = ResourceS3Path.EC_META_DATA_FILE_PTH.value.format(
            software_type=SoftwareTypes.PRODUCTION.value)
        ec_metadata_df, download_bug = hiperdatalake.download_excel(s3_key=ec_metadata_pth)
        return ec_metadata_df, download_bug

    def create_emulator_cycle(self):

        duration = 0
        file_like = io.BytesIO()
        for row in self.scenario_data:
            for value in row:
                # Pack each uint16 value into binary format
                print(struct.pack("H", value))
                duration += value
                file_like.write(struct.pack("H", value))  # "H" is for uint16

        file_like.seek(0)

        _, save_ec_bug = self.save_emulator_cycle_bin(test_process_bin=file_like)

        if not save_ec_bug:
            self.save_ec_meta_data(duration=duration)
        
        file_like.seek(0)

        return file_like

    def save_ec_meta_data(self, duration: int):
        emulator_cycles_df, download_bug = self.get_emulator_cycles_csv()

        if emulator_cycles_df is None:
            print("No existing emulator cycles list found. Creating a new one.")
            emulator_cycles_df = pd.DataFrame(columns=["emulator_cycle_name", "duration", "added_by"])

        new_record = {"emulator_cycle_name": self.emulator_cycle_name, 'duration': duration, 'added_by': self.added_by}
        new_record_df = pd.DataFrame([new_record])

        updated_df = pd.concat([emulator_cycles_df, new_record_df], ignore_index=True)

        updated_df['id'] = updated_df.index

        emulator_cycles_csv_pth = ResourceS3Path.EC_META_DATA_FILE_PTH.value.format(
            software_type=SoftwareTypes.PRODUCTION.value)

        _, upload_bug = hiperdatalake.upload_dataframe_to_s3_csv(dataframe=updated_df,
                                                                 s3_key=emulator_cycles_csv_pth)

        if upload_bug:
            return False

        return True

    def save_emulator_cycle_bin(self, test_process_bin):

        test_process_s3_key = self.emulator_cycle_bin_s3_location.format(
            software_type=SoftwareTypes.PRODUCTION.value) + self.emulator_cycle_name + ".bin"

        _, upload_bug = hiperdatalake.upload_obj_to_s3(obj=test_process_bin, s3_key=test_process_s3_key)

        print(upload_bug)

        return _, upload_bug


class RunTestUtil:

    @staticmethod
    @error_handler(library_code="30", function_code="01")
    def get_available_test_rigs():
        """
        Fetch all available test rigs with active status = 0 and vehicle numbers containing 'TEST_RIG_'.
        """
        session = new_prod_schema.get_connection()

        with handle_session(session) as ns:
            rigs = (
                ns.query(VehicleRegistrationNew.vehicle_num)
                .filter(
                    VehicleRegistrationNew.active_status == 0,
                    VehicleRegistrationNew.vehicle_num.like("TEST_RIG_%")
                )
                .all()
            )
            return [rig.vehicle_num for rig in rigs]

    @staticmethod
    @error_handler(library_code="30", function_code="02")
    def get_test_requests():
        """
        Fetch all test requests from the test_request_rds table where status is NULL.
        """
        session = new_prod_schema.get_connection()
        with handle_session(session) as ns:
            test_requests = (
                ns.query(TestRequestTicket)
                .filter(TestRequestTicket.status == None)  # Use `None` for SQL `NULL`
                .all()
            )
            return [tr.test_request_id for tr in test_requests]

    @staticmethod
    @error_handler(library_code="30", function_code="03")
    def get_test_case(test_request_id: int, software_type: str = SoftwareTypes.PRODUCTION):
        json_path = ResourceS3Path.TEST_REQUEST_RESULT_JSON_PATH.value.format(
            software_type=software_type,
            test_request_id=test_request_id
        )

        test_result_json, bug = hiperdatalake.download_json(s3_key=json_path)
        if bug:
            raise ValueError(f"Failed to fetch test result JSON for test_request_id {test_request_id}: {bug}")

        test_cases = test_result_json.get("test_cases", [])
        if not test_cases:
            raise ValueError(f"No test cases found in JSON for test_request_id {test_request_id}")

        filtered_test_cases = [case['id'] for case in test_cases if case.get("QA_status") is None]

        return filtered_test_cases

    @staticmethod
    @error_handler(library_code="30", function_code="04")
    def register_test_rig_with_test_case(
            test_rig: str,
            test_request_id: int,
            testcase: int
    ):
        """
        Register a test rig with a test case and activate the test rig in vehicle_registration.
        """
        session = new_prod_schema.get_connection()

        # Step 1: Create or Update Test Rig Tracker
        with handle_session(session) as ns:
            # Check if the test rig already exists
            existing_rig = ns.query(TestRigTracker).filter(TestRigTracker.test_rig == test_rig).first()

            if existing_rig:
                # Update the existing record
                ns.execute(
                    update(TestRigTracker)
                    .where(TestRigTracker.test_rig == test_rig)
                    .values(
                        test_request_id=test_request_id,
                        testcase=testcase,
                    )
                )
            else:
                # Create a new record
                new_rig = TestRigTracker(
                    test_rig=test_rig,
                    test_request_id=test_request_id,
                    testcase=testcase,
                )
                ns.add(new_rig)

        with handle_session(session) as ns:
            updated_vehicle = (
                ns.query(VehicleRegistrationNew)
                .filter(VehicleRegistrationNew.vehicle_num == test_rig)
                .update({VehicleRegistrationNew.active_status: 1})
            )
            if not updated_vehicle:
                raise ValueError(f"Failed to activate test rig '{test_rig}' in vehicle_registration.")

        return {"message": f"Test rig '{test_rig}' successfully registered and activated."}



class DSMManagement:

    @staticmethod
    @error_handler(library_code="30", function_code="05")
    def get_dtc_data():
        session = new_prod_schema.get_connection()
        with handle_session(session) as ns:
            dtc_data = ns.query(DsmStatus.device_id, DsmStatus.dtc_clear).all()
            df = pd.DataFrame(dtc_data, columns=['device_id', 'dtc_clear'])
            # print(df)

            return df.to_dict(orient='list')
        
    @staticmethod
    @error_handler(library_code="30", function_code="06")
    def update_dtc_data(device_id: str, dtc_clear: int):
        session = new_prod_schema.get_connection()
        with handle_session(session) as ns:
            ns.query(DsmStatus).filter(DsmStatus.device_id == device_id).update({DsmStatus.dtc_clear: dtc_clear})

            return True



if __name__ == '__main__':
    # vehicle_status = VehicleStatus()

    # print(vehicle_status.get_vehicle_status())
    # print("=====")
    # start_date = "2024-05-01"
    # end_date = "2024-05-05"
    # print(TripClassification.get_vehicle_summary(vehicle_num='NL01B3011', start_date=start_date, end_date=end_date))

    # print(DriverClassification.get_fleet_and_vehicle())

    # print(RawLogFiles.update_last_file_s3("U_2024_05_023", 5))

    # print(DSMManagement.get_dtc_data())
    # print(DSMManagement.update_dtc_data(device_id="U_2024_05_023", dtc_clear=0))    
    # print(DSMManagement.get_dtc_data())
    pass