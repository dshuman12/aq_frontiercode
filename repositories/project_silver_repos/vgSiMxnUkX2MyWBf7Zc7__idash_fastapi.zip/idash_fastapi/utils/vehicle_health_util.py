# Import inbuilt libraries



# Import third party libraries
# eg from fastapi import FastAPI,Request,HTTPException,Depends, HTTPException
from datetime import datetime, timedelta
import json
import random
import time
import numpy as np
import pandas as pd
from collections import deque

# Include repos folder for custom libraries


# Declare variables used 
# Library Code for Vehicle Health Library

lib_code_VHT = "47"
lib_ver_VHT = "00"

lib_code_ver_VHT = f"{lib_code_VHT}{lib_ver_VHT}"




# Include custom libraries
from hiper_utils.Decoraters.exception_handler import error_handler,combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from storage_settings import rds_instance,hiperft_bucket,get_current_date,redis_instance,vehicle_health_ticket_path, prod_rds_instance
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.vehicle_health_schema import *
from schema.common_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from utils.common_util import *
from schema.bug_ticket_schema import *
from hiper_utils.data_models.s3_data_models.vehicle_health_ticket import *
from hiper_utils.data_models.s3_data_models.common_models import *
from utils.attachment_util import upload_attachments_to_s3
from utils.common_util import *
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew as VR_RDS
from hiper_utils.data_models.rds_data_models.ticket_rds_models import VehicleHealthTicket as VHT_RDS

# initialize the logger
logger_1 = LoggerFactory(name="bug_ticket_utils", file_name="message.log").get_logger()


# Define Helper class used with the pydantic model
# define other funcs

@error_handler(library_code=lib_code_ver_VHT, function_code="01")
def all_vehicle_health_ticket_records():
    '''
    Function to get all the vehicle health ticket records from VEHICLE_HEALTH_TICKET RDS or Redis cache if available.

    Returns:
        - pd.DataFrame with all the vehicle health ticket records.
        - Empty DataFrame if the function fails or if no tickets are found.
    '''

    # Get the connection
    session = prod_rds_instance.get_connection()

    with handle_session(session) as ns:
        vehicle_health_tickets = ns.query(VHT_RDS).all()
        
        # Log if no records are found
        if not vehicle_health_tickets:
            logger_1.warning("No vehicle health tickets found.")
            return pd.DataFrame(columns=['id', 'name', 'vehicle_number', 'date_of_issue', 'latest_date', 'status','anomaly'])

        logger_1.info(f"Vehicle Health Tickets Retrieved: {len(vehicle_health_tickets)}")

        # Convert the SQLAlchemy objects to a list of dictionaries
        tickets_list = [
            {
                'id': getattr(ticket, 'id', None),
                'name': getattr(ticket, 'name', ''),
                'vehicle_number': getattr(ticket, 'veh_num', ''),
                'date_of_issue': getattr(ticket, 'date_of_issue', ''),
                'latest_date': getattr(ticket, 'latest_date', ''),
                'status': getattr(ticket, 'status', ''),
                'anomaly': getattr(ticket, 'anomaly', '')
            }
            for ticket in vehicle_health_tickets
        ]

        # Convert the list of dictionaries to a pandas DataFrame
        all_vehicle_tickets_df = pd.DataFrame(tickets_list)

        # Check if the DataFrame is empty
        if all_vehicle_tickets_df.empty:
            logger_1.warning("Vehicle Health Tickets DataFrame is empty.")
            return pd.DataFrame(columns=['id', 'name', 'vehicle_number', 'date_of_issue', 'latest_date', 'status','anomaly'])

        # Convert DataFrame to a dictionary of dictionaries with 'id' as the key
        all_vehicle_tickets_dict = all_vehicle_tickets_df.set_index('id').T.to_dict()

        # Convert Timestamps to strings and replace NaT values with None
        for ticket_id, ticket in all_vehicle_tickets_dict.items():
            for key, value in ticket.items():
                if isinstance(value, pd.Timestamp):
                    ticket[key] = value.strftime('%Y-%m-%d %H:%M:%S')
                if pd.isnull(value):
                    ticket[key] = None

        # Ensure proper ordering of columns
        all_vehicle_tickets_df = all_vehicle_tickets_df[['id'] + [col for col in all_vehicle_tickets_df.columns if col != 'id']]

        # Replace NaN with empty strings
        all_vehicle_tickets_df = all_vehicle_tickets_df.fillna('')

        # Ensure proper data types for integer fields
        integer_columns = ['status']
        for col in integer_columns:
            all_vehicle_tickets_df[col] = all_vehicle_tickets_df[col].apply(lambda x: int(x) if x != '' else '')

        # Handle datetime columns, replacing NaT with empty strings
        datetime_columns = ['date_of_issue', 'latest_date']
        for col in datetime_columns:
            all_vehicle_tickets_df[col] = pd.to_datetime(all_vehicle_tickets_df[col], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
            all_vehicle_tickets_df[col] = all_vehicle_tickets_df[col].replace('NaT', '')

    return all_vehicle_tickets_df



# function to create a new vehicle health ticket in s3
@error_handler(library_code=lib_code_ver_VHT, function_code="02")
def create_ticket_in_s3(ticket_to_rds : int,ticket : Create_Vehicle_Health_Ticket,bugs={}):
    '''
    Function to create a new vehicle health ticket in the S3 bucket

    params:
        - new_ticket_id : int : ID of the newly created ticket
        - ticket : Create_Vehicle_Health_Ticket : Instance of the Create_Vehicle_Health_Ticket model

    Returns:
        - ticket_to_s3 : int : ID of the ticket created in S3, None if the function fails
        - bugs : dict : Dictionary containing any bugs encountered
    '''

    # create a metadata block
    metadata = {
        "created_by" : str(ticket.added_by),
        "updated_by" : str(ticket.added_by),
        "status" : "0"
    }

    # serialize the metadata object
    metadata_serialized = MetadataBlock(**metadata)

    if ticket.attachments is not None:
        logger_1.info(f"Attachments are {ticket.attachments}")

        # call the upload_attachments_to_s3 function to upload the attachments to s3
        attachment_urls_list, bugs_local = upload_attachments_to_s3(ticket.attachments,ticket_type=6, ticket_master_id=ticket_to_rds,block_id=1)

        if bugs_local:
            logger_1.error(f"Failed to upload attachments, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif attachment_urls_list is not None:
            logger_1.info(f"Attachment urls are {attachment_urls_list}")

    # create a heading block
    heading = {
        "ticket_master_id" : str(ticket_to_rds),
        "ticket_name" : ticket.name,
        "ticket_description" : ticket.description,
        "priority" : str(ticket.priority),
        "raised_by" : str(ticket.added_by)
    }

    # serialize the heading object
    heading_serialized = HeadingBlock(**heading)

    # create a status block
    status_block = {
        "status_change_description": f"Vehicle health ticket named {ticket.name} created successfully",
        "updated_by": str(ticket.added_by),
    }

    # serialize the status block
    status = StatusChangeBlock(**status_block)
       
    # ticket object 
    ticket_data = {
        "0" : metadata_serialized.model_dump(),
        "1" : heading_serialized.model_dump(),
        "2" : status.model_dump()
    }

    
    ticket_data,bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{vehicle_health_ticket_path}{str(ticket_to_rds).zfill(5)}.json", data_dict=ticket_data)

    if bugs_local:
        logger_1.info(f"Failed in writing bug ticket {ticket.name} to S3, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None

    else:
       logger_1.info(f"Vehicle health ticket created successfully in S3")
       
       # download the ticket once the upload is complete
       new_ticket_data,bugs_local = hiperft_bucket.download_json(s3_key=f"{vehicle_health_ticket_path}{str(ticket_to_rds).zfill(5)}.json")
       
       if bugs_local:
           logger_1.info(f"Failed in downloading bug ticket {ticket.name} from S3, {bugs_local}")
           bugs = c_bugs(bugs,bugs_local)
           bugs = s_bugs(bugs)
           return None
       
       return new_ticket_data
       
        



@error_handler(library_code=lib_code_ver_VHT, function_code="03")
def fetch_and_cache_vh_ticket(ticketid : int , bugs={}):
    '''
    
    Function to fetch and cache the vehicle health ticket data from S3

    params:
        - ticket_id : int : ticket id of the vehicle health ticket to fetch and cache

    returns:
        - ticket_data : dict : dictionary containing the bug ticket data
        - None if the function fails

    '''

    # fetch the ticket data from S3
    ticket_data,bugs_local = hiperft_bucket.download_json(s3_key=f"{vehicle_health_ticket_path}{str(ticketid).zfill(5)}.json")

    if bugs_local:
        logger_1.info(f"Failed in downloading vehicle health ticket with ticket id {ticketid} from S3, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    return ticket_data


# function to fetch all vehicle numbers
@error_handler(library_code=lib_code_ver_VHT, function_code="04")
def fetch_and_cache_vehicle_numbers():
    
    """
    Retrieves all vehicle numbers either from cache or from RDS if not cached.

    params: None
    
    Returns:
        A dictionary with a message and the list of vehicle numbers.
    """


    # Check if the data is cached
    cached_vehicle_numbers = redis_instance.get_key('vehicle_numbers')

    if cached_vehicle_numbers:
        try:
            # Deserialize cached data
            vehicle_numbers = json.loads(cached_vehicle_numbers.decode('utf-8'))
            logger_1.info("Retrieved vehicle numbers from cache.")
            return {
                "message": "All vehicle numbers retrieved from cache",
                "vehicle_numbers": vehicle_numbers
            }
        except Exception as e:
            logger_1.error(f"Failed to deserialize cached vehicle numbers: {str(e)}")
            raise Exception("Failed to retrieve cached vehicle numbers.") from e

    # If not cached, fetch from RDS
    try:
        all_vehicle_nums = []
        session = rds_instance.get_connection()

        with handle_session(session) as ns:
            # Get the vehicle numbers
            vehicle_nums = ns.query(VR_RDS).all()

            for vehicle in vehicle_nums:
                all_vehicle_nums.append(vehicle.vehicle_num)
        
        # Serialize data to JSON before caching
        serialized_vehicle_numbers = json.dumps(all_vehicle_nums)
        
        # Cache the vehicle numbers for 10 minutes
        redis_instance.set_key('vehicle_numbers', serialized_vehicle_numbers, ex=600)  # 600 seconds = 10 minutes

        logger_1.info("Vehicle numbers fetched from RDS and cached.")
        return {
            "message": "All vehicle numbers retrieved from RDS and cached",
            "vehicle_numbers": all_vehicle_nums
        }
    
    except Exception as e:
        logger_1.error(f"Error occurred while fetching vehicle numbers, {e}")
        return {
            "error": "Unknown error occurred while fetching vehicle numbers"
        }
    

# function to update a vehicle health ticket in s3
@error_handler(library_code=lib_code_ver_VHT, function_code="05")
def update_rds_vh_ticket_record(ticket : Update_Vehicle_Health_Ticket):
    '''
    
    Function to update a vehicle health ticket record in RDS 

    params:
        - ticket : Update_Vehicle_Health_Ticket : Instance of the Update_Vehicle_Health_Ticket model
        - bugs : dict : Dictionary containing any bugs encountered
        
    returns:
        - updated sqlalchemy object if successful, else None
    
    
    '''

    # get the session
    session = rds_instance.get_connection()

    with handle_session(session) as ns:
        # fetch the ticket record
        ticket_record = ns.query(VHT_RDS).filter(VHT_RDS.id == ticket.ticketid).first()

        # update the record
        if ticket.vehicle_number:
            ticket_record.veh_num = ticket.vehicle_number

        if ticket.name:
            ticket_record.name = ticket.name

        if ticket.priority:
            ticket_record.priority = ticket.priority

        if ticket.owner:
            ticket_record.assigned_to = ticket.owner

        if ticket.status:
            ticket_record.status = ticket.status
    

        # commit the changes
        ns.commit()

        return ticket_record
    

# function to update a vehicle health ticket in s3
@error_handler(library_code=lib_code_ver_VHT, function_code="06")
def update_vh_ticket_fields(ticket : Update_Vehicle_Health_Ticket, bugs={}):

    '''
    Function to update a vehicle health ticket in S3

    params:
        - ticket : Update_Vehicle_Health_Ticket : Instance of the Update_Vehicle_Health_Ticket model

    Returns:
        - updated_ticket : dict : Updated vehicle health ticket data, None if the function fails
        - bugs : dict : Dictionary containing any bugs encountered


    '''

    # download th ticket
    ticket_to_update, bugs_local = hiperft_bucket.download_json(s3_key=f"{vehicle_health_ticket_path}{str(ticket.ticketid).zfill(5)}.json")
    
    if bugs_local:
        logger_1.info(f"Failed in downloading bug ticket {ticket.name} from S3, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None

    elif ticket_to_update is not None:
        # perform the manipulation to heading block here and serialize it
        heading = ticket_to_update['1']

        # update the heading block
        heading['ticket_name'] = ticket.name if ticket.name is not None else heading['ticket_name']
        heading['ticket_description'] = ticket.description if ticket.description is not None else heading['ticket_description']
        heading['priority'] = ticket.priority if ticket.priority is not None else heading['priority']

        # fetch the last key in the ticket_data
        last_key = list(ticket_to_update.keys())[-1]

        # create a new status block saying that the ticket is updated
        status_block_id = int(last_key) + 1

        status_block = {
            'status_change_description': f'Ticket updated',
            'updated_by': ticket.updated_by
        }

        # serialize the status block
        serialized_status = StatusChangeBlock(**status_block)

        # add the status block to the ticket_data
        ticket_to_update[str(status_block_id)] = serialized_status.model_dump()

        # write the ticket back to s3
        ticket_data,bugs_local = hiperft_bucket.write_json_to_s3(s3_key=f"{vehicle_health_ticket_path}{str(ticket.ticketid).zfill(5)}.json", data_dict=ticket_to_update)

        if bugs_local:
            logger_1.info(f"Failed in writing bug ticket {ticket.name} to S3, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return None

        else:
            logger_1.info(f"Vehicle health ticket created successfully in S3")
        
            # download the ticket once the upload is complete
            new_ticket_data,bugs_local = hiperft_bucket.download_json(s3_key=f"{vehicle_health_ticket_path}{str(ticket.ticketid).zfill(5)}.json")
            
            if bugs_local:
                logger_1.info(f"Failed in downloading bug ticket {ticket.name} from S3, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
            
            return new_ticket_data
            

# function to handle ticket update in s3
@error_handler(library_code=lib_code_ver_VHT, function_code="07")
def handle_ticket_update_for_s3(ticketid : int,ticket_with_updation : dict, user_id : int, bugs={}):
    '''
    Function to handle the update of a vehicle health ticket in S3

    params:
        - ticket_with_updation : dict : Updated vehicle health ticket data
    
    returns:
        - updated_ticket : dict : Updated vehicle health ticket data, None if the function fails
        - bugs : dict : Dictionary containing any bugs encountered

    '''
    # Update metadata
    updated_ticket, bugs_local = update_metadata(ticket_with_updation, user_id)

    if bugs_local:
        logger_1.error(f"Failed to update metadata for ticket {ticketid}: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        
    
    elif updated_ticket is not None:
        logger_1.info(f"Metadata updated for ticket {ticketid}")

    logger_1.info("ticket with updation is",ticket_with_updation)

    # Serialize the updated ticket data to a JSON string
    updated_ticket_data = json.dumps(ticket_with_updation)

    # Save the updated ticket data back to the cache (if needed)
    redis_instance.set_key(f'vh_ticket_{ticketid}', updated_ticket_data,ex=1200)

    # Add the ticket id to the S3 update queue for later processing
    redis_instance.lpush('s3_vh_ticket_update_queue', str(ticketid))

    return ticket_with_updation


# function to write to s3 queue
@error_handler(library_code=lib_code_ver_VHT, function_code="08")
def write_vh_changes_to_s3():

    '''
    Function to write changes to S3 in the background.

    params: None
    returns: None
    
    '''


    while True:
        # Sleep for the specified interval (e.g., 1 minute for testing)
        time.sleep(60)

        # logger_1.info("Checking for vh changes to write to S3")

        try:
            while True:
                # Pop a ticket ID from the S3 update queue
                ticket_id = redis_instance.rpop('s3_vh_ticket_update_queue')
                if not ticket_id:
                    break  # No more items in the queue

                ticket_id = ticket_id.decode('utf-8')
                logger_1.info(f"Writing changes for ticket {ticket_id} to S3")

                # Retrieve the updated ticket data from the cache (if needed)
                ticket_data = redis_instance.get_key(f'vh_ticket_{ticket_id}')
                if ticket_data is None:
                    logger_1.error(f"Failed to retrieve ticket data for ticket ID {ticket_id} from cache")
                    continue

                # Decode bytes to string if necessary
                if isinstance(ticket_data, bytes):
                    ticket_data = ticket_data.decode('utf-8')

                # Deserialize the data
                ticket_data = json.loads(ticket_data)

                # Write the ticket data to S3
                s3_path = vehicle_health_ticket_path
                s3_key = f"{s3_path}{str(ticket_id).zfill(5)}.json"
                
                
                updated_ticket,bugs_local = hiperft_bucket.write_json_to_s3(data_dict=ticket_data, s3_key=s3_key)

                if bugs_local:
                    logger_1.error(f"Error writing changes to S3: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                
                elif updated_ticket is not None:
                    logger_1.info(f"Changes written to S3 successfully")

        except Exception as e:
            logger_1.error(f"Error writing changes to S3: {e}")



# function to transfer an anomaly
@error_handler(library_code=lib_code_ver_VHT, function_code="09")
def transfer_anomaly_service(anomaly_id : int, ticket_id : int, new_ticket_id : int, transferee : int, bugs={}):

    '''
    Function to transfer an anomaly from one vehicle health ticket to another

    params: 
        - anomaly_id : int
        - ticket_id : int
        - new_ticket_id : int
        - transferee : int

    returns: 
        - updated_ticket_after_transfer : dict : Updated vehicle health ticket data after the transfer, None if the function fails
        - bugs : dict : Dictionary containing any bugs encountered
    
    
    
    '''

    # call fetch and cache ticket
    ticket_data,bugs_local = fetch_and_cache_vh_ticket(ticket_id)

    if bugs_local:
        logger_1.error(f"Failed to fetch the ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    else:

        anomaly_block = ticket_data[str(anomaly_id)]

        # get the anomaly id from the anomaly block
        anomaly_id_in_block = anomaly_block['anomaly_id']

#        logger_1.info(f"Anomaly id in block is {anomaly_id_in_block}")

        # fetch the new ticket from s3
        new_ticket_data,bugs_local = fetch_and_cache_vh_ticket(new_ticket_id)

        if bugs_local:
            logger_1.error(f"Failed to fetch the new ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        else:

            # check the last key in the ticket data
            last_key = list(new_ticket_data.keys())[-1]

            # get the last key and add 1 to it
            new_key = str(int(last_key) + 1)

            # add the anomaly block to the new ticket data
            new_ticket_data[new_key] = anomaly_block

            # update the anomaly block in the metadata of the new ticket data
            new_ticket_data['0']['anomaly_blocks'][str(anomaly_id_in_block)] = [new_key]

            # create a new status saying the anomaly has been transferred
            status_change_text = f"ANOMALY TRANSFERRED FROM {ticket_data['1']['ticket_name']}"


            new_status_data = {
                "status_change_description": status_change_text,
                "updated_by": str(transferee),
            }

            # Serialize the new status data and log it
            status_serializer = StatusChangeBlock(**new_status_data)


            # check the last key in the ticket data
            last_key_for_status = list(new_ticket_data.keys())[-1]

            # get the last key and add 1 to it
            new_key_for_status = str(int(last_key_for_status) + 1)

            # add the new status to the status blocks
            new_ticket_data[new_key_for_status] = status_serializer.model_dump()

            new_ticket_data['0']['status_blocks'].append(new_key_for_status)

            # push the updated ticket data to s3
            result,bugs_local = handle_ticket_update_for_s3(new_ticket_id, new_ticket_data, transferee)

            if bugs_local:
                logger_1.error(f"Failed to update the new ticket, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None
                
            else:

                # delete the anomaly block from the old ticket data
                del ticket_data[str(anomaly_id)]

                # update the anomaly block in the metadata of the old ticket data
                anomaly_blocks_in_ticket = ticket_data['0']['anomaly_blocks']

#                   logger_1.info(f"Anomaly blocks in ticket are {anomaly_blocks_in_ticket}")

                del anomaly_blocks_in_ticket[str(anomaly_id_in_block)]

                # check if there are is no anomaly block in the old ticket data, if so update the status to 6 - empty ticket
                if len(ticket_data['0']['anomaly_blocks']) == 0:
                    
                    # update the status of the ticket to 6
                    ticket_data['0']['status'] = '6'

                    # similarly update the status of the new ticket to 6 in vehicle health ticket rds
                    session = rds_instance.get_connection()

                    with handle_session(session) as ns:
                        ticket = ns.query(VHT_RDS).filter(VHT_RDS.id == ticket_id).first()
                        ticket.status = 6
                        session.commit()
                        session.close()

                # add a new status saying the anomaly has been transferred
                status_change_text = f"ANOMALY TRANSFERRED TO {new_ticket_data['1']['ticket_name']}"

                new_status_data = {
                    "status_change_description": status_change_text,
                    "updated_by": str(transferee),
                }

                # Serialize the new status data and log it
                status_serializer = StatusChangeBlock(**new_status_data)

                # check the last key in the ticket data
                last_key_for_status = list(ticket_data.keys())[-1]

                # get the last key and add 1 to it
                new_key_for_status = str(int(last_key_for_status) + 1)

                # add the new status to the status blocks
                ticket_data[new_key_for_status] = status_serializer.model_dump()

                ticket_data['0']['status_blocks'].append(new_key_for_status)

                # push the updated ticket data to s3
                result,bugs_local = handle_ticket_update_for_s3(ticket_id, ticket_data, transferee)

                if bugs_local:
                    logger_1.error(f"Failed to update the old ticket, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                else:
                    return ticket_data
            
                                              
                            

