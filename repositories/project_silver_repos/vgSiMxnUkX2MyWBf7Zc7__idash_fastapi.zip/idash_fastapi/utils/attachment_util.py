import os
import urllib.parse
from tempfile import NamedTemporaryFile

from typing import List, Optional
from fastapi import UploadFile
from storage_settings import hiperft_bucket, feat_ticket_path, bug_ticket_path,feat_ticket_attachment_path,bug_ticket_attachment_path,vehicle_data_path,get_current_date
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs as c_bugs, serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.data_models.s3_data_models.feature_ticket import *
from hiper_utils.data_models.s3_data_models.common_models import *
from utils.fleets_util import get_fleet_name
from urllib.parse import unquote


# Library Code for Attachment Module
lib_code_AM = "29"
lib_ver_AM = "00"

lib_code_ver_AM = f"{lib_code_AM}{lib_ver_AM}"


# initialize the logger
logger_1 = LoggerFactory(name="attachment_utils",
                         file_name="message.log").get_logger()


# Define Helper class used with the pydantic model

# define other funcs

@error_handler(library_code=lib_code_ver_AM, function_code="01")
def upload_attachments_to_s3(
    attachments: List[UploadFile], 
    ticket_type: Optional[int] = None,
    ticket_master_id: Optional[int] = None,
    block_id: Optional[int] = None,
    start: int = 1,
    custom_s3_path: Optional[str] = None 
) -> List[str]:
    
    '''
    Service to upload the attachments to S3

    params:
        - attachments : List[UploadFile] : List of attachments to be uploaded
        - ticket_type : Optional[int] : Type of the ticket (if related to a ticket)
        - ticket_master_id : Optional[int] : ID of the ticket (if related to a ticket)
        - block_id : Optional[int] : ID of the block (if related to a ticket)
        - start : int : Start index for the attachment
        - custom_s3_path : Optional[str] : Custom S3 path for non-ticket-related uploads

    returns:
        - uploaded_keys : List[str] : List of S3 keys of the uploaded attachments

    '''

    uploaded_keys = []

    for count, attachment in enumerate(attachments, start=start):
        try:
            # Save the file temporarily
            with NamedTemporaryFile(delete=False) as temp_file:
                temp_file.write(attachment.file.read())
                temp_file_path = temp_file.name

            # Determine the file extension
            file_extension = attachment.filename.split(".")[-1]

            # Generate the full file name
            file_name = f"{str(ticket_master_id).zfill(5)}_{str(block_id).zfill(3)}_{str(count).zfill(2)}.{file_extension}"

            # Determine the S3 path
            if custom_s3_path:
                # Custom path for non-ticket-related uploads
                s3_key = f"{custom_s3_path}{attachment.filename}"
            else:
                # Path for ticket-related uploads
                if ticket_type == 6:
                    s3_key = f"{feat_ticket_attachment_path}{file_name}"
                elif ticket_type == 2:
                    s3_key = f"{bug_ticket_attachment_path}{file_name}"
                else:
                    raise ValueError("Invalid ticket type provided.")

            # Upload the file to S3 using your existing S3Bucket class method
            success = hiperft_bucket.upload_file_to_s3(fpath=temp_file_path, s3_key=s3_key)

            if success:
                uploaded_keys.append(s3_key)

            # Clean up the temporary file
            os.remove(temp_file_path)

        except Exception as e:
            print(f"Error uploading file {attachment.filename}: {e}")

    return uploaded_keys



@error_handler(library_code=lib_code_ver_AM, function_code="02")
def delete_attachment_from_ticket(s3_key : str,ticket_type : int, ticket_id : int, block_id : int,deleted_by, bugs = {}):

    '''
    Function to delete the attachment from the ticket

    params:
        - ticket_type : int : Type of the ticket
        - ticket_id : int : ID of the ticket
        - block_id : int : ID of the block

    returns:
        -ticket_data : dict : Dictionary containing the ticket data after deleting the attachment, None if failed
    
    '''

    # using lazy import to avoid circular imports
    from utils.feature_tickets_util import fetch_and_cache_ticket, handle_ticket_update_for_s3

    # Fetch the ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket_type=ticket_type, ticketid=ticket_id)

    if bugs_local:
        logger_1.info(f"Unable to fetch ticket data for {ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # Delete the attachment from the ticket data
        ticket_data_after_deletion,bugs_local = delete_attachment_in_block(ticket_data = ticket_s3_data,block_id=block_id,s3_key=s3_key,deleted_by=deleted_by)

        if bugs_local:
            logger_1.info(f"Unable to delete attachment from {ticket_id}, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif ticket_data_after_deletion is not None:
            # call handle_ticket_update_for_s3
            updated_ticket_data, bugs_local = handle_ticket_update_for_s3(ticketid=ticket_id,ticket_with_updation=ticket_data_after_deletion,user_id=deleted_by)

            if bugs_local:
                logger_1.info(f"Unable to update ticket data for {ticket_id}, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None
           
    return updated_ticket_data
          



# Define the function to delete the attachment from the block
@error_handler(library_code=lib_code_ver_AM, function_code="03")
def delete_attachment_in_block(ticket_data : dict, block_id : int,s3_key : str,deleted_by : int, bugs = {}):

    '''
    Function to delete the attachment from the block

    params:
        - ticket_data : dict : Dictionary containing the ticket data
        - block_id : int : ID of the block

    returns:
        -ticket_data : dict : Dictionary containing the ticket data after deleting the attachment, None if failed
    
    '''

    completed = False

    # retrieve the block
    block_with_attachment = ticket_data.get(str(block_id))

    if block_with_attachment is not None:

        # fetch the attachment using the key as attachments
        attachment_list = block_with_attachment.get("attachments")

        # remove the s3_key from the attachment list
        attachment_list.remove(s3_key)

        # fetch the last key in the ticket_data and add 1 to it to get the status block id
        last_key_for_status = list(ticket_data.keys())[-1]

        status_block_id = int(last_key_for_status) + 1

        # create a new status block to the ticket saying that the ticket is closed
        status_block = {
            "status_change_description": f"Attachment with name {s3_key} has been deleted",
            "updated_by": deleted_by,
        }

    
        # Serialize the new status data and log it
        status_serialized = StatusChangeBlock(**status_block)         

        # add the status block to the ticket
        ticket_data[str(status_block_id)] = status_serialized.model_dump()

        completed = True

    if completed:
        return ticket_data
    else:
        return None




# Define the function to add extra attachment to the block
@error_handler(library_code=lib_code_ver_AM, function_code="04")
def add_extra_attachment_to_block(ticket_type : int, ticket_id : int, block_id : int, attachments : List[UploadFile],added_by : int, bugs = {}):

    '''
    Function to add the extra attachment to the block

    params:
        - ticket_data : dict : Dictionary containing the ticket data
        - block_id : int : ID of the block
        - s3_key : str : S3 key of the attachment to be added

    returns:
        -ticket_data : dict : Dictionary containing the ticket data after adding the attachment, None if failed
    
    '''

    # using lazy import to avoid circular imports
    from utils.feature_tickets_util import fetch_and_cache_ticket

    completed = False

    # Fetch the ticket data
    ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticket_type=ticket_type, ticketid=ticket_id)

    if bugs_local:
        logger_1.info(f"Unable to fetch ticket data for {ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif ticket_s3_data is not None:

        # retrieve the block
        block_with_attachment = ticket_s3_data.get(str(block_id))

        if block_with_attachment is not None:

            logger_1.info(f"block with attachment {block_with_attachment}")

            # fetch the attachment using the key as attachments
            attachment_list = block_with_attachment.get("attachments")

            # get the length of the attachment list
            attachment_length = len(attachment_list)

            # add the s3_key to the attachment list
            uploaded_keys, bugs_local = upload_attachments_to_s3(attachments=attachments, ticket_type=ticket_type,ticket_master_id=ticket_id, block_id=block_id,start=attachment_length+1)

            if bugs_local:
                logger_1.info(f"Unable to upload attachment for {ticket_id}, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif uploaded_keys is not None:
                attachment_list.extend(uploaded_keys)

                # fetch the last key in the ticket_data and add 1 to it to get the status block id
                last_key_for_status = list(ticket_s3_data.keys())[-1]

                status_block_id = int(last_key_for_status) + 1

                # create a new status block to the ticket saying that the ticket is closed
                status_block = {
                    "status_change_description": f"More attachments have been added to the block with ID {block_id}",
                    "updated_by": added_by,
                }

            
                # Serialize the new status data and log it
                status_serialized = StatusChangeBlock(**status_block)         

                # add the status block to the ticket
                ticket_s3_data[str(status_block_id)] = status_serialized.model_dump()

                completed = True

    if completed:
        return ticket_s3_data
    
    else:
        return None


@error_handler(library_code=lib_code_ver_AM, function_code="05")
def extract_s3_key_from_url(presigned_url: str) -> str:
    """
    Extracts the S3 key from a presigned URL.

    Args:
        presigned_url (str): The presigned URL.

    Returns:
        str: The S3 key extracted from the URL.
    """
    url_parts = urllib.parse.urlparse(presigned_url)
    
    logger_1.info(f"URL parts: {url_parts}")
    
    s3_key = url_parts.path.lstrip('/')

    logger_1.info(f"S3 key: {s3_key}")

    if s3_key:
        return s3_key
    else:
        return None
    
    

# Helper function to fetch ticket data and generate presigned URLs
@error_handler(library_code=lib_code_ver_AM, function_code="06")
def fetch_attachments(ticket_type: int, ticket_id: int, block_id: int, bugs = {}) -> Optional[List[str]]:
    
    """
    
    Function to fetch the attachment from a ticket block and return the list of presigned URLs for the attachments
    
    params:
        - ticket_type : int : Type of the ticket
        - ticket_id : int : ID of the ticket
        - block_id : int : ID of the block
        
    returns:
        - Success : list : List of presigned URLs for the attachments
        - Failure : error message with status code 500
    
    """
    
    from utils.bug_tickets_util import fetch_and_cache_bug_ticket
    from utils.feature_tickets_util import fetch_and_cache_ticket
   
    # call fetch_and_cache_ticket function based on ticket type
    if ticket_type == 1:
        ticket_s3_data, bugs_local = fetch_and_cache_bug_ticket(ticketid=ticket_id)
    elif ticket_type == 6:
        ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid=ticket_id, ticket_type=ticket_type)
  
    # Handle any errors encountered during fetching
    if bugs_local:
        logger_1.info(f"Unable to fetch ticket data for {ticket_id}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None, {"error": "Unable to fetch attachments, unknown error occurred"}
    
    if ticket_s3_data is None:
        return None, {"error": "No ticket data found"}

    # Get the block data
    block_data = ticket_s3_data.get(str(block_id))
    if block_data is None:
        return None, {"error": "Block not found"}
    
    # Extract attachments and generate presigned URLs
    attachments_in_block = block_data.get("attachments", [])
    logger_1.info(f"Attachments in block: {attachments_in_block}")
    
    presigned_urls_list = []
    for attachment in attachments_in_block:
        logger_1.info(f"Processing attachment: {attachment}")
        presigned_url, bugs_local = hiperft_bucket.generate_presigned_url_for_download(
            s3_key=attachment, expiration=3600
        )
        if bugs_local:
            logger_1.info(f"Unable to generate presigned URL for {attachment}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None, {"error": "Unable to fetch the attachment, unknown error occurred"}

        if presigned_url:
            logger_1.info(f"Presigned URL generated for {attachment} is {presigned_url}")
            presigned_urls_list.append(presigned_url)

    return presigned_urls_list



# Helper function to fetch and generate presigned URL for custom S3 path
@error_handler(library_code=lib_code_ver_AM, function_code="07")
def fetch_attachment_by_custom_path(s3_path: str, bugs = {}):

    """
    
    Function to fetch the attachment from a custom S3 path and return the presigned URL for the attachment
    
    params:
        - s3_path : str : Custom S3 path for the attachment
        
    returns:
        - Success : str : Presigned URL for the attachment
        - bug : dict : Dictionary containing the bug data
    
    """

    # Generate presigned URL for the custom S3 path
    presigned_url, bugs_local = hiperft_bucket.generate_presigned_url_for_download(s3_key=s3_path, expiration=3600)

    # Handle any issues with presigned URL generation
    if bugs_local:
        logger_1.info(f"Unable to generate presigned URL for {s3_path}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None

    if presigned_url is not None:
        logger_1.info(f"Presigned URL generated for {s3_path} is {presigned_url}")
        return presigned_url


@error_handler(library_code=lib_code_ver_AM, function_code="08")
def delete_attachment_from_vehicle_json(s3_key: str, vehicle_num: str, deleted_by: str, bugs={}):
    """
    Function to delete the attachment from the vehicle_data.json
    
    params:
        - s3_key : str : The S3 key of the attachment to be deleted
        - vehicle_num : str : The vehicle number associated with the attachment
        - deleted_by : str : The user who deleted the attachment
    
    returns:
        - vehicle_data : dict : Updated vehicle data after deletion, None if failed
    """

    
    # get the fleet name using the vehicle number
    fleet_name,bugs_local = get_fleet_name(vehicle_num)
    
    if bugs_local:
        logger_1.info(f"Unable to fetch fleet name for {vehicle_num}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif fleet_name is not None:
    
        # Define paths for vehicle json and attachments
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/Vehicle_JSON.json"

        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)

        if bugs_local:
            logger_1.info(f"Unable to fetch vehicle data for {vehicle_num}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None

        if vehicle_json is not None:
            # Delete the attachment from the vehicle data
            vehicle_data_after_deletion, bugs_local = delete_attachment_in_vehicle_data_block(vehicle_data=vehicle_json, s3_key=s3_key)

            if bugs_local:
                logger_1.info(f"Unable to delete attachment from vehicle data {vehicle_num}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return None

            elif vehicle_data_after_deletion is not None:
                logger_1.info(f"Attachment deleted successfully from vehicle data: {vehicle_num}")
                
                
                # add a new status block to the vehicle data
                last_key_for_status = list(vehicle_data_after_deletion.keys())[-1]
                
                status_block_id = int(last_key_for_status) + 1
                
                status_block = {
                    "status_change_description": f"Attachment with name {s3_key} has been deleted",
                    "updated_by": deleted_by,
                }
                
                # Serialize the new status data and log it
                status_serialized = StatusChangeBlock(**status_block)
                
                # add the status block to the vehicle data
                vehicle_data_after_deletion[str(status_block_id)] = status_serialized.model_dump()
             
                # write the updated vehicle json to s3
                updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)

                if bugs_local:
                    logger_1.info(f"Unable to update vehicle data for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return None
                
                else:
                    logger_1.info(f"Vehicle data updated successfully after deleting attachment: {vehicle_num}")
                    
                    # download the updated vehicle data
                    updated_vehicle_data, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)
                    
                    if bugs_local:
                        logger_1.info(f"Unable to fetch updated vehicle data for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    
                    return updated_vehicle_data
                    
    


# function to delete the attachment from the vehicle data
@error_handler(library_code=lib_code_ver_AM, function_code="09")
def delete_attachment_in_vehicle_data_block(vehicle_data: dict, s3_key: str):
    
    """
    Function to delete the attachment from the vehicle_data.json

    params:
        - vehicle_data: dict : The vehicle data block
        - s3_key: str : The S3 key of the attachment to delete
        - deleted_by: str : The user who deleted the attachment
    
    returns:
        - updated_vehicle_data: dict : The updated vehicle data
        - bugs: dict : Any bugs encountered during the deletion process
    """
    
    updated = False
    
      
    # Decode the S3 key to handle any URL encoding (e.g., %20 -> space)
    decoded_s3_key = unquote(s3_key)
    
    # Log the decoded S3 key
    logger_1.info(f"Decoded S3 key: {decoded_s3_key}")
    
    # log the s3 key received
    logger_1.info(f"Deleting attachment {decoded_s3_key} from vehicle data")

    # Iterate over all the blocks in vehicle_data
    for block_id, block_data in vehicle_data.items():
        
        # log the block data
        logger_1.info(f"Processing block {block_data}")
        
        # Check in the various fields that can have attachments
        for field in ["OBD_location_image", "video_link_of_installation", "number_plate_photo", "wheels_photo", "rc_book_photo", "puc_certificate"]:
            
            logger_1.info(f"Processing field {field}")
            
            if field in block_data and isinstance(block_data[field], list):
                if decoded_s3_key in block_data[field]:
                    block_data[field].remove(decoded_s3_key)  # Remove the attachment
                    updated = True
                    logger_1.info(f"Attachment {decoded_s3_key} deleted from block {block_id} in field {field}")

    if not updated:
        logger_1.info(f"Attachment {decoded_s3_key} not found in vehicle data")

    return vehicle_data



# Function to add more attachments to the installation block
@error_handler(library_code=lib_code_ver_AM, function_code="10")
def append_to_installation_block(vehicle_num : str, added_by : str, obd_location_photo : List[UploadFile] = None , installation_video : List[UploadFile] = None, bugs = {}):
    
    """
    
    Function to add more attachments to the installation block in the vehicle data
    
    params:
        - vehicle_num : str : Vehicle number
        - added_by : str : User who added the attachments
        - obd_location_photo : List[UploadFile] : List of OBD location photos
        - installation_video : List[UploadFile] : List of installation videos
        
    returns:
        - success : bool : True if the attachments were added successfully, False otherwise
        - bugs : dict : Any bugs encountered during the
    
    
    """

    
    # initialize the success flag
    success_create = False
    
    attachment_urls_list = []
    video_urls_list = []

    
    
    # Fetch the fleet name
    fleet_name, bugs_local = get_fleet_name(vehicle_num)
    
    if bugs_local:
        logger_1.info(f"Unable to fetch fleet name for {vehicle_num}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_create
    
    elif fleet_name is not None:
        
        # get the vehicle data path and attachment path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/Vehicle_JSON.json"
        attachment_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/attachments/"
        
        # download the vehicle data
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)
        
        if bugs_local:
            logger_1.info(f"Unable to fetch vehicle data for {vehicle_num}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_create
        
        elif vehicle_json is not None:
            
            metadata = vehicle_json.get("0", {})
            
            # get the installation block
            installation_blocks = metadata.get("installation_blocks", [])
            installation_block = vehicle_json.get(installation_blocks[0], {})
                        
            status_changes = "Installation block updated with new attachments: "
    
            # Handle OBD location photo uploads
            if obd_location_photo is not None:
                attachment_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=obd_location_photo,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload OBD location photos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif attachment_urls_list is not None or attachment_urls_list != []:
                    
                    logger_1.info(f"attachment_urls_list: {attachment_urls_list}")
                     
                    logger_1.info(f"OBD location photos uploaded successfully for {vehicle_num}")
                    
                    # add a new status saying that the installation block has been updated new obd location photos
                    status_changes += "OBD location photos" 
                    
               
                    # add the attachment urls to the installation block obd location image list
                    obd_location_photo_list = installation_block.get("OBD_location_image", [])
                    
                    # append the new attachment urls to the existing list
                    obd_location_photo_list.extend(attachment_urls_list)
                    

            # Handle installation video uploads
            if installation_video is not None:
                video_urls_list, bugs_local = upload_attachments_to_s3(
                    attachments=installation_video,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload installation videos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif video_urls_list:
                    logger_1.info(f"Installation videos uploaded successfully for {vehicle_num}")
                    
                    # update the status according to the changes made
                    if obd_location_photo is not None:
                        status_changes += ", Installation videos"
                        
                    else:
                        status_changes += "Installation videos"
                        
                    # add the attachment urls to the installation block video link of installation list
                    video_link_list = installation_block.get("video_link_of_installation", [])
                    
                    # append the new attachment urls to the existing list
                    video_link_list.extend(video_urls_list)
                
            
            # create a new status block to the vehicle data    
            last_key_for_status = list(vehicle_json.keys())[-1]
            
            status_block_id = int(last_key_for_status) + 1
            
            status_block = {
                "status_change_description": status_changes,
                "updated_by": added_by,
            }
            
            # Serialize the new status data and log it
            status_serialized = StatusChangeBlock(**status_block)
            
            # add the status block to the vehicle data
            vehicle_json[str(status_block_id)] = status_serialized.model_dump()
            
            

            # Update the metadata
            metadata = vehicle_json.get("0", {})
            metadata["updated_by"] = added_by
            metadata["updated_on"] = get_current_date()
            
            # update the metadata status block with the status block id
            status_blocks = metadata.get("status_blocks", [])
            status_blocks.append(status_block_id)

            # write the updated vehicle json to s3
            updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)
            
            if bugs_local:
                logger_1.info(f"Unable to update vehicle data for {vehicle_num}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_create
            
            else:
                logger_1.info(f"Vehicle data updated successfully after adding attachments: {vehicle_num}")
                success_create = True
                return success_create

        

# Function to add attachments to calibration block
@error_handler(library_code=lib_code_ver_AM, function_code="11")
def append_to_calibration_block(vehicle_num : str, added_by : str, photo_of_rc_book : List[UploadFile] = None, photo_of_wheels : List[UploadFile] = None, photo_of_number_plate : List[UploadFile] = None, puc_certificate : List[UploadFile] = None, bugs = {}):

    """
    
    Function to add more attachments to the calibration block in the vehicle data
    
    params:
        - vehicle_num : str : Vehicle number
        - added_by : str : User who added the attachments
        - photo_of_rc_book : List[UploadFile] : List of RC book photos
        - photo_of_wheels : List[UploadFile] : List of wheels photos
        - photo_of_number_plate : List[UploadFile] : List of number plate photos
        - puc_certificate : List[UploadFile] : List of PUC certificate photos
        
    returns:
        - success : bool : True if the attachments were added successfully, False otherwise
        - bugs : dict : Any bugs encountered during the
    

    """
    
       # initialize the success flag
    success_create = False
    
    rc_book_photos = []
    wheel_photos = []
    number_plate_photos = []
    puc_certificate_photos = []
    
    
    # Fetch the fleet name
    fleet_name, bugs_local = get_fleet_name(vehicle_num)
    
    if bugs_local:
        logger_1.info(f"Unable to fetch fleet name for {vehicle_num}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return success_create
    
    elif fleet_name is not None:
        
        # get the vehicle data path and attachment path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/Vehicle_JSON.json"
        attachment_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/attachments/"
        
        # download the vehicle data
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)
        
        if bugs_local:
            logger_1.info(f"Unable to fetch vehicle data for {vehicle_num}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return success_create
        
        elif vehicle_json is not None:
            
            metadata = vehicle_json.get("0", {})
            
            # get the calibration block
            calibration_blocks = metadata.get("calibration_blocks", [])
            recent_calibration_block = vehicle_json.get(calibration_blocks[-1], {})
                        
            status_changes = "Calibration block updated with new attachments: "

            
            # Handle RC book photo uploads
            if photo_of_rc_book is not None:
                rc_book_photos, bugs_local = upload_attachments_to_s3(
                    attachments=photo_of_rc_book,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload RC book photos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif rc_book_photos is not None or rc_book_photos != []:
                    
                    logger_1.info(f"RC book photos uploaded successfully for {vehicle_num}")
                    
                    # add a new status saying that the calibration block has been updated with new rc book photos
                    status_changes += "RC book photos" 
                    
                    # add the attachment urls to the calibration block rc book photo list
                    rc_book_photo_list = recent_calibration_block.get("rc_book_photo", [])
                    
                    # append the new attachment urls to the existing list
                    rc_book_photo_list.extend(rc_book_photos)
                    
            # Handle wheels photo uploads
            if photo_of_wheels is not None:
                wheel_photos, bugs_local = upload_attachments_to_s3(
                    attachments=photo_of_wheels,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload wheels photos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif wheel_photos:
                    logger_1.info(f"Wheels photos uploaded successfully for {vehicle_num}")
                    
                    # update the status according to the changes made
                    if photo_of_rc_book is not None:
                        status_changes += ", Wheels photos"
                        
                    else:
                        status_changes += "Wheels photos"
                        
                    # add the attachment urls to the calibration block wheels photo list
                    wheels_photo_list = recent_calibration_block.get("wheels_photo", [])
                    
                    # append the new attachment urls to the existing list
                    wheels_photo_list.extend(wheel_photos)
                    
            # Handle number plate photo uploads
            if photo_of_number_plate is not None:
                number_plate_photos, bugs_local = upload_attachments_to_s3(
                    attachments=photo_of_number_plate,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload number plate photos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif number_plate_photos:
                    logger_1.info(f"Number plate photos uploaded successfully for {vehicle_num}")
                    
                    # update the status according to the changes made
                    if photo_of_rc_book is not None or photo_of_wheels is not None:
                        status_changes += ", Number plate photos"
                        
                    else:
                        status_changes += "Number plate photos"
                        
                    # add the attachment urls to the calibration block number plate photo list
                    number_plate_photo_list = recent_calibration_block.get("number_plate_photo", [])
                    
                    # append the new attachment urls to the existing list
                    number_plate_photo_list.extend(number_plate_photos)
                    
            
            # Handle PUC certificate photo uploads
            if puc_certificate is not None:          
                puc_certificate_photos, bugs_local = upload_attachments_to_s3(
                    attachments=puc_certificate,
                    block_id=vehicle_num,
                    custom_s3_path=attachment_path
                )
                
                if bugs_local:
                    logger_1.info(f"Unable to upload PUC certificate photos for {vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)
                    return success_create
                
                elif puc_certificate_photos:
                    logger_1.info(f"PUC certificate photos uploaded successfully for {vehicle_num}")
                    
                    # update the status according to the changes made
                    if photo_of_rc_book is not None or photo_of_wheels is not None or photo_of_number_plate is not None:
                        status_changes += ", PUC certificate photos"
                        
                    else:
                        status_changes += "PUC certificate photos"
                        
                    # add the attachment urls to the calibration block puc certificate photo list
                    puc_certificate_photo_list = recent_calibration_block.get("puc_certificate", [])
                    
                    # append the new attachment urls to the existing list
                    puc_certificate_photo_list.extend(puc_certificate_photos)
                    
            
            # create a new status block to the vehicle data
            last_key_for_status = list(vehicle_json.keys())[-1]
            
            status_block_id = int(last_key_for_status) + 1
            
            status_block = {
                "status_change_description": status_changes,
                "updated_by": added_by,
            }
            
            # Serialize the new status data and log it
            status_serialized = StatusChangeBlock(**status_block)
            
            # add the status block to the vehicle data
            vehicle_json[str(status_block_id)] = status_serialized.model_dump()
            
            # Update the metadata
            metadata = vehicle_json.get("0", {})
            metadata["updated_by"] = added_by
            metadata["updated_on"] = get_current_date()
            
            # update the metadata status block with the status block id
            status_blocks = metadata.get("status_blocks", [])
            status_blocks.append(status_block_id)
            
            # write the updated vehicle json to s3
            updated_vehicle_json, bugs_local = hiperft_bucket.write_json_to_s3(data_dict=vehicle_json, s3_key=vehicle_json_path)
            
            if bugs_local:
                logger_1.info(f"Unable to update vehicle data for {vehicle_num}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return success_create
            
            else:
                logger_1.info(f"Vehicle data updated successfully after adding attachments: {vehicle_num}")
                success_create = True
                return success_create
            
                
# function to fetch all attachments from the vehicle data
@error_handler(library_code=lib_code_ver_AM, function_code="12")
def fetch_attachments_for_vehicle_data(vehicle_num : str, obd_location_photo : bool , installation_video : bool, photo_of_rc_book : bool, photo_of_wheels : bool, photo_of_number_plate : bool, puc_certificate : bool, bugs={}):
    
    """
    
    Function to fetch all the attachments from the vehicle data depending on the flags
    
    params:
        - vehicle_num : str : Vehicle number
        - obd_location_photo : bool : Flag to fetch OBD location photos
        - installation_video : bool : Flag to fetch installation videos
        - photo_of_rc_book : bool : Flag to fetch RC book photos
        - photo_of_wheels : bool : Flag to fetch wheels photos
        - photo_of_number_plate : bool : Flag to fetch number plate photos
        - puc_certificate : bool : Flag to fetch PUC certificate photos
    
    
    returns:
        - attachments : list : List of presigned URLs for the attachments
        - bugs : dict : Any bugs encountered during the process
    
    
    """
    
    # get the fleet name followed by vehicle data path
    fleet_name, bugs_local = get_fleet_name(vehicle_num)
    
    if bugs_local:
        logger_1.info(f"Unable to fetch fleet name for {vehicle_num}, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        return None
    
    elif fleet_name is not None:
        
        # get the vehicle data path
        vehicle_json_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/Vehicle_JSON.json"
        attachment_path = f"{vehicle_data_path}{fleet_name}/{vehicle_num}/attachments/"
        
        # download the vehicle data
        vehicle_json, bugs_local = hiperft_bucket.download_json(s3_key=vehicle_json_path)
        
        if bugs_local:
            logger_1.info(f"Unable to fetch vehicle data for {vehicle_num}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return None
        
        elif vehicle_json is not None:
            
            # get the metadata
            metadata = vehicle_json.get("0", {})
            
            # get the installation block and calibration block
            installation_blocks = metadata.get("installation_blocks", [])
            recent_installation_block = vehicle_json.get(installation_blocks[0], {})
            
            calibration_blocks = metadata.get("calibration_blocks", [])
            recent_calibration_block = vehicle_json.get(calibration_blocks[-1], {})
            
            attachments = []
          
            # fetch the attachments based on the flags
            if obd_location_photo == True:
                obd_location_photos = recent_installation_block.get("OBD_location_image", [])
                
                logger_1.info(f"OBD location photos: {obd_location_photos}")
                
                for photo in obd_location_photos:
                    
                    logger_1.info(f"Processing OBD location photo: {photo}")
                    
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{photo}")
                    
                    if bugs_local:
                        logger_1.info(f"Unable to fetch OBD location photos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    
                    elif presigned_url is not None:
                        attachments.append(presigned_url)

            if installation_video == True:
                installation_videos = recent_installation_block.get("video_link_of_installation", [])
                for video in installation_videos:
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{video}")
                    if bugs_local:
                        logger_1.info(f"Unable to fetch installation videos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    attachments.append(presigned_url)
                    
                    
            if photo_of_rc_book == True:
                rc_book_photos = recent_calibration_block.get("rc_book_photo", [])
                for photo in rc_book_photos:
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{photo}")
                    if bugs_local:
                        logger_1.info(f"Unable to fetch RC book photos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    attachments.append(presigned_url)
                    
            if photo_of_wheels == True:
                wheel_photos = recent_calibration_block.get("wheels_photo", [])
                for photo in wheel_photos:
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{photo}")
                    if bugs_local:
                        logger_1.info(f"Unable to fetch wheels photos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    attachments.append(presigned_url)
                    
            if photo_of_number_plate == True:
                number_plate_photos = recent_calibration_block.get("number_plate_photo", [])
                for photo in number_plate_photos:
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{photo}")
                    if bugs_local:
                        logger_1.info(f"Unable to fetch number plate photos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    attachments.append(presigned_url)
                    
            if puc_certificate == True:
                puc_certificate_photos = recent_calibration_block.get("puc_certificate", [])
                for photo in puc_certificate_photos:
                    presigned_url, bugs_local = fetch_attachment_by_custom_path(f"{photo}")
                    if bugs_local:
                        logger_1.info(f"Unable to fetch PUC certificate photos for {vehicle_num}, {bugs_local}")
                        bugs = c_bugs(bugs, bugs_local)
                        bugs = s_bugs(bugs)
                        return None
                    attachments.append(presigned_url)
                    
            return attachments