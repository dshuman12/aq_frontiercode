import os
from datetime import datetime, timezone, timedelta
import sys
import json
from typing import List
import threading
import io
import zipfile

sys.path.append("../../")

from hiper_utils.aws.s3.s3 import S3Bucket
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB, handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import create_event_table_class
from hiper_utils.other_utils.vehicles_util import get_location_from_lat_lon
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path
import pytz
import pandas as pd

dev_db = MySQLDB(
    db_name="new_production_schema",
    env_var_prefix="MYSQL"
)

lib_code = '47'
lib_ver = '00'
lib_code_ver = f"{lib_code}{lib_ver}"


class VehicleTimeLine:

    @classmethod
    @error_handler(library_code=lib_code_ver, function_code="01")
    def get_timeline_data(cls, vehicle_num: str, start_datetime: str, end_datetime: str):
        # Define the UTC timezone
        utc_tz = pytz.UTC

        # Convert input datetime strings to datetime objects in UTC
        start_date = datetime.strptime(start_datetime, "%Y-%m-%d %H:%M:%S")
        end_date = datetime.strptime(end_datetime, "%Y-%m-%d %H:%M:%S")

        # Make sure these datetime objects are timezone-aware and set to UTC
        start_date = utc_tz.localize(start_date)
        end_date = utc_tz.localize(end_date)

        session = dev_db.get_connection()

        event_table = create_event_table_class(vehicle_num)

        with handle_session(session) as ns:
            # Apply date filtering to the query, converting `server_time` to UTC if necessary
            result = ns.query(event_table).filter(
                event_table.server_time >= start_date,
                event_table.server_time <= end_date
            ).all()

            vehicle_status_list = []
            for row in result:
                row_dict = {column.name: getattr(row, column.name) for column in event_table.__table__.columns}
                vehicle_status_list.append(row_dict)

            # Convert the list of dictionaries into a DataFrame
            vehicle_status_df = pd.DataFrame(vehicle_status_list)

            

            # Convert server_time to IST (Indian Standard Time)
            if vehicle_status_list:
                vehicle_status_df['server_time'] = vehicle_status_df['server_time'] + pd.Timedelta(hours=5, minutes=30)

            # Convert DataFrame to a dictionary with lists as values
            vehicle_status_json = vehicle_status_df.to_dict(orient='list')

            return vehicle_status_json
