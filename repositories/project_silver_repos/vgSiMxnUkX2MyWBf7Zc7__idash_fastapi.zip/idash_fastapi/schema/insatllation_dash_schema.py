from pydantic import BaseModel, Field, validator, model_validator, conlist
from typing import List, Optional, Union, Dict
from enum import Enum
from datetime import datetime

# class AggregateDataEnum(str, Enum):
#     MEAN = "MEAN"
#     MEDIAN = "MEDIAN"
#     COUNT = "COUNT"
#     VARIANCE = "VARIANCE"


GPS_PARAMS = {

    1: "TIME",
    2: "LAT",
    3: "LONG",
    4: "ALT",
    5: "HEADING",
    6: "BEARING"

}

IMU_PARAMAS = {
    1: 'ax',
    2: 'ay',
    3: 'az',
    4: 'gx/gy/gz',
}

AGG_OPTIONS = {
    1: "MEAN",
    2: "MEDIAN",
    3: "COUNT",
    4: "VARIANCE"
}


class Endian(str, Enum):
    LITTLE = "LITTLE"
    BIG = "BIG"


class CANDataMode(Enum):
    CAN_1_0 = (1, "CAN 1.0")
    CAN_2_0 = (2, "CAN 2.0")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class CANBaudRate(Enum):
    Kbps_250 = (0, "250 kbps")
    Kbps_500 = (1, "500 kbps")
    Kbps_1000 = (2, "1000 kbps")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class IMUDataRange(Enum):
    HZ_1_6 = (0, "1.6 Hz")
    HZ_12_5 = (1, "12.5 Hz")
    HZ_26 = (2, "26 Hz")
    HZ_52 = (3, "52 Hz")
    HZ_104 = (4, "104 Hz")
    HZ_208 = (5, "208 Hz")
    HZ_416 = (6, "416 Hz")
    HZ_833 = (7, "833 Hz")
    KHZ_1_66 = (8, "1.66 kHz")
    KHZ_3_33 = (9, "3.33 kHz")
    KHZ_6_66 = (10, "6.66 kHz")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class AccelerometerFullScale(Enum):
    G_2 = (0, "±2 g")
    G_4 = (1, "±4 g")
    G_8 = (2, "±8 g")
    G_16 = (3, "±16 g")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class GyroscopeFullScale(Enum):
    DPS_125 = (0, "±125 dps")
    DPS_250 = (1, "±250 dps")
    DPS_500 = (2, "±500 dps")
    DPS_1000 = (3, "±1000 dps")
    DPS_2000 = (4, "±2000 dps")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class AnalogChannel(Enum):
    ANALOG_IN_1 = (0, "ANALOG_IN_1")
    ANALOG_IN_2 = (1, "ANALOG_IN_2")

    def __init__(self, id: int, description: str):
        self.id = id
        self.description = description


class FetchParamsResponse(BaseModel):
    req_params: Dict[int, str]
    broad_params: Dict[int, str]
    gps_params: Dict[int, str]
    i2c_params: Dict[int, str]
    can_data_mode: Dict[int, str]
    can_baud_rate: Dict[int, str]
    imu_data_range: Dict[int, str]
    acc_full_scale_range: Dict[int, str]
    gyro_full_scale_range: Dict[int, str]
    analog_channel: Dict[int, str]
    aggregate_data_type: Dict[int, str]


class SourceEnum(str, Enum):
    CAN = "CAN"
    GPS = "GPS"
    I2C = "I2C"


class LogConfigMetaData(BaseModel):
    created_by: Optional[int] = Field(None, description="User ID who created the block")
    created_on: Optional[str] = Field(None, description="Timestamp when the block was created")
    updated_by: Optional[int] = Field(None, description="User ID who last updated the block")
    updated_on: Optional[str] = Field(None, description="Timestamp when the block was last updated")
    sources: Optional[List[SourceEnum]] = Field(None, description="List of sources for the block")


class EncodingTypeEnum(str, Enum):
    DECIMAL = "DECIMAL"
    FLOAT = "FLOAT"
    ASCII = "ASCII"
    HEX = "HEX"


class ParameterBase(BaseModel):
    name: str
    length: Optional[float] = None
    units: Optional[str] = Field(None)
    frequency: Optional[float] = Field(None, description="Only to be mentioned if not 1 Hz")
    num_buckets: Optional[int] = Field(None)
    bucket_range_low: Optional[List[int]] = Field(None, description="List of low range values for buckets")
    bucket_range_high: Optional[List[int]] = Field(None, description="List of high range values for buckets")
    aggregate_data: Optional[List[int]] = Field(None,
                                                description="List of ENUM MEAN, MEDIAN, COUNT, VARIANCE")
    encoding: Optional[EncodingTypeEnum] = Field(EncodingTypeEnum.HEX)

    @model_validator(mode="before")
    @classmethod
    def check_mandatory_fields(cls, values):
        frequency = values.get('frequency')
        if frequency and frequency > 1:
            required_fields = ['num_buckets', 'bucket_range_low', 'bucket_range_high', 'aggregate_data']
            for field in required_fields:
                if values.get(field) is None:
                    raise ValueError(f'{field} is mandatory when frequency is greater than 1')
        return values


class CanParamBase(ParameterBase):
    master_pid: int


class GPSParam(ParameterBase):
    pass


class I2CParam(ParameterBase):
    pass
    # multiplier: float
    # offset: float
    # min: int
    # max: int


class AnalogParam(ParameterBase):
    #   temp unitl we have list of table for analog
    multiplier: float = 0
    offset: float = 0
    min: int = 0
    max: int = 0
    channel: int


class DigitalParam(ParameterBase):
    multiplier: float
    offset: float
    min: int
    max: int


class CANParam(CanParamBase):
    multiplier: float
    offset: float
    endian: Endian = None
    is_signed: bool = False
    min: int
    max: int
    device_params: dict


class UserLogConfigForm(BaseModel):
    make_model: str
    can_data_mode: int
    GPS: List[int]
    can_baud_rate: int
    imu_data_range: int
    acc_full_scale: int
    gyro_full_scale: int
    # gps_baud_rate: int
    can_req: List[CanParamBase]
    can_broad: List[CanParamBase]
    analog: List[AnalogParam]
    # digital: List[DigitalParam]
    i2c: List[I2CParam]
    remark_by_user: str = ""


class ServerLogConfigFile(BaseModel):
    metadata: LogConfigMetaData
    GPS: List[GPSParam]
    CAN: List[CANParam]
    I2C: List[I2CParam]
    analog: List[AnalogParam]
    # digital: List[DigitalParam]


class Bucket(BaseModel):
    bucket_range_low: int
    bucket_range_high: int
    aggregate_data: List[int]


# ================== Source : CAN ================================

class RequestParamCfg(BaseModel):
    service_id: int
    can_ext_param: Optional[int] = None
    pid1: str
    pid2: int
    length: float


class RequestRespCfg(BaseModel):
    request_id: str
    response_id: str
    request_param_cfg: List[RequestParamCfg]


class BroadcastParam(BaseModel):
    length: float
    start_byte: int


class PGNCfg(BaseModel):
    pgn_id: str
    broadcast_param: List[BroadcastParam]


class CANConfig(BaseModel):
    data_mode: int
    baud_rate: int
    pgn_cfg: List[PGNCfg]
    request_resp_cfg: List[RequestRespCfg]


class DeviceCANSource(BaseModel):
    source_id: int = 1
    can_cfg: CANConfig


# ================== Source : CAN ================================

# ================== Source : IMU ================================


class AccBucket(BaseModel):
    ax_bucket_config: conlist(list, max_length=5)
    ay_bucket_config: conlist(list, max_length=5)
    az_bucket_config: conlist(list, max_length=5)


class GyroBucket(BaseModel):
    gyro_bucket_config: conlist(list, max_length=5)


class IMUConfig(BaseModel):
    odr: int
    acc_fs: int
    gyro_fs: int
    accel_bucket_count: int
    gyro_bucket_count: int


class DeviceIMUSource(BaseModel):
    source_id: int = 2
    imu_cfg: IMUConfig
    acc_bucket: AccBucket
    gyro_bucket: GyroBucket


# ================== Source : IMU ================================

# ================== Source : Analog ================================
class ChannelCfg(BaseModel):
    channel_id: int
    multiplier: float = 0.00968


class AnalogConfig(BaseModel):
    channel_cfg: List[ChannelCfg]


class DeviceAnalogSource(BaseModel):
    source_id: int = 4
    analog_cfg: AnalogConfig


# ================== Source : Analog ================================


# ================== Source :GPS ================================
class DeviceGPSConfig(BaseModel):
    num_param_log: List[int]

    @validator('num_param_log')
    def check_num_param_log(cls, v):
        if not all(1 <= item <= 6 for item in v):
            raise ValueError('Each value in num_param_log must be between 1 and 6')
        return v


class DeviceGPSSource(BaseModel):
    source_id: int = 3
    gps_cfg: DeviceGPSConfig


# ================== Source : GPS ================================


class DeviceLogConfigFile(BaseModel):
    source_cfg: List[Union[DeviceCANSource, DeviceIMUSource, DeviceGPSSource, DeviceAnalogSource]]


class DeviceConfigBinary(BaseModel):
    encoded_can_cfg: bytes
    encoded_imu_cfg: bytes
