from fastapi import File, UploadFile
from pydantic import BaseModel,Field, field_validator
from typing import Optional, List
from datetime import datetime
from storage_settings import calculate_seven_days



from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class Create_Feature_Ticket_Input(BaseModel):
    feature_name: str = Field(..., title="Feature Name", description="Name of the feature", min_length=1)
    added_by: Optional[int] = Field(..., title="Added By", description="ID of the user who added the feature", gt=0)
    description: Optional[str] = Field(None, title="Description", description="Description of the feature", min_length=1)
    priority: Optional[int] = Field(None, title="Priority", description="Priority of the feature", gt=0)
    team: Optional[int] = Field(None, title="Team", description="ID of the team responsible for the feature", gt=0)
    owner: Optional[int] = Field(None, title="Owner", description="ID of the owner of the feature, if any", gt=0)
    requested_eta: Optional[str] = Field(None, title="Requested ETA", description="Requested ETA for the feature in format '07-07-2024 05:36:00'")
    requirement: Optional[str] = Field(None, title="Requirement", description="Requirement for the feature", min_length=1)
    modules: Optional[List[int]] = Field(None, title="Modules", description="List of module IDs related to the feature")
    attachments :Optional[List] = Field(None, title="Attachments", description="List of attachments related to the feature")

    @field_validator('requested_eta', mode='before')
    def set_requested_eta(cls, v):
        if v is None:
            return calculate_seven_days()
        return v



class UpdateFeatureTicket(BaseModel):
    ticketid: int = Field(..., gt=0, description="ID of the feature ticket to be updated")
    updated_by: int = Field(..., gt=0, description="ID of the user updating the feature ticket")
    feature_name: Optional[str] = Field(None, min_length=1, description="Name of the feature")
    description: Optional[str] = Field(None, min_length=1, description="Description of the feature")
    priority: Optional[int] = Field(None, gt=0, description="Priority of the feature")
    team: Optional[int] = Field(None, gt=0, description="ID of the team responsible for the feature")
    owner: Optional[int] = Field(None, gt=0, description="ID of the owner of the feature")
    requested_eta: Optional[str] = Field(None, description="Requested ETA for the feature")
    modules: Optional[List[int]] = Field(None, description="List of module IDs related to the feature")
    requirement: Optional[str] = Field(None, min_length=1, description="Requirement for the feature")
    status: Optional[int] = Field(None, description="Status of the feature ticket")
    approved: int = Field(None, title="Approved", description="Indicates whether the feature ticket is approved or rejected. Must be a boolean value.")


class EditRequirement(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="Specifies the ID of the feature ticket to which the requirement block belongs. Must be a positive integer.", gt=0)
    updated_by: int = Field(..., title="Updated By", description="Indicates the ID of the user who is updating the requirement block. Must be a positive integer.", gt=0)
    requirement_text: str = Field(..., title="Requirement Text", description="Mentions the requirement of the feature request ticket. Must be a non-empty string.")




class AddSubfeature(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="The ID of the feature ticket to which the Sub Feature block is to be added. Must be a positive integer.", gt=0)
    added_by: int = Field(..., title="Added By", description="The ID of the user who is adding the Sub Feature block. Must be a positive integer.", gt=0)
    sub_feature_name: str = Field(..., title="Sub Feature Name", description="The name of the Sub Feature block being added. Must be a non-empty string.", min_length=1)
    sub_feature_description: str = Field(..., title="Sub Feature Description", description="Provides a detailed description of the Sub Feature block. Must be a non-empty string.", min_length=1)
    modules: Optional[List[int]] = Field(None, title="Modules", description="A comma-separated list of library IDs that are related to the Sub Feature block. Optional field.")
    attachments :Optional[List] = Field(None, title="Attachments", description="List of attachments related to the subfeature")


class EditSubfeature(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="The unique identifier of the feature ticket to which the Sub Feature block belongs.", gt=0)
    updated_by: int = Field(..., title="Updated By", description="The user ID of the person who is making the changes.", gt=0)
    sub_feature_name: Optional[str] = Field(None, title="Sub Feature Name", description="The new name of the subfeature.", min_length=1)
    sub_feature_description: Optional[str] = Field(None, title="Sub Feature Description", description="A new description for the subfeature.", min_length=1)
    modules: Optional[List[int]] = Field(None, title="Modules", description="A comma-separated list of module IDs related to the subfeature.")


class DeleteSubfeature(BaseModel):
    ticketid: int
    deleted_by: int
    block_ids: List[int]



class AddPrototype(BaseModel):
    ticketid: int = Field(..., gt=0, description="The unique identifier of the feature ticket to which the prototype is being added.")
    added_by: int = Field(..., gt=0, description="The ID of the user who is adding the prototype.")
    prototype_description: str = Field(..., min_length=1, description="A detailed description of the prototype.")
    related_sub_feature_block: int = Field(..., gt=0, description="The ID of the subfeature block that is related to the prototype.")
    modules: Optional[List[int]] = Field(None, description="A list of module IDs related to the prototype.")
    attachments :Optional[List] = Field(None, title="Attachments", description="List of attachments related to the prototype")
  


class EditPrototype(BaseModel):
    ticketid: int = Field(..., gt=0, description="The unique identifier of the feature ticket to which the prototype is being added.")
    updated_by: int = Field(..., gt=0, description="The user ID of the person who is making the changes.")
    prototype_description: Optional[str] = Field(None, min_length=1, description="A detailed description of the prototype's purpose and functionality.")
    modules: Optional[List[int]] = Field(None, description="A list of module IDs related to the prototype.")
    related_sub_feature_block: Optional[int] = Field(None, gt=0, description="The identifier of the subfeature block to which this prototype is related.")
    stage: Optional[int] = Field(None, ge=0, description="Development stage of the prototype. Must be 0 or higher.")
    iterations: Optional[int] = Field(None, description="Number of iterations for the prototype, starting from 0.")


class DeletePrototype(BaseModel):
    ticketid: int = Field(..., gt=0, description="The ID of the feature ticket to which the prototype is linked. This field is critical for identifying the specific feature ticket from which the prototype will be deleted.")
    deleted_by: Optional[int] = Field(None, gt=0, description="The ID of the user who is performing the deletion. This is used for audit trails and permission checks to ensure that only authorized users can delete prototypes.")
    block_ids: Optional[List[int]] = Field(None, description="A list of block IDs related to the prototype that are to be deleted. This allows for selective deletion of prototype blocks if necessary.")

class ApproveFeatTicketInput(BaseModel):
    ticketid: int = Field(..., gt=0, description="The ID of the feature request ticket being approved. It serves as a primary key identifier for the specific feature ticket in question.")
    user_id: int = Field(..., gt=0, description="The ID of the user performing the approval or rejection. This is used to authenticate and authorize the action, ensuring that only eligible users can execute these operations.")



class RejectFeatTicketInput(BaseModel):
    ticketid: int = Field(..., description="The ID of the feature request ticket being rejected.")
    user_id: int = Field(..., description="The ID of the user performing the rejection.")
    notes: str = Field(..., description="The reason for the ticket being rejected.")


class CloseFeatTicketInput(BaseModel):
    ticketid: int = Field(..., description="The unique identifier of the feature ticket being closed.")
    user_id: int = Field(..., description="The identifier for the user responsible for closing the ticket.")
    req_summary: Optional[str] = Field(None, description="A brief summary of the requirements that were addressed during the lifecycle of the ticket.")
    proto_summary: Optional[str] = Field(None, description="A recap of the prototypes that were developed as part of the ticket.")
    sub_feat_summary: Optional[str] = Field(None, description="A summary of any subfeatures that were included in the feature ticket.")
    release_notes: Optional[str] = Field(None, description="Notes that describe the changes and features included in the release associated with the ticket.")
    future_imp: Optional[str] = Field(None, description="Insights or plans for future improvements based on the outcomes of the ticket.")
    learnings: Optional[str] = Field(None, description="Key learnings or takeaways from the experience of working on the feature ticket.")

 
class Approve_or_Reject_Feature_Ticket(BaseModel):
    ticketid : int = Field(..., title="Ticket ID", description="The ID of the feature ticket to be approved or rejected. Must be a positive integer.", gt=0)
    approved: int = Field(..., title="Approved", description="Indicates whether the feature ticket is approved or rejected. Must be a boolean value.")
    user_id : int = Field(..., title="User ID", description="The ID of the user who is approving or rejecting the feature ticket. Must be a positive integer.", gt=0)
    
    
class DeleteFeatureTicket(BaseModel):
    ticket_ids: List[int] = Field(..., description="List of feature ticket IDs to delete")
    deleted_by: int = Field(..., description="ID of the user requesting the deletion")
