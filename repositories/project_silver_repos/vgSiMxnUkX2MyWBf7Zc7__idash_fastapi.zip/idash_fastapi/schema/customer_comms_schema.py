


from typing import List, Optional
from pydantic import BaseModel


class MessageInput(BaseModel):
    vehicle_number : str
    date : str
    
    
class TripMetricsMessage(BaseModel):
    message_JSON : dict 
    phone_numbers: Optional[List[str]] = None
    
    
class RaiseErrorInput(BaseModel):
    message_JSON: dict
    raised_by: str
    