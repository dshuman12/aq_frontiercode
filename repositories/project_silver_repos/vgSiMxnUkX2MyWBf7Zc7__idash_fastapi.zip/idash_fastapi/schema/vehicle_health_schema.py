


from typing import List, Optional

from fastapi import UploadFile
from pydantic import BaseModel, Field



class Create_Vehicle_Health_Ticket(BaseModel):
    name : str = Field(None,title="Vehicle Health Ticket Name",description="Name of the vehicle health ticket")
    vehicle_number: str = Field(...,title="Vehicle Number",description="Vehicle number of the vehicle the ticket is related to")
    added_by : int = Field(...,title="Added By",description="User who added the vehicle health ticket")
    priority : Optional[int] = Field(None,title="Priority",description="Priority of the vehicle health ticket")
    description : Optional[str] = Field(None,title="Description",description="Description of the vehicle health ticket")
    modules : Optional[List[int]]  = Field(None,title="Modules",description="List of module IDs related to the feature")
    analysis_ticket_id : Optional[int] = Field(None,title="Analysis Ticket ID",description="ID of the analysis ticket related to the vehicle health ticket")
    attachments : Optional[List] = Field(None,title="Attachments",description="List of attachments related to the vehicle health ticket")


class Update_Vehicle_Health_Ticket(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="ID of the vehicle health ticket")
    updated_by : int = Field(...,title="Updated By",description="User who updated the vehicle health ticket")
    name : Optional[str] = Field(None,title="Vehicle Health Ticket Name",description="Name of the vehicle health ticket")
    vehicle_number: Optional[str] = Field(None,title="Vehicle Number",description="Vehicle number of the vehicle the ticket is related to")
    priority : Optional[int] = Field(None,title="Priority",description="Priority of the vehicle health ticket")
    description : Optional[str] = Field(None,title="Description",description="Description of the vehicle health ticket")
    modules : Optional[List[int]]  = Field(None,title="Modules",description="List of module IDs related to the feature")
    analysis_ticket_id : Optional[int] = Field(None,title="Analysis Ticket ID",description="ID of the analysis ticket related to the vehicle health ticket")
    owner : Optional[int] = Field(None,title="Owner",description="User who is the owner of the vehicle health ticket")
    status : Optional[int] = Field(None,title="Status",description="Status of the vehicle health ticket")


class TransferAnomalyRequest(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="ID of the vehicle health ticket")
    new_ticketid : int = Field(...,title="New Ticket ID",description="ID of the new vehicle health ticket")
    anomaly_id : int = Field(...,title="Anomaly ID",description="ID of the anomaly")
    transferee : int = Field(...,title="Transferee",description="User ID of the transferee")