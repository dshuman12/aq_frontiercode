
from typing import List, Optional
from pydantic import BaseModel, Field


class Add_New_Vehicle(BaseModel):
    
    user_id : int
    reg_no : str
    vehicle_make : str 
    vehicle_model : str
    emission : str
    chassis_no : str
    engine_no : str
    mfg_year : int
    fleet_id : int
    dataset_id : str
    device_id : str
   


class Update_ECU_Details(BaseModel):
    reg_no : str
    user_id : int
    ecu_no : str = Field(None, title="ECU No", description="ECU number of the vehicle")
    ecu_make : str = Field(None, title="ECU Make", description="Make of the ECU")
    ecu_model : str = Field(None, title="ECU Model", description="Model of the ECU")


class Create_Installation_Checklist(BaseModel):
    reg_no : str
    user_id : int
    battery_voltage : float = Field(None, title="Battery Voltage", description="Battery voltage should be between 12.5V to 14.5V")
    check_can_pins : bool = Field(default=False)
    check_KLINE_pins : bool = Field(default=False)
    igniton_affecting_voltage : Optional[str] = Field(None, title="Ignition Affecting Voltage")
    obd_location_photo: Optional[List] = Field(None, title="OBD port location photo", description="Expecting photos of OBD port location")
    installation_video : Optional[List] = Field(None, title="Installation video", description="Expecting video of installation"),
    add_pins_on_obd : Optional[List] = Field(None, title="Additional pins on OBD", description="Expecting additional pins on OBD")



class Create_Calibration_Block(BaseModel):
    reg_no : str 
    user_id : int 
    puc_certificate : Optional[List] = Field(None, title="PUC Certificate", description="Expecting PUC certificate")
    empty_weight : float = Field(..., title="Empty Weight", description="Empty weight of the vehicle")
    loaded_weight : float = Field(..., title="Loaded Weight", description="Loaded weight of the vehicle")
    photo_of_number_plate : Optional[List] = Field(None, title="Photo of Number Plate", description="Expecting photo of number plate")
    photo_of_wheels : Optional[List] = Field(None, title="Photo of Wheels", description="Expecting photo of wheels")
    photo_of_rc_book : Optional[List] = Field(None, title="Photo of RC Book", description="Expecting photo of RC book")



class Edit_Vehicle_Details(BaseModel):
    reg_no : str
    user_id : int
    vehicle_make : str = Field(None, title="Vehicle Make")
    vehicle_model : str = Field(None, title="Vehicle Model")
    emission : str = Field(None, title="Emission")
    chassis_no : str = Field(None, title="Chassis No")
    engine_no : str = Field(None, title="Engine No")
    fleet_id : int = Field(None, title="Fleet ID")
    mfg_year : int = Field(None, title="Manufacturing Year")


class Update_Electricals(BaseModel):
    user_id : int
    reg_no : str
    battery_voltage : float = Field(None, title="Battery Voltage", description="Battery voltage should be between 12.5V to 14.5V")
    ignition_affecting_voltage : Optional[str] = Field(None, title="Ignition Affecting Voltage")
    

class Update_Calibration(BaseModel):
    user_id : int
    reg_no : str
    empty_weight : float = Field(None, title="Empty Weight", description="Empty weight of the vehicle")
    loaded_weight : float = Field(None, title="Loaded Weight", description="Loaded weight of the vehicle")


class Add_New_Fleet(BaseModel):
    fleet_name : str
    user_id : int


class Edit_Fleet_Details(BaseModel):
    fleet_id : int
    fleet_name : str
    user_id : int


class Add_New_Make_Model(BaseModel):
    make : str
    model : str
    user_id : int


class Edit_Make_Model_Details(BaseModel):
    make : str
    model : str
    user_id : int


