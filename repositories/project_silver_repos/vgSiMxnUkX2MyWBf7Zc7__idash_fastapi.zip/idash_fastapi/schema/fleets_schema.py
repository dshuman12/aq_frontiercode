from pydantic import BaseModel, Field

class Add_Fleet(BaseModel):
    fleet_name: str = Field(..., max_length=255, description="Name of the fleet to be added")
    number_of_vehicles: int = Field(..., description="Number of vehicles in the fleet")
    distributor_id: int = Field(..., description="ID of the distributor")

class Update_Fleet(BaseModel):
    fleet_id: int = Field(..., description="ID of the fleet to be updated")
    fleet_name: str = Field(None, max_length=255, description="Updated name of the fleet")
    number_of_vehicles: int = Field(None, description="Updated number of vehicles in the fleet")
    distributor_id: int = Field(None, description="Updated ID of the distributor")


class Delete_Fleet(BaseModel):
    fleet_id: int = Field(..., description="ID of the fleet to be deleted")






