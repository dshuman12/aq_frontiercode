from pydantic import BaseModel, Field, validator, model_validator
from typing import List, Optional
from enum import Enum, IntEnum
from datetime import datetime


class VehicleSummaryRequest(BaseModel):
    vehicle_num: str
    start_date: str
    end_date: str


class TripRecord(BaseModel):
    trip_id: Optional[int] = Field(default=None, description="Unique identifier for the trip")
    start_id: int
    end_id: int
    payload: str
    slip: int = 0
    trip_flag: Optional[int] = 0
    health_flag: int = 0
    remarks: str = ""


class OptimizationData(BaseModel):
    vehicle_number: str
    improvement_latest_strat: Optional[float] = None
    last_week_improvement: Optional[float] = None
    distance_latest_strat: Optional[float] = None
    projected_monthly_savings: Optional[float] = None
    last_week_savings: Optional[float] = None
    overall_savings: Optional[float] = None
    total_distance: Optional[float] = None
    overall_improvement: Optional[float] = None


class HWUno2Input(BaseModel):
    part_number: str
    stm_id: str
    imei: str
    iccid_1: Optional[str] = None
    iccid_2: Optional[str] = None
    imsi_1: Optional[str] = None
    imsi_2: Optional[str] = None
    gps_serial_number: Optional[str] = None
    QA: Optional[int] = None
    year_of_production: Optional[int] = None
    batch_number: Optional[int] = None


class FuelFillingRecord(BaseModel):
    fuel_filling_id: Optional[int] = None
    filling_date_time: datetime
    pump_name: str
    odometer_reading: Optional[float] = None
    filling_place: str
    fuel_filled: float


class SoftwareTypes(Enum):
    BOOT_LOADER = "Boot Loader"
    CAN_FLASHING = "CAN Flashing"
    CAN_LOGGER = "CAN Logger"
    EMULATOR = "Emulator"
    PREPROD = "Pre-Production"
    PRODUCTION = "Production"

    CAN_CONFIG = "CAN_CONFIG"
    EDGE_CONFIG = "EDGE_CONFIG"


class SoftwareTypesIntEnum(IntEnum):
    BOOT_LOADER = 1
    CAN_FLASHING = 2
    CAN_LOGGER = 3
    EMULATOR = 4
    PREPROD = 5
    PRODUCTION = 6

    CAN_CONFIG = 7
    EDGE_CONFIG = 8


software_types_mapping = {stype: SoftwareTypesIntEnum[stype.name].value for stype in SoftwareTypes}


class SoftwareVersionRecord(BaseModel):
    software_type: SoftwareTypes
    added_by: int
    git_commit: str = ""
    git_url: str = ""


class TestRequirementRecord(BaseModel):
    emulator_cycle_id: int
    edge_config_version: int
    can_config_version: int


class TestRequirement(BaseModel):
    test_requirement_name: str
    test_requirements: List[TestRequirementRecord]
