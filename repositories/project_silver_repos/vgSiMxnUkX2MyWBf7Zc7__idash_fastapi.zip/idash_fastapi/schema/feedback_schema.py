

from typing import List, Optional
from pydantic import BaseModel


class AddFeedback_Input(BaseModel):
    ticket_id: int
    ticket_type: int
    added_by: int
    related_prototype_block: int
    result_summary: str
    attachments: Optional[List] = None
