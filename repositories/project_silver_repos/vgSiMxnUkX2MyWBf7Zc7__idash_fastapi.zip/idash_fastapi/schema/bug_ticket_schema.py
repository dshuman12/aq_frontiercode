from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from sqlalchemy.inspection import inspect


def sqlalchemy_obj_to_dict(obj):
    """
    Convert a SQLAlchemy object to a dictionary.

    If datetime objects are present, they are converted to string.


    """
    # Create a dictionary to store the object's attributes
    obj_dict = {}
    # Get the attributes of the object
    for key in inspect(obj).attrs.keys():
        # Get the value of the attribute
        value = getattr(obj, key)
        # If the value is a datetime object, convert it to string
        if isinstance(value, datetime):
            value = value.strftime('%Y-%m-%d %H:%M:%S')
        # Add the attribute to the dictionary
        obj_dict[key] = value
    # Return the dictionary
    return obj_dict

# Assuming you have a Pydantic model for BugTicket
class BugTicket(BaseModel):
    id: int
    name: str
    added_on: Optional[datetime] = None
    added_by_id: int
    module_id: Optional[str] = None
    owner: int
    approver: int
    bug_code: Optional[str] = None
    count: int
    group_id: Optional[int] = None
    status: str
    last_active: Optional[datetime] = None
    type: int
    priority: int
    assigned_team: int



class Create_Bug_Ticket(BaseModel):
    bug_name : Optional[str] = Field(None,title="Bug Ticket Name",description="Name of the bug ticket",alias="name")
    added_by : int = Field(...,title="Added By",description="User who added the bug ticket")
    bug_description : Optional[str] = Field(None,title="Bug Ticket Description",description="Description of the bug ticket")
    requested_eta : Optional[datetime] = Field(None,title="Requested ETA",description="Requested ETA for the bug ticket")
    priority : Optional[int] = Field(None,title="Priority",description="Priority of the bug ticket")
    owner : Optional[int] = Field(None,title="Owner",description="Owner of the bug ticket")
    modules: Optional[List[int]] = Field(None, title="Modules", description="List of module IDs related to the bug ticket")
    attachments : Optional[List] = Field(None, title="Attachments", description="List of attachments related to the bug ticket")


    class Config:
        populate_by_name = True


class Update_Bug_Ticket(BaseModel):
    bug_name : Optional[str] = Field(None,title="Bug Ticket Name",description="Name of the bug ticket",alias="name")
    updated_by : int = Field(...,title="Added By",description="User who added the bug ticket")
    bug_description : Optional[str] = Field(None,title="Bug Ticket Description",description="Description of the bug ticket")
    requested_eta : Optional[datetime] = Field(None,title="Requested ETA",description="Requested ETA for the bug ticket")
    priority : Optional[int] = Field(None,title="Priority",description="Priority of the bug ticket")
    owner : Optional[int] = Field(None,title="Owner",description="Owner of the bug ticket")
    modules : Optional[List] = Field(None,title="Library ID",description="Library ID of the bug ticket")
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    type : Optional[str] = Field(None,title="Type",description="Type of the bug ticket")

    class Config:
        populate_by_name = True


class Add_Cause_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    cause_name : str = Field(None,title="Cause Name",description="Name of the cause block")
    added_by : int = Field(...,title="Added By",description="User who added the cause block")
    description : str = Field(None,title="Cause Description",description="Description of the cause block")
    modules : List[int] = Field(None,title="Libraries",description="List of libraries related to the cause block")
    bug_blocks : List[int] = Field(None,title="Bug Blocks",description="List of bug blocks related to the cause block")
    function_code : Optional[str] = Field(None,title="Function Code",description="Function code of the cause block")
    attachments : Optional[List] = Field(None, title="Attachments", description="List of attachments related to the cause block")


class Update_Cause_Block(BaseModel):
    cause_block_id : int = Field(...,title="Cause ID",description="Cause ID of the cause block")
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    cause_name : Optional[str] = Field(None,title="Cause Name",description="Name of the cause block")
    updated_by : Optional[int] = Field(...,title="Added By",description="User who added the cause block")
    description : Optional[str] = Field(None,title="Cause Description",description="Description of the cause block")
    modules : Optional[List[int]] = Field(None,title="Libraries",description="List of libraries related to the cause block")
    related_bug_blocks : Optional[List[int]] = Field(None,title="Bug Blocks",description="List of bug blocks related to the cause block")
    function_code : Optional[str] = Field(None,title="Function Code",description="Function code of the cause block")


class Add_Solution_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    solution_name : str = Field(None,title="Solution Name",description="Name of the solution block")
    added_by : int = Field(...,title="Added By",description="User who added the solution block")
    solution_steps : Optional[str] = Field(None,title="Solution Steps",description="List of steps to resolve the bug")
    modules : List[int] = Field(None,title="Libraries",description="List of libraries related to the solution block")
    related_cause_blocks : List[int] = Field(None,title="Cause Blocks",description="List of cause blocks related to the solution block")
    function_code : Optional[str] = Field(None,title="Function Code",description="Function code of the solution block")
    attachments : Optional[List] = Field(None, title="Attachments", description="List of attachments related to the solution block")


class Update_Solution_Block(BaseModel):
    ticketid : int = Field(...,description="Ticket ID of the bug ticket"),     
    solution_block_id : int = Field(...,description="Solution Block ID"),
    updated_by : int = Field(...,description="User who updated the solution block"),
    solution_name : Optional[str] = Field(None,description="Name of the solution block"),
    steps : Optional[str] = Field(None,description="Description of the solution block"),
    related_cause_blocks : List[int] = Field(None,title="Cause Blocks",description="List of cause blocks related to the solution block"),
    modules : Optional[List[int]] = Field(None,description="List of modules related to the solution block"),
    function_code : Optional[str] = Field(None,description="Function code")


class Add_Result_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    added_by : int = Field(...,title="Added By",description="User who added the result block")
    result_name : str = Field(...,title="Result Name",description="Name of the result block")
    result_summary : str = Field(...,title="Result Summary",description="Summary of the result block")
    related_solution_blocks : List[int] = Field(...,title="Solution Blocks",description="List of solution blocks related to the result block")
    attachments : Optional[List] = Field(None, title="Attachments", description="List of attachments related to the result block")

class Update_Result_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    result_block_id : int = Field(...,title="Result Block ID",description="Result Block ID")
    updated_by : int = Field(...,title="Updated By",description="User who updated the result block")
    result_name : Optional[str] = Field(None,title="Result Name",description="Name of the result block")
    result_summary : Optional[str] = Field(None,title="Result Summary",description="Summary of the result block")
    related_solution_blocks : Optional[List[int]] = Field(None,title="Solution Blocks",description="List of solution blocks related to the result block")

class Transfer_Bug_Block(BaseModel):
    source_ticket_id : int = Field(...,title="Source Ticket ID",description="Source Ticket ID"), 
    target_ticket_id : int = Field(...,title="Target Ticket ID",description="Target Ticket ID"), 
    block_ids : List[int] = Field(...,title="Block IDs",description="List of block IDs to be transferred"),
    updated_by : int = Field(...,title="Updated By",description="User who updated the bug block")

class Delete_Bug_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    bug_block_ids : List[int] = Field(...,title="Bug Block IDs",description="List of bug block IDs to be deleted")
    deleted_by : int = Field(...,title="deleted By",description="User who deleted the bug block")


class Split_Bug_Block(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    bug_block_id : int = Field(...,title="Bug Block ID",description="Bug Block ID to be split")
    added_by : int = Field(...,title="Added By",description="User who added the bug block")
    instances : List[int] = Field(...,title="Instances",description="List of instances to be created")


class  Close_BugTicket(BaseModel):
    ticketid : int = Field(...,title="Ticket ID",description="Ticket ID of the bug ticket")
    closed_by : int = Field(...,title="Updated By",description="User who updated the bug ticket")
    future_imp : Optional[str] = Field(None,title="Future Implementation",description="Future Implementation")
    learnings : Optional[str] = Field(None,title="Learnings",description="Learnings")
    
class Modify_Function_List(BaseModel):
    bug_code: str
    function_name: str = None
    team_id: int = None
    
    
class Report_Bug(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="Ticket ID of the bug ticket")
    reported_by: int = Field(..., title="Reported By", description="User who reported the bug")
    bug_noted: str = Field(..., title="User Comments", description="User comments on the bug")
    vehicle_num: Optional[str] = Field(None, title="Vehicle Number", description="Vehicle number associated with the bug")
    device_id: Optional[str] = Field(None, title="Device ID", description="Device ID associated with the bug")

