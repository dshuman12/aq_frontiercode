

from typing import List
from pydantic import BaseModel


class DownloadFile_Schema(BaseModel):
    pth : str
    
class Read_RDSTable(BaseModel):
    table_name : str
    page: int = 2