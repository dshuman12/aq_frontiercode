# pydantic model for adding/updating a Conversation
from typing import Optional
from pydantic import BaseModel, Field


class Add_Conversation_Model(BaseModel):
    ticketid : int = Field(..., title="Ticket ID", description="ID of the feature ticket to which the conversation belongs", gt=0)
    added_by : Optional[int] = Field(None, title="Added By", description="ID of the user who added the conversation", gt=0)
    text : Optional[str] = Field(None, title="Text", description="Text of the conversation", min_length=1)
    parent_block : Optional[int] = Field(None, title="Parent Block", description="ID of the parent block")
    ticket_type : Optional[int] = Field(None, title="Ticket Type", description="Type of the ticket")
    
    
class Delete_Conversation_Model(BaseModel):
    ticketid : int = Field(..., title="Ticket ID", description="ID of the feature ticket to which the conversation belongs", gt=0)
    ticket_type : Optional[int] = Field(None, title="Ticket Type", description="Type of the ticket")
    convo_id : Optional[int] = Field(None, title="Conversation ID", description="ID of the conversation")
    deleted_by : Optional[int] = Field(None, title="Deleted By", description="ID of the user who is deleting the conversation", gt=0)
    
    
    