from pydantic import BaseModel, Field
from storage_settings import get_current_date

class add_hw_input(BaseModel):
    imei_no: str
    added_by: int
    
    
# Pydantic model for a hardware issue
class issue_instance(BaseModel):
    description: str = Field(..., description="Description of the issue.")
    added_on: str = Field(default_factory=get_current_date, description="Timestamp when the issue was added.")
    added_by: int = Field(..., description="Person or system adding the issue.")
    
    
# Pydantic model for getting the files for device preparation
class dload_code_input(BaseModel):
    device_id: str
    make_model: str
    

# Pydantic model for ping status input
class ping_status_input(BaseModel):
    imei_no : str
