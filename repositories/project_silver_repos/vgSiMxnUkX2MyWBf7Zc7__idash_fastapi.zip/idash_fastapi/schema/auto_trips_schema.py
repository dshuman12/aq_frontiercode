from typing import List, Optional
from fastapi import File, UploadFile
from pydantic import BaseModel


class Get_AutoTrips_Input(BaseModel):

    vehicle_num : str 
    start_date : str
    end_date : str 
    
class Update_Trip_Input(BaseModel):
    
    vehicle_number: str
    trip_id: int 
    verified: Optional[bool] = None 
    remark: Optional[str] = None
    category: Optional[str] = None
    