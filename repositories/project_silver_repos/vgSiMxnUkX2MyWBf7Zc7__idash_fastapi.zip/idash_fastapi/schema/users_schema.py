
import bcrypt
from pydantic import BaseModel,EmailStr, constr,field_validator,Field
from typing import List, Optional
from passlib.context import CryptContext


# Define Pydantic model for user serialization
class Users_Serializer(BaseModel):
    user_id: List[int]
    username: List[str]
    fullname: List[Optional[str]]

    @classmethod
    def from_dataframe(cls, all_users):
        user_id_list = all_users['id'].tolist()
        username_list = all_users['username'].tolist()
        fullname_list = []

        for _, row in all_users.iterrows():
            if row['first_name'] and row['last_name']:
                fullname_list.append(f"{row['first_name']} {row['last_name']}")
            elif row['first_name']:
                fullname_list.append(row['first_name'])
            else:
                fullname_list.append(row['username'])

        return cls(user_id=user_id_list, username=username_list, fullname=fullname_list)
    

# Define Pydantic model for team serialization
class Teams_Serializer(BaseModel):
    team_id: List[int]
    team_name: List[Optional[str]]



# Define pydantic model for creating a user 


class CreateUserModel(BaseModel):
    email: EmailStr
    phone_number: str
    team_id: int
    requested_user_id: int
    designation: Optional[str] = None
    is_superuser: Optional[int] = None

    @field_validator('phone_number')
    def validate_phone_number(cls, v):
        if not (v.startswith('+') and 12 <= len(v) <= 13 and v[1:3].isdigit()):
            raise ValueError('Phone number must start with "+" and be 12-13 characters long, where 2 or 3 digits after "+" represent the country code.')
        return v




password_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class SignUpModel(BaseModel):
    username: str
    email_id: EmailStr
    phone_number: str = Field(..., pattern=r'^\+\d{11,12}$')
    first_name: str
    last_name: str
    password: str = Field(..., min_length=8)
    emergency_contact_name: str
    emergency_contact_number: Optional[str] = None
    alternate_phone_number: Optional[str] = None
    personal_email: Optional[EmailStr] = None

    
    @field_validator('password', mode='before')
    def hash_password(cls, value):
        return password_context.hash(value)






class LoginUserModel(BaseModel):
    """
    Pydantic model for logging in a user.
    """

    username: str
    password: str

    class Config:
        # Pydantic model configuration
        orm_mode = True  # Allows parsing of ORM objects

    @field_validator('password',mode='before')
    def validate_password(cls, v):
        """
        Validate the password field to ensure it is at least 8 characters long.
        """
        assert len(v) >= 8, 'Password must be at least 8 characters long'
        return v
    

    
    
class UsernameCheck(BaseModel):
    username: str