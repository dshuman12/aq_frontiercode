from typing import List, Optional
from fastapi import File, UploadFile
from pydantic import BaseModel


class DeleteAttachment_Input(BaseModel):
    presigned_url : str
    ticket_type: int = None
    ticketid : int = None
    block_id : int = None
    deleted_by: int 
    vehicle_num : str = None
 
    
class AddMoreAttachments_Input(BaseModel):
    added_by: int
    ticket_type: Optional[int] = None
    ticketid : Optional[int] = None
    block_id : Optional[int] = None
    attachments : Optional[List[UploadFile]] = None
    vehicle_num : Optional[str] = None
    obd_location_photo : Optional[List[UploadFile]] = None
    installation_video : Optional[List[UploadFile]] = None
    photo_of_rc_book : Optional[List[UploadFile]] = None
    photo_of_wheels : Optional[List[UploadFile]] = None
    photo_of_number_plate : Optional[List[UploadFile]] = None    
    puc_certificate_photo : Optional[List[UploadFile]] = None
    
