from typing import List
from fastapi import File, UploadFile
from pydantic import BaseModel


class AddToTest(BaseModel):
    vehicle_number : str
    device_id : str
    
class Test_Rig_Input(BaseModel):
    test_rig_id : str
    

class Mark_Test_Started(BaseModel):
    test_rig_id : str
    device_id : str
    
    
class Release_Test_Rig(BaseModel):
    test_rig_id : str
