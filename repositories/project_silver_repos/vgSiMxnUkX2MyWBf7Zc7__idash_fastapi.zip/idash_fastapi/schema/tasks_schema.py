
from typing import List, Optional
from pydantic import BaseModel, Field



# for accepting inputs for add task
class AddTask_Input(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="ID of the feature ticket to which the task belongs", gt=0)
    added_by: int = Field(..., title="Added By", description="ID of the user who added the task", gt=0)
    ticket_type: int = Field(..., title="Ticket Type", description="The type of ticket")
    priority: int = Field(default=1, title="Priority", description="Priority of the task")
    status: int = Field(default=1, title="Status", description="Current status of the task")
    deadline: Optional[str] = Field(None, title="Deadline", description="Deadline for the task")
    name: str = Field(..., title="Task Name", description="Name of the task")
    owner: Optional[int] = Field(default=None, title="Owner", description="ID of the owner of the task", gt=0)
    machine_raised: Optional[bool] = Field(default=False, title="Machine Raised", description="Whether the task was raised by a machine")
    attachments: Optional[List] = Field(None, title="Attachments", description="List of attachments related to the task")


# for accepting inputs for update task
class UpdateTask_Input(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="ID of the feature ticket to which the task belongs", gt=0)
    ticket_type: int = Field(..., title="Ticket Type", description="The type of ticket")
    taskid: int = Field(..., title="Task ID", description="ID of the task to be updated", gt=0)
    updated_by: int = Field(..., title="Updated By", description="ID of the user who updated the task", gt=0)
    priority: Optional[int] = Field(None, title="Priority", description="Priority of the task")
    status: Optional[int] = Field(None, title="Status", description="Current status of the task")
    deadline: Optional[str] = Field(None, title="Deadline", description="Deadline for the task")
    name: Optional[str] = Field(None, title="Task Name", description="Name of the task")
    owner: Optional[int] = Field(None, title="Owner", description="ID of the owner of the task", gt=0)
    machine_raised: Optional[bool] = Field(None, title="Machine Raised", description="Whether the task was raised by a machine")


# for accepting inputs for delete task
class DeleteTask_Input(BaseModel):
    ticketid: int = Field(..., title="Ticket ID", description="ID of the feature ticket to which the task belongs", gt=0)
    ticket_type: int = Field(..., title="Ticket Type", description="The type of ticket")
    task_ids: List[int] = Field(..., title="Task ID", description="ID of the tasks to be deleted")
    deleted_by: int = Field(..., title="Deleted By", description="ID of the user who deleted the task", gt=0)
