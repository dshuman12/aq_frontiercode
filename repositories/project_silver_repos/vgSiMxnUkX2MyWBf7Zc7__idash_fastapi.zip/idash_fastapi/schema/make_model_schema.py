

from typing import Optional
from pydantic import BaseModel


class AddMakeModel(BaseModel):
    make_model_id: str
    vehicle_make: str
    vehicle_model: str
    emission: Optional[str]
    ecu_make: Optional[str]
    ecu_model: Optional[str]
    ecu_software_id: Optional[str]
    gvw: Optional[int]
    cylinders: Optional[int]
    num_of_gears: Optional[int]
    engine_capacity: Optional[int]
    power: Optional[int]
    max_torque_nm: Optional[int]
    rpm_min_for_max_torque: Optional[int]
    rpm_max_for_max_torque: Optional[int]
    max_rpm: Optional[int]
    oe_front_tyre_type: Optional[int]
    oe_rear_tyre_type: Optional[int]
    wheel_radius: Optional[float]
    gear_1: Optional[float]
    gear_2: Optional[float]
    gear_3: Optional[float]
    gear_4: Optional[float]
    gear_5: Optional[float]
    gear_6: Optional[float]
    gear_7: Optional[str]
    gear_8: Optional[str]
    gear_9: Optional[str]
    crawler: Optional[str]
    rear_axle_ratio: Optional[float]
    reverse: Optional[float]
    injector_part_number: Optional[str]
    fuel_pump_make: Optional[str]
    fuel_pump_model: Optional[str]
    pp_flag: Optional[str]
    algo_flag: Optional[str]
    broadcast_flag: Optional[int]
    request_flag: Optional[int]
    exec_command_flag: Optional[int]
    flashing_flag: Optional[int]
    dataset_flag: Optional[int]
    bb_flag: Optional[str]
    dtc_flag: Optional[int]
    pairs: Optional[int]
    req_id: Optional[str]
    resp_id: Optional[str]
    dataset_id : Optional[str]
    
class UpdateMakeModel(BaseModel):
    make_model_id: str  # Required field
    
    vehicle_make: Optional[str] = None
    vehicle_model: Optional[str] = None
    emission: Optional[str] = None
    ecu_make: Optional[str] = None
    ecu_model: Optional[str] = None
    ecu_software_id: Optional[str] = None
    gvw: Optional[int] = None
    cylinders: Optional[int] = None
    num_of_gears: Optional[int] = None
    engine_capacity: Optional[int] = None
    power: Optional[int] = None
    max_torque_nm: Optional[int] = None
    rpm_min_for_max_torque: Optional[int] = None
    rpm_max_for_max_torque: Optional[int] = None
    max_rpm: Optional[int] = None
    oe_front_tyre_type: Optional[int] = None
    oe_rear_tyre_type: Optional[int] = None
    wheel_radius: Optional[float] = None
    gear_1: Optional[float] = None
    gear_2: Optional[float] = None
    gear_3: Optional[float] = None
    gear_4: Optional[float] = None
    gear_5: Optional[float] = None
    gear_6: Optional[float] = None
    gear_7: Optional[str] = None
    gear_8: Optional[str] = None
    gear_9: Optional[str] = None
    crawler: Optional[str] = None
    rear_axle_ratio: Optional[float] = None
    reverse: Optional[float] = None
    injector_part_number: Optional[str] = None
    fuel_pump_make: Optional[str] = None
    fuel_pump_model: Optional[str] = None
    pp_flag: Optional[str] = None
    algo_flag: Optional[str] = None
    broadcast_flag: Optional[int] = None
    request_flag: Optional[int] = None
    exec_command_flag: Optional[int] = None
    flashing_flag: Optional[int] = None
    dataset_flag: Optional[int] = None
    bb_flag: Optional[str] = None
    dtc_flag: Optional[int] = None
    pairs: Optional[int] = None
    req_id: Optional[str] = None
    resp_id: Optional[str] = None
    dataset_id : Optional[str] = None
    
    class Config:
        orm_mode = True
    
class DeleteMakeModel(BaseModel):
    make_model_id : str

