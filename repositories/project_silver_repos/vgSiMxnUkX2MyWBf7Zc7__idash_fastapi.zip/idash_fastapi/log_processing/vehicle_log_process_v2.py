import json
import struct
from typing import List, Tuple, Union
import math
import datetime
import os

from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB
from hiper_utils.aws.s3.s3 import S3Bucket
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs, create_bug_instance, \
    append_to_input_data, serialize_bug_instance
from hiper_utils.other_utils.vehicles_util import get_location_from_lat_lon, get_summary_vehicle, get_vehicle_make_model
from hiper_utils.Loggers.python_logger import LoggerFactory
from log_processing.log_processing_models import DecodeType, file_ending_param_decode_type_2, CalculatedSummaryData
# from log_processing.post_processing import PostProcessing
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleDeviceLogs, ActiveVehicle
from hiper_utils.other_utils.bug_util import add_bug

import numpy as np
from geopy import distance
import geopy as gp
import pandas as pd
from sqlalchemy import update

import warnings

# Ignore all warnings
warnings.filterwarnings("ignore")

lib_code = '07'
lib_ver = '01'

lib_code_ver = f"{lib_code}{lib_ver}"


class LogProcessorBase:

    def __init__(self):
        self.hiperft_bucket = S3Bucket(
            bucket_name="hiperftp"
        )

        self.hipedatalake = S3Bucket(
            bucket_name="hiperdatalake"
        )

    @staticmethod
    def replace_values_with_nearest(df_or_series: Union[pd.DataFrame, pd.Series], condition: pd.Series,
                                    column_name: str = None):
        """
         Replace incorrect values in a DataFrame column or a Pandas Series based on a given condition with the nearest correct value.
         Prefer previous row, then next row.
        """

        if isinstance(df_or_series, pd.Series):
            column = df_or_series
        else:
            column = df_or_series[column_name]

        # Replace incorrect values with NaN where the condition is True

        column = column.where(~condition, pd.NA)
        # Forward fill NaN values with the nearest correct value (prefer previous, then next)
        column = column.fillna(method='ffill')

        # Backward fill remaining NaN values with the nearest correct value
        column = column.fillna(method='bfill')

        return column


class DeviceLogProcessor(LogProcessorBase):
    DEVICE_RAW_LOG_FILE_PTH = 'hiperftp/deviceFolders/device_id/logfiles/raw_log_file.bin'
    FILE_ENDING_PARAM_DECODE_TYPE = file_ending_param_decode_type_2
    DBC_FILE_PTH = 'make_model_data/make_model_id/DBC_make_model_iddbc_version.parquet'
    VEHICLE_JSON = 'website/vehicles/<veh_num>/<veh_num>.json'

    CHECKSUM_OCCUPIED_BYTES = 1
    GPS_PARAMS = {
        'GPS Time': 3,
        'Lat': 4,
        'Long': 4,
        'Altitude': 4
    }

    IMU_PARMAS = {
        'Ax': 30,
        'Ay': 30,
        'Az': 30,
        'Rx': 30,
        'Ry': 30,
        'Rz': 30
    }

    ADC_PARAMS = {
        "fuel_level": 4,
        "v_bat": 4,

    }

    vehicle_model_manual_mapping = {
        'AP39T2882': '0111',
        'KA25D4795': '0112',
        'TN06AB7905': '0110',
        'TN86E5699': '0113',
        'TN02BY0523': '0114',
        'MH12NX5938': '0201',
        'KA51AB2021': '0301',
        "NL01B3011": "0113"
    }

    def __init__(self, logger_obj, vehicle_model_mapping, run_type: str):
        super().__init__()
        if run_type == "PROD":

            self.VEHICLE_SUMMARY_PTH = 'vehicle_data/<veh_num>/SUMMARY_<veh_num>.parquet'  # Production
            self.PROCESSED_LOG_FILE_PTH = 'vehicle_data/<v_num>/log_data/<device_id>/<file_name>'  # Prod

            self.rds_instance = MySQLDB(
                db_name="lite_db",
                env_var_prefix="MYSQL"
            )
            self.session = self.rds_instance.get_connection()

        else:

            self.rds_instance = MySQLDB(
                db_name="dev_schema",
                env_var_prefix="MYSQL_DEV"
            )
            self.session = self.rds_instance.get_connection()

            self.VEHICLE_SUMMARY_PTH = 'vehicle_data/<veh_num>/dev_env/SUMMARY_<veh_num>.parquet'  # Dev
            self.PROCESSED_LOG_FILE_PTH = 'vehicle_data/dev_env/<v_num>/log_data/<device_id>/<file_name>'  # Dev

        with open("STM_file_ending_version_mapping.json", "r") as t:
            mapping = json.load(t)
        self.stm_file_ending_mapping = mapping
        with open("default_values_mapping.json", "r") as t:
            default_values_mapping = json.load(t)
        self.default_values_mapping = default_values_mapping

        self.lp_logger = logger_obj
        self.VEHICLE_MODEL_MAPPING = vehicle_model_mapping
        self.VEHICLE_MODEL_MAPPING.update(self.vehicle_model_manual_mapping)

        # Temporary Addition
        self.strat_table, self.strat_bug = self.hiperft_bucket.download_parquet(
            s3_key="vehicle_data/strat_table.parquet", save_local=True)

        self.lp_logger.info(f" ### Run Type {run_type}")

    @staticmethod
    def decoded_to_ascii(bin_data: bytes) -> str:
        return bin_data.decode('utf-8')

    @staticmethod
    def decode_to_decimal(bin_data: bytes) -> int:
        if isinstance(bin_data, int):
            return bin_data
        return int.from_bytes(bin_data, byteorder='big')

    @error_handler(library_code=lib_code_ver, function_code="02", class_logger="lp_logger")
    def process_pending_device_logs(self, v_num: str, device_id: str, pending_file: str, raw_log_file_data,
                                    make_model: str, is_manual_run: bool = False, bugs={}):

        make_model_id = self.VEHICLE_MODEL_MAPPING[v_num]
        file_num = int(pending_file.split('_')[1].split('.')[0])

        print(f"### Processing file : {pending_file} device : {device_id}\n\n")
        self.lp_logger.info(f"\n\n### Processing file : {pending_file} device : {device_id}\n\n")

        default_values, default_value_bug = self.get_default_values(file_num=file_num, device_id=device_id)

        combine_bugs(bugs, default_value_bug)

        is_log_file_processed, device_process_bug = self.process_device_log_file(raw_data=raw_log_file_data,
                                                                                 v_num=v_num,
                                                                                 default_values=default_values,
                                                                                 make_model=make_model)

        append_to_input_data(bug_instances=device_process_bug, additional_data={
            "device_id": device_id,
            "file_num": pending_file
        })

        combine_bugs(bugs, device_process_bug)

        if is_log_file_processed is None or is_log_file_processed is False:
            print(f"Error Processing file: {device_process_bug}")
            self.lp_logger.error(f"Error Processing file: {device_process_bug}")
            # continue

        print(f"Processing Complete for file :: {pending_file} device : {device_id}")
        self.lp_logger.info(f"Processing Complete for file :: {pending_file} device : {device_id}")
        processed_log_df, file_ending_dict, checksum_match, single_row_info = is_log_file_processed

        return processed_log_df, checksum_match, single_row_info

    @error_handler(library_code=lib_code_ver, function_code="03", class_logger="lp_logger")
    def process_device_log_file(self, raw_data: bytes, v_num: str, default_values: dict, make_model: str, bugs={}):

        print(f"Total Bytes Received: {len(raw_data)}")
        self.lp_logger.info(f"Total Bytes Received: {len(raw_data)}")

        # Separating Log file
        separation_result, separation_bug = self.separate_log_parts(raw_data=raw_data,
                                                                    default_stm=default_values['default_stm_version'])

        combine_bugs(bugs, separation_bug)
        if separation_result is None:
            return False

        run_time_raw_data, file_ending_data, file_ending_format, is_file_ending_corrupted = separation_result
        print("Run time data size ", len(run_time_raw_data))
        self.lp_logger.info(f"Run time data size {len(run_time_raw_data)} ")

        # Processing File Ending
        processed_file_ending_data, file_end_process_bug = self.process_file_ending(
            file_ending_bytes=file_ending_data,
            file_ending_format=file_ending_format,
            default_values=default_values,
            v_num=v_num
        )

        if file_end_process_bug:
            combine_bugs(bugs, file_end_process_bug)
            return False

        print("================= File Ending Data =============")
        print(processed_file_ending_data)
        self.lp_logger.info("================= File Ending Data =============")
        self.lp_logger.info(processed_file_ending_data)
        self.lp_logger.info("================= File Ending Data =============")

        make_model_id = self.VEHICLE_MODEL_MAPPING[v_num]
        # dbc_version = processed_file_ending_data['DBC Version #']
        # dbc_file_pth_s3 = self.DBC_FILE_PTH.replace("make_model_id", make_model_id)
        # dbc_file_pth_s3 = dbc_file_pth_s3.replace("dbc_version", dbc_version)
        #
        # print("DEBUG:: ", dbc_file_pth_s3)
        # self.lp_logger.debug(dbc_file_pth_s3)

        # dbc_file_df, dbc_file_bug = self.hiperft_bucket.download_parquet(
        #     s3_key=dbc_file_pth_s3,
        #     save_local=False
        # )

        dbc_file_json, dbc_file_json_bug = self.hipedatalake.download_json(
            s3_key=f"make model/{make_model}/log_config/server_log_config_{make_model}.json")

        if dbc_file_json is None:
            combine_bugs(bugs, dbc_file_json_bug)
            return False
        print(f"make model/{make_model}/server_log_config_{make_model}.json")
        # with open('server_log_config_0113.json', "r") as t:
        print("============================")
        print(dbc_file_json_bug)

        dbc_file_json = dbc_file_json['CAN']

        dbc_file_df, dbc_file_bug = pd.DataFrame(dbc_file_json), {}
        dbc_file_df['param_type'] = dbc_file_df['device_params'].apply(lambda device_param: device_param['type'])
        dbc_file_df['pgn_id'] = dbc_file_df['device_params'].apply(lambda device_param: device_param.get("pgn_id", ""))

        # Step 3: Rearrange rows so that 'BRD' type comes on top
        df_brd = dbc_file_df[dbc_file_df['param_type'].str.contains('BRD')]  # Rows with 'BRD'
        df_non_brd = dbc_file_df[~dbc_file_df['param_type'].str.contains('BRD')]  # Rows without 'BRD'

        # Step 4: Concatenate 'BRD' rows on top of the rest
        dbc_file_df = pd.concat([df_brd, df_non_brd], ignore_index=True)

        # dbc_file_df.to_csv("DEBUF DBC.csv")

        dbc_file_df.rename(columns={"length": "size_in_bytes", "name": "param_name"}, inplace=True)
        if dbc_file_bug:
            combine_bugs(bugs, dbc_file_bug)
            return False

        single_row_info, calculation_bug = self.calculate_row_byte_lengths(dbc_file_df=dbc_file_df)
        if calculation_bug:
            combine_bugs(bugs, calculation_bug)
            return False

        single_row_size, tracking_param_length, param_names, empty_bytes_to_add = single_row_info

        print(f"Single Row Size ::: {single_row_size}")
        self.lp_logger.info(f"Single Row Size ::: {single_row_size}")

        verification_result, segregation_bug = self.verify_and_segregate_data(raw_run_time=run_time_raw_data,
                                                                              dbc_file_df=dbc_file_df,
                                                                              single_raw_size=single_row_size,
                                                                              total_lines=1000,
                                                                              is_file_ending_corrupted=is_file_ending_corrupted,
                                                                              file_ending_format=file_ending_format,
                                                                              tracking_param_length=tracking_param_length,
                                                                              empty_bytes_added=empty_bytes_to_add)

        combine_bugs(bugs, segregation_bug)
        if verification_result is None:
            return False

        raw_run_time_df, partial_frame_write_issue, checksum_match = verification_result

        # if processed_file_ending_data['Total # of Lines'] is None:
        processed_file_ending_data['Total # of Lines'] = raw_run_time_df.shape[0]

        processed_run_time_df, process_bug = self.process_raw_runtime(
            raw_run_time_df=raw_run_time_df,
            dbc_file_df=dbc_file_df
        )

        # processed_run_time_df.to_csv()

        if process_bug:
            combine_bugs(bugs, process_bug)
            if processed_run_time_df is None:
                return False

        # if partial_frame_write_issue:
        #     # Remove Corrupted Data
        #     self.lp_logger.warning(f"Partial Frame write issue {partial_frame_write_issue}")
        #
        #     clean_run_time_df, detect_corruption_bug = self.detect_corrupted_rows(processed_run_time_df)
        #
        #     combine_bugs(bugs, detect_corruption_bug)
        #
        #     if clean_run_time_df is not None:
        #         processed_run_time_df = clean_run_time_df

        return processed_run_time_df, processed_file_ending_data, checksum_match, single_row_info

    @error_handler(library_code=lib_code_ver, function_code="04", class_logger="lp_logger")
    def separate_log_parts(self, raw_data: bytes, default_stm: str, bugs={}) -> Tuple[bytes, bytes, dict, bool]:
        # stm_version = self.decode_to_decimal(raw_data[-1])

        # stm_version = 37
        # print(f"STM version from file ending:: {stm_version}")
        # self.lp_logger.info(f"STM version from file ending :: {stm_version}")
        # is_file_ending_corrupted = False

        # if str(stm_version) != default_stm and default_stm is not None:
        #     is_file_ending_corrupted = True
        #     stm_bug = create_bug_instance(
        #         module_code=lib_code_ver,
        #         function_code="04",
        #         error_code="01",
        #         message=f"File ending seems to be corrupted wrong STM version found {stm_version}"
        #     )
        #     combine_bugs(bugs, stm_bug)

        #     stm_version = default_stm
        #     print(f"Considering default STM version :: {stm_version}")
        #     self.lp_logger.warning(f"Considering default STM version :: {stm_version}")
        #
        # file_ending_version = self.stm_file_ending_mapping['version_mapping'].get(str(stm_version))
        # if file_ending_version is None:
        #     print(f"Can not find file ending version mapping for STM version {stm_version}")
        #     raise f"Can not find file ending version mapping for STM version {stm_version}"
        # file_ending_format = self.stm_file_ending_mapping['format_mapping'][file_ending_version]
        #
        # file_ending_bytes = sum(file_ending_format.values())
        # print(f"File Ending Bytes Size : {file_ending_bytes}")
        # self.lp_logger.info(f"File Ending Bytes Size : {file_ending_bytes}")

        # if is_file_ending_corrupted:
        #     '''
        #     INCASE OF FILE ENDING CORRUPTION ASSUMING FILE ENDING IS NOT THERE
        #     SENDING ALL DATA AS RUN TIME DATA ,
        #     BUT STILL SENDING FILE_ENDING DATA BYTES FROM  AS PLACEHOLDERS
        #     '''
        #     run_time_data = raw_data
        # else:
        file_ending_format = {"Date": 8,
                              "Current Image": 3,
                              "c_can_cfg": 1,
                              "c_imu_cfg": 1,
                              "c_adc_cfg": 1,
                              "c_anl_cfg": 1,
                              "c_dig_cfg": 1,
                              "c_exp_cfg": 1,
                              "c_strat": 1,
                              "Driver ID": 1}
        is_file_ending_corrupted = False
        file_ending_bytes = 19
        run_time_data = raw_data[:-file_ending_bytes]

        file_ending_data = raw_data[-file_ending_bytes:]

        print(file_ending_data)

        return run_time_data, file_ending_data, file_ending_format, is_file_ending_corrupted

    @error_handler(library_code=lib_code_ver, function_code="19", class_logger="lp_logger")
    def get_default_values(self, file_num: int, device_id: str, bugs={}) -> dict:

        default_dbc_version = None
        default_stm_version = None
        default_strat_version = None

        default_values = self.default_values_mapping.get(device_id)

        if default_values is None:
            default_value_bug = create_bug_instance(
                module_code=lib_code_ver,
                function_code="19",
                error_code="01",
                input_data={"device_id": device_id},
                message="default value mapping not found for device"

            )
            combine_bugs(bugs, default_value_bug)
        else:
            update_from_file_num = default_values['update_from_file_num']

            if update_from_file_num is not None and file_num >= update_from_file_num:
                default_dbc_version = default_values['dbc_updated']
                default_stm_version = default_values['stm_updated']
                default_strat_version = default_values['strat_updated']
            else:
                default_dbc_version = default_values['dbc_current']
                default_stm_version = default_values['stm_current']
                default_strat_version = default_values['strat_current']

        # if summary_file[summary_file['device_id'] == device_id].shape[0] == 0:
        #     self.lp_logger.info('No rows for device id %s in summary file of', device_id)
        #     default_dbc_version = None
        #     default_stm_version = None
        #     default_strat_version = None
        # else:
        #     # Get the list of summary ids in the summary file for the given device id
        #     summary_id_lst = summary_file[summary_file['device_id'] == device_id].index.tolist()
        #     # Find the nearest summary id to the given summary id
        #     nearest_summary_id = min(summary_id_lst, key=lambda x: abs(x - summary_id))
        #     default_dbc_version = summary_file.loc[nearest_summary_id, 'dbc_current']
        #     default_stm_version = summary_file.loc[nearest_summary_id, 'stm_current']
        #     default_strat_version = summary_file.loc[nearest_summary_id, 'strat_current']
        self.lp_logger.info(f'Default dbc version of the file {file_num} {default_dbc_version}')
        self.lp_logger.info(f'Default strat version of the file {file_num} {default_strat_version}')
        self.lp_logger.info(f'Default stm version of the file {file_num} is {default_stm_version}')

        return {
            "default_stm_version": default_stm_version,
            "default_dbc_version": default_dbc_version,
            "default_strat_version": default_strat_version
        }

    @error_handler(library_code=lib_code_ver, function_code="05", class_logger="lp_logger")
    def process_file_ending(self, file_ending_bytes: bytes, file_ending_format: dict, default_values: dict,
                            v_num=None) -> dict:

        parsed_values = {}

        print(file_ending_format)
        for key in file_ending_format:
            num_bytes = file_ending_format[key]
            param_bytes = file_ending_bytes[:num_bytes]

            # Determine the decoding type for the current parameter
            decode_type = file_ending_param_decode_type_2.get(key)
            if decode_type is None:
                print(f"Please Specify how to decode {key} param , in file_ending_param_decode_type")
                raise f"Please Specify how to decode {key} param , in file_ending_param_decode_type"

            # Convert the bytes to the appropriate data type based on the decoding type
            if decode_type == DecodeType.DECIMAL:
                try:
                    parsed_values[key] = self.decode_to_decimal(bin_data=param_bytes)
                except:
                    parsed_values[key] = None
            elif decode_type == DecodeType.ASCII:
                try:
                    parsed_values[key] = self.decoded_to_ascii(bin_data=param_bytes)
                except:
                    parsed_values[key] = None

            # Remove the processed bytes from the file ending bytes
            file_ending_bytes = file_ending_bytes[num_bytes:]

        print(parsed_values)
        # self.lp_logger.info(parsed_values)
        # parsed_values['STRAT VERSION #'] = None if parsed_values['STRAT VERSION #'] is None else str(
        #     parsed_values['STRAT VERSION #']).zfill(3)
        # if "Start RTC Time" in parsed_values:
        #     try:
        #         parsed_values['Start RTC Time'] = datetime.datetime.strptime(parsed_values['Start RTC Time'],
        #                                                                      '%H%M%S').time()
        #     except:
        #         parsed_values['Start RTC Time'] = None
        # 
        # if "Start Date" in parsed_values:
        #     try:
        #         parsed_values['Start Date'] = datetime.datetime.strptime(parsed_values['Start Date'], '%d%m%y').date()
        #     except:
        #         parsed_values['Start Date'] = None

        # if file ending is corrupted
        # default_strat_version = default_values['default_strat_version']
        # default_dbc_version = default_values['default_dbc_version']
        # default_stm_version = default_values['default_stm_version']

        ## This if statement is added  temprory , until embed team fix the issue  2022_04_054 , TN33BT5080   DBC Version

        if v_num == 'TN33BT5080' and parsed_values['DBC Version #'] == '002':
            parsed_values['DBC Version #'] = '001'

        ## This if statement is added  temprory , until embed team fix the issue  2022_04_054 , TN33BT5080   DBC Version

        # if str(parsed_values['STM Version #']) != default_stm_version:
        #     parsed_values['STM Version #'] = default_stm_version
        #     if default_dbc_version == parsed_values['DBC Version #']:
        #         # Only STM version is corrupted
        #         pass
        #     else:
        #         # Whole file edning is corrupted
        #         parsed_values['DBC Version #'] = default_dbc_version
        #         parsed_values['STRAT VERSION #'] = default_strat_version
        #         parsed_values['File Ending Type'] = 3
        #         parsed_values['IGN on time'] = None
        #         parsed_values['Total # of Lines'] = None

        return parsed_values

    @error_handler(library_code=lib_code_ver, function_code="06", class_logger="lp_logger")
    def calculate_row_byte_lengths(self, dbc_file_df: pd.DataFrame) -> int:
        param_names = ['gps time', 'lat',
                       'long',
                       'altitude']  # To show which bit reprenst which tracking param , we are maninting param name
        # Order of log file
        # GPS
        # CAN
        #     CAN
        #     BROAD
        #     CAN
        #     REQ
        #
        # IMU
        # ADC(v_bat, fuel_level) << float
        # tracking
        # chacksum

        # to do add check sum parma size

        check_sum_bytes = self.CHECKSUM_OCCUPIED_BYTES
        imu_tracking_param = 1

        can_req_params = dbc_file_df['param_type'].to_list().count('REQ')
        # can_broad_params = len(
        #     set(dbc_file_df[dbc_file_df['param_type'] == 'BRD']['pgn_id'].to_list()))  # Number of PGNS

        can_broad_params = dbc_file_df['param_type'].to_list().count('BRD')

        pgns_id = dbc_file_df[dbc_file_df['param_type'] == 'BRD']['param_name']
        param_names.extend(pgns_id)

        req_param_names = dbc_file_df[dbc_file_df['param_type'] == 'REQ']['param_name']
        param_names.extend(req_param_names)
        param_names.append("IMU")
        param_names.extend(["v_bat", "fuel_level"])

        print(dbc_file_df.columns)
        dbc_param_size = dbc_file_df['size_in_bytes'].apply(lambda x: math.ceil(float(x))).sum()
        print("DBC PARAM REQ::: ", can_req_params)
        print("DBC PARAM BROAD::: ", can_broad_params)
        # A line(Row) contains gps params, dbc params, imu params and tracking param

        tracking_param_size_in_bytes = math.ceil(
            (can_req_params + can_broad_params + len(self.GPS_PARAMS) + imu_tracking_param + len(self.ADC_PARAMS)) / 8)

        print("TRACKING PARAM :::", tracking_param_size_in_bytes)

        gps_param_size = sum(self.GPS_PARAMS.values())
        imu_param_size = sum(self.IMU_PARMAS.values())
        adc_param_size = sum(self.ADC_PARAMS.values())
        line_size = dbc_param_size + gps_param_size + imu_param_size + tracking_param_size_in_bytes + adc_param_size + check_sum_bytes

        if line_size % 4 != 0:
            empty_bytes_to_add = 4 - (line_size % 4)
        else:
            empty_bytes_to_add = 0
        line_size += empty_bytes_to_add
        # line size = length of row in bytes
        return line_size, tracking_param_size_in_bytes, param_names, empty_bytes_to_add

    @staticmethod
    def decode_bucket(data_chunk: bytes):
        # First 4 bytes -> little-endian float
        float_value = struct.unpack('<f', data_chunk[:4])[0]

        # Last 1 byte -> integer (decimal)
        int_value = int.from_bytes(data_chunk[4:5], byteorder='big')

        return (float_value, int_value)

    def decode_acc_values(self, byte_data: bytes):
        decoded_data = []
        for i in range(0, len(byte_data), 5):  # Process in chunks of 5 bytes
            bucket = byte_data[i:i + 5]
            decoded_data.append(self.decode_bucket(bucket))
        return decoded_data

    @error_handler(library_code=lib_code_ver, function_code="07", class_logger="lp_logger")
    def verify_and_segregate_data(self, raw_run_time: bytes, dbc_file_df: pd.DataFrame, single_raw_size: int,
                                  total_lines: int, is_file_ending_corrupted: bool, file_ending_format: dict,
                                  tracking_param_length: int, empty_bytes_added: int,
                                  bugs={}) -> (pd.DataFrame, bool):

        # Verification
        total_rows = math.ceil(len(raw_run_time) / single_raw_size)

        file_ending_bytes = sum(file_ending_format.values())
        file_ending_data = raw_run_time[-file_ending_bytes:]

        if is_file_ending_corrupted:
            if len(raw_run_time) % single_raw_size == 0:
                print("File ending is not present at all")
                self.lp_logger.warning("File ending is not present at all")
            else:
                print("File ending is there but in corrupted format , Trying after removing last file ending bytes")
                self.lp_logger.warning(
                    "File ending is there but in corrupted format , Trying after removing last file ending bytes")

                raw_run_time = raw_run_time[:-file_ending_bytes]
                total_rows = math.ceil(len(raw_run_time) / single_raw_size)

        partial_frame_write_issue = False
        if len(raw_run_time) % single_raw_size != 0:
            self.lp_logger.warning(
                "Run time data bytes does not completely divisible , ending frames seems to be issue while writing on deivce")
            print(
                "Run time data bytes does not completely divisible , ending frames seems to be issue while wrting on deivce")
            # taking only complete frames( can include corrupted frames as well)

            self.lp_logger.info(f"Before Adding file ending bytes: {len(raw_run_time)}")

            raw_run_time = raw_run_time + file_ending_data

            self.lp_logger.info(f"After adding file ending bytes : {len(raw_run_time)}")

            incomplete_frame_bytes = len(raw_run_time) % single_raw_size

            print("Incomplete frame size", incomplete_frame_bytes)
            self.lp_logger.info(f"Incomplete frame size : {incomplete_frame_bytes}")

            if incomplete_frame_bytes:
                raw_run_time = raw_run_time[:-incomplete_frame_bytes]

            self.lp_logger.info(f"after removing incomplete frame : {len(raw_run_time)}")
            self.lp_logger.info(f"Divisibility check : {len(raw_run_time) % single_raw_size}")
            print(">>>>> ", len(raw_run_time) % single_raw_size)

            partial_frame_write_issue = True

            total_rows = math.ceil(len(raw_run_time) / single_raw_size)

        if total_lines is not None and total_rows != total_lines:
            print("Total number of run time not matching with total line received in file ending")
            self.lp_logger.warning("Total number of run time not matching with total line received in file ending")
            total_line_not_match_bug = create_bug_instance(
                module_code=lib_code_ver,
                function_code="07",
                error_code="01",
                input_data={},
                message="Total number of run time not matching with total line received in file ending"
            )
            combine_bugs(bugs, total_line_not_match_bug)

        valid_rows = []
        invalid_rows = []
        checksum_match = {
            "calculated_checksum": [],
            "received_checksum": []

        }
        for i in range(total_rows):
            single_run_time = raw_run_time[i * single_raw_size:(i + 1) * single_raw_size]
            if empty_bytes_added:
                single_run_time = single_run_time[:-empty_bytes_added]
            received_checksum = single_run_time[-1]
            calculated_checksum = self.calculate_checksum(single_run_time[:-1])
            print("Calculated Checksum", calculated_checksum)
            print("Recived Check sum", received_checksum)
            # calculated_checksum = 100

            checksum_match['calculated_checksum'].append(calculated_checksum)
            checksum_match['received_checksum'].append(received_checksum)

            valid_rows.append(single_run_time)
            # print(">>> index",i)
            # print(single_run_time)
            # if calculated_checksum == received_checksum:
            #     valid_rows.append(single_run_time)
            # else:
            #
            #     print(f"Invalid Row Found {i}")
            #     self.lp_logger.warning(f"Invalid Row Found {i}")
            #     invalid_rows.append(i)

        if len(valid_rows) != total_rows:
            check_sum_bug = create_bug_instance(
                module_code=lib_code_ver,
                function_code="07",
                error_code="02",
                message=f"Check sum mismatch   for {(total_rows - len(valid_rows)) * 100 / total_rows}% values {','.join(map(str, invalid_rows))}"
            )
            combine_bugs(bugs, check_sum_bug)
        # Segregation
        parameters_size_dict = {}

        parameters_size_dict.update(self.GPS_PARAMS)
        for ind, dbc_parma_row in dbc_file_df.iterrows():
            parameters_size_dict[dbc_parma_row['param_name']] = math.ceil(float(dbc_parma_row['size_in_bytes']))
        parameters_size_dict.update(self.IMU_PARMAS)
        parameters_size_dict.update(self.ADC_PARAMS)

        # total_params = len(parameters_size_dict)
        # tracking_param_size = math.ceil(total_params / 8)

        parameters_size_dict['tracking_param'] = tracking_param_length
        parameters_size_dict['checksum'] = self.CHECKSUM_OCCUPIED_BYTES

        print(parameters_size_dict)

        # Define the struct format based on column specifications
        struct_format = "<" + "".join([f"{size}s" for size in parameters_size_dict.values()])
        print(parameters_size_dict)
        valid_rows_data = []
        for valid_row in valid_rows:
            # print(valid_row)
            unpacked_data = struct.iter_unpack(struct_format, valid_row)
            data_list = [dict(zip(parameters_size_dict.keys(), row)) for row in unpacked_data]
            # print(data_list)
            valid_rows_data.append(data_list[0])

        raw_run_time_df = pd.DataFrame(valid_rows_data)

        print(raw_run_time_df)
        # parameters_size_dict.pop('tracking_param')
        # parameters_size_dict.pop('checksum')

        #

        # a b c d e 1111

        # boolean_df = pd.DataFrame(raw_run_time_df['tracking_param'].apply(lambda row: [bit == '1' for bit in
        #                                                                                format(
        #                                                                                    int.from_bytes(row, 'big'),
        #                                                                                    '0{}b'.format(
        #                                                                                        8 * tracking_param_length))[
        #                                                                                ::-1][
        #                                                                                0:len(
        #                                                                                    parameters_size_dict)]]).tolist(),
        #                           columns=parameters_size_dict.keys())
        #
        # bool_df_columns = boolean_df.columns
        # for bool_column in bool_df_columns:
        #     boolean_df.rename(columns={bool_column: f"{bool_column} Tracking"}, inplace=True)
        #
        # raw_run_time_df = pd.concat([raw_run_time_df, boolean_df], axis=1)

        #
        # print(raw_run_time_df)

        fuel_level_hex_list = raw_run_time_df['fuel_level'].apply(lambda x: x.hex()).tolist()

        print(fuel_level_hex_list)
        raw_run_time_df.to_csv("DEBUG_4.csv", index=False)
        return raw_run_time_df, partial_frame_write_issue, checksum_match

    @error_handler(library_code=lib_code_ver, function_code="30", class_logger="lp_logger")
    def detect_corrupted_rows(self, df):

        min_lat = -90
        max_lat = 90
        min_long = -180
        max_long = 180

        # Detect indices of rows with latitude or longitude values outside their actual ranges
        out_of_range_indices = df.index[~((df['lat'] >= min_lat) & (df['lat'] <= max_lat) &
                                          (df['longi'] >= min_long) & (df['longi'] <= max_long))]

        self.lp_logger.warning(f"Corrupted rows detected at {out_of_range_indices}")
        # Remove rows with out-of-range values
        df = df.drop(out_of_range_indices)

        return df

    @error_handler(library_code=lib_code_ver, function_code="07", class_logger="lp_logger")
    def process_raw_runtime(self, raw_run_time_df: pd.DataFrame, dbc_file_df: pd.DataFrame, bugs={}) -> pd.DataFrame:

        print(raw_run_time_df['tracking_param'])
        # raw_run_time_df.drop('tracking_param', axis=1, inplace=True)
        # raw_run_time_df.drop('checksum', axis=1, inplace=True)
        dbc_file_df = dbc_file_df.set_index('param_name')
        dbc_file_df['size_in_bytes'] = dbc_file_df['size_in_bytes'].apply(lambda x: math.ceil(float(x)))
        # if len(raw_run_time_df) > 30:
        # Remove the last 30 rows from the DataFrame
        # raw_run_time_df = raw_run_time_df.iloc[:-30]
        # tracking_param_false_percentage = self.verify_tracking_param_percentage(processed_df=raw_run_time_df)
        # if tracking_param_false_percentage:
        #     tracking_param_bug = create_bug_instance(
        #         module_code=lib_code_ver,
        #         function_code="07",
        #         error_code="01",
        #         input_data={},
        #         message=f"Tracking param values less than 100%  parameters with false value % {tracking_param_false_percentage}"
        #     )
        #     combine_bugs(bugs, tracking_param_bug)

        processed_log_df = pd.DataFrame(columns=raw_run_time_df.columns)
        time_bytes_corrupted_frame_ind = None
        for col in raw_run_time_df.columns:
            if col == "GPS Time":
                processed_log_df[col] = raw_run_time_df[col].apply(self.decode_time_bytes)

                # corrupted_indices = processed_log_df[col][processed_log_df[col].isnull()].index
                # time_bytes_corrupted_frame_ind = corrupted_indices
                # for idx in corrupted_indices:
                #     self.lp_logger.warning(f"Corrupted time at index: {idx}")
                #     print("Corrupted time at index:", idx)
                #     if idx > 0:
                #         print("Time above:", processed_log_df[col][idx - 1])
                #         self.lp_logger.warning(f"Time above: {processed_log_df[col][idx - 1]}")
                #     if idx < len(processed_log_df) - 1:
                #         print("Time below:", processed_log_df[col][idx + 1])
                #         self.lp_logger.warning(f"Time below: {processed_log_df[col][idx + 1]}")
                # processed_log_df[col], correct_time_bug = self.correct_time_param(processed_log_df[col])
                # if correct_time_bug:
                #     combine_bugs(bugs, correct_time_bug)

            elif col == 'Lat' or col == 'Long':
                # tracking_param_false_condition = raw_run_time_df[col + " Tracking"] == False
                # raw_run_time_df[col] = self.replace_values_with_nearest(df_or_series=raw_run_time_df,
                #                                                         condition=tracking_param_false_condition,
                #                                                         column_name=col)
                processed_log_df[col] = raw_run_time_df[col].apply(self.decode_lat_longi_bytes)

            elif col == 'Altitude':
                # tracking_param_false_condition = raw_run_time_df[col + " Tracking"] == False
                # raw_run_time_df[col] = self.replace_values_with_nearest(df_or_series=raw_run_time_df,
                #                                                         condition=tracking_param_false_condition,
                #                                                         column_name=col)

                processed_log_df[col] = raw_run_time_df[col].apply(self.decode_altitude_bytes)


            elif col in ['Ax', 'Ay', 'Az', 'Rx', 'Ry', 'Rz']:
                processed_log_df[col] = raw_run_time_df[col].apply(lambda x: self.decode_acc_values(byte_data=x))

            elif "Tracking" in col:
                processed_log_df[col] = raw_run_time_df[col]

            elif "fuel_level" == col:
                processed_log_df[col] = raw_run_time_df[col].apply(lambda x : struct.unpack('<f', x)[0])

            elif "v_bat" == col:
                processed_log_df[col] = raw_run_time_df[col].apply(lambda x: struct.unpack('<f', x)[0])

            else:
                # tracking_param_false_condition = raw_run_time_df[col + " Tracking"] == False
                # raw_run_time_df[col] = self.replace_values_with_nearest(df_or_series=raw_run_time_df,
                #                                                         condition=tracking_param_false_condition,
                #                                                         column_name=col)
                processed_log_df[col], decode_dbc_bug = self.decode_dbc_param(dbc_file=dbc_file_df,
                                                                              dbc_param_column=raw_run_time_df[col],
                                                                              dbc_param_tracking_column="",
                                                                              param_name=col)

                if decode_dbc_bug:
                    combine_bugs(bugs, decode_dbc_bug)

        # raw_run_time_df['vbat_fuel_level_hex'] = raw_run_time_df['Ax'] + raw_run_time_df['Ay']
        # raw_run_time_df['vbat_fuel_level_hex'] = raw_run_time_df['vbat_fuel_level_hex'].apply(lambda x: x.hex())
        #
        # # Marking Tracking Param False for frames which has corrupted time bytes
        #
        # processed_log_df['v_bat'] = raw_run_time_df['vbat_fuel_level_hex'].apply(lambda hex_str: hex_str[:8][::-1])
        # processed_log_df['v_bat'] = processed_log_df['v_bat'].apply(
        #     lambda hex_str: ''.join([''.join(reversed(hex_str[i:i + 2])) for i in range(0, len(hex_str), 2)]))
        # processed_log_df['v_bat'] = processed_log_df['v_bat'].apply(
        #     lambda hex: struct.unpack('!f', bytes.fromhex(hex))[0])
        #
        # processed_log_df['fuel_level'] = raw_run_time_df['vbat_fuel_level_hex'].apply(
        #     lambda hex_str: hex_str[8:16][::-1])
        # processed_log_df['fuel_level'] = processed_log_df['fuel_level'].apply(
        #     lambda hex_str: ''.join([''.join(reversed(hex_str[i:i + 2])) for i in range(0, len(hex_str), 2)]))
        # processed_log_df['fuel_level'] = processed_log_df['fuel_level'].apply(
        #     lambda hex: struct.unpack('!f', bytes.fromhex(hex))[0])

        # if time_bytes_corrupted_frame_ind is not None:
        #     print(time_bytes_corrupted_frame_ind)
        #
        #     for col in processed_log_df.columns:
        #         if ' Tracking' in col:
        #             processed_log_df.loc[time_bytes_corrupted_frame_ind, col] = False
        print("===============================")
        print(raw_run_time_df['tracking_param'])

        processed_log_df['tracking_param'] = raw_run_time_df['tracking_param'].apply(
            lambda x: format(int.from_bytes(x, 'big'), f'0{len(x) * 8}b')[::-1]
        )
        processed_log_df.rename(columns={'GPS Time': 'time',
                                         'Lat': 'lat',
                                         'Long': 'longi',
                                         'Altitude': 'altitude'}, inplace=True)
        # processed_log_df.to_csv("l__002.csv")
        # print("================")
        return processed_log_df

    @staticmethod
    def verify_tracking_param_percentage(processed_df: pd.DataFrame) -> dict:
        false_percentage_dict = {}
        for col in processed_df:
            if " Tracking" in col:
                orignal_col = col.replace(" Tracking", "")
                false_count = (processed_df[col] == False).sum()
                total_count = len(processed_df[col])
                false_percentage = (false_count / total_count) * 100
                if false_percentage:
                    false_percentage_dict[orignal_col] = false_percentage

        return false_percentage_dict

    @staticmethod
    def calculate_checksum(data):
        # print(data)
        checksum = sum(data)
        checksum_hex = hex(checksum)[2:]

        # Zero-pad if necessary to ensure at least two characters
        checksum_hex = checksum_hex.zfill(2)

        # Get the least significant byte
        least_significant_byte = int(checksum_hex[-2:], 16)

        return least_significant_byte

    @staticmethod
    def decode_time_bytes(raw_time_byte: bytes):
        # Decode the raw time byte. If it cannot be decoded then set the value to None

        hours = int.from_bytes(raw_time_byte[0:1], 'big')
        minutes = int.from_bytes(raw_time_byte[1:2], 'big')
        seconds = int.from_bytes(raw_time_byte[2:3], 'big')

        # Format as HH:MM:SS
        formatted_time = f"{hours:02}{minutes:02}{seconds:02}"

        # print(f"Formatted Time: {formatted_time}")
        try:
            time = datetime.datetime.strptime(formatted_time, '%H%M%S')
            return time
        except Exception as e:
            # print(e)
            return None

    @staticmethod
    def decode_lat_longi_bytes(raw_bytes: bytes) -> float:
        """
        Decode latitude or longitude from a 4-byte byte string.

        Args:
            raw_bytes (bytes): 4-byte data representing the latitude or longitude.

        Returns:
            float: The decoded latitude or longitude value, or None if the conversion fails.
        """
        try:
            if len(raw_bytes) != 4:
                print(f"Warning: Expected 4 bytes, got {len(raw_bytes)} bytes. Returning None.")
                return None
        except:
            return None

        try:

            value = struct.unpack('<f', raw_bytes)[0]

            return value
        except (ValueError, TypeError):
            print(f"Warning: Error decoding bytes {raw_bytes!r}. Returning None.")
            return None

    @staticmethod
    def decode_altitude_bytes(raw_altitude_byte):
        # Decode the raw altitude byte. If it cannot be decoded then set the value to None
        try:
            altitude = raw_altitude_byte.decode()
        except:
            altitude = None
        return altitude

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="12")
    def correct_time_param(time_column):

        # Find the index with a valid datetime
        time_col_index = time_column[time_column.notnull()].index[0]

        correct_time_lst = []
        for i in range(len(time_column)):
            if i == time_col_index:
                correct_time_lst.insert(i, time_column[i])
            elif i < time_col_index:
                seconds = int(time_col_index - i)
                correct_time_lst.insert(i, time_column[time_col_index] - datetime.timedelta(seconds=seconds))
            else:
                seconds = int(i - time_col_index)
                correct_time_lst.insert(i, time_column[time_col_index] + datetime.timedelta(seconds=seconds))
        correct_time_series = pd.Series(correct_time_lst)
        # Convert correct_time_series to datetime.time
        correct_time_series = correct_time_series.apply(lambda x: x.time())
        return correct_time_series

    @error_handler(library_code=lib_code_ver, function_code="13")
    def decode_dbc_param(self, dbc_file, dbc_param_column, dbc_param_tracking_column, param_name, bugs={}):

        if dbc_file.loc[param_name, 'size_in_bytes'] == 1:
            # If 1 byte, then convert the raw_param_column to int
            decoded_series = dbc_param_column.apply(
                lambda x: (ord(x) * dbc_file.loc[param_name, "multiplier"]) + dbc_file.loc[param_name, "offset"])



        elif dbc_file.loc[param_name, 'size_in_bytes'] == 2 or dbc_file.loc[param_name, 'size_in_bytes'] == 4:

            endian = dbc_file.loc[param_name, 'endian']

            is_signed = dbc_file.loc[param_name, 'is_signed']

            if endian == 'LITTLE':

                if is_signed:
                    decoded_series = dbc_param_column.apply(

                        lambda x: int.from_bytes(x, "little", signed=True) * dbc_file.loc[param_name, "multiplier"]) + \
 \
                                     dbc_file.loc[param_name, "offset"]

                else:

                    decoded_series = dbc_param_column.apply(

                        lambda x: int.from_bytes(x, "little", signed=False) * dbc_file.loc[param_name, "multiplier"]) + \
 \
                                     dbc_file.loc[param_name, "offset"]

            elif endian == 'BIG':

                if is_signed:
                    decoded_series = dbc_param_column.apply(

                        lambda x: int.from_bytes(x, "big", signed=True) * dbc_file.loc[param_name, "multiplier"]) + \
 \
                                     dbc_file.loc[param_name, "offset"]

                else:

                    decoded_series = dbc_param_column.apply(

                        lambda x: int.from_bytes(x, "big", signed=False) * dbc_file.loc[param_name, "multiplier"]) + \
 \
                                     dbc_file.loc[param_name, "offset"]

            else:

                print(f"Warning: Unknown endianness '{endian}' for parameter '{param_name}'. Skipping decoding.")

                # continue

        if not (dbc_file.loc[param_name, 'size_in_bytes'] == 2 or dbc_file.loc[param_name, 'size_in_bytes'] == 4):
            out_of_range_condition = (decoded_series < dbc_file.loc[param_name, 'min']) | (
                    decoded_series > dbc_file.loc[param_name, 'max'])

            if not decoded_series[out_of_range_condition].empty:
                self.lp_logger.warning(decoded_series[out_of_range_condition])

            out_of_range_value_indices = decoded_series[out_of_range_condition].index
            # tracking_param_true_indices = dbc_param_tracking_column[dbc_param_tracking_column == True].index

            # out_of_range_true_indices = [index for index in out_of_range_value_indices if
            #                              index in tracking_param_true_indices]

            # if out_of_range_true_indices:
            #     # Raise bug : Value is out of range but tracking param is True for param:
            #     out_of_rng_bug = create_bug_instance(
            #         module_code=lib_code_ver,
            #         function_code="13",
            #         error_code="01",
            #         message=f"Value is out of range but tracking param is True for param: {param_name}"
            #     )
            #     combine_bugs(bugs, out_of_rng_bug)
            # decoded_series = self.replace_values_with_nearest(df_or_series=decoded_series,
            #                                                   condition=out_of_range_condition)

        return decoded_series

    @error_handler(library_code=lib_code_ver, function_code="23")
    def apply_correction_to_processed_log(self, processed_log_df: pd.DataFrame, vehicle_json: dict):
        if "correction_block" in vehicle_json['0'].keys():
            self.lp_logger.info("Applying Correction to processed log data")
            correction_block = vehicle_json['0']['correction_block']
            for i in vehicle_json[correction_block].keys():
                processed_log_df.loc[:, i] = processed_log_df.loc[:, i] * float(vehicle_json[correction_block][i])

        return processed_log_df

    @error_handler(library_code=lib_code_ver, function_code="14")
    def calculate_summary_data(self, log_df: pd.DataFrame, file_end: dict, device_id, file_num,
                               bugs={}) -> CalculatedSummaryData:

        idling_locations, idling_bugs = self.get_filtered_idle_spots(log_df=log_df)

        if 'vehicle_speed' in log_df.columns:
            # Compute the distance travelled using vehicle speed
            distance_vehicle_speed, bug = self.distance_by_vehicle_speed(speed_column=log_df['vehicle_speed'])
            if bug:
                bugs = combine_bugs(bugs, bug)
        else:
            distance_vehicle_speed = None

        distance_from_gps, gps_distance_bug = self.gps_distance(gps_data=log_df[['lat', 'longi']])
        if gps_distance_bug:
            bugs = combine_bugs(bugs, gps_distance_bug)

        if (distance_from_gps is not None) and (distance_vehicle_speed is not None):
            if (distance_from_gps / distance_vehicle_speed < 0.98) and (distance_vehicle_speed > 1):
                # Raise bug as the distance computed using gps and vehicle speed is not matching
                speed_bug_instance = create_bug_instance(
                    module_code=lib_code_ver,
                    function_code="14",
                    error_code="01",
                    input_data={
                        "distance_gps": distance_from_gps,
                        "distance_vehicle_speed": distance_vehicle_speed,
                        "device_id": device_id,
                        "file_num": file_num
                    },
                    message="Ratio of distance_gps and distance_vehicle_speed < 98 percent and distance_vehicle_speed > 1km"
                )

                combine_bugs(bugs, speed_bug_instance)

        fuel_consumption, bug = self.fuel_consumed(fuel_column=log_df['fuel_rate'])
        bugs = combine_bugs(bugs, bug)

        if (fuel_consumption != 0) and (fuel_consumption != None):
            if distance_vehicle_speed == None:
                fuel_economy = round(distance_from_gps / fuel_consumption, 2)
            else:
                fuel_economy = round(distance_vehicle_speed / fuel_consumption, 2)
        else:
            # Check if run time is >0
            #     # Raise bug as fuel consumption is zero but run time is >0

            total_lines = file_end['Total # of Lines']
            if (total_lines > 0) and (fuel_consumption == 0):
                fuel_run_time_bug_instance = create_bug_instance(
                    module_code=lib_code_ver,
                    function_code="14",
                    error_code="02",
                    input_data={
                        "run_time": total_lines,
                        "fuel_consumption": fuel_consumption,
                        "device_id": device_id,
                        "file_num": file_num
                    },
                    message="Fuel consumption is zero but run time is >0"
                )

                combine_bugs(bugs, fuel_run_time_bug_instance)
            fuel_economy = 0

        gps_data, gps_start_stop_bug = self.start_stop_gps(gps_df=log_df[['lat', 'longi']])
        if gps_start_stop_bug:
            bugs = combine_bugs(bugs, gps_start_stop_bug)

        if 'vehicle_speed' in log_df.columns:
            distance_travelled = distance_vehicle_speed
        else:
            distance_travelled = distance_from_gps

        # Filter rows where both 'vehicle_speed' and 'tps' are non-zero , i.e filter out idling data
        non_idle_df = log_df[log_df['vehicle_speed'] != 0]
        # Drop rows where 'vehicle_speed' is missing (NaN)
        non_idle_df = non_idle_df.dropna(subset=['vehicle_speed'])
        # Count the number of non-idle seconds
        non_idling_seconds = non_idle_df.shape[0]
        # Calculate the average vehicle speed during non-idle seconds
        non_idling_speed = non_idle_df['vehicle_speed'].mean()

        print(idling_bugs, "<<<<<<<<<<<<<")
        calculated_summary_data = CalculatedSummaryData(
            distance_travelled=distance_travelled,
            fuel_consumption=fuel_consumption,
            fuel_economy=fuel_economy,
            gps_data=gps_data,
            distance_from_gps=distance_from_gps,
            non_idling_seconds=non_idling_seconds,
            non_idling_speed=non_idling_speed,
            idling_locations=[] if idling_locations is None else idling_locations
        )
        return calculated_summary_data

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="32")
    def get_filtered_idle_spots(log_df, idle_seconds_threshold=180, gps_round_off=4):
        """
        Identify and filter idle spots from GPS log data.

        Args:
        log_df (pd.DataFrame): Input DataFrame with GPS log data.
        idle_seconds_threshold (int): Minimum duration (in seconds) to consider a spot as idle.
        gps_round_off (int): Number of decimal places to round GPS coordinates.

        Returns:
        list: List of dictionaries containing filtered idle spots.
        """

        # Select only necessary columns and filter for idle vehicles
        idle_df = log_df[log_df['vehicle_speed'] == 0][['lat', 'longi', 'Long Tracking', 'Lat Tracking']]

        # Remove rows with missing GPS data and ensure tracking is active
        idle_df = idle_df.dropna(subset=['lat', 'longi'])
        # idle_df = idle_df[(idle_df['Long Tracking'] & idle_df['Lat Tracking'])]

        # Round GPS coordinates
        idle_df['lat'] = idle_df['lat'].round(gps_round_off)
        idle_df['longi'] = idle_df['longi'].round(gps_round_off)

        # Group by location and count occurrences
        idle_spots_location_df = idle_df.groupby(['lat', 'longi']).size().reset_index(name='idle_time')

        # Filter spots that exceed the idle threshold
        filtered_idle_spots = idle_spots_location_df[idle_spots_location_df['idle_time'] > idle_seconds_threshold]

        return str(filtered_idle_spots.to_dict(orient='records'))

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="09")
    def distance_by_vehicle_speed(speed_column):
        speed_column = speed_column.fillna(0)
        y = speed_column.to_numpy()
        x = speed_column.index.to_numpy()
        a_u_c = np.trapz(y, x=x)
        distance = round(a_u_c / 3600, 2)
        return distance

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="10")
    def gps_distance(gps_data):
        df = gps_data[
            (gps_data['lat'] > 7) & (gps_data['lat'] < 35) & (gps_data['longi'] > 65) & (gps_data['longi'] < 98)]
        lat_lst = [x for x in df['lat']]
        lon_lst = [x for x in df['longi']]
        distance_lst = []
        for i in range(1, len(lat_lst)):
            try:
                step_distance = distance.distance((lat_lst[i], lon_lst[i]), (lat_lst[i - 1], lon_lst[i - 1])).km
                if step_distance < 0.05:
                    distance_lst.append(step_distance)
            except:
                pass
        total_distance = sum(distance_lst)

        return total_distance

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="09")
    def fuel_consumed(fuel_column):
        y = fuel_column.to_numpy()
        x = fuel_column.index.to_numpy()
        a_u_c = np.trapz(y, x=x)
        fc_data = round(a_u_c / 3600, 2)
        return fc_data

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="10")
    def start_stop_gps(gps_df, bugs={}):
        gps_data = {}

        tempLocData = gps_df[gps_df['lat'].notna()]
        tempLocData = tempLocData[tempLocData['longi'].notna()]
        for i in range(0, len(tempLocData)):
            if tempLocData['lat'].iloc[i] == 0 or tempLocData['longi'].iloc[i] == 0:
                continue
            else:
                gps_data['start_lat'] = tempLocData['lat'].iloc[i]
                gps_data['start_longi'] = tempLocData['longi'].iloc[i]
                break

        for i in range(len(tempLocData) - 1, -1, -1):
            if tempLocData['lat'].iloc[i] == 0 or tempLocData['longi'].iloc[i] == 0:
                continue
            else:
                gps_data['end_lat'] = tempLocData['lat'].iloc[i]
                gps_data['end_longi'] = tempLocData['longi'].iloc[i]
                break

        result, bug_local = get_location_from_lat_lon(gps_data['start_lat'], gps_data['start_longi'])
        if len(bug_local) > 0:
            bugs = combine_bugs(bugs, bug_local)
        if result is not None:
            start_city, start_state = result
        else:
            start_city, start_state = None, None
        gps_data['start_location'] = str(start_city) + ", " + str(start_state)

        result, bug_local = get_location_from_lat_lon(gps_data['end_lat'], gps_data['end_longi'])
        if len(bug_local) > 0:
            bugs = combine_bugs(bugs, bug_local)

        if result is not None:
            end_city, end_state = result
        else:
            end_city, end_state = None, None

        gps_data['end_location'] = str(end_city) + ", " + str(end_state)

        return gps_data

    @error_handler(library_code=lib_code_ver, function_code="11")
    def update_summary_data(self, summary_info: CalculatedSummaryData, file_ending: dict, file_num: int, offset: int,
                            summary_file: pd.DataFrame,
                            device_id: str,
                            bugs={}):

        gps_data = summary_info.gps_data
        summary_id = file_num + offset

        summary_file.set_index('id', drop=False, inplace=True)

        summary_file.loc[summary_id, 'health_flag'] = 0
        summary_file.loc[summary_id, 'corrected_fuel_consumption'] = 0
        summary_file.loc[summary_id, 'pp_flag'] = '0'
        summary_file.loc[summary_id, 'gps_distance'] = summary_info.distance_from_gps

        if summary_file[summary_file['device_id'] == device_id].shape[0] == 0:
            # If the summary file is empty, then data loss is zero
            summary_file.loc[summary_id, 'data_loss_flag'] = 0
            summary_file.loc[summary_id, 'data_loss_km'] = 0
        else:
            # Get the list of summary ids in the summary file for the given device id
            summary_id_lst = summary_file[summary_file['device_id'] == device_id].index.tolist()
            # Find the previous summary id to the given summary id
            previous_summary_id_lst = [i for i in summary_id_lst if i < summary_id]
            if len(previous_summary_id_lst) == 0:
                summary_file.loc[summary_id, 'data_loss_flag'] = 0
                summary_file.loc[summary_id, 'data_loss_km'] = 0
            else:
                previous_summary_id = max(previous_summary_id_lst)
                # Get the file number of the previous summary id
                nearest_file_num = summary_file.loc[previous_summary_id, 'file_num']
                # Get the end lat and longi of the previous summary id
                end_lat = summary_file.loc[previous_summary_id, 'end_lat']
                end_lon = summary_file.loc[previous_summary_id, 'end_lon']
                # Calculate the data loss
                if gps_data is None:
                    gps_data = {}
                    data_loss_result = None
                else:
                    data_loss_result, bug = self.data_loss(gps_data['start_lat'], gps_data['start_longi'],
                                                           end_lat,
                                                           end_lon)

                    combine_bugs(bugs, bug)

                if data_loss_result is None:
                    data_loss_flag, data_loss_km = None, None
                else:
                    data_loss_flag, data_loss_km = data_loss_result

                summary_file.loc[summary_id, 'data_loss_flag'] = data_loss_flag
                summary_file.loc[summary_id, 'data_loss_km'] = data_loss_km

            # # Raise bug if data loss flag is set
            if summary_file.loc[summary_id, 'data_loss_flag'] == 1:
                data_loss_bug = create_bug_instance(
                    module_code=lib_code_ver,
                    function_code="20",
                    error_code="01",
                    input_data={"file_num": file_num, "device_id": device_id},
                    message=f"Dat Loss in file {file_num} : Data loss {data_loss_km}"
                )
                combine_bugs(bugs, data_loss_bug)

        summary_file.loc[summary_id, 'id'] = summary_id
        summary_file.loc[summary_id, 'device_id'] = device_id
        summary_file.loc[summary_id, 'file_num'] = file_num
        summary_file.loc[summary_id, 'start_time'] = file_ending['Start RTC Time']
        # logging.info('Type of Start time of file %s is %s', file_num, type(file_ending['start_time']))
        summary_file.loc[summary_id, 'start_location'] = gps_data.get('start_location')
        summary_file.loc[summary_id, 'start_lat'] = gps_data.get('start_lat')
        summary_file.loc[summary_id, 'start_lon'] = gps_data.get('start_longi')
        summary_file.loc[summary_id, 'end_location'] = gps_data.get('end_location')
        summary_file.loc[summary_id, 'end_lat'] = gps_data.get('end_lat')
        summary_file.loc[summary_id, 'end_lon'] = gps_data.get('end_longi')
        summary_file.loc[summary_id, 'distance'] = summary_info.distance_travelled
        summary_file.loc[summary_id, 'fuel_consumed'] = summary_info.fuel_consumption
        summary_file.loc[summary_id, 'fuel_econ'] = summary_info.fuel_economy
        summary_file.loc[summary_id, 'file_end_type'] = str(file_ending['File Ending Type'])
        summary_file.loc[summary_id, 'dbc_current'] = file_ending['DBC Version #']
        summary_file.loc[summary_id, 'stm_current'] = str(file_ending['STM Version #'])
        summary_file.loc[summary_id, 'strat_current'] = str(file_ending['STRAT VERSION #'])
        summary_file.loc[summary_id, 'ign_on_time'] = file_ending['IGN on time']
        summary_file.loc[summary_id, 'avg_non_idle_speed'] = summary_info.non_idling_speed
        summary_file.loc[summary_id, 'non_idle_run_time'] = summary_info.non_idling_seconds
        summary_file.loc[summary_id, 'idling_locations'] = summary_info.idling_locations

        # Check the total line of the file to decide whether to set proce_flag as 1 or 0

        if file_ending['Total # of Lines'] <= 30:
            summary_file.loc[summary_id, 'run_time'] = file_ending['Total # of Lines']
            # Set proc_flag as 1 if the file is less than or equal to 30 lines
            summary_file.loc[summary_id, 'proc_flag'] = 1
        else:
            summary_file.loc[summary_id, 'run_time'] = file_ending['Total # of Lines'] - 30
            summary_file.loc[summary_id, 'proc_flag'] = 0

        ## Handling Corrupted Start date and Time
        if file_ending['Start Date'] is not None:
            summary_file.loc[summary_id, 'start_date'] = file_ending['Start Date']
        else:
            # Find the nearest id in the summary file whose start date is not null
            summary_id_lst = summary_file[summary_file['start_time'].notnull()].index.tolist()
            if len(summary_id_lst) == 0:
                summary_file.loc[summary_id, 'start_date'] = None
            else:
                run_time_seconds = file_ending['Total # of Lines']
                summary_id_lst = [sid for sid in summary_id_lst if sid < summary_id]
                nearest_summary_id = min(summary_id_lst, key=lambda x: abs(x - summary_id))

                nearest_start_date = summary_file.loc[nearest_summary_id, 'start_date']
                nearest_start_time = summary_file.loc[nearest_summary_id, 'start_time']

                date_time_string = f"{nearest_start_date} {nearest_start_time}"
                nearest_date_time = datetime.datetime.strptime(date_time_string, "%Y-%m-%d %H:%M:%S")

                current_date_time = nearest_date_time + datetime.timedelta(seconds=run_time_seconds)
                current_date = current_date_time.date()
                current_time = current_date_time.time()

                summary_file.loc[summary_id, 'start_date'] = current_date
                summary_file.loc[summary_id, 'start_time'] = current_time

    @staticmethod
    @error_handler(library_code=lib_code_ver, function_code="12")
    def data_loss(x2, y2, x1, y1):
        bug_local = {}
        coords_1 = (x1, y1)
        coords_2 = (x2, y2)
        distance = gp.distance.geodesic(coords_1, coords_2).km
        if distance > 0.5:
            flag = 1
        else:
            flag = 0
        return flag, distance

    @error_handler(library_code=lib_code_ver, function_code="13", class_logger="lp_logger")
    def update_last_processed_file_num_in_rds(self, vehicle_num: str, device_id: str, last_processed_file: str,
                                              last_processed_file_time: datetime.datetime):
        last_processed_file = int(last_processed_file.split('_')[1].split('.')[0])
        # Update the last_processed_file attribute
        self.session.execute(
            update(VehicleDeviceLogs)
            .where(VehicleDeviceLogs.vehicle_num == vehicle_num)
            .where(VehicleDeviceLogs.device_id == device_id)
            .values(last_processed_file=last_processed_file,
                    last_processed_file_time=last_processed_file_time)
        )

        self.session.execute(
            update(ActiveVehicle)
            .where(ActiveVehicle.vehicle_num == vehicle_num)
            .where(ActiveVehicle.device_id == device_id)
            .values(last_processed_file=str(last_processed_file),
                    last_processed_file_time=last_processed_file_time)
        )

        self.session.commit()
        print(
            f"Successfully updated last_processed_file to {last_processed_file} for vehicle_num={vehicle_num}, device_id={device_id}")
        self.lp_logger.info(
            f"Successfully updated last_processed_file to {last_processed_file} for vehicle_num={vehicle_num}, device_id={device_id}")


class VehicleLogProcessor(LogProcessorBase):
    # VEHICLE_SUMMARY_PTH = "vehicle_data/test/SUMMARY_vehicle_num.parquet"

    def __init__(self, logger_obj, run_type: str):
        super().__init__()
        self.lp_logger = logger_obj
        self.VEHICLE_MODEL_MAPPING, self.mapping_bug = get_vehicle_make_model()
        print(self.VEHICLE_MODEL_MAPPING)
        if self.mapping_bug:
            self.lp_logger.error(self.mapping_bug)
        self.device_processor = DeviceLogProcessor(
            logger_obj=self.lp_logger,
            vehicle_model_mapping={} if self.VEHICLE_MODEL_MAPPING is None else self.VEHICLE_MODEL_MAPPING,
            run_type=run_type
        )

    # def process_active_vehicles_logs(self, active_vehicles: pd.DataFrame):
    #
    #     # To do: make this multiprocess
    #     for v_num in active_vehicles.index.unique():
    #         print(f"======= Processing logs for vehicle :: {v_num} ==============")
    #         self.process_vehicle_logs(v_num=v_num)

    @error_handler(library_code=lib_code_ver, function_code="22", class_logger="lp_logger")
    def process_vehicle_logs(self, v_num: int, active_vehicles: pd.DataFrame, process_all_logs: bool = False,
                             process_manual_files: Tuple[str, List] = None) -> None:
        active_vehicles_df = active_vehicles.copy()

        if process_all_logs:
            print(f"Processing all logs for vehicle {v_num}")
            self.lp_logger.infof(f"#####  Processing all logs for vehicle {v_num}  #####\n")
            active_vehicles_df['last_processed_file'] = -1

        devices_pending_files = self._get_pending_files(v_num, active_vehicles_df)
        is_manual_run = False
        manual_device = None
        if process_manual_files:
            manual_device = process_manual_files[0]
            manual_pending_files = [f'l_{file_num:05d}.bin' for file_num in process_manual_files[1]]

            if not manual_device in devices_pending_files:
                print("please Provide correct device name in manual run....")

            else:
                devices_pending_files[manual_device]['pending_files'] = manual_pending_files
                is_manual_run = True

        print("====================  ====================")
        print(f"Pending files for {v_num} : {devices_pending_files}")
        print("====================  ====================")
        self.lp_logger.info("====================  ====================")
        self.lp_logger.info(f"Pending files for {v_num} : {devices_pending_files}")
        self.lp_logger.info("====================  ====================")
        for device_id in devices_pending_files.keys():
            print(f"========== Processing Vehicle {v_num} Device {device_id} ==========")
            self.lp_logger.info(f"========== Processing Vehicle {v_num} Device {device_id} ==========")
            if devices_pending_files[device_id]['pending_files']:
                if is_manual_run and device_id == manual_device:
                    result, bugs = self.device_processor.process_pending_device_logs(v_num=v_num, device_id=device_id,
                                                                                     device_pending_files=devices_pending_files,
                                                                                     is_manual_run=is_manual_run)
                else:
                    result, bugs = self.device_processor.process_pending_device_logs(v_num=v_num, device_id=device_id,
                                                                                     device_pending_files=devices_pending_files)

                if bugs:
                    bug_add_result, bug_add_issue = add_bug(serialize_bug_instance(bugs), raised_by=lib_code_ver,
                                                            vehicle_num=v_num, device_id=device_id)
                    if bug_add_issue:
                        self.lp_logger.error(f"Error Occured in add_bug() {bug_add_issue}")

        self.lp_logger.info(f"\n\n------ Log Processing completed for {v_num} ----------")

    def _get_pending_files(self, vehicle_num: str, active_vehicles: pd.DataFrame) -> dict:
        vehicle_devices_df = active_vehicles.loc[vehicle_num]
        if isinstance(vehicle_devices_df, pd.Series):
            vehicle_devices_df = vehicle_devices_df.to_frame().T
        device_pending_files_dict = {}
        for ind, device in vehicle_devices_df.iterrows():

            previous_devices = device['prev_devices']
            offset = 0
            if previous_devices:
                for prev_dev in previous_devices:
                    prev_device_info = vehicle_devices_df[vehicle_devices_df['device_id'] == prev_dev].iloc[0]
                    file_before_removal = prev_device_info['file_before_removal']

                    if file_before_removal == '':
                        print("========= Error =================")
                        print(
                            f"Field Engineer needs to update file_before_removal value for vehicle: {vehicle_num} Device : {prev_dev}")
                        raise f"Field Engineer needs to update file_before_removal value for vehicle: {vehicle_num} Device : {prev_dev}"
                    else:
                        offset += file_before_removal + 1

            last_processed_file = device['last_processed_file']
            last_log_file_s3 = device['last_log_file_s3']

            device_pending_files_dict[device['device_id']] = {}
            device_pending_files_dict[device['device_id']]['pending_files'] = self.calculate_pending_files(
                last_log_file_s3=last_log_file_s3,
                last_processed_file=last_processed_file
            )
            device_pending_files_dict[device['device_id']]['offset'] = offset

        return device_pending_files_dict

    @staticmethod
    def calculate_pending_files(last_log_file_s3: int, last_processed_file: int) -> List[str]:
        files_to_process = [f'l_{file_num:05d}.bin' for file_num in
                            range(last_processed_file + 1, last_log_file_s3 + 1)]

        return files_to_process


if __name__ == "__main__":
    # vehicle_log_processor = VehicleLogProcessor()
    # vehicle_log_processor.process_active_vehicles_logs()

    # Experiments:

    lp_logger = LoggerFactory(name="log_processing_LOGS").get_logger()

    dv_lp = DeviceLogProcessor(logger_obj=lp_logger, run_type="DEV", vehicle_model_mapping=get_vehicle_make_model()[0])

    device_logs_processing, bugs = dv_lp.process_pending_device_logs(
        v_num="TN02BU0893",
        device_id="2022_04_074",
        device_pending_files={
            "2022_04_074": {
                "pending_files": [f'l_{l:05d}.bin' for l in range(1, 2)],
                "offset": 0
            }
        }
    )
    #
    # device_logs_processing, bugs = dv_lp.process_pending_device_logs(
    #     v_num="TEST_RIG_2",
    #     device_id="2022_04_062",
    #     device_pending_files={
    #         "2022_04_062": {
    #             "pending_files": [f'l_{l:05d}.bin' for l in range(74)],
    #             "offset": 0
    #         }
    #     }
    # )

    print(device_logs_processing)

    ser_bug = serialize_bug_instance(bugs)
    print(ser_bug)
    # result, bugs = dv_lp.process_device_log_file(raw_data=raw_log_data, v_num="TEST")
    # print(result, bugs)
