from enum import Enum
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
class DecodeType(Enum):
    ASCII = 'ascii'
    DECIMAL = 'decimal'


file_ending_param_decode_type = {
    "File Ending Type": DecodeType.DECIMAL,
    "Start Date": DecodeType.ASCII,
    "Start RTC Time": DecodeType.ASCII,
    "DBC Version #": DecodeType.ASCII,
    "STRAT VERSION #": DecodeType.DECIMAL,
    "Total # of Lines": DecodeType.DECIMAL,
    "IGN on time": DecodeType.DECIMAL,
    "STM Version #": DecodeType.DECIMAL
}

file_ending_param_decode_type_2 = {
    "Date": DecodeType.ASCII,             # YYYYMMDD format
    "Current Image": DecodeType.ASCII,    # ASCII representation of the image parameter
    "c_can_cfg": DecodeType.DECIMAL,      # CAN configuration
    "c_imu_cfg": DecodeType.DECIMAL,      # IMU configuration
    "c_adc_cfg": DecodeType.DECIMAL,      # ADC configuration
    "c_anl_cfg": DecodeType.DECIMAL,      # Analog configuration
    "c_dig_cfg": DecodeType.DECIMAL,      # Digital configuration
    "c_exp_cfg": DecodeType.DECIMAL,      # Expansion configuration
    "c_strat": DecodeType.DECIMAL,        # Strategy configuration
    "Driver ID": DecodeType.DECIMAL       # Driver identification
}


class CalculatedSummaryData(BaseModel):
    distance_travelled: Optional[float] = Field(None, description="Total distance travelled")
    fuel_consumption: Optional[float] = Field(None, description="Total fuel consumed")
    fuel_economy: Optional[float] = Field(None, description="Fuel economy (distance/fuel)")
    gps_data: Optional[dict] = Field(None, description="GPS start and stop coordinates")
    distance_from_gps: Optional[float] = Field(None, description="Distance calculated from GPS")
    non_idling_seconds: Optional[int] = Field(None, description="Number of non-idling seconds")
    non_idling_speed: Optional[float] = Field(None, description="Average speed during non-idling periods")
    idling_locations: Optional[str] = Field(None, description="Idling locations with idling time")
