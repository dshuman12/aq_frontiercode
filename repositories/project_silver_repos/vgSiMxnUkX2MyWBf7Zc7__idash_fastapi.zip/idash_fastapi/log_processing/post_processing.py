import json
import os
import sys

sys.path.append(
    '../'
)

from hiper_utils.google_drive.google_drive import GoogleDriveClient
from Orchestrator.orchestrator import Orchestrator, ParseObsidianCanvas
from hiper_utils.Decoraters.exception_handler import error_handler, combine_bugs, serialize_bug_instance, \
    append_to_input_data
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.other_utils.bug_util import add_bug
from hiper_utils.other_utils.vehicles_util import get_summary_vehicle
import pandas as pd

lib_code = 'LP'
lib_ver = '01'

lib_code_ver = f"{lib_code}{lib_ver}"


class PostProcessing:
    pp_file_obsidian_flow_pth = "post_processing_<make_model>.canvas"
    key_file_pth = "google-key.json"

    def __init__(self, make_model: str, logger=None):
        self.google_drive_cli = GoogleDriveClient(json_key_file_name=self.key_file_pth)
        self.make_model = make_model
        self.logger = logger

        self.pp_file_canvas, self.canvas_download_bug = self.fetch_flow_from_obsidian()
        self.pp_orchestrator_json, self.parser_bug = None, None

        if self.pp_file_canvas is not None:
            parsed_canavas_obj = ParseObsidianCanvas(obsidian_canvas=self.pp_file_canvas)
            self.pp_orchestrator_json, self.parser_bug = parsed_canavas_obj.parsed_canvas, parsed_canavas_obj.parse_bug

    @error_handler(library_code=lib_code_ver, function_code="24")
    def fetch_flow_from_obsidian(self):
        flow_name = self.pp_file_obsidian_flow_pth.replace('<make_model>', self.make_model)

        file_id = self.google_drive_cli.find_file_id_by_name(
            file_name=flow_name)

        file_id = file_id[0]
        print(file_id)
        if file_id is not None:
            print(self.google_drive_cli.download_file(file_id=file_id, file_name=flow_name))

            with open(flow_name, "r") as file:
                canvas_data = file.read()
                canvas_json = json.loads(canvas_data)
                try:
                    os.remove(flow_name)
                except:
                    pass
                return canvas_json


        else:
            print(f"{flow_name} not found in Obsidian...")
            raise ValueError(f"{flow_name} not found in Obsidian...")

    @error_handler(library_code=lib_code_ver, function_code="23")
    def run_post_process_file(self, log_df: pd.DataFrame, veh_num, device_id, summary_id, summary_df, file_num,
                              bugs={}) -> bool:

        if self.pp_file_canvas is None:
            combine_bugs(bugs, self.canvas_download_bug)
            return None

        if self.pp_orchestrator_json is None:
            combine_bugs(bugs, self.parser_bug)
            return None

        meta_data = {
            'global_inputs': {
                '0_0': log_df,
                '0_1': self.make_model,
                '0_2': summary_id,
                '0_3': veh_num,
                '0_4': summary_df
            }
        }

        orchestrator = Orchestrator(meta_data=meta_data, logger=self.logger)

        flow_output_dict, orchestrator_execution_bug = orchestrator.run_orchestrator(
            flow_dict=self.pp_orchestrator_json)

        if orchestrator_execution_bug:
            combine_bugs(bugs, orchestrator_execution_bug)
            return None

        bugs_in_post_process = {}
        for bock_id, func_exec in flow_output_dict.items():
            func_bug = func_exec['bugs']
            if func_bug:
                append_to_input_data(bug_instances=func_bug, additional_data={
                    "device_id": device_id,
                    "file_num": file_num,
                    "vehicle_number": veh_num
                })

            combine_bugs(bugs_in_post_process, func_bug)

        # if bugs_in_post_process:
        #     # print(bugs_in_post_process)
        #     bug_add_result, bug_add_issue = add_bug(serialize_bug_instance(bugs_in_post_process),
        #                                             raised_by=lib_code_ver,
        #                                             vehicle_num=veh_num, device_id=device_id)
        #     if bug_add_issue:
        #         self.logger.error(f"Error Occured in add_bug() {bug_add_issue}")
        #         combine_bugs(bugs, bug_add_issue)

        post_processed_summary = orchestrator.meta_data['global_inputs']['0_4']

        post_processed_summary.loc[summary_id, 'pp_file'] = '01'  # To do : fetch from flow

        return True


if __name__ == '__main__':

    veh_num = "TN58BC8362"
    device = "2022_04_067"
    make_model = "0116"
    pp_logger = LoggerFactory(name="PP_LOGS").get_logger()

    from hiper_utils.aws.s3.s3 import S3Bucket

    hiperft_bucket = S3Bucket(
        bucket_name="hiperftp"
    )

    post_processor = PostProcessing(
        make_model=make_model,
        logger=pp_logger

    )

    print(post_processor.pp_file_canvas, post_processor.canvas_download_bug)
    print(post_processor.pp_orchestrator_json, post_processor.parser_bug)
    p = 'vehicle_data/<veh_num>/SUMMARY_<veh_num>.parquet'
    p = p.replace("<veh_num>", veh_num)

    summary_df, summ_bug = get_summary_vehicle(p)
    summary_df.set_index('id', drop=False, inplace=True)

    print(summary_df.columns)

    for file_num in range(1, 4):

        proceesed_log_pth = f'vehicle_data/{veh_num}/log_data/{device}/{file_num}.parquet'
        print(proceesed_log_pth)
        processed_df, bug = hiperft_bucket.download_parquet(proceesed_log_pth)

        if processed_df is not None:
            summ_id = summary_df[(summary_df['file_num'] == file_num) & (summary_df['device_id'] == device)]['id']

            print(summ_id, "<><>")
            print(post_processor.run_post_process_file(
                log_df=processed_df,
                veh_num=veh_num,
                device_id=device,
                summary_id=summ_id,
                summary_df=summary_df,
                file_num=file_num
            ))

        # hiperft_bucket.upload_dataframe_to_s3_parquet(dataframe=processed_df,s3_key=proceesed_log_pth)
        # processed_df.to_csv(f"{file_num}.csv")

    # summary_df.reset_index(drop=True, inplace=True)
    # hiperft_bucket.upload_dataframe_to_s3_parquet(dataframe=summary_df,s3_key=p)
    # summary_df.to_csv(f"{veh_num}summ.csv")
