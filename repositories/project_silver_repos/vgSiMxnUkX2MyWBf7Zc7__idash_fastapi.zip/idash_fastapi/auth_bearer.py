from fastapi import Request, HTTPException, Response
import time
import jwt
from fastapi.security import HTTPBearer
from utils.users_utils import JWT_ALGORITHM, JWT_SECRET
from datetime import datetime, timedelta

from fastapi import Request, HTTPException
from fastapi.security import HTTPBearer
import jwt
import time


class JWTBearer(HTTPBearer):
    async def __call__(self, request: Request):
        
        print("entered JWTBearer")
        
        token = request.cookies.get('access_token')
        if not token:
            raise HTTPException(status_code=403, detail="No token found in cookies.")
        if not self.verify_jwt(token):
            raise HTTPException(status_code=403, detail="Invalid or expired token.")
        return token

    def verify_jwt(self, token: str) -> bool:
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            return payload["expires"] >= time.time()
        except jwt.ExpiredSignatureError:
            return False
        except jwt.InvalidTokenError:
            return False
