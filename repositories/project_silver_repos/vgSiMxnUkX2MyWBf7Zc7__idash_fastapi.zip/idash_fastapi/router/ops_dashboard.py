import sys
from datetime import datetime, timedelta
from typing import Any, Dict, Union
from typing_extensions import List, Optional
import json
import random
import io
import base64
import subprocess
import struct

sys.path.append("../")

from fastapi import APIRouter, HTTPException, Query, Body, status, Response, Depends, UploadFile, File
from fastapi.responses import StreamingResponse
from fastapi_cache.decorator import cache
from fastapi_cache import FastAPICache
import pandas as pd
import numpy as np

from utils.ops_dash_util import VehicleStatus, TripClassification, StratTable, DriverClassification, DeviceRegistration, \
    DeviceConfigFiles, RawLogFiles, RawPing, SysLog, DeviceSoftwareVersioning, EmulatorCycle, TestRequirementUtil, \
    RunTestUtil, DSMManagement
from utils.trip_classfication_util import TripClassificationUtil
from schema.ops_dash_schema import VehicleSummaryRequest, TripRecord, HWUno2Input, SoftwareTypes, SoftwareVersionRecord, \
    TestRequirement
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path
from hiper_utils.Decoraters.exception_handler import serialize_bug_instance
from auth_bearer import JWTBearer
from hiper_utils.other_utils.redis_util import RedisUtil
from idash_fastapi.log_processing.vehicle_log_process_v2 import DeviceLogProcessor, LoggerFactory
from hiper_utils.other_utils.vehicles_util import VehicleJSON, get_fleet_name_for_vehicle
from cdash_fastapi.utils.trips_utils import TripManagement
from storage_settings import prod_rds_instance
from subprocess import PIPE
import asyncio

router = APIRouter()

redis_util = RedisUtil(host='localhost', port=6379, db=0)


@router.get("/fetch_vehicle_status", dependencies=[Depends(JWTBearer())])
async def fetch_vehicle_status():
    print("Fetching Vehicle Status ::::")

    # Run the blocking function asynchronously in a separate thread
    vehicle_status_obj = VehicleStatus()
    vehicle_status = await asyncio.to_thread(vehicle_status_obj.get_vehicle_status)

    print("Bug in Vehicle Status :: ", vehicle_status[1])
    return vehicle_status[0]


@router.get("/fetch_vehicles_list", dependencies=[Depends(JWTBearer())])
@cache(namespace="vehicle_list", expire=10800)  # Cache for 3 hour
async def fetch_vehicles_list():
    vehicle_list, bug = TripClassification.get_vehicle_list()
    print(bug)
    if vehicle_list is None:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch vehicle list")
    else:
        return vehicle_list


@router.get("/fetch_trip_table", dependencies=[Depends(JWTBearer())])
async def fetch_trip_table(vehicle_num: str = Query(...)):
    print(vehicle_num)
    trips_table, bug = TripClassification.get_trip_data(vehicle_num=vehicle_num)
    print(bug)
    return trips_table


@router.get("/fetch_improvement_table", dependencies=[Depends(JWTBearer())])
async def fetch_improvement_table(response: Response):
    print("Fetching Improvement table .....................")

    # Check if the improvement table exists in cache asynchronously
    cache_table = await asyncio.to_thread(redis_util.get_key, 'improvement_table')

    if cache_table:
        # Cache hit
        cache_table_decoded = cache_table.decode('utf-8')
        imp_table = json.loads(cache_table_decoded)
        return imp_table

    else:
        # Cache miss, fetching from optimization table
        imp_table, bug = await asyncio.to_thread(VehicleStatus.get_optimization_table)

        if imp_table is None:
            print(bug)
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                detail="Failed to fetch improvement table")

        # Cache the new improvement table asynchronously
        cache_table = json.dumps(imp_table)
        await asyncio.to_thread(redis_util.set_key, 'improvement_table', cache_table, ex=10800)

        return imp_table


@router.delete("/clear_cache", dependencies=[Depends(JWTBearer())])
async def clear_cache(namespace: str):
    print(f"Clearing cache for namespace: {namespace}")
    redis_util.delete_key(namespace)
    print(f"Cache cleared for namespace: {namespace}")
    return {"message": f"Cache cleared for namespace: {namespace}"}


@router.post("/add_trip_record", dependencies=[Depends(JWTBearer())])
async def add_trip_record(
        vehicle_num: str = Body(),
        trip_records: List[TripRecord] = Body(..., description="List of existing trip records"),
        new_trip_record: TripRecord = Body(..., description="New trip record to add")
):
    trips_df = pd.DataFrame([trip.dict() for trip in trip_records])

    trips_df, add_trip_bug = TripClassification.add_trip_to_trip_df(trips_df, new_trip_record, vehicle_num)
    print("============")
    print(add_trip_bug)
    if trips_df is not None:
        return trips_df.to_dict(orient='records')

    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to add trip record")


@router.post("/update_trip_table", dependencies=[Depends(JWTBearer())])
async def update_trip_record(
        vehicle_num: str = Body(),
        trip_records: List[TripRecord] = Body(..., description="List of existing trip records")
):
    trips_df = pd.DataFrame([trip.dict() for trip in trip_records])

    trips_df, add_trip_bug = TripClassification.update_trip_df(
        trips_df=trips_df,
        vehicle_num=vehicle_num
    )

    if trips_df is not None:
        return trips_df.to_dict(orient='records')

    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to update trip records")


@router.post("/update_summary_table", dependencies=[Depends(JWTBearer())])
async def update_summary_table(
        vehicle_num: str = Body(),
        summ_ids_to_update: List[int] = Body(),
        column_value: int = Body(),
):
    summary_update_status, summary_update_bug = TripClassification.update_vehicle_summary_df(vehicle_num=vehicle_num,
                                                                                             summ_ids_to_update=summ_ids_to_update,
                                                                                             column_value=column_value)
    print(f"summary table update bug : {summary_update_bug}")
    if summary_update_status:
        return summary_update_status

    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to update summary table")


@router.post("/delete_trip_records", dependencies=[Depends(JWTBearer())])
async def delete_trip_record(
        vehicle_num: str = Body(),
        trip_records: List[TripRecord] = Body(..., description="List of existing trip records"),
        trip_ids_to_delete: List[int] = Body(..., description="Trip ids ro delete")
):
    trips_df = pd.DataFrame([trip.dict() for trip in trip_records])

    trips_df, add_trip_bug = TripClassification.delete_trips_from_trip_df(
        trips_df=trips_df,
        trip_ids_to_delete=trip_ids_to_delete,
        vehicle_num=vehicle_num
    )

    if trips_df is not None:
        return trips_df.to_dict(orient='records')

    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to delete trip records")


@router.post("/fetch_vehicle_summary", dependencies=[Depends(JWTBearer())])
async def get_vehicle_summary(filter_data: VehicleSummaryRequest):
    summary_data, bug = TripClassification.get_vehicle_summary(filter_data.vehicle_num, filter_data.start_date,
                                                               filter_data.end_date)

    print(bug)

    return summary_data


@router.get("/fetch_start_table", dependencies=[Depends(JWTBearer())])
async def fetch_start_table():
    print("Fetching start table ::::")
    start_table_df, start_table_bug = ResourceUtil().get_start_table()
    return start_table_df.to_dict(orient='records')


@router.post("/update_start_values", dependencies=[Depends(JWTBearer())])
async def update_start_value(
        vehicle_num: str = Body(...),
        strat: int = Body(...),
        log_file: int = Body(...),
        prev_strat: int = Body(...)
):
    update_start_status, update_start_bug = StratTable().update_start_value(
        vehicle_num, log_file, strat, prev_strat
    )
    print(update_start_status, update_start_bug)
    return update_start_status


@router.get("/fetch_fleet_and_vehicle_id")
async def fetch_fleet_names():
    print("Fetching fleet table ::::")

    fleet_data, fleet_bug = DriverClassification.get_fleet_and_vehicle()

    return fleet_data


@router.get("/fetch_driver_names")
async def fetch_driver_names():
    print("Fetching Driver Table ::::")

    driver_data, driver_bug = DriverClassification.get_driver_ids()
    if driver_data:
        return driver_data
    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to fetch driver names")


@router.post("/update_driverid_in_summary")
async def update_summary_table(
        vehicle_num: str = Body(),
        summ_ids_to_update: List[int] = Body(),
        column_value: int = Body(),
):
    column_value = str(column_value).zfill(3)
    summary_update_status, summary_update_bug = TripClassification.update_vehicle_summary_df(vehicle_num=vehicle_num,
                                                                                             summ_ids_to_update=summ_ids_to_update,
                                                                                             column_value=column_value,
                                                                                             column_name="driver_id")
    print(f"summary table update bug : {summary_update_bug}")
    if summary_update_status:
        return summary_update_status

    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to update summary table")


@router.post("/upload_images")
async def upload_images(driver_images: List[UploadFile] = File(...), fleet_name: str = Body(...),
                        driver_id: int = Body(...)):
    print("Upoading Driver images........")
    print(len(driver_images))
    driver_image_upload_status = await  DriverClassification.upload_driver_images(
        driver_images=driver_images,
        fleet_name=fleet_name,
        driver_id=driver_id)

    if not driver_image_upload_status:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to upload images")


@router.post("/fetch_image_log_file_mapping")
async def fetch_image_log_file_mapping(vehicle_num: str = Body(...), image_file_names_list: List[str] = Body(...)):
    image_log_mapping, mapping_bug = DriverClassification.map_images_to_log_file(vehicle_num=vehicle_num,
                                                                                 image_file_name=image_file_names_list)
    print(mapping_bug)
    if mapping_bug:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to map images and log file")

    return image_log_mapping


@router.post("/add_driver")
async def add_driver(
        vehicle_num: str = Body(...),
        first_name: str = Body(...),
        last_name: str = Body(...),
        contact: Optional[int] = Body(None),
        fleet_id: int = Body(...)
):
    driver_insert_status, driver_insert_bug = DriverClassification.insert_driver(
        vehicle_num=vehicle_num,
        first_name=first_name,
        last_name=last_name,
        fleet_id=fleet_id,
        contact=contact)

    print(driver_insert_bug, ">>>>>>>>>>>>")
    if driver_insert_bug:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to add driver")


@router.get("/fetch_summary_ids")
async def fetch_summary_ids(vehicle_num: str = Query(...)):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    start_date_str = start_date.strftime("%Y-%m-%d")
    end_date_str = end_date.strftime("%Y-%m-%d")

    summary_data, bug = TripClassification.get_vehicle_summary(vehicle_num, start_date_str,
                                                               end_date_str)

    print(bug)
    if summary_data is not None:
        summary_id_drop_down = {
            "id": [],
            "file_num": [],
            "start_date_time": []
        }

        for summ_reocrd in summary_data:
            combined_datetime_str = f"{summ_reocrd['start_date'].split('T')[0]}T{summ_reocrd['start_time']}"
            start_datetime = datetime.fromisoformat(combined_datetime_str)

            summary_id_drop_down['id'].append(summ_reocrd['id'])
            summary_id_drop_down['file_num'].append(summ_reocrd['file_num'])
            summary_id_drop_down['start_date_time'].append(start_datetime)

        return summary_id_drop_down


## Add Hardware


@router.post("/add_hardware", dependencies=[Depends(JWTBearer())])
async def add_hardware(data: HWUno2Input):
    hw_insert_status, hw_insert_bug = DeviceRegistration.insert_hardware(
        data=data
    )

    if not hw_insert_status:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add hardware entry: {hw_insert_bug}"
        )
    return hw_insert_status


@router.get("/fetch_hw_serial", dependencies=[Depends(JWTBearer())])
async def fetch_hw_serial() -> List[str]:
    print("Fetching Hardware Serial Number...")

    unused_hw_serial, query_bug = DeviceRegistration.get_hardware_serial_number()
    if unused_hw_serial is not None:
        return unused_hw_serial
    else:
        print(query_bug)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to unused_hw_serial")


@router.get("/fetch_active_device_ids")
async def fetch_device_ids() -> List[str]:
    print("Fetching Active Device ids")

    active_Device_ids, query_bug = DeviceRegistration.fetch_device_ids()
    if active_Device_ids is not None:
        return active_Device_ids
    else:
        print(query_bug)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to unused_hw_serial")


@router.get("/download_device_bin_files", dependencies=[Depends(JWTBearer())])
async def download_config(make_model: str = Query(...)):
    zip_buffer, bug = DeviceConfigFiles.download_device_config_files(make_model)

    if zip_buffer is None:
        return Response(status_code=404, content="File not found")

    return StreamingResponse(zip_buffer, media_type="application/zip", headers={
        "Content-Disposition": f"attachment; filename={make_model}_config_files.zip"
    })


@router.get("/fetch_vehicles_list_new", dependencies=[Depends(JWTBearer())])
async def fetch_vehicles_list():
    vehicle_list, bug = TripClassification.get_vehicle_list_new()
    print(bug)
    if vehicle_list is None:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to fetch vehicle list")
    else:
        return vehicle_list


@router.get("/fetch_hw_and_device_info", dependencies=[Depends(JWTBearer())])
async def fetch_vehicles_list():
    registered_hw_and_devices, bug = DeviceRegistration.get_registered_hw_and_devices()
    print(bug)
    if registered_hw_and_devices is None:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to fetch Registered Hardware and Device info")
    else:
        return registered_hw_and_devices


@router.post("/upload_raw_log_files")
async def upload_raw_log_files(
        raw_log_files: List[UploadFile] = File(...),
        device_id: str = Body(...)
):
    print("Uploading Raw Log files........")
    print(len(raw_log_files))

    # Perform file upload task (this is blocking, so we await it)
    upload_raw_log_status = await RawLogFiles.upload_raw_log_file(raw_log_files=raw_log_files, device_id=device_id)

    if not upload_raw_log_status:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to upload raw log files")

    # Send the response first to the client
    response = {"message": "Raw log files uploaded successfully. Processing started in the background."}

    # Now start the subprocess in the background (without blocking)
    asyncio.create_task(run_log_processing())

    return response


async def run_log_processing():
    try:
        # Run the log processing commands asynchronously
        process = await asyncio.create_subprocess_shell(
            "pwd && ls -l && cd .. && pwd && ls -l && cd log_processing_v2/ && pwd && ls -l && sudo bash run_log_processing_cron.sh",
            stdout=PIPE,
            stderr=PIPE
        )

        # Await the process to complete and capture output
        stdout, stderr = await process.communicate()

        # Check the result and handle accordingly
        if process.returncode != 0:
            print(f"Failed to execute commands: {stderr.decode()}")
        else:
            print("============== Script executed successfully ==============")
            print(stdout.decode())

    except Exception as e:
        print(f"Error executing the command: {str(e)}")


@router.get("/fetch_vehicle_device_mapping", dependencies=[Depends(JWTBearer())])
async def fetch_vehicle_device_mapping():
    registered_hw_and_devices, bug = RawPing.get_vehicle_device_mapping()
    print(bug)
    if registered_hw_and_devices is None:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to fetch Registered Hardware and Device info")
    else:
        return registered_hw_and_devices


@router.get("/fetch_syslog", dependencies=[Depends(JWTBearer())])
async def fetch_vehicle_status(device_id: str, start_datetime: str, end_datetime: str):
    print("Fetching Sys Log...")

    syslog_fetcher = SysLog(device_id=device_id)
    sys_logs = syslog_fetcher.fetch_syslogs(start_datetime=start_datetime, end_datetime=end_datetime)

    return sys_logs


@router.get("/fetch_software_types", dependencies=[Depends(JWTBearer())])
async def fetch_software_types():
    return [x.value for x in SoftwareTypes]


@router.post("/insert_software_type", dependencies=[Depends(JWTBearer())])
async def insert_software_type(software_record: SoftwareVersionRecord):
    insert_software_version, insertion_bug = DeviceSoftwareVersioning().insert_software_versio_record(
        software_version_record=software_record
    )

    print(insertion_bug)
    if insertion_bug:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to insert software version record")


@router.get("/fetch_software_versioning_table", dependencies=[Depends(JWTBearer())])
async def fetch_software_versioning_table():
    software_versioning_table, bug = DeviceSoftwareVersioning().fetch_software_versioning_table()

    if not bug:
        return software_versioning_table
    else:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Failed to fetch software version tables")


@router.post("/create_emulator_cycle")
async def create_emulator_cycle(data: List[List[int]], emulator_cycle_name: str, added_by: int):
    test_process = EmulatorCycle(scenario_data=data, emulator_cycle_name=emulator_cycle_name, added_by=added_by)
    test_process_bin_file = test_process.create_emulator_cycle()

    return StreamingResponse(
        test_process_bin_file,
        media_type="application/octet-stream",
        headers={"Content-Disposition": 'attachment; filename="scenario.bin"'}
    )


@router.get("/fetch_emulator_cycles", dependencies=[Depends(JWTBearer())])
async def get_test_process_list():
    ec_metadata_df, download_bug = EmulatorCycle.get_emulator_cycles_csv()

    if not download_bug:
        return ec_metadata_df.to_dict(orient='list')
    else:
        return []


@router.get("/get_available_config_version", dependencies=[Depends(JWTBearer())])
async def get_available_config_version():
    test_process_list = TestRequirementUtil.get_available_config_version()
    return test_process_list


@router.post("/insert_test_requirement")
async def insert_test_requirement(test_requirement: TestRequirement):
    insert_test_req_result, insertion_bug = TestRequirementUtil().insert_production_test_requirement(
        test_requirement=test_requirement)

    if not insert_test_req_result:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Failed to insert test requirement  {str(insertion_bug)}")


@router.get("/get_available_test_rig")
async def get_available_test_rigs():
    rigs, bug = RunTestUtil().get_available_test_rigs()
    if bug:
        raise HTTPException(status_code=500, detail=f"Failed to fetch available test rigs: {bug}")
    return rigs


@router.get("/get_available_test_request_tickets")
async def get_available_test_request_tickets():
    available_test_requests, bug = RunTestUtil().get_test_requests()
    if bug:
        raise HTTPException(status_code=500, detail=f"Failed to fetch available test rigs: {bug}")
    return available_test_requests


@router.get("/get_test_case/{test_request_id}")
async def get_test_case(test_request_id: int):
    test_cases, bug = RunTestUtil.get_test_case(test_request_id=test_request_id)
    if bug:
        raise HTTPException(status_code=500, detail=f"Failed to fetch test case: {bug}")
    return test_cases


@router.post("/register_test_rig_with_test_case")
async def register_test_rig_with_test_case(
    test_rig: str,
    test_request_id: int,
    testcase: int
):
    """
    API to register a test rig with test case and activate the test rig in vehicle_registration.
    """
    register_test_rig_status , register_test_rig_bug =  RunTestUtil.register_test_rig_with_test_case(
        test_rig=test_rig,
        test_request_id=test_request_id,
        testcase=testcase,
    )

    if register_test_rig_bug:
        raise HTTPException(status_code=500, detail=f"Failed to register test rig with test case: {register_test_rig_bug}")
    return  register_test_rig_bug





@router.post("/process_log_file")
async def process_log_file(log_bin_file: UploadFile = File(...), make_model: str = Body(...)):
    print("Uploading log file")

    # Access the file name
    file_name = log_bin_file.filename
    file_name = file_name.split("(")[0].strip() + ".bin"
    print(f"File name: {file_name}")

    # Access the binary content of the uploaded file
    log_bin_file = await log_bin_file.read()

    lp_logger = LoggerFactory(name="log_processing_LOGS").get_logger()

    dv_lp = DeviceLogProcessor(logger_obj=lp_logger, run_type="DEV", vehicle_model_mapping={"TN02BU0893": "0113"})

    device_logs_processing, bugs = dv_lp.process_pending_device_logs(
        v_num="TN02BU0893",
        device_id="2022_04_074",
        pending_file=file_name,
        raw_log_file_data=log_bin_file,
        make_model=make_model
    )

    if device_logs_processing is not None:

        device_logs_processing, checksum_matches, single_row_info = device_logs_processing  # Processed DF and Checksum matche

        single_row_size, tracking_param_length, param_names, empty_bytes_to_add = single_row_info

        tracking_param_df = pd.DataFrame()

        processed_df = device_logs_processing.fillna('')

        tracking_param_df['time'] = pd.to_timedelta(processed_df.index, unit='s')
        tracking_param_df['time'] = tracking_param_df['time'].apply(lambda x: str(timedelta(seconds=x.seconds)))

        number_of_tracking_param = len(str(processed_df['tracking_param'].iloc[0]))
        processed_df['tracking_param'] = processed_df['tracking_param'].astype(str)

        for nth_tracking_param in range(number_of_tracking_param):
            tracking_param_df[str(nth_tracking_param + 1)] = processed_df['tracking_param'].apply(
                lambda tracking_params: tracking_params[nth_tracking_param])

        available_tracking_params = list(tracking_param_df.columns)
        available_tracking_params.remove('time')

        tracking_param_analytics = tracking_param_df.to_dict(orient='list')
        tracking_param_analytics['file'] = file_name
        tracking_param_analytics['params'] = available_tracking_params

        # Convert the processed DataFrame to CSV and encode as base64
        csv_buffer = io.StringIO()
        processed_df.to_csv(csv_buffer, index=False, escapechar='\\')
        csv_buffer.seek(0)
        csv_base64 = base64.b64encode(csv_buffer.getvalue().encode()).decode()

        print(make_model, "<<<<<<<<<<<<<<<<<")
        # Return JSON with CSV data included as base64
        return {
            "tracking_param_analytics": tracking_param_analytics,
            "csv_file_base64": csv_base64,  # Base64 encoded CSV content
            "csv_filename": f"{file_name}_processed.csv",
            "bugs": serialize_bug_instance(bugs),
            "Checksum": checksum_matches,
            "param_names": param_names[::-1],
            "debug info": {
                "Single Row Size": int(single_row_size),
                "Tracking Param Length": int(tracking_param_length)
            }
        }

    else:
        return bugs


@router.get("/fetch_dtc_data", dependencies=[Depends(JWTBearer())])
async def fetch_dtc_data():
    dtc_data, bug = DSMManagement.get_dtc_data()
    print(bug)
    return dtc_data


@router.post("/update_dtc_data", dependencies=[Depends(JWTBearer())])
async def update_dtc_data(device_id: str, dtc_clear: int):
    update_status, bug = DSMManagement.update_dtc_data(device_id=device_id, dtc_clear=dtc_clear)
    print(bug)
    return update_status


@router.get("/fetch_trips", dependencies=[Depends(JWTBearer())])
async def fetch_trips(vehicle_num: str = Query(...), start_date: str = Query(...), end_date: str = Query(...)):
    trip_manager = TripManagement(db_instance=prod_rds_instance, vehicle_id=vehicle_num)
    trips, bugs = trip_manager.get_trip_records(start_date=start_date, end_date=end_date)
    print(bugs)
    if trips is not None:
        return trips.to_dict(orient='records')


@router.get("/fetch_benchmarks", dependencies=[Depends(JWTBearer())])
async def fetch_benchmarks(vehicle_num: str = Query(...)):
    vehicle_fleet_mapping = redis_util.get_key('vehicle_fleet_mapping')
    
    if vehicle_fleet_mapping:
        # Cache hit - decode and parse mapping
        mapping = json.loads(vehicle_fleet_mapping.decode('utf-8'))
        if vehicle_num in mapping:
            fleet_name = mapping[vehicle_num]
        else:
            # Vehicle not in cache, fetch from DB and update cache
            fleet_name, bug = get_fleet_name_for_vehicle(vehicle_num=vehicle_num)
            if fleet_name:
                mapping[vehicle_num] = fleet_name
                redis_util.set_key('vehicle_fleet_mapping', json.dumps(mapping))
    else:
        # Cache miss - create new mapping
        fleet_name, bug = get_fleet_name_for_vehicle(vehicle_num=vehicle_num)
        if fleet_name:
            mapping = {vehicle_num: fleet_name}
            redis_util.set_key('vehicle_fleet_mapping', json.dumps(mapping))

    vehicle_json = VehicleJSON(vehicle_num=vehicle_num, fleet_name=fleet_name)
    return vehicle_json.get_benchmark_category()




@router.post("/update_benchmark", dependencies=[Depends(JWTBearer())])
async def update_benchmark(
    vehicle_num: str = Body(...),
    trip_id: int = Body(...),
    category: int = Body(...)
):
    trip_manager = TripManagement(db_instance=prod_rds_instance, vehicle_id=vehicle_num)
    update_status = trip_manager.update_benchmark_category(trip_id=trip_id, category=category)
    
    if update_status:
        return {"message": "Benchmark category updated successfully"}
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update benchmark category"
        )
    

@router.post("/edit_trip", dependencies=[Depends(JWTBearer())])
async def edit_trip(
    vehicle_num: str = Body(...),
    trips_info: List[Dict] = Body(...),
    trip_start_event_id: int = Body(...),
    trip_end_event_id: int = Body(...)
):
    trip_manager = TripManagement(db_instance=prod_rds_instance, vehicle_id=vehicle_num)
    edit_status = trip_manager.edit_trip(
        trips_info=trips_info,
        trip_start_event_id=trip_start_event_id,
        trip_end_event_id=trip_end_event_id
    )
    
    if edit_status:
        return {"message": "Trip edited successfully"}
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to edit trip"
        )


@router.post("/update_trip_rds_column", dependencies=[Depends(JWTBearer())])
async def update_trip_rds_column(
    vehicle_num: str = Body(...),
    trip_id: int = Body(...),
    column_values: Dict[str, Any] = Body(...)
):
    trip_manager = TripManagement(db_instance=prod_rds_instance, vehicle_id=vehicle_num)
    update_status = trip_manager.update_column_values(id=trip_id, column_values=column_values)

    if update_status:
        return {"message": "Column updated successfully"}
    else:
        return {"message": "Failed to update column"}




@router.get("/get_trip_metrics", dependencies=[Depends(JWTBearer())])
async def get_trip_metrics(
    vehicle_num: str = Query(...),
    trip_start_time: str = Query(...),
    start_file_number: int = Query(...),
    end_file_number: Optional[Union[int, str]] = Query(None)
):
    
    print("========================")
    print(start_file_number)
    print(end_file_number)
    print("========================")
    print(type(start_file_number))
    print(type(end_file_number))
    vehicle_fleet_mapping = redis_util.get_key('vehicle_fleet_mapping')
    
    if vehicle_fleet_mapping:
        # Cache hit - decode and parse mapping
        mapping = json.loads(vehicle_fleet_mapping.decode('utf-8'))
        if vehicle_num in mapping:
            fleet_name = mapping[vehicle_num]
        else:
            # Vehicle not in cache, fetch from DB and update cache
            fleet_name, bug = get_fleet_name_for_vehicle(vehicle_num=vehicle_num)
            if fleet_name:
                mapping[vehicle_num] = fleet_name
                redis_util.set_key('vehicle_fleet_mapping', json.dumps(mapping))
    else:
        # Cache miss - create new mapping
        fleet_name, bug = get_fleet_name_for_vehicle(vehicle_num=vehicle_num)
        if fleet_name:
            mapping = {vehicle_num: fleet_name}
            redis_util.set_key('vehicle_fleet_mapping', json.dumps(mapping))

    # If end_file_number is None, use start_file_number as the end_file_number
    if end_file_number is None or end_file_number == "None":
        end_file_number = start_file_number

    trip_classification_util = TripClassificationUtil(vehicle_num, fleet_name)
    trip_metrics = trip_classification_util.get_trip_metrics_from_log_file(trip_start_time, start_file_number, int(end_file_number))
    return trip_metrics





