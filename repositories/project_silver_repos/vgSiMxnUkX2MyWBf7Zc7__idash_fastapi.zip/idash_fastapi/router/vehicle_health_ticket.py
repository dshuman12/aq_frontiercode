# Import inbuilt libraries
import io

# Import third party libraries
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile,status as http_status,Form,Response
from fastapi.responses import JSONResponse
from datetime import datetime
from typing import Optional,List




# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for vehicle health tickets
lib_code_VHT = "47"
lib_ver_VHT = "00"

lib_code_ver_VHT = f"{lib_code_VHT}{lib_ver_VHT}"



# Include custom libraries
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.data_models.rds_data_models.ticket_rds_models import *
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.common_schema import *
from schema.vehicle_health_schema import *
from utils.vehicle_health_util import *
from storage_settings import rds_instance,get_current_date,redis_instance
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew
from hiper_utils.other_utils.add_anom_v2 import *

# Initialize the logger
logger_1 = LoggerFactory(name="vehicle_health_ticket_router_logs", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()



# endpoints start here

# endpoint to create a new ticket
@router.post("/createticket/")
async def create_ticket(vehicle_number : str = Form(...,description="Vehicle number of the vehicle the ticket is related to"),
                        ticket_name  : str = Form(...,description="Name of the vehicle health ticket"),
                        added_by : int = Form(..., description="ID of the user who created the ticket"),
                        priority : int = Form(None, description="Priority of the ticket"),
                        description : str = Form(None,description="Description of the ticket"),
                        modules : Optional[str] = Form(None, description="List of module IDs related to the feature"),
                        analysis_ticket_id : Optional[int] = Form(None, description="ID of the analysis ticket related to the vehicle health ticket"),
                        attachments : List[UploadFile] = File(None)):
    """
    API Endpoint to create a vehicle health ticket

    params : vehicle_number, ticket_name, added_by
    optional params : priority, description, libraries, analysis_ticket_id

    return : ticket data
        
    """

    bugs = {}

    try:

        # call create_vehicle_health_ticket from add anomaly v2
        new_ticket , bugs_local = create_vehicle_health_ticket(vehicle_number=vehicle_number,added_by=added_by,name=ticket_name,description=description,priority=priority,modules=modules,analysis_ticket_id=analysis_ticket_id,attachments=attachments)

        if bugs_local:
            logger_1.error(f"Failed in creating vehicle health ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to create vehicle health ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif new_ticket is not None:
            return {"message" : "Vehicle health ticket created successfully","ticket_id" : new_ticket}
        
        return JSONResponse({"error" : "Vehicle health ticket creation failed"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    except Exception as e:
        logger_1.error(f"Error occurred while creating vehicle health ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


@router.get("/getalltickets/")
async def get_all_tickets():
    """
    Endpoint to get all tickets

    params: None
    returns: all tickets
    """

    bugs = {}

    try:
        all_vehicle_health_tickets, bugs_local = all_vehicle_health_ticket_records()

        if bugs_local:
            logger_1.info(f"Failed in retrieving all vehicle health tickets, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error while retrieving all vehicle health tickets"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif all_vehicle_health_tickets is not None:
            # Convert DataFrame to CSV
            csv_buffer = io.StringIO()
            all_vehicle_health_tickets.to_csv(csv_buffer, index=False)
            csv_data = csv_buffer.getvalue()

            # Return CSV data
            return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": "attachment;filename=bug_tickets.csv"})

    except Exception as e:
        logger_1.error(f"Error occurred while fetching all libraries, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# endpoint to update a ticket
@router.put("/updateticket/")
async def update_ticket(ticket : Update_Vehicle_Health_Ticket):
    """
    API Endpoint to update a vehicle health ticket

    params :
        - ticket id : int

    optional params :
        - vehicle_number : str
        - ticket_name : str
        - description : str
        - owner : int
        - priority : int
        - analysis_ticket_id : int
        - modules : List[int]
        - status : int

    return : 
        - ticket data

    """

    bugs = {}

    try:

        # call update_rds_vh_ticket_record function
        updated_ticket_record, bugs_local = update_rds_vh_ticket_record(ticket)

        if bugs_local:
            logger_1.error(f"Updating the bug ticket rds record failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_record is not None:

            # call ticket update service function and perform the changes to s3 ticket
            updated_ticket, bugs_local = update_vh_ticket_fields(ticket)

            if bugs_local:
                logger_1.error(f"Updating the ticket in s3 failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif updated_ticket is not None:
                return {"message" : "Ticket updated successfully", "ticket_data" : updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while updating vehicle health ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# endpoint to get a single ticket
@router.get("/getticket/")
async def get_ticket(ticket_id : int):
    
    '''
    Endpoint to get a single vehicle health ticket

    query_params : ticket_id
    return : 200 if ticket found, else failure message with bugs
    
    '''

    bugs = {}


    try:
        # call fetch_and_cache_bug_ticket function
        ticket, bugs_local = fetch_and_cache_vh_ticket(ticket_id)

        if bugs_local:
            logger_1.info(f"Failed in fetching vehicle health ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error while fetching vehicle health ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket is not None:
            return {"message": "Vehicle health ticket fetched successfully", "ticket_data": ticket}


    except Exception as e:
        return JSONResponse({"error": "Unknown error occurred, failed to fetch bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# endpoint to transfer an anomaly
@router.post("/transferanomaly/")
async def transfer_anomaly(ticket : TransferAnomalyRequest):
    """

    API Endpoint to transfer an anomaly to another ticket

    params : 
        - anomaly_id : int
        - ticket_id : int
        - new_ticket_id : int
        - transferee : int

    return : 
        - ticket data with the transferred anomaly 
        - error message if any

    """

    bugs = {}

    try:

        # call transfer_anomaly_service function
        ticket_after_transfer, bugs_local = transfer_anomaly_service(ticket.anomaly_id, ticket.ticketid, ticket.new_ticketid, ticket.transferee)

        if bugs_local:
            logger_1.error(f"Error occurred while transferring anomaly, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error occurred while transferring anomaly"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_after_transfer is not None:
            return {"message": "Anomaly transferred successfully", "ticket_data": ticket_after_transfer}

      
    except Exception as e:
        logger_1.error(f"Error occurred while transferring anomaly, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


@router.get("/vehiclenums/")
async def get_vehicle_nums():
    """
    Endpoint to retrieve all vehicle numbers.

    Returns:
        All vehicle numbers.
    """
    try:
        all_veh_nums,bugs_local = fetch_and_cache_vehicle_numbers()
    
        if bugs_local:
            logger_1.error(f"Error occurred while retrieving vehicle numbers: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error occurred while retrieving vehicle numbers"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif all_veh_nums is not None:
            return {"message": "Vehicle numbers fetched successfully", "vehicle_numbers": all_veh_nums}

    except Exception as e:
        logger_1.error(f"Error occurred while retrieving vehicle numbers: {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# Define the request body using Pydantic
class AnomalyRequest(BaseModel):
    anomaly_id: str = Field(..., title="Anomaly ID")
    vehicle_number: str = Field(..., title="Vehicle Number")
    raised_by: str = Field(..., title="Raised By")
    start_date: str = Field(..., title="Start Date")
    end_date: Optional[str] = Field(None, title="End Date")


@router.post("/add_anomaly/")
async def add_anomaly_endpoint(request: AnomalyRequest):
    """
    FastAPI endpoint to add or update an anomaly ticket.
    """
    
    bugs = {}
    
    try:
        status, bugs_local = add_anomaly(
            anomaly_id=request.anomaly_id,
            vehicle_number=request.vehicle_number,
            raised_by=request.raised_by,
            start_date=request.start_date,
            end_date=request.end_date
        )
        
        if bugs_local:
            logger_1.error(f"Error occurred while adding/updating anomaly: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return {"error": "Error occurred while adding/updating anomaly"}

        print(f"status is {status}")

        if status == False:
            raise HTTPException(status_code=400, detail="Failed to add/update anomaly")

        elif status == True:
            return {"status": "success", "message": "Anomaly processed successfully"}

        else:
            raise HTTPException(status_code=500, detail="Unknown error")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))