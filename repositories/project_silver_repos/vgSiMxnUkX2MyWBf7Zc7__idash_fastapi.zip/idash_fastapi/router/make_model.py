# Import inbuilt libraries
import io

# Import third party libraries
from fastapi import APIRouter, Depends, File, UploadFile,status as http_status,Form,Response
from fastapi.responses import JSONResponse
from datetime import datetime
from typing import Optional,List



# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for make model library
lib_code_MM = "49"
lib_ver_MM = "00"

lib_code_ver_MM = f"{lib_code_MM}{lib_ver_MM}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.make_model_schema import *
from utils.make_model_util import *




# Initialize the logger
logger_1 = LoggerFactory(name="make_model_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()



# endpoints start here

# api to get make model table
@router.get("/table/")
async def get_make_model_table():
    """
    API to get make model table

    params:
        - None

    returns:
        - CSVResponse: CSV file with make model table data
        - error: error message if any error occurs

    """

    bugs = {}
    
    try:
        
        # call the function to get make model data as df
        df, bugs_local = get_make_model_data_as_df()
        
        if bugs_local:
            logger_1.error(f"Error in get_make_model_table: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failure to get the make model table"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif df is not None:
            # convert the df to csv
            csv = df.to_csv(index=False)
            return Response(content=csv, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=make_model_table.csv"})
        
        
    except Exception as e:
        logger_1.error(f"Error in get_make_model_table: {str(e)}")
        return JSONResponse({"error" : "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
    return {"message": "Make Model API ready to be used."}


# api to add a new make model
@router.post("/add/")
async def add_make_model(make_model: AddMakeModel):
    """
    API to add a new make model

    params:
        - make_model_id : str
        - vehicle_make : str
        - vehicle_model : str
        - emission : str
        - ecu_make : str
        - ecu_model : str
        - ecu_software_id : str
        - gvw : int
        - cylinders : int
        - num_of_gears : int
        - engine_capacity : int
        - power : int
        - max_torque_nm : int
        - rpm_min_for_max_torque : int
        - rpm_max_for_max_torque : int
        - max_rpm : int
        - oe_front_tyre_type : int
        - oe_rear_tyre_type : int
        - wheel_radius : float
        - gear_1 : float
        - gear_2 : float
        - gear_3 : float
        - gear_4 : float
        - gear_5 : float
        - gear_6 : float
        - gear_7 : str
        - gear_8 : str
        - gear_9 : str
        - crawler : str
        - rear_axle_ratio : float
        - reverse : float
        - injector_part_number : str
        - fuel_pump_make : str
        - fuel_pump_model : str
        - pp_flag : str
        - algo_flag : str
        - broadcast_flag : int
        - request_flag : int
        - exec_command_flag : int
        - flashing_flag : int
        - dataset_flag : int
        - bb_flag : str
        - dtc_flag : int
        - pairs : int
        - req_id : str
        - resp_id : str
        - dataset_id : str 

    returns:
        - JSONResponse: success message
        - error: error message if any error occurs

    """

    bugs = {}
    
    try:
        
        # call the function to add to make model rds
        success, bugs_local = add_make_model_to_rds(make_model)
        
        if bugs_local:
            logger_1.error(f"Error in add_make_model: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failure to add make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif success == True:
            return {"message": "Make Model added successfully."}
        
        else:
            return JSONResponse({"error" : "Failure to add make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        logger_1.error(f"Error in add_make_model: {str(e)}")
        return JSONResponse({"error" : "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    


# api to update make model
@router.put("/update/")
async def update_make_model(make_model: UpdateMakeModel):
    """
    API to update make model

    params:
        - make_model_id : str 
        
        optional fields:
        - vehicle_make : str
        - vehicle_model : str
        - emission : str
        - ecu_make : str
        - ecu_model : str
        - ecu_software_id : str
        - gvw : int
        - cylinders : int
        - num_of_gears : int
        - engine_capacity : int
        - power : int
        - max_torque_nm : int
        - rpm_min_for_max_torque : int
        - rpm_max_for_max_torque : int
        - max_rpm : int
        - oe_front_tyre_type : int
        - oe_rear_tyre_type : int
        - wheel_radius : float
        - gear_1 : float
        - gear_2 : float
        - gear_3 : float
        - gear_4 : float
        - gear_5 : float
        - gear_6 : float
        - gear_7 : str
        - gear_8 : str
        - gear_9 : str
        - crawler : str
        - rear_axle_ratio : float
        - reverse : float
        - injector_part_number : str
        - fuel_pump_make : str
        - fuel_pump_model : str
        - pp_flag : str
        - algo_flag : str
        - broadcast_flag : int
        - request_flag : int
        - exec_command_flag : int
        - flashing_flag : int
        - dataset_flag : int
        - bb_flag : str
        - dtc_flag : int
        - pairs : int
        - req_id : str
        - resp_id : str
        - from_manuf_year : int
         
       

    returns:
        - JSONResponse: success message
        - error: error message if any error occurs

    """

    bugs = {}
    
    try:
        
        # call the function to update make model
        success, bugs_local = update_make_model_in_rds(make_model)
        
        if bugs_local:
            logger_1.error(f"Error in update_make_model: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failure to update make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif success == True:
            return {"message": "Make Model updated successfully."}
        
        else:
            return JSONResponse({"error" : "Failure to update make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        logger_1.error(f"Error in update_make_model: {str(e)}")
        return JSONResponse({"error" : "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    

# api to delete make model
@router.delete("/delete/")
async def delete_make_model(make_model: DeleteMakeModel):
    """
    API to delete make model

    params:
        - make_model_id : str

    returns:
        - JSONResponse: success message
        - error: error message if any error occurs

    """

    bugs = {}
    
    try:
        
        # call delete_from_make_model_rds function
        success, bugs_local = delete_from_make_model_rds(make_model)
        
        if bugs_local:
            logger_1.error(f"Error in delete_make_model: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failure to delete make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif success == True:
            return {"message": "Make Model deleted successfully."}
        
        else:
            return JSONResponse({"error" : "Failure to delete make model"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        logger_1.error(f"Error in delete_make_model: {str(e)}")
        return JSONResponse({"error" : "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# endpoint to get all make 
@router.get("/allmake/")
async def get_all_make():

    '''
    API Endpoint to get all vehicle makes

    params
        - None

    returns
        - JSONResponse: JSON response with all vehicle makes
        - error: error message if any error occurs
    
    
    '''

    bugs = {}

    try:
        make_list,bugs_local = get_all_make_dict()
        
        if bugs_local:
            logger_1.error(f"Error in getting all vehicle make, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to fetch all vehicle makes"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif make_list is not None or make_list != []:
            return {"message" : "All vehicle makes fetched", "data" : make_list}
        
        else:
            return {"message" : "No vehicle makes found"}

    except Exception as e:
        logger_1.error(f"Unknowne error occured, failed to fetch all vehicle makes {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# endpoint to get all vehicle models
@router.get("/allmodel/")
async def get_all_model(make_name:str):
    
    '''
    API Endpoint to get all vehicle models

    params
        - make : manufaturer name of the vehicle
    
    returns
        - JSONResponse: JSON response with all vehicle models related to the make
        - error: error message if any error occurs
    
    '''

    bugs = {}

    try:
        all_models,bugs_local = get_all_models_to_make(make_name)
        
        if bugs_local:
            logger_1.error(f"Error in getting all vehicle models, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to fetch all vehicle models"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif all_models is not None or all_models != {}:
            return {"message" : "All vehicle models fetched", "data" : all_models}
        
        else:
            return {"message" : "No vehicle models found"}

    except Exception as e:
        logger_1.error(f"Unknown error occured, failed to fetch all vehicle models {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    



# endpoint to get all ecu make
@router.get("/allecumakes/")
async def get_all_ecu_make():

    '''

    API Endpoint to get all ecu makes

    params
        - None

    returns
        - JSONResponse: JSON response with all ecu makes
        - error: error message if any error occurs

    '''

    bugs = {}

    try:
        
        ecu_make_list,bugs_local = get_all_ecu_make_dict()

        if bugs_local:
            logger_1.error(f"Error in getting all ecu makes, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to fetch all ecu makes"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ecu_make_list is not None or ecu_make_list != []:
            return {"message" : "All ecu makes fetched", "data" : ecu_make_list}
        
        else:
            return {"message" : "No ecu makes found"}

    except Exception as e:
        logger_1.error(f"Error in get_all_ecu_make endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    


# endpoint to get all ecu models
@router.get("/allecumodels/")
async def get_all_ecu_model(ecu_make_name : str):
    
    '''
    
    API Endpoint to get all ecu models

    params
        - ecu_make_name : name of the ecu make

    returns
        - JSONResponse: JSON response with all ecu models related to the ecu make
        - error: error message if any error occurs
    
    
    '''
    
    bugs = {}
    
    try:
      
        ecu_model_list,bugs_local = get_all_ecu_model_dict_to_make(ecu_make_name)
        
        if bugs_local:
            logger_1.error(f"Error in getting all ecu models, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to fetch all ecu models"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ecu_model_list is not None or ecu_model_list != []:
            return {"message" : "All ecu models fetched", "data" : ecu_model_list}
        
        else:
            return {"message" : "No ecu models found"}


    except Exception as e:
        logger_1.error(f"Error in get_all_ecu_model endpoint {str(e)}")
        return JSONResponse(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,content={"message":"Internal Server Error"})


# endpoint to get emissions related to a make model
@router.get("/getemissions/")
async def get_emissions(make : str, model : str):
    
    """
    
    API Endpoint to get emissions in relation to make model
    
    params :
        - make : str 
        - model : str
            
    
    returns:
    
        - JSONResponse: list of emissions
        - error : error message if any error occurs
    
    
    
    """
    
    bugs = {}
    
    try:
        
        # call the function get_emissions_to_make_model
        emissions,bugs_local = get_emissions_to_make_model(make,model)
        
        if bugs_local:
            logger_1.error(f"Error in getting emissions, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to fetch emissions"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif emissions is not None or emissions != []:
            return {"message" : "Emissions fetched", "data" : emissions}
        
        else:
            return {"message" : "No emissions found"}
    
    except Exception as e:
        logger_1.error(f"Error in get_emissions endpoint {str(e)}")
        return JSONResponse(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,content={"message":"Internal Server Error"})