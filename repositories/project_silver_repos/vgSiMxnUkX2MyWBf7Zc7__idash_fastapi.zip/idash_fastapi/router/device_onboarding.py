# Import inbuilt libraries


# Import third party libraries
from typing import List
from fastapi import APIRouter, File, Form, UploadFile, status as http_status
from fastapi.responses import JSONResponse, StreamingResponse


# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for device onboarding library
lib_code_DOL = "55"
lib_ver_DOL = "00"

lib_code_ver_DOL = f"{lib_code_DOL}{lib_ver_DOL}"



# Include custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.bug_tickets_util import handle_bugs
from utils.device_onboarding_util import *
from schema.device_onboarding_schema import *
from storage_settings import save_temp_file

# Initialize the logger
logger_1 = LoggerFactory(name="device_onboarding_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()

# API Endpoint for uploading hardware images
@router.post("/upload_images/")
async def upload_hw_images(
    imei_no: str = Form(...),
    images: List[UploadFile] = File(...)
):
    """
    API Endpoint for uploading hardware images.

    params:
        - imei_no: str: IMEI number of the device.
        - images: List[UploadFile]: List of images to be uploaded.


    Returns:
        - 200 OK: Success message if images are uploaded successfully.
        - 500 Internal Server Error: Error message if the operation fails.
   
    """
    bugs = {}

    try:

        # Check or register the hardware device
        registration_status = check_hw_registered_or_register(imei_no)

        if not registration_status:
            return JSONResponse(
                {"error": "Device marked with issues and cannot be registered."},
                status_code=http_status.HTTP_400_BAD_REQUEST
            )


        # Call the image processing function
        upload_status, bugs_local = process_hw_images(imei_no, images)

        # Handle bugs if any
        if bugs_local:
            logger_1.error(f"Error occured during image upload: {bugs_local}")
            bugs = handle_bugs(bugs, bugs_local)
            return JSONResponse({"error": "Image upload failed, error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Check upload status
        if not upload_status:
            return JSONResponse({"error": "Image upload failed"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Success response
        return JSONResponse({"message": "Images uploaded successfully"}, status_code=http_status.HTTP_200_OK)

    except Exception as exc:
        # Handle unexpected errors
        logger_1.error(f"Unexpected error during image upload: {exc}") 
        return JSONResponse(status_code=500, content={"error": "Unknown error occurred"})


# API Endpoint for adding an issue during physical inspection
@router.post("/add_issue/")
async def add_hw_issue(hw: add_hw_input):
    """
    API Endpoint for adding an issue during physical inspection.

    Parameters:
        - hw: add_hw_input: Input containing IMEI number, issue description, and added_by information.

    Returns:
        - 200 OK: Success message if issue is added successfully.
        - 500 Internal Server Error: Error message if the operation fails.
    """
    bugs = {}

    try:
        
        # Mark QA as 0 in the database
        update_status = mark_qa_as_failed(hw.imei_no)

        if not update_status:
            return JSONResponse(
                {"error": "Failed to update QA status."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        return JSONResponse(
            {"message": "Issue added successfully and QA marked as failed."},
            status_code=http_status.HTTP_200_OK
        )

    except Exception as exc:
        logger_1.error(f"Unexpected error during adding issue: {exc}")
        return JSONResponse(
            {"error": "Unknown error occurred."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@router.get("/check_issues/")
async def get_qa_status(imei_no: str):
    """
    API Endpoint to check the QA status of a hardware device.

    Parameters:
        - imei_no: str: IMEI number of the device.

    Returns:
        - 200 OK: The QA status of the device.
        - 404 Not Found: If the device is not found.
        - 500 Internal Server Error: Error message if the operation fails.
    """


    try:
        # Call the dedicated function to get QA status
        qa_status = check_hw_status(imei_no)

        if qa_status is None:
            return JSONResponse(
                {"error": "Device not found."},
                status_code=http_status.HTTP_404_NOT_FOUND
            )

        # Success response
        return JSONResponse(
            {"qa_status": qa_status},
            status_code=http_status.HTTP_200_OK
        )

    except Exception as exc:
        logger_1.error(f"Unexpected error during QA status check: {exc}")
        return JSONResponse(
            {"error": "Unknown error occurred."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
    

# API endpoint to dowload the code at the stage of device prepration    
@router.post("/dl_code/")
async def dl_code(inputs: dload_code_input):
    """
    API Endpoint to fetch required files for device preparation.

    params:
        - device_id: str: The ID of the device.
        - make_model: str: The make and model of the device.


    Returns:
        - a downlaodable zip file
        - error message in case of failure
    
    """

    bugs = {}

    try:
        
        # call the get_all_files func
        zip_file, bugs_local = get_all_files(inputs.device_id, inputs.make_model)
        
        if bugs_local:
            logger_1.error(f"Error occured during file download: {bugs_local}")
            bugs = handle_bugs(bugs, bugs_local)
            return JSONResponse({"error": "File download failed, error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif zip_file:
            
        #    logger_1.info(f"get_all_files returned: {zip_file}, type: {type(zip_file)}")
            
            # Prepare StreamingResponse with proper headers
            headers = {
                "Content-Disposition": f"attachment; filename={inputs.device_id}_{inputs.make_model}_files.zip",
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
            return StreamingResponse(
                zip_file,  # Pass the BytesIO object
                media_type="application/zip",
                headers=headers
            )
        
            
    except Exception as e:
        logger_1.error(f"Unexpected error during file download: {e}")
        return JSONResponse(status_code=500, content={"error": "Unknown error occurred"})
            
        
        
# API endpoint to download the production code during benchtesting
@router.get("/dl_btest_code/")
def dl_btest_code():
    
    """
    
    API Endpoint to fetch production code
    
    params : 
        - None
    
    returns : 
        - production code file : zip
        - error message in case the api fails
    
    
    
    """
    
    bugs = {}
    
    try:
     
        # call download_production_bin 
        prod_bin_zip,bugs_local = fetch_prod_bin()
        
        if bugs_local:
            logger_1.error(f"Error occured during production file download: {bugs_local}")
            bugs = handle_bugs(bugs, bugs_local)
            return JSONResponse({"error": "Production file download failed, error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Prepare StreamingResponse with proper headers
        headers = {
            "Content-Disposition": f"attachment; filename=production_files.zip",
            "Access-Control-Expose-Headers": "Content-Disposition"
        }
        
        return StreamingResponse(
            prod_bin_zip,  # Pass the BytesIO object
            media_type="application/zip",
            headers=headers
        )
     
        
    except Exception as e:
        logger_1.error(f"Failed to get the production file , {e}")
        return JSONResponse(status_code=500, content={"error": "Unknown error occurred"})

    
# API endpoint to check ping status of the device
@router.get("/ping_status/")
async def ping_status(device_id : str):
    """
    API Endpoint to check the ping status of the device.

    Parameters:
        - inputs (ping_status_input): Input data containing the device IMEI number.

    Returns:
        - JSONResponse:
            - 200 OK for status `4` (device is ready).
            - 202 Accepted for status `3` (device issue detected, continue polling).
            - 500 Internal Server Error for backend issues.
    """
    
    bugs = {}
    
    try:
        # Call the check_ping_status function
        ping_sts,bugs_local = check_onboard_stage(device_id)

        if bugs_local:
            logger_1.error(f"Error occured during ping status check: {bugs_local}")
            bugs = handle_bugs(bugs, bugs_local)
            return JSONResponse({"error": "Ping status check failed, error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Success response
        return ping_sts
        
    except Exception as e:
        # Handle unexpected backend errors
        logger_1.error(f"Unexpected error during ping status check: {e}")
        return JSONResponse(
            {
                "error": "Unknown error occurred",
            },
            status_code=500
        )


# API Endpoint to download the code in the hardware registration page
@router.get("/dl_hw_code/")
async def dl_hw_code():
    
    '''
    
    API Endpoint to fetch required files for hardware registration
    
    params:
        - None
        
    returns:
        - a downlaodable zip file
        - error message in case of failure
    
    
    
    '''
    
    bugs = {}
    
    try:
        
        # call the get_all_files func
        zip_file, bugs_local = get_hw_files()
        
        if bugs_local:
            logger_1.error(f"Error occured during file download: {bugs_local}")
            bugs = handle_bugs(bugs, bugs_local)
            return JSONResponse({"error": "File download failed, error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif zip_file is not None:
            
        #    logger_1.info(f"get_all_files returned: {zip_file}, type: {type(zip_file)}")
            
            # Prepare StreamingResponse with proper headers
            headers = {
                "Content-Disposition": f"attachment; filename=hardware_files.zip",
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
            return StreamingResponse(
                zip_file,  # Pass the BytesIO object
                media_type="application/zip",
                headers=headers
            )
            
        else:
            return JSONResponse({"error": "File download failed"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        logger_1.error(f"Unexpected error during file download: {e}")
        return JSONResponse(status_code=500, content={"error": "Unknown error occurred"})
    
    
# API Endpoint to update production code
@router.post("/up_prod_code/")
async def update_production_file(file: UploadFile):
    """
    API to upload a production file to S3 and update the path in storage_settings.py.

    Parameters:
    - file: The production file to be uploaded.

    Returns:
    - JSONResponse with success or error message.
    """
    try:
        # Extract filename from uploaded file
        file_name = file.filename
        if not file_name.endswith(".bin"):
            return JSONResponse(status_code=400, detail="File must have a .bin extension")

        # Save the file temporarily in GLOBAL_TEMP_DIR
        temp_file_path = save_temp_file(await file.read(), file_name)
        
        print(f"File saved temporarily at: {temp_file_path}")

        # Define the S3 path (key)
        s3_key = f"devices/test/{file_name}"

        # Upload the file to S3
        upload_file_to_s3(temp_file_path, s3_key)

        # Update storage_settings.py
        update_storage_settings(s3_key)

        # Clean up the temporary file
        os.remove(temp_file_path)
        
        print(f"File removed from temp directory: {temp_file_path}")
        
        print(f"File uploaded successfully to {s3_key} and path updated.")

        return {"message": f"File uploaded successfully to {s3_key}"}

    except Exception as e:
        return {"error": f"Failed to upload and update production file: {str(e)}"}





