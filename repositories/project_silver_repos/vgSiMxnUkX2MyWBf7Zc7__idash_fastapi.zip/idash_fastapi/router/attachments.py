# Import inbuilt libraries



# Import third party libraries
from typing import List
from fastapi import APIRouter, File, Form, UploadFile,status as http_status
from fastapi.responses import JSONResponse
from schema.attachments_schema import *



# Include repos folder for custom libraries
from auth_bearer import JWTBearer
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs, serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from storage_settings import hiperft_bucket
from utils.attachment_util import *
from utils.feature_tickets_util import handle_ticket_update_for_s3
from utils.vehicle_registration_util import check_vehicle_already_registered

# Declare variables used 
# Library Code for Attachment Module
lib_code_AM = "29"
lib_ver_AM = "00"

lib_code_ver_AM = f"{lib_code_AM}{lib_ver_AM}"


# initialize the logger
logger_1 = LoggerFactory(name="attachment_routes",file_name="message.log").get_logger()


router = APIRouter()


@router.get("/get/")
async def get_attachment(ticket_type: int = None , ticket_id: int = None, block_id: int = None, custom_s3_path : str = None):
    
    '''
    API Endpoint to fetch the attachment from a ticket block and return the list of presigned URLs for the attachments
    
    params
    
        - ticket_type : int : Type of the ticket
        - ticket_id : int : ID of the ticket
        - block_id : int : ID of the block
        
    
    returns:
    
        - dict : dict : Response object containing the list of presigned URLs for the attachments   
        - error : str : Error message in case of failure
    
    '''
    try:
        # Call the helper function
        if ticket_type and ticket_id and block_id:
            presigned_urls_list, bugs_local = fetch_attachments(ticket_type, ticket_id, block_id)

            if bugs_local:
                logger_1.error(f"Error with get attachment api : {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to fetch attachments for the ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            if presigned_urls_list is not None:
                return {"attachments": presigned_urls_list}

            return JSONResponse({"error": "No attachments found for the ticket"}, status_code=http_status.HTTP_404_NOT_FOUND)
        

    except Exception as e:
        logger_1.error(f"Error with get attachment api : {str(e)}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



@router.delete("/delete/")
async def delete_attachment(attachment : DeleteAttachment_Input):

    '''
    API Endpoint to delete the attachment from S3

    params:
        - s3_key : str : S3 key of the attachment to be deleted
    
    returns:
        - dict : dict : Response object containing the status of the operation
    
    '''

    bugs = {}


    try:

        # call extract_s3_key_from_presigned_url function
        s3_key, bugs_local = extract_s3_key_from_url(attachment.presigned_url)

        if bugs_local:
            logger_1.info(f"Unable to extract S3 key from presigned URL {attachment.presigned_url}, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Unable to delete attachment from ticket, unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        logger_1.info(f"S3 key extracted from presigned URL: {s3_key}")

        # Delete the file from S3
        result,bugs_local = hiperft_bucket.delete_file_from_s3(s3_key=s3_key)

        if bugs_local:
            logger_1.info(f"Unable to delete the file {s3_key} from S3, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Unable to delete attachment from ticket, unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif result == True:
            logger_1.info(f"File deleted successfully from S3: {s3_key}")    
            
            if attachment.ticket_type and attachment.ticketid and attachment.block_id:
                # call delete_attachment_from_ticket
                ticket_data_after_deletion,bugs_local = delete_attachment_from_ticket(s3_key=s3_key,ticket_type=attachment.ticket_type,ticket_id=attachment.ticketid,block_id=attachment.block_id,deleted_by=attachment.deleted_by)

                if bugs_local:
                    logger_1.info(f"Unable to delete attachment from ticket {attachment.ticketid}, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return JSONResponse({"error" : "Unable to delete attachment from ticket, unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


                elif ticket_data_after_deletion is not None:
                    return JSONResponse({"message" : "Attachment deleted successfully from ticket", "ticket_data" : ticket_data_after_deletion},status_code=http_status.HTTP_200_OK)
                
            if attachment.vehicle_num:
                # call delete_attachment_from_vehicle
                vehicle_data_after_deletion,bugs_local = delete_attachment_from_vehicle_json(s3_key=s3_key,vehicle_num=attachment.vehicle_num,deleted_by=attachment.deleted_by)

                logger_1.info(f"Vehicle data after deletion: {vehicle_data_after_deletion}")
        
                if bugs_local:
                    logger_1.info(f"Unable to delete attachment from vehicle {attachment.vehicle_num}, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return JSONResponse({"error" : "Unable to delete attachment from vehicle, unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

                elif vehicle_data_after_deletion is not None:
                    return JSONResponse({"message" : "Attachment deleted successfully from vehicle", "vehicle_data" : vehicle_data_after_deletion},status_code=http_status.HTTP_200_OK)

    except Exception as e:
        logger_1.info(f"Error deleting attachment from ticket, {e}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




@router.post("/addmore/")
async def add_more_attachments(
    attachments: List[UploadFile] = File(None),
    ticket_type: Optional[int] = Form(None),
    ticket_id: Optional[int] = Form(None),
    block_id: Optional[int] = Form(None),
    vehicle_num: Optional[str] = Form(None),
    obd_location_photo: List[UploadFile] = File(None),
    photo_of_rc_book: List[UploadFile] = File(None),
    installation_video: List[UploadFile] = File(None),
    photo_of_wheels: List[UploadFile] = File(None),
    photo_of_number_plate: List[UploadFile] = File(None),
    puc_certificate: List[UploadFile] = File(None),
    added_by: int = Form(...)
):
    """
    API Endpoint to add more attachments to either a ticket or vehicle data.

    params:
        - attachments: List[UploadFile]: List of files to be uploaded
        - ticket_type: Optional[int]: Type of the ticket (required for ticket-related uploads)
        - ticket_id: Optional[int]: ID of the ticket (required for ticket-related uploads)
        - block_id: Optional[int]: ID of the block (required for ticket-related uploads)
        - vehicle_num: Optional[str]: Vehicle number (required for vehicle-related uploads)
        - obd_location_photo: Optional[List[UploadFile]]: OBD location photo for vehicle-related uploads
        - photo_of_rc_book: Optional[List[UploadFile]]: RC book photo for vehicle-related uploads
        - installation_video: Optional[List[UploadFile]]: Installation video for vehicle-related uploads
        - photo_of_wheels: Optional[List[UploadFile]]: Wheels photo for vehicle-related uploads
        - photo_of_number_plate: Optional[List[UploadFile]]: Number plate photo for vehicle-related uploads
        - puc_certificate: Optional[List[UploadFile]]: PUC certificate for vehicle-related uploads
        - added_by: int: ID of the user who added the attachment

    returns:
        - dict: Response object containing the status of the operation
    """

    bugs = {}
    
    

    # Handle ticket-related attachments
    if ticket_type and ticket_id and block_id:
        # Create an attachment object for tickets
        attachment = AddMoreAttachments_Input(
            ticket_type=ticket_type,
            ticketid=ticket_id,
            block_id=block_id,
            added_by=added_by,
            attachments=attachments
        )

        # Call the function to add attachments to the ticket
        updated_ticket, bugs_local = add_extra_attachment_to_block(
            ticket_type=attachment.ticket_type,
            ticket_id=attachment.ticketid,
            block_id=attachment.block_id,
            attachments=attachment.attachments,
            added_by=attachment.added_by
        )

        if bugs_local:
            logger_1.info(f"Unable to add attachments to ticket {attachment.ticketid}, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to add attachments to ticket, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif updated_ticket is not None:
            # Call the function to update ticket data in S3
            updated_ticket_data, bugs_local = handle_ticket_update_for_s3(
                ticketid=attachment.ticketid, 
                ticket_with_updation=updated_ticket, 
                user_id=attachment.added_by
            )

            if bugs_local:
                logger_1.info(f"Unable to update ticket data for {attachment.ticketid}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket data after adding attachments, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            return JSONResponse({"message": "Attachments added successfully to ticket", "ticket_data": updated_ticket_data}, status_code=http_status.HTTP_200_OK)

    # Handle vehicle-related attachments
    elif vehicle_num:
        
        # check if the vehicle actually exists calling check_vehicle_already_registered
        vehicle_registered,bugs_local = check_vehicle_already_registered(vehicle_num)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to add attachments as vehicle does not exist"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not found"},status_code=http_status.HTTP_400_BAD_REQUEST)
                
        
        # inti a boolean variable to check if the attachments are added successfully
        write_success = False

        # create an instance of AddMoreAttachments_Input for vehicle
        attachment = AddMoreAttachments_Input(
            vehicle_num=vehicle_num,
            added_by=added_by,
            obd_location_photo=obd_location_photo,
            installation_video=installation_video,
            photo_of_rc_book=photo_of_rc_book,
            photo_of_wheels=photo_of_wheels,
            photo_of_number_plate=photo_of_number_plate,
            puc_certificate_photo=puc_certificate
        ) 

        # If OBD location photo or installation video is provided, handle installation block
        if attachment.obd_location_photo or attachment.installation_video:
            
            success, bugs_local = append_to_installation_block(
                vehicle_num=attachment.vehicle_num,
                obd_location_photo=attachment.obd_location_photo,
                installation_video=attachment.installation_video,
                added_by=attachment.added_by
            )
            
            if bugs_local:
                logger_1.info(f"Unable to add attachments to vehicle {vehicle_num}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to add attachments to vehicle, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif success == True:
                write_success = True
                logger_1.info(f"Installation Attachments added successfully to vehicle {vehicle_num}")
            
        
        # If RC book photo, wheels photo, or number plate photo is provided, handle calibration block
        if attachment.photo_of_rc_book or attachment.photo_of_wheels or attachment.photo_of_number_plate or attachment.puc_certificate_photo:   
            
            success, bugs_local = append_to_calibration_block(
                vehicle_num=attachment.vehicle_num,
                photo_of_rc_book=attachment.photo_of_rc_book,
                photo_of_wheels=attachment.photo_of_wheels,
                photo_of_number_plate=attachment.photo_of_number_plate,
                puc_certificate=attachment.puc_certificate_photo,
                added_by=attachment.added_by
            )

            if bugs_local:
                logger_1.info(f"Unable to add attachments to vehicle {vehicle_num}, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to add attachments to vehicle, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif success == True:
                logger_1.info(f"Calibration Attachments added successfully to vehicle {vehicle_num}")
                write_success = True
                
        if write_success:
            return JSONResponse({"message": "Attachments added successfully to vehicle"}, status_code=http_status.HTTP_200_OK)
        
        return JSONResponse({"error": "No attachments provided to add"}, status_code=http_status.HTTP_400_BAD_REQUEST)
            


# route to get attachments on vehicle data
@router.get("/get_vehicle_attachments/")
async def get_vehicle_attachments(vehicle_num: str , obd_location_photo: bool = False, installation_video: bool = False, photo_of_rc_book: bool = False, photo_of_wheels: bool = False, photo_of_number_plate: bool = False, puc_certificate: bool = False):
    """
    API Endpoint to fetch the attachments for a vehicle.

    params:
        - vehicle_num: str: Vehicle number
        - obd_location_photo: bool: Flag to fetch OBD location photo
        - installation_video: bool: Flag to fetch installation video
        - photo_of_rc_book: bool: Flag to fetch RC book photo
        - photo_of_wheels: bool: Flag to fetch wheels photo
        - photo_of_number_plate: bool: Flag to fetch number plate photo
        - puc_certificate: bool: Flag to fetch PUC certificate photo

    returns:
        - dict: Response object containing the list of presigned URLs for the attachments
        - error: str: Error message in case of failure
    """

    try:

        presigned_urls_list, bugs_local = fetch_attachments_for_vehicle_data(vehicle_num, obd_location_photo, installation_video, photo_of_rc_book, photo_of_wheels, photo_of_number_plate, puc_certificate)

        if bugs_local:
            logger_1.error(f"Error with get attachment api : {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to fetch attachments for the vehicle"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if presigned_urls_list is not None:
            return {"attachments": presigned_urls_list}

        return JSONResponse({"error": "No attachments found for the vehicle"}, status_code=http_status.HTTP_404_NOT_FOUND)
        

    except Exception as e:
        logger_1.error(f"Error with get attachment api : {str(e)}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)