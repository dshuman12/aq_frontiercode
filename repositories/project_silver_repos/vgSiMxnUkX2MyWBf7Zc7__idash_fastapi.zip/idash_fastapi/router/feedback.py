# Import inbuilt libraries





# Import third party libraries
from typing import List,Optional
from fastapi import APIRouter, File, Form,UploadFile,status as http_status
from fastapi.responses import JSONResponse





# Include repos folder for custom libraries



# Declare variables used 

# Library Code for Users Module
lib_code_FM = "28"
lib_ver_FM = "00"

lib_code_ver_FM = f"{lib_code_FM}{lib_ver_FM}"



# Include custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.feedback_util import *
from schema.feedback_schema import *


router = APIRouter()

logger_1 = LoggerFactory(name="feedback_route", file_name="message.log").get_logger()



# api endpoint to add a feedback
@router.post("/add/")
async def add_feedback(
    ticket_id: str = Form(...),
    ticket_type: str = Form(...),
    added_by: int = Form(...),
    related_prototype_block: int = Form(...),
    result_summary: str = Form(...),
    attachments: List[UploadFile] = File(None)
):
    '''
    API Endpoint to add a feedback

    params: feedback object
    return : success message or error message
    
  '''

    # create a addfeedback_input object
    feedback = AddFeedback_Input(
        ticket_id=ticket_id,
        ticket_type=ticket_type,
        related_prototype_block=related_prototype_block,
        added_by=added_by,
        result_summary=result_summary,
        attachments=attachments
    )


    bugs = {}


    # call the add_feedback_service to add the feedback
    ticket_s3_data,bugs_local = add_feedback_service(feedback=feedback)

    if bugs_local:
        logger_1.error(f"Error in adding feedback, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return JSONResponse({"error" : "Failed in adding feedback, unknwown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif ticket_s3_data is not None:
        return {"message":"Feedback added successfully","ticket_data" : ticket_s3_data}
    
    return JSONResponse({"error" : "Unknwown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)





