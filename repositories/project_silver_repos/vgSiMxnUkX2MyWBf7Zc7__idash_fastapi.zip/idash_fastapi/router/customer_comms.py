# Import inbuilt libraries


# Import third party libraries
from fastapi import APIRouter, Depends, File, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse
from typing import List


# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for customer comms library
lib_code_ver_CUCOMS = "79"
lib_ver_CUCOMSlib_code_ver_CUCOMS = "00"

lib_code_ver_CUCOMSlib_code_ver_CUCOMS = f"{lib_code_ver_CUCOMS}{lib_ver_CUCOMSlib_code_ver_CUCOMS}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.other_utils.bug_util_up import BugHandler
from schema.customer_comms_schema import *
from utils.customer_comms_util import *



# Initialize the logger
logger_1 = LoggerFactory(name="customer_comms_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()


# endpoints start here
@router.post("/generate/")
async def gen_message(inputs: MessageInput):
    '''
    API Endpoint to generate a trip message.

    Parameters:
        - vehicle_number : str
        - date : str (YYYY-MM-DD format)

    Returns:
        - JSONResponse : Trip metrics in JSON format or an error message.
    '''

    bugs = {}
    
    try:
        
        # Call get_trip_metrics with converted UTC range
        trip_metrics, bugs_local = get_trip_metrics(inputs.vehicle_number, inputs.date)

        if bugs_local:
            logger_1.error(f"Failed to generate_message: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"error": "Failed to generate message"}
            )
    
        # Return the generated trip metrics
        return JSONResponse(
            status_code=http_status.HTTP_200_OK,
            content={"status": "success", "trip_metrics": trip_metrics}
        )

    except Exception as e:
        logger_1.error(f"generate_message: {e}")
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "Internal Server Error"}
        )





# API endpoint for sending trip metrics
@router.post("/send/")
def send_trip_metrics(inputs: TripMetricsMessage):
    '''
    API Endpoint to send the message generated

    params:
        - vehicle_number : str
        - message : dict
        - phone_numbers : Optional List of strings

    returns
        - JSONResponse : Success or error message
    '''
    
    bugs = {}
    
    try:
        # Construct the message_body with placeholders from the input message
        message_body = {
            "1": inputs.message_JSON.get("vehicle_number"),
            "2": inputs.message_JSON.get("trip_period"),
            "3": inputs.message_JSON.get("start_location"),
            "4": inputs.message_JSON.get("end_location"),
            "5": inputs.message_JSON.get("distance"),
            "6": inputs.message_JSON.get("fuel_consumed"),
            "7": inputs.message_JSON.get("mileage"),
            "8": inputs.message_JSON.get("average_speed"),
            "9": inputs.message_JSON.get("engine_idle_running"),
            "10": inputs.message_JSON.get("health_alert")
        }
        
        
        logger_1.info(f"the message body is {message_body}")
        
        # log the phone number
        logger_1.info(f"Phone numbers fetched for vehicle {inputs.phone_numbers}")       
        
        vehicle_number = inputs.message_JSON.get("vehicle_number") 
        
        if inputs.phone_numbers is None:
            # call get_phone_numbers_by_vehicle_number
            phone_numbers, bugs_local = get_phone_numbers_by_vehicle_number(vehicle_number)

            if bugs_local:
                logger_1.error(f"Failed to fetch customers related to the vehicle: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                
                return JSONResponse(
                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content={"error": "Failed to fetch customers related to the vehicle"}
                )
                
            # log the phone numbers here
            logger_1.info(f"Phone numbers fetched for vehicle {phone_numbers}")
            
        else:
            # Use provided phone numbers or default to the given number
            phone_numbers = inputs.phone_numbers

        # Template SID
        template_sid = "HX67cc888741c7f4a5751e8ed7db13c6cb"

        # Call send_whatsapp_twilio for each phone number
        sent_messages = []
        for phone_number in phone_numbers:
            try:
                message_sid = send_whatsapp_twilio(message_body, phone_number, template_sid)
                        
                sent_messages.append({"phone_number": phone_number, "sid": message_sid})
            
            except Exception as e:
                logger_1.error(f"Error sending message to {phone_number}: {e}")
                return JSONResponse(
                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content={"error": "Failed to send the messages"}
                )

        return {"message": "Messages processed", "details": sent_messages}

    except Exception as e:
        print(f"Unknown error occurred sending trip metrics: {e}")
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": "Unknown error occurred"}
        )
        
        
# API Endpoint to raise an error in case the message is incorrect        
@router.post("/raise_error/")
def raise_error(inputs : RaiseErrorInput):
    """
    API to raise an error when a user finds a message to be incorrect.

    Parameters:
        - input_data: RaiseErrorInput - Includes message JSON and user ID.

    Returns:
        - JSONResponse: Status of the bug creation or update.
    """
    try:
        # Prepare the bug object
        bug_obj = {
            1: {
            "date_of_bug": datetime.now().strftime("%Y-%m-%d"),
            "code": "79000300",
            "message": "Incorrect message formed",
            "input": inputs.message_JSON
            }
        }


        # Call the add_bug function
        bug_handler = BugHandler()
        
        add_status, bugs_local = bug_handler.add_bug(
            bug_obj=bug_obj,
            raised_by=inputs.raised_by,
            ticket_name=f"Incorrect Message Formed for {inputs.message_JSON.get('vehicle_number')} on {datetime.now().strftime('%Y-%m-%d')}",
        )

        # Handle the response
        if bugs_local:
            logger_1.error(f"Failed to raise_error: {bugs_local}")
            return JSONResponse(
                status_code=500,
                content={"error": "Failed to raise error, Unknown error occurred"}
            )

        if add_status:
            return JSONResponse(
                status_code=200,
                content={"message": "Raised error successfully"}
            )
        else:
            return JSONResponse(
                status_code=500,
                content={"error": "Failed to raise error"}
            )

    except Exception as e:
        logger_1.error(f"raise_error: {e}")
        return JSONResponse(
            status_code=500,
            content={"message": "Internal Server Error"}
        )


@router.post("/test-dtc-alerts")
async def test_dtc_alerts():
    """
    API endpoint to test the `send_dtc_alerts` function.
    """
    
    # run the check_if_dtc_changed function to get the vehicle list
    # vehicle_list, bugs_local = check_if_dtc_changed()
    
    # if bugs_local:
    #     logger_1.error(f"Failed to test_dtc_alerts: {bugs_local}")
    #     return JSONResponse(
    #         status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
    #         content={"error": "Failed to test DTC alerts"}
    #     )
        
    
    # return JSONResponse(
    #     status_code=http_status.HTTP_200_OK,
    #     content={"message": "Test DTC alerts successful", "vehicle_list": vehicle_list}
    # )
    
    # response = send_dtc_alerts() 
    
    response = send_trip_metrics_util() 
    
    return response