# Import inbuilt libraries
import sys
sys.path.append("../")




# Import third party libraries
from fastapi import APIRouter, Request,status as http_status,Response,Depends
from datetime import datetime, timedelta, timezone
from fastapi.responses import JSONResponse

# Include repos folder for custom libraries



# Declare variables used 
# Library Code for Users Module
lib_code_UM = "25"
lib_ver_UM = "00"

lib_code_ver_UM = f"{lib_code_UM}{lib_ver_UM}"



# Include custom libraries
from storage_settings import rds_instance
from hiper_utils.data_models.rds_data_models.users_rds_models import Employee
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.users_schema import *
from storage_settings import rds_instance
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.users_utils import *
from auth_bearer import JWTBearer

router = APIRouter()

logger_1 = LoggerFactory(name="user_route", file_name="message.log").get_logger()


# ENDPOINTS START FROM HERE


# endpoint to get all users
@router.get("/getallusers/")
async def get_all_users():
    '''
    Endpoint to get all UserTable

    params: None
    return : JSON response with all UserTable
    
    '''

    bugs={}


    get_user_data,bugs_local = all_user_records()

    if bugs_local:
        logger_1.info("Failed to fetch all users: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)   
        bugs = s_bugs(bugs) 

            
    elif get_user_data is not None:

        logger_1.info(f"all users are {get_user_data}")
        
        # Format user data using Pydantic model
        formatted_users = Users_Serializer.from_dataframe(get_user_data)

        return {"users": formatted_users.model_dump()}

    return JSONResponse({"error" : "Failed to fetch all users"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    





# endpoint to get all teams
@router.get("/getallteams/",dependencies=[Depends(JWTBearer())])
async def get_all_teams():
    '''
    Endpoint to get all teams

    params: None
    return : JSON response with all teams
    
    '''

    bugs={}

    team_data,bugs_local = all_teams_records()

    if bugs_local:
        logger_1.info("Failed to fetch all teams: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)   
        bugs = s_bugs(bugs) 

        
    elif team_data is not None:

        # Serialize team data using Pydantic model
        formatted_teams = Teams_Serializer(
            team_id=team_data['id'].tolist(),
            team_name=team_data['team_name'].tolist()
        )

        return {"teams": formatted_teams.model_dump()}


    return JSONResponse({"error" : "Failed to fetch all teams"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




# endpoint to create a user only for the superuser
@router.post("/createemp/")
async def create_employee(user: CreateUserModel):
    '''
    Endpoint to create a user in the user table

    params: email, phone_number, team_id, requested_user_id
    return : JSON response with the user created 201 status code
    
    '''

    bugs = {}


    # check if the requested user is a superuser
    check_is_superuser,bugs_local = check_if_superuser(user_id=user.requested_user_id)

    if bugs_local:
        logger_1.info("Failed to check if user is superuser: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    
    elif check_is_superuser == False:
        return JSONResponse({"error" : "Sorry, you are not authorized to create a user"},status_code=http_status.HTTP_401_UNAUTHORIZED)
        
    # check if the user exists with the provided email and phone number
    check_user,bugs_local = check_user_exists(email=user.email,phone_number=user.phone_number)

    if bugs_local:
        logger_1.info("Failed to check user exists: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif check_user is not None:
        return JSONResponse({"error" : "User already exists with the provided email and phone number"},status_code=http_status.HTTP_409_CONFLICT)
    
    else:

        # create the user
        new_user_id,bugs_local = rds_instance.create_record_in_table(
            table_model=Employee,
            email_id=user.email,
            username=user.email,
            phone_number=user.phone_number,
            user_team=user.team_id,
            designation=user.designation,
            is_superuser=user.is_superuser
        ) 

        if bugs_local:
            logger_1.info("Failed to create user: " + str(bugs_local))
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)

            return JSONResponse({"error" : "Failed to create user"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif new_user_id is not None:
            logger_1.info(f"new user id is {new_user_id}")
            redis_instance.delete_key(key="all_users_cached")
            return JSONResponse({"message" : "User created successfully"},status_code=http_status.HTTP_201_CREATED)

    return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# endpoint to sign up a user
@router.post("/createuser/")
async def sign_up(user: SignUpModel):

    '''
    Endpoint to sign up a user. This api checks if a user record with the provided combo of email and phone number exists.
    Only if it does, the user is allowed to assign a password and username to the account.
    similarly the user will be allowed to update the user record with first name, last name
    
    params: email, password, first_name, last_name, phone_number, team_id, designation
    return : JSON response with the user signed in successfully with 200 status code

    
    '''
    bugs = {}


    # check if the user exists with the provided email and phone number
    check_user,bugs_local = check_user_exists(email=user.email_id,phone_number=user.phone_number) 

    if bugs_local:
        logger_1.info("Failed to check user exists: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    elif check_user is None:
        return JSONResponse({"message" : "You are not allowed to sign up.Please contact admin"},status_code=http_status.HTTP_404_NOT_FOUND)
        
    # check if any other users have the same username
    check_username,bugs_local = check_username_taken(username=user.username) 

    if bugs_local:
        logger_1.info("Failed to check username exists: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


    elif check_username == True:
        return JSONResponse({"message" : "Username already taken"},status_code=http_status.HTTP_409_CONFLICT)
    

    # check if the user is already signed up
    check_signup,bugs_local = check_user_already_signed_up(user_id=check_user['id'])

    if bugs_local:
        logger_1.info("Failed to check if user is already signed up: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    elif check_signup == True:
        return JSONResponse({"message" : "User already signed up"},status_code=http_status.HTTP_406_NOT_ACCEPTABLE)
    
    else:

        
        # call update record in table to update the user record
        update_user,bugs_local = rds_instance.update_record_in_table(
            table_model=Employee,
            record_id=check_user['id'],
            username=user.username,
            password=user.password,
            first_name=user.first_name,
            last_name=user.last_name,
            phone_number=user.phone_number,
            emergency_contact_name=user.emergency_contact_name,
            emergency_contact_number=user.emergency_contact_number,
            alternate_phone_number=user.alternate_phone_number,
            personal_email=user.personal_email
        )

        if bugs_local:
            logger_1.info("Failed to update user record: " + str(bugs_local))
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)

            return JSONResponse({"error" : "Failed to sign up, unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif update_user is not None:
            redis_instance.delete_key(key="all_users_cached")
            return JSONResponse({"message" : "User signed up successfully"},status_code=http_status.HTTP_200_OK)
    
    return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



    
@router.post("/login/")
async def user_login(user: LoginUserModel,response: Response):

    bugs = {}

    check_credentials,bugs_local = check_credentials_are_valid(username=user.username,password=user.password)

    if bugs_local:
        logger_1.info("Failed to check credentials: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error": "Login failed, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
    elif check_credentials == False:
        logger_1.info("Invalid credentials")
        return JSONResponse({"error" : "Invalid credentials"},status_code=http_status.HTTP_401_UNAUTHORIZED) 
    
  
    token,bugs_local = sign_jwt(user.username)

    if bugs_local:
        logger_1.info("Failed to sign JWT: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error": "Login failed, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif token is not None:

        user_details, bugs_local = get_user_details(username=user.username)

        if bugs_local:
            logger_1.info("Failed to get user details: " + str(bugs_local))
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)

            # Fallback response in case none of the conditions above were met
            return JSONResponse({"error": "Login failed, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif user_details is not None:
        
            # Calculate expiration time for the cookie (30 minutes from now)
            expires = datetime.utcnow() + timedelta(minutes=30)
            
            # Set the access token in the cookie
            response.set_cookie(
                key="access_token",
                value=token,
                httponly=True,
                max_age=1800,  # 30 minutes
                samesite='Lax',
                secure=False  # Set to True in production with HTTPS
            )
            
            # get a refresh token
            refresh_token,bugs_local = sign_refresh_token(user.username)
            
            if bugs_local:
                logger_1.info("Failed to sign refresh token: " + str(bugs_local))
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)

                return JSONResponse({"error": "Login failed, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif refresh_token is not None:
                # Set the refresh token in the cookie
                response.set_cookie(
                    key="refresh_token",
                    value=refresh_token,
                    httponly=True,
                    max_age=86400,  # 24 hours
                    samesite='Lax',
                    secure=False  # Set to True in production with HTTPS
                )

            return {"user" : user_details}
        
     # Fallback response in case none of the conditions above were met
    return JSONResponse({"error": "Login failed, unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




    


@router.post("/logout/")
async def logout(response: Response):
    try:
        # Attempt to delete the access token cookie
        response.delete_cookie(key="access_token")
        return {"message": "Successfully logged out!"}
    except Exception as e:
        # Log the exception if needed
        logger_1.info(f"Failed to logout: {str(e)}")
        # Fallback message if there's an error during logout
        return JSONResponse({"error": "Failed to log out, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



    

# endpoint to check if a username is taken in live. This is used in the sign up process
@router.post("/checkusername/")
async def check_username(user : UsernameCheck):
    '''
    Endpoint to check if a username is taken

    params: username
    return : JSON response with the username status
    
    '''
    bugs = {}

    available = False

    check_username,bugs_local = check_username_taken(username=user.username)

    if bugs_local:
        logger_1.info("Failed to check username exists: " + str(bugs_local))
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error" : "Unknown error occured, please try again later"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    elif check_username == True:
        available = True

    return available




# API endpoint to check if an access token is about to expire within 5 minutes
@router.get("/checktoken/")
async def check_token(request: Request):
    """
    Endpoint to check if an access token is about to expire

    params: token (from cookies)
    return: JSON response with the token status
    """
    try:
        # Get the token from the cookies
        token = request.cookies.get('access_token')
                
        if not token:

            return JSONResponse(status_code=401, detail="Access token not found in cookies.")

        # Check if the token is about to expire
        is_expiring_soon,bugs_local = check_token_expiry(token)
        
        if bugs_local:
            logger_1.info("Failed to check token expiry: " + str(bugs_local))
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Unknown error occurred"}, status_code=500)
        
        elif is_expiring_soon is not None:
            return {"is_expiring_soon": is_expiring_soon}    
        
    except Exception as e:
        return JSONResponse({"error": "Unknown error occurred: " + str(e)}, status_code=500)


# API to refresh the access token
@router.post("/refresh_token/")
async def refresh_access_token(request: Request, response: Response):
    """
    Endpoint to refresh the access token using a valid refresh token

    Refresh token is obtained from HTTP-only cookie.
    Returns: New access token in an HTTP-only cookie if refresh token is valid.
    """
    try:
        # Get the refresh token from cookies
        refresh_token = request.cookies.get('refresh_token')
        
        if not refresh_token:
            raise JSONResponse(status_code=401, detail="Refresh token not found.")

        # Decode and validate the refresh token
        try:
            payload = jwt.decode(refresh_token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        except jwt.ExpiredSignatureError:
            raise JSONResponse(status_code=401, detail="Refresh token has expired.")
        except jwt.InvalidTokenError:
            raise JSONResponse(status_code=401, detail="Invalid refresh token.")

        # Generate new access token
        new_access_token,bugs_local = sign_jwt(payload["user_name"])

        if bugs_local:
            logger_1.info("Failed to sign JWT: " + str(bugs_local))
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Unknown error occurred"}, status_code=500)


        # Set the new access token in the response cookie
        response.set_cookie(
            key="access_token",
            value=new_access_token,
            httponly=True,
            max_age=1800, 
            secure=False,  # Set to True in production with HTTPS
            samesite='Lax'
        )

        return {"message": "Access token has been refreshed."}

    except Exception as e:
        return JSONResponse({"error": "Unknown error occurred: " + str(e)}, status_code=500)


