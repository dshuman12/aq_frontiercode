# Import inbuilt libraries
import io
import os

# Import third party libraries
from fastapi import APIRouter, Depends, File, UploadFile,status as http_status,Form,Response
from fastapi.responses import JSONResponse
from datetime import datetime
from typing import Optional,List


# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for feature tickets
lib_code_FT = "26"
lib_ver_FT = "00"

lib_code_ver_FT = f"{lib_code_FT}{lib_ver_FT}"



# Include custom libraries
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.data_models.rds_data_models.ticket_rds_models import *
from hiper_utils.data_models.rds_data_models.users_rds_models import Employee
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.common_schema import *
from utils.feature_tickets_util import *
from storage_settings import rds_instance,get_current_date,redis_instance
from schema.feature_ticket_schema import *
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from utils.slack_notify_utils import *
from utils.users_utils import return_emaiL

# Initialize the logger
logger_1 = LoggerFactory(name="feature_ticket_router_logs", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()


# Declare variables used 
env = load_dotenv()

# slack webhook url
slack_webhook_url = os.getenv("SLACK_WEBHOOK_URL")

# endpoints start here

# api endpoint to get all libraries from Library RDS
@router.get("/listmodules/", status_code=http_status.HTTP_200_OK)
async def list_all_libraries():
    '''
    Endpoint to get all the libraries from the Library RDS
    '''
    
    try:
        session = rds_instance.get_connection()

        with handle_session(session) as ns:

            modules = session.query(Libraries).all()


            modules_data = [
            {
                "id": module.id,
                "name": module.name,
                "owner": module.owner,
                "running_on": module.running_on,
                "team": module.team,
                "approver": module.approver,
                "version": module.version,
                "update_time": module.update_time,
                "status": module.status
            } for module in modules
            ]                

            return {'message': 'All libraries fetched' ,'response' : modules_data}

    except Exception as e:
        logger_1.error(f"Error occurred while fetching all libraries, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to fetch all libraries"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

@router.get("/getalltickets/", response_class=Response)
async def get_all_feature_tickets():
   
   
    bugs = {}


    try:
        # Call the function to fetch all feature ticket records
        all_feat_tickets, bugs_local = all_feat_records()

        if bugs_local:
            logger_1.error(f"Failed to fetch all records, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return Response(content="Failed to fetch all records", status_code=500, media_type="text/plain")
        
        elif all_feat_tickets is not None:
        
            # Convert DataFrame to CSV
            csv_buffer = io.StringIO()
            all_feat_tickets.to_csv(csv_buffer, index=False)
            csv_data = csv_buffer.getvalue()

            # Return CSV data
            return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": "attachment;filename=feature_tickets.csv"})

    except Exception as e:
        logger_1.error(f"Error occurred while fetching all feature tickets, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to fetch all feature tickets"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



    



@router.get("/getsingleticket/6/")
async def get_single_ticket(ticketid : int):

    bugs = {}

    try:

        ticket, bugs_local = fetch_and_cache_ticket(ticketid,6)

        logger_1.info(f"Ticket fetched successfully, {ticket}")

        if bugs_local:
            logger_1.info(f"Failed to fetch the ticket,{bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to fetch feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket is not None:
            return {"ticket_data" : ticket}

    except Exception as e:
        return JSONResponse({"error": "Unknown error occurred, failed to fetch feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)        

@router.post("/createfeatreq/", status_code=http_status.HTTP_201_CREATED)
async def create_feature_ticket( feature_name: str = Form(..., description="Name of the feature"),
    added_by: int = Form(..., description="ID of the user who added the feature"),
    description: str = Form(..., description="Description of the feature"),
    priority: int = Form(..., description="Priority of the feature"),
    team: int = Form(..., description="ID of the team responsible for the feature"),
    owner: Optional[int] = Form(None, description="ID of the user the feature ticket is assigned to, if any"),
    requested_eta: Optional[datetime] = Form(None, description="Requested ETA for the feature"),
    requirement: Optional[str] = Form(None, description="Requirement for the feature"),
    modules : Optional[str] = Form(None, description="List of module IDs related to the feature"),
    attachments : List[UploadFile] = File(None)
    ):
  
  
    '''
    Endpoint for creating a feature ticket

    params : feature_name, added_by, description, priority, team
    optional params : owner, requested_eta, modules, requirement

    '''
   

    bugs = {}


    try:

        # Parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []

        # create an instance of Create Feature Ticket 
        ticket = Create_Feature_Ticket_Input(
            feature_name=feature_name,
            added_by=added_by,
            description=description,
            owner=owner,
            team=team,
            priority=priority,
            requested_eta=requested_eta.strftime("%d-%m-%Y %H:%M:%S") if requested_eta else calculate_seven_days(),
            requirement=requirement,
            modules=modules_list,
            attachments=attachments
        )

        # modules will come a string "[1,2,3]", convert it to a single string "1,2,3"
        modules_to_rds = ",".join([str(x) for x in ticket.modules])


        # call create record in rds
        session = rds_instance.get_connection()

        with handle_session(session) as ns:
            
            added_by_superuser = True if ns.query(Employee).filter(Employee.id == added_by).first().is_superuser else 0

            logger_1.info(f"added by superuser is {added_by_superuser}")
                    
            
            new_feature_req = FT_RDS(
                ticket_name = ticket.feature_name,
                added_by = ticket.added_by, 
                assigned_to = ticket.owner,
                added_on = get_current_date(),
                priority = ticket.priority,
                approved_status = 0,
                approved_on = get_current_date() if ticket.added_by == ticket.owner else None, 
                deadline = requested_eta,
                assigned_team = ticket.team,
                status = 2 if ticket.added_by == ticket.owner else 0,
                group_id = None,
                libraries = modules_to_rds
            )

            ns.add(new_feature_req)  # Add the new record to the session
            ns.commit()  # Commit the transaction
            ns.flush()  # Synchronize the session with the database
            ticket_to_rds = new_feature_req.id  # Access the newly created ID
            logger_1.info(f"New feature ticket created with ID: {ticket_to_rds}")      

            # call create_ticket_in_s3 function
            ticket_to_s3,bugs_local = create_ticket_in_s3(ticket_to_rds,ticket,added_by_superuser)

            if bugs_local:
                logger_1.info(f"Failed to create the ticket in s3, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                # delete the record from rds
                ns.delete(new_feature_req)
                ns.commit()
                return JSONResponse({"error": "Failed to create feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif ticket_to_s3 is not None:
                # invalidate the rds_feat_tickets_cached
                redis_instance.delete_key('rds_feat_tickets_cached')
                
                # get the email of the owner
                owner_email = return_emaiL(ticket.owner)
                
                logger_1.info(f"Owner email is {owner_email}")
                
                assingee_email = return_emaiL(ticket.added_by)
                     
                # call notify slack function
                #status = notify_slack(ticket_title=ticket.feature_name, assigned_to_email=owner_email, assigned_by_email=assingee_email, ticket_url=f"https://dxlq5q0lkehfz.cloudfront.net/single-tickets/{ticket_to_rds}", ticket_type="Feature Ticket")
                
                # if status == False:
                #     logger_1.error(f"Failed to send message to slack channel, {bugs_local}")
                #     return JSONResponse({"error": "Failed to create feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
                
                # elif status == True:
                return {"message" : "Feature ticket created successfully", "ticket_data" : ticket_to_s3}
            
                
    except Exception as e:
        logger_1.error(f"Error occurred while creating the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to create feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)    



    
   
# api endpoint for updating a feature ticket
@router.patch("/updateticket/", status_code=http_status.HTTP_200_OK)
async def update_feat_ticket(ticket : UpdateFeatureTicket):
    '''
    Endpoint for updating a feature ticket

    params : ticket_id , updated_by
    optional params : feature_name, description, priority, team, owner, requested_eta, modules, requirement, status
        
    '''

    bugs = {}

    try:

        # call check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = ticket.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_approved == False:

            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = ticket.ticketid, userid = ticket.updated_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
            
        # call update ticket service
        updated_ticket, bugs_local = push_updates_to_rds_cache(ticket)

        if bugs_local:
            logger_1.error(f"Updating the rds cache failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:

                # call ticket update service function and perform the changes to s3 ticket
                updated_ticket, bugs_local = update_feat_ticket_fields(ticket)

                if bugs_local:
                    logger_1.error(f"Updating the ticket in s3 failed, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
                
                elif updated_ticket is not None:
                    return {"message" : "Ticket updated successfully", "ticket_data" : updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while updating the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



#### Requirement endpoints ####
# edit requirement
@router.put("/editrequirement/{blockid}/", status_code=http_status.HTTP_200_OK)
async def edit_requirement(blockid : int, requirement : EditRequirement):
    '''
    Endpoint to edit a requirement block in a feature ticket

    params: ticketid, updated_by, requirement_text
    return: returns 200 OK if requirement block is edited, 500 if Internal Server Error
    
    '''

    bugs = {}

    try:

        # call the edit_requirement_in_s3 function
        updated_ticket_data,bugs_local = edit_requirement_in_s3(blockid,requirement)

        if bugs_local:
            logger_1.error(f"Editing requirements failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        else:
            return {"message" : "Requirement edited successfully", "ticket_data" : updated_ticket_data}

    except Exception as e:
        logger_1.error(f"Error occurred while editing the requirement, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update requirement"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




#### Subfeature endpoints ####

# add subfeature
@router.post("/addsubfeature/", status_code=http_status.HTTP_200_OK)
async def add_subfeature_block(ticketid: int = Form(..., description="ID of the feature ticket"),
                               added_by: int = Form(..., description="ID of the user who added the subfeature"),
                               sub_feature_name: str = Form(..., description="Name of the subfeature"),
                               sub_feature_description: str = Form(..., description="Description of the subfeature"),
                               modules: str = Form(None, description="List of module IDs related to the subfeature"),
                               attachments : List[UploadFile] = File(None)
                               ):
    '''

    Endpoint to add a subfeature to a feature ticket

    params: ticketid, added_by, sub_feature_name, sub_feature_description, module_id
    return: returns 200 OK if subfeature block is added, 500 if Internal Server Error
    
    '''    

    bugs = {}

    try:

        # Parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []

        subfeature = AddSubfeature(
            ticketid = ticketid,
            added_by = added_by,
            sub_feature_name = sub_feature_name,
            sub_feature_description = sub_feature_description,
            modules = modules_list,
            attachments=attachments
        )

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = subfeature.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_approved == False:
                
                # call check user has permission
                user_has_permission, bugs_local = check_user_has_permissions(ticketid = subfeature.ticketid, userid = subfeature.added_by, ticket_type = 6)
        
                if bugs_local:
                    logger_1.error(f"Checking user permission failed, {bugs_local}")
                    bugs = c_bugs(bugs,bugs_local)
                    bugs = s_bugs(bugs)
                    return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
                elif user_has_permission == False:
                    return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
                

        # call the add_subfeature_to_s3 function
        updated_ticket_data,bugs_local = add_subfeature_to_ticket(subfeature)

        if bugs_local:
            logger_1.error(f"Adding the subfeature to the feat ticket in s3 failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif updated_ticket_data is not None:
            return {"message" : "Subfeature added successfully", "ticket_data" : updated_ticket_data}

    except Exception as e:
        logger_1.error(f"Error occurred while adding the subfeature, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add subfeature"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



    
# edit subfeature block
@router.put("/editsubfeature/{blockid}/", status_code=http_status.HTTP_200_OK)
async def edit_subfeature_block(blockid : int , ticketid: int = Form(..., description="ID of the feature ticket"),
                                updated_by: int = Form(..., description="ID of the user who updated the subfeature"),
                                sub_feature_name: str = Form(None, description="Name of the subfeature"),
                                sub_feature_description: str = Form(None, description="Description of the subfeature"),
                                modules: str = Form(None, description="List of module IDs related to the subfeature")):
    
    '''
    Endpoint to edit a subfeature block in a feature ticket

    params: ticketid, updated_by
    optional params: sub_feature_name, sub_feature_description, module_id
    return: returns 200 OK if subfeature block is edited, 500 if Internal Server Error
    
    
    '''

    bugs = {}

    try:

        # parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []
        
        subfeature = EditSubfeature(
            ticketid = ticketid,
            updated_by = updated_by,
            sub_feature_name = sub_feature_name,
            sub_feature_description = sub_feature_description,
            modules = modules_list
        )

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = subfeature.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


        elif ticket_approved == False:
            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = subfeature.ticketid, userid = subfeature.updated_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)

        # call the edit_subfeature_in_s3 function
        updated_ticket_data,bugs_local = edit_subfeature_in_ticket(blockid,subfeature)

        if bugs_local:
            logger_1.error(f"Editing the subfeature failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_data is not None:
            return {"message" : "Subfeature edited successfully", "ticket_data" : updated_ticket_data}

    except Exception as e:
        logger_1.error(f"Error occurred while editing the subfeature, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update subfeature"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
   


# delete subfeature block
@router.post("/delsubfeature/", status_code=http_status.HTTP_200_OK)
async def delete_subfeature_block(subfeature : DeleteSubfeature):
    ''''
    Endpoint to delete a subfeature block in a feature ticket

    params: ticketid, deleted_by, blockids
    return: returns 200 OK if subfeature block is deleted, 500 if Internal Server Error
    
    '''

    bugs = {}

    try:

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = subfeature.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif ticket_approved == False:
                    
            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = subfeature.ticketid, userid = subfeature.deleted_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
            

        # call the delete_subfeature_from_s3 function
        updated_ticket_data,bugs_local = delete_subfeature_from_ticket(subfeature)

        if bugs_local:
            logger_1.error(f"Deleting the subfeature from the feat ticket in s3 failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_data is not None:
            return {"message" : "Subfeature deleted successfully", "ticket_data" : updated_ticket_data}

    except Exception as e:
        logger_1.error(f"Error occurred while deleting the subfeature, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to delete subfeature"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)    


 

### Prototype Endpoints ###

# add prototype 
@router.post("/addprototype/", status_code=http_status.HTTP_200_OK)
async def add_prototype_block(ticketid: int = Form(..., description="ID of the feature ticket"),
                               added_by: int = Form(..., description="ID of the user who added the prototype"),
                               prototype_description: str = Form(..., description="Description of the prototype"),
                               related_sub_feature_block: int = Form(..., description="ID of the subfeature block"),
                               stage: int = Form(None, description="Stage of the prototype"),
                               modules: str = Form(None, description="List of module IDs related to the prototype"),
                               attachments : List[UploadFile] = File(None)
                               ):
    '''
    Endpoint to add a prototype to a feature ticket

    params: ticketid, added_by, prototype_description,related_sub_feature_block
    optional params : stage,modules
    return: returns 200 OK if prototype block is added, 500 if Internal Server Error
    
    '''

    bugs = {}

    try:

        # parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []

        prototype = AddPrototype(
            ticketid = ticketid,
            added_by = added_by,
            prototype_description = prototype_description,
            related_sub_feature_block = related_sub_feature_block,
            modules = modules_list,
            attachments=attachments
        )

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = prototype.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_approved == False:
            
            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = prototype.ticketid, userid = prototype.added_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
            

        # call the add_prototype_to_s3 function
        updated_ticket_data,bugs_local = add_prototype_to_ticket(prototype)

        if bugs_local:
            logger_1.error(f"Adding the prototype failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_data is not None:
            return {"message" : "Prototype added successfully", "ticket_data" : updated_ticket_data}

    except Exception as e:
        logger_1.error(f"Error occurred while adding the prototype, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add prototype"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# edit prototype
@router.put("/editprototype/{blockid}/", status_code=http_status.HTTP_200_OK)
async def edit_prototype_block(blockid : int , ticketid: int = Form(..., description="ID of the feature ticket"),
                                updated_by: int = Form(..., description="ID of the user who updated the prototype"),
                                prototype_description: str = Form(None, description="Description of the prototype"),
                                related_sub_feature_block: int = Form(None, description="ID of the subfeature block"),
                                stage: int = Form(None, description="Stage of the prototype"),
                                modules: str = Form(None, description="List of module IDs related to the prototype"),
                                itterations : int = Form(None, description="Number of itterations")
                                ):
    
    '''
    Endpoint to edit a prototype block in a feature ticket

    params: ticketid, updated_by
    optional params: prototype_description, related_sub_feature_block, stage, modules
    return: returns 200 OK if prototype block is edited, 500 if Internal Server Error
    
    '''

    bugs = {}


    try:
        # parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []

        prototype = EditPrototype(
            ticketid = ticketid,
            updated_by = updated_by,
            prototype_description = prototype_description,
            related_sub_feature_block = related_sub_feature_block,
            stage = stage,
            modules = modules_list,
            itterations = itterations
        )

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = prototype.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_approved == False:

            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = prototype.ticketid, userid = prototype.updated_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
            
        # call the edit_prototype_in_s3 function
        updated_ticket_data,bugs_local = edit_prototype_in_ticket(blockid,prototype)

        if bugs_local:
            logger_1.error(f"Editing the prototype in the feat ticket in s3 failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_data is not None:
            return {"message" : "Prototype edited successfully", "ticket_data" : updated_ticket_data}
        
    except Exception as e:
        logger_1.error(f"Error occurred while editing the prototype, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update prototype"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




# delete prototype block
@router.post("/delprototype/", status_code=http_status.HTTP_200_OK)
async def delete_prototype_block(prototype : DeletePrototype):
    '''
    Endpoint to delete a prototype block in a feature ticket

    params: ticketid, deleted_by, block_ids
    return: returns 200 OK if prototype block is deleted, 500 if Internal Server Error
    
    '''

    bugs = {}

    try:

        # call the check ticket is approved function
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid = prototype.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_approved == False:
            
            # call check user has permission
            user_has_permission, bugs_local = check_user_has_permissions(ticketid = prototype.ticketid, userid = prototype.deleted_by, ticket_type = 6)

            if bugs_local:
                logger_1.error(f"Checking user permission failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif user_has_permission == False:
                return JSONResponse({"error": "You are not allowed to update the ticket."}, status_code=http_status.HTTP_401_UNAUTHORIZED)
            
        # call the delete_prototype_from_s3 function
        updated_ticket_data,bugs_local = delete_prototype_from_ticket(prototype)

        if bugs_local:
            logger_1.error(f"Deleting the prototype failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_data is not None:
            return {"message" : "Prototype deleted successfully", "ticket_data" : updated_ticket_data}

        return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)        

    except Exception as e:
        logger_1.error(f"Error occurred while deleting the prototype, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to delete prototype"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# api endpoint to approve a feature ticket
@router.patch("/approveticket/", status_code=http_status.HTTP_200_OK)
async def approve_feat_ticket(ticket : ApproveFeatTicketInput):
    '''
    Endpoint to approve a feature ticket. Only available to the approver or manager
    
    params : ticket_id, approver_id
    return : ticket object with ticket details and ticket data
    
    '''
    bugs = {}

    try:
        
        # check if the user is a superuser or manager of the team
        user_is_superuser, bugs_local = check_if_user_has_approval_rights(ticketid=ticket.ticketid, userid=ticket.user_id)

        if bugs_local:
            logger_1.error(f"Checking if user is superuser failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to approve ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        

        elif user_is_superuser == False:
            return JSONResponse({"error": "You do not have sufficient permission to perform this action"}, status_code=http_status.HTTP_401_UNAUTHORIZED)
        

        # call the check ticket is closed function
        ticket_closed, bugs_local = check_if_ticket_is_closed(ticketid = ticket.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking if ticket is closed failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to approve ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_closed == True:
            return JSONResponse({"error": "Ticket is already closed"}, status_code=http_status.HTTP_400_BAD_REQUEST)


        # call the approve_ticket function
        approved_ticket, bugs_local = mark_ticket_as_approved(ticketid = ticket.ticketid, approver_id = ticket.user_id)

        if bugs_local:
            logger_1.error(f"Approving the ticket failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to approve ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif approved_ticket is not None:
            return {"message" : "Ticket approved successfully", "ticket_data" : approved_ticket}
        
    except Exception as e:
        logger_1.error(f"Error occurred while approving the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to approve feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)  
    

# api endpoint to reject a feature ticket
@router.patch("/rejectticket/", status_code=http_status.HTTP_200_OK)
async def reject_feat_ticket(ticket : RejectFeatTicketInput):
    '''
    Endpoint to reject a feature ticket. Only available to the approver or manager

    params : ticketid, user_id, notes
    return : ticket object with ticket details and ticket data
    
    '''

    bugs = {}

    try:

        # check if the user is a superuser or manager of the team
        user_is_superuser, bugs_local = check_if_user_has_approval_rights(ticketid=ticket.ticketid, userid=ticket.user_id)

        if bugs_local:
            logger_1.error(f"Checking if user is superuser failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to reject ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        

        elif user_is_superuser == False:
            return JSONResponse({"error": "You do not have sufficient permission to perform this action"}, status_code=http_status.HTTP_401_UNAUTHORIZED)
        

        # call the check ticket is closed function
        ticket_closed, bugs_local = check_if_ticket_is_closed(ticketid = ticket.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking if ticket is closed failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to reject ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_closed == True:
            return JSONResponse({"error": "Ticket is already closed"}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        
        # call the approve_ticket function
        rejected_ticket, bugs_local = mark_ticket_as_rejected(ticket = ticket)

        if bugs_local:
            logger_1.error(f"Rejecting the ticket failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to reject ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif rejected_ticket is not None:
            return {"message" : "Ticket rejected successfully", "ticket_data" : rejected_ticket}
        
    except Exception as e:
        logger_1.error(f"Error occurred while rejecting the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to reject feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

# api endpoint to close a feature ticket
@router.patch("/closeticket/", status_code=http_status.HTTP_200_OK)
async def close_feat_ticket(ticketid : int = Form(..., description="ID of the feature ticket"),
                            user_id : int = Form(..., description="ID of the user who is closing the ticket"),
                            req_summary : Optional[str] = Form(None, description="Summary of the requirements"),
                            proto_summary : Optional[str] = Form(None, description="Summary of the prototypes"),
                            sub_feat_summary : Optional[str] = Form(None, description="Summary of the subfeatures"),
                            release_notes : Optional[str] = Form(None, description="Release notes"),
                            future_imp : Optional[str] = Form(None, description="Future improvements"),
                            learnings : Optional[str] = Form(None, description="Learnings")):
    
    '''
    Endpoint to close a feature ticket. 

    params : ticketid, user_id
    optional params : req_summary,proto_summary,sub_feat_summary,release_notes,future_imp,learnings
    return : ticket object with ticket details and ticket data
    
    '''

    bugs = {}

    try:

        # create an instance of closefeatticketinput
        close_ticket = CloseFeatTicketInput(
            ticketid = ticketid,
            user_id = user_id,
            req_summary = req_summary,
            proto_summary = proto_summary,
            sub_feat_summary = sub_feat_summary,
            release_notes = release_notes,
            future_imp = future_imp,
            learnings = learnings
        )
        

        # call the check_if_ticket_is_closed function
        ticket_closed, bugs_local = check_if_ticket_is_closed(ticketid = close_ticket.ticketid, ticket_type = 6)

        if bugs_local:
            logger_1.error(f"Checking if ticket is closed failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_closed == True:
            return JSONResponse({"error": "Ticket is already closed"}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        
        # check if the user is a superuser by calling the check_if_superuser
        superuser_rights, bugs_local = check_if_superuser(close_ticket.user_id)
        
        if bugs_local:
            logger_1.error(f"Checking if user is superuser failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif superuser_rights == True:
           # call mark_ticket_as_closed function
            closed_ticket, bugs_local = mark_ticket_as_closed(close_ticket)

            if bugs_local:
                logger_1.error(f"Closing the ticket failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif closed_ticket is not None:
                return {"message" : "Ticket closed successfully", "ticket_data" : closed_ticket} 
            

        # call has_subfeature_blocks function
        has_subfeature, bugs_local = has_subfeature_blocks(ticketid = close_ticket.ticketid)

        if bugs_local:
            logger_1.error(f"Checking if ticket has subfeature blocks failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif has_subfeature == False:
            return JSONResponse({"error": "No subfeature blocks found in the ticket"}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        
        # call the validate_subfeatures_have_prototypes function
        subfeatures_have_atleast_a_prototype, bugs_local = validate_subfeatures_have_prototypes(ticketid = close_ticket.ticketid)

        if bugs_local:
            logger_1.error(f"Validating subfeatures have prototypes failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif subfeatures_have_atleast_a_prototype == False:
            return JSONResponse({"error": "No prototype blocks found in the ticket"}, status_code=http_status.HTTP_400_BAD_REQUEST)


        # call validate_prototype_stages
        prototype_stages_valid, bugs_local = validate_prototype_stages(ticketid = close_ticket.ticketid)

        if bugs_local:
            logger_1.error(f"Validating prototype stages failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif prototype_stages_valid == False:
            return JSONResponse({"error": "Some prototypes are still in development or testing stage"}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # call verify_tasks_are_completed func to check if all tasks are completed
        tasks_completed, bugs_local = verify_tasks_are_completed(ticketid = close_ticket.ticketid)

        if bugs_local:
            logger_1.error(f"Verifying tasks are completed failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif tasks_completed == False:
            return JSONResponse({"error": "Some tasks are still pending"}, status_code=http_status.HTTP_400_BAD_REQUEST)

        # call mark_ticket_as_closed function
        closed_ticket, bugs_local = mark_ticket_as_closed(close_ticket)

        if bugs_local:
            logger_1.error(f"Closing the ticket failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to close ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif closed_ticket is not None:
            return {"message" : "Ticket closed successfully", "ticket_data" : closed_ticket}
        
    except Exception as e:
        logger_1.error(f"Error occurred while closing the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to close feature ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)





# API Endpoint to approve or reject a feature ticket
@router.patch("/updateapprovalfeatureticket/", status_code=http_status.HTTP_200_OK)
async def update_approval_feature_ticket(input : Approve_or_Reject_Feature_Ticket):
    """
    Endpoint to approve or reject a feature ticket.

    Params:
    - ticket_id: ID of the feature ticket to update approval status.
    - approved_by: ID of the user updating the approval.
    - approved: Approval status, 1 for approved, -1 for rejected.
    """

    bugs = {}

    try:

        # Check if the ticket is already approved or rejected
        ticket_approved, bugs_local = check_ticket_is_approved(ticketid=input.ticketid, ticket_type=6)
        
        logger_1.info(f"Checking ticket approval status, {ticket_approved}")

        if bugs_local:
            logger_1.error(f"Checking ticket approval failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."},
                                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        if ticket_approved == True:
            return JSONResponse({"message": "Ticket is already approved."}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # create an instance of UpdateFeatureTicket
        data = UpdateFeatureTicket(
            ticketid=input.ticketid,
            updated_by=input.user_id,
            approved=input.approved
        )

        push_to_rds, bugs_local = push_updates_to_rds_cache(data)

        if bugs_local:
            logger_1.error(f"Updating RDS cache failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."},
                                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        if not push_to_rds:
            return JSONResponse({"error": "Failed to update ticket, RDS cache update unsuccessful."},
                                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

 
        updated_ticket, bugs_local = update_feat_ticket_fields(data)

        if bugs_local:
            logger_1.error(f"Updating S3 metadata failed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."},
                                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        if updated_ticket is not None:
            message = "Ticket approved successfully" if input.approved == 1 else "Ticket rejected successfully"
            return {"message": message, "ticket_data": updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while updating the approval status of the feature ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update feature ticket approval status."},
                            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


@router.delete("/deletefeatureticket/", status_code=http_status.HTTP_200_OK)
async def delete_feature_ticket(delete_request: DeleteFeatureTicket):
    """
    Endpoint to delete one or multiple feature tickets.

    Params:
    - delete_request: Pydantic model containing `ticket_ids` and `deleted_by`.
    """
    try:
        # Call the service function to process deletion
        response = await process_delete_feature_ticket(delete_request)
        return response
   
    except Exception as e:
        logger_1.error(f"Error occurred while deleting feature tickets, {e}")
        return JSONResponse({"error": "Unknown error occurred"},
                            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)