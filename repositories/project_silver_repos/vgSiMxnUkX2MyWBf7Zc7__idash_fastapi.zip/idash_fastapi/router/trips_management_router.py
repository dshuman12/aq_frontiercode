from fastapi import APIRouter, Depends, HTTPException
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB
from hiper_utils.Decoraters.exception_handler import combine_bugs
from typing import Dict
from utils.trips_utils import TripManagement
# Initialize Router
router = APIRouter()

# Initialize MySQLDB connection (update DB details as necessary)
db_instance = MySQLDB(db_name="new_production_schema", env_var_prefix="MYSQL")


@router.get("/trips/data-with-coordinates")
async def get_trip_data_with_coordinates(vehicle_id: str, start_date: str, end_date: str):
    """
    API endpoint to fetch trip data along with coordinates for a given vehicle and date range.

    :param vehicle_id: ID of the vehicle to fetch data for.
    :param start_date: Start date for filtering trips (YYYY-MM-DD).
    :param end_date: End date for filtering trips (YYYY-MM-DD).
    :return: Trip data combined with coordinates.
    """

    # Initialize TripManagement instance
    trip_manager = TripManagement(db_instance=db_instance, vehicle_id=vehicle_id)

    # Fetch trip data with coordinates
    trip_data_with_coordinates, bugs = trip_manager.get_trip_data_with_coordinates(start_date, end_date)

    # Handle bugs if any
    if bugs:
        raise HTTPException(status_code=500, detail=bugs)

    return trip_data_with_coordinates
