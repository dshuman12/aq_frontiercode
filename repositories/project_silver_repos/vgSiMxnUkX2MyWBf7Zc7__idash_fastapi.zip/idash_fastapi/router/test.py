# Import inbuilt libraries





# Import third party libraries
from datetime import timedelta
import json
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, Form, HTTPException, UploadFile,status as http_status,Response
from fastapi.responses import JSONResponse
from fastapi import Query
from fastapi.responses import Response
import pandas as pd




# Include repos folder for custom libraries



# Declare variables used 

# Library Code for Users Module
lib_code_TM = "100"
lib_ver_TM = "00"

lib_code_ver_TM = f"{lib_code_TM}{lib_ver_TM}"



# Include custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.other_utils.resource_util import CRUDBase
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import Fleet as FL_RDS
from pydantic import BaseModel


router = APIRouter()

logger_1 = LoggerFactory(name="task_route", file_name="message.log").get_logger()


# ENDPOINTS START FROM HERE

# Initialize MySQLDB and CRUDBase
dev_db = MySQLDB(db_name="dev_schema", env_var_prefix="MYSQL_DEV")
crud = CRUDBase(db_instance=dev_db, model=FL_RDS)

# Pydantic models for request validation
class CreateRecord(BaseModel):
    fleet_name: str
    created_at : str
    num_of_vehicles: int
    distributor_id: int

class UpdateRecord(BaseModel):
    updates: Dict[str, Any]


@router.post("/create/")
async def create_record(record: CreateRecord):
    """
    Create a new record in the database.
    """
    success, bugs_local = crud.insert(record.dict())
    
    if bugs_local:
        logger_1.error(f"Failed to create the record , {bugs_local}")
        raise HTTPException(status_code=500, detail="Failed to insert record.")
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to insert record.")
    
    return {"message": "Record created successfully."}

@router.get("/read_records/")
async def read_records(
    filters: Optional[str] = Query(default=None, description="JSON string of filters"),
    columns: Optional[str] = Query(default=None, description="Comma-separated list of column names to retrieve")
):
    """
    Read records from the database table and return the result as a CSV.
    :param filters: JSON string representing filters (e.g., '{"num_of_vehicles": {"$gt": 2}}').
    :param columns: Comma-separated list of column names to retrieve (e.g., "fleet_name,num_of_vehicles").
    :return: CSV file as a downloadable response.
    """
  
  
    bugs = {}
  
    try:
        # Parse filters if provided
        parsed_filters = json.loads(filters) if filters else None

        # Parse columns as a list if provided
        parsed_columns = columns.split(",") if columns else None

        # Call the `read` function
        df,bugs_local = crud.read(filters=parsed_filters, columns=parsed_columns)

        if bugs_local:
            logger_1.error(f"Failed to read the table , {bugs_local}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch records: {bugs_local}")

        elif df.empty:
            raise HTTPException(status_code=404, detail="No records found.")

        # Convert the DataFrame to CSV
        csv_output = df.to_csv(index=False)

        # Return CSV as a downloadable response
        return Response(content=csv_output, media_type="text/csv", headers={
            "Content-Disposition": "attachment; filename=records.csv"
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching records: {str(e)}")
    
    

@router.put("/records/{record_id}")
async def update_record(record_id: int, record: UpdateRecord):
    """
    Update an existing record in the database.
    """
    success = crud.update(record_id=record_id, updates=record.updates)
    if not success:
        raise HTTPException(status_code=404, detail="Record not found or update failed.")
    return {"message": "Record updated successfully."}


@router.delete("/records/{record_id}")
async def delete_record(record_id: int):
    """
    Delete a record from the database.
    """
    success = crud.delete(record_id=record_id)
    if not success:
        raise HTTPException(status_code=404, detail="Record not found or delete failed.")
    return {"message": "Record deleted successfully."}