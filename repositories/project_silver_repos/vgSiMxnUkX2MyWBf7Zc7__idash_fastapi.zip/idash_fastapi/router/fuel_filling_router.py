import sys
from typing_extensions import List, Optional
import json

sys.path.append("../")

from fastapi import APIRouter, HTTPException, Query, Body, status, Response, Depends, UploadFile, File
from fastapi.responses import StreamingResponse
from fastapi_cache.decorator import cache
from fastapi_cache import FastAPICache
import pandas as pd

from utils.ops_dash_util import VehicleStatus, TripClassification, StratTable, DriverClassification, DeviceRegistration, \
    DeviceConfigFiles, RawLogFiles, RawPing, SysLog

from utils.fuel_filling_util import FuelFilling
from schema.ops_dash_schema import VehicleSummaryRequest, TripRecord, HWUno2Input, FuelFillingRecord
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path
from hiper_utils.Decoraters.exception_handler import serialize_bug_instance
from auth_bearer import JWTBearer
from hiper_utils.other_utils.redis_util import RedisUtil
from idash_fastapi.log_processing.vehicle_log_process_v2 import DeviceLogProcessor, LoggerFactory

router = APIRouter()


@router.post("/insert_fuel_filling_record")
async def insert_fuel_filling_record(slip_image: Optional[UploadFile] = File(None), fleet_name: str = Body(...),
                                     vehicle_num: str = Body(...), fuel_filling_record: str = Body()):
    fuel_filling_record = FuelFillingRecord(**json.loads(fuel_filling_record))

    fuel_filling_handler = FuelFilling(fleet_name=fleet_name, vehicle_num=vehicle_num)

    if slip_image is not None:

        file_bytes = await slip_image.read()
        file_extension = slip_image.filename.split(".")[-1]

        insert_record, insertion_bug = fuel_filling_handler.insert_fuel_filling_record(
            fuel_filling_record=fuel_filling_record,
            slip_image=file_bytes,
            slip_image_extension=file_extension
        )
    else:
        insert_record, insertion_bug = fuel_filling_handler.insert_fuel_filling_record(
            fuel_filling_record=fuel_filling_record
        )

    if not insert_record:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(insertion_bug))
    else:
        return insert_record


@router.post("/view_fuel_filling_record")
async def view_fuel_filling_record(fleet_name: str = Body(...),
                                   vehicle_num: str = Body(...)):
    fuel_filling_handler = FuelFilling(fleet_name=fleet_name, vehicle_num=vehicle_num)

    fuel_filling_df, fuel_filling_bug = fuel_filling_handler.get_fuel_filling_file()
    if fuel_filling_bug:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(fuel_filling_bug))
    else:
        fuel_filling_df.fillna('', inplace=True)
        fuel_filling_dict = fuel_filling_df.to_dict(orient='list')

        return fuel_filling_dict
