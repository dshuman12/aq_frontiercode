# Import inbuilt libraries


# Import third party libraries
from datetime import datetime
from fastapi import APIRouter, status as http_status
from fastapi.responses import JSONResponse


# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for automated trips library
lib_code_ATL = "54"
lib_ver_ATL = "00"

lib_code_ver_ATL = f"{lib_code_ATL}{lib_ver_ATL}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.auto_trips_schema import *
from utils.auto_trips_util import *
from utils.trip_automation import *
from hiper_utils.other_utils.vehicles_util import calculate_trip_metrics


# Initialize the logger
logger_1 = LoggerFactory(name="auto_trips_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()



# endpoints start here

@router.post("/get_trips/")
async def get_trips(veh: Get_AutoTrips_Input):
    """
    API to get all trips for a vehicle within a range

    Parameters:
     - veh : GetAutoTripsInput (vehicle_num, start_date, end_date)

    Returns:
    - JSONResponse: Message with trips or failure details
    
    """
    
    bugs = {}
    
    try:
      

        # Call the service to get filtered trips
        all_trips, bugs_local = get_filtered_trips(
            vehicle_number=veh.vehicle_num, 
            start_time=f"{veh.start_date} 00:00:00", 
            end_time=f"{veh.end_date} 23:59:59"
        )
        
        if bugs_local:
            logger_1.error(f"Error in get_filtered_trips: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                {"error": "Error fetching trips"},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )
            
        elif all_trips:
            logger_1.info(f"all trips are {all_trips}")
            
            # serialize datetime to string
            for trip in all_trips:
                trip["start_time"] = trip["start_time"].strftime("%Y-%m-%d %H:%M:%S")
                trip["end_time"] = trip["end_time"].strftime("%Y-%m-%d %H:%M:%S")
                
            return JSONResponse(
                {"message": "Trips fetched successfully", "trips": all_trips},
                status_code=http_status.HTTP_200_OK
            )
            
        else:
            return JSONResponse(
                {"error" : "No trips found"}
                ,status_code=http_status.HTTP_404_NOT_FOUND
            )

    
    except Exception as e:
        logger_1.error(f"Error while fetching trips: {e}")
        return JSONResponse(
            {"error": "An unknown error occurred", "details": str(e)},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    

# Endpoint to update a trip
@router.put("/update_trip/")
async def update_trip(trip: Update_Trip_Input):
    
    '''
    
    Endpoint to update a trip
    
    parameters : 
        - vehicle_number : str
        - trip_id : int
    
    optional_parameters :
        - remark : str
        - category : str
        - validate : bool
    
    
    '''
    
    bugs = {}
    
    
    try:
        
        # call update trip record func
        status, bugs_local = update_trip_record(trip.vehicle_number, trip.trip_id, trip.remark, trip.category, trip.verified)
        
        if bugs_local:
            logger_1.error(f"Error in update_trip_record: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                {"error": "Error updating trip"},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
            )
            
        elif status:
            return JSONResponse(
                {"message": "Trip updated successfully"},
                status_code=http_status.HTTP_200_OK
            )
        
    except Exception as e:
        logger_1.error(f"Error while updating trip: {e}")
        return JSONResponse(
            {"error": "An unknown error occurred", "details": str(e)},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )
        
          
@router.post("/form_trips/")
async def FORM_trips():
    """
    API Endpoint to fetch events and update trips for a given vehicle.

    Parameters:
    - vehicle_number: str (Vehicle number for which trips need to be updated)

    Returns:
    - JSONResponse: Updated trips table or an error message
    """
    try:
        # Call the function to fetch events and update trips
        trips_table, bugs_local = fetch_events_table_and_update_trips()

        if bugs_local:
            # Log bugs and return an error response
            logger_1.error(f"Bugs encountered while updating trips for vehicle : {bugs_local}")
            return JSONResponse(
                {"error": "Failed to update trips due to bugs", "bugs": bugs_local},
                status_code=500
            )
        
        if trips_table is None:
            return JSONResponse(
                {"message": f"No new trips found for vehicle."},
                status_code=200
            )
        
        # Convert DataFrame to a list of dictionaries
        #trips_list = trips_table.to_dict(orient="records")
        
        # Convert Timestamps to string format
        # for trip in trips_list:
        #     if "start_time" in trip and isinstance(trip["start_time"], pd.Timestamp):
        #         trip["start_time"] = trip["start_time"].strftime("%Y-%m-%d %H:%M:%S")
        #     if "end_time" in trip and isinstance(trip["end_time"], pd.Timestamp):
        #         trip["end_time"] = trip["end_time"].strftime("%Y-%m-%d %H:%M:%S")
        
        return JSONResponse(
            {"message": "Trips updated successfully", "trips": trips_table},
            status_code=200
        )
    
    except Exception as e:
        # Log the exception and return an error response
        logger_1.error(f"Error occurred while updating trips for vehicle: {e}")
        return JSONResponse(
            {"error" : f"Unknown error occured, {e}"},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )


from hiper_utils.other_utils.vehicles_util import calculate_trip_metrics

@router.get("/calculate-metrics")
def calculate_metrics_api(start_event_id: int, end_event_id: int, vehicle_number: str):
    """
    API endpoint to calculate fuel consumed, distance, and idle time for a given range of events.

    Args:
        start_event_id (int): Start event ID.
        end_event_id (int): End event ID.
        vehicle_number (str): Vehicle number.
        db (Session): Database session (dependency injection).

    Returns:
        dict: Contains calculated metrics for the specified event range.
    """
    try:
        # Call the function to calculate trip metrics
        metrics, bugs_local = calculate_trip_metrics(start_event_id, end_event_id, vehicle_number)

        # If bugs are encountered, include them in the response
        if bugs_local:
            logger_1.info(f"Calculating metrics failed, {bugs_local}")
            return JSONResponse({"error" : "Failed to calculate trip metrics"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
        return {"metrics": metrics}

    except Exception as e:
        logger_1.error(f"Unknwon error , {e}")
        # Handle unexpected errors
        return JSONResponse({"error" : "Unknown error"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    


from fastapi import FastAPI, UploadFile, HTTPException
from fastapi.responses import FileResponse
import pandas as pd
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
import os


from opencage.geocoder import OpenCageGeocode

# Replace with your OpenCage API key (free tier available)
API_KEY = "f17052dcd3ad4db39277cd2106988f82"
geocoder = OpenCageGeocode(API_KEY)

def geocode_location(location_name: str) -> tuple:
    """
    Geocode a location name into latitude and longitude using a geocoding service.
    """
    results = geocoder.geocode(location_name)
    if results:
        return results[0]['geometry']['lat'], results[0]['geometry']['lng']
    else:
        return None, None


@router.post("/convert-parquet-to-csv-with-geopy/")
async def convert_parquet_to_csv_with_geopy(file: UploadFile):
    """
    Convert a Parquet file to CSV and update 'start_location' and 'end_location' fields
    with latitude and longitude values.
    """
    # Ensure the uploaded file is a Parquet file
    if not file.filename.endswith(".parquet"):
        raise HTTPException(status_code=400, detail="Please upload a Parquet file.")
    
    # Save the uploaded Parquet file temporarily
    temp_parquet_path = f"temp_{file.filename}"
    with open(temp_parquet_path, "wb") as f:
        f.write(await file.read())
    
    # Convert Parquet to CSV with geocoding
    temp_csv_path = temp_parquet_path.replace(".parquet", ".csv")
    try:
        df = pd.read_parquet(temp_parquet_path)

        # Geocode start and end locations
        if "start_location" in df.columns and "end_location" in df.columns:
            df["start_location"] = df["start_location"].apply(
                lambda loc: f"{','.join(map(str, geocode_location(loc)))}" if loc else loc
            )
            df["end_location"] = df["end_location"].apply(
                lambda loc: f"{','.join(map(str, geocode_location(loc)))}" if loc else loc
            )
        
        # Save the updated DataFrame as a CSV file
        df.to_csv(temp_csv_path, index=False)
    except Exception as e:
        os.remove(temp_parquet_path)
        print(f"The error is {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process the file: {e}")
    
    # Clean up the Parquet file
    os.remove(temp_parquet_path)
    
    # Return the CSV file as a downloadable response
    return FileResponse(temp_csv_path, media_type="text/csv", filename=temp_csv_path)
