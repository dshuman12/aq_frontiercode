from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel, Field, root_validator
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from fastapi.encoders import jsonable_encoder
import cbor2

from utils.installation_util import LogConfig
from schema.insatllation_dash_schema import *
from auth_bearer import JWTBearer

import sys
import io
import zipfile
import json
import tempfile

sys.path.append("../")
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import MySQLDB
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import MakeModel

router = APIRouter()


@router.get("/hello")
async def say_hello():
    return {"message": "Hello from Installation Dashboard"}


@router.post("/create_log_config", dependencies=[Depends(JWTBearer())])
async def create_log_config(data: UserLogConfigForm):
    log_config_creator = LogConfig(make_model=data.make_model, remark_by_user=data.remark_by_user)
    server_log_config_file, device_log_config_file, device_log_config_bin = log_config_creator.create_log_config_file(
        user_submitted_data=data)
    print("=============== Genrated File =========================")
    print(server_log_config_file)

    make_model = data.make_model
    zip_buffer = io.BytesIO()

    with open('temp.bin', 'wb') as f:
        f.write(device_log_config_bin.encoded_imu_cfg)

    print("Saved local")

    config_version_generated = str(log_config_creator.version_to_assign).zfill(2)

    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_STORED) as zip_file:
        # Add the log config JSON file to the zip
        log_config_json = json.dumps(server_log_config_file.model_dump(), indent=4)
        zip_file.writestr(F"server_log_config_{make_model}_{config_version_generated}.json", log_config_json)

        device_log_config_json = json.dumps(device_log_config_file.model_dump(), indent=4)
        zip_file.writestr(f"device_log_config_{make_model}_{config_version_generated}.json", device_log_config_json)

        # Save binary file as well in the zip
        can_config_pth = f"can_config_{make_model}_{config_version_generated}.bin"
        imu_config_pth = f"imu_config_{make_model}_{config_version_generated}.bin"

        print("======= $$$$")
        print(device_log_config_bin.encoded_imu_cfg)
        zip_file.writestr(can_config_pth, device_log_config_bin.encoded_can_cfg)
        # zip_file.writestr(imu_config_pth, device_log_config_bin.encoded_imu_cfg)

        zip_file.write('temp.bin', imu_config_pth)

    # Seek to the beginning of the stream
    zip_buffer.seek(0)

    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(zip_buffer.read())

    # tmp_file_path = tmp_file.name

    headers = {
        "Content-Disposition": 'attachment; filename="log_config.zip"'
    }
    return StreamingResponse(iter([zip_buffer.getvalue()]), headers=headers, media_type='application/zip')


@router.get("/fetch_make_model", dependencies=[Depends(JWTBearer())])
async def fetch_make_model():
    prod_rds_instance = MySQLDB(
        db_name="new_production_schema",
        env_var_prefix="MYSQL"
    )
    session = prod_rds_instance.get_connection()

    query_result = session.query(MakeModel.make_model_id).all()

    make_model_list = [r.make_model_id for r in query_result]

    session.close()
    return make_model_list


# @router.get("/fetch_aggregate_options")
# async def fetch_aggregate_options():
#     return [option.value for option in AggregateDataEnum]

# @router.get("/fetch_encoding_types")
# async def fetch_encodings_options():
#     return [option.value for option in EncodingTypeEnum]

@router.get("/fetch_params", dependencies=[Depends(JWTBearer())])
async def fetch_params(make_model: str = Query(..., description="The make and model of the vehicle")):
    all_params = {
        'req_params': [],
        'broad_params': [],
        'gps_params': None,
        'i2c_params': None,
        'can_data_mode': [],
        'can_baud_rate': [],
        'imu_data_range': [],
        'imu_param_range': [],
        'analog_channel': [],
        'aggregate_data_type': [],
    }

    print("=====  ", make_model)
    log_config = LogConfig(make_model=make_model)

    can_param_list = log_config.fetch_can_param_list()

    if can_param_list is not None:
        req_param_df, broad_param_df = can_param_list

        all_params['req_params'] = {row[LogConfig.MASTER_PID_COLUMN]: row[LogConfig.PARAM_NAME_COLUMN] for ind, row in
                                    req_param_df.iterrows()}
        all_params['broad_params'] = {row[LogConfig.MASTER_PID_COLUMN]: row[LogConfig.PARAM_NAME_COLUMN] for ind, row in
                                      broad_param_df.iterrows()}

    all_params['gps_params'] = {option_id: option_label for option_id, option_label in GPS_PARAMS.items()}
    all_params['i2c_params'] = {option_id: option_label for option_id, option_label in IMU_PARAMAS.items()}

    # Populate enum data
    all_params['can_data_mode'] = {mode.id: mode.description for mode in CANDataMode}
    all_params['can_baud_rate'] = {rate.id: rate.description for rate in CANBaudRate}
    all_params['imu_data_range'] = {range.id: range.description for range in IMUDataRange}
    all_params['acc_full_scale_range'] = {range.id: range.description for range in AccelerometerFullScale}
    all_params['gyro_full_scale_range'] = {range.id: range.description for range in GyroscopeFullScale}
    all_params['analog_channel'] = {channel.id: channel.description for channel in AnalogChannel}
    all_params['aggregate_data_type'] = {option_id: option_label for option_id, option_label in AGG_OPTIONS.items()}

    return FetchParamsResponse(**all_params)
