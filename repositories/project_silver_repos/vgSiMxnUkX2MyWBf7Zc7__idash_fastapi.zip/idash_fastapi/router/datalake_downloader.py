# Import inbuilt libraries


# Import third party libraries
import io
import json
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List
import pandas as pd
from sqlalchemy import inspect
from sqlalchemy import Table, MetaData, select
from sqlalchemy.orm import sessionmaker

# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for datalake downloader library
lib_code_DDL = "22"
lib_ver_DDL = "00"

lib_code_ver_DDL = f"{lib_code_DDL}{lib_ver_DDL}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.datalake_downloader_schema import *
from hiper_utils.other_utils.resource_util import S3ResourceBase, CRUDBase
from storage_settings import prod_rds_instance
from hiper_utils.data_models.rds_data_models import *
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import Base
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from utils.datalake_downloader_util import *

# Initialize the logger
logger_1 = LoggerFactory(name="datalake_downloader_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()


# download the s3 file
@router.post("/")
async def download_s3_file(inputs: DownloadFile_Schema):
    """
    Downloads a file from S3 and returns it as a downloadable response.

    Params:
        - pth: Path to the S3 file

    Returns:
        - File as a downloadable content
    """

    bugs = {}

    try:
        # Call get_file function
        file_data, bugs_local = get_file(inputs.pth)

        if bugs_local:
            logger_1.error(f"Failed to get file: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                status_code=500,
                content={"error": "Failed to download the file"}
            )

        elif file_data is not None:
            # Extract filename from path
            file_name = inputs.pth.split("/")[-1]
            
            return StreamingResponse(
                file_data,
                media_type="application/octet-stream",
                headers={"Content-Disposition": f"attachment; filename={file_name}"}
            )

        else:
            return JSONResponse(
                status_code=404,
                content={"error": "File not found"}
            )

    except Exception as e:
        logger_1.error(f"Failed to download the file: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": "Unknown error occurred"}
        )


# function to list all table names
@router.get("/")
async def get_all_tables():
    
    '''
    
    To return the list of tables in the database
    
    params:
        - None
        
    returns:
        - List of table names
    
    
    '''
    
    try:
        
        session = prod_rds_instance.get_connection()  # Get a SQLAlchemy session

        inspector = inspect(session.bind)  # Bind session to inspector
        tables = inspector.get_table_names()
        
        return tables

    except Exception as e:
        logger_1.error(f"Failed to get all tables, {e}")                
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": "Unknown error occured"}
        )


@router.post("/rds/")
async def get_table_data(inputs: Read_RDSTable):
    """
    API Endpoint to return paginated records from an RDS table as a CSV.

    Params (Request Body):
        - table_name : str (RDS Table name)
        - page: int (Page number, starts from 1)

    Returns:
        - CSV file as a StreamingResponse
    """
    try:
        if inputs.page < 1:
            raise HTTPException(status_code=http_status.HTTP_400_BAD_REQUEST, detail="Page number must be 1 or greater")

        table_name = inputs.table_name
        page = inputs.page
        page_size = 1000  # Default page size (1000 records per page)

        metadata = MetaData()
        
        # Reflect all tables dynamically
        metadata.reflect(bind=prod_rds_instance.engine)

        # Ensure table exists
        if table_name not in metadata.tables:
            raise HTTPException(status_code=http_status.HTTP_404_NOT_FOUND, detail="Table not found in RDS")

        table = metadata.tables[table_name]

        #  Calculate Offset from Page Number
        offset = (page - 1) * page_size

        #  Execute paginated SQL query
        session = prod_rds_instance.get_connection()

        with handle_session(session) as ns:
            stmt = select(table).limit(page_size).offset(offset)  # Apply pagination
            result = ns.execute(stmt)

            # Convert query result into list of dictionaries
            column_names = result.keys()  # Get column names
            records_list = [dict(zip(column_names, row)) for row in result.fetchall()]

            logger_1.info(f"Retrieved {len(records_list)} records from {table_name} (Page={page}, Page Size={page_size})")

            if not records_list:
                return JSONResponse(
                    status_code=http_status.HTTP_404_NOT_FOUND,
                    content={"error": "No data found in the table for the given page number"}
                )

            # Convert to DataFrame and return as CSV
            df = pd.DataFrame(records_list)
            csv_io = io.StringIO()
            df.to_csv(csv_io, index=False)
            csv_io.seek(0)

            return StreamingResponse(
                iter([csv_io.getvalue()]),
                media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename={table_name}_page{page}.csv"},
            )

    except Exception as e:
        logger_1.error(f"Failed to get the table data: {e}")
        return JSONResponse(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": "Unknown error occurred"}
        )