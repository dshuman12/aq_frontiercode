# Import inbuilt libraries
import io

# Import third party libraries
from fastapi import APIRouter, Depends, File, UploadFile,status as http_status,Form,Response
from fastapi.responses import JSONResponse
from datetime import datetime
from typing import Optional,List



# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for fleets library
lib_code_FL = "50"
lib_ver_FL = "00"

lib_code_ver_FL = f"{lib_code_FL}{lib_ver_FL}"



# Include custom libraries
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.fleets_schema import *
from utils.fleets_util import *




# Initialize the logger
logger_1 = LoggerFactory(name="fleet_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()



# endpoints start here


# api to get fleet table
@router.get("/table/")
async def get_fleet_table():
    """
    API to get fleet table

    params:
        - None

    returns:
        - CSVResponse: CSV file with fleet table data
        - error: error message if any error occurs

    """

    bugs = {}

    try:
        
        # call get_fleet_rds_df function
        fleet_df, bugs_local = get_fleet_rds_df()

        if bugs_local:
            logger_1.error(f"Error in getting fleet rds df , {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to get fleet table"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif fleet_df is not None:
            # convert the dataframe to csv
            csv_file = fleet_df.to_csv(index=False)
            return Response(content=csv_file, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=fleet_table.csv"})

    except Exception as e:
        logger_1.error(f"Error in get_fleet_table API: {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# api to add a new fleet
@router.post("/add/")
async def add_new_fleet(fleet: Add_Fleet):
    """
    API to add a new fleet

    params:
        
        - fleet_name : str : name of the fleet
        - number_of_vehicles : int : number of vehicles in the fleet
        - distributor_id : int : id of the distributor

    returns:
        - success: success message
        - error: error message if any error occurs

    """
    try:
        
        # call add_new_fleet_to_rds function
        success, bugs_local = add_new_fleet_to_rds(fleet)

        if bugs_local:
            logger_1.error(f"Error in adding new fleet to rds, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to add new fleet"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        

        elif success == True:
            return JSONResponse({"success" : "New fleet added successfully"},status_code=http_status.HTTP_200_OK)


    except Exception as e:
        logger_1.error(f"Error in add_new_fleet API: {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# api to update fleet details
@router.put("/update/")
async def update_fleet_details(fleet: Update_Fleet):
    """
    API to update fleet details

    params:
        
        - fleet_id : int : id of the fleet
        - fleet_name : str : name of the fleet
        - number_of_vehicles : int : number of vehicles in the fleet
        - distributor_id : int : id of the distributor

    returns:
        - success: success message
        - error: error message if any error occurs

    """
    try:
        
        # call update_fleet_in_fleet_rds function
        success, bugs_local = update_fleet_in_fleet_rds(fleet)

        if bugs_local:
            logger_1.error(f"Error in updating fleet details, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to update fleet details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif success == True:
            return {"success" : "Fleet details updated successfully"}

    except Exception as e:
        logger_1.error(f"Error in update_fleet_details API: {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# api to delete a fleet
@router.delete("/delete/")
async def delete_fleet(fleet: Delete_Fleet):
    """
    API to delete a fleet

    params:
        
        - fleet_id : int : id of the fleet

    returns:
        - success: success message
        - error: error message if any error occurs

    """
    try:
        
        # call delete_fleet_from_rds function
        success, bugs_local = delete_fleet_from_rds(fleet)

        if bugs_local:
            logger_1.error(f"Error in deleting fleet, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to delete fleet"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif success == True:
            return {"success" : "Fleet deleted successfully"}

    except Exception as e:
        logger_1.error(f"Error in delete_fleet API: {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

@router.get("/allfleet/")
async def get_all_fleet():
    '''
    API Endpoint to get all fleets

    params
        - None

    returns
        - JSONResponse: JSON response with all fleets
        - error: error message if any error occurs
    '''

    bugs = {}

    try:
        # Fetch the fleet data using get_fleet_rds_df
        fleet_df, bugs_local = get_fleet_rds_df()

        if bugs_local:
            logger_1.error(f"Error in getting all fleets, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to fetch all fleets"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif not fleet_df.empty:
            # Extract only the 'id' and 'fleet_name' columns
            fleet_filtered = fleet_df[['id', 'fleet_name']]

            # Convert DataFrame to dictionary with 'id' as key and 'fleet_name' as value
            fleets_dict = fleet_filtered.set_index('id')['fleet_name'].to_dict()

            return {"message": "All fleets fetched", "data": fleets_dict}

        else:
            return {"message": "No fleets found"}

    except Exception as e:
        logger_1.error(f"Error in get_all_fleet endpoint {str(e)}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
