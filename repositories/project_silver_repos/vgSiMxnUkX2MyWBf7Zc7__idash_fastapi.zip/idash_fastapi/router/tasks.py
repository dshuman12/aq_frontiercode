# Import inbuilt libraries





# Import third party libraries
from datetime import timedelta
from fastapi import APIRouter, File, Form, UploadFile,status as http_status,Response
from fastapi.responses import JSONResponse





# Include repos folder for custom libraries



# Declare variables used 

# Library Code for Users Module
lib_code_TM = "27"
lib_ver_TM = "00"

lib_code_ver_TM = f"{lib_code_TM}{lib_ver_TM}"



# Include custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.tasks_utils import *
from schema.tasks_schema import *
from utils.slack_notify_utils import notify_slack
from utils.users_utils import return_emaiL


router = APIRouter()

logger_1 = LoggerFactory(name="task_route", file_name="message.log").get_logger()


# ENDPOINTS START FROM HERE

# endpoint to get all tasks
@router.get("/fetchall/",status_code=http_status.HTTP_200_OK)    
async def get_all_tasks():
    '''
    API Endpoint to get all tasks

    params: None
    return : csv with all tasks records or error message
    
    
    '''

    bugs = {}

    # call the all_task_records function from tasks_util
    all_tasks_fetched, bugs_local = all_task_records()

    if bugs_local:
        logger_1.error(f"Error in fetching all tasks: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error": "Failed to fetch tasks, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif all_tasks_fetched is not None:
        # return the records omiting the index column
        return Response(content=all_tasks_fetched.to_csv(index=False), media_type="text/csv")
      


# endpoint to add a new task
@router.post("/add/",status_code=http_status.HTTP_201_CREATED)
async def add_task( ticketid: int = Form(...),
    added_by: int = Form(...),
    ticket_type: int = Form(...),
    priority: int = Form(default=1, title="Priority", description="Priority of the task"),
    status: int = Form(default=1, title="Status", description="Current status of the task"),
    deadline: Optional[str] = Form(None),
    name: str = Form(...),
    owner: Optional[int] = Form(default=None),
    machine_raised: Optional[bool] = Form(False),
    attachments : List[UploadFile] = File(None)
    ):

    '''
    API Endpoint to add a new task

    params: 
    
    return : 
     - success with ticket data
     - error message
    
    
    '''

    bugs = {}


    # create an instance of AddTask_Input
    task = AddTask_Input(ticketid=ticketid,added_by=added_by,ticket_type=ticket_type,priority=priority,status=status,deadline=deadline,name=name,owner=owner,machine_raised=machine_raised,attachments=attachments)

    # call the next_child_id function from tasks_utils
    next_child_id_fetched, bugs_local = next_child_id(task.ticketid, task.ticket_type)

    if bugs_local:
        logger_1.error(f"Error in fetching next child id: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        
        return JSONResponse({"error": "Failed to create task, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
    elif next_child_id_fetched is not None:

        # call the create_task_record function from tasks_utils
        task_id, bugs_local = create_task_record(task, next_child_id_fetched)

        if bugs_local:
            logger_1.error(f"Error in creating task record: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)

            return JSONResponse({"error": "Failed to create task, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
        elif task_id is not None:

            # call the insert_record_to_rds_cache function from tasks_util to get the updated records
            updated_cache, bugs_local = insert_record_to_task_cache(task_id)

            if bugs_local:
                logger_1.error(f"Error in fetching all tasks: {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)

                return JSONResponse({"error": "Failed to fetch tasks, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif updated_cache == True:

                # call the add_task_to_ticket function from tasks_util
                ticket_s3_data, bugs_local = add_task_to_ticket(task,task_id,next_child_id_fetched)

                if bugs_local:
                    logger_1.error(f"Error in adding task to ticket: {bugs_local}")
                    bugs = c_bugs(bugs, bugs_local)
                    bugs = s_bugs(bugs)

                    return JSONResponse({"error": "Failed to add task to ticket, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
                
                elif ticket_s3_data is not None:
                    
                    # get the email of the owner
                    owner_email = return_emaiL(task.owner)
                    
                    logger_1.info(f"Owner email is {owner_email}")
                    
                    assingee_email = return_emaiL(task.added_by)
                        
                    # call notify slack function
                    # status = notify_slack(ticket_title=task.name, assigned_to_email=owner_email, assigned_by_email=assingee_email, ticket_url=f"https://dxlq5q0lkehfz.cloudfront.net/tickets-dashboard", ticket_type="Task")
                    
                    # if status == False:
                    #     logger_1.error(f"Failed to send message to slack channel, {bugs_local}")
                    #     return JSONResponse({"error": "Failed to create task"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
                    
                    # elif status == True:
                    return {"message": "Task added successfully", "ticket_data": ticket_s3_data}

    return JSONResponse({"error": "Unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            


# endpoint to update a task
@router.patch("/update/",status_code=http_status.HTTP_200_OK)
async def update_task(Task: UpdateTask_Input):
    '''
    API Endpoint to update a task partially

    params: 
    
    return : 
     - success with ticket data
     - error message
    
    
    '''

    bugs = {}


    # Extract the dictionary from the Pydantic model and filter out None values
    task_updates = {k: v for k, v in Task.dict().items() if v is not None}

    # call the push_updates_to_task_cache function from tasks_util
    updated_task, bugs_local = push_updates_to_task_rds_cache(task_id=Task.taskid,updates=task_updates)

    if bugs_local:
        logger_1.error(f"Error in updating task record: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error": "Failed to update task, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif updated_task is not None:

        # call the update_task_in_ticket function from tasks_util
        ticket_s3_data, bugs_local = update_task_in_ticket(Task)

        if bugs_local:
            logger_1.info(f"Error in updating task in ticket: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)

            return JSONResponse({"error": "Failed to update task in ticket, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_s3_data is not None:            
            return {"message": "Task updated successfully", "ticket_data": ticket_s3_data}




# endpoint to delete a task
@router.delete("/delete/",status_code=http_status.HTTP_200_OK)
async def delete_task(Task : DeleteTask_Input):
    '''
    API Endpoint to delete a task

    params: 
     - Task : DeleteTask_Input
     
    
    return : 
     - success with ticket data
     - error message
    
    '''

    bugs = {}
    
    # call the delete_task_service function from tasks_utils
    tasks_are_deleted, bugs_local = delete_task_service(Task)

    if bugs_local:
        logger_1.error(f"Error in deleting task: {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)

        return JSONResponse({"error": "Failed to delete tasks, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif tasks_are_deleted == True:
        # call fetch and cache ticket to get the updated ticket data
        ticket_s3_data, bugs_local = fetch_and_cache_ticket(ticketid=Task.ticketid,ticket_type=Task.ticket_type)

        if bugs_local:
            logger_1.error(f"Error in fetching ticket data: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)

            return JSONResponse({"error": "Failed to fetch the latest ticket, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket_s3_data is not None:
            return {"message": "Task deleted successfully", "ticket_data": ticket_s3_data}
        
    
    return JSONResponse({"error": "Failed to delete tasks, unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    

     
    



