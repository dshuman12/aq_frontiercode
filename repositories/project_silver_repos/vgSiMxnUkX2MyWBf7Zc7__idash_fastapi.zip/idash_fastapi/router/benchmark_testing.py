# Import inbuilt libraries



# Import third party libraries
import io
from fastapi import APIRouter
from fastapi import APIRouter, File, Response, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse



# Include repos folder for custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.benchmark_testing_schema import *
from utils.benchmark_testing_util import *
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs, serialize_bug_instance as s_bugs
from utils.bug_tickets_util import push_to_bug_dict

# Declare variables used 

# Library Code for Benchmark Testing Module
lib_code_BTE = "44"
lib_ver_BTE = "00"

lib_code_ver_BTE = f"{lib_code_BTE}{lib_ver_BTE}"


# initialize the logger
logger_1 = LoggerFactory(name="benchmark_testing_routes",file_name="message.log").get_logger()


router = APIRouter()

# endpoint to get all test rigs after filtering out the test rigs already on test
@router.get("/availablerigs/")
async def get_all_test_rigs():
    '''
    API Endpoint to fetch all the test rigs from the database and return the list of test rigs

    returns:
        - Success : list : List of test rigs
        - Failure : error message with status code 500
    
    '''

    bugs = {}

    try:
        
        available_test_rigs, bugs_local = get_available_test_rigs()

        if bugs_local:
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while getting available test rigs"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


        elif available_test_rigs == []:
            return JSONResponse({"error": "No test rigs available"}, status_code=http_status.HTTP_404_NOT_FOUND)
        
        return {"message": "Test rigs fetched successfully","rigs": available_test_rigs}

    except Exception as e:
        logger_1.error(f"Error while getting available test rigs : {e}")
        return JSONResponse({"error": "Unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# endpoint to get all devices from device registration table
@router.get("/alldevices/")
async def get_all_devices():
    '''
    API Endpoint to fetch all the devices from the database and return the list of devices not connected to any vehicles

    returns:
        - Success : list : List of devices
        - Failure : error message with status code 500
    
    '''
    bugs = {}

    try:

        all_devices, bugs_local = fetch_devices()

        if bugs_local:
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while getting all devices"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif all_devices == []:
            return JSONResponse({"error": "No devices available"}, status_code=http_status.HTTP_404_NOT_FOUND)
        
        return {"message": "Devices fetched successfully","data": all_devices}

    except Exception as e:
        logger_1.error(f"Error while getting all devices : {e}")
        return JSONResponse({"error": "Unknown error occured"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# API Endpoint to add a device for benchmark testing
@router.post("/addtotest/")
async def add_device_to_test(test: AddToTest):
    """
    API Endpoint to add a device to a test rig and update the QA status.

    Args:
        test (AddToTest): Payload containing the test rig and device ID.

    Returns:
        JSONResponse: Success or error message.
    """
    try:
        # Step 1: Add the device to the test rig
        vehicle_response, vehicle_bugs = add_to_vehicle_registration(test.vehicle_number, test.device_id)

        # Check for bugs in vehicle registration
        if vehicle_bugs:
            logger_1.error(f"Bug encountered in add_to_vehicle_registration: {vehicle_bugs}")
            return JSONResponse(
                {"error": "Error while adding device to test rig."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Check if the response indicates failure
        if not isinstance(vehicle_response, JSONResponse) or vehicle_response.status_code not in [200, 201]:
            return vehicle_response

        # Step 2: Update the QA status of the device
        qa_response, qa_bugs = update_device_qa_status(test.device_id, 0)

        # Check for bugs in QA update
        if qa_bugs:
            logger_1.error(f"Bug encountered in update_device_qa_status: {qa_bugs}")
            return JSONResponse(
                {"error": "Error while updating QA status."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Check if the response indicates failure
        if not isinstance(qa_response, JSONResponse) or qa_response.status_code != 200:
            return qa_response

        # If both succeed, return success message
        return JSONResponse(
            {"message": "Device added to testing successfully."},
            status_code=http_status.HTTP_200_OK,
        )

    except Exception as e:
        logger_1.error(f"Error in addtotest API: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


@router.get("/table/")
async def get_table():
    """
    API Endpoint to fetch the table data from the database and return the table data.

    Returns:
        - Success: List of table data as CSV or JSON
        - Failure: Error message with appropriate status code
    """
    bugs = {}

    try:
        # Define the columns for the table
        columns = ["Device Id", "Test Rig", "Status"]

        # Get the table data
        table_data_df, bugs_local = get_table_data()

        # Check for bugs during data retrieval
        if bugs_local:
            logger_1.error(f"Error while getting table data: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse(
                {"error": "Error while getting table data"},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Convert the DataFrame to CSV
        csv_buffer = io.StringIO()
        table_data_df.to_csv(csv_buffer, index=False, header=columns)
        csv_data = csv_buffer.getvalue()

        # Return CSV data as a response
        return Response(
            content=csv_data, 
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=table_data.csv"}
        )

    except Exception as e:
        logger_1.error(f"Error while getting table data: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred"},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

@router.post("/mark_test_rig_as_test_started/")
async def mark_test_rig_as_test_started(input: Mark_Test_Started):
    """
    API to mark a test rig as test started and update the QA status of the associated device.

    Args:
        input (Mark_Test_Started): Payload containing test rig ID and device ID.

    Returns:
        JSONResponse: Success or error message.
    """
    try:

        # Step 1: Update the QA status of the device
        qa_response, qa_bugs = update_device_qa_status(input.device_id, 1)

        # Check for bugs in QA status update
        if qa_bugs:
            logger_1.error(f"Failed to update device registration QA status: {qa_bugs}")
            return JSONResponse(
                {"error": f"Failed to mark {input.test_rig_id} as started testing."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Check if the response indicates failure
        if not isinstance(qa_response, JSONResponse) or qa_response.status_code != 200:
            return qa_response

        # mark the record active status a 1
        test_marked_started = update_active_status(input.test_rig_id,input.device_id,1)
        
        return JSONResponse(
            {"message": f"Started testing on {input.test_rig_id}."},
            status_code=http_status.HTTP_200_OK,
        )

    except Exception as e:
        logger_1.error(f"Error in marking test rig as test started: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
        )



@router.post("/release_test_rig/")
async def release_test_rig(input : Release_Test_Rig):
    """
    API Endpoint to release a test rig.

    Params:
        - test_rig (str): The name of the test rig to be released.

    Returns:
        - Success: Message confirming the release.
        - Failure: Error message with the reason for failure.
    """

    # Call the release_test_rig_service function
    return release_test_rig_service(input.test_rig_id)



@router.get("/device_test_history/")
async def get_devices_with_qa():
    """
    API to fetch devices with a non-NULL QA status.

    Returns:
        JSONResponse or CSV:
            - JSONResponse: Error message if the query fails.
            - CSV: Data containing device_id and QA status.
    """
    bugs = {}

    try:
        # Fetch devices with QA status
        devices_df, bugs_local = get_devices_with_qa_status()

        # Check for bugs during data retrieval
        if bugs_local:
            logger_1.error(f"Error while fetching devices with QA status: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse(
                {"error": "Error while fetching devices with QA status."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Convert the DataFrame to CSV format
        csv_buffer = io.StringIO()
        devices_df.to_csv(csv_buffer, index=False, header=["Device ID", "QA Status"])
        csv_data = csv_buffer.getvalue()

        # Return the CSV as a response
        return Response(
            content=csv_data,
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=devices_with_qa.csv"},
        )

    except Exception as e:
        logger_1.error(f"Error while fetching devices with QA status: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred."},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

    