# Import inbuilt libraries


# Import third party libraries
from fastapi import APIRouter, Depends, File, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse
from typing import List
from utils.trip_automation import *


# Include repos folder for custom libraries
from auth_bearer import JWTBearer

# Declare variables used 
# Library code for vehicle registration library
lib_code_VRL = "48"
lib_ver_VRL = "00"

lib_code_ver_VRL = f"{lib_code_VRL}{lib_ver_VRL}"



# Include custom libraries
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.data_models.rds_data_models.ticket_rds_models import *
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.common_schema import *
from schema.vehicle_registration_schema import *
from utils.vehicle_registration_util import *
from storage_settings import rds_instance,get_current_date
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session
from hiper_utils.data_models.rds_data_models.vehicle_rds_models import VehicleRegistrationNew as VR_RDS
from hiper_utils.other_utils.resource_util import ResourceUtil



# Initialize the logger
logger_1 = LoggerFactory(name="vehicle_registration_routes", file_name="message.log").get_logger()

# Initialize the router
router = APIRouter()



# endpoints start here


# endpoint to add new vehicle registration
@router.post("/addnewvehicle/")
async def add_new_vehicle(new_vehicle : Add_New_Vehicle):

    '''
    
    API Endpoint to add new vehicle registration

    params
        - vehicle_make : str : manufacturer of the vehicle
        - vehicle_model : str : model of the vehicle
        - emission : str : emission of the vehicle
        - chassis_no : str : chassis number of the vehicle
        - engine_no : str : engine number of the vehicle
        - mfg_year : int : manufacturing year of the vehicle
        - fleet_id : int : fleet id of the vehicle
        - reg_no : str : registration number of the vehicle
        - user_id : int : user id of the user who is registering the vehicle
        - dataset_id : str : dataset id of the vehicle
        - device_id : str : device id of the vehicle
 
        
    returns
        - JSONResponse: Success message if vehicle registration is successful else failure message
        - error: error message if any error occurs
    
    '''

    bugs = {}

    logger_1.info(f"New vehicle registration request received for {new_vehicle.reg_no}")

    try:

        # check if the vehicle is already registered
        vehicle_registered,bugs_local = check_vehicle_already_registered(new_vehicle.reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check vehicle registration"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == True:
            return JSONResponse({"error" : "Vehicle already registered"},status_code=http_status.HTTP_400_BAD_REQUEST)


        else:

            # call create_new_vehicle_record function
            new_vehicle_number,bugs_local = create_vehicle_record(reg_no=new_vehicle.reg_no,engine_no=new_vehicle.engine_no,chassis_no=new_vehicle.chassis_no,fleet_id=new_vehicle.fleet_id,mfg_year=new_vehicle.mfg_year,vehicle_make=new_vehicle.vehicle_make,vehicle_model=new_vehicle.vehicle_model,emission=new_vehicle.emission,device_id=new_vehicle.device_id)

            if bugs_local:
                logger_1.error(f"Error in creating vehicle record, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error" : "Failed to create vehicle record"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif new_vehicle_number is not None:
                logger_1.info(f"Vehicle record created successfully, {new_vehicle_number}")
                
                return {"message" : "Vehicle registered successfully"}    
            
    except Exception as e:
        logger_1.error(f"Error in add_new_vehicle endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# route to update ecu details
@router.post("/updateecu/")
async def update_ecu_details(ecu_update : Update_ECU_Details):

    '''
    
    API Endpoint to update ecu details

    params
     - vehicle_no : str : vehicle number
     - user_id : int : user id of the user who is updating the ecu details
     - ecu_no : str : ecu number
     - ecu_make : str : ecu make
     - ecu_model : str : ecu model

    returns
        - JSONResponse: Success message if ecu details update is successful else failure message
        - error: error message if any error occurs

    '''

    bugs = {}

    # call update ecu details of the vehicle function
    logger_1.info(f"ECU update request received for {ecu_update.reg_no}")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(ecu_update.reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check vehicle registration"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # call update ecu details of the vehicle function
        update_success,bugs_local = update_ecu_details_of_vehicle(ecu_update)

        if bugs_local:
            logger_1.error(f"Error in updating ecu details, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to update ecu details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif update_success == True:
            
            # # create vehicle json
            # create_vehicle_json_status, bugs_local = create_vehicle_json(vehicle_num=ecu_update.reg_no)
            
            # if bugs_local:
            #     logger_1.error(f"Error in creating vehicle json, {bugs_local}")
            #     bugs = c_bugs(bugs,bugs_local)
            #     bugs = s_bugs(bugs)
            #     return JSONResponse({"error" : "Failed to update ecu details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            # elif create_vehicle_json_status == True:
            logger_1.info(f"ECU details updated successfully")
                
            return {"message" : "ECU details updated successfully"}
    
        else:
            return JSONResponse ({"error" : "Updating ecu details failed"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        logger_1.error(f"Error in update_ecu_details endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# route to update the installation checklist
@router.post("/addchecklist/")
async def create_installation_checklist(
    reg_no : str = Form(..., description="Registration number of the vehicle"),
    user_id : int = Form(..., description="User id of the user who is updating the installation checklist"),
    battery_voltage_value : str = Form(..., description="Battery voltage of the vehicle"),
    check_can_pins_value : bool = Form(False, description="Check CAN pins"),
    check_KLINE_pins_value : bool = Form(False, description="Check KLINE pins"),
    igniton_affecting_voltage_value : str = Form(None, description="Reasons for ignition affecting voltage"),
    obd_location_photos : List[UploadFile] = File(..., description="OBD port location photo"),
    installation_videos_in : List[UploadFile] = File(..., description="Installation video"),
    additional_pins_on_obd : list = Form(None, description="Additional pins on OBD")

):
    
    '''
    API Endpoint to update installation checklist

    params
        - reg_no : str : registration number of the vehicle
        - user_id : int : user id of the user who is updating the installation checklist
        - battery_voltage : str : battery voltage of the vehicle
        - check_can_pins : bool : check CAN pins
        - check_KLINE_pins : bool : check KLINE pins
        - obd_location_photo : list : OBD port location photo
        - installation_video : list : installation video
        

        optional params
        - additional_pins_on_obd : list : additional pins on OBD    
        - iginiton_affecting_voltage : str : reasons for ignition affecting voltage


    returns
        - JSONResponse: Success message if installation checklist update is successful else failure message
        - error: error message if any error occurs
    ''' 
    
    bugs = {}

    logger_1.info(f"Installation checklist update request received for {reg_no}")


    # log the iginiton_affecting_voltage_value
    logger_1.info(f"Ignition affecting voltage value is {igniton_affecting_voltage_value}")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to create installation block"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # call check installlation block already exists function
        installation_block_exists,bugs_local = check_installation_block_exists(reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking installation block exists, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to create installation block"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif installation_block_exists == True:
            return JSONResponse({"error" : "Installation block already exists"},status_code=http_status.HTTP_400_BAD_REQUEST)

        # create an instance of the checklist
        check = Create_Installation_Checklist(
            reg_no = reg_no,
            user_id = user_id,
            battery_voltage = battery_voltage_value if battery_voltage_value else None,
            check_can_pins = check_can_pins_value,
            check_KLINE_pins = check_KLINE_pins_value,
            igniton_affecting_voltage = igniton_affecting_voltage_value,
            obd_location_photo = obd_location_photos,
            installation_video = installation_videos_in,
            add_pins_on_obd= additional_pins_on_obd
        )

        # call update installation block function
        added,bugs_local = create_installation_block(check)

        if bugs_local:
            logger_1.error(f"Error in creating installation checklist, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to add installation checklist"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif added == True:
            return {"message" : "Installation checklist added successfully"}
        
        else:
            return JSONResponse ({"error" : "Adding installation checklist failed"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    except Exception as e:
        logger_1.error(f"Error in create_installation_checklist endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




# route to get add a new calibration block
@router.post("/addcalibration/")
async def add_calibration_block_to_vehicle(
    reg_no : str = Form(..., description="Registration number of the vehicle"),
    user_id : int = Form(..., description="User id of the user who is adding the calibration block"),
    puc_certificate : List[UploadFile] = File(..., description="PUC certificate"),
    empty_weight : float = Form(..., description="Empty weight of the vehicle"),
    loaded_weight : float = Form(..., description="Loaded weight of the vehicle"),
    photo_of_number_plate : List[UploadFile] = File(..., description="Photo of the number plate"),
    photo_of_wheels : List[UploadFile] = File(..., description="Photo of the wheels"),
    photo_of_rc_book : List[UploadFile] = File(..., description="Photo of the RC book")
):

    '''

    API Endpoint to add a new calibration block

    params
        - puc_certificate : file : PUC certificate
        - empty_weight : float : empty weight of the vehicle
        - loaded_weight : float : loaded weight of the vehicle
        - photo_of_number_plate : list : photo of the number plate
        - photo_of_wheels : list : photo of the wheels

    returns
        - JSONResponse: Success message if calibration block is added successfully else failure message
        - error: error message if any error occurs

    '''

    bugs = {}

    logger_1.info(f"Calibration block request received")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to create calibration block"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)

        # create an instance of the calibration block
        calibration_block = Create_Calibration_Block(
            reg_no = reg_no,
            user_id = user_id,
            puc_certificate = puc_certificate,
            empty_weight = empty_weight,
            loaded_weight = loaded_weight,
            photo_of_number_plate = photo_of_number_plate,
            photo_of_wheels = photo_of_wheels,
            photo_of_rc_book = photo_of_rc_book
        )

        # call add calibration block function
        added,bugs_local = add_calibration_block(calibration_block)

        if bugs_local:
            logger_1.error(f"Error in adding calibration block, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to add calibration block"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif added == True:
            return {"message" : "Calibration block added successfully"}
        
        else:
            return JSONResponse ({"error" : "Adding calibration block failed"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    
    except Exception as e:
        logger_1.error(f"Error in add_calibration_block endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# get_vr_table route
@router.get("/table/")
async def get_vr_table():
    '''
    API Endpoint to get all registered vehicles

    params
        - None

    returns
        - JSONResponse: JSON response with all registered vehicles
        - error: error message if any error occurs
    '''
    bugs = {}

    try:
        # Call get all registered vehicles function
        all_reg_vehicles_dict, bugs_local = get_all_registered_vehicles()

        if bugs_local:
            logger_1.error(f"Error in getting all registered vehicles, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to fetch all registered vehicles"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif all_reg_vehicles_dict is not None and all_reg_vehicles_dict != {}:
            logger_1.info(f"All registered vehicles fetched, {all_reg_vehicles_dict}")
            return {"message": "All registered vehicles fetched", "data": all_reg_vehicles_dict}
        
        else:
            logger_1.info("No registered vehicles found.")
            return JSONResponse({"message": "No registered vehicles found."}, status_code=http_status.HTTP_404_NOT_FOUND)

    except Exception as e:
        logger_1.error(f"Error in get_vr_table endpoint {str(e)}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# route to check if the engine number is related to any registered vehicle
@router.get("/checkenginenum/")
async def check_engine_num_is_taken(engine_no : str):

    '''
    
    API Endpoint to check if the engine number is related to any registered vehicle

    params
        - engine_num : str : engine number of the vehicle

    returns

        - bool : True if engine number is related to any registered vehicle else False
        - error: error message if any error occurs
    
    
    '''

    bugs = {}

    try:

        # call check engine number taken function
        engine_num_taken,bugs_local = check_engine_number_taken(engine_no)

        if bugs_local:
            logger_1.error(f"Error in checking engine number, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check engine number"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif engine_num_taken == True:
            return True
        
        else:
            return False

    
    except Exception as e:
        logger_1.error(f"Error in check_engine_num endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    


# route to update vehicle details
@router.post("/updatevehicledetails/")
async def update_vehicle_details(vehicle_edit : Edit_Vehicle_Details):

    '''
    
    API Endpoint to update vehicle details

    params
        - reg_no : str : registration number of the vehicle
        - user_id : int : user id of the user who is updating the vehicle details

        optional params
        - vehicle_make : str : manufacturer of the vehicle
        - vehicle_model : str : model of the vehicle
        - emission : str : emission of the vehicle
        - chassis_no : str : chassis number of the vehicle
        - engine_no : str : engine number of the vehicle
        - fleet_id : int : fleet id of the vehicle
        - mfg_year : int : manufacturing year of the vehicle


    returns
        - JSONResponse: Success message if vehicle details update is successful else failure message
        - error: error message if any error occurs
    
    
    
    '''

    bugs = {}

    logger_1.info(f"Vehicle edit request received for {vehicle_edit.reg_no}")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(vehicle_edit.reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check vehicle registration"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)
        

        # call check_valid_engine_number function if engine number is provided
        if vehicle_edit.engine_no:
            valid_engine_number,bugs_local = check_valid_engine_number(vehicle_edit.engine_no)

            if bugs_local:
                logger_1.error(f"Error in checking engine number, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error" : "Failed to update vehicle details"},status_code=http_status.HTTP_400_BAD_REQUEST)
            
            elif valid_engine_number == False:
                return JSONResponse({"error" : "Invalid engine number"},status_code=http_status.HTTP_400_BAD_REQUEST)
            


        # call check_valid_chassis_number function if chassis number is provided
        if vehicle_edit.chassis_no:
            valid_chassis_number,bugs_local = check_valid_chassis_number(vehicle_edit.chassis_no)

            if bugs_local:
                logger_1.error(f"Error in checking chassis number, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error" : "Failed to update vehicle details"},status_code=http_status.HTTP_400_BAD_REQUEST)
            
            elif valid_chassis_number == False:
                return JSONResponse({"error" : "Invalid chassis number"},status_code=http_status.HTTP_400_BAD_REQUEST)


        # call update_s3_vehicle_details function
        update_success,bugs_local = update_s3_vehicle_details(vehicle_edit)

        if bugs_local:
            logger_1.error(f"Error in updating vehicle details, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to update vehicle details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif update_success == True:
        
            # call update_rds_vehicle_details function
            write_success, bugs_local = update_rds_vehicle_details(vehicle_num=vehicle_edit.reg_no, vehicle_make=vehicle_edit.vehicle_make, vehicle_model=vehicle_edit.vehicle_model, fleet_id=vehicle_edit.fleet_id, mfg_year=vehicle_edit.mfg_year, engine_number=vehicle_edit.engine_no, chassis_number=vehicle_edit.chassis_no)

            if bugs_local:
                logger_1.error(f"Error in updating vehicle details, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                return JSONResponse({"error" : "Failed to update vehicle details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif write_success == True:
                return {"message" : "Vehicle details updated successfully"}
            
            else:
                return JSONResponse ({"error" : "Updating vehicle details failed"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        else:
            logger_1.error(f"Error in updating vehicle details, updating RDS failed")
            return JSONResponse({"error" : "Failed to update vehicle details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    except Exception as e:
        logger_1.error(f"Error in update_vehicle_details endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)




# route to update elecricals
@router.post("/updateelectricals/")
async def update_electricals(electrical_edit : Update_Electricals):

    '''
    
    API Endpoint to update electrical details

    params
        - reg_no : str : registration number of the vehicle
        - user_id : int : user id of the user who is updating the electrical details

        optional params
        - battery_voltage : float : battery voltage of the vehicle
        - iginition_affecting_voltage : str : reasons for ignition affecting voltage

    returns
        - JSONResponse: Success message if electrical details update is successful else failure message
        - error: error message if any error occurs
    
    '''

    bugs = {}

    logger_1.info(f"Electrical edit request received for {electrical_edit.reg_no}")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(electrical_edit.reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check vehicle registration"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # call update electricals function
        update_success,bugs_local = update_s3_electrical_details(electrical_edit)

        if bugs_local:
            logger_1.error(f"Error in updating electrical details, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to update electrical details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif update_success == True:
            return {"message" : "Electrical details updated successfully"}

    except Exception as e:
        logger_1.error(f"Error in update_electricals endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# route to update calibration details
@router.post("/updatecalibration/")
async def update_calibration(calibration_edit : Update_Calibration):

    '''
    
    API Endpoint to update calibration details

    params
        - reg_no : str : registration number of the vehicle
        - user_id : int : user id of the user who is updating the calibration details

        optional params
        - empty_weight : float : empty weight of the vehicle
        - loaded_weight : float : loaded weight of the vehicle


    returns
        - JSONResponse: Success message if calibration details update is successful else failure message
        - error: error message if any error occurs
    
    '''

    bugs = {}

    logger_1.info(f"Calibration edit request received for {calibration_edit.reg_no}")

    try:

        # call check vehicle already registered function
        vehicle_registered,bugs_local = check_vehicle_already_registered(calibration_edit.reg_no)

        if bugs_local:
            logger_1.error(f"Error in checking vehicle registration, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to check vehicle registration"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif vehicle_registered == False:
            return JSONResponse({"error" : "Vehicle not registered"},status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # call update calibration function
        update_success,bugs_local = update_s3_vehicle_calibration_details(calibration_edit)

        if bugs_local:
            logger_1.error(f"Error in updating calibration details, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error" : "Failed to update calibration details"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif update_success == True:
            return {"message" : "Calibration details updated successfully"}

    except Exception as e:
        logger_1.error(f"Error in update_calibration endpoint {str(e)}")
        return JSONResponse({"error" : "Unknown error occured"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
# route to check how get trips summary parquet is working
@router.get("/gettripsummary/")
async def get_trip_summary(reg_no : str):
    
    bugs = {}
    
    # call get_trips_summary function from hiper_utils
    trips_summary, bugs_local = ResourceUtil().get_trips_summary(vehicle=reg_no)
    
    if bugs_local:
        logger_1.error(f"Error in getting trips summary, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return JSONResponse({"error" : "Failed to get trips summary"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif trips_summary is not None:
        logger_1.info(f"Trips summary fetched successfully, {trips_summary}")
        
        return {"message" : "Trips summary fetched successfully","data" : trips_summary}
    
    

# test trip automation
@router.get("/test/")
async def test_trip_automation(vehicle_number : str):
    
    '''
    
    Test API Endpoint to test trip automation
    
    '''
    
    bugs = {}
    
    events_table, bugs_local = fetch_events_table_and_update_trips(vehicle_number) 
    
    if bugs_local:
        logger_1.error(f"Error in fetching events table, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return JSONResponse({"error" : "Failed to fetch events table"},status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif events_table is not None:
        logger_1.info(f"Events table fetched successfully, {events_table}")
        
        