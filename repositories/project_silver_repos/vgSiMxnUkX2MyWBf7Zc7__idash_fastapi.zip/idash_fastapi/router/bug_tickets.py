# Import inbuilt libraries
import io
import sys


# Import third party libraries
from fastapi import APIRouter, File, Response, UploadFile,status as http_status,Form
from fastapi.responses import JSONResponse



# Include repos folder for custom libraries


# Declare variables used
sys.path.append("../")


# Library code for bug tickets
lib_code_BT = "41"
lib_ver_BT = "00"

lib_code_ver_BT = f"{lib_code_BT}{lib_ver_BT}"



# Include custom libraries
from hiper_utils.data_models.dashboard_tables import *
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from schema.common_schema import *
from utils.bug_tickets_util import *
from storage_settings import rds_instance, redis_instance
from hiper_utils.data_models.rds_data_models.ticket_rds_models import Bug_Ticket
from hiper_utils.data_models.rds_data_models.users_rds_models import Employee,Team
from hiper_utils.Relational_DB.MYSQL_DB.mysql_db import handle_session

# Initialize the logger
logger_1 = LoggerFactory(name="bug_ticket_router", file_name="message.log").get_logger()


router = APIRouter()


# endpoints start here
@router.get("/allbugs/", status_code=http_status.HTTP_200_OK)
async def get_all_bug_tickets():
    '''
    Endpoint to get all bug tickets

    params: None
    return 200 with message saying all bug tickets retrieved else failure message
    '''
    
    bugs = {}

    try:
        all_bug_tickets, bugs_local = all_bug_ticket_records()
        
        if bugs_local:
            logger_1.error(f"Failed in fetching all bug tickets, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Failed to fetch bug tickets"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        

        # Check if the DataFrame is empty
        elif all_bug_tickets.empty:
            logger_1.info("No bug tickets available.")
            return JSONResponse({"message": "No bug tickets available"}, status_code=http_status.HTTP_200_OK)

        # Convert DataFrame to CSV
        csv_buffer = io.StringIO()
        all_bug_tickets.to_csv(csv_buffer, index=False)
        csv_data = csv_buffer.getvalue()

        # Return CSV data
        return Response(
            content=csv_data,
            media_type="text/csv",
            headers={"Content-Disposition": "attachment;filename=bug_tickets.csv"}
        )

    except Exception as e:
        # Log the error and return a 500 Internal Server Error
        logger_1.error(f"Unknown error occurred while fetching bug tickets: {e}")
        return JSONResponse(
            {"error": "Unknown error occurred, failed to fetch bug tickets"},
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR
        )


# get single bug ticket
@router.get("/getsingleticket/1/", status_code=http_status.HTTP_200_OK)
async def get_single_bug_ticket(ticket_id: int):
    '''
    Endpoint to get a single bug ticket

    query_params : ticket_id
    return : 200 if ticket found, else failure message with bugs
    
    '''

    bugs = {}


    try:
        # call fetch_and_cache_bug_ticket function
        ticket, bugs_local = fetch_and_cache_bug_ticket(ticket_id)

        if bugs_local:
            logger_1.info(f"Failed in fetching bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while fetching bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif ticket is not None:
            return {"message": "Bug ticket fetched successfully", "ticket_data": ticket}


    except Exception as e:
        return JSONResponse({"error": "Unknown error occurred, failed to fetch bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)





# create a bug ticket
@router.post("/createbugticket/", status_code=http_status.HTTP_201_CREATED)
async def create_bug_ticket(name  : str = Form(...,description="Name of the bug ticket"),
                            added_by : int = Form(..., description="ID of the user who created the bug ticket"),
                            bug_description : str = Form(...,description="Description of the bug ticket"),
                            owner : Optional[int] = Form(None,description="ID of the user the bug ticket is assigned to, if any"),
                            priority : int = Form(..., description="Priority of the bug ticket"),
                            modules : Optional[str] = Form(None, description="List of module IDs related to the feature"),
                            attachments : List[UploadFile] = File(None)):
    '''
    Endpoint to create a bug ticket

    params: bug_name, added_by, bug_description, priority, owner
    optional : modules (libraries)
    return 201 with message saying ticket created successfully else failure message
    
    '''

    bugs = {}

    try:

        # Parse the modules_str into a list of integers
        modules_list = [int(x) for x in modules.strip('[]').split(',')] if modules else []

        # create an instance of the Create_Bug_Ticket
        ticket = Create_Bug_Ticket(
            bug_name = name,
            added_by = added_by,
            bug_description = bug_description,
            owner = owner,
            priority = priority,
            modules = modules_list,
            attachments=attachments
        )

        # modules will come a string "[1,2,3]", convert it to a single string "1,2,3"
        modules_to_rds = ",".join([str(x) for x in ticket.modules])

        # get the connection
        session = rds_instance.get_connection()

        # query the bug ticket table using handle session context manager
        with handle_session(session) as ns:
            
            owner_team = None
        
            if ticket.owner:
        
                owner_team = session.query(Employee).filter(Employee.id == ticket.owner).first()
        
                approver = session.query(Team).filter(Employee.user_team == owner_team.user_team).first().l2_manager
        
            else:
                approver = None
            
            # create a new bug ticket record
            new_bug_ticket_record = Bug_Ticket(
                name=ticket.bug_name,
                added_by_id=ticket.added_by,
                libraries=modules_to_rds,
                approver=approver,
                status="0" if ticket.owner else "2",
                assigned_to=ticket.owner,
                priority = ticket.priority,
                assigned_team = owner_team
            )


            ns.add(new_bug_ticket_record)
            ns.flush()  # Synchronize the session with the database
            new_ticket_id = new_bug_ticket_record.id  # Access the newly created ID
            print("*** New Bug Ticket Added with ID:", new_ticket_id)

            redis_instance.delete_key('rds_bug_tickets_cached')
        
        # call create bug ticket in s3 function
        ticket_to_s3,bugs_local = create_ticket_in_s3(new_ticket_id,ticket)

        if bugs_local:
            logger_1.info(f"Failed in creating bug ticket in S3, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Failed to create bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif ticket_to_s3 is not None:
            return {"message" : "Bug Ticket created successfully", "ticket_data" : ticket_to_s3}

    except Exception as e:
        logger_1.error(f"Error occurred while creating bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# update a bug ticket
@router.post("/updatebugticket/", status_code=http_status.HTTP_200_OK)
async def update_bug_ticket(ticket: Update_Bug_Ticket):
    ''''
    Endpoint to update a bug ticket


    params : ticket_id,updated_by
    optional params : bug_name, bug_description,requested_eta,priority, owner, modules, type
    return : 200 if updated successfully, else failure message with bugs 

    '''
    bugs = {}

    try:

        # call update ticket service
        updated_ticket_record, bugs_local = update_rds_bug_ticket_record(ticket)

        if bugs_local:
            logger_1.error(f"Updating the bug ticket rds record failed, {bugs_local}")
            bugs = c_bugs(bugs,bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket_record is not None:
            
            # delete the cached bug tickets
            redis_instance.delete_key('rds_bug_tickets_cached')
            
            # call ticket update service function and perform the changes to s3 ticket
            updated_ticket, bugs_local = update_bug_ticket_fields(ticket)

            if bugs_local:
                logger_1.error(f"Updating the ticket in s3 failed, {bugs_local}")
                bugs = c_bugs(bugs,bugs_local)
                bugs = s_bugs(bugs)
                push_to_bug_dict(bugs)
                return JSONResponse({"error": "Failed to update ticket, unknown error occurred."}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif updated_ticket is not None:
                # delete the s3 cache ticket
                redis_instance.delete_key(f"bug_ticket_{ticket.ticketid}")
                
                return {"message" : "Ticket updated successfully", "ticket_data" : updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while updating bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


  



# add a cause block to a bug block
@router.post("/addcauseblocks/", status_code=http_status.HTTP_200_OK)
async def add_cause_blocks_in_bug_ticket(ticketid : int = Form(...,description="Ticket ID of the bug ticket"), 
                                         cause_name : str = Form(...,description="Name of the cause block"), 
                                         description : str = Form(...,description="Description of the cause block"), 
                                         related_bug_blocks : str = Form(...,description="List of related bug blocks"), 
                                         added_by : int = Form(...,description="User who added the cause block"), 
                                         libraries : str = Form(None,description="List of libraries"), 
                                         function_code : Optional[str] = Form(None,description="Function code"), 
                                         attachments : List[UploadFile] = File(None)
                                        ):

    '''
    Endpoint to add a cause block to a bug ticket

    params : ticket_id, cause_name,description,list of related_bug_blocks,added_by
    optional : libararies, function_code, attachments
    return : 200 if cause block added successfully, else failure message with bugs 
    
    '''


    bugs = {}


    try:
        
        # log the libraries and also the related bug blocks
        logger_1.info(f"libraries : {libraries}")
        
        logger_1.info(f"related bug blocks : {related_bug_blocks}")

        if isinstance(libraries, str) and libraries.strip() == "[]" :
            libraries_list = []
        
        elif libraries is not None:
            libraries_list = libraries.strip("[]").split(",")
            libraries_list = [int(i) for i in libraries_list]

        if isinstance(related_bug_blocks, str) and related_bug_blocks.strip() == "[]" :
            related_bug_blocks_list = [] 

        elif related_bug_blocks is not None:
            related_bug_blocks_list = related_bug_blocks.strip("[]").split(",")
            related_bug_blocks_list = [int(i) for i in related_bug_blocks_list]   
        
        
        # log the libraries and also the related bug blocks
        logger_1.info(f"libraries now is : {libraries_list}")

        logger_1.info(f"related bug blocks now is : {related_bug_blocks_list}")

        # create an instance of Add_Cause_Block
        ticket = Add_Cause_Block(
            ticketid = ticketid,
            cause_name = cause_name,
            added_by = added_by,
            description = description,
            modules = libraries_list,
            bug_blocks = related_bug_blocks_list,
            function_code = function_code ,    
            attachments= attachments
        )


        # call the add cause block function
        updated_ticket, bugs_local = add_cause_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in adding cause block to bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while adding cause block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:
            return {"message": "Cause block added successfully", "ticket": updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while adding cause block to bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add cause block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)


# update a cause block
@router.patch("/editcauseblocks/", status_code=http_status.HTTP_200_OK)
async def edit_cause_blocks_in_bug_ticket(ticket : Update_Cause_Block):
    
    '''

    Endpoint to edit a cause block in a bug ticket

    params : ticket_id,cause_block_id,updated_by
    optional : cause_name,description,related_bug_blocks,libraries, function_code, attachments
    return : 200 if cause block edited successfully, else failure message with bugs 

    '''
    bugs = {}
    
    try:
        # call the update cause block function
        updated_ticket, bugs_local = update_cause_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in updating cause block in bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while updating cause block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:
            return {"message": "Cause block updated successfully", "ticket": updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while updating cause block in bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update cause block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)   
         

# add a solution block to a bug block
@router.post("/addsolutionblocks/", status_code=http_status.HTTP_200_OK)
async def add_solution_blocks_in_bug_ticket(ticketid : int = Form(None,description="Ticket ID of the bug ticket"), 
                                         solution_name : str = Form(None,description="Name of the solution block"), 
                                         steps : str = Form(None,description="Description of the solution block"), 
                                         related_cause_blocks : str = Form(None,description="Related cause block"), 
                                         added_by : int = Form(None,description="User who added the solution block"), 
                                         libraries : str = Form(None,description="List of libraries"), 
                                         function_code : str = Form(None,description="Function code"), 
                                         attachments : List[UploadFile] = File(None)
                                        ):

    '''
    Endpoint to add a solution block to a bug ticket

    params : ticket_id, solution_name,description,related_cause_blocks,added_by
    optional : libararies, function_code, attachments
    return : 200 if solution block added successfully, else failure message with bugs 
    
    '''

    bugs = {}

    try:

        logger_1.info(f"related cause blocks : {related_cause_blocks}")

        if libraries is not None:
            # similar to related cause blocks, libraries will be a string containing list of libraries, ie. "[1,2,3]", get it as [1,2,3] that is a list with integers
            libraries = libraries.strip("[]").split(",")
            # convert the libraries to integers
            libraries = [int(i) for i in libraries]

        if related_cause_blocks is not None:
            # similar to libraries, related cause blocks will be a string containing list of related cause blocks, ie. "[1,2,3]", get it as [1,2,3] that is a list with integers
            related_cause_blocks = related_cause_blocks.strip("[]").split(",")
            # convert the related cause blocks to integers
            related_cause_blocks = [int(i) for i in related_cause_blocks]

        # create a bug ticket object
        ticket = Add_Solution_Block(
            ticketid = ticketid,
            solution_name = solution_name,
            added_by = added_by,
            solution_steps = steps,
            libraries = libraries,
            related_cause_blocks = related_cause_blocks,
            function_code = function_code,
            attachments=attachments    
        )


        # call the add solution block function
        updated_ticket, bugs_local = add_solution_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in adding solution block to bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while adding solution block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:
            return {"message": "Solution block added successfully", "ticket": updated_ticket}
        
    except Exception as e:
        logger_1.error(f"Error occurred while adding solution block to bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add solution block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# edit a solution block in a bug ticket
@router.patch("/editsolutionblocks/", status_code=http_status.HTTP_200_OK)
async def edit_solution_blocks_in_bug_ticket(ticket : Update_Solution_Block):

    '''

    Endpoint to edit a solution block in a bug ticket

    params : ticket_id,solution_block_id
    optional : related_cause_blocks,solution_name,steps,attachments
    return : 200 if solution block edited successfully, else failure message with bugs 

    ''' 

    bugs = {}

    try:
        # call the update solution block function
        updated_ticket, bugs_local = update_solution_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in updating solution block in bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while updating solution block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

        elif updated_ticket is not None:
            return {"message": "Solution block updated successfully", "ticket": updated_ticket}
        
    except Exception as e:
        logger_1.error(f"Error occurred while updating solution block in bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update solution block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# add a result block
@router.post("/addresultblocks/", status_code=http_status.HTTP_200_OK)
async def add_result_block_in_bug_ticket(ticketid : int = Form(None,description="Ticket ID of the bug ticket"),
                                         added_by : int = Form(None,description="User who added the result block"),
                                         result_name : str = Form(None,description="Name of the result block"),
                                         result_summary : str = Form(None,description="Summary of the result block"),
                                         related_solution_blocks : str = Form(None,description="Related solution blocks"),
                                         attachments : List[UploadFile] = File(None) ):
    
    '''
    Endpoint to add a result block to a bug ticket

    params : ticket_id, added_by, result_name, result_summary, related_solution_blocks
    return : 200 if result block added successfully, else failure message with bugs 

    '''

    bugs = {}


    try:
        # similar to related cause blocks, related solution blocks will be a string containing list of related solution blocks, ie. "[1,2,3]", get it as [1,2,3] that is a list with integers
        related_solution_block = related_solution_blocks.strip("[]").split(",")
        # convert the related solution blocks to integers
        related_solution_block_list = [int(i) for i in related_solution_block]

        # create a bug ticket object
        ticket = Add_Result_Block(
            ticketid = ticketid,
            added_by = added_by,
            result_name = result_name,
            result_summary = result_summary,
            related_solution_blocks = related_solution_block_list,
            attachments = attachments
        )

        # call the add result block function
        updated_ticket, bugs_local = add_result_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in adding result block to bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while adding result block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:
            return {"message": "Result block added successfully", "ticket": updated_ticket}

    except Exception as e:
        logger_1.error(f"Error occurred while adding result block to bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add result block to bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)    



# edit a result block
@router.patch("/editresultblocks/", status_code=http_status.HTTP_200_OK)
async def edit_result_block_in_bug_ticket(ticket : Update_Result_Block):
    '''
    Endpoint to edit a result block in a bug ticket

    params : ticket_id, result_block_id, updated_by
    optional : result_name, result_summary, related_solution_blocks
    return : 200 if result block edited successfully, else failure message with bugs 
    
    
    '''
    bugs = {}

    try:
        # call the update result block function
        updated_ticket, bugs_local = update_result_block(ticket)

        if bugs_local:
            logger_1.info(f"Failed in updating result block in bug ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while updating result block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif updated_ticket is not None:
            return {"message": "Result block updated successfully", "ticket": updated_ticket}
    
    except Exception as e:
        logger_1.error(f"Error occurred while updating result block in bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to update result block in bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)



# delete a bug block
@router.patch("/delbugblock/", status_code=http_status.HTTP_200_OK)
async def delete_bug_block(ticket : Delete_Bug_Block):
    '''
    Endpoint to remove list of bug block/s from a bug ticket

    params : ticketid,bug_block_ids,deleted_by

    return : 200 if bug block removed successfully, else failure message with bugs 
        
    
    '''

    bugs = {}

    # call delete bug block service function
    updated_ticket, bugs_local = delete_bug_block_service(ticket)

    if bugs_local:
        logger_1.info(f"Failed in deleting bug block from bug ticket, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        push_to_bug_dict(bugs)
        return JSONResponse({"error": "Error while deleting bug block from bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)

    elif updated_ticket is not None:
        return {"message": "Bug block deleted successfully", "ticket": updated_ticket} 
    


# split bug instances
@router.patch("/splitbugblock/", status_code=http_status.HTTP_200_OK)
async def split_bug_block(ticket : Split_Bug_Block):
    '''
    Endpoint to select a list of instances and move it to a new bug block in the same ticket

    params : ticketid,instances,added_by,bug_block_id
    return : 200 if instances moved to a new bug block successfully, else failure message with bugs 

    '''

    bugs = {}

    # call split bug block service function
    ticket_data,bugs_local = split_bug_block_service(ticket)

    if bugs_local:
        logger_1.info(f"Failed in downloading ticket from s3, {bugs_local}")
        bugs = c_bugs(bugs, bugs_local)
        bugs = s_bugs(bugs)
        push_to_bug_dict(bugs)
        return JSONResponse({"error": "Error while splitting bug block"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    elif ticket_data is not None:
        return {"message" : "Bug block split successfully", "ticket" : ticket_data}




# close a bug ticket
@router.patch("/closeticket/", status_code=http_status.HTTP_200_OK)
async def close_bug_ticket(ticketid : int = Form(None,description="Ticket ID of the bug ticket"),
                            closed_by : int = Form(None,description="User who updated the ticket"),
                            future_imp : str = Form(None,description="Future implementation"),
                            learnings : str = Form(None,description="Learnings"),
                            attachments : List[UploadFile] = File(None)
                            ):

    '''
    Endpoint to close a bug ticket

    params : ticket_id,updated_by
    optional_params : future_imp, learnings
    return : 200 if ticket closed successfully, else failure message with bugs 
    
    '''

    bugs = {}

    try:

        # create a ticket object
        ticket = Close_BugTicket(
            ticketid = ticketid,
            closed_by = closed_by,
            future_imp = future_imp,
            learnings = learnings,
            attachments = attachments
        )


        # call check if ticket is closed func
        closed_status, bugs_local = checK_if_ticket_is_closed(ticket)

        if bugs_local:
            logger_1.info(f"Failed in checking if ticket is closed, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            push_to_bug_dict(bugs)
            return JSONResponse({"error": "Error while closing bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif closed_status == True:
            return JSONResponse({"error" : "Ticket is already closed"},status_code=http_status.HTTP_400_BAD_REQUEST)
        
        elif closed_status == None:
            return JSONResponse({"error": "Error while checking if the ticket is already closed"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif closed_status == False:
            # if the above is passed, call check if all cause blocks have solution block func
            all_cause_blocks_have_sol_blocks, bugs_local = check_if_all_cause_blocks_have_solution_blocks(ticket)

            if bugs_local:
                logger_1.info(f"Failed in checking if all cause blocks have solution blocks, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                push_to_bug_dict(bugs)
                return JSONResponse({"error": "Error while closing bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_cause_blocks_have_sol_blocks == None:
                return JSONResponse({"error": "Error while checking if all cause blocks have solution blocks"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_cause_blocks_have_sol_blocks == True:
                return JSONResponse({"error" : "All cause blocks do not have solution blocks, cannot close the ticket"},status_code=http_status.HTTP_400_BAD_REQUEST)
            
            # call check if all solution blocks have a result block func
            all_solution_blocks_have_result_blocks, bugs_local = check_if_all_solution_blocks_have_result_blocks(ticket)

            if bugs_local:
                logger_1.info(f"Failed in checking if all solution blocks have result blocks, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                push_to_bug_dict(bugs)
                return JSONResponse({"error": "Error while closing bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_solution_blocks_have_result_blocks == None:
                return JSONResponse({"error": "Error while checking if all solution blocks have result blocks"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_solution_blocks_have_result_blocks == True:
                return JSONResponse({"error" : "All solution blocks do not have result blocks, cannot close the ticket"},status_code=http_status.HTTP_400_BAD_REQUEST)

            # call check all tasks are closed func
            all_tasks_closed, bugs_local = check_if_all_tasks_are_closed(ticket)

            if bugs_local:
                logger_1.info(f"Failed in checking if all tasks are closed, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                push_to_bug_dict(bugs)
                return JSONResponse({"error": "Error while closing bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_tasks_closed == None:
                return JSONResponse({"error": "Error while checking if all tasks are closed"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif all_tasks_closed == True:
                return JSONResponse({"error" : "All tasks are not closed, cannot close the ticket"},status_code=http_status.HTTP_400_BAD_REQUEST)
            

            # call update_close_ticket_object
            updated_ticket, bugs_local = update_close_ticket_object(ticket)

            if bugs_local:
                logger_1.info(f"Failed in updating close ticket object, {bugs_local}")
                bugs = c_bugs(bugs, bugs_local)
                bugs = s_bugs(bugs)
                push_to_bug_dict(bugs)
                return JSONResponse({"error": "Error while closing bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            elif updated_ticket is not None:
                return {"message": "Ticket closed successfully", "ticket": updated_ticket}
    except Exception as e:
        logger_1.error(f"Error occurred while closing bug ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to close bug ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)        



# API Endpoint to enabe transfer of bug blocks
@router.patch("/transferbugblock/", status_code=http_status.HTTP_200_OK)
async def transfer_bug_block(input : Transfer_Bug_Block):
    
    '''
    
    API Endpoint to enable transfer of bug blocks from one ticket to another
    
    params : source_ticket_id, target_ticket_id, block_ids, updated_by
    
    return : 200 if bug block transferred successfully, else failure message with bugs
    
    '''
    
    bugs = {}
    
    try:
        
        # call transfer bug block service function
        blocks_to_transfer, bugs_local = get_bug_block_to_transfer(input)
        
        if bugs_local:
            logger_1.info(f"Failed in transferring bug block to another ticket, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error while transferring bug block to another ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif blocks_to_transfer == {}:
            return JSONResponse({"error": "Failed to fetch the bug blocks for transfer, please try again later"}, status_code=http_status.HTTP_400_BAD_REQUEST)
        
        # Add the retrieved bug blocks to the target ticket
        updated_target_ticket, bugs_local = add_bug_block_to_target_ticket(blocks_to_transfer, input)
        
        if bugs_local:
            logger_1.error(f"Error in adding bug blocks to target ticket: {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse(
                {"error": "Error while adding bug blocks to the target ticket."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        elif updated_target_ticket is not None:
            
            # Clean the source ticket
            clean_success = clean_source_ticket(blocks_to_transfer, input)
            
            if not clean_success:
                logger_1.error("Failed to clean source ticket after transferring bug blocks.")
                return JSONResponse(
                    {"error": "Failed to clean source ticket."},
                    status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

            return {"message": "Bug block transferred successfully", "ticket": updated_target_ticket}

        else:
            return JSONResponse(
                {"error": "Unknown error occurred, failed to transfer bug block."},
                status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        
    except Exception as e:
        logger_1.error(f"Error occurred while transferring bug block to another ticket, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to transfer bug block to another ticket"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    
    
    
# API Endpoint to fetch the function rds
@router.get("/getfunctionrds/", status_code=http_status.HTTP_200_OK)
async def get_function_rds():
    
    '''
    
    API Endpoint to fetch the function rds
    
    params : None
    
    return :
        - CSV file with the function rds with status 200
        - Failure JSON response with status 500
    
    
    '''    
    
    bugs = {}
    
    try:
        
        # call the function fetch_function_rds_csv to get the function list
        function_rds, bugs_local = fetch_function_rds_table()
        
        if bugs_local:
            logger_1.info(f"Failed in fetching function rds, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error while fetching function rds"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        elif function_rds is not None:
            # Convert DataFrame to CSV
            csv_buffer = io.StringIO()
            function_rds.to_csv(csv_buffer, index=False)
            csv_data = csv_buffer.getvalue()
            
            # Return CSV data
            return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": "attachment;filename=function_rds.csv"})
        
    except Exception as e:
        logger_1.error(f"Error occurred while fetching function rds, {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to fetch function rds"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
        

# API Endpoint to modify the function name and team
@router.patch("/modifyfunctionrds/", status_code=http_status.HTTP_200_OK)
async def modify_func_rds(inputs: Modify_Function_List):
    """
    API Endpoint to modify the function name and team.

    Parameters:
        - bug_code: Unique identifier for the record (required)
        - function_name: New function name (optional)
        - team_id: New team ID (optional)

    Returns:
        - JSONResponse: Containing status_code and either 'message' or 'error'.
    """
    # Call the update function
    return update_function_record(
        bug_code=inputs.bug_code,
        new_function_name=inputs.function_name,
        new_team_id=inputs.team_id
    )



# API Endpoint to report a manual bug
@router.post("/reportbug/", status_code=http_status.HTTP_201_CREATED)
async def report_bug(inputs: Report_Bug):
    """
    API Endpoint to report a manual bug.

    Params:
    - inputs: Report_Bug object containing ticket ID, reporter ID, and bug description.

    Returns:
    - JSONResponse with success or failure message.
    """
    return report_bug_service(inputs)

    
    
########### test api ################    
# Pydantic model for input validation
class BugRequest(BaseModel):
    bug_obj: dict
    raised_by: int
    ticket_name: str = None
    assigned_team: str = None
    vehicle_num: str = None
    device_id: str = None
    
    
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import logging
from hiper_utils.other_utils.bug_util_up import BugHandler
from hiper_utils.data_models.s3_data_models.bug_ticket import BugInstance

# Initialize the BugHandler instance
bug_handler = BugHandler()

# Assuming BugHandler is already implemented and initialized as `bug_handler`
# Example: bug_handler = BugHandler()


class BugInstanceModel(BaseModel):
    date_of_bug: str = Field(default_factory=lambda: datetime.now().strftime('%d-%m-%Y %H:%M:%S'))
    code: str
    message: str
    input: dict
    
class AddBugRequest(BaseModel):
    bug_obj: Dict[int, BugInstanceModel]
    raised_by: int
    ticket_name: Optional[str] = None
    assigned_team: Optional[str] = None
    vehicle_num: Optional[str] = None
    device_id: Optional[str] = None
  
  
  
  
#   date_of_bug='14-12-2024 16:56:11' code='07020702' message='Check sum mismatch ' input={'device_id': 'U_2024_05_016', 'file_num': 'l_00009.bin'}
    
    
@router.post("/add-bug/")
async def add_bug():
    """
    Endpoint to add a bug using a hardcoded bug object.
    """
    bugs = {}
    # Hardcoded bug object
    hardcoded_bug_obj = {
        1: {
            "date_of_bug": "14-12-2024 16:56:11",
            "code": "07020700",
            "message": "Check sum mismatch",
            "input": {'device_id': 'U_2024_05_016', 'file_num': 'l_00009.bin'}
        }
    }
    try:
        # Call the add_bug function from BugHandler with the raw bug object
        success, bugs_local = bug_handler.add_bug(
            bug_obj=hardcoded_bug_obj,  # Pass raw hardcoded object
            raised_by=26,  # Hardcoded example for raised_by
            assigned_team="4",  # Example assigned team
            vehicle_num="TN24AZ1996",  # Example vehicle number
            device_id="U_2024_05_014"  # Example device ID
        )
        if bugs_local:
            logger_1.info(f"Failed to add bug, {bugs_local}")
            bugs = c_bugs(bugs, bugs_local)
            bugs = s_bugs(bugs)
            return JSONResponse({"error": "Error while adding bug"}, status_code=500)
        elif success:
            return {"message": "Bug added successfully"}
        else:
            return JSONResponse({"error": "Unknown error occurred, failed to add bug"}, status_code=500)
    except Exception as e:
        logger_1.error(f"Error occurred while adding bug: {e}")
        return JSONResponse({"error": "Unknown error occurred, failed to add bug"}, status_code=500)
    

    
