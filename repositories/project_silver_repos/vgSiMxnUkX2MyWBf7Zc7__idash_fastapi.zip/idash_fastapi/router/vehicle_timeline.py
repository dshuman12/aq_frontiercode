import sys
from datetime import datetime, timedelta
from typing_extensions import List, Optional

sys.path.append("../")

from fastapi import APIRouter, HTTPException, Query, Body, status, Response, Depends, UploadFile, File
from fastapi.responses import StreamingResponse
from fastapi_cache.decorator import cache
from fastapi_cache import FastAPICache
import pandas as pd

from utils.vehicle_timline_utils import VehicleTimeLine
from schema.ops_dash_schema import VehicleSummaryRequest, TripRecord, HWUno2Input
from hiper_utils.other_utils.resource_util import ResourceUtil, ResourceS3Path
from hiper_utils.aws.s3.s3 import S3Bucket
from auth_bearer import JWTBearer

hiperftp = S3Bucket(
    bucket_name="hiperftp"
)
router = APIRouter()


@router.get("/fetch_vehicle_timeline", dependencies=[Depends(JWTBearer())])
async def fetch_vehicle_status(vehicle_num: str, start_datetime: str, end_datetime: str):
    print("Fetching Vehicle timeline")

    vehicle_timeline_dict, vehicle_timeline_bug = VehicleTimeLine.get_timeline_data(vehicle_num=vehicle_num,
                                                                                    start_datetime=start_datetime,
                                                                                    end_datetime=end_datetime)

    if vehicle_timeline_bug:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(vehicle_timeline_bug))

    return vehicle_timeline_dict


@router.get("/fetch_raw_pings", dependencies=[Depends(JWTBearer())])
async def fetch_vehicle_status():

    df, bug = hiperftp.download_excel("2024-09-10_raw_pings.csv")
    df.fillna('',inplace=True)
    print(bug)

    return df.to_dict(orient='list')
