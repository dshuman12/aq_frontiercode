# Import inbuilt libraries





# Import third party libraries
from fastapi import APIRouter,status as http_status,Depends
from fastapi.responses import JSONResponse
from auth_bearer import JWTBearer



# Include repos folder for custom libraries



# Declare variables used 

# Library Code for Conversation Module
lib_code_CM = "48"
lib_ver_CM = "00"


lib_code_ver_CM = f"{lib_code_CM}{lib_ver_CM}"



# Include custom libraries
from hiper_utils.Loggers.python_logger import LoggerFactory
from hiper_utils.Decoraters.exception_handler import combine_bugs as c_bugs,serialize_bug_instance as s_bugs
from hiper_utils.Loggers.python_logger import LoggerFactory
from utils.conversation_util import *
from schema.conversation_schema import *
from storage_settings import bug_ticket_path,feat_ticket_path

router = APIRouter()

logger_1 = LoggerFactory(name="conversation_route", file_name="message.log").get_logger()


# add conversation
@router.post("/addconversation/", status_code=http_status.HTTP_200_OK)
async def add_conversation_block(conversation : Add_Conversation_Model):


    '''
    Endpoint to add a conversation block to a ticket

    params : ticketid, added_by, text
    optional params : parent_block
    return : returns 200 OK if conversation block is added, 500 if Internal Server Error
    
    '''

    bugs = {}


    ticket_location = feat_ticket_path

    if conversation.ticket_type == 1:
        ticket_location = bug_ticket_path
    
    # all fields are mandatory, if not provided, return 400
    if conversation.ticketid is None or conversation.added_by is None or conversation.text is None:
        return JSONResponse({"error": "Ticket id, Added by and Text are mandatory fields"}, status_code=http_status.HTTP_400_BAD_REQUEST)
    
    # call the add_conversation_to_s3 function
    updated_ticket_data,bugs_local = add_conversation_to_ticket(conversation,ticket_location)


    if bugs_local:
        logger_1.error(f"Adding the conversation to the feat ticket in s3 failed, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return JSONResponse({"error": "Error updating ticket to S3"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    else:
        logger_1.info(f"Conversation added successfully")
        return {"message" : "Conversation added successfully", "ticket_data" : updated_ticket_data}
    
    
# delete conversation
@router.post("/delconversation/", status_code=http_status.HTTP_200_OK)
async def delete_conversation_block(conversation : Delete_Conversation_Model):
    '''
    Endpoint to delete a conversation block in a ticket

    params : ticketid, deleted_by, convo_id,ticket_type
    return : returns 200 OK if conversation block is deleted, 500 if Internal Server Error
    
    '''

    bugs = {}

    # all fields are mandatory, if not provided, return 400
    if conversation.ticketid is None or conversation.deleted_by is None or conversation.convo_id is None or conversation.ticket_type is None:
        return JSONResponse({"error": "Ticket id, Deleted by and Conversation id are mandatory fields"}, status_code=http_status.HTTP_400_BAD_REQUEST)
    
    # call the delete_conversation_from_s3 function
    updated_ticket_data,bugs_local = delete_conversation_from_ticket(conversation)

    if bugs_local:
        logger_1.error(f"Deleting the conversation from the feat ticket in s3 failed, {bugs_local}")
        bugs = c_bugs(bugs,bugs_local)
        bugs = s_bugs(bugs)
        return JSONResponse({"error": "Error updating ticket to S3"}, status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    else:
        logger_1.info(f"Conversation deleted successfully")
        return {"message" : "Conversation deleted successfully", "ticket_data" : updated_ticket_data}

