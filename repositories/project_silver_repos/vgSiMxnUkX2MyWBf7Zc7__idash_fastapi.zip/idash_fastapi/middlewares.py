import time
from fastapi import Request, HTTPException
import jwt
from utils.users_utils import JWT_ALGORITHM,JWT_SECRET
from auth_bearer import JWTBearer


async def refresh_token_middleware(request: Request, call_next):
    print("entered refresh token middleware")
    
    # Get tokens from cookies
    access_token = request.cookies.get('access_token')
    refresh_token = request.cookies.get('refresh_token')
    
    print("Access token: ", access_token)
    
    print("Refresh token: ", refresh_token)
    
    print("path is: ", request.scope['path'])
    
    # print all the dependencies of the request
    print("dependencies are: ", request.scope)
    
    return await call_next(request)


    # If access token is present, check if it is expired
    if access_token is None:
        
        print("No access token found")
        
        # If refresh token is valid, generate a new access token
        if refresh_token and not is_token_expired(refresh_token):
            print("Refresh token is valid, generating new access token")
            
            # Generate new access token
            new_access_token = generate_new_access_token(refresh_token)
            
            # Continue the request and set the new access token in the response
            response = await call_next(request)
            response.set_cookie(
                key="access_token",
                value=new_access_token,
                httponly=True,
                max_age=10,  # 30 minutes
                secure=False,  # Set to True in production with HTTPS
                samesite='Lax'
            )
            print("New access token set")
            return response
        
        else:
            # If refresh token is invalid or expired, raise 401 Unauthorized
            raise HTTPException(status_code=401, detail="Refresh token expired or invalid. Please log in again.")
    
    # If no refresh is needed, continue to the next part of the request
    return await call_next(request)

# Helper functions for token checks and generation
def is_token_expired(token: str) -> bool:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload["expires"] < time.time()
    except jwt.InvalidTokenError:
        return True

def generate_new_access_token(refresh_token: str) -> str:
    try:
        # Decode the refresh token
        payload = jwt.decode(refresh_token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload["user_name"]

        # Generate new access token (valid for 30 minutes)
        access_token_payload = {
            "user_name": username,
            "expires": time.time() + 1800  # 30 minutes
        }
        return jwt.encode(access_token_payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid refresh token.")
