# import inbuilt 
import os

# Import third party libraries
import threading
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi_cache import FastAPICache
from fastapi_cache.backends.inmemory import InMemoryBackend
from router.users import router as auth_router
from router.feature_tickets import router as feat_ticket_router
from router.bug_tickets import router as bug_ticket_router
from router.installation_dashboard import router as installation_router
from router.ops_dashboard import router as ops_router
from router.tasks import router as tasks_router
from utils.feature_tickets_util import write_changes_to_rds, write_changes_to_s3
from utils.tasks_utils import process_task_deletion_queue, write_updates_to_task_rds
from utils.bug_tickets_util import write_changes_to_bug_ticket_rds, write_bug_ticket_changes_to_s3
from utils.vehicle_health_util import write_vh_changes_to_s3
from router.feedback import router as feedback_router
from router.attachments import router as attachment_router
from router.conversation import router as conversation_router
from router.benchmark_testing import router as benchmark_router
from router.vehicle_health_ticket import router as vehicle_health_ticket_router
from router.vehicle_timeline import router as vehicle_time_line_route
from router.vehicle_registration import router as vehicle_registration_router
from router.fleets import router as fleets_router
from router.make_model import router as make_model_router
from router.conversation import router as conversation_router
from router.auto_trips import router as auto_trips_router
from router.device_onboarding import router as device_onboarding_router
from storage_settings import GLOBAL_TEMP_DIR, clean_global_temp_dir
from router.customer_comms import router as customer_comms_router
from router.fuel_filling_router import router as fuel_filling_router
from router.trips_management_router import router as trip_management_router
from router.vehicle_registration import router as vehicle_registration_router
from router.fleets import router as fleets_router
from router.make_model import router as make_model_router
from middlewares import *
from router.auto_trips import router as auto_trips_router
from router.device_onboarding import router as device_onboarding_router
from hiper_utils.Loggers.python_logger import LoggerFactory
from storage_settings import GLOBAL_TEMP_DIR, clean_global_temp_dir
from router.customer_comms import router as customer_comms_router
from router.test import router as ts_router
from router.datalake_downloader import router as ddl_router

# include custom libraries



app = FastAPI()

app.include_router(auth_router, prefix="/idash/users", tags=["users"])
app.include_router(feat_ticket_router, prefix="/idash/features", tags=["features"])
app.include_router(installation_router, prefix="/installation", tags=["installation"])
app.include_router(bug_ticket_router, prefix="/idash/bugs", tags=["bugs"])
app.include_router(ops_router, prefix="/ops_dash", tags=["Ops Dashboard"])
app.include_router(tasks_router, prefix="/idash/tasks", tags=["Tasks"])
app.include_router(feedback_router, prefix="/idash/feedback", tags=["feedback"])
app.include_router(attachment_router, prefix="/idash/attachments", tags=["attachments"])
app.include_router(benchmark_router, prefix="/idash/benchmark", tags=["benchmark"])
app.include_router(vehicle_health_ticket_router, prefix="/idash/vehicle_health", tags=["vehicle_health_ticket"])
app.include_router(vehicle_time_line_route, prefix="/vehicle_timeline", tags=["Vehicle Timeline"])
app.include_router(vehicle_registration_router, prefix="/idash/vehicle_registration", tags=["vehicle_registration"])
app.include_router(fleets_router, prefix="/idash/fleets", tags=["fleets"])
app.include_router(make_model_router, prefix="/idash/make_model", tags=["make_model"])
app.include_router(conversation_router, prefix="/idash/conversation", tags=["conversation"])
app.include_router(auto_trips_router, prefix="/auto_trips", tags=["auto_trips"])
app.include_router(device_onboarding_router, prefix="/hw", tags=["device_onboarding"])
app.include_router(customer_comms_router, prefix="/idash/c_comms", tags=["customer_comms"])
app.include_router(fuel_filling_router, prefix="/ops_dash", tags=["ops Dashboard"])
app.include_router(trip_management_router, prefix="/ops_dash", tags=["ops Dashboard"])
app.include_router(ts_router, prefix="/ts")
app.include_router(ddl_router, prefix="/idash/ddl", tags=["datalake_downloader"])

# allow all origins
origins = ["http://localhost:3001", "http://localhost:3000", "https://www.hiperautomotive.com/", 
          "https://dxlq5q0lkehfz.cloudfront.net", "https://th1zhzcf-3000.inc1.devtunnels.ms/"]


app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger_1 = LoggerFactory(name="user_module_logs", file_name="message.log").get_logger()


@app.get("/")
def read_root():
    return {"message": "Tickets API ready to be used."}


@app.on_event("startup")
async def on_startup():
    FastAPICache.init(InMemoryBackend(), prefix="fastapi-cache")


# Start the background task
def start_background_task():
    # Start the background task for writing changes to RDS
    thread = threading.Thread(target=write_changes_to_rds)
    thread.daemon = True
    thread.start()

    # Start the background task for writing changes to Task RDS
    task_thread = threading.Thread(target=write_updates_to_task_rds)
    task_thread.daemon = True
    task_thread.start()

    # Start the background task for deleting task from rds
    delete_task_thread = threading.Thread(target=process_task_deletion_queue)
    delete_task_thread.daemon = True
    delete_task_thread.start()

    # Start the background task for writing changes to S3
    s3_thread = threading.Thread(target=write_changes_to_s3)
    s3_thread.daemon = True
    s3_thread.start()

    # Start the background task for writing changes to Bug Ticket RDS
    bug_ticket_thread = threading.Thread(target=write_changes_to_bug_ticket_rds)
    bug_ticket_thread.daemon = True
    bug_ticket_thread.start()

    # Start the background task for writing changes to Bug Ticket S3
    bug_ticket_s3_thread = threading.Thread(target=write_bug_ticket_changes_to_s3)
    bug_ticket_s3_thread.daemon = True
    bug_ticket_s3_thread.start()

    # Start the background task for writing changes to Vehicle Health Ticket S3
    vh_s3_thread = threading.Thread(target=write_vh_changes_to_s3)
    vh_s3_thread.daemon = True
    vh_s3_thread.start()


@app.on_event("startup")
def on_startup():
    start_background_task()


@app.on_event("startup")
def startup_event():
    """Application startup hook to ensure temp directory exists."""
    if not os.path.exists(GLOBAL_TEMP_DIR):
        os.makedirs(GLOBAL_TEMP_DIR)
    print(f"Temporary directory {GLOBAL_TEMP_DIR} is ready!")


@app.on_event("shutdown")
def shutdown_event():
    """Application shutdown hook to clean up global temporary directory."""
    clean_global_temp_dir()



if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8002, reload=True)
