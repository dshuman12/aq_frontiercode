locals {
  producerLambdaName = var.PRODUCER_LAMBDA_NAME
}

module "service_monitor" {
  source  = "app.terraform.io/onmo/module-service-monitor/aws"
  version = "~> 2.0"

  service_config = local.service_config # Mandatory

  lambda_functions = [ # Mandatory
    { name = module.createCardRepayment.name, alert_config = {
      duration = {
        enabled           = true
        threshold         = 1500
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.createDirectDebit.name },
    { name = module.deleteDirectDebit.name },
    { name = module.getDirectDebit.name },
    { name = module.createDirectDebitHosted.name, alert_config = {
      duration = {
        enabled           = true
        threshold         = 1200
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.mandateUpdated.name },
    { name = module.webhookHandler.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.directDebits.name },
    { name = module.getPaymentMethodByMandateId.name },
    { name = module.cards.name },
    { name = module.directDebitRepaymentDue.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
    } },
    { name = module.directDebitRepaymentScheduler.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      }
    } },
    { name = module.directDebitRepaymentProcessor.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.throttlingDlqToS3.name },
    { name = module.repaymentProcessorDlqToS3.name },
    { name = module.nextDirectDebitIntentDate.name },
    { name = module.getCPASubscription.name },
    { name = module.deleteMandate.name },
    { name = module.updateDirectDebitHosted.name, alert_config = {
      duration = {
        enabled           = true
        threshold         = 1200
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.sendSFMCComms.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.ddRetryListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.ddSearchPaidInstalments.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
    } },
    { name = module.ddFullStatementScheduler.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
    } },
    { name = module.ddFullStatementDlqToS3.name },
    { name = module.retryProcessorDlqToS3.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      },
    } },
    { name = module.directDebitRetryProcessor.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      },
    } },
    { name = module.repaymentFailedListener.name, alert_config = {
      errors = {
        enabled           = true
        threshold         = 1.0
        time_window       = "last_30m"
        renotify_interval = 0
      },
      duration = {
        enabled           = true
        threshold         = 15000
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.createPayByBankHosted.name, alert_config = {
      duration = {
        enabled           = true
        threshold         = 1200
        time_window       = "last_1h"
        renotify_interval = 0
      }
    } },
    { name = module.getPaymentReceiptBySessionId.name },
  ]
  api_gateways = [ # Mandatory
    { name = module.rest_api_gateway.name },
  ]

  #  github_repository = var.GITHUB_REPO               # Optional 
  #  runbook_url       = "https://example.com/runbook" # Optional
  notification_emails         = ["aline.francois@onmo.app"]
  notification_slack_channels = ["${var.SLACK_CHANNEL}"]
  monitor_configs = { # Optional
    api_latency = {
      enabled           = true
      threshold         = 15000
      time_window       = "last_30m"
      renotify_interval = 0
      warning_threshold = 0
    },
    lambda_errors = {
      enabled = false
    },
    api_5xx_errors = {
      enabled           = true
      threshold         = 0
      time_window       = "last_30m"
      renotify_interval = 0
      warning_threshold = 0
    },
    api_4xx_errors = {
      enabled           = false
      threshold         = 15.0
      time_window       = "last_30m"
      warning_threshold = 0
    },
    lambda_throttles = {
      enabled           = true
      threshold         = 5
      time_window       = "last_1h"
      renotify_interval = 0
      warning_threshold = 0
    }
  }
}
