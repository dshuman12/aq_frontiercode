module "rest_api_gateway" {
  source         = "app.terraform.io/onmo/module-rest-api-gateway/aws"
  version        = " 1.1.0"
  service_config = local.service_config
  gateway_config = local.gateway_config

  description = "REST API for the Repayment Service for ${var.ENVIRONMENT}"

  aws_integration_paths = [
    {
      path_from_root = "one-off-payment/card"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createCardRepayment"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "cards"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-cards"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "mandate/{mandateId}"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getPaymentMethodByMandateId"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "DELETE"
          lambda_function_name   = "${local.function_prefix}-deleteMandate"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
      ]
    },
    {
      path_from_root = "docs"
      integrations = [
        {
          method               = "GET"
          lambda_function_name = "${local.function_prefix}-docs"
        }
      ]
    },
    {
      path_from_root = "doc"
      integrations = [
        {
          method               = "GET"
          lambda_function_name = "${local.function_prefix}-docs"
        }
      ]
    },
    {
      path_from_root = "direct-debit"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createDirectDebit"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getDirectDebit"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "direct-debit/hosted"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createDirectDebitHosted"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "PUT"
          lambda_function_name   = "${local.function_prefix}-updateDirectDebitHosted"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "direct-debit/{paymentMethodId}"
      integrations = [
        {
          method                 = "DELETE"
          lambda_function_name   = "${local.function_prefix}-deleteDirectDebit"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        },
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getDirectDebit"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "one-off-payment/payment-successful"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-paymentSuccessful"
          lambda_authorizer_name = "${local.function_prefix}-repaymentAuthorizer"
        }
      ]
    },
    {
      path_from_root = "direct-debit/mandate-updated"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-mandateUpdated"
          lambda_authorizer_name = "${local.function_prefix}-repaymentAuthorizer"
        }
      ]
    },
    {
      path_from_root = "webhook-handler"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-webhookHandler"
          lambda_authorizer_name = "${local.function_prefix}-repaymentAuthorizer"
        }
      ]
    },
    {
      path_from_root = "payment-link"
      cors           = { allow_origins = [var.SF_FE_URL, var.SF_LIGHTNING_FE_URL], allow_custom_headers = ["Content-Type", "x-api-key", "X-API-KEY", "Cookie"] }
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-generatePaymentLink"
          lambda_authorizer_name = "${var.ENVIRONMENT}-account-service-authorizer"
        }
      ]
    },
    {
      path_from_root = "direct-debit/repayment-due"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-directDebitRepaymentDue"
          lambda_authorizer_name = "${local.function_prefix}-repaymentAuthorizer"
        },
      ]
    },
    {
      path_from_root = "direct-debit/next-payment-intent-date"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-nextDirectDebitIntentDate"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "mandate/pending"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-hasPendingMandate"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "one-off-payment/pay-by-bank"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createPayByBankHosted"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "one-off-payment/checkout"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createCheckoutRepayment"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "one-off-payment/intent"
      integrations = [
        {
          method                 = "POST"
          lambda_function_name   = "${local.function_prefix}-createIntentRepayment"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "payment-receipt/{sessionId}"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getPaymentReceiptBySessionId"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "payment-status/{sessionId}"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getPaymentStatusBySessionId"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
    {
      path_from_root = "cpa/subscription"
      integrations = [
        {
          method                 = "GET"
          lambda_function_name   = "${local.function_prefix}-getCPASubscription"
          lambda_authorizer_name = "${var.ENVIRONMENT}-authentication-authorizer"
        }
      ]
    },
  ]

  lambda_authorizers = [
    {
      lambda_function_name = "${var.ENVIRONMENT}-authentication-authorizer",
      auth_config          = { type = "token", location = "header", key_name = "Authorization" }
      ttl                  = 0
    },
    {
      lambda_function_name = "${local.function_prefix}-repaymentAuthorizer",
      auth_config          = { type = "request", location = "querystring", key_name = "onmokey" }
      ttl                  = 0
    },

    {
      lambda_function_name = "${var.ENVIRONMENT}-account-service-authorizer",
      auth_config          = { type = "request" },
      ttl                  = 0
    }
  ]


}
