# keep the same lambda_function_name for the module name & in:
# ./src/functions/lambda_function_name/lambda_function_name.ts
locals {
  dynamo_prefix       = "arn:aws:dynamodb:${var.REGION}:${var.AWS_ACCOUNT_ID}:table"
  kinesis_prefix      = "arn:aws:kinesis:${var.REGION}:${var.AWS_ACCOUNT_ID}:stream"
  glue_schema_prefix  = "arn:aws:glue:${var.REGION}:${var.AWS_ACCOUNT_ID}:schema"
  sqs_prefix          = "arn:aws:sqs:${var.REGION}:${var.AWS_ACCOUNT_ID}"
  event_stream_prefix = "arn:aws:kinesis:${var.REGION}:${var.AWS_ACCOUNT_ID}:stream"
  scheduler_prefix    = "arn:aws:scheduler:${var.REGION}:${var.AWS_ACCOUNT_ID}:schedule-group"
  s3_prefix           = "arn:aws:s3:::"
}
module "createIntentRepayment" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createIntentRepayment"
  description          = "Lambda function to interact with Stripe API to create a payment intent and return paymentSecret and ephemeralKey"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}
module "createCheckoutRepayment" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createCheckoutRepayment"
  description          = "Lambda function to interact with Stripe API to create a checkout session accepting configurable payment methods"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}
module "createCardRepayment" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createCardRepayment"
  description          = "Lambda function to interact with Stripe API to create a payment intent"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "cards" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "cards"
  description          = "Lambda function to get customer card details"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "getPaymentMethodByMandateId" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "getPaymentMethodByMandateId"
  description          = "returns payment method by mandateId"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "docs" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "docs"
  description          = "Lambda function to get customer card details"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  memory_size    = 2048
  timeout        = 900
}

module "webhookHandler" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.webhookHandler_lambda_environment_variables

  lambda_function_name = "webhookHandler"
  description          = "Receives webhook events from repayments processor"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN, var.SALESFORCE_SECRET_ARN, var.POSTHOG_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect = "Allow",
      Actions = [
        "kinesis:DescribeStream",
        "kinesis:PutRecord",
        "kinesis:PutRecords"
      ],
      Resource = [
        "${local.kinesis_prefix}/onmo-business-events-stream-${var.ENVIRONMENT}"
      ]
    },
    {
      Effect = "Allow",
      Actions = [
        "glue:GetRegistry",
        "glue:GetSchema",
        "glue:GetSchemaByDefinition",
        "glue:GetSchemaVersion",
        "glue:ListRegistries",
        "glue:ListSchemas"
      ],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:CreateSchedule", "scheduler:ListSchedules", "scheduler:DeleteSchedule"],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["iam:PassRole"],
      Resource = [aws_iam_role.scheduler_role.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["ssm:GetParameter"],
      Resource = ["arn:aws:ssm:${var.REGION}:${var.AWS_ACCOUNT_ID}:parameter/repayment-service/*"]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "createDirectDebit" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createDirectDebit"
  description          = "Returns a clientSecret necessary to create a form for direct debit"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "updateDirectDebitHosted" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "updateDirectDebitHosted"
  description          = "Returns a clientSecret necessary to create a form for direct debit, used to create new mandate before cancelling old one when the new one is active."

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "createDirectDebitHosted" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createDirectDebitHosted"
  description          = "Returns a clientSecret necessary to create a form for direct debit"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "deleteMandate" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "deleteMandate"
  description          = "Lambda function to delete a direct debit mandate"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "deleteDirectDebit" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "deleteDirectDebit"
  description          = "Lambda function to delete a direct debit mandate"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "directDebits" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "directDebits"
  description          = "Retrieves direct debit data for current user"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "getDirectDebit" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "getDirectDebit"
  description          = "Lambda function to get a direct debit details"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "paymentSuccessful" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "paymentSuccessful"
  description          = "Lambda function to raise a RepaymentCollected event on Stripe payment success"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect = "Allow",
      Actions = [
        "kinesis:DescribeStream",
        "kinesis:PutRecord",
        "kinesis:PutRecords"
      ],
      Resource = [
        "${local.kinesis_prefix}/onmo-business-events-stream-${var.ENVIRONMENT}"
      ]
    },
    {
      Effect = "Allow",
      Actions = [
        "glue:GetRegistry",
        "glue:GetSchema",
        "glue:GetSchemaByDefinition",
        "glue:GetSchemaVersion",
        "glue:ListRegistries",
        "glue:ListSchemas"
      ],
      Resource = ["*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "mandateUpdated" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "mandateUpdated"
  description          = "Lambda function to raise a MandateUpdated event on Stripe mandate update"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect = "Allow",
      Actions = [
        "kinesis:DescribeStream",
        "kinesis:PutRecord",
        "kinesis:PutRecords"
      ],
      Resource = [
        "${local.kinesis_prefix}/onmo-business-events-stream-${var.ENVIRONMENT}"
      ]
    },
    {
      Effect = "Allow",
      Actions = [
        "glue:GetRegistry",
        "glue:GetSchema",
        "glue:GetSchemaByDefinition",
        "glue:GetSchemaVersion",
        "glue:ListRegistries",
        "glue:ListSchemas"
      ],
      Resource = ["*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "repaymentFailedListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "repaymentFailedListener"
  description          = "Lambda function to respond to a RepaymentFailed event raised from the Stripe webhook"

  execution_from = [{ service = "Kinesis", source_arn = data.aws_kinesis_stream.business_events_stream.arn, kinesis_config = {
    starting_position = "LATEST",
    max_retry_attempts : 5,
    max_record_age = 900,
    on_failure = {
      destination_arn     = "${local.sqs_prefix}:${var.ONMO_BUSINESS_EVENTS_STREAM_DLQ}"
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["RepaymentFailed"] } })
  } }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN, var.SALESFORCE_SECRET_ARN]
    },
    {
      Effect   = "Allow",
      Actions  = ["glue:GetSchemaVersion"],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["kinesis:GetRecords", "kinesis:GetShardIterator", "kinesis:DescribeStream", "kinesis:PutRecord", "kinesis:PutRecords"],
      Resource = ["${local.event_stream_prefix}/${var.ONMO_BUSINESS_EVENTS_STREAM}"]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = ["${local.sqs_prefix}:${var.ONMO_BUSINESS_EVENTS_STREAM_DLQ}", aws_sqs_queue.sfmcCommsQueue.arn, aws_sqs_queue.cpaCommsQueue.arn]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["ssm:GetParameter"],
      Resource = ["arn:aws:ssm:${var.REGION}:${var.AWS_ACCOUNT_ID}:parameter/repayment-service/*"]
    }

  ]
  memory_size = 2048
  timeout     = 900
}

module "repaymentFailedEnrich" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables
  lambda_function_name  = "repaymentFailedEnrich"
  description           = "A lambda to enrich repaymentFailed event"
  execution_from        = []
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["glue:GetSchemaVersion"],
      Resource = ["*"]
    }
  ]
  memory_size = 512
  timeout     = 3
}


module "generatePaymentLink" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "generatePaymentLink"
  description          = "Lambda function to generate payment link"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.REPAYMENT_SECRET_ARN, var.MAMBU_SECRET_ARN, var.POSTHOG_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "repaymentAuthorizer" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "repaymentAuthorizer"
  description          = "Authorizer for ${var.SERVICE_NAME} API Gateway"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    { Effect = "Allow", Actions = ["secretsmanager:GetSecretValue"], Resource = [var.REPAYMENT_SECRET_ARN] }
  ]
  memory_size = 2048
  timeout     = 900
}

module "directDebitRepaymentDue" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "directDebitRepaymentDue"
  description          = "Receives webhook events from Mambu when a repayment is due in 7 days. It puts messages in repayment-due-throttling-queue"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.repaymentDueThrottlingQueue.arn]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "directDebitRepaymentScheduler" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.scheduler_lambda_environment_variables

  lambda_function_name = "directDebitRepaymentScheduler"
  description          = "Lambda to schedule a direct debit repayment on the due date. It fetches messages from repayment-due-throttling-queue"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.repaymentDueThrottlingQueue.arn
    # Configured to process max 50 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 50,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.repaymentDueThrottlingQueue.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:*"],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["iam:PassRole"],
      Resource = [aws_iam_role.scheduler_role.arn]
    },
    {
      Effect  = "Allow",
      Actions = ["s3:PutObject"],
      Resource = [
        "${local.s3_prefix}${var.ONMO_DATALAKE_BUCKET}",
        "${local.s3_prefix}${var.ONMO_DATALAKE_BUCKET}/*",
      ]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "directDebitRepaymentProcessor" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  # for execution_from see scheduler_invoke_lambda_policy in 11-scheduler.tf
  lambda_function_name = "directDebitRepaymentProcessor"
  description          = "Lambda to take a direct debit payment on the due date. Invoked from the EventBridge Scheduler"

  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.directDebitRepaymentProcessorDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:*"],
      Resource = ["*"]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "throttlingDlqToS3" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "throttlingDlqToS3"
  description          = "Lambda to archive failed events to S3. It fetches messages from repayment-due-throttling-dlq"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.repaymentDueThrottlingDlq.arn
    # Configured to process max 500 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 500,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.repaymentDueThrottlingDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["s3:PutObject"],
      Resource = [aws_s3_bucket.repayment_dlq_archive.arn, "${aws_s3_bucket.repayment_dlq_archive.arn}/*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "repaymentProcessorDlqToS3" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "repaymentProcessorDlqToS3"
  description          = "Lambda to archive failed events to S3. It fetches messages from direct-debit-repayment-processor-dlq"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.directDebitRepaymentProcessorDlq.arn
    # Configured to process max 500 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 500,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.directDebitRepaymentProcessorDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["s3:PutObject"],
      Resource = [aws_s3_bucket.repayment_dlq_archive.arn]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "nextDirectDebitIntentDate" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "nextDirectDebitIntentDate"
  description          = "Lambda function to get the next direct debit payment intent date"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "hasPendingMandate" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "hasPendingMandate"
  description          = "Lambda function to tell if a customer has pending mandates"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "getCPASubscription" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "getCPASubscription"
  description          = "Lambda function to get CPA (Continuous Payment Authority) subscription details for a customer"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["ssm:GetParameter"],
      Resource = ["arn:aws:ssm:${var.REGION}:${var.AWS_ACCOUNT_ID}:parameter/repayment-service/*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "sendSFMCComms" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "sendSFMCComms"
  description          = "Lambda to send customer SMS & emails via SFMC. It fetches messages from sfmc-comms-queue"

  execution_from = [
    {
      service    = "SQS"
      source_arn = aws_sqs_queue.sfmcCommsQueue.arn
      # Configured to process max 50 records after the interval of 5 seconds
      sqs_config = {
        batch_size              = 50,
        enabled                 = true,
        max_batch_window        = 5
        function_response_types = ["ReportBatchItemFailures"]
      }
    },
    {
      service    = "SQS"
      source_arn = aws_sqs_queue.cpaCommsQueue.arn
      sqs_config = {
        batch_size              = 50,
        enabled                 = true,
        max_batch_window        = 5
        function_response_types = ["ReportBatchItemFailures"]
      }
    }
  ]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.sfmcCommsQueue.arn, aws_sqs_queue.cpaCommsQueue.arn]
    }
  ]
  memory_size = 2048
  timeout     = 900
}


module "ddRetryListener" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.dd_retry_listener_lambda_environment_variables

  lambda_function_name = "ddRetryListener"
  description          = "Lambda function to respond to a ddFailedEligbileForRetry event raised from the repaymentFailedListener"

  execution_from = [{ service = "Kinesis", source_arn = data.aws_kinesis_stream.business_events_stream.arn, kinesis_config = {
    starting_position = "LATEST",
    max_retry_attempts : 15,
    max_record_age = 900,
    on_failure = {
      destination_arn     = "${local.sqs_prefix}:${var.ONMO_BUSINESS_EVENTS_STREAM_DLQ}"
      destination_service = "SQS"
    }
    filter_criteria = jsonencode({ data = { event = ["DDFailedEligibleForRetry"] } })
  } }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
      Resource = [var.MAMBU_SECRET_ARN]
    },
    {
      Effect   = "Allow",
      Actions  = ["glue:GetSchemaVersion"],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["kinesis:GetRecords", "kinesis:GetShardIterator", "kinesis:DescribeStream", "kinesis:PutRecord", "kinesis:PutRecords"],
      Resource = ["${local.event_stream_prefix}/${var.ONMO_BUSINESS_EVENTS_STREAM}"]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = ["${local.sqs_prefix}:${var.ONMO_BUSINESS_EVENTS_STREAM_DLQ}", aws_sqs_queue.sfmcCommsQueue.arn]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:*"],
      Resource = ["*"]
    },
    {
      Effect   = "Allow",
      Actions  = ["iam:PassRole"],
      Resource = [aws_iam_role.scheduler_role.arn]
    },
    {
      Effect  = "Allow",
      Actions = ["s3:PutObject"],
      Resource = [
        "${local.s3_prefix}${var.ONMO_DATALAKE_BUCKET}",
        "${local.s3_prefix}${var.ONMO_DATALAKE_BUCKET}/*",
      ]
    },

  ]
  memory_size = 2048
  timeout     = 900
}

module "ddSearchPaidInstalments" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  # for execution_from see scheduler_invoke_lambda_policy in 11-scheduler.tf
  lambda_function_name = "ddSearchPaidInstalments"
  description          = "Called from a daily cron from EventBridge. Search for instalments dueDate in 8 days already paid and sends messages to the directDebiyFullStatement queue"

  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.MAMBU_SECRET_ARN]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.ddFullStatementCheckQueue.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:*"],
      Resource = ["*"]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "ddFullStatementScheduler" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.scheduler_lambda_environment_variables

  lambda_function_name = "ddFullStatementScheduler"
  description          = "Lambda to check if a user who already paid their instalment has full statement as their preference to schedule their direct debit payment if needed."

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.ddFullStatementCheckQueue.arn
    # Configured to process max 10 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 50,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.ddFullStatementCheckQueue.arn, aws_sqs_queue.repaymentDueThrottlingQueue.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["iam:PassRole"],
      Resource = [aws_iam_role.scheduler_role.arn]
    },
  ]
  memory_size          = 2048
  timeout              = 900
  reserved_concurrency = 8
}

module "ddFullStatementDlqToS3" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "ddFullStatementDlqToS3"
  description          = "Lambda to archive failed events to S3. It fetches messages from dd-full-statement-check-dlq"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.ddFullStatementCheckDlq.arn
    # Configured to process max 500 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 500,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.ddFullStatementCheckDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["s3:PutObject"],
      Resource = [aws_s3_bucket.repayment_dlq_archive.arn, "${aws_s3_bucket.repayment_dlq_archive.arn}/*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "directDebitRetryProcessor" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  # for execution_from see scheduler_invoke_lambda_policy in 11-scheduler.tf
  lambda_function_name = "directDebitRetryProcessor"
  description          = "Lambda to retry a failed direct debit payment. Invoked from the EventBridge Scheduler"

  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.retryProcessorDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["scheduler:*"],
      Resource = ["*"]
    },
  ]
  memory_size = 2048
  timeout     = 900
}

module "retryProcessorDlqToS3" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "retryProcessorDlqToS3"
  description          = "Lambda to archive failed events to S3. It fetches messages from direct-debit-retry-processor-dlq"

  execution_from = [{
    service    = "SQS"
    source_arn = aws_sqs_queue.retryProcessorDlq.arn
    # Configured to process max 500 records after the interval of 5 seconds
    sqs_config = {
      batch_size       = 500,
      enabled          = true,
      max_batch_window = 5
    }
  }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["sqs:*"],
      Resource = [aws_sqs_queue.retryProcessorDlq.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["s3:PutObject"],
      Resource = [aws_s3_bucket.repayment_dlq_archive.arn]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "ddRetryProdWait" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "ddRetryProdWait"
  description          = "Called by EventBridge Scheduler. It publishes repaymentFailed and repaymentCollected event after waiting 2 working days to mimic prod timings."

  # for execution_from see scheduler.tf 

  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN]
    },
    {
      Effect = "Allow",
      Actions = [
        "kinesis:DescribeStream",
        "kinesis:PutRecord",
        "kinesis:PutRecords"
      ],
      Resource = [
        "${local.kinesis_prefix}/onmo-business-events-stream-${var.ENVIRONMENT}"
      ]
    },
    {
      Effect = "Allow",
      Actions = [
        "glue:GetRegistry",
        "glue:GetSchema",
        "glue:GetSchemaByDefinition",
        "glue:GetSchemaVersion",
        "glue:ListRegistries",
        "glue:ListSchemas"
      ],
      Resource = ["*"]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "createPayByBankHosted" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "createPayByBankHosted"
  description          = "Lambda to create a payment link for pay by bank"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN, var.MAMBU_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:UpdateItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "getPaymentReceiptBySessionId" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "getPaymentReceiptBySessionId"
  description          = "Lambda function to get payment receipt by sessionId"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN]
    }
  ]
  memory_size = 2048
  timeout     = 900
}
module "getPaymentStatusBySessionId" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  lambda_function_name = "getPaymentStatusBySessionId"
  description          = "Lambda function to get payment status by sessionId"

  execution_from = [{ service = "APIGateway", source_arn = module.rest_api_gateway.execution_arn }]
  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue"],
      Resource = [var.STRIPE_SECRET_ARN]
    }
  ]
  memory_size = 2048
  timeout     = 900
}

module "cpaPaymentReminderProcessor" {
  source                = "app.terraform.io/onmo/module-lambda-function/aws"
  version               = "1.0.0"
  service_config        = local.service_config
  lambda_config         = local.lambda_config
  environment_variables = local.lambda_environment_variables

  # for execution_from see scheduler_invoke_lambda_policy in 11-scheduler.tf
  lambda_function_name = "cpaPaymentReminderProcessor"
  description          = "Processes CPA payment reminder schedules and sends SFMC comms"

  permission_statements = [
    {
      Effect   = "Allow",
      Actions  = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
      Resource = [var.MAMBU_SECRET_ARN, var.SALESFORCE_SECRET_ARN, var.STRIPE_SECRET_ARN]
    },
    {
      Effect  = "Allow",
      Actions = ["dynamodb:GetItem", "dynamodb:Query"],
      Resource = [
        "${local.dynamo_prefix}/${var.USER_TABLE}",
        "${local.dynamo_prefix}/${var.USER_TABLE}/index/*"
      ]
    },
    {
      Effect   = "Allow",
      Actions  = ["sqs:SendMessage"],
      Resource = [aws_sqs_queue.cpaCommsQueue.arn]
    },
    {
      Effect   = "Allow",
      Actions  = ["ssm:GetParameter"],
      Resource = ["arn:aws:ssm:${var.REGION}:${var.AWS_ACCOUNT_ID}:parameter/repayment-service/*"]
    },
  ]
  memory_size = 2048
  timeout     = 900
}
