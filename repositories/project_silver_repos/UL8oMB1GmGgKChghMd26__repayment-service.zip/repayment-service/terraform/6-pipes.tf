# module "RepaymentFailedPipe" {
#   depends_on            = [module.repaymentFailedEnrich]
#   source                = "./modules/pipes"
#   source-arn            = data.aws_kinesis_stream.business_events_stream.arn
#   target-arn            = module.repaymentFailedListener.arn
#   event-name            = "RepaymentFailed"
#   environment           = var.ENVIRONMENT
#   enrichment-arn        = module.repaymentFailedEnrich.arn
#   pipe-name             = "onmo-repayment-service-consumer-pipe-repayment-failed-${var.ENVIRONMENT}"
#   iam-role-name         = "onmo-repayment-service-consumer-pipe-repayment-failed-${var.ENVIRONMENT}"
#   dead-letter-queue-arn = data.aws_ssm_parameter.business_events_stream_dlq_arn.value
# }
