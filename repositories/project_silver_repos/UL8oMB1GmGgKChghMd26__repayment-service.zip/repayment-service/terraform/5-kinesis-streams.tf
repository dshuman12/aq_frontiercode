data "aws_kinesis_stream" "business_events_stream" {
  name = "onmo-business-events-stream-${var.ENVIRONMENT}"
}
