resource "aws_iam_role" "scheduler_role" {
  name = "scheduler-role-${var.ENVIRONMENT}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "scheduler.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "scheduler_role_attach" {
  role       = aws_iam_role.scheduler_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEventBridgeSchedulerFullAccess"
}

resource "aws_iam_role_policy" "scheduler_invoke_lambda_policy" {
  name = "SchedulerInvokeLambdaPolicy"
  role = aws_iam_role.scheduler_role.id
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect   = "Allow",
        Action   = "lambda:InvokeFunction",
        Resource = module.directDebitRepaymentProcessor.arn
      },
      {
        Effect   = "Allow",
        Action   = "lambda:InvokeFunction",
        Resource = module.ddSearchPaidInstalments.arn
      },
      {
        Effect   = "Allow",
        Action   = "lambda:InvokeFunction",
        Resource = module.directDebitRetryProcessor.arn
      },
      {
        Effect   = "Allow",
        Action   = "lambda:InvokeFunction",
        Resource = module.ddRetryProdWait.arn
      },
      {
        Effect   = "Allow",
        Action   = "lambda:InvokeFunction",
        Resource = module.cpaPaymentReminderProcessor.arn
      }
    ]
  })
}

resource "aws_lambda_permission" "allow_eventbridge" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = module.directDebitRepaymentProcessor.name
  principal     = "scheduler.amazonaws.com"
}

resource "aws_lambda_permission" "allow_eventbridge_ddSearch" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = module.ddSearchPaidInstalments.name
  principal     = "scheduler.amazonaws.com"
}

resource "aws_lambda_permission" "allow_eventbridge_ddRetry" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = module.directDebitRetryProcessor.name
  principal     = "scheduler.amazonaws.com"
}

resource "aws_lambda_permission" "allow_eventbridge_ddRetryProdWait" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = module.ddRetryProdWait.name
  principal     = "scheduler.amazonaws.com"
}

resource "aws_lambda_permission" "allow_eventbridge_cpaReminder" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = module.cpaPaymentReminderProcessor.name
  principal     = "scheduler.amazonaws.com"
}

resource "aws_scheduler_schedule_group" "cpa_payment_reminders" {
  name = "${var.ENVIRONMENT}-cpa-payment-reminders"
}

resource "aws_scheduler_schedule" "ddFullStatementCron" {
  name       = "${var.ENVIRONMENT}-dd-full-statement-check-cron"
  group_name = "default"

  schedule_expression = "cron(0 6 * * ? *)" # Runs every day at 6am 
  flexible_time_window {
    mode = "OFF"
  }
  target {
    arn      = module.ddSearchPaidInstalments.arn
    role_arn = aws_iam_role.scheduler_role.arn
  }
}
