# .github/workflows/${ENVIRONMENT}.deploy.yaml

locals {
  # Deterministic function name prefix — used in 3-gateway.tf to avoid
  # Terraform graph dependencies between the API Gateway body and lambda modules.
  # Pattern: ${environment}-${service_name}-${functionName}
  function_prefix = "${var.ENVIRONMENT}-${var.SERVICE_NAME}"

  service_config = {
    service_name   = var.SERVICE_NAME
    environment    = var.ENVIRONMENT
    region         = var.REGION
    aws_account_id = var.AWS_ACCOUNT_ID
  }

  gateway_config = {
    disable_default_endpoint = var.DISABLE_DEFAULT_ENDPOINT,
    custom_domain_names      = var.CUSTOM_DOMAIN_NAMES
    web_acl_arn              = var.WEB_ACL_ARN
    throttling_burst_limit   = var.THROTTLING_BURST_LIMIT
    throttling_rate_limit    = var.THROTTLING_RATE_LIMIT
    base_path                = var.BASE_PATH
  }

  lambda_config = {
    source_dir = "${path.root}/../build"
  }

  lambda_environment_variables = {
    ENVIRONMENT                                 = var.ENVIRONMENT
    REGION                                      = var.REGION
    AWS_ACCOUNT_ID                              = var.AWS_ACCOUNT_ID
    USER_TABLE                                  = var.USER_TABLE
    REPAYMENT_COLLECTED_SCHEMA_VERSION          = data.aws_ssm_parameter.repayment_collected_schema_version_id.value
    REPAYMENT_FAILED_SCHEMA_VERSION             = data.aws_ssm_parameter.repayment_failed_schema_version_id.value
    MANDATE_UPSERTED_SCHEMA_VERSION             = data.aws_ssm_parameter.mandate_upserted_schema_version_id.value
    MANDATE_CANCELLED_SCHEMA_VERSION            = data.aws_ssm_parameter.mandate_cancelled_schema_version_id.value
    DD_FAILED_ELIGIBLE_FOR_RETRY_SCHEMA_VERSION = data.aws_ssm_parameter.dd_failed_eligible_for_retry_schema_version_id.value
    CPA_SUBSCRIPTION_CREATED_SCHEMA_VERSION     = data.aws_ssm_parameter.cpa_subscription_created_schema_version_id.value
    CPA_SUBSCRIPTION_CANCELLED_SCHEMA_VERSION   = data.aws_ssm_parameter.cpa_subscription_cancelled_schema_version_id.value
    SERVICE_NAME                                = var.SERVICE_NAME # used for publish event by source
    LOGGING_LEVEL                               = var.LOGGING_LEVEL
    REPAYMENT_DUE_THROTTLING_QUEUE_URL          = aws_sqs_queue.repaymentDueThrottlingQueue.url
    SCHEDULER_ROLE_ARN                          = aws_iam_role.scheduler_role.arn
    REPAYMENT_PROCESSOR_DLQ_ARN                 = aws_sqs_queue.directDebitRepaymentProcessorDlq.arn
    REPAYMENT_DLQ_ARCHIVE_S3_BUCKET             = aws_s3_bucket.repayment_dlq_archive.bucket
    REPAYMENT_DUE_THROTTLING_DLQ_URL            = aws_sqs_queue.repaymentDueThrottlingDlq.url
    REPAYMENT_PROCESSOR_DLQ_URL                 = aws_sqs_queue.directDebitRepaymentProcessorDlq.url
    SFMC_TOKEN_URL                              = var.SFMC_TOKEN_URL
    SFMC_GRANT_TYPE                             = var.SFMC_GRANT_TYPE
    SFMC_CLIENT_ID                              = var.SFMC_CLIENT_ID
    SFMC_CLIENT_SECRET                          = var.SFMC_CLIENT_SECRET
    SFMC_ACCOUNT_ID                             = var.SFMC_ACCOUNT_ID
    SFMC_COMMS_URL                              = var.SFMC_COMMS_URL
    SFMC_DD_RETRY_EVENT_DEFINITION_KEY          = var.SFMC_DD_RETRY_EVENT_DEFINITION_KEY
    SFMC_CPA_EVENT_DEFINITION_KEY               = var.SFMC_CPA_EVENT_DEFINITION_KEY
    SFMC_COMMS_QUEUE_URL                        = var.SFMC_COMMS_QUEUE_URL
    CPA_COMMS_QUEUE_URL                         = aws_sqs_queue.cpaCommsQueue.url
    CPA_CANCELLED_WINDOW_DAYS_SSM_PARAM         = var.CPA_CANCELLED_WINDOW_DAYS_SSM_PARAM
    CPA_REMINDER_DAYS_SSM_PARAM                 = var.CPA_REMINDER_DAYS_SSM_PARAM
    CPA_MAX_RETRY_ATTEMPTS_SSM_PARAM            = var.CPA_MAX_RETRY_ATTEMPTS_SSM_PARAM
    DD_FULL_STATEMENT_CHECK_QUEUE_URL           = aws_sqs_queue.ddFullStatementCheckQueue.url
    DD_FULL_STATEMENT_CHECK_DLQ_URL             = aws_sqs_queue.ddFullStatementCheckDlq.url
    DD_RETRY_PROCESSOR_DLQ_URL                  = aws_sqs_queue.retryProcessorDlq.url
    DD_RETRY_PROCESSOR_DLQ_ARN                  = aws_sqs_queue.retryProcessorDlq.arn
    POSTHOG_SECRET_ARN                          = var.POSTHOG_SECRET_ARN
    ONMO_DATALAKE_BUCKET                        = var.ONMO_DATALAKE_BUCKET
  }

  # Separate set specifically for directDebitRepaymentScheduler as it needs another lambda's ARN
  # this avoids a circular reference in directDebitRepaymentProcessor
  scheduler_lambda_environment_variables = merge(
    local.lambda_environment_variables,
    {
      REPAYMENT_PROCESSOR_ARN = module.directDebitRepaymentProcessor.arn
      DD_PAYMENTS_GROUP_NAME  = var.DD_PAYMENTS_GROUP_NAME
    }
  )

  # Separate set specifically for ddRetryListener as it needs another lambda's ARN 
  # this avoids a circular reference in directDebitRetryProcessor
  dd_retry_listener_lambda_environment_variables = merge(
    local.lambda_environment_variables,
    {
      DD_RETRY_PROCESSOR_ARN = module.directDebitRetryProcessor.arn
      DD_RETRY_GROUP_NAME    = var.DD_RETRY_GROUP_NAME
    }
  )

  # Separate set specifically for webhookHandler as it needs another lambda's ARN
  # this avoids a circular reference in ddRetryProdWait
  webhookHandler_lambda_environment_variables = merge(
    local.lambda_environment_variables,
    {
      DD_RETRY_PROD_WAIT_ARN               = module.ddRetryProdWait.arn
      CPA_REMINDER_GROUP_NAME              = aws_scheduler_schedule_group.cpa_payment_reminders.name
      CPA_REMINDER_PROCESSOR_ARN           = module.cpaPaymentReminderProcessor.arn
      CPA_REMINDER_SCHEDULE_OFFSET_MINUTES = var.CPA_REMINDER_SCHEDULE_OFFSET_MINUTES
    }
  )
}


# SERVICE CONFIG

variable "SERVICE_NAME" {
  type = string
}
variable "ENVIRONMENT" {
  type = string
}
variable "REGION" {
  type = string
}
variable "AWS_ACCOUNT_ID" {
  type = string
}

variable "ONMO_BUSINESS_EVENTS_STREAM" {
  type = string
}

variable "ONMO_BUSINESS_EVENTS_STREAM_DLQ" {
  type = string
}

# SECRETS ARNS
variable "STRIPE_SECRET_ARN" {
  type = string
}

variable "MAMBU_SECRET_ARN" {
  type = string
}

variable "POSTHOG_SECRET_ARN" {
  type = string
}

variable "REPAYMENT_SECRET_ARN" {
  type = string
}


# GATEWAY CONFIG 

variable "DISABLE_DEFAULT_ENDPOINT" {
  type = bool
}
variable "CUSTOM_DOMAIN_NAMES" {
  type = list(string)
}
variable "WEB_ACL_ARN" {
  type = string
}
variable "THROTTLING_BURST_LIMIT" {
  type = number
}
variable "THROTTLING_RATE_LIMIT" {
  type = number
}
variable "BASE_PATH" {
  type    = string
  default = "service/repayments"
}

variable "SF_FE_URL" {
  type = string
}

variable "SF_LIGHTNING_FE_URL" {
  type = string
}


# LAMBDA ENVIRONMENT VARIABLES

# USER Table to Fetch accountId and customerId from DynamoDB
variable "USER_TABLE" {
  type = string
}
variable "DATADOG_API_KEY" {
  type = string
}

variable "DATADOG_APP_KEY" {
  type = string
}

variable "GITHUB_REPO" {
  type = string
}

variable "LOGGING_LEVEL" {
  type    = string
  default = "INFO"
}

variable "DD_PAYMENTS_GROUP_NAME" {
  type = string
}

variable "DD_RETRY_GROUP_NAME" {
  type = string
}

variable "SLACK_CHANNEL" {
  type = string
}

variable "BUSINESS_ALERTS_SLACK_CHANNEL" {
  type = string
}

variable "PRODUCER_LAMBDA_NAME" {
  type = string
}

variable "SFMC_TOKEN_URL" {
  type = string
}
variable "SFMC_GRANT_TYPE" {
  type = string
}
variable "SFMC_CLIENT_ID" {
  type = string
}
variable "SFMC_CLIENT_SECRET" {
  type = string
}
variable "SFMC_ACCOUNT_ID" {
  type = string
}
variable "SFMC_COMMS_URL" {
  type = string
}
variable "SFMC_DD_RETRY_EVENT_DEFINITION_KEY" {
  type = string
}
variable "SFMC_CPA_EVENT_DEFINITION_KEY" {
  type = string
}
variable "SFMC_COMMS_QUEUE_URL" {
  type = string
}

variable "SALESFORCE_SECRET_ARN" {
  type = string
}

variable "ONMO_DATALAKE_BUCKET" {
  type = string
}

variable "DATABRICKS_LEGACY_ACCOUNT_ACCESS_ROLE_ARN" {
  type = string
}

variable "CPA_REMINDER_SCHEDULE_OFFSET_MINUTES" {
  type        = string
  default     = ""
  description = "When set, both CPA reminders fire this many minutes from now instead of days before due date. Used for testing."
}

variable "CPA_REMINDER_DAYS_SSM_PARAM" {
  type        = string
  default     = ""
  description = "SSM parameter name storing JSON array of reminder days before due date (e.g. [10, 1]). Fetched at runtime for configurability without code release."
}

variable "CPA_CANCELLED_WINDOW_DAYS_SSM_PARAM" {
  type        = string
  default     = ""
  description = "SSM parameter name storing the number of days to show cancelled CPA subscriptions. Fetched at runtime for configurability without code release."
}

variable "CPA_MAX_RETRY_ATTEMPTS_SSM_PARAM" {
  type        = string
  default     = ""
  description = "SSM parameter name storing the maximum number of CPA payment retry attempts (matching Stripe retry policy). Fetched at runtime for configurability without code release."
}

