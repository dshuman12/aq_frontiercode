resource "aws_s3_bucket" "repayment_dlq_archive" {
  bucket        = "onmo-repayment-service-dlq-archive-${var.ENVIRONMENT}"
  force_destroy = false
}
resource "aws_s3_bucket_policy" "repayment_dlq_archive_policy" {
  bucket = aws_s3_bucket.repayment_dlq_archive.id

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Sid    = "${var.ENVIRONMENT}-databricks-permission",
        Effect = "Allow",
        Principal = {
          AWS = [
            var.DATABRICKS_LEGACY_ACCOUNT_ACCESS_ROLE_ARN
          ]
        },
        Action = [
          "s3:GetBucketLocation",
          "s3:ListBucket"
        ],
        Resource = "${aws_s3_bucket.repayment_dlq_archive.arn}"
      },
      {
        Effect = "Allow",
        Principal = {
          AWS = [
            var.DATABRICKS_LEGACY_ACCOUNT_ACCESS_ROLE_ARN
          ]
        },
        Action   = "s3:GetObject",
        Resource = "${aws_s3_bucket.repayment_dlq_archive.arn}/*"
      }
    ]
  })
}
