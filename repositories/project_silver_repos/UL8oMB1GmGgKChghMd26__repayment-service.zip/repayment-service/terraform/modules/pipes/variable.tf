variable "environment" {
  type = string
}

variable "event-name" {
  type = string
}

variable "source-arn" {
  type = string
}

variable "target-arn" {
  type = string
}

variable "enrichment-arn" {
  type = string
}

variable "pipe-name" {
  type = string
}

variable "iam-role-name" {
  type = string
}

variable "dead-letter-queue-arn" {
  type = string
}

variable "maximum-retry-attempts" {
  type    = string
  default = 3
}
