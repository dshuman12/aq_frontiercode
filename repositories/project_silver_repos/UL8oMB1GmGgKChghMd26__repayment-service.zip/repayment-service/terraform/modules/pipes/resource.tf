resource "aws_iam_role" "stsAssumeRole" {
  name = var.iam-role-name
  assume_role_policy = jsonencode(
    {
      Version = "2012-10-17"
      Statement = [
        {
          Action = "sts:AssumeRole"
          Effect = "Allow"
          Principal = {
            Service = "pipes.amazonaws.com"
          }
        }
      ]
  })
}

resource "aws_cloudwatch_log_group" "this" {
  name              = "/aws/pipes/${var.pipe-name}"
  retention_in_days = 90

}
resource "aws_iam_role_policy" "source" {
  role = aws_iam_role.stsAssumeRole.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "kinesis:Get*",
          "kinesis:Describe*",
          "kinesis:List*",
        ],
        Resource = [
          "${var.source-arn}",
        ]
      },
    ]
  })
}

resource "aws_iam_role_policy" "target" {
  role = aws_iam_role.stsAssumeRole.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "events:InvokeApiDestination",
        ],
        Resource = [
          "${var.target-arn}"
        ]
      },
    ]
  })
}

resource "aws_iam_role_policy" "invoke_lambda" {
  role = aws_iam_role.stsAssumeRole.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "lambda:InvokeFunction",
        ],
        Resource = [
          "${var.enrichment-arn}"
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "sqs:SendMessage",
        ],
        Resource = [
          "${var.dead-letter-queue-arn}"
        ]
      },
    ]
  })
}

resource "aws_pipes_pipe" "this" {
  depends_on = [aws_cloudwatch_log_group.this]
  name       = var.pipe-name
  role_arn   = aws_iam_role.stsAssumeRole.arn
  source     = var.source-arn
  source_parameters {
    kinesis_stream_parameters {
      starting_position = "TRIM_HORIZON"
      dead_letter_config {
        arn = var.dead-letter-queue-arn
      }
      maximum_retry_attempts = var.maximum-retry-attempts
    }
    filter_criteria {
      filter {
        pattern = jsonencode({
          "data" : {
            "event" : [{
              "equals-ignore-case" : "${var.event-name}"
            }]
          }
        })
      }
    }
  }

  target     = var.target-arn
  enrichment = var.enrichment-arn
  enrichment_parameters {
    input_template = "{\"partitionKey\":<$.partitionKey>,\"data\":<$.data>}"
  }
}
