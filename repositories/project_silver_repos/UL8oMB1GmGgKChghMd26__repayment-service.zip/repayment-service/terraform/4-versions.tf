module "v1" {
  source         = "app.terraform.io/onmo/module-version-api/aws"
  version        = "3.0.0"
  service_config = local.service_config
  gateway_config = local.gateway_config

  rest_api_gateway = module.rest_api_gateway
  version_name     = "v1"

  minor_versions = [23, 24, 25, 26, 31, 32, 34, 35, 36, 37, 38, 39, 40]

  lambda_functions = [
    # modules of Lambdas to snapshot in API version (only for API-invoked functions/authorizers)
    module.createCardRepayment,
    module.createCheckoutRepayment,
    module.createIntentRepayment,
    module.cards,
    module.getPaymentMethodByMandateId,
    module.docs,
    module.createDirectDebit,
    module.getDirectDebit,
    module.createDirectDebitHosted,
    module.deleteDirectDebit,
    module.deleteMandate,
    module.paymentSuccessful,
    module.mandateUpdated,
    module.webhookHandler,
    module.generatePaymentLink,
    module.directDebitRepaymentDue,
    module.nextDirectDebitIntentDate,
    module.repaymentAuthorizer,
    module.hasPendingMandate,
    module.updateDirectDebitHosted,
    module.createPayByBankHosted,
    module.getPaymentReceiptBySessionId,
    module.getPaymentStatusBySessionId,
    module.getCPASubscription,
    { name = "${var.ENVIRONMENT}-authentication-authorizer", version = data.aws_lambda_function.oidc_authorizer_function.version },
    { name = "${var.ENVIRONMENT}-account-service-authorizer", version = data.aws_lambda_function.account_service_function.version },
  ]
}
