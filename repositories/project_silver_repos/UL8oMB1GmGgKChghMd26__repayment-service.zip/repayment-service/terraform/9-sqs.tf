resource "aws_sqs_queue" "repaymentDueThrottlingDlq" {
  name                       = "repayment-due-throttling-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "repaymentDueThrottlingQueue" {
  depends_on                 = [aws_sqs_queue.repaymentDueThrottlingDlq]
  name                       = "repayment-due-throttling-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 900

  redrive_policy = jsonencode({
    maxReceiveCount     = 4
    deadLetterTargetArn = aws_sqs_queue.repaymentDueThrottlingDlq.arn
  })
}

resource "aws_lambda_event_source_mapping" "sqs_mapping" {
  event_source_arn        = aws_sqs_queue.repaymentDueThrottlingQueue.arn
  function_name           = module.directDebitRepaymentScheduler.arn
  function_response_types = ["ReportBatchItemFailures"]
}
resource "aws_sqs_queue" "directDebitRepaymentProcessorDlq" {
  name                       = "direct-debit-repayment-processor-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "sfmcCommsDlq" {
  name                       = "sfmc-comms-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "sfmcCommsQueue" {
  depends_on                 = [aws_sqs_queue.sfmcCommsDlq]
  name                       = "sfmc-comms-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 900

  redrive_policy = jsonencode({
    maxReceiveCount     = 4
    deadLetterTargetArn = aws_sqs_queue.sfmcCommsDlq.arn
  })
}

resource "aws_sqs_queue" "cpaCommsDlq" {
  name                       = "cpa-comms-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "cpaCommsQueue" {
  depends_on                 = [aws_sqs_queue.cpaCommsDlq]
  name                       = "cpa-comms-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 900

  redrive_policy = jsonencode({
    maxReceiveCount     = 4
    deadLetterTargetArn = aws_sqs_queue.cpaCommsDlq.arn
  })
}

resource "aws_sqs_queue" "ddFullStatementCheckDlq" {
  name                       = "dd-full-statement-check-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}

resource "aws_sqs_queue" "ddFullStatementCheckQueue" {
  depends_on                 = [aws_sqs_queue.ddFullStatementCheckDlq]
  name                       = "dd-full-statement-check-queue-${var.ENVIRONMENT}"
  message_retention_seconds  = 86400
  visibility_timeout_seconds = 900

  redrive_policy = jsonencode({
    maxReceiveCount     = 5
    deadLetterTargetArn = aws_sqs_queue.ddFullStatementCheckDlq.arn
  })
}

resource "aws_lambda_event_source_mapping" "sqs_mapping_dd_queue" {
  event_source_arn        = aws_sqs_queue.ddFullStatementCheckQueue.arn
  function_name           = module.ddFullStatementScheduler.arn
  function_response_types = ["ReportBatchItemFailures"]
}

resource "aws_sqs_queue" "retryProcessorDlq" {
  name                       = "direct-debit-retry-processor-dlq-${var.ENVIRONMENT}"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 900
}
