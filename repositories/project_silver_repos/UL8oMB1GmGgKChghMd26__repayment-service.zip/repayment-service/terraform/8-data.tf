data "aws_ssm_parameter" "repayment_collected_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/repayment-collected-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "repayment_failed_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/repayment-failed-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "mandate_upserted_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/mandate-upserted-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "mandate_cancelled_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/mandate-cancelled-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "dd_failed_eligible_for_retry_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/dd-failed-eligible-for-retry-${var.ENVIRONMENT}"
}
data "aws_ssm_parameter" "cpa_subscription_created_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/cpa-subscription-created-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "cpa_subscription_cancelled_schema_version_id" {
  name = "/onmo/service-layer/event-hub/glue-schema-version/cpa-subscription-cancelled-${var.ENVIRONMENT}"
}

data "aws_ssm_parameter" "business_events_stream_dlq_arn" {
  name = "/dlq/business-events-stream/arn/${var.ENVIRONMENT}"
}

data "aws_lambda_function" "oidc_authorizer_function" {
  function_name = "${var.ENVIRONMENT}-authentication-authorizer"
}

data "aws_lambda_function" "account_service_function" {
  function_name = "${var.ENVIRONMENT}-account-service-authorizer"
}
