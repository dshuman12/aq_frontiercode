import { S3Client, ListObjectsV2Command, GetObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";
import { access, readFile, writeFile } from "fs/promises";
import path from "path";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";

const BUCKET_NAME = "onmo-archived-events-prod";
const day = "-all2";
export const SUBFOLDER_PREFIX = `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/`;
const REGION = "eu-west-1";

const folderList = [
  `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/17`,
  `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/18`,
  `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/19`,
  `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/20`,
];
const MAX_CONCURRENT_FILES = 20; // Adjust based on your needs
const OUTPUT_FILE = path.join(__dirname, `aggregated${day}.json`);
export const BATCH_SIZE = 150;
export const SLEEP_DURATION = 3000;

const s3 = new S3Client({ region: REGION });
export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function listFolders(bucket: string, prefix: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, Delimiter: "/" });
  const response = await s3.send(command);
  return response.CommonPrefixes?.map((p) => p.Prefix!) || [];
}

async function listJsonFiles(bucket: string, folder: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: folder });
  const response = await s3.send(command);
  return response.Contents?.filter((obj) => obj.Key?.endsWith(".json")).map((obj) => obj.Key!) || [];
}

async function getJsonContent(bucket: string, key: string): Promise<any> {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3.send(command);

    if (!response.Body) throw new Error(`Empty body for ${key}`);

    const streamToString = async (stream: Readable): Promise<string> => {
      return new Promise((resolve, reject) => {
        const chunks: any[] = [];
        stream.on("data", (chunk) => chunks.push(chunk));
        stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
        stream.on("error", reject);
      });
    };

    const jsonString = await streamToString(response.Body as Readable);
    return JSON.parse(jsonString);
  } catch (error) {
    console.error(`Error reading ${key}:`, error);
    return null;
  }
}

async function processFolder(bucket: string, folder: string): Promise<any[]> {
  const jsonFiles = await listJsonFiles(bucket, folder);

  const fileBatches: string[][] = [];
  for (let i = 0; i < jsonFiles.length; i += MAX_CONCURRENT_FILES) {
    fileBatches.push(jsonFiles.slice(i, i + MAX_CONCURRENT_FILES));
  }

  let folderData: any[] = [];
  for (const batch of fileBatches) {
    const results = await Promise.allSettled(batch.map((file) => getJsonContent(bucket, file)));
    folderData.push(
      ...results
        .filter((r) => r.status === "fulfilled" && r.value !== null)
        .map((r) => (r as PromiseFulfilledResult<any>).value),
    );
  }

  return folderData;
}

function removeDuplicates(data: any[]): any[] {
  const seen = new Set<string>();
  return data.filter((item) => {
    const key = item.eventData?.idempotencyKey;
    if (!key || seen.has(key)) return false; // Skip duplicates
    seen.add(key);
    return true;
  });
}
function removeMetadata(data: any[]): any[] {
  return data.map((item) => {
    const { metaData, ...cleanedItem } = item; // Remove "metaData"
    return cleanedItem;
  });
}

async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

async function readJsonFile(filePath: string): Promise<any[]> {
  try {
    await access(filePath); // Check if file exists
    const fileContent = await readFile(filePath, "utf-8");
    return JSON.parse(fileContent);
  } catch (error) {
    return []; // Return empty array if file doesn't exist
  }
}

// Function to append new data to an existing JSON file
async function appendJsonLocally(filePath: string, newData: any[]) {
  try {
    const existingData = await readJsonFile(filePath); // Read existing file
    const combinedData = [...existingData, ...newData]; // Append new data
    await writeFile(filePath, JSON.stringify(combinedData, null, 2), "utf-8");
    console.log(`✅ Appended ${newData.length} records to ${filePath}`);
  } catch (error) {
    console.error(`❌ Error appending to ${filePath}:`, error);
  }
}

export async function transactionExists(
  accountId: string,
  externalId: string,
  jsonObject: any,
  success: any[],
  failure: any[],
) {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const res = await bankingClient?.findCreditAccountTransactionsByExternalId(accountId, externalId);
  if (res?.error) {
    console.error(res.error);
  } else {
    if (res?.data?.transactions && res.data.transactions.length > 0) {
      success.push(jsonObject);
      return Promise.resolve(true);
    }
    failure.push(jsonObject);
    return Promise.resolve(false);
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,customerId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.eventData?.eventData?.accountId || "";
        const customerId = item.eventData?.eventData?.customerId || "";
        return `${accountId},${customerId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

async function main() {
  let allJsonData: any[] = [];

  for (let i = 0; i < folderList.length; i++) {
    console.log(folderList[i]);
    const folders = await listFolders(BUCKET_NAME, folderList[i]);

    const results = await Promise.allSettled(folders.map((folder) => processFolder(BUCKET_NAME, folder)));
    const flattened = results
      .filter((r) => r.status === "fulfilled")
      .flatMap((r) => (r as PromiseFulfilledResult<any[]>).value);

    allJsonData = [...allJsonData, ...flattened];
  }

  console.log(`✅ Found ${allJsonData.length} JSON objects before deduplication.`);

  // Remove duplicates
  allJsonData = removeDuplicates(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects after deduplication.`);

  // Remove metadata
  allJsonData = removeMetadata(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects after removing metadata.`);

  // Save filtered JSON locally (optional)
  await saveJsonLocally(OUTPUT_FILE, allJsonData);

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  console.log(`Checking ${allJsonData.length} objects for existing transactions...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(
      batch.map((obj) =>
        transactionExists(
          obj.eventData.eventData.accountId,
          obj.eventData.eventData.repayment.externalId,
          obj,
          successArray,
          failureArray,
        ),
      ),
    );

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Successful transactions: ${successArray.length} ${new Date().toISOString()}`);
  console.log(`❌ Failed transactions: ${failureArray.length}`);

  // Save success and failure results locally
  await appendJsonLocally(path.join(__dirname, `successCheck${day}.json`), successArray);
  await appendJsonLocally(path.join(__dirname, `failureCheck${day}.json`), failureArray);
  await saveCsvLocally(path.join(__dirname, `missingTransactions${day}.csv`), failureArray);
}

main().catch(console.error);
