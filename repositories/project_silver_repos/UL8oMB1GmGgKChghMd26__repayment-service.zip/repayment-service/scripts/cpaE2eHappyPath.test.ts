import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlerts,
  getMambuInterestRate,
  setMambuInterestRate,
  makeManualRepayment,
  advanceTestClock,
  verifyEmailSent,
  verifyReminderFired,
  setCollectionPlanActive,
  getCollectionPlanStatus,
  verifyCpaSSMParams,
  getReminderCreatives,
  listCpaReminderSchedules,
  cleanup,
} from "./cpaE2eHelpers";

let setup: SetupResult;
let startTimeMs: number;
let originalInterestRate: number | null;
let cancelledWindowDays: number;
let expectedReminderCreatives: { daysBefore: number; creative: string }[];

describe("CPA E2E - Happy Path", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Happy-Path");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 0: Verify CPA SSM parameters exist and are valid", async () => {
    const ssmParams = await verifyCpaSSMParams();

    expect(Array.isArray(ssmParams.reminderDays)).toBe(true);
    expect(ssmParams.reminderDays.length).toBeGreaterThan(0);
    expect(ssmParams.reminderDays.every((d) => typeof d === "number" && d > 0)).toBe(true);

    expect(ssmParams.cancelledWindowDays).toBeGreaterThan(0);
    cancelledWindowDays = ssmParams.cancelledWindowDays;
    expectedReminderCreatives = getReminderCreatives(ssmParams.reminderDays);
    log("Phase 0", `Expected reminder creatives: ${JSON.stringify(expectedReminderCreatives)}`);
  });

  test("Phase 1: Setup - create test clock, customer, subscription", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Happy-Path",
      8, // billing in 8 days
      60, // subscription ends in 60 days
    );

    expect(setup.subscription.id).toBeTruthy();
    expect(setup.stripeCustomer.id).toBeTruthy();
    expect(setup.testClock.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Active");
  });

  test("Phase 2: Verify subscription is active via CPA API", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();

    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    expect(status.nextCPADueDate).toBeTruthy();
    expect(status.daysFromCPA).toBeGreaterThan(0);

    log(
      "Phase 2",
      `isInCPA: ${status.isInCPA}, amount: £${status.cpaPaymentAmount}, daysFromCPA: ${status.daysFromCPA}`,
    );
  });

  test("Phase 2: Set Mambu interest rate to 0", async () => {
    originalInterestRate = await getMambuInterestRate();
    log("Phase 2", `Original interest rate: ${originalInterestRate}%`);

    await setMambuInterestRate(0);

    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Verify Email1 (plan confirmation) sent", async () => {
    await waitForCondition(
      () => verifyEmailSent("Email1", startTimeMs),
      "Email1 (plan confirmation) in CloudWatch logs",
      5_000,
      180_000,
    );
  });

  test("Phase 2: Verify CPA reminder schedules were created", async () => {
    await pollUntil(async () => {
      const schedules = await listCpaReminderSchedules(CONFIG.accountId);
      log("Phase 2", `Schedules found: ${schedules.length}, expected: ${expectedReminderCreatives.length}`);
      return schedules.length >= expectedReminderCreatives.length;
    }, `${expectedReminderCreatives.length} CPA reminder schedule(s) to be created`);

    const schedules = await listCpaReminderSchedules(CONFIG.accountId);
    expect(schedules.length).toBe(expectedReminderCreatives.length);
  });

  test("Phase 2: Verify 'Your next payment is coming up' alert", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");

    const paymentAlert = alerts.alert.find(
      (a) => a.alertType === "Information" && a.title === "Your next payment is coming up",
    );
    expect(paymentAlert).toBeDefined();
    expect(paymentAlert!.message).toContain(`Amount: £${CONFIG.cpaAmountPence / 100}`);
    expect(paymentAlert!.message).toContain(`Due date: ${status.nextCPADueDate}`);
    expect(paymentAlert!.message).toContain("This payment is part of your payment plan");
  });

  test("Phase 3: Verify all reminder emails sent (driven by SSM config)", async () => {
    // Staging uses CPA_REMINDER_SCHEDULE_OFFSET_MINUTES=1, so all reminders fire within minutes.
    // We verify each individual reminder type fired (e.g. "14d", "8d", "1d") by checking
    // the cpaPaymentReminderProcessor logs, not just the email creative.
    log(
      "Phase 3",
      `Expecting ${expectedReminderCreatives.length} reminder(s): ${expectedReminderCreatives.map((r) => `${r.daysBefore}d→${r.creative}`).join(", ")}`,
    );
    for (const { daysBefore, creative } of expectedReminderCreatives) {
      const reminderType = `${daysBefore}d`;
      await pollUntil(
        () => verifyReminderFired(reminderType, startTimeMs),
        `${reminderType} reminder (${creative}) in cpaPaymentReminderProcessor logs`,
        120_000,
      );
      log("Phase 3", `✓ ${reminderType} reminder fired → ${creative}`);
    }

    // Also verify the emails themselves were sent via SFMC
    const uniqueCreatives = [...new Set(expectedReminderCreatives.map((r) => r.creative))];
    for (const creative of uniqueCreatives) {
      await pollUntil(() => verifyEmailSent(creative, startTimeMs), `${creative} in sendSFMCComms logs`, 120_000);
    }
  });

  test("Phase 4: Manual repayment does not affect CPA amount", async () => {
    const beforeStatus = await getCpaStatus();
    log("Phase 4", `CPA amount before repayment: £${beforeStatus.cpaPaymentAmount}`);

    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, CONFIG.manualRepaymentPence);

    await waitForCondition(
      async () => {
        const s = await getCpaStatus();
        return s.isInCPA && s.cpaStatus === "active" && s.cpaPaymentAmount === CONFIG.cpaAmountPence / 100;
      },
      "CPA amount unchanged after manual repayment",
      5_000,
      60_000,
    );

    const afterStatus = await getCpaStatus();
    expect(afterStatus.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    expect(afterStatus.isInCPA).toBe(true);
    expect(afterStatus.cpaStatus).toBe("active");
    log("Phase 4", `CPA amount unchanged at £${afterStatus.cpaPaymentAmount}`);
  });

  test("Phase 5: Advance to 1 day before billing - daysFromCPA updates", async () => {
    const oneDayBefore = setup.billingAnchor - 24 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, oneDayBefore);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      log("Phase 5", `daysFromCPA: ${status.daysFromCPA}`);
      return status.daysFromCPA !== null && status.daysFromCPA <= 1;
    }, "daysFromCPA to be 1 (payment due tomorrow)");

    const status = await getCpaStatus();
    expect(status.daysFromCPA).toBeLessThanOrEqual(1);
  });

  test("Phase 5: Verify 'payment due today' alert", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");

    const dueAlert = alerts.alert.find(
      (a) => a.alertType === "Information" && a.title === "Heads up - your payment's due today!",
    );
    expect(dueAlert).toBeDefined();

    expect(dueAlert!.message).toContain(`Amount: £${CONFIG.cpaAmountPence / 100}`);
    expect(dueAlert!.message).toContain("This payment is part of your payment plan.");
  });

  test("Phase 6: Advance past billing - payment succeeds", async () => {
    const pastBilling = setup.billingAnchor + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastBilling);

    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 6", `cpaStatus: ${status.cpaStatus}, cpaPaymentFailed: ${status.cpaPaymentFailed}`);
        return status.isInCPA && status.cpaStatus === "active" && !status.cpaPaymentFailed;
      },
      "Payment to succeed (subscription remains active)",
      10_000,
      120_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentFailed).toBe(false);

    log("Phase 6", `Payment succeeded. Next due: ${status.nextCPADueDate}, amount: £${status.cpaPaymentAmount}`);
  });

  test("Phase 7: Advance past subscription end - subscription cancelled", async () => {
    const pastEnd = setup.cancelAt + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastEnd);

    // end_date_reached cancellations are not shown in the cancelled window
    // (only payment_failed cancellations are), so isInCPA should become false immediately
    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 7", `isInCPA: ${status.isInCPA}, cpaCancelled: ${status.cpaCancelled}`);
        return status.isInCPA === false;
      },
      "Subscription to be cancelled (end_date_reached)",
      10_000,
      120_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
  });

  test("Phase 7: Verify Email6 (plan ended) sent", async () => {
    await pollUntil(() => verifyEmailSent("Email6", startTimeMs), "Email6 (plan ended) in CloudWatch logs", 120_000);
  });

  test("Phase 7: Verify alerts after subscription ended", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");
    expect(alerts.alert).toBeDefined();
  });

  test("Phase 7: Verify Mambu interest rate restored", async () => {
    if (originalInterestRate === null || originalInterestRate === 0) {
      log("Phase 7", "Original interest rate was 0 or null - skipping restoration check");
      return;
    }

    await pollUntil(async () => {
      const currentRate = await getMambuInterestRate();
      return currentRate === originalInterestRate;
    }, `Interest rate to restore to ${originalInterestRate}%`);

    const finalRate = await getMambuInterestRate();
    expect(finalRate).toBe(originalInterestRate);
  });

  test("Phase 7: Verify Salesforce collection plan expired", async () => {
    await pollUntil(async () => {
      const status = await getCollectionPlanStatus();
      return status === "Expired";
    }, "Salesforce collection plan to be Expired");

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Expired");
  });

  test("Phase 7: Verify CPA not visible after end_date_reached cancellation", async () => {
    // end_date_reached cancellations are excluded from the cancelled window
    // (only payment_failed keeps isInCPA true within the window)
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
    expect(status.cpaCancelled).toBe(false);
    log("Phase 7", "CPA correctly not visible — end_date_reached excluded from cancelled window");
  });

  test("Phase 8: Advance past cancelled window - CPA still not visible", async () => {
    const pastWindow = setup.cancelAt + (cancelledWindowDays + 1) * 24 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastWindow);

    log("Phase 8", `Advanced ${cancelledWindowDays + 1} days past cancellation, confirming CPA still not visible...`);

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
    expect(status.cpaCancelled).toBe(false);
    expect(status.daysFromCPA).toBeNull();
  });
});
