import dayjs from "dayjs";
import { sendMessage } from "@onmoapp/onmo-sqs";

export const SFMC_DD_FAILED_ACCOUNT_CLOSED = "DD_FAILED_ACCT_CLOSED";
export const SFMC_DD_FAILED_INSUFFICIENT_FUNDS = "DD_FAILED_INSUFFICIENTFUNDS";
async function main() {
  //prepare event
  const accountClosedCommsEvent = {
    commsKey: SFMC_DD_FAILED_INSUFFICIENT_FUNDS,
    firstName: "Joe",
    dueDate: dayjs("10-04-2024").format("YYYY-MM-DD"),
    emailAddress: "joe.kadi@onmo.app",
    customerId: "randomcustomerid",
    personContactId: "randomContactId",
    phoneNumber: "+447402020719",
    retryDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
    avoidFeeCutOffDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
    preventRetryDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
  };
  //put on queue
  await sendMessage({
    MessageBody: JSON.stringify(accountClosedCommsEvent),
    QueueUrl: process.env.SFMC_COMMS_QUEUE_URL,
  });
}

main().catch(console.error);
