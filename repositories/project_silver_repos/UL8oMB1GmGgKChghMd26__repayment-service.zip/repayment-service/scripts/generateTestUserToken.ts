import { generateAccessTokenOfTestUser } from "../src/utils/oidcAuthToken";

async function run() {
  if (!process.argv[2]) {
    console.error("Please provide the customer ID as an argument");
    return;
  }
  try {
    const customerId = process.argv[2]; // Get the customer ID from command line argument
    const token = await generateAccessTokenOfTestUser(customerId);
    console.log("Generated Access Token:", token);
  } catch (error) {
    console.error("Error generating access token:", error);
  }
}

run();
