import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import Stripe from "stripe";
import { v4 as uuid } from "uuid";

async function main() {
  const mandateId = "mandate_1R1W5ORp1KcrfXlP1ik5exZ7";
  const idempotencyKey = uuid();
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  const paymentMethod = await repaymentClient?.getPaymentMethodByMandateId(mandateId);
  if (!paymentMethod) {
    throw new Error("No payment method found for mandate");
  }

  const stripeClient = new Stripe(
    "sk_test_51QAC9ZRp1KcrfXlPT5orQBthSH2kbIqUPTe8vHP4sy2n3rJw82Ecl7oyHlaBMzOllDdbkUYg00VEwMfhRtTnBbaV00mZ0SjROF",
    {
      apiVersion: "2024-12-18.acacia",
    },
  );

  const paymentIntentId = "pi_3RBwa2Rp1KcrfXlP1PubzEjR";
  stripeClient.paymentIntents.update(paymentIntentId, {
    amount: 9050,
    payment_method: paymentMethod.paymentMethodId,
    metadata: { idempotencyKey, repaymentType: "DIRECT_DEBIT" },
  });

  stripeClient.paymentIntents.confirm(paymentIntentId, { idempotencyKey });
}

main().catch(console.error);
