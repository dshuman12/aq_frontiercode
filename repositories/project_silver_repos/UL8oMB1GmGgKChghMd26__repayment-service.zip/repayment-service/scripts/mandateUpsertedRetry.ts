import { access, readFile, writeFile } from "fs/promises";
import path from "path";
import { eventHubAdapter } from "@onmoapp/onmo-adapters";

export const BATCH_SIZE = 150;
export const SLEEP_DURATION = 8000;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function readJsonFile(filePath: string): Promise<any[]> {
  try {
    await access(filePath); // Check if file exists
    const fileContent = await readFile(filePath, "utf-8");
    return JSON.parse(fileContent);
  } catch (error) {
    return []; // Return empty array if file doesn't exist
  }
}

// Function to append new data to an existing JSON file
async function appendJsonLocally(filePath: string, newData: any[]) {
  try {
    const existingData = await readJsonFile(filePath); // Read existing file
    const combinedData = [...existingData, ...newData]; // Append new data
    await writeFile(filePath, JSON.stringify(combinedData, null, 2), "utf-8");
    console.log(`✅ Appended ${newData.length} records to ${filePath}`);
  } catch (error) {
    console.error(`❌ Error appending to ${filePath}:`, error);
  }
}

// Function to send data to Kinesis with success/failure tracking
async function retryMessage(jsonObject: any, successArray: any[], failureArray: any[]) {
  try {
    const eventData = jsonObject.eventData;
    const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");
    if (!eventHubClient) {
      throw new Error("No event hub client found for KINESIS_ADAPTER");
    }

    const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
      await eventHubClient.validateEvent(eventData);

    if (!isEventDataValid) {
      throw new Error(`An error occurred: ${eventValidationErrors}`);
    }

    const {
      isValid: isPublishingEventValid,
      isPublished,
      validationErrors: publishingValidationErrors,
    } = await eventHubClient.publishToEventHub(eventData, eventData.correlationId);

    if (!isPublishingEventValid || !isPublished) {
      throw new Error(`An error occurred: ${publishingValidationErrors}`);
    }

    successArray.push(jsonObject); // Store successful message
  } catch (error) {
    failureArray.push({ jsonObject, error: error.message }); // Store failed message with error
  }
}

/**
 * Retry sending events to Kinesis from a JSON file
 * The file can be produced using the prepare-mandate-retry script
 * This script will output 2 JSON files: one containing the events successfully sent to kinesis
 * And one containing the events that failed to be sent
 */
async function retryFromJsonFile() {
  let allJsonData = await readJsonFile(path.join(__dirname, `mandateUpsertedEventsToSend.json`));

  console.log(`✅ Found ${allJsonData.length} events to retry.`);

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  // Send each object to Kinesis
  console.log(`📤 Sending ${allJsonData.length} objects to Kinesis...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    const accountIds = batch.map((item) => item.eventData?.eventData?.accountId);
    console.log(`Account IDs: ${accountIds}`);
    await Promise.allSettled(batch.map((obj) => retryMessage(obj, successArray, failureArray)));

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Successfully sent messages: ${successArray.length} ${new Date().toISOString()}`);
  console.log(`❌ Failed messages: ${failureArray.length}`);

  // Save success and failure results locally
  await appendJsonLocally(path.join(__dirname, `success-mandates-kinesis.json`), successArray);
  await appendJsonLocally(path.join(__dirname, `failure-mandates-kinesis.json`), failureArray);
}

async function main() {
  await retryFromJsonFile();
}

main().catch(console.error);
