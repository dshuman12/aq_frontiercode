import { readFile, writeFile } from "fs/promises";
import path from "path";
import fs from "fs";
import { coreRepaymentsAdapter, StripeClient } from "@onmoapp/onmo-adapters";
import csvParser from "csv-parser";
import Stripe from "stripe";
import { getCustomer } from "../src/utils/db";
import { createEvent } from "../src/libs/eventHubUtils";
import { MandateUpsertedEvent } from "../src/shared-types/eventHub-types";

export const BATCH_SIZE = 40;
export const SLEEP_DURATION = 1500;

export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

const SUCCESS_FILE = path.join(__dirname, `success.json`);

export async function readSuccessEvents(): Promise<any[]> {
  try {
    const fileContent = await readFile(SUCCESS_FILE, "utf-8");
    const failedData = JSON.parse(fileContent);
    console.log(`✅ Loaded ${failedData.length} success events.`);
    return failedData.map((item) => item.jsonObject);
  } catch (error) {
    console.error(`❌ Failed to read ${SUCCESS_FILE}:`, error);
    return [];
  }
}

interface ExtractedData {
  accountId: string;
  customerId: string;
}

async function extractInfo(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser())
      .on("data", (row) => {
        const sanitizedRow = Object.keys(row).reduce(
          (acc, key) => {
            const cleanKey = key.replace(/^\uFEFF|\s+/g, "").trim(); // Remove BOM and trim spaces
            acc[cleanKey] = row[key]?.trim(); // Trim values too
            return acc;
          },
          {} as Record<string, string>,
        );

        if (sanitizedRow.accountId && sanitizedRow.customerId) {
          results.push({
            accountId: sanitizedRow.accountId,
            customerId: sanitizedRow.customerId,
          });
        }
      })
      .on("end", () => resolve(results))
      .on("error", (error) => reject(error));
  });
}

async function prepareMandateUpsertedEventsForRetry(
  repaymentClient: StripeClient,
  stripeClient: Stripe,
  data: ExtractedData,
  successArray: any[],
  failureArray: any[],
) {
  try {
    const customer = await getCustomer(data.customerId);
    if (!customer.data?.pspCustomerId) {
      console.warn(`No customer found for this account ${data.accountId}`);
      failureArray.push({ eventData: { eventData: { accountId: data.accountId, customerId: data.customerId } } });
      return;
    }
    const mandates = await repaymentClient.getCustomerMandateStatus(customer.data.pspCustomerId);
    if (mandates.length === 0) {
      console.warn(`No mandates found for this account ${data.accountId}`);
      failureArray.push({ eventData: { eventData: { accountId: data.accountId, customerId: data.customerId } } });
      return;
    }
    const activeMandates = mandates.filter((mandate) => mandate.status === "active");
    if (activeMandates.length > 1) {
      console.warn(`More than one active mandate found for this account ${data.accountId}`);
      failureArray.push({ eventData: { eventData: { accountId: data.accountId, customerId: data.customerId } } });
      return;
    }
    if (activeMandates.length === 0) {
      console.warn(`No active mandate found for this account ${data.accountId}`);
      failureArray.push({ eventData: { eventData: { accountId: data.accountId, customerId: data.customerId } } });
      return;
    }

    const activeMandate = activeMandates[0];
    const mandateDetails = await stripeClient.mandates.retrieve(activeMandate.mandateId);
    const paymentMethod = await stripeClient.paymentMethods.retrieve(mandateDetails.payment_method as string);

    const mandateUpsertedEventData = createEvent<MandateUpsertedEvent>(
      {
        startDate: mandateDetails.customer_acceptance.accepted_at || 0,
        created: new Date(paymentMethod.created).getTime(),
        mandateDetails: {
          accountId: data.accountId,
          customerId: data.customerId,
          mandateId: mandateDetails.id,
          oldMandateId: null,
          status: "ACTIVE",
          startDate: mandateDetails.customer_acceptance.accepted_at || 0,
          bankDetails: {
            accountNumber: paymentMethod.bacs_debit?.last4 || "",
            sortCode: paymentMethod.bacs_debit?.sort_code || "",
            accountName: "Direct Debit",
          },
          processorReference: mandateDetails.payment_method_details.bacs_debit?.reference || "",
        },
      },
      {
        eventType: "MandateUpserted",
        initiatedBy: "mandateUpdated",
      },
    );
    successArray.push({ eventData: mandateUpsertedEventData });
  } catch (err) {
    console.error(`❌ Error retrying transaction:`, err);
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,customerId,dueDate,externalId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.eventData?.eventData?.accountId || "";
        const customerId = item.eventData?.eventData?.customerId || "";
        const dueDate = item.eventData?.eventData?.date || "";
        const externalId = item.eventData?.eventData?.repayment?.externalId || "";
        return `${accountId},${customerId},${dueDate},${externalId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

/**
 * Go to Mambu loans, apply the filter "GC Stripe mismatch"
 * Edit columns to keep only the account ID and ONMO ID
 * Export to CSV
 * rename the columns in the csv to accountId,customerId
 * Feed this CSV to this script
 * The script will produce 2 files: one JSON file with an array of events ready to be published again on Kinesis
 * and one CSV file with the failed accountIds for which we couldn't find an active Stripe mandate for review
 *
 * Once you have the JSON file, you can run the retry-mandate script
 */

async function main() {
  // Read mismatched accounts from CSV
  let allJsonData = await extractInfo(path.join(__dirname, "mismatchedDD.csv"));

  if (allJsonData.length === 0) {
    console.log(`🚫 Nothing to check.`);
    return;
  }

  const successArray: any[] = [];
  const failureArray: any[] = [];

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  if (!repaymentClient) {
    console.error("No repayment client found for STRIPE_CLIENT");
    return;
  }

  const key = process.env.STRIPE_API_KEY || "";
  const stripeClient = new Stripe(key, {
    apiVersion: "2024-12-18.acacia",
  });
  console.log(`🔍 Checking ${allJsonData.length} accounts...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(
      batch.map((obj) =>
        prepareMandateUpsertedEventsForRetry(repaymentClient, stripeClient, obj, successArray, failureArray),
      ),
    );

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Done: ${successArray.length} event(s) ready to retry ${new Date().toISOString()}`);

  await saveJsonLocally(path.join(__dirname, `mandateUpsertedEventsToSend.json`), successArray);
  await saveCsvLocally(path.join(__dirname, `noActiveMandates.csv`), failureArray);
}

main().catch(console.error);
