import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlerts,
  getMambuInterestRate,
  setMambuInterestRate,
  advanceTestClock,
  verifyEmailSent,
  setCollectionPlanActive,
  getCollectionPlanStatus,
  verifyCpaSSMParams,
  listCpaReminderSchedules,
  cleanup,
} from "./cpaE2eHelpers";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

let setup: SetupResult;
let startTimeMs: number;
let originalInterestRate: number | null;
let cancelledWindowDays: number;
let cancellationTimestamp: number;

describe("CPA E2E - Sad Path", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Sad-Path");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 0: Verify CPA SSM parameters exist and are valid", async () => {
    const ssmParams = await verifyCpaSSMParams();

    expect(Array.isArray(ssmParams.reminderDays)).toBe(true);
    expect(ssmParams.reminderDays.length).toBeGreaterThan(0);
    expect(ssmParams.reminderDays.every((d) => typeof d === "number" && d > 0)).toBe(true);

    expect(ssmParams.cancelledWindowDays).toBeGreaterThan(0);
    cancelledWindowDays = ssmParams.cancelledWindowDays;
  });

  test("Phase 1: Setup with failing card", async () => {
    setup = await setupCpaTest(
      CONFIG.sadPathCard,
      "CPA-E2E-Sad-Path",
      8, // billing in 8 days
      90, // subscription would end in 90 days (but will be cancelled earlier)
    );

    console.log("SUBSCRIPTION DETAILS:", setup.subscription);

    expect(setup.subscription.id).toBeTruthy();
    expect(setup.stripeCustomer.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Active");
  });

  test("Phase 1: Verify subscription is active", async () => {
    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        return status.isInCPA && status.cpaStatus === "active";
      },
      "CPA subscription to appear as active",
      5_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
  });

  test("Phase 1: Set Mambu interest rate to 0", async () => {
    originalInterestRate = await getMambuInterestRate();
    log("Phase 1", `Original interest rate: ${originalInterestRate}%`);

    await setMambuInterestRate(0);

    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Advance to billing - payment fails", async () => {
    const pastBilling = setup.billingAnchor + 1 * 60 * 60; // +5 minutes - keep small to avoid triggering Stripe's 1-day retry
    await advanceTestClock(setup.stripe, setup.testClock.id, pastBilling);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      log("Phase 2", `cpaStatus: ${status.cpaStatus}, failed: ${status.cpaPaymentFailed}`);
      return status.cpaPaymentFailed === true && status.cpaStatus === "past_due";
    }, "Payment to fail (subscription past_due)");

    const status = await getCpaStatus();
    expect(status.cpaPaymentFailed).toBe(true);
    expect(status.cpaStatus).toBe("past_due");
    expect(status.cpaAttemptCount).toBeGreaterThan(0);

    log("Phase 2", `cpaAttemptCount: ${status.cpaAttemptCount}, cpaNextRetryDate: ${status.cpaNextRetryDate}`);
  });

  test("Phase 2: Verify Email4 (payment failed) sent", async () => {
    await pollUntil(
      () => verifyEmailSent("Email4", startTimeMs),
      "Email4 (payment failed) in CloudWatch logs",
      120_000,
    );
  });

  test("Phase 2: Verify alerts after payment failure", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");
    expect(alerts.alert).toBeDefined();
  });

  test("Phase 3: Advance to retry - subscription cancelled", async () => {
    const repaymentClient = await CoreRepaymentsFactory.build("stripe");
    if (!repaymentClient) throw new Error("Failed to initialize repayment client");

    const subsResult = await repaymentClient.getSubscriptionsByPsPCustomerId(setup.stripeCustomer.id);
    const pastDueSub = subsResult.subscriptions.find((s) => s.status === "past_due");

    let retryTimestamp: number;

    if (pastDueSub) {
      const invoice = await repaymentClient.getLatestInvoiceForSubscription(pastDueSub.subscriptionId);
      if (invoice?.nextPaymentAttempt) {
        retryTimestamp = invoice.nextPaymentAttempt;
        log("Phase 3", `Next retry at: ${new Date(retryTimestamp * 1000).toISOString()}`);
      } else {
        retryTimestamp = setup.billingAnchor + 3 * 24 * 60 * 60;
        log("Phase 3", "No retry date found, advancing 3 days past billing");
      }
    } else {
      retryTimestamp = setup.billingAnchor + 3 * 24 * 60 * 60;
      log("Phase 3", "No past_due subscription found, advancing 3 days past billing");
    }

    cancellationTimestamp = retryTimestamp + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, cancellationTimestamp);

    await pollUntil(
      async () => {
        const status = await getCpaStatus();
        log("Phase 3", `cpaCancelled: ${status.cpaCancelled}, reason: ${status.cpaCancellationReason}`);
        return status.cpaCancelled === true;
      },
      "Subscription to be cancelled after retry failure",
      300_000,
    );

    const status = await getCpaStatus();
    expect(status.cpaCancelled).toBe(true);
    expect(status.cpaCancellationReason).toBe("payment_failed");
  });

  test("Phase 3: Verify Email5 (subscription cancelled) sent", async () => {
    await pollUntil(
      () => verifyEmailSent("Email5", startTimeMs),
      "Email5 (subscription cancelled) in CloudWatch logs",
      120_000,
    );
  });

  test("Phase 3: Verify alerts after CPA cancellation", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");
    expect(alerts.alert).toBeDefined();
  });

  test("Phase 4: Verify Mambu interest rate restored", async () => {
    if (originalInterestRate === null || originalInterestRate === 0) {
      log("Phase 4", "Original interest rate was 0 or null - skipping restoration check");
      return;
    }

    await pollUntil(async () => {
      const currentRate = await getMambuInterestRate();
      return currentRate === originalInterestRate;
    }, `Interest rate to restore to ${originalInterestRate}%`);

    const finalRate = await getMambuInterestRate();
    expect(finalRate).toBe(originalInterestRate);
  });

  test("Phase 4: Verify Salesforce collection plan expired", async () => {
    await pollUntil(async () => {
      const status = await getCollectionPlanStatus();
      return status === "Expired";
    }, "Salesforce collection plan to be Expired");

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Expired");
  });

  test("Phase 4: Verify CPA reminder schedules deleted after cancellation", async () => {
    await pollUntil(async () => {
      const schedules = await listCpaReminderSchedules(CONFIG.accountId);
      return schedules.length === 0;
    }, "All CPA reminder schedules to be deleted");

    const schedules = await listCpaReminderSchedules(CONFIG.accountId);
    expect(schedules.length).toBe(0);
    log("Phase 4", "All CPA reminder schedules cleaned up after payment_failed cancellation");
  });

  test("Phase 4: Verify CPA still visible within cancelled window", async () => {
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaCancelled).toBe(true);
    log("Phase 4", `CPA still visible within ${cancelledWindowDays}-day cancelled window`);
  });

  test("Phase 5: Advance past cancelled window - CPA disappears", async () => {
    const pastWindow = cancellationTimestamp + (cancelledWindowDays + 1) * 24 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastWindow);

    log("Phase 5", `Advanced ${cancelledWindowDays + 1} days past cancellation, waiting for CPA to disappear...`);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      log("Phase 5", `isInCPA: ${status.isInCPA}`);
      return status.isInCPA === false;
    }, `CPA to disappear after ${cancelledWindowDays}-day cancelled window`);

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
    expect(status.cpaCancelled).toBe(false);
    expect(status.daysFromCPA).toBeNull();
  });
});
