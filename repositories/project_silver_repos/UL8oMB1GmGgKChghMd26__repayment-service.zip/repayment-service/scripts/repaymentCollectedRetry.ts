import { S3Client, ListObjectsV2Command, GetObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";
import { access, readFile, writeFile } from "fs/promises";
import path from "path";
import { eventHubAdapter } from "@onmoapp/onmo-adapters";

const BUCKET_NAME = "onmo-archived-events-prod";
const day = "04";
const SUBFOLDER_PREFIX = `prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/${day}/`;
const REGION = "eu-west-1";

const MAX_CONCURRENT_FILES = 20;
const OUTPUT_FILE = path.join(__dirname, `aggregated${day}.json`);
export const BATCH_SIZE = 150;
export const SLEEP_DURATION = 8000;

const s3 = new S3Client({ region: REGION });
export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function listFolders(bucket: string, prefix: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, Delimiter: "/" });
  const response = await s3.send(command);
  return response.CommonPrefixes?.map((p) => p.Prefix!) || [];
}

async function listJsonFiles(bucket: string, folder: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: folder });
  const response = await s3.send(command);
  return response.Contents?.filter((obj) => obj.Key?.endsWith(".json")).map((obj) => obj.Key!) || [];
}

async function getJsonContent(bucket: string, key: string): Promise<any> {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3.send(command);

    if (!response.Body) throw new Error(`Empty body for ${key}`);

    const streamToString = async (stream: Readable): Promise<string> => {
      return new Promise((resolve, reject) => {
        const chunks: any[] = [];
        stream.on("data", (chunk) => chunks.push(chunk));
        stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
        stream.on("error", reject);
      });
    };

    const jsonString = await streamToString(response.Body as Readable);
    return JSON.parse(jsonString);
  } catch (error) {
    console.error(`Error reading ${key}:`, error);
    return null;
  }
}

async function processFolder(bucket: string, folder: string): Promise<any[]> {
  const jsonFiles = await listJsonFiles(bucket, folder);

  const fileBatches: string[][] = [];
  for (let i = 0; i < jsonFiles.length; i += MAX_CONCURRENT_FILES) {
    fileBatches.push(jsonFiles.slice(i, i + MAX_CONCURRENT_FILES));
  }

  let folderData: any[] = [];
  for (const batch of fileBatches) {
    const results = await Promise.allSettled(batch.map((file) => getJsonContent(bucket, file)));
    folderData.push(
      ...results
        .filter((r) => r.status === "fulfilled" && r.value !== null)
        .map((r) => (r as PromiseFulfilledResult<any>).value),
    );
  }

  return folderData;
}

function removeDuplicates(data: any[]): any[] {
  const seen = new Set<string>();
  return data.filter((item) => {
    const key = item.eventData?.idempotencyKey;
    if (!key || seen.has(key)) return false; // Skip duplicates
    seen.add(key);
    return true;
  });
}

function removeMetadata(data: any[]): any[] {
  return data.map((item) => {
    const { metaData, ...cleanedItem } = item; // Remove "metaData"
    return cleanedItem;
  });
}

async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

async function readJsonFile(filePath: string): Promise<any[]> {
  try {
    await access(filePath); // Check if file exists
    const fileContent = await readFile(filePath, "utf-8");
    return JSON.parse(fileContent);
  } catch (error) {
    return []; // Return empty array if file doesn't exist
  }
}

// Function to send data to Kinesis with success/failure tracking
export async function retryMessage(jsonObject: any, successArray: any[], failureArray: any[]) {
  try {
    const eventData = jsonObject.eventData;
    // eventData.eventData.date = "2025-03-13T00:00:00.000Z"; uncomment here if you want to force transactions to a specific date

    const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");
    if (!eventHubClient) {
      throw new Error("No event hub client found for KINESIS_ADAPTER");
    }

    const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
      await eventHubClient.validateEvent(eventData);

    if (!isEventDataValid) {
      throw new Error(`An error occurred: ${eventValidationErrors}`);
    }

    const {
      isValid: isPublishingEventValid,
      isPublished,
      validationErrors: publishingValidationErrors,
    } = await eventHubClient.publishToEventHub(eventData, eventData.correlationId);

    if (!isPublishingEventValid || !isPublished) {
      throw new Error(`An error occurred: ${publishingValidationErrors}`);
    }

    successArray.push(jsonObject); // Store successful message
  } catch (error) {
    console.error(error);
    failureArray.push({ jsonObject, error: error.message }); // Store failed message with error
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,customerId,dueDate,transactionExternalId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.eventData?.eventData?.accountId || "";
        const customerId = item.eventData?.eventData?.customerId || "";
        const dueDate = item.eventData?.eventData?.date || "";
        const externalId = item.eventData?.eventData?.repayment.externalId || "";
        return `${accountId},${customerId},${dueDate},${externalId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

export async function retryFromJsonFile() {
  let allJsonData = await readJsonFile(path.join(__dirname, `repaymentCollectedEventsToRetry.json`));

  console.log(`✅ Found ${allJsonData.length} events to retry.`);

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  // Send each object to Kinesis
  console.log(`📤 Sending ${allJsonData.length} objects to Kinesis...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    const accountIds = batch.map((item) => item.eventData?.eventData?.accountId);
    console.log(`Account IDs: ${accountIds}`);
    await Promise.allSettled(batch.map((obj) => retryMessage(obj, successArray, failureArray)));

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Successfully sent messages: ${successArray.length} ${new Date().toISOString()}`);
  console.log(`❌ Failed messages: ${failureArray.length}`);

  // Save success and failure results locally
  await saveJsonLocally(path.join(__dirname, `success-repayment-kinesis.json`), successArray);
  await saveJsonLocally(path.join(__dirname, `failure-repayment-kinesis.json`), failureArray);
  await saveCsvLocally(path.join(__dirname, "retriedTransactions.csv"), allJsonData);
}

export async function retryFromS3() {
  const folders = await listFolders(BUCKET_NAME, SUBFOLDER_PREFIX);

  const results = await Promise.allSettled(folders.map((folder) => processFolder(BUCKET_NAME, folder)));

  let allJsonData = results
    .filter((r) => r.status === "fulfilled")
    .flatMap((r) => (r as PromiseFulfilledResult<any[]>).value);

  console.log(`✅ Found ${allJsonData.length} JSON objects before deduplication.`);

  // Remove duplicates
  allJsonData = removeDuplicates(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects after deduplication.`);

  // Remove metadata
  allJsonData = removeMetadata(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects after removing metadata.`);

  // Save filtered JSON locally (optional)
  await saveJsonLocally(OUTPUT_FILE, allJsonData);

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  // Send each object to Kinesis
  console.log(`📤 Sending ${allJsonData.length} objects to Kinesis...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    const accountIds = batch.map((item) => item.eventData?.eventData?.accountId);
    console.log(`Account IDs: ${accountIds}`);
    await Promise.allSettled(batch.map((obj) => retryMessage(obj, successArray, failureArray)));

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Successfully sent messages: ${successArray.length} ${new Date().toISOString()}`);
  console.log(`❌ Failed messages: ${failureArray.length}`);

  // Save success and failure results locally
  await saveJsonLocally(path.join(__dirname, `success-kinesis-${day}.json`), successArray);
  await saveJsonLocally(path.join(__dirname, `failure-kinesis-${day}.json`), failureArray);
  await saveCsvLocally(path.join(__dirname, "missingTransactions.csv"), allJsonData);
}

// You can choose here to get the events from the archived S3 bucket directly, or from a local JSON file
// generated by other scripts
async function main() {
  await retryFromJsonFile();
  // await retryFromS3();
}

main().catch(console.error);
