import { readFile, writeFile, access } from "fs/promises";
import path from "path";
import { coreBankingAdapter, EventData } from "@onmoapp/onmo-adapters";
import { RepaymentCollectedEvent } from "../src/shared-types/eventHub-types";
import { getCustomer } from "../src/utils/db";

export const BATCH_SIZE = 40;
export const SLEEP_DURATION = 1500;

export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

const SUCCESS_FILE = path.join(__dirname, `success.json`);

export async function readSuccessEvents(): Promise<any[]> {
  try {
    const fileContent = await readFile(SUCCESS_FILE, "utf-8");
    const failedData = JSON.parse(fileContent);
    console.log(`✅ Loaded ${failedData.length} success events.`);
    return failedData.map((item) => item.jsonObject);
  } catch (error) {
    console.error(`❌ Failed to read ${SUCCESS_FILE}:`, error);
    return [];
  }
}

async function transactionExists(repaymentCollectedEventData: any, externalId: string, success: any[], failure: any[]) {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const res = await bankingClient?.findCreditAccountTransactionsByExternalId(
    repaymentCollectedEventData.eventData.accountId,
    externalId,
  );

  if (res?.error) {
    console.error(res.error);
  } else {
    if (res?.data?.transactions && res.data.transactions.length > 0) {
      success.push({ eventData: repaymentCollectedEventData });
      return Promise.resolve(true);
    } else {
      // checking technical account transactions
      const user = await getCustomer(repaymentCollectedEventData.eventData.customerId);
      const resTech = await bankingClient?.findTechnicalAccountTransactionsByExternalId(
        user.data.technicalAccountId,
        externalId,
      );

      if (resTech?.error) {
        console.error(resTech.error);
      } else {
        if (resTech?.data?.transactions && resTech.data.transactions.length > 0) {
          success.push({ eventData: repaymentCollectedEventData });
          return Promise.resolve(true);
        }
      }
    }
    failure.push({ eventData: repaymentCollectedEventData });
    return Promise.resolve(false);
  }
}

async function prepareRepaymentCollectedEvent(
  repaymentCollectedEventData: EventData<RepaymentCollectedEvent>,
  successArray: any[],
  failureArray: any[],
) {
  try {
    await transactionExists(
      repaymentCollectedEventData,
      repaymentCollectedEventData.eventData.repayment.externalId,
      successArray,
      failureArray,
    );
  } catch (err) {
    console.error(`❌ Error retrying transaction:`, err);
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,customerId,dueDate,externalId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.eventData?.eventData?.accountId || "";
        const customerId = item.eventData?.eventData?.customerId || "";
        const dueDate = item.eventData?.eventData?.date || "";
        const externalId = item.eventData?.eventData?.repayment?.externalId || "";
        return `${accountId},${customerId},${dueDate},${externalId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

async function readJsonFile(filePath: string): Promise<any[]> {
  try {
    await access(filePath); // Check if file exists
    const fileContent = await readFile(filePath, "utf-8");
    return JSON.parse(fileContent);
  } catch (error) {
    return []; // Return empty array if file doesn't exist
  }
}

function removeDuplicates(data: any[]): any[] {
  const seen = new Set<string>();
  return data.filter((item) => {
    const key = item.eventData?.idempotencyKey;
    if (!key || seen.has(key)) return false; // Skip duplicates
    seen.add(key);
    return true;
  });
}

/**
 * Check if the events sent for a retry to Kinesis made it to Mambu, using the success JSON file
 */
async function main(filename?: string) {
  // Read success kinesis events
  const file = filename ? `${filename}.json` : `success-repayment-kinesis.json`;
  let allJsonData = await readJsonFile(path.join(__dirname, file));

  // Remove duplicates
  allJsonData = removeDuplicates(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects after deduplication.`);

  console.log(`✅ Found ${allJsonData.length} events to check.`);

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  console.log(`🔍 Checking ${allJsonData.length} transactions...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(
      batch.map((obj) => prepareRepaymentCollectedEvent(obj.eventData, successArray, failureArray)),
    );

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Done: ${successArray.length} ${new Date().toISOString()}`);

  // Save new success and failure results
  await saveJsonLocally(path.join(__dirname, `repaymentCollectedEventsToRetry.json`), failureArray);

  await saveCsvLocally(path.join(__dirname, "successfulRetriesFromMambuCsv.csv"), successArray);
  await saveCsvLocally(path.join(__dirname, "missingTransactions.csv"), failureArray);
}

const filename = process.argv[2];

main(filename).catch(console.error);
