import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlerts,
  getMambuInterestRate,
  setMambuInterestRate,
  advanceTestClock,
  verifyEmailSent,
  switchSubscriptionPaymentMethod,
  setCollectionPlanActive,
  getCollectionPlanStatus,
  cleanup,
} from "./cpaE2eHelpers";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

/**
 * CPA E2E - Failed Payment Then Successful Retry
 *
 * QA Scenarios: 4, 20
 * - First payment attempt fails (bad card)
 * - Card is switched to a valid one before retry
 * - Retry succeeds → subscription remains active
 * - Account stays active (does not enter arrears)
 */

let setup: SetupResult;
let startTimeMs: number;
let originalInterestRate: number | null;

describe("CPA E2E - Failed Then Retry Success", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Failed-Retry-Success");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 1: Setup with failing card", async () => {
    setup = await setupCpaTest(
      CONFIG.sadPathCard,
      "CPA-E2E-Failed-Retry-Success",
      8, // billing in 8 days
      90, // subscription ends in 90 days
    );

    expect(setup.subscription.id).toBeTruthy();
    expect(setup.stripeCustomer.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();
  });

  test("Phase 1: Verify subscription is active", async () => {
    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        return status.isInCPA && status.cpaStatus === "active";
      },
      "CPA subscription to appear as active",
      5_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
  });

  test("Phase 1: Set Mambu interest rate to 0", async () => {
    originalInterestRate = await getMambuInterestRate();
    log("Phase 1", `Original interest rate: ${originalInterestRate}%`);
    await setMambuInterestRate(0);
    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Advance to billing - payment fails", async () => {
    const pastBilling = setup.billingAnchor + 1 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastBilling);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      log("Phase 2", `cpaStatus: ${status.cpaStatus}, failed: ${status.cpaPaymentFailed}`);
      return status.cpaPaymentFailed === true && status.cpaStatus === "past_due";
    }, "Payment to fail (subscription past_due)");

    const status = await getCpaStatus();
    expect(status.cpaPaymentFailed).toBe(true);
    expect(status.cpaStatus).toBe("past_due");
    expect(status.cpaAttemptCount).toBeGreaterThan(0);
    log("Phase 2", `Payment failed. Attempt count: ${status.cpaAttemptCount}, next retry: ${status.cpaNextRetryDate}`);
  });

  test("Phase 2: Verify Email4 (payment failed, retry pending) sent", async () => {
    await pollUntil(
      () => verifyEmailSent("Email4", startTimeMs),
      "Email4 (payment failed) in CloudWatch logs",
      120_000,
    );
  });

  test("Phase 2: Verify 'payment didn't go through' alert", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    const failedAlert = alerts.alert.find(
      (a) => a.alertType === "Warning" && a.title === "Your automatic payment didn't go through",
    );
    expect(failedAlert).toBeDefined();
  });

  test("Phase 3: Switch to good card before retry", async () => {
    const newPmId = await switchSubscriptionPaymentMethod(
      setup.stripe,
      setup.subscription.id,
      setup.stripeCustomer.id,
      CONFIG.happyPathCard,
    );
    expect(newPmId).toBeTruthy();
    log("Phase 3", `Switched to good card: ${newPmId}`);
  });

  test("Phase 3: Advance to retry - payment succeeds", async () => {
    const repaymentClient = await CoreRepaymentsFactory.build("stripe");
    if (!repaymentClient) throw new Error("Failed to initialize repayment client");

    const subsResult = await repaymentClient.getSubscriptionsByPsPCustomerId(setup.stripeCustomer.id);
    const pastDueSub = subsResult.subscriptions.find((s) => s.status === "past_due");

    let retryTimestamp: number;

    if (pastDueSub) {
      const invoice = await repaymentClient.getLatestInvoiceForSubscription(pastDueSub.subscriptionId);
      if (invoice?.nextPaymentAttempt) {
        retryTimestamp = invoice.nextPaymentAttempt;
        log("Phase 3", `Next retry at: ${new Date(retryTimestamp * 1000).toISOString()}`);
      } else {
        retryTimestamp = setup.billingAnchor + 3 * 24 * 60 * 60;
        log("Phase 3", "No retry date found, advancing 3 days past billing");
      }
    } else {
      retryTimestamp = setup.billingAnchor + 3 * 24 * 60 * 60;
      log("Phase 3", "No past_due subscription found, advancing 3 days past billing");
    }

    const pastRetry = retryTimestamp + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastRetry);

    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 3", `cpaStatus: ${status.cpaStatus}, failed: ${status.cpaPaymentFailed}, cancelled: ${status.cpaCancelled}`);
        return status.isInCPA && status.cpaStatus === "active" && !status.cpaPaymentFailed;
      },
      "Retry to succeed (subscription back to active)",
      10_000,
      120_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentFailed).toBe(false);
    expect(status.cpaCancelled).toBe(false);
    log("Phase 3", "Retry succeeded — subscription remains active");
  });

  test("Phase 3: Verify subscription is not cancelled", async () => {
    const status = await getCpaStatus();
    expect(status.cpaCancelled).toBe(false);
    expect(status.cpaCancellationReason).toBeNull();
    expect(status.nextCPADueDate).toBeTruthy();
    log("Phase 3", `Next payment due: ${status.nextCPADueDate}`);
  });

  test("Phase 3: Verify Salesforce collection plan still Active", async () => {
    const planStatus = await getCollectionPlanStatus();
    expect(planStatus).toBe("Active");
    log("Phase 3", "Salesforce plan still Active — not expired by retry success");
  });

  test("Phase 3: Verify interest rate still frozen at 0", async () => {
    const rate = await getMambuInterestRate();
    expect(rate).toBe(0);
    log("Phase 3", "Interest rate still 0% — not restored by retry success");
  });
});
