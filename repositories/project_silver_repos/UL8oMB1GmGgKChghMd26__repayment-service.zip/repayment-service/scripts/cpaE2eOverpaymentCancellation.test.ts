import { describe, test, expect, beforeAll, afterAll } from "vitest";
import dayjs from "dayjs";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlertsWithOverrides,
  getMambuInterestRate,
  setMambuInterestRate,
  getMambuTotalBalancePence,
  makeMambuDisbursement,
  makeManualRepayment,
  verifyEmailSent,
  setCollectionPlanActive,
  getCollectionPlanStatus,
  listCpaReminderSchedules,
  cleanup,
} from "./cpaE2eHelpers";

/**
 * CPA E2E - Overpayment Cancellation & Alert Transitions
 *
 * QA Scenarios: 7, 25, 27, 28
 * - Manual overpayment beyond balance → subscription cancelled (balance_paid)
 * - Old CPA alerts removed
 * - Non-CPA alerts (e.g. DD) return after CPA is finished
 * - CPA reminder schedules cleaned up
 */

let setup: SetupResult;
let startTimeMs: number;
let originalInterestRate: number | null;
let originalBalancePence: number;

describe("CPA E2E - Overpayment Cancellation & Alert Transitions", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Overpayment-Cancellation");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 1: Setup - create subscription with good card", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Overpayment-Cancellation",
      30, // billing far out so it doesn't fire before manual repayment
      90,
    );

    expect(setup.subscription.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();
  });

  test("Phase 2: Verify subscription is active", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
  });

  test("Phase 2: Set Mambu interest rate to 0", async () => {
    originalInterestRate = await getMambuInterestRate();
    log("Phase 2", `Original interest rate: ${originalInterestRate}%`);
    await setMambuInterestRate(0);
    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Verify alerts API responds while CPA is active", async () => {
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);

    const alerts = await getAlertsWithOverrides(status);
    expect(alerts.message).toBe("Account credit alerts generated successfully");
    log("Phase 2", `Got ${alerts.alert.length} alert(s) while CPA is active (billing in 30 days)`);
  });

  test("Phase 2: Verify CPA reminder schedules exist", async () => {
    await pollUntil(async () => {
      const schedules = await listCpaReminderSchedules(CONFIG.accountId);
      return schedules.length > 0;
    }, "CPA reminder schedules to be created");

    const schedules = await listCpaReminderSchedules(CONFIG.accountId);
    expect(schedules.length).toBeGreaterThan(0);
    log("Phase 2", `${schedules.length} reminder schedule(s) exist`);
  });

  // ── Scenario 7/25: Overpayment clears balance → subscription cancelled ──

  test("Phase 3: Make manual repayment exceeding full balance", async () => {
    originalBalancePence = await getMambuTotalBalancePence();
    log("Phase 3", `Total balance: £${(originalBalancePence / 100).toFixed(2)}`);
    expect(originalBalancePence).toBeGreaterThan(0);

    // Pay more than the balance (overpayment)
    const overpaymentPence = originalBalancePence + 500; // £5 extra
    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, overpaymentPence);
    log("Phase 3", `Manual repayment of £${(overpaymentPence / 100).toFixed(2)} submitted (overpayment of £5.00)`);

  });

  test("Phase 3: Verify subscription cancelled with balance_paid reason", async () => {
    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 3", `isInCPA: ${status.isInCPA}, cpaCancelled: ${status.cpaCancelled}`);
        return status.isInCPA === false;
      },
      "Subscription to be cancelled (balance_paid)",
      10_000,
      120_000,
    );

    // balance_paid cancellations are excluded from cancelled window — isInCPA immediately false
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
  });

  test("Phase 3: Verify Email6 (plan completed) sent", async () => {
    await pollUntil(
      () => verifyEmailSent("Email6", startTimeMs),
      "Email6 (plan completed) in CloudWatch logs",
      120_000,
    );
  });

  test("Phase 3: Verify Mambu balance is zero or negative", async () => {
    const balance = await getMambuTotalBalancePence();
    expect(balance).toBeLessThanOrEqual(0);
    log("Phase 3", `Balance after overpayment: £${(balance / 100).toFixed(2)}`);
  });

  // ── Scenario 27: CPA reminder schedules cleaned up ──

  test("Phase 4: Verify CPA reminder schedules deleted", async () => {
    await pollUntil(async () => {
      const schedules = await listCpaReminderSchedules(CONFIG.accountId);
      return schedules.length === 0;
    }, "All CPA reminder schedules to be deleted");

    const schedules = await listCpaReminderSchedules(CONFIG.accountId);
    expect(schedules.length).toBe(0);
    log("Phase 4", "All CPA reminder schedules cleaned up");
  });

  // ── Scenario 28: CPA alerts gone, other alerts return ──

  test("Phase 4: Verify CPA alerts are no longer showing", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlertsWithOverrides(status);

    const cpaAlerts = alerts.alert.filter(
      (a) =>
        a.title === "Your next payment is coming up" ||
        a.title === "Heads up - your payment's due today!" ||
        a.title === "Your automatic payment didn't go through" ||
        a.title === "Your payment plan has been cancelled",
    );
    expect(cpaAlerts.length).toBe(0);
    log("Phase 4", "No CPA alerts showing after balance_paid cancellation");
  });

  test("Phase 4: Verify non-CPA alerts can now show (DD alerts no longer suppressed)", async () => {
    const status = await getCpaStatus();

    // Simulate an account with DD set up — DD alerts should show now that CPA is gone
    const alerts = await getAlertsWithOverrides(status, {
      directDebitAmountPref: "50",
      daysFromDueDate: 5,
      nextDirectDebitAmount: 50,
      nextStatementDueDate: dayjs().add(5, "day").format("YYYY-MM-DD"),
      totalNextMinimumPaymentDue: 50,
      previousPeriodBalance: 100,
    });

    // With isInCPA=false and DD fields set, CPA should NOT suppress DD alerts
    // The exact alert content depends on alert-service rules, but we verify
    // that the response is valid and doesn't contain CPA-specific alerts
    expect(alerts.message).toBe("Account credit alerts generated successfully");

    const cpaAlerts = alerts.alert.filter(
      (a) => a.message?.includes("payment plan"),
    );
    expect(cpaAlerts.length).toBe(0);
    log("Phase 4", `Got ${alerts.alert.length} alert(s) — CPA not suppressing other alerts`);
  });

  // ── Cleanup: restore Mambu state ──

  test("Phase 4: Verify Mambu interest rate restored", async () => {
    if (originalInterestRate === null || originalInterestRate === 0) {
      log("Phase 4", "Original interest rate was 0 or null — skipping restoration check");
      return;
    }

    await pollUntil(async () => {
      const currentRate = await getMambuInterestRate();
      return currentRate === originalInterestRate;
    }, `Interest rate to restore to ${originalInterestRate}%`);

    const finalRate = await getMambuInterestRate();
    expect(finalRate).toBe(originalInterestRate);
  });

  test("Phase 4: Verify Salesforce collection plan expired", async () => {
    await pollUntil(async () => {
      const status = await getCollectionPlanStatus();
      return status === "Expired";
    }, "Salesforce collection plan to be Expired");

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Expired");
  });

  test("Phase 5: Restore Mambu balance via disbursement", async () => {
    log("Phase 5", `Restoring balance of £${(originalBalancePence / 100).toFixed(2)}...`);
    await makeMambuDisbursement(originalBalancePence);

    const restoredBalance = await getMambuTotalBalancePence();
    log("Phase 5", `Balance restored to £${(restoredBalance / 100).toFixed(2)}`);
    expect(restoredBalance).toBeGreaterThan(0);
  });
});
