import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  createStripeClient,
  cleanupExistingTestClocks,
  createTestClock,
  createTestClockCustomer,
  attachCardToCustomer,
  getOrCreateProduct,
  createSubscriptionWithoutMetadata,
  createCpaSubscription,
  detachPaymentMethod,
  swapPspCustomerId,
  restorePspCustomerId,
  advanceTestClock,
  getCpaStatus,
  verifyWebhookError,
  listCpaReminderSchedules,
  cleanup,
} from "./cpaE2eHelpers";
import Stripe from "stripe";

/**
 * CPA E2E - Validation & Edge Cases
 *
 * QA Scenarios: 11, 12, 19
 * - Missing metadata on subscription → webhook rejects, CPA not activated
 * - Payment method removed before billing → payment fails
 * - No valid payment method at charge time → clear failure
 */

let stripe: Stripe;
let testClock: Stripe.TestHelpers.TestClock;
let stripeCustomer: Stripe.Customer;
let originalPspCustomerId: string | null;
let productId: string;
let startTimeMs: number;

describe("CPA E2E - Validation & Edge Cases", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Validation");
    startTimeMs = Date.now();
    await init();
    stripe = await createStripeClient();
    await cleanupExistingTestClocks(stripe);
    testClock = await createTestClock(stripe, "CPA-E2E-Validation");
    stripeCustomer = await createTestClockCustomer(stripe, testClock.id);
    originalPspCustomerId = await swapPspCustomerId(stripeCustomer.id);
    productId = await getOrCreateProduct(stripe);
  });

  afterAll(async () => {
    if (stripe && testClock) {
      await cleanup(stripe, testClock.id, originalPspCustomerId);
    }
  });

  // ── Scenario 12: Missing Metadata ──

  describe("Missing Metadata", () => {
    let subscriptionNoMetadata: Stripe.Subscription;

    test("Create subscription without required metadata", async () => {
      const paymentMethodId = await attachCardToCustomer(stripe, stripeCustomer.id, CONFIG.happyPathCard);
      const frozenTime = testClock.frozen_time;
      const billingAnchor = frozenTime + 10 * 24 * 60 * 60;
      const cancelAt = frozenTime + 60 * 24 * 60 * 60;

      subscriptionNoMetadata = await createSubscriptionWithoutMetadata(
        stripe,
        stripeCustomer.id,
        paymentMethodId,
        productId,
        billingAnchor,
        cancelAt,
      );

      expect(subscriptionNoMetadata.id).toBeTruthy();
      log("Missing Metadata", `Subscription ${subscriptionNoMetadata.id} created without metadata`);
    });

    test("Verify webhook handler logged metadata error and cancelled subscription", async () => {
      await waitForCondition(
        () => verifyWebhookError('"missing from subscription metadata"', startTimeMs),
        "Webhook error for missing metadata in CloudWatch logs",
        5_000,
        120_000,
      );
      log("Missing Metadata", "Webhook correctly rejected subscription with missing metadata");

      // Verify the subscription was automatically cancelled
      await waitForCondition(
        async () => {
          const sub = await stripe.subscriptions.retrieve(subscriptionNoMetadata.id);
          log("Missing Metadata", `Subscription status: ${sub.status}`);
          return sub.status === "canceled";
        },
        "Subscription to be cancelled due to missing metadata",
        5_000,
        60_000,
      );

      const cancelledSub = await stripe.subscriptions.retrieve(subscriptionNoMetadata.id);
      expect(cancelledSub.status).toBe("canceled");
      expect(cancelledSub.metadata?.cancellationReason).toBe("cancellation_requested");
      log("Missing Metadata", `Subscription ${subscriptionNoMetadata.id} auto-cancelled with reason: cancellation_requested`);
    });

    test("Verify CPA API does not show subscription as active", async () => {
      const status = await getCpaStatus();
      expect(status.isInCPA).toBe(false);
      log("Missing Metadata", "CPA API correctly does not show subscription without metadata");
    });

    test("Verify no CPA reminder schedules were created", async () => {
      const schedules = await listCpaReminderSchedules(CONFIG.accountId);
      expect(schedules.length).toBe(0);
      log("Missing Metadata", "No reminder schedules created for invalid subscription");
    });
  });

  // ── Scenario 11/19: Payment Method Removed Before Billing ──

  describe("Payment Method Removed Before Billing", () => {
    let subscriptionId: string;
    let paymentMethodId: string;

    test("Create valid subscription then detach payment method", async () => {
      // Need a fresh customer for this test since the previous subscription
      // may have tainted the state. We reuse the same test clock.
      paymentMethodId = await attachCardToCustomer(stripe, stripeCustomer.id, CONFIG.happyPathCard);

      const frozenTime = testClock.frozen_time;
      const billingAnchor = frozenTime + 8 * 24 * 60 * 60;
      const cancelAt = frozenTime + 60 * 24 * 60 * 60;

      const subscription = await createCpaSubscription(
        stripe,
        stripeCustomer.id,
        paymentMethodId,
        productId,
        billingAnchor,
        cancelAt,
      );

      subscriptionId = subscription.id;
      expect(subscriptionId).toBeTruthy();

      // Verify subscription is active before detaching
      await waitForCondition(
        async () => {
          const status = await getCpaStatus();
          return status.isInCPA && status.cpaStatus === "active";
        },
        "CPA subscription to appear as active",
        5_000,
      );

      // Detach the payment method
      await detachPaymentMethod(stripe, paymentMethodId);
      log("No Payment Method", "Payment method detached — subscription has no valid payment method");
    });

    test("Advance to billing - payment fails due to no payment method", async () => {
      const frozenTime = testClock.frozen_time;
      const pastBilling = frozenTime + 8 * 24 * 60 * 60 + 1 * 60 * 60;
      await advanceTestClock(stripe, testClock.id, pastBilling);

      await pollUntil(async () => {
        const status = await getCpaStatus();
        log("No Payment Method", `cpaStatus: ${status.cpaStatus}, failed: ${status.cpaPaymentFailed}`);
        return status.cpaPaymentFailed === true;
      }, "Payment to fail (no payment method)");

      const status = await getCpaStatus();
      expect(status.cpaPaymentFailed).toBe(true);
      log("No Payment Method", `Payment failed as expected: status=${status.cpaStatus}, attempts=${status.cpaAttemptCount}`);
    });

    afterAll(async () => {
      if (subscriptionId) {
        try {
          await stripe.subscriptions.cancel(subscriptionId);
          log("No Payment Method", `Cleaned up subscription ${subscriptionId}`);
        } catch {
          // Already cancelled
        }
      }
    });
  });
});
