import { S3Client, ListObjectsV2Command, GetObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";
import { readFile, writeFile } from "fs/promises";
import path from "path";
import { eventHubAdapter } from "@onmoapp/onmo-adapters";

export const BUCKET_NAME = "onmo-archived-events-prod";
const day = "all";
export const SUBFOLDER_PREFIX = `prod-repayment-service-repaymentFailedListener/onmo-business-events-stream-prod/2025/03/${day}/`;
//  "prod-account-service-repaymentCollectedListener/onmo-business-events-stream-prod/2025/03/03/21/";
const REGION = "eu-west-1";
const date = `03-${day}`;
const MAX_CONCURRENT_FILES = 20;
export const OUTPUT_FILE = path.join(__dirname, `aggregatedRepaymentFailed${date}.json`);
const BATCH_SIZE = 200;
const SLEEP_DURATION = 5000;

const s3 = new S3Client({ region: REGION });
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function listFolders(bucket: string, prefix: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, Delimiter: "/" });
  const response = await s3.send(command);
  return response.CommonPrefixes?.map((p) => p.Prefix!) || [];
}

async function listJsonFiles(bucket: string, folder: string): Promise<string[]> {
  const command = new ListObjectsV2Command({ Bucket: bucket, Prefix: folder });
  const response = await s3.send(command);
  return response.Contents?.filter((obj) => obj.Key?.endsWith(".json")).map((obj) => obj.Key!) || [];
}

async function getJsonContent(bucket: string, key: string): Promise<any> {
  try {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3.send(command);

    if (!response.Body) throw new Error(`Empty body for ${key}`);

    const streamToString = async (stream: Readable): Promise<string> => {
      return new Promise((resolve, reject) => {
        const chunks: any[] = [];
        stream.on("data", (chunk) => chunks.push(chunk));
        stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
        stream.on("error", reject);
      });
    };

    const jsonString = await streamToString(response.Body as Readable);
    return JSON.parse(jsonString);
  } catch (error) {
    console.error(`Error reading ${key}:`, error);
    return null;
  }
}

export async function processFolder(bucket: string, folder: string): Promise<any[]> {
  const jsonFiles = await listJsonFiles(bucket, folder);

  const fileBatches: string[][] = [];
  for (let i = 0; i < jsonFiles.length; i += MAX_CONCURRENT_FILES) {
    fileBatches.push(jsonFiles.slice(i, i + MAX_CONCURRENT_FILES));
  }

  let folderData: any[] = [];
  for (const batch of fileBatches) {
    const results = await Promise.allSettled(batch.map((file) => getJsonContent(bucket, file)));
    folderData.push(
      ...results
        .filter((r) => r.status === "fulfilled" && r.value !== null)
        .map((r) => (r as PromiseFulfilledResult<any>).value),
    );
  }

  return folderData;
}

export function removeMetadata(data: any[]): any[] {
  return data.map((item) => {
    const { metaData, ...cleanedItem } = item;
    return cleanedItem;
  });
}

async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

async function retryMessage(jsonObject: any, successArray: any[], failureArray: any[]) {
  try {
    const eventData = jsonObject.eventData;
    const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");
    if (!eventHubClient) {
      throw new Error("No event hub client found for KINESIS_ADAPTER");
    }

    const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
      await eventHubClient.validateEvent(eventData);

    if (!isEventDataValid) {
      console.error(JSON.stringify(eventValidationErrors));
      throw new Error(`An error occurred: ${eventValidationErrors}`);
    }

    const {
      isValid: isPublishingEventValid,
      isPublished,
      validationErrors: publishingValidationErrors,
    } = await eventHubClient.publishToEventHub(eventData, eventData.correlationId);

    if (!isPublishingEventValid || !isPublished) {
      console.error(JSON.stringify(publishingValidationErrors));
      throw new Error(`An error occurred: ${publishingValidationErrors}`);
    }

    successArray.push(jsonObject);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`❌ Failed to send to Kinesis: ${error.message}`);
    }
    console.error(`❌ Failed to send to Kinesis`, error);
    failureArray.push({ jsonObject, error: error.message });
  }
}

async function readFailedEvents(): Promise<any[]> {
  try {
    const fileContent = await readFile(FAILURE_FILE, "utf-8");
    const failedData = JSON.parse(fileContent);
    console.log(`✅ Loaded ${failedData.length} failed events.`);
    return failedData.map((item) => item.jsonObject);
  } catch (error) {
    console.error(`❌ Failed to read ${FAILURE_FILE}:`, error);
    return [];
  }
}

const FAILURE_FILE = path.join(__dirname, `failureRetryFromStripeData.json`);

export async function retryFromJson() {
  // Read failed events from failure.json
  let allJsonData = await readFailedEvents();

  if (allJsonData.length === 0) {
    console.log(`🚫 No failed events to retry.`);
    return;
  }

  // Arrays for success and failure tracking
  const successArray: any[] = [];
  const failureArray: any[] = [];

  // Retry sending each event
  console.log(`📤 Retrying ${allJsonData.length} failed events...`);
  await Promise.allSettled(allJsonData.map((obj) => retryMessage(obj, successArray, failureArray)));

  console.log(`✅ Successfully resent messages: ${successArray.length}`);
  console.log(`❌ Still failing messages: ${failureArray.length}`);

  // Save new success and failure results
  await saveJsonLocally(path.join(__dirname, `successRepaymentFailed${date}kinesis.json`), successArray);
  await saveJsonLocally(path.join(__dirname, `failureRepaymentFailed${date}kinesis.json`), failureArray);
}

export async function retryFromS3() {
  const folders = await listFolders(BUCKET_NAME, SUBFOLDER_PREFIX);

  const results = await Promise.allSettled(folders.map((folder) => processFolder(BUCKET_NAME, folder)));

  let allJsonData = results
    .filter((r) => r.status === "fulfilled")
    .flatMap((r) => (r as PromiseFulfilledResult<any[]>).value);

  allJsonData = removeMetadata(allJsonData);
  console.log(`✅ ${allJsonData.length} JSON objects.`);

  await saveJsonLocally(OUTPUT_FILE, allJsonData);

  const successArray: any[] = [];
  const failureArray: any[] = [];

  console.log(`📤 Sending ${allJsonData.length} objects to Kinesis...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(batch.map((obj) => retryMessage(obj, successArray, failureArray)));

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Successfully sent messages: ${successArray.length}`);
  console.log(`❌ Failed messages: ${failureArray.length}`);

  await saveJsonLocally(path.join(__dirname, `successRepaymentFailed${date}kinesis.json`), successArray);
  await saveJsonLocally(path.join(__dirname, `failureRepaymentFailed${date}kinesis.json`), failureArray);
}

async function main() {
  await retryFromJson();
}

main().catch(console.error);
