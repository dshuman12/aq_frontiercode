import fs from "fs";
import readline from "readline";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";

/***
 * Kept here for reference, this is the one off script that was ran to check if the first mandate migration was successful,
 * and flag accounts that needed remediation
 */

async function processCSV(filePath) {
  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("Error creating core banking client");
  }

  const fileStream = fs.createReadStream(filePath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity,
  });
  const missingMandates: Array<string> = [];

  for await (const line of rl) {
    const [accountId] = line.split(",");
    const { data, error } = await coreBankingClient.getCreditAccount(accountId);
    if (error) {
      console.error(error);
      continue;
    }
    if (data?.directDebitSettings?.mandateID) {
      if (!data.directDebitSettings.mandateID.startsWith("mandate_")) {
        missingMandates.push(accountId);
        console.warn(`Mandate ID is from Gocardless for account ${accountId} - ${data.directDebitSettings.mandateID}`);
      } else {
        console.log(`Mandate ID found for account ${accountId} - ${data.directDebitSettings.mandateID}`);
      }
    } else {
      missingMandates.push(accountId);
      console.warn(`Mandate ID not found for account ${accountId}`);
    }
  }

  if (missingMandates.length > 0) {
    fs.writeFileSync("accountIds.json", JSON.stringify(missingMandates, null, 2));
    console.warn(`Missing mandates for ${missingMandates.length} accounts`);
    console.warn(missingMandates.toString());
  }
}

const filePath = process.argv[2];
if (!filePath) {
  console.error("Usage: ts-node script.ts <file.csv>");
  process.exit(1);
}

processCSV(filePath)
  .then(() => {
    console.log("done");
  })
  .catch(console.error);
