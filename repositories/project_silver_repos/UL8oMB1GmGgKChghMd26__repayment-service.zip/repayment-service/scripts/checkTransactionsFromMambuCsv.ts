import { readFile, writeFile } from "fs/promises";
import path from "path";
import fs from "fs";
import { coreBankingAdapter, coreRepaymentsAdapter, StripeClient } from "@onmoapp/onmo-adapters";
import csvParser from "csv-parser";
import dayjs from "dayjs";
import { createEvent } from "../src/libs/eventHubUtils";
import { RepaymentCollectedEvent } from "../src/shared-types/eventHub-types";
import { getCustomer } from "../src/utils/db";
import { Stripe } from "stripe";

export const BATCH_SIZE = 40;
export const SLEEP_DURATION = 1500;

export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export function removeMetadata(data: any[]): any[] {
  return data.map((item) => {
    const { metaData, ...cleanedItem } = item;
    return cleanedItem;
  });
}

export async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

const SUCCESS_FILE = path.join(__dirname, `success.json`);

export async function readSuccessEvents(): Promise<any[]> {
  try {
    const fileContent = await readFile(SUCCESS_FILE, "utf-8");
    const failedData = JSON.parse(fileContent);
    console.log(`✅ Loaded ${failedData.length} success events.`);
    return failedData.map((item) => item.jsonObject);
  } catch (error) {
    console.error(`❌ Failed to read ${SUCCESS_FILE}:`, error);
    return [];
  }
}

export async function transactionExists(
  repaymentCollectedEventData: any,
  externalId: string,
  success: any[],
  failure: any[],
) {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const res = await bankingClient?.findCreditAccountTransactionsByExternalId(
    repaymentCollectedEventData.eventData.accountId,
    externalId,
  );
  if (res?.error) {
    console.error(res.error);
  } else {
    if (res?.data?.transactions && res.data.transactions.length > 0) {
      success.push({ eventData: repaymentCollectedEventData });
      return Promise.resolve(true);
    } else {
      // checking technical account transactions
      const user = await getCustomer(repaymentCollectedEventData.eventData.customerId);
      const resTech = await bankingClient?.findTechnicalAccountTransactionsByExternalId(
        user.data.technicalAccountId,
        externalId,
      );

      if (resTech?.error) {
        console.error(resTech.error);
      } else {
        if (resTech?.data?.transactions && resTech.data.transactions.length > 0) {
          success.push({ eventData: repaymentCollectedEventData });
          return Promise.resolve(true);
        }
      }
    }
    failure.push({ eventData: repaymentCollectedEventData });
    return Promise.resolve(false);
  }
}

interface ExtractedData {
  accountId: string;
  externalId: string;
  dueDate: string;
}

async function extractAccountAndTransactionIds(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser())
      .on("data", (row) => {
        if (row.accountId && row.externalId && row.dueDate) {
          results.push({
            accountId: row.accountId,
            externalId: row.externalId,
            dueDate: row.dueDate,
          });
        }
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
}

async function prepareRepaymentCollectedEvent(
  repaymentClient: StripeClient,
  stripeClient: Stripe,
  data: ExtractedData,
  successArray: any[],
  failureArray: any[],
) {
  try {
    const paymentIntent = await repaymentClient.getPaymentIntent(data.externalId);
    const stripePaymentIntent = await stripeClient.paymentIntents.retrieve(data.externalId, {
      expand: ["payment_method"],
    });
    const stripePaymentMethod = stripePaymentIntent.payment_method as Stripe.PaymentMethod;

    const mandate =
      stripePaymentMethod.type == "bacs_debit"
        ? await repaymentClient.getMandateIdBySucceededPaymentIntent(data.externalId)
        : null;
    const nextStatementDueDate = dayjs(data.dueDate, "DD/MM/YYYY").toISOString();

    const repaymentCollectedEvent = {
      accountId: data.accountId,
      accountType: "CARD",
      customerId: paymentIntent.customerId,
      date: nextStatementDueDate,
      processor: "Stripe",
      repayment: {
        amount: stripePaymentIntent.amount,
        paymentMethod: mandate ? "DIRECT_DEBIT" : "CARD",
        externalId: data.externalId,
        mandateId: mandate?.mandateId || null,
      },
    } as RepaymentCollectedEvent;

    const repaymentCollectedEventData = createEvent<RepaymentCollectedEvent>(
      repaymentCollectedEvent,
      {
        eventType: "RepaymentCollected",
        subType: mandate ? "DIRECT_DEBIT" : "CARD",
        initiatedBy: "paymentIntentSucceeded",
      },
      stripePaymentIntent.metadata.idempotencyKey,
    );

    await transactionExists(repaymentCollectedEventData, data.externalId, successArray, failureArray);
  } catch (err) {
    console.error(`❌ Error retrying transaction:`, err);
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,customerId,dueDate,externalId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.eventData?.eventData?.accountId || "";
        const customerId = item.eventData?.eventData?.customerId || "";
        const dueDate = item.eventData?.eventData?.date || "";
        const externalId = item.eventData?.eventData?.repayment?.externalId || "";
        return `${accountId},${customerId},${dueDate},${externalId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

/**
 * Check if all the transactions in a given CSV file exist in Mambu, and prepare the repaymentCollectedEvents
 * for the failed ones for easy retry.
 * The file is usually an Excel file given from a Mambu export. Make sure to rename the columns
 * to match the accountId, dueDate (value date) and externalId (transactionId/payment intent id).
 * You can then feed the repaymentCollectedEventsToRetry.json file to the repaymentCollectedRetry script
 * Check the date format - Mambu exports usually use DD/MM/YYYY
 */
async function main() {
  // Read failed events from failure.json
  let allJsonData = await extractAccountAndTransactionIds(path.join(__dirname, "MatchingExport_03122025173914.csv"));

  if (allJsonData.length === 0) {
    console.log(`🚫 No transactions to check.`);
    return;
  }

  const successArray: any[] = [];
  const failureArray: any[] = [];

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  if (!repaymentClient) {
    console.error("No repayment client found for STRIPE_CLIENT");
    return;
  }

  const key = process.env.STRIPE_API_KEY || "";
  const stripeClient = new Stripe(key, {
    apiVersion: "2024-12-18.acacia",
  });

  console.log(`🔍 Checking ${allJsonData.length} transactions...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(
      batch.map((obj) =>
        prepareRepaymentCollectedEvent(repaymentClient, stripeClient, obj, successArray, failureArray),
      ),
    );

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Done: ${successArray.length} ${new Date().toISOString()}`);

  // Save new success and failure results
  await saveJsonLocally(path.join(__dirname, `repaymentCollectedEventsToRetry.json`), failureArray);

  await saveCsvLocally(path.join(__dirname, "successfulRetriesFromMambuCsv.csv"), successArray);
  await saveCsvLocally(path.join(__dirname, "missingTransactions.csv"), failureArray);
}

main().catch(console.error);
