import { describe, test, expect, beforeAll, afterAll } from "vitest";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  advanceTestClock,
  setCollectionPlanActive,
  setMambuInterestRate,
  cleanup,
} from "./cpaE2eHelpers";

dayjs.extend(utc);
dayjs.extend(timezone);

/**
 * CPA E2E - Date & Timezone Consistency
 *
 * QA Scenario: 13
 * - nextCPADueDate format is YYYY-MM-DD
 * - daysFromCPA is timezone-aware (Europe/London)
 * - daysFromCPA decreases as time advances
 * - Dates remain consistent across time advances
 */

let setup: SetupResult;

describe("CPA E2E - Date & Timezone Consistency", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Date-Timezone");
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 1: Setup - create subscription with billing 12 days out", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Date-Timezone",
      12, // billing in 12 days
      60,
    );

    expect(setup.subscription.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    await setCollectionPlanActive();
  });

  test("Phase 1: Set Mambu interest rate to 0", async () => {
    await setMambuInterestRate(0);
  });

  test("Phase 2: Verify subscription active with valid date fields", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();

    // Verify nextCPADueDate format is YYYY-MM-DD
    expect(status.nextCPADueDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    log("Phase 2", `nextCPADueDate: ${status.nextCPADueDate}`);

    // Verify daysFromCPA is a positive number
    expect(status.daysFromCPA).toBeGreaterThan(0);
    log("Phase 2", `daysFromCPA: ${status.daysFromCPA}`);

    // Verify the date is in the future (relative to real time)
    const dueDate = dayjs(status.nextCPADueDate);
    expect(dueDate.isValid()).toBe(true);
    log("Phase 2", `Due date parsed successfully: ${dueDate.format("YYYY-MM-DD")}`);
  });

  test("Phase 2: Verify daysFromCPA is consistent with nextCPADueDate", async () => {
    const status = await getCpaStatus();

    // daysFromCPA should approximately match the difference between
    // "now" in Europe/London and the due date. Since we're using test clocks,
    // the server calculates this based on the test clock's frozen time.
    // We just verify the relationship is reasonable.
    expect(status.daysFromCPA).toBeTruthy();
    expect(status.nextCPADueDate).toBeTruthy();

    // daysFromCPA should be between 1 and the billing days (12)
    expect(status.daysFromCPA).toBeGreaterThan(0);
    expect(status.daysFromCPA).toBeLessThanOrEqual(12);
    log("Phase 2", `daysFromCPA (${status.daysFromCPA}) is within expected range [1, 12]`);
  });

  test("Phase 3: Advance 5 days - daysFromCPA decreases", async () => {
    const statusBefore = await getCpaStatus();
    const daysBefore = statusBefore.daysFromCPA!;

    // Advance 5 days
    const fiveDaysLater = setup.frozenTime + 5 * 24 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, fiveDaysLater);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.daysFromCPA !== null && status.daysFromCPA < daysBefore;
    }, "daysFromCPA to decrease after time advance");

    const statusAfter = await getCpaStatus();
    expect(statusAfter.daysFromCPA).toBeLessThan(daysBefore);

    // nextCPADueDate should remain the same (same billing cycle)
    expect(statusAfter.nextCPADueDate).toBe(statusBefore.nextCPADueDate);

    log("Phase 3", `daysFromCPA decreased: ${daysBefore} → ${statusAfter.daysFromCPA}`);
    log("Phase 3", `nextCPADueDate unchanged: ${statusAfter.nextCPADueDate}`);
  });

  test("Phase 3: Advance to 1 day before billing - daysFromCPA is 1 or less", async () => {
    const oneDayBefore = setup.billingAnchor - 24 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, oneDayBefore);

    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.daysFromCPA !== null && status.daysFromCPA <= 1;
    }, "daysFromCPA to be <= 1");

    const status = await getCpaStatus();
    expect(status.daysFromCPA).toBeLessThanOrEqual(1);
    expect(status.daysFromCPA).toBeGreaterThanOrEqual(0);
    log("Phase 3", `daysFromCPA at 1 day before billing: ${status.daysFromCPA}`);
  });

  test("Phase 4: Advance past billing - next cycle date updates", async () => {
    const statusBefore = await getCpaStatus();
    const dueDateBefore = statusBefore.nextCPADueDate;

    const pastBilling = setup.billingAnchor + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastBilling);

    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        return (
          status.isInCPA &&
          status.cpaStatus === "active" &&
          status.nextCPADueDate !== null &&
          status.nextCPADueDate !== dueDateBefore
        );
      },
      "nextCPADueDate to update to next billing cycle",
      10_000,
      120_000,
    );

    const statusAfter = await getCpaStatus();

    // New due date should be in YYYY-MM-DD format
    expect(statusAfter.nextCPADueDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);

    // New due date should be after the old due date
    const oldDate = dayjs(dueDateBefore);
    const newDate = dayjs(statusAfter.nextCPADueDate);
    expect(newDate.isAfter(oldDate)).toBe(true);

    // daysFromCPA should reset to a higher value for the next cycle
    expect(statusAfter.daysFromCPA).toBeGreaterThan(1);

    log("Phase 4", `Due date updated: ${dueDateBefore} → ${statusAfter.nextCPADueDate}`);
    log("Phase 4", `daysFromCPA reset to: ${statusAfter.daysFromCPA}`);
  });
});
