import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import dayjs, { Dayjs } from "dayjs";
import { CloudWatchLogsClient, StartQueryCommand, GetQueryResultsCommand } from "@aws-sdk/client-cloudwatch-logs";
import path from "path";
import fs from "fs";
import { writeFile } from "fs/promises";
import csvParser from "csv-parser";

async function searchCloudwatch({
  logGroupNames,
  queryString,
  start,
  end,
}: {
  logGroupNames: string[];
  queryString: string;
  start: Dayjs;
  end: Dayjs;
}) {
  const startQuery = new StartQueryCommand({
    logGroupNames,
    startTime: start.valueOf(),
    endTime: end.valueOf(),
    queryString,
  });

  const client = new CloudWatchLogsClient({ region: process.env.TF_VAR_REGION });
  const { queryId } = await client.send(startQuery);

  if (!queryId) throw new Error("Failed to start query");

  let status = "Running";
  let results: any[] = [];

  while (status === "Running" || status === "Scheduled") {
    await new Promise((r) => setTimeout(r, 2000));

    const res = await client.send(new GetQueryResultsCommand({ queryId }));
    status = res.status ?? "Failed";

    if (status === "Complete") {
      results = res.results ?? [];
      break;
    }
  }

  return results;
}

const aggregateInformation = async (accountId: string): Promise<any> => {
  let info = {
    accountId,
    customerId: "",
    missedScheduling: false,
    schedulingStarted: false,
  };

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const { data } = await coreBankingClient.getCreditAccount(accountId);
  info.customerId = data?.accountDetails.customerId ?? "Not Found";
  const fromDate = "2025-09-14";
  const toDate = "2025-09-29";

  const queryString = `
    fields @timestamp, @message, @logStream, @logn
| filter strcontains(@message, "Received event") and message.event.accountId = '${accountId}'
| sort @timestamp desc
| limit 10
  `;
  const logGroup = ["/aws/lambda/prod-repayment-service-directDebitRepaymentProcessor"];

  console.log("Searching CloudWatch logs for accountID:", accountId);
  const test = await searchCloudwatch({
    logGroupNames: logGroup,
    queryString,
    start: dayjs(fromDate).startOf("day"),
    end: dayjs(toDate).endOf("day"),
  });

  if (test.length > 0) {
    console.log("Found log entry, scheduling started successfully");
    info.schedulingStarted = true;
  } else {
    console.log("No log entry found for scheduling");
    info.missedScheduling = true;
  }
  console.log("Final info:", info);
  return info;
};

interface ExtractedData {
  accountId: string;
}

async function extractInfo(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser())
      .on("data", (row) => {
        if (row.accountId) {
          results.push({
            accountId: row.accountId,
          });
        }
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,dueDate,installmentState,minimumAmount,customerId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.accountId || "";
        const dueDate = item.dueDate || "";
        const installmentState = item.installmentState || "";
        const minimumAmount = item.minimumAmount || "";
        const customerId = item.customerId || "";
        return `${accountId},${dueDate},${installmentState},${minimumAmount},${customerId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

export const checkDDOwed = async (accountId: string): Promise<any> => {
  let info = {
    accountId,
    customerId: "",
    dueDate: "",
    installmentState: "",
    minimumAmount: 0,
    debugDate: "",
  };

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const { data } = await coreBankingClient.getCreditAccount(accountId);
  info.customerId = data?.accountDetails.customerId ?? "Not Found";
  info.installmentState = data?.installmentDetails?.installmentState ?? "Not Found";
  info.dueDate = data?.installmentDetails?.nextInstallmentDate ?? "Not Found";
  const unpaid = data?.installmentDetails?.lastUnpaidInstallment;

  info.debugDate = unpaid?.dueDate ?? "Not Found";
  info.minimumAmount =
    (unpaid?.principal?.amount?.due || 0) + (unpaid?.interest?.amount?.due || 0) + (unpaid?.fee?.amount?.due || 0);

  if (!unpaid && info.installmentState !== "PAID") {
    const test = await coreBankingClient.getInstalmentByDueDate(accountId, info.dueDate);
    const schedule = test.data;
    info.minimumAmount =
      (schedule?.principal?.amount?.due || 0) +
      (schedule?.interest?.amount?.due || 0) +
      (schedule?.fee?.amount?.due || 0);
  }
  return info;
};

async function main() {
  // to generate this log insights csv, go to CloudWatch Insights and run the following query
  // with log group /aws/lambda/prod-repayment-service-directDebitScheduler:
  /*
  fields @timestamp, message.API_REQUEST.url, @message, @logStream, @log
  | filter strcontains(@message, "Throttling: API request limit exceeded")
  | sort @timestamp desc
  | limit 10000 */
  // then you can do a clean up of the URL to only keep the accountId (I used a combinaison of LEFT and RIGHT in Excel)
  let allJsonData = await extractInfo(path.join(__dirname, "logs-insights-results-7.csv"));
  const result = [] as any[];
  for (const data of allJsonData) {
    // this is going to be long, each query to CW takes a few seconds, and the original file had about 900 rows
    const info = await aggregateInformation(data.accountId);
    result.push(info);
  }

  const missedScheduling = result.filter((a) => a.missedScheduling);
  const schedulingStarted = result.filter((a) => a.schedulingStarted);
  console.log("Accounts that missed scheduling:", missedScheduling.length);
  console.log("Accounts that started scheduling:", schedulingStarted.length);

  await saveCsvLocally(path.join(__dirname, "dd_mambu_missed_scheduling.csv"), missedScheduling);
  await saveCsvLocally(path.join(__dirname, "dd_mambu_scheduling_started.csv"), schedulingStarted);

  const checkInstalmentRes = [] as any[];
  for (const data of missedScheduling) {
    const info = await checkDDOwed(data.accountId);
    checkInstalmentRes.push(info);
  }

  const owedDD = checkInstalmentRes.filter((a) => a.installmentState !== "PAID");
  await saveCsvLocally(path.join(__dirname, "missed_dd_schedule_mambu_outage.csv"), owedDD);

  const paid = checkInstalmentRes.filter((a) => a.installmentState === "PAID");
  await saveCsvLocally(path.join(__dirname, "already_paid_dd_mambu_outage.csv"), paid);
  console.log("Process completed.");
}

main().catch(console.error);
