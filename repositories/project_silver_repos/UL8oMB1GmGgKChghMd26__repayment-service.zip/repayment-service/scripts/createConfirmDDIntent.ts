import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import Stripe from "stripe";
import { v4 as uuid } from "uuid";

async function main() {
  const mandateId = "mandate_1R1W5ORp1KcrfXlP1ik5exZ7";
  const pspCustomerId = "cus_RPo40ucEuS7iRg";
  const amount = 1000;
  const customerId = "78fa61e3-c9ed-4786-9ee7-d88c3f934bd6";
  const accountId = "SVBS920";
  const accountType = "card";
  const instalmentDate = "2025-03-24";
  //const originalUserPreference = "Minimum Payment";
  const idempotencyKey = uuid();
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  const paymentMethod = await repaymentClient?.getPaymentMethodByMandateId(mandateId);
  if (!paymentMethod) {
    throw new Error("No payment method found for mandate");
  }

  const stripeClient = new Stripe(
    "sk_test_51QAC9ZRp1KcrfXlPT5orQBthSH2kbIqUPTe8vHP4sy2n3rJw82Ecl7oyHlaBMzOllDdbkUYg00VEwMfhRtTnBbaV00mZ0SjROF",
    {
      apiVersion: "2024-12-18.acacia",
    },
  );

  const paymentIntention = await stripeClient?.paymentIntents.create(
    {
      customer: pspCustomerId,
      amount,
      currency: "gbp",
      payment_method: paymentMethod.paymentMethodId,
      payment_method_types: ["bacs_debit"],
      metadata: {
        idempotencyKey: uuid(),
        accountId,
        customerId,
        accountType,
        instalmentDate,
        //originalUserPreference,
      },
    },
    { idempotencyKey },
  );

  if (!paymentIntention.client_secret || !paymentIntention.amount) {
    throw new Error("Failed to create payment intention");
  }

  console.log({
    customer: pspCustomerId,
    paymentIntentId: paymentIntention.id,
    paymentMethodId: paymentMethod.paymentMethodId,
    status: paymentIntention.status,
  });

  const paymentIntentId = paymentIntention.id;

  console.log({ message: "Payment intention created", paymentIntentId });

  const confirmedPaymentIntention = await repaymentClient?.confirmPaymentIntent({
    paymentIntentId,
    idempotencyKey: `${idempotencyKey}-confirm`,
  });

  console.log({ message: "Confirmed payment intention", confirmedPaymentIntention });

  //await coreBankingClient.setScheduledAmount(customer.data.accountId, nextDirectDebitAmount);
  //logger.info({ message: "Scheduled amount set in Mambu account", nextDirectDebitAmount });

  console.log("Event published successfully");
}

main().catch(console.error);
