import { deleteAccessTokenOfTestUser } from "../src/utils/oidcAuthToken";
import { deleteTestCreditCustomerAccount } from "../src/utils/customerAccountUtils";

async function run(userCreds, accessToken) {
  try {
    await deleteTestCreditCustomerAccount(userCreds);
    console.log("Customer account deleted", userCreds);
    await deleteAccessTokenOfTestUser(userCreds.customerId, accessToken);
    console.log("Access token deleted.");
  } catch (error) {
    console.error("Error deleting access token:", error);
  }
}

if (!process.argv[2] || !process.argv[3]) throw new Error("Missing arguments");

const userCreds = JSON.parse(process.argv[2]);
const accessToken = JSON.parse(process.argv[3]);

run(userCreds, accessToken);
