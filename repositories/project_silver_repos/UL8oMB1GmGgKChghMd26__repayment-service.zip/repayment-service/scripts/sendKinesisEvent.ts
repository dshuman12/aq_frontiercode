import { eventHubAdapter } from "@onmoapp/onmo-adapters";
import { RepaymentFailedEvent } from "../src/shared-types/eventHub-types";
import { createEvent } from "../src/libs/eventHubUtils";
import dayjs from "dayjs";
async function main() {
  // const event = {
  //   id: uuid(),
  //   idempotencyKey: uuid(),
  //   correlationId: uuid(),
  //   event: "RepaymentCollected",
  //   subtype: "CARD",
  //   source: "repayment-service",
  //   schemaVersion: "d052498b-9ce0-421a-ba4a-87c4b73e0b6d",
  //   created: "2025-03-24T16:50:13.783Z",
  //   initiatedBy: "paymentIntentSucceeded",
  //   eventData: {
  //     accountId: "JTZT945",
  //     accountType: "CARD",
  //     customerId: "force-trigger-not-found",
  //     date: "2025-03-22T15:50:13.783Z",
  //     processor: "Stripe",
  //     repayment: {
  //       amount: 1343,
  //       paymentMethod: "CARD",
  //       externalId: "pi_test-test",
  //       mandateId: null,
  //     },
  //   },
  // } as EventData<RepaymentCollectedEvent>;

  // const event = {
  //   id: uuid(),
  //   idempotencyKey: uuid(),
  //   correlationId: uuid(),
  //   event: "RepaymentFailed",
  //   subtype: "DIRECT_DEBIT",
  //   source: "repayment-service",
  //   schemaVersion: "d052498b-9ce0-421a-ba4a-87c4b73e0b6d",
  //   created: "2025-03-24T16:50:13.783Z",
  //   initiatedBy: "webhookHandler",
  //   eventData: {
  //     accountId: "JTZT945",
  //     accountType: "CARD",
  //     customerId: "randomUUID",
  //     failureDetails: {
  //       failureCategory: "INSUFFICIENT_FUNDS",
  //       failureCode: "RANDOM",
  //       failureMessage: "RANDOM",
  //       failureTime: dayjs().format("YYYY-MM-DD"),
  //     },
  //     paymentDetails: {
  //       amount: 900,
  //       paymentMethod: "DIRECT_DEBIT",
  //       externalId: "pi_test-test",
  //       mandateId: "test test",
  //     },
  //     processor: "Stripe",
  //     processorReference: "random",
  //   },
  // } as EventData<RepaymentFailedEvent>;

  /*

   accountId: event.metadata.accountId,
    accountType: AccountType.Card,
    customerId: event.metadata.customerId,
    failureDetails: {
      failureCategory: getFailureCategory(event),
      failureCode: event.failureReason.declineCode
        ? `${event.failureReason.failureCode}-${event.failureReason.declineCode}`
        : `${event.failureReason.failureCode}`,
      failureMessage: event.failureReason.message,
      failureTime: event.created.toString(),
    },
    paymentDetails: {
      amount: event.amount, // Amount received is in cents,
      paymentMethod: repaymentType,
      externalId: event.paymentIntentId,
      mandateId: mandate ? mandate.mandateId : null,
    },
    processor: "Stripe",
    processorReference: event.paymentIntentId,

    */

  const repaymentFailedEvent = {
    accountId: "AZTI246",
    accountType: "CARD",
    customerId: "0f878845-4e1f-4e27-b9de-b071a7026594",
    failureDetails: {
      failureCategory: "INSUFFICIENT_FUNDS",
      failureCode: "RANDOM",
      failureMessage: "RANDOM",
      failureTime: dayjs().format("YYYY-MM-DD"),
    },
    paymentDetails: {
      amount: 900,
      paymentMethod: "DIRECT_DEBIT",
      externalId: "pi_test-test",
      mandateId: "test test",
    },
    processor: "Stripe",
    processorReference: "random",
  } as RepaymentFailedEvent;

  const event = createEvent<RepaymentFailedEvent>(repaymentFailedEvent, {
    eventType: "RepaymentFailed",
    subType: "DIRECT_DEBIT",
    initiatedBy: "paymentIntentFailed",
  });

  event.schemaVersion = "2a55b1db-b77e-4fbf-8039-f935b4122c00"; //hard code version since this comes from SSM param
  console.log(event);
  console.log({ correlationId: event.correlationId, id: event.id, idempotencyKey: event.idempotencyKey });
  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");
  if (!eventHubClient) {
    throw new Error("No event hub client found for KINESIS_ADAPTER");
  }

  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(event);
  if (!isEventDataValid) {
    console.error(eventValidationErrors);
    throw new Error(`An error occurred when validating : ${JSON.stringify(eventValidationErrors)}`);
  }

  const { isPublished, isValid, validationErrors } = await eventHubClient.publishToEventHub(event, event.correlationId);
  if (!isPublished || !isValid) {
    throw new Error(`An error occurred when publishing: ${JSON.stringify(validationErrors)}`);
  }

  console.log("Event published successfully");
}

main().catch(console.error);
