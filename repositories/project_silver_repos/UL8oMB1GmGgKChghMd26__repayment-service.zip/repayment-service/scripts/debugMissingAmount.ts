import Stripe from "stripe";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import dayjs, { Dayjs } from "dayjs";
import { CloudWatchLogsClient, StartQueryCommand, GetQueryResultsCommand } from "@aws-sdk/client-cloudwatch-logs";

async function searchCloudwatch({
  logGroupNames,
  queryString,
  start,
  end,
}: {
  logGroupNames: string[];
  queryString: string;
  start: Dayjs;
  end: Dayjs;
}) {
  const startQuery = new StartQueryCommand({
    logGroupNames,
    startTime: start.valueOf(),
    endTime: end.valueOf(),
    queryString,
  });

  const client = new CloudWatchLogsClient({ region: process.env.TF_VAR_REGION });
  const { queryId } = await client.send(startQuery);

  if (!queryId) throw new Error("Failed to start query");

  let status = "Running";
  let results: any[] = [];

  while (status === "Running" || status === "Scheduled") {
    await new Promise((r) => setTimeout(r, 2000));

    const res = await client.send(new GetQueryResultsCommand({ queryId }));
    status = res.status ?? "Failed";

    if (status === "Complete") {
      results = res.results ?? [];
      break;
    }
  }

  return results;
}

function findRawBody(cwResults: any[]): any {
  for (const row of cwResults) {
    const messageField = row.find((f) => f.field === "@message");
    if (!messageField?.value) continue;

    const [, , , jsonString] = messageField.value.split("\t");

    try {
      const parsed = JSON.parse(jsonString);
      const rawBodyEscaped = parsed.message.rawBody;
      const rawBody = JSON.parse(rawBodyEscaped);

      return rawBody;
    } catch (err) {
      console.error("Failed to parse message", err);
    }
  }
}

type Change = {
  fieldDetailName: string;
  originalValue: string | null;
  newValue: string | null;
  timestamp: string;
};

function formatChanges(changes: Change[]) {
  const sorted = [...changes].sort((a, b) => dayjs(a.timestamp).valueOf() - dayjs(b.timestamp).valueOf());

  const grouped: Record<string, string[]> = {};

  for (const c of sorted) {
    const day = dayjs(c.timestamp).format("YYYY-MM-DD");

    let text = "";
    if (c.newValue == null) {
      text = `Removed ${c.fieldDetailName} ${c.originalValue}`;
    } else if (c.originalValue == null) {
      text = `Added ${c.fieldDetailName} ${c.newValue}`;
    } else {
      text = `Updated ${c.fieldDetailName} from ${c.originalValue} to ${c.newValue}`;
    }

    if (!grouped[day]) grouped[day] = [];
    grouped[day].push(text);
  }

  return grouped;
}

async function fetchInBatches<T>(
  fromDate: string,
  toDate: string,
  batchSizeDays: number,
  fetchBatch: (from: string, to: string) => Promise<T[]>,
): Promise<T[]> {
  let cursor = dayjs(fromDate);
  const end = dayjs(toDate);
  const allResults: T[] = [];
  let safetyCounter = 0;

  while (cursor.isBefore(end) || cursor.isSame(end, "day")) {
    if (safetyCounter++ > 100) throw new Error("Batch loop stuck");

    const batchStart = cursor;

    const batchEndTimestamp = Math.min(cursor.add(batchSizeDays - 1, "day").valueOf(), end.valueOf());
    const batchEnd = dayjs(batchEndTimestamp);

    const results = await fetchBatch(batchStart.format("YYYY-MM-DD"), batchEnd.format("YYYY-MM-DD"));
    if (results?.length) allResults.push(...results);

    cursor = batchEnd.add(1, "day");
  }

  return allResults;
}

type CWField = { field: string; value: string };
type CWResult = CWField[][];

function extractUniqueDates(results: CWResult): string[] {
  const dates: string[] = results
    .map((entry) => entry.find((field) => field.field === "@timestamp")?.value)
    .filter((ts): ts is string => Boolean(ts)) // remove undefined
    .map((ts) => dayjs(ts).format("YYYY-MM-DD"));

  // Force Set<string> → string[]
  return Array.from(new Set<string>(dates));
}

type MandateInfo = {
  mandateId: string;
  stripeCancelEventId: string;
  mandateCancelReason: string;
  date: string;
};

const aggregateInformation = async (accountId: string, mandateId: string) => {
  let info = {
    fromGoCardless: false,
    accountId,
    currentMandateId: mandateId,
    customerId: "",
    mandateCancelActivities: [] as MandateInfo[],
    manualDDcreationDates: [] as string[],
  };
  const stripeClient = new Stripe(process.env.STRIPE_API_KEY || "", {
    apiVersion: "2024-12-18.acacia",
  });

  const customer = await stripeClient.customers.search({
    query: `metadata['accountId']:'${accountId}'`,
  });

  console.log(customer);
  info.fromGoCardless = !!customer.data[0]?.metadata.old_id;
  info.customerId = customer.data[0]?.metadata.customerId;
  console.log(info);

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const fromDate = "2024-01-01";
  const toDate = "2025-09-11";
  const allActivities = await fetchInBatches(fromDate, toDate, 21, async (from, to) => {
    const response = await coreBankingClient.getCustomerActivity({
      customerId: info.customerId,
      fromDate: from,
      toDate: to,
    });
    return response?.data?.activity || [];
  });

  const ddActivities = allActivities
    .filter((a) => a.activity.type === "LOAN_ACCOUNT_EDITED" && a.activity.fieldChanges.length > 0)
    .map((a) => a.activity)
    .flatMap((activity) =>
      activity.fieldChanges
        .filter((fc) => !!fc.fieldDetailName && fc.fieldDetailName.startsWith("Direct Debit"))
        .map((fc) => ({
          fieldDetailName: fc.fieldDetailName,
          originalValue: fc.originalValue,
          newValue: fc.newValue,
          timestamp: activity.timestamp,
        })),
    );
  if (!ddActivities) {
    console.log("No direct debit activities found");
    return;
  }

  const formattedDDActivities = formatChanges(ddActivities);
  console.log(formattedDDActivities);

  const removedPrefDates = ddActivities.filter(
    (a) => a.fieldDetailName === "Direct Debit Payment Amount Preference" && !a.newValue,
  );

  for (const removedPrefDate of removedPrefDates) {
    const formattedRemovedPrefDate = dayjs(removedPrefDate?.timestamp).format("YYYY-MM-DD");
    const activityForRemovePref = formattedDDActivities[formattedRemovedPrefDate];

    const mandateFromActivity = activityForRemovePref
      .find((a) => a.includes("Direct Debit Mandate ID"))
      ?.split(" ")
      .at(-1);

    const queryString = `
    fields @timestamp, @message, @logStream, @log
    | filter strcontains(@message, "${mandateFromActivity}")
        and strcontains(@message, "Received webhook event")
    | sort @timestamp desc
    | limit 10
  `;
    const logGroup = ["/aws/lambda/prod-repayment-service-webhookHandler"];

    console.log("Searching CloudWatch logs for mandate ID:", mandateFromActivity);
    const test = await searchCloudwatch({
      logGroupNames: logGroup,
      queryString,
      start: dayjs(formattedRemovedPrefDate).startOf("day"),
      end: dayjs(formattedRemovedPrefDate).endOf("day"),
    });

    const rawBody = findRawBody(test);

    const stripeEvent = rawBody.data?.object;
    info.mandateCancelActivities.push({
      stripeCancelEventId: rawBody.id || "Not found",
      mandateId: stripeEvent?.id || "Not found",
      mandateCancelReason: stripeEvent?.payment_method_details?.bacs_debit?.revocation_reason || "Not found",
      date: formattedRemovedPrefDate,
    });
  }

  console.log("Searching CW logs for user calling createDirectDebitHosted endpoint...");
  const appDDcreation = await searchCloudwatch({
    logGroupNames: ["/aws/lambda/prod-repayment-service-createDirectDebitHosted"],
    queryString: `fields @timestamp, @message, @logStream, @log
    | filter strcontains(@message, "Direct debit session created") and customerId = '${info.customerId}'
    | sort @timestamp asc
    | limit 10`,
    start: dayjs(fromDate).startOf("day"),
    end: dayjs(toDate).endOf("day"),
  });
  info.manualDDcreationDates = extractUniqueDates(appDDcreation);

  console.log(info);
};

async function main() {
  await aggregateInformation("YRAB168", "d");
}

main().catch(console.error);
