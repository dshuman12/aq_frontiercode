import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import dayjs, { Dayjs } from "dayjs";
import { CloudWatchLogsClient, StartQueryCommand, GetQueryResultsCommand } from "@aws-sdk/client-cloudwatch-logs";
import path from "path";
import fs from "fs";
import { writeFile } from "fs/promises";
import csvParser from "csv-parser";
import { queryTableMethod } from "@onmoapp/onmo-dynamodb";

async function searchCloudwatch({
  logGroupNames,
  queryString,
  start,
  end,
}: {
  logGroupNames: string[];
  queryString: string;
  start: Dayjs;
  end: Dayjs;
}) {
  const startQuery = new StartQueryCommand({
    logGroupNames,
    startTime: start.valueOf(),
    endTime: end.valueOf(),
    queryString,
  });

  const client = new CloudWatchLogsClient({ region: process.env.TF_VAR_REGION });
  const { queryId } = await client.send(startQuery);

  if (!queryId) throw new Error("Failed to start query");

  let status = "Running";
  let results: any[] = [];

  while (status === "Running" || status === "Scheduled") {
    await new Promise((r) => setTimeout(r, 2000));

    const res = await client.send(new GetQueryResultsCommand({ queryId }));
    status = res.status ?? "Failed";

    if (status === "Complete") {
      results = res.results ?? [];
      break;
    }
  }

  return results;
}

export const aggregateInformation = async (accountId: string): Promise<any> => {
  let info = {
    accountId,
    customerId: "",
    missedScheduling: false,
    schedulingStarted: false,
  };

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const { data } = await coreBankingClient.getCreditAccount(accountId);
  info.customerId = data?.accountDetails.customerId ?? "Not Found";
  const fromDate = "2025-09-14";
  const toDate = "2025-09-29";

  const queryString = `
    fields @timestamp, @message, @logStream, @logn
| filter strcontains(@message, "Received event") and message.event.accountId = '${accountId}'
| sort @timestamp desc
| limit 10
  `;
  const logGroup = ["/aws/lambda/prod-repayment-service-directDebitRepaymentProcessor"];

  console.log("Searching CloudWatch logs for accountID:", accountId);
  const test = await searchCloudwatch({
    logGroupNames: logGroup,
    queryString,
    start: dayjs(fromDate).startOf("day"),
    end: dayjs(toDate).endOf("day"),
  });

  if (test.length > 0) {
    console.log("Found log entry, scheduling started successfully");
    info.schedulingStarted = true;
  } else {
    console.log("No log entry found for scheduling");
    info.missedScheduling = true;
  }
  console.log("Final info:", info);
  return info;
};

interface ExtractedData {
  accountId: string;
  cardId: string;
}

export async function extractInfo(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser())
      .on("data", (row) => {
        if (row.accountId && row.cardId) {
          results.push({
            accountId: row.accountId,
            cardId: row.cardId,
          });
        }
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
}

export async function saveCsvLocally(filePath: string, data: any[], headers?: string) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = headers || "accountId,dueDate,installmentState,minimumAmount,customerId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.accountId || "";
        const dueDate = item.dueDate || "";
        const installmentState = item.installmentState || "";
        const minimumAmount = item.minimumAmount || "";
        const customerId = item.customerId || "";
        const cardId = item.cardId || "";
        const dynamoStatus = item.dynamoStatus || "";
        const ptyStatus = item.ptyStatus || "";
        const dateTime = item.dateTime || "";

        return headers
          ? `${cardId},${item.customerId},${item.accountId},${dynamoStatus},${ptyStatus},${dateTime}`
          : `${accountId},${dueDate},${installmentState},${minimumAmount},${customerId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

export const checkDDOwed = async (accountId: string): Promise<any> => {
  let info = {
    accountId,
    customerId: "",
    dueDate: "",
    installmentState: "",
    minimumAmount: 0,
    debugDate: "",
  };

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const { data } = await coreBankingClient.getCreditAccount(accountId);
  info.customerId = data?.accountDetails.customerId ?? "Not Found";
  info.installmentState = data?.installmentDetails?.installmentState ?? "Not Found";
  info.dueDate = data?.installmentDetails?.nextInstallmentDate ?? "Not Found";
  const unpaid = data?.installmentDetails?.lastUnpaidInstallment;

  info.debugDate = unpaid?.dueDate ?? "Not Found";
  info.minimumAmount =
    (unpaid?.principal?.amount?.due || 0) + (unpaid?.interest?.amount?.due || 0) + (unpaid?.fee?.amount?.due || 0);

  if (!unpaid && info.installmentState !== "PAID") {
    const test = await coreBankingClient.getInstalmentByDueDate(accountId, info.dueDate);
    const schedule = test.data;
    info.minimumAmount =
      (schedule?.principal?.amount?.due || 0) +
      (schedule?.interest?.amount?.due || 0) +
      (schedule?.fee?.amount?.due || 0);
  }
  return info;
};

export function extractBodies(results) {
  return results.flatMap((innerArray) =>
    innerArray
      .filter((item) => item.field === "@message")
      .map((item) => {
        try {
          // Remove timestamp/UUID/INFO prefix
          const jsonPart = item.value.split("\t").slice(3).join("\t");
          const parsed = JSON.parse(jsonPart);
          return JSON.parse(parsed.message.event.body);
        } catch (err) {
          console.warn("Failed to parse message:", err);
          return null;
        }
      })
      .filter(Boolean),
  );
}

interface MessageBody {
  MESSAGE_TYPE: {
    "Message Type": string;
    "Message Desc": string;
  };
  SUMMARY: {
    "Unique Identifier": string;
    "Client ID": number;
    PID: number;
    Token: number;
    "Token Status_Old": string;
    "Token Status_New": string;
    Source: string;
    Network: string;
    Date_Time: string; // 'dd-MM-yyyy HH:mm:ss'
    Message_Reason: any;
  };
}

export function mergeByLatestToken(bodies: MessageBody[]): MessageBody[] {
  const map = new Map<number, MessageBody>();

  bodies.forEach((item) => {
    const token = item.SUMMARY.Token;
    const itemDate = dayjs(item.SUMMARY.Date_Time, "DD-MM-YYYY HH:mm:ss");

    const existing = map.get(token);
    if (!existing) {
      map.set(token, item);
    } else {
      const existingDate = dayjs(existing.SUMMARY.Date_Time, "DD-MM-YYYY HH:mm:ss");
      if (itemDate.isAfter(existingDate)) {
        map.set(token, item);
      }
    }
  });

  return Array.from(map.values());
}

export const PTYtoOnmoStatus: Record<string, string> = {
  "1000": "ACTIVE",
  "1005": "FREEZE",
  "1199": "VOID",
  "1001": "PENDING",
  "1004": "RETAIN",
  "1008": "VERIFY",
  "1041": "LOST",
  "1043": "STOLEN",
  "1054": "EXPIRED",
  "1154": "EXPIRED",
  "1062": "LOCK",
} as const;

async function main() {
  const query = `
    fields @message
  | filter strcontains(@message, "Received message")
  | sort @timestamp desc
  | limit 10000`;

  const part1 = await searchCloudwatch({
    logGroupNames: ["/aws/lambda/prod-card-service-cardStatusUpdateWebhook"],
    queryString: query,
    start: dayjs("2025-09-18").startOf("day"),
    end: dayjs("2025-10-03").endOf("day"),
  });

  const part2 = await searchCloudwatch({
    logGroupNames: ["/aws/lambda/prod-card-service-cardStatusUpdateWebhook"],
    queryString: query,
    start: dayjs("2025-09-05").startOf("day"),
    end: dayjs("2025-09-17").endOf("day"),
  });

  const part3 = await searchCloudwatch({
    logGroupNames: ["/aws/lambda/prod-card-service-cardStatusUpdateWebhook"],
    queryString: query,
    start: dayjs("2025-09-01").startOf("day"),
    end: dayjs("2025-09-04").endOf("day"),
  });

  const flattened = extractBodies(part1).concat(extractBodies(part2), extractBodies(part3));

  const merged = mergeByLatestToken(flattened);
  const mismatched = [] as any[];
  let count = 1;

  for (const item of merged) {
    const response = await queryTableMethod({
      TableName: "customer-to-card-mapping-prod",
      KeyConditionExpression: "cardId = :cardId",
      ExpressionAttributeValues: {
        ":cardId": item.SUMMARY.Token.toString(),
      },
    });
    if (!response.Items || response.Items.length === 0) {
      return;
    }
    const dynamoStatus = response.Items[0].cardStatus;
    const ptyStatus = PTYtoOnmoStatus[item.SUMMARY["Token Status_New"]];
    console.log(`Processing ${count++} of ${merged.length} - Dynamo: ${dynamoStatus}, PTY: ${ptyStatus}`);

    if (dynamoStatus !== ptyStatus) {
      mismatched.push({
        cardId: item.SUMMARY.Token.toString(),
        customerId: response.Items[0].customerId,
        accountId: response.Items[0].coreBankingAccountId,
        dynamoStatus,
        ptyStatus,
        dateTime: item.SUMMARY.Date_Time,
      });
    }
  }

  console.log(`Looked through ${merged.length} entries - found ${mismatched.length} mismatches`);
  await saveCsvLocally(
    "cardStatusMismatches.csv",
    mismatched,
    "cardId,customerId,accountId,dynamoStatus,ptyStatus,dateTime\n",
  );

  // count = 0;
  // for (const mismatch of mismatched) {
  //   console.log(`${count++}/${mismatched.length} - Removing cardStatus for ${mismatch.accountId}`);
  //   await updateItemMethod({
  //     TableName: "customer-to-card-mapping-prod",
  //     Key: { cardId: mismatch.cardId },
  //     UpdateExpression: "REMOVE cardStatus",
  //   });
  // }
}

main().catch(console.error);
