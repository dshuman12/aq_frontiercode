import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import Stripe from "stripe";

// This script allows you to update an existing payment intent with a new direct debit mandate

async function main(mandateId: string, paymentIntentId: string) {
  console.info(`Attempting to update payment intent ${paymentIntentId} with mandate ${mandateId}`);
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  const paymentMethod = await repaymentClient?.getPaymentMethodByMandateId(mandateId);
  if (!paymentMethod) {
    throw new Error("No payment method found for mandate");
  }

  console.info(`Payment method found: ${JSON.stringify(paymentMethod)}`);
  const stripeClient = new Stripe(
    "sk_test_51QAC9ZRp1KcrfXlPT5orQBthSH2kbIqUPTe8vHP4sy2n3rJw82Ecl7oyHlaBMzOllDdbkUYg00VEwMfhRtTnBbaV00mZ0SjROF",
    {
      apiVersion: "2024-12-18.acacia",
    },
  );

  await stripeClient.paymentIntents.update(paymentIntentId, {
    payment_method: paymentMethod.paymentMethodId,
  });
  console.info(`Payment intent ${paymentIntentId} updated successfully with ${paymentMethod.paymentMethodId}`);
}

if (!process.argv[2] || !process.argv[3]) {
  console.error("Missing argument(s). Usage: npm run set-mandate-on-pi <mandateId> <paymentIntentId>");
  process.exit(1);
}

const mandateId = process.argv[2];
const paymentIntentId = process.argv[3];

main(mandateId, paymentIntentId).catch(console.error);
