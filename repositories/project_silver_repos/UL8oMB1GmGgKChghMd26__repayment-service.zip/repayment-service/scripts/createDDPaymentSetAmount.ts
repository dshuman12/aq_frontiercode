import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { v4 as uuid } from "uuid";
import { getCustomer } from "../src/utils/db";
import { RepaymentType } from "../src/libs/types";
import { CreateMandateRepayment } from "@onmoapp/onmo-types";

// Only use this if you need to create a DD no matter the state of nextDirectDebitAmount
// and need to set the amount yourself
// This is a bit step by step and does not call the exact same function as the one we use on prod

// it is best to use createDDintent if possible to match prod behaviour

async function main() {
  const mandateId = "mandate_1R1W5ORp1KcrfXlP1ik5exZ7";
  const idempotencyKey = uuid();
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  const paymentMethod = await repaymentClient?.getPaymentMethodByMandateId(mandateId);
  if (!paymentMethod) {
    throw new Error("No payment method found for mandate");
  }

  const accountId = "AAIV308";
  const customerId = "a5ff4619-d5db-4a52-ad35-dde205cbc5a3";
  const customer = await getCustomer(customerId);

  const creditAccount = await coreBankingClient?.getCreditAccount(customer.data.accountId);
  if (!creditAccount?.data) {
    throw new Error(`Error getting credit account with ID: ${customer.data.accountId}, ${creditAccount?.error}`);
  }

  const accountData = creditAccount.data;
  const { nextDirectDebitAmount, mandateID, amountPreference } = accountData?.directDebitSettings;
  if (!mandateID) {
    throw new Error("No mandate ID found");
  }

  if (!amountPreference) {
    throw new Error("No amount preference found");
  }

  if (!accountData?.installmentDetails?.nextInstallmentDate) {
    throw new Error("No next installment date found");
  }

  console.info(`Original DD amount: ${nextDirectDebitAmount}`);
  const amount = 1000; // this is in pence

  const payload = {
    accountId,
    mandateId: mandateID,
    accountType: "card",
    amount,
    customerId,
    idempotencyKey,
    instalmentDate: accountData?.installmentDetails?.nextInstallmentDate, // you may need to hardcode it when forcing DD retry, it should be in the past in that case
    originalUserPreference: amountPreference,
    pspCustomerId: customer.data.pspCustomerId,
    repaymentType: RepaymentType.DirectDebit,
  } as CreateMandateRepayment;

  console.info("Preparing payload for DD repayment", payload);
  const res = await repaymentClient?.createMandateRepayment(payload);
  console.info(`Created payment: ${res?.paymentIntentId} ${res?.status}`);
  if (!res?.paymentIntentId) {
    throw new Error("No payment intent ID found");
  }
  await repaymentClient?.confirmPaymentIntent({ paymentIntentId: res?.paymentIntentId, idempotencyKey: uuid() });

  await coreBankingClient?.setScheduledAmount(customer.data.accountId, Number((amount / 100).toFixed(2)));
  console.info(`Confirmed payment and set scheduled amount to ${Number((amount / 100).toFixed(2))}`);
}

main().catch(console.error);
