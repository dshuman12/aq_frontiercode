import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getMambuInterestRate,
  setMambuInterestRate,
  getMambuTotalBalancePence,
  makeMambuDisbursement,
  makeManualRepayment,
  verifyEmailSent,
  setCollectionPlanActive,
  getCollectionPlanStatus,
  cleanup,
} from "./cpaE2eHelpers";

let setup: SetupResult;
let startTimeMs: number;
let originalInterestRate: number | null;
let originalBalancePence: number;

describe("CPA E2E - Balance Paid Cancellation", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Balance-Paid");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 1: Setup - create test clock, customer, subscription", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Balance-Paid",
      30, // billing in 30 days (far enough that it won't fire before we cancel)
      90, // subscription ends in 90 days
    );

    expect(setup.subscription.id).toBeTruthy();
    expect(setup.stripeCustomer.id).toBeTruthy();
    expect(setup.testClock.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();
  });

  test("Phase 2: Verify subscription is active", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
  });

  test("Phase 2: Set Mambu interest rate to 0", async () => {
    originalInterestRate = await getMambuInterestRate();
    log("Phase 2", `Original interest rate: ${originalInterestRate}%`);

    await setMambuInterestRate(0);

    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Verify Email1 (plan confirmation) sent", async () => {
    await waitForCondition(
      () => verifyEmailSent("Email1", startTimeMs),
      "Email1 (plan confirmation) in CloudWatch logs",
      5_000,
      180_000,
    );
  });

  test("Phase 3: Make manual repayment covering full balance", async () => {
    originalBalancePence = await getMambuTotalBalancePence();
    log("Phase 3", `Total Mambu balance: £${(originalBalancePence / 100).toFixed(2)}`);
    expect(originalBalancePence).toBeGreaterThan(0);

    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, originalBalancePence);
    log("Phase 3", `Manual repayment of £${(originalBalancePence / 100).toFixed(2)} submitted`);

  });

  test("Phase 3: Verify subscription cancelled with balance_paid reason", async () => {
    // balance_paid cancellations are excluded from the cancelled window
    // (only payment_failed keeps isInCPA true), so isInCPA should be false immediately
    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 3", `isInCPA: ${status.isInCPA}, cpaCancelled: ${status.cpaCancelled}`);
        return status.isInCPA === false;
      },
      "Subscription to be cancelled (balance_paid)",
      10_000,
      120_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(false);
  });

  test("Phase 3: Verify Email6 (plan completed) sent", async () => {
    await pollUntil(
      () => verifyEmailSent("Email6", startTimeMs),
      "Email6 (plan completed) in CloudWatch logs",
      120_000,
    );
  });

  test("Phase 4: Verify Mambu interest rate restored", async () => {
    if (originalInterestRate === null || originalInterestRate === 0) {
      log("Phase 4", "Original interest rate was 0 or null - skipping restoration check");
      return;
    }

    await pollUntil(async () => {
      const currentRate = await getMambuInterestRate();
      return currentRate === originalInterestRate;
    }, `Interest rate to restore to ${originalInterestRate}%`);

    const finalRate = await getMambuInterestRate();
    expect(finalRate).toBe(originalInterestRate);
  });

  test("Phase 4: Verify Salesforce collection plan expired", async () => {
    await pollUntil(async () => {
      const status = await getCollectionPlanStatus();
      return status === "Expired";
    }, "Salesforce collection plan to be Expired");

    const status = await getCollectionPlanStatus();
    expect(status).toBe("Expired");
  });

  test("Phase 4: Verify Mambu balance is zero", async () => {
    const balance = await getMambuTotalBalancePence();
    expect(balance).toBe(0);
  });

  test("Phase 5: Restore Mambu balance via disbursement", async () => {
    log("Phase 5", `Restoring balance of £${(originalBalancePence / 100).toFixed(2)}...`);
    await makeMambuDisbursement(originalBalancePence);

    const restoredBalance = await getMambuTotalBalancePence();
    log("Phase 5", `Balance restored to £${(restoredBalance / 100).toFixed(2)}`);
    expect(restoredBalance).toBeGreaterThan(0);
  });
});
