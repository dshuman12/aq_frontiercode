import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlerts,
  getMambuInterestRate,
  setMambuInterestRate,
  verifyEmailSent,
  verifyReminderFired,
  verifyReminderAmountInLogs,
  updateSubscriptionAmount,
  setCollectionPlanActive,
  verifyCpaSSMParams,
  getReminderCreatives,
  cleanup,
} from "./cpaE2eHelpers";

let setup: SetupResult;
let startTimeMs: number;
let expectedReminderCreatives: { daysBefore: number; creative: string }[];

const UPDATED_AMOUNT_PENCE = 3500; // £35.00 (changed from £42.69)

describe("CPA E2E - Agent Updates Subscription Amount", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Amount-Update");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 0: Verify CPA SSM parameters", async () => {
    const ssmParams = await verifyCpaSSMParams();
    expectedReminderCreatives = getReminderCreatives(ssmParams.reminderDays);
  });

  test("Phase 1: Setup - create test clock, customer, subscription", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Amount-Update",
      8, // billing in 8 days
      60, // subscription ends in 60 days
    );

    expect(setup.subscription.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();
  });

  test("Phase 2: Verify subscription is active with original amount", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    log("Phase 2", `Original CPA amount: £${status.cpaPaymentAmount}`);
  });

  test("Phase 2: Set Mambu interest rate to 0", async () => {
    await setMambuInterestRate(0);
    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Verify Email1 (plan confirmation) sent", async () => {
    await waitForCondition(
      () => verifyEmailSent("Email1", startTimeMs),
      "Email1 (plan confirmation) in CloudWatch logs",
      5_000,
      180_000,
    );
  });

  test("Phase 3: Agent updates subscription amount", async () => {
    const beforeStatus = await getCpaStatus();
    log("Phase 3", `Amount before update: £${beforeStatus.cpaPaymentAmount}`);

    await updateSubscriptionAmount(setup.subscription.id, UPDATED_AMOUNT_PENCE);

    // Stripe prorates mid-cycle changes, so the amount returned by getCpaStatus
    // (via invoices.createPreview) will differ from the exact new unit price.
    // Verify the amount changed from the original.
    await pollUntil(async () => {
      const status = await getCpaStatus();
      log("Phase 3", `Current amount: £${status.cpaPaymentAmount}`);
      return status.cpaPaymentAmount !== null && status.cpaPaymentAmount !== CONFIG.cpaAmountPence / 100;
    }, "CPA amount to change from original after subscription update");

    const afterStatus = await getCpaStatus();
    expect(afterStatus.cpaPaymentAmount).not.toBe(CONFIG.cpaAmountPence / 100);
    expect(afterStatus.isInCPA).toBe(true);
    expect(afterStatus.cpaStatus).toBe("active");
    log("Phase 3", `Amount changed to £${afterStatus.cpaPaymentAmount} (prorated from £${UPDATED_AMOUNT_PENCE / 100})`);
  });

  test("Phase 3: Verify alert shows updated amount", async () => {
    const status = await getCpaStatus();
    const alerts = await getAlerts(status);

    expect(alerts.message).toBe("Account credit alerts generated successfully");

    const paymentAlert = alerts.alert.find(
      (a) => a.alertType === "Information" && a.title === "Your next payment is coming up",
    );
    expect(paymentAlert).toBeDefined();

    // Alert should show whatever getCpaStatus returned (prorated amount), not the original
    expect(paymentAlert!.message).toContain(`Amount: £${status.cpaPaymentAmount}`);
    expect(paymentAlert!.message).not.toContain(`Amount: £${CONFIG.cpaAmountPence / 100}`);
    log("Phase 3", `Alert shows amount: £${status.cpaPaymentAmount}`);
  });

  test("Phase 4: Verify reminder emails use updated amount", async () => {
    log("Phase 4", `Expecting ${expectedReminderCreatives.length} reminder(s)`);
    for (const { daysBefore, creative } of expectedReminderCreatives) {
      const reminderType = `${daysBefore}d`;
      await pollUntil(
        () => verifyReminderFired(reminderType, startTimeMs),
        `${reminderType} reminder (${creative}) in cpaPaymentReminderProcessor logs`,
        120_000,
      );
      log("Phase 4", `${reminderType} reminder fired`);
    }

    // Verify the reminder processor used the updated subscription amount (not the original).
    // The reminder processor fetches the live subscription amount from Stripe (in pence),
    // so paymentPlanValue in the logs will be the raw unit price (£35.00), not the
    // prorated invoice preview amount that getCpaStatus returns.
    const updatedAmountPounds = UPDATED_AMOUNT_PENCE / 100;
    await pollUntil(
      () => verifyReminderAmountInLogs(updatedAmountPounds, startTimeMs),
      `Reminder logs to contain paymentPlanValue of £${updatedAmountPounds}`,
      120_000,
    );
    log("Phase 4", `Reminder emails sent with updated amount: £${updatedAmountPounds}`);
  });
});
