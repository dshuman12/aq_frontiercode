import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { v4 as uuid } from "uuid";
import { createDirectDebitPayment } from "../src/libs/directDebit";
import { DirectDebitRepaymentDue } from "../src/shared-types/sqs-types";
import { getCustomer } from "../src/utils/db";

async function main() {
  const idempotencyKey = uuid();

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("Core banking client not found");
  }

  const directDebitRepaymentDue = {
    accountId: "MVOX882",
    customerId: "78d7fd7d-af23-432d-a7ea-e672088cd1a5",
    dueDate: "not-needed-for-creating-dd", // put whatever
    idempotencyKey,
  } as DirectDebitRepaymentDue;

  const customer = await getCustomer(directDebitRepaymentDue.customerId);

  if (customer.error || !customer.data) {
    console.error(customer.error);
    throw new Error(`Error getting customer with ID: ${directDebitRepaymentDue.customerId}, ${customer.error}`);
  }

  const creditAccount = await coreBankingClient.getCreditAccount(customer.data.accountId);
  if (!creditAccount.data) {
    throw new Error(`Error getting credit account with ID: ${customer.data.accountId}, ${creditAccount.error}`);
  }

  const res = await createDirectDebitPayment({
    accountData: creditAccount.data,
    customer: customer.data,
    directDebitRepaymentDue,
  });

  console.info(res);
}

main().catch(console.error);
