import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import dayjs from "dayjs";
import path from "path";
import fs from "fs";
import csvParser from "csv-parser";

async function fetchInBatches<T>(
  fromDate: string,
  toDate: string,
  batchSizeDays: number,
  fetchBatch: (from: string, to: string) => Promise<T[]>,
): Promise<T[]> {
  let cursor = dayjs(fromDate);
  const end = dayjs(toDate);
  const allResults: T[] = [];
  let safetyCounter = 0;

  while (cursor.isBefore(end) || cursor.isSame(end, "day")) {
    if (safetyCounter++ > 100) throw new Error("Batch loop stuck");

    const batchStart = cursor;

    const batchEndTimestamp = Math.min(cursor.add(batchSizeDays - 1, "day").valueOf(), end.valueOf());
    const batchEnd = dayjs(batchEndTimestamp);

    const results = await fetchBatch(batchStart.format("YYYY-MM-DD"), batchEnd.format("YYYY-MM-DD"));
    if (results?.length) allResults.push(...results);

    cursor = batchEnd.add(1, "day");
  }

  return allResults;
}

type MandateInfo = {
  mandateId: string;
  stripeCancelEventId: string;
  mandateCancelReason: string;
  date: string;
};

const aggregateInformation = async (accountId: string, mandateId: string, customerId: string) => {
  let info = {
    accountId,
    currentMandateId: mandateId,
    customerId,
    mandateCancelActivities: [] as MandateInfo[],
    manualDDcreationDates: [] as string[],
  };

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!coreBankingClient) {
    throw new Error("No core banking client");
  }

  const toDate = "2025-10-06";
  const fromDate = "2021-01-01";
  const allActivities = await fetchInBatches(fromDate, toDate, 21, async (from, to) => {
    const response = await coreBankingClient.getCustomerActivity({
      customerId: info.customerId,
      fromDate: from,
      toDate: to,
    });
    return response?.data?.activity || [];
  });

  const ddActivities = allActivities
    .filter((a) => a.activity.type === "LOAN_ACCOUNT_EDITED" && a.activity.fieldChanges.length > 0)
    .map((a) => a.activity)
    .flatMap((activity) =>
      activity.fieldChanges
        .filter((fc) => !!fc.fieldDetailName && fc.fieldDetailName.startsWith("Direct Debit"))
        .map((fc) => ({
          fieldDetailName: fc.fieldDetailName,
          originalValue: fc.originalValue,
          newValue: fc.newValue,
          timestamp: activity.timestamp,
        })),
    );
  if (!ddActivities) {
    console.log("No direct debit activities found");
    return;
  }

  const removedPref = ddActivities
    .filter((a) => a.fieldDetailName === "Direct Debit Payment Amount Preference" && !a.newValue)
    .sort((a, b) => dayjs(b.timestamp).valueOf() - dayjs(a.timestamp).valueOf());

  if (!removedPref || removedPref.length === 0) {
    console.error(`No removed amount pref found for account ${accountId}`);
    console.log("All DD activities:", ddActivities);
    return;
  }

  console.log(`Old amount pref for account ${accountId}: ${removedPref[0].originalValue}`);
  const amountPref = removedPref[0].originalValue;

  if (amountPref !== "Minimum Payment" && amountPref !== "Full Statement Balance" && !amountPref.startsWith("Custom")) {
    console.error(`Unexpected amount pref value for account ${accountId}: ${amountPref}`);
    return;
  }

  console.log(`Set amount pref back to orignal value for account ${accountId}: ${amountPref}`);
  const res = await coreBankingClient.updateCreditAccount(accountId, {
    directDebitSettings: { amountPreference: amountPref },
  });
  if (res.error) {
    console.error(`Failed to update amount pref for account ${accountId}:`, res.error);
  }
  console.log(`Successfully updated amount pref for account ${accountId} to ${amountPref}`);
};

interface ExtractedData {
  accountId: string;
  mandateId: string;
  customerId: string;
}

export async function extractInfo(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser({ mapHeaders: ({ header }) => header.replace(/^\uFEFF/, "") }))
      .on("data", (row) => {
        if (row.accountId && row.mandateId && row.customerId) {
          results.push({
            accountId: row.accountId,
            mandateId: row.mandateId,
            customerId: row.customerId,
          });
        }
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
}

async function main() {
  const allData = await extractInfo(path.join(__dirname, "third_pass.csv"));
  console.log(`Extracted ${allData.length} entries from CSV.`);
  for (const entry of allData) {
    await aggregateInformation(entry.accountId, entry.mandateId, entry.customerId);
  }
}

main().catch(console.error);
