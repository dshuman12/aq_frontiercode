import { generateAccessTokenOfTestUser } from "../src/utils/oidcAuthToken";
import { setUpTestCreditCustomerAccount } from "../src/utils/customerAccountUtils";

async function run() {
  console.log(process.argv);
  try {
    const userCreds = await setUpTestCreditCustomerAccount();
    console.log("User credentials:", userCreds);
    const token = await generateAccessTokenOfTestUser(userCreds.customerId);
    console.log("Generated Access Token:", token);
    console.log("IMPORTANT: run the following to clean up:");
    console.log(`npm run delete-test-user '${JSON.stringify(userCreds)}' '${JSON.stringify(token)}'`);
  } catch (error) {
    console.error("Error generating access token:", error);
  }
}

run();
