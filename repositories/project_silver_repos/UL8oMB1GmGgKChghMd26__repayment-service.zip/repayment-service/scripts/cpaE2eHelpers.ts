import "dotenv/config";
import { fromSSO } from "@aws-sdk/credential-provider-sso";

import Stripe from "stripe";
import { v4 as uuid } from "uuid";
import dayjs from "dayjs";
import jwt from "jsonwebtoken";
import { CloudWatchLogsClient, FilterLogEventsCommand } from "@aws-sdk/client-cloudwatch-logs";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import { SchedulerClient, ListSchedulesCommand } from "@aws-sdk/client-scheduler";
import { coreBankingAdapter, salesforceCrmAdapter } from "@onmoapp/onmo-adapters";
import { getItemMethod, updateItemMethod, putItemMethod } from "@onmoapp/onmo-dynamodb";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import fs from "fs";
import path from "path";

// ── Configuration ──────────────────────────────────────────────

export const CONFIG = {
  customerId: "fdeb9be5-09bc-4c25-9ca9-78ed63d3b716",
  accountId: "ZMWB755",
  email: "yihein.chai@onmo.app",
  happyPathCard: "4000056655665556",
  sadPathCard: "4000000000000341",
  cpaAmountPence: 4269, // £42.69
  manualRepaymentPence: 269, // £2.69
  cpaApiUrl: "https://api.staging.onmo.app/service/repayments/next/cpa/subscription",
  region: "eu-west-1",
  userTable: process.env.USER_TABLE || "mobile-staging",
  environment: process.env.ENVIRONMENT || "staging",
  pollIntervalMs: 3_000,
  pollTimeoutMs: 180_000, // 3 min
  cwLogGroup: `/aws/lambda/${process.env.ENVIRONMENT || "staging"}-repayment-service-sendSFMCComms`,
};

// ── Types ──────────────────────────────────────────────────────

export type CPASubscriptionDetails = {
  isInCPA: boolean;
  daysFromCPA: number | null;
  nextCPADueDate: string | null;
  cpaPaymentAmount: number | null;
  cpaStatus: string | null;
  cpaPaymentFailed: boolean;
  cpaAttemptCount: number | null;
  cpaNextRetryDate: string | null;
  cpaCancelled: boolean;
  cpaCancellationReason: string | null;
};

export type SetupResult = {
  stripe: Stripe;
  testClock: Stripe.TestHelpers.TestClock;
  stripeCustomer: Stripe.Customer;
  subscription: Stripe.Subscription;
  paymentMethodId: string;
  originalPspCustomerId: string | null;
  frozenTime: number;
  billingAnchor: number;
  cancelAt: number;
  productId: string;
};

// ── Init (must be called before any AWS API calls) ─────────────

export async function init(): Promise<void> {
  // Resolve SSO credentials and set as env vars so all AWS SDKs/adapters work
  const creds = await fromSSO({ profile: "default" })();
  process.env.AWS_ACCESS_KEY_ID = creds.accessKeyId;
  process.env.AWS_SECRET_ACCESS_KEY = creds.secretAccessKey;
  if (creds.sessionToken) process.env.AWS_SESSION_TOKEN = creds.sessionToken;
  process.env.AWS_REGION = process.env.REGION || "eu-west-1";
  log("Init", "AWS SSO credentials resolved");
}

// ── Logging ────────────────────────────────────────────────────

const LOG_DIR = path.join(__dirname, "cpa-e2e-logs");
let _logFile: string | null = null;

export function setLogFile(label: string): void {
  if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
  const filename = `${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${dayjs().format("YYYY-MM-DD-HHmmss")}.log`;
  _logFile = path.join(LOG_DIR, filename);
  fs.writeFileSync(_logFile, `=== ${label} — ${dayjs().format("YYYY-MM-DD HH:mm:ss")} ===\n`);
}

export function getLogFilePath(): string | null {
  return _logFile;
}

export function log(phase: string, message: string): void {
  const ts = dayjs().format("HH:mm:ss");
  const line = `[${ts}] [${phase}] ${message}`;
  console.log(line);
  if (_logFile) {
    fs.appendFileSync(_logFile, line + "\n");
  }
}

// ── Polling ────────────────────────────────────────────────────

export function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export async function pollUntil(
  condition: () => Promise<boolean>,
  description: string,
  timeoutMs = CONFIG.pollTimeoutMs,
  intervalMs = CONFIG.pollIntervalMs,
): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      if (await condition()) {
        log("Poll", `OK: ${description}`);
        return;
      }
    } catch {
      // condition threw - keep polling
    }
    log("Poll", `Waiting: ${description}...`);
    await sleep(intervalMs);
  }
  throw new Error(`TIMEOUT waiting for: ${description} (${timeoutMs}ms)`);
}

/**
 * Waits a minimum period (for webhook/event propagation), then polls until the condition is met.
 * Faster than a hard sleep() because it checks early and often after the initial wait.
 */
export async function waitForCondition(
  condition: () => Promise<boolean>,
  description: string,
  minWaitMs: number = 5_000,
  timeoutMs: number = CONFIG.pollTimeoutMs,
  intervalMs: number = CONFIG.pollIntervalMs,
): Promise<void> {
  await sleep(minWaitMs);
  return pollUntil(condition, description, timeoutMs - minWaitMs, intervalMs);
}

// ── Stripe Client ──────────────────────────────────────────────

let _stripeClient: Stripe | null = null;

export async function createStripeClient(): Promise<Stripe> {
  if (_stripeClient) return _stripeClient;
  const { SecretString } = await getSecret(`onmo-stripe-${CONFIG.environment}`);
  if (!SecretString) throw new Error("Stripe secret not found in Secrets Manager");
  const { secretKey } = JSON.parse(SecretString);
  _stripeClient = new Stripe(secretKey, { apiVersion: "2025-09-30.clover" as any });
  log("Stripe", "Client initialized");
  return _stripeClient;
}

// ── Test Clock Management ──────────────────────────────────────

export async function cleanupExistingTestClocks(stripe: Stripe): Promise<void> {
  log("Cleanup", `Searching for existing customers with email ${CONFIG.email}...`);
  const customers = await stripe.customers.search({ query: `email:"${CONFIG.email}"` });

  for (const customer of customers.data) {
    if (!customer.test_clock) continue;
    const clockId = typeof customer.test_clock === "string" ? customer.test_clock : customer.test_clock.id;
    log("Cleanup", `Deleting test clock ${clockId} (customer ${customer.id})`);
    try {
      await stripe.testHelpers.testClocks.del(clockId);
    } catch (e: any) {
      log("Cleanup", `Could not delete test clock: ${e.message}`);
    }
  }
}

export async function createTestClock(stripe: Stripe, label: string): Promise<Stripe.TestHelpers.TestClock> {
  const frozenTime = Math.floor(Date.now() / 1000);
  const clock = await stripe.testHelpers.testClocks.create({ frozen_time: frozenTime, name: label });
  log("TestClock", `Created ${clock.id}, frozen at ${dayjs.unix(frozenTime).format("YYYY-MM-DD HH:mm")}`);
  return clock;
}

export async function advanceTestClock(stripe: Stripe, testClockId: string, targetTimestamp: number): Promise<void> {
  log("TestClock", `Advancing to ${dayjs.unix(targetTimestamp).format("YYYY-MM-DD HH:mm")}...`);
  await stripe.testHelpers.testClocks.advance(testClockId, { frozen_time: targetTimestamp });

  // Stripe processes clock advances asynchronously - poll until ready
  await pollUntil(
    async () => {
      const clock = await stripe.testHelpers.testClocks.retrieve(testClockId);
      return clock.status === "ready";
    },
    "Test clock advance to complete",
    300_000, // 5 min - clock advances can be slow
    1_000,
  );
}

// ── Stripe Customer ────────────────────────────────────────────

export async function createTestClockCustomer(stripe: Stripe, testClockId: string): Promise<Stripe.Customer> {
  const customer = await stripe.customers.create({
    email: CONFIG.email,
    test_clock: testClockId,
    metadata: { customerId: CONFIG.customerId, onmouuid: CONFIG.customerId },
  });
  log("Customer", `Created ${customer.id} on test clock ${testClockId}`);
  return customer;
}

// ── Payment Methods ────────────────────────────────────────────

const TEST_TOKEN_MAP: Record<string, string> = {
  "4000056655665556": "tok_visa_debit", // Visa Debit - succeeds
  "4000000000000341": "tok_chargeCustomerFail", // Attaches OK, declines on charge
};

export async function attachCardToCustomer(stripe: Stripe, pspCustomerId: string, cardNumber: string): Promise<string> {
  const testToken = TEST_TOKEN_MAP[cardNumber];
  if (!testToken) throw new Error(`No test token mapping for card ${cardNumber}`);

  const pm = await stripe.paymentMethods.create({ type: "card", card: { token: testToken } });
  await stripe.paymentMethods.attach(pm.id, { customer: pspCustomerId });
  await stripe.customers.update(pspCustomerId, {
    invoice_settings: { default_payment_method: pm.id },
  });

  log("Card", `Attached ${testToken} as ${pm.id}`);
  return pm.id;
}

// ── Stripe Product ─────────────────────────────────────────────

export async function getOrCreateProduct(stripe: Stripe): Promise<string> {
  // Search for existing test product
  const products = await stripe.products.search({ query: 'metadata["usage"]:"cpa-e2e-test"' });
  if (products.data.length > 0) {
    log("Product", `Using existing product ${products.data[0].id}`);
    return products.data[0].id;
  }

  const product = await stripe.products.create({
    name: "CPA E2E Test Subscription",
    metadata: { usage: "cpa-e2e-test" },
  });
  log("Product", `Created product ${product.id}`);
  return product.id;
}

// ── Subscription ───────────────────────────────────────────────

export async function createCpaSubscription(
  stripe: Stripe,
  pspCustomerId: string,
  paymentMethodId: string,
  productId: string,
  billingAnchor: number,
  cancelAt: number,
): Promise<Stripe.Subscription> {
  const subscription = await stripe.subscriptions.create({
    customer: pspCustomerId,
    items: [
      {
        price_data: {
          currency: "gbp",
          product: productId,
          unit_amount: CONFIG.cpaAmountPence,
          recurring: { interval: "month" },
        },
      },
    ],
    default_payment_method: paymentMethodId,
    billing_cycle_anchor: billingAnchor,
    cancel_at: cancelAt,
    metadata: {
      accountId: CONFIG.accountId,
      customerId: CONFIG.customerId,
      accountType: "card",
    },
    proration_behavior: "none",
  });

  log("Subscription", `Created ${subscription.id} (status: ${subscription.status})`);
  log("Subscription", `First billing: ${dayjs.unix(billingAnchor).format("YYYY-MM-DD HH:mm")}`);
  log("Subscription", `Ends at: ${dayjs.unix(cancelAt).format("YYYY-MM-DD HH:mm")}`);
  return subscription;
}

// ── DynamoDB ───────────────────────────────────────────────────

export async function swapPspCustomerId(newPspCustomerId: string): Promise<string | null> {
  const res = (await getItemMethod({
    TableName: CONFIG.userTable,
    Key: { onmouuid: CONFIG.customerId },
  })) as any;

  const original = res?.Item?.pspCustomerId || null;

  await updateItemMethod({
    TableName: CONFIG.userTable,
    Key: { onmouuid: CONFIG.customerId },
    UpdateExpression: "set pspCustomerId = :v",
    ExpressionAttributeValues: { ":v": newPspCustomerId },
  });

  log("DynamoDB", `pspCustomerId: ${original} -> ${newPspCustomerId}`);
  return original;
}

export async function restorePspCustomerId(original: string | null): Promise<void> {
  const value = original || "";
  await updateItemMethod({
    TableName: CONFIG.userTable,
    Key: { onmouuid: CONFIG.customerId },
    UpdateExpression: "set pspCustomerId = :v",
    ExpressionAttributeValues: { ":v": value },
  });
  log("DynamoDB", `Restored pspCustomerId to ${value || "(empty)"}`);
}

// ── Auth Token ─────────────────────────────────────────────────

let _cachedToken: { token: string; expiresAt: number } | null = null;

export async function generateAuthToken(): Promise<string> {
  // Reuse token if it has >5 min remaining
  if (_cachedToken && _cachedToken.expiresAt > Date.now() / 1000 + 300) {
    return _cachedToken.token;
  }

  const environment = CONFIG.environment;
  const { SecretString } = await getSecret(`onmo-auth-signing-keys-${environment}`);
  if (!SecretString) throw new Error("Auth signing keys not found");
  const { priv_signing_key } = JSON.parse(SecretString) as { priv_signing_key?: string };
  if (!priv_signing_key) throw new Error("Missing private signing key");

  const now = Math.floor(Date.now() / 1000);
  const tokenId = uuid();
  const accessToken = jwt.sign(
    {
      iss: `${process.env.TF_VAR_ONMO_AUTH_URL || "auth.staging.onmo.app"}/oidc`,
      sub: CONFIG.customerId,
      aud: process.env.TF_VAR_ONMO_API_URL || "api.staging.onmo.app",
      exp: now + 3600,
      iat: now,
      jti: tokenId,
      env: environment,
      scope: "repayment,credit-card-account",
    },
    priv_signing_key.replace(/\\n/g, "\n"),
    { algorithm: "RS256" },
  );

  const authTable =
    process.env.TF_VAR_AUTH_TOKENS_TABLE || process.env.AUTH_TOKENS_TABLE || `auth-tokens-${environment}`;
  await putItemMethod({
    TableName: authTable,
    Item: {
      token_id: tokenId,
      onmouuid: CONFIG.customerId,
      scope: "repayment,credit-card-account",
      token: accessToken,
      ttl: now + 3600,
    },
  });

  _cachedToken = { token: accessToken, expiresAt: now + 3600 };
  log("Auth", "Generated access token");
  return accessToken;
}

// ── CPA API ────────────────────────────────────────────────────

export async function getCpaStatus(): Promise<CPASubscriptionDetails> {
  const token = await generateAuthToken();
  const response = await fetch(CONFIG.cpaApiUrl, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`CPA API ${response.status}: ${text}`);
  }
  return (await response.json()) as CPASubscriptionDetails;
}

// ── Alerts API ──────────────────────────────────────────────────

export type AlertDetail = {
  alertType: string;
  title: string;
  message: string;
};

export type AlertsResponse = {
  alert: AlertDetail[];
  shouldGetCollectionsComms: boolean;
  message: string;
};

export async function getAlerts(cpaStatus: CPASubscriptionDetails): Promise<AlertsResponse> {
  const token = await generateAuthToken();
  const alertsUrl = "https://api.staging.onmo.app/service/alerts/next/account-credit-alerts";

  // Build the payload matching what the app sends from Dashboard
  const payload = {
    isInArrears: false,
    directDebitAmountPref: null,
    daysFromDueDate: 9, // not near DD due date
    inArrearsDays: 0,
    nextStatementDueDate: dayjs().add(20, "day").format("YYYY-MM-DD"),
    totalNextMinimumPaymentDue: 0,
    arrearsBalanceTotal: 0,
    availableCredit: 100,
    cardStatus: "ACTIVE",
    nextDirectDebitAmount: null,
    previousPeriodBalance: 0,
    directDebitRetryInProgress: false,
    directDebitRetryAmount: null,
    directDebitRetryDate: null,
    directDebitAvoidFeeCutOffDate: null,
    // CPA fields from subscription status
    isInCPA: cpaStatus.isInCPA,
    daysFromCPA: cpaStatus.daysFromCPA,
    nextCPADueDate: cpaStatus.nextCPADueDate,
    cpaPaymentAmount: cpaStatus.cpaPaymentAmount,
    cpaPaymentFailed: cpaStatus.cpaPaymentFailed,
    cpaAttemptCount: cpaStatus.cpaAttemptCount,
    cpaNextRetryDate: cpaStatus.cpaNextRetryDate,
    cpaCancelled: cpaStatus.cpaCancelled,
    cpaCancellationReason: cpaStatus.cpaCancellationReason,
  };

  const response = await fetch(alertsUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Alerts API ${response.status}: ${text}`);
  }

  const result = (await response.json()) as AlertsResponse;
  log("Alerts", `Got ${result.alert.length} alert(s)`);
  console.log(result);

  for (const a of result.alert) {
    log("Alerts", `  [${a.alertType}] ${a.title}: ${a.message}`);
  }
  return result;
}

// ── Manual Repayment ───────────────────────────────────────────

export async function makeManualRepayment(stripe: Stripe, pspCustomerId: string, amountPence: number): Promise<string> {
  log("Repayment", `Creating payment for £${(amountPence / 100).toFixed(2)}...`);

  const customer = (await stripe.customers.retrieve(pspCustomerId)) as Stripe.Customer;
  const defaultPm = customer.invoice_settings?.default_payment_method;
  if (!defaultPm) throw new Error("No default payment method on customer");
  const pmId = typeof defaultPm === "string" ? defaultPm : defaultPm.id;

  const pi = await stripe.paymentIntents.create({
    customer: pspCustomerId,
    amount: amountPence,
    currency: "gbp",
    payment_method: pmId,
    metadata: {
      customerId: CONFIG.customerId,
      accountId: CONFIG.accountId,
      accountType: "card",
      repaymentType: "CARD",
      idempotencyKey: uuid(),
    },
    confirm: true,
    off_session: true,
  });

  if (pi.status !== "succeeded") {
    throw new Error(`PaymentIntent ${pi.id} status: ${pi.status} (expected succeeded)`);
  }

  log("Repayment", `PaymentIntent ${pi.id} succeeded`);
  return pi.id;
}

// ── Mambu Interest Rate ────────────────────────────────────────

export async function getMambuInterestRate(): Promise<number | null> {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!bankingClient) throw new Error("Failed to initialize Mambu client");
  const { data, error } = await bankingClient.getCreditAccount(CONFIG.accountId);
  if (error || !data) throw new Error(`Failed to get credit account: ${JSON.stringify(error)}`);
  const rate = data.accountDetails?.interestRate ?? null;
  log("Mambu", `Current interest rate: ${rate}%`);
  return rate;
}

export async function getMambuTotalBalancePence(): Promise<number> {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!bankingClient) throw new Error("Failed to initialize Mambu client");
  const { data, error } = await bankingClient.getCreditAccount(CONFIG.accountId);
  if (error || !data) throw new Error(`Failed to get credit account: ${JSON.stringify(error)}`);
  const balances = data.accountBalances.balances;
  const totalPence = Math.round((balances.fees + balances.interest + balances.principal) * 100);
  log("Mambu", `Total balance: £${(totalPence / 100).toFixed(2)} (${totalPence} pence)`);
  return totalPence;
}

export async function makeMambuDisbursement(amountPence: number): Promise<void> {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!bankingClient) throw new Error("Failed to initialize Mambu client");
  const amountPounds = Number((amountPence / 100).toFixed(2));
  const valueDate = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
  const { error } = await bankingClient.makeDisbursementToCreditAccount(CONFIG.accountId, {
    amount: amountPounds,
    valueDate,
    bookingDate: valueDate,
    externalId: uuid(),
    notes: "CPA E2E test - restoring balance",
    transactionChannelId: "cash",
  });
  if (error) throw new Error(`Failed to make disbursement: ${JSON.stringify(error)}`);
  log("Mambu", `Disbursement of £${amountPounds} made to restore balance`);
}

export async function setMambuInterestRate(rate: number): Promise<void> {
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!bankingClient) throw new Error("Failed to initialize Mambu client");
  const valueDate = dayjs().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
  const { error } = await bankingClient.updateInterestRateToCreditAccount(CONFIG.accountId, {
    interestRate: rate,
    valueDate,
    notes: `CPA E2E test - setting interest rate to ${rate}`,
  });
  if (error) throw new Error(`Failed to set interest rate: ${JSON.stringify(error)}`);
  log("Mambu", `Interest rate set to ${rate}%`);
}

// ── Email Verification (CloudWatch Logs) ───────────────────────

const cwClient = new CloudWatchLogsClient({ region: CONFIG.region });

export async function verifyEmailSent(creative: string, afterTimestampMs: number): Promise<boolean> {
  try {
    const response = await cwClient.send(
      new FilterLogEventsCommand({
        logGroupName: CONFIG.cwLogGroup,
        startTime: afterTimestampMs,
        filterPattern: `"${creative}" "${CONFIG.customerId}"`,
      }),
    );
    return (response.events?.length ?? 0) > 0;
  } catch (e: any) {
    log("CloudWatch", `Error querying logs: ${e.message}`);
    return false;
  }
}

export async function verifyReminderFired(reminderType: string, afterTimestampMs: number): Promise<boolean> {
  const logGroup = `/aws/lambda/${CONFIG.environment}-repayment-service-cpaPaymentReminderProcessor`;
  try {
    const response = await cwClient.send(
      new FilterLogEventsCommand({
        logGroupName: logGroup,
        startTime: afterTimestampMs,
        filterPattern: `"reminderType" "${reminderType}" "${CONFIG.customerId}"`,
      }),
    );
    return (response.events?.length ?? 0) > 0;
  } catch (e: any) {
    log("CloudWatch", `Error querying reminder logs: ${e.message}`);
    return false;
  }
}

export async function verifyReminderAmountInLogs(expectedAmountPounds: number, afterTimestampMs: number): Promise<boolean> {
  const logGroup = `/aws/lambda/${CONFIG.environment}-repayment-service-cpaPaymentReminderProcessor`;
  try {
    const response = await cwClient.send(
      new FilterLogEventsCommand({
        logGroupName: logGroup,
        startTime: afterTimestampMs,
        filterPattern: `"paymentPlanValue" "${CONFIG.customerId}"`,
      }),
    );
    if (!response.events?.length) return false;
    // Check if any log entry contains the expected amount
    return response.events.some((e) => e.message?.includes(`"paymentPlanValue":${expectedAmountPounds}`) || e.message?.includes(`"paymentPlanValue": ${expectedAmountPounds}`));
  } catch (e: any) {
    log("CloudWatch", `Error querying reminder amount logs: ${e.message}`);
    return false;
  }
}

export async function updateSubscriptionAmount(subscriptionId: string, newAmountPence: number): Promise<void> {
  const repaymentClient = await CoreRepaymentsFactory.build("stripe");
  if (!repaymentClient) throw new Error("Failed to initialize repayment client");
  const result = await repaymentClient.updateSubscription({ subscriptionId, amount: newAmountPence });
  if (result.error) throw new Error(`Failed to update subscription amount: ${result.error.errorMessage}`);
  log("Stripe", `Subscription ${subscriptionId} amount updated to ${newAmountPence} pence (£${(newAmountPence / 100).toFixed(2)})`);
}

// ── Salesforce Collection Plan ────────────────────────────────

async function getSalesforceClient() {
  const client = await salesforceCrmAdapter("SALESFORCE_CLIENT");
  if (!client) throw new Error("Failed to initialize Salesforce client");
  return client;
}

async function getCollectionPlans(): Promise<Array<{ Id: string; Type__c: string; Status__c: string }>> {
  const client = await getSalesforceClient();
  const query = `?q=${[
    "SELECT+Id,+Type__c,+Status__c",
    "+FROM+Collections_Plan__c",
    `+WHERE+(Financial_Account__c+IN+(SELECT+Id+FROM+Financial_Account__c+WHERE+customerId__c='${CONFIG.customerId}'))`,
    "+LIMIT+200",
  ].join("")}`;

  const response = await client._axios.get(`/data/v61.0/query/${query}`);
  return response.data.records;
}

export async function setCollectionPlanActive(): Promise<string> {
  const plans = await getCollectionPlans();
  if (plans.length === 0) throw new Error("No collection plans found for test customer");

  const plan = plans[0];
  const client = await getSalesforceClient();

  if (plan.Status__c !== "Active") {
    await client._axios.patch(`/data/v61.0/sobjects/Collections_Plan__c/${plan.Id}`, {
      Status__c: "Active",
    });
    log("Salesforce", `Set collection plan ${plan.Id} to Active`);
  } else {
    log("Salesforce", `Collection plan ${plan.Id} already Active`);
  }

  return plan.Id;
}

export async function getCollectionPlanStatus(): Promise<string> {
  const plans = await getCollectionPlans();
  if (plans.length === 0) throw new Error("No collection plans found for test customer");
  log("Salesforce", `Collection plan ${plans[0].Id} status: ${plans[0].Status__c}`);
  return plans[0].Status__c;
}

// ── SSM Parameter Verification ─────────────────────────────────

const ssmClient = new SSMClient({ region: CONFIG.region });

export async function getSSMParam(name: string): Promise<string> {
  const response = await ssmClient.send(
    new GetParameterCommand({ Name: name, WithDecryption: true }),
  );
  if (!response.Parameter?.Value) throw new Error(`SSM parameter ${name} not found or empty`);
  return response.Parameter.Value;
}

export type CpaSSMParams = {
  reminderDays: number[];
  cancelledWindowDays: number;
};

/**
 * Maps reminder days to email creatives using the same logic as cpaPaymentReminderProcessor:
 * - 1 day before → Email3 (payment tomorrow)
 * - everything else → Email2 (payment upcoming)
 */
export function getReminderCreatives(reminderDays: number[]): { daysBefore: number; creative: string }[] {
  return reminderDays.map((daysBefore) => ({
    daysBefore,
    creative: daysBefore === 1 ? "Email3" : "Email2",
  }));
}

export async function verifyCpaSSMParams(): Promise<CpaSSMParams> {
  const env = CONFIG.environment;

  const reminderDaysRaw = await getSSMParam(`/repayment-service/cpa-reminder-days-${env}`);
  const reminderDays = JSON.parse(reminderDaysRaw) as number[];
  log("SSM", `CPA reminder days: ${JSON.stringify(reminderDays)}`);

  const cancelledWindowRaw = await getSSMParam(`/repayment-service/cpa-cancelled-window-days-${env}`);
  const cancelledWindowDays = parseInt(cancelledWindowRaw, 10);
  log("SSM", `CPA cancelled window days: ${cancelledWindowDays}`);

  return { reminderDays, cancelledWindowDays };
}

// ── Scheduler Verification ─────────────────────────────────────

const schedulerClient = new SchedulerClient({ region: CONFIG.region });
const CPA_REMINDER_SCHEDULE_GROUP = `${CONFIG.environment}-cpa-payment-reminders`;

export async function listCpaReminderSchedules(accountId: string): Promise<string[]> {
  const response = await schedulerClient.send(
    new ListSchedulesCommand({
      GroupName: CPA_REMINDER_SCHEDULE_GROUP,
      NamePrefix: `cpa-reminder`,
      MaxResults: 100,
    }),
  );
  // Filter to only schedules for this accountId (name format: cpa-reminder-{N}d-{accountId}-{date})
  const names = (response.Schedules ?? [])
    .map((s) => s.Name!)
    .filter((name) => name.includes(accountId));
  log("Scheduler", `Found ${names.length} CPA reminder schedule(s) for ${accountId}: ${names.join(", ") || "(none)"}`);
  return names;
}

// ── Payment Method Switching ──────────────────────────────────

export async function switchSubscriptionPaymentMethod(
  stripe: Stripe,
  subscriptionId: string,
  pspCustomerId: string,
  newCardNumber: string,
): Promise<string> {
  const newPmId = await attachCardToCustomer(stripe, pspCustomerId, newCardNumber);
  await stripe.subscriptions.update(subscriptionId, {
    default_payment_method: newPmId,
  });
  log("Card", `Switched subscription ${subscriptionId} payment method to ${newPmId}`);
  return newPmId;
}

export async function detachPaymentMethod(stripe: Stripe, paymentMethodId: string): Promise<void> {
  await stripe.paymentMethods.detach(paymentMethodId);
  log("Card", `Detached payment method ${paymentMethodId}`);
}

// ── Subscription Without Metadata ─────────────────────────────

export async function createSubscriptionWithoutMetadata(
  stripe: Stripe,
  pspCustomerId: string,
  paymentMethodId: string,
  productId: string,
  billingAnchor: number,
  cancelAt: number,
): Promise<Stripe.Subscription> {
  const subscription = await stripe.subscriptions.create({
    customer: pspCustomerId,
    items: [
      {
        price_data: {
          currency: "gbp",
          product: productId,
          unit_amount: CONFIG.cpaAmountPence,
          recurring: { interval: "month" },
        },
      },
    ],
    default_payment_method: paymentMethodId,
    billing_cycle_anchor: billingAnchor,
    cancel_at: cancelAt,
    // No metadata — intentionally omitted
    proration_behavior: "none",
  });

  log("Subscription", `Created ${subscription.id} WITHOUT metadata (status: ${subscription.status})`);
  return subscription;
}

// ── Webhook Error Verification ────────────────────────────────

export async function verifyWebhookError(filterPattern: string, afterTimestampMs: number): Promise<boolean> {
  const logGroup = `/aws/lambda/${CONFIG.environment}-repayment-service-webhookHandler`;
  try {
    const response = await cwClient.send(
      new FilterLogEventsCommand({
        logGroupName: logGroup,
        startTime: afterTimestampMs,
        filterPattern,
      }),
    );
    return (response.events?.length ?? 0) > 0;
  } catch (e: any) {
    log("CloudWatch", `Error querying webhook logs: ${e.message}`);
    return false;
  }
}

// ── Extended Alerts ───────────────────────────────────────────

export type AlertPayloadOverrides = Partial<{
  isInArrears: boolean;
  directDebitAmountPref: string | number | null;
  daysFromDueDate: number;
  inArrearsDays: number;
  nextStatementDueDate: string;
  totalNextMinimumPaymentDue: number;
  arrearsBalanceTotal: number;
  availableCredit: number;
  cardStatus: string;
  nextDirectDebitAmount: number | null;
  previousPeriodBalance: number;
  directDebitRetryInProgress: boolean;
  directDebitRetryAmount: number | null;
  directDebitRetryDate: string | null;
  directDebitAvoidFeeCutOffDate: string | null;
}>;

export async function getAlertsWithOverrides(
  cpaStatus: CPASubscriptionDetails,
  overrides: AlertPayloadOverrides = {},
): Promise<AlertsResponse> {
  const token = await generateAuthToken();
  const alertsUrl = "https://api.staging.onmo.app/service/alerts/next/account-credit-alerts";

  const payload = {
    isInArrears: false,
    directDebitAmountPref: null,
    daysFromDueDate: 9,
    inArrearsDays: 0,
    nextStatementDueDate: dayjs().add(20, "day").format("YYYY-MM-DD"),
    totalNextMinimumPaymentDue: 0,
    arrearsBalanceTotal: 0,
    availableCredit: 100,
    cardStatus: "ACTIVE",
    nextDirectDebitAmount: null,
    previousPeriodBalance: 0,
    directDebitRetryInProgress: false,
    directDebitRetryAmount: null,
    directDebitRetryDate: null,
    directDebitAvoidFeeCutOffDate: null,
    // CPA fields
    isInCPA: cpaStatus.isInCPA,
    daysFromCPA: cpaStatus.daysFromCPA,
    nextCPADueDate: cpaStatus.nextCPADueDate,
    cpaPaymentAmount: cpaStatus.cpaPaymentAmount,
    cpaPaymentFailed: cpaStatus.cpaPaymentFailed,
    cpaAttemptCount: cpaStatus.cpaAttemptCount,
    cpaNextRetryDate: cpaStatus.cpaNextRetryDate,
    cpaCancelled: cpaStatus.cpaCancelled,
    cpaCancellationReason: cpaStatus.cpaCancellationReason,
    // Apply overrides
    ...overrides,
  };

  const response = await fetch(alertsUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Alerts API ${response.status}: ${text}`);
  }

  const result = (await response.json()) as AlertsResponse;
  log("Alerts", `Got ${result.alert.length} alert(s)`);
  for (const a of result.alert) {
    log("Alerts", `  [${a.alertType}] ${a.title}: ${a.message}`);
  }
  return result;
}

// ── Full Setup ─────────────────────────────────────────────────

export async function setupCpaTest(
  cardNumber: string,
  label: string,
  billingDaysFromNow: number,
  cancelDaysFromNow: number,
): Promise<SetupResult> {
  const stripe = await createStripeClient();

  // Clean up leftover test clocks from previous runs
  await cleanupExistingTestClocks(stripe);

  const testClock = await createTestClock(stripe, label);
  const frozenTime = testClock.frozen_time;

  const stripeCustomer = await createTestClockCustomer(stripe, testClock.id);
  const originalPspCustomerId = await swapPspCustomerId(stripeCustomer.id);
  const paymentMethodId = await attachCardToCustomer(stripe, stripeCustomer.id, cardNumber);
  const productId = await getOrCreateProduct(stripe);

  const billingAnchor = frozenTime + billingDaysFromNow * 24 * 60 * 60;
  const cancelAt = frozenTime + cancelDaysFromNow * 24 * 60 * 60;

  const subscription = await createCpaSubscription(
    stripe,
    stripeCustomer.id,
    paymentMethodId,
    productId,
    billingAnchor,
    cancelAt,
  );

  console.log("SUBSCRIPTION DETAILS:", subscription);

  return {
    stripe,
    testClock,
    stripeCustomer,
    subscription,
    paymentMethodId,
    originalPspCustomerId,
    frozenTime,
    billingAnchor,
    cancelAt,
    productId,
  };
}

// ── Cleanup ────────────────────────────────────────────────────

export async function cleanup(
  stripe: Stripe,
  testClockId: string,
  originalPspCustomerId: string | null,
): Promise<void> {
  log("Cleanup", "Starting...");

  // Deleting test clock auto-deletes attached customer + subscriptions
  try {
    await stripe.testHelpers.testClocks.del(testClockId);
    log("Cleanup", `Deleted test clock ${testClockId}`);
  } catch (e: any) {
    log("Cleanup", `Error deleting test clock: ${e.message}`);
  }

  await restorePspCustomerId(originalPspCustomerId);
  log("Cleanup", "Done");
}
