import { readFile, writeFile } from "fs/promises";
import path from "path";
import fs from "fs";
import { coreBankingAdapter, MambuClient } from "@onmoapp/onmo-adapters";
import csvParser from "csv-parser";
import dayjs from "dayjs";

export const BATCH_SIZE = 100;
export const SLEEP_DURATION = 1000;

export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export function removeMetadata(data: any[]): any[] {
  return data.map((item) => {
    const { metaData, ...cleanedItem } = item;
    return cleanedItem;
  });
}

export async function saveJsonLocally(filePath: string, data: any) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await writeFile(filePath, jsonData, "utf-8");
    console.log(`✅ JSON saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving JSON locally:`, error);
  }
}

const SUCCESS_FILE = path.join(__dirname, `success.json`);

export async function readSuccessEvents(): Promise<any[]> {
  try {
    const fileContent = await readFile(SUCCESS_FILE, "utf-8");
    const failedData = JSON.parse(fileContent);
    console.log(`✅ Loaded ${failedData.length} success events.`);
    return failedData.map((item) => item.jsonObject);
  } catch (error) {
    console.error(`❌ Failed to read ${SUCCESS_FILE}:`, error);
    return [];
  }
}

interface ExtractedData {
  accountId: string;
  collectionday: string;
  customerId: string;
}

async function extractInfo(filePath: string): Promise<ExtractedData[]> {
  return new Promise((resolve, reject) => {
    const results: ExtractedData[] = [];

    fs.createReadStream(path.resolve(filePath))
      .pipe(csvParser())
      .on("data", (row) => {
        if (row.accountId && row.collectionday && row.customerId) {
          results.push({
            accountId: row.accountId,
            collectionday: row.collectionday,
            customerId: row.customerId,
          });
        }
      })
      .on("end", () => {
        resolve(results);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
}

async function callMambuWebhook(
  bankingClient: MambuClient,
  data: ExtractedData,
  successArray: any[],
  failureArray: any[],
) {
  try {
    const { data: res, error } = await bankingClient.getCreditAccount(data.accountId);

    if (error || !res) {
      failureArray.push({ accountId: data.accountId });
      console.error("Error fetching account details");
      return;
    }

    const paymentDate = res.accountDetails.nextStatementDueDate;
    const payment_date = dayjs(paymentDate).format("YYYY-MM-DD");
    const payload = {
      payment_date,
      loan_account_id: data.accountId,
      onmouuid: data.customerId,
    };

    const response = await fetch(
      "https://api.onmo.app/service/repayments/v1/direct-debit/repayment-due?onmokey=bb36a119-768f-4e40-bebd-0ae6c6a76932",
      {
        method: "POST",
        body: JSON.stringify(payload),
        headers: {
          "Content-Type": "application/json",
        },
      },
    );

    if (response.status !== 200) {
      console.error(response);
      failureArray.push({
        accountId: data.accountId,
        collectionday: data.collectionday,
        payment_date,
        customerId: data.customerId,
      });
      return;
    }

    successArray.push({
      accountId: data.accountId,
      collectionday: data.collectionday,
      payment_date,
      customerId: data.customerId,
    });
  } catch (err) {
    console.error(`❌ Error retrying transaction:`, err);
  }
}

async function saveCsvLocally(filePath: string, data: any[]) {
  try {
    if (data.length === 0) {
      console.log(`⚠️ No data to save in CSV.`);
      return;
    }

    const csvHeader = "accountId,collectionday,payment_date,customerId\n";
    const csvRows = data
      .map((item) => {
        const accountId = item.accountId || "";
        const collectionday = item.collectionday || "";
        const payment_date = item.payment_date || "";
        const customerId = item.customerId || "";
        return `${accountId},${collectionday},${payment_date},${customerId}`;
      })
      .join("\n");

    const csvContent = csvHeader + csvRows;
    await writeFile(filePath, csvContent, "utf-8");
    console.log(`✅ CSV saved locally at: ${filePath}`);
  } catch (error) {
    console.error(`❌ Error saving CSV locally:`, error);
  }
}

/**
 * Call the Mambu webhook for all accountIds in the provided CSV file
 */
async function main() {
  // Read failed events from failure.json
  let allJsonData = await extractInfo(path.join(__dirname, "dd_migration_too_late.csv"));

  if (allJsonData.length === 0) {
    console.log(`🚫 No accounts.`);
    return;
  }

  const successArray: any[] = [];
  const failureArray: any[] = [];

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  if (!bankingClient) {
    console.error("No client found");
    return;
  }

  console.log(`🔍 Checking ${allJsonData.length} transactions...`);

  for (let i = 0; i < allJsonData.length; i += BATCH_SIZE) {
    const batch = allJsonData.slice(i, i + BATCH_SIZE);
    console.log(`🚀 Processing batch ${i / BATCH_SIZE + 1} (${batch.length} items)...`);

    await Promise.allSettled(batch.map((obj) => callMambuWebhook(bankingClient, obj, successArray, failureArray)));

    console.log(
      `✅ Batch ${i / BATCH_SIZE + 1} complete. Success: ${successArray.length}, Failures: ${failureArray.length}`,
    );

    if (i + BATCH_SIZE < allJsonData.length) {
      console.log(`⏳ Sleeping for ${SLEEP_DURATION / 1000} seconds to avoid throttling...`);
      await sleep(SLEEP_DURATION);
    }
  }

  console.log(`✅ Done: ${successArray.length} ${new Date().toISOString()}`);

  // Save new success and failure results
  await saveJsonLocally(path.join(__dirname, `migrationFail.json`), failureArray);

  await saveCsvLocally(path.join(__dirname, "migrationOk.csv"), successArray);
  await saveCsvLocally(path.join(__dirname, "migrationOk.csv"), failureArray);
}

main().catch(console.error);
