import { describe, test, expect, beforeAll, afterAll } from "vitest";
import {
  CONFIG,
  SetupResult,
  init,
  log,
  setLogFile,
  pollUntil,
  waitForCondition,
  setupCpaTest,
  getCpaStatus,
  getAlerts,
  getMambuInterestRate,
  setMambuInterestRate,
  getMambuTotalBalancePence,
  makeManualRepayment,
  advanceTestClock,
  verifyEmailSent,
  setCollectionPlanActive,
  cleanup,
} from "./cpaE2eHelpers";

/**
 * CPA E2E - Manual Payment Independence
 *
 * QA Scenarios: 5, 6, 14, 21, 22, 23, 26
 * - Manual repayments do NOT count toward CPA scheduled payments
 * - CPA amount remains unchanged after manual payments
 * - Scheduled CPA payment still triggers after manual payments
 * - Multiple manual payments do not replace CPA
 * - No double counting between manual and scheduled payments
 */

let setup: SetupResult;
let startTimeMs: number;
let balanceBeforeManualPayments: number;
let balanceAfterManualPayments: number;

describe("CPA E2E - Manual Payment Independence", { timeout: 900_000 }, () => {
  beforeAll(async () => {
    setLogFile("CPA-E2E-Manual-Payment-Independence");
    startTimeMs = Date.now();
    await init();
  });

  afterAll(async () => {
    if (setup) {
      await cleanup(setup.stripe, setup.testClock.id, setup.originalPspCustomerId);
    }
  });

  test("Phase 1: Setup - create subscription with good card", async () => {
    setup = await setupCpaTest(
      CONFIG.happyPathCard,
      "CPA-E2E-Manual-Payment-Independence",
      15, // billing in 15 days — enough time for multiple manual payments
      90, // subscription ends in 90 days
    );

    expect(setup.subscription.id).toBeTruthy();
  });

  test("Phase 1: Set Salesforce collection plan to Active", async () => {
    const planId = await setCollectionPlanActive();
    expect(planId).toBeTruthy();
  });

  test("Phase 2: Verify subscription is active", async () => {
    await pollUntil(async () => {
      const status = await getCpaStatus();
      return status.isInCPA && status.cpaStatus === "active";
    }, "CPA subscription to appear as active");

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
  });

  test("Phase 2: Set Mambu interest rate to 0", async () => {
    await setMambuInterestRate(0);
    const currentRate = await getMambuInterestRate();
    expect(currentRate).toBe(0);
  });

  test("Phase 2: Record balance before manual payments", async () => {
    balanceBeforeManualPayments = await getMambuTotalBalancePence();
    log("Phase 2", `Balance before manual payments: £${(balanceBeforeManualPayments / 100).toFixed(2)}`);
    expect(balanceBeforeManualPayments).toBeGreaterThan(0);
  });

  // ── Scenario 5/21: Small manual repayment does not affect CPA ──

  test("Phase 3: Make small manual repayment (£2.69)", async () => {
    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, CONFIG.manualRepaymentPence);

    await waitForCondition(
      async () => {
        const s = await getCpaStatus();
        return s.isInCPA && s.cpaStatus === "active" && s.cpaPaymentAmount === CONFIG.cpaAmountPence / 100;
      },
      "CPA unchanged after small manual repayment",
      5_000,
      60_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    expect(status.cpaPaymentFailed).toBe(false);
    log("Phase 3", `CPA amount unchanged at £${status.cpaPaymentAmount} after small manual repayment`);
  });

  // ── Scenario 6: Large partial payment does not satisfy CPA ──

  test("Phase 3: Make large partial payment (£50.00)", async () => {
    const largePartialPence = 5000; // £50.00
    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, largePartialPence);

    await waitForCondition(
      async () => {
        const s = await getCpaStatus();
        return s.isInCPA && s.cpaStatus === "active" && s.cpaPaymentAmount === CONFIG.cpaAmountPence / 100;
      },
      "CPA unchanged after large partial payment",
      5_000,
      60_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    log("Phase 3", `CPA still active at £${status.cpaPaymentAmount} after large partial payment`);
  });

  // ── Scenario 14: Multiple manual payments do not replace CPA ──

  test("Phase 3: Make another manual repayment (£10.00)", async () => {
    const anotherRepaymentPence = 1000; // £10.00
    await makeManualRepayment(setup.stripe, setup.stripeCustomer.id, anotherRepaymentPence);

    await waitForCondition(
      async () => {
        const s = await getCpaStatus();
        return s.isInCPA && s.cpaStatus === "active" && s.cpaPaymentAmount === CONFIG.cpaAmountPence / 100;
      },
      "CPA unchanged after third manual repayment",
      5_000,
      60_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentAmount).toBe(CONFIG.cpaAmountPence / 100);
    log("Phase 3", "CPA still active after 3 manual payments — manual payments do not replace CPA");
  });

  test("Phase 3: Verify balance reduced by manual payments", async () => {
    balanceAfterManualPayments = await getMambuTotalBalancePence();
    const totalManualPence = CONFIG.manualRepaymentPence + 5000 + 1000; // £2.69 + £50 + £10

    log("Phase 3", `Balance after manual payments: £${(balanceAfterManualPayments / 100).toFixed(2)}`);
    log("Phase 3", `Total manual payments: £${(totalManualPence / 100).toFixed(2)}`);

    // Balance should have decreased (but not necessarily by exact amount due to rounding/fees)
    expect(balanceAfterManualPayments).toBeLessThan(balanceBeforeManualPayments);
  });

  // ── Scenario 22: Overpayment before due date — CPA unaffected ──

  test("Phase 3: Verify alerts API responds while CPA is still active after manual payments", async () => {
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");

    const alerts = await getAlerts(status);
    expect(alerts.message).toBe("Account credit alerts generated successfully");
    log("Phase 3", `Got ${alerts.alert.length} alert(s) — CPA still active after manual payments`);
  });

  // ── Scenario 23/26: Scheduled payment still triggers, no double counting ──

  test("Phase 4: Advance to billing - CPA payment triggers despite manual payments", async () => {
    const pastBilling = setup.billingAnchor + 2 * 60 * 60;
    await advanceTestClock(setup.stripe, setup.testClock.id, pastBilling);

    await waitForCondition(
      async () => {
        const status = await getCpaStatus();
        log("Phase 4", `cpaStatus: ${status.cpaStatus}, failed: ${status.cpaPaymentFailed}`);
        return status.isInCPA && status.cpaStatus === "active" && !status.cpaPaymentFailed;
      },
      "Scheduled CPA payment to succeed",
      10_000,
      120_000,
    );

    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.cpaPaymentFailed).toBe(false);
    log("Phase 4", "Scheduled CPA payment succeeded — manual payments did not prevent it");
  });

  test("Phase 4: Verify balance reduced by both manual and CPA payments", async () => {
    const balanceAfterCPA = await getMambuTotalBalancePence();
    log("Phase 4", `Balance after CPA payment: £${(balanceAfterCPA / 100).toFixed(2)}`);

    // Balance should be less than after manual payments (CPA payment further reduced it)
    expect(balanceAfterCPA).toBeLessThan(balanceAfterManualPayments);
    log("Phase 4", "Both manual and CPA payments correctly reduced balance — no double counting");
  });

  test("Phase 4: Verify subscription still active with correct amount for next cycle", async () => {
    const status = await getCpaStatus();
    expect(status.isInCPA).toBe(true);
    expect(status.cpaStatus).toBe("active");
    expect(status.nextCPADueDate).toBeTruthy();
    log("Phase 4", `Next CPA payment due: ${status.nextCPADueDate}, amount: £${status.cpaPaymentAmount}`);
  });
});
