import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { getSecret } from "@onmoapp/onmo-secrets-manager";

const env = process.env.ENVIRONMENT;
const internal_api_domain = process.env.TF_VAR_INTERNAL_API_DOMAIN_NAME as string;
const api_test_secret = process.env.API_TEST_SECRET_VALUE as string;

export const fetchAPISecret = async () => {
  let secret: any;
  try {
    secret = await getSecret("onmo-service-layer-" + env);
  } catch (e) {
    console.log("ERROR", e);
  }
  const SecretString = secret?.SecretString;
  if (!SecretString) {
    throw new OnmoError({
      name: ErrorNamesEnum.GET_SECRET_VALUE_ERROR,
      message: "API secret not found",
    });
  }
  const apiSecret = JSON.parse(SecretString);
  return apiSecret?.apiKey;
};

export const invokeFullLock = async (accountId: string, apiKeyValue: string, includeApiKey: boolean = true) => {
  const payment_plan_url = `https://${internal_api_domain}/service/accounts/next/credit/${accountId}/full-lock`;
  return await fetch(payment_plan_url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(includeApiKey ? { "x-api-key": apiKeyValue } : {}),
      "x-api-test-secret": api_test_secret,
    },
  });
};
