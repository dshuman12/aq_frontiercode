import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { formatErrorMessage } from "./errorUtil";

export const pspCustomerHasPendingMandate = async (
  pspCustomerId: string,
): Promise<{ data?: { hasPendingMandate: boolean }; error?: { message: string } }> => {
  const env = process.env.ENVIRONMENT;
  const logger = new Logger({ env });
  logger.addContext({ functionName: "pspCustomerHasPendingMandate" });

  if (!pspCustomerId) {
    // Customer does not exist so it has no pending mandates
    return { data: { hasPendingMandate: false } };
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  if (!repaymentClient) {
    logger.error("No repayment client found for STRIPE_CLIENT");
    return { error: { message: "An error occurred" } };
  }

  try {
    const mandates = await repaymentClient.getCustomerMandateStatus(pspCustomerId);
    const pendingMandates = mandates.filter((mandate) => mandate.status === "pending");
    const activeMandates = mandates.filter((mandate) => mandate.status === "active");

    const hasPendingMandate = env === "staging" ? activeMandates.length > 1 : pendingMandates.length > 0;

    if (pendingMandates.length > 0) {
      logger.addContext({ pendingMandates });
      logger.info("Customer has pending mandates");
    }
    return { data: { hasPendingMandate } };
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.addContext({ errorMessage });
    logger.error("Error checking for pending mandate");
    return { error: { message: "An error occurred" } };
  }
};
