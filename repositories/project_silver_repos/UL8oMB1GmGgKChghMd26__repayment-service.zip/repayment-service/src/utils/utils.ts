import { RepaymentType } from "@libs/types";

/**
 * Determines the repayment type based on the payment intent details.
 * @param paymentIntentType - The type of the payment intent.
 * @returns The corresponding RepaymentType.
 * @throws Error if the payment intent type is unknown.
 */
export const determineRepaymentType = (paymentIntentType: string): RepaymentType => {
  if (paymentIntentType === "card") {
    return RepaymentType.Card;
  } else if (paymentIntentType === "bacs_debit") {
    return RepaymentType.DirectDebit;
  } else if (paymentIntentType === "pay_by_bank") {
    return RepaymentType.Bank;
  } else {
    throw new Error(`Unknown payment intent type: ${paymentIntentType}`);
  }
};
