import { RepaymentType } from "@libs/types";
import { PaymentEvent, PaymentEventStatus } from "@libs/types/paymentEvent";
import { StripePaymentEvent } from "@libs/types/stripePaymentEvent";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { GetPaymentIntentOutcome } from "@onmoapp/onmo-types";

const getRepaymentType = (type: string): RepaymentType => {
  if (type === "card") {
    return RepaymentType.Card;
  }
  if (type === "bacs_debit") {
    return RepaymentType.DirectDebit;
  }
  throw new OnmoError({
    name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
    message: `Unsupported payment method: ${type}`,
  });
};

export const stripeToPaymentEvent = (
  paymentIntent: GetPaymentIntentOutcome,
  stripeEvent: StripePaymentEvent,
): PaymentEvent => {
  return {
    id: paymentIntent.paymentIntentId,
    provider: "stripe",
    amount: paymentIntent.amount,
    currency: paymentIntent.currency,
    status: paymentIntent.status === "succeeded" ? PaymentEventStatus.SUCCESS : PaymentEventStatus.FAILED,
    created: stripeEvent.data.object.created,
    repaymentType: getRepaymentType(paymentIntent.type),
    pspCustomerId: stripeEvent.data.object.customer,
    customerId: paymentIntent.customerId,
    accountId: stripeEvent.data.object.metadata.accountId,
    accountType: stripeEvent.data.object.metadata.accountType,
  };
};
