import { Customer } from "@libs/types";
import { ICoreRepayments } from "@onmoapp/core-repayments";
import { CreatePspCustomerOutcome, CustomerGenericData } from "@onmoapp/onmo-types";

export const createPspCustomer = async ({
  repaymentClient,
  customer,
  customerData,
}: {
  repaymentClient: ICoreRepayments;
  customer: Customer;
  customerData: CustomerGenericData;
}): Promise<{ data: CreatePspCustomerOutcome, error: string }> => {
  let data = null
  let error = null
  try {
    data = await repaymentClient.createCustomer({
      customerId: customer.customerId,
      email: customerData.emailAddresses.primary,
      address: customerData.addresses[0],
      accountId: customer.accountId,
      firstName: customerData.firstName,
      lastName: customerData.lastName,
    });
  } catch (e) {
    error = e;
  }

  return { data, error };
};
