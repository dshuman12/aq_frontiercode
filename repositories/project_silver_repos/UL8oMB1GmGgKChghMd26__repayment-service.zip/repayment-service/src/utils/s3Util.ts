import { putObject } from "@onmoapp/onmo-s3";

export const uploadToS3 = async ({ data, key, bucket }: { data: Buffer; key: string; bucket: string }) => {
  return await putObject({
    Bucket: bucket,
    Key: key,
    ContentType: "application/json",
    Body: data,
  });
};
