import { deleteMessage } from "@onmoapp/onmo-sqs";
import { getLogger } from "@libs/logger";
import { formatErrorMessage } from "./errorUtil";
import { SQSRecord } from "aws-lambda";
import { Logger } from "@onmoapp/onmo-logger";
import { ChangeMessageVisibilityCommand, SQSClient } from "@aws-sdk/client-sqs";

export type ErrorLogInput = {
  sqsRecord: SQSRecord;
  message: string;
  logger: Logger;
};

export const deleteMessageFromQueue = async ({
  queueUrl,
  receiptHandle,
}: {
  queueUrl: string;
  receiptHandle: string;
}): Promise<void> => {
  const logger = getLogger();
  logger.addContext({ origin: "deleteMessageFromQueue" });
  try {
    await deleteMessage({
      ReceiptHandle: receiptHandle,
      QueueUrl: queueUrl,
    });
    logger.info({
      outputMessage: "Message deleted successfully",
      receiptHandle,
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({
      errorMessage: `Error deleting message: ${errorMessage}`,
      error,
    });
    throw error;
  }
};

export const logAndReturnFailedMessage = ({ logger, message, sqsRecord }: ErrorLogInput) => {
  logErrorWithContextReset({ logger, message, sqsRecord });
  return {
    error: {
      message,
      sqsMessageId: sqsRecord.messageId,
    },
  };
};

export const logErrorWithContextReset = ({ logger, message, sqsRecord }: ErrorLogInput) => {
  logger.addContext({ sqsRecord });
  logger.error(message);
  logger.removeContext("sqsRecord");
};

async function changeMessageVisibility({
  queueUrl,
  receiptHandle,
  visibilityTimeout,
  logger,
}: {
  queueUrl: string;
  receiptHandle: string;
  visibilityTimeout: number;
  logger: Logger;
}) {
  const sqsClient = new SQSClient({ region: process.env.REGION });
  try {
    const params = {
      QueueUrl: queueUrl,
      ReceiptHandle: receiptHandle,
      VisibilityTimeout: visibilityTimeout, // Time in seconds
    };

    const command = new ChangeMessageVisibilityCommand(params);
    const response = await sqsClient.send(command);

    logger.info({ message: "Visibility timeout updated successfully", response });
  } catch (error) {
    logger.error({ message: "Could not update visibility timeout", error: error.message });
  }
}

export const setProgressiveRetry = async (sqsRecord: SQSRecord, queueUrl: string, logger: Logger) => {
  const retryCount = Number.parseInt(sqsRecord.attributes["ApproximateReceiveCount"]);
  if (retryCount > 0) {
    const visibilityTimeout = retryCount < 3 ? 60 * 30 : 60 * 60; // 30 minutes for the first few retries, then 1h
    logger.info({
      message: `Retry number ${retryCount}. Changing visibility timeout to ${visibilityTimeout / 60} minutes`,
    });
    await changeMessageVisibility({
      queueUrl,
      logger,
      receiptHandle: sqsRecord.receiptHandle,
      visibilityTimeout,
    });
  }
};
