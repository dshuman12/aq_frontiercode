import { Logger } from "@onmoapp/onmo-logger";
import { ErrorOutcome, GetCreditAccountOutcome, GetPaymentIntentOutcome, Installment } from "@onmoapp/onmo-types";
import { Customer } from "@libs/types";
import { subtractWorkingDays } from "./dateUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import dayjs from "dayjs";
import { formatErrorMessage } from "./errorUtil";

const logWarningAndReturnError = ({
  paymentIntentId,
  logger,
  alertKeyword,
  message,
}: {
  paymentIntentId: string;
  logger: Logger;
  alertKeyword: string;
  message: string;
}): CalculateAmountToRetryOutcome => {
  logger.warn({ message: `${alertKeyword}: ${message} for ${paymentIntentId}` });
  return {
    data: null,
    error: {
      errorMessage: `${message} for ${paymentIntentId}`,
    },
  };
};

export const getPaymentRequestDate = (dueDate: string): string => {
  return subtractWorkingDays(dueDate, 2);
};

export type CanTakeDirectDebitOutcome = {
  data: {
    canTakeDirectDebit: boolean;
    reason?: string;
  } | null;
  error: ErrorOutcome | null;
};

export type ShouldRetryDirectDebitOutcome = {
  data: {
    shouldRetryDirectDebit: boolean;
    reason?: string;
    retryAmount?: number; // in base currency (GBP)
  } | null;
  error: ErrorOutcome | null;
};

export const canTakeDirectDebitPayment = async ({
  customer,
  logger,
  creditAccount,
}: {
  customer: Customer;
  logger: Logger;
  creditAccount: GetCreditAccountOutcome;
}): Promise<CanTakeDirectDebitOutcome> => {
  if (creditAccount.error) {
    logger.warn(creditAccount.error);
    return {
      data: null,
      error: {
        errorMessage: `Error getting credit account with ID: ${customer.accountId}, ${creditAccount.error}`,
      },
    };
  }

  logger.addContext({ customerId: customer.customerId, accountId: customer.accountId });

  if (creditAccount.data.accountDetails.accountState === "CLOSED") {
    logger.info(`Account ${customer.accountId} is closed. Skipping.`);
    return {
      data: {
        canTakeDirectDebit: false,
        reason: "Account is closed",
      },
      error: null,
    };
  }
  if (creditAccount.data.accountDetails.state === "FULL_LOCK") {
    logger.info(`Account ${customer.accountId} is fully locked. Skipping.`);
    return {
      data: {
        canTakeDirectDebit: false,
        reason: "Account is fully locked",
      },
      error: null,
    };
  }

  const { nextDirectDebitAmount, mandateID, ...rest } = creditAccount.data.directDebitSettings;

  logger.info({ message: "Direct debit settings", nextDirectDebitAmount, mandateID, ...rest });

  if (creditAccount.data.accountDetails.customerId !== customer.customerId) {
    logger.warn("Customer ID mismatch");
    return {
      data: null,
      error: {
        errorMessage: "Customer ID mismatch",
      },
    };
  }

  if (!mandateID) {
    logger.info(`Mandate ID not found ${mandateID}. Skipping.`);
    return {
      data: {
        canTakeDirectDebit: false,
        reason: "Mandate ID not found",
      },
      error: null,
    };
  }

  return {
    data: {
      canTakeDirectDebit: true,
    },
    error: null,
  };
};

export const calculateAmountToRetry = async (
  paymentIntent: GetPaymentIntentOutcome,
  logger: Logger,
  dateFrom?: string,
): Promise<CalculateAmountToRetryOutcome> => {
  const amountPreference = paymentIntent.metadata.originalUserPreference;
  const instalmentDate = paymentIntent.metadata.instalmentDate;
  const accountId = paymentIntent.metadata.accountId;

  if (!instalmentDate) {
    // TODO set up alert
    return logWarningAndReturnError({
      paymentIntentId: paymentIntent.paymentIntentId,
      logger,
      alertKeyword: "Alert_NoInstalment",
      message: "Instalment date not found in payment intent metadata",
    });
  }
  if (!amountPreference) {
    return logWarningAndReturnError({
      paymentIntentId: paymentIntent.paymentIntentId,
      logger,
      alertKeyword: "Alert_NoAmountPreference",
      message: "Amount preference not found in payment intent metadata",
    });
  }

  if (!accountId) {
    return logWarningAndReturnError({
      paymentIntentId: paymentIntent.paymentIntentId,
      logger,
      alertKeyword: "Alert_NoAccountId",
      message: "Account ID not found in payment intent metadata",
    });
  }

  const from = dateFrom ? dayjs(dateFrom).toISOString() : dayjs(paymentIntent.creationDate).toISOString();
  const dateTo = dayjs().toISOString();
  const adhocRepaymentsTotal = await getTotalRepaymentInDateRange(from, dateTo, accountId);
  const adhocTotalInPence = Number((adhocRepaymentsTotal * 100).toFixed(2));
  let ddRetryAmountInPence = 0;

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  switch (amountPreference) {
    case "Full Statement Balance":
    case "Custom": {
      ddRetryAmountInPence = paymentIntent.amount - adhocTotalInPence;
      break;
    }
    case "Minimum Payment": {
      // Fetch the instalment saved on the payment intent
      const res = await coreBankingClient.getInstalmentByDueDate(accountId, instalmentDate);
      if (res.error) {
        return logWarningAndReturnError({
          paymentIntentId: paymentIntent.paymentIntentId,
          logger,
          alertKeyword: "Alert_NoInstallmentInMambu",
          message: "Installment not found when searching Mambu",
        });
      }

      logger.debug({ instalment: res.data });
      const minimumDue = calculateMinimumDue(res.data);
      // no need to remove adhoc payments
      // as Mambu does it automatically
      ddRetryAmountInPence = Number((minimumDue * 100).toFixed(2));
      break;
    }
    default: {
      logger.error("Invalid amount preference");
      throw new Error(`Invalid amount preference: ${amountPreference}`);
    }
  }

  return {
    data: {
      directDebitRetryAmount: Number((ddRetryAmountInPence / 100).toFixed(2)), // this may be negative if the user made more repayments than needed
    },
    error: null,
  };
};

export const getTotalRepaymentInDateRange = async (dateFrom: string, dateTo: string, accountId): Promise<number> => {
  if (!dayjs(dateFrom, "YYYY-MM-DDTHH:mm:ss.SSS[Z]", true).isValid()) {
    throw new Error(`Invalid date format for dateFrom: ${dateFrom}. Expected ISO format`);
  }

  if (!dayjs(dateTo, "YYYY-MM-DDTHH:mm:ss.SSS[Z]", true).isValid()) {
    throw new Error(`Invalid date format for dateTo: ${dateTo}. Expected ISO format`);
  }

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const res = await coreBankingClient.getTransactionsInDateRange({
    accountId,
    dateFrom,
    dateTo,
    limit: 50,
  });

  if (res.error) {
    throw new Error(res.error.errorMessage);
  }

  const repaymentTransactions = res.data.transactions.filter(
    (transaction) =>
      transaction.onmoTransactionType.startsWith("REPAYMENT") ||
      transaction.onmoTransactionType === "REPAYMENT_ADJUSTMENT",
  );

  const sumAlreadyPaid = repaymentTransactions
    .map((transaction) => transaction.destinationAmount)
    .reduce((sum, current) => sum + current, 0);

  return Math.abs(sumAlreadyPaid); // a repayment is logged as negative as it reduces how much you owe
};

const calculateMinimumDue = (instalment: Installment): number => {
  const principalDue = instalment.principal.amount.due || 0;
  const interestDue = instalment.interest.amount.due || 0;
  const feeDue = instalment.fee.amount.due || 0;
  return principalDue + interestDue + feeDue;
};

export type CalculateAmountToRetryOutcome = {
  data: {
    directDebitRetryAmount: number; // in base currency (GBP)
  } | null;
  error: ErrorOutcome | null;
};

export const shouldRetryDirectDebit = async ({
  customer,
  logger,
  creditAccount,
  paymentIntentId,
  dateFrom,
}: {
  customer: Customer;
  logger: Logger;
  creditAccount: GetCreditAccountOutcome;
  paymentIntentId: string;
  dateFrom?: string;
}): Promise<ShouldRetryDirectDebitOutcome> => {
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  const checkSettings = await canTakeDirectDebitPayment({ customer, logger, creditAccount });
  if (checkSettings.error) {
    return {
      data: null,
      error: checkSettings.error,
    };
  }

  if (!checkSettings.data.canTakeDirectDebit) {
    return {
      data: {
        shouldRetryDirectDebit: false,
        reason: checkSettings.data.reason,
      },
      error: null,
    };
  }

  try {
    const paymentIntent = await repaymentClient.getPaymentIntent(paymentIntentId);
    const amountToRetryResult = await calculateAmountToRetry(paymentIntent, logger, dateFrom);
    if (amountToRetryResult.error) {
      return {
        data: null,
        error: amountToRetryResult.error,
      };
    }

    const amountToRetry = amountToRetryResult.data.directDebitRetryAmount;

    if (amountToRetry <= 0) {
      return {
        data: {
          shouldRetryDirectDebit: false,
          reason: `Customer already covered the payment with ADHOC payments, amount is ${amountToRetry}`,
        },
        error: null,
      };
    }

    return {
      data: {
        shouldRetryDirectDebit: true,
        retryAmount: amountToRetry,
      },
      error: null,
    };
  } catch (error) {
    return {
      data: null,
      error: {
        errorMessage: `Error getting payment intent with ID: ${paymentIntentId}, ${formatErrorMessage(error)}`,
      },
    };
  }
};
