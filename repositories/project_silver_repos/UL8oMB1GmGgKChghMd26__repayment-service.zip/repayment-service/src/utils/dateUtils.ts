import dayjs, { Dayjs } from "dayjs";

// These utils will be moved to onmo-utilities later
const holidays = [
  "2024-08-26T00:00:00Z",
  "2024-12-25T00:00:00Z",
  "2024-12-26T00:00:00Z",
  "2025-01-01T00:00:00Z",
  "2025-04-18T00:00:00Z",
  "2025-04-21T00:00:00Z",
  "2025-05-05T00:00:00Z",
  "2025-05-26T00:00:00Z",
  "2025-08-25T00:00:00Z",
  "2025-12-25T00:00:00Z",
  "2025-12-26T00:00:00Z",
  "2026-01-01T00:00:00Z",
  "2026-04-03T00:00:00Z",
  "2026-04-06T00:00:00Z",
  "2026-05-04T00:00:00Z",
  "2026-05-25T00:00:00Z",
  "2026-08-31T00:00:00Z",
  "2026-12-25T00:00:00Z",
  "2026-12-28T00:00:00Z",
  "2027-01-01T00:00:00Z",
  "2027-03-26T00:00:00Z",
  "2027-03-29T00:00:00Z",
  "2027-05-03T00:00:00Z",
  "2027-05-31T00:00:00Z",
  "2027-08-30T00:00:00Z",
  "2027-12-27T00:00:00Z",
  "2027-12-28T00:00:00Z",
];

const getHolidaysUK = (): Dayjs[] => {
  return holidays.map((holiday) => dayjs(holiday));
};

const isWeekend = (date: Dayjs): boolean => {
  return date.day() === 0 || date.day() === 6;
};

export const isPublicHoliday = (date: string): boolean => {
  const convertedDate = dayjs(date);
  const holidays = getHolidaysUK();
  return holidays.some((holiday) => holiday.isSame(convertedDate, "day"));
};

export const nextWorkingDay = (date: string): string => {
  const convertedDate = dayjs(date);
  if (!isPublicHoliday(date) && !isWeekend(convertedDate)) {
    return date;
  }
  let nextDay = convertedDate.add(1, "day");
  let guard = 0;

  while (isPublicHoliday(nextDay.toISOString()) || isWeekend(nextDay)) {
    // 0: Sunday, 6: Saturday
    nextDay = nextDay.add(1, "day");
    guard++;
    if (guard > 10) {
      throw new Error("Infinite loop detected");
    }
  }
  return nextDay.toISOString();
};

export const subtractWorkingDays = (date: string, days: number): string => {
  if (days < 0) {
    throw new Error("Invalid value for working days");
  }

  const convertedDate = dayjs(date);
  let remainingDays = days;
  let resultDate = convertedDate;

  while (remainingDays > 0) {
    resultDate = resultDate.subtract(1, "day");
    if (!isPublicHoliday(resultDate.toISOString()) && !isWeekend(resultDate)) {
      remainingDays--;
    }
  }

  return resultDate.toISOString();
};

export const addWorkingDays = (date: string, days: number): string => {
  if (days < 0) {
    throw new Error("Invalid value for working days");
  }

  const convertedDate = dayjs(date);
  let remainingDays = days;
  let resultDate = convertedDate;

  while (remainingDays > 0) {
    resultDate = resultDate.add(1, "day");
    if (!isPublicHoliday(resultDate.toISOString()) && !isWeekend(resultDate)) {
      remainingDays--;
    }
  }

  return resultDate.toISOString();
};
