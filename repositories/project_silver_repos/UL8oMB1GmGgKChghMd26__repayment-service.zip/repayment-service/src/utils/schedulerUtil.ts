import { getLogger } from "@libs/logger";

import {
  SchedulerClient,
  ListSchedulesCommand,
  ListSchedulesCommandInput,
  CreateScheduleCommandOutput,
  CreateScheduleCommand,
  DeleteScheduleCommandInput,
  DeleteScheduleCommand,
  GetScheduleCommand,
  UpdateScheduleCommand,
} from "@aws-sdk/client-scheduler";
import { RepaymentCollectedEvent, RepaymentFailedEvent } from "@shared-types/eventHub-types";
import { EventData } from "@onmoapp/event-hub-interface";
import { PROD_WAIT_SCHEDULE_GROUP_NAME } from "@libs/constants";
import dayjs from "dayjs";
import { addWorkingDays } from "./dateUtils";
import { uploadToS3 } from "./s3Util";
import { Logger } from "@onmoapp/onmo-logger";

export type ScheduleExistsInput = {
  namePrefix: string;
  groupName: string;
};

export const scheduleExists = async (input: ScheduleExistsInput): Promise<boolean> => {
  const logger = getLogger();

  logger.addContext({ functionName: "scheduleExists", input });
  const { namePrefix, groupName } = input;
  const client = new SchedulerClient({ region: process.env.REGION });

  const params = {
    GroupName: groupName,
    MaxResults: 1,
    NamePrefix: namePrefix,
  } as ListSchedulesCommandInput;

  logger.addContext({ params });
  logger.info({ message: "Sending command to list schedules by name prefix in specific group name" });
  const command = new ListSchedulesCommand(params);

  const response = await client.send(command);
  logger.info({ message: "Received response", response });
  return response.Schedules?.length > 0;
};

export type CreateProdWaitScheduleInput = {
  event: EventData<RepaymentCollectedEvent> | EventData<RepaymentFailedEvent>;
};

export const createProdWaitSchedule = async (
  input: CreateProdWaitScheduleInput,
): Promise<CreateScheduleCommandOutput | void> => {
  const logger = getLogger();
  logger.addContext({ functionName: "createProdWaitSchedule", input });
  logger.info({ message: "Creating schedule for event", input });

  const event = input.event;
  const accountId = event.eventData.accountId;

  const namePrefix = `prod-wait-${accountId}-${event.id}`;


  const scheduleFound = await scheduleExists({
    groupName: PROD_WAIT_SCHEDULE_GROUP_NAME,
    namePrefix,
  });

  if (scheduleFound) {
    logger.info({ message: "Prod wait chedule already exists for this account. Skipping." });
    return;
  }

  const client = new SchedulerClient({ region: process.env.REGION });
  const addTwoWorkingDays = addWorkingDays(dayjs().toISOString(), 3);
  const scheduleDate = dayjs(addTwoWorkingDays).set("hour", 21).set("minute", 0).set("second", 0);

  logger.info({ message: "Scheduling prod delay" });

  return await client.send(
    new CreateScheduleCommand({
      Name: `${namePrefix}-${scheduleDate.format("YYYY-MM-DD")}`.substring(0,64), // character limit for schedule name
      ScheduleExpression: `at(${scheduleDate.toISOString().substring(0, 19)})`,
      Target: {
        Arn: process.env.DD_RETRY_PROD_WAIT_ARN,
        RoleArn: process.env.SCHEDULER_ROLE_ARN,
        Input: JSON.stringify(event),
      },
      FlexibleTimeWindow: {
        Mode: "OFF",
      },
      GroupName: PROD_WAIT_SCHEDULE_GROUP_NAME,
      ActionAfterCompletion: "DELETE",
    }),
  );
};

export const findAndGetSchedulePayload = async <T>({
  accountId,
  namePrefix,
  groupName,
}: {
  accountId: string;
  namePrefix: string;
  groupName: string;
}): Promise<T> => {
  const logger = getLogger();

  logger.addContext({ functionName: "findAndUpdateSchedule", accountId });
  try {
    const client = new SchedulerClient({ region: process.env.REGION });

    const params = {
      GroupName: groupName,
      MaxResults: 1,
      NamePrefix: `${namePrefix}-${accountId}`,
    } as ListSchedulesCommandInput;

    logger.addContext({ params });
    logger.info({ message: "Sending command to list schedules by name prefix" });
    const command = new ListSchedulesCommand(params);

    const response = await client.send(command);
    logger.info({ message: "Received response", response });

    if (response.Schedules.length > 0) {
      const scheduleSum = response.Schedules[0];
      const schedule = await client.send(
        new GetScheduleCommand({
          Name: scheduleSum.Name,
          GroupName: groupName,
        }),
      );

      return JSON.parse(schedule.Target.Input) as T;
    }
  } catch (err) {
    logger.error({ message: "Error in findAndDeleteSchedule", error: err });
    throw err;
  }
};

export const findAndTriggerSchedule = async ({
  accountId,
  namePrefix,
  groupName,
}: {
  accountId: string;
  namePrefix: string;
  groupName: string;
}): Promise<void> => {
  const logger = getLogger();

  logger.addContext({ functionName: "findAndUpdateSchedule", accountId });
  try {
    const client = new SchedulerClient({ region: process.env.REGION });

    const params = {
      GroupName: groupName,
      MaxResults: 1,
      NamePrefix: `${namePrefix}-${accountId}`,
    } as ListSchedulesCommandInput;

    logger.addContext({ params });
    logger.info({ message: "Sending command to list schedules by name prefix" });
    const command = new ListSchedulesCommand(params);

    const response = await client.send(command);
    logger.info({ message: "Received response", response });

    if (response.Schedules.length > 0) {
      const scheduleSum = response.Schedules[0];
      const schedule = await client.send(
        new GetScheduleCommand({
          Name: scheduleSum.Name,
          GroupName: groupName,
        }),
      );

      await client.send(
        new UpdateScheduleCommand({
          Name: scheduleSum.Name,
          GroupName: groupName,
          ScheduleExpression: `at(${dayjs().add(1, "minutes").toISOString().substring(0, 19)})`,
          FlexibleTimeWindow: {
            Mode: "OFF",
          },
          Target: schedule.Target,
          ActionAfterCompletion: schedule.ActionAfterCompletion,
        }),
      );
    }
  } catch (err) {
    logger.error({ message: "Error in findAndDeleteSchedule", error: err });
    throw err;
  }
};

export const findAndDeleteSchedule = async ({
  accountId,
  namePrefix,
  groupName,
}: {
  accountId: string;
  namePrefix: string;
  groupName: string;
}): Promise<void> => {
  const logger = getLogger();

  logger.addContext({ functionName: "findAndDeleteSchedule", accountId });
  try {
    const client = new SchedulerClient({ region: process.env.REGION });

    const params = {
      GroupName: groupName,
      MaxResults: 1,
      NamePrefix: `${namePrefix}-${accountId}`,
    } as ListSchedulesCommandInput;

    logger.addContext({ params });
    logger.info({ message: "Sending command to list schedules by name prefix" });
    const command = new ListSchedulesCommand(params);

    const response = await client.send(command);
    logger.info({ message: "Received response", response });

    if (response.Schedules.length > 0) {
      const deleteCommand = {
        Name: response.Schedules[0].Name,
        GroupName: groupName,
      } as DeleteScheduleCommandInput;

      logger.info({ message: "Sending command to delete schedule", deleteCommand });
      const delCommand = new DeleteScheduleCommand(deleteCommand);
      const delRes = await client.send(delCommand);
      logger.info({ message: "Received response", delRes });
    }
  } catch (err) {
    logger.error({ message: "Error in findAndDeleteSchedule", error: err });
    throw err;
  }
};

export const findAndDeleteAllSchedules = async ({
  accountId,
  namePrefix,
  groupName,
}: {
  accountId: string;
  namePrefix: string;
  groupName: string;
}): Promise<void> => {
  const logger = getLogger();

  logger.addContext({ functionName: "findAndDeleteAllSchedules", accountId });
  try {
    const client = new SchedulerClient({ region: process.env.REGION });

    const params = {
      GroupName: groupName,
      MaxResults: 100,
      NamePrefix: `${namePrefix}-${accountId}`,
    } as ListSchedulesCommandInput;

    logger.info({ message: "Listing all schedules by name prefix", params });
    const response = await client.send(new ListSchedulesCommand(params));
    logger.info({ message: `Found ${response.Schedules?.length ?? 0} schedule(s) to delete` });

    for (const schedule of response.Schedules ?? []) {
      logger.info({ message: "Deleting schedule", name: schedule.Name });
      await client.send(new DeleteScheduleCommand({ Name: schedule.Name, GroupName: groupName }));
    }
  } catch (err) {
    logger.error({ message: "Error in findAndDeleteAllSchedules", error: err });
    throw err;
  }
};

export const putScheduleDataInDatalakeS3 = async ({
  customerId,
  scheduleDataForDatalake,
  logger,
}: {
  customerId: string;
  scheduleDataForDatalake: any;
  logger: Logger;
}) => {
  const filename = `${customerId}-${Date.now()}.json`;
  const filepath = `non-pii/tech-events/repayment-service/year=${dayjs().format("YYYY")}/month=${dayjs().format("MM")}/day=${dayjs().format("DD")}/${filename}`;

  logger.info(
    `Storing schedule data to ${process.env.ONMO_DATALAKE_BUCKET} S3: ${filepath}, ${JSON.stringify(scheduleDataForDatalake, null, 2)}`,
  );

  await uploadToS3({
    data: Buffer.from(JSON.stringify(scheduleDataForDatalake)),
    key: filepath,
    bucket: process.env.ONMO_DATALAKE_BUCKET,
  });
};
