import {
  CORE_BANKING_ADAPTER_CLIENT_NAME,
  CREDIT_ACCOUNT_PRODUCT_KEY,
  TECHNICAL_ACCOUNT_PRODUCT_KEY,
} from "@libs/constants";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { putItemMethod, deleteItemMethod } from "@onmoapp/onmo-dynamodb";
import {
  CreateCreditAccountInput,
  CreateCreditAccountOutcome,
  CreateCustomerInput,
  CreateCustomerOutcome,
  CreateTechnicalAccountInput,
  CreateTechnicalAccountOutcome,
} from "@onmoapp/onmo-types";
import { UserCredentials } from "./testTypes";
import { v4 as uuidv4 } from "uuid";

const generateUniqueIdentifier = () => `TEST-REPAYMENT-${uuidv4()}`;

const userTable = process.env.TF_VAR_USER_TABLE as string;

export const createUserRecordInMobileTable = async (userCredentials: UserCredentials) => {
  try {
    await putItemMethod({
      TableName: userTable,
      Item: {
        createDateTime: new Date().toISOString(),
        mambuID: userCredentials.coreBankingCustomerId,
        onmouuid: userCredentials.customerId,
        mambuCreditCardAccountID: userCredentials.creditAccountId,
        pspCustomerId: userCredentials.pspCustomerId,
        ...(userCredentials.technicalAccountId && {
          mambuTechnicalAccountID: userCredentials.technicalAccountId,
        }),
      },
    });
  } catch (error) {
    console.log("[createUserRecordInMobileTable] ERROR ", error);
  }
};

export const deleteUserRecordInMobileTable = async (customerId: string) => {
  await deleteItemMethod({ TableName: userTable, Key: { onmouuid: customerId } });
};

export const setUpTestCreditCustomerAccount = async (includeRepaymentService = true) => {
  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);
  if (!coreBankingClient) {
    throw new Error("Core banking client not found");
  }
  const createCustomerInput: CreateCustomerInput = {
    applicationDetail: {
      onmoUuid: uuidv4(),
      crmId: generateUniqueIdentifier(),
    },
    personalData: {
      firstName: "test",
      lastName: "test",
      dateOfBirth: "1990-01-01",
      emailAddresses: ["test@test.com"],
      mobileNumbers: ["1234567890"],
    },
  };
  let createCustomerOutcome: CreateCustomerOutcome;

  createCustomerOutcome = await coreBankingClient.createCustomer(createCustomerInput);

  const updateAddress = await coreBankingClient.updateCustomer(createCustomerOutcome.data.coreBankingCustomerId, {
    address: {
      addressLine1: "test",
      city: "test",
      postalCode: "test",
      country: "test",
    },
  });

  console.log({ updateAddress });
  const { coreBankingCustomerId, coreBankingCustomerEncodedKey } = createCustomerOutcome.data;
  const createCreditAccountInput: CreateCreditAccountInput = {
    coreBankingCustomerEncodedKey,
    productKey: CREDIT_ACCOUNT_PRODUCT_KEY,
    loanAmount: 100,
    interestRate: 1,
    paymentDay: 30,
    creditRiskGroup: "987",
  };

  const createCreditAccountOutcome: CreateCreditAccountOutcome =
    await coreBankingClient.createCreditAccount(createCreditAccountInput);

  let pspCustomerId = null;
  if (includeRepaymentService) {
    const createRepaymentAccount = await coreRepaymentsAdapter("STRIPE_CLIENT");
    const createRepaymentAccountOutcome = await createRepaymentAccount.createCustomer({
      email: createCustomerInput.personalData.emailAddresses[0],
      address: [],
      customerId: createCustomerInput.applicationDetail.onmoUuid,
      accountId: createCreditAccountOutcome.data.accountId,
      firstName: createCustomerInput.personalData.firstName,
      lastName: createCustomerInput.personalData.lastName,
    });

    pspCustomerId = createRepaymentAccountOutcome.pspCustomerId;

    console.log({ createRepaymentAccountOutcome });
  }
  const createTechnicalAccountInput: CreateTechnicalAccountInput = {
    coreBankingCustomerEncodedKey,
    productKey: TECHNICAL_ACCOUNT_PRODUCT_KEY,
  };
  const createTechnicalAccountOutcome: CreateTechnicalAccountOutcome =
    await coreBankingClient.createTechnicalAccount(createTechnicalAccountInput);

  await coreBankingClient.approveTechnicalAccount(createTechnicalAccountOutcome.data.technicalAccountId);

  const testUserCreds: UserCredentials = {
    coreBankingCustomerId,
    creditAccountId: createCreditAccountOutcome.data.accountId,
    customerId: createCustomerInput?.applicationDetail?.onmoUuid!,
    technicalAccountId: createTechnicalAccountOutcome.data.technicalAccountId,
    ...(pspCustomerId && { pspCustomerId: pspCustomerId }),
  };
  await createUserRecordInMobileTable(testUserCreds);
  return testUserCreds;
};

export const deleteTestCreditCustomerAccount = async (userCredentials: UserCredentials) => {
  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);

  await Promise.all([
    coreBankingClient.deleteCreditAccount(userCredentials.creditAccountId),
    coreBankingClient.deleteTechnicalAccount(userCredentials.technicalAccountId),
  ]);

  await coreBankingClient.deleteCustomer(userCredentials.coreBankingCustomerId);
  await deleteUserRecordInMobileTable(userCredentials.customerId);
};
