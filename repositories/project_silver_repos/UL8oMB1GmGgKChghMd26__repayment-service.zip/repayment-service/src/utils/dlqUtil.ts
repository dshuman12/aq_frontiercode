import { Logger } from "@onmoapp/onmo-logger";
import { SQSRecord } from "aws-lambda";
import dayjs from "dayjs";
import { uploadToS3 } from "./s3Util";
import { deleteMessageFromQueue } from "./sqsUtils";
import { formatErrorMessage } from "./errorUtil";

export const archiveAndDeleteMessage = async ({
  record,
  queueUrl,
  folder,
  bucket,
  logger,
}: {
  record: SQSRecord;
  queueUrl: string;
  folder: string;
  bucket: string;
  logger: Logger;
}) => {
  const failedMessage = JSON.parse(record.body);
  logger.info({ message: "Processing message", failedMessage });

  const date = dayjs(record.attributes.SentTimestamp);

  const path = `${folder}/${date.format("YYYY/MM/DD/HH")}`;
  logger.info({ mesage: "Uploading to S3", path, bucket });

  await uploadToS3({
    data: Buffer.from(JSON.stringify(failedMessage)),
    key: path,
    bucket,
  });

  // Delete the message
  try {
    await deleteMessageFromQueue({
      queueUrl,
      receiptHandle: record.receiptHandle,
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({
      errorMessage,
      error,
      record,
    });
    throw new Error("Some error has occured while processing the records. Please check the logs for more details.");
  }
};
