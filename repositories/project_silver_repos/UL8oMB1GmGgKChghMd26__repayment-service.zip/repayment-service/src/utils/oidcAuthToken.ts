import { accessTokenObject } from "@libs/types";
import { deleteItemMethod, putItemMethod } from "@onmoapp/onmo-dynamodb";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import jwt from "jsonwebtoken";
import { UserCredentials } from "./testTypes";
import { randomBytes } from "crypto";

const getCurrentTimestampInSeconds = () => Math.floor(Date.now() / 1000);
const generateJti = () => randomBytes(16).toString("hex");

const auth_tokens_table = process.env.TF_VAR_AUTH_TOKENS_TABLE as string;
const onmo_auth_url = process.env.TF_VAR_ONMO_AUTH_URL as string;
const onmo_api_url = process.env.TF_VAR_ONMO_API_URL as string;
const environment = process.env.TF_VAR_ENVIRONMENT as string;

export const generateAccessTokenOfTestUser = async (
  customerId: UserCredentials["customerId"],
  scope = "repayment",
): Promise<accessTokenObject> => {
  const accessToken: accessTokenObject = await createTestTokenRecord({
    scope,
    environment,
    expiryTimeMinutes: 60,
    tableName: auth_tokens_table,
    onmouuid: customerId,
  });
  return accessToken;
};

export const deleteAccessTokenOfTestUser = async (
  customerId: UserCredentials["customerId"],
  accessToken: accessTokenObject,
): Promise<void> => {
  await deleteItemMethod({
    TableName: auth_tokens_table,
    Key: { token_id: accessToken.token_id, onmouuid: customerId },
  });
};

type GenerateAccessTokenInput = {
  onmouuid: string;
  scope: string;
  secretKey: string;
  expiryTimeMinutes: number;
  environment: string;
};
export const generateTestAccessToken = ({
  onmouuid,
  scope,
  secretKey,
  expiryTimeMinutes,
  environment,
}: GenerateAccessTokenInput) => {
  const sanitizedPrivKey = secretKey.replace(/\\n/g, "\n");
  const issuedAt = getCurrentTimestampInSeconds();
  const expirationTime = issuedAt + expiryTimeMinutes * 60;
  const token_id = generateJti();
  const payload = {
    iss: `${onmo_auth_url}/oidc`,
    sub: onmouuid,
    aud: onmo_api_url,
    exp: expirationTime,
    iat: issuedAt,
    jti: token_id,
    env: environment,
    scope,
  };

  return {
    access_token: jwt.sign(payload, sanitizedPrivKey, { algorithm: "RS256" }),
    expires_in: expirationTime,
    token_id,
  };
};

type CreateTestTokenRecordInput = {
  scope: string;
  environment: string;
  expiryTimeMinutes: number;
  tableName: string;
  onmouuid: string;
};

type SigningKeySecrets = { pub_signing_key?: string; priv_signing_key?: string };
export const createTestTokenRecord = async ({
  scope,
  environment,
  expiryTimeMinutes,
  tableName,
  onmouuid,
}: CreateTestTokenRecordInput): Promise<accessTokenObject> => {
  const { SecretString } = await getSecret(`onmo-auth-signing-keys-${environment}`);
  if (!SecretString) {
    throw new Error("Token signing keys secrets string is undefined");
  }

  const { priv_signing_key }: SigningKeySecrets = JSON.parse(SecretString);
  if (!priv_signing_key) {
    throw new Error("Missing necessary signing private key");
  }

  const accessToken = generateTestAccessToken({
    onmouuid,
    scope,
    secretKey: priv_signing_key,
    expiryTimeMinutes,
    environment,
  });

  try {
    await putItemMethod({
      TableName: tableName,
      Item: {
        token_id: accessToken.token_id,
        onmouuid,
        scope,
        token: accessToken.access_token,
        ttl: accessToken.expires_in,
      },
    });
  } catch (error) {
    console.log("[createTestTokenRecord] ERROR ", error);
    throw new Error(`Error generating token`);
  }
  return {
    token_id: accessToken.token_id,
    access_token: accessToken.access_token,
  };
};
