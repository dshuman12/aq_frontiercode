export type UserCredentials = {
  coreBankingCustomerId?: string;
  creditAccountId: string;
  customerId: string;
  technicalAccountId: string;
  pspCustomerId: string;
};
