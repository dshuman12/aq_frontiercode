import { beforeEach, describe, expect, test, vi } from "vitest";
import { archiveAndDeleteMessage } from "./dlqUtil";
import * as s3Util from "./s3Util";
import * as sqsUtil from "./sqsUtils";
import { REPAYMENT_DUE_THROTTLING_DLQ_ARCHIVE_BUCKET_FOLDER } from "@libs/constants";
import { getLogger } from "@libs/logger";

vi.mock("src/utils/s3Util");
vi.mock("src/utils/sqsUtils");

describe("throttlingDlqToS3", () => {
  const bucketName = "bucket-name";
  const bucketFolder = REPAYMENT_DUE_THROTTLING_DLQ_ARCHIVE_BUCKET_FOLDER;
  const queueUrl = "queue-url";

  beforeEach(() => {
    vi.resetAllMocks();
  });
  test("It should upload to S3 bucket in the right folder", async () => {
    vi.mocked(s3Util.uploadToS3, { partial: true }).mockResolvedValue({
      $metadata: {},
    });
    vi.mocked(sqsUtil.deleteMessageFromQueue, { partial: true }).mockResolvedValue();

    const event = {
      messageId: "059f36b4-87a3-44ab-83d2-661975830a7d",
      body: JSON.stringify({ message: "test" }),
      attributes: {
        SentTimestamp: "2025-01-01T14:48:00.000Z",
        ApproximateReceiveCount: "1",
        ApproximateFirstReceiveTimestamp: "2025-01-01T14:48:00.000Z",
        SenderId: "123456789012",
      },
      eventSourceARN: "arn:aws:sqs:us-east-1:123456789012:MyQueue",
      receiptHandle: "receipt-handle",
      messageAttributes: {},
      md5OfBody: "",
      eventSource: "aws:sqs",
      awsRegion: "eu-west-1",
    };

    await archiveAndDeleteMessage({
      bucket: bucketName,
      folder: bucketFolder,
      logger: getLogger(),
      queueUrl,
      record: event,
    });
    expect(s3Util.uploadToS3).toHaveBeenCalledWith({
      data: Buffer.from(JSON.stringify({ message: "test" })),
      key: `${bucketFolder}/2025/01/01/14`,
      bucket: "bucket-name",
    });

    expect(s3Util.uploadToS3).toHaveBeenCalledOnce();
    expect(sqsUtil.deleteMessageFromQueue).toHaveBeenCalledOnce();

    expect(sqsUtil.deleteMessageFromQueue).toHaveBeenCalledWith({
      queueUrl,
      receiptHandle: "receipt-handle",
    });
  });
});
