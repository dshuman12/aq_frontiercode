import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";

export const formatErrorMessage = (error: any): string => {
  const errorMessage = error instanceof Error ? `${error.name}: ${error.message}` : JSON.stringify(error);
  return errorMessage;
};

/**
 * Throws an error if the adapter response has an error or if the extra condition is true.
 *
 * @param adapterResponse - The response object from the adapter.
 * @param options - An object containing the extra condition and the error message.
 * @throws {OnmoError} - Throws an OnmoError with the specified message and the adapter error as the cause.
 */
export const throwErrorIfAdapterResHaveError = (
  adapterResponse: { data: any | null; error: any | null } | undefined,
  options: {
    extraCondition?: boolean;
    message: string;
  },
): void => {
  if (!adapterResponse || adapterResponse.error || !adapterResponse.data || options.extraCondition) {
    throw new OnmoError({
      name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
      message: options.message || "Something went wrong",
      cause: adapterResponse?.error,
    });
  }
};
