import { describe, test, expect } from "vitest";
import { isPublicHoliday, subtractWorkingDays, nextWorkingDay, addWorkingDays } from "./dateUtils";

// this just tests the library, it will be removed once this is integrated with the scheduler
describe("Public Holidays util test", () => {
  describe("isPublicHoliday", () => {
    test("Not a public holiday - it should return false", () => {
      const result = isPublicHoliday("2024-08-24T00:00:00.000Z");
      expect(result).toBe(false);
    });
    test("Public holiday - it should return true", () => {
      const result = isPublicHoliday("2024-01-01T00:00:00.000Z");
      expect(result).toBe(false);
    });
  });
  describe("nextWorkingDay", () => {
    test("Day is a Wednesday - it should not change the date", () => {
      const result = nextWorkingDay("2024-12-18T00:00:00.000Z");
      expect(result).toBe("2024-12-18T00:00:00.000Z");
    });
    test("Day is a Saturday - it should change the date to following Monday", () => {
      const result = nextWorkingDay("2024-12-21T00:00:00Z");
      expect(result).toBe("2024-12-23T00:00:00.000Z");
    });
    test("Day is a Sunday - it should change the date to following Monday", () => {
      const result = nextWorkingDay("2024-12-22T00:00:00Z");
      expect(result).toBe("2024-12-23T00:00:00.000Z");
    });
    test("Good Friday case - it should change the date to the following Tuesday", () => {
      const result = nextWorkingDay("2025-04-18T00:00:00Z");
      expect(result).toBe("2025-04-22T00:00:00.000Z");
    });
    test("Holiday day - it should change the date to the next day", () => {
      const result = nextWorkingDay("2025-05-26T00:00:00.000Z");
      expect(result).toBe("2025-05-27T00:00:00.000Z");
    });
  });
  describe("subtractWorkingDays - 3 days", () => {
    test("Day is a Wednesday - it should return the previous Friday", () => {
      const result = subtractWorkingDays("2024-12-18T00:00:00.000Z", 3);
      expect(result).toBe("2024-12-13T00:00:00.000Z");
    });
    test("Day is a Saturday - it should return Wednesday", () => {
      const result = subtractWorkingDays("2024-12-21T00:00:00Z", 3);
      expect(result).toBe("2024-12-18T00:00:00.000Z");
    });
    test("Day is a Sunday - it should return Wednesday", () => {
      const result = subtractWorkingDays("2024-12-22T00:00:00Z", 3);
      expect(result).toBe("2024-12-18T00:00:00.000Z");
    });
    test("Easter Monday case - it should return last Tuesday", () => {
      const result = subtractWorkingDays("2025-04-21T00:00:00Z", 3);
      expect(result).toBe("2025-04-15T00:00:00.000Z");
    });
    test("Single holiday day - it should change the date to 3 working days before", () => {
      const result = subtractWorkingDays("2025-12-25T00:00:00.000Z", 3);
      expect(result).toBe("2025-12-22T00:00:00.000Z");
    });
  });
  describe("addWorkingDays - 3 days", () => {
    test("Day is a Wednesday - it should return the following Monday", () => {
      const result = addWorkingDays("2024-12-18T00:00:00.000Z", 3);
      expect(result).toBe("2024-12-23T00:00:00.000Z");
    });
    test("Day is a Saturday - it should return the following Wednesday", () => {
      const result = addWorkingDays("2024-12-14T00:00:00Z", 3);
      expect(result).toBe("2024-12-18T00:00:00.000Z");
    });
    test("Day is a Sunday - it should return the following Wednesday", () => {
      const result = addWorkingDays("2024-12-15T00:00:00Z", 3);
      expect(result).toBe("2024-12-18T00:00:00.000Z");
    });
    test("Easter Monday case - it should return Thursday", () => {
      const result = addWorkingDays("2025-04-21T00:00:00Z", 3);
      expect(result).toBe("2025-04-24T00:00:00.000Z");
    });
    test("Single holiday day - it should change the date to 3 working days after", () => {
      const result = addWorkingDays("2025-05-05T00:00:00.000Z", 3);
      expect(result).toBe("2025-05-08T00:00:00.000Z");
    });
  });
});
