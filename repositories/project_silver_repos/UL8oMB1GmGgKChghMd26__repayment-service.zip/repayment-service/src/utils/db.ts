import { Customer } from "@libs/types";
import { getItemMethod, updateItemMethod } from "@onmoapp/onmo-dynamodb";

const USER_TABLE = process.env.USER_TABLE;

export const getCustomer = async (customerId: string): Promise<{ data?: Customer; error?: string }> => {
  try {
    console.log({ USER_TABLE });
    const res = (await getItemMethod({
      TableName: USER_TABLE,
      Key: { onmouuid: customerId },
    })) as any;

    const user = res.Item;
    user.customerId = user.onmouuid;
    user.accountId = user.mambuCreditCardAccountID;
    user.technicalAccountId = user.mambuTechnicalAccountID;

    return { data: user, error: null };
  } catch (error) {
    return { data: null, error };
  }
};

export const updateCustomer = async (
  customerId: string,
  pspCustomerId: string,
): Promise<{ data?: { pspCustomerId: string }; error?: string }> => {
  try {
    const res = (await updateItemMethod({
      TableName: USER_TABLE,
      Key: { onmouuid: customerId },
      UpdateExpression: "set pspCustomerId = :pspCustomerId",
      ExpressionAttributeValues: { ":pspCustomerId": pspCustomerId },
    })) as any;
    return { data: res, error: null };
  } catch (error) {
    console.log(error);
    return { data: null, error };
  }
};
