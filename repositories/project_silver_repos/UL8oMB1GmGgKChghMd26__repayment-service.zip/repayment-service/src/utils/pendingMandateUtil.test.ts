import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import * as adapters from "@onmoapp/onmo-adapters";
import { pspCustomerHasPendingMandate } from "./pendingMandateUtil";

vi.mock("@onmoapp/onmo-adapters");

describe("pspCustomerHasPendingMandate", () => {
  const originEnv = process.env.ENVIRONMENT;
  beforeEach(() => {
    process.env.ENVIRONMENT = "local";
    vi.resetAllMocks();
  });
  afterEach(() => {
    process.env.ENVIRONMENT = originEnv;
  });
  describe("Staging setup", () => {
    beforeEach(() => {
      process.env.ENVIRONMENT = "staging";
    });
    afterEach(() => {
      process.env.ENVIRONMENT = originEnv;
    });
    test("Customer has several active mandates - it should return true", async () => {
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getCustomerMandateStatus: vi.fn().mockResolvedValue([
          {
            mandateId: "mandate1",
            status: "active",
          },
          {
            mandateId: "mandate2",
            status: "active",
          },
        ]),
      });
      const result = await pspCustomerHasPendingMandate("pspCustomerId");
      expect(result.data?.hasPendingMandate).toBe(true);
    });
  });
  test("Customer has pending mandate - it should return true", async () => {
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getCustomerMandateStatus: vi.fn().mockResolvedValue([
        {
          mandateId: "mandate1",
          status: "active",
        },
        {
          mandateId: "mandate2",
          status: "pending",
        },
      ]),
    });
    const result = await pspCustomerHasPendingMandate("pspCustomerId");
    expect(result.data?.hasPendingMandate).toBe(true);
  });
  test("Customer has no pending mandates", async () => {
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getCustomerMandateStatus: vi.fn().mockResolvedValue([
        {
          mandateId: "mandate1",
          status: "active",
        },
        {
          mandateId: "mandate2",
          status: "inactive",
        },
      ]),
    });
    const result = await pspCustomerHasPendingMandate("pspCustomerId");
    expect(result.data?.hasPendingMandate).toBe(false);
  });
  test("Customer does not exist on third party platform - it should return false", async () => {
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getCustomerMandateStatus: vi.fn().mockResolvedValue([
        {
          mandateId: "mandate1",
          status: "active",
        },
        {
          mandateId: "mandate2",
          status: "inactive",
        },
      ]),
    });
    const result = await pspCustomerHasPendingMandate(undefined);
    expect(result.data?.hasPendingMandate).toBe(false);

    const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock;
    expect(repaymentMock.results.length).toBe(0);
  });
  test("Sad Path - An error ocurred when trying to get mandates", async () => {
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getCustomerMandateStatus: vi.fn().mockRejectedValue(new Error("An error occurred")),
    });
    const result = await pspCustomerHasPendingMandate("pspCustomerId");
    expect(result.error).toBeDefined();
    expect(result.error?.message).toBe("An error occurred");
  });
});
