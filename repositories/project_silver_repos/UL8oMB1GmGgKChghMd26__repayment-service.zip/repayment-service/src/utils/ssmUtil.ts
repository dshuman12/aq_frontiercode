import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";

const ssmClient = new SSMClient({ region: process.env.REGION });
const cache = new Map<string, { value: string; expiry: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

export const getSSMParameter = async (paramName: string): Promise<string> => {
  const cached = cache.get(paramName);
  if (cached && Date.now() < cached.expiry) {
    return cached.value;
  }

  const command = new GetParameterCommand({ Name: paramName, WithDecryption: true });
  const response = await ssmClient.send(command);

  if (!response.Parameter?.Value) {
    throw new Error(`SSM parameter ${paramName} not found or has no value`);
  }

  cache.set(paramName, { value: response.Parameter.Value, expiry: Date.now() + CACHE_TTL_MS });
  return response.Parameter.Value;
};
