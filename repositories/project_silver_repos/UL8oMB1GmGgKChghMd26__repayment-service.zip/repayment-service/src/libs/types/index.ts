import { LambdaEvent } from "hono/aws-lambda";
export * from "./oidcAuth";
export * from "./mambu";

export type RequestContextBindings = {
  event: LambdaEvent & {
    requestContext: {
      authorizer: {
        onmouuid: string;
      };
    };
  };
};

export type DirectDebit = {
  paymentSecret: string;
};

export type DirectDebitHosted = {
  url: string;
};

export type PayByBankHostedSession = {
  url: string;
};

export type DirectDebitError = {
  message: string;
};

export type Customer = {
  customerId: string;
  pspCustomerId?: string;
  accountId: string;
  email: string;
  address: string;
  mambuID: string;
  technicalAccountId?: string;
};

export enum RepaymentType {
  Card = "CARD",
  Bank = "PAY_BY_BANK",
  DirectDebit = "DIRECT_DEBIT",
  DirectDebitRetry = "DIRECT_DEBIT_RETRY",
  CPA = "CPA",
}

export type PayByBankError = {
  message: string;
};

export type IntentError = {
  message: string;
};
