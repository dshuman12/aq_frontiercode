import { RepaymentType } from ".";

export type PaymentEvent = {
  id: string;
  provider: string;
  pspCustomerId: string;
  customerId: string;
  amount: number;
  currency: string;
  status: PaymentEventStatus;
  created: number;
  repaymentType: RepaymentType;
  accountId: string;
  accountType: string;
};

export enum PaymentEventStatus {
  SUCCESS = "success",
  FAILED = "failed",
}
