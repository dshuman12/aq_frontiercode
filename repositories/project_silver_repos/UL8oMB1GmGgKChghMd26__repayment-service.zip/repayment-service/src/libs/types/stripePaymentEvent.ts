export type StripePaymentEvent = {
  id: string;
  object: string;
  type: string;
  data: {
    object: {
      id: string;
      object: string;
      amount: number;
      amount_capturable: number;
      amount_received: number;
      currency: string;
      automatic_payment_method: {
        enabled: boolean;
      };
      status: string;
      client_secret: string;
      created: number;
      metadata: {
        [key: string]: any;
      };
      payment_method: string; // ID
      customer: string; // ID
    };
  };
};
