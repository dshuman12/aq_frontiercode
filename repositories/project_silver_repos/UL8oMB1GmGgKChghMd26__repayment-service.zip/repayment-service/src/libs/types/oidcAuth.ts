import { APIGatewayEvent } from "aws-lambda";

export type accessTokenObject = {
  access_token: string;
  token_id: string;
};

export type APIGatewayEventHandler = { body?: APIGatewayEvent["body"] } & {
  requestContext: {
    authorizer: {
      onmouuid: string;
    };
  };
};

export type APIGatewayEventGet = { pathParameters?: APIGatewayEvent["pathParameters"] } & {
  requestContext: {
    authorizer: {
      onmouuid: string;
    };
  };
};

