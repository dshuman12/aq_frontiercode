import { AWSGlueClient } from "@onmoapp/onmo-glue";

export const deserializeUtil = async (dataString: string, schemaId: string): Promise<any> => {
  const glueClient = new AWSGlueClient();
  const outputData = await glueClient.deserializeWithDataSchema(dataString, {
    SchemaVersionId: schemaId,
  });
  return outputData;
};
