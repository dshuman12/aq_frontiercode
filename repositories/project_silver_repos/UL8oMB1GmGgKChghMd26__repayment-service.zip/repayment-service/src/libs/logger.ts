import { Logger, LogLevel } from "@onmoapp/onmo-logger";

export const getLogger = () =>
  new Logger(
    {
      env: process.env.STAGE,
    },
    process.env.LOGGING_LEVEL as LogLevel,
  );
