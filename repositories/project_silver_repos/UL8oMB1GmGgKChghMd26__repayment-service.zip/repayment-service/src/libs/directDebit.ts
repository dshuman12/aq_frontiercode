import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { AccountGenericData, CreateMandateRepayment } from "@onmoapp/onmo-types";
import { DirectDebitRepaymentDue } from "@shared-types/sqs-types";
import { Customer, RepaymentType } from "@libs/types";
import { getLogger } from "./logger";
import { v4 as uuid } from "uuid";

/**
 * Logic for creating original direct debit payment (not a retry)
 * Will create and confirm a payment intent if the user has a nextDirectDebitAmount > 0
 */
export const createDirectDebitPayment = async ({
  directDebitRepaymentDue,
  accountData,
  customer,
}: {
  directDebitRepaymentDue: DirectDebitRepaymentDue;
  accountData: AccountGenericData;
  customer: Customer;
}): Promise<{ created: boolean }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "createDirectDebit" });
  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  const idempotencyKey = directDebitRepaymentDue.idempotencyKey;

  const { nextDirectDebitAmount, mandateID, amountPreference } = accountData.directDebitSettings;

  if (nextDirectDebitAmount === undefined || nextDirectDebitAmount === null) {
    logger.info(`Next direct debit amount not found. Skipping.`);
    return { created: false };
  }

  if (nextDirectDebitAmount === 0) {
    logger.info("Next direct debit amount is 0. Skipping.");
    return { created: false };
  }

  const amount = Number((nextDirectDebitAmount * 100).toFixed(2));

  if (amount < 30) {
    logger.info({ message: "LowAmount: Amount is less than 30p. Skipping." });
    return { created: false };
  }

  const payload = {
    pspCustomerId: customer.pspCustomerId,
    amount,
    customerId: customer.customerId,
    accountId: customer.accountId,
    accountType: "card",
    mandateId: mandateID,
    idempotencyKey: uuid(),
    originalUserPreference: amountPreference, // needed for retries
    instalmentDate: accountData.installmentDetails.nextInstallmentDate, // needed for retries
    repaymentType: RepaymentType.DirectDebit,
  } as CreateMandateRepayment;
  logger.info({ message: "Creating mandate repayment", payload });
  const { paymentIntentId } = await repaymentClient.createMandateRepayment(payload);

  logger.info({ message: "Payment intention created", paymentIntentId });

  const confirmedPaymentIntention = await repaymentClient.confirmPaymentIntent({
    paymentIntentId,
    idempotencyKey: `${idempotencyKey}-confirm`,
  });

  logger.info({ message: "Confirmed payment intention", confirmedPaymentIntention });
  return { created: true };
};
