export async function errorHandler<T>(fn: () => Promise<{ data: T; error: any }>) {
  try {
    const data = await fn();
    return { data, error: null };
  } catch (error: any) {
    return { data: null, error };
  }
}
