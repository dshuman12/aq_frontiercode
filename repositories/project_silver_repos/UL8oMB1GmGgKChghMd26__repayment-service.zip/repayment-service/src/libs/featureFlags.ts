import { Logger } from "@onmoapp/onmo-logger";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { PostHog } from "posthog-node";

const env = process.env.ENVIRONMENT;

const logger = new Logger({ env });

export const getFeatureFlagClient = async () => {
  const { SecretString: featureFlagSecret } = await getSecret(process.env.POSTHOG_SECRET_ARN);
  const { apiKey, host } = JSON.parse(featureFlagSecret);

  if(!featureFlagSecret) {
    logger.error("Feature flag secret is not defined");
    return null;
  }

  return new PostHog(apiKey, { host });
};

export const isCPAEnabled = async (): Promise<boolean> => {
  try {
    const client = await getFeatureFlagClient();
    if (!client) return false;
    const enabled = await client.isFeatureEnabled("cpa-enabled", "global");
    logger.info({ message: "CPA feature flag check", cpaEnabled: enabled });
    return enabled ?? false;
  } catch (error) {
    logger.error({ message: "Failed to check CPA feature flag", error });
    return false;
  }
};
