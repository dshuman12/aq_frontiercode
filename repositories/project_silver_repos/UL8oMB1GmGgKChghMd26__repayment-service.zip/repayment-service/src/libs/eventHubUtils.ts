import { EventData } from "@onmoapp/onmo-adapters";
import { EventType } from "@onmoapp/event-hub-kinesis-adapter";
import { v4 as uuid } from "uuid";

export type CreateEventPayloadInput = {
  eventType: EventType;
  subType?: string;
  initiatedBy: string;
};

const getSchemaVersionByEventType = (eventType: EventType): string | undefined => {
  switch (eventType) {
    case "RepaymentCollected":
      return process.env.REPAYMENT_COLLECTED_SCHEMA_VERSION;
    case "RepaymentFailed":
      return process.env.REPAYMENT_FAILED_SCHEMA_VERSION;
    case "MandateUpserted":
      return process.env.MANDATE_UPSERTED_SCHEMA_VERSION;
    case "MandateCancelled":
      return process.env.MANDATE_CANCELLED_SCHEMA_VERSION;
    case "DDFailedEligibleForRetry":
      return process.env.DD_FAILED_ELIGIBLE_FOR_RETRY_SCHEMA_VERSION;
    case "CPASubscriptionCreated":
      return process.env.CPA_SUBSCRIPTION_CREATED_SCHEMA_VERSION;
    case "CPASubscriptionCancelled":
      return process.env.CPA_SUBSCRIPTION_CANCELLED_SCHEMA_VERSION;
    default: {
      throw new Error("No matching schema version found for the given event type");
    }
  }
};
export const createEvent = <T>(event: T, payload: CreateEventPayloadInput, idempotencyKey?: string): EventData<T> => {
  const id = uuid();
  const correlationId = uuid();

  return {
    id,
    idempotencyKey: idempotencyKey || id,
    correlationId,
    event: payload.eventType,
    subtype: payload.subType,
    source: process.env.SERVICE_NAME,
    schemaVersion: getSchemaVersionByEventType(payload.eventType),
    created: new Date().toISOString(),
    initiatedBy: payload.initiatedBy,
    eventData: event,
  } as EventData<T>;
};
