type FormatJSONResponseInput<T> = {
  statusCode: number;
  body: T;
  headers?: Record<string, string>;
};

const baseJSONHeaders = {
  "Content-Type": "application/json",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
};

export const formatJSONResponse = <T>({ statusCode, body, headers = {} }: FormatJSONResponseInput<T>) => {
  return {
    statusCode,
    body,
    headers: { ...baseJSONHeaders, ...headers },
  };
};
