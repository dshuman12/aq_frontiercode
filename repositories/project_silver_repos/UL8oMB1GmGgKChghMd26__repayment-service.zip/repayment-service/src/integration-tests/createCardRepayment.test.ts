import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { handler } from "../functions/createCardRepayment/createCardRepayment";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { updateCustomer, getCustomer } from "src/utils/db";
import { fetchAPISecret, invokeFullLock } from "src/utils/testutils";
import { UserCredentials } from "src/utils/testTypes";

// The two tests marked with concurrent will be run in parallel
describe("Cards", () => {
  test("returns 500 if customer does not exist", async () => {
    const result = await handler({
      body: JSON.stringify({ amount: 100 }),
      requestContext: {
        authorizer: {
          onmouuid: "nonexistent-customer",
        },
      },
    });
    expect(result.statusCode).toBe(500);
  });

  describe("With customer setup", () => {
    let customer: UserCredentials;

    beforeEach(async () => {
      customer = await setUpTestCreditCustomerAccount();
    });

    afterEach(async () => {
      await deleteTestCreditCustomerAccount(customer);
    });

    test("returns paymentSecret if user already exists", async () => {
      const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

      // create a payment-intent for the customer before going to handler,
      // to simulate the customer already existing
      const pspUser = await repaymentClient.createCustomer({
        customerId: customer.customerId,
        email: "",
        firstName: "",
        accountId: "account-id",
      });

      await updateCustomer(customer.customerId, pspUser.pspCustomerId);
      const updatedCustomer = await getCustomer(customer.customerId);

      expect(updatedCustomer.data.pspCustomerId).toBe(pspUser.pspCustomerId);

      const result = await handler({
        body: JSON.stringify({ amount: 100 }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });
      expect(result.body.paymentSecret).toBeDefined();
      expect(result.body.ephemeralKey).toBeDefined();
      expect(result.body.pspCustomerId).toBeDefined();
    });

    test("returns client secret if user does exist", async () => {
      const result = await handler({
        body: JSON.stringify({ amount: 100 }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });
      expect(result.body.paymentSecret).toBeDefined();
    });

    test("returns 400 if payment amount is less than .50", async () => {
      const result = await handler({
        body: JSON.stringify({ amount: 0.49 }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });
      expect(result.statusCode).toBe(400);
    });

    test("returns 400 if body is invalid", async () => {
      const result = await handler({
        body: JSON.stringify({}),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });
      expect(result.statusCode).toBe(400);
    });

    // This test is mostly testing if bankingClient.getCreditAccount is working.
    // and whether or not it exposes an error. This is outside of scope for this
    // test suite, as it's an implementation detail but may be useful for debugging.
    test.skip("repayment fails if creditAccount cannot be found", async () => {
      const secretKey = await fetchAPISecret();
      const invokedLock = await invokeFullLock(customer.creditAccountId, secretKey);

      expect(invokedLock.status).toBe(200);

      const result = await handler({
        body: JSON.stringify({ amount: 100 }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });

      expect(result.statusCode).toBe(500);
    });
    test.skip("repayment is blocked if account is locked", async () => {
      // const repaymentClient = await coreRepaymentsAdapter('STRIPE_CLIENT')
      const secretKey = await fetchAPISecret();
      const invokedLock = await invokeFullLock(customer.creditAccountId, secretKey);

      expect(invokedLock.status).toBe(200);

      const result = await handler({
        body: JSON.stringify({ amount: 100 }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });
      expect(result.statusCode).toBe(400);
      expect(result.message).toBe("Bad Request");
    });
  });
});
