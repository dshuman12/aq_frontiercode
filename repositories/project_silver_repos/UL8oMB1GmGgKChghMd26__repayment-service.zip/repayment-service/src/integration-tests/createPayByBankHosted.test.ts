import { describe, expect, afterEach, beforeEach, test } from "vitest";
import { handler } from "../functions/createPayByBankHosted/createPayByBankHosted";
import { setUpTestCreditCustomerAccount, deleteTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { PayByBankHostedSession } from "@libs/types";

describe("Create Pay By Bank hosted", () => {
  let customer: UserCredentials;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  afterEach(async () => {
    await deleteTestCreditCustomerAccount(customer);
  });

  test("returns a 200", async () => {
    const event = {
      body: JSON.stringify({
        amount: 11,
        paymentPreference: "CUSTOM_AMOUNT",
        successUrl: "https://example.com/success",
        cancelUrl: "https://example.com/cancel",
      }),
      requestContext: {
        authorizer: { onmouuid: customer.customerId },
      },
    };
    const result = await handler(event);
    expect(result.statusCode).toBe(200);
    const body: PayByBankHostedSession = result.body;
    expect(body.url.startsWith("https://checkout.stripe.com/c/pay/")).toBeTruthy();
  });
});
