import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { deleteHandler } from "../functions/deleteDirectDebit/deleteDirectDebit";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { BASE_PATH } from "@libs/constants";

describe.skip("DeleteDirectDebit", () => {
  let customer: UserCredentials;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  afterEach(async () => {
    await deleteTestCreditCustomerAccount(customer);
  });

  test.skip("Delete a mandate returns 200", async () => {
    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    const paymentMethod = await repaymentClient.createCustomerPaymentMethod({
      customerId: "444",
      pspCustomerId: customer.pspCustomerId,
      paymentMethodId: "pm_card_visa",
    });

    const result = await deleteHandler.request(
      `/${BASE_PATH}/next/direct-debit/${paymentMethod.paymentMethodId}`,
      {
        method: "DELETE",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: customer.customerId,
            },
          },
        },
      },
    );

    expect(result.status).toBe(200);
  });

  test.skip("returns 500 if customer does not exist", async () => {
    const result = await deleteHandler.request(
      `/${BASE_PATH}/next/direct-debit/123`,
      {
        method: "DELETE",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: "non-existent-customer",
            },
          },
        },
      },
    );

    expect(result.status).toBe(500);
  });
});
