import { afterAll, beforeAll, describe, expect, test } from "vitest";
import { handler } from "../functions/directDebitRepaymentProcessor/directDebitRepaymentProcessor";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { ScheduledEvent } from "aws-lambda";

describe.skip("Direct Debit Repayment Processor", () => {
  // too flaky for now, need to set up proper test account with a proper schedule
  let customer: UserCredentials;

  beforeAll(async () => {
    console.log("test user created");
    customer = await setUpTestCreditCustomerAccount();
  });

  afterAll(async () => {
    console.log("test user deleted");
    await deleteTestCreditCustomerAccount(customer);
  });

  test("returns a confirmed payment intent", async () => {
    const response = await handler({
      detail: JSON.stringify({
        loan_account_id: "1234",
        customerId: "test-repayments-c799971a-b667-44ea-9050-0bd9a627ff30",
        payment_date: "2021-09-01",
      }),
    } as ScheduledEvent);

    expect(response).toBeDefined();
  });
});
