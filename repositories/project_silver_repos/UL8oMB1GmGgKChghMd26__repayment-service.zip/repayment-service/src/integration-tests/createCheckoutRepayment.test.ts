import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { handler } from "../functions/createCheckoutRepayment/createCheckoutRepayment";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { updateCustomer, getCustomer } from "src/utils/db";
import { UserCredentials } from "src/utils/testTypes";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { getSecret } from "@onmoapp/onmo-secrets-manager";

// The two tests marked with concurrent will be run in parallel
describe("Checkout", () => {
  test("returns 500 if customer does not exist", async () => {
    const result = await handler({
      body: JSON.stringify({
        amount: 100,
        uiMode: "embedded",
        paymentMethods: ["pay_by_bank"],
        return_url: "onmoapp://PayByBankSession",
      }),
      requestContext: {
        authorizer: {
          onmouuid: "non-existent-customer",
        },
      },
    });
    expect(result.statusCode).toBe(500);
  });

  describe("With customer setup", () => {
    let customer: UserCredentials;

    beforeEach(async () => {
      customer = await setUpTestCreditCustomerAccount();
    });

    afterEach(async () => {
      await deleteTestCreditCustomerAccount(customer);
    });

    describe("Input validation", () => {
      test("returns 400 if payment amount is less than .50", async () => {
        const result = await handler({
          body: JSON.stringify({ amount: 49 }),
          requestContext: {
            authorizer: {
              onmouuid: customer.customerId,
            },
          },
        });
        expect(result.statusCode).toBe(400);
      });

      test("returns 400 if body is invalid", async () => {
        const result = await handler({
          body: JSON.stringify({}),
          requestContext: {
            authorizer: {
              onmouuid: customer.customerId,
            },
          },
        });
        expect(result.statusCode).toBe(400);
      });

      test("returns 400 if return_url not provided in embedded mode", async () => {
        const result = await handler({
          body: JSON.stringify({
            amount: 100,
            uiMode: "embedded",
            paymentMethods: ["pay_by_bank"],
          }),
          requestContext: {
            authorizer: {
              onmouuid: "non-existent-customer",
            },
          },
        });
        expect(result.statusCode).toBe(400);
      });

      test("returns 400 if success_url not provided in hosted mode", async () => {
        const result = await handler({
          body: JSON.stringify({
            amount: 100,
            uiMode: "hosted",
            paymentMethods: ["pay_by_bank"],
          }),
          requestContext: {
            authorizer: {
              onmouuid: "non-existent-customer",
            },
          },
        });
        expect(result.statusCode).toBe(400);
      });
    });

    test("returns clientSecret if user already exists", async () => {
      const env = "staging";
      const { SecretString: stripeSecretString } = await getSecret(`onmo-stripe-${env}`);
      const { secretKey } = JSON.parse(stripeSecretString);
      const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
        stageName: env,
        configuration: {
          secretAccessKey: secretKey,
        },
      });

      // create a payment-intent for the customer before going to handler,
      // to simulate the customer already existing
      const pspUser = await repaymentClient.createCustomer({
        customerId: customer.customerId,
        email: "",
        firstName: "",
        accountId: "account-id",
      });

      await updateCustomer(customer.customerId, pspUser.pspCustomerId);
      const updatedCustomer = await getCustomer(customer.customerId);

      expect(updatedCustomer.data.pspCustomerId).toBe(pspUser.pspCustomerId);

      const result = await handler({
        body: JSON.stringify({
          amount: 100,
          uiMode: "embedded",
          paymentMethods: ["pay_by_bank"],
          return_url: "onmoapp://PayByBankSession",
        }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });

      expect(result.body.sessionId).toBeDefined();
      expect(result.body.clientSecret).toBeDefined();
    });

    test("returns client secret if user does exist", async () => {
      const result = await handler({
        body: JSON.stringify({
          amount: 100,
          uiMode: "embedded",
          paymentMethods: ["pay_by_bank"],
          return_url: "onmoapp://PayByBankSession",
        }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });

      expect(result.body.sessionId).toBeDefined();
      expect(result.body.clientSecret).toBeDefined();
    });

    test("returns session url for hosted mode", async () => {
      const result = await handler({
        body: JSON.stringify({
          amount: 100,
          uiMode: "hosted",
          paymentMethods: ["pay_by_bank"],
          success_url: "onmoapp://PayByBankSession",
        }),
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });

      expect(result.body.sessionId).toBeDefined();
      expect(result.body.url).toBeDefined();
    });
  });
});
