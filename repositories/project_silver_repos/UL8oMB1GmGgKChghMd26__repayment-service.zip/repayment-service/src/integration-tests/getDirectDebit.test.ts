import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { directDebitHandler } from "../functions/getDirectDebit/getDirectDebit";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { BASE_PATH } from "@libs/constants";

describe("CreateCardRepayment", () => {
  let customer: UserCredentials;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  afterEach(async () => {
    await deleteTestCreditCustomerAccount(customer);
  });

  test("Delete a mandate returns 200", async () => {
    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    const paymentMethod = await repaymentClient.createCustomerPaymentMethod({
      customerId: "444",
      pspCustomerId: customer.pspCustomerId,
      paymentMethodId: "pm_card_visa",
    });

    const result = await directDebitHandler.request(
      `/${BASE_PATH}/next/direct-debit/${paymentMethod.paymentMethodId}`,
      {
        method: "GET",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: customer.customerId,
            },
          },
        },
      },
    );

    expect(result.status).toBe(200);
  });

  test("returns 401 if customer does not exist", async () => {
    const result = await directDebitHandler.request(
      `/${BASE_PATH}/next/direct-debit/123`,
      {
        method: "GET",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: "nonexistent-customer",
            },
          },
        },
      },
    );

    expect(result.status).toBe(500);
  });

  test("returns 404", async () => {
    const result = await directDebitHandler.request(
      `/${BASE_PATH}/next/direct-debit/123`,
      {
        method: "GET",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: customer.customerId,
            },
          },
        },
      },
    );

    expect(result.status).toBe(500);
  });
});
