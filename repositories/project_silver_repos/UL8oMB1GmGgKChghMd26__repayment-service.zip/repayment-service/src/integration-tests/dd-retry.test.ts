import { DD_RETRY_NAME_PREFIX, PROD_WAIT_SCHEDULE_GROUP_NAME } from "@libs/constants";
import { createDirectDebitPayment } from "@libs/directDebit";
import { coreBankingAdapter, coreRepaymentsAdapter, StripeClient } from "@onmoapp/onmo-adapters";
import { AccountGenericData, CreateMandateRepayment } from "@onmoapp/onmo-types";
import { getCustomer } from "@utils/db";
import {
  findAndDeleteSchedule,
  findAndGetSchedulePayload,
  findAndTriggerSchedule,
  scheduleExists,
} from "@utils/schedulerUtil";
import dayjs from "dayjs";
import { beforeAll, describe, expect, test } from "vitest";
import { v4 as uuid } from "uuid";
import { DirectDebitRetryProcessorEvent } from "@shared-types/sqs-types";
import { RepaymentType } from "@libs/types";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const setMandateOnPaymentIntent = async (paymentIntentId: string, mandateId: string, accountId: string) => {
  console.info(`Attempting to update payment intent ${paymentIntentId} with mandate ${mandateId}`);
  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  await coreBankingClient.updateDirectDebitSettingsOnAccount(accountId, {
    directDebitSettings: {
      mandateID: mandateId,
    },
  });
  console.info(`Mandate ID updated successfully with ${mandateId}`);
};

const resetTestAccount = async (accountId: string, failingMandate: string) => {
  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  const { data: details } = await coreBankingClient.getCreditAccount(accountId);
  const ddSettings = details.directDebitSettings;
  if (
    !!ddSettings.directDebitAvoidFeeCutOffDate &&
    !!ddSettings.directDebitPreventRetryDate &&
    !!ddSettings.directDebitRetryDate
  ) {
    const res = await coreBankingClient.updateDDRetryFields(accountId, false, null, null, null);
    if (res.error) {
      throw new Error(`Failed to reset test account: ${res.error}`);
    }
  } else {
    console.info("No need to reset retry flags");
  }

  if (ddSettings.mandateID !== failingMandate) {
    console.log("Setting mandate to failing one.");
    const res = await coreBankingClient.updateDirectDebitSettingsOnAccount(accountId, {
      directDebitSettings: {
        mandateID: failingMandate,
      },
    });
    if (res.error) {
      throw new Error(`Failed to reset mandate ID on account: ${res.error}`);
    }
  }

  if (ddSettings.scheduledDirectDebitAmount) {
    const res = await coreBankingClient.setScheduledAmount(accountId, 0);
    if (res.error) {
      throw new Error(`Failed to reset DD scheduled amount on account: ${res.error}`);
    }
  }

  await findAndDeleteSchedule({
    accountId,
    namePrefix: "prod-wait",
    groupName: PROD_WAIT_SCHEDULE_GROUP_NAME,
  });

  if (!details.accountBalances.totalNextMinimumPaymentDue) {
    // Need to adjust some repayments to put it back in a state where money is owed
    const dateFrom = dayjs().subtract(14, "day").toISOString();
    const { data: transactionsRes } = await coreBankingClient.getTransactionsInDateRange({
      accountId,
      dateFrom,
      dateTo: dayjs().toISOString(),
      limit: 50,
    });
    console.log(transactionsRes.transactions);

    const transactions = transactionsRes.transactions;
    const transactionsToAdjust = transactions.filter(
      (t) =>
        t.adjustmentTransactionKey === null &&
        (t.onmoTransactionType === "REPAYMENT" || t.onmoTransactionType === "REPAYMENT - STRIPE_DD"),
    );

    if (transactionsToAdjust.length === 0) {
      throw new Error("No transactions found to adjust. Try subtracting more days or reset the account manually.");
    }

    console.log(`Found ${transactionsToAdjust.length} transactions to adjust`);
    await Promise.all(
      transactionsToAdjust.map((transactionToAdjust) =>
        coreBankingClient.adjustTransactionByTransactionId(
          transactionToAdjust.coreBankingTransactionId,
          "reset from integration tests repayment-service",
        ),
      ),
    );
    await sleep(1000);
  }
};

const hasDirectDebitSettings = (accountDetails: AccountGenericData) => {
  return (
    !!accountDetails.directDebitSettings &&
    !!accountDetails.directDebitSettings.amountPreference &&
    !!accountDetails.directDebitSettings.mandateID &&
    !!accountDetails.directDebitSettings.mandateReference
  );
};

const hasDDRetrySettings = (accountDetails: AccountGenericData) => {
  const ddSettings = accountDetails.directDebitSettings;
  return (
    !!ddSettings.directDebitAvoidFeeCutOffDate &&
    !!ddSettings.directDebitPreventRetryDate &&
    !!ddSettings.directDebitRetryDate &&
    ddSettings.directDebitRetryInProgress
  );
};

describe.skip("Direct Debit Retry integration tests", () => {
  const accountId = "AAIV308"; // set with mandate to trigger insufficient funds error immediately (no wait)
  const customerId = "a5ff4619-d5db-4a52-ad35-dde205cbc5a3";
  const failingMandate = "mandate_1RThoORp1KcrfXlPz3oZZzem";
  const successMandate = "mandate_1RRLu7Rp1KcrfXlPRjkVhL1L";

  beforeAll(async () => {
    console.info(`Resetting test account ${accountId}...`);
    await resetTestAccount(accountId, failingMandate);
  });

  test(
    "Happy Path",
    async () => {
      const secrets = await StripeClient.retrieveSecrets("staging");
      const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
      const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

      const { data } = await coreBankingClient.getCreditAccount(accountId);
      console.log(data);
      expect(hasDirectDebitSettings(data)).toBe(true);

      const customer = await getCustomer(data.accountDetails.customerId);
      const canTestFullFlow = !!data.directDebitSettings.nextDirectDebitAmount;

      if (canTestFullFlow) {
        const res = await createDirectDebitPayment({
          accountData: data,
          customer: customer.data,
          directDebitRepaymentDue: {
            accountId,
            customerId,
            dueDate: "not-needed-for-creating-dd",
            idempotencyKey: uuid(),
          },
        });
        if (!res.created) {
          throw new Error("Failed to create direct debit payment");
        }
      } else {
        // nextDirectDebitAmount is most likely null so we need to create a payment intent with a hardcoded amount
        // to still trigger the retry flow
        const { data: accountData } = await coreBankingClient.getCreditAccount(accountId);

        const payload = {
          accountId,
          mandateId: failingMandate,
          accountType: "card",
          amount: 1000, // this is in pence
          customerId,
          idempotencyKey: uuid(),
          instalmentDate: accountData?.installmentDetails?.nextInstallmentDate,
          originalUserPreference: accountData.directDebitSettings.amountPreference,
          pspCustomerId: customer.data.pspCustomerId,
          repaymentType: RepaymentType.DirectDebit,
        } as CreateMandateRepayment;

        console.info("Preparing payload for DD repayment", payload);
        const res = await repaymentClient?.createMandateRepayment(payload);
        console.info(`Created payment: ${res?.paymentIntentId} ${res?.status}`);
        if (!res?.paymentIntentId) {
          throw new Error("No payment intent ID found");
        }
        await repaymentClient?.confirmPaymentIntent({ paymentIntentId: res?.paymentIntentId, idempotencyKey: uuid() });
      }

      console.info("Waiting for Kinesis to pick up and process the event...");
      await sleep(0.5 * 60 * 1000);

      if (secrets.ddRetryProdWait || secrets.ddRetryBypassDateInFutureAccounts.includes(accountId)) {
        await findAndTriggerSchedule({
          groupName: PROD_WAIT_SCHEDULE_GROUP_NAME,
          namePrefix: `prod-wait-${accountId}`,
          accountId,
        });
        console.info("Bypassing prod wait schedule for DD repayment...");
        await sleep(1 * 60 * 1000);
      }

      console.info(
        "Direct debit payment created. It should fail immediately, waiting 3min for kinesis to pick it up and update Mambu accordingly...",
      );

      await sleep(3 * 60 * 1000);

      const { data: afterFailureData } = await coreBankingClient.getCreditAccount(accountId);
      expect(hasDDRetrySettings(afterFailureData)).toBe(true);

      await expect(
        scheduleExists({
          groupName: process.env.DD_RETRY_GROUP_NAME,
          namePrefix: `${DD_RETRY_NAME_PREFIX}-${accountId}`,
        }),
      ).toBeTruthy();

      const payload = await findAndGetSchedulePayload<DirectDebitRetryProcessorEvent>({
        groupName: process.env.DD_RETRY_GROUP_NAME,
        namePrefix: DD_RETRY_NAME_PREFIX,
        accountId,
      });

      expect(payload.accountId).toBe(accountId);
      expect(payload.customerId).toBe(customerId);
      expect(payload.paymentIntentId).toBeDefined();

      console.log("Updating mandate to use the working one");
      await setMandateOnPaymentIntent(payload.paymentIntentId, successMandate, accountId);

      console.log("Triggering retry schedule early...");
      await findAndTriggerSchedule({
        groupName: process.env.DD_RETRY_GROUP_NAME,
        namePrefix: DD_RETRY_NAME_PREFIX,
        accountId,
      });

      console.info("Waiting for the retry to be processed...");
      await sleep(3.5 * 60 * 1000);
      console.info("Waiting done. Checking processing result...");

      const paymentIntent = await repaymentClient.getPaymentIntent(payload.paymentIntentId);
      const { data: afterRetryInitiated } = await coreBankingClient.getCreditAccount(accountId);
      const baseCurrencyAmount = Number((paymentIntent.amount / 100).toFixed(2));
      expect(baseCurrencyAmount).toBe(afterRetryInitiated.directDebitSettings.scheduledDirectDebitAmount);
      expect(paymentIntent.metadata.repaymentType).toBe("DIRECT_DEBIT_RETRY");

      const res = await scheduleExists({
        groupName: process.env.DD_RETRY_GROUP_NAME,
        namePrefix: `${DD_RETRY_NAME_PREFIX}-${accountId}`,
      });
      expect(res).toBeFalsy();

      if (secrets.ddRetryProdWait || secrets.ddRetryBypassDateInFutureAccounts.includes(accountId)) {
        await findAndTriggerSchedule({
          groupName: PROD_WAIT_SCHEDULE_GROUP_NAME,
          namePrefix: `prod-wait-${accountId}`,
          accountId,
        });
        console.info("Bypassing prod wait schedule for DD retry repayment...");
        await sleep(1 * 60 * 1000);
      }

      console.info("Waiting for the retry to be processed...");
      await sleep(3 * 60 * 1000);

      const { data: afterRetryDone } = await coreBankingClient.getCreditAccount(accountId);
      expect(hasDDRetrySettings(afterRetryDone)).toBe(false);

      const { data: transactionData } = await coreBankingClient.findCreditAccountTransactionsByExternalId(
        accountId,
        payload.paymentIntentId,
      );
      expect(transactionData).toBeDefined();
      expect(transactionData.transactions).toBeDefined();
      expect(transactionData.transactions.length).toBeGreaterThan(0);
      expect(afterRetryDone.directDebitSettings.scheduledDirectDebitAmount).toBeNull();
    },
    15 * 60 * 1000,
  );
});
