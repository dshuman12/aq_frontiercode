import { describe, expect, afterEach, beforeEach, test } from "vitest";
import { handler } from "../functions/createDirectDebitHosted/createDirectDebitHosted";
import { setUpTestCreditCustomerAccount, deleteTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { updateCustomer, getCustomer } from "src/utils/db";
import { fetchAPISecret, invokeFullLock } from "src/utils/testutils";
import { DirectDebitHosted } from "@libs/types";

// The two tests marked with concurrent will be run in parallel
describe("Create Direct Debit Hosted", () => {
  let customer: UserCredentials;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  afterEach(async () => {
    await deleteTestCreditCustomerAccount(customer);
  });

  test("returns a 200", async () => {
    const result = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(200);
    const body = result.body as DirectDebitHosted;
    expect(body.url).toBeDefined();
  });

  test("returns a 200 if cancelUrl is not passed", async () => {
    const result = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
      }),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(200);
    const body = result.body as DirectDebitHosted;
    expect(body.url).toBeDefined();
  });

  test("returns a 400 if the returlUrl is not a valid url", async () => {
    const result = await handler({
      body: JSON.stringify({
        successUrl: "example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(400);
  });

  test("returns a paymentSecret if user already exists", async () => {
    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    // create a payment-intent for the customer before going to handler,
    // to simulate the customer already existing
    const pspUser = await repaymentClient.createCustomer({
      customerId: customer.customerId,
      email: "",
      address: "",
      accountId: "account-id",
    });

    await updateCustomer(customer.customerId, pspUser.pspCustomerId);
    const updatedCustomer = await getCustomer(customer.customerId);

    expect(updatedCustomer.data.pspCustomerId).toBe(pspUser.pspCustomerId);
    const result = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(200);
    const body = result.body as DirectDebitHosted;
    expect(body.url).toBeDefined();
  });

  test("returns 400 if body is invalid", async () => {
    const result = await handler({
      body: JSON.stringify({}),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(400);
  });

  test.skip("repayment is blocked if account is locked", async () => {
    const secretKey = await fetchAPISecret();
    const invokedLock = await invokeFullLock(customer.creditAccountId, secretKey);

    expect(invokedLock.status).toBe(200);

    const result = await handler({
      body: JSON.stringify({ returnUrl: "https://example.com" }),
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });
    expect(result.statusCode).toBe(500);
  });
});
