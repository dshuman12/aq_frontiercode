import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { handler } from "../functions/cards/cards";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";

// The two tests marked with concurrent will be run in parallel
describe("CreateCardRepayment", () => {
  test("returns 500 if customer does not exist", async () => {
    const result = await handler({
      body: "",
      requestContext: {
        authorizer: {
          onmouuid: "nonexistent-customer",
        },
      },
    });
    expect(result.statusCode).toBe(500);
  });

  describe("With customer setup", () => {
    let customer: UserCredentials;

    beforeEach(async () => {
      customer = await setUpTestCreditCustomerAccount();
    });

    afterEach(async () => {
      await deleteTestCreditCustomerAccount(customer);
    });

    test("returns cards attached to customer", async () => {
      const stripeClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

      await stripeClient.createCustomerPaymentMethod({
        customerId: customer.customerId,
        pspCustomerId: customer.pspCustomerId,
        paymentMethodId: "pm_card_visa",
      });

      const result = await handler({
        body: "",
        requestContext: {
          authorizer: {
            onmouuid: customer.customerId,
          },
        },
      });

      expect(result.body.paymentMethods.length).toBeGreaterThan(0);
    });
  });
});
