import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { directDebitHandler } from "../functions/directDebits/directDebits";
import { generateAccessTokenOfTestUser, deleteAccessTokenOfTestUser } from "src/utils/oidcAuthToken";
import { accessTokenObject } from "@libs/types";
import { BASE_PATH } from "@libs/constants";

describe.skip("DirectDebits", () => {
  // This isn't stable enough and causes the CI to fail too much
  const customerId = "test-repayments-c799971a-b667-44ea-9050-0bd9a627ff30";
  let accessToken: accessTokenObject;

  beforeEach(async () => {
    // customer = await setUpTestCreditCustomerAccount();
    accessToken = await generateAccessTokenOfTestUser(customerId);
  });

  afterEach(async () => {
    deleteAccessTokenOfTestUser(customerId, accessToken);
    // await deleteTestCreditCustomerAccount(customer);
  });

  // NOTE: This test uses an account that has a payment method created via form.
  // I don't know how to trigger it otherwise. If this test fails, it's likely
  // because the test account has been deleted.
  test("getting direct-debits returns direct-debits", async () => {
    const result = await directDebitHandler.request(
      `/${BASE_PATH}/next/direct-debit`,
      {
        method: "GET",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: customerId,
            },
          },
        },
      },
    );

    expect(result.status).toBe(200);
    // TODO: give this payment method a correct type
    const { paymentMethods }: any = await result.json();
    expect(paymentMethods.length).toBeGreaterThan(0);
  });

  test("returns 404 if customer does not exist", async () => {
    const result = await directDebitHandler.request(
      `/${BASE_PATH}/next/direct-debit/123`,
      {
        method: "GET",
      },
      {
        event: {
          requestContext: {
            authorizer: {
              onmouuid: "non-existent-customer",
            },
          },
        },
      },
    );

    expect(result.status).toBe(404);
  });
});
