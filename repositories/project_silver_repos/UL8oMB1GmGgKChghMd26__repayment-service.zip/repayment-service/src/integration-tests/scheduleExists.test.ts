import { describe, expect, test } from "vitest";

import { directDebitScheduleExists } from "@functions/directDebitRepaymentScheduler/directDebitScheduleExists";
import { RepaymentType } from "@libs/types";

describe("scheduleExists", () => {
  const accountId = "ABD123";

  describe("When the schedule exists", () => {
    test("It should return true", async () => {
      const result = await directDebitScheduleExists(accountId, RepaymentType.DirectDebit);
      expect(result).toBeTruthy();
    });
  });
  describe("When the schedule does not exist", () => {
    test("It should return false", async () => {
      const result = await directDebitScheduleExists("non_existent_account_id", RepaymentType.DirectDebit);
      expect(result).toBeFalsy();
    });
  });
});
