import { afterAll, beforeAll, describe, expect, test } from "vitest";
import { handler } from "../functions/generatePaymentLink/generatePaymentLink";
import { v4 as uuid } from "uuid";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { fetchAPISecret, invokeFullLock } from "src/utils/testutils";
import { Logger } from "@onmoapp/onmo-logger";

const env = process.env.ENVIRONMENT;
const logger = new Logger({ env });

describe("generatePaymentLink", () => {
  let userCredentials;

  beforeAll(async () => {
    console.log("test user created");
    userCredentials = await setUpTestCreditCustomerAccount(false);
  });

  afterAll(async () => {
    console.log("test user deleted");
    await deleteTestCreditCustomerAccount(userCredentials);
  });

  test("AccountID is missing", async () => {
    const response = await handler({
      body: JSON.stringify({
        amount: 4500,
        onmouuid: "1234",
        channelId: "repayment_channel",
      }),
    } as any);

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "Account id is required",
    });
  });

  test("AccountId is empty", async () => {
    const response = await handler({
      body: JSON.stringify({ amount: 4500, accountId: "", onmouuid: "1234", channelId: "repayment_channel" }),
    } as any);

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "Account id can not be empty",
    });
  });

  test("Onmouuid is missing", async () => {
    const response = await handler({
      body: JSON.stringify({ amount: 4500, accountId: "XXXXXXX", onmouuid: "1234", channelId: "repayment_channel" }),
    } as any);

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "onmouuid must be a valid UUID",
    });
  });

  test("Amount is negative", async () => {
    const response = await handler({
      body: JSON.stringify({ amount: -2500, accountId: "XXXXXXX", onmouuid: uuid(), channelId: "repayment_channel" }),
    } as any);

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "The minimum amount required to pay via the link is £0.50. Please enter a minimum value of 50",
    });
  });

  test("AccountId mismatched", async () => {
    const { customerId } = userCredentials;
    const response = await handler({
      body: JSON.stringify({ amount: 5000, accountId: "XYZ", onmouuid: customerId, channelId: "repayment_channel" }),
    } as any);

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "Account ID does not match the onmouuid",
    });
  });

  test("success - generate payment link - not exist user", async () => {
    console.log("userCredentials success:= ", userCredentials);
    const { creditAccountId, customerId } = userCredentials;

    const response = await handler({
      body: JSON.stringify({
        amount: 5000,
        accountId: creditAccountId,
        onmouuid: customerId,
        channelId: "repayment_channel",
      }),
    } as any);

    expect(response.statusCode).toBe(200);
    expect(response.body.url.startsWith("https://buy.stripe.com/test")).toBeTruthy();
  }, 30000);

  test("Account has FULL_LOCK", async () => {
    console.log("userCredentials full-lock := ", userCredentials);
    const { creditAccountId, customerId } = userCredentials;

    const secretKey = await fetchAPISecret();
    await invokeFullLock(creditAccountId, secretKey);

    const response = await handler({
      body: JSON.stringify({
        amount: 5000,
        accountId: creditAccountId,
        onmouuid: customerId,
        channelId: "repayment_channel",
      }),
    } as any);

    logger.info({ response });

    expect(response.statusCode).toBe(400);
    expect(response.body).toEqual({
      message: "Can not generate payment link because the account has a FULL_LOCK",
    });
  }, 30000);
});
