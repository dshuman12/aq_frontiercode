import { describe, expect, test, beforeEach } from "vitest";
import { setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import { generateAccessTokenOfTestUser } from "src/utils/oidcAuthToken";
import { accessTokenObject } from "@libs/types";
import { handler } from "../functions/deleteMandate/deleteMandate";

const customerId = "test-repayments-c799971a-b667-44ea-9050-0bd9a627ff30";

describe.skip("DeleteMandate", () => {
  let customer: UserCredentials;
  let accessToken: accessTokenObject;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  beforeEach(async () => {
    accessToken = await generateAccessTokenOfTestUser(customerId);
  });

  // NOTE: In order to test this, you need to create a mandate.
  // Using the stripe dashbaord.
  test.skip("Delete a mandate returns 200", async () => {
    const result = await handler({
      pathParameters: {
        mandateId: "mandate_1QguPgRp1KcrfXlPCYaE9K5I",
      },
      requestContext: {
        authorizer: {
          onmouuid: customerId,
        },
      },
    });

    expect(result.statusCode).toBe(200);
  });
});
