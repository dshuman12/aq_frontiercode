import { describe, expect, test, beforeEach, afterEach } from "vitest";
import { deleteTestCreditCustomerAccount, setUpTestCreditCustomerAccount } from "src/utils/customerAccountUtils";
import { UserCredentials } from "src/utils/testTypes";
import PaymentMethodByMandateIdHandler from "@functions/getPaymentMethodByMandateId/getPaymentMethodByMandateId";

describe("CreateCardRepayment", () => {
  let customer: UserCredentials;

  beforeEach(async () => {
    customer = await setUpTestCreditCustomerAccount();
  });

  afterEach(async () => {
    await deleteTestCreditCustomerAccount(customer);
  });

  test("returns a 200", async () => {
    const result = await PaymentMethodByMandateIdHandler({
      pathParameters: {
        mandateId: "mandate_1QfPCLRp1KcrfXlPOYBKRkOz",
      },
      requestContext: {
        authorizer: {
          onmouuid: "stripe-account-with-mandate-17cd3c1a-d455-4700-845b-ef02ef4d1bb0",
        },
      },
    });

    expect(result.statusCode).toBe(200);
    expect(result.body.directDebitDetails).toBeDefined();
  });

  test("returns a 401 if customer does not exist", async () => {
    const result = await PaymentMethodByMandateIdHandler({
      pathParameters: {
        mandateId: "mandate_1QQX04Rp1KcrfXlPFaqjKZ2d",
      },
      requestContext: {
        authorizer: {
          onmouuid: "nonexistent-customer",
        },
      },
    });

    expect(result.statusCode).toBe(404);
  });

  test("returns 404 if mandate isn't found", async () => {
    const result = await PaymentMethodByMandateIdHandler({
      pathParameters: {
        mandateId: "nonexistent-mandate",
      },
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });

    expect(result.statusCode).toBe(404);
  });

  test("returns a 404 if validated user doesn't own the mandate", async () => {
    const result = await PaymentMethodByMandateIdHandler({
      pathParameters: {
        mandateId: "mandate_1QQX04Rp1KcrfXlPFaqjKZ2d",
      },
      requestContext: {
        authorizer: {
          onmouuid: customer.customerId,
        },
      },
    });

    expect(result.statusCode).toBe(404);
  });
});
