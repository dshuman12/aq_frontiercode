import { vi } from "vitest";

// Mock handler-middleware to be a passthrough in tests.
// The middleware wraps handlers with ALS context + tracing which requires
// @onmoapp/logger runtime — not needed in unit tests.
vi.mock("@onmoapp/handler-middleware", () => ({
  createApiHandler: (name: string) => ({
    use: () => ({ handle: (fn: any) => fn }),
    handle: (fn: any) => fn,
  }),
  createEventHandler: (name: string) => ({
    use: () => ({ handle: (fn: any) => fn }),
    handle: (fn: any) => fn,
  }),
}));
