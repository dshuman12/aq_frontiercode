import { RepaymentType } from "@libs/types";

export enum AccountType {
  Card = "CARD",
  Load = "LOAN",
}

export enum FailureCategory {
  InsufficientFunds = "INSUFFICIENT_FUNDS",
  BankAccountClosed = "BANK_ACCOUNT_CLOSED",
  MandateCancelled = "MANDATE_CANCELLED",
  TechnicalFailure = "TECHNICAL_FAILURE",
  CardDeclined = "CARD_DECLINED",
  ExpiredCard = "EXPIRED_CARD",
  Ohter = "OTHER",
}

export type Repayment = {
  amount: number;
  paymentMethod: RepaymentType;
  externalId: string;
  mandateId?: string | null;
};

export type RepaymentCollectedEvent = {
  accountId: string;
  accountType: AccountType;
  customerId: string;
  repayment: Repayment;
  processor: string;
  date: string;
};

export type DDEligibleForRetryEvent = {
  accountId: string;
  customerId: string;
  personContactId: string;
  firstName: string;
  dueDate: string;
  emailAddress: string;
  phoneNumber: string;
  failureDate: string;
  processor: string;
  processorReference: string | null;
  paymentIntentId: string;
};

type MandateDetails = {
  mandateId: string;
  oldMandateId: string | null;
  accountId: string;
  customerId: string;
  status: "PENDING" | "ACTIVE" | "CANCELLED" | "FAILED";
  bankDetails: BankDetails;
  startDate: number;
  processorReference: string;
};

type BankDetails = {
  accountNumber: string;
  sortCode: string;
  accountName: string;
};

export type MandateUpsertedEvent = {
  mandateDetails: MandateDetails;
  startDate: number;
  created: number;
};

type CancellationReason =
  | "ACCOUNT_CLOSED"
  | "BANK_ACCOUNT_CLOSED"
  | "BANK_ACCOUNT_RESTRICTED"
  | "MANDATE_EXPIRED"
  | "PAYMENT_FAILED"
  | "OTHER";

export type MandateCancelledEvent = {
  mandateId: string;
  accountId: string;
  customerId: string;
  cancellationReason: CancellationReason;
  cancellationDate: number;
};

export type FailureDetails = {
  failureCode: string;
  failureMessage: string;
  failureCategory: FailureCategory;
  failureTime: string;
};

export type RepaymentFailedEvent = {
  accountId: string;
  accountType: AccountType;
  customerId: string;
  cpaAttemptCount: number;
  paymentDetails: Repayment;
  failureDetails: FailureDetails;
  processor: string;
  processorReference: string;
};

export enum CPACancellationReason {
  CancellationRequested = "cancellation_requested",
  PaymentDisputed = "payment_disputed",
  PaymentFailed = "payment_failed",
  EndDateReached = "end_date_reached",
  BalancePaid = "balance_paid",
}

type CPASubscriptionDetails = {
  subscriptionId: string;
  status: string;
  amount: number;
  currentPeriodEnd: number;
};

export type CPASubscriptionCreatedEvent = {
  accountId: string;
  accountType: AccountType;
  customerId: string;
  pspCustomerId: string;
  subscriptionDetails: CPASubscriptionDetails;
  processor: string;
  processorReference: string | null;
};

export type CPASubscriptionCancelledEvent = {
  accountId: string;
  accountType: AccountType;
  customerId: string;
  pspCustomerId: string;
  subscriptionDetails: CPASubscriptionDetails & {
    cancellationReason: CPACancellationReason;
  };
  processor: string;
  processorReference: string | null;
};

