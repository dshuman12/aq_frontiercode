import { APIGatewayEvent } from "aws-lambda";

export type ApiGatewayEventWithRawBody = APIGatewayEvent & { rawBody: string };