import { MambuWebhookEvent } from "@libs/types";
import { z } from "zod";
import {
  SFMC_DD_FAILED_ACCOUNT_CLOSED,
  SFMC_DD_FAILED_INSUFFICIENT_FUNDS,
  SFMC_CPA_CREATIVE_PLAN_CONFIRMATION,
  SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_10_DAYS,
  SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_1_DAY,
  SFMC_CPA_CREATIVE_PAYMENT_FAILED_RETRY,
  SFMC_CPA_CREATIVE_SUBSCRIPTION_CANCELLED,
  SFMC_CPA_CREATIVE_PLAN_ENDED,
} from "@libs/constants";
import dayjs from "dayjs";

export type DirectDebitRepaymentDue = {
  accountId: string;
  customerId: string;
  dueDate: string;
  idempotencyKey: string;
  webhookDetails?: MambuWebhookEvent; // we keep all of it for now as I want to log some properties and compare them with the value we get for dd
};

export type DirectDebitRetryProcessorEvent = {
  paymentIntentId: string;
  accountId: string;
  customerId: string;
};

export const SFMCDDCommsEventSchema = z.object({
  commsKey: z.enum([
    SFMC_DD_FAILED_ACCOUNT_CLOSED,
    SFMC_DD_FAILED_INSUFFICIENT_FUNDS,
  ]),
  firstName: z.string(),
  dueDate: z.string().refine((dateStr) => dayjs(dateStr, "YYYY-MM-DD", true).isValid(), {
    message: "Invalid due date format, must be YYYY-MM-DD",
  }),
  emailAddress: z.string().email(),
  customerId: z.string(),
  personContactId: z.string(),
  phoneNumber: z.string(),
  retryDate: z.string().refine((dateStr) => dayjs(dateStr, "YYYY-MM-DD", true).isValid(), {
    message: "Invalid retry date format, must be YYYY-MM-DD",
  }),
  avoidFeeCutOffDate: z.string().refine((dateStr) => dayjs(dateStr, "YYYY-MM-DD", true).isValid(), {
    message: "Invalid avoid fee cut off date format, must be YYYY-MM-DD",
  }),
  preventRetryDate: z.string().refine((dateStr) => dayjs(dateStr, "YYYY-MM-DD", true).isValid(), {
    message: "Invalid prevent retry date format, must be YYYY-MM-DD",
  }),
});

export type SFMCDDCommsEvent = z.infer<typeof SFMCDDCommsEventSchema>;

export const SFMCCPACommsEventSchema = z.object({
  creative: z.enum([
    SFMC_CPA_CREATIVE_PLAN_CONFIRMATION,
    SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_10_DAYS,
    SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_1_DAY,
    SFMC_CPA_CREATIVE_PAYMENT_FAILED_RETRY,
    SFMC_CPA_CREATIVE_SUBSCRIPTION_CANCELLED,
    SFMC_CPA_CREATIVE_PLAN_ENDED,
  ]),
  firstName: z.string(),
  emailAddress: z.string().email(),
  customerId: z.string(),
  personContactId: z.string(),
  paymentPlanDate: z.string().nullable(),
  planEndDate: z.string().nullable(),
  retryDate: z.string().nullable(),
  paymentPlanValue: z.number().nullable(),
  arrearsBalance: z.number().nullable(),
});

export type SFMCCPACommsEvent = z.infer<typeof SFMCCPACommsEventSchema>;

// Keep backward-compatible alias
export const SFMCCommsEventSchema = SFMCDDCommsEventSchema;
export type SFMCCommsEvent = SFMCDDCommsEvent;
