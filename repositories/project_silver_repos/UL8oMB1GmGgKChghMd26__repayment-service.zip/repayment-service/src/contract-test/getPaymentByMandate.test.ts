import { BASE_PATH } from "@libs/constants";
import { accessTokenObject } from "@libs/types/oidcAuth";
import { generateAccessTokenOfTestUser } from "src/utils/oidcAuthToken";
import { beforeEach, describe, expect, test } from "vitest";

describe("Create Card Repayment", () => {
  let accessToken: accessTokenObject;

  beforeEach(async () => {
    accessToken = await generateAccessTokenOfTestUser(`test-repayments-c799971a-b667-44ea-9050-0bd9a627ff30`);
  });

  // These tests right now are not integrated into CI/CD pipeline.
  // Their purpose is to test thea actual endpoints after a deployment.
  test("fetch to hit the actual endpoints", async () => {
    const mandateId = "mandate_1QQX04Rp1KcrfXlPFaqjKZ2d";
    const result = await fetch(`https://api.staging.onmo.app/${BASE_PATH}/next/mandate/${mandateId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken.access_token,
      },
    });

    expect(result.status).toBe(200);
    const parsed = await result.json();
    expect(parsed.directDebitDetails).toBeDefined();
  });

  test("returns 401 if no access token is provided", async () => {
    const mandateId = "mandate_1QQX04Rp1KcrfXlPFaqjKZ2d";
    const result = await fetch(`https://api.staging.onmo.app/${BASE_PATH}/next/mandate/${mandateId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    expect(result.status).toBe(401);
  });

  test("returns 404 if mandateId is not found", async () => {
    const mandateId = "this isn't a valid mandate";
    const result = await fetch(`https://api.staging.onmo.app/${BASE_PATH}/next/mandate/${mandateId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken.access_token,
      },
    });

    expect(result.status).toBe(404);
  });
});
