import { BASE_PATH } from "@libs/constants";
import { accessTokenObject } from "@libs/types/oidcAuth";
import { generateAccessTokenOfTestUser } from "src/utils/oidcAuthToken";
import { beforeEach, describe, expect, test } from "vitest";

const customerId = "test-repayments-c799971a-b667-44ea-9050-0bd9a627ff30";

describe("delete mandate", () => {
  let accessToken: accessTokenObject;

  beforeEach(async () => {
    accessToken = await generateAccessTokenOfTestUser(customerId);
  });

  // These tests require a mandate to be created first.
  test.skip("successfully deletes an endpoint", async () => {
    const mandateId = "mandate_1QgwFBRp1KcrfXlP7dW4SFrt";

    const result = await fetch(`https://api.staging.onmo.app/${BASE_PATH}/next/direct-debit/${mandateId}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken.access_token,
      },
    });

    expect(result.status).toBe(200);
    const parsed = await result.json();
    expect(parsed.message).toBe("direct debit deleted");
  });
});
