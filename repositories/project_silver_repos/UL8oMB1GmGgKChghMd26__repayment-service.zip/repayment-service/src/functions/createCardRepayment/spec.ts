
import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: 'Bad Request',
  }),
})


// can return paymentSecret as a string, OR message as a string
const CreateCardRepaymentOutput = z.union([
  z.object({
    paymentSecret: z.string(),
  }),
  z.object({
    message: z.string(),
  }),
])

app.openapi(
  createRoute({
    method: 'post',
    path: '/one-off-payment/card',
    security: [
      {
        Bearer: []
      }
    ],
    requestBody: {
      description: 'The amount to be paid, in pence. Must be at least 30p.',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              amount: {
                type: 'number',
                example: 1000,
              },
            },
            required: ['amount', 'currency', 'paymentMethodId'],
          }
        }
      }
    },
    responses: {
      200: {
        description: 'returns a payment secret used to create a session with the payment provider, or a message if an error occurred',
        content: {
          'application/json': {
            schema: CreateCardRepaymentOutput
          }
        }
      },
      400: {
        content: {
          'application/json': {
            schema: ErrorSchema,
          },
        },
        description: 'Returns an error',
      },

    }
  }),
  (c) => {
    return c.json({
      paymentSecret: 'pmi_1234',
    })
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 400,
          message: 'Custom Message',
        },
        400
      )
    }
  }
)

export default app
