import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer, updateCustomer } from "src/utils/db";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { APIGatewayEventHandler } from "@libs/types";
import { createPspCustomer } from "src/utils/createPspCustomer";
import { formatErrorMessage } from "src/utils/errorUtil";

const env = process.env.ENVIRONMENT;

type CardRepayment = {
  paymentSecret: string;
  ephemeralKey: string;
  pspCustomerId: string;
};

type CardError = {
  message: string;
};

const validateBody = (body: string) => {
  return z
    .object({
      amount: z.number().min(50),
    })
    .safeParse(JSON.parse(body));
};

export const handler = async (event: APIGatewayEventHandler): Promise<any> => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createCardRepayment" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  const body = validateBody(event.body || "");

  if (!body.success) {
    logger.warn(`Invalid request body: ${body.error}`);
    return formatJSONResponse<CardError>({ statusCode: 400, body: { message: "Invalid request body" } });
  }

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError) {
    logger.error(`Error fetching customer details: ${customerError}`);
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!customer.accountId || !customer.mambuID) {
    logger.error("Customer account details missing");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  // check banking adapter for Mambu full lock
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);

  if (customerInformation.error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (data.accountDetails.state === "FULL_LOCK") {
    logger.warn(
      `Account ${data.accountDetails.accountId} is in FULL_LOCK state. Cannot create repayment, returning 400.`,
    );
    return formatJSONResponse<CardError>({ statusCode: 400, body: { message: "Bad Request" } });
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Error fetching repayment client");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  let pspUser = null;
  if (!customer.pspCustomerId) {
    logger.info("Customer created");

    const { data, error } = await createPspCustomer({
      repaymentClient,
      customer,
      customerData: customerInformation.data,
    });
    if (error) {
      logger.error("Error creating customer");
      return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    pspUser = data;

    const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);

    if (updatedCustomer.error) {
      logger.error("Error updating customer details");
      return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    logger.info("Customer updated with pspCustomerId");
  }

  let paymentIntent;
  try {
    paymentIntent = await repaymentClient.createCardRepayment({
      amount: Number(body.data.amount.toFixed(0)),
      customerId: customer.customerId,
      pspCustomerId: pspUser?.pspCustomerId || customer.pspCustomerId,
      accountId: customer.accountId,
      accountType: "card",
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({ message: "Error creating payment intent", errorMessage });
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!paymentIntent) {
    logger.error("Error creating payment intent");
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.info("Payment intent created");

  return formatJSONResponse<CardRepayment>({
    statusCode: 200,
    body: {
      paymentSecret: paymentIntent.clientSecret,
      ephemeralKey: paymentIntent.ephemeralKey,
      pspCustomerId: paymentIntent.pspCustomerId,
    },
  });
};
