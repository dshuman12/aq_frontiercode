
import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { getCustomer, updateCustomer } from "src/utils/db";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { APIGatewayEventHandler } from "@libs/types";
import { createPspCustomer } from "src/utils/createPspCustomer";
import { formatErrorMessage } from "src/utils/errorUtil";

const env = process.env.ENVIRONMENT;

type CheckoutRepayment = {
  sessionId: string;
  clientSecret?: string;
  url?: string;
};

type CheckoutRepaymentError = {
  message: string;
};

const validateBody = (body: string) => {
  const commonSchema = {
    amount: z.number().min(50),
    paymentMethods: z
      .array(z.enum(["pay_by_bank", "card"]), {
        required_error: "paymentMethods list is required",
      })
      .min(1, "Pick at least one payment method")
      .max(2, "At most two payment methods")
      .refine((arr) => new Set(arr).size === arr.length, {
        message: "Duplicate payment methods aren't allowed",
      }),
  };

  return z
    .discriminatedUnion("uiMode", [
      z.object({
        ...commonSchema,
        uiMode: z.literal("hosted"),
        success_url: z.string().url(),
      }),
      z.object({
        ...commonSchema,
        uiMode: z.literal("embedded"),
        return_url: z.string().url(),
      }),
      z.object({
        ...commonSchema,
        uiMode: z.literal("custom"),
        return_url: z.string().url(),
      }),
    ])
    .safeParse(JSON.parse(body));
};

export const handler = async (event: APIGatewayEventHandler): Promise<any> => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createCheckoutRepayment" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  const body = validateBody(event.body || "");

  if (!body.success) {
    logger.warn(`Invalid request body: ${body.error}`);
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 400, body: { message: "Invalid request body" } });
  }

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError) {
    logger.error(`Error fetching customer details: ${customerError}`);
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!customer.accountId || !customer.mambuID) {
    logger.error("Customer account details missing");
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  // check banking adapter for Mambu full lock
  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.error({ message: "Error fetching credit account details", error: formatErrorMessage(error) });
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);

  if (customerInformation.error) {
    logger.error({
      message: "Error fetching customer information",
      error: formatErrorMessage(customerInformation.error),
    });
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (data.accountDetails.state === "FULL_LOCK") {
    logger.warn(
      `Account ${data.accountDetails.accountId} is in FULL_LOCK state. Cannot create repayment, returning 400.`,
    );
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 400, body: { message: "Bad Request" } });
  }

  const { SecretString: stripeSecretString } = await getSecret(`onmo-stripe-${env}`);
  if (!stripeSecretString) {
    throw new Error("Stripe secrets string is undefined");
  }

  const { secretKey } = JSON.parse(stripeSecretString);

  const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
    stageName: env as "staging" | "prod",
    configuration: {
      secretAccessKey: secretKey,
    },
  });

  if (!repaymentClient) {
    logger.error("Error fetching repayment client");
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  let pspUser = null;
  if (!customer.pspCustomerId) {
    logger.info("Customer does not exist in PSP. Creating customer...");

    const { data, error } = await createPspCustomer({
      repaymentClient,
      customer,
      customerData: customerInformation.data,
    });
    if (error) {
      logger.error({ message: "Error creating PSP customer", error: formatErrorMessage(error) });

      return formatJSONResponse<CheckoutRepaymentError>({
        statusCode: 500,
        body: { message: "Internal Server Error" },
      });
    }
    pspUser = data;

    const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);

    if (updatedCustomer.error) {
      logger.error({
        message: "Error updating newly created PSP user id on dynamo DB table",
        error: formatErrorMessage(updatedCustomer.error),
      });

      return formatJSONResponse<CheckoutRepaymentError>({
        statusCode: 500,
        body: { message: "Internal Server Error" },
      });
    }
    logger.info("Customer updated with pspCustomerId");
  }

  let session;
  try {
    const paymentInfo = {
      amount: Number(body.data.amount.toFixed(0)),
      pspCustomerId: pspUser?.pspCustomerId || customer.pspCustomerId,
      customerId: customer.customerId,
      accountId: customer.accountId,
      accountType: "card" as const,
      paymentPreferenceName: "ONMO Repayment",
      paymentMethods: body.data.paymentMethods, // array of payment method types
    };

    if (body.data.uiMode === "hosted") {
      session = await repaymentClient.createCheckoutRepayment({
        ...paymentInfo,
        uiMode: body.data.uiMode,
        successUrl: body.data.success_url,
      });
    } else if (body.data.uiMode === "embedded" || body.data.uiMode === "custom") {
      session = await repaymentClient.createCheckoutRepayment({
        ...paymentInfo,
        uiMode: body.data.uiMode,
        returnUrl: body.data.return_url,
      });
    }
  } catch (error) {
    logger.error({ message: "Error creating checkout repayment session", error: formatErrorMessage(error) });
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!session) {
    logger.error({
      message: "Error getting checkout repayment session id",
    });
    return formatJSONResponse<CheckoutRepaymentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.info("Payment intent created");

  if (body.data.uiMode === "embedded" || body.data.uiMode === "custom") {
    return formatJSONResponse<CheckoutRepayment>({
      statusCode: 200,
      body: {
        sessionId: session.sessionId,
        clientSecret: session.clientSecret,
      },
    });
  } else {
    return formatJSONResponse<CheckoutRepayment>({
      statusCode: 200,
      body: {
        sessionId: session.sessionId,
        url: session.url,
      },
    });
  }
};
