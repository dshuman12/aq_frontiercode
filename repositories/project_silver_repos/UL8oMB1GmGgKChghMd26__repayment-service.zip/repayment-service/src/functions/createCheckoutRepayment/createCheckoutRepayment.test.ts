import { beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./createCheckoutRepayment";
import * as dbUtil from "src/utils/db";
import * as createPspCustomerUtil from "src/utils/createPspCustomer";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { getSecret } from "@onmoapp/onmo-secrets-manager";

vi.mock("src/utils/db");
vi.mock("src/utils/createPspCustomer");
vi.mock("@onmoapp/core-repayments");
vi.mock("@onmoapp/onmo-adapters");
vi.mock("@onmoapp/onmo-secrets-manager");

describe("createCheckoutRepayment", () => {
  beforeEach(() => {
    vi.resetAllMocks();

    // Default mock for getSecret
    vi.mocked(getSecret).mockResolvedValue({
      SecretString: JSON.stringify({ secretKey: "sk_test_123" }),
    } as any);
  });

  const baseCustomerData = {
    data: {
      customerId: "customer-id",
      mambuID: "mambu-id",
      pspCustomerId: "psp-customer-id",
      accountId: "account-id",
      address: "",
      email: "test@example.com",
    },
    error: null,
  };

  const baseEventBodyHosted = {
    amount: 100,
    uiMode: "hosted" as const,
    success_url: "https://example.com/success",
    paymentMethods: ["card"],
  };

  const baseEventBodyEmbedded = {
    amount: 100,
    uiMode: "embedded" as const,
    return_url: "https://example.com/return",
    paymentMethods: ["card"],
  };

  const baseEventBodyCustom = {
    amount: 100,
    uiMode: "custom" as const,
    return_url: "https://example.com/return",
    paymentMethods: ["card"],
  };

  describe("Sad Path", () => {
    test("No ONMO UUID in authorizer", async () => {
      await expect(handler({ requestContext: { authorizer: { onmouuid: undefined } } } as any)).rejects.toThrow(
        "Missing onmouuid from authorizer",
      );
    });

    test("Invalid request body - empty body", async () => {
      const res = await handler({
        body: "{}",
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - amount less than 50", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, amount: 49 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - missing paymentMethods", async () => {
      const res = await handler({
        body: JSON.stringify({ amount: 100, uiMode: "hosted", success_url: "https://example.com" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - empty paymentMethods array", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: [] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - more than 2 payment methods", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: ["card", "pay_by_bank", "card"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - duplicate payment methods", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: ["card", "card"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - invalid payment method", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: ["invalid_method"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - invalid success_url for hosted mode", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, success_url: "invalid-url" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Invalid request body - invalid return_url for embedded mode", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyEmbedded, return_url: "invalid-url" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });

    test("Customer not found in database", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Customer not found" });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Customer missing accountId", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: { ...baseCustomerData.data, accountId: null },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Customer missing mambuID", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: { ...baseCustomerData.data, mambuID: null },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Banking client not available", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue(null);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error fetching account details", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: null,
          error: "Account not found",
        }),
        getCustomerByCoreBankingCustomerId: vi.fn(),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error fetching customer information", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: null,
          error: "Customer not found",
        }),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Account is in FULL_LOCK state", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "FULL_LOCK",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Bad Request" });
    });

    test("Repayment client not available", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(null);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error creating PSP customer for new customer", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn(),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: null,
        error: "Failed to create PSP customer",
      });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error updating customer with pspCustomerId", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn(),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: { pspCustomerId: "new-psp-customer-id" },
        error: null,
      });
      vi.mocked(dbUtil.updateCustomer).mockResolvedValue({
        data: null,
        error: "Failed to update customer",
      });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error creating checkout repayment session", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockRejectedValue(new Error("Payment creation failed")),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Session creation returns null", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue(null),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
  });

  describe("Happy Path", () => {
    const setupSuccessfulMocks = () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);
    };

    test("Create hosted checkout repayment with existing PSP customer", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-123",
          url: "https://checkout.stripe.com/session-123",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith({
        amount: 100,
        pspCustomerId: "psp-customer-id",
        customerId: "customer-id",
        accountId: "account-id",
        accountType: "card",
        paymentPreferenceName: "ONMO Repayment",
        paymentMethods: ["card"],
        uiMode: "hosted",
        successUrl: "https://example.com/success",
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        sessionId: "session-123",
        url: "https://checkout.stripe.com/session-123",
      });
    });

    test("Create embedded checkout repayment with existing PSP customer", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-456",
          clientSecret: "cs_test_secret",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyEmbedded),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith({
        amount: 100,
        pspCustomerId: "psp-customer-id",
        customerId: "customer-id",
        accountId: "account-id",
        accountType: "card",
        paymentPreferenceName: "ONMO Repayment",
        paymentMethods: ["card"],
        uiMode: "embedded",
        returnUrl: "https://example.com/return",
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        sessionId: "session-456",
        clientSecret: "cs_test_secret",
      });
    });

    test("Create custom checkout repayment with existing PSP customer", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-789",
          clientSecret: "cs_test_custom_secret",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBodyCustom),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith({
        amount: 100,
        pspCustomerId: "psp-customer-id",
        customerId: "customer-id",
        accountId: "account-id",
        accountType: "card",
        paymentPreferenceName: "ONMO Repayment",
        paymentMethods: ["card"],
        uiMode: "custom",
        returnUrl: "https://example.com/return",
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        sessionId: "session-789",
        clientSecret: "cs_test_custom_secret",
      });
    });

    test("Create checkout repayment with multiple payment methods", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-multi",
          url: "https://checkout.stripe.com/session-multi",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: ["card", "pay_by_bank"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentMethods: ["card", "pay_by_bank"],
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Create PSP customer and checkout repayment for new customer", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: {
            customerId: "customer-id",
            firstName: "John",
            lastName: "Doe",
            emailAddresses: { primary: "john@example.com" },
            addresses: [{ line1: "123 Main St", city: "London", postalCode: "SW1A 1AA", country: "GB" }],
          },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-new-customer",
          url: "https://checkout.stripe.com/session-new-customer",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: { pspCustomerId: "new-psp-customer-id" },
        error: null,
      });
      vi.mocked(dbUtil.updateCustomer).mockResolvedValue({
        data: { ...customerWithoutPsp.data, pspCustomerId: "new-psp-customer-id" },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBodyHosted),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(createPspCustomerUtil.createPspCustomer).toHaveBeenCalledWith({
        repaymentClient: mockRepaymentClient,
        customer: customerWithoutPsp.data,
        customerData: expect.objectContaining({
          customerId: "customer-id",
          firstName: "John",
          lastName: "Doe",
        }),
      });
      expect(dbUtil.updateCustomer).toHaveBeenCalledWith("customer-id", "new-psp-customer-id");
      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          pspCustomerId: "new-psp-customer-id",
        }),
      );
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        sessionId: "session-new-customer",
        url: "https://checkout.stripe.com/session-new-customer",
      });
    });

    test("Create checkout repayment with minimum amount (50)", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-min",
          url: "https://checkout.stripe.com/session-min",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, amount: 50 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          amount: 50,
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Create checkout repayment with pay_by_bank only", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-pbb",
          url: "https://checkout.stripe.com/session-pbb",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyHosted, paymentMethods: ["pay_by_bank"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentMethods: ["pay_by_bank"],
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Decimal amounts are rounded", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createCheckoutRepayment: vi.fn().mockResolvedValue({
          sessionId: "session-pbb",
          url: "https://checkout.stripe.com/session-pbb",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBodyEmbedded, amount: 2345.23 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createCheckoutRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          amount: 2345,
        }),
      );
      expect(res.statusCode).toBe(200);
    });
  });
});
