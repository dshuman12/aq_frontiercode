import { getLogger } from "@libs/logger";
import { deserializeUtil } from "@libs/deserializeUtil";

export const handler = async (event: any) => {
  const logger = getLogger();
  logger.info({
    outputMessage: "repaymentFailedEnrich function invoked",
    event,
  });
  // todo tests
  const data = await deserializeUtil(event[0].data.data, event[0].data.schemaId);
  logger.info({ data, message: "Data deserialized successfully" });
  return data;
};
