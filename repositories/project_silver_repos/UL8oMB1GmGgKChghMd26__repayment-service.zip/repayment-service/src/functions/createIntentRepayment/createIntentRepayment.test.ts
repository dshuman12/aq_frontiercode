import { beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./createIntentRepayment";
import * as dbUtil from "src/utils/db";
import * as createPspCustomerUtil from "src/utils/createPspCustomer";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { getSecret } from "@onmoapp/onmo-secrets-manager";

vi.mock("src/utils/db");
vi.mock("src/utils/createPspCustomer");
vi.mock("@onmoapp/core-repayments");
vi.mock("@onmoapp/onmo-adapters");
vi.mock("@onmoapp/onmo-secrets-manager");

describe("createIntentRepayment", () => {
  beforeEach(() => {
    vi.resetAllMocks();

    // Default mock for getSecret
    vi.mocked(getSecret).mockResolvedValue({
      SecretString: JSON.stringify({ secretKey: "sk_test_123" }),
    } as any);
  });

  const baseCustomerData = {
    data: {
      customerId: "customer-id",
      mambuID: "mambu-id",
      pspCustomerId: "psp-customer-id",
      accountId: "account-id",
      address: "",
      email: "test@example.com",
    },
    error: null,
  };

  const baseEventBody = {
    amount: 100,
    paymentMethods: ["card"],
  };

  describe("Sad Path", () => {
    test("No ONMO UUID in authorizer", async () => {
      const res = await handler({ requestContext: { authorizer: { onmouuid: undefined } } } as any);
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Invalid request body - empty body", async () => {
      const res = await handler({
        body: "{}",
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - amount less than 50", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, amount: 49 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - missing paymentMethods", async () => {
      const res = await handler({
        body: JSON.stringify({ amount: 100 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - empty paymentMethods array", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: [] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - more than 2 payment methods", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: ["card", "pay_by_bank", "card"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - duplicate payment methods", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: ["card", "card"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Invalid request body - invalid payment method", async () => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: ["invalid_method"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);
      expect(res.statusCode).toBe(400);
      expect(res.body.message).toContain("Invalid request body");
    });

    test("Customer not found in database", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Customer not found" });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Customer missing accountId", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: { ...baseCustomerData.data, accountId: null },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Customer missing mambuID", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: { ...baseCustomerData.data, mambuID: null },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Banking client not available", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue(null);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error fetching account details", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: null,
          error: "Account not found",
        }),
        getCustomerByCoreBankingCustomerId: vi.fn(),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Account is in FULL_LOCK state", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "FULL_LOCK",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error fetching customer information", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: null,
          error: "Customer not found",
        }),
      } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Stripe secret not found", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);
      vi.mocked(getSecret).mockResolvedValue({ SecretString: undefined } as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Repayment client not available", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(null);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error creating PSP customer for new customer", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn(),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: null,
        error: "Failed to create PSP customer",
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error updating customer with pspCustomerId", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn(),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: { pspCustomerId: "new-psp-customer-id" },
        error: null,
      });
      vi.mocked(dbUtil.updateCustomer).mockResolvedValue({
        data: null,
        error: "Failed to update customer",
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Error creating payment intent", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockRejectedValue(new Error("Payment intent creation failed")),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Payment intent creation returns null", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue(null),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
  });

  describe("Happy Path", () => {
    const setupSuccessfulMocks = () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: { customerId: "customer-id" },
          error: null,
        }),
      } as any);
    };

    test("Create intent repayment with existing PSP customer", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_123_secret_456",
          ephemeralKey: "ek_test_123",
          pspCustomerId: "psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith({
        amount: 100,
        pspCustomerId: "psp-customer-id",
        customerId: "customer-id",
        accountId: "account-id",
        accountType: "loan",
        paymentMethods: ["card"],
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        paymentSecret: "pi_123_secret_456",
        ephemeralKey: "ek_test_123",
        pspCustomerId: "psp-customer-id",
      });
    });

    test("Create intent repayment with multiple payment methods", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_123_secret_456",
          ephemeralKey: "ek_test_123",
          pspCustomerId: "psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: ["card", "pay_by_bank"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentMethods: ["card", "pay_by_bank"],
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Create PSP customer and payment intent for new customer", async () => {
      const customerWithoutPsp = {
        data: { ...baseCustomerData.data, pspCustomerId: null },
        error: null,
      };

      vi.mocked(dbUtil.getCustomer).mockResolvedValue(customerWithoutPsp);
      vi.mocked(coreBankingAdapter).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "ACTIVE",
              accountId: "account-id",
            },
          },
          error: null,
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: {
            customerId: "customer-id",
            firstName: "John",
            lastName: "Doe",
            emailAddresses: { primary: "john@example.com" },
            addresses: [{ line1: "123 Main St", city: "London", postalCode: "SW1A 1AA", country: "GB" }],
          },
          error: null,
        }),
      } as any);

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_new_secret_789",
          ephemeralKey: "ek_test_new_456",
          pspCustomerId: "new-psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
      vi.mocked(createPspCustomerUtil.createPspCustomer).mockResolvedValue({
        data: { pspCustomerId: "new-psp-customer-id" },
        error: null,
      });
      vi.mocked(dbUtil.updateCustomer).mockResolvedValue({
        data: { ...customerWithoutPsp.data, pspCustomerId: "new-psp-customer-id" },
        error: null,
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(createPspCustomerUtil.createPspCustomer).toHaveBeenCalledWith({
        repaymentClient: mockRepaymentClient,
        customer: customerWithoutPsp.data,
        customerData: expect.objectContaining({
          customerId: "customer-id",
          firstName: "John",
          lastName: "Doe",
        }),
      });
      expect(dbUtil.updateCustomer).toHaveBeenCalledWith("customer-id", "new-psp-customer-id");
      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          pspCustomerId: "new-psp-customer-id",
        }),
      );
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({
        paymentSecret: "pi_new_secret_789",
        ephemeralKey: "ek_test_new_456",
        pspCustomerId: "new-psp-customer-id",
      });
    });

    test("Create payment intent with minimum amount (50)", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_min_secret",
          ephemeralKey: "ek_test_min",
          pspCustomerId: "psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, amount: 50 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          amount: 50,
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Create payment intent with pay_by_bank only", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_pbb_secret",
          ephemeralKey: "ek_test_pbb",
          pspCustomerId: "psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentMethods: ["pay_by_bank"] }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentMethods: ["pay_by_bank"],
        }),
      );
      expect(res.statusCode).toBe(200);
    });

    test("Decimal amounts are rounded down", async () => {
      setupSuccessfulMocks();

      const mockRepaymentClient = {
        createIntentRepayment: vi.fn().mockResolvedValue({
          clientSecret: "pi_decimal_secret",
          ephemeralKey: "ek_test_decimal",
          pspCustomerId: "psp-customer-id",
        }),
      };
      vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, amount: 2345.67 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      } as any);

      expect(mockRepaymentClient.createIntentRepayment).toHaveBeenCalledWith(
        expect.objectContaining({
          amount: 2346,
        }),
      );
      expect(res.statusCode).toBe(200);
    });
  });
});
