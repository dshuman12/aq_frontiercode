
import { Logger } from "@onmoapp/onmo-logger";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { getCustomer, updateCustomer } from "@utils/db";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { IntentError } from "@libs/types";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { createPspCustomer } from "@utils/createPspCustomer";
import { formatErrorMessage, throwErrorIfAdapterResHaveError } from "@utils/errorUtil";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { getSecret } from "@onmoapp/onmo-secrets-manager";

const env = process.env.ENVIRONMENT;

const validateBody = (body: string) => {
  return z
    .object({
      amount: z
        .number({
          required_error: "Amount is required",
        })
        .min(50, "Amount must be greater than or equal to £0.50"),
      paymentMethods: z
        .array(z.enum(["pay_by_bank", "card"]), {
          required_error: "paymentMethods list is required",
        })
        .min(1, "Pick at least one payment method")
        .max(2, "At most two payment methods")
        .refine((arr) => new Set(arr).size === arr.length, {
          message: "Duplicate payment methods aren't allowed",
        }),
    })
    .safeParse(JSON.parse(body));
};

type IntentRepayment = {
  paymentSecret: string;
  ephemeralKey: string;
  pspCustomerId: string;
};

export const handler = async (event): Promise<any> => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createIntentRepayment" });

  try {
    const { onmouuid: customerId } = event?.requestContext?.authorizer;

    if (!customerId) {
      throw new OnmoError({
        name: ErrorNamesEnum.NOT_FOUND_ERROR,
        message: "Missing onmouuid from authorizer",
        cause: "Missing onmouuid from authorizer",
      });
    }

    const body = validateBody(event.body || "{}");

    if (!body.success) {
      logger.info(body.error);
      const errorMessage = `Invalid request body : ${body?.error?.issues?.[0]?.message}`;

      logger.error(errorMessage);
      return formatJSONResponse<IntentError>({ statusCode: 400, body: { message: errorMessage } });
    }

    logger.info({ body });

    const { amount, paymentMethods } = body.data;

    logger.info("fetching customer info from table");

    const customerDetails = (await getCustomer(customerId)) as { data: any; error: string };

    throwErrorIfAdapterResHaveError(customerDetails, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const { data: customer } = customerDetails;

    if (!customer.accountId || !customer.mambuID) {
      logger.error("Customer account details missing");
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

    const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

    if (!bankingClient) {
      logger.error("Error fetching banking client");
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    const accountDetails = await bankingClient.getCreditAccount(customer.accountId);

    throwErrorIfAdapterResHaveError(accountDetails, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const { data } = accountDetails;

    if (data.accountDetails.state === "FULL_LOCK") {
      logger.error("Account is fully locked");
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);
    throwErrorIfAdapterResHaveError(customerInformation, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const { SecretString: stripeSecretString } = await getSecret(`onmo-stripe-${env}`);
    if (!stripeSecretString) {
      throw new Error("Stripe secrets string is undefined");
    }

    const { secretKey } = JSON.parse(stripeSecretString);

    const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
      stageName: env as "staging" | "prod",
      configuration: {
        secretAccessKey: secretKey,
      },
    });

    if (!repaymentClient) {
      logger.error("Error fetching repayment client");
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    let pspCustomerId = customer.pspCustomerId;
    if (!customer.pspCustomerId) {
      logger.info("Customer does not exist in PSP. Creating customer...");

      const { data: pspUser, error } = await createPspCustomer({
        repaymentClient,
        customer,
        customerData: customerInformation.data,
      });
      if (error) {
        logger.error("Error creating customer");
        return formatJSONResponse<IntentError>({
          statusCode: 500,
          body: { message: "Internal Server Error" },
        });
      }
      logger.info(`PSP Customer created: ${pspUser.pspCustomerId}`);
      const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);
      logger.info(
        `Customer updated with pspCustomerId in mobile table: ${customer.customerId} ${pspUser.pspCustomerId}`,
      );

      if (updatedCustomer.error) {
        logger.error("Error updating customer details");
        return formatJSONResponse<IntentError>({
          statusCode: 500,
          body: { message: "Internal Server Error" },
        });
      }
      pspCustomerId = pspUser.pspCustomerId;
      logger.info("Customer updated with pspCustomerId");
    }

    let paymentIntent;
    try {
      paymentIntent = await repaymentClient.createIntentRepayment({
        amount: Number(amount.toFixed(0)),
        pspCustomerId: pspCustomerId,
        customerId: customer.customerId,
        accountId: customer.accountId,
        accountType: "loan",
        paymentMethods,
      });
    } catch (error) {
      const errorMessage = formatErrorMessage(error);
      logger.error({ message: "Error creating payment intent", errorMessage });
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    if (!paymentIntent) {
      logger.error("Error creating payment intent");
      return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    logger.info("Payment intent created");

    return formatJSONResponse<IntentRepayment>({
      statusCode: 200,
      body: {
        paymentSecret: paymentIntent.clientSecret,
        ephemeralKey: paymentIntent.ephemeralKey,
        pspCustomerId: paymentIntent.pspCustomerId,
      },
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(errorMessage);
    return formatJSONResponse<IntentError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }
};
