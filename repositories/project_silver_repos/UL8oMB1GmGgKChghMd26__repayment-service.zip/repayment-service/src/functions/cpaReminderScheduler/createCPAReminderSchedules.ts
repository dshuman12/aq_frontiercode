import { getLogger } from "@libs/logger";
import {
  SchedulerClient,
  CreateScheduleCommand,
  CreateScheduleCommandInput,
} from "@aws-sdk/client-scheduler";
import dayjs from "dayjs";
import { CPA_REMINDER_NAME_PREFIX } from "@libs/constants";
import { scheduleExists } from "@utils/schedulerUtil";
import { getSSMParameter } from "@utils/ssmUtil";

export type CreateCPAReminderSchedulesInput = {
  accountId: string;
  customerId: string;
  pspCustomerId: string;
  currentPeriodEnd: number;
  amount: number;
};

type ReminderConfig = {
  namePrefix: string;
  daysBefore: number;
  reminderType: string;
};

const DEFAULT_REMINDER_DAYS = [10, 1];

const getReminderConfigs = async (): Promise<ReminderConfig[]> => {
  const logger = getLogger();
  const ssmParamName = process.env.CPA_REMINDER_DAYS_SSM_PARAM;

  let reminderDays = DEFAULT_REMINDER_DAYS;

  if (ssmParamName) {
    try {
      const paramValue = await getSSMParameter(ssmParamName);
      const parsed = JSON.parse(paramValue) as number[];
      if (Array.isArray(parsed) && parsed.every((d) => typeof d === "number" && d > 0)) {
        reminderDays = parsed;
      } else {
        logger.warn({ message: "Invalid CPA reminder days SSM param, using defaults", paramValue });
      }
    } catch (error) {
      logger.warn({ message: "Failed to fetch CPA reminder days from SSM, using defaults", error });
    }
  }

  return reminderDays.map((daysBefore) => ({
    namePrefix: `${CPA_REMINDER_NAME_PREFIX}-${daysBefore}d`,
    daysBefore,
    reminderType: `${daysBefore}d`,
  }));
};

export const createCPAReminderSchedules = async (input: CreateCPAReminderSchedulesInput): Promise<void> => {
  const logger = getLogger();
  const { accountId, customerId, pspCustomerId, currentPeriodEnd, amount } = input;
  logger.addContext({ functionName: "createCPAReminderSchedules", accountId });
  logger.info({ message: "Creating CPA reminder schedules", input });

  const dueDate = dayjs.unix(currentPeriodEnd);
  const client = new SchedulerClient({ region: process.env.REGION });
  const groupName = process.env.CPA_REMINDER_GROUP_NAME;

  const scheduleOffsetMinutes = process.env.CPA_REMINDER_SCHEDULE_OFFSET_MINUTES
    ? parseInt(process.env.CPA_REMINDER_SCHEDULE_OFFSET_MINUTES, 10)
    : null;

  if (scheduleOffsetMinutes) {
    logger.info({ message: `Using test offset: both reminders will fire in ${scheduleOffsetMinutes} minutes` });
  }

  const reminderConfigs = await getReminderConfigs();

  for (const [index, config] of reminderConfigs.entries()) {
    const reminderDate = scheduleOffsetMinutes
      ? dayjs().add(scheduleOffsetMinutes * (index + 1), "minute")
      : dueDate.subtract(config.daysBefore, "day").set("hour", 9).set("minute", 0).set("second", 0);

    if (reminderDate.toDate() < new Date()) {
      logger.info({ message: `Reminder date for ${config.reminderType} is in the past. Skipping.`, reminderDate: reminderDate.toISOString() });
      continue;
    }

    const namePrefix = `${config.namePrefix}-${accountId}`;
    const scheduleFound = await scheduleExists({ namePrefix, groupName });

    if (scheduleFound) {
      logger.info({ message: `Schedule already exists for ${config.reminderType}. Skipping.` });
      continue;
    }

    const scheduleName = `${config.namePrefix}-${accountId}-${dueDate.format("YYYY-MM-DD")}`.substring(0, 64);

    const params: CreateScheduleCommandInput = {
      Name: scheduleName,
      ScheduleExpression: `at(${reminderDate.toISOString().substring(0, 19)})`,
      Target: {
        Arn: process.env.CPA_REMINDER_PROCESSOR_ARN,
        RoleArn: process.env.SCHEDULER_ROLE_ARN,
        Input: JSON.stringify({
          accountId,
          customerId,
          pspCustomerId,
          dueDate: dueDate.toISOString(),
          amount,
          reminderType: config.reminderType,
        }),
      },
      FlexibleTimeWindow: {
        Mode: "OFF",
      },
      GroupName: groupName,
      ActionAfterCompletion: "DELETE",
    };

    logger.info({ message: `Scheduling CPA ${config.reminderType} reminder`, params });
    const res = await client.send(new CreateScheduleCommand(params));

    if (!res) {
      logger.error({ message: `Failed to create ${config.reminderType} reminder schedule` });
      throw new Error(`Failed to create ${config.reminderType} reminder schedule`);
    }

    logger.info({ message: `CPA ${config.reminderType} reminder schedule created`, scheduleName });
  }
};
