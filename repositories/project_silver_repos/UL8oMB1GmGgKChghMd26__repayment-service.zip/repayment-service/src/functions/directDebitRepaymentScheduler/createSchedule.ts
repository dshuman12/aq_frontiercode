import { getLogger } from "@libs/logger";
import {
  SchedulerClient,
  CreateScheduleCommand,
  CreateScheduleCommandInput,
  CreateScheduleCommandOutput,
} from "@aws-sdk/client-scheduler";
import dayjs, { Dayjs } from "dayjs";
import { DD_PAYMENTS_NAME_PREFIX, DD_RETRY_NAME_PREFIX } from "@libs/constants";
import { RepaymentType } from "@libs/types";
import { directDebitScheduleExists } from "./directDebitScheduleExists";

export type CreateScheduleInput = {
  accountId: string;
  customerId: string;
  paymentDate: string;
  repaymentType: RepaymentType;
  idempotencyKey: string;
  paymentIntentId?: string;
};

const getCreateScheduleCommand = (
  { accountId, customerId, repaymentType, idempotencyKey, paymentIntentId }: CreateScheduleInput,
  paymentDateDayjs: Dayjs,
): CreateScheduleCommandInput => {
  const namePrefix = repaymentType === RepaymentType.DirectDebitRetry ? DD_RETRY_NAME_PREFIX : DD_PAYMENTS_NAME_PREFIX;
  const targetArn =
    repaymentType === RepaymentType.DirectDebitRetry
      ? process.env.DD_RETRY_PROCESSOR_ARN
      : process.env.REPAYMENT_PROCESSOR_ARN;

  const dlqArn =
    repaymentType === RepaymentType.DirectDebitRetry
      ? process.env.DD_RETRY_PROCESSOR_DLQ_ARN
      : process.env.REPAYMENT_PROCESSOR_DLQ_ARN;

  const groupName =
    repaymentType === RepaymentType.DirectDebitRetry
      ? process.env.DD_RETRY_GROUP_NAME
      : process.env.DD_PAYMENTS_GROUP_NAME;

  return {
    Name: `${namePrefix}-${accountId}-${paymentDateDayjs.format("YYYY-MM-DD")}`,
    ScheduleExpression: `at(${paymentDateDayjs.toISOString().substring(0, 19)})`,
    Target: {
      Arn: targetArn,
      RoleArn: process.env.SCHEDULER_ROLE_ARN,
      Input: JSON.stringify({
        accountId,
        customerId,
        dueDate: paymentDateDayjs.toISOString(),
        repaymentType,
        idempotencyKey,
        paymentIntentId,
      }),
      DeadLetterConfig: {
        Arn: dlqArn,
      },
    },
    FlexibleTimeWindow: {
      Mode: "FLEXIBLE",
      MaximumWindowInMinutes: 180, // 3h window to collect direct debit, from 2am to 5am
    },
    GroupName: groupName,
    ActionAfterCompletion: "DELETE",
  } as CreateScheduleCommandInput;
};

export const createSchedule = async (input: CreateScheduleInput): Promise<CreateScheduleCommandOutput | void> => {
  const logger = getLogger();
  const { accountId, paymentDate } = input;
  logger.addContext({ functionName: "createSchedule", accountId });
  logger.info({ message: "Creating schedule for event", input });

  const scheduleFound = await directDebitScheduleExists(accountId, input.repaymentType);

  if (scheduleFound) {
    logger.info({ message: "Schedule already exists for this account. Skipping." });
    return;
  }

  const client = new SchedulerClient({ region: process.env.REGION });
  const paymentDateDayjs = dayjs(paymentDate);

  if (paymentDateDayjs.toDate() < new Date()) {
    logger.error({ message: "Payment date is in the past. Skipping." });
    return;
  }

  const params = getCreateScheduleCommand(input, paymentDateDayjs);

  logger.info({ message: "Scheduling direct debit", params });
  const res = await client.send(new CreateScheduleCommand(params));
  if (!res) {
    logger.error({ message: "Failed to create schedule" });
    throw new Error("Failed to create schedule");
  }
  return res;
};
