import { DD_PAYMENTS_NAME_PREFIX, DD_RETRY_NAME_PREFIX } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { RepaymentType } from "@libs/types";
import { scheduleExists } from "@utils/schedulerUtil";

export const directDebitScheduleExists = async (accountId: string, repaymentType: RepaymentType): Promise<boolean> => {
  const logger = getLogger();

  logger.addContext({ functionName: "directDebitScheduleExists", accountId });

  const groupName =
    repaymentType === RepaymentType.DirectDebitRetry
      ? process.env.DD_RETRY_GROUP_NAME
      : process.env.DD_PAYMENTS_GROUP_NAME;

  const namePrefix =
    repaymentType === RepaymentType.DirectDebitRetry
      ? `${DD_RETRY_NAME_PREFIX}-${accountId}`
      : `${DD_PAYMENTS_NAME_PREFIX}-${accountId}`;

  return await scheduleExists({ groupName, namePrefix });
};
