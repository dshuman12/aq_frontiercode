import * as dbUtil from "src/utils/db";
import * as scheduleUtil from "./createSchedule";
import * as datalakeUtil from "@utils/schedulerUtil";
import { describe, expect, test, afterEach, vi, beforeEach } from "vitest";
import * as adapters from "@onmoapp/onmo-adapters";
import { mockGetAccount, mockGetCustomer, mockMessage, mockSchedule } from "./testUtils";
import { handler } from "./directDebitRepaymentScheduler";
import { RepaymentType } from "@libs/types";
vi.mock("@onmoapp/onmo-adapters");
vi.mock("src/utils/db");
vi.mock("./createSchedule");
vi.mock("@utils/schedulerUtil");

describe("directDebitRepaymentScheduler", () => {
  describe("Happy Path - All items successful", () => {
    let messages = [];
    beforeEach(async () => {
      messages = [];
    });
    afterEach(() => {
      vi.resetAllMocks();
      messages = [];
    });

    test("It should call the Mambu adapter for each message", async () => {
      const getCreditAccounMock = vi.fn();
      vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        messages.push(mockMessage(i));
      }
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(0);
      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(10);
      for (let i = 0; i < 10; i++) {
        expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenNthCalledWith(i + 1, `account-id-${i}`);
      }
    });
    test("It should create 10 schedules with the correct payment date", async () => {
      const getCreditAccounMock = vi.fn();
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
        messages.push(mockMessage(i));
      }
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(0);

      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(10);

      expect(createScheduleMockCalls[0][0]).toMatchObject({
        accountId: `account-id-0`,
        customerId: `customer-id-0`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-11-28T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[1][0]).toMatchObject({
        accountId: `account-id-1`,
        customerId: `customer-id-1`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-11-28T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[2][0]).toMatchObject({
        accountId: `account-id-2`,
        customerId: `customer-id-2`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-11-29T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[3][0]).toMatchObject({
        accountId: `account-id-3`,
        customerId: `customer-id-3`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-02T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[4][0]).toMatchObject({
        accountId: `account-id-4`,
        customerId: `customer-id-4`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-03T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[5][0]).toMatchObject({
        accountId: `account-id-5`,
        customerId: `customer-id-5`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-04T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[6][0]).toMatchObject({
        accountId: `account-id-6`,
        customerId: `customer-id-6`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-05T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[7][0]).toMatchObject({
        accountId: `account-id-7`,
        customerId: `customer-id-7`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-05T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[8][0]).toMatchObject({
        accountId: `account-id-8`,
        customerId: `customer-id-8`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-05T02:00:00.000Z",
      });
      expect(createScheduleMockCalls[9][0]).toMatchObject({
        accountId: `account-id-9`,
        customerId: `customer-id-9`,
        repaymentType: RepaymentType.DirectDebit,
        paymentDate: "2024-12-06T02:00:00.000Z",
      });
    });
  });
  describe("Sad Path - Some failed items", () => {
    let messages = [];
    beforeEach(async () => {
      messages = [];
    });
    afterEach(() => {
      vi.resetAllMocks();
      messages = [];
    });

    test("No user found - it should fail that message and process the others", async () => {
      const getCreditAccounMock = vi.fn();
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
        messages.push(mockMessage(i));
      }
      messages.push(mockMessage(10)); // fail message
      vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce({ error: "User not found" });

      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(1);
      expect(result.batchItemFailures[0].itemIdentifier).toBe("message-id-10");

      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(10);
      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(10);
    });

    test("No account found - it should fail that message and process the others", async () => {
      const getCreditAccounMock = vi.fn();
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
        messages.push(mockMessage(i));
      }
      messages.push(mockMessage(10)); // fail message
      vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(10));
      getCreditAccounMock.mockResolvedValueOnce({ error: "Account not found" });

      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(1);
      expect(result.batchItemFailures[0].itemIdentifier).toBe("message-id-10");

      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(11);
      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(10);
    });

    test("No direct debit settings on account - it should fail that message and process the others", async () => {
      const getCreditAccounMock = vi.fn();
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
        messages.push(mockMessage(i));
      }
      messages.push(mockMessage(10)); // fail message
      vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(10));
      getCreditAccounMock.mockResolvedValueOnce({
        data: {
          accountDetails: {
            customerId: "customer-id-10",
          },
        },
      });

      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(1);
      expect(result.batchItemFailures[0].itemIdentifier).toBe("message-id-10");

      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(11);
      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(10);
    });

    test("Account is linked to a different user - it should fail that message and process the others", async () => {
      const getCreditAccounMock = vi.fn();
      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);
        messages.push(mockMessage(i));
      }
      messages.push(mockMessage(10)); // fail message
      vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(10));
      getCreditAccounMock.mockResolvedValueOnce({
        data: {
          accountDetails: {
            customerId: "another-customer-id",
          },
        },
      });

      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(1);
      expect(result.batchItemFailures[0].itemIdentifier).toBe("message-id-10");

      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(11);
      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(10);
    });

    test("Error thrown while creating a schedule - it should fail that message and process the others", async () => {
      const getCreditAccounMock = vi.fn();
      vi.mocked(datalakeUtil.putScheduleDataInDatalakeS3).mockResolvedValue(undefined);

      for (let i = 0; i < 10; i++) {
        getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(i));
        vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(i));
        vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockResolvedValueOnce(mockSchedule(i));
        messages.push(mockMessage(i));
      }
      messages.push(mockMessage(10)); // fail message
      getCreditAccounMock.mockResolvedValueOnce(mockGetAccount(10));
      vi.mocked(dbUtil, { partial: true }).getCustomer.mockResolvedValueOnce(mockGetCustomer(10));

      vi.mocked(scheduleUtil.createSchedule, { partial: true }).mockRejectedValueOnce({ error: "Error" });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: getCreditAccounMock,
      });

      const result = await handler({ Records: messages });
      expect(result.batchItemFailures.length).toBe(1);
      expect(result.batchItemFailures[0].itemIdentifier).toBe("message-id-10");

      const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
      expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledTimes(11);
      const createScheduleMockCalls = await vi.mocked(scheduleUtil.createSchedule).mock.calls;
      expect(createScheduleMockCalls.length).toBe(11);
    });
  });
});
