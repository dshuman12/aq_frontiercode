import { describe, vi, test, expect, beforeEach } from "vitest";
import * as scheduleExistUtil from "./directDebitScheduleExists";
import { CreateScheduleCommand, SchedulerClient } from "@aws-sdk/client-scheduler";
import { createSchedule } from "./createSchedule";
import dayjs from "dayjs";
import { RepaymentType } from "@libs/types";

vi.mock("./directDebitScheduleExists");
vi.mock("@aws-sdk/client-scheduler", async () => {
  const originalModule = await vi.importActual("@aws-sdk/client-scheduler");
  return {
    ...originalModule,
    SchedulerClient: vi.fn(() => ({
      send: vi.fn(),
    })),
    CreateScheduleCommand: vi.fn(),
  };
});

describe("createSchedule", () => {
  let sendMock: ReturnType<typeof vi.fn>;
  let createCommandMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    vi.resetAllMocks();
    sendMock = vi.fn().mockResolvedValue({ ok: "true" });
    createCommandMock = vi.fn();
    (SchedulerClient as unknown as ReturnType<typeof vi.fn>).mockImplementation(() => ({
      send: sendMock,
    }));
    (CreateScheduleCommand as unknown as ReturnType<typeof vi.fn>).mockImplementation(createCommandMock);
  });

  describe("When a schedule already exists for the accountId", () => {
    beforeEach(() => {
      vi.mocked(scheduleExistUtil.directDebitScheduleExists).mockResolvedValue(true);
    });
    test("It should not create a schedule", async () => {
      const input = {
        accountId: "account-id",
        customerId: "customer-id",
        paymentDate: "2025-01-01T02:00:00Z",
        repaymentType: RepaymentType.DirectDebit,
        idempotencyKey: "idempotency-key",
      };
      await createSchedule(input);
      expect(sendMock).not.toHaveBeenCalled();
    });
  });

  describe("When no schedules exist for the accountId", () => {
    beforeEach(() => {
      vi.mocked(scheduleExistUtil.directDebitScheduleExists).mockResolvedValue(false);
    });
    test("It should create a new schedule on the given paymentDate for the accountId", async () => {
      const tomorrow = dayjs().add(1, "day").format("YYYY-MM-DD");
      const input = {
        accountId: "account-id",
        customerId: "customer-id",
        paymentDate: `${tomorrow}T02:00:00Z`,
        repaymentType: RepaymentType.DirectDebit,
        idempotencyKey: "idempotency-key",
      };
      await createSchedule(input);
      expect(sendMock).toHaveBeenCalled();
      expect(createCommandMock.mock.calls[0][0]).toMatchObject({
        Name: `dd-payment-account-id-${tomorrow}`,
        ScheduleExpression: `at(${tomorrow}T02:00:00)`,
        Target: {
          Input: JSON.stringify({
            accountId: "account-id",
            customerId: "customer-id",
            dueDate: `${tomorrow}T02:00:00.000Z`,
            repaymentType: RepaymentType.DirectDebit,
            idempotencyKey: "idempotency-key",
          }),
        },
        FlexibleTimeWindow: {
          Mode: "FLEXIBLE",
          MaximumWindowInMinutes: 180,
        },
        GroupName: process.env.DD_PAYMENTS_GROUP_NAME,
        ActionAfterCompletion: "DELETE",
      });
    });
  });
});
