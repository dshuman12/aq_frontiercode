import { SQSRecord } from "aws-lambda";
import dayjs from "dayjs";

export const mockGetAccount = (index: number) => ({
  data: {
    accountDetails: {
      customerId: `customer-id-${index}`,
    },
    directDebitSettings: {
      nextDirectDebitAmount: index * 10 + 1,
      mandateID: `mandate-id-${index}`,
    },
  },
});

export const mockGetCustomer = (index: number) => ({
  data: {
    customerId: `customer-id-${index}`,
    accountId: `"account-id"-${index}`,
    address: "",
    email: `fake${index}@fake.com`,
    mambuID: `mambu-id-${index}`,
    pspCustomerId: `psp-customer-id-${index}`,
  },
});

export const mockSchedule = (index: number) => ({
  $metadata: {},
  ScheduleArn: `arn:aws:events:us-west-2:123456789012:rule/my-schedule-${index}`,
});

export const mockMessage = (index: number): SQSRecord => {
  const dueDate = dayjs()
    .set("year", 2024)
    .set("month", 11)
    .set("date", index + 1);
  return {
    body: JSON.stringify({
      accountId: `account-id-${index}`,
      customerId: `customer-id-${index}`,
      dueDate: dueDate.toISOString(),
    }),
    messageId: `message-id-${index}`,
    md5OfBody: "",
    messageAttributes: {},
    awsRegion: process.env.REGION,
    eventSource: "eventSource",
    eventSourceARN: "eventSourceARN",
    receiptHandle: "",
    attributes: {
      SenderId: "senderId",
      ApproximateFirstReceiveTimestamp: "0",
      ApproximateReceiveCount: "0",
      SentTimestamp: "0",
    },
  };
};
