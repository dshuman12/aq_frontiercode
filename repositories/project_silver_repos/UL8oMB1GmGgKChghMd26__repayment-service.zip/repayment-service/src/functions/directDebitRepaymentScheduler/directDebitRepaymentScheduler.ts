import { SQSEvent, SQSRecord } from "aws-lambda";
import { getLogger } from "@libs/logger";
import { DirectDebitRepaymentDue } from "@shared-types/sqs-types";
import { coreBankingAdapter, MambuClient } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { createSchedule } from "./createSchedule";
import { Logger } from "@onmoapp/onmo-logger";
import dayjs from "dayjs";
import { v4 as uuid } from "uuid";
import { formatErrorMessage } from "src/utils/errorUtil";
import { logAndReturnFailedMessage } from "src/utils/sqsUtils";
import { getPaymentRequestDate } from "@utils/directDebitUtil";
import { RepaymentType } from "@libs/types";
import { putScheduleDataInDatalakeS3 } from "@utils/schedulerUtil";

type ProcessRepaymentDueOutcome = {
  success?: DirectDebitRepaymentDue;
  error?: {
    message: string;
    sqsMessageId: string;
  };
};

type ProcessRepaymentDueInput = {
  sqsRecord: SQSRecord;
  coreBankingClient: MambuClient;
  logger: Logger;
};

export const handler = async (event: SQSEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "directDebitRepaymentScheduler" });
  logger.info({ message: "Received event", event });

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const promises = event.Records.map((sqsRecord) => processRepaymentDue({ sqsRecord, coreBankingClient, logger }));
  const result = await Promise.all(promises); // Process items in parallel
  const batchItemFailures = result
    .filter((result) => result.error)
    .map((r) => ({
      itemIdentifier: r.error.sqsMessageId,
    }));

  return { batchItemFailures }; // Report failed messages for SQS to handle the retry without invalidating the whole batch
};

const processRepaymentDue = async ({
  sqsRecord,
  coreBankingClient,
  logger,
}: ProcessRepaymentDueInput): Promise<ProcessRepaymentDueOutcome> => {
  const event = JSON.parse(sqsRecord.body) as DirectDebitRepaymentDue;
  const { accountId, customerId, dueDate } = event;

  const customerResult = await getCustomer(customerId);

  if (customerResult.error) {
    return logAndReturnFailedMessage({ sqsRecord, message: customerResult.error, logger });
  }
  const customer = customerResult.data;

  const accountResult = await coreBankingClient.getCreditAccount(accountId);
  if (accountResult.error) {
    return logAndReturnFailedMessage({ sqsRecord, message: accountResult.error.errorMessage, logger });
  }

  const accountData = accountResult.data;

  const ddSettings = accountData.directDebitSettings;
  if (!ddSettings || !ddSettings.mandateID) {
    return logAndReturnFailedMessage({
      sqsRecord,
      message: `Account ${accountId} does not have proper direct debit settings.`,
      logger,
    });
  }

  if (accountData.accountDetails.customerId !== customer.customerId) {
    return logAndReturnFailedMessage({
      sqsRecord,
      message: `Account ${accountId} does not belong to ${customerId}`,
      logger,
    });
  }

  const paymentDate = getPaymentRequestDate(dueDate);
  const paymentDate2am = dayjs(paymentDate).set("hour", 2).set("minute", 0).set("second", 0).set("millisecond", 0);
  logger.info({ message: `Mambu due date: ${dueDate} - Payment date: ${paymentDate2am.toISOString()}` });

  try {
    const response = await createSchedule({
      accountId,
      customerId,
      paymentDate: paymentDate2am.toISOString(),
      repaymentType: RepaymentType.DirectDebit,
      idempotencyKey: uuid(), // One unique ID for each payment scheduled for safe retries in the EventBridge Scheduler
    });
    if (response) {
      logger.info({
        message: `Schedule created for account ${accountId} - ${response.ScheduleArn}. Storing data to S3 for datalake`,
      });

      const scheduleDataForDatalake = {
        accountId,
        customerId,
        dateIntentWillBeCreated: paymentDate2am.toISOString(),
        dueDate,
        repaymentType: RepaymentType.DirectDebit,
        dateScheduleCreated: dayjs().toISOString(),
      };

      await putScheduleDataInDatalakeS3({ customerId, scheduleDataForDatalake, logger });

      logger.info(`Stored schedule data to S3 for datalake`);
    }
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    return logAndReturnFailedMessage({ logger, message: errorMessage, sqsRecord });
  }

  return {
    success: event,
  };
};
