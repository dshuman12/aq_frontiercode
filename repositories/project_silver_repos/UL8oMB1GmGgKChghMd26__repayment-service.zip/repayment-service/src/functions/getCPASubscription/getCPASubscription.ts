
import { formatJSONResponse } from "@libs/gatewayUtils";
import { APIGatewayEventHandler, DirectDebitError } from "@libs/types";
import { Logger } from "@onmoapp/onmo-logger";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { getCustomer } from "src/utils/db";
import { getSSMParameter } from "@utils/ssmUtil";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(utc);
dayjs.extend(timezone);

const TIMEZONE = "Europe/London";

const env = process.env.ENVIRONMENT;

export type CPASubscriptionDetails = {
  isInCPA: boolean;
  daysFromCPA: number | null;
  nextCPADueDate: string | null;
  cpaPaymentAmount: number | null;
  cpaStatus: string | null;
  cpaPaymentFailed: boolean;
  cpaAttemptCount: number | null;
  cpaNextRetryDate: string | null;
  cpaCancelled: boolean;
  cpaCancellationReason: string | null;
};

export type CPASubscriptionOutcome = CPASubscriptionDetails;

const NO_CPA_RESPONSE: CPASubscriptionOutcome = {
  isInCPA: false,
  daysFromCPA: null,
  nextCPADueDate: null,
  cpaPaymentAmount: null,
  cpaStatus: null,
  cpaPaymentFailed: false,
  cpaAttemptCount: null,
  cpaNextRetryDate: null,
  cpaCancelled: false,
  cpaCancellationReason: null,
};

const DEFAULT_CANCELLED_WINDOW_DAYS = 7;

const getCancelledWindowSeconds = async (): Promise<number> => {
  const logger = new Logger({ env });
  const ssmParamName = process.env.CPA_CANCELLED_WINDOW_DAYS_SSM_PARAM;
  if (ssmParamName) {
    try {
      const paramValue = await getSSMParameter(ssmParamName);
      const days = parseInt(paramValue, 10);
      if (!isNaN(days) && days > 0) {
        logger.info({ message: "Using CPA cancelled window from SSM", days, seconds: days * 24 * 60 * 60 });
        return days * 24 * 60 * 60;
      }
    } catch (error) {
      logger.warn({ message: "Failed to fetch CPA cancelled window from SSM, using default", error });
    }
  }
  logger.info({ message: "Using default CPA cancelled window", days: DEFAULT_CANCELLED_WINDOW_DAYS });
  return DEFAULT_CANCELLED_WINDOW_DAYS * 24 * 60 * 60;
};

const calculateDaysFromCPA = (currentPeriodEndTimestamp: number, testClockFrozenTime: number | null): number => {
  const now = testClockFrozenTime
    ? dayjs.unix(testClockFrozenTime).tz(TIMEZONE)
    : dayjs().tz(TIMEZONE);

  const paymentDate = dayjs.unix(currentPeriodEndTimestamp).tz(TIMEZONE);

  const diffDays = paymentDate.startOf("day").diff(now.startOf("day"), "day");

  return diffDays;
};

const formatUnixTimestampToDate = (timestamp: number): string => {
  return dayjs.unix(timestamp).tz(TIMEZONE).format("YYYY-MM-DD");
};

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "getCPASubscription" });
  logger.info(event);

  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    logger.info("Missing onmouuid from authorizer.");
    return formatJSONResponse<DirectDebitError>({ statusCode: 401, body: { message: "Unauthorized." } });
  }

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!customer.pspCustomerId) {
    // Customer doesn't have a Stripe customer ID, so they can't have a CPA subscription
    logger.info("Customer does not have a pspCustomerId, returning no CPA");
    return formatJSONResponse<CPASubscriptionOutcome>({
      statusCode: 200,
      body: NO_CPA_RESPONSE,
    });
  }

  logger.addContext({ customerId: customer.customerId, pspCustomerId: customer.pspCustomerId });

  const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
    stageName: env as "staging" | "prod",
  });

  if (!repaymentClient) {
    logger.error("Error building repayment client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  try {
    const subscriptionsResult = await repaymentClient.getSubscriptionsByPsPCustomerId(customer.pspCustomerId);

    logger.info({ subscriptionsResult });

    // Priority: active > past_due > recently canceled
    const activeSubscription = subscriptionsResult.subscriptions.find((sub) => sub.status === "active");
    const pastDueSubscription = subscriptionsResult.subscriptions.find((sub) => sub.status === "past_due");
    const nowSeconds = subscriptionsResult.testClockFrozenTime ?? Math.floor(Date.now() / 1000);
    const cancelledWindowSeconds = await getCancelledWindowSeconds();
    logger.info({
      message: "Cancelled window check",
      nowSeconds,
      cancelledWindowSeconds,
      usingTestClock: !!subscriptionsResult.testClockFrozenTime,
    });
    const canceledSubscription = subscriptionsResult.subscriptions.find(
      (sub) => {
        if (sub.status !== "canceled" || !sub.canceledAt) return false;
        // Only show cancelled CPA status within the window for payment_failed cancellations
        // Other reasons (balance_paid, end_date_reached, manual) should not keep isInCPA true
        if (sub.cancellationReason !== "payment_failed") return false;
        const elapsed = nowSeconds - sub.canceledAt;
        logger.info({ message: "Checking cancelled sub", subId: sub.subscriptionId, canceledAt: sub.canceledAt, cancellationReason: sub.cancellationReason, elapsed, windowSeconds: cancelledWindowSeconds, withinWindow: elapsed < cancelledWindowSeconds });
        return elapsed < cancelledWindowSeconds;
      },
    );

    // 1. Active subscription — happy path
    if (activeSubscription) {
      const subscription = activeSubscription;
      const daysFromCPA = calculateDaysFromCPA(subscription.currentPeriodEnd, subscriptionsResult.testClockFrozenTime);
      const nextCPADueDate = formatUnixTimestampToDate(subscription.currentPeriodEnd);
      const cpaPaymentAmount = subscription.amount != null ? subscription.amount / 100 : null;

      logger.info({
        message: "Active CPA subscription found",
        daysFromCPA,
        nextCPADueDate,
        cpaPaymentAmount,
        status: subscription.status,
      });

      return formatJSONResponse<CPASubscriptionOutcome>({
        statusCode: 200,
        body: {
          isInCPA: true,
          daysFromCPA,
          nextCPADueDate,
          cpaPaymentAmount,
          cpaStatus: subscription.status,
          cpaPaymentFailed: false,
          cpaAttemptCount: null,
          cpaNextRetryDate: null,
          cpaCancelled: false,
          cpaCancellationReason: null,
        },
      });
    }

    // 2. Past due subscription — payment failed, fetch invoice for details
    if (pastDueSubscription) {
      const subscription = pastDueSubscription;
      let cpaPaymentAmount = subscription.amount != null ? subscription.amount / 100 : null;

      let cpaAttemptCount: number | null = null;
      let cpaNextRetryDate: string | null = null;

      try {
        const invoice = await repaymentClient.getLatestInvoiceForSubscription(subscription.subscriptionId, "open");
        if (invoice) {
          cpaAttemptCount = invoice.attemptCount;
          cpaNextRetryDate = invoice.nextPaymentAttempt ? formatUnixTimestampToDate(invoice.nextPaymentAttempt) : null;
          cpaPaymentAmount = invoice.amountDue / 100;
        }
      } catch (invoiceError) {
        logger.error({ message: "Error fetching invoice for past_due subscription", error: invoiceError });
        // Continue with null details — we still know payment failed
      }

      logger.info({
        message: "Past due CPA subscription found",
        cpaPaymentAmount,
        cpaAttemptCount,
        cpaNextRetryDate,
        status: subscription.status,
      });

      return formatJSONResponse<CPASubscriptionOutcome>({
        statusCode: 200,
        body: {
          isInCPA: true,
          daysFromCPA: null,
          nextCPADueDate: null,
          cpaPaymentAmount,
          cpaStatus: subscription.status,
          cpaPaymentFailed: true,
          cpaAttemptCount,
          cpaNextRetryDate,
          cpaCancelled: false,
          cpaCancellationReason: null,
        },
      });
    }

    // 3. Recently canceled subscription (within 7 days)
    if (canceledSubscription) {
      const subscription = canceledSubscription;
      let cpaPaymentAmount = subscription.amount != null ? subscription.amount / 100 : null;

      try {
        const invoice = await repaymentClient.getLatestInvoiceForSubscription(subscription.subscriptionId);
        if (invoice) {
          cpaPaymentAmount = invoice.amountDue / 100;
        }
      } catch (invoiceError) {
        logger.error({ message: "Error fetching invoice for canceled subscription", error: invoiceError });
      }

      // If the subscription had a scheduled end date (cancel_at) and was canceled at/after that date,
      // we can infer the cancellation reason was reaching the end date rather than a user-initiated cancellation or payment failure
      const isScheduledEnd =
        subscription.cancelAt && subscription.canceledAt && subscription.canceledAt >= subscription.cancelAt;

      const cpaCancellationReason = isScheduledEnd ? "end_date_reached" : (subscription.cancellationReason ?? null);

      logger.info({
        message: "Recently canceled CPA subscription found",
        cpaPaymentAmount,
        cancellationReason: subscription.cancellationReason,
        isScheduledEnd,
        cpaCancellationReason,
        canceledAt: subscription.canceledAt,
        cancelAt: subscription.cancelAt,
        status: subscription.status,
      });

      return formatJSONResponse<CPASubscriptionOutcome>({
        statusCode: 200,
        body: {
          isInCPA: true,
          daysFromCPA: null,
          nextCPADueDate: null,
          cpaPaymentAmount,
          cpaStatus: subscription.status,
          cpaPaymentFailed: false,
          cpaAttemptCount: null,
          cpaNextRetryDate: null,
          cpaCancelled: true,
          cpaCancellationReason,
        },
      });
    }

    // No relevant subscriptions found
    logger.info("No relevant CPA subscriptions found");
    return formatJSONResponse<CPASubscriptionOutcome>({
      statusCode: 200,
      body: NO_CPA_RESPONSE,
    });
  } catch (error) {
    logger.error({ message: "Error fetching CPA subscriptions", error });
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }
};
