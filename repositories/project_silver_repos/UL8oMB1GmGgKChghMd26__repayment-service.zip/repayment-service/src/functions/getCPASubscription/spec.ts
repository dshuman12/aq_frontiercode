import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono();

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: "Bad Request",
  }),
});

const CPASubscriptionOutcome = z.object({
  isInCPA: z.boolean().openapi({
    example: true,
    description: "Whether the customer has an active CPA subscription",
  }),
  daysFromCPA: z.number().nullable().openapi({
    example: 5,
    description: "Number of days until the next CPA payment (positive = future, negative = past)",
  }),
  nextCPADueDate: z.string().nullable().openapi({
    example: "2026-02-09",
    description: "The date of the next CPA payment in ISO format (YYYY-MM-DD)",
  }),
  cpaPaymentAmount: z.number().nullable().openapi({
    example: 25.0,
    description: "The amount of the CPA payment in pounds",
  }),
  cpaStatus: z.string().nullable().openapi({
    example: "active",
    description: "The status of the CPA subscription",
  }),
  cpaPaymentFailed: z.boolean().openapi({
    example: false,
    description: "Whether the CPA payment has failed",
  }),
  cpaAttemptCount: z.number().nullable().openapi({
    example: null,
    description: "The number of payment attempts made for the current billing period",
  }),
  cpaNextRetryDate: z.string().nullable().openapi({
    example: null,
    description: "The date of the next payment retry attempt in ISO format (YYYY-MM-DD)",
  }),
  cpaCancelled: z.boolean().openapi({
    example: false,
    description: "Whether the CPA subscription has been cancelled",
  }),
  cpaCancellationReason: z.string().nullable().openapi({
    example: null,
    description: "The reason for CPA subscription cancellation",
  }),
});

app.openapi(
  createRoute({
    method: "get",
    path: "/cpa/subscription",
    security: [
      {
        Bearer: [],
      },
    ],
    description: "Get CPA (Continuous Payment Authority) subscription details for the authenticated customer",
    responses: {
      200: {
        description: "Returns CPA subscription details",
        content: {
          "application/json": {
            schema: CPASubscriptionOutcome,
          },
        },
      },
      401: {
        content: {
          "application/json": {
            schema: ErrorSchema,
          },
        },
        description: "Unauthorized - missing or invalid authentication",
      },
      500: {
        content: {
          "application/json": {
            schema: ErrorSchema,
          },
        },
        description: "Internal server error",
      },
    },
  }),
  (c) => {
    return c.json({
      isInCPA: true,
      daysFromCPA: 5,
      nextCPADueDate: "2026-02-09",
      cpaPaymentAmount: 25.0,
      cpaStatus: "active",
      cpaPaymentFailed: false,
      cpaAttemptCount: null,
      cpaNextRetryDate: null,
      cpaCancelled: false,
      cpaCancellationReason: null,
    });
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: "Custom Message",
        },
        500,
      );
    }
  },
);

export default app;
