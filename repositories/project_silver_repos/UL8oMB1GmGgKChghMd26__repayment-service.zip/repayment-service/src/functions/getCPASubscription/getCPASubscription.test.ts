import { describe, it, expect, vi, beforeEach } from "vitest";
import { handler, CPASubscriptionOutcome } from "./getCPASubscription";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import * as db from "src/utils/db";

vi.mock("@onmoapp/core-repayments");
vi.mock("src/utils/db");
vi.mock("@onmoapp/onmo-logger", () => ({
  Logger: vi.fn().mockImplementation(() => ({
    addContext: vi.fn(),
    info: vi.fn(),
    error: vi.fn(),
  })),
}));

const DEFAULT_NEW_FIELDS = {
  cpaPaymentFailed: false,
  cpaAttemptCount: null,
  cpaNextRetryDate: null,
  cpaCancelled: false,
  cpaCancellationReason: null,
};

describe("getCPASubscription", () => {
  const mockEvent = {
    requestContext: {
      authorizer: {
        onmouuid: "test-customer-id",
      },
    },
  } as any;

  const mockCustomer = {
    customerId: "test-customer-id",
    pspCustomerId: "cus_stripe123",
    accountId: "ACC123",
    mambuID: "MAMBU123",
    email: "test@example.com",
    address: "123 Test St",
  };

  beforeEach(() => {
    vi.clearAllMocks();
    process.env.ENVIRONMENT = "staging";
  });

  it("should return 401 if customer ID is missing from authorizer", async () => {
    const eventWithoutCustomerId = {
      requestContext: {
        authorizer: {},
      },
    } as any;

    const result = await handler(eventWithoutCustomerId);

    expect(result.statusCode).toBe(401);
    expect(result.body).toEqual({ message: "Unauthorized." });
  });

  it("should return isInCPA=false when customer has no pspCustomerId", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: { ...mockCustomer, pspCustomerId: undefined },
      error: null,
    });

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(false);
    expect(body.daysFromCPA).toBeNull();
    expect(body.nextCPADueDate).toBeNull();
    expect(body.cpaPaymentAmount).toBeNull();
    expect(body.cpaStatus).toBeNull();
    expect(body.cpaPaymentFailed).toBe(false);
    expect(body.cpaAttemptCount).toBeNull();
    expect(body.cpaNextRetryDate).toBeNull();
    expect(body.cpaCancelled).toBe(false);
    expect(body.cpaCancellationReason).toBeNull();
  });

  it("should return isInCPA=false when customer has no active subscriptions", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 0,
        testClockFrozenTime: null,
        subscriptions: [],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(false);
    expect(body).toMatchObject(DEFAULT_NEW_FIELDS);
  });

  it("should return CPA details when customer has active subscription", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    // Unix timestamp for Feb 9, 2026 00:00:00 UTC
    const futureTimestamp = Math.floor(new Date("2026-02-09T00:00:00Z").getTime() / 1000);

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_123",
            status: "active",
            currentPeriodEnd: futureTimestamp,
            amount: 2500, // £25.00 in pence
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.nextCPADueDate).toBe("2026-02-09");
    expect(body.cpaPaymentAmount).toBe(25);
    expect(body.cpaStatus).toBe("active");
    expect(typeof body.daysFromCPA).toBe("number");
    expect(body).toMatchObject(DEFAULT_NEW_FIELDS);
  });

  it("should filter out canceled subscriptions older than 7 days", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const eightDaysAgo = Math.floor(Date.now() / 1000) - 8 * 24 * 60 * 60;

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 2,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_123",
            status: "canceled",
            currentPeriodEnd: 1739001600,
            amount: 2500,
            canceledAt: eightDaysAgo,
            cancellationReason: "payment_failed",
          },
          {
            subscriptionId: "sub_456",
            status: "unpaid",
            currentPeriodEnd: 1739001600,
            amount: 3000,
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(false);
  });

  it("should include trialing subscriptions as active", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const futureTimestamp = Math.floor(new Date("2026-02-15T00:00:00Z").getTime() / 1000);

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_trial",
            status: "trialing",
            currentPeriodEnd: futureTimestamp,
            amount: 1500, // £15.00
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    // trialing is not active/past_due/canceled, so no relevant subscription
    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(false);
  });

  it("should return 500 when getCustomer fails", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: null,
      error: "Database error",
    });

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(500);
    expect(result.body).toEqual({ message: "Internal Server Error" });
  });

  it("should return 500 when CoreRepaymentsFactory.build fails", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(null);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(500);
    expect(result.body).toEqual({ message: "Internal Server Error" });
  });

  it("should return 500 when Stripe API call fails", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockRejectedValue(new Error("Stripe API error")),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(500);
    expect(result.body).toEqual({ message: "Internal Server Error" });
  });

  // New tests for failure/cancellation logic

  it("should return failure details for past_due subscription", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_past_due",
            status: "past_due",
            currentPeriodEnd: 1739001600,
            amount: 5000, // £50.00
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
      getLatestInvoiceForSubscription: vi.fn().mockResolvedValue({
        invoiceId: "inv_123",
        status: "open",
        attemptCount: 2,
        nextPaymentAttempt: Math.floor(new Date("2026-03-01T00:00:00Z").getTime() / 1000),
        amountDue: 5000,
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.cpaPaymentFailed).toBe(true);
    expect(body.cpaAttemptCount).toBe(2);
    expect(body.cpaNextRetryDate).toBe("2026-03-01");
    expect(body.cpaPaymentAmount).toBe(50);
    expect(body.cpaStatus).toBe("past_due");
    expect(body.cpaCancelled).toBe(false);
    expect(body.daysFromCPA).toBeNull();
    expect(body.nextCPADueDate).toBeNull();
  });

  it("should use invoice amountDue for past_due subscription when manual repayments reduced the amount", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_past_due",
            status: "past_due",
            currentPeriodEnd: 1739001600,
            amount: 5000, // £50.00 — this is the next invoice preview (wrong)
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
      getLatestInvoiceForSubscription: vi.fn().mockResolvedValue({
        invoiceId: "inv_123",
        status: "open",
        attemptCount: 1,
        nextPaymentAttempt: Math.floor(new Date("2026-03-01T00:00:00Z").getTime() / 1000),
        amountDue: 2000, // £20.00 — actual failed amount after £30 manual repayment
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.cpaPaymentAmount).toBe(20); // Should use invoice amount, not subscription amount
    expect(body.cpaPaymentFailed).toBe(true);
  });

  it("should return cancellation details for recently canceled subscription with invoice amount", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const recentCancelTime = Math.floor(Date.now() / 1000) - 2 * 24 * 60 * 60; // 2 days ago

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_canceled",
            status: "canceled",
            currentPeriodEnd: 1739001600,
            amount: 3000, // £30.00 — base subscription price
            canceledAt: recentCancelTime,
            cancellationReason: "payment_failed",
          },
        ],
      }),
      getLatestInvoiceForSubscription: vi.fn().mockResolvedValue({
        invoiceId: "inv_456",
        status: "void",
        attemptCount: 2,
        nextPaymentAttempt: null,
        amountDue: 1500, // £15.00 — actual amount after manual repayments
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.cpaCancelled).toBe(true);
    expect(body.cpaCancellationReason).toBe("payment_failed");
    expect(body.cpaPaymentAmount).toBe(15); // Should use invoice amount, not subscription amount
    expect(body.cpaStatus).toBe("canceled");
    expect(body.cpaPaymentFailed).toBe(false);
  });

  it("should return isInCPA=false for canceled subscription older than 7 days", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const oldCancelTime = Math.floor(Date.now() / 1000) - 10 * 24 * 60 * 60; // 10 days ago

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_old_canceled",
            status: "canceled",
            currentPeriodEnd: 1739001600,
            amount: 3000,
            canceledAt: oldCancelTime,
            cancellationReason: "payment_failed",
          },
        ],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(false);
  });

  it("should prioritize active over past_due subscription", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const futureTimestamp = Math.floor(new Date("2026-03-15T00:00:00Z").getTime() / 1000);

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 2,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_past_due",
            status: "past_due",
            currentPeriodEnd: 1739001600,
            amount: 5000,
            canceledAt: null,
            cancellationReason: null,
          },
          {
            subscriptionId: "sub_active",
            status: "active",
            currentPeriodEnd: futureTimestamp,
            amount: 2500,
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.cpaStatus).toBe("active");
    expect(body.cpaPaymentFailed).toBe(false);
    expect(body.cpaPaymentAmount).toBe(25);
  });

  it("should prioritize past_due over canceled subscription", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const recentCancelTime = Math.floor(Date.now() / 1000) - 2 * 24 * 60 * 60;

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 2,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_canceled",
            status: "canceled",
            currentPeriodEnd: 1739001600,
            amount: 3000,
            canceledAt: recentCancelTime,
            cancellationReason: "payment_failed",
          },
          {
            subscriptionId: "sub_past_due",
            status: "past_due",
            currentPeriodEnd: 1739001600,
            amount: 5000,
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
      getLatestInvoiceForSubscription: vi.fn().mockResolvedValue(null),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.cpaStatus).toBe("past_due");
    expect(body.cpaPaymentFailed).toBe(true);
    expect(body.cpaCancelled).toBe(false);
  });

  it("should handle invoice fetch failure gracefully for past_due subscription", async () => {
    vi.mocked(db.getCustomer).mockResolvedValue({
      data: mockCustomer,
      error: null,
    });

    const mockRepaymentClient = {
      getSubscriptionsByPsPCustomerId: vi.fn().mockResolvedValue({
        count: 1,
        testClockFrozenTime: null,
        subscriptions: [
          {
            subscriptionId: "sub_past_due",
            status: "past_due",
            currentPeriodEnd: 1739001600,
            amount: 5000,
            canceledAt: null,
            cancellationReason: null,
          },
        ],
      }),
      getLatestInvoiceForSubscription: vi.fn().mockRejectedValue(new Error("Invoice fetch failed")),
    };

    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);

    const result = await handler(mockEvent);

    expect(result.statusCode).toBe(200);
    const body = result.body as CPASubscriptionOutcome;
    expect(body.isInCPA).toBe(true);
    expect(body.cpaPaymentFailed).toBe(true);
    expect(body.cpaAttemptCount).toBeNull();
    expect(body.cpaNextRetryDate).toBeNull();
    expect(body.cpaPaymentAmount).toBe(50);
  });
});
