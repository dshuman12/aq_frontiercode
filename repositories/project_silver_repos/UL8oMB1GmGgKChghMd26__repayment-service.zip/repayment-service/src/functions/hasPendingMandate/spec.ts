import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono();

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: "Bad Request",
  }),
});

const HasPendingMandateOutcome = z.object({
  hasPendingMandate: z.boolean(),
});

app.openapi(
  createRoute({
    method: "get",
    path: "/mandate/pending",
    security: [
      {
        Bearer: [],
      },
    ],
    responses: {
      200: {
        description: "Returns a boolean indicatinf if the user currently has any pending direct debit mandates.",
        content: {
          "application/json": {
            schema: HasPendingMandateOutcome,
          },
        },
      },
      500: {
        content: {
          "application/json": {
            schema: ErrorSchema,
          },
        },
        description: "Returns an error",
      },
    },
  }),
  (c) => {
    return c.json({
      hasPendingMandate: false,
    });
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: "Custom Message",
        },
        500,
      );
    }
  },
);

export default app;
