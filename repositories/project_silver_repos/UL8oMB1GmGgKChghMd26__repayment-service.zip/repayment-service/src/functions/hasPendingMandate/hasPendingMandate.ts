import { formatJSONResponse } from "@libs/gatewayUtils";
import { APIGatewayEventHandler, DirectDebitError } from "@libs/types";
import { Logger } from "@onmoapp/onmo-logger";
import { getCustomer } from "src/utils/db";
import { pspCustomerHasPendingMandate } from "src/utils/pendingMandateUtil";

export type HasPendingMandateOutcome = {
  hasPendingMandate: boolean;
};

export const handler = async (event: APIGatewayEventHandler) => {
  const env = process.env.ENVIRONMENT;
  const logger = new Logger({ env });
  logger.addContext({ functionName: "hasPendingMandate" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    logger.info("Missing onmouuid from authorizer.");
    return formatJSONResponse<DirectDebitError>({ statusCode: 401, body: { message: "Unauthorized." } });
  }

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await pspCustomerHasPendingMandate(customer.pspCustomerId);
  if (error) {
    logger.addContext({ errorDetails: error.message });
    logger.error("Error checking for pending mandate");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  return formatJSONResponse<HasPendingMandateOutcome>({
    statusCode: 200,
    body: { hasPendingMandate: data.hasPendingMandate },
  });
};
