import { describe, test, beforeEach, expect, vi, beforeAll, afterAll } from "vitest";
import { handler } from "./hasPendingMandate";
import * as dbUtil from "src/utils/db";
import * as pendingMandateUtil from "src/utils/pendingMandateUtil";

vi.mock("src/utils/db");
vi.mock("src/utils/pendingMandateUtil");

const oldEnv = process.env.ENVIRONMENT;

describe("hasPendingMandate", () => {
  beforeAll(() => {
    process.env.ENVIRONMENT = "local";
  });
  beforeEach(() => {
    vi.resetAllMocks();
  });
  afterAll(() => {
    process.env.ENVIRONMENT = oldEnv;
  });
  test("Happy Path - User has a pending mandate", async () => {
    vi.mocked(dbUtil.getCustomer).mockResolvedValue({
      data: {
        pspCustomerId: "psp-customer-id",
        accountId: "account-id",
        address: "",
        email: "email",
        customerId: "customer-id",
        mambuID: "mambu-id",
      },
      error: null,
    });
    vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
      data: { hasPendingMandate: true },
    });

    const event = {
      requestContext: {
        authorizer: { onmouuid: "customer-id" },
      },
    };
    const res = await handler(event);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({ hasPendingMandate: true });
  });
  test("Happy Path - User has no pending mandates", async () => {
    vi.mocked(dbUtil.getCustomer).mockResolvedValue({
      data: {
        pspCustomerId: "psp-customer-id",
        accountId: "account-id",
        address: "",
        email: "email",
        customerId: "customer-id",
        mambuID: "mambu-id",
      },
      error: null,
    });
    vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
      data: { hasPendingMandate: false },
    });

    const event = {
      requestContext: {
        authorizer: { onmouuid: "customer-id" },
      },
    };
    const res = await handler(event);
    expect(res.statusCode).toBe(200);
    expect(res.body).toMatchObject({ hasPendingMandate: false });
  });
  describe("Sad Path", () => {
    test("Missing OMNO UUID from authorizer", async () => {
      const event = {
        requestContext: {
          authorizer: { onmouuid: undefined },
        },
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(401);
      expect(response.body).toMatchObject({ message: "Unauthorized." });
    });
    test("Error fetching customer from DB", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error fetching customer" });

      const event = {
        requestContext: {
          authorizer: { onmouuid: "customer-id" },
        },
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(500);
      expect(response.body).toMatchObject({ message: "Internal Server Error" });
      const dbMock = vi.mocked(dbUtil);
      expect(dbMock.getCustomer).toHaveBeenCalledWith("customer-id");
    });
  });
});
