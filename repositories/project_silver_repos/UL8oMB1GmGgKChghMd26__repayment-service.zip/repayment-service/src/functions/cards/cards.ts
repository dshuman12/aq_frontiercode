import { getLogger } from "@libs/logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { APIGatewayEventHandler } from "@libs/types";

export type CardError = {
  message: string;
};

export type CardsOutcome = {
  paymentMethods: any[];
};

export async function handler(event: APIGatewayEventHandler): Promise<any> {
  const logger = getLogger();
  logger.addContext({ functionName: "repayments/cards" });

  const customerId = event?.requestContext?.authorizer?.onmouuid;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  logger.addContext({ customerId });

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError) {
    logger.error(`Error fetching customer details: ${customerError}`);
    return formatJSONResponse<CardError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ pspCustomerId: customer.pspCustomerId });

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  const paymentMethods = await repaymentClient.getPaymentMethodByPspCustomerId(customer.pspCustomerId);

  logger.info(paymentMethods);

  return formatJSONResponse<CardsOutcome>({ statusCode: 200, body: { paymentMethods: paymentMethods } });
}
