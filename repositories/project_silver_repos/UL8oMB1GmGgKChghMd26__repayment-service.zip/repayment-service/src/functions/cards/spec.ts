import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: 'Bad Request',
  }),
})


const CardOutputSchema = z.object({
  paymentMethodId: z.string(),
  type: z.string(),
  card: z.object({
    brand: z.string(),
    last4: z.string(),
    expiryMonth: z.number(),
    expiryYear: z.number(),
  }),
}).array()

app.openapi(
  createRoute({
    method: 'get',
    path: '/cards',
    security: [
      {
        Bearer: []
      }
    ],
    responses: {
      200: {
        description: 'returns a list of cards',
        content: {
          'application/json': {
            schema: CardOutputSchema
          }
        }
      },
      400: {
        content: {
          'application/json': {
            schema: ErrorSchema,
          },
        },
        description: 'Returns an error',
      },
    }
  }),
  (c) => {
    return c.json([
      {
        paymentMethodId: 'pmi_1234',
        type: 'card',
        card: {
          brand: 'visa',
          last4: '4242',
          expiryMonth: 12,
          expiryYear: 2024,
        },
      },
    ])
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 400,
          message: 'Custom Message',
        },
        400
      )
    }
  }
)

export default app
