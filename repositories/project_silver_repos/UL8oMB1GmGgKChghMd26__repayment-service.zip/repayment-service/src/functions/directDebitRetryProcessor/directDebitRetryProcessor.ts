import { getLogger } from "@libs/logger";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { formatErrorMessage, throwErrorIfAdapterResHaveError } from "src/utils/errorUtil";
import { UpdateCreditAccountOutcome, UpdateMandateRepayment } from "@onmoapp/onmo-types";
import { shouldRetryDirectDebit } from "@utils/directDebitUtil";
import { DirectDebitRetryProcessorEvent } from "@shared-types/sqs-types";
import { v4 as uuid } from "uuid";
import { RepaymentType } from "@libs/types";

export const handler = async (event: any) => {
  const logger = getLogger();
  logger.addContext({ functionName: "directDebitRetryProcesor" });
  logger.info({ message: "Received event", event });

  const ddRetryEvent = event as DirectDebitRetryProcessorEvent;

  const customer = await getCustomer(ddRetryEvent.customerId);

  if (customer.error || !customer.data) {
    logger.error(customer.error);
    throw new Error(`Error getting customer with ID: ${ddRetryEvent.customerId}, ${customer.error}`);
  }

  logger.addContext({ accountId: customer.data.accountId, customerId: ddRetryEvent.customerId });

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const creditAccount = await coreBankingClient.getCreditAccount(customer.data.accountId);

  const response = await shouldRetryDirectDebit({
    customer: customer.data,
    logger,
    creditAccount,
    paymentIntentId: ddRetryEvent.paymentIntentId,
  });

  throwErrorIfAdapterResHaveError(response, { message: "Error checking DD retry eligibility" });

  if (!response.data.shouldRetryDirectDebit) {
    logger.info({ message: response.data.reason });

    const updateDDRetryFields: UpdateCreditAccountOutcome = await coreBankingClient.updateDDRetryFields(
      ddRetryEvent.accountId,
      false,
      null,
      null,
      null,
    );
    throwErrorIfAdapterResHaveError(updateDDRetryFields, { message: "Failed to update dd retry fields" });
    logger.info({ message: "DD retry fields have been removed" });
    return;
  }

  logger.debug({ message: "Preparing payload for direct debit retry" });

  if (!response.data.retryAmount) {
    logger.error({ message: "Retry amount is undefined" });
    throw new Error("Retry amount is undefined");
  }

  if (!creditAccount.data.directDebitSettings.directDebitRetryInProgress) {
    logger.info({ message: "Direct debit retry flag is false." });
    throw new Error("Direct debit retry in progress is false");
  }

  const retryAmount = response.data.retryAmount;
  const { mandateID } = creditAccount.data.directDebitSettings;

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  const idempotencyKey = uuid();

  const amount = Number((retryAmount * 100).toFixed(2)); // Stripe requires amount in cents

  const payload = {
    amount,
    mandateId: mandateID,
    paymentIntentId: ddRetryEvent.paymentIntentId,
    repaymentType: RepaymentType.DirectDebitRetry,
  } as UpdateMandateRepayment;

  try {
    const result = await repaymentClient.updateMandateRepayment(payload);
    if (result.error) {
      throw new Error(result.error.errorMessage);
    }

    logger.info({ message: `Updated payment intention`, payload });

    const confirmedPaymentIntention = await repaymentClient.confirmPaymentIntent({
      paymentIntentId: payload.paymentIntentId,
      idempotencyKey: `${idempotencyKey}-confirm`,
    });

    logger.info({ message: "Confirmed payment intention", confirmedPaymentIntention });

    await coreBankingClient.setScheduledAmount(customer.data.accountId, retryAmount);
    logger.info({ message: "Scheduled amount set in Mambu account", retryAmount });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({
      message: "Alert_FailedToCreateIntent: Error processing direct debit repayment",
      error: errorMessage,
    });
    throw new Error("Error processing direct debit repayment");
  }
};
