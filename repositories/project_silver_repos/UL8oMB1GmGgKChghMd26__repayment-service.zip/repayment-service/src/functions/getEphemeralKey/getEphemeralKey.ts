import { BASE_PATH } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { RequestContextBindings } from "@libs/types";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { Hono } from "hono";
import { handle } from "hono/aws-lambda";
import { formatErrorMessage } from "src/utils/errorUtil";

const app = new Hono<{ Bindings: RequestContextBindings }>().basePath(`/${BASE_PATH}/*`);

export const directDebitHandler = app.get("/ephemeral-key", async (c) => {
  const logger = getLogger();

  logger.info("Getting Ephemeral Key");
  const { onmouuid: customerId } = c.env.event.requestContext.authorizer;

  const paymentMethodId = c.req.param("paymentMethodId");

  logger.addContext({ customerId, paymentMethodId, functionName: "getEphemeralKey" });

  if (!customerId) {
    logger.error("Customer ID missing");
    return c.json({ message: "Customer ID missing" }, 400);
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return c.json({ message: "Repayment client not found" }, 500);
  }

  let directDebitDetails;
  try {
    directDebitDetails = await repaymentClient.getPaymentMethod(paymentMethodId);
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error getting direct debit details: ${errorMessage}`);
    return c.json({ message: "Error getting direct debit details" }, 500);
  }

  return c.json({ directDebitDetails }, 200);
});

export const handler = handle(app);
export default handler;
