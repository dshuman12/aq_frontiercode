import { APIGatewayEventGet } from "@libs/types";
import { handler } from "./getPaymentReceiptBySessionId";
import * as adapters from "@onmoapp/onmo-adapters";
import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@onmoapp/onmo-adapters");

describe("getPaymentReceiptBySessionId handler", () => {
  const mockEvent = {
    pathParameters: {
      sessionId: "test-session-id",
    },
  } as unknown as APIGatewayEventGet;

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return 400 if sessionId is missing", async () => {
    const event = { pathParameters: {} } as unknown as APIGatewayEventGet;

    const response = await handler(event);

    expect(response.statusCode).toEqual(400);
    expect(response.body).toEqual({ message: "Missing sessionId in request" });
  });

  it("should return 404 if payment intent is not found", async () => {
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntentBySessionId: vi.fn().mockRejectedValue("Error retrieving payment intent"),
    });

    const response = await handler(mockEvent);

    expect(response.statusCode).toEqual(500);
    expect(response.body).toEqual({ message: "Internal Server Error" });
  });

  it("should return 200 with mapped payment intent if found", async () => {
    const mockPaymentIntent = {
      id: "test-intent-id",
      amount: 100,
      currency: "USD",
      receiptNumber: null,
      receiptUrl: "https://example.com/receipt",
    };

    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntentBySessionId: vi.fn().mockResolvedValue(mockPaymentIntent),
    });

    const response = await handler(mockEvent);

    expect(response.statusCode).toEqual(200);
    expect(response.body).toEqual({
      receiptUrl: "https://example.com/receipt",
      receiptNumber: null,
    });
  });
});
