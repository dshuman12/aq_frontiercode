import { getLogger } from "@libs/logger";
import { CustomerCreatedEventOutcome } from "@onmoapp/onmo-types";
import { getCustomer, updateCustomer } from "src/utils/db";

export const customerCreated = async (
  event: CustomerCreatedEventOutcome,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "customerCreated" });
  logger.info(event);

  if (!event.metadata?.customerId) {
    logger.error("CustomerId missing from customer.");
    return { statusCode: 500, message: "CustomerId missing from customer." };
  }
  const { data: customer, error: customerError } = await getCustomer(event.metadata.customerId);
  if (customerError) {
    logger.error(`Error fetching customer details: ${customerError}`);
    return { statusCode: 500, message: "Internal Server Error" };
  }

  if (customer.pspCustomerId === event.pspCustomerId) {
    logger.info("Customer already has up to date pspCustomerId. SKipping.");
    return { statusCode: 200, message: "Customer updated successfully." };
  }

  const { error } = await updateCustomer(customer.customerId, event.pspCustomerId);
  if (error) {
    logger.error(`Error updating customer: ${error}`);
    return { statusCode: 500, message: "Internal Server Error" };
  }

  logger.info(`Customer updated successfully: ${customer.customerId} pspCustomerId: ${event.pspCustomerId}`);
  return { statusCode: 200, message: "Customer updated successfully." };
};
