import { test, expect, describe, vi, beforeEach } from "vitest";
import { customerCreated } from "./customerCreated";
import * as dbUtil from "src/utils/db";

vi.mock("src/utils/db");

const testData = require("./testData.json");

describe("customerCreated tests", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });
  test("Happy path - Customer needs updating", async () => {
    vi.mocked(dbUtil.getCustomer, { partial: true }).mockResolvedValue({
      data: { customerId: "customer_id", accountId: "account_id", email: "email", address: "", mambuID: "mambu_id" },
    });
    vi.mocked(dbUtil.updateCustomer, { partial: true }).mockResolvedValue({
      data: { pspCustomerId: "psp_customer_id" },
    });
    const event = testData.customerCreatedEvent;
    const response = await customerCreated(event);

    expect(response.statusCode).toBe(200);

    const dbMock = await vi.mocked(dbUtil);
    expect(dbMock.getCustomer).toHaveBeenCalled();
    expect(dbMock.updateCustomer).toHaveBeenCalled();

    expect(dbMock.getCustomer).toHaveBeenCalledWith("customer_id");
    expect(dbMock.updateCustomer).toHaveBeenCalledWith("customer_id", "psp_customer_id");
  });
  test("Happy path - Customer is up to date", async () => {
    vi.mocked(dbUtil.getCustomer, { partial: true }).mockResolvedValue({
      data: {
        customerId: "customer_id",
        accountId: "account_id",
        email: "email",
        address: "",
        mambuID: "mambu_id",
        pspCustomerId: "psp_customer_id",
      },
    });
    vi.mocked(dbUtil.updateCustomer, { partial: true }).mockResolvedValue({
      data: { pspCustomerId: "psp_customer_id" },
    });
    const event = testData.customerCreatedEvent;
    const response = await customerCreated(event);

    expect(response.statusCode).toBe(200);

    const dbMock = await vi.mocked(dbUtil);
    expect(dbMock.getCustomer).toHaveBeenCalled();
    expect(dbMock.updateCustomer).not.toHaveBeenCalled();
  });
  test("Sad path -  Error getting customer from mobile table", async () => {
    vi.mocked(dbUtil.getCustomer, { partial: true }).mockResolvedValue({
      data: null,
      error: "Error fetching customer details",
    });
    vi.mocked(dbUtil.updateCustomer, { partial: true }).mockResolvedValue({
      data: { pspCustomerId: "psp_customer_id" },
    });
    const event = testData.customerCreatedEvent;
    const response = await customerCreated(event);

    expect(response.statusCode).toBe(500);

    const dbMock = await vi.mocked(dbUtil);
    expect(dbMock.getCustomer).toHaveBeenCalled();
    expect(dbMock.updateCustomer).not.toHaveBeenCalled();
  });
  test("Sad path -  Error updating customer", async () => {
    vi.mocked(dbUtil.getCustomer, { partial: true }).mockResolvedValue({
      data: { customerId: "customer_id", accountId: "account_id", email: "email", address: "", mambuID: "mambu_id" },
    });
    vi.mocked(dbUtil.updateCustomer, { partial: true }).mockResolvedValue({
      data: null,
      error: "Error updating customer",
    });
    const event = testData.customerCreatedEvent;
    const response = await customerCreated(event);

    expect(response.statusCode).toBe(500);

    const dbMock = await vi.mocked(dbUtil);
    expect(dbMock.getCustomer).toHaveBeenCalled();
    expect(dbMock.updateCustomer).toHaveBeenCalled();
  });
  test("Sad path -  No customerId set in metadata", async () => {
    vi.mocked(dbUtil.getCustomer, { partial: true }).mockResolvedValue({
      data: { customerId: "customer_id", accountId: "account_id", email: "email", address: "", mambuID: "mambu_id" },
    });
    vi.mocked(dbUtil.updateCustomer, { partial: true }).mockResolvedValue({
      data: { pspCustomerId: "psp_customer_id" },
    });
    const event = testData.customerCreatedEventNoCustomerId;
    const response = await customerCreated(event);

    expect(response.statusCode).toBe(500);

    const dbMock = await vi.mocked(dbUtil);
    expect(dbMock.getCustomer).not.toHaveBeenCalled();
    expect(dbMock.updateCustomer).not.toHaveBeenCalled();
  });
});
