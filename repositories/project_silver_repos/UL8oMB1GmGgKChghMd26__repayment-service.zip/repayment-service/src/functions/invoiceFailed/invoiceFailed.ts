import { createEvent } from "@libs/eventHubUtils";
import { getLogger } from "@libs/logger";
import { RepaymentType } from "@libs/types";
import { eventHubAdapter } from "@onmoapp/onmo-adapters";
import { AccountType, FailureCategory, RepaymentFailedEvent } from "@shared-types/eventHub-types";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { InvoicePaymentFailedEventOutcome } from "@onmoapp/onmo-types";

const getFailureCategory = (event: InvoicePaymentFailedEventOutcome): FailureCategory => {
  switch (event.failureReason.failureCode) {
    case "card_declined": {
      if (event.failureReason.declineCode == "expired_card") {
        return FailureCategory.ExpiredCard;
      }
      if (event.failureReason.declineCode == "insufficient_funds") {
        return FailureCategory.InsufficientFunds;
      }
      if (
        event.failureReason.declineCode == "try_again_later" ||
        event.failureReason.declineCode == "processing_error"
      ) {
        return FailureCategory.TechnicalFailure;
      }
      if (event.failureReason.declineCode == "account_closed") {
        return FailureCategory.BankAccountClosed;
      }
      return FailureCategory.CardDeclined;
    }
    case "account_closed":
      return FailureCategory.BankAccountClosed;
    case "balance_insufficient":
    case "insufficient_funds":
      return FailureCategory.InsufficientFunds;
    case "expired_card":
      return FailureCategory.ExpiredCard;
    case "payment_method_not_available":
    case "processing_error":
    case "lock_timeout":
    case "rate_limit":
      return FailureCategory.TechnicalFailure;
    case "payment_intent_mandate_invalid":
      return FailureCategory.MandateCancelled;
    default:
      return FailureCategory.Ohter;
  }
};

export const invoiceFailed = async (event: InvoicePaymentFailedEventOutcome) => {
  const logger = getLogger();
  logger.addContext({ functionName: "invoiceFailed" });
  logger.info(event);
  const env = process.env.ENVIRONMENT;
  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
    stageName: env as "staging" | "prod",
  });
  if (!repaymentClient) {
    logger.error("No event hub client found for STRIPE_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  let repaymentType = RepaymentType.CPA;

  const repaymentFailedEvent = {
    accountId: event.metadata.accountId,
    accountType: AccountType.Card,
    customerId: event.metadata.customerId,
    failureDetails: {
      failureCategory: getFailureCategory(event),
      failureCode: event.failureReason.declineCode
        ? `${event.failureReason.failureCode}-${event.failureReason.declineCode}`
        : `${event.failureReason.failureCode}`,
      failureMessage: event.failureReason.message,
      failureTime: event.created.toString(),
    },
    cpaAttemptCount: event.attemptCount,
    paymentDetails: {
      amount: event.amount, // Amount received is in cents,
      paymentMethod: repaymentType,
      externalId: event.paymentIntentId,
    },
    processor: "Stripe",
    processorReference: event.paymentIntentId,
  } satisfies RepaymentFailedEvent;
  const repaymentFailedEventData = createEvent<RepaymentFailedEvent>(repaymentFailedEvent, {
    eventType: "RepaymentFailed",
    subType: repaymentType,
    initiatedBy: "invoiceFailed",
  });

  logger.info({ repaymentFailedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(repaymentFailedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(repaymentFailedEventData, repaymentFailedEventData.correlationId);

  logger.debug({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }
  return { statusCode: 200, message: "RepaymentFailed event published successfully." };
};
