import { BASE_PATH } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { RequestContextBindings } from "@libs/types";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { Hono } from "hono";
import { handle } from "hono/aws-lambda";
import { formatErrorMessage } from "src/utils/errorUtil";

const app = new Hono<{ Bindings: RequestContextBindings }>().basePath(`/${BASE_PATH}/*`);

export const deleteHandler = app.delete("/direct-debit/:paymentMethodId", async (c) => {
  const logger = getLogger();

  logger.info("Deleting direct debit");
  logger.info(c.env.event);
  const { onmouuid: customerId } = c.env.event.requestContext.authorizer;

  const paymentMethodId = c.req.param("paymentMethodId");

  logger.addContext({ customerId, paymentMethodId });

  if (!customerId) {
    logger.error("Customer ID missing");
    return c.json({ message: "Customer ID missing" }, 400);
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return c.json({ message: "Repayment client not found" }, 500);
  }

  try {
    const paymentMethod = await repaymentClient.getPaymentMethodByMandateId(paymentMethodId);
    if (!paymentMethod) {
      return c.json({ message: "Mandate not found from payment method" }, 404);
    }
    await repaymentClient.deletePaymentMethod({ paymentMethodId: paymentMethod.paymentMethodId });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({ message: `Error deleting direct debit: ${errorMessage}` });
    return c.json({ message: "Error deleting direct debit" }, 500);
  }

  return c.json({ message: "Direct debit deleted" }, 200);
});

export const handler = handle(app);
export default handler;
