
import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: 'Bad Request',
  }),
})


const SuccessSchema = z.object({
  paymentMethodId: z.string(),
  type: z.string(),
  directDebit: z.object({
    bankCode: z.string(),
    last4: z.string(),
  }),
  billingDetails: z.object({
    name: z.string(),
    email: z.string(),
    phone: z.string(),
    address: z.object({
      city: z.string(),
      country: z.string(),
      line1: z.string(),
      line2: z.string(),
      postalCode: z.string(),
      state: z.string(),
    })
  }),
})

const RequestParamsSchema = z.object({
  id: z.string().openapi({
    example: 'pmi_1234',
  }),
})

app.openapi(
  createRoute({
    method: 'get',
    path: '/direct-debit/{id}',
    security: [
      {
        Bearer: []
      }
    ],
    request: {
      params: RequestParamsSchema,
    },
    responses: {
      200: {
        description: 'returns a specific direct-debit',
        content: {
          'application/json': {
            schema: SuccessSchema
          }
        }
      },
      400: {
        content: {
          'application/json': {
            schema: ErrorSchema,
          },
        },
        description: 'Returns an error',
      },
    }
  }),
  (c) => {
    return c.json(
      {
        paymentMethodId: 'pmi_1234',
        type: 'direct-debit',
        directDebit: {
          bankCode: '1234',
          last4: '1234',
        },
        billingDetails: {
          name: 'John Doe',
          email: 'john@doe.com',
          phone: '123456789',
          address: {
            city: 'London',
            country: 'UK',
            line1: '123 Street',
            line2: 'Apt 1',
            postalCode: '12345',
            state: 'London',
          }
        },
      }
    )
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 400,
          message: 'Custom Message',
        },
        400
      )
    }
  }
)

export default app
