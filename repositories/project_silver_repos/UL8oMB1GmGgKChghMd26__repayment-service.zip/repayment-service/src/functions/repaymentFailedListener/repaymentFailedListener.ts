
import { getLogger } from "@libs/logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { deserializeUtil } from "@libs/deserializeUtil";
import { EventData, EventHubDataToPublishType } from "@onmoapp/event-hub-interface";
import { throwErrorIfAdapterResHaveError } from "src/utils/errorUtil";
import { RepaymentFailedEvent, FailureCategory, DDEligibleForRetryEvent } from "@shared-types/eventHub-types";

import {
  coreBankingAdapter,
  salesforceCrmAdapter,
  eventHubAdapter,
  coreRepaymentsAdapter,
  StripeClient,
} from "@onmoapp/onmo-adapters";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import {
  CORE_BANKING_ADAPTER_CLIENT_NAME,
  CRM_ADAPTER_CLIENT_NAME,
  KINESIS_ADAPTER_CLIENT_NAME,
} from "@libs/constants";
import { sendMessage } from "@onmoapp/onmo-sqs";
import { SFMC_DD_FAILED_ACCOUNT_CLOSED, SFMC_CPA_CREATIVE_PAYMENT_FAILED_RETRY } from "@libs/constants";
import {
  GetCreditAccountOutcome,
  GetCustomerByCustomerIdOutcome,
  GetCrmCustomerDetailsOutCome,
  UpdateCreditAccountOutcome,
  DirectDebitSettings,
} from "@onmoapp/onmo-types";
import dayjs from "dayjs";
import { SFMCCommsEvent, SFMCCPACommsEvent } from "@shared-types/sqs-types";
import { createEvent } from "@libs/eventHubUtils";
import { RepaymentType } from "@libs/types";
import { shouldRetryDirectDebit } from "@utils/directDebitUtil";
import { getCustomer } from "@utils/db";
import { Logger } from "@onmoapp/onmo-logger";
import { getSSMParameter } from "@utils/ssmUtil";

const DEFAULT_CPA_MAX_RETRY_ATTEMPTS = 1;

const getCPAMaxRetryAttempts = async (logger: any): Promise<number> => {
  const ssmParamName = process.env.CPA_MAX_RETRY_ATTEMPTS_SSM_PARAM;
  if (ssmParamName) {
    try {
      const paramValue = await getSSMParameter(ssmParamName);
      const maxRetries = parseInt(paramValue, 10);
      if (!isNaN(maxRetries) && maxRetries > 0) {
        logger.info({ message: "Using CPA max retry attempts from SSM", maxRetries });
        return maxRetries;
      }
    } catch (error) {
      logger.warn({ message: "Failed to fetch CPA max retry attempts from SSM, using default", error });
    }
  }
  logger.info({ message: "Using default CPA max retry attempts", maxRetries: DEFAULT_CPA_MAX_RETRY_ATTEMPTS });
  return DEFAULT_CPA_MAX_RETRY_ATTEMPTS;
};
export const handler = async (event: any) => {
  const logger = getLogger();
  logger.addContext({ functionName: "repaymentFailedListener" });
  logger.info(event);

  //parse the event - bypassing the enrichment for now
  const data = event?.Records[0]?.kinesis?.data;
  if (!data) {
    logger.error("No Kinesis data found.");
    return formatJSONResponse({ statusCode: 500, body: { message: "No Kinesis data" } });
  }
  const dataBuffer = JSON.parse(Buffer.from(data, "base64").toString()) as EventHubDataToPublishType;
  const repaymentFailed: EventData<RepaymentFailedEvent> = await deserializeUtil(dataBuffer.data, dataBuffer.schemaId);
  logger.info(repaymentFailed);

  //extract attributes required for processing
  const { failureCategory } = repaymentFailed.eventData.failureDetails;
  const { paymentMethod } = repaymentFailed.eventData.paymentDetails;
  const customerId = repaymentFailed.eventData.customerId;
  const accountId: string = repaymentFailed.eventData.accountId;
  logger.addContext({ accountId, customerId, paymentMethod, failureCategory });

  const isDdOrDdRetry: boolean =
    paymentMethod === RepaymentType.DirectDebit || paymentMethod === RepaymentType.DirectDebitRetry;

  const customer = await getCustomer(customerId);

  if (customer.error || !customer.data) {
    logger.error(customer.error);
    throw new Error(`Error getting customer with ID: ${customerId}, ${customer.error}`);
  }

  if (paymentMethod === RepaymentType.CPA) {
    if (!customer.data.pspCustomerId) {
      logger.error({ message: "pspCustomerId is missing on customer record for CPA payment failure", customerId });
      throw new Error(`pspCustomerId is missing for customer ${customerId}`);
    }

    await sendCPAFailedComms(accountId, customerId, customer.data.pspCustomerId, repaymentFailed.eventData.paymentDetails.amount, repaymentFailed.eventData.cpaAttemptCount, logger);

    return formatJSONResponse({
      statusCode: 200,
      body: { message: "CPA failed comms sent + standard failure path done", repaymentFailed },
    });
  }

  if (!isDdOrDdRetry) {
    // No more processing required
    return formatJSONResponse({ statusCode: 200, body: { repaymentFailed } });
  }

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const creditAccount = await coreBankingClient.getCreditAccount(customer.data.accountId);

  await removeCoreBankingDDFlags(accountId, paymentMethod, logger, creditAccount.data.directDebitSettings);

  if (failureCategory === FailureCategory.InsufficientFunds && paymentMethod === RepaymentType.DirectDebit) {
    logger.info({
      message: `Initial direct debit failed due to ${FailureCategory.InsufficientFunds}`,
    });

    //check if payment intent has installmentDate in metadata (indicates this intent was created post go live of retries, so is eligble)
    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
    if (!repaymentClient) {
      logger.error("No event hub client found for STRIPE_CLIENT");
      return { statusCode: 500, message: "An error occured." };
    }
    const paymentIntentId = repaymentFailed.eventData.paymentDetails.externalId;
    const paymentIntentDetails = await repaymentClient.getPaymentIntent(paymentIntentId);
    const installmentDate = paymentIntentDetails.metadata.instalmentDate;
    if (!installmentDate) {
      logger.info({
        message: `No installment date found for payment intent ${paymentIntentId}, therefore not eligible for retry as intent created pre go live of retries`,
        repaymentFailed,
      });
      return formatJSONResponse({ statusCode: 200, body: { repaymentFailed } });
    }
    //otherwise, pass it through to method below and include it on firecomms

    const secrets =
      process.env.ENVIRONMENT === "staging" ? await StripeClient.retrieveSecrets(process.env.ENVIRONMENT) : null;

    // check if the user covered the direct debit amount already
    const dateFrom =
      secrets && secrets.ddRetryBypassDateInFutureAccounts?.includes(accountId)
        ? dayjs(paymentIntentDetails.creationDate).toISOString()
        : dayjs(installmentDate).toISOString();
    const shouldRetryResult = await shouldRetryDirectDebit({
      customer: customer.data,
      logger,
      creditAccount,
      paymentIntentId,
      dateFrom,
    });

    throwErrorIfAdapterResHaveError(shouldRetryResult, { message: "Error checking DD retry eligibility" });

    if (!shouldRetryResult.data.shouldRetryDirectDebit) {
      logger.info({ message: `No need to schedule DD retry: ${shouldRetryResult.data.reason}` });
      return;
    }

    await fireDdEligibleForRetryEvent(
      accountId,
      customerId,
      repaymentFailed.eventData.processorReference,
      repaymentFailed.eventData.paymentDetails.externalId,
      installmentDate,
      logger,
    );
    return formatJSONResponse({ statusCode: 200, body: { repaymentFailed } });
  }

  if (failureCategory === FailureCategory.BankAccountClosed) {
    logger.info({
      message: `Direct debit failed because ${FailureCategory.BankAccountClosed} and is a ${paymentMethod}`,
    });

    await sendAccountClosedComms(accountId, customerId, logger);
    return formatJSONResponse({
      statusCode: 200,
      body: { message: "Account closed comms sent + standard failure path done", repaymentFailed },
    });
  }

  logger.warn({
    message: `Unretriable direct debit failure: ${failureCategory} and is a ${paymentMethod}`,
    repaymentFailed,
  });

  return formatJSONResponse({ statusCode: 200, body: { repaymentFailed } });
};

const retryFlagsRemoved = (ddSettings: DirectDebitSettings): boolean => {
  return (
    !ddSettings.directDebitAvoidFeeCutOffDate &&
    !ddSettings.directDebitPreventRetryDate &&
    !ddSettings.directDebitRetryDate
  );
};

const removeCoreBankingDDFlags = async (
  accountId: string,
  paymentMethod: string,
  logger: Logger,
  ddSettings: DirectDebitSettings,
): Promise<void> => {
  //create core banking adapter
  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);
  logger.info({ message: "Core banking client created" });

  //perform operations
  if (!!ddSettings.scheduledDirectDebitAmount) {
    const setScheduledAmountOutcome: UpdateCreditAccountOutcome = await coreBankingClient.setScheduledAmount(
      accountId,
      0,
    ); // setting to 0 removes it
    throwErrorIfAdapterResHaveError(setScheduledAmountOutcome, { message: "Failed to remove scheduled amount" });
    logger.info({ message: "Removed scheduled amount from core banking loan account" });
  }
  if (paymentMethod === RepaymentType.DirectDebitRetry) {
    if (retryFlagsRemoved(ddSettings)) {
      if (!ddSettings.mandateID) {
        logger.info({ message: "The user cancelled their mandate. No need to remove DD retry flags." });
        return;
      }

      // DD retry flags where removed but we still have the mandateID. This shouldn't happen, raise an alert
      logger.error({
        message: `Alert_DDRetryFlagsWithMandate: The DD retry flags were removed for ${accountId} yet the mandate is still present. Investigate.`,
      });
    }

    const updateDDRetryFields: UpdateCreditAccountOutcome = await coreBankingClient.updateDDRetryFields(
      accountId,
      false,
      null,
      null,
      null,
    );
    throwErrorIfAdapterResHaveError(updateDDRetryFields, { message: "Failed to update DD retry fields" });
    logger.info({
      message:
        "Removed DD retry flags from core banking loan account since this is a DD retry failure and not being retried any further",
    });
  }
};

const fireDdEligibleForRetryEvent = async (
  accountId: string,
  customerId: string,
  processorReference: string,
  paymentIntentId: string,
  installmentDate: string,
  logger: any,
): Promise<void> => {
  // get customer info
  const { crmCustomerDetails, coreBankingCustomer } = await getCustomerInfo(customerId, logger);
  logger.info({ message: "Got customer info" });

  // create kinesis adapter
  const eventHubClient = await eventHubAdapter(KINESIS_ADAPTER_CLIENT_NAME);
  logger.info({ message: "Event hub client created" });

  // prepare event
  const ddEligibleForRetryEvent = {
    accountId,
    customerId,
    dueDate: dayjs(installmentDate).format("YYYY-MM-DD"),
    personContactId: crmCustomerDetails.data.contactId,
    firstName: coreBankingCustomer.data.firstName,
    emailAddress: coreBankingCustomer.data.emailAddresses.primary,
    phoneNumber: coreBankingCustomer.data.mobileNumbers.primary,
    failureDate: dayjs().format("YYYY-MM-DD"),
    processor: "Stripe",
    processorReference,
    paymentIntentId,
  } as DDEligibleForRetryEvent;
  const ddEligibleForRetryEventData = createEvent<DDEligibleForRetryEvent>(ddEligibleForRetryEvent, {
    eventType: "DDFailedEligibleForRetry",
    initiatedBy: "repaymentFailedListener",
  });
  logger.info({ message: "ddEligibleForRetryEventData event data created", ddEligibleForRetryEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(ddEligibleForRetryEventData);
  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    const msg = "Invalid event data";
    logger.error(msg);
    throw new Error(msg);
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(ddEligibleForRetryEventData, ddEligibleForRetryEventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    const msg = "Failed to publish event to event hub";
    logger.error(msg);
    throw new Error(msg);
  }
};

const sendAccountComms = async (
  comms_key: string,
  accountId: string,
  customerId: string,
  logger: any,
): Promise<void> => {
  //get customer info
  const { crmCustomerDetails, coreBankingCustomer, accountDetails } = await getCustomerInfo(
    customerId,
    logger,
    accountId,
  );
  logger.info({ message: "Got customer info" });

  //prepare event
  const accountClosedCommsEvent = {
    commsKey: comms_key,
    firstName: coreBankingCustomer.data.firstName.trim(),
    dueDate: dayjs(accountDetails?.data.accountDetails?.nextStatementDueDate).format("YYYY-MM-DD"),
    emailAddress: coreBankingCustomer.data.emailAddresses.primary,
    customerId,
    personContactId: crmCustomerDetails.data.contactId,
    phoneNumber: coreBankingCustomer.data.mobileNumbers.primary,
    retryDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
    avoidFeeCutOffDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
    preventRetryDate: dayjs().format("YYYY-MM-DD"), //not used for account closed comms but required in sfmc request so using default value (we should probs seperate out the account closed and retry comms into seperate api event triggers)
  } as SFMCCommsEvent;

  //put on queue
  logger.info({ message: "Sending message to SFMC SQS for account comms", comms_key, accountClosedCommsEvent });
  const result = await sendMessage({
    MessageBody: JSON.stringify(accountClosedCommsEvent),
    QueueUrl: process.env.SFMC_COMMS_QUEUE_URL,
  });
  logger.info({
    message: "Message sent to SFMC comms SQS for account comms",
    comms_key,
    messageId: result.MessageId,
    sequenceNumber: result.SequenceNumber,
  });
};

const sendAccountClosedComms = async (accountId: string, customerId: string, logger: any): Promise<void> => {
  await sendAccountComms(SFMC_DD_FAILED_ACCOUNT_CLOSED, accountId, customerId, logger);
};

const sendCPAFailedComms = async (
  accountId: string,
  customerId: string,
  pspCustomerId: string,
  amountInCents: number,
  cpaAttemptCount: number,
  logger: any,
): Promise<void> => {
  const { crmCustomerDetails, coreBankingCustomer, accountDetails } = await getCustomerInfo(
    customerId,
    logger,
    accountId,
  );

  const repaymentClient = await CoreRepaymentsFactory.build("stripe");
  const subscriptionsResult = await repaymentClient.getSubscriptionsByPsPCustomerId(pspCustomerId);

  const activeSubscription = subscriptionsResult.subscriptions.find(
    (sub) => sub.status === "active" || sub.status === "past_due",
  );

  let retryDate: string | null = null;
  let planEndDate: string | null = null;
  const now = subscriptionsResult.testClockFrozenTime
    ? dayjs.unix(subscriptionsResult.testClockFrozenTime)
    : dayjs();

  if (activeSubscription) {
    planEndDate = activeSubscription.cancelAt
      ? dayjs.unix(activeSubscription.cancelAt).format("YYYY-MM-DD")
      : null;

    const invoice = await repaymentClient.getLatestInvoiceForSubscription(activeSubscription.subscriptionId);

    const maxRetryAttempts = await getCPAMaxRetryAttempts(logger);

    // Skip Email4 on the final attempt — Stripe will cancel the subscription
    // and comms are handled by subscriptionCancelled (Email5) instead.
    // We use cpaAttemptCount vs maxRetryAttempts rather than nextPaymentAttempt
    // because nextPaymentAttempt can be null due to race conditions with Stripe.
    if (cpaAttemptCount > maxRetryAttempts) {
      logger.info({ message: "Final retry attempt exceeded — skipping CPA failed comms, subscription cancellation will handle it", cpaAttemptCount, maxRetryAttempts });
      return;
    }

    retryDate = invoice?.nextPaymentAttempt
      ? dayjs.unix(invoice.nextPaymentAttempt).format("YYYY-MM-DD")
      : now.add(1, "day").format("YYYY-MM-DD");
  }

  const cpaFailedCommsEvent: SFMCCPACommsEvent = {
    creative: SFMC_CPA_CREATIVE_PAYMENT_FAILED_RETRY,
    firstName: coreBankingCustomer.data.firstName.trim(),
    emailAddress: coreBankingCustomer.data.emailAddresses.primary,
    customerId,
    personContactId: crmCustomerDetails.data.contactId,
    paymentPlanDate: now.format("YYYY-MM-DD"),
    planEndDate,
    retryDate,
    paymentPlanValue: amountInCents / 100,
    arrearsBalance: accountDetails?.data?.accountBalances?.arrearBalances?.total ?? null,
  };

  logger.info({ message: "Sending CPA failed comms to CPA comms SQS", cpaFailedCommsEvent });
  const result = await sendMessage({
    MessageBody: JSON.stringify(cpaFailedCommsEvent),
    QueueUrl: process.env.CPA_COMMS_QUEUE_URL,
  });
  logger.info({
    message: "CPA failed comms message sent to CPA comms SQS",
    messageId: result.MessageId,
    sequenceNumber: result.SequenceNumber,
  });
};

interface CustomerData {
  crmCustomerDetails: GetCrmCustomerDetailsOutCome;
  coreBankingCustomer: GetCustomerByCustomerIdOutcome;
  accountDetails?: GetCreditAccountOutcome;
}

const getCustomerInfo = async (customerId: string, logger: any, accountId?: string): Promise<CustomerData> => {
  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);
  logger.info({ message: "Core banking client created" });
  const crmAdapter = await salesforceCrmAdapter(CRM_ADAPTER_CLIENT_NAME);
  logger.info({ message: "CRM client created" });

  const crmCustomerDetails: GetCrmCustomerDetailsOutCome =
    await crmAdapter.getCrmCustomerDetailsByCustomerId(customerId);
  throwErrorIfAdapterResHaveError(crmCustomerDetails, { message: "Failed to get CRM customer details" });
  logger.info({ message: "CRM customer details retrieved", crmCustomerDetails });

  const coreBankingCustomer: GetCustomerByCustomerIdOutcome =
    await coreBankingClient.getCustomerByCustomerId(customerId);
  throwErrorIfAdapterResHaveError(coreBankingCustomer, { message: "Failed to get core banking customer details" });
  logger.info({ message: "Core banking customer details retrieved", coreBankingCustomer });

  // Conditionally fetch accountDetails only if accountId is provided.
  let accountDetails: GetCreditAccountOutcome | undefined;
  if (accountId) {
    accountDetails = await coreBankingClient.getCreditAccount(accountId);
    throwErrorIfAdapterResHaveError(accountDetails, { message: "Failed to get core banking account details" });
    logger.info({ message: "Core banking account details retrieved", accountDetails });
  }

  return accountId
    ? { crmCustomerDetails, coreBankingCustomer, accountDetails }
    : { crmCustomerDetails, coreBankingCustomer };
};
