import { serve } from '@hono/node-server'
import docs from './docs'

// TODO:
// There's likely a better way to do this.
// I would like to see if I can group all the routes
// (docs and the other routes) into a single file.
// - I would also like to measure the performance
// difference between the two approaches.

serve({
  fetch: docs.fetch,
  port: 3001
})

