import { OpenAPIHono, z } from "@hono/zod-openapi";
import { swaggerUI } from "@hono/swagger-ui";
import cards from "../cards/spec";
import createCardRepayment from "../createCardRepayment/spec";
import createDirectDebit from "../createDirectDebit/spec";
import directDebits from "../directDebits/directDebits.spec";
import createDirectDebitHosted from "../createDirectDebitHosted/spec";
import webhookHandler from "../webhookHandler/spec";
import getPaymentMethodByMandateId from "../getPaymentMethodByMandateId/getPaymentMethodByMandateId.spec";
import nextDirectDebitIntentDate from "../nextDirectDebitIntentDate/spec";
import deleteMandate from "../deleteMandate/spec";
import updateDirectDebitHosted from "../updateDirectDebitHosted/spec";
import { handle } from "hono/aws-lambda";
import { RequestContextBindings } from "@libs/types";
import hasPendingMandate from "../hasPendingMandate/spec";
import getCPASubscription from "../getCPASubscription/spec";
import { BASE_PATH } from "@libs/constants";

const app = new OpenAPIHono<{ Bindings: RequestContextBindings }>().basePath(`/${BASE_PATH}/*`);

app.openAPIRegistry.registerComponent("securitySchemes", "Bearer", {
  type: "http",
  scheme: "bearer",
});

// app.route("", deleteDirectDebit); --> Should not be used, may need some clean up of other endpoints too
app.route("", directDebits);
app.route("", cards);
app.route("", createCardRepayment);
app.route("", createDirectDebit);
app.route("", createDirectDebitHosted);
app.route("", webhookHandler);
app.route("", getPaymentMethodByMandateId);
// app.route("", getDirectDebit); ---> Should not be used
app.route("", nextDirectDebitIntentDate);
app.route("", deleteMandate);
app.route("", updateDirectDebitHosted);
app.route("", hasPendingMandate);
app.route("", getCPASubscription);

app.get(
  "/docs",
  swaggerUI({
    url: `${BASE_PATH}/*/doc`,
  }),
);

app.doc("/doc", {
  info: {
    title: "Repayment Services",
    version: "v1",
  },
  openapi: "3.1.0",
});

export const handler = handle(app);
export default app;
