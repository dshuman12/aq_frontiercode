import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer, updateCustomer } from "src/utils/db";
import { z } from "zod";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { ONMO_REPAYMENT_SECRET_PREFIX } from "@libs/constants";
import { createPspCustomer } from "src/utils/createPspCustomer";
import { getFeatureFlagClient } from "@libs/featureFlags";
import { PaymentLinkRepaymentType } from "@onmoapp/onmo-types";

const env = process.env.ENVIRONMENT;

type GeneratePaymentLinkResponse = {
  url: string;
  paymentLinkId: string;
};

type GeneratePaymentLinkError = {
  message: string;
};

const validateBody = (body: string) => {
  return z
    .object({
      accountId: z
        .string({
          required_error: "Account id is required",
        })
        .min(1, "Account id can not be empty"),
      onmouuid: z
        .string({
          required_error: "onmouuid is required",
        })
        .min(1, "onmouuid can not be empty")
        .uuid("onmouuid must be a valid UUID"),
      amount: z
        .number({
          required_error: "Amount is required",
        })
        .gte(50, "The minimum amount required to pay via the link is £0.50. Please enter a minimum value of 50"),
      channelId: z.string().optional(),
    })
    .safeParse(JSON.parse(body));
};

const logger = new Logger({ env });

export const handler = async (event): Promise<any> => {
  try {
    logger.addContext({ functionName: "generatePaymentLink" });
    logger.info({ event });

    const body = validateBody(event.body || "{}");

    if (!body.success) {
      logger.info(body.error);
      const errorMessage = body?.error?.issues?.[0]?.message;

      throw new OnmoError({
        name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
        message: errorMessage,
      });
    }

    logger.info("fetching customer info from table");
    const { accountId, amount, onmouuid, channelId } = body.data;
    const { data: customer, error: getCustomerError } = await getCustomer(onmouuid);

    if (getCustomerError) {
      logger.error(`Error while fetching customer details: ${getCustomerError}`);
      throw new OnmoError({
        name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
        message: getCustomerError,
      });
    }

    if (customer.accountId !== accountId) {
      logger.error("Account ID does not match the onmouuid.");
      throw new OnmoError({
        name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
        message: "Account ID does not match the onmouuid",
      });
    }

    logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

    const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");

    logger.info("fetching customer credit account details");
    const getCreditAccountRes = await coreBankingClient.getCreditAccount(accountId);
    const creditAccountData = getCreditAccountRes.data;

    if (getCreditAccountRes.error) {
      logger.error("Error while fetching mambu account details");
      logger.error(getCreditAccountRes.error);

      throw new OnmoError({
        name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
        message: getCreditAccountRes?.error?.errorMessage,
      });
    }

    logger.info("fetching mambu customer details");
    const customerInformation = await coreBankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);

    if (customerInformation.error) {
      logger.error("Error while fetching account details");
      logger.error(customerInformation.error);

      throw new OnmoError({
        name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
        message: customerInformation?.error?.errorMessage,
      });
    }

    if (creditAccountData.accountDetails.state === "FULL_LOCK") {
      logger.error("Account FULL_LOCK detected");
      throw new OnmoError({
        name: ErrorNamesEnum.INPUT_VALIDATION_ERROR,
        message: "Can not generate payment link because the account has a FULL_LOCK",
      });
    }

    const { SecretString: stripeSecretString } = await getSecret(
      `${ONMO_REPAYMENT_SECRET_PREFIX}${process.env.ENVIRONMENT}`,
    );
    if (!stripeSecretString) {
      throw new OnmoError({
        name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
        message: "Stripe secrets string is undefined",
      });
    }
    const { productKey } = JSON.parse(stripeSecretString);

    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    let pspUser = null;
    if (!customer.pspCustomerId) {
      logger.info("Customer doesn't exist, Need to create...");

      const { data, error } = await createPspCustomer({
        repaymentClient,
        customer,
        customerData: customerInformation.data,
      });
      if (error) {
        logger.error(`Error while creating customer ${error}`);
        throw new OnmoError({
          name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
          message: error,
        });
      }

      pspUser = data;

      logger.info("Customer created!");
      const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);

      if (updatedCustomer.error) {
        logger.error(`Error while updating customer details ${updatedCustomer.error}`);
        throw new OnmoError({
          name: ErrorNamesEnum.INTERNAL_SERVER_ERROR,
          message: updatedCustomer?.error,
        });
      }
      logger.info("Customer updated with pspCustomerId");
    }

    const client = await getFeatureFlagClient();

    logger.info("checking feature flag for payment type");
    const isPayByBankEnabled = await client.isFeatureEnabled(
      '2025_06_05_mobile_pay_by_bank_available',
      onmouuid
    );

    logger.info(`Feature flag for pay by bank is ${isPayByBankEnabled}`);

    const repaymentTypes: PaymentLinkRepaymentType[] = isPayByBankEnabled ? ["PAY_BY_BANK", "CARD"] : ["CARD"];
    logger.info(`Using repayment type: ${repaymentTypes}`);

    logger.info("generating payment link ...");

    const createPaymentLinkRes = await repaymentClient.createPaymentLink({
      amount: Number(amount.toFixed(0)),
      customerId: customer.customerId,
      pspCustomerId: pspUser?.pspCustomerId || customer.pspCustomerId,
      accountId: accountId,
      productId: productKey,
      repaymentTypes,
      ...(channelId && { channelId }),
    });

    logger.info("Payment link generation done");

    return formatJSONResponse<GeneratePaymentLinkResponse>({
      statusCode: 200,
      body: {
        url: createPaymentLinkRes.url,
        paymentLinkId: createPaymentLinkRes.paymentLinkId,
      },
    });
  } catch (err) {
    const error = err as unknown as OnmoError;
    logger.error({ message: "generatePaymentLink error", errorName: error.name, errorMessage: error.message });

    const statusCode = error.name === ErrorNamesEnum.INPUT_VALIDATION_ERROR ? 400 : 500;
    const errorMessage = error.name === ErrorNamesEnum.INPUT_VALIDATION_ERROR ? error.message : "Internal server error";

    return formatJSONResponse<GeneratePaymentLinkError>({
      statusCode: statusCode,
      body: {
        message: errorMessage,
      },
    });
  }
};
