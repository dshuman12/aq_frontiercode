import { SQSEvent, SQSRecord } from "aws-lambda";
import { getLogger } from "@libs/logger";
import axios from "axios";
import dayjs from "dayjs";
import advancedFormat from "dayjs/plugin/advancedFormat";
import {
  SFMCDDCommsEventSchema,
  SFMCDDCommsEvent,
  SFMCCPACommsEventSchema,
  SFMCCPACommsEvent,
} from "@shared-types/sqs-types";
dayjs.extend(advancedFormat);

interface ProcessCommsOutcome {
  success?: SFMCDDCommsEvent | SFMCCPACommsEvent;
  error?: {
    message: string;
    sqsMessageId: string;
  };
}

interface ErrorLogInput {
  logger: any;
  message: string;
  sqsRecord: SQSRecord;
}

export const handler = async (event: SQSEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "sendSFMCComms" });
  logger.info({ message: "Received event", event });

  // process each msg
  const promises = event.Records.map((sqsRecord) => processComms(sqsRecord, logger));
  const results: ProcessCommsOutcome[] = await Promise.all(promises);

  // returns only failed msgs to be retried
  const batchItemFailures = results
    .filter((result) => result.error)
    .map((r) => ({
      itemIdentifier: r.error!.sqsMessageId,
    }));

  return { batchItemFailures };
};

const processComms = async (sqsRecord: SQSRecord, logger: any): Promise<ProcessCommsOutcome> => {
  let parsedData: unknown;
  try {
    parsedData = JSON.parse(sqsRecord.body);
  } catch (error) {
    return logAndReturnFailedMessage({ logger, message: "Invalid JSON format", sqsRecord });
  }

  // Try CPA comms first
  const cpaValidation = SFMCCPACommsEventSchema.safeParse(parsedData);
  if (cpaValidation.success) {
    try {
      await sendCPAComms(cpaValidation.data, logger);
      logger.info({ message: `CPA communication sent successfully for creative ${cpaValidation.data.creative}` });
      return { success: cpaValidation.data };
    } catch (error) {
      return logAndReturnFailedMessage({ logger, message: formatErrorMessage(error), sqsRecord });
    }
  }

  // Fall back to DD comms
  const ddValidation = SFMCDDCommsEventSchema.safeParse(parsedData);
  if (!ddValidation.success) {
    return logAndReturnFailedMessage({ logger, message: "Invalid event structure", sqsRecord });
  }

  try {
    await sendDDComms(ddValidation.data, logger);
    logger.info({ message: `DD communication sent successfully for key ${ddValidation.data.commsKey}` });
  } catch (error) {
    return logAndReturnFailedMessage({ logger, message: formatErrorMessage(error), sqsRecord });
  }

  return { success: ddValidation.data };
};

const getSFMCAccessToken = async (logger: any): Promise<string> => {
  const tokenPayload = {
    grant_type: process.env.SFMC_GRANT_TYPE,
    client_id: process.env.SFMC_CLIENT_ID,
    client_secret: process.env.SFMC_CLIENT_SECRET,
    account_id: process.env.SFMC_ACCOUNT_ID,
  };

  try {
    const tokenResponse = await axios.post(process.env.SFMC_TOKEN_URL, tokenPayload, {
      headers: { "Content-Type": "application/json" },
    });
    logger.info("SFMC access token obtained successfully");
    return tokenResponse.data.access_token;
  } catch (error) {
    throw new Error("Failed to obtain SFMC access token: " + error);
  }
};

const postToSFMC = async (eventPayload: any, accessToken: string, logger: any): Promise<void> => {
  logger.info({ message: "Sending communication request to SFMC", eventPayload });

  try {
    await axios.post(process.env.SFMC_COMMS_URL, eventPayload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    });
  } catch (error) {
    if (error.response) {
      logger.error({ message: "Failed to send SFMC comms", error: error.response.data });
    } else {
      logger.error({ message: "Error setting up request or no response received", error: error.message });
    }
    throw new Error("Failed to send communication: " + error);
  }
};

const sendDDComms = async (commsEvent: SFMCDDCommsEvent, logger: any): Promise<void> => {
  const accessToken = await getSFMCAccessToken(logger);

  const eventPayload = {
    ContactKey: commsEvent.personContactId,
    EventDefinitionKey: process.env.SFMC_DD_RETRY_EVENT_DEFINITION_KEY,
    Data: {
      FirstName: commsEvent.firstName,
      due_date: dayjs(commsEvent.dueDate).format("D MMMM YYYY"),
      EmailAddress: commsEvent.emailAddress,
      onmouuid: commsEvent.customerId,
      PersonContactID: commsEvent.personContactId,
      SubscriberKey: commsEvent.personContactId,
      Locale: "GB",
      PhoneNumber: commsEvent.phoneNumber,
      EmailType: commsEvent.commsKey,
      UniqueID: Math.random().toString(36).substring(2, 15),
      avoidFeeCutOffDate: dayjs(commsEvent.avoidFeeCutOffDate).format("D MMMM YYYY"),
      retryDate: dayjs(commsEvent.retryDate).format("D MMMM YYYY"),
      preventRetryDate: dayjs(commsEvent.preventRetryDate).format("D MMMM YYYY"),
      API_Date: dayjs().format("YYYY-MM-DD"),
      API_Time: parseInt(dayjs().format("HHmm"), 10),
      seq: 3,
    },
  };

  await postToSFMC(eventPayload, accessToken, logger);
  logger.info(
    `SFMC endpoint invocation to send ${commsEvent.commsKey} comm resolved with no error. Although, this doesn't guarantee successful delivery.`,
  );
};

const sendCPAComms = async (commsEvent: SFMCCPACommsEvent, logger: any): Promise<void> => {
  const accessToken = await getSFMCAccessToken(logger);

  const eventPayload = {
    ContactKey: commsEvent.personContactId,
    EventDefinitionKey: process.env.SFMC_CPA_EVENT_DEFINITION_KEY,
    Data: {
      UniqueID: Math.random().toString(36).substring(2, 15),
      OnmoUUID: commsEvent.customerId,
      PersonContactID: commsEvent.personContactId,
      Timestamp: commsEvent.paymentPlanDate
        ? dayjs(commsEvent.paymentPlanDate).toISOString()
        : dayjs().toISOString(),
      FirstName: commsEvent.firstName,
      Email: commsEvent.emailAddress,
      Creative: commsEvent.creative,
      PaymentPlanDate: commsEvent.paymentPlanDate,
      PlanEndDate: commsEvent.planEndDate,
      RetryDate: commsEvent.retryDate,
      PaymentPlanValue: commsEvent.paymentPlanValue,
      ArrearsBalance: commsEvent.arrearsBalance,
    },
  };

  await postToSFMC(eventPayload, accessToken, logger);
  logger.info(
    `SFMC endpoint invocation to send CPA ${commsEvent.creative} comm resolved with no error. Although, this doesn't guarantee successful delivery.`,
  );
};

const logAndReturnFailedMessage = ({ logger, message, sqsRecord }: ErrorLogInput): ProcessCommsOutcome => {
  logErrorWithContextReset({ logger, message, sqsRecord });
  return {
    error: {
      message,
      sqsMessageId: sqsRecord.messageId,
    },
  };
};

const logErrorWithContextReset = ({ logger, message, sqsRecord }: ErrorLogInput): void => {
  logger.addContext({ sqsRecord });
  logger.error(message);
  logger.removeContext("sqsRecord");
};

const formatErrorMessage = (error: any): string => {
  return error.message || "Unknown error";
};
