import { getLogger } from "@libs/logger";
import { eventHubAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { createEvent } from "@libs/eventHubUtils";
import { RepaymentCollectedEvent } from "@shared-types/eventHub-types";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { StripePaymentEvent } from "@libs/types/stripePaymentEvent";
import { stripeToPaymentEvent } from "src/utils/stripeToPaymentEvent";
import { ApiGatewayEventWithRawBody } from "@shared-types/apiGateway-types";

/**
 * Called by Stripe on payment successful
 * and publish repayment collected event to EventHub
 *
 * @param {APIGatewayEvent} event - The AWS Lambda event object containing the request information.
 * @returns {Promise<any>} - A promise that resolves to the JSON response object.
 * @throws {OnmoError} - Throws an OnmoError if there is an issue with the input validation
 */
export const handler = async (event: ApiGatewayEventWithRawBody) => {
  const logger = getLogger();
  logger.addContext({ functionName: "paymentSuccessful" });

  logger.info(event);

  if (!event.body) {
    logger.error("Missing body in request.");
    return formatJSONResponse({ statusCode: 400, body: { error: "Missing body in request." } });
  }

  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return formatJSONResponse({ statusCode: 500, body: { message: "An error occured." } });
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  const stripeEvent = JSON.parse(event.body) as StripePaymentEvent;
  const paymentIntent = await repaymentClient.getPaymentIntent(stripeEvent.data.object.id);
  const paymentEvent = stripeToPaymentEvent(paymentIntent, stripeEvent); //todo update getPaymentIntent to get all relevant info from there

  const isValid = await repaymentClient.verifySignature({
    eventType: stripeEvent.type,
    body: event.rawBody,
    signature: event.headers["Stripe-Signature"],
  });

  if (!isValid) {
    logger.addContext({ stripeEvent, body: event.rawBody, signature: event.headers["Stripe-Signature"] });
    logger.error("Invalid signature from Stripe");
    return formatJSONResponse({ statusCode: 500, body: { message: "Invalid webhook signature." } });
  } else {
    logger.info("Signature from Stripe is valid.");
  }

  const repaymentCollectedEvent = {
    accountId: paymentEvent.accountId,
    accountType: paymentEvent.accountType,
    customerId: paymentEvent.customerId,
    date: new Date().toISOString(),
    processor: "Stripe",
    repayment: {
      amount: paymentEvent.amount,
      paymentMethod: paymentEvent.repaymentType,
      externalId: paymentEvent.id,
      mandateId: null,
    },
  } as RepaymentCollectedEvent;
  const repaymentCollectedEventData = createEvent<RepaymentCollectedEvent>(repaymentCollectedEvent, {
    eventType: "RepaymentCollected",
    subType: paymentEvent.repaymentType,
    initiatedBy: "paymentSuccessful",
  });

  logger.debug({ repaymentCollectedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(repaymentCollectedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    throw new OnmoError({
      name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
      message: "Validation Failed: Invalid Event Data",
      cause: eventValidationErrors,
    });
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(repaymentCollectedEventData, repaymentCollectedEventData.correlationId);

  logger.debug({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    throw new OnmoError({
      name: ErrorNamesEnum.SOME_ERROR_OCCURRED,
      message: "Failed to publish event to event hub",
      cause: publishingValidationErrors,
    });
  }

  return formatJSONResponse({ statusCode: 200, body: { message: "Event published successfully" } });
};

export default handler;
