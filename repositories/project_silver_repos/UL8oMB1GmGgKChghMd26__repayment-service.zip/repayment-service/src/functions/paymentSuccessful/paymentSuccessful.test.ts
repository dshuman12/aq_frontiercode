import { test, expect, describe, vi } from "vitest";
import { handler } from "./paymentSuccessful";
import * as adapters from "@onmoapp/onmo-adapters";
import { ApiGatewayEventWithRawBody } from "@shared-types/apiGateway-types";

const testData = require("../../integration-tests/testData.json");

vi.mock("@onmoapp/onmo-adapters");

describe("paymentSuccessful tests", () => {
  test("Happy path", async () => {
    vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
      publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
      validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      verifySignature: vi.fn().mockResolvedValue(true),
      getPaymentIntent: vi.fn().mockResolvedValue(testData.paymentIntent),
    });
    const validBody = testData.validBody;

    const event = {
      rawBody: validBody,
      body: validBody,
    } as ApiGatewayEventWithRawBody;
    event.headers = {
      "Stripe-Signature": "signature",
    };

    const response = await handler(event);
    expect(response.statusCode).toBe(200);

    const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
    const coreRepaymentsAdapterMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;

    expect(coreRepaymentsAdapterMock.verifySignature).toHaveBeenCalledWith({
      eventType: "payment_intent.succeeded",
      body: validBody,
      signature: "signature",
    });
    expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();
  });
});
