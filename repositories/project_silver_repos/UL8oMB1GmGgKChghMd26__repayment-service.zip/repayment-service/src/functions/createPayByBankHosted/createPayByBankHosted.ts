import { Logger } from "@onmoapp/onmo-logger";
import { ErrorNamesEnum, OnmoError } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { getCustomer, updateCustomer } from "@utils/db";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { PayByBankError, PayByBankHostedSession } from "@libs/types";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { createPspCustomer } from "@utils/createPspCustomer";
import { formatErrorMessage, throwErrorIfAdapterResHaveError } from "@utils/errorUtil";

const env = process.env.ENVIRONMENT;

const validateBody = (body: string) => {

  const urlRegex = /^[a-zA-Z][a-zA-Z\d+\-.]*:\/\/[^\s]+$/;

  return z
    .object({
      amount: z
        .number({
          required_error: "Amount is required",
        })
        .gte(0.50, "Amount must be greater than or equal to £0.50"),
      successUrl: z.string().refine((value) => urlRegex.test(value), {
        message: "Please enter a valid success URL",
      }),
      cancelUrl: z.string().refine((value) => urlRegex.test(value), {
        message: "Please enter a valid cancel URL",
      }),
      paymentPreference: z
        .string({
          required_error: "paymentPreference is required",
        })
        .refine(
          (val) =>
            [
              "MIN_PAYMENT",
              "OVERDUE_PAYMENT",
              "OVERLIMIT_AMOUNT",
              "STATEMENT_BAL",
              "FULL_BALANCE",
              "CUSTOM_AMOUNT",
              "SMART_PAYMENT",
              "TOP_UP_PAYMENT",
            ].includes(val),
          {
            message:
              "paymentPreference must be one of 'MIN_PAYMENT', 'OVERDUE_PAYMENT', 'OVERLIMIT_AMOUNT', 'STATEMENT_BAL', 'FULL_BALANCE', 'CUSTOM_AMOUNT', 'SMART_PAYMENT' or 'TOP_UP_PAYMENT'",
          },
        ),
    })
    .safeParse(JSON.parse(body));
};

export const handler = async (event): Promise<any> => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createPayByBankHosted" });

  try {
    const { onmouuid: customerId } = event?.requestContext?.authorizer;

    if (!customerId) {
      throw new OnmoError({
        name: ErrorNamesEnum.NOT_FOUND_ERROR,
        message: "Missing onmouuid from authorizer",
        cause: "Missing onmouuid from authorizer",
      });
    }

    const body = validateBody(event.body || "{}");

    if (!body.success) {
      logger.info(body.error);
      const errorMessage = `Invalid request body : ${body?.error?.issues?.[0]?.message}`;

      logger.error(errorMessage);
      return formatJSONResponse<PayByBankError>({ statusCode: 400, body: { message: errorMessage } });
    }

    logger.info({ body });

    const { amount, successUrl, cancelUrl, paymentPreference } = body.data;

    logger.addContext({ paymentPreference });

    const paymentPreferenceDisplayMap: Record<string, string> = {
      MIN_PAYMENT: "Minimum Payment",
      CUSTOM_AMOUNT: "Custom Payment",
      FULL_BALANCE: "Full Balance Payment",
      OVERDUE_PAYMENT: "Overdue Balance Payment",
      OVERLIMIT_AMOUNT: "Overlimit Balance Payment",
      STATEMENT_BAL: "Statement Balance Payment",
      SMART_PAYMENT: "Smart Payment",
      TOP_UP_PAYMENT: "Top Up Payment",
    };
    const paymentPreferenceName = paymentPreferenceDisplayMap[paymentPreference];

    logger.info("fetching customer info from table");

    const customerDetails = (await getCustomer(customerId)) as { data: any; error: string };

    throwErrorIfAdapterResHaveError(customerDetails, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const { data: customer } = customerDetails;

    if (!customer.accountId || !customer.mambuID) {
      logger.error("Customer account details missing");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

    const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

    if (!bankingClient) {
      logger.error("Error fetching banking client");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    const accountDetails = await bankingClient.getCreditAccount(customer.accountId);

    throwErrorIfAdapterResHaveError(accountDetails, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const { data, error } = accountDetails;

    if (error) {
      logger.error("Error fetching account details");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    if (data.accountDetails.state === "FULL_LOCK") {
      logger.error("Account is fully locked");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    let expectedAmount: number | undefined;
    if (paymentPreference === "MIN_PAYMENT" || paymentPreference === "FULL_BALANCE") {
      expectedAmount = Math.abs(
        paymentPreference === "MIN_PAYMENT"
          ? data.accountBalances.totalNextMinimumPaymentDue
          : data.accountBalances.balances.total,
      );
      if (expectedAmount === 0) {
        logger.info(`${paymentPreferenceName} expected amount is 0`);
        return formatJSONResponse<PayByBankError>({
          statusCode: 400,
          body: { message: `Invalid ${paymentPreferenceName.toLowerCase()} amount` },
        });
      }
      if (expectedAmount !== amount) {
        logger.error(`${paymentPreference} amount from request does not match expected amount`);
        return formatJSONResponse<PayByBankError>({
          statusCode: 400,
          body: { message: "Amount from request does not match expected amount" },
        });
      }
    }
    

    const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);
    throwErrorIfAdapterResHaveError(customerInformation, {
      message: `Error while fetching customer details: ${customerId}`,
    });

    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    if (!repaymentClient) {
      logger.error("Error fetching repayment client");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    let pspCustomerId = customer.pspCustomerId;
    if (!customer.pspCustomerId) {
      logger.info("Customer does not exist in PSP. Creating customer...");

      const { data: pspUser, error } = await createPspCustomer({
        repaymentClient,
        customer,
        customerData: customerInformation.data,
      });
      if (error) {
        logger.error("Error creating customer");
        return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
      }
      logger.info(`PSP Customer created: ${pspUser.pspCustomerId}`);
      const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);
      logger.info(
        `Customer updated with pspCustomerId in mobile table: ${customer.customerId} ${pspUser.pspCustomerId}`,
      );

      if (updatedCustomer.error) {
        logger.error("Error updating customer details");
        return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
      }
      pspCustomerId = pspUser.pspCustomerId;
      logger.info("Customer updated with pspCustomerId");
    }

    const amountInCents = Math.round(amount * 100);

    const session = await repaymentClient.createPayByBankHostedSession({
      amount: amountInCents,
      customerId: customer.customerId,
      accountId: customer.accountId,
      accountType: "loan",
      paymentPreferenceName: paymentPreferenceName,
      pspCustomerId: pspCustomerId,
      successUrl,
      cancelUrl,
    });
    if (!session) {
      logger.error("Error creating pay by bank hosted session");
      return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    return formatJSONResponse<PayByBankHostedSession>({ statusCode: 200, body: { url: session.sessionUrl } });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(errorMessage);
    return formatJSONResponse<PayByBankError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }
};
