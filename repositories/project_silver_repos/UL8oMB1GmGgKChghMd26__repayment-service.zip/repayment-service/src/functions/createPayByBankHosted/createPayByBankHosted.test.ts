import { beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./createPayByBankHosted";
import * as dbUtil from "src/utils/db";
import * as adapters from "@onmoapp/onmo-adapters";

vi.mock("src/utils/db");
vi.mock("@onmoapp/onmo-adapters");

describe("createPayByBankHosted", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  const baseCustomerData = {
    data: {
      customerId: "customer-id",
      mambuID: "mambu-id",
      pspCustomerId: "psp-customer-id",
      accountId: "account-id",
      address: "",
      email: "email",
    },
    error: null,
  };
  const baseEventBody = {
    amount: 1,
    successUrl: "https://example.com",
    cancelUrl: "https://example.com",
    paymentPreference: "MIN_PAYMENT",
  };
  describe("Sad Path", () => {
    test("No ONMO UUID in authorizer", async () => {
      const res = await handler({ requestContext: { authorizer: { onmouuid: undefined } } });
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Amount is required", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "invalidUrl",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body : Amount is required" });
    });

    test("Amount is greater than or equal to 50p", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE", amount: 0.49 }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body : Amount must be greater than or equal to £0.50" });
    });
    
    test("A valid success url is required", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          amount: 1,
          successUrl: "invalidUrl",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body : Please enter a valid success URL" });
    });

    test("A valid cancel url is required", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          amount: 1,
          successUrl: "http://test.com",
          cancelUrl: "invalidUrl",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body : Please enter a valid cancel URL" });
    });

    test.each([
      [undefined, "paymentPreference is required"],
      [
        "INVALID",
        "paymentPreference must be one of 'MIN_PAYMENT', 'OVERDUE_PAYMENT', 'OVERLIMIT_AMOUNT', 'STATEMENT_BAL', 'FULL_BALANCE', 'CUSTOM_AMOUNT', 'SMART_PAYMENT' or 'TOP_UP_PAYMENT'",
      ],
    ])("fails when paymentPreference is %s", async (paymentPreference, expectedMessage) => {
      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: `Invalid request body : ${expectedMessage}` });
    });

    test.each(["MIN_PAYMENT", "CUSTOM_AMOUNT", "FULL_BALANCE", "OVERLIMIT_AMOUNT", "STATEMENT_BAL", "TOP_UP_PAYMENT", "SMART_PAYMENT", "OVERDUE_PAYMENT"])(
      "accepts valid paymentPreference: %s",
      async (paymentPreference) => {
        vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
        const res = await handler({
          body: JSON.stringify({ ...baseEventBody, paymentPreference }),
          requestContext: { authorizer: { onmouuid: "customer-id" } },
        });
        // Should pass validation and reach customer fetch (which is mocked to error)
        expect(res.statusCode).toBe(500);
        expect(res.body).toEqual({ message: "Internal Server Error" });
      },
    );

    test("Customer not found in mobile table", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Cannot fetch account details", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: null,
          error: "Cannot fetch account details",
        }),
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Account is in full lock", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              state: "FULL_LOCK",
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Unexpected MINIMUM_PAYMENT amount (totalNextMinimumPaymentDue = 0)", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: { totalNextMinimumPaymentDue: 0 },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid minimum payment amount" });
    });

    test("Unexpected MINIMUM_PAYMENT amount (totalNextMinimumPaymentDue = 10)", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: { totalNextMinimumPaymentDue: 10 },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const res = await handler({
        body: JSON.stringify(baseEventBody),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Amount from request does not match expected amount" });
    });

    test("Unexpected FULL_BALANCE_PAYMENT amount (balances.total = 0)", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: 0,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid full balance payment amount" });
    });

    test("Unexpected FULL_BALANCE amount (balances.total = -10)", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: -10,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Amount from request does not match expected amount" });
    });

    test("fails to create pay by bank hosted session", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: 1,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createPayByBankHostedSession: vi.fn().mockRejectedValue("Error creating hosted session"),
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
  });

  describe("Happy Path", () => {
    test(" create pay by bank hosted session", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: 1,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const createPayByBankHostedSessionMock = vi.fn().mockResolvedValue({
        sessionUrl: "https://example.com/session",
        sessionId: "session-id",
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createPayByBankHostedSession: createPayByBankHostedSessionMock,
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(createPayByBankHostedSessionMock).toHaveBeenCalledWith({
        accountId: "account-id",
        accountType: "loan",
        amount: 100,
        cancelUrl: "https://example.com",
        customerId: "customer-id",
        paymentPreferenceName: "Full Balance Payment",
        pspCustomerId: "psp-customer-id",
        successUrl: "https://example.com",
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({ url: "https://example.com/session" });
    });
    test("create pay by bank hosted session and pre-populate email input if customer has a validated email", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: 1,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({
          data: {
            customerId: "customer-id",
            emailAddresses: {
              primary: "test@onmo.app",
              isEmailValidated: true,
            },
          },
        }),
      });

      const createPayByBankHostedSessionMock = vi.fn().mockResolvedValue({
        sessionUrl: "https://example.com/session",
        sessionId: "session-id",
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createPayByBankHostedSession: createPayByBankHostedSessionMock,
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference: "FULL_BALANCE" }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(createPayByBankHostedSessionMock).toHaveBeenCalledWith({
        accountId: "account-id",
        accountType: "loan",
        amount: 100,
        cancelUrl: "https://example.com",
        customerId: "customer-id",
        paymentPreferenceName: "Full Balance Payment",
        pspCustomerId: "psp-customer-id",
        successUrl: "https://example.com",
      });
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({ url: "https://example.com/session" });
    });

    test.each([
      ["SMART_PAYMENT", "Smart Payment"],
      ["TOP_UP_PAYMENT", "Top Up Payment"],
    ])("creates hosted session with correct paymentPreferenceName for %s", async (paymentPreference, expectedName) => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue(baseCustomerData);
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            accountBalances: {
              balances: {
                total: 1,
              },
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });

      const createPayByBankHostedSessionMock = vi.fn().mockResolvedValue({
        sessionUrl: "https://example.com/session",
        sessionId: "session-id",
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createPayByBankHostedSession: createPayByBankHostedSessionMock,
      });

      const res = await handler({
        body: JSON.stringify({ ...baseEventBody, paymentPreference }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(createPayByBankHostedSessionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentPreferenceName: expectedName,
        }),
      );
      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual({ url: "https://example.com/session" });
    });
  });
});
