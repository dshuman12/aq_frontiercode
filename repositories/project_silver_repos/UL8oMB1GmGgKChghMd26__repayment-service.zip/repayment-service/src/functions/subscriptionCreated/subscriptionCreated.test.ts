import { test, expect, describe, vi, beforeEach } from "vitest";
import { subscriptionCreated } from "./subscriptionCreated";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { getCustomer, updateCustomer } from "@utils/db";

vi.mock("@onmoapp/event-hub-kinesis-adapter");
vi.mock("@onmoapp/core-repayments");
vi.mock("@utils/db");
vi.mock("@functions/cpaReminderScheduler/createCPAReminderSchedules", () => ({
  createCPAReminderSchedules: vi.fn().mockResolvedValue(undefined),
}));

const mockEventHubClient = {
  validateEvent: vi.fn(),
  publishToEventHub: vi.fn(),
};

const mockRepaymentClient = {
  cancelSubscription: vi.fn().mockResolvedValue({ data: { subscriptionId: "sub_123", status: "canceled" }, error: null }),
};

const baseEvent = {
  type: "customer.subscription.created" as const,
  subscriptionId: "sub_123",
  pspCustomerId: "cus_456",
  created: 1700000000,
  status: "active",
  currentPeriodEnd: 1700100000,
  amount: 5000,
  metadata: {
    customerId: "customer_id",
    accountId: "account_id",
  },
};

describe("subscriptionCreated tests", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(EventHubKinesisAdapter.build).mockResolvedValue(mockEventHubClient as any);
    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
    vi.mocked(getCustomer).mockResolvedValue({
      data: { customerId: "customer_id", accountId: "account_id", pspCustomerId: "cus_existing" } as any,
    });
    vi.mocked(updateCustomer).mockResolvedValue({ data: { pspCustomerId: "cus_456" } });
  });

  test("Happy path - CPASubscriptionCreated event published successfully", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: true });
    mockEventHubClient.publishToEventHub.mockResolvedValue({ isValid: true, isPublished: true });

    const response = await subscriptionCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("CPASubscriptionCreated event published successfully.");

    expect(mockEventHubClient.publishToEventHub).toHaveBeenCalled();

    const callParameter = mockEventHubClient.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "CPASubscriptionCreated",
      initiatedBy: "subscriptionCreated",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        pspCustomerId: "cus_456",
        subscriptionDetails: {
          subscriptionId: "sub_123",
          status: "active",
          amount: 5000,
          currentPeriodEnd: 1700100000,
        },
        processor: "Stripe",
        processorReference: null,
      },
    });
  });

  test("Sad path - No customerId in metadata — cancels subscription", async () => {
    const event = { ...baseEvent, metadata: { accountId: "account_id" } };

    const response = await subscriptionCreated(event);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("customerId missing from subscription metadata");
    expect(mockRepaymentClient.cancelSubscription).toHaveBeenCalledWith({
      subscriptionId: "sub_123",
      metadata: { cancellationReason: "cancellation_requested" },
    });
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - No accountId in metadata — cancels subscription", async () => {
    const event = { ...baseEvent, metadata: { customerId: "customer_id" } };

    const response = await subscriptionCreated(event);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("accountId missing from subscription metadata");
    expect(mockRepaymentClient.cancelSubscription).toHaveBeenCalledWith({
      subscriptionId: "sub_123",
      metadata: { cancellationReason: "cancellation_requested" },
    });
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - No metadata at all — cancels subscription", async () => {
    const event = { ...baseEvent, metadata: undefined };

    const response = await subscriptionCreated(event);

    expect(response.statusCode).toBe(400);
    expect(mockRepaymentClient.cancelSubscription).toHaveBeenCalledWith({
      subscriptionId: "sub_123",
      metadata: { cancellationReason: "cancellation_requested" },
    });
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - Invalid customerId (customer not found) — cancels subscription", async () => {
    vi.mocked(getCustomer).mockResolvedValue({ data: null as any, error: "Customer not found" });

    const response = await subscriptionCreated(baseEvent);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("Invalid customerId in subscription metadata — customer not found");
    expect(mockRepaymentClient.cancelSubscription).toHaveBeenCalledWith({
      subscriptionId: "sub_123",
      metadata: { cancellationReason: "cancellation_requested" },
    });
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - accountId does not match customer record — cancels subscription", async () => {
    vi.mocked(getCustomer).mockResolvedValue({
      data: { customerId: "customer_id", accountId: "REAL_ACCOUNT_ID", pspCustomerId: "cus_existing" } as any,
    });

    const response = await subscriptionCreated(baseEvent);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("Invalid accountId in subscription metadata — does not match customer record");
    expect(mockRepaymentClient.cancelSubscription).toHaveBeenCalledWith({
      subscriptionId: "sub_123",
      metadata: { cancellationReason: "cancellation_requested" },
    });
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - Event validation fails", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: false, validationErrors: ["Invalid schema"] });

    const response = await subscriptionCreated(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("An error occured.");
    expect(mockEventHubClient.publishToEventHub).not.toHaveBeenCalled();
  });

  test("Sad path - Event publishing fails", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: true });
    mockEventHubClient.publishToEventHub.mockResolvedValue({ isValid: false, isPublished: false });

    const response = await subscriptionCreated(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("An error occured.");
  });
});
