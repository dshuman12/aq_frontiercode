import { getLogger } from "@libs/logger";
import { SubscriptionCreatedEventOutcome } from "@onmoapp/onmo-types";
import { AccountType, CPASubscriptionCreatedEvent } from "@shared-types/eventHub-types";
import { createEvent } from "@libs/eventHubUtils";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";
import { createCPAReminderSchedules } from "@functions/cpaReminderScheduler/createCPAReminderSchedules";
import { getCustomer, updateCustomer } from "@utils/db";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

const cancelInvalidSubscription = async (subscriptionId: string, logger: any): Promise<void> => {
  try {
    const repaymentClient = await CoreRepaymentsFactory.build("stripe");
    if (repaymentClient) {
      await repaymentClient.cancelSubscription({
        subscriptionId,
        metadata: { cancellationReason: "cancellation_requested" },
      });
      logger.info({ message: "Subscription cancelled due to invalid metadata", subscriptionId });
    }
  } catch (error) {
    logger.error({ message: "Failed to cancel subscription with invalid metadata", subscriptionId, error });
  }
};

export const subscriptionCreated = async (
  event: SubscriptionCreatedEventOutcome,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "subscriptionCreated" });
  logger.info(event);

  const customerId = event.metadata?.customerId;
  const accountId = event.metadata?.accountId;

  if (!customerId || !accountId) {
    const missing = [!customerId && "customerId", !accountId && "accountId"].filter(Boolean).join(", ");
    logger.error({ message: `${missing} missing from subscription metadata — cancelling subscription`, subscriptionId: event.subscriptionId });
    await cancelInvalidSubscription(event.subscriptionId, logger);
    return { statusCode: 400, message: `${missing} missing from subscription metadata` };
  }

  logger.addContext({
    customerId,
    accountId,
    subscriptionId: event.subscriptionId,
    pspCustomerId: event.pspCustomerId,
  });

  // Validate the customer exists and the accountId matches
  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (!customer || customerError) {
    logger.error({ message: "Invalid customerId in subscription metadata — customer not found, cancelling subscription", customerId, subscriptionId: event.subscriptionId });
    await cancelInvalidSubscription(event.subscriptionId, logger);
    return { statusCode: 400, message: "Invalid customerId in subscription metadata — customer not found" };
  }

  if (customer.accountId !== accountId) {
    logger.error({ message: "Invalid accountId in subscription metadata — does not match customer record, cancelling subscription", expected: customer.accountId, received: accountId, subscriptionId: event.subscriptionId });
    await cancelInvalidSubscription(event.subscriptionId, logger);
    return { statusCode: 400, message: "Invalid accountId in subscription metadata — does not match customer record" };
  }

  // Ensure pspCustomerId is stored on the customer record so it's available
  // for getCPASubscription and other functions that need it
  if (event.pspCustomerId && !customer.pspCustomerId) {
    logger.info({ message: "Adding pspCustomerId to customer record", pspCustomerId: event.pspCustomerId });
    const { error: updateError } = await updateCustomer(customerId, event.pspCustomerId);
    if (updateError) {
      logger.error({ message: "Failed to update customer with pspCustomerId", error: updateError });
      return { statusCode: 500, message: "Failed to update customer with pspCustomerId" };
    }
  }

  const eventHubClient = await EventHubKinesisAdapter.build();

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const cpaSubscriptionCreatedEvent: CPASubscriptionCreatedEvent = {
    accountId,
    accountType: AccountType.Card,
    customerId,
    pspCustomerId: event.pspCustomerId,
    subscriptionDetails: {
      subscriptionId: event.subscriptionId,
      status: event.status,
      amount: event.amount,
      currentPeriodEnd: event.currentPeriodEnd,
    },
    processor: "Stripe",
    processorReference: null,
  };

  const eventData = createEvent<CPASubscriptionCreatedEvent>(cpaSubscriptionCreatedEvent, {
    eventType: "CPASubscriptionCreated",
    initiatedBy: "subscriptionCreated",
  });

  logger.info({ eventData });

  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(eventData);

  logger.info({ message: "Result of Event validation", isEventDataValid, eventValidationErrors });

  if (!isEventDataValid) {
    logger.addContext({ eventValidationErrors });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(eventData, eventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }

  await createCPAReminderSchedules({
    accountId,
    customerId,
    pspCustomerId: event.pspCustomerId,
    currentPeriodEnd: event.currentPeriodEnd,
    amount: event.amount,
  });

  return { statusCode: 200, message: "CPASubscriptionCreated event published successfully." };
};
