import { getLogger } from "@libs/logger";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { DirectDebitRepaymentDue } from "@shared-types/sqs-types";
import { formatErrorMessage } from "src/utils/errorUtil";
import { createDirectDebitPayment } from "@libs/directDebit";
import { canTakeDirectDebitPayment } from "@utils/directDebitUtil";

export const handler = async (event: any) => {
  const logger = getLogger();
  logger.addContext({ functionName: "directDebitRepaymentProcessor" });
  logger.info({ message: "Received event", event });

  const directDebitRepaymentDue = event as DirectDebitRepaymentDue;

  const customer = await getCustomer(directDebitRepaymentDue.customerId);

  if (customer.error || !customer.data) {
    logger.error(customer.error);
    throw new Error(`Error getting customer with ID: ${directDebitRepaymentDue.customerId}, ${customer.error}`);
  }

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const creditAccount = await coreBankingClient.getCreditAccount(customer.data.accountId);

  const response = await canTakeDirectDebitPayment({ customer: customer.data, logger, creditAccount });

  if (response.error) {
    logger.error({ error: response.error, message: "Error checking direct debit eligibility" });
    throw new Error(response.error.errorMessage);
  }

  if (!response.data.canTakeDirectDebit) {
    logger.info({ message: response.data.reason });
    return;
  }

  const { nextDirectDebitAmount } = creditAccount.data.directDebitSettings;

  try {
    const { created } = await createDirectDebitPayment({
      accountData: creditAccount.data,
      customer: customer.data,
      directDebitRepaymentDue,
    });
    if (created) {
      await coreBankingClient.setScheduledAmount(customer.data.accountId, nextDirectDebitAmount);
      logger.info({ message: "Scheduled amount set in Mambu account", nextDirectDebitAmount });
    }
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({
      message: "Alert_FailedToCreateIntent: Error processing direct debit repayment",
      error: errorMessage,
    });
    throw new Error("Error processing direct debit repayment");
  }
};
