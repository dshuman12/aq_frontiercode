import { getLogger } from "@libs/logger";
import { InvoicePaidEventOutcome } from "@onmoapp/onmo-types";
import { coreBankingAdapter, eventHubAdapter } from "@onmoapp/onmo-adapters";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { AccountType, RepaymentCollectedEvent } from "@shared-types/eventHub-types";
import { RepaymentType } from "@libs/types";
import { createEvent } from "@libs/eventHubUtils";
import { getCustomer } from "src/utils/db";
import { v4 as uuid } from "uuid";
import { createCPAReminderSchedules } from "@functions/cpaReminderScheduler/createCPAReminderSchedules";

export const invoicePaid = async (event: InvoicePaidEventOutcome): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "invoicePaid" });
  logger.info(event);

  const env = process.env.ENVIRONMENT;
  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
    stageName: env as "staging" | "prod",
  });

  if (!repaymentClient) {
    logger.error("No repayment client found for STRIPE_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("No banking client found for MAMBU_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  const { data: customer, error: customerError } = await getCustomer(event.metadata.customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return { statusCode: 500, message: "An error occured." };
  }

  const { data: creditAccount, error: creditAccountError } = await bankingClient.getCreditAccount(customer.accountId);

  if (creditAccountError || !creditAccount) {
    logger.error("Error fetching credit account");
    return { statusCode: 500, message: "An error occured." };
  }

  const dateFundsLeftCustomersAccount = new Date().toISOString();

  const repaymentCollectedEvent = {
    accountId: event.metadata.accountId,
    accountType: AccountType.Card,
    customerId: event.metadata.customerId,
    date: dateFundsLeftCustomersAccount,
    processor: "Stripe",
    repayment: {
      amount: event.amount, // Amount in cents
      paymentMethod: RepaymentType.CPA,
      externalId: event.paymentIntentId,
    },
  } as RepaymentCollectedEvent;

  const idempotencyKey = uuid();

  const repaymentCollectedEventData = createEvent<RepaymentCollectedEvent>(
    repaymentCollectedEvent,
    {
      eventType: "RepaymentCollected",
      subType: RepaymentType.CPA,
      initiatedBy: "invoicePaid",
    },
    idempotencyKey,
  );

  logger.info({ repaymentCollectedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(repaymentCollectedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(repaymentCollectedEventData, repaymentCollectedEventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }

  // Schedule CPA reminders for the next billing cycle
  const subscriptions = await repaymentClient.getSubscriptionsByPsPCustomerId(event.pspCustomerId);
  const activeSubscription = subscriptions.subscriptions.find((s) => s.status === "active");
  if (activeSubscription) {
    await createCPAReminderSchedules({
      accountId: event.metadata.accountId,
      customerId: event.metadata.customerId,
      pspCustomerId: event.pspCustomerId,
      currentPeriodEnd: activeSubscription.currentPeriodEnd,
      amount: activeSubscription.amount,
    });
  }

  return { statusCode: 200, message: "RepaymentCollected event for CPA invoice published successfully." };
};
