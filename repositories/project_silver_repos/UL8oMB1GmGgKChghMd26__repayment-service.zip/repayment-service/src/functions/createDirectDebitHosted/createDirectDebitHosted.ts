import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer, updateCustomer } from "src/utils/db";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { APIGatewayEventHandler, DirectDebitError, DirectDebitHosted } from "@libs/types";
import { createPspCustomer } from "src/utils/createPspCustomer";
import { pspCustomerHasPendingMandate } from "src/utils/pendingMandateUtil";
import { formatErrorMessage } from "src/utils/errorUtil";

const env = process.env.ENVIRONMENT;

// According to UX requirements, an amount should be provided
// at time of DirectDebit creation, even though it's not
// strictly necessary to establish the direct debit.
// In the future, there may be more validation necessary, or
// amount is not required at all.
const validateBody = (body: string) => {
  return z
    .object({
      successUrl: z.string().refine((value) => /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value), {
        message: "Please enter a valid URL",
      }),
      cancelUrl: z
        .string()
        .refine((value) => /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value), {
          message: "Please enter a valid URL",
        })
        .optional(),
    })
    .safeParse(JSON.parse(body));
};

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createDirectDebitHosted" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  const body = validateBody(event.body || "");

  if (body.error || !body.data) {
    logger.error(`Invalid request body: ${body.error}`);
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Invalid request body" } });
  }

  logger.info({ body });

  const { successUrl, cancelUrl } = body.data;

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);

  if (customerInformation.error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (data.accountDetails.state === "FULL_LOCK") {
    logger.warn("Account is fully locked, returning 400");
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Bad Request" } });
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Error fetching repayment client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  let pspCustomerId = customer.pspCustomerId;
  if (!customer.pspCustomerId) {
    logger.info("Customer does not exist in PSP. Creating customer...");

    const { data: pspUser, error } = await createPspCustomer({
      repaymentClient,
      customer,
      customerData: customerInformation.data,
    });
    if (error) {
      logger.error("Error creating customer");
      return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    logger.info(`PSP Customer created: ${pspUser.pspCustomerId}`);
    const updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);
    logger.info(`Customer updated with pspCustomerId in mobile table: ${customer.customerId} ${pspUser.pspCustomerId}`);

    if (updatedCustomer.error) {
      logger.error("Error updating customer details");
      return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    pspCustomerId = pspUser.pspCustomerId;
    logger.info("Customer updated with pspCustomerId");
  } else {
    const { data, error } = await pspCustomerHasPendingMandate(customer.pspCustomerId);
    if (error) {
      logger.addContext({ errorDetails: error.message });
      logger.error("Error checking for pending mandate");
      return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }

    // We block creation when another mandate was made recently and is still pending
    if (data.hasPendingMandate) {
      logger.error("Cannot create Direct Debit. Pending mandate found. Returning 500.");
      return formatJSONResponse<DirectDebitError>({
        statusCode: 500,
        body: { message: "Cannot create a new mandate when a pending mandate exists." },
      });
    }
  }

  let directDebitSession;
  try {
    directDebitSession = await repaymentClient.createDirectDebitHosted({
      customerId,
      accountType: "card",
      pspCustomerId: pspCustomerId,
      accountId: customer.accountId,
      successUrl,
      cancelUrl,
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error creating direct debit session: ${errorMessage}`);
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!directDebitSession) {
    logger.error("Error creating direct debit session");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.info(`Direct debit session created: ${directDebitSession}`);

  return formatJSONResponse<DirectDebitHosted>({ statusCode: 200, body: { url: directDebitSession.url } });
};
