import { beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./createDirectDebitHosted";
import * as dbUtil from "src/utils/db";
import * as adapters from "@onmoapp/onmo-adapters";
import * as createPspUtil from "src/utils/createPspCustomer";
import * as pendingMandateUtil from "src/utils/pendingMandateUtil";

vi.mock("src/utils/db");
vi.mock("@onmoapp/onmo-adapters");
vi.mock("src/utils/createPspCustomer");
vi.mock("src/utils/pendingMandateUtil");

describe("createDirectDebitHosted", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  test("Happy Path - PSP Customer exists", async () => {
    vi.mocked(dbUtil.getCustomer).mockResolvedValue({
      data: {
        customerId: "customer-id",
        mambuID: "mambu-id",
        pspCustomerId: "psp-customer-id",
        accountId: "account-id",
        address: "",
        email: "email",
      },
      error: null,
    });
    vi.mocked(createPspUtil.createPspCustomer).mockResolvedValue(null);
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2025-01-27",
            state: "NOT_APPLICABLE",
          },
          directDebitSettings: {
            nextDirectDebitAmount: 10,
          },
        },
      }),
      getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      createDirectDebitHosted: vi.fn().mockResolvedValue({
        url: "session-url",
      }),
    });
    vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
      data: { hasPendingMandate: false },
    });

    const res = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: { authorizer: { onmouuid: "customer-id" } },
    });

    const createPspMock = await vi.mocked(createPspUtil);
    expect(createPspMock.createPspCustomer).not.toHaveBeenCalled();

    const pendingMandateMock = vi.mocked(pendingMandateUtil);
    expect(pendingMandateMock.pspCustomerHasPendingMandate).toHaveBeenCalled();

    const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentMock.createDirectDebitHosted).toHaveBeenCalledWith({
      customerId: "customer-id",
      accountType: "card",
      pspCustomerId: "psp-customer-id",
      accountId: "account-id",
      successUrl: "https://example.com",
      cancelUrl: "https://example.com",
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ url: "session-url" });
  });
  test("Happy Path - PSP Customer does not exist", async () => {
    vi.mocked(dbUtil.getCustomer).mockResolvedValue({
      data: {
        customerId: "customer-id",
        mambuID: "mambu-id",
        pspCustomerId: undefined,
        accountId: "account-id",
        address: "",
        email: "email",
      },
      error: null,
    });
    vi.mocked(dbUtil.updateCustomer).mockResolvedValue({
      data: {
        pspCustomerId: "new-psp-customer-id",
      },
      error: null,
    });
    vi.mocked(createPspUtil.createPspCustomer).mockResolvedValue({
      data: { pspCustomerId: "new-psp-customer-id" },
      error: undefined,
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2025-01-27",
            state: "NOT_APPLICABLE",
          },
          directDebitSettings: {
            nextDirectDebitAmount: 10,
          },
        },
      }),
      getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      createDirectDebitHosted: vi.fn().mockResolvedValue({
        url: "session-url",
      }),
    });
    vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
      data: { hasPendingMandate: false },
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      createDirectDebitHosted: vi.fn().mockResolvedValue({
        url: "session-url",
      }),
    });

    const res = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: { authorizer: { onmouuid: "customer-id" } },
    });

    const createPspMock = await vi.mocked(createPspUtil);
    expect(createPspMock.createPspCustomer).toHaveBeenCalled();

    const pendingMandateMock = vi.mocked(pendingMandateUtil);
    expect(pendingMandateMock.pspCustomerHasPendingMandate).not.toHaveBeenCalled();

    const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentMock.createDirectDebitHosted).toHaveBeenCalledWith({
      customerId: "customer-id",
      accountType: "card",
      pspCustomerId: "new-psp-customer-id",
      accountId: "account-id",
      successUrl: "https://example.com",
      cancelUrl: "https://example.com",
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ url: "session-url" });
  });
  describe("Sad Path", () => {
    test("No ONMO UUID in authorizer", async () => {
      await expect(handler({ requestContext: { authorizer: { onmouuid: undefined } } })).rejects.toThrow(
        "Missing onmouuid from authorizer",
      );
    });
    test("Invalid request body", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "invalidUrl",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });
    test("Customer not found in mobile table", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
    test("Pending mandate exists", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockResolvedValue({
          url: "session-url",
        }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: true },
      });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Cannot create a new mandate when a pending mandate exists." });
    });
    test("Cannot fetch account details", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: null,
          error: "Cannot fetch account details",
        }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
    test("Customer already has a mandate setup - It should not block creation", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockResolvedValue({
          url: "session-url",
        }),
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(200);
    });
    test("Account is in full lock", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "FULL_LOCK",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Bad Request" });
    });
    test("Error creating the hosted session", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
        getCustomerByCoreBankingCustomerId: vi.fn().mockResolvedValue({ data: { customerId: "customer-id" } }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockRejectedValue("Error creating hosted session"),
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });

      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
  });
});
