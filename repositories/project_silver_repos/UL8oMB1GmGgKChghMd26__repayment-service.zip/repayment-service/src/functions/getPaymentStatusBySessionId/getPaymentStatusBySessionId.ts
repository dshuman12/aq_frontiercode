import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { APIGatewayEventGet } from "@libs/types";
import { getLogger } from "@libs/logger";

export const handler = async (event: APIGatewayEventGet): Promise<any> => {
  const logger = getLogger();

  logger.addContext({ functionName: "getPaymentReceiptBySessionId" });
  logger.info({ event });

  try {
    const sessionId = event.pathParameters?.sessionId;
    logger.addContext({ sessionId });

    if (!sessionId) {
      logger.error("Missing sessionId in request");
      return formatJSONResponse({ statusCode: 400, body: { message: "Missing sessionId in request" } });
    }

    const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

    const paymentIntent = await repaymentClient.getPaymentIntentBySessionId(sessionId);

    const status = {
      status: paymentIntent.status || null,
    };

    return formatJSONResponse({ statusCode: 200, body: status });
  } catch (error) {
    logger.error(error);
    return formatJSONResponse({ statusCode: 500, body: { message: "Internal Server Error" } });
  }
};
