import { getLogger } from "@libs/logger";
import { coreBankingAdapter, MambuClient } from "@onmoapp/onmo-adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { sendMessage } from "@onmoapp/onmo-sqs";
import { DirectDebitRepaymentDue } from "@shared-types/sqs-types";
import { SQSEvent, SQSRecord } from "aws-lambda";
import { logAndReturnFailedMessage, setProgressiveRetry } from "src/utils/sqsUtils";

export const handler = async (event: SQSEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "ddFullStatementScheduler" });
  logger.info({ message: "Received event", event });

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const promises = event.Records.map((sqsRecord) =>
    checkUserPreferenceForDirectDebit({ sqsRecord, coreBankingClient, logger }),
  );
  const result = await Promise.all(promises); // Process items in parallel
  const batchItemFailures = result
    .filter((result) => result.error)
    .map((r) => ({
      itemIdentifier: r.error.sqsMessageId,
    }));

  return { batchItemFailures }; // Report failed messages for SQS to handle the retry without invalidating the whole batch
};

type CheckUserPreferenceInput = {
  sqsRecord: SQSRecord;
  coreBankingClient: MambuClient;
  logger: Logger;
};

type CheckUserPreferenceOutcome = {
  success?: boolean;
  error?: {
    message: string;
    sqsMessageId: string;
  };
};

export type CheckUserPreference = {
  parentAccountKey: string;
};

const checkUserPreferenceForDirectDebit = async ({
  sqsRecord,
  coreBankingClient,
  logger,
}: CheckUserPreferenceInput): Promise<CheckUserPreferenceOutcome> => {
  await setProgressiveRetry(sqsRecord, process.env.DD_FULL_STATEMENT_CHECK_QUEUE_URL, logger);
  const event = JSON.parse(sqsRecord.body) as CheckUserPreference;
  const { parentAccountKey } = event;

  const res = await coreBankingClient.getCreditAccountsByParentAccountKey(parentAccountKey);
  if (res.error) {
    return logAndReturnFailedMessage({ sqsRecord, message: res.error.errorMessage, logger });
  }

  const accountId = res.data[0].accountId;
  const accountResult = await coreBankingClient.getCreditAccount(accountId);
  if (accountResult.error) {
    return logAndReturnFailedMessage({ sqsRecord, message: accountResult.error.errorMessage, logger });
  }

  const accountData = accountResult.data;

  const ddSettings = accountData.directDebitSettings;
  if (!ddSettings || !ddSettings.mandateID) {
    logger.info(`No direct debit mandate found for accountId: ${accountId}. No further action needed.`);
    return { success: true };
  }

  if (
    ddSettings.amountPreference === "Full Statement Balance" &&
    ddSettings.nextDirectDebitAmount &&
    ddSettings.nextDirectDebitAmount > 0
  ) {
    // This user made a card repayment this month that satisfied the minimum due
    // but their preference is to take the full amount and they still have a balance to pay
    // scheduling direct debit to be taken (as Mambu webhook won't fire for this)
    const directDebitRepaymentDue = {
      accountId,
      customerId: accountData.accountDetails.customerId,
      dueDate: accountData.accountDetails.nextStatementDueDate,
    } as DirectDebitRepaymentDue;

    logger.info({ message: "Sending message to SQS", directDebitRepaymentDue });
    const result = await sendMessage({
      MessageBody: JSON.stringify(directDebitRepaymentDue),
      QueueUrl: process.env.REPAYMENT_DUE_THROTTLING_QUEUE_URL,
    });

    logger.info({ message: "Message sent to SQS", messageId: result.MessageId, sequenceNumber: result.SequenceNumber });
    return {
      success: true,
    };
  }

  logger.info({ message: `No action needed for accountId: ${accountId}.` });
  return {
    success: true,
  };
};
