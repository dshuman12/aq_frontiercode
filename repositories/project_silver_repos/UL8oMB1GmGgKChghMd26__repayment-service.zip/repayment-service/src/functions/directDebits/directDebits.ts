import { BASE_PATH } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { RequestContextBindings } from "@libs/types";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { Hono } from "hono";
import { handle } from "hono/aws-lambda";
import { getCustomer } from "src/utils/db";
import { formatErrorMessage } from "src/utils/errorUtil";

const app = new Hono<{ Bindings: RequestContextBindings }>().basePath(`/${BASE_PATH}/*`);

export const directDebitHandler = app.get("/direct-debit", async (c) => {
  const logger = getLogger();

  logger.info("Getting All Direct Debits");
  const { onmouuid: customerId } = c.env.event.requestContext.authorizer;

  logger.addContext({ customerId });

  if (!customerId) {
    logger.error("Customer ID missing");
    return c.json({ message: "Customer ID missing" }, 400);
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return c.json({ message: "Repayment client not found" }, 500);
  }

  const { data, error } = await getCustomer(customerId);

  if (error) {
    logger.error(`Error fetching customer details: ${error}`);
    return c.json({ message: "Internal Server Error" }, 500);
  }

  let paymentMethods;
  try {
    paymentMethods = await repaymentClient.getPaymentMethodByPspCustomerId(data.pspCustomerId, { type: "bacs_debit" });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error({ message: `Error retrieving payment methods: ${errorMessage}` });
    return c.json({ message: "error retrieving payment methods" }, 500);
  }

  logger.info({ paymentMethods });

  return c.json({ paymentMethods }, 200);
});

export const handler = handle(app);
export default handler;
