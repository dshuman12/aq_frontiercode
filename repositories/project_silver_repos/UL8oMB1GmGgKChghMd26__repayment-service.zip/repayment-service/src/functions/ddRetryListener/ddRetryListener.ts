import { getLogger } from "@libs/logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { EventData, EventHubDataToPublishType } from "@onmoapp/event-hub-interface";
import { DDEligibleForRetryEvent } from "@shared-types/eventHub-types";
import { deserializeUtil } from "@libs/deserializeUtil";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { CORE_BANKING_ADAPTER_CLIENT_NAME, SFMC_DD_FAILED_INSUFFICIENT_FUNDS } from "@libs/constants";
import { UpdateCreditAccountOutcome } from "@onmoapp/onmo-types";
import { throwErrorIfAdapterResHaveError } from "src/utils/errorUtil";
import { createSchedule } from "@functions/directDebitRepaymentScheduler/createSchedule";
import dayjs from "dayjs";
import { v4 as uuid } from "uuid";
import { sendMessage } from "@onmoapp/onmo-sqs";
import { SFMCCommsEvent } from "@shared-types/sqs-types";
import { addWorkingDays } from "@utils/dateUtils";
import { RepaymentType } from "@libs/types";
import { putScheduleDataInDatalakeS3 } from "@utils/schedulerUtil";

export const handler = async (event: any) => {
  const logger = getLogger();
  logger.addContext({ functionName: "ddRetryListener" });

  //parse the event - bypassing the enrichment for now
  const data = event?.Records[0]?.kinesis?.data;
  if (!data) {
    logger.error("No Kinesis data found.");
    return formatJSONResponse({ statusCode: 500, body: { message: "No Kinesis data" } });
  }
  const dataBuffer = JSON.parse(Buffer.from(data, "base64").toString()) as EventHubDataToPublishType;
  const ddEligibleForRetry: EventData<DDEligibleForRetryEvent> = await deserializeUtil(
    dataBuffer.data,
    dataBuffer.schemaId,
  );
  logger.info({
    message: `ddFailedEligibleForRetry event received and validated: ${ddEligibleForRetry}`,
  });

  //extract attributes from event data necessary for processing
  const { dueDate, failureDate, accountId, customerId } = ddEligibleForRetry.eventData;
  if (!dayjs(dueDate, "YYYY-MM-DD", true).isValid()) {
    const msg = `Invalid dueDate format: ${dueDate}. Expected format: YYYY-MM-DD`;
    logger.error(msg);
    throw new Error(msg);
  }
  logger.info(`Due date format validated`);
  logger.addContext({ dueDate });
  if (!dayjs(failureDate, "YYYY-MM-DD", true).isValid()) {
    const msg = `Invalid failureDate format: ${dueDate}. Expected format: YYYY-MM-DD`;
    logger.error(msg);
    throw new Error(msg);
  }
  logger.addContext({ failureDate });
  logger.info(`Failure date format validated`);
  logger.addContext({ accountId, customerId });

  //calculate retry date, prevent retry date & avoid fee cut off date (arrears date)
  const retryDate = addWorkingDays(failureDate, 6); //6 working days from failure date, date retry funds will leave customers account if their eligble
  logger.info(`Retry date calculated: ${retryDate}`);
  const avoidFeeCutOffDate = dayjs(dueDate).add(7, "day").format("YYYY-MM-DD");
  logger.info(
    `Avoid fee cut off date calculated: ${avoidFeeCutOffDate} e.g the day customer will go into arrears. 7 days from due date (installment date of failed direct debit)`,
  );
  const preventRetryDate = addWorkingDays(failureDate, 3);

  //schedule event bridge event for payment intent processor in 4 working days, 2am.
  const retryIntentAssessmentDate2am = dayjs(addWorkingDays(failureDate, 4))
    .set("hour", 2)
    .set("minute", 0)
    .set("second", 0)
    .set("millisecond", 0);

  await createSchedule({
    accountId,
    customerId,
    paymentDate: retryIntentAssessmentDate2am.toISOString(),
    repaymentType: RepaymentType.DirectDebitRetry,
    paymentIntentId: ddEligibleForRetry.eventData.paymentIntentId,
    idempotencyKey: uuid(), // One unique ID for each payment scheduled for safe retries in the EventBridge Scheduler
  });

  const scheduleDataForDatalake = {
    accountId,
    customerId,
    dateIntentWillBeCreated: retryIntentAssessmentDate2am.toISOString(),
    dueDate,
    repaymentType: RepaymentType.DirectDebitRetry,
    dateScheduleCreated: dayjs().toISOString(),
  };

  await putScheduleDataInDatalakeS3({ customerId, scheduleDataForDatalake, logger });

  logger.info(`Stored schedule data to S3 for datalake`);

  //update dd retry flags
  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);
  logger.info({ message: "Core banking client created" });
  const updateDDRetryFields: UpdateCreditAccountOutcome = await coreBankingClient.updateDDRetryFields(
    accountId,
    true,
    retryDate,
    preventRetryDate,
    avoidFeeCutOffDate,
  );
  throwErrorIfAdapterResHaveError(updateDDRetryFields, { message: "Failed to update DD retry fields" });
  logger.info({ message: "DD retry fields updated" });

  //send insufficent funds eligble for retry comms via sfmc
  const insufficientFundsRetryCommsEvent = {
    commsKey: SFMC_DD_FAILED_INSUFFICIENT_FUNDS,
    firstName: ddEligibleForRetry.eventData.firstName.trim(),
    dueDate: dayjs(dueDate).format("YYYY-MM-DD"),
    emailAddress: ddEligibleForRetry.eventData.emailAddress,
    customerId,
    personContactId: ddEligibleForRetry.eventData.personContactId,
    phoneNumber: ddEligibleForRetry.eventData.phoneNumber,
    retryDate,
    avoidFeeCutOffDate,
    preventRetryDate,
  } as SFMCCommsEvent;
  logger.info({
    message: "Sending message to SFMC SQS for insufficent funds retry DD comms",
    insufficientFundsRetryCommsEvent,
  });
  const result = await sendMessage({
    MessageBody: JSON.stringify(insufficientFundsRetryCommsEvent),
    QueueUrl: process.env.SFMC_COMMS_QUEUE_URL,
  });
  logger.info({
    message: "Message sent to SFMC comms SQS for insufficent funds retry coms",
    messageId: result.MessageId,
    sequenceNumber: result.SequenceNumber,
  });
};
