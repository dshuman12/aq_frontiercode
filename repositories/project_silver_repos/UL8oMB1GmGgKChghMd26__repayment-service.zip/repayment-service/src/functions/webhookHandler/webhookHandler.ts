import { getLogger } from "@libs/logger";
import { Hono } from "hono";
import { handle, LambdaEvent } from "hono/aws-lambda";
import dotenv from "dotenv";
import { mandateUpdated } from "../mandateUpdated/mandateUpdated";
import fs from "fs";
import { PaymentIntentSucceededEventOutcome } from "@onmoapp/onmo-types";
import { StatusCode } from "hono/utils/http-status";
import { paymentIntentSucceeded } from "../paymentSucceeded";
import { paymentIntentFailed } from "../paymentFailed";
import { paymentIntentCreated } from "../paymentIntentCreated/paymentIntentCreated";
import { customerCreated } from "@functions/customerCreated";
import { BASE_PATH } from "@libs/constants";
import { formatErrorMessage } from "src/utils/errorUtil";
import { invoicePaid } from "@functions/invoicePaid/invoicePaid";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";
import { invoiceFailed } from "@functions/invoiceFailed/invoiceFailed";
import { subscriptionCancelled } from "@functions/subscriptionCancelled/subscriptionCancelled";
import { subscriptionCreated } from "@functions/subscriptionCreated/subscriptionCreated";
import { isCPAEnabled } from "@libs/featureFlags";

dotenv.config();

/**
 * Checks if a payment intent is a CPA (subscription) payment intent by
 * looking for an invoice attached to the payment intent object.
 * CPA payment intents are created automatically by Stripe subscriptions
 * and will always have an associated invoice.
 */
const isCPAPaymentIntent = (event: any, cpaEnabled: boolean): boolean => {
  if (!cpaEnabled) return false;
  return event?.invoice != null;
};

type Bindings = {
  event: LambdaEvent & { rawBody: string };
};

const app = new Hono<{ Bindings: Bindings }>().basePath(`/${BASE_PATH}/*`);

// useful for generating test data. This will write the event to a file in the data folder.
const STORE_TEST_DATA = false;

export const localApp = app.post("/webhook-handler", async (c) => {
  const logger = getLogger();

  const signature = c.req.header("stripe-signature");
  const body = await c.req.text();
  const rawBody = c.env.event?.rawBody;
  logger.addContext({ functionName: "webhookHandler" });
  logger.info({ message: "Received webhook event", rawBody });

  if (!signature) {
    logger.error("Signature missing");
    return c.json({ message: "Signature missing" }, 400);
  }

  const env = process.env.ENVIRONMENT;

  const repaymentClient = await CoreRepaymentsFactory.build("stripe", {
    stageName: env as "staging" | "prod",
  });

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return c.json({ message: "Repayment client not found" }, 500);
  }

  let event;
  try {
    event = await repaymentClient.webhookHandler(rawBody || body, signature);
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error handling webhook: ${errorMessage}`);
    return c.json({ message: "Error handling webhook" }, 500);
  }

  if (!event) {
    logger.error("Event not found");
    return c.json({ message: "Event not found" }, 500);
  }

  logger.info({ event });
  logger.info(`Processing event type: "${event.type}" (type: ${typeof event.type}, length: ${event.type?.length})`);
  logger.info(`Event type raw bytes: ${JSON.stringify([...event.type].map((c) => c.charCodeAt(0)))}`);

  // this can be used to capture webhook events that have been forwarded by stripe.
  if (STORE_TEST_DATA) {
    fs.writeFileSync(`data/${event.type}.json`, JSON.stringify(event, null, 2));
  }

  const cpaEnabled = await isCPAEnabled();
  logger.addContext({ cpaEnabled });

  logger.info("About to enter switch statement");

  switch (event.type) {
    case "payment_intent.succeeded": {
      logger.info("Matched: payment_intent.succeeded");
      console.log("Payment intent succeeded", event);
      const paymentSuccessfulEvent = event as PaymentIntentSucceededEventOutcome;

      if (isCPAPaymentIntent(paymentSuccessfulEvent, cpaEnabled)) {
        // CPA payment intents are created by Stripe subscriptions and have an invoice attached.
        // We listen to invoice.paid events for these instead.
        return c.json({ message: "Invoice payment intent succeeded events are not processed" }, 200);
      }

      const { message, statusCode } = await paymentIntentSucceeded(paymentSuccessfulEvent);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "payment_intent.payment_failed": {
      logger.info("Matched: payment_intent.payment_failed");
      console.log("Payment intent failed", event);

      if (isCPAPaymentIntent(event, cpaEnabled)) {
        // CPA payment intents are created by Stripe subscriptions and have an invoice attached.
        // We listen to invoice.payment_failed events for these instead.
        return c.json({ message: "Invoice payment intent failed events are not processed" }, 200);
      }
      const { message, statusCode } = await paymentIntentFailed(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "payment_intent.created": {
      logger.info("Matched: payment_intent.created");

      // Only CPA (invoice-linked) PIs need metadata stamping. Non-CPA PIs
      // are created by us directly via paymentIntents.create with metadata
      // already set inline.
      if (!isCPAPaymentIntent(event, cpaEnabled)) {
        return c.json({ message: "Non-CPA payment intent — no metadata stamp needed" }, 200);
      }

      const { message, statusCode } = await paymentIntentCreated({
        type: "payment_intent.created",
        paymentIntentId: event.paymentIntentId,
        invoice: (event as any).invoice,
      });
      return c.json({ message }, statusCode as StatusCode);
    }
    case "payment_method.attached":
      logger.info("Matched: payment_method.attached");
      console.log("Payment method attached", event);
      break;
    case "mandate.updated": {
      logger.info("Matched: mandate.updated");
      const { message, statusCode } = await mandateUpdated(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "setup_intent.created":
      logger.info("Matched: setup_intent.created");
      console.log("Setup intent created", event);
      break;
    case "setup_intent.succeeded":
      logger.info("Matched: setup_intent.succeeded");
      console.log("Setup intent succeeded", event);
      break;
    // case 'checkout.session.completed':
    //   console.log('Checkout session completed', event)
    //   break
    case "payment_method.detached":
      logger.info("Matched: payment_method.detached");
      console.log("Payment method detached", event);
      break;
    case "customer.created": {
      logger.info("Matched: customer.created");
      console.log("Customer created", event);
      const { message, statusCode } = await customerCreated(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "invoice.paid": {
      logger.info("Matched: invoice.paid");
      if (!cpaEnabled) return c.json({ message: "CPA disabled, skipping invoice.paid" }, 200);
      console.log("Invoice paid", event);
      const { message, statusCode } = await invoicePaid(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "invoice.payment_failed": {
      logger.info("Matched: invoice.payment_failed");
      if (!cpaEnabled) return c.json({ message: "CPA disabled, skipping invoice.payment_failed" }, 200);
      console.log("Invoice failed", event);
      const { message, statusCode } = await invoiceFailed(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "customer.subscription.created": {
      logger.info("Matched: customer.subscription.created");
      if (!cpaEnabled) return c.json({ message: "CPA disabled, skipping subscription.created" }, 200);
      console.log("Subscription created", event);
      const { message, statusCode } = await subscriptionCreated(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    case "customer.subscription.deleted": {
      logger.info("Matched: customer.subscription.deleted");
      if (!cpaEnabled) return c.json({ message: "CPA disabled, skipping subscription.deleted" }, 200);
      console.log("Subscription cancelled", event);
      const { message, statusCode } = await subscriptionCancelled(event);
      return c.json({ message }, statusCode as StatusCode);
    }
    default:
      logger.warn(`Event type "${event.type}" did not match any case`);
      logger.warn(`Checking literal match: invoice.paid === event.type: ${event.type === "invoice.paid"}`);
      console.log("Event not handled", event.type);
  }
  logger.info("Exited switch statement, returning default response");
  return c.json({ message: "Event received" });
});

export const handler = handle(app);
export default handler;
