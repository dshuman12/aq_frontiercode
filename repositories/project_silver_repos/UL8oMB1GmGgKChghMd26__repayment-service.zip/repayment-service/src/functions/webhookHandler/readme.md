# Webhook Handler

The event handler is the function that handles webhook connections
from the repayments provider. It is responsible for delegating the
event to the correct function. The event handler is the entry point.

It's also possible to run it in local development mode, which it runs
in a server, and allows debugging.

## Getting Started

In order to get started with the event handler, you will need to have
the stripe CLI installed in order to forward events to your local machine.

[stripe CLI](https://docs.stripe.com/stripe-cli)

### Forwarding Stripe Events

Once you have the CLI installed, and authenticated, you can run the
following command to start forwarding events to your local machine

```bash
stripe listen --load-from-webhooks-api --forward-to localhost:4242
```

Running this command will output a webhook secret, which you will
need to set the LOCAL_STRIPE_WEBHOOK_SECRET environment variable.

### Trigger Events

In order to trigger events, so that you can see them working, run

```bash
stripe trigger payment_intent.succeeded
```

### Running the event handler

In order to run the event handler in local development mode, run

```bash
yarn dev
```

### Trigger Events from repayments-service-ui

Some events are not able to be triggered from the stripe CLI, such as
'mandate.updated'. In order to trigger these events, you need to use a
stripe form from the front-end. You can spin up the repayments-service-ui.

## TODO

I would like to implement testing in local development mode, so that
I can test the event handler without having to rely on deploying to
staging. This will require invoking stripe events in the test suite.
