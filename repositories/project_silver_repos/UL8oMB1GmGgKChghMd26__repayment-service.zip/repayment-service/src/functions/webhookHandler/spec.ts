import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

app.openapi(
  createRoute({
    method: 'post',
    path: '/webhook-handler',
    description: 'A webhook handler that receives events from the payment provider',
    security: [
      {
        Bearer: []
      }
    ],
    request: {
      body: {
        description: 'The event from the payment provider',
        content: {
          'application/json': {
            schema: z.object({
              event: z.object({
                type: z.string(),
                pspCustomerId: z.string(),
                created: z.number(),
                metadata: z.any().optional(),
                mandateId: z.string().optional(),
                acceptedAt: z.number().nullable().optional(),
                status: z.string().optional(),
                paymentIntentId: z.string().optional(),
                amount: z.number().optional(),
                sessionId: z.string().optional(),
              })
            })
          }
        }
      }
    },
    responses: {
      200: {
        description: 'success',
        content: {
          'application/json': {
            schema: z.object({
              message: z.string(),
            })
          }
        }
      }
    }
  }),
  (c) => {
    return c.json({
      message: 'this is a webhook handler, and you will never see this message.'
    })
  }
)

export default app
