import { serve } from '@hono/node-server'
import { localApp } from './webhookHandler'

require('dotenv').config()

const port = 4242
console.log('This should not be running in production')
console.log(`Server is running on http://localhost:${port}`)

serve({
  fetch: localApp.fetch,
  port
})
