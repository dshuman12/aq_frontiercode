import { getLogger } from "@libs/logger";
import { coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { APIGatewayEventGet, DirectDebitError } from "@libs/types";
import { formatJSONResponse } from "@libs/gatewayUtils";

type DirectDebitIntentOutcome = {
  directDebitDetails: any;
};

export const handler = async (event: APIGatewayEventGet) => {
  const logger = getLogger();

  logger.info("getting payment method by mandate id");
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  const mandateId = event.pathParameters?.mandateId;
  logger.addContext({ customerId, mandateId });

  if (!customerId) {
    logger.error("Customer ID missing");
    return formatJSONResponse<DirectDebitError>({ statusCode: 401, body: { message: "Unauthorized." } });
  }

  const customer = await getCustomer(customerId);

  if (!customer.data) {
    logger.error("Customer not found");
    return formatJSONResponse<DirectDebitError>({ statusCode: 404, body: { message: "Customer not found" } });
  }

  logger.info({ customer });

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Repayment client not found" } });
  }

  try {
    const directDebitDetails = await repaymentClient.getPaymentMethodByMandateId(mandateId);

    if (!directDebitDetails || Object.keys(directDebitDetails).length === 0) {
      // When the app loads, it does a check to see if a mandate exists in stripe or not.
      // if a user has not setup a direct debit, this will throw a warning.
      logger.warn("Direct debit details not found");
      return formatJSONResponse<DirectDebitError>({
        statusCode: 404,
        body: { message: "Mandate not found" },
      });
    }

    logger.info({ directDebitDetails });

    // check if pspCustomerId matches the pspCustomerId from the customer object
    if (directDebitDetails.pspCustomerId !== customer.data.pspCustomerId) {
      logger.error(`PSP Customer ID mismatch: ${directDebitDetails.pspCustomerId} !== ${customer.data.pspCustomerId}`);
      return formatJSONResponse<DirectDebitError>({ statusCode: 404, body: { message: "PSP Customer ID mismatch" } });
    }

    return formatJSONResponse<DirectDebitIntentOutcome>({ statusCode: 200, body: { directDebitDetails } });
  } catch (e) {
    if (e.message === "No customer found on payment method") {
      logger.info({ message: `Payment method linked to mandate is detached from user. Returning 404.` });
      return formatJSONResponse<DirectDebitError>({
        statusCode: 404,
        body: { message: "Mandate does not exist on customer." },
      });
    }
    logger.error(`Error getting direct debit details: ${e.message}`);
    return formatJSONResponse<DirectDebitError>({
      statusCode: 500,
      body: { message: "Error getting direct debit details" },
    });
  }
};

export default handler;
