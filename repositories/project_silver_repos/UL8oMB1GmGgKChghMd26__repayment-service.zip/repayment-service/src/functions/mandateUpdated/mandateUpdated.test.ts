
import { test, expect } from "vitest";

test("mandateUpdated test", async () => {
  // TODO 
  expect(true).toBeTruthy();
});
