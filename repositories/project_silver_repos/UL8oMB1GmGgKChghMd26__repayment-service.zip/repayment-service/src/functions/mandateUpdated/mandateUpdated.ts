import { createEvent } from "@libs/eventHubUtils";
import { getLogger } from "@libs/logger";
import { coreBankingAdapter, eventHubAdapter } from "@onmoapp/onmo-adapters";
import { MandateUpdatedEventOutcome } from "@onmoapp/onmo-types";
import { MandateCancelledEvent, MandateUpsertedEvent } from "@shared-types/eventHub-types";
import { getCustomer } from "src/utils/db";

export const mandateUpdated = async (
  event: MandateUpdatedEventOutcome,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "mandateUpdated" });

  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  logger.debug({ event });

  const { data, error } = await getCustomer(event.customerId);

  if (error) {
    logger.error(`Error fetching customer details: ${error}`);
    return { statusCode: 500, message: "An error occured." };
  }

  if (event.status === "CANCELLED") {
    const mandateCancelledEventData = createEvent<MandateCancelledEvent>(
      {
        mandateId: event.mandateId,
        accountId: data.accountId,
        customerId: event.customerId,
        cancellationReason: event.revocationReason,
        cancellationDate: new Date().getTime(),
      },
      {
        eventType: "MandateCancelled",
        initiatedBy: "mandateUpdated",
      },
    );

    logger.info({ mandateCancelledEventData });

    const { isValid: isCancelledEventValid, validationErrors: cancelledValidationErrors } =
      await eventHubClient.validateEvent(mandateCancelledEventData);

    logger.info({
      message: "Result of Event validation",
      isCancelledEventValid,
      cancelledValidationErrors,
    });

    if (!isCancelledEventValid) {
      logger.addContext({ cancelledValidationErrors });
      logger.error("Invalid event data");
      return { statusCode: 500, message: "An error occured." };
    }

    const { isValid: isPublished, validationErrors: publishingValidationErrors } =
      await eventHubClient.publishToEventHub(mandateCancelledEventData, mandateCancelledEventData.correlationId);

    logger.debug({
      message: "Result of Event publishing",
      isPublished,
      publishingValidationErrors,
    });

    if (!isPublished) {
      logger.addContext({ publishingValidationErrors });
      logger.error("Failed to publish event to event hub");
      return { statusCode: 500, message: "An error occured." };
    }

    return {
      statusCode: 200,
      message: "mandate cancelled published successfully",
    };
  }

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return { statusCode: 500, message: "Internal Server Error" };
  }

  const { data: accountDetails, error: accountDetailsError } = await bankingClient.getCreditAccount(data.accountId);
  if (accountDetailsError) {
    logger.addContext({ accountDetailsError });
    logger.error("Error fetching account details");
    return { statusCode: 500, message: "Internal Server Error" };
  }

  const oldMandateId = accountDetails.directDebitSettings.mandateID || null;

  const mandateUpsertedEventData = createEvent<MandateUpsertedEvent>(
    {
      startDate: event.acceptedAt,
      created: new Date(event.created).getTime(),
      mandateDetails: {
        accountId: data.accountId,
        customerId: event.customerId,
        mandateId: event.mandateId,
        oldMandateId,
        status: event.status,
        startDate: event.acceptedAt,
        bankDetails: {
          accountNumber: event.bankDetails.last4,
          sortCode: event.bankDetails.sortCode,
          accountName: "Direct Debit",
        },
        processorReference: event.reference,
      },
    },
    {
      eventType: "MandateUpserted",
      initiatedBy: "mandateUpdated",
    },
  );

  logger.info({ mandateUpsertedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(mandateUpsertedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(mandateUpsertedEventData, mandateUpsertedEventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }
  return { statusCode: 200, message: "mandate upsert published successfully" };
};
