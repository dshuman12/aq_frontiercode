import { beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./updateDirectDebitHosted";
import * as dbUtil from "src/utils/db";
import * as adapters from "@onmoapp/onmo-adapters";
import * as pendingMandateUtil from "src/utils/pendingMandateUtil";

vi.mock("src/utils/db");
vi.mock("@onmoapp/onmo-adapters");
vi.mock("src/utils/pendingMandateUtil");

describe("updateDirectDebitHosted", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  test("Happy Path", async () => {
    vi.mocked(dbUtil.getCustomer).mockResolvedValue({
      data: {
        customerId: "customer-id",
        mambuID: "mambu-id",
        pspCustomerId: "psp-customer-id",
        accountId: "account-id",
        address: "",
        email: "email",
      },
      error: null,
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2025-01-27",
            state: "NOT_APPLICABLE",
          },
          directDebitSettings: {
            nextDirectDebitAmount: 10,
          },
        },
      }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      createDirectDebitHosted: vi.fn().mockResolvedValue({
        url: "session-url",
      }),
    });
    vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
      data: { hasPendingMandate: false },
    });

    const res = await handler({
      body: JSON.stringify({
        successUrl: "https://example.com",
        cancelUrl: "https://example.com",
      }),
      requestContext: { authorizer: { onmouuid: "customer-id" } },
    });
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ url: "session-url" });
  });
  describe("Sad Path", () => {
    test("No ONMO UUID in authorizer", async () => {
      await expect(handler({ requestContext: { authorizer: { onmouuid: undefined } } })).rejects.toThrow(
        "Missing onmouuid from authorizer",
      );
    });
    test("Invalid request body", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "invalidUrl",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Invalid request body" });
    });
    test("Customer not found in mobile table", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({ data: null, error: "Error" });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
    test("Customer exists in mobile table but has no pspCustomerId", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: undefined,
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
    test("Pending mandate exists", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockResolvedValue({
          url: "session-url",
        }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: true },
      });
      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Cannot request a new mandate when a pending mandate exists." });
    });
    test("Cannot fetch account details", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: null,
          error: "Cannot fetch account details",
        }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockResolvedValue({
          url: "session-url",
        }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });

    test("Account is in full lock", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "FULL_LOCK",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockResolvedValue({
          url: "session-url",
        }),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(400);
      expect(res.body).toEqual({ message: "Bad Request" });
    });

    test("Error creating the hosted session", async () => {
      vi.mocked(dbUtil.getCustomer).mockResolvedValue({
        data: {
          customerId: "customer-id",
          mambuID: "mambu-id",
          pspCustomerId: "psp-customer-id",
          accountId: "account-id",
          address: "",
          email: "email",
        },
        error: null,
      });
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          data: {
            accountDetails: {
              nextStatementDueDate: "2025-01-27",
              state: "NOT_APPLICABLE",
            },
            directDebitSettings: {
              nextDirectDebitAmount: 10,
            },
          },
        }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        createDirectDebitHosted: vi.fn().mockRejectedValue("Error creating hosted session"),
      });
      vi.mocked(pendingMandateUtil.pspCustomerHasPendingMandate, { partial: true }).mockResolvedValue({
        data: { hasPendingMandate: false },
      });

      const res = await handler({
        body: JSON.stringify({
          successUrl: "https://example.com",
          cancelUrl: "https://example.com",
        }),
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(res.statusCode).toBe(500);
      expect(res.body).toEqual({ message: "Internal Server Error" });
    });
  });
});
