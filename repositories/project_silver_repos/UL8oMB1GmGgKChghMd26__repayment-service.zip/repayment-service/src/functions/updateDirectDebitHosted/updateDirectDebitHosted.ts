import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { APIGatewayEventHandler, DirectDebitError, DirectDebitHosted } from "@libs/types";
import { pspCustomerHasPendingMandate } from "src/utils/pendingMandateUtil";
import { formatErrorMessage } from "src/utils/errorUtil";

const env = process.env.ENVIRONMENT;

const validateBody = (body: string) => {
  return z
    .object({
      successUrl: z.string().refine((value) => /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value), {
        message: "Please enter a valid URL",
      }),
      cancelUrl: z
        .string()
        .refine((value) => /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value), {
          message: "Please enter a valid URL",
        })
        .optional(),
    })
    .safeParse(JSON.parse(body));
};

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "updateDirectDebitHosted" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  const body = validateBody(event.body || "");

  if (body.error || !body.data) {
    logger.error(`Invalid request body: ${body.error}`);
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Invalid request body" } });
  }

  logger.info({ body });

  const { successUrl, cancelUrl } = body.data;

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  if (!customer.pspCustomerId) {
    logger.error("pspCustomer not found. Cannot update Direct Debit.");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Error fetching repayment client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data: pendingMandate, error: pendingMandateError } = await pspCustomerHasPendingMandate(
    customer.pspCustomerId,
  );
  if (pendingMandateError) {
    logger.addContext({ errorDetails: pendingMandateError.message });
    logger.error("Error checking for pending mandate");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  // We block updates when another one was made recently and the new mandate is still pending
  if (pendingMandate.hasPendingMandate) {
    logger.error("Cannot update Direct Debit. Pending mandate found.");
    return formatJSONResponse<DirectDebitError>({
      statusCode: 500,
      body: { message: "Cannot request a new mandate when a pending mandate exists." },
    });
  }
  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.addContext({ error });
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (data.accountDetails.state === "FULL_LOCK") {
    logger.addContext({ accountDetails: data.accountDetails });
    logger.warn("Account is fully locked, blocking and returning 400");
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Bad Request" } });
  }

  try {
    const directDebitSession = await repaymentClient.createDirectDebitHosted({
      customerId,
      accountType: "card",
      pspCustomerId: customer.pspCustomerId,
      accountId: customer.accountId,
      successUrl,
      cancelUrl,
    });

    logger.info(`Direct debit session created: ${directDebitSession}`);
    return formatJSONResponse<DirectDebitHosted>({ statusCode: 200, body: { url: directDebitSession.url } });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error creating direct debit session: ${errorMessage}`);
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }
};
