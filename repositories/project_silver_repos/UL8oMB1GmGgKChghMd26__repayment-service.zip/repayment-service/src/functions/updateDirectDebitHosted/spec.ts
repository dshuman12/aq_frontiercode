import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono();

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: "Bad Request",
  }),
});

const CardOutputSchema = z.object({
  url: z.string(),
});

app.openapi(
  createRoute({
    method: "put",
    path: "/direct-debit/hosted",
    security: [
      {
        Bearer: [],
      },
    ],
    requestBody: {
      description: "The returnUrl to redirect the user to after the mandate setup is complete",
      content: {
        "application/json": {
          schema: {
            type: "object",
            properties: {
              successUrl: {
                type: "string",
                description: "The URL to redirect the user to after the mandate setup is complete",
              },
              cancelUrl: {
                type: "string",
                description: "[optional] The URL to redirect the user to after the mandate setup is canceled",
                optional: true,
              },
            },
            required: ["returnUrl"],
          },
        },
      },
    },
    responses: {
      200: {
        description: "Returns a url used to redirect to a stripe hosted direct debit setup form.",
        content: {
          "application/json": {
            schema: CardOutputSchema,
          },
        },
      },
      500: {
        content: {
          "application/json": {
            schema: ErrorSchema,
          },
        },
        description:
          "Returns an error. It will error if trying to create a direct debit when a pending mandate already exists.",
      },
    },
  }),
  (c) => {
    return c.json({
      url: "https://stripe.com/some-url",
    });
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: "Custom Message",
        },
        500,
      );
    }
  },
);

export default app;
