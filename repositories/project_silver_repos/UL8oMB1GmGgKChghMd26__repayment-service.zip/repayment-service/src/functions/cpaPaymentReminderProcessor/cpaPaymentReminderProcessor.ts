import { getLogger } from "@libs/logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, salesforceCrmAdapter } from "@onmoapp/onmo-adapters";
import {
  CORE_BANKING_ADAPTER_CLIENT_NAME,
  CRM_ADAPTER_CLIENT_NAME,
  SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_10_DAYS,
  SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_1_DAY,
} from "@libs/constants";
import { throwErrorIfAdapterResHaveError } from "src/utils/errorUtil";
import { sendMessage } from "@onmoapp/onmo-sqs";
import { SFMCCPACommsEvent } from "@shared-types/sqs-types";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

import dayjs from "dayjs";

export type CPAReminderEvent = {
  accountId: string;
  customerId: string;
  pspCustomerId: string;
  dueDate: string;
  amount: number;
  reminderType: string;
};

export const handler = async (event: CPAReminderEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "cpaPaymentReminderProcessor" });
  logger.info({ message: "CPA payment reminder event received", event });

  const { accountId, customerId, pspCustomerId, dueDate, amount, reminderType } = event;
  logger.addContext({ accountId, customerId, reminderType });

  // Fetch the current subscription amount from Stripe — the agent may have changed it
  // since the reminder schedule was created
  let currentAmount = amount;
  try {
    const repaymentClient = await CoreRepaymentsFactory.build("stripe");
    if (repaymentClient) {
      const subscriptionsResult = await repaymentClient.getSubscriptionsByPsPCustomerId(pspCustomerId);
      const activeSubscription = subscriptionsResult.subscriptions.find((sub) => sub.status === "active");
      if (activeSubscription?.amount != null) {
        logger.info({ message: "Using current subscription amount from Stripe", scheduledAmount: amount, currentAmount: activeSubscription.amount });
        currentAmount = activeSubscription.amount;
      }
    }
  } catch (error) {
    logger.warn({ message: "Failed to fetch current amount from Stripe, using scheduled amount", error });
  }

  const coreBankingClient = await coreBankingAdapter(CORE_BANKING_ADAPTER_CLIENT_NAME);
  const crmAdapter = await salesforceCrmAdapter(CRM_ADAPTER_CLIENT_NAME);

  const coreBankingCustomer = await coreBankingClient.getCustomerByCustomerId(customerId);
  throwErrorIfAdapterResHaveError(coreBankingCustomer, { message: "Failed to get core banking customer details" });

  const crmCustomerDetails = await crmAdapter.getCrmCustomerDetailsByCustomerId(customerId);
  throwErrorIfAdapterResHaveError(crmCustomerDetails, { message: "Failed to get CRM customer details" });

  const creditAccount = await coreBankingClient.getCreditAccount(accountId);
  throwErrorIfAdapterResHaveError(creditAccount, { message: "Failed to get credit account details" });

  const creative = reminderType === "1d" ? SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_1_DAY : SFMC_CPA_CREATIVE_PAYMENT_UPCOMING_10_DAYS;

  const commsEvent: SFMCCPACommsEvent = {
    creative,
    firstName: coreBankingCustomer.data.firstName.trim(),
    emailAddress: coreBankingCustomer.data.emailAddresses.primary,
    customerId,
    personContactId: crmCustomerDetails.data.contactId,
    paymentPlanDate: dayjs(dueDate).format("YYYY-MM-DD"),
    planEndDate: null,
    retryDate: null,
    paymentPlanValue: currentAmount / 100,
    arrearsBalance: creditAccount.data?.accountBalances?.arrearBalances?.total ?? null,
  };

  logger.info({ message: "Sending CPA reminder comms to SFMC SQS", commsEvent });
  const result = await sendMessage({
    MessageBody: JSON.stringify(commsEvent),
    QueueUrl: process.env.CPA_COMMS_QUEUE_URL,
  });

  logger.info({
    message: "CPA reminder comms sent to SFMC SQS",
    messageId: result.MessageId,
    creative,
    reminderType,
  });

  return formatJSONResponse({ statusCode: 200, body: { message: "CPA payment reminder processed successfully" } });
};
