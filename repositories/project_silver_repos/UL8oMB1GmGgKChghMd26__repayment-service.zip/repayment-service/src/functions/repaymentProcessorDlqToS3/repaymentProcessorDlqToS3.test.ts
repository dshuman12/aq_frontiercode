import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import { handler } from "./repaymentProcessorDlqToS3";
import * as dlqUtil from "src/utils/dlqUtil";
import { REPAYMENT_PROCESSOR_DLQ_ARCHIVE_BUCKET_FOLDER } from "@libs/constants";

vi.mock("src/utils/dlqUtil");

const originalEnv = process.env;

describe("throttlingDlqToS3", () => {
  const bucketName = "bucket-name";
  const bucketFolder = REPAYMENT_PROCESSOR_DLQ_ARCHIVE_BUCKET_FOLDER;
  const queueUrl = "queue-url";

  beforeEach(() => {
    vi.resetAllMocks();
    process.env.REPAYMENT_DLQ_ARCHIVE_S3_BUCKET = bucketName;
    process.env.REPAYMENT_PROCESSOR_DLQ_URL = queueUrl;
  });
  afterEach(() => {
    process.env = originalEnv;
  });
  test("It should upload all events to S3 bucket in the right folder", async () => {
    vi.mocked(dlqUtil.archiveAndDeleteMessage, { partial: true }).mockResolvedValue();

    const event1 = {
      messageId: "059f36b4-87a3-44ab-83d2-661975830a7d",
      body: JSON.stringify({ message: "test" }),
      attributes: {
        SentTimestamp: "2025-01-01T14:48:00.000Z",
        ApproximateReceiveCount: "1",
        ApproximateFirstReceiveTimestamp: "2025-01-01T14:48:00.000Z",
        SenderId: "123456789012",
      },
      eventSourceARN: "arn:aws:sqs:us-east-1:123456789012:MyQueue",
      receiptHandle: "receipt-handle",
      messageAttributes: {},
      md5OfBody: "",
      eventSource: "aws:sqs",
      awsRegion: "eu-west-1",
    };
    const event2 = {
      messageId: "059f36b4-87a3-44ab-83d2-661975832222",
      body: JSON.stringify({ message: "test2" }),
      attributes: {
        SentTimestamp: "2024-01-01T14:48:00.000Z",
        ApproximateReceiveCount: "1",
        ApproximateFirstReceiveTimestamp: "2024-01-01T14:48:00.000Z",
        SenderId: "123456789012",
      },
      eventSourceARN: "arn:aws:sqs:us-east-1:123456789012:MyQueue",
      receiptHandle: "receipt-handle2",
      messageAttributes: {},
      md5OfBody: "",
      eventSource: "aws:sqs",
      awsRegion: "eu-west-1",
    };
    const events = {
      Records: [event1, event2],
    };

    await handler(events);
    expect(dlqUtil.archiveAndDeleteMessage).toHaveBeenCalledTimes(2);
    expect(dlqUtil.archiveAndDeleteMessage).toHaveBeenNthCalledWith(1, {
      logger: expect.any(Object),
      record: event1,
      folder: bucketFolder,
      bucket: bucketName,
      queueUrl,
    });
    expect(dlqUtil.archiveAndDeleteMessage).toHaveBeenNthCalledWith(2, {
      logger: expect.any(Object),
      record: event2,
      folder: bucketFolder,
      bucket: bucketName,
      queueUrl,
    });
  });
});
