import { REPAYMENT_PROCESSOR_DLQ_ARCHIVE_BUCKET_FOLDER } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { SQSEvent } from "aws-lambda";
import { archiveAndDeleteMessage } from "src/utils/dlqUtil";

export const handler = async (event: SQSEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "repaymentProcessorDlqToS3" });

  const bucket = process.env.REPAYMENT_DLQ_ARCHIVE_S3_BUCKET;
  const queueUrl = process.env.REPAYMENT_PROCESSOR_DLQ_URL;
  const folder = REPAYMENT_PROCESSOR_DLQ_ARCHIVE_BUCKET_FOLDER;

  logger.info({ message: "Received event", event, bucket, folder });

  for (const record of event.Records) {
    logger.warn({ message: `Could not schedule Direct Debit. Archiving to S3.`, record });
    await archiveAndDeleteMessage({
      logger,
      record,
      folder,
      bucket,
      queueUrl,
    });
  }
};
