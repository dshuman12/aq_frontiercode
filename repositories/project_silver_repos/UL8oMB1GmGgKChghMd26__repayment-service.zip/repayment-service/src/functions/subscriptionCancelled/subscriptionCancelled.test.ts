import { test, expect, describe, vi, beforeEach } from "vitest";
import { subscriptionCancelled } from "./subscriptionCancelled";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";

vi.mock("@onmoapp/event-hub-kinesis-adapter");

const mockEventHubClient = {
  validateEvent: vi.fn(),
  publishToEventHub: vi.fn(),
};

const baseEvent = {
  type: "customer.subscription.deleted" as const,
  subscriptionId: "sub_123",
  pspCustomerId: "cus_456",
  created: 1700000000,
  status: "cancelled" as const,
  currentPeriodEnd: 1700100000,
  amount: 5000,
  cancellationReason: "cancellation_requested",
  metadata: {
    customerId: "customer_id",
    accountId: "account_id",
  },
};

describe("subscriptionCancelled tests", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(EventHubKinesisAdapter.build).mockResolvedValue(mockEventHubClient as any);
  });

  test("Happy path - CPASubscriptionCancelled event published successfully", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: true });
    mockEventHubClient.publishToEventHub.mockResolvedValue({ isValid: true, isPublished: true });

    const response = await subscriptionCancelled(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("CPASubscriptionCancelled event published successfully.");

    expect(mockEventHubClient.publishToEventHub).toHaveBeenCalled();

    const callParameter = mockEventHubClient.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "CPASubscriptionCancelled",
      initiatedBy: "subscriptionCancelled",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        pspCustomerId: "cus_456",
        subscriptionDetails: {
          subscriptionId: "sub_123",
          status: "cancelled",
          amount: 5000,
          currentPeriodEnd: 1700100000,
          cancellationReason: "cancellation_requested",
        },
        processor: "Stripe",
        processorReference: null,
      },
    });
  });

  test("Sad path - No customerId in metadata", async () => {
    const event = { ...baseEvent, metadata: { accountId: "account_id" } };

    const response = await subscriptionCancelled(event);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("customerId missing from subscription metadata");
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - No accountId in metadata", async () => {
    const event = { ...baseEvent, metadata: { customerId: "customer_id" } };

    const response = await subscriptionCancelled(event);

    expect(response.statusCode).toBe(400);
    expect(response.message).toBe("accountId missing from subscription metadata");
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - No metadata at all", async () => {
    const event = { ...baseEvent, metadata: undefined };

    const response = await subscriptionCancelled(event);

    expect(response.statusCode).toBe(400);
    expect(EventHubKinesisAdapter.build).not.toHaveBeenCalled();
  });

  test("Sad path - Event validation fails", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: false, validationErrors: ["Invalid schema"] });

    const response = await subscriptionCancelled(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("An error occured.");
    expect(mockEventHubClient.publishToEventHub).not.toHaveBeenCalled();
  });

  test("Sad path - Event publishing fails", async () => {
    mockEventHubClient.validateEvent.mockResolvedValue({ isValid: true });
    mockEventHubClient.publishToEventHub.mockResolvedValue({ isValid: false, isPublished: false });

    const response = await subscriptionCancelled(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("An error occured.");
  });

  test("Sad path - No event hub client", async () => {
    vi.mocked(EventHubKinesisAdapter.build).mockResolvedValue(null as any);

    const response = await subscriptionCancelled(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("An error occured.");
  });
});
