import { getLogger } from "@libs/logger";
import { SubscriptionDeletedEventOutcome } from "@onmoapp/onmo-types";
import { EventHubKinesisAdapter } from "@onmoapp/event-hub-kinesis-adapter";
import { AccountType, CPACancellationReason, CPASubscriptionCancelledEvent } from "@shared-types/eventHub-types";
import { createEvent } from "@libs/eventHubUtils";
import { findAndDeleteAllSchedules } from "@utils/schedulerUtil";
import { CPA_REMINDER_NAME_PREFIX } from "@libs/constants";

const getCancellationReason = (reason: string | null): CPACancellationReason => {
  switch (reason) {
    case "payment_disputed":
      return CPACancellationReason.PaymentDisputed;
    case "payment_failed":
      return CPACancellationReason.PaymentFailed;
    case "end_date_reached":
      return CPACancellationReason.EndDateReached;
    case "balance_paid":
      return CPACancellationReason.BalancePaid;
    default:
      return CPACancellationReason.CancellationRequested;
  }
};

export const subscriptionCancelled = async (
  event: SubscriptionDeletedEventOutcome,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "subscriptionCancelled" });
  logger.info(event);

  const customerId = event.metadata?.customerId;

  if (!customerId) {
    logger.error("customerId missing from subscription metadata");
    return { statusCode: 400, message: "customerId missing from subscription metadata" };
  }

  const accountId = event.metadata?.accountId;

  if (!accountId) {
    logger.error("accountId missing from subscription metadata");
    return { statusCode: 400, message: "accountId missing from subscription metadata" };
  }

  logger.addContext({
    customerId,
    accountId,
    subscriptionId: event.subscriptionId,
    pspCustomerId: event.pspCustomerId,
  });

  const eventHubClient = await EventHubKinesisAdapter.build();

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const cpaSubscriptionCancelledEvent: CPASubscriptionCancelledEvent = {
    accountId,
    accountType: AccountType.Card,
    customerId,
    pspCustomerId: event.pspCustomerId,
    subscriptionDetails: {
      subscriptionId: event.subscriptionId,
      status: event.status,
      amount: event.amount,
      currentPeriodEnd: event.currentPeriodEnd,
      cancellationReason: getCancellationReason(event.cancellationReason),
    },
    processor: "Stripe",
    processorReference: null,
  };

  const eventData = createEvent<CPASubscriptionCancelledEvent>(cpaSubscriptionCancelledEvent, {
    eventType: "CPASubscriptionCancelled",
    initiatedBy: "subscriptionCancelled",
  });

  logger.info({ eventData });

  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(eventData);

  logger.info({ message: "Result of Event validation", isEventDataValid, eventValidationErrors });

  if (!isEventDataValid) {
    logger.addContext({ eventValidationErrors });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(eventData, eventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }

  // Delete any pending CPA reminder schedules
  const groupName = process.env.CPA_REMINDER_GROUP_NAME;
  if (groupName) {
    await findAndDeleteAllSchedules({ accountId, namePrefix: CPA_REMINDER_NAME_PREFIX, groupName });
  }

  return { statusCode: 200, message: "CPASubscriptionCancelled event published successfully." };
};
