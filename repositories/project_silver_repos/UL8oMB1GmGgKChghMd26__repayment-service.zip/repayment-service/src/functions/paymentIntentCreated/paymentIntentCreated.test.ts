import { test, expect, describe, vi, beforeEach } from "vitest";
import { paymentIntentCreated } from "./paymentIntentCreated";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

vi.mock("@onmoapp/core-repayments");

const mockRepaymentClient = {
  getSubscriptionByInvoiceId: vi.fn(),
  updatePaymentIntentMetadata: vi.fn(),
};

const baseEvent = {
  type: "payment_intent.created" as const,
  paymentIntentId: "pi_123",
  invoice: "in_456",
};

describe("paymentIntentCreated", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(mockRepaymentClient as any);
  });

  test("Happy path - stamps accountId, customerId, accountType onto PI", async () => {
    mockRepaymentClient.getSubscriptionByInvoiceId.mockResolvedValue({
      subscriptionId: "sub_789",
      status: "active",
      metadata: { accountId: "ACCT123", customerId: "customer-uuid", accountType: "card" },
    });
    mockRepaymentClient.updatePaymentIntentMetadata.mockResolvedValue(undefined);

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("PI metadata stamped");
    expect(mockRepaymentClient.getSubscriptionByInvoiceId).toHaveBeenCalledWith("in_456");
    expect(mockRepaymentClient.updatePaymentIntentMetadata).toHaveBeenCalledWith("pi_123", {
      accountId: "ACCT123",
      customerId: "customer-uuid",
      accountType: "card",
    });
  });

  test("No subscription resolved from invoice - skips stamp", async () => {
    mockRepaymentClient.getSubscriptionByInvoiceId.mockResolvedValue(null);

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("No subscription for invoice — skipped");
    expect(mockRepaymentClient.updatePaymentIntentMetadata).not.toHaveBeenCalled();
  });

  test("Subscription metadata missing accountId - skips stamp", async () => {
    mockRepaymentClient.getSubscriptionByInvoiceId.mockResolvedValue({
      subscriptionId: "sub_789",
      status: "active",
      metadata: { customerId: "customer-uuid", accountType: "card" },
    });

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("Subscription metadata incomplete — skipped");
    expect(mockRepaymentClient.updatePaymentIntentMetadata).not.toHaveBeenCalled();
  });

  test("Subscription metadata missing customerId - skips stamp", async () => {
    mockRepaymentClient.getSubscriptionByInvoiceId.mockResolvedValue({
      subscriptionId: "sub_789",
      status: "active",
      metadata: { accountId: "ACCT123", accountType: "card" },
    });

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("Subscription metadata incomplete — skipped");
    expect(mockRepaymentClient.updatePaymentIntentMetadata).not.toHaveBeenCalled();
  });

  test("Subscription metadata missing accountType - skips stamp", async () => {
    mockRepaymentClient.getSubscriptionByInvoiceId.mockResolvedValue({
      subscriptionId: "sub_789",
      status: "active",
      metadata: { accountId: "ACCT123", customerId: "customer-uuid" },
    });

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(200);
    expect(response.message).toBe("Subscription metadata incomplete — skipped");
    expect(mockRepaymentClient.updatePaymentIntentMetadata).not.toHaveBeenCalled();
  });

  test("No repayment client - returns 500", async () => {
    vi.mocked(CoreRepaymentsFactory.build).mockResolvedValue(null as any);

    const response = await paymentIntentCreated(baseEvent);

    expect(response.statusCode).toBe(500);
    expect(response.message).toBe("No repayment client");
  });
});
