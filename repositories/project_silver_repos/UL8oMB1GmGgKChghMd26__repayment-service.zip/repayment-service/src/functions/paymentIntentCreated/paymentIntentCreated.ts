import { getLogger } from "@libs/logger";
import { CoreRepaymentsFactory } from "@onmoapp/core-repayments";

type PaymentIntentCreatedCPAEvent = {
  type: "payment_intent.created";
  paymentIntentId: string;
  invoice: string;
};

/**
 * Stamps subscription metadata (accountId, accountType, customerId) onto
 * a CPA-generated PaymentIntent so it lands in Stripe's payout reconciliation
 * report populated identically to one-off card/DD/PIB payments.
 *
 * Stripe does not propagate subscription metadata to the PIs it creates for
 * each recurring invoice — we stamp it here so ReconArt can auto-match.
 * The payout report reads current PI metadata at report-generation time
 * (~T+2 after charge), so we have plenty of headroom for the stamp.
 */
export const paymentIntentCreated = async (
  event: PaymentIntentCreatedCPAEvent,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({
    functionName: "paymentIntentCreated",
    paymentIntentId: event.paymentIntentId,
    invoiceId: event.invoice,
  });

  const repaymentClient = await CoreRepaymentsFactory.build("stripe");

  if (!repaymentClient) {
    logger.error("No repayment client found for stripe");
    return { statusCode: 500, message: "No repayment client" };
  }

  const subscription = await repaymentClient.getSubscriptionByInvoiceId(event.invoice);

  if (!subscription) {
    logger.warn({ message: "No subscription resolved from invoice — skipping stamp" });
    return { statusCode: 200, message: "No subscription for invoice — skipped" };
  }

  const { accountId, customerId, accountType } = subscription.metadata;

  if (!accountId || !customerId || !accountType) {
    logger.warn({
      message: "Subscription metadata missing accountId/customerId/accountType — skipping stamp",
      subscriptionId: subscription.subscriptionId,
    });
    return { statusCode: 200, message: "Subscription metadata incomplete — skipped" };
  }

  await repaymentClient.updatePaymentIntentMetadata(event.paymentIntentId, {
    accountId,
    customerId,
    accountType,
  });

  logger.info({
    message: "PI metadata stamped for CPA reconciliation",
    subscriptionId: subscription.subscriptionId,
    accountId,
  });

  return { statusCode: 200, message: "PI metadata stamped" };
};
