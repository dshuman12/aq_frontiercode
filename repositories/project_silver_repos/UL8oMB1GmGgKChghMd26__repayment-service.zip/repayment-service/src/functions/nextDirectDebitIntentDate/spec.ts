import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono();

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: "Bad Request",
  }),
});

const NextDirectDebitIntentDateOutcome = z.object({
  nextDirectDebitIntentDate: z.string(),
});

app.openapi(
  createRoute({
    method: "get",
    path: "/direct-debit/next-payment-intent-date",
    security: [
      {
        Bearer: [],
      },
    ],
    responses: {
      200: {
        description: "Returns",
        content: {
          "application/json": {
            schema: NextDirectDebitIntentDateOutcome,
          },
        },
      },
      500: {
        content: {
          "application/json": {
            schema: ErrorSchema,
          },
        },
        description: "Returns an error",
      },
    },
  }),
  (c) => {
    return c.json({
      nextDirectDebitIntentDate: '"2025-01-03T02:00:00.000Z"',
    });
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: "Custom Message",
        },
        500,
      );
    }
  },
);

export default app;
