import { formatJSONResponse } from "@libs/gatewayUtils";
import { APIGatewayEventHandler, DirectDebitError } from "@libs/types";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { getPaymentRequestDate } from "@utils/directDebitUtil";
import { getCustomer } from "src/utils/db";

const env = process.env.ENVIRONMENT;

export type DirectDebitIntentOutcome = {
  nextDirectDebitIntentDate: string;
};

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "nextDirectDebitIntentDate" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    logger.info("Missing onmouuid from authorizer.");
    return formatJSONResponse<DirectDebitError>({ statusCode: 401, body: { message: "Unauthorized." } });
  }

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!customer.accountId || !customer.mambuID) {
    logger.error("Customer account details missing");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!data.directDebitSettings.nextDirectDebitAmount) {
    // No new schedule so nothing is owed, no date to return
    return formatJSONResponse<DirectDebitIntentOutcome>({ statusCode: 200, body: { nextDirectDebitIntentDate: null } });
  }
  const paymentDate = data.accountDetails.nextStatementDueDate;
  const nextDirectDebitIntentDate = getPaymentRequestDate(paymentDate);

  return formatJSONResponse<DirectDebitIntentOutcome>({ statusCode: 200, body: { nextDirectDebitIntentDate } });
};
