import { beforeEach, describe, expect, test, vi } from "vitest";
import { DirectDebitIntentOutcome, handler } from "./nextDirectDebitIntentDate";
import * as adapters from "@onmoapp/onmo-adapters";
import * as db from "src/utils/db";

vi.mock("@onmoapp/onmo-adapters");
vi.mock("src/utils/db");

describe("nextDirectDebitIntentDate", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });
  test("Happy Path - Schedule exists -  it should return a date that is 2 working days before next statement date", async () => {
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2025-01-27",
          },
          directDebitSettings: {
            nextDirectDebitAmount: 10,
          },
        },
      }),
    });
    vi.mocked(db, { partial: true }).getCustomer.mockResolvedValue({
      data: {
        accountId: "account-id",
        mambuID: "mambu-id",
        customerId: "customer-id",
        address: "",
        email: "",
        pspCustomerId: "psp-customer-id",
      },
    });

    const result = await handler({
      requestContext: { authorizer: { onmouuid: "customer-id" } },
    });
    expect(result.statusCode).toBe(200);
    const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
    expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledWith("account-id");

    const body = result.body as DirectDebitIntentOutcome;
    expect(body.nextDirectDebitIntentDate).toBe("2025-01-23T00:00:00.000Z");
  });
  test("Happy Path - No schedule yet - it should return null", async () => {
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2025-01-27",
          },
          directDebitSettings: {
            nextDirectDebitAmount: null, // this happens when the current date is between lastDueDate and billing date
          },
        },
      }),
    });
    vi.mocked(db, { partial: true }).getCustomer.mockResolvedValue({
      data: {
        accountId: "account-id",
        mambuID: "mambu-id",
        customerId: "customer-id",
        address: "",
        email: "",
        pspCustomerId: "psp-customer-id",
      },
    });

    const result = await handler({
      requestContext: { authorizer: { onmouuid: "customer-id" } },
    });
    expect(result.statusCode).toBe(200);
    const coreBankingAdapterMock = await vi.mocked(adapters).coreBankingAdapter.mock.results[0].value;
    expect(coreBankingAdapterMock.getCreditAccount).toHaveBeenCalledWith("account-id");

    const body = result.body as DirectDebitIntentOutcome;
    expect(body.nextDirectDebitIntentDate).toBeNull();
  });
  describe("Sad Path", () => {
    test("No auth token - it should error", async () => {
      const result = await handler({
        requestContext: { authorizer: { onmouuid: "" } },
      });
      expect(result.statusCode).toBe(401);
    });
    test("No customer found in db - it should error", async () => {
      vi.mocked(db, { partial: true }).getCustomer.mockResolvedValue({
        error: "Could not find customer",
      });
      const result = await handler({
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(result.statusCode).toBe(500);
    });
    test("Error creating coreBanking client - it should error", async () => {
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue(null);
      vi.mocked(db, { partial: true }).getCustomer.mockResolvedValue({
        data: {
          accountId: "account-id",
          mambuID: "mambu-id",
          customerId: "customer-id",
          address: "",
          email: "",
          pspCustomerId: "psp-customer-id",
        },
      });
      const result = await handler({
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(result.statusCode).toBe(500);
    });
    test("Error getting account details - it should error", async () => {
      vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
        getCreditAccount: vi.fn().mockResolvedValue({
          error: "An error ocurred",
        }),
      });
      vi.mocked(db, { partial: true }).getCustomer.mockResolvedValue({
        data: {
          accountId: "account-id",
          mambuID: "mambu-id",
          customerId: "customer-id",
          address: "",
          email: "",
          pspCustomerId: "psp-customer-id",
        },
      });

      const result = await handler({
        requestContext: { authorizer: { onmouuid: "customer-id" } },
      });
      expect(result.statusCode).toBe(500);
    });
  });
});
