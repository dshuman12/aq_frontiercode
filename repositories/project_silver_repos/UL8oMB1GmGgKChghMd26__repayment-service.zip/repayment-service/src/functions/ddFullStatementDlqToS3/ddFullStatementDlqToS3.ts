import { DD_FULL_STATEMENT_CHECK_DLQ_ARCHIVE_BUCKET_FOLDER } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { SQSEvent } from "aws-lambda";
import { archiveAndDeleteMessage } from "src/utils/dlqUtil";

export const handler = async (event: SQSEvent) => {
  const logger = getLogger();
  logger.addContext({ functionName: "ddFullStatementDlqToS3" });
  logger.info({ message: "Received event", event });

  const bucket = process.env.REPAYMENT_DLQ_ARCHIVE_S3_BUCKET;
  const queueUrl = process.env.DD_FULL_STATEMENT_CHECK_DLQ_URL;

  for (const record of event.Records) {
    await archiveAndDeleteMessage({
      logger,
      record,
      folder: DD_FULL_STATEMENT_CHECK_DLQ_ARCHIVE_BUCKET_FOLDER,
      bucket,
      queueUrl,
    });
  }
};
