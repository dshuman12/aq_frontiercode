import { CheckUserPreference } from "@functions/ddFullStatementScheduler/ddFullStatementScheduler";
import { getLogger } from "@libs/logger";
import { coreBankingAdapter } from "@onmoapp/onmo-adapters";
import { Logger } from "@onmoapp/onmo-logger";
import { sendMessage } from "@onmoapp/onmo-sqs";
import dayjs from "dayjs";
import { formatErrorMessage } from "src/utils/errorUtil";

const sendMessageToQueue = async (sqsMessage: CheckUserPreference, logger: Logger) => {
  logger.info({
    message: "Sending message to SQS",
    sqsMessage,
    queue: process.env.DD_FULL_STATEMENT_CHECK_QUEUE_URL,
  });
  try {
    const result = await sendMessage({
      MessageBody: JSON.stringify(sqsMessage),
      QueueUrl: process.env.DD_FULL_STATEMENT_CHECK_QUEUE_URL,
    });

    logger.info({
      message: "Message sent to SQS",
      messageId: result.MessageId,
      sequenceNumber: result.SequenceNumber,
    });
  } catch (e) {
    logger.error({ message: "Error sending message to SQS", error: formatErrorMessage(e) });
  }
};

export const handler = async () => {
  const logger = getLogger();
  logger.addContext({ functionName: "ddSearchPaidInstalments" });

  const dueDate = dayjs().add(8, "day").toISOString();
  logger.addContext({ dueDate });

  const coreBankingClient = await coreBankingAdapter("MAMBU_CLIENT");
  const res = await coreBankingClient.searchInstalments({
    dueFrom: dueDate,
    dueTo: dueDate,
    instalmentState: "PAID",
    limit: 1000,
  });

  if (res.error) {
    logger.error({ message: "Error searching instalments", error: res.error });
    return;
  }

  const sendMessagePromises = res.data.instalments
    .map(
      (instalment) =>
        ({
          parentAccountKey: instalment.parentAccountKey,
        }) as CheckUserPreference,
    )
    .map((cup) => sendMessageToQueue(cup, logger));

  try {
    await Promise.all(sendMessagePromises);
  } catch (e) {
    logger.error({ message: "Error sending messages to SQS", error: formatErrorMessage(e) });
  }
};
