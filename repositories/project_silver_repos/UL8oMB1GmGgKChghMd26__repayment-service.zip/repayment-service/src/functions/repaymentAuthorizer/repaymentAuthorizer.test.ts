import { handler } from "./repaymentAuthorizer";
import * as secretManager from "@onmoapp/onmo-secrets-manager";
import { beforeEach } from "node:test";
import { test, describe, vi, expect } from "vitest";

vi.mock("@onmoapp/onmo-secrets-manager");

describe("repaymentAuthorizer", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  const repaymentSecret = JSON.stringify({ authorizerApiKey: "valid-key" });

  test("Happy Path - it should allow the request", async () => {
    vi.mocked(secretManager.getSecret, { partial: true }).mockResolvedValue({ SecretString: repaymentSecret });
    const result = await handler({
      queryStringParameters: { onmokey: "valid-key" },
      methodArn: "arn",
    });
    expect(result.policyDocument.Statement[0].Effect).toBe("Allow");
  });

  describe("Sad Path", () => {
    const invalidRepaymentSecret = JSON.stringify({ someOtherKey: "value" });

    test("it should deny the request if the repayment secrets string is undefined", async () => {
      vi.mocked(secretManager.getSecret, { partial: true }).mockResolvedValue({ SecretString: undefined });
      const result = await handler({
        queryStringParameters: { onmokey: "valid-key" },
        methodArn: "arn",
      });
      expect(result.policyDocument.Statement[0].Effect).toBe("Deny");
    });
    test("it should deny the request if the repayment authorizer API key is undefined", async () => {
      vi.mocked(secretManager.getSecret, { partial: true }).mockResolvedValue({ SecretString: invalidRepaymentSecret });
      const result = await handler({
        queryStringParameters: { onmokey: "valid-key" },
        methodArn: "arn",
      });
      expect(result.policyDocument.Statement[0].Effect).toBe("Deny");
    });
    test("it should deny the request if the authorization token does not match the repayment authorizer API key", async () => {
      vi.mocked(secretManager.getSecret, { partial: true }).mockResolvedValue({ SecretString: repaymentSecret });
      const result = await handler({
        queryStringParameters: { onmokey: "invalid-key" },
        methodArn: "arn",
      });
      expect(result.policyDocument.Statement[0].Effect).toBe("Deny");
    });
  });
});
