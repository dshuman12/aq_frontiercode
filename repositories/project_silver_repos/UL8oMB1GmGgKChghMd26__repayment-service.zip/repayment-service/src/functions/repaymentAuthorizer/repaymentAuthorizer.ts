import { getLogger } from "@libs/logger";
import { getSecret } from "@onmoapp/onmo-secrets-manager";
import { ONMO_REPAYMENT_SECRET_PREFIX } from "@libs/constants";

type HandlerEvent = { queryStringParameters: { onmokey: string }; methodArn: string };

export const handler = async (event: HandlerEvent) => {
  const logger = getLogger();
  const {
    queryStringParameters: { onmokey },
    methodArn,
  } = event;

  const authorizeResponse = (Effect: "Allow" | "Deny") => {
    return {
      principalId: "user",
      policyDocument: {
        Version: "2012-10-17",
        Statement: [{ Effect, Action: "execute-api:Invoke", Resource: methodArn }],
      },
    };
  };

  try {
    const { SecretString: repaymentSecretString } = await getSecret(
      `${ONMO_REPAYMENT_SECRET_PREFIX}${process.env.ENVIRONMENT}`,
    );
    if (!repaymentSecretString) {
      throw new Error("Repayment secrets string is undefined");
    }

    const { authorizerApiKey } = JSON.parse(repaymentSecretString);
    if (!authorizerApiKey) {
      throw new Error("Repayment authorizer API key is undefined");
    }

    if (onmokey !== authorizerApiKey) {
      throw new Error("Authorization token does not match repayment authorizer API key");
    }

    return authorizeResponse("Allow");
  } catch (error: any) {
    logger.error(`Something went wrong: ${error?.message || error}`);

    return authorizeResponse("Deny");
  }
};

export default handler;
