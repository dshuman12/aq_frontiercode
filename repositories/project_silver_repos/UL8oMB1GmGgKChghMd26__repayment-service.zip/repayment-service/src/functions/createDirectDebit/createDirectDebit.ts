import { Logger } from "@onmoapp/onmo-logger";
import { formatJSONResponse } from "@libs/gatewayUtils";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { getCustomer, updateCustomer } from "src/utils/db";
import { OnmoError, ErrorNamesEnum } from "@onmoapp/onmo-error-types";
import { z } from "zod";
import { APIGatewayEventHandler, DirectDebit, DirectDebitError } from "@libs/types";
import { createPspCustomer } from "src/utils/createPspCustomer";
import { formatErrorMessage } from "src/utils/errorUtil";

const env = process.env.ENVIRONMENT;

// According to UX requirements, an ammount should be provided
// at time of DirectDebit creation, even though it's not
// strictly necessary to establish the direct debit.
// In the future, there may be more validation necessary, or
// amount is not required at all.
const validateBody = (body: string) => {
  return z
    .object({
      returnUrl: z.string().refine((value) => /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value), {
        message: "Please enter a valid URL",
      }),
    })
    .safeParse(JSON.parse(body));
};

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = new Logger({ env });
  logger.addContext({ functionName: "createDirectDebit" });
  logger.info(event);
  const { onmouuid: customerId } = event?.requestContext?.authorizer;

  if (!customerId) {
    throw new OnmoError({
      name: ErrorNamesEnum.NOT_FOUND_ERROR,
      message: "Missing onmouuid from authorizer",
    });
  }

  const body = validateBody(event.body || "");

  if (body.error || !body.data) {
    logger.error("Invalid request body");
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Invalid request body" } });
  }

  const { returnUrl } = body.data;

  const { data: customer, error: customerError } = await getCustomer(customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!customer.accountId || !customer.mambuID) {
    logger.error("Customer account details missing");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  logger.addContext({ customerId: customer.customerId, mambuID: customer.mambuID });

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const { data, error } = await bankingClient.getCreditAccount(customer.accountId);

  if (error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  const customerInformation = await bankingClient.getCustomerByCoreBankingCustomerId(customer.mambuID);

  if (customerInformation.error) {
    logger.error("Error fetching account details");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (data.accountDetails.state === "FULL_LOCK") {
    logger.warn("Account is fully locked, returning 400");
    return formatJSONResponse<DirectDebitError>({ statusCode: 400, body: { message: "Bad Request" } });
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Error fetching repayment client");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  let updatedCustomer;
  if (!customer.pspCustomerId) {
    logger.info("Customer created");

    const { data: pspUser, error } = await createPspCustomer({
      repaymentClient,
      customer,
      customerData: customerInformation.data,
    });
    if (error) {
      logger.error("Error creating customer");
      return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    updatedCustomer = await updateCustomer(customer.customerId, pspUser.pspCustomerId);

    if (updatedCustomer.error) {
      logger.error("Error updating customer details");
      return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
    }
    logger.info("Customer updated with pspCustomerId");
  }

  let directDebitSession;
  try {
    directDebitSession = await repaymentClient.createDirectDebit({
      customerId,
      accountType: "card",
      pspCustomerId: customer.pspCustomerId || updatedCustomer.data.pspCustomerId,
      accountId: customer.accountId,
      returnUrl: returnUrl,
    });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error creating direct debit session: ${errorMessage}`);
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  if (!directDebitSession) {
    logger.error("Error creating direct debit session");
    return formatJSONResponse<DirectDebitError>({ statusCode: 500, body: { message: "Internal Server Error" } });
  }

  return formatJSONResponse<DirectDebit>({ statusCode: 200, body: { paymentSecret: directDebitSession.clientSecret } });
};
