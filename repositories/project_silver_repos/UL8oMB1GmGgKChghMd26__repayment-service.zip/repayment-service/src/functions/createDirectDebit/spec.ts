import { handler } from './createDirectDebit'
import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

export const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: 'Bad Request',
  }),
})


const CardOutputSchema = z.object({
  paymentSecret: z.string(),
})

app.openapi(
  createRoute({
    method: 'post',
    path: '/direct-debit',
    security: [
      {
        Bearer: []
      }
    ],
    requestBody: {
      description: 'The returnUrl to redirect the user to after the payment is complete',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              returnUrl: {
                type: 'string',
                example: 'https://example.com/success',
              },
            },
            required: ['returnUrl'],
          }
        }
      }
    },
    responses: {
      200: {
        description: 'returns a payment secret used to create a session with the payment provider, or a message if an error occurred',
        content: {
          'application/json': {
            schema: CardOutputSchema
          }
        }
      },
      500: {
        content: {
          'application/json': {
            schema: ErrorSchema,
          },
        },
        description: 'Returns an error',
      },
    }
  }),
  (c) => {
    return c.json({
      paymentSecret: 'pmi_1234',
    })
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: 'Custom Message',
        },
        500
      )
    }
  }
)

export default app
