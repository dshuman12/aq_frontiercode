import { getLogger } from "@libs/logger";
import { eventHubAdapter } from "@onmoapp/onmo-adapters";

export const handler = async (eventToPublish: any) => {
  const logger = getLogger();
  logger.addContext({ functionName: "ddRetryProdWait" });
  logger.info({ message: "Received event", eventToPublish });

  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(eventToPublish);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    throw new Error("An error occured.");
  }

  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(eventToPublish, eventToPublish.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    throw new Error("An error occured.");
  }

  logger.info({ message: "Event published successfully.", eventToPublish });
};
