import { getLogger } from "@libs/logger";
import { APIGatewayEventHandler, MambuWebhookEvent } from "@libs/types";
import { DirectDebitRepaymentDue } from "@shared-types/sqs-types";
import { sendMessage } from "@onmoapp/onmo-sqs";
import dayjs from "dayjs";

export const handler = async (event: APIGatewayEventHandler) => {
  const logger = getLogger();
  logger.addContext({ functionName: "directDebitRepaymentDue" });
  logger.info({ message: "Received event", event });

  const mambuEvent = JSON.parse(event.body) as MambuWebhookEvent;

  const directDebitRepaymentDue = {
    accountId: mambuEvent.loan_account_id,
    customerId: mambuEvent.onmouuid,
    dueDate: dayjs(mambuEvent.payment_date).toISOString(),
    webhookDetails: mambuEvent,
  } as DirectDebitRepaymentDue;

  logger.info({ message: "Sending message to SQS", directDebitRepaymentDue });
  const result = await sendMessage({
    MessageBody: JSON.stringify(directDebitRepaymentDue),
    QueueUrl: process.env.REPAYMENT_DUE_THROTTLING_QUEUE_URL,
  });

  logger.info({ message: "Message sent to SQS", messageId: result.MessageId, sequenceNumber: result.SequenceNumber });
};
