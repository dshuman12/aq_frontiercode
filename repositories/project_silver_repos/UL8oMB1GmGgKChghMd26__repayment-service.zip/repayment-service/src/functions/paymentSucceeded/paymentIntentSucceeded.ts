import { createEvent } from "@libs/eventHubUtils";
import { getLogger } from "@libs/logger";
import { RepaymentType } from "@libs/types";
import { coreBankingAdapter, coreRepaymentsAdapter, eventHubAdapter, StripeClient } from "@onmoapp/onmo-adapters";
import { PaymentIntentSucceededEventOutcome } from "@onmoapp/onmo-types";
import { AccountType, RepaymentCollectedEvent } from "@shared-types/eventHub-types";
import { addWorkingDays } from "@utils/dateUtils";
import { createProdWaitSchedule } from "@utils/schedulerUtil";
import dayjs from "dayjs";
import { getCustomer } from "src/utils/db";
import { determineRepaymentType } from "src/utils/utils";

export const paymentIntentSucceeded = async (
  event: PaymentIntentSucceededEventOutcome,
): Promise<{ message: string; statusCode: number }> => {
  const logger = getLogger();
  logger.addContext({ functionName: "paymentIntentSucceeded" });
  logger.info(event);

  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  if (!repaymentClient) {
    logger.error("No repayment client found for STRIPE_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  let repaymentType: RepaymentType;
  if (event.metadata.repaymentType) {
    repaymentType = event.metadata.repaymentType as RepaymentType;
    logger.info(`Repayment type found in metadata, ${repaymentType}`);
  } else {
    /* 
      to remain backwards compatible with any intents already created when we launch this that don't have repaymentType in metadata
      will only be card or initial DD's, all retries will have repaymentType in metadata can remove after dd retries live for a few weeks 
    */
    /*
      This is now used for intents created via PaymentLinks. PaymentLinks now allow paying by card or pay by bank. repaymentType is not 
      set in metadata for intents created by PaymentLinks, so we need to determine the repayment type from the payment intent.
    */
    logger.info(`Repayment type not found in metadata as intent must have been created pre direct debit go live or this is a PaymentLink`);

    const paymentIntentDetails = await repaymentClient.getPaymentIntent(event.paymentIntentId);
    repaymentType = determineRepaymentType(paymentIntentDetails.type);
    logger.info(`Repayment type found from payment intent, ${repaymentType}`);
  }

  const mandate =
    repaymentType === RepaymentType.DirectDebit || repaymentType === RepaymentType.DirectDebitRetry
      ? await repaymentClient.getMandateIdBySucceededPaymentIntent(event.paymentIntentId)
      : null;

  const msg = mandate
    ? `Mandate found since type was ${repaymentType}, ${mandate.mandateId}`
    : `No mandate found since type was ${repaymentType}`;
  logger.info(msg);

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("No banking client found for MAMBU_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  const { data: customer, error: customerError } = await getCustomer(event.metadata.customerId);

  if (customerError || !customer) {
    logger.error("Error fetching customer");
    return { statusCode: 500, message: "An error occured." };
  }

  const { data: creditAccount, error: creditAccountError } = await bankingClient.getCreditAccount(customer.accountId);

  if (creditAccountError || !creditAccount) {
    logger.error("Error fetching credit account");
    return { statusCode: 500, message: "An error occured." };
  }

  const dateFundsLeftCustomersAccount =
    repaymentType === RepaymentType.DirectDebit
      ? new Date(creditAccount.accountDetails.nextStatementDueDate).toISOString() //for intial dd its the statement due date
      : repaymentType === RepaymentType.DirectDebitRetry
        ? addWorkingDays(dayjs.unix(event.created).toISOString(), 2) //for dd retries its the intent confirmation date + 2 working days
        : new Date().toISOString(); //for card payments its today

  const repaymentCollectedEvent = {
    accountId: event.metadata.accountId,
    accountType: AccountType.Card,
    customerId: event.metadata.customerId,
    date: dateFundsLeftCustomersAccount,
    processor: "Stripe",
    repayment: {
      amount: event.amount, // Amount in cents
      paymentMethod: repaymentType,
      externalId: event.paymentIntentId,
      mandateId: mandate?.mandateId || null,
    },
  } as RepaymentCollectedEvent;
  const repaymentCollectedEventData = createEvent<RepaymentCollectedEvent>(
    repaymentCollectedEvent,
    {
      eventType: "RepaymentCollected",
      subType: repaymentType,
      initiatedBy: "paymentIntentSucceeded",
    },
    event.metadata.idempotencyKey,
  );

  logger.info({ repaymentCollectedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(repaymentCollectedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  if (process.env.ENVIRONMENT === "staging" && (repaymentType === RepaymentType.DirectDebit ||repaymentType === RepaymentType.DirectDebitRetry)) {
    const secrets = await StripeClient.retrieveSecrets(process.env.ENVIRONMENT);
    if (
      secrets.ddRetryProdWait ||
      secrets.ddRetryAlwaysProdWaitAccounts.includes(repaymentCollectedEventData.eventData.accountId)
    ) {
      logger.info({ message: `Account set up for waiting 2 working days before receiving the event. Scheduling now.` });

      await createProdWaitSchedule({ event: repaymentCollectedEventData });
      return { statusCode: 200, message: "Waiting 2 working days before firing event." };
    }
  }

  // sending event to event hub
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(repaymentCollectedEventData, repaymentCollectedEventData.correlationId);

  logger.info({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }
  return { statusCode: 200, message: "RepaymentCollected event published successfully." };
};
