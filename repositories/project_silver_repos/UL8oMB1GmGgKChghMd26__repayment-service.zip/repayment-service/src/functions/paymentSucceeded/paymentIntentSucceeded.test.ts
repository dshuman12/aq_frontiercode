import { test, expect, describe, vi, beforeEach } from "vitest";
import { paymentIntentSucceeded } from "./paymentIntentSucceeded";
import * as adapters from "@onmoapp/onmo-adapters";
import { getCustomer } from "src/utils/db";

vi.mock("@onmoapp/onmo-adapters");
vi.mock("src/utils/db");

const testData = require("./testData.json");

describe("paymentIntentSucceeded tests", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });
  test("Happy path - Card repayment", async () => {
    vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
      publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
      validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntent: vi.fn().mockResolvedValue({
        type: "card",
      }),
      getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
        mandateId: "mandate-id",
        status: "active",
        reference: "ref",
        mandateUrl: "mandate-url",
        revocationReason: null,
      }),
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2023-09-01T00:00:00.000Z",
          },
        },
      }),
    });
    vi.mocked(getCustomer, { partial: true }).mockResolvedValue({
      data: {
        customerId: "customer_id",
        mambuID: "mambu_id",
        address: "address",
        email: "email",
        accountId: "account_id",
      },
    });
    (
      adapters.StripeClient as unknown as {
        retrieveSecrets: ReturnType<typeof vi.fn>;
      }
    ).retrieveSecrets = vi.fn().mockResolvedValue({
      ddRetryProdWait: false,
      ddRetryAlwaysProdWaitAccounts: [],
    });
    const event = testData.paymentIntentSucceededEvent;
    const response = await paymentIntentSucceeded(event);

    expect(response.statusCode).toBe(200);

    const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
    expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

    const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "RepaymentCollected",
      subtype: "CARD",
      initiatedBy: "paymentIntentSucceeded",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        processor: "Stripe",
        repayment: {
          amount: 1050,
          paymentMethod: "CARD",
          externalId: "payment_intent_id",
          mandateId: null,
        },
      },
    });
    const repaymentAdapter = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentAdapter.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();
  });
  test("Happy path - Card - Reuse idempotency key from metadata if exists", async () => {
    vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
      publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
      validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntent: vi.fn().mockResolvedValue({
        type: "card",
      }),
      getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
        mandateId: "mandate-id",
        status: "active",
        reference: "ref",
        mandateUrl: "mandate-url",
        revocationReason: null,
      }),
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2023-09-01T00:00:00.000Z",
          },
        },
      }),
    });
    (
      adapters.StripeClient as unknown as {
        retrieveSecrets: ReturnType<typeof vi.fn>;
      }
    ).retrieveSecrets = vi.fn().mockResolvedValue({
      ddRetryProdWait: false,
      ddRetryAlwaysProdWaitAccounts: [],
    });
    vi.mocked(getCustomer, { partial: true }).mockResolvedValue({
      data: {
        customerId: "customer_id",
        mambuID: "mambu_id",
        address: "address",
        email: "email",
        accountId: "account_id",
      },
    });
    const event = testData.paymentIntentSucceededEventWithKey;
    const response = await paymentIntentSucceeded(event);

    expect(response.statusCode).toBe(200);

    const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
    expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

    const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "RepaymentCollected",
      idempotencyKey: "idempotency_key",
      subtype: "CARD",
      initiatedBy: "paymentIntentSucceeded",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        processor: "Stripe",
        repayment: {
          amount: 1050,
          paymentMethod: "CARD",
          externalId: "payment_intent_id",
          mandateId: null,
        },
      },
    });
    const repaymentAdapter = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentAdapter.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();
  });
  test("Happy path - Direct Debit repayment", async () => {
    vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
      publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
      validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
    });
    (
      adapters.StripeClient as unknown as {
        retrieveSecrets: ReturnType<typeof vi.fn>;
      }
    ).retrieveSecrets = vi.fn().mockResolvedValue({
      ddRetryProdWait: false,
      ddRetryAlwaysProdWaitAccounts: [],
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntent: vi.fn().mockResolvedValue({
        type: "bacs_debit",
      }),
      getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
        mandateId: "mandate-id",
        status: "active",
        reference: "ref",
        mandateUrl: "mandate-url",
        revocationReason: null,
      }),
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2023-09-01T00:00:00.000Z",
          },
        },
      }),
    });
    vi.mocked(getCustomer, { partial: true }).mockResolvedValue({
      data: {
        customerId: "customer_id",
        mambuID: "mambu_id",
        address: "address",
        email: "email",
        accountId: "account_id",
      },
    });
    const event = testData.paymentIntentSucceededEvent;
    const response = await paymentIntentSucceeded(event);

    expect(response.statusCode).toBe(200);

    const repaymentAdapter = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentAdapter.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();
    const getMandateCallParameter = repaymentAdapter.getMandateIdBySucceededPaymentIntent.mock.calls[0][0];
    expect(getMandateCallParameter).toBe("payment_intent_id");

    const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
    expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

    const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "RepaymentCollected",
      subtype: "DIRECT_DEBIT",
      initiatedBy: "paymentIntentSucceeded",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        processor: "Stripe",
        repayment: {
          amount: 1050,
          paymentMethod: "DIRECT_DEBIT",
          externalId: "payment_intent_id",
          mandateId: "mandate-id",
        },
      },
    });
  });
  test("Happy path - PaymentLink repayment", async () => {
    vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
      publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
      validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
    });
    vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
      getPaymentIntent: vi.fn().mockResolvedValue({
        type: "pay_by_bank",
      }),
      getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
        mandateId: "mandate-id",
        status: "active",
        reference: "ref",
        mandateUrl: "mandate-url",
        revocationReason: null,
      }),
    });
    vi.mocked(adapters.coreBankingAdapter, { partial: true }).mockResolvedValue({
      getCreditAccount: vi.fn().mockResolvedValue({
        data: {
          accountDetails: {
            nextStatementDueDate: "2023-09-01T00:00:00.000Z",
          },
        },
      }),
    });
    vi.mocked(getCustomer, { partial: true }).mockResolvedValue({
      data: {
        customerId: "customer_id",
        mambuID: "mambu_id",
        address: "address",
        email: "email",
        accountId: "account_id",
      },
    });
    (
      adapters.StripeClient as unknown as {
        retrieveSecrets: ReturnType<typeof vi.fn>;
      }
    ).retrieveSecrets = vi.fn().mockResolvedValue({
      ddRetryProdWait: false,
      ddRetryAlwaysProdWaitAccounts: [],
    });
    const event = testData.paymentIntentSucceededEvent;
    const response = await paymentIntentSucceeded(event);

    expect(response.statusCode).toBe(200);

    const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
    expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

    const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
    expect(callParameter).toMatchObject({
      event: "RepaymentCollected",
      subtype: "PAY_BY_BANK",
      initiatedBy: "paymentIntentSucceeded",
      eventData: {
        accountId: "account_id",
        accountType: "CARD",
        customerId: "customer_id",
        processor: "Stripe",
        repayment: {
          amount: 1050,
          paymentMethod: "PAY_BY_BANK",
          externalId: "payment_intent_id",
          mandateId: null,
        },
      },
    });
    const repaymentAdapter = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
    expect(repaymentAdapter.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();
  });
});
