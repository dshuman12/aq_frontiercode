
import { createRoute, OpenAPIHono } from "@hono/zod-openapi";
import { z } from "zod";

const app = new OpenAPIHono()

const ErrorSchema = z.object({
  code: z.number().openapi({
    example: 400,
  }),
  message: z.string().openapi({
    example: 'Bad Request',
  }),
})

const CardsSchema = z.object({
  id: z
    .string()
    .min(3)
    .openapi({
      param: {
        name: 'id',
        in: 'path',
      },
      example: 'pmi_1234',
    }),
})

app.openapi(
  createRoute({
    method: 'delete',
    path: '/mandate/{id}',
    request: {
      params: CardsSchema
    },
    security: [
      {
        Bearer: []
      }
    ],
    responses: {
      200: {
        description: 'returns a message to confirm the deletion',
        content: {
          'application/json': {
            schema: z.object({
              message: z.string()
            })
          }
        }
      },
      500: {
        content: {
          'application/json': {
            schema: ErrorSchema,
          },
        },
        description: 'Returns an error',
      },
    }
  }),
  (c) => {
    return c.json({
      message: 'mandate deleted'
    })
  },
  (result, c) => {
    if (!result.success) {
      return c.json(
        {
          code: 500,
          message: 'Custom Message',
        },
        500
      )
    }
  }
)

export default app
