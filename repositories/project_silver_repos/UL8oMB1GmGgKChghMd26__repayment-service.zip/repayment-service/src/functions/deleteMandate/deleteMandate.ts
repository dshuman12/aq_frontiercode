import { BASE_PATH } from "@libs/constants";
import { getLogger } from "@libs/logger";
import { RequestContextBindings } from "@libs/types";
import { coreBankingAdapter, coreRepaymentsAdapter } from "@onmoapp/onmo-adapters";
import { Hono } from "hono";
import { handle } from "hono/aws-lambda";
import { formatErrorMessage } from "src/utils/errorUtil";

const app = new Hono<{ Bindings: RequestContextBindings }>().basePath(`/${BASE_PATH}/*`);

export const deleteHandler = app.delete("/mandate/:mandateId", async (c) => {
  const logger = getLogger();

  logger.info("Deleting mandate:");
  logger.info(c.env.event);
  const { onmouuid: customerId } = c.env.event.requestContext.authorizer;

  const mandateId = c.req.param("mandateId");

  logger.addContext({ customerId, mandateId, functionName: "deleteMandate" });

  if (!customerId) {
    logger.error("Customer ID missing");
    return c.json({ message: "Customer ID missing" }, 400);
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");

  if (!repaymentClient) {
    logger.error("Repayment client not found");
    return c.json({ message: "Repayment client not found" }, 500);
  }

  const bankingClient = await coreBankingAdapter("MAMBU_CLIENT");

  if (!bankingClient) {
    logger.error("Error fetching banking client");
    return { statusCode: 500, message: "Internal Server Error" };
  }

  const { data: accountDetails, error } = await bankingClient.getCreditAccount(customerId);
  if (error) {
    logger.error(error);
    return c.json({ message: "Error fetching account details" }, 500);
  }

  if (accountDetails.directDebitSettings.mandateID !== mandateId) {
    logger.error("Mandate ID does not match");
    return c.json({ message: "Mandate ID does not match loan account" }, 500);
  }

  // check if scheduledAmount is truthy, if it is, return 400
  if (accountDetails.directDebitSettings.scheduledDirectDebitAmount) {
    logger.error("Scheduled amount is not empty");
    return c.json({ message: "payment is pending" }, 400);
  }

  try {
    const paymentMethod = await repaymentClient.getPaymentMethodByMandateId(mandateId);
    if (!paymentMethod) {
      return c.json({ message: "Mandate not found" }, 404);
    }
    await repaymentClient.deletePaymentMethod({ paymentMethodId: paymentMethod.paymentMethodId });
  } catch (error) {
    const errorMessage = formatErrorMessage(error);
    logger.error(`Error deleting mandate: ${errorMessage}`);
    return c.json({ message: "Error deleting mandate" }, 500);
  }

  return c.json({ message: "mandate deleted" }, 200);
});

export const handler = handle(app);
export default handler;
