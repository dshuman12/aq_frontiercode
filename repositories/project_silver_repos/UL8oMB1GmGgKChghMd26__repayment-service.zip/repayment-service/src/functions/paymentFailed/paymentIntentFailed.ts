import { createEvent } from "@libs/eventHubUtils";
import { getLogger } from "@libs/logger";
import { RepaymentType } from "@libs/types";
import { eventHubAdapter, coreRepaymentsAdapter, StripeClient } from "@onmoapp/onmo-adapters";
import { PaymentIntentFailedEventOutcome } from "@onmoapp/onmo-types";
import { AccountType, FailureCategory, RepaymentFailedEvent } from "@shared-types/eventHub-types";
import { createProdWaitSchedule } from "@utils/schedulerUtil";
import { determineRepaymentType } from "src/utils/utils";

const getFailureCategory = (event: PaymentIntentFailedEventOutcome): FailureCategory => {
  switch (event.failureReason.failureCode) {
    case "card_declined": {
      if (event.failureReason.declineCode == "expired_card") {
        return FailureCategory.ExpiredCard;
      }
      if (event.failureReason.declineCode == "insufficient_funds") {
        return FailureCategory.InsufficientFunds;
      }
      if (
        event.failureReason.declineCode == "try_again_later" ||
        event.failureReason.declineCode == "processing_error"
      ) {
        return FailureCategory.TechnicalFailure;
      }
      if (event.failureReason.declineCode == "account_closed") {
        return FailureCategory.BankAccountClosed;
      }
      return FailureCategory.CardDeclined;
    }
    case "account_closed":
      return FailureCategory.BankAccountClosed;
    case "balance_insufficient":
    case "insufficient_funds":
      return FailureCategory.InsufficientFunds;
    case "expired_card":
      return FailureCategory.ExpiredCard;
    case "payment_method_not_available":
    case "processing_error":
    case "lock_timeout":
    case "rate_limit":
      return FailureCategory.TechnicalFailure;
    case "payment_intent_mandate_invalid":
      return FailureCategory.MandateCancelled;
    default:
      return FailureCategory.Ohter;
  }
};
export const paymentIntentFailed = async (event: PaymentIntentFailedEventOutcome) => {
  const logger = getLogger();
  logger.addContext({ functionName: "paymentIntentFailed" });
  logger.info(event);

  const eventHubClient = await eventHubAdapter("KINESIS_ADAPTER");

  if (!eventHubClient) {
    logger.error("No event hub client found for KINESIS_ADAPTER");
    return { statusCode: 500, message: "An error occured." };
  }

  const repaymentClient = await coreRepaymentsAdapter("STRIPE_CLIENT");
  if (!repaymentClient) {
    logger.error("No event hub client found for STRIPE_CLIENT");
    return { statusCode: 500, message: "An error occured." };
  }

  let repaymentType: RepaymentType;
  if (event.metadata.repaymentType) {
    repaymentType = event.metadata.repaymentType as RepaymentType;
  } else {
    /* 
      to remain backwards compatible with any intents already created when we launch this that don't have repaymentType in metadata
      will only be card or initial DD's, all retries will have repaymentType in metadata can remove after dd retries live for a few weeks 
    */
    /*
      This is now used for intents created via PaymentLinks. PaymentLinks now allow paying by card or pay by bank. repaymentType is not 
      set in metadata for intents created by PaymentLinks, so we need to determine the repayment type from the payment intent.
    */
    logger.info(`Repayment type not found in metadata as intent must have been created pre direct debit go live or this is a PaymentLink`);

    const paymentIntentDetails = await repaymentClient.getPaymentIntent(event.paymentIntentId);
    repaymentType = determineRepaymentType(paymentIntentDetails.type);
    logger.info(`Repayment type found from payment intent, ${repaymentType}`);
  }

  const mandate =
    repaymentType === RepaymentType.DirectDebit || repaymentType === RepaymentType.DirectDebitRetry
      ? await repaymentClient.getMandateIdBySucceededPaymentIntent(event.paymentIntentId)
      : null;

  const repaymentFailedEvent = {
    accountId: event.metadata.accountId,
    accountType: AccountType.Card,
    customerId: event.metadata.customerId,
    failureDetails: {
      failureCategory: getFailureCategory(event),
      failureCode: event.failureReason.declineCode
        ? `${event.failureReason.failureCode}-${event.failureReason.declineCode}`
        : `${event.failureReason.failureCode}`,
      failureMessage: event.failureReason.message,
      failureTime: event.created.toString(),
    },
    paymentDetails: {
      amount: event.amount, // Amount received is in cents,
      paymentMethod: repaymentType,
      externalId: event.paymentIntentId,
      mandateId: mandate ? mandate.mandateId : null,
    },
    processor: "Stripe",
    processorReference: event.paymentIntentId,
  } as RepaymentFailedEvent;
  const repaymentFailedEventData = createEvent<RepaymentFailedEvent>(repaymentFailedEvent, {
    eventType: "RepaymentFailed",
    subType: repaymentType,
    initiatedBy: "paymentIntentFailed",
  });

  logger.info({ repaymentFailedEventData });

  // checking validation of eventData
  const { isValid: isEventDataValid, validationErrors: eventValidationErrors } =
    await eventHubClient.validateEvent(repaymentFailedEventData);

  logger.info({
    message: "Result of Event validation",
    isEventDataValid,
    eventValidationErrors,
  });

  if (!isEventDataValid) {
    logger.addContext({
      eventValidationErrors,
    });
    logger.error("Invalid event data");
    return { statusCode: 500, message: "An error occured." };
  }

  if (
    process.env.ENVIRONMENT === "staging" &&
    (repaymentType === RepaymentType.DirectDebit || repaymentType === RepaymentType.DirectDebitRetry)
  ) {
    const secrets = await StripeClient.retrieveSecrets(process.env.ENVIRONMENT);
    if (
      secrets.ddRetryProdWait ||
      secrets.ddRetryAlwaysProdWaitAccounts.includes(repaymentFailedEventData.eventData.accountId)
    ) {
      logger.info({ message: `Account set up for waiting 3 working days before receiving the event. Scheduling now.` });

      await createProdWaitSchedule({ event: repaymentFailedEventData });
      return { statusCode: 200, message: "Waiting 3 working days before firing event." };
    }
  }

  // sending event to event hub 
  const {
    isValid: isPublishingEventValid,
    isPublished,
    validationErrors: publishingValidationErrors,
  } = await eventHubClient.publishToEventHub(repaymentFailedEventData, repaymentFailedEventData.correlationId);

  logger.debug({
    message: "Result of Event publishing",
    isPublishingEventValid,
    isPublished,
    publishingValidationErrors,
  });

  if (!isPublishingEventValid || !isPublished) {
    logger.addContext({ publishingValidationErrors });
    logger.error("Failed to publish event to event hub");
    return { statusCode: 500, message: "An error occured." };
  }
  return { statusCode: 200, message: "RepaymentFailed event published successfully." };
};
