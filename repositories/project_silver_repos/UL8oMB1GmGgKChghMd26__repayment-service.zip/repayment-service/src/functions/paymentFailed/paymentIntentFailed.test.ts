import { test, expect, describe, vi, beforeEach } from "vitest";
import { paymentIntentFailed } from "./paymentIntentFailed";
import * as adapters from "@onmoapp/onmo-adapters";

vi.mock("@onmoapp/onmo-adapters");

const testData = require("./testData.json");

describe("paymentIntentFailed tests", () => {
  describe("Card repayments", () => {
    beforeEach(() => {
      vi.resetAllMocks();
    });
    test("Insufficient Funds", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });

      const event = testData.cardDeclinedInsufficientFunds;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 88888,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "INSUFFICIENT_FUNDS",
            failureCode: "card_declined-insufficient_funds",
            failureMessage: "Your card has insufficient funds.",
          },
        },
      });
    });
    test("Expired Card", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedExpiredCard;
      console.log(event);
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "EXPIRED_CARD",
            failureCode: "card_declined-expired_card",
            failureMessage: "Your card has expired.",
          },
        },
      });
    });
    test("Technical Issue", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedTechnicalIssue;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "TECHNICAL_FAILURE",
            failureCode: "card_declined-try_again_later",
            failureMessage: "Try again later.",
          },
        },
      });
    });
    test("Account Closed", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedAccountClosed;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "BANK_ACCOUNT_CLOSED",
            failureCode: "card_declined-account_closed",
            failureMessage: "Account closed.",
          },
        },
      });
    });
    test("Processing Error", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedProcessingError;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "TECHNICAL_FAILURE",
            failureCode: "card_declined-processing_error",
            failureMessage: "Processing error.",
          },
        },
      });
    });
    test("Other issue", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "card",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue(null),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedOther;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "CARD",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "CARD",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "CARD_DECLINED",
            failureCode: "card_declined-call_issuer",
            failureMessage: "Contact issuer for more information.",
          },
        },
      });
    });
  });
  describe("Direct Debit repayments", () => {
    beforeEach(() => {
      vi.resetAllMocks();
    });
    test("Insufficient Funds", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "bacs_debit",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      const event = testData.ddInsufficientFunds;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "DIRECT_DEBIT",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "DIRECT_DEBIT",
            mandateId: "mandate-id",
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "INSUFFICIENT_FUNDS",
            failureCode: "insufficient_funds",
            failureMessage: "Insufficient funds.",
          },
        },
      });
    });
    test("Lock Timetout", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "bacs_debit",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.ddLockTimeout;
      console.log(event);
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "DIRECT_DEBIT",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "DIRECT_DEBIT",
            mandateId: "mandate-id",
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "TECHNICAL_FAILURE",
            failureCode: "lock_timeout",
            failureMessage: "Stripe API is busy, please try again later.",
          },
        },
      });
    });
    test("Technical Issue", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "bacs_debit",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.cardDeclinedTechnicalIssue;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "DIRECT_DEBIT",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "DIRECT_DEBIT",
            mandateId: "mandate-id",
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "TECHNICAL_FAILURE",
            failureCode: "card_declined-try_again_later",
            failureMessage: "Try again later.",
          },
        },
      });
    });
    test("Account Closed", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "bacs_debit",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.ddAccountClosed;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "DIRECT_DEBIT",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "DIRECT_DEBIT",
            mandateId: "mandate-id",
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "BANK_ACCOUNT_CLOSED",
            failureCode: "account_closed",
            failureMessage: "Account closed.",
          },
        },
      });
    });
    test("Invalid mandate", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "bacs_debit",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      const event = testData.ddOther;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "DIRECT_DEBIT",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "DIRECT_DEBIT",
            mandateId: "mandate-id",
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "MANDATE_CANCELLED",
            failureCode: "payment_intent_mandate_invalid",
            failureMessage: "The mandate is invalid.",
          },
        },
      });
    });
  });
  
  describe("PaymentLinks repayments", () => {
    beforeEach(() => {
      vi.resetAllMocks();
    });
    test("generic decline", async () => {
      vi.mocked(adapters.eventHubAdapter, { partial: true }).mockResolvedValue({
        publishToEventHub: vi.fn().mockResolvedValue({ isValid: true, isPublished: true }),
        validateEvent: vi.fn().mockResolvedValue({ isValid: true }),
      });
      (
        adapters.StripeClient as unknown as {
          retrieveSecrets: ReturnType<typeof vi.fn>;
        }
      ).retrieveSecrets = vi.fn().mockResolvedValue({
        ddRetryProdWait: false,
        ddRetryAlwaysProdWaitAccounts: [],
      });
      vi.mocked(adapters.coreRepaymentsAdapter, { partial: true }).mockResolvedValue({
        getPaymentIntent: vi.fn().mockResolvedValue({
          type: "pay_by_bank",
        }),
        getMandateIdBySucceededPaymentIntent: vi.fn().mockResolvedValue({
          mandateId: "mandate-id",
          status: "active",
          reference: "ref",
          mandateUrl: "mandate-url",
          revocationReason: null,
        }),
      });
      const event = testData.payByBankGenericDecline;
      const response = await paymentIntentFailed(event);

      expect(response.statusCode).toBe(200);

      const eventHubAdapterMock = await vi.mocked(adapters).eventHubAdapter.mock.results[0].value;
      expect(eventHubAdapterMock.publishToEventHub).toHaveBeenCalled();

      const repaymentMock = await vi.mocked(adapters).coreRepaymentsAdapter.mock.results[0].value;
      expect(repaymentMock.getPaymentIntent).toHaveBeenCalled();
      expect(repaymentMock.getMandateIdBySucceededPaymentIntent).not.toHaveBeenCalled();

      const callParameter = eventHubAdapterMock.publishToEventHub.mock.calls[0][0];
      expect(callParameter).toMatchObject({
        event: "RepaymentFailed",
        subtype: "PAY_BY_BANK",
        initiatedBy: "paymentIntentFailed",
        eventData: {
          accountId: "account_id",
          accountType: "CARD",
          customerId: "customer_id",
          processor: "Stripe",
          paymentDetails: {
            amount: 1050,
            paymentMethod: "PAY_BY_BANK",
            mandateId: null,
            externalId: "payment_intent_id",
          },
          failureDetails: {
            failureCategory: "OTHER",
            failureCode: "payment_intent_payment_attempt_failed-generic_decline",
            failureMessage: "The payment failed.",
          },
        },
      });
    });
  });
});
