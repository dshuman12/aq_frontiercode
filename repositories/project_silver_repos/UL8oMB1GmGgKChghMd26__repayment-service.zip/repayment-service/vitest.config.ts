import { defineConfig, configDefaults } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  optimizeDeps: {
    exclude: ["@onmoapp/onmo-types"], // vitest will try to bundle ESM as CJS by default
  },
  ssr: {
    noExternal: ["@onmoapp/onmo-types"], // same shenanigans around ESM treated as CJS
  },
  plugins: [tsconfigPaths()],
  test: {
    coverage: {
      reporter: ["text", "json", "html"],
      exclude: [...configDefaults.exclude, "**/build/**", "**/*.spec.ts", "**/contract-test/**"],
    },
    setupFiles: ["dotenv/config", "./src/test-setup.ts"],
    exclude: [...configDefaults.exclude, "**/build/**", "**/*.spec.ts", "**/contract-test/**", "./src/integration-tests/**", "./scripts/**"],
  },
});
