import { defineConfig, configDefaults } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  optimizeDeps: {
    exclude: ["@onmoapp/onmo-types"],
  },
  ssr: {
    noExternal: ["@onmoapp/onmo-types"],
  },
  plugins: [tsconfigPaths()],
  test: {
    setupFiles: ["dotenv/config"],
    exclude: [...configDefaults.exclude, "**/build/**"],
  },
});
