# Repayment Service

This repository handles all repayments made via Stripe. That includes card and direct debit repayments.

The main documentation to see the full flow is this diagram:
[Repayment Service Tech Stack](https://lucid.app/lucidchart/945a0ae4-5edf-41ab-a327-a6911de3d3a6/edit?viewport_loc=-4129%2C-2045%2C7684%2C4088%2C.EB7xP9RQhK1&invitationId=inv_8fb0d7bc-b1fa-4b9d-b688-d594483df9e9)

If you work on a new feature that alters the stack, please update the diagram accordingly.

## Jira Board

If you encounter an issue related to the code in this repository, please raise a ticket in [The Watch](https://onmo.atlassian.net/jira/software/projects/TW/boards/504)

[Direct Debit Retry requirements](https://onmo-app.atlassian.net/wiki/x/AYDnUQ)

[Original Jira Epic](https://onmo.atlassian.net/browse/OCT-622)

## Requirements

This repository is trunk based, open a new branch for any feature work, merge to main when stable and ready to be deployed to staging. Deploy to production from main.
Please follow conventional commits as it is used for semantic versioning during deployments.

- **Node.js & npm**: [Install instructions (via nvm)](https://github.com/nvm-sh/nvm)
- **Terraform CLI**: [Install instructions](https://developer.hashicorp.com/terraform/tutorials/aws-get-started/install-cli)
- **GitHub Personal Access Token**:

  - Create a GitHub personal access token with `read:packages` permission
  - Export the token in your `~/.bashrc` file (or equivalent):

    ```sh
    export ONMO_REGISTRY_PACKAGES="YOUR_TOKEN_HERE"
    ```

## Deployment

The deployment process is managed using GitHub Actions. The workflows are defined in the `.github/workflows` directory:

- `run.planpr.yaml`: Runs on pull requests to plan Terraform changes and check formatting
- `prod.deploy.yaml`: Deploys to the production environment. It will look at all new commits since the latest release and create the relevant new version & release based on the conventional commits present (semantic versioning)
- `staging.deploy.yaml`: Deploys to the staging environment. It triggers automatically when merging to main. It will also run all integration tests after.

## Environment Variables

Required environment variables can be found in `env.example`

# QA Utilities

Dealing with direct debits on staging can be challenging as Stripe will succeed or fail a payment immediately, whereas on production you wouldn't get the event until 2 working days later. This can cause problems when trying to wor out the transaction value date as we need to do calculation based off of when the event was created in Stripe to build the RepaymentCollected event. To help with this, we have a few staging flags that will bypass that calculation to set the transaction date to today, and also flags to choose to have a prod like waiting like (2 working days) on staging or not.

More information on [this diagram](https://lucid.app/lucidchart/fdbeae54-4615-4865-bf11-801222bc331d/edit?viewport_loc=-1325%2C146%2C4144%2C1927%2C6WZ0M78rIgrV&invitationId=inv_d7694f4a-544e-4029-a096-81fb38b3c559)

# Retry scripts

Several scripts were used to identify and retry missed Mambu transactions.

## aggregate-repayment

Usage: `npm run aggregate-repayment`

This script will look into all the S3 bucket folders listed in the `folderList` array to gather them all in a new JSON array, deduplicate them by idempotencyKey
and search for a matching transaction in Mambu by externalId (the payment_intent ID).

It will then produce 3 files:

- JSON file with the successful transactions
- JSON file with the failed transactions (no match gound in Mambu)
- a CSV file with the missing transactions

## check-transactions-from-stripe

Before running it, you need to run a SQL query in Databricks to get the payment succeeded events from Stripe compiled in a CSV that is needed for the script.
The query is in a a comment in the script.

Usage: `npm run check-transactions-from-stripe`

The script will read the CSV and check if a matching transaction exists in Mambu.
It will produce a JSON file with all the repaymentCollected events that needs to be retried, along with CSV files gathering the successful and failed transactions.

## check-transactions-from-mambu

Before running it, you need to a Mambu query done via the UI exported via CSV. Make sure to check the date format, the script will use DD/MM/YYYY

Usage: `npm run check-transactions-from-mambu`

The script will read the CSV and check if a matching transaction exists in Mambu.
It will produce a JSON file with all the repaymentCollected events that needs to be retried, along with CSV files gathering the successful and failed transactions

## repayment-collected-retry

Usage: `npm run repayment-collected-retry`

You can use this script in 2 ways. Default is to call it after one of the scripts above that will produce a JSON file with a list of failed events to retry.

You can also comment out the call to `retryFromJsonFile` and uncomment `retryFromS3` to switch it up and instead retry all the events that are in a specified S3 bucket (from the DLQ). I would recommend calling the aggregrate-repayment script for that case instead as it is a bit more refined.

The script will publish all the events to Kinesis again to retry them.
It will produce a JSON file for all events published to Kinesis successfully (this is NOT indicate a successful transaction added), and another JSON file for events that failed to publish.
It will also provide a CSV compiling the missing transactions (which is just the original JSON file formatted in CSV)

## prepate-mandate-retry

Before running this script, export in CSV the result of the "GC Stripr mismatch" filter in Mambu UI. If you can't find the filter you can create it as follow:
`Where Direct Debit Mandate ID is starting with case sensitive 'M' and Direct Debit Provider is 'Stripe'`

Usage: `npm run prepare-mandate-retry`

This script will call the Stripe API directly to find the active mandate linked to each accountId and prepare a new mandateUpserted event to retry to fix the formatting. The script will produce a JSON file containing these mandateUpserted events ready to be retried, along with a CSV gathering the accounts for which we couldn't find an active mandate (so they cannot be retried)

## retry-mandate

Before running this script, you will need a JSON file compiling the mandateUpserted events you need to retry.

Usage: `npm run retry-mandate`

The script will publish all the events to Kinesis again to retry them.
It will produce a JSON file for all events published to Kinesis successfully (this is NOT indicate a successful transaction added), and another JSON file for events that failed to publish.
