"""Iterative deepening depth-first search."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def depth_limited_search(graph: Any, start: NodeID, goal: NodeID,
                         max_depth: int) -> list[NodeID] | None:
    """Perform depth-limited search up to a maximum depth.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.
        goal: The target node ID.
        max_depth: Maximum depth to search.

    Returns:
        Path as list of node IDs, or None if not found within depth limit.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    if start == goal:
        return [start]

    def _dls(node: NodeID, depth: int, visited: set[NodeID],
             path: list[NodeID]) -> list[NodeID] | None:
        if depth == 0:
            return None
        for neighbor in graph.neighbors(node):
            if neighbor in visited:
                continue
            new_path = path + [neighbor]
            if neighbor == goal:
                return new_path
            visited.add(neighbor)
            result = _dls(neighbor, depth - 1, visited, new_path)
            if result is not None:
                return result
            visited.discard(neighbor)
        return None

    visited: set[NodeID] = {start}
    return _dls(start, max_depth, visited, [start])

def iddfs(graph: Any, start: NodeID, goal: NodeID,
          max_depth: int = 100) -> list[NodeID] | None:
    """Iterative deepening depth-first search.

    Combines the space efficiency of DFS with the completeness of BFS
    by repeating depth-limited searches with increasing depth bounds.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.
        goal: The target node ID.
        max_depth: Maximum depth limit to try.

    Returns:
        Shortest path as list of node IDs, or None if not reachable.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    if not graph.has_node(goal):
        raise KeyError(f"Goal node {goal!r} not found")
    for depth in range(max_depth + 1):
        result = depth_limited_search(graph, start, goal, depth)
        if result is not None:
            return result
    return None

def iddfs_all_nodes(graph: Any, start: NodeID,
                    max_depth: int = 100) -> list[NodeID]:
    """Visit all reachable nodes using iterative deepening.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.
        max_depth: Maximum depth limit.

    Returns:
        List of visited node IDs.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    all_visited: set[NodeID] = set()
    for depth in range(max_depth + 1):
        visited_at_depth: set[NodeID] = set()
        _visit_at_depth(graph, start, depth, visited_at_depth)
        prev_size = len(all_visited)
        all_visited.update(visited_at_depth)
        if len(all_visited) == prev_size and depth > 0:
            break
    return list(all_visited)

def _visit_at_depth(graph: Any, node: NodeID, depth: int,
                    visited: set[NodeID]) -> None:
    """Helper to visit nodes at a specific depth bound."""
    visited.add(node)
    if depth <= 0:
        return
    for neighbor in graph.neighbors(node):
        if neighbor not in visited:
            _visit_at_depth(graph, neighbor, depth - 1, visited)

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
