"""Breadth-first search traversal."""
from __future__ import annotations
from collections import deque
from typing import Any, Callable
from graphyn.core.types import NodeID

def bfs(graph: Any, start: NodeID,
        visit_fn: Callable[[NodeID], None] | None = None) -> list[NodeID]:
    """Perform breadth-first search from a starting node.

    Visits all reachable nodes level by level from the start node.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.
        visit_fn: Optional callback invoked for each visited node.

    Returns:
        List of visited node IDs in BFS order.

    Raises:
        KeyError: If start node does not exist in the graph.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    visited: set[NodeID] = set()
    order: list[NodeID] = []
    queue: deque[NodeID] = deque([start])
    visited.add(start)
    while queue:
        current = queue.popleft()
        order.append(current)
        if visit_fn is not None:
            visit_fn(current)
        for neighbor in graph.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return order

def bfs_layers(graph: Any, start: NodeID) -> list[list[NodeID]]:
    """Return nodes grouped by BFS distance layers.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.

    Returns:
        List of layers, where each layer is a list of node IDs.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    visited: set[NodeID] = {start}
    layers: list[list[NodeID]] = [[start]]
    while layers[-1]:
        next_layer: list[NodeID] = []
        for node in layers[-1]:
            for neighbor in graph.neighbors(node):
                if neighbor not in visited:
                    visited.add(neighbor)
                    next_layer.append(neighbor)
        if next_layer:
            layers.append(next_layer)
        else:
            break
    return layers

def bfs_path(graph: Any, start: NodeID, end: NodeID) -> list[NodeID] | None:
    """Find shortest unweighted path using BFS.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: The starting node ID.
        end: The target node ID.

    Returns:
        List of node IDs forming the path, or None if no path exists.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    if not graph.has_node(end):
        raise KeyError(f"End node {end!r} not found")
    if start == end:
        return [start]
    visited: set[NodeID] = {start}
    queue: deque[list[NodeID]] = deque([[start]])
    while queue:
        path = queue.popleft()
        current = path[-1]
        for neighbor in graph.neighbors(current):
            if neighbor == end:
                return path + [neighbor]
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(path + [neighbor])
    return None

def bfs_connected_component(graph: Any, start: NodeID) -> set[NodeID]:
    """Find all nodes in the connected component containing start.

    Args:
        graph: A graph object with neighbors() and has_node() methods.
        start: A node in the target component.

    Returns:
        Set of node IDs in the same connected component.
    """
    if not graph.has_node(start):
        raise KeyError(f"Start node {start!r} not found")
    visited: set[NodeID] = {start}
    queue: deque[NodeID] = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in graph.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited
