"""Graphyn — Graph analytics and network intelligence framework."""

__version__ = "0.1.0"
__author__ = "Birajit Saikia"
