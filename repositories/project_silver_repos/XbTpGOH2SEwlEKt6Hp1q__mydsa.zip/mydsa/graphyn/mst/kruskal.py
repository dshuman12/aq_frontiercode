"""Kruskal's minimum spanning tree algorithm."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID
from graphyn.mst.union_find import UnionFind

def kruskal_mst(graph: Any) -> list[tuple[NodeID, NodeID, float]]:
    """Compute minimum spanning tree using Kruskal's algorithm.

    Sorts all edges by weight and greedily adds them if they
    do not form a cycle, using Union-Find for cycle detection.

    Time complexity: O(E log E) where E is the number of edges.

    Args:
        graph: An undirected graph with get_node_ids() and iter_edges().

    Returns:
        List of (source, target, weight) tuples forming the MST.
    """
    edges = sorted(graph.iter_edges(), key=lambda e: e[2])
    uf: UnionFind[NodeID] = UnionFind()
    for nid in graph.get_node_ids():
        uf.make_set(nid)
    mst: list[tuple[NodeID, NodeID, float]] = []
    for u, v, w in edges:
        if not uf.connected(u, v):
            uf.union(u, v)
            mst.append((u, v, w))
    return mst

def kruskal_mst_weight(graph: Any) -> float:
    """Compute the total weight of the MST.

    Args:
        graph: An undirected graph.

    Returns:
        Total weight of the minimum spanning tree.
    """
    mst = kruskal_mst(graph)
    return sum(w for _, _, w in mst)

def is_forest(graph: Any) -> bool:
    """Check if the graph is a forest (acyclic undirected graph).

    A forest has exactly n - k edges where n is the number of
    nodes and k is the number of connected components.

    Args:
        graph: An undirected graph.

    Returns:
        True if the graph has no cycles.
    """
    uf: UnionFind[NodeID] = UnionFind()
    for nid in graph.get_node_ids():
        uf.make_set(nid)
    for u, v, _ in graph.iter_edges():
        if uf.connected(u, v):
            return False
        uf.union(u, v)
    return True

def is_spanning_tree(graph: Any, edges: list[tuple[NodeID, NodeID, float]]) -> bool:
    """Check if given edges form a spanning tree of the graph.

    A spanning tree connects all nodes with exactly n-1 edges
    and no cycles.

    Args:
        graph: An undirected graph.
        edges: List of (source, target, weight) tuples.

    Returns:
        True if edges form a valid spanning tree.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if len(edges) != n - 1:
        return False
    uf: UnionFind[NodeID] = UnionFind()
    for nid in nodes:
        uf.make_set(nid)
    for u, v, _ in edges:
        if uf.connected(u, v):
            return False
        uf.union(u, v)
    return uf.count == 1

def second_best_mst_weight(graph: Any) -> float | None:
    """Compute the weight of the second-best MST.

    Finds the MST, then for each non-MST edge, tries swapping
    it in and computes the resulting tree weight.

    Args:
        graph: An undirected graph.

    Returns:
        Weight of the second-best MST, or None if not possible.
    """
    mst_edges = kruskal_mst(graph)
    mst_set = {(min(u, v, key=str), max(u, v, key=str)) for u, v, _ in mst_edges}
    all_edges = list(graph.iter_edges())
    non_mst = [(u, v, w) for u, v, w in all_edges
                if (min(u, v, key=str), max(u, v, key=str)) not in mst_set]
    if not non_mst:
        return None
    best_second = float("inf")
    nodes = graph.get_node_ids()
    for nu, nv, nw in non_mst:
        for i, (mu, mv, mw) in enumerate(mst_edges):
            trial = [e for j, e in enumerate(mst_edges) if j != i]
            trial.append((nu, nv, nw))
            uf: UnionFind[NodeID] = UnionFind()
            for nid in nodes:
                uf.make_set(nid)
            valid = True
            for u, v, _ in trial:
                if uf.connected(u, v):
                    valid = False
                    break
                uf.union(u, v)
            if valid and uf.count == 1:
                w_total = sum(w for _, _, w in trial)
                best_second = min(best_second, w_total)
    return best_second if best_second != float("inf") else None

def mst_edge_set(graph: Any) -> set[tuple[NodeID, NodeID]]:
    """Return the edge set of the MST as unordered pairs.

    Args:
        graph: An undirected graph.

    Returns:
        Set of (u, v) tuples (sorted by str).
    """
    mst = kruskal_mst(graph)
    return {(min(u, v, key=str), max(u, v, key=str)) for u, v, _ in mst}

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
