"""Union-Find (Disjoint Set Union) data structure."""
from __future__ import annotations
from typing import Generic, TypeVar

T = TypeVar("T")

class UnionFind(Generic[T]):
    """Disjoint Set Union with union by rank and path compression.

    Efficiently tracks connected components and supports near O(1)
    amortized union and find operations.

    Attributes:
        count: Current number of disjoint sets.
    """
    def __init__(self) -> None:
        """Initialize an empty Union-Find structure."""
        self._parent: dict[T, T] = {}
        self._rank: dict[T, int] = {}
        self._size: dict[T, int] = {}
        self._count: int = 0

    @property
    def count(self) -> int:
        """Return the number of disjoint sets."""
        return self._count

    def make_set(self, x: T) -> None:
        """Create a new singleton set containing element x.

        Args:
            x: The element to add.
        """
        if x in self._parent:
            return
        self._parent[x] = x
        self._rank[x] = 0
        self._size[x] = 1
        self._count += 1

    def find(self, x: T) -> T:
        """Find the representative of the set containing x.

        Uses path compression for amortized near-constant time.

        Args:
            x: The element to find.

        Returns:
            The representative element of the set.

        Raises:
            KeyError: If x has not been added.
        """
        if x not in self._parent:
            raise KeyError(f"Element {x!r} not found")
        if self._parent[x] != x:
            self._parent[x] = self.find(self._parent[x])
        return self._parent[x]

    def union(self, x: T, y: T) -> bool:
        """Merge the sets containing x and y.

        Uses union by rank to keep trees balanced.

        Args:
            x: First element.
            y: Second element.

        Returns:
            True if the sets were merged (were different), False if already same.
        """
        rx = self.find(x)
        ry = self.find(y)
        if rx == ry:
            return False
        if self._rank[rx] < self._rank[ry]:
            rx, ry = ry, rx
        self._parent[ry] = rx
        self._size[rx] += self._size[ry]
        if self._rank[rx] == self._rank[ry]:
            self._rank[rx] += 1
        self._count -= 1
        return True

    def connected(self, x: T, y: T) -> bool:
        """Check if two elements are in the same set.

        Args:
            x: First element.
            y: Second element.

        Returns:
            True if x and y are in the same set.
        """
        return self.find(x) == self.find(y)

    def set_size(self, x: T) -> int:
        """Return the size of the set containing x.

        Args:
            x: An element in the structure.

        Returns:
            Number of elements in the same set.
        """
        return self._size[self.find(x)]

    def sets(self) -> list[set[T]]:
        """Return all disjoint sets.

        Returns:
            List of sets, each containing elements in one group.
        """
        groups: dict[T, set[T]] = {}
        for x in self._parent:
            root = self.find(x)
            if root not in groups:
                groups[root] = set()
            groups[root].add(x)
        return list(groups.values())

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
