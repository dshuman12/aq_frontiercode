"""Prim's minimum spanning tree algorithm."""
from __future__ import annotations
import heapq
from typing import Any
from graphyn.core.types import NodeID

def prim_mst(graph: Any, start: NodeID | None = None) -> list[tuple[NodeID, NodeID, float]]:
    """Compute minimum spanning tree using Prim's algorithm.

    Starts from a given node and greedily adds the cheapest edge
    connecting the MST to a non-MST node.

    Time complexity: O(E log V) using a binary heap.

    Args:
        graph: An undirected graph with get_node_ids(), neighbors(),
               get_edge_weight().
        start: Starting node. If None, uses the first node.

    Returns:
        List of (source, target, weight) tuples forming the MST.
    """
    nodes = graph.get_node_ids()
    if not nodes:
        return []
    if start is None:
        start = nodes[0]
    in_mst: set[NodeID] = {start}
    mst: list[tuple[NodeID, NodeID, float]] = []
    heap: list[tuple[float, NodeID, NodeID]] = []
    for nb in graph.neighbors(start):
        w = graph.get_edge_weight(start, nb)
        heapq.heappush(heap, (w, start, nb))
    while heap and len(in_mst) < len(nodes):
        w, u, v = heapq.heappop(heap)
        if v in in_mst:
            continue
        in_mst.add(v)
        mst.append((u, v, w))
        for nb in graph.neighbors(v):
            if nb not in in_mst:
                w2 = graph.get_edge_weight(v, nb)
                heapq.heappush(heap, (w2, v, nb))
    return mst

def prim_mst_weight(graph: Any, start: NodeID | None = None) -> float:
    """Compute the total weight of the MST using Prim's.

    Args:
        graph: An undirected graph.
        start: Optional starting node.

    Returns:
        Total weight of the minimum spanning tree.
    """
    mst = prim_mst(graph, start)
    return sum(w for _, _, w in mst)
