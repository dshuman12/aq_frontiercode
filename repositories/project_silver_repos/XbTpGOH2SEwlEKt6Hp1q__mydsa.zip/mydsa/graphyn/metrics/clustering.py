"""Clustering coefficient computation."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def clustering_coefficient(graph: Any, node_id: NodeID) -> float:
    """Compute the local clustering coefficient of a node.

    The clustering coefficient measures the fraction of possible
    triangles through a node that actually exist.

    Args:
        graph: An undirected graph with neighbors() method.
        node_id: The node to compute clustering for.

    Returns:
        Clustering coefficient between 0.0 and 1.0.
    """
    neighbors = graph.neighbors(node_id)
    k = len(neighbors)
    if k < 2:
        return 0.0
    neighbor_set = set(neighbors)
    triangles = 0
    for i in range(len(neighbors)):
        for j in range(i + 1, len(neighbors)):
            if graph.has_edge(neighbors[i], neighbors[j]):
                triangles += 1
    return (2.0 * triangles) / (k * (k - 1))

def avg_clustering(graph: Any) -> float:
    """Compute the average clustering coefficient of the graph.

    Args:
        graph: An undirected graph.

    Returns:
        Mean clustering coefficient across all nodes.
    """
    nodes = graph.get_node_ids()
    if not nodes:
        return 0.0
    total = sum(clustering_coefficient(graph, n) for n in nodes)
    return total / len(nodes)

def transitivity(graph: Any) -> float:
    """Compute the global transitivity (ratio of triangles).

    Transitivity is 3 * (number of triangles) / (number of triads).

    Args:
        graph: An undirected graph.

    Returns:
        Global transitivity value.
    """
    triangles = 0
    triads = 0
    for v in graph.get_node_ids():
        neighbors = graph.neighbors(v)
        k = len(neighbors)
        triads += k * (k - 1) // 2
        neighbor_set = set(neighbors)
        for i in range(len(neighbors)):
            for j in range(i + 1, len(neighbors)):
                if graph.has_edge(neighbors[i], neighbors[j]):
                    triangles += 1
    if triads == 0:
        return 0.0
    return triangles / triads

def triangle_count(graph: Any) -> int:
    """Count the total number of triangles in the graph.

    Args:
        graph: An undirected graph.

    Returns:
        Number of unique triangles.
    """
    count = 0
    for v in graph.get_node_ids():
        neighbors = graph.neighbors(v)
        for i in range(len(neighbors)):
            for j in range(i + 1, len(neighbors)):
                if graph.has_edge(neighbors[i], neighbors[j]):
                    count += 1
    return count // 3
