"""Graph diameter and radius computation."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID

INF = float("inf")

def graph_diameter(graph: Any) -> float:
    """Compute the diameter of a graph.

    The diameter is the maximum eccentricity of any node, i.e.,
    the longest shortest path between any pair of nodes.

    Args:
        graph: A graph with get_node_ids() and neighbors().

    Returns:
        The diameter, or inf if the graph is disconnected.
    """
    nodes = graph.get_node_ids()
    if len(nodes) <= 1:
        return 0.0
    max_dist = 0.0
    for source in nodes:
        dist = _bfs_distances(graph, source)
        for target in nodes:
            if target not in dist:
                return INF
            max_dist = max(max_dist, dist[target])
    return float(max_dist)

def graph_radius(graph: Any) -> float:
    """Compute the radius of a graph.

    The radius is the minimum eccentricity among all nodes.

    Args:
        graph: A graph with get_node_ids() and neighbors().

    Returns:
        The radius, or inf if the graph is disconnected.
    """
    nodes = graph.get_node_ids()
    if len(nodes) <= 1:
        return 0.0
    min_ecc = INF
    for source in nodes:
        dist = _bfs_distances(graph, source)
        if len(dist) < len(nodes):
            return INF
        ecc = max(dist.values())
        min_ecc = min(min_ecc, ecc)
    return float(min_ecc)

def eccentricity(graph: Any, node_id: NodeID) -> float:
    """Compute the eccentricity of a single node.

    Args:
        graph: A graph.
        node_id: The node to compute eccentricity for.

    Returns:
        Maximum distance from node_id to any other node.
    """
    dist = _bfs_distances(graph, node_id)
    if len(dist) < graph.node_count:
        return INF
    return float(max(dist.values())) if dist else 0.0

def center_nodes(graph: Any) -> list[NodeID]:
    """Find the center nodes of the graph.

    Center nodes have eccentricity equal to the radius.

    Args:
        graph: A graph.

    Returns:
        List of node IDs in the center.
    """
    nodes = graph.get_node_ids()
    r = graph_radius(graph)
    if r == INF:
        return []
    return [n for n in nodes if eccentricity(graph, n) == r]

def _bfs_distances(graph: Any, source: NodeID) -> dict[NodeID, int]:
    """BFS shortest distances from source."""
    dist: dict[NodeID, int] = {source: 0}
    queue: deque[NodeID] = deque([source])
    while queue:
        v = queue.popleft()
        for w in graph.neighbors(v):
            if w not in dist:
                dist[w] = dist[v] + 1
                queue.append(w)
    return dist

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
