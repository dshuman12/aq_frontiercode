"""Betweenness centrality computation."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID

def betweenness_centrality(graph: Any, normalized: bool = True) -> dict[NodeID, float]:
    """Compute betweenness centrality for all nodes.

    Betweenness centrality measures how often a node appears on
    shortest paths between other pairs of nodes. Uses Brandes' algorithm.

    Time complexity: O(VE) for unweighted graphs.

    Args:
        graph: A graph with get_node_ids() and neighbors().
        normalized: If True, normalize scores by 2/((n-1)(n-2)).

    Returns:
        Dictionary mapping node IDs to betweenness centrality scores.
    """
    nodes = graph.get_node_ids()
    centrality: dict[NodeID, float] = {v: 0.0 for v in nodes}
    for s in nodes:
        stack: list[NodeID] = []
        pred: dict[NodeID, list[NodeID]] = {w: [] for w in nodes}
        sigma: dict[NodeID, int] = {w: 0 for w in nodes}
        sigma[s] = 1
        dist: dict[NodeID, int] = {w: -1 for w in nodes}
        dist[s] = 0
        queue: deque[NodeID] = deque([s])
        while queue:
            v = queue.popleft()
            stack.append(v)
            for w in graph.neighbors(v):
                if dist[w] < 0:
                    queue.append(w)
                    dist[w] = dist[v] + 1
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)
        delta: dict[NodeID, float] = {v: 0.0 for v in nodes}
        while stack:
            w = stack.pop()
            for v in pred[w]:
                ratio = sigma[v] / sigma[w]
                delta[v] += ratio * (1.0 + delta[w])
            if w != s:
                centrality[w] += delta[w]
    is_directed = hasattr(graph, "_succ")
    if not is_directed:
        for v in centrality:
            centrality[v] /= 2.0
    if normalized:
        n = len(nodes)
        if n > 2:
            scale = 1.0 / ((n - 1) * (n - 2))
            if not is_directed:
                scale *= 2.0
            for v in centrality:
                centrality[v] *= scale
    return centrality

def edge_betweenness(graph: Any) -> dict[tuple[NodeID, NodeID], float]:
    """Compute betweenness centrality for all edges.

    Args:
        graph: A graph with get_node_ids() and neighbors().

    Returns:
        Dictionary mapping (source, target) tuples to centrality scores.
    """
    nodes = graph.get_node_ids()
    edge_cent: dict[tuple[NodeID, NodeID], float] = {}
    for s in nodes:
        stack: list[NodeID] = []
        pred: dict[NodeID, list[NodeID]] = {w: [] for w in nodes}
        sigma: dict[NodeID, int] = {w: 0 for w in nodes}
        sigma[s] = 1
        dist: dict[NodeID, int] = {w: -1 for w in nodes}
        dist[s] = 0
        queue: deque[NodeID] = deque([s])
        while queue:
            v = queue.popleft()
            stack.append(v)
            for w in graph.neighbors(v):
                if dist[w] < 0:
                    queue.append(w)
                    dist[w] = dist[v] + 1
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)
        delta: dict[NodeID, float] = {v: 0.0 for v in nodes}
        while stack:
            w = stack.pop()
            for v in pred[w]:
                ratio = sigma[v] / sigma[w]
                contrib = ratio * (1.0 + delta[w])
                delta[v] += contrib
                edge_key = (min(v, w, key=str), max(v, w, key=str))
                edge_cent[edge_key] = edge_cent.get(edge_key, 0.0) + contrib
    for key in edge_cent:
        edge_cent[key] /= 2.0
    return edge_cent
