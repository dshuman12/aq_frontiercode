"""Eigenvector centrality computation."""
from __future__ import annotations
import math
from typing import Any
from graphyn.core.types import NodeID

def eigenvector_centrality(graph: Any, max_iter: int = 100,
                           tolerance: float = 1e-6) -> dict[NodeID, float]:
    """Compute eigenvector centrality using power iteration.

    A node has high eigenvector centrality if it is connected to
    other nodes that themselves have high centrality.

    Args:
        graph: A graph with get_node_ids() and neighbors().
        max_iter: Maximum number of iterations.
        tolerance: Convergence threshold.

    Returns:
        Dictionary mapping node IDs to centrality scores.

    Raises:
        RuntimeError: If the algorithm fails to converge.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return {}
    x: dict[NodeID, float] = {nid: 1.0 / n for nid in nodes}
    for iteration in range(max_iter):
        x_new: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
        for nid in nodes:
            for neighbor in graph.neighbors(nid):
                x_new[nid] += x[neighbor]
        norm = math.sqrt(sum(v ** 2 for v in x_new.values()))
        if norm == 0:
            return {nid: 0.0 for nid in nodes}
        x_new = {nid: v / norm for nid, v in x_new.items()}
        diff = math.sqrt(sum((x_new[nid] - x[nid]) ** 2 for nid in nodes))
        x = x_new
        if diff < tolerance:
            return x
    raise RuntimeError(
        f"Eigenvector centrality did not converge after {max_iter} iterations")

def katz_centrality(graph: Any, alpha: float = 0.1,
                    beta: float = 1.0, max_iter: int = 100,
                    tolerance: float = 1e-6) -> dict[NodeID, float]:
    """Compute Katz centrality.

    Katz centrality computes the relative influence of a node by
    summing all paths from that node, with exponentially decaying
    contributions for longer paths.

    Args:
        graph: A graph with get_node_ids() and neighbors().
        alpha: Attenuation factor.
        beta: Base centrality for each node.
        max_iter: Maximum iterations.
        tolerance: Convergence threshold.

    Returns:
        Dictionary mapping node IDs to Katz centrality scores.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return {}
    x: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
    for _ in range(max_iter):
        x_new: dict[NodeID, float] = {}
        for nid in nodes:
            total = beta
            for neighbor in graph.neighbors(nid):
                total += alpha * x[neighbor]
            x_new[nid] = total
        diff = math.sqrt(sum((x_new[nid] - x[nid]) ** 2 for nid in nodes))
        x = x_new
        if diff < tolerance:
            break
    norm = math.sqrt(sum(v ** 2 for v in x.values()))
    if norm > 0:
        x = {nid: v / norm for nid, v in x.items()}
    return x
