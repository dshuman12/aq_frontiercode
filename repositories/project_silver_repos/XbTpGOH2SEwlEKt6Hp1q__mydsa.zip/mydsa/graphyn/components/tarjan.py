"""Tarjan's strongly connected components algorithm."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def tarjan_scc(graph: Any) -> list[set[NodeID]]:
    """Find strongly connected components using Tarjan's algorithm.

    Uses a single DFS pass with a stack to identify SCCs.
    A node is the root of an SCC if its low-link value equals
    its discovery time.

    Time complexity: O(V + E).

    Args:
        graph: A directed graph with get_node_ids() and neighbors().

    Returns:
        List of sets, each containing nodes in one SCC.
    """
    nodes = graph.get_node_ids()
    index_counter = [0]
    stack: list[NodeID] = []
    on_stack: set[NodeID] = set()
    disc: dict[NodeID, int] = {}
    low: dict[NodeID, int] = {}
    sccs: list[set[NodeID]] = []

    def _strongconnect(v: NodeID) -> None:
        disc[v] = index_counter[0]
        low[v] = index_counter[0]
        index_counter[0] += 1
        stack.append(v)
        on_stack.add(v)
        for w in graph.neighbors(v):
            if w not in disc:
                _strongconnect(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], disc[w])
        if low[v] == disc[v]:
            scc: set[NodeID] = set()
            while True:
                w = stack.pop()
                on_stack.discard(w)
                scc.add(w)
                if w == v:
                    break
            sccs.append(scc)

    for v in nodes:
        if v not in disc:
            _strongconnect(v)
    return sccs

def is_strongly_connected(graph: Any) -> bool:
    """Check if a directed graph is strongly connected.

    A graph is strongly connected if every node is reachable
    from every other node.

    Args:
        graph: A directed graph.

    Returns:
        True if the graph is strongly connected.
    """
    sccs = tarjan_scc(graph)
    return len(sccs) == 1

def condensation_graph_data(graph: Any) -> tuple[list[set[NodeID]], dict[NodeID, int]]:
    """Compute SCC condensation data.

    The condensation graph is a DAG where each node represents
    an SCC from the original graph. This function returns the
    SCCs and a mapping from original nodes to their SCC index.

    Args:
        graph: A directed graph.

    Returns:
        Tuple of (scc_list, node_to_scc_index).
    """
    sccs = tarjan_scc(graph)
    node_to_scc: dict[NodeID, int] = {}
    for idx, scc in enumerate(sccs):
        for node in scc:
            node_to_scc[node] = idx
    return sccs, node_to_scc

def scc_sizes(graph: Any) -> list[int]:
    """Return SCC sizes sorted from largest to smallest.

    Args:
        graph: A directed graph.

    Returns:
        List of SCC sizes in descending order.
    """
    sccs = tarjan_scc(graph)
    return sorted([len(s) for s in sccs], reverse=True)

def largest_scc(graph: Any) -> set[NodeID]:
    """Return the largest strongly connected component.

    Args:
        graph: A directed graph.

    Returns:
        Set of node IDs in the largest SCC.
    """
    sccs = tarjan_scc(graph)
    if not sccs:
        return set()
    return max(sccs, key=len)

def scc_dag_edges(graph: Any) -> list[tuple[int, int]]:
    """Compute edges of the condensation DAG.

    Returns edges between SCC indices (not between individual nodes).

    Args:
        graph: A directed graph.

    Returns:
        List of (scc_from, scc_to) edges in the DAG.
    """
    sccs, node_to_scc = condensation_graph_data(graph)
    dag_edges: set[tuple[int, int]] = set()
    for u, v, _ in graph.iter_edges():
        c_u = node_to_scc[u]
        c_v = node_to_scc[v]
        if c_u != c_v:
            dag_edges.add((c_u, c_v))
    return list(dag_edges)
