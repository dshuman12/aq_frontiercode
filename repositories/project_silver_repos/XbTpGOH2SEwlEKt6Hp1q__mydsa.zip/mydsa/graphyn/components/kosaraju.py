"""Kosaraju's strongly connected components algorithm."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def kosaraju_scc(graph: Any) -> list[set[NodeID]]:
    """Find strongly connected components using Kosaraju's algorithm.

    Performs two DFS passes:
    1. First pass on the original graph to compute finish order.
    2. Second pass on the reversed graph in reverse finish order
       to identify SCCs.

    Time complexity: O(V + E).

    Args:
        graph: A directed graph with get_node_ids(), neighbors(),
               and a reverse() or predecessors() method.

    Returns:
        List of sets, each containing nodes in one SCC.
    """
    nodes = graph.get_node_ids()
    visited: set[NodeID] = set()
    finish_order: list[NodeID] = []

    def _dfs_first(v: NodeID) -> None:
        visited.add(v)
        for w in graph.neighbors(v):
            if w not in visited:
                _dfs_first(w)
        finish_order.append(v)

    for v in nodes:
        if v not in visited:
            _dfs_first(v)
    visited.clear()
    sccs: list[set[NodeID]] = []

    def _dfs_second(v: NodeID, component: set[NodeID]) -> None:
        visited.add(v)
        component.add(v)
        if hasattr(graph, "predecessors"):
            reverse_neighbors = graph.predecessors(v)
        else:
            reverse_neighbors = graph.neighbors(v)
        for w in reverse_neighbors:
            if w not in visited:
                _dfs_second(w, component)

    for v in reversed(finish_order):
        if v not in visited:
            component: set[NodeID] = set()
            _dfs_second(v, component)
            sccs.append(component)
    return sccs

def scc_count(graph: Any) -> int:
    """Return the number of strongly connected components.

    Args:
        graph: A directed graph.

    Returns:
        Number of SCCs.
    """
    return len(kosaraju_scc(graph))

def kosaraju_is_strongly_connected(graph: Any) -> bool:
    """Check if a directed graph is strongly connected using Kosaraju.

    Args:
        graph: A directed graph.

    Returns:
        True if the graph has exactly one SCC.
    """
    return scc_count(graph) == 1

def weakly_connected_components(graph: Any) -> list[set[NodeID]]:
    """Find weakly connected components of a directed graph.

    A weakly connected component is a maximal set of nodes such
    that there is an undirected path between every pair.

    Args:
        graph: A directed graph.

    Returns:
        List of weakly connected component node sets.
    """
    from collections import deque
    nodes = graph.get_node_ids()
    adj: dict[NodeID, set[NodeID]] = {n: set() for n in nodes}
    for u, v, _ in graph.iter_edges():
        adj[u].add(v)
        adj[v].add(u)
    visited: set[NodeID] = set()
    components: list[set[NodeID]] = []
    for node in nodes:
        if node in visited:
            continue
        comp: set[NodeID] = set()
        queue: deque[NodeID] = deque([node])
        visited.add(node)
        while queue:
            current = queue.popleft()
            comp.add(current)
            for nb in adj[current]:
                if nb not in visited:
                    visited.add(nb)
                    queue.append(nb)
        components.append(comp)
    return components

def is_weakly_connected(graph: Any) -> bool:
    """Check if a directed graph is weakly connected.

    Args:
        graph: A directed graph.

    Returns:
        True if the graph is weakly connected.
    """
    return len(weakly_connected_components(graph)) == 1

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
