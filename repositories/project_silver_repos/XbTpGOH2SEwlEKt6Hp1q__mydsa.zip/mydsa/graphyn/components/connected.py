"""Connected components for undirected graphs."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID

def connected_components(graph: Any) -> list[set[NodeID]]:
    """Find all connected components in an undirected graph.

    Uses BFS to discover each component. Each node belongs to
    exactly one connected component.

    Args:
        graph: An undirected graph with get_node_ids() and neighbors().

    Returns:
        List of sets, each containing node IDs in one component.
    """
    nodes = graph.get_node_ids()
    visited: set[NodeID] = set()
    components: list[set[NodeID]] = []
    for node in nodes:
        if node in visited:
            continue
        component: set[NodeID] = set()
        queue: deque[NodeID] = deque([node])
        visited.add(node)
        while queue:
            current = queue.popleft()
            component.add(current)
            for neighbor in graph.neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        components.append(component)
    return components

def is_connected(graph: Any) -> bool:
    """Check if an undirected graph is connected.

    Args:
        graph: An undirected graph.

    Returns:
        True if all nodes are reachable from any node.
    """
    nodes = graph.get_node_ids()
    if len(nodes) <= 1:
        return True
    visited: set[NodeID] = set()
    queue: deque[NodeID] = deque([nodes[0]])
    visited.add(nodes[0])
    while queue:
        current = queue.popleft()
        for neighbor in graph.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return len(visited) == len(nodes)

def number_of_components(graph: Any) -> int:
    """Return the number of connected components.

    Args:
        graph: An undirected graph.

    Returns:
        Integer count of components.
    """
    return len(connected_components(graph))

def largest_component(graph: Any) -> set[NodeID]:
    """Return the largest connected component.

    Args:
        graph: An undirected graph.

    Returns:
        Set of node IDs in the largest component.
    """
    comps = connected_components(graph)
    if not comps:
        return set()
    return max(comps, key=len)

def smallest_component(graph: Any) -> set[NodeID]:
    """Return the smallest connected component.

    Args:
        graph: An undirected graph.

    Returns:
        Set of node IDs in the smallest component.
    """
    comps = connected_components(graph)
    if not comps:
        return set()
    return min(comps, key=len)

def node_component(graph: Any, node_id: NodeID) -> set[NodeID]:
    """Find the connected component containing a specific node.

    Args:
        graph: An undirected graph.
        node_id: The node to find the component for.

    Returns:
        Set of node IDs in the same component.

    Raises:
        KeyError: If the node does not exist.
    """
    if not graph.has_node(node_id):
        raise KeyError(f"Node {node_id!r} not found")
    visited: set[NodeID] = {node_id}
    queue: deque[NodeID] = deque([node_id])
    while queue:
        current = queue.popleft()
        for neighbor in graph.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited

def component_sizes(graph: Any) -> list[int]:
    """Return sizes of all connected components, sorted descending.

    Args:
        graph: An undirected graph.

    Returns:
        List of component sizes from largest to smallest.
    """
    comps = connected_components(graph)
    return sorted([len(c) for c in comps], reverse=True)

def articulation_points(graph: Any) -> set[NodeID]:
    """Find all articulation points (cut vertices) in the graph.

    An articulation point is a node whose removal disconnects
    the graph (increases the number of connected components).

    Uses Tarjan's bridge-finding DFS.

    Args:
        graph: An undirected graph.

    Returns:
        Set of articulation point node IDs.
    """
    nodes = graph.get_node_ids()
    disc: dict[NodeID, int] = {}
    low: dict[NodeID, int] = {}
    parent: dict[NodeID, NodeID | None] = {}
    ap: set[NodeID] = set()
    timer = [0]

    def _dfs(u: NodeID) -> None:
        children = 0
        disc[u] = timer[0]
        low[u] = timer[0]
        timer[0] += 1
        for v in graph.neighbors(u):
            if v not in disc:
                children += 1
                parent[v] = u
                _dfs(v)
                low[u] = min(low[u], low[v])
                if parent[u] is None and children > 1:
                    ap.add(u)
                if parent[u] is not None and low[v] >= disc[u]:
                    ap.add(u)
            elif v != parent.get(u):
                low[u] = min(low[u], disc[v])

    for node in nodes:
        if node not in disc:
            parent[node] = None
            _dfs(node)
    return ap

def bridges(graph: Any) -> list[tuple[NodeID, NodeID]]:
    """Find all bridge edges in the graph.

    A bridge is an edge whose removal disconnects the graph.

    Args:
        graph: An undirected graph.

    Returns:
        List of (u, v) tuples representing bridge edges.
    """
    nodes = graph.get_node_ids()
    disc: dict[NodeID, int] = {}
    low: dict[NodeID, int] = {}
    parent: dict[NodeID, NodeID | None] = {}
    bridge_list: list[tuple[NodeID, NodeID]] = []
    timer = [0]

    def _dfs(u: NodeID) -> None:
        disc[u] = timer[0]
        low[u] = timer[0]
        timer[0] += 1
        for v in graph.neighbors(u):
            if v not in disc:
                parent[v] = u
                _dfs(v)
                low[u] = min(low[u], low[v])
                if low[v] > disc[u]:
                    bridge_list.append((u, v))
            elif v != parent.get(u):
                low[u] = min(low[u], disc[v])

    for node in nodes:
        if node not in disc:
            parent[node] = None
            _dfs(node)
    return bridge_list

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
