"""Functions for loading graphs from common data formats."""
from __future__ import annotations
from typing import Any
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.types import NodeID, Weight

def from_edge_list(edges: list[tuple[NodeID, NodeID, float]],
                   name: str = "edge_list_graph",
                   directed: bool = False) -> Graph | DiGraph:
    """Create a graph from a list of (source, target, weight) tuples.

    Args:
        edges: List of edge tuples.
        name: Name of the graph.
        directed: If True, creates a DiGraph.

    Returns:
        A Graph or DiGraph instance.
    """
    if directed:
        g = DiGraph(name=name)
    else:
        g = Graph(name=name)
    node_ids: set[NodeID] = set()
    for src, tgt, _ in edges:
        node_ids.add(src)
        node_ids.add(tgt)
    for nid in sorted(node_ids, key=str):
        g.add_node(Node(node_id=nid))
    for src, tgt, wt in edges:
        g.add_edge(Edge(source=src, target=tgt, weight=wt))
    return g

def from_adjacency_dict(adj: dict[NodeID, list[tuple[NodeID, float]]],
                        name: str = "adj_dict_graph",
                        directed: bool = False) -> Graph | DiGraph:
    """Create a graph from an adjacency dictionary.

    Args:
        adj: Mapping from node IDs to lists of (neighbor, weight) tuples.
        name: Name of the graph.
        directed: If True, creates a DiGraph.

    Returns:
        A Graph or DiGraph instance.
    """
    if directed:
        g = DiGraph(name=name)
    else:
        g = Graph(name=name)
    all_ids: set[NodeID] = set(adj.keys())
    for neighbors in adj.values():
        for nid, _ in neighbors:
            all_ids.add(nid)
    for nid in sorted(all_ids, key=str):
        g.add_node(Node(node_id=nid))
    added: set[tuple[NodeID, NodeID]] = set()
    for src, neighbors in adj.items():
        for tgt, wt in neighbors:
            if directed or (src, tgt) not in added:
                g.add_edge(Edge(source=src, target=tgt, weight=wt))
                added.add((src, tgt))
                added.add((tgt, src))
    return g

def from_node_pairs(pairs: list[tuple[NodeID, NodeID]],
                    name: str = "pairs_graph",
                    directed: bool = False) -> Graph | DiGraph:
    """Create an unweighted graph from a list of node pairs.

    Args:
        pairs: List of (source, target) tuples.
        name: Name of the graph.
        directed: If True, creates a DiGraph.

    Returns:
        A Graph or DiGraph instance.
    """
    weighted = [(s, t, 1.0) for s, t in pairs]
    return from_edge_list(weighted, name=name, directed=directed)
