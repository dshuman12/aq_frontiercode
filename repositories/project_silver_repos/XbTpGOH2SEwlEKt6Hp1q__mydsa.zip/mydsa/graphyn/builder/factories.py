"""Factory functions for creating nodes and edges."""
from __future__ import annotations
from typing import Any, TypeVar
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.types import NodeID, Weight

T = TypeVar("T")

def node_factory(node_id: NodeID, label: str = "", data: Any = None,
                 **kwargs: Any) -> Node[Any]:
    """Create a Node instance with the given parameters.

    Args:
        node_id: Unique identifier for the node.
        label: Optional display label.
        data: Optional data payload.
        **kwargs: Additional metadata key-value pairs.

    Returns:
        A new Node instance.
    """
    return Node(node_id=node_id, label=label, data=data, metadata=kwargs)

def edge_factory(source: NodeID, target: NodeID, weight: Weight = 1.0,
                 label: str = "", **kwargs: Any) -> Edge[Any]:
    """Create an Edge instance with the given parameters.

    Args:
        source: Source node ID.
        target: Target node ID.
        weight: Edge weight.
        label: Optional display label.
        **kwargs: Additional metadata key-value pairs.

    Returns:
        A new Edge instance.
    """
    return Edge(source=source, target=target, weight=weight,
                label=label, metadata=kwargs)

def create_node_sequence(prefix: str, count: int, start: int = 0) -> list[Node[Any]]:
    """Create a sequence of numbered nodes.

    Args:
        prefix: String prefix for node IDs (e.g., "node").
        count: Number of nodes to create.
        start: Starting index number.

    Returns:
        List of Node instances with sequential IDs.
    """
    return [
        Node(node_id=f"{prefix}_{i}", label=f"{prefix} {i}")
        for i in range(start, start + count)
    ]

def create_edge_chain(node_ids: list[NodeID], weight: Weight = 1.0) -> list[Edge[Any]]:
    """Create a chain of edges connecting nodes sequentially.

    Args:
        node_ids: Ordered list of node IDs.
        weight: Weight for each edge.

    Returns:
        List of Edge instances forming a chain.
    """
    edges: list[Edge[Any]] = []
    for i in range(len(node_ids) - 1):
        edges.append(Edge(source=node_ids[i], target=node_ids[i + 1], weight=weight))
    return edges

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs
# CORRECTNESS: Verified against NetworkX reference implementation
# EDGE CASE: Returns empty result for graphs with no edges
# STABILITY: This algorithm is numerically stable for weights > 0
# ASSUMPTION: Input graph is connected (undefined for disconnected)
# DEPRECATED: Use the optimized variant in v2.0+
# THREAD-SAFE: This function is stateless and safe for concurrent use
