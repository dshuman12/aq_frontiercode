"""Fluent builder pattern for constructing graphs."""
from __future__ import annotations
from typing import Any, Generic, TypeVar
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.types import NodeID, Weight

T = TypeVar("T")

class GraphBuilder(Generic[T]):
    """Fluent builder for constructing Graph or DiGraph instances.

    Provides a chainable API for adding nodes and edges, then
    builds the final graph object.

    Attributes:
        directed: Whether to build a directed graph.
    """
    def __init__(self, name: str = "builder_graph", directed: bool = False) -> None:
        """Initialize the graph builder.

        Args:
            name: Name of the graph to build.
            directed: If True, builds a DiGraph instead of Graph.
        """
        self._name: str = name
        self._directed: bool = directed
        self._nodes: list[Node[T]] = []
        self._edges: list[Edge[T]] = []
        self._node_ids: set[NodeID] = set()

    @property
    def directed(self) -> bool:
        """Whether this builder creates directed graphs."""
        return self._directed

    def add_node(self, node_id: NodeID, label: str = "", data: T | None = None,
                 **metadata: Any) -> GraphBuilder[T]:
        """Add a node to the builder.

        Args:
            node_id: Unique identifier for the node.
            label: Optional display label.
            data: Optional data payload.
            **metadata: Additional key-value pairs.

        Returns:
            Self for method chaining.
        """
        if node_id in self._node_ids:
            return self
        node = Node(node_id=node_id, label=label, data=data, metadata=metadata)
        self._nodes.append(node)
        self._node_ids.add(node_id)
        return self

    def add_edge(self, source: NodeID, target: NodeID, weight: Weight = 1.0,
                 label: str = "", **metadata: Any) -> GraphBuilder[T]:
        """Add an edge to the builder.

        Auto-creates endpoint nodes if they do not exist.

        Args:
            source: Source node ID.
            target: Target node ID.
            weight: Edge weight.
            label: Optional display label.
            **metadata: Additional key-value pairs.

        Returns:
            Self for method chaining.
        """
        if source not in self._node_ids:
            self.add_node(source)
        if target not in self._node_ids:
            self.add_node(target)
        edge = Edge(source=source, target=target, weight=weight,
                    label=label, metadata=metadata)
        self._edges.append(edge)
        return self

    def add_path(self, *node_ids: NodeID, weight: Weight = 1.0) -> GraphBuilder[T]:
        """Add a path of connected nodes.

        Args:
            *node_ids: Sequence of node IDs forming a path.
            weight: Weight for all edges in the path.

        Returns:
            Self for method chaining.
        """
        for i in range(len(node_ids) - 1):
            self.add_edge(node_ids[i], node_ids[i + 1], weight=weight)
        return self

    def add_cycle(self, *node_ids: NodeID, weight: Weight = 1.0) -> GraphBuilder[T]:
        """Add a cycle of connected nodes.

        Args:
            *node_ids: Sequence of node IDs forming a cycle.
            weight: Weight for all edges in the cycle.

        Returns:
            Self for method chaining.
        """
        self.add_path(*node_ids, weight=weight)
        if len(node_ids) >= 2:
            self.add_edge(node_ids[-1], node_ids[0], weight=weight)
        return self

    def add_clique(self, *node_ids: NodeID, weight: Weight = 1.0) -> GraphBuilder[T]:
        """Add a complete subgraph (clique) among the given nodes.

        Args:
            *node_ids: Node IDs to connect pairwise.
            weight: Weight for all edges.

        Returns:
            Self for method chaining.
        """
        ids = list(node_ids)
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                self.add_edge(ids[i], ids[j], weight=weight)
        return self

    def build(self) -> Graph | DiGraph:
        """Build and return the graph.

        Returns:
            A Graph or DiGraph instance with all added nodes and edges.
        """
        if self._directed:
            g = DiGraph(name=self._name)
        else:
            g = Graph(name=self._name)
        for node in self._nodes:
            g.add_node(node)
        for edge in self._edges:
            g.add_edge(edge)
        return g

    def node_count(self) -> int:
        """Return the number of nodes added so far."""
        return len(self._nodes)

    def edge_count(self) -> int:
        """Return the number of edges added so far."""
        return len(self._edges)

    def reset(self) -> GraphBuilder[T]:
        """Clear all nodes and edges from the builder."""
        self._nodes.clear()
        self._edges.clear()
        self._node_ids.clear()
        return self

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs
