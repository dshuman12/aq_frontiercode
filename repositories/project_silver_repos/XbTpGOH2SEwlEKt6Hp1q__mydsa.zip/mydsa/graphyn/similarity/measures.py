"""Graph similarity measures."""
from __future__ import annotations
import math
from typing import Any
from graphyn.core.types import NodeID

def jaccard_similarity(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute Jaccard similarity between two nodes.

    Jaccard similarity is the ratio of common neighbors to the
    union of neighbor sets.

    Args:
        graph: A graph with neighbors() method.
        u: First node ID.
        v: Second node ID.

    Returns:
        Jaccard coefficient between 0.0 and 1.0.
    """
    neighbors_u = set(graph.neighbors(u))
    neighbors_v = set(graph.neighbors(v))
    intersection = neighbors_u & neighbors_v
    union = neighbors_u | neighbors_v
    if not union:
        return 0.0
    return len(intersection) / len(union)

def cosine_similarity(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute cosine similarity between two nodes.

    Based on the overlap of neighbor sets treated as binary vectors.

    Args:
        graph: A graph with neighbors() method.
        u: First node ID.
        v: Second node ID.

    Returns:
        Cosine similarity between 0.0 and 1.0.
    """
    neighbors_u = set(graph.neighbors(u))
    neighbors_v = set(graph.neighbors(v))
    if not neighbors_u or not neighbors_v:
        return 0.0
    intersection = len(neighbors_u & neighbors_v)
    magnitude = math.sqrt(len(neighbors_u)) * math.sqrt(len(neighbors_v))
    return intersection / magnitude

def overlap_coefficient(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute the overlap coefficient between two nodes.

    The overlap coefficient is the size of the intersection divided
    by the size of the smaller neighbor set.

    Args:
        graph: A graph with neighbors() method.
        u: First node ID.
        v: Second node ID.

    Returns:
        Overlap coefficient between 0.0 and 1.0.
    """
    neighbors_u = set(graph.neighbors(u))
    neighbors_v = set(graph.neighbors(v))
    if not neighbors_u or not neighbors_v:
        return 0.0
    intersection = len(neighbors_u & neighbors_v)
    return intersection / min(len(neighbors_u), len(neighbors_v))

def dice_similarity(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute Dice similarity coefficient between two nodes.

    Args:
        graph: A graph with neighbors() method.
        u: First node ID.
        v: Second node ID.

    Returns:
        Dice coefficient between 0.0 and 1.0.
    """
    neighbors_u = set(graph.neighbors(u))
    neighbors_v = set(graph.neighbors(v))
    total = len(neighbors_u) + len(neighbors_v)
    if total == 0:
        return 0.0
    intersection = len(neighbors_u & neighbors_v)
    return 2.0 * intersection / total

def graph_edit_distance_estimate(g1: Any, g2: Any) -> int:
    """Estimate graph edit distance using simple heuristic.

    Counts differences in node count and edge count as a
    lower bound on the true edit distance.

    Args:
        g1: First graph.
        g2: Second graph.

    Returns:
        Estimated edit distance (lower bound).
    """
    node_diff = abs(g1.node_count - g2.node_count)
    edge_diff = abs(g1.edge_count - g2.edge_count)
    return node_diff + edge_diff

def structural_equivalence(graph: Any, u: NodeID, v: NodeID) -> bool:
    """Check if two nodes are structurally equivalent.

    Two nodes are structurally equivalent if they share the exact
    same set of neighbors (excluding each other).

    Args:
        graph: A graph.
        u: First node.
        v: Second node.

    Returns:
        True if nodes have identical neighbor sets.
    """
    nu = set(graph.neighbors(u)) - {v}
    nv = set(graph.neighbors(v)) - {u}
    return nu == nv

def neighbor_overlap_matrix(graph: Any) -> dict[tuple[NodeID, NodeID], float]:
    """Compute pairwise neighbor overlap for all node pairs.

    Args:
        graph: A graph.

    Returns:
        Dictionary mapping (u, v) to Jaccard similarity.
    """
    nodes = graph.get_node_ids()
    result: dict[tuple[NodeID, NodeID], float] = {}
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            u, v = nodes[i], nodes[j]
            result[(u, v)] = jaccard_similarity(graph, u, v)
    return result

def simrank(graph: Any, u: NodeID, v: NodeID,
            decay: float = 0.8, max_iter: int = 10) -> float:
    """Compute SimRank similarity between two nodes.

    SimRank is based on the intuition that two nodes are similar
    if they are referenced by similar nodes.

    Args:
        graph: A graph.
        u: First node.
        v: Second node.
        decay: Decay factor (0 to 1).
        max_iter: Maximum iterations.

    Returns:
        SimRank score between 0 and 1.
    """
    if u == v:
        return 1.0
    nodes = graph.get_node_ids()
    sim: dict[tuple[NodeID, NodeID], float] = {}
    for a in nodes:
        for b in nodes:
            sim[(a, b)] = 1.0 if a == b else 0.0
    for _ in range(max_iter):
        new_sim: dict[tuple[NodeID, NodeID], float] = {}
        for a in nodes:
            for b in nodes:
                if a == b:
                    new_sim[(a, b)] = 1.0
                    continue
                na = graph.neighbors(a)
                nb = graph.neighbors(b)
                if not na or not nb:
                    new_sim[(a, b)] = 0.0
                    continue
                total = 0.0
                for pa in na:
                    for pb in nb:
                        total += sim.get((pa, pb), 0.0)
                new_sim[(a, b)] = decay * total / (len(na) * len(nb))
        sim = new_sim
    return sim.get((u, v), 0.0)

def role_similarity(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute role-based similarity using degree-sequence comparison.

    Two nodes are role-similar if their local neighborhoods have
    similar degree sequences.

    Args:
        graph: A graph.
        u: First node.
        v: Second node.

    Returns:
        Role similarity score between 0 and 1.
    """
    deg_u = sorted([len(graph.neighbors(nb)) for nb in graph.neighbors(u)])
    deg_v = sorted([len(graph.neighbors(nb)) for nb in graph.neighbors(v)])
    if not deg_u and not deg_v:
        return 1.0
    if not deg_u or not deg_v:
        return 0.0
    max_len = max(len(deg_u), len(deg_v))
    while len(deg_u) < max_len:
        deg_u.append(0)
    while len(deg_v) < max_len:
        deg_v.append(0)
    diff = sum(abs(a - b) for a, b in zip(deg_u, deg_v))
    max_possible = sum(max(a, b) for a, b in zip(deg_u, deg_v))
    if max_possible == 0:
        return 1.0
    return 1.0 - diff / max_possible

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
