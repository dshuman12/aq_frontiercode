"""Graph isomorphism checking utilities."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def is_isomorphic_candidate(g1: Any, g2: Any) -> bool:
    """Quick check if two graphs could be isomorphic.

    Performs fast invariant checks before expensive exact matching.
    Returns False if graphs are definitely not isomorphic, True if
    they might be (not a guarantee).

    Args:
        g1: First graph.
        g2: Second graph.

    Returns:
        True if the graphs pass basic invariant checks.
    """
    if g1.node_count != g2.node_count:
        return False
    if g1.edge_count != g2.edge_count:
        return False
    deg_seq_1 = _degree_sequence(g1)
    deg_seq_2 = _degree_sequence(g2)
    return deg_seq_1 == deg_seq_2

def _degree_sequence(graph: Any) -> list[int]:
    """Compute sorted degree sequence of a graph."""
    degrees = [len(graph.neighbors(n)) for n in graph.get_node_ids()]
    return sorted(degrees)

def degree_preserving_check(g1: Any, g2: Any) -> bool:
    """Check if graphs have matching degree histograms.

    Args:
        g1: First graph.
        g2: Second graph.

    Returns:
        True if degree distributions match.
    """
    hist1 = _degree_histogram(g1)
    hist2 = _degree_histogram(g2)
    return hist1 == hist2

def _degree_histogram(graph: Any) -> dict[int, int]:
    """Compute degree histogram."""
    hist: dict[int, int] = {}
    for n in graph.get_node_ids():
        deg = len(graph.neighbors(n))
        hist[deg] = hist.get(deg, 0) + 1
    return hist

def subgraph_isomorphism_candidates(g1: Any, g2: Any) -> bool:
    """Quick check if g1 could be a subgraph of g2.

    Args:
        g1: Potential subgraph.
        g2: Potential supergraph.

    Returns:
        True if basic invariants allow subgraph relationship.
    """
    if g1.node_count > g2.node_count:
        return False
    if g1.edge_count > g2.edge_count:
        return False
    max_deg_1 = max((len(g1.neighbors(n)) for n in g1.get_node_ids()), default=0)
    max_deg_2 = max((len(g2.neighbors(n)) for n in g2.get_node_ids()), default=0)
    return max_deg_1 <= max_deg_2

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
