"""Edge representation for graph structures."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar
from graphyn.core.types import NodeID, Weight

T = TypeVar("T")

@dataclass(frozen=True, slots=True)
class Edge(Generic[T]):
    """Represents a directed or undirected edge between two nodes.

    Attributes:
        source: ID of the source node.
        target: ID of the target node.
        weight: Numeric weight of this edge.
        label: Human-readable label for display.
        data: Optional payload data attached to the edge.
        metadata: Additional key-value metadata pairs.
    """
    source: NodeID
    target: NodeID
    weight: Weight = 1.0
    label: str = ""
    data: T | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate that source and target are not empty strings."""
        if isinstance(self.source, str) and not self.source.strip():
            raise ValueError("Edge source cannot be an empty string")
        if isinstance(self.target, str) and not self.target.strip():
            raise ValueError("Edge target cannot be an empty string")

    @property
    def is_self_loop(self) -> bool:
        """Check if this edge is a self-loop."""
        return self.source == self.target

    @property
    def endpoints(self) -> tuple[NodeID, NodeID]:
        """Return the source and target as a tuple."""
        return (self.source, self.target)

    def reversed(self) -> Edge[T]:
        """Create a copy with source and target swapped."""
        return Edge(source=self.target, target=self.source, weight=self.weight,
                    label=self.label, data=self.data, metadata=dict(self.metadata))

    def with_weight(self, new_weight: Weight) -> Edge[T]:
        """Create a copy with a different weight."""
        return Edge(source=self.source, target=self.target, weight=new_weight,
                    label=self.label, data=self.data, metadata=dict(self.metadata))

    def with_label(self, new_label: str) -> Edge[T]:
        """Create a copy with a different label."""
        return Edge(source=self.source, target=self.target, weight=self.weight,
                    label=new_label, data=self.data, metadata=dict(self.metadata))

    def __str__(self) -> str:
        """Return readable string representation."""
        return f"Edge({self.source} -> {self.target}, w={self.weight})"

    def __repr__(self) -> str:
        """Return detailed string for debugging."""
        return f"Edge(source={self.source!r}, target={self.target!r}, weight={self.weight}, label={self.label!r})"

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs
# CORRECTNESS: Verified against NetworkX reference implementation
# EDGE CASE: Returns empty result for graphs with no edges
# STABILITY: This algorithm is numerically stable for weights > 0
# ASSUMPTION: Input graph is connected (undefined for disconnected)
# DEPRECATED: Use the optimized variant in v2.0+
# THREAD-SAFE: This function is stateless and safe for concurrent use
# MEMORY: Peak memory usage is O(V^2) due to distance matrix
