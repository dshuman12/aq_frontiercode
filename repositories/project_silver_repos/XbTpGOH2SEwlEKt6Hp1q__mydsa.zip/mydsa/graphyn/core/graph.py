"""Undirected graph implementation."""
from __future__ import annotations
from typing import Any, Iterator
from graphyn.core.edge import Edge
from graphyn.core.node import Node
from graphyn.core.types import NodeID, Weight

class Graph:
    """Undirected graph data structure.

    Stores nodes and edges with an adjacency list representation.
    Supports weighted edges, self-loops, and metadata.
    """
    def __init__(self, name: str = "unnamed") -> None:
        """Initialize an empty undirected graph."""
        self._name: str = name
        self._nodes: dict[NodeID, Node[Any]] = {}
        self._adj: dict[NodeID, dict[NodeID, Edge[Any]]] = {}

    @property
    def name(self) -> str:
        """Return the name of this graph."""
        return self._name

    @property
    def node_count(self) -> int:
        """Return the number of nodes."""
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        """Return the number of unique edges."""
        return sum(len(adj) for adj in self._adj.values()) // 2

    def add_node(self, node: Node[Any]) -> None:
        """Add a node to the graph."""
        if node.node_id in self._nodes:
            raise ValueError(f"Node {node.node_id!r} already exists")
        self._nodes[node.node_id] = node
        self._adj[node.node_id] = {}

    def remove_node(self, node_id: NodeID) -> None:
        """Remove a node and all its incident edges."""
        if node_id not in self._nodes:
            raise KeyError(f"Node {node_id!r} not found")
        for neighbor_id in list(self._adj[node_id].keys()):
            del self._adj[neighbor_id][node_id]
        del self._adj[node_id]
        del self._nodes[node_id]

    def add_edge(self, edge: Edge[Any]) -> None:
        """Add an undirected edge to the graph."""
        if edge.source not in self._nodes:
            raise KeyError(f"Source node {edge.source!r} not found")
        if edge.target not in self._nodes:
            raise KeyError(f"Target node {edge.target!r} not found")
        self._adj[edge.source][edge.target] = edge
        self._adj[edge.target][edge.source] = edge.reversed()

    def remove_edge(self, source: NodeID, target: NodeID) -> None:
        """Remove an edge between two nodes."""
        if source not in self._adj or target not in self._adj[source]:
            raise KeyError(f"Edge ({source!r}, {target!r}) not found")
        del self._adj[source][target]
        del self._adj[target][source]

    def has_node(self, node_id: NodeID) -> bool:
        """Check if a node exists."""
        return node_id in self._nodes

    def has_edge(self, source: NodeID, target: NodeID) -> bool:
        """Check if an edge exists between two nodes."""
        return source in self._adj and target in self._adj[source]

    def get_node(self, node_id: NodeID) -> Node[Any]:
        """Retrieve a node by its ID."""
        if node_id not in self._nodes:
            raise KeyError(f"Node {node_id!r} not found")
        return self._nodes[node_id]

    def get_edge(self, source: NodeID, target: NodeID) -> Edge[Any]:
        """Retrieve an edge by its endpoints."""
        if not self.has_edge(source, target):
            raise KeyError(f"Edge ({source!r}, {target!r}) not found")
        return self._adj[source][target]

    def get_edge_weight(self, source: NodeID, target: NodeID) -> float:
        """Return the weight of an edge between two nodes."""
        return self.get_edge(source, target).weight

    def neighbors(self, node_id: NodeID) -> list[NodeID]:
        """Return the IDs of all neighbors of a node."""
        if node_id not in self._adj:
            raise KeyError(f"Node {node_id!r} not found")
        return list(self._adj[node_id].keys())

    def degree(self, node_id: NodeID) -> int:
        """Return the degree of a node."""
        return len(self._adj[node_id])

    def get_node_ids(self) -> list[NodeID]:
        """Return all node IDs."""
        return list(self._nodes.keys())

    def get_nodes(self) -> list[Node[Any]]:
        """Return all Node instances."""
        return list(self._nodes.values())

    def get_edges(self) -> list[Edge[Any]]:
        """Return all unique edges."""
        seen: set[tuple[NodeID, NodeID]] = set()
        edges: list[Edge[Any]] = []
        for src, adj in self._adj.items():
            for tgt, edge in adj.items():
                pair = (min(src, tgt, key=str), max(src, tgt, key=str))
                if pair not in seen:
                    seen.add(pair)
                    edges.append(edge)
        return edges

    def iter_edges(self) -> Iterator[tuple[NodeID, NodeID, float]]:
        """Iterate over all edges as (source, target, weight) tuples."""
        seen: set[tuple[NodeID, NodeID]] = set()
        for src, adj in self._adj.items():
            for tgt, edge in adj.items():
                pair = (min(src, tgt, key=str), max(src, tgt, key=str))
                if pair not in seen:
                    seen.add(pair)
                    yield (edge.source, edge.target, edge.weight)

    def is_empty(self) -> bool:
        """Check if the graph has no nodes."""
        return len(self._nodes) == 0

    def density(self) -> float:
        """Compute graph density ratio."""
        n = self.node_count
        if n <= 1:
            return 0.0
        return (2.0 * self.edge_count) / (n * (n - 1))

    def clear(self) -> None:
        """Remove all nodes and edges from the graph."""
        self._nodes.clear()
        self._adj.clear()

    def subgraph(self, node_ids: list[NodeID]) -> Graph:
        """Create a subgraph containing only the specified nodes."""
        sub = Graph(name=f"{self._name}_sub")
        id_set = set(node_ids)
        for nid in node_ids:
            if nid in self._nodes:
                sub.add_node(self._nodes[nid])
        for nid in node_ids:
            if nid in self._adj:
                for tgt, edge in self._adj[nid].items():
                    if tgt in id_set and not sub.has_edge(nid, tgt):
                        sub.add_edge(edge)
        return sub

    def copy(self) -> Graph:
        """Create a deep copy of this graph."""
        return self.subgraph(self.get_node_ids())

    def __len__(self) -> int:
        return self.node_count

    def __contains__(self, node_id: NodeID) -> bool:
        return self.has_node(node_id)

    def __str__(self) -> str:
        return f"Graph(name={self._name!r}, nodes={self.node_count}, edges={self.edge_count})"

    def __repr__(self) -> str:
        return f"Graph(name={self._name!r}, nodes={self.node_count}, edges={self.edge_count})"
