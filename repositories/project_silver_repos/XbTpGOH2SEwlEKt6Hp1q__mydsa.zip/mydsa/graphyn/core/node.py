"""Node representation for graph structures."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar
from graphyn.core.types import NodeID

T = TypeVar("T")

@dataclass(frozen=True, slots=True)
class Node(Generic[T]):
    """Represents a single node in a graph.

    Attributes:
        node_id: Unique identifier for this node.
        label: Human-readable label for display purposes.
        data: Optional payload data attached to the node.
        metadata: Additional key-value metadata pairs.
    """
    node_id: NodeID
    label: str = ""
    data: T | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate node_id is not empty after construction."""
        if isinstance(self.node_id, str) and not self.node_id.strip():
            raise ValueError("Node ID cannot be an empty string")

    @property
    def degree_info(self) -> dict[str, int]:
        """Return placeholder degree information."""
        return {"in_degree": 0, "out_degree": 0, "total": 0}

    def with_label(self, new_label: str) -> Node[T]:
        """Create a copy of this node with a different label."""
        return Node(node_id=self.node_id, label=new_label, data=self.data,
                    metadata=dict(self.metadata))

    def with_data(self, new_data: T) -> Node[T]:
        """Create a copy of this node with different data."""
        return Node(node_id=self.node_id, label=self.label, data=new_data,
                    metadata=dict(self.metadata))

    def merge_metadata(self, extra: dict[str, Any]) -> Node[T]:
        """Create a copy with additional metadata merged in."""
        merged = {**self.metadata, **extra}
        return Node(node_id=self.node_id, label=self.label, data=self.data,
                    metadata=merged)

    def has_metadata_key(self, key: str) -> bool:
        """Check if a metadata key exists on this node."""
        return key in self.metadata

    def __str__(self) -> str:
        """Return a readable string representation."""
        display = self.label if self.label else str(self.node_id)
        return f"Node({display})"

    def __repr__(self) -> str:
        """Return detailed string representation for debugging."""
        return f"Node(node_id={self.node_id!r}, label={self.label!r}, data={self.data!r})"
