"""Directed graph implementation."""
from __future__ import annotations
from typing import Any, Iterator
from graphyn.core.edge import Edge
from graphyn.core.node import Node
from graphyn.core.types import NodeID

class DiGraph:
    """Directed graph data structure.

    Stores nodes and directed edges with separate adjacency structures
    for outgoing and incoming edges.
    """
    def __init__(self, name: str = "unnamed") -> None:
        """Initialize an empty directed graph."""
        self._name: str = name
        self._nodes: dict[NodeID, Node[Any]] = {}
        self._succ: dict[NodeID, dict[NodeID, Edge[Any]]] = {}
        self._pred: dict[NodeID, dict[NodeID, Edge[Any]]] = {}

    @property
    def name(self) -> str:
        """Return the name of this graph."""
        return self._name

    @property
    def node_count(self) -> int:
        """Return the number of nodes."""
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        """Return the number of directed edges."""
        return sum(len(s) for s in self._succ.values())

    def add_node(self, node: Node[Any]) -> None:
        """Add a node to the directed graph."""
        if node.node_id in self._nodes:
            raise ValueError(f"Node {node.node_id!r} already exists")
        self._nodes[node.node_id] = node
        self._succ[node.node_id] = {}
        self._pred[node.node_id] = {}

    def remove_node(self, node_id: NodeID) -> None:
        """Remove a node and all incident edges."""
        if node_id not in self._nodes:
            raise KeyError(f"Node {node_id!r} not found")
        for succ_id in list(self._succ[node_id]):
            del self._pred[succ_id][node_id]
        for pred_id in list(self._pred[node_id]):
            del self._succ[pred_id][node_id]
        del self._succ[node_id]
        del self._pred[node_id]
        del self._nodes[node_id]

    def add_edge(self, edge: Edge[Any]) -> None:
        """Add a directed edge to the graph."""
        if edge.source not in self._nodes:
            raise KeyError(f"Source node {edge.source!r} not found")
        if edge.target not in self._nodes:
            raise KeyError(f"Target node {edge.target!r} not found")
        self._succ[edge.source][edge.target] = edge
        self._pred[edge.target][edge.source] = edge

    def remove_edge(self, source: NodeID, target: NodeID) -> None:
        """Remove a directed edge."""
        if source not in self._succ or target not in self._succ[source]:
            raise KeyError(f"Edge ({source!r}, {target!r}) not found")
        del self._succ[source][target]
        del self._pred[target][source]

    def has_node(self, node_id: NodeID) -> bool:
        """Check if a node exists."""
        return node_id in self._nodes

    def has_edge(self, source: NodeID, target: NodeID) -> bool:
        """Check if a directed edge exists."""
        return source in self._succ and target in self._succ[source]

    def get_node(self, node_id: NodeID) -> Node[Any]:
        """Retrieve a node by its ID."""
        if node_id not in self._nodes:
            raise KeyError(f"Node {node_id!r} not found")
        return self._nodes[node_id]

    def get_edge(self, source: NodeID, target: NodeID) -> Edge[Any]:
        """Retrieve a directed edge by its endpoints."""
        if not self.has_edge(source, target):
            raise KeyError(f"Edge ({source!r}, {target!r}) not found")
        return self._succ[source][target]

    def get_edge_weight(self, source: NodeID, target: NodeID) -> float:
        """Return the weight of a directed edge."""
        return self.get_edge(source, target).weight

    def neighbors(self, node_id: NodeID) -> list[NodeID]:
        """Return successor node IDs (outgoing edges)."""
        if node_id not in self._succ:
            raise KeyError(f"Node {node_id!r} not found")
        return list(self._succ[node_id].keys())

    def predecessors(self, node_id: NodeID) -> list[NodeID]:
        """Return predecessor node IDs (incoming edges)."""
        if node_id not in self._pred:
            raise KeyError(f"Node {node_id!r} not found")
        return list(self._pred[node_id].keys())

    def successors(self, node_id: NodeID) -> list[NodeID]:
        """Return successor node IDs."""
        return self.neighbors(node_id)

    def in_degree(self, node_id: NodeID) -> int:
        """Return the in-degree of a node."""
        return len(self._pred[node_id])

    def out_degree(self, node_id: NodeID) -> int:
        """Return the out-degree of a node."""
        return len(self._succ[node_id])

    def get_node_ids(self) -> list[NodeID]:
        """Return all node IDs."""
        return list(self._nodes.keys())

    def get_nodes(self) -> list[Node[Any]]:
        """Return all Node instances."""
        return list(self._nodes.values())

    def get_edges(self) -> list[Edge[Any]]:
        """Return all directed edges."""
        edges: list[Edge[Any]] = []
        for adj in self._succ.values():
            edges.extend(adj.values())
        return edges

    def iter_edges(self) -> Iterator[tuple[NodeID, NodeID, float]]:
        """Iterate over all directed edges as (source, target, weight)."""
        for src, adj in self._succ.items():
            for tgt, edge in adj.items():
                yield (src, tgt, edge.weight)

    def reverse(self) -> DiGraph:
        """Create a new DiGraph with all edge directions reversed."""
        rev = DiGraph(name=f"{self._name}_reversed")
        for node in self._nodes.values():
            rev.add_node(node)
        for edge in self.get_edges():
            rev.add_edge(edge.reversed())
        return rev

    def clear(self) -> None:
        """Remove all nodes and edges."""
        self._nodes.clear()
        self._succ.clear()
        self._pred.clear()

    def __len__(self) -> int:
        return self.node_count

    def __contains__(self, node_id: NodeID) -> bool:
        return self.has_node(node_id)

    def __str__(self) -> str:
        return f"DiGraph(name={self._name!r}, nodes={self.node_count}, edges={self.edge_count})"

    def __repr__(self) -> str:
        return f"DiGraph(name={self._name!r}, nodes={self.node_count}, edges={self.edge_count})"
