"""Event types for streaming graph updates."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any
from graphyn.core.types import NodeID

class EventType(Enum):
    """Types of graph mutation events."""
    NODE_ADD = auto()
    NODE_REMOVE = auto()
    EDGE_ADD = auto()
    EDGE_REMOVE = auto()
    WEIGHT_UPDATE = auto()
    LABEL_UPDATE = auto()
    BATCH = auto()

@dataclass(frozen=True, slots=True)
class GraphEvent:
    """Represents a single graph mutation event.

    Attributes:
        event_type: The type of graph mutation.
        node_id: Target node ID (for node events).
        source: Source node ID (for edge events).
        target: Target node ID (for edge events).
        weight: New weight value (for weight updates).
        label: New label string (for label updates).
        timestamp: Event timestamp in seconds.
        metadata: Additional event metadata.
    """
    event_type: EventType
    node_id: NodeID | None = None
    source: NodeID | None = None
    target: NodeID | None = None
    weight: float | None = None
    label: str | None = None
    timestamp: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def add_node(cls, node_id: NodeID, timestamp: float = 0.0,
                 **kwargs: Any) -> GraphEvent:
        """Create a node addition event."""
        return cls(EventType.NODE_ADD, node_id=node_id,
                  timestamp=timestamp, metadata=kwargs)

    @classmethod
    def remove_node(cls, node_id: NodeID, timestamp: float = 0.0) -> GraphEvent:
        """Create a node removal event."""
        return cls(EventType.NODE_REMOVE, node_id=node_id, timestamp=timestamp)

    @classmethod
    def add_edge(cls, source: NodeID, target: NodeID,
                 weight: float = 1.0, timestamp: float = 0.0) -> GraphEvent:
        """Create an edge addition event."""
        return cls(EventType.EDGE_ADD, source=source, target=target,
                  weight=weight, timestamp=timestamp)

    @classmethod
    def remove_edge(cls, source: NodeID, target: NodeID,
                    timestamp: float = 0.0) -> GraphEvent:
        """Create an edge removal event."""
        return cls(EventType.EDGE_REMOVE, source=source, target=target,
                  timestamp=timestamp)

    @classmethod
    def update_weight(cls, source: NodeID, target: NodeID,
                      weight: float, timestamp: float = 0.0) -> GraphEvent:
        """Create a weight update event."""
        return cls(EventType.WEIGHT_UPDATE, source=source, target=target,
                  weight=weight, timestamp=timestamp)

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
