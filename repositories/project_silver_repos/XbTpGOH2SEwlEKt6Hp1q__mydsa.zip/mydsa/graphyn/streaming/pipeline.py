"""Streaming graph update pipeline."""
from __future__ import annotations
from typing import Any, Callable
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.types import NodeID
from graphyn.streaming.events import GraphEvent, EventType

EventHandler = Callable[[GraphEvent, Any], None]

class StreamPipeline:
    """Pipeline for processing streaming graph updates.

    Applies graph events sequentially and invokes registered
    handlers for each event type. Supports event filtering,
    batching, and rollback capabilities.

    Attributes:
        graph: The graph being updated.
    """
    def __init__(self, graph: Graph | DiGraph) -> None:
        """Initialize the pipeline with a target graph.

        Args:
            graph: The graph to apply events to.
        """
        self._graph: Graph | DiGraph = graph
        self._handlers: dict[EventType, list[EventHandler]] = {}
        self._event_log: list[GraphEvent] = []
        self._event_count: int = 0
        self._error_count: int = 0
        self._filters: list[Callable[[GraphEvent], bool]] = []

    @property
    def graph(self) -> Graph | DiGraph:
        """Return the underlying graph."""
        return self._graph

    @property
    def event_count(self) -> int:
        """Return total number of processed events."""
        return self._event_count

    @property
    def error_count(self) -> int:
        """Return total number of failed events."""
        return self._error_count

    def register_handler(self, event_type: EventType,
                         handler: EventHandler) -> None:
        """Register a handler for a specific event type.

        Args:
            event_type: The event type to handle.
            handler: Callable receiving (event, graph).
        """
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def add_filter(self, predicate: Callable[[GraphEvent], bool]) -> None:
        """Add an event filter predicate.

        Events that fail the predicate will be skipped.

        Args:
            predicate: Function returning True for events to process.
        """
        self._filters.append(predicate)

    def process_event(self, event: GraphEvent) -> bool:
        """Process a single graph event.

        Applies the mutation to the graph and invokes handlers.

        Args:
            event: The event to process.

        Returns:
            True if event was processed successfully.
        """
        for f in self._filters:
            if not f(event):
                return False
        try:
            self._apply_event(event)
            self._event_log.append(event)
            self._event_count += 1
            for handler in self._handlers.get(event.event_type, []):
                handler(event, self._graph)
            return True
        except (KeyError, ValueError):
            self._error_count += 1
            return False

    def process_batch(self, events: list[GraphEvent]) -> int:
        """Process a batch of events.

        Args:
            events: List of events to process.

        Returns:
            Number of events successfully processed.
        """
        count = 0
        for event in events:
            if self.process_event(event):
                count += 1
        return count

    def _apply_event(self, event: GraphEvent) -> None:
        """Apply a single event mutation to the graph."""
        if event.event_type == EventType.NODE_ADD:
            if event.node_id is not None:
                node = Node(node_id=event.node_id)
                self._graph.add_node(node)
        elif event.event_type == EventType.NODE_REMOVE:
            if event.node_id is not None:
                self._graph.remove_node(event.node_id)
        elif event.event_type == EventType.EDGE_ADD:
            if event.source is not None and event.target is not None:
                w = event.weight if event.weight is not None else 1.0
                edge = Edge(source=event.source, target=event.target, weight=w)
                self._graph.add_edge(edge)
        elif event.event_type == EventType.EDGE_REMOVE:
            if event.source is not None and event.target is not None:
                self._graph.remove_edge(event.source, event.target)
        elif event.event_type == EventType.WEIGHT_UPDATE:
            if event.source is not None and event.target is not None:
                self._graph.remove_edge(event.source, event.target)
                w = event.weight if event.weight is not None else 1.0
                edge = Edge(source=event.source, target=event.target, weight=w)
                self._graph.add_edge(edge)

    def get_event_log(self) -> list[GraphEvent]:
        """Return the event processing log."""
        return list(self._event_log)

    def get_stats(self) -> dict[str, int]:
        """Return pipeline processing statistics.

        Returns:
            Dictionary with processed, errors, and filtered counts.
        """
        return {
            "processed": self._event_count,
            "errors": self._error_count,
            "log_size": len(self._event_log),
            "node_count": self._graph.node_count,
            "edge_count": self._graph.edge_count,
        }

    def clear_log(self) -> None:
        """Clear the event processing log."""
        self._event_log.clear()

    def clear_handlers(self) -> None:
        """Remove all registered handlers."""
        self._handlers.clear()

    def reset_stats(self) -> None:
        """Reset processing statistics."""
        self._event_count = 0
        self._error_count = 0
