"""JSON serialization for graph structures."""
from __future__ import annotations
import json
from typing import Any
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge

def to_json(graph: Any, indent: int = 2) -> str:
    """Serialize a graph to a JSON string.

    Captures all nodes with metadata and all edges with weights.
    The output format preserves directed/undirected information
    and the graph name.

    Args:
        graph: A Graph or DiGraph instance.
        indent: JSON indentation level.

    Returns:
        JSON string representing the graph.
    """
    is_directed = hasattr(graph, "_succ")
    data: dict[str, Any] = {
        "name": graph.name,
        "directed": is_directed,
        "nodes": [],
        "edges": [],
    }
    for node in graph.get_nodes():
        node_data: dict[str, Any] = {
            "id": node.node_id,
            "label": node.label,
        }
        if node.metadata:
            node_data["metadata"] = node.metadata
        data["nodes"].append(node_data)
    for edge in graph.get_edges():
        edge_data: dict[str, Any] = {
            "source": edge.source,
            "target": edge.target,
            "weight": edge.weight,
        }
        if edge.label:
            edge_data["label"] = edge.label
        data["edges"].append(edge_data)
    return json.dumps(data, indent=indent, default=str)

def from_json(json_str: str) -> Graph | DiGraph:
    """Deserialize a graph from a JSON string.

    Reconstructs the full graph including node metadata,
    edge weights, and graph directionality.

    Args:
        json_str: JSON string produced by to_json().

    Returns:
        A Graph or DiGraph instance.
    """
    data = json.loads(json_str)
    directed = data.get("directed", False)
    name = data.get("name", "unnamed")
    if directed:
        g = DiGraph(name=name)
    else:
        g = Graph(name=name)
    for node_data in data.get("nodes", []):
        node = Node(
            node_id=node_data["id"],
            label=node_data.get("label", ""),
            metadata=node_data.get("metadata", {}),
        )
        g.add_node(node)
    for edge_data in data.get("edges", []):
        edge = Edge(
            source=edge_data["source"],
            target=edge_data["target"],
            weight=edge_data.get("weight", 1.0),
            label=edge_data.get("label", ""),
        )
        g.add_edge(edge)
    return g

def to_json_file(graph: Any, filepath: str, indent: int = 2) -> None:
    """Write graph to a JSON file.

    Args:
        graph: A Graph or DiGraph instance.
        filepath: Path to the output file.
        indent: JSON indentation level.
    """
    json_str = to_json(graph, indent=indent)
    with open(filepath, "w") as f:
        f.write(json_str)

def from_json_file(filepath: str) -> Graph | DiGraph:
    """Load a graph from a JSON file.

    Args:
        filepath: Path to the JSON file.

    Returns:
        A Graph or DiGraph instance.
    """
    with open(filepath) as f:
        return from_json(f.read())

def to_adjacency_json(graph: Any, indent: int = 2) -> str:
    """Serialize graph as adjacency list JSON.

    Alternative format that represents the graph as an adjacency list
    rather than separate node/edge lists.

    Args:
        graph: A Graph or DiGraph instance.
        indent: JSON indentation level.

    Returns:
        JSON string with adjacency list format.
    """
    adjacency: dict[str, list[dict[str, Any]]] = {}
    for node in graph.get_nodes():
        nid = str(node.node_id)
        adjacency[nid] = []
        for nb in graph.neighbors(node.node_id):
            entry: dict[str, Any] = {"target": nb}
            if graph.has_edge(node.node_id, nb):
                entry["weight"] = graph.get_edge_weight(node.node_id, nb)
            adjacency[nid].append(entry)
    return json.dumps(adjacency, indent=indent, default=str)

def to_edge_list_json(graph: Any, indent: int = 2) -> str:
    """Serialize graph as a simple edge list JSON array.

    Args:
        graph: A Graph or DiGraph instance.
        indent: JSON indentation level.

    Returns:
        JSON array of edge objects.
    """
    edges: list[dict[str, Any]] = []
    for edge in graph.get_edges():
        edges.append({
            "source": edge.source,
            "target": edge.target,
            "weight": edge.weight,
        })
    return json.dumps(edges, indent=indent, default=str)

def graph_summary_json(graph: Any) -> str:
    """Generate a JSON summary of graph statistics.

    Args:
        graph: A Graph or DiGraph instance.

    Returns:
        JSON string with graph statistics.
    """
    is_directed = hasattr(graph, "_succ")
    summary = {
        "name": graph.name,
        "directed": is_directed,
        "node_count": graph.node_count,
        "edge_count": graph.edge_count,
        "density": (2.0 * graph.edge_count) / (graph.node_count * (graph.node_count - 1))
                   if graph.node_count > 1 else 0.0,
    }
    return json.dumps(summary, indent=2)

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs
