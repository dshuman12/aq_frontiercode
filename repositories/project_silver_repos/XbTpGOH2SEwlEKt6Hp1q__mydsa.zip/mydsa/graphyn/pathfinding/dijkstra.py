"""Dijkstra's shortest path algorithm."""
from __future__ import annotations
import heapq
from typing import Any
from graphyn.core.types import NodeID

def dijkstra(graph: Any, source: NodeID) -> tuple[dict[NodeID, float], dict[NodeID, NodeID | None]]:
    """Compute shortest paths from source to all reachable nodes.

    Uses a priority queue to explore nodes in order of increasing
    distance. Does not support negative edge weights.

    Args:
        graph: A graph with neighbors(), get_edge_weight(), get_node_ids(), has_node().
        source: The starting node ID.

    Returns:
        Tuple of (distances, predecessors) dictionaries.

    Raises:
        KeyError: If source node does not exist.
        ValueError: If a negative edge weight is encountered.
    """
    if not graph.has_node(source):
        raise KeyError(f"Source node {source!r} not found")
    dist: dict[NodeID, float] = {source: 0.0}
    prev: dict[NodeID, NodeID | None] = {source: None}
    visited: set[NodeID] = set()
    heap: list[tuple[float, NodeID]] = [(0.0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if u in visited:
            continue
        visited.add(u)
        for v in graph.neighbors(u):
            w = graph.get_edge_weight(u, v)
            if w < 0:
                raise ValueError(f"Negative edge weight {w} on ({u}, {v})")
            alt = d + w
            if v not in dist or alt < dist[v]:
                dist[v] = alt
                prev[v] = u
                heapq.heappush(heap, (alt, v))
    return dist, prev

def dijkstra_path(graph: Any, source: NodeID,
                  target: NodeID) -> tuple[list[NodeID], float]:
    """Find shortest path between two nodes using Dijkstra.

    Args:
        graph: A graph with neighbors() and get_edge_weight().
        source: Start node ID.
        target: End node ID.

    Returns:
        Tuple of (path as list of node IDs, total distance).

    Raises:
        KeyError: If either node does not exist.
        ValueError: If no path exists between the nodes.
    """
    dist, prev = dijkstra(graph, source)
    if target not in dist:
        raise ValueError(f"No path from {source!r} to {target!r}")
    path: list[NodeID] = []
    current: NodeID | None = target
    while current is not None:
        path.append(current)
        current = prev[current]
    path.reverse()
    return path, dist[target]

def dijkstra_all_pairs(graph: Any) -> dict[NodeID, dict[NodeID, float]]:
    """Compute all-pairs shortest paths using repeated Dijkstra.

    Args:
        graph: A graph object supporting the traversable interface.

    Returns:
        Nested dictionary mapping source -> target -> distance.
    """
    result: dict[NodeID, dict[NodeID, float]] = {}
    for node in graph.get_node_ids():
        distances, _ = dijkstra(graph, node)
        result[node] = distances
    return result
