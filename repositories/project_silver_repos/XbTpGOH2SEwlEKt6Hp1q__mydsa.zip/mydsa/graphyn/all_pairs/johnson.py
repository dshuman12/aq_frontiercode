"""Johnson's all-pairs shortest path algorithm."""
from __future__ import annotations
import heapq
from typing import Any
from graphyn.core.types import NodeID

class NegativeCycleError(Exception):
    """Raised when a negative cycle is detected."""
    pass

def johnson_all_pairs(graph: Any) -> dict[NodeID, dict[NodeID, float]]:
    """Compute all-pairs shortest paths using Johnson's algorithm.

    Combines Bellman-Ford reweighting with repeated Dijkstra.
    More efficient than Floyd-Warshall on sparse graphs:
    O(V^2 log V + VE) vs O(V^3).

    Args:
        graph: A directed graph with get_node_ids(), iter_edges(),
               neighbors(), get_edge_weight().

    Returns:
        Nested dictionary of shortest distances.

    Raises:
        NegativeCycleError: If the graph contains a negative cycle.
    """
    nodes = graph.get_node_ids()
    if not nodes:
        return {}
    sentinel = "__johnson_source__"
    bf_dist: dict[Any, float] = {sentinel: 0.0}
    for n in nodes:
        bf_dist[n] = float("inf")
    edges: list[tuple[Any, Any, float]] = [(sentinel, n, 0.0) for n in nodes]
    for u, v, w in graph.iter_edges():
        edges.append((u, v, w))
    n_total = len(nodes) + 1
    for _ in range(n_total - 1):
        for u, v, w in edges:
            if bf_dist.get(u, float("inf")) + w < bf_dist.get(v, float("inf")):
                bf_dist[v] = bf_dist[u] + w
    for u, v, w in edges:
        if bf_dist.get(u, float("inf")) + w < bf_dist.get(v, float("inf")):
            raise NegativeCycleError("Graph contains a negative weight cycle")
    h: dict[NodeID, float] = {n: bf_dist[n] for n in nodes}
    result: dict[NodeID, dict[NodeID, float]] = {}
    for source in nodes:
        dist: dict[NodeID, float] = {n: float("inf") for n in nodes}
        dist[source] = 0.0
        heap: list[tuple[float, NodeID]] = [(0.0, source)]
        visited: set[NodeID] = set()
        while heap:
            d, u = heapq.heappop(heap)
            if u in visited:
                continue
            visited.add(u)
            for v in graph.neighbors(u):
                w = graph.get_edge_weight(u, v)
                reweighted = w + h.get(u, 0) - h.get(v, 0)
                new_dist = d + reweighted
                if new_dist < dist[v]:
                    dist[v] = new_dist
                    heapq.heappush(heap, (new_dist, v))
        result[source] = {}
        for v in nodes:
            if dist[v] < float("inf"):
                result[source][v] = dist[v] - h.get(source, 0) + h.get(v, 0)
            else:
                result[source][v] = float("inf")
    return result

def johnson_path(graph: Any, source: NodeID,
                 target: NodeID) -> tuple[list[NodeID], float] | None:
    """Find shortest path between two nodes using Johnson's algorithm.

    Args:
        graph: A directed graph.
        source: Start node.
        target: End node.

    Returns:
        Tuple of (path, distance) or None if no path exists.
    """
    all_dists = johnson_all_pairs(graph)
    if source not in all_dists or target not in all_dists[source]:
        return None
    dist = all_dists[source][target]
    if dist == float("inf"):
        return None
    path = _reconstruct_johnson_path(graph, all_dists, source, target)
    return path, dist

def _reconstruct_johnson_path(graph: Any,
                               all_dists: dict[NodeID, dict[NodeID, float]],
                               source: NodeID,
                               target: NodeID) -> list[NodeID]:
    """Reconstruct path from all-pairs distance matrix."""
    path: list[NodeID] = [source]
    current = source
    max_steps = len(all_dists)
    while current != target:
        best_next: NodeID | None = None
        best_total = float("inf")
        for nb in graph.neighbors(current):
            w = graph.get_edge_weight(current, nb)
            if nb in all_dists and target in all_dists[nb]:
                total = w + all_dists[nb][target]
                if total < best_total:
                    best_total = total
                    best_next = nb
        if best_next is None:
            break
        path.append(best_next)
        current = best_next
        max_steps -= 1
        if max_steps <= 0:
            break
    return path

def johnson_eccentricities(graph: Any) -> dict[NodeID, float]:
    """Compute eccentricity for all nodes using Johnson's algorithm.

    Args:
        graph: A directed graph.

    Returns:
        Dictionary mapping nodes to eccentricity values.
    """
    all_dists = johnson_all_pairs(graph)
    result: dict[NodeID, float] = {}
    for u in all_dists:
        max_d = 0.0
        for v in all_dists[u]:
            if u != v and all_dists[u][v] != float("inf"):
                max_d = max(max_d, all_dists[u][v])
        result[u] = max_d
    return result

def johnson_diameter(graph: Any) -> float:
    """Compute graph diameter using Johnson's algorithm.

    Args:
        graph: A directed graph.

    Returns:
        Diameter of the graph.
    """
    eccs = johnson_eccentricities(graph)
    return max(eccs.values()) if eccs else 0.0

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
