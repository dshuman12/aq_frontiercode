"""Minimum cut computation."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID
from graphyn.flow.edmonds_karp import edmonds_karp

def min_cut(graph: Any, source: NodeID,
            sink: NodeID) -> tuple[float, set[NodeID], set[NodeID]]:
    """Compute the minimum s-t cut using max-flow min-cut theorem.

    The minimum cut partitions the graph into two sets S and T such
    that source is in S, sink is in T, and the total capacity of
    edges crossing from S to T is minimized.

    Args:
        graph: A directed graph.
        source: Source node ID.
        sink: Sink node ID.

    Returns:
        Tuple of (cut_value, S_partition, T_partition).
    """
    max_flow_val, flow_dict = edmonds_karp(graph, source, sink)
    nodes = graph.get_node_ids()
    capacity: dict[NodeID, dict[NodeID, float]] = {}
    for n in nodes:
        capacity[n] = {}
    for u, v, w in graph.iter_edges():
        capacity[u][v] = capacity[u].get(v, 0) + w
        if v not in capacity:
            capacity[v] = {}
        if u not in capacity[v]:
            capacity[v][u] = 0
    flow: dict[NodeID, dict[NodeID, float]] = {}
    for n in nodes:
        flow[n] = {m: 0.0 for m in nodes}
    for (u, v), f in flow_dict.items():
        flow[u][v] = f
    reachable: set[NodeID] = set()
    queue: deque[NodeID] = deque([source])
    reachable.add(source)
    while queue:
        u = queue.popleft()
        for v in nodes:
            if v in reachable:
                continue
            cap = capacity.get(u, {}).get(v, 0)
            fl = flow[u].get(v, 0)
            if cap - fl > 0:
                reachable.add(v)
                queue.append(v)
    s_partition = reachable
    t_partition = set(nodes) - reachable
    return max_flow_val, s_partition, t_partition

def min_cut_edges(graph: Any, source: NodeID,
                  sink: NodeID) -> list[tuple[NodeID, NodeID, float]]:
    """Return the edges that form the minimum cut.

    Args:
        graph: A directed graph.
        source: Source node ID.
        sink: Sink node ID.

    Returns:
        List of (u, v, capacity) tuples crossing the min cut.
    """
    _, s_part, _ = min_cut(graph, source, sink)
    cut_edges: list[tuple[NodeID, NodeID, float]] = []
    for u, v, w in graph.iter_edges():
        if u in s_part and v not in s_part:
            cut_edges.append((u, v, w))
    return cut_edges
