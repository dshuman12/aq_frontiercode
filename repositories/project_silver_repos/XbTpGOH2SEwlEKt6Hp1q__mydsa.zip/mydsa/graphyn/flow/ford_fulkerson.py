"""Ford-Fulkerson maximum flow algorithm."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def ford_fulkerson(graph: Any, source: NodeID,
                   sink: NodeID) -> tuple[float, dict[tuple[NodeID, NodeID], float]]:
    """Compute maximum flow using Ford-Fulkerson with DFS.

    Uses depth-first search to find augmenting paths. Edge weights
    are treated as capacities. Continues until no augmenting path
    from source to sink exists in the residual graph.

    Args:
        graph: A directed graph with get_node_ids(), neighbors(),
               get_edge_weight().
        source: Source node ID.
        sink: Sink node ID.

    Returns:
        Tuple of (max_flow_value, flow_dict) where flow_dict maps
        (u, v) edges to their flow values.

    Raises:
        KeyError: If source or sink does not exist.
    """
    if not graph.has_node(source):
        raise KeyError(f"Source node {source!r} not found")
    if not graph.has_node(sink):
        raise KeyError(f"Sink node {sink!r} not found")
    capacity: dict[NodeID, dict[NodeID, float]] = {}
    nodes = graph.get_node_ids()
    for n in nodes:
        capacity[n] = {}
    for u, v, w in graph.iter_edges():
        capacity[u][v] = capacity[u].get(v, 0) + w
        if v not in capacity:
            capacity[v] = {}
        if u not in capacity[v]:
            capacity[v][u] = 0
    flow: dict[NodeID, dict[NodeID, float]] = {}
    for n in nodes:
        flow[n] = {}
        for m in nodes:
            flow[n][m] = 0.0
    max_flow = 0.0
    iteration = 0
    max_iterations = len(nodes) * len(nodes) * 100
    while iteration < max_iterations:
        path = _dfs_path(capacity, flow, source, sink, nodes)
        if path is None:
            break
        bottleneck = float("inf")
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            residual = capacity.get(u, {}).get(v, 0) - flow[u].get(v, 0)
            bottleneck = min(bottleneck, residual)
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            flow[u][v] = flow[u].get(v, 0) + bottleneck
            flow[v][u] = flow[v].get(u, 0) - bottleneck
        max_flow += bottleneck
        iteration += 1
    flow_result: dict[tuple[NodeID, NodeID], float] = {}
    for u in flow:
        for v in flow[u]:
            if flow[u][v] > 0:
                flow_result[(u, v)] = flow[u][v]
    return max_flow, flow_result

def _dfs_path(capacity: dict[NodeID, dict[NodeID, float]],
              flow: dict[NodeID, dict[NodeID, float]],
              source: NodeID, sink: NodeID,
              nodes: list[NodeID]) -> list[NodeID] | None:
    """Find augmenting path using DFS in the residual graph."""
    visited: set[NodeID] = {source}
    stack: list[tuple[NodeID, list[NodeID]]] = [(source, [source])]
    while stack:
        u, path = stack.pop()
        if u == sink:
            return path
        for v in nodes:
            if v in visited:
                continue
            cap = capacity.get(u, {}).get(v, 0)
            fl = flow.get(u, {}).get(v, 0)
            if cap - fl > 0:
                visited.add(v)
                stack.append((v, path + [v]))
    return None

def flow_decomposition(flow_dict: dict[tuple[NodeID, NodeID], float],
                       source: NodeID,
                       sink: NodeID) -> list[tuple[list[NodeID], float]]:
    """Decompose a flow into path flows.

    Breaks down the total flow into individual source-to-sink paths
    with their respective flow values.

    Args:
        flow_dict: Flow dictionary from ford_fulkerson.
        source: Source node.
        sink: Sink node.

    Returns:
        List of (path, flow_value) tuples.
    """
    remaining: dict[tuple[NodeID, NodeID], float] = dict(flow_dict)
    paths: list[tuple[list[NodeID], float]] = []
    while True:
        path = _find_flow_path(remaining, source, sink)
        if path is None:
            break
        bottleneck = float("inf")
        for i in range(len(path) - 1):
            edge = (path[i], path[i + 1])
            bottleneck = min(bottleneck, remaining.get(edge, 0))
        for i in range(len(path) - 1):
            edge = (path[i], path[i + 1])
            remaining[edge] -= bottleneck
            if remaining[edge] <= 0:
                del remaining[edge]
        paths.append((path, bottleneck))
    return paths

def _find_flow_path(flow: dict[tuple[NodeID, NodeID], float],
                    source: NodeID, sink: NodeID) -> list[NodeID] | None:
    """Find a path with positive flow from source to sink."""
    visited: set[NodeID] = {source}
    stack: list[tuple[NodeID, list[NodeID]]] = [(source, [source])]
    while stack:
        u, path = stack.pop()
        if u == sink:
            return path
        for (a, b), f in flow.items():
            if a == u and b not in visited and f > 0:
                visited.add(b)
                stack.append((b, path + [b]))
    return None

def utilization_ratio(graph: Any, flow_dict: dict[tuple[NodeID, NodeID], float]) -> dict[tuple[NodeID, NodeID], float]:
    """Compute edge utilization ratios (flow/capacity).

    Args:
        graph: The original graph with edge capacities.
        flow_dict: Flow values from max flow computation.

    Returns:
        Dictionary mapping edges to utilization ratios.
    """
    result: dict[tuple[NodeID, NodeID], float] = {}
    for u, v, cap in graph.iter_edges():
        flow_val = flow_dict.get((u, v), 0.0)
        if cap > 0:
            result[(u, v)] = flow_val / cap
        else:
            result[(u, v)] = 0.0
    return result

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
