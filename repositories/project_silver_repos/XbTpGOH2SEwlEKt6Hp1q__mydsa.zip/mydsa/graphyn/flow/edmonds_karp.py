"""Edmonds-Karp maximum flow algorithm."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID

def edmonds_karp(graph: Any, source: NodeID,
                 sink: NodeID) -> tuple[float, dict[tuple[NodeID, NodeID], float]]:
    """Compute maximum flow using Edmonds-Karp (BFS-based Ford-Fulkerson).

    Uses BFS to find shortest augmenting paths, guaranteeing
    O(VE^2) time complexity.

    Args:
        graph: A directed graph with get_node_ids(), neighbors(),
               get_edge_weight().
        source: Source node ID.
        sink: Sink node ID.

    Returns:
        Tuple of (max_flow_value, flow_dict).
    """
    if not graph.has_node(source):
        raise KeyError(f"Source {source!r} not found")
    if not graph.has_node(sink):
        raise KeyError(f"Sink {sink!r} not found")
    nodes = graph.get_node_ids()
    capacity: dict[NodeID, dict[NodeID, float]] = {}
    for n in nodes:
        capacity[n] = {}
    for u, v, w in graph.iter_edges():
        capacity[u][v] = capacity[u].get(v, 0) + w
        if v not in capacity:
            capacity[v] = {}
        if u not in capacity[v]:
            capacity[v][u] = 0
    flow: dict[NodeID, dict[NodeID, float]] = {}
    for n in nodes:
        flow[n] = {m: 0.0 for m in nodes}
    max_flow = 0.0
    while True:
        parent = _bfs_augmenting(capacity, flow, source, sink, nodes)
        if parent is None:
            break
        bottleneck = float("inf")
        v = sink
        while v != source:
            u = parent[v]
            residual = capacity.get(u, {}).get(v, 0) - flow[u][v]
            bottleneck = min(bottleneck, residual)
            v = u
        v = sink
        while v != source:
            u = parent[v]
            flow[u][v] += bottleneck
            flow[v][u] -= bottleneck
            v = u
        max_flow += bottleneck
    flow_result: dict[tuple[NodeID, NodeID], float] = {}
    for u in flow:
        for v in flow[u]:
            if flow[u][v] > 0:
                flow_result[(u, v)] = flow[u][v]
    return max_flow, flow_result

def _bfs_augmenting(capacity: dict[NodeID, dict[NodeID, float]],
                    flow: dict[NodeID, dict[NodeID, float]],
                    source: NodeID, sink: NodeID,
                    nodes: list[NodeID]) -> dict[NodeID, NodeID] | None:
    """BFS to find shortest augmenting path."""
    visited: set[NodeID] = {source}
    parent: dict[NodeID, NodeID] = {}
    queue: deque[NodeID] = deque([source])
    while queue:
        u = queue.popleft()
        for v in nodes:
            if v in visited:
                continue
            cap = capacity.get(u, {}).get(v, 0)
            fl = flow.get(u, {}).get(v, 0)
            if cap - fl > 0:
                visited.add(v)
                parent[v] = u
                if v == sink:
                    return parent
                queue.append(v)
    return None

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
