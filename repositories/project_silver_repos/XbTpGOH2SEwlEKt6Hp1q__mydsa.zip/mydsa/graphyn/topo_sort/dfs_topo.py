"""DFS-based topological sorting."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID
from graphyn.topo_sort.kahn import CycleDetectedError

def dfs_topo_sort(graph: Any) -> list[NodeID]:
    """Compute topological ordering using DFS.

    Performs DFS and records nodes in reverse postorder.
    Detects cycles by tracking nodes currently on the recursion stack.

    Time complexity: O(V + E).

    Args:
        graph: A directed graph with get_node_ids() and neighbors().

    Returns:
        List of node IDs in topological order.

    Raises:
        CycleDetectedError: If the graph contains a cycle.
    """
    nodes = graph.get_node_ids()
    visited: set[NodeID] = set()
    on_stack: set[NodeID] = set()
    result: list[NodeID] = []

    def _dfs(node: NodeID) -> None:
        visited.add(node)
        on_stack.add(node)
        for neighbor in graph.neighbors(node):
            if neighbor in on_stack:
                raise CycleDetectedError(
                    f"Cycle detected via edge ({node}, {neighbor})")
            if neighbor not in visited:
                _dfs(neighbor)
        on_stack.discard(node)
        result.append(node)

    for node in nodes:
        if node not in visited:
            _dfs(node)
    result.reverse()
    return result

def dfs_topo_sort_iterative(graph: Any) -> list[NodeID]:
    """Iterative DFS-based topological sort.

    Uses an explicit stack to avoid recursion depth limits.

    Args:
        graph: A directed graph.

    Returns:
        List of node IDs in topological order.

    Raises:
        CycleDetectedError: If a cycle exists.
    """
    nodes = graph.get_node_ids()
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[NodeID, int] = {n: WHITE for n in nodes}
    result: list[NodeID] = []
    for start in nodes:
        if color[start] != WHITE:
            continue
        stack: list[tuple[NodeID, int]] = [(start, 0)]
        color[start] = GRAY
        while stack:
            node, idx = stack[-1]
            neighbors = graph.neighbors(node)
            if idx < len(neighbors):
                stack[-1] = (node, idx + 1)
                nb = neighbors[idx]
                if color[nb] == GRAY:
                    raise CycleDetectedError(
                        f"Cycle detected via edge ({node}, {nb})")
                if color[nb] == WHITE:
                    color[nb] = GRAY
                    stack.append((nb, 0))
            else:
                stack.pop()
                color[node] = BLACK
                result.append(node)
    result.reverse()
    return result

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs
