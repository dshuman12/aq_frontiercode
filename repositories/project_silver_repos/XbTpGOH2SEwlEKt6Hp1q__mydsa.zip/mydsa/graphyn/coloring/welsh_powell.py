"""Welsh-Powell graph coloring algorithm."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def welsh_powell_coloring(graph: Any) -> dict[NodeID, int]:
    """Color the graph using the Welsh-Powell algorithm.

    Sorts nodes by decreasing degree and assigns colors greedily.
    Often produces better results than arbitrary-order greedy coloring.

    Args:
        graph: An undirected graph with get_node_ids() and neighbors().

    Returns:
        Dictionary mapping node IDs to integer color values (0-based).
    """
    nodes = graph.get_node_ids()
    sorted_nodes = sorted(nodes, key=lambda n: len(graph.neighbors(n)),
                          reverse=True)
    color: dict[NodeID, int] = {}
    for node in sorted_nodes:
        neighbor_colors: set[int] = set()
        for nb in graph.neighbors(node):
            if nb in color:
                neighbor_colors.add(color[nb])
        c = 0
        while c in neighbor_colors:
            c += 1
        color[node] = c
    return color

def welsh_powell_chromatic_bound(graph: Any) -> int:
    """Upper bound on chromatic number via Welsh-Powell.

    Args:
        graph: An undirected graph.

    Returns:
        Upper bound on the number of colors needed.
    """
    coloring = welsh_powell_coloring(graph)
    if not coloring:
        return 0
    return max(coloring.values()) + 1

def coloring_stats(graph: Any, coloring: dict[NodeID, int]) -> dict[str, Any]:
    """Compute statistics about a graph coloring.

    Provides detailed information about the coloring quality
    including color distribution and validity verification.

    Args:
        graph: An undirected graph.
        coloring: A coloring dictionary.

    Returns:
        Dictionary with keys: num_colors, color_sizes, is_valid,
        largest_color_class, smallest_color_class.
    """
    from graphyn.coloring.greedy import verify_coloring
    color_groups: dict[int, int] = {}
    for c in coloring.values():
        color_groups[c] = color_groups.get(c, 0) + 1
    sizes = list(color_groups.values()) if color_groups else [0]
    return {
        "num_colors": len(set(coloring.values())) if coloring else 0,
        "color_sizes": color_groups,
        "is_valid": verify_coloring(graph, coloring),
        "largest_color_class": max(sizes) if sizes else 0,
        "smallest_color_class": min(sizes) if sizes else 0,
    }

def compare_colorings(graph: Any, coloring1: dict[NodeID, int],
                       coloring2: dict[NodeID, int]) -> dict[str, Any]:
    """Compare two colorings of the same graph.

    Args:
        graph: An undirected graph.
        coloring1: First coloring.
        coloring2: Second coloring.

    Returns:
        Dictionary with comparison metrics.
    """
    from graphyn.coloring.greedy import verify_coloring
    colors1 = len(set(coloring1.values())) if coloring1 else 0
    colors2 = len(set(coloring2.values())) if coloring2 else 0
    return {
        "colors_1": colors1,
        "colors_2": colors2,
        "valid_1": verify_coloring(graph, coloring1),
        "valid_2": verify_coloring(graph, coloring2),
        "winner": 1 if colors1 <= colors2 else 2,
        "same_count": colors1 == colors2,
    }

def independent_sets_from_coloring(coloring: dict[NodeID, int]) -> list[set[NodeID]]:
    """Extract independent sets from a coloring.

    Each color class is an independent set (no two adjacent
    nodes share a color).

    Args:
        coloring: A valid coloring dictionary.

    Returns:
        List of independent sets.
    """
    groups: dict[int, set[NodeID]] = {}
    for node, c in coloring.items():
        if c not in groups:
            groups[c] = set()
        groups[c].add(node)
    return list(groups.values())

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
# PERFORMANCE: Profiling shows this is the bottleneck on large graphs

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
