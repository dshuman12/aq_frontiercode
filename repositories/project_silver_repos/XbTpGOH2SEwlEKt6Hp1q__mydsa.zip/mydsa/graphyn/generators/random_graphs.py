"""Random graph generation algorithms."""
from __future__ import annotations
import random
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.types import NodeID

def erdos_renyi(n: int, p: float, seed: int | None = None,
                directed: bool = False) -> Graph:
    """Generate an Erdos-Renyi random graph G(n, p).

    Each possible edge is included independently with probability p.

    Args:
        n: Number of nodes.
        p: Edge probability between 0 and 1.
        seed: Random seed for reproducibility.
        directed: If True, generates a DiGraph.

    Returns:
        A random Graph instance.
    """
    if seed is not None:
        random.seed(seed)
    g = Graph(name=f"erdos_renyi_{n}_{p}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(n):
        start = 0 if directed else i + 1
        for j in range(start, n):
            if i == j:
                continue
            if random.random() < p:
                g.add_edge(Edge(source=i, target=j))
    return g

def erdos_renyi_gnm(n: int, m: int, seed: int | None = None) -> Graph:
    """Generate an Erdos-Renyi G(n, m) random graph.

    Selects exactly m edges uniformly at random from all possible edges.

    Args:
        n: Number of nodes.
        m: Exact number of edges.
        seed: Random seed.

    Returns:
        A random Graph with exactly m edges.
    """
    if seed is not None:
        random.seed(seed)
    g = Graph(name=f"erdos_renyi_gnm_{n}_{m}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    all_edges: list[tuple[int, int]] = []
    for i in range(n):
        for j in range(i + 1, n):
            all_edges.append((i, j))
    chosen = random.sample(all_edges, min(m, len(all_edges)))
    for i, j in chosen:
        g.add_edge(Edge(source=i, target=j))
    return g

def barabasi_albert(n: int, m: int, seed: int | None = None) -> Graph:
    """Generate a Barabasi-Albert preferential attachment graph.

    Starts with m connected nodes, then adds nodes one at a time.
    Each new node connects to m existing nodes with probability
    proportional to their degree.

    Args:
        n: Total number of nodes.
        m: Edges per new node (must be <= initial nodes).
        seed: Random seed.

    Returns:
        A scale-free Graph instance.
    """
    if seed is not None:
        random.seed(seed)
    if m < 1 or m >= n:
        raise ValueError(f"m must be >= 1 and < n, got m={m}, n={n}")
    g = Graph(name=f"barabasi_albert_{n}_{m}")
    for i in range(m):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(m):
        for j in range(i + 1, m):
            g.add_edge(Edge(source=i, target=j))
    targets: list[int] = []
    for i in range(m):
        targets.extend([i] * (m - 1))
    for i in range(m, n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
        chosen = _pick_targets(targets, m)
        for t in chosen:
            g.add_edge(Edge(source=i, target=t))
            targets.append(i)
            targets.append(t)
    return g

def _pick_targets(targets: list[int], m: int) -> list[int]:
    """Pick m unique targets using preferential attachment."""
    chosen: set[int] = set()
    while len(chosen) < m:
        t = random.choice(targets)
        chosen.add(t)
    return list(chosen)

def watts_strogatz(n: int, k: int, p: float,
                   seed: int | None = None) -> Graph:
    """Generate a Watts-Strogatz small-world graph.

    Starts with a ring lattice where each node connects to k nearest
    neighbors, then rewires edges with probability p.

    Args:
        n: Number of nodes.
        k: Each node connects to k/2 neighbors on each side.
        p: Rewiring probability.
        seed: Random seed.

    Returns:
        A small-world Graph instance.
    """
    if seed is not None:
        random.seed(seed)
    if k % 2 != 0:
        k = k - 1
    g = Graph(name=f"watts_strogatz_{n}_{k}_{p}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    edges_to_add: list[tuple[int, int]] = []
    for i in range(n):
        for j in range(1, k // 2 + 1):
            target = (i + j) % n
            edges_to_add.append((i, target))
    for src, tgt in edges_to_add:
        if not g.has_edge(src, tgt):
            g.add_edge(Edge(source=src, target=tgt))
    for src, tgt in list(edges_to_add):
        if random.random() < p:
            new_tgt = random.randint(0, n - 1)
            while new_tgt == src or g.has_edge(src, new_tgt):
                new_tgt = random.randint(0, n - 1)
            if g.has_edge(src, tgt):
                g.remove_edge(src, tgt)
                g.add_edge(Edge(source=src, target=new_tgt))
    return g

def random_tree(n: int, seed: int | None = None) -> Graph:
    """Generate a random tree with n nodes.

    Uses Prufer sequence to generate a uniformly random labeled tree.

    Args:
        n: Number of nodes.
        seed: Random seed.

    Returns:
        A random tree Graph.
    """
    if seed is not None:
        random.seed(seed)
    g = Graph(name=f"random_tree_{n}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    if n <= 1:
        return g
    if n == 2:
        g.add_edge(Edge(source=0, target=1))
        return g
    prufer = [random.randint(0, n - 1) for _ in range(n - 2)]
    degree: list[int] = [1] * n
    for x in prufer:
        degree[x] += 1
    for x in prufer:
        for i in range(n):
            if degree[i] == 1:
                g.add_edge(Edge(source=x, target=i))
                degree[x] -= 1
                degree[i] -= 1
                break
    remaining = [i for i in range(n) if degree[i] == 1]
    if len(remaining) == 2:
        g.add_edge(Edge(source=remaining[0], target=remaining[1]))
    return g

def random_regular(n: int, d: int, seed: int | None = None) -> Graph | None:
    """Generate a random d-regular graph.

    Uses a simple pairing algorithm. May return None if a valid
    graph cannot be constructed.

    Args:
        n: Number of nodes.
        d: Degree of each node.
        seed: Random seed.

    Returns:
        A d-regular Graph, or None if construction fails.
    """
    if seed is not None:
        random.seed(seed)
    if n * d % 2 != 0:
        return None
    g = Graph(name=f"regular_{n}_{d}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    stubs = []
    for i in range(n):
        stubs.extend([i] * d)
    random.shuffle(stubs)
    for attempt in range(10):
        random.shuffle(stubs)
        valid = True
        temp_edges: set[tuple[int, int]] = set()
        for i in range(0, len(stubs), 2):
            u, v = stubs[i], stubs[i + 1]
            if u == v or (min(u, v), max(u, v)) in temp_edges:
                valid = False
                break
            temp_edges.add((min(u, v), max(u, v)))
        if valid:
            for u, v in temp_edges:
                g.add_edge(Edge(source=u, target=v))
            return g
    return None

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
