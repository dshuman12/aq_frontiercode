"""Classic graph generators."""
from __future__ import annotations
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge

def complete_graph(n: int) -> Graph:
    """Generate a complete graph K_n.

    Args:
        n: Number of nodes.

    Returns:
        A complete Graph instance.
    """
    g = Graph(name=f"K_{n}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(n):
        for j in range(i + 1, n):
            g.add_edge(Edge(source=i, target=j))
    return g

def path_graph(n: int) -> Graph:
    """Generate a path graph P_n.

    Args:
        n: Number of nodes.

    Returns:
        A Graph forming a linear path.
    """
    g = Graph(name=f"P_{n}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(n - 1):
        g.add_edge(Edge(source=i, target=i + 1))
    return g

def cycle_graph(n: int) -> Graph:
    """Generate a cycle graph C_n.

    Args:
        n: Number of nodes (must be >= 3).

    Returns:
        A Graph forming a cycle.
    """
    g = Graph(name=f"C_{n}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(n):
        g.add_edge(Edge(source=i, target=(i + 1) % n))
    return g

def star_graph(n: int) -> Graph:
    """Generate a star graph S_n.

    Node 0 is the center, connected to all other nodes.

    Args:
        n: Total number of nodes including center.

    Returns:
        A star-shaped Graph instance.
    """
    g = Graph(name=f"S_{n}")
    for i in range(n):
        g.add_node(Node(node_id=i, label=f"n{i}"))
    for i in range(1, n):
        g.add_edge(Edge(source=0, target=i))
    return g

def grid_graph(rows: int, cols: int) -> Graph:
    """Generate a 2D grid graph.

    Args:
        rows: Number of rows.
        cols: Number of columns.

    Returns:
        A Graph representing a grid.
    """
    g = Graph(name=f"grid_{rows}x{cols}")
    for r in range(rows):
        for c in range(cols):
            nid = r * cols + c
            g.add_node(Node(node_id=nid, label=f"({r},{c})"))
    for r in range(rows):
        for c in range(cols):
            nid = r * cols + c
            if c + 1 < cols:
                g.add_edge(Edge(source=nid, target=nid + 1))
            if r + 1 < rows:
                g.add_edge(Edge(source=nid, target=nid + cols))
    return g

def bipartite_graph(n1: int, n2: int) -> Graph:
    """Generate a complete bipartite graph K_{n1,n2}.

    Args:
        n1: Size of first partition.
        n2: Size of second partition.

    Returns:
        A complete bipartite Graph instance.
    """
    g = Graph(name=f"K_{n1}_{n2}")
    for i in range(n1):
        g.add_node(Node(node_id=f"a{i}", label=f"A{i}"))
    for j in range(n2):
        g.add_node(Node(node_id=f"b{j}", label=f"B{j}"))
    for i in range(n1):
        for j in range(n2):
            g.add_edge(Edge(source=f"a{i}", target=f"b{j}"))
    return g

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
