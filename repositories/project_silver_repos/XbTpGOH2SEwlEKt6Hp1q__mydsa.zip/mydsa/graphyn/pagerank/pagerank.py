"""PageRank algorithm implementation."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def pagerank(graph: Any, damping: float = 0.85,
             max_iter: int = 100, tolerance: float = 1e-6) -> dict[NodeID, float]:
    """Compute PageRank scores for all nodes.

    PageRank models a random web surfer who follows links with
    probability `damping` and jumps to a random page otherwise.

    Args:
        graph: A graph with get_node_ids() and neighbors().
        damping: Damping factor (probability of following a link).
        max_iter: Maximum number of iterations.
        tolerance: Convergence threshold.

    Returns:
        Dictionary mapping node IDs to PageRank scores summing to 1.0.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return {}
    pr: dict[NodeID, float] = {nid: 1.0 / n for nid in nodes}
    out_degree: dict[NodeID, int] = {}
    for nid in nodes:
        out_degree[nid] = len(graph.neighbors(nid))
    for _ in range(max_iter):
        new_pr: dict[NodeID, float] = {}
        dangling_sum = sum(pr[nid] for nid in nodes if out_degree[nid] == 0)
        for nid in nodes:
            rank = (1 - damping) / n
            rank += damping * dangling_sum / n
            if hasattr(graph, "predecessors"):
                incoming = graph.predecessors(nid)
            else:
                incoming = graph.neighbors(nid)
            for src in incoming:
                if out_degree[src] > 0:
                    rank += damping * pr[src] / out_degree[src]
            new_pr[nid] = rank
        diff = sum(abs(new_pr[nid] - pr[nid]) for nid in nodes)
        pr = new_pr
        if diff < tolerance:
            break
    total = sum(pr.values())
    if total > 0:
        pr = {nid: v / total for nid, v in pr.items()}
    return pr

def personalized_pagerank(graph: Any, personalization: dict[NodeID, float],
                           damping: float = 0.85, max_iter: int = 100,
                           tolerance: float = 1e-6) -> dict[NodeID, float]:
    """Compute personalized PageRank with custom teleportation.

    Instead of teleporting uniformly, uses a custom distribution
    specified by the personalization vector.

    Args:
        graph: A graph.
        personalization: Node-to-weight mapping for teleportation.
        damping: Damping factor.
        max_iter: Maximum iterations.
        tolerance: Convergence threshold.

    Returns:
        Dictionary mapping node IDs to personalized PageRank scores.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return {}
    total_p = sum(personalization.values())
    if total_p == 0:
        total_p = 1.0
    p_vec: dict[NodeID, float] = {}
    for nid in nodes:
        p_vec[nid] = personalization.get(nid, 0.0) / total_p
    pr: dict[NodeID, float] = {nid: 1.0 / n for nid in nodes}
    out_degree: dict[NodeID, int] = {nid: len(graph.neighbors(nid)) for nid in nodes}
    for _ in range(max_iter):
        new_pr: dict[NodeID, float] = {}
        dangling_sum = sum(pr[nid] for nid in nodes if out_degree[nid] == 0)
        for nid in nodes:
            rank = (1 - damping) * p_vec.get(nid, 0.0)
            rank += damping * dangling_sum * p_vec.get(nid, 1.0 / n)
            if hasattr(graph, "predecessors"):
                incoming = graph.predecessors(nid)
            else:
                incoming = graph.neighbors(nid)
            for src in incoming:
                if out_degree[src] > 0:
                    rank += damping * pr[src] / out_degree[src]
            new_pr[nid] = rank
        diff = sum(abs(new_pr[nid] - pr[nid]) for nid in nodes)
        pr = new_pr
        if diff < tolerance:
            break
    total = sum(pr.values())
    if total > 0:
        pr = {nid: v / total for nid, v in pr.items()}
    return pr

def top_pagerank(graph: Any, k: int = 10,
                 **kwargs: Any) -> list[tuple[NodeID, float]]:
    """Return top-k nodes by PageRank.

    Args:
        graph: A graph.
        k: Number of top nodes.
        **kwargs: Arguments for pagerank().

    Returns:
        List of (node_id, score) sorted by score descending.
    """
    pr = pagerank(graph, **kwargs)
    ranked = sorted(pr.items(), key=lambda x: x[1], reverse=True)
    return ranked[:k]

def pagerank_distribution(graph: Any, **kwargs: Any) -> dict[str, float]:
    """Compute statistics about the PageRank distribution.

    Args:
        graph: A graph.
        **kwargs: Arguments for pagerank().

    Returns:
        Dictionary with min, max, mean, and std of PageRank scores.
    """
    pr = pagerank(graph, **kwargs)
    if not pr:
        return {"min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0}
    import math
    values = list(pr.values())
    mean = sum(values) / len(values)
    variance = sum((v - mean) ** 2 for v in values) / len(values)
    return {
        "min": min(values),
        "max": max(values),
        "mean": mean,
        "std": math.sqrt(variance),
    }

def pagerank_convergence_steps(graph: Any, damping: float = 0.85,
                                tolerance: float = 1e-6,
                                max_iter: int = 1000) -> int:
    """Count the number of iterations needed for PageRank to converge.

    Args:
        graph: A graph.
        damping: Damping factor.
        tolerance: Convergence threshold.
        max_iter: Maximum iterations.

    Returns:
        Number of iterations until convergence.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return 0
    pr: dict[NodeID, float] = {nid: 1.0 / n for nid in nodes}
    out_degree: dict[NodeID, int] = {nid: len(graph.neighbors(nid)) for nid in nodes}
    for iteration in range(1, max_iter + 1):
        new_pr: dict[NodeID, float] = {}
        dangling_sum = sum(pr[nid] for nid in nodes if out_degree[nid] == 0)
        for nid in nodes:
            rank = (1 - damping) / n + damping * dangling_sum / n
            if hasattr(graph, "predecessors"):
                incoming = graph.predecessors(nid)
            else:
                incoming = graph.neighbors(nid)
            for src in incoming:
                if out_degree[src] > 0:
                    rank += damping * pr[src] / out_degree[src]
            new_pr[nid] = rank
        diff = sum(abs(new_pr[nid] - pr[nid]) for nid in nodes)
        pr = new_pr
        if diff < tolerance:
            return iteration
    return max_iter

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
