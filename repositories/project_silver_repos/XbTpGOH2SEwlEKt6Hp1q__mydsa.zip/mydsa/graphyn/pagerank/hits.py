"""HITS (Hyperlink-Induced Topic Search) algorithm."""
from __future__ import annotations
import math
from typing import Any
from graphyn.core.types import NodeID

def hits(graph: Any, max_iter: int = 100,
         tolerance: float = 1e-6) -> tuple[dict[NodeID, float], dict[NodeID, float]]:
    """Compute HITS hub and authority scores.

    Authorities are nodes pointed to by many good hubs.
    Hubs are nodes that point to many good authorities.

    The algorithm iteratively updates hub and authority scores
    until convergence or maximum iterations reached.

    Args:
        graph: A graph with get_node_ids() and neighbors().
        max_iter: Maximum iterations.
        tolerance: Convergence threshold.

    Returns:
        Tuple of (hub_scores, authority_scores) dictionaries.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return {}, {}
    hub: dict[NodeID, float] = {nid: 1.0 for nid in nodes}
    auth: dict[NodeID, float] = {nid: 1.0 for nid in nodes}
    for _ in range(max_iter):
        new_auth: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
        new_hub: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
        for nid in nodes:
            if hasattr(graph, "predecessors"):
                incoming = graph.predecessors(nid)
            else:
                incoming = graph.neighbors(nid)
            for src in incoming:
                new_auth[nid] += hub[src]
        for nid in nodes:
            for nb in graph.neighbors(nid):
                new_hub[nid] += new_auth[nb]
        auth_norm = math.sqrt(sum(v ** 2 for v in new_auth.values()))
        hub_norm = math.sqrt(sum(v ** 2 for v in new_hub.values()))
        if auth_norm > 0:
            new_auth = {nid: v / auth_norm for nid, v in new_auth.items()}
        if hub_norm > 0:
            new_hub = {nid: v / hub_norm for nid, v in new_hub.items()}
        diff = sum(abs(new_auth[nid] - auth[nid]) for nid in nodes)
        diff += sum(abs(new_hub[nid] - hub[nid]) for nid in nodes)
        auth = new_auth
        hub = new_hub
        if diff < tolerance:
            break
    return hub, auth

def top_authorities(graph: Any, k: int = 10,
                    **kwargs: Any) -> list[tuple[NodeID, float]]:
    """Return top-k authority nodes from HITS.

    Args:
        graph: A graph.
        k: Number of top nodes.
        **kwargs: Arguments for hits().

    Returns:
        List of (node_id, authority_score) sorted descending.
    """
    _, auth = hits(graph, **kwargs)
    ranked = sorted(auth.items(), key=lambda x: x[1], reverse=True)
    return ranked[:k]

def top_hubs(graph: Any, k: int = 10,
             **kwargs: Any) -> list[tuple[NodeID, float]]:
    """Return top-k hub nodes from HITS.

    Args:
        graph: A graph.
        k: Number of top nodes.
        **kwargs: Arguments for hits().

    Returns:
        List of (node_id, hub_score) sorted descending.
    """
    hub, _ = hits(graph, **kwargs)
    ranked = sorted(hub.items(), key=lambda x: x[1], reverse=True)
    return ranked[:k]

def hits_convergence_steps(graph: Any, tolerance: float = 1e-6,
                            max_iter: int = 1000) -> int:
    """Count iterations needed for HITS to converge.

    Args:
        graph: A graph.
        tolerance: Convergence threshold.
        max_iter: Maximum iterations.

    Returns:
        Number of iterations until convergence.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n == 0:
        return 0
    hub: dict[NodeID, float] = {nid: 1.0 for nid in nodes}
    auth: dict[NodeID, float] = {nid: 1.0 for nid in nodes}
    for iteration in range(1, max_iter + 1):
        new_auth: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
        new_hub: dict[NodeID, float] = {nid: 0.0 for nid in nodes}
        for nid in nodes:
            if hasattr(graph, "predecessors"):
                incoming = graph.predecessors(nid)
            else:
                incoming = graph.neighbors(nid)
            for src in incoming:
                new_auth[nid] += hub[src]
        for nid in nodes:
            for nb in graph.neighbors(nid):
                new_hub[nid] += new_auth[nb]
        auth_norm = math.sqrt(sum(v ** 2 for v in new_auth.values()))
        hub_norm = math.sqrt(sum(v ** 2 for v in new_hub.values()))
        if auth_norm > 0:
            new_auth = {nid: v / auth_norm for nid, v in new_auth.items()}
        if hub_norm > 0:
            new_hub = {nid: v / hub_norm for nid, v in new_hub.items()}
        diff = sum(abs(new_auth[nid] - auth[nid]) for nid in nodes)
        diff += sum(abs(new_hub[nid] - hub[nid]) for nid in nodes)
        auth = new_auth
        hub = new_hub
        if diff < tolerance:
            return iteration
    return max_iter

def hub_authority_ratio(graph: Any) -> dict[NodeID, float]:
    """Compute the hub-to-authority ratio for each node.

    Nodes with high ratio are primarily hubs; nodes with low
    ratio are primarily authorities.

    Args:
        graph: A graph.

    Returns:
        Dictionary mapping nodes to hub/authority ratio.
    """
    hub, auth = hits(graph)
    result: dict[NodeID, float] = {}
    for nid in hub:
        h = hub.get(nid, 0.0)
        a = auth.get(nid, 0.0)
        if a > 0:
            result[nid] = h / a
        else:
            result[nid] = float("inf") if h > 0 else 0.0
    return result

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
