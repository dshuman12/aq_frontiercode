"""Louvain community detection algorithm."""
from __future__ import annotations
import random
from typing import Any
from graphyn.core.types import NodeID

def louvain_communities(graph: Any, resolution: float = 1.0,
                        seed: int | None = None,
                        max_passes: int = 20) -> list[set[NodeID]]:
    """Detect communities using the Louvain method.

    The Louvain algorithm optimizes modularity by iteratively
    moving nodes between communities and then aggregating the graph.
    This is a simplified single-level implementation.

    Args:
        graph: An undirected graph with get_node_ids(), neighbors(),
               get_edge_weight().
        resolution: Resolution parameter controlling community size.
                    Higher values produce smaller communities.
        seed: Random seed for reproducibility.
        max_passes: Maximum optimization passes.

    Returns:
        List of sets, each containing node IDs in one community.
    """
    if seed is not None:
        random.seed(seed)
    nodes = graph.get_node_ids()
    if not nodes:
        return []
    community: dict[NodeID, int] = {n: i for i, n in enumerate(nodes)}
    total_weight = _total_edge_weight(graph)
    if total_weight == 0:
        return [{n} for n in nodes]
    node_weights: dict[NodeID, float] = {}
    for n in nodes:
        s = 0.0
        for nb in graph.neighbors(n):
            s += graph.get_edge_weight(n, nb)
        node_weights[n] = s
    improved = True
    passes = 0
    while improved and passes < max_passes:
        improved = False
        passes += 1
        order = list(nodes)
        random.shuffle(order)
        for node in order:
            current_comm = community[node]
            neighbor_comms: dict[int, float] = {}
            for nb in graph.neighbors(node):
                c = community[nb]
                w = graph.get_edge_weight(node, nb)
                neighbor_comms[c] = neighbor_comms.get(c, 0.0) + w
            best_comm = current_comm
            best_gain = 0.0
            ki = node_weights[node]
            for c, ki_in in neighbor_comms.items():
                sigma_tot = sum(
                    node_weights[n2] for n2 in nodes if community[n2] == c
                )
                if c == current_comm:
                    sigma_tot -= ki
                delta = ki_in - resolution * sigma_tot * ki / (2 * total_weight)
                if delta > best_gain:
                    best_gain = delta
                    best_comm = c
            if best_comm != current_comm:
                community[node] = best_comm
                improved = True
    comm_sets: dict[int, set[NodeID]] = {}
    for n, c in community.items():
        if c not in comm_sets:
            comm_sets[c] = set()
        comm_sets[c].add(n)
    return list(comm_sets.values())

def _total_edge_weight(graph: Any) -> float:
    """Sum all edge weights in the graph."""
    total = 0.0
    for _, _, w in graph.iter_edges():
        total += w
    return total

def louvain_modularity(graph: Any, resolution: float = 1.0,
                        seed: int | None = None) -> tuple[list[set[NodeID]], float]:
    """Run Louvain and return both communities and their modularity.

    Args:
        graph: An undirected graph.
        resolution: Resolution parameter.
        seed: Random seed.

    Returns:
        Tuple of (communities, modularity_score).
    """
    from graphyn.community.modularity import modularity_score
    communities = louvain_communities(graph, resolution=resolution, seed=seed)
    mod = modularity_score(graph, communities)
    return communities, mod

def community_assignment(graph: Any, resolution: float = 1.0,
                          seed: int | None = None) -> dict[NodeID, int]:
    """Return a node-to-community-index mapping.

    Args:
        graph: An undirected graph.
        resolution: Resolution parameter.
        seed: Random seed.

    Returns:
        Dictionary mapping each node ID to its community index.
    """
    communities = louvain_communities(graph, resolution=resolution, seed=seed)
    assignment: dict[NodeID, int] = {}
    for idx, comm in enumerate(communities):
        for node in comm:
            assignment[node] = idx
    return assignment

def community_sizes(graph: Any, resolution: float = 1.0,
                     seed: int | None = None) -> list[int]:
    """Return community sizes sorted by size descending.

    Args:
        graph: An undirected graph.
        resolution: Resolution parameter.
        seed: Random seed.

    Returns:
        Sorted list of community sizes.
    """
    communities = louvain_communities(graph, resolution=resolution, seed=seed)
    return sorted([len(c) for c in communities], reverse=True)
