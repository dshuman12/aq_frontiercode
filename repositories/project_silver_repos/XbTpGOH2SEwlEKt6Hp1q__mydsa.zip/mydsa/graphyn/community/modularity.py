"""Modularity computation for community evaluation."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def modularity_score(graph: Any, communities: list[set[NodeID]]) -> float:
    """Compute the modularity of a graph partition.

    Modularity measures the quality of a partition by comparing the
    fraction of intra-community edges to the expected fraction
    in a random graph with the same degree sequence.

    Q = (1/2m) * sum_ij [A_ij - (k_i*k_j)/(2m)] * delta(c_i, c_j)

    Args:
        graph: An undirected graph with get_node_ids(), iter_edges(),
               get_edge_weight().
        communities: List of sets of node IDs forming the partition.

    Returns:
        Modularity score Q, typically in [-0.5, 1.0].
    """
    total_weight = 0.0
    edges = list(graph.iter_edges())
    for _, _, w in edges:
        total_weight += w
    if total_weight == 0:
        return 0.0
    m2 = 2.0 * total_weight
    node_to_comm: dict[NodeID, int] = {}
    for idx, comm in enumerate(communities):
        for node in comm:
            node_to_comm[node] = idx
    degrees: dict[NodeID, float] = {}
    for nid in graph.get_node_ids():
        deg = 0.0
        for nb in graph.neighbors(nid):
            deg += graph.get_edge_weight(nid, nb)
        degrees[nid] = deg
    q = 0.0
    for u, v, w in edges:
        if node_to_comm.get(u) == node_to_comm.get(v):
            q += w - (degrees[u] * degrees[v]) / m2
            if not hasattr(graph, "_succ"):
                q += w - (degrees[v] * degrees[u]) / m2
    return q / m2

def modularity_matrix_entry(graph: Any, u: NodeID, v: NodeID) -> float:
    """Compute a single entry of the modularity matrix.

    B_ij = A_ij - (k_i * k_j) / (2m)

    Args:
        graph: An undirected graph.
        u: Row node.
        v: Column node.

    Returns:
        Modularity matrix value.
    """
    total_weight = sum(w for _, _, w in graph.iter_edges())
    if total_weight == 0:
        return 0.0
    m2 = 2.0 * total_weight
    a_ij = graph.get_edge_weight(u, v) if graph.has_edge(u, v) else 0.0
    k_i = sum(graph.get_edge_weight(u, nb) for nb in graph.neighbors(u))
    k_j = sum(graph.get_edge_weight(v, nb) for nb in graph.neighbors(v))
    return a_ij - (k_i * k_j) / m2

def community_coverage(graph: Any, communities: list[set[NodeID]]) -> float:
    """Compute the fraction of intra-community edges.

    Coverage is the fraction of edges that fall within communities
    rather than crossing community boundaries.

    Args:
        graph: An undirected graph.
        communities: Partition as list of node sets.

    Returns:
        Coverage fraction between 0.0 and 1.0.
    """
    if graph.edge_count == 0:
        return 0.0
    node_to_comm: dict[NodeID, int] = {}
    for idx, comm in enumerate(communities):
        for node in comm:
            node_to_comm[node] = idx
    intra = 0
    for u, v, _ in graph.iter_edges():
        if node_to_comm.get(u) == node_to_comm.get(v):
            intra += 1
    return intra / graph.edge_count

def community_performance(graph: Any, communities: list[set[NodeID]]) -> float:
    """Compute performance of a community partition.

    Performance measures the fraction of node pairs that are
    correctly classified (both in same community and connected,
    or in different communities and not connected).

    Args:
        graph: An undirected graph.
        communities: Partition as list of node sets.

    Returns:
        Performance value between 0.0 and 1.0.
    """
    nodes = graph.get_node_ids()
    n = len(nodes)
    if n <= 1:
        return 1.0
    node_to_comm: dict[NodeID, int] = {}
    for idx, comm in enumerate(communities):
        for node in comm:
            node_to_comm[node] = idx
    correct = 0
    total = n * (n - 1) // 2
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            u, v = nodes[i], nodes[j]
            same_comm = node_to_comm.get(u) == node_to_comm.get(v)
            connected = graph.has_edge(u, v)
            if same_comm == connected:
                correct += 1
    return correct / total if total > 0 else 1.0

def inter_community_edges(graph: Any, communities: list[set[NodeID]]) -> int:
    """Count the number of edges crossing community boundaries.

    Args:
        graph: An undirected graph.
        communities: Partition as list of node sets.

    Returns:
        Number of inter-community edges.
    """
    node_to_comm: dict[NodeID, int] = {}
    for idx, comm in enumerate(communities):
        for node in comm:
            node_to_comm[node] = idx
    count = 0
    for u, v, _ in graph.iter_edges():
        if node_to_comm.get(u) != node_to_comm.get(v):
            count += 1
    return count

def conductance(graph: Any, community: set[NodeID]) -> float:
    """Compute the conductance of a single community.

    Conductance measures how well-separated a community is,
    defined as the ratio of cut edges to the minimum of edge
    volume on either side.

    Args:
        graph: An undirected graph.
        community: Set of node IDs in the community.

    Returns:
        Conductance value between 0.0 and 1.0.
    """
    cut = 0.0
    vol_s = 0.0
    vol_complement = 0.0
    for u, v, w in graph.iter_edges():
        u_in = u in community
        v_in = v in community
        if u_in and not v_in:
            cut += w
        elif not u_in and v_in:
            cut += w
        if u_in:
            vol_s += w
        else:
            vol_complement += w
        if v_in:
            vol_s += w
        else:
            vol_complement += w
    min_vol = min(vol_s, vol_complement)
    if min_vol == 0:
        return 0.0
    return cut / min_vol

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
