"""Cycle detection algorithms."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID

def has_cycle(graph: Any) -> bool:
    """Check if the graph contains a cycle.

    For directed graphs, uses DFS with coloring. For undirected
    graphs, uses DFS with parent tracking.

    Args:
        graph: A graph with get_node_ids() and neighbors().

    Returns:
        True if the graph contains at least one cycle.
    """
    is_directed = hasattr(graph, "_succ")
    if is_directed:
        return _has_cycle_directed(graph)
    return _has_cycle_undirected(graph)

def _has_cycle_directed(graph: Any) -> bool:
    """Detect cycle in a directed graph using DFS coloring."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[NodeID, int] = {n: WHITE for n in graph.get_node_ids()}
    for start in graph.get_node_ids():
        if color[start] != WHITE:
            continue
        stack: list[tuple[NodeID, int]] = [(start, 0)]
        color[start] = GRAY
        while stack:
            node, idx = stack[-1]
            neighbors = graph.neighbors(node)
            if idx < len(neighbors):
                stack[-1] = (node, idx + 1)
                nb = neighbors[idx]
                if color[nb] == GRAY:
                    return True
                if color[nb] == WHITE:
                    color[nb] = GRAY
                    stack.append((nb, 0))
            else:
                stack.pop()
                color[node] = BLACK
    return False

def _has_cycle_undirected(graph: Any) -> bool:
    """Detect cycle in an undirected graph using DFS with parent tracking."""
    visited: set[NodeID] = set()
    for start in graph.get_node_ids():
        if start in visited:
            continue
        stack: list[tuple[NodeID, NodeID | None]] = [(start, None)]
        visited.add(start)
        while stack:
            node, parent = stack.pop()
            for nb in graph.neighbors(node):
                if nb == parent:
                    continue
                if nb in visited:
                    return True
                visited.add(nb)
                stack.append((nb, node))
    return False

def find_cycle(graph: Any) -> list[NodeID] | None:
    """Find one cycle in the graph, if any exists.

    Args:
        graph: A graph with get_node_ids() and neighbors().

    Returns:
        List of node IDs forming a cycle, or None if acyclic.
    """
    is_directed = hasattr(graph, "_succ")
    if is_directed:
        return _find_cycle_directed(graph)
    return _find_cycle_undirected(graph)

def _find_cycle_directed(graph: Any) -> list[NodeID] | None:
    """Find a cycle in a directed graph."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[NodeID, int] = {n: WHITE for n in graph.get_node_ids()}
    parent: dict[NodeID, NodeID | None] = {}
    for start in graph.get_node_ids():
        if color[start] != WHITE:
            continue
        stack: list[tuple[NodeID, int]] = [(start, 0)]
        color[start] = GRAY
        parent[start] = None
        while stack:
            node, idx = stack[-1]
            neighbors = graph.neighbors(node)
            if idx < len(neighbors):
                stack[-1] = (node, idx + 1)
                nb = neighbors[idx]
                if color[nb] == GRAY:
                    cycle: list[NodeID] = [nb, node]
                    current = node
                    while current != nb:
                        current = parent.get(current)
                        if current is None:
                            break
                        cycle.append(current)
                    cycle.reverse()
                    return cycle
                if color[nb] == WHITE:
                    color[nb] = GRAY
                    parent[nb] = node
                    stack.append((nb, 0))
            else:
                stack.pop()
                color[node] = BLACK
    return None

def _find_cycle_undirected(graph: Any) -> list[NodeID] | None:
    """Find a cycle in an undirected graph."""
    visited: set[NodeID] = set()
    parent: dict[NodeID, NodeID | None] = {}
    for start in graph.get_node_ids():
        if start in visited:
            continue
        stack: list[NodeID] = [start]
        visited.add(start)
        parent[start] = None
        while stack:
            node = stack.pop()
            for nb in graph.neighbors(node):
                if nb == parent.get(node):
                    continue
                if nb in visited:
                    cycle = [nb, node]
                    current = node
                    while parent.get(current) is not None and current != nb:
                        current = parent[current]
                        cycle.append(current)
                    return cycle
                visited.add(nb)
                parent[nb] = node
                stack.append(nb)
    return None

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
