"""Bipartite matching algorithms."""
from __future__ import annotations
from collections import deque
from typing import Any
from graphyn.core.types import NodeID

INF = float("inf")

def maximum_matching(graph: Any) -> dict[NodeID, NodeID]:
    """Find a maximum matching using augmenting paths.

    Simple augmenting path algorithm for bipartite graphs.

    Args:
        graph: A bipartite undirected graph.

    Returns:
        Dictionary mapping matched node pairs.
    """
    from graphyn.bipartite.checking import two_coloring
    coloring = two_coloring(graph)
    if coloring is None:
        return {}
    left = {n for n, c in coloring.items() if c == 0}
    match: dict[NodeID, NodeID | None] = {n: None for n in graph.get_node_ids()}
    for u in left:
        visited: set[NodeID] = set()
        _augment(graph, u, match, visited, left)
    result: dict[NodeID, NodeID] = {}
    for u in left:
        if match[u] is not None:
            result[u] = match[u]
    return result

def _augment(graph: Any, u: NodeID, match: dict[NodeID, NodeID | None],
             visited: set[NodeID], left: set[NodeID]) -> bool:
    """Try to find an augmenting path from node u."""
    for v in graph.neighbors(u):
        if v in visited or v in left:
            continue
        visited.add(v)
        if match[v] is None or _augment(graph, match[v], match, visited, left):
            match[u] = v
            match[v] = u
            return True
    return False

def hopcroft_karp(graph: Any) -> dict[NodeID, NodeID]:
    """Find maximum matching using Hopcroft-Karp algorithm.

    More efficient than simple augmenting paths, runs in O(E * sqrt(V)).

    Args:
        graph: A bipartite undirected graph.

    Returns:
        Dictionary mapping matched node pairs (left -> right).
    """
    from graphyn.bipartite.checking import two_coloring
    coloring = two_coloring(graph)
    if coloring is None:
        return {}
    left = [n for n, c in coloring.items() if c == 0]
    right = [n for n, c in coloring.items() if c == 1]
    pair_u: dict[NodeID, NodeID | None] = {u: None for u in left}
    pair_v: dict[NodeID, NodeID | None] = {v: None for v in right}
    dist: dict[NodeID | None, float] = {}
    while _hk_bfs(graph, left, pair_u, pair_v, dist):
        for u in left:
            if pair_u[u] is None:
                _hk_dfs(graph, u, pair_u, pair_v, dist, set(right))
    return {u: v for u, v in pair_u.items() if v is not None}

def _hk_bfs(graph: Any, left: list[NodeID],
            pair_u: dict[NodeID, NodeID | None],
            pair_v: dict[NodeID, NodeID | None],
            dist: dict[NodeID | None, float]) -> bool:
    """BFS phase of Hopcroft-Karp."""
    queue: deque[NodeID] = deque()
    for u in left:
        if pair_u[u] is None:
            dist[u] = 0
            queue.append(u)
        else:
            dist[u] = INF
    dist[None] = INF
    while queue:
        u = queue.popleft()
        if dist[u] < dist[None]:
            for v in graph.neighbors(u):
                if v not in pair_v:
                    continue
                next_u = pair_v[v]
                if dist.get(next_u, INF) == INF:
                    dist[next_u] = dist[u] + 1
                    if next_u is not None:
                        queue.append(next_u)
    return dist[None] != INF

def _hk_dfs(graph: Any, u: NodeID,
            pair_u: dict[NodeID, NodeID | None],
            pair_v: dict[NodeID, NodeID | None],
            dist: dict[NodeID | None, float],
            right_set: set[NodeID]) -> bool:
    """DFS phase of Hopcroft-Karp."""
    if u is not None:
        for v in graph.neighbors(u):
            if v not in right_set:
                continue
            next_u = pair_v.get(v)
            if dist.get(next_u, INF) == dist[u] + 1:
                if _hk_dfs(graph, next_u, pair_u, pair_v, dist, right_set):
                    pair_v[v] = u
                    pair_u[u] = v
                    return True
        dist[u] = INF
        return False
    return True

def matching_size(matching: dict[NodeID, NodeID]) -> int:
    """Return the size of a matching.

    Args:
        matching: A matching dictionary.

    Returns:
        Number of matched pairs.
    """
    return len(matching)

def is_perfect_matching(graph: Any, matching: dict[NodeID, NodeID]) -> bool:
    """Check if a matching is perfect (covers all nodes).

    Args:
        graph: A bipartite graph.
        matching: A matching dictionary.

    Returns:
        True if every node is matched.
    """
    matched_nodes = set(matching.keys()) | set(matching.values())
    return len(matched_nodes) == graph.node_count

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
