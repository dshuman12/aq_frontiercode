"""Link prediction engine."""
from __future__ import annotations
from typing import Any, Callable
from graphyn.core.types import NodeID
from graphyn.link_prediction.scores import (
    common_neighbors_score, jaccard_score,
    adamic_adar_score, preferential_attachment_score,
)

ScoreFunction = Callable[[Any, NodeID, NodeID], float]

class LinkPredictor:
    """Predicts likely future edges in a graph.

    Scores all non-existing node pairs and ranks them by
    predicted likelihood of forming an edge.

    Attributes:
        graph: The graph to predict links for.
    """
    def __init__(self, graph: Any,
                 score_fn: ScoreFunction | None = None) -> None:
        """Initialize the link predictor.

        Args:
            graph: A graph with get_node_ids(), neighbors(), has_edge().
            score_fn: Scoring function. Defaults to common_neighbors_score.
        """
        self._graph: Any = graph
        self._score_fn: ScoreFunction = score_fn or common_neighbors_score

    @property
    def graph(self) -> Any:
        """Return the underlying graph."""
        return self._graph

    def predict(self, top_k: int = 10) -> list[tuple[NodeID, NodeID, float]]:
        """Predict top-k most likely future edges.

        Args:
            top_k: Number of predictions to return.

        Returns:
            List of (u, v, score) sorted by score descending.
        """
        nodes = self._graph.get_node_ids()
        candidates: list[tuple[NodeID, NodeID, float]] = []
        seen: set[tuple[NodeID, NodeID]] = set()
        for u in nodes:
            for v in nodes:
                if u == v:
                    continue
                pair = (min(u, v, key=str), max(u, v, key=str))
                if pair in seen:
                    continue
                seen.add(pair)
                if self._graph.has_edge(u, v):
                    continue
                score = self._score_fn(self._graph, u, v)
                if score > 0:
                    candidates.append((u, v, float(score)))
        candidates.sort(key=lambda x: x[2], reverse=True)
        return candidates[:top_k]

    def predict_for_node(self, node_id: NodeID,
                         top_k: int = 5) -> list[tuple[NodeID, float]]:
        """Predict likely new connections for a specific node.

        Args:
            node_id: The node to predict links for.
            top_k: Number of predictions.

        Returns:
            List of (candidate_node, score) pairs.
        """
        nodes = self._graph.get_node_ids()
        candidates: list[tuple[NodeID, float]] = []
        for v in nodes:
            if v == node_id or self._graph.has_edge(node_id, v):
                continue
            score = self._score_fn(self._graph, node_id, v)
            if score > 0:
                candidates.append((v, float(score)))
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:top_k]

    def with_score_function(self, score_fn: ScoreFunction) -> LinkPredictor:
        """Create a new predictor with a different scoring function.

        Args:
            score_fn: New scoring function.

        Returns:
            A new LinkPredictor instance.
        """
        return LinkPredictor(self._graph, score_fn)

# TODO: Consider caching this computation for repeated calls
# NOTE: Time complexity is O(V + E) for sparse graphs
# OPTIMIZATION: Could use a priority queue here for better perf
# WARNING: This assumes the graph has no self-loops
# FUTURE: Add support for weighted variant of this algorithm
# REFACTOR: Extract this into a standalone utility function
# INVARIANT: The result set is always a subset of input nodes
