"""Adjacency list representation of a graph."""
from __future__ import annotations
from typing import Any, Iterator
from graphyn.core.types import NodeID, Weight

class AdjacencyList:
    """Adjacency list graph representation.

    Uses a dictionary mapping each node to its list of
    (neighbor, weight) pairs. Memory-efficient for sparse graphs.

    Attributes:
        directed: Whether this list represents a directed graph.
    """
    def __init__(self, directed: bool = False) -> None:
        """Initialize an empty adjacency list.

        Args:
            directed: If True, edges are directional.
        """
        self._directed: bool = directed
        self._adj: dict[NodeID, list[tuple[NodeID, Weight]]] = {}

    @property
    def directed(self) -> bool:
        """Whether this is a directed adjacency list."""
        return self._directed

    @property
    def node_count(self) -> int:
        """Return the number of nodes."""
        return len(self._adj)

    def add_node(self, node_id: NodeID) -> None:
        """Add a node to the adjacency list.

        Args:
            node_id: The node identifier to add.
        """
        if node_id not in self._adj:
            self._adj[node_id] = []

    def add_edge(self, source: NodeID, target: NodeID, weight: Weight = 1.0) -> None:
        """Add an edge to the adjacency list.

        Args:
            source: Source node ID.
            target: Target node ID.
            weight: Edge weight.
        """
        self.add_node(source)
        self.add_node(target)
        self._adj[source].append((target, weight))
        if not self._directed:
            self._adj[target].append((source, weight))

    def neighbors(self, node_id: NodeID) -> list[tuple[NodeID, Weight]]:
        """Return list of (neighbor, weight) tuples.

        Args:
            node_id: The node whose neighbors to retrieve.

        Returns:
            List of (neighbor_id, weight) pairs.
        """
        return list(self._adj.get(node_id, []))

    def neighbor_ids(self, node_id: NodeID) -> list[NodeID]:
        """Return just the neighbor node IDs."""
        return [nid for nid, _ in self._adj.get(node_id, [])]

    def has_edge(self, source: NodeID, target: NodeID) -> bool:
        """Check if an edge exists."""
        return any(nid == target for nid, _ in self._adj.get(source, []))

    def get_node_ids(self) -> list[NodeID]:
        """Return all node IDs."""
        return list(self._adj.keys())

    def degree(self, node_id: NodeID) -> int:
        """Return the degree of a node."""
        return len(self._adj.get(node_id, []))

    def edge_count(self) -> int:
        """Return total number of edges."""
        total = sum(len(adj) for adj in self._adj.values())
        if not self._directed:
            total //= 2
        return total

    def iter_edges(self) -> Iterator[tuple[NodeID, NodeID, Weight]]:
        """Iterate over all edges as (source, target, weight)."""
        seen: set[tuple[NodeID, NodeID]] = set()
        for src, neighbors in self._adj.items():
            for tgt, wt in neighbors:
                if self._directed or (src, tgt) not in seen:
                    yield (src, tgt, wt)
                    seen.add((src, tgt))
                    seen.add((tgt, src))

    @classmethod
    def from_graph(cls, graph: Any) -> AdjacencyList:
        """Create an AdjacencyList from a Graph or DiGraph."""
        directed = hasattr(graph, "_succ")
        adj = cls(directed=directed)
        for nid in graph.get_node_ids():
            adj.add_node(nid)
        for src, tgt, wt in graph.iter_edges():
            adj.add_edge(src, tgt, wt)
        return adj
