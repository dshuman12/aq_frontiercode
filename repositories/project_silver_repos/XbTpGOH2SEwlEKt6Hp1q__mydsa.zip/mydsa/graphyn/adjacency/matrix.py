"""Adjacency matrix representation of a graph."""
from __future__ import annotations
from typing import Any
from graphyn.core.types import NodeID, Weight

class AdjacencyMatrix:
    """Dense adjacency matrix representation.

    Stores edge weights in a 2D dictionary keyed by node IDs.
    Suitable for dense graphs where most node pairs are connected.

    Attributes:
        directed: Whether this matrix represents a directed graph.
    """
    def __init__(self, directed: bool = False) -> None:
        """Initialize an empty adjacency matrix.

        Args:
            directed: If True, edges are directional.
        """
        self._directed: bool = directed
        self._nodes: list[NodeID] = []
        self._index: dict[NodeID, int] = {}
        self._matrix: dict[int, dict[int, Weight]] = {}

    @property
    def directed(self) -> bool:
        """Whether this is a directed adjacency matrix."""
        return self._directed

    @property
    def size(self) -> int:
        """Return the number of nodes."""
        return len(self._nodes)

    def add_node(self, node_id: NodeID) -> None:
        """Add a node to the matrix.

        Args:
            node_id: The node identifier to add.
        """
        if node_id in self._index:
            return
        idx = len(self._nodes)
        self._nodes.append(node_id)
        self._index[node_id] = idx
        self._matrix[idx] = {}

    def set_edge(self, source: NodeID, target: NodeID, weight: Weight = 1.0) -> None:
        """Set an edge weight in the matrix.

        Args:
            source: Source node ID.
            target: Target node ID.
            weight: Edge weight.
        """
        si = self._index[source]
        ti = self._index[target]
        self._matrix[si][ti] = weight
        if not self._directed:
            self._matrix[ti][si] = weight

    def get_weight(self, source: NodeID, target: NodeID) -> Weight | None:
        """Get the weight of an edge, or None if no edge exists.

        Args:
            source: Source node ID.
            target: Target node ID.

        Returns:
            Edge weight or None.
        """
        si = self._index.get(source)
        ti = self._index.get(target)
        if si is None or ti is None:
            return None
        return self._matrix.get(si, {}).get(ti)

    def has_edge(self, source: NodeID, target: NodeID) -> bool:
        """Check if an edge exists between two nodes."""
        return self.get_weight(source, target) is not None

    def remove_edge(self, source: NodeID, target: NodeID) -> None:
        """Remove an edge from the matrix."""
        si = self._index[source]
        ti = self._index[target]
        self._matrix[si].pop(ti, None)
        if not self._directed:
            self._matrix[ti].pop(si, None)

    def neighbors(self, node_id: NodeID) -> list[NodeID]:
        """Return neighbor node IDs."""
        idx = self._index[node_id]
        result: list[NodeID] = []
        for ti, _ in self._matrix.get(idx, {}).items():
            result.append(self._nodes[ti])
        return result

    def get_node_ids(self) -> list[NodeID]:
        """Return all node IDs in insertion order."""
        return list(self._nodes)

    def edge_count(self) -> int:
        """Return the total number of edges."""
        total = sum(len(row) for row in self._matrix.values())
        if not self._directed:
            total //= 2
        return total

    def to_dense_list(self) -> list[list[float]]:
        """Convert to a dense 2D list.

        Returns:
            2D list with edge weights (0.0 for missing edges).
        """
        n = len(self._nodes)
        result: list[list[float]] = [[0.0] * n for _ in range(n)]
        for si, row in self._matrix.items():
            for ti, wt in row.items():
                result[si][ti] = wt
        return result

    @classmethod
    def from_graph(cls, graph: Any) -> AdjacencyMatrix:
        """Create an AdjacencyMatrix from a Graph or DiGraph instance.

        Args:
            graph: A Graph or DiGraph object.

        Returns:
            An AdjacencyMatrix populated from the graph.
        """
        directed = hasattr(graph, "_succ")
        matrix = cls(directed=directed)
        for nid in graph.get_node_ids():
            matrix.add_node(nid)
        for src, tgt, wt in graph.iter_edges():
            matrix.set_edge(src, tgt, wt)
        return matrix
