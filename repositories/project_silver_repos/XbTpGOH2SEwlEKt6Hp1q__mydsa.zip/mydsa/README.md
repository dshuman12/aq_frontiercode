# Graphyn

A production-grade Python graph analytics and network intelligence framework.

## Overview

Graphyn provides a comprehensive suite of graph algorithms and data structures
for building, analyzing, and visualizing complex networks. It is designed for
performance, type safety, and ease of use.

## Features

- **Core Graph Types**: Undirected Graph, Directed DiGraph with full adjacency
  list representation, node/edge dataclasses with metadata support.
- **Graph Builder**: Chainable API for constructing graphs from edge lists,
  adjacency dictionaries, or programmatic node/edge addition.
- **Adjacency Representations**: Matrix, list, and incidence matrix forms with
  conversion to/from core graph types.
- **Traversal Algorithms**: BFS, DFS, and iterative deepening DFS with layer
  support, path finding, and connected component discovery.
- **Pathfinding**: Dijkstra, A* (with pluggable heuristics), Bellman-Ford with
  negative cycle detection, and bidirectional A*.
- **All-Pairs Shortest Paths**: Floyd-Warshall (O(V^3)) and Johnson's algorithm
  (O(V^2 log V + VE)) for sparse graphs.
- **Centrality Measures**: Degree, betweenness (Brandes' O(VE)), closeness,
  harmonic, eigenvector (power iteration), and Katz centrality.
- **Community Detection**: Louvain method with resolution parameter, label
  propagation (sync and semi-sync), weighted label propagation, and modularity scoring.
- **Connected Components**: BFS-based undirected components, Tarjan's and
  Kosaraju's strongly connected components, articulation points, and bridges.
- **Minimum Spanning Trees**: Kruskal's (O(E log E)) and Prim's (O(E log V))
  with Union-Find data structure.
- **Network Flow**: Ford-Fulkerson (DFS-based), Edmonds-Karp (BFS-based, O(VE^2)),
  min-cut computation, and flow decomposition.
- **Graph Metrics**: Density, diameter, radius, eccentricity, clustering
  coefficient, transitivity, degree distribution, and assortativity.
- **Graph Coloring**: Greedy, Welsh-Powell, largest-first, smallest-last,
  and DSATUR heuristics with verification.
- **Topological Sorting**: Kahn's algorithm and DFS-based topological sort
  with cycle detection, topological levels, critical path, and longest path.
- **Cycle Detection**: Directed and undirected cycle detection, cycle
  enumeration (Johnson's algorithm), girth computation.
- **Serialization**: JSON, GraphML (XML), and DOT format import/export with
  file I/O utilities and adjacency list JSON format.
- **Streaming Pipeline**: Event-driven graph mutation processing with
  sliding time windows, filters, and handler registration.
- **Visualization**: SVG circular layout export, DOT rendering with community
  coloring, weighted edges, path highlighting, and adjacency matrix heatmaps.
- **Bipartite Graphs**: Bipartiteness checking, 2-coloring, bipartite sets,
  bipartite projection, Hopcroft-Karp matching, and odd cycle detection.
- **Graph Generators**: Erdos-Renyi G(n,p) and G(n,m), Barabasi-Albert
  preferential attachment, Watts-Strogatz small-world, random trees,
  random regular graphs, and classic graphs (complete, path, cycle, star, grid).
- **Graph Similarity**: Jaccard, cosine, overlap, Dice similarity, SimRank,
  role similarity, structural equivalence, and isomorphism checking.
- **Link Prediction**: Common neighbors, Jaccard, Adamic-Adar, preferential
  attachment, resource allocation, hub promoted/depressed, Salton, Sorensen,
  and LHN indices with a top-k prediction engine.
- **PageRank & HITS**: Classic PageRank with damping, personalized PageRank,
  convergence analysis, HITS hub/authority scores.

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

```python
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.traversal.bfs import bfs
from graphyn.pathfinding.dijkstra import dijkstra_path

# Create a graph
g = Graph(name="example")
g.add_node(Node(node_id="a", label="Alice"))
g.add_node(Node(node_id="b", label="Bob"))
g.add_node(Node(node_id="c", label="Charlie"))
g.add_edge(Edge(source="a", target="b", weight=1.0))
g.add_edge(Edge(source="b", target="c", weight=2.0))
g.add_edge(Edge(source="a", target="c", weight=5.0))

# Traverse
order = bfs(g, "a")
print(f"BFS order: {order}")

# Find shortest path
path, cost = dijkstra_path(g, "a", "c")
print(f"Shortest path: {path}, cost: {cost}")
```

## Testing

```bash
pytest tests/ -v
```

## Docker

```bash
docker build -t graphyn .
docker run graphyn
```

## Project Structure

```
graphyn/
├── core/           # Node, Edge, Graph, DiGraph, Protocols
├── builder/        # GraphBuilder, factories, loaders
├── adjacency/      # AdjacencyMatrix, AdjacencyList, IncidenceMatrix
├── traversal/      # BFS, DFS, IDDFS
├── pathfinding/    # Dijkstra, A*, Bellman-Ford
├── all_pairs/      # Floyd-Warshall, Johnson
├── centrality/     # Degree, betweenness, closeness, eigenvector
├── community/      # Louvain, label propagation, modularity
├── components/     # Connected, Tarjan, Kosaraju
├── mst/            # Kruskal, Prim, Union-Find
├── flow/           # Ford-Fulkerson, Edmonds-Karp, min-cut
├── metrics/        # Density, diameter, clustering, degree dist
├── coloring/       # Greedy, Welsh-Powell, DSATUR
├── topo_sort/      # Kahn, DFS-based
├── cycles/         # Detection, enumeration
├── serialization/  # JSON, GraphML, DOT
├── streaming/      # Pipeline, events, sliding window
├── visualization/  # SVG, DOT render, heatmap
├── bipartite/      # Checking, matching
├── generators/     # Random and classic graphs
├── similarity/     # Measures, isomorphism
├── link_prediction/# Scores, predictor
└── pagerank/       # PageRank, HITS
```

## Requirements

- Python 3.11+
- pytest for testing

## License

MIT License

## Author

Birajit Saikia
