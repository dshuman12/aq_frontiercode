"""Tests for cycle detection."""
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.cycles.detection import has_cycle, find_cycle
from graphyn.cycles.enumeration import cycle_count

def test_acyclic_graph() -> None:
    """Tree should have no cycles."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=0, target=2))
    g.add_edge(Edge(source=2, target=3))
    assert not has_cycle(g)
    assert find_cycle(g) is None

def test_cycle_in_undirected() -> None:
    """Triangle should be detected as cycle."""
    g = Graph()
    for i in range(3):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=0))
    assert has_cycle(g)

def test_cycle_in_directed() -> None:
    """Directed cycle should be detected."""
    dg = DiGraph()
    for i in range(3):
        dg.add_node(Node(node_id=i))
    dg.add_edge(Edge(source=0, target=1))
    dg.add_edge(Edge(source=1, target=2))
    dg.add_edge(Edge(source=2, target=0))
    assert has_cycle(dg)
    cycle = find_cycle(dg)
    assert cycle is not None
    assert len(cycle) >= 3
