"""Tests for serialization."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.serialization.json_serializer import to_json, from_json
from graphyn.serialization.dot import to_dot

def test_json_roundtrip() -> None:
    """Graph should survive JSON serialization roundtrip."""
    g = Graph(name="test_graph")
    g.add_node(Node(node_id="a", label="A"))
    g.add_node(Node(node_id="b", label="B"))
    g.add_edge(Edge(source="a", target="b", weight=3.0))
    json_str = to_json(g)
    g2 = from_json(json_str)
    assert g2.node_count == 2
    assert g2.edge_count == 1
    assert g2.has_edge("a", "b")

def test_dot_export() -> None:
    """DOT export should produce valid format."""
    g = Graph(name="dot_test")
    g.add_node(Node(node_id="x"))
    g.add_node(Node(node_id="y"))
    g.add_edge(Edge(source="x", target="y"))
    dot = to_dot(g)
    assert "graph" in dot
    assert "x" in dot
    assert "y" in dot
