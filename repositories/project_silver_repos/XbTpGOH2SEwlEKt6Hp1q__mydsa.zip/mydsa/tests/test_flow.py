"""Tests for network flow algorithms."""
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.flow.ford_fulkerson import ford_fulkerson
from graphyn.flow.edmonds_karp import edmonds_karp
from graphyn.flow.min_cut import min_cut

def _flow_graph() -> DiGraph:
    dg = DiGraph()
    for n in ["s", "a", "b", "t"]:
        dg.add_node(Node(node_id=n))
    dg.add_edge(Edge(source="s", target="a", weight=10.0))
    dg.add_edge(Edge(source="s", target="b", weight=5.0))
    dg.add_edge(Edge(source="a", target="b", weight=3.0))
    dg.add_edge(Edge(source="a", target="t", weight=7.0))
    dg.add_edge(Edge(source="b", target="t", weight=8.0))
    return dg

def test_ford_fulkerson() -> None:
    """Ford-Fulkerson should find maximum flow."""
    dg = _flow_graph()
    max_flow, _ = ford_fulkerson(dg, "s", "t")
    assert max_flow == 15.0

def test_edmonds_karp() -> None:
    """Edmonds-Karp should match Ford-Fulkerson."""
    dg = _flow_graph()
    max_flow, _ = edmonds_karp(dg, "s", "t")
    assert max_flow == 15.0

def test_min_cut() -> None:
    """Min cut value should equal max flow."""
    dg = _flow_graph()
    cut_val, s_part, t_part = min_cut(dg, "s", "t")
    assert cut_val == 15.0
    assert "s" in s_part
    assert "t" in t_part
