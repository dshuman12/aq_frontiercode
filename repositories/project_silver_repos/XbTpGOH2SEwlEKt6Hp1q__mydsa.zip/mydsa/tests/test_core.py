"""Tests for core graph data structures."""
import pytest
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph

def test_node_creation() -> None:
    """Test basic node creation and properties."""
    node = Node(node_id="a", label="Alice")
    assert node.node_id == "a"
    assert node.label == "Alice"
    assert str(node) == "Node(Alice)"

def test_node_empty_id_raises() -> None:
    """Test that empty node ID raises ValueError."""
    with pytest.raises(ValueError):
        Node(node_id="  ")

def test_edge_creation() -> None:
    """Test edge creation and properties."""
    edge = Edge(source="a", target="b", weight=2.5)
    assert edge.source == "a"
    assert edge.target == "b"
    assert edge.weight == 2.5
    assert not edge.is_self_loop

def test_edge_self_loop() -> None:
    """Test self-loop detection."""
    edge = Edge(source="x", target="x")
    assert edge.is_self_loop

def test_graph_add_nodes_and_edges() -> None:
    """Test adding nodes and edges to undirected graph."""
    g = Graph(name="test")
    g.add_node(Node(node_id="a"))
    g.add_node(Node(node_id="b"))
    g.add_node(Node(node_id="c"))
    g.add_edge(Edge(source="a", target="b", weight=1.0))
    g.add_edge(Edge(source="b", target="c", weight=2.0))
    assert g.node_count == 3
    assert g.edge_count == 2
    assert g.has_edge("a", "b")
    assert g.has_edge("b", "a")
    assert not g.has_edge("a", "c")

def test_graph_neighbors() -> None:
    """Test neighbor retrieval."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_node(Node(node_id=3))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=1, target=3))
    neighbors = g.neighbors(1)
    assert set(neighbors) == {2, 3}

def test_digraph_directed_edges() -> None:
    """Test directed graph edge directionality."""
    dg = DiGraph(name="directed")
    dg.add_node(Node(node_id="x"))
    dg.add_node(Node(node_id="y"))
    dg.add_edge(Edge(source="x", target="y"))
    assert dg.has_edge("x", "y")
    assert not dg.has_edge("y", "x")
    assert dg.neighbors("x") == ["y"]
    assert dg.predecessors("y") == ["x"]

def test_graph_remove_node() -> None:
    """Test node removal cascades to edges."""
    g = Graph()
    g.add_node(Node(node_id="a"))
    g.add_node(Node(node_id="b"))
    g.add_edge(Edge(source="a", target="b"))
    g.remove_node("a")
    assert g.node_count == 1
    assert g.edge_count == 0
