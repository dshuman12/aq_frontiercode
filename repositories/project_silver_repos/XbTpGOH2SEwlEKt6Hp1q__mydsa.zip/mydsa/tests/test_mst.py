"""Tests for minimum spanning tree."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.mst.kruskal import kruskal_mst, kruskal_mst_weight
from graphyn.mst.prim import prim_mst_weight
from graphyn.mst.union_find import UnionFind

def _weighted_graph() -> Graph:
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1, weight=1.0))
    g.add_edge(Edge(source=0, target=2, weight=3.0))
    g.add_edge(Edge(source=1, target=2, weight=2.0))
    g.add_edge(Edge(source=2, target=3, weight=4.0))
    return g

def test_kruskal_mst() -> None:
    """Kruskal MST should find correct weight."""
    g = _weighted_graph()
    weight = kruskal_mst_weight(g)
    assert weight == 7.0

def test_prim_mst() -> None:
    """Prim MST weight should match Kruskal."""
    g = _weighted_graph()
    assert prim_mst_weight(g) == kruskal_mst_weight(g)

def test_union_find() -> None:
    """Union-Find should correctly track connected components."""
    uf: UnionFind[int] = UnionFind()
    for i in range(5):
        uf.make_set(i)
    uf.union(0, 1)
    uf.union(2, 3)
    assert uf.connected(0, 1)
    assert not uf.connected(0, 2)
    assert uf.count == 3
