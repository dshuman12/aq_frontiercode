"""Tests for streaming pipeline."""
from graphyn.core.graph import Graph
from graphyn.streaming.pipeline import StreamPipeline
from graphyn.streaming.events import GraphEvent, EventType
from graphyn.streaming.window import SlidingWindow

def test_stream_add_nodes() -> None:
    """Pipeline should add nodes from events."""
    g = Graph()
    p = StreamPipeline(g)
    p.process_event(GraphEvent.add_node("a", timestamp=1.0))
    p.process_event(GraphEvent.add_node("b", timestamp=2.0))
    assert g.node_count == 2
    assert p.event_count == 2

def test_stream_add_edges() -> None:
    """Pipeline should add edges from events."""
    g = Graph()
    p = StreamPipeline(g)
    p.process_event(GraphEvent.add_node("x"))
    p.process_event(GraphEvent.add_node("y"))
    p.process_event(GraphEvent.add_edge("x", "y"))
    assert g.edge_count == 1

def test_stream_batch() -> None:
    """Pipeline should process batch events."""
    g = Graph()
    p = StreamPipeline(g)
    events = [
        GraphEvent.add_node("a"),
        GraphEvent.add_node("b"),
        GraphEvent.add_node("c"),
        GraphEvent.add_edge("a", "b"),
        GraphEvent.add_edge("b", "c"),
    ]
    count = p.process_batch(events)
    assert count == 5
    assert g.node_count == 3

def test_sliding_window() -> None:
    """Sliding window should expire old events."""
    w = SlidingWindow(window_size=10.0)
    w.add_event(GraphEvent.add_node("a", timestamp=1.0))
    w.add_event(GraphEvent.add_node("b", timestamp=5.0))
    w.add_event(GraphEvent.add_node("c", timestamp=15.0))
    events = w.get_events(current_time=15.0)
    assert len(events) == 2

def test_event_rate() -> None:
    """Event rate should be computed correctly."""
    w = SlidingWindow(window_size=10.0)
    for i in range(5):
        w.add_event(GraphEvent.add_node(f"n{i}", timestamp=float(i)))
    rate = w.event_rate(10.0)
    assert rate > 0

def test_pipeline_stats() -> None:
    """Pipeline stats should track metrics."""
    g = Graph()
    p = StreamPipeline(g)
    p.process_event(GraphEvent.add_node("a"))
    stats = p.get_stats()
    assert stats["processed"] == 1
    assert stats["node_count"] == 1
