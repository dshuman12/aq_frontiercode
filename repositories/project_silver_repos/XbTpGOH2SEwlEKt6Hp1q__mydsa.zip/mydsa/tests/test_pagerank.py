"""Tests for PageRank."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.pagerank.pagerank import pagerank

def test_pagerank_sums_to_one() -> None:
    """PageRank scores should sum to approximately 1."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    g.add_edge(Edge(source=3, target=4))
    pr = pagerank(g)
    assert abs(sum(pr.values()) - 1.0) < 1e-6
