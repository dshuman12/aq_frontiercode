"""Tests for community detection."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.community.label_propagation import label_propagation
from graphyn.community.modularity import modularity_score

def _two_clique_graph() -> Graph:
    g = Graph()
    for i in range(6):
        g.add_node(Node(node_id=i))
    for i in range(3):
        for j in range(i + 1, 3):
            g.add_edge(Edge(source=i, target=j))
    for i in range(3, 6):
        for j in range(i + 1, 6):
            g.add_edge(Edge(source=i, target=j))
    g.add_edge(Edge(source=2, target=3))
    return g

def test_label_propagation_finds_communities() -> None:
    """Label propagation should detect the two cliques."""
    g = _two_clique_graph()
    communities = label_propagation(g, seed=42)
    assert len(communities) >= 1
    total_nodes = sum(len(c) for c in communities)
    assert total_nodes == 6

def test_modularity_positive() -> None:
    """Good partition should have positive modularity."""
    g = _two_clique_graph()
    partition = [{0, 1, 2}, {3, 4, 5}]
    q = modularity_score(g, partition)
    assert q > 0
