"""Tests for pathfinding algorithms."""
import pytest
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.pathfinding.dijkstra import dijkstra_path
from graphyn.pathfinding.bellman_ford import bellman_ford_path

def _weighted_graph() -> Graph:
    g = Graph()
    for nid in ["a", "b", "c", "d"]:
        g.add_node(Node(node_id=nid))
    g.add_edge(Edge(source="a", target="b", weight=1.0))
    g.add_edge(Edge(source="b", target="c", weight=2.0))
    g.add_edge(Edge(source="a", target="c", weight=5.0))
    g.add_edge(Edge(source="c", target="d", weight=1.0))
    return g

def test_dijkstra_shortest_path() -> None:
    """Dijkstra should find shortest weighted path."""
    g = _weighted_graph()
    path, cost = dijkstra_path(g, "a", "d")
    assert path == ["a", "b", "c", "d"]
    assert cost == 4.0

def test_bellman_ford_shortest_path() -> None:
    """Bellman-Ford should find shortest path."""
    g = _weighted_graph()
    path, cost = bellman_ford_path(g, "a", "d")
    assert cost == 4.0
    assert path[0] == "a"
    assert path[-1] == "d"
