"""Tests for graph coloring algorithms."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.coloring.greedy import (
    greedy_coloring, verify_coloring, dsatur_coloring,
    chromatic_number_upper
)
from graphyn.coloring.welsh_powell import welsh_powell_coloring

def _triangle_graph() -> Graph:
    g = Graph()
    for i in range(3):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=0, target=2))
    return g

def test_greedy_coloring_valid() -> None:
    """Greedy coloring should produce valid coloring."""
    g = _triangle_graph()
    coloring = greedy_coloring(g)
    assert verify_coloring(g, coloring)

def test_triangle_needs_3_colors() -> None:
    """Triangle graph requires 3 colors."""
    g = _triangle_graph()
    assert chromatic_number_upper(g) == 3

def test_welsh_powell_valid() -> None:
    """Welsh-Powell should produce valid coloring."""
    g = _triangle_graph()
    coloring = welsh_powell_coloring(g)
    assert verify_coloring(g, coloring)

def test_dsatur_valid() -> None:
    """DSATUR should produce valid coloring."""
    g = _triangle_graph()
    coloring = dsatur_coloring(g)
    assert verify_coloring(g, coloring)

def test_bipartite_2_colorable() -> None:
    """Path graph should be 2-colorable."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    coloring = greedy_coloring(g)
    assert max(coloring.values()) + 1 <= 2
