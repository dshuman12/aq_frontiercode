"""Integration tests for end-to-end workflows."""
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.builder.builder import GraphBuilder
from graphyn.traversal.bfs import bfs, bfs_path
from graphyn.traversal.dfs import dfs
from graphyn.pathfinding.dijkstra import dijkstra_path
from graphyn.centrality.degree import degree_centrality
from graphyn.mst.kruskal import kruskal_mst_weight
from graphyn.coloring.greedy import greedy_coloring, verify_coloring
from graphyn.serialization.json_serializer import to_json, from_json
from graphyn.generators.classic import complete_graph, cycle_graph
from graphyn.metrics.density import graph_density
from graphyn.pagerank.pagerank import pagerank
from graphyn.streaming.pipeline import StreamPipeline
from graphyn.streaming.events import GraphEvent

def test_builder_to_traversal() -> None:
    """Build graph with builder and traverse it."""
    builder = GraphBuilder()
    builder.add_node("a").add_node("b").add_node("c")
    builder.add_edge("a", "b").add_edge("b", "c")
    g = builder.build()
    order = bfs(g, "a")
    assert set(order) == {"a", "b", "c"}

def test_builder_path_to_pathfinding() -> None:
    """Build path graph and find shortest path."""
    builder = GraphBuilder()
    for n in ["a", "b", "c", "d"]:
        builder.add_node(n)
    builder.add_edge("a", "b", 1.0)
    builder.add_edge("b", "c", 2.0)
    builder.add_edge("a", "c", 10.0)
    builder.add_edge("c", "d", 1.0)
    g = builder.build()
    path, cost = dijkstra_path(g, "a", "d")
    assert cost == 4.0

def test_json_roundtrip_preserves_structure() -> None:
    """Full serialization roundtrip preserves graph."""
    g = complete_graph(4)
    json_str = to_json(g)
    g2 = from_json(json_str)
    assert g2.node_count == g.node_count
    assert g2.edge_count == g.edge_count

def test_centrality_on_generated_graph() -> None:
    """Centrality on generated complete graph."""
    g = complete_graph(5)
    cent = degree_centrality(g)
    for v in cent.values():
        assert abs(v - 1.0) < 1e-6

def test_coloring_on_cycle() -> None:
    """Cycle graph coloring should be valid."""
    g = cycle_graph(6)
    coloring = greedy_coloring(g)
    assert verify_coloring(g, coloring)

def test_density_complete_graph() -> None:
    """Complete graph density is 1.0."""
    g = complete_graph(5)
    assert abs(graph_density(g) - 1.0) < 1e-6

def test_mst_weight_consistency() -> None:
    """MST weight should be deterministic."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1, weight=1.0))
    g.add_edge(Edge(source=1, target=2, weight=2.0))
    g.add_edge(Edge(source=2, target=3, weight=3.0))
    g.add_edge(Edge(source=3, target=4, weight=4.0))
    g.add_edge(Edge(source=0, target=4, weight=10.0))
    assert kruskal_mst_weight(g) == 10.0

def test_pagerank_on_cycle() -> None:
    """PageRank on cycle should be uniform."""
    g = cycle_graph(4)
    pr = pagerank(g)
    values = list(pr.values())
    for v in values:
        assert abs(v - 0.25) < 0.05

def test_streaming_pipeline() -> None:
    """Streaming pipeline should process events."""
    g = Graph()
    pipeline = StreamPipeline(g)
    pipeline.process_event(GraphEvent.add_node("x"))
    pipeline.process_event(GraphEvent.add_node("y"))
    pipeline.process_event(GraphEvent.add_edge("x", "y"))
    assert g.node_count == 2
    assert g.edge_count == 1

def test_digraph_traversal() -> None:
    """Directed graph BFS should respect edge direction."""
    dg = DiGraph()
    for n in ["a", "b", "c"]:
        dg.add_node(Node(node_id=n))
    dg.add_edge(Edge(source="a", target="b"))
    dg.add_edge(Edge(source="b", target="c"))
    order = bfs(dg, "a")
    assert order == ["a", "b", "c"]

def test_full_pipeline_workflow() -> None:
    """Complete workflow: build, analyze, serialize."""
    builder = GraphBuilder()
    for i in range(6):
        builder.add_node(i)
    edges = [(0, 1), (0, 2), (1, 2), (1, 3), (2, 3), (3, 4), (4, 5)]
    for u, v in edges:
        builder.add_edge(u, v)
    g = builder.build()
    assert g.node_count == 6
    assert g.edge_count == 7
    cent = degree_centrality(g)
    assert cent[3] > cent[5]
    json_str = to_json(g)
    g2 = from_json(json_str)
    assert g2.edge_count == 7
    pr = pagerank(g)
    assert sum(pr.values()) > 0.99
