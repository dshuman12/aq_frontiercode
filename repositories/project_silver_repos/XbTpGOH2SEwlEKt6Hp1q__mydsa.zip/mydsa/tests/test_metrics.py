"""Tests for graph metrics."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.metrics.density import graph_density
from graphyn.metrics.diameter import graph_diameter
from graphyn.metrics.clustering import clustering_coefficient, avg_clustering
from graphyn.metrics.degree_dist import degree_distribution, average_degree

def _complete4() -> Graph:
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    for i in range(4):
        for j in range(i + 1, 4):
            g.add_edge(Edge(source=i, target=j))
    return g

def test_density_complete() -> None:
    """Complete graph should have density 1.0."""
    g = _complete4()
    assert abs(graph_density(g) - 1.0) < 1e-6

def test_diameter_path() -> None:
    """Path graph diameter should be n-1."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    for i in range(4):
        g.add_edge(Edge(source=i, target=i + 1))
    assert graph_diameter(g) == 4.0

def test_clustering_complete() -> None:
    """Complete graph should have clustering coefficient 1.0."""
    g = _complete4()
    assert abs(clustering_coefficient(g, 0) - 1.0) < 1e-6

def test_avg_clustering() -> None:
    """Average clustering of complete graph should be 1.0."""
    g = _complete4()
    assert abs(avg_clustering(g) - 1.0) < 1e-6

def test_degree_distribution() -> None:
    """Degree distribution should sum to 1."""
    g = _complete4()
    dist = degree_distribution(g)
    assert abs(sum(dist.values()) - 1.0) < 1e-6

def test_average_degree() -> None:
    """K4 should have average degree 3."""
    g = _complete4()
    assert abs(average_degree(g) - 3.0) < 1e-6
