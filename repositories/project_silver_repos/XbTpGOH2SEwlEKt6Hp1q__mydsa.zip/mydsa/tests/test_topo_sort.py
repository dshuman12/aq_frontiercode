"""Tests for topological sorting."""
import pytest
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.topo_sort.kahn import (
    kahn_topo_sort, is_dag, CycleDetectedError,
    topological_levels, longest_path_dag
)
from graphyn.topo_sort.dfs_topo import dfs_topo_sort

def _make_dag() -> DiGraph:
    dg = DiGraph()
    for n in ["a", "b", "c", "d"]:
        dg.add_node(Node(node_id=n))
    dg.add_edge(Edge(source="a", target="b"))
    dg.add_edge(Edge(source="a", target="c"))
    dg.add_edge(Edge(source="b", target="d"))
    dg.add_edge(Edge(source="c", target="d"))
    return dg

def test_kahn_topo_sort() -> None:
    """Kahn's sort should produce valid topological order."""
    dg = _make_dag()
    order = kahn_topo_sort(dg)
    assert order.index("a") < order.index("b")
    assert order.index("a") < order.index("c")
    assert order.index("b") < order.index("d")

def test_dfs_topo_sort() -> None:
    """DFS topo sort should produce valid order."""
    dg = _make_dag()
    order = dfs_topo_sort(dg)
    assert order.index("a") < order.index("d")

def test_cycle_detection() -> None:
    """Cycle should be detected in non-DAG."""
    dg = DiGraph()
    for n in ["x", "y", "z"]:
        dg.add_node(Node(node_id=n))
    dg.add_edge(Edge(source="x", target="y"))
    dg.add_edge(Edge(source="y", target="z"))
    dg.add_edge(Edge(source="z", target="x"))
    assert not is_dag(dg)
    with pytest.raises(CycleDetectedError):
        kahn_topo_sort(dg)

def test_topological_levels() -> None:
    """Topological levels should group by dependency depth."""
    dg = _make_dag()
    levels = topological_levels(dg)
    assert levels[0] == ["a"]
    assert set(levels[-1]) == {"d"}

def test_longest_path_dag() -> None:
    """Longest path should be computed correctly."""
    dg = _make_dag()
    assert longest_path_dag(dg) == 2
