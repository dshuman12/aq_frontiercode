"""Tests for adjacency representations."""
from graphyn.adjacency.adjacency_list import AdjacencyList
from graphyn.adjacency.matrix import AdjacencyMatrix
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge

def test_adjacency_list_basic() -> None:
    """Basic adjacency list operations."""
    al = AdjacencyList()
    al.add_edge("a", "b", 1.0)
    al.add_edge("b", "c", 2.0)
    assert al.has_edge("a", "b")
    assert al.has_edge("b", "a")
    assert not al.has_edge("a", "c")
    assert al.degree("b") == 2
    assert al.edge_count == 2

def test_adjacency_list_directed() -> None:
    """Directed adjacency list should not add reverse edges."""
    al = AdjacencyList(directed=True)
    al.add_edge("a", "b")
    assert al.has_edge("a", "b")
    assert not al.has_edge("b", "a")

def test_adjacency_list_from_graph() -> None:
    """Conversion from Graph should preserve structure."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_node(Node(node_id=3))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    al = AdjacencyList.from_graph(g)
    assert len(al) == 3
    assert al.has_edge(1, 2)

def test_adjacency_list_remove() -> None:
    """Edge removal should work correctly."""
    al = AdjacencyList()
    al.add_edge("x", "y")
    assert al.has_edge("x", "y")
    al.remove_edge("x", "y")
    assert not al.has_edge("x", "y")

def test_adjacency_matrix_from_graph() -> None:
    """Matrix should represent graph correctly."""
    g = Graph()
    for i in range(3):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1, weight=2.0))
    g.add_edge(Edge(source=1, target=2, weight=3.0))
    mat = AdjacencyMatrix.from_graph(g)
    assert mat.get_weight(0, 1) == 2.0
    assert mat.get_weight(1, 0) == 2.0
    assert mat.get_weight(0, 2) is None
