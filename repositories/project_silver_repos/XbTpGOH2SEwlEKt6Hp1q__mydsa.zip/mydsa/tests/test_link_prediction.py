"""Tests for link prediction."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.link_prediction.scores import (
    common_neighbors_score, jaccard_score,
    adamic_adar_score, preferential_attachment_score,
)
from graphyn.link_prediction.predictor import LinkPredictor

def _test_graph() -> Graph:
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=0, target=2))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=1, target=3))
    g.add_edge(Edge(source=2, target=3))
    return g

def test_common_neighbors() -> None:
    """Nodes 0 and 3 share neighbors 1 and 2."""
    g = _test_graph()
    assert common_neighbors_score(g, 0, 3) == 2

def test_jaccard() -> None:
    """Jaccard score should be between 0 and 1."""
    g = _test_graph()
    score = jaccard_score(g, 0, 3)
    assert 0.0 <= score <= 1.0

def test_preferential_attachment() -> None:
    """PA score should be product of degrees."""
    g = _test_graph()
    score = preferential_attachment_score(g, 0, 4)
    assert score == 2 * 0

def test_predictor() -> None:
    """Link predictor should return predictions."""
    g = _test_graph()
    predictor = LinkPredictor(g)
    preds = predictor.predict(top_k=3)
    assert isinstance(preds, list)
    for u, v, score in preds:
        assert not g.has_edge(u, v)
