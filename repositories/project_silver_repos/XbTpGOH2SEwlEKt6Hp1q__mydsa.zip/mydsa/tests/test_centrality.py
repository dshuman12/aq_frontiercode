"""Tests for centrality algorithms."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.centrality.degree import degree_centrality

def test_degree_centrality_star() -> None:
    """Center of star graph should have highest centrality."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    for i in range(1, 5):
        g.add_edge(Edge(source=0, target=i))
    cent = degree_centrality(g)
    assert cent[0] == 1.0
    for i in range(1, 5):
        assert cent[i] == 0.25
