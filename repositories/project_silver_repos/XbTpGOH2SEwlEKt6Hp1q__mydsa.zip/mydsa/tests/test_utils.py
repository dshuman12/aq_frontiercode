"""Tests for utility functions."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.utils.validation import validate_graph, has_self_loops, is_simple
from graphyn.utils.stats import graph_summary, compare_graphs, weight_statistics

def test_validate_clean_graph() -> None:
    """Clean graph should have no issues."""
    g = Graph()
    g.add_node(Node(node_id="a"))
    g.add_node(Node(node_id="b"))
    g.add_edge(Edge(source="a", target="b"))
    issues = validate_graph(g)
    assert len([i for i in issues if "Self-loop" in i]) == 0

def test_no_self_loops() -> None:
    """Simple graph should have no self-loops."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_edge(Edge(source=1, target=2))
    assert not has_self_loops(g)

def test_is_simple() -> None:
    """Simple graph should pass simplicity check."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_edge(Edge(source=1, target=2))
    assert is_simple(g)

def test_graph_summary() -> None:
    """Summary should contain expected fields."""
    g = Graph(name="test")
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_edge(Edge(source=1, target=2))
    s = graph_summary(g)
    assert s["node_count"] == 2
    assert s["edge_count"] == 1
    assert s["name"] == "test"

def test_compare_same_graph() -> None:
    """Comparing graph to itself should show same structure."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_edge(Edge(source=1, target=2))
    result = compare_graphs(g, g)
    assert result["same_structure"]

def test_weight_stats() -> None:
    """Weight statistics should be computed."""
    g = Graph()
    g.add_node(Node(node_id=1))
    g.add_node(Node(node_id=2))
    g.add_node(Node(node_id=3))
    g.add_edge(Edge(source=1, target=2, weight=2.0))
    g.add_edge(Edge(source=2, target=3, weight=4.0))
    ws = weight_statistics(g)
    assert ws["min"] == 2.0
    assert ws["max"] == 4.0
    assert ws["total"] == 6.0
