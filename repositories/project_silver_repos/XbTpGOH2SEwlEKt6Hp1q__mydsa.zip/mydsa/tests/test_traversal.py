"""Tests for graph traversal algorithms."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.traversal.bfs import bfs, bfs_path
from graphyn.traversal.dfs import dfs

def _make_test_graph() -> Graph:
    g = Graph()
    for nid in ["a", "b", "c", "d", "e"]:
        g.add_node(Node(node_id=nid))
    g.add_edge(Edge(source="a", target="b"))
    g.add_edge(Edge(source="a", target="c"))
    g.add_edge(Edge(source="b", target="d"))
    g.add_edge(Edge(source="c", target="d"))
    g.add_edge(Edge(source="d", target="e"))
    return g

def test_bfs_visits_all() -> None:
    """BFS should visit all connected nodes."""
    g = _make_test_graph()
    order = bfs(g, "a")
    assert set(order) == {"a", "b", "c", "d", "e"}
    assert order[0] == "a"

def test_bfs_path() -> None:
    """BFS path should find shortest unweighted path."""
    g = _make_test_graph()
    path = bfs_path(g, "a", "e")
    assert path is not None
    assert path[0] == "a"
    assert path[-1] == "e"

def test_dfs_visits_all() -> None:
    """DFS should visit all connected nodes."""
    g = _make_test_graph()
    order = dfs(g, "a")
    assert set(order) == {"a", "b", "c", "d", "e"}
    assert order[0] == "a"
