"""Tests for connected components."""
from graphyn.core.graph import Graph
from graphyn.core.digraph import DiGraph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.components.connected import (
    connected_components, is_connected, number_of_components,
    largest_component, articulation_points, bridges
)
from graphyn.components.tarjan import tarjan_scc
from graphyn.components.kosaraju import kosaraju_scc

def test_connected_components() -> None:
    """Test basic component detection."""
    g = Graph()
    for i in range(6):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=3, target=4))
    comps = connected_components(g)
    assert len(comps) == 3
    assert not is_connected(g)

def test_connected_graph() -> None:
    """Test is_connected on a connected graph."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    assert is_connected(g)
    assert number_of_components(g) == 1

def test_largest_component() -> None:
    """Test largest component finding."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=3, target=4))
    lc = largest_component(g)
    assert len(lc) == 3

def test_tarjan_scc() -> None:
    """Test Tarjan's strongly connected components."""
    dg = DiGraph()
    for i in range(4):
        dg.add_node(Node(node_id=i))
    dg.add_edge(Edge(source=0, target=1))
    dg.add_edge(Edge(source=1, target=2))
    dg.add_edge(Edge(source=2, target=0))
    dg.add_edge(Edge(source=2, target=3))
    sccs = tarjan_scc(dg)
    scc_sizes = sorted([len(s) for s in sccs])
    assert scc_sizes == [1, 3]

def test_kosaraju_scc() -> None:
    """Test Kosaraju's SCC algorithm."""
    dg = DiGraph()
    for i in range(4):
        dg.add_node(Node(node_id=i))
    dg.add_edge(Edge(source=0, target=1))
    dg.add_edge(Edge(source=1, target=2))
    dg.add_edge(Edge(source=2, target=0))
    dg.add_edge(Edge(source=2, target=3))
    sccs = kosaraju_scc(dg)
    scc_sizes = sorted([len(s) for s in sccs])
    assert scc_sizes == [1, 3]

def test_articulation_points() -> None:
    """Test articulation point detection."""
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    g.add_edge(Edge(source=3, target=4))
    aps = articulation_points(g)
    assert 1 in aps
    assert 2 in aps
    assert 3 in aps
