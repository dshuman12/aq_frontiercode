"""Tests for bipartite graph utilities."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.bipartite.checking import is_bipartite, bipartite_sets
from graphyn.bipartite.matching import maximum_matching

def test_bipartite_check() -> None:
    """Even cycle should be bipartite."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=3))
    g.add_edge(Edge(source=3, target=0))
    assert is_bipartite(g)

def test_non_bipartite() -> None:
    """Odd cycle should not be bipartite."""
    g = Graph()
    for i in range(3):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=1, target=2))
    g.add_edge(Edge(source=2, target=0))
    assert not is_bipartite(g)

def test_bipartite_sets() -> None:
    """Bipartite sets should be disjoint."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=2, target=3))
    result = bipartite_sets(g)
    assert result is not None
    a, b = result
    assert not (a & b)
    assert len(a) + len(b) == 4

def test_maximum_matching() -> None:
    """Maximum matching should be found."""
    g = Graph()
    for i in range(4):
        g.add_node(Node(node_id=i))
    g.add_edge(Edge(source=0, target=1))
    g.add_edge(Edge(source=2, target=3))
    matching = maximum_matching(g)
    assert len(matching) >= 1
