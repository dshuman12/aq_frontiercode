"""Tests for graph generators."""
from graphyn.generators.classic import complete_graph, path_graph, cycle_graph
from graphyn.generators.random_graphs import erdos_renyi

def test_complete_graph() -> None:
    """Complete graph K_5 should have 10 edges."""
    g = complete_graph(5)
    assert g.node_count == 5
    assert g.edge_count == 10

def test_path_graph() -> None:
    """Path graph P_4 should have 3 edges."""
    g = path_graph(4)
    assert g.node_count == 4
    assert g.edge_count == 3

def test_cycle_graph() -> None:
    """Cycle graph C_5 should have 5 edges."""
    g = cycle_graph(5)
    assert g.node_count == 5
    assert g.edge_count == 5

def test_erdos_renyi() -> None:
    """Erdos-Renyi G(10, 0.5) should have 10 nodes."""
    g = erdos_renyi(10, 0.5, seed=42)
    assert g.node_count == 10
