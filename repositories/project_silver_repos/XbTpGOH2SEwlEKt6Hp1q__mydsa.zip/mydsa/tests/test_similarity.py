"""Tests for graph similarity."""
from graphyn.core.graph import Graph
from graphyn.core.node import Node
from graphyn.core.edge import Edge
from graphyn.similarity.measures import (
    jaccard_similarity, cosine_similarity,
    structural_equivalence, graph_edit_distance_estimate,
)
from graphyn.similarity.isomorphism import is_isomorphic_candidate

def _star5() -> Graph:
    g = Graph()
    for i in range(5):
        g.add_node(Node(node_id=i))
    for i in range(1, 5):
        g.add_edge(Edge(source=0, target=i))
    return g

def test_jaccard_same_neighborhood() -> None:
    """Leaves of a star have high Jaccard similarity."""
    g = _star5()
    score = jaccard_similarity(g, 1, 2)
    assert score > 0

def test_structural_equivalence() -> None:
    """Star leaves should be structurally equivalent."""
    g = _star5()
    assert structural_equivalence(g, 1, 2)

def test_isomorphic_same_graph() -> None:
    """Same graph should pass isomorphism check."""
    g1 = _star5()
    g2 = _star5()
    assert is_isomorphic_candidate(g1, g2)

def test_edit_distance_same() -> None:
    """Same graph should have 0 edit distance estimate."""
    g = _star5()
    assert graph_edit_distance_estimate(g, g) == 0
