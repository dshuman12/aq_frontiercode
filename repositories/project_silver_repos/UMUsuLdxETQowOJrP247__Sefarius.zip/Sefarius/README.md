# NF-e System — Sistema de Notas Fiscais Eletrônicas

Sistema completo de **emissão, faturamento, controle de estoque e impressão** de Notas Fiscais Eletrônicas, construído sobre uma arquitetura de microsserviços em Go e front-end Angular 17 com Design System proprietário.

<div align="center">

![Status](https://img.shields.io/badge/Status-Produção-00BC7D?style=for-the-badge)
![Angular](https://img.shields.io/badge/Angular-17.0.0-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Go](https://img.shields.io/badge/Go-1.21+-00ADD8?style=for-the-badge&logo=go&logoColor=white)
![Fiber](https://img.shields.io/badge/Fiber-Framework-00ACD7?style=for-the-badge)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-4169E1?style=for-the-badge&logo=postgresql&logoColor=white)
![Docker](https://img.shields.io/badge/Docker_Compose-2496ED?style=for-the-badge&logo=docker&logoColor=white)
![SCSS](https://img.shields.io/badge/SCSS-CC6699?style=for-the-badge&logo=sass&logoColor=white)
![ESLint](https://img.shields.io/badge/ESLint-4B32C3?style=for-the-badge&logo=eslint&logoColor=white)
![CI/CD](https://img.shields.io/badge/GitHub_Actions-CI-2088FF?style=for-the-badge&logo=githubactions&logoColor=white)

</div>

---

## 📋 Índice

- [Visão Geral](#-visão-geral)
- [Decisões Técnicas (Trade-offs)](#-decisões-técnicas-trade-offs)
- [Tecnologias](#-stack-tecnológica)
- [Arquitetura](#-arquitetura-de-microsserviços)
- [Clean Architecture](#-clean-architecture-por-serviço)
- [Estrutura de Pastas](#-estrutura-de-pastas-completa)
- [Banco de Dados](#-banco-de-dados)
- [API — Rotas e Endpoints](#-api--rotas-e-endpoints)
- [Frontend — Angular 17](#-frontend--angular-17)
- [Design System](#-design-system)
- [Padrões de Resiliência](#-padrões-de-resiliência)
- [CI/CD e Qualidade](#-cicd-e-qualidade-de-código)
- [Instalação e Execução](#-instalação-e-execução)
- [Variáveis de Ambiente](#-variáveis-de-ambiente)
- [Scripts Disponíveis](#-scripts-disponíveis)
- [Autor](#-autor)

---

## 🎯 Visão Geral

Este projeto moderniza o fluxo completo de **faturamento logístico de NF-e**, desde o cadastro de produtos no estoque até a emissão, fechamento e impressão de notas fiscais. Ele resolve problemas reais de concorrência, duplicidade de faturamento e falhas em cascata, usando:

| Problema Real                       | Solução Implementada                                                       |
| ----------------------------------- | -------------------------------------------------------------------------- |
| Dupla emissão por retry de rede     | **Idempotency Keys** (UUID v4) com log persistente em PostgreSQL           |
| Race-condition no estoque           | **Pessimistic Locking** (`SELECT ... FOR UPDATE`) com nível `Serializable` |
| Queda de microsserviço derruba tudo | **Circuit Breaker** (CLOSED → OPEN → HALF_OPEN) no API Gateway             |
| Impressão travando a UI             | **Print Job Async** com fila + **polling reativo** (RxJS `switchMap`)      |
| Requisições instáveis na rede       | **Retry com Exponential Backoff** (3 tentativas, multiplicador 2x)         |
| Timeout e sobrecarga                | **Rate Limiting** (100 req/min por IP, Sliding Window)                     |

---

## 🧠 Decisões Técnicas (Trade-offs)

| Decisão                                           | Justificativa                                                                                                                                       |
| ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Go + Fiber** (não Gin, Echo)                    | Fiber opera sobre fasthttp — throughput ~10x superior ao `net/http` em benchmarks de payload JSON. Ideal para proxy reverso com body forwarding     |
| **Microsserviços separados** (não monolito)       | Cada domínio (estoque, faturamento, impressão) escala independentemente; fault isolation garante que uma falha no print-service não afeta o billing |
| **PostgreSQL schemas** (não databases separados)  | Schemas segregam dados por serviço mantendo um único pool de conexão; simplifica migrations e queries cross-schema quando necessário                |
| **Angular Standalone Components** (não NgModules) | Angular 17 incentiva `standalone: true` para tree-shaking otimizado e lazy-loading nativo por rota                                                  |
| **SCSS com Design Tokens** (não Tailwind)         | Variáveis SCSS garantem consistência no design system sem acoplamento a frameworks utility-first; facilita theming e controle granular              |
| **Polling** (não WebSocket)                       | Para o print-service, o volume de jobs não justifica a complexidade de WebSockets; polling com `interval` + `takeWhile` é mais simples e debugável  |

---

## 💻 Stack Tecnológica

### Frontend

| Tecnologia       | Versão  | Propósito                                                  |
| ---------------- | ------- | ---------------------------------------------------------- |
| Angular          | 17.0.0  | Framework SPA com Standalone Components e Lazy Loading     |
| RxJS             | 7.8.0   | Programação reativa (BehaviorSubjects, switchMap, polling) |
| Angular Material | 17.3.10 | Componentes CDK base (Dialog integration)                  |
| SCSS/Sass        | Nativo  | Pré-processador CSS com design tokens                      |
| TypeScript       | 5.2.x   | Tipagem estática com strict mode                           |

### Backend

| Tecnologia  | Versão      | Propósito                                                 |
| ----------- | ----------- | --------------------------------------------------------- |
| Go (Golang) | 1.21+       | Linguagem compilada com goroutines para alta concorrência |
| Fiber v2    | Latest      | Framework web sobre fasthttp (proxy reverso performático) |
| lib/pq      | Latest      | Driver PostgreSQL nativo para Go                          |
| Docker      | Multi-stage | Build otimizado (golang:1.21-alpine → alpine:latest)      |

### Infraestrutura

| Tecnologia           | Propósito                                                            |
| -------------------- | -------------------------------------------------------------------- |
| PostgreSQL 15 Alpine | RDBMS com schemas segregados, bloqueios pessimistas, sequences       |
| Docker Compose 3.8   | Orquestração de 6 containers com health checks e dependency ordering |
| GitHub Actions       | CI pipeline (lint, prettier, build de produção)                      |

---

## 🏗️ Arquitetura de Microsserviços

```
                          ┌─────────────────────────────────────┐
                          │     FRONTEND (Angular 17 + RxJS)    │
                          │    http://localhost:4200            │
                          │    Standalone Components            │
                          │    Lazy Loading por Rota            │
                          └──────────────┬──────────────────────┘
                                         │
                                    REST API
                                         │
                          ┌──────────────▼──────────────────────┐
                          │    API GATEWAY (Go + Fiber)          │
                          │    http://localhost:3000             │
                          │                                     │
                          │  ┌─────────────────────────────────┐│
                          │  │ Circuit Breaker │ Rate Limiter  ││
                          │  │ Retry+Backoff   │ CORS          ││
                          │  │ Request Logging │ Error Handler ││
                          │  └─────────────────────────────────┘│
                          └───┬────────┬────────┬────────┬──────┘
                              │        │        │        │
                         :5001    :5002    :5003    :5004
                              │        │        │        │
                    ┌─────────▼┐ ┌─────▼──┐ ┌───▼───┐ ┌──▼─────┐
                    │  Stock   │ │Billing │ │ Print │ │Invoice │
                    │ Service  │ │Service │ │Service│ │Service │
                    └────┬─────┘ └───┬────┘ └───┬───┘ └───┬────┘
                         │           │          │         │
                    ┌────▼───────────▼──────────▼─────────▼────┐
                    │             PostgreSQL 15                 │
                    │                                          │
                    │   stock.*  billing.*  print.*  shared.*  │
                    │   (schemas segregados por serviço)        │
                    └──────────────────────────────────────────┘
```

### Comunicação entre Serviços

| Origem                              | Destino                                                 | Motivo |
| ----------------------------------- | ------------------------------------------------------- | ------ |
| **billing-service** → stock-service | Reservar/liberar estoque ao criar/cancelar NF           |
| **print-service** → billing-service | Consultar/fechar NF durante processamento do print job  |
| **print-service** → stock-service   | Decrementar estoque definitivo após impressão concluída |
| **Frontend** → API Gateway          | Toda comunicação passa pelo proxy reverso na porta 3000 |

---

## 🧱 Clean Architecture (Por Serviço)

Cada microsserviço (exceto invoice-service, que é mais simples) segue rigorosamente **4 camadas**:

```
┌───────────────────────────────────────────────────┐
│                  interfaces/                       │
│   HTTP Handlers (Fiber) + Response DTOs            │
│   Recebe HTTP, valida input, devolve JSON          │
├───────────────────────────────────────────────────┤
│                  application/                      │
│   Use Cases + DTOs de entrada/saída                │
│   Orquestra lógica de negócio, chama domain        │
├───────────────────────────────────────────────────┤
│                  domain/                           │
│   Entities + Interfaces (contratos)                │
│   Regras puras, sem dependência de framework       │
├───────────────────────────────────────────────────┤
│                  infrastructure/                   │
│   PostgreSQL Repository + HTTP Clients externos    │
│   Implementa as interfaces do domain               │
└───────────────────────────────────────────────────┘
```

### Detalhamento por Serviço

| Serviço             | Porta | Camadas                                            | Arquivos | Responsabilidade                                                      |
| ------------------- | ----- | -------------------------------------------------- | -------- | --------------------------------------------------------------------- |
| **api-gateway**     | 3000  | `main.go` (monolítico)                             | 1        | Proxy reverso, Circuit Breaker, Rate Limiting, CORS                   |
| **stock-service**   | 5001  | domain → application → infrastructure → interfaces | 8        | CRUD de produtos, Pessimistic Lock, Reserve/Release/Decrement estoque |
| **billing-service** | 5002  | domain → application → infrastructure → interfaces | 9        | CRUD de NF-e, Idempotência, Close/Cancel com saga reversa             |
| **print-service**   | 5003  | domain → application → infrastructure → interfaces | 10       | Fila de impressão assíncrona, Worker background, Retry automático     |
| **invoice-service** | 5004  | `main.go` + domain                                 | 2        | Reporting: histórico e estatísticas agregadas de NF-e                 |

---

## 📁 Estrutura de Pastas Completa

```
notas_fiscais/
├── 📁 .github/
│   └── 📁 workflows/
│       └── 📄 ci.yml                              # GitHub Actions (lint + prettier + build)
│
├── 📁 backend/
│   ├── 📁 api-gateway/                             # 🌐 Proxy Reverso (Port 3000)
│   │   ├── 📄 main.go                              # ServiceRegistry, CircuitBreaker, ProxyRequest
│   │   └── 📄 Dockerfile                           # Multi-stage (golang:1.21-alpine → alpine)
│   │
│   ├── 📁 stock-service/                           # 📦 Estoque (Port 5001)
│   │   ├── 📁 domain/
│   │   │   ├── 📄 entity.go                        # Product (id, code, description, balance, version)
│   │   │   ├── 📄 interfaces.go                    # ProductRepository + ProductUseCase contracts
│   │   │   ├── 📄 errors.go                        # ErrProductNotFound, ErrInsufficientStock
│   │   │   └── 📄 constants.go                     # Domain constants
│   │   ├── 📁 application/
│   │   │   ├── 📄 dto.go                           # CreateProductInput, UpdateProductInput, StockReservation
│   │   │   └── 📄 use_cases.go                     # Business logic (CRUD, Reserve, Decrement)
│   │   ├── 📁 infrastructure/
│   │   │   └── 📄 persistence.go                   # PostgreSQL with SELECT ... FOR UPDATE
│   │   ├── 📁 interfaces/
│   │   │   ├── 📄 http_handler.go                  # Fiber handlers (6 endpoints)
│   │   │   └── 📄 response.go                      # Standard API response wrapper
│   │   ├── 📄 main.go                              # DI wiring, Fiber setup, graceful shutdown
│   │   └── 📄 Dockerfile
│   │
│   ├── 📁 billing-service/                         # 🧾 Faturamento (Port 5002)
│   │   ├── 📁 domain/
│   │   │   ├── 📄 entity.go                        # Invoice, InvoiceItem (Aggregate Root)
│   │   │   ├── 📄 interfaces.go                    # InvoiceRepo + IdempotencyRepo + StockClient
│   │   │   └── 📄 errors.go                        # ErrInvoiceNotFound, ErrInvalidStatus
│   │   ├── 📁 application/
│   │   │   ├── 📄 dto.go                           # CreateInvoiceInput + ItemInput
│   │   │   └── 📄 use_cases.go                     # Create, Close, Cancel (com saga rollback)
│   │   ├── 📁 infrastructure/
│   │   │   ├── 📄 persistence.go                   # InvoiceRepository + IdempotencyRepository (PG)
│   │   │   └── 📄 stock_client.go                  # HTTP client para stock-service
│   │   ├── 📁 interfaces/
│   │   │   ├── 📄 http_handler.go                  # Fiber handlers (7 endpoints)
│   │   │   └── 📄 response.go
│   │   ├── 📄 main.go
│   │   └── 📄 Dockerfile
│   │
│   ├── 📁 print-service/                           # 🖨️ Impressão Assíncrona (Port 5003)
│   │   ├── 📁 domain/
│   │   │   ├── 📄 entity.go                        # PrintJob (status machine: PENDING→PROCESSING→COMPLETED|FAILED)
│   │   │   └── 📄 interfaces.go                    # PrintJobRepo + BillingClient + StockClient + Worker
│   │   ├── 📁 application/
│   │   │   ├── 📄 dto.go                           # CreatePrintJobInput
│   │   │   └── 📄 use_cases.go                     # Create, Process (fecha NF + decrementa estoque)
│   │   ├── 📁 infrastructure/
│   │   │   ├── 📄 persistence.go                   # PrintJob PostgreSQL repository
│   │   │   ├── 📄 clients.go                       # HTTP clients (billing + stock)
│   │   │   └── 📄 worker.go                        # Background goroutine (polling de jobs pendentes)
│   │   ├── 📁 interfaces/
│   │   │   ├── 📄 http_handler.go                  # Fiber handlers (5 endpoints)
│   │   │   └── 📄 response.go
│   │   ├── 📄 main.go
│   │   └── 📄 Dockerfile
│   │
│   ├── 📁 invoice-service/                         # 📊 Reporting (Port 5004)
│   │   ├── 📁 domain/
│   │   │   └── 📄 entity.go                        # Invoice entity
│   │   ├── 📄 main.go                              # Inline handlers: /history + /stats
│   │   └── 📄 Dockerfile
│   │
│   └── 📁 scripts/
│       └── 📄 go-quality.sh                        # Batch: gofmt + go vet + go test + golangci-lint
│
├── 📁 database/
│   └── 📁 migrations/
│       ├── 📄 001_initial_schema.sql               # 4 schemas, 6 tabelas, sequences, grants
│       └── 📄 002_performance_indexes.sql          # 7 partial/composite indexes otimizados
│
├── 📁 frontend/                                     # 🎨 Angular 17 SPA
│   ├── 📁 src/
│   │   ├── 📁 app/
│   │   │   ├── 📄 app.component.ts                 # Root (sidebar + router-outlet)
│   │   │   ├── 📄 app.component.html               # Layout principal com navegação
│   │   │   ├── 📄 app.component.scss               # Sidebar + layout global
│   │   │   ├── 📄 app.routes.ts                    # 5 rotas (lazy loading por feature)
│   │   │   │
│   │   │   ├── 📁 features/                        # Componentes roteáveis (Lazy Loaded)
│   │   │   │   ├── 📁 dashboard/                   # Painel principal com KPIs
│   │   │   │   │   ├── 📄 dashboard.component.ts
│   │   │   │   │   ├── 📄 dashboard.component.html
│   │   │   │   │   └── 📄 dashboard.component.scss
│   │   │   │   ├── 📁 products/                    # CRUD completo de Produtos
│   │   │   │   │   ├── 📄 products.component.ts
│   │   │   │   │   ├── 📄 products.component.html
│   │   │   │   │   └── 📄 products.component.scss
│   │   │   │   └── 📁 invoices/                    # Listagem + Emissão de NF-e
│   │   │   │       ├── 📄 invoices.component.ts
│   │   │   │       ├── 📄 invoices.component.html
│   │   │   │       ├── 📄 invoices.component.scss
│   │   │   │       └── 📁 invoice-detail/          # Visualização + Print Flow
│   │   │   │           ├── 📄 invoice-detail.component.ts
│   │   │   │           ├── 📄 invoice-detail.component.html
│   │   │   │           └── 📄 invoice-detail.component.scss
│   │   │   │
│   │   │   └── 📁 shared/                          # Módulos reutilizáveis
│   │   │       ├── 📁 components/
│   │   │       │   ├── 📄 base.component.ts        # BaseComponent (unsubscribe automático)
│   │   │       │   ├── 📄 index.ts                 # Barrel exports
│   │   │       │   ├── 📁 card/                    # Card wrapper com título e ações
│   │   │       │   ├── 📁 confirm-dialog/          # Modal de confirmação (deleção)
│   │   │       │   ├── 📁 data-table/              # Tabela dinâmica genérica
│   │   │       │   ├── 📁 form-builder/            # Formulário dinâmico com validação
│   │   │       │   ├── 📁 header/                  # Header + Breadcrumb navegável
│   │   │       │   └── 📁 page-container/          # Container padronizado de páginas
│   │   │       ├── 📁 constants/
│   │   │       │   └── 📄 app.constants.ts         # Magic strings/numbers centralizados
│   │   │       ├── 📁 interceptors/
│   │   │       │   ├── 📄 error.interceptor.ts     # Interceptor global de erros HTTP
│   │   │       │   └── 📄 loading.interceptor.ts   # Loading state global automático
│   │   │       ├── 📁 models/
│   │   │       │   └── 📄 api.models.ts            # 15+ interfaces TypeScript tipadas
│   │   │       └── 📁 services/
│   │   │           ├── 📄 api.service.ts           # 15 endpoints HTTP (Stock + Billing + Print)
│   │   │           ├── 📄 breadcrumb.service.ts    # Gerenciador de breadcrumb reativo
│   │   │           ├── 📄 dialog.service.ts        # Serviço de diálogo centralizado
│   │   │           ├── 📄 error.service.ts         # Serviço de notificação de erro
│   │   │           └── 📄 loading.service.ts       # BehaviorSubject para loading global
│   │   │
│   │   ├── 📁 styles/                              # Design System Global
│   │   │   ├── 📄 _variables.scss                  # 70+ design tokens (cores, espaçamento, tipografia)
│   │   │   ├── 📄 _mixins.scss                     # Mixins SCSS reutilizáveis
│   │   │   ├── 📄 _buttons.scss                    # Button variants padronizados
│   │   │   └── 📄 _material-overrides.scss         # Overrides do Angular Material
│   │   │
│   │   ├── 📄 styles.scss                          # Entry point global dos estilos
│   │   ├── 📄 main.ts                              # Bootstrap (standalone, interceptors)
│   │   └── 📄 index.html                           # Shell HTML com Google Fonts (Inter)
│   │
│   ├── 📄 angular.json                             # Config do Angular CLI
│   ├── 📄 tsconfig.json                            # TypeScript strict, paths aliases
│   ├── 📄 .eslintrc.json                           # ESLint + @angular-eslint + Prettier
│   ├── 📄 .prettierrc                              # Config do Prettier
│   └── 📄 package.json                             # Dependências (17 packages)
│
├── 📄 docker-compose.yml                            # 6 services + volumes + network
├── 📄 .env.example                                  # 30+ variáveis de configuração documentadas
├── 📄 .golangci.yml                                 # Linter Go (errcheck, govet, staticcheck)
├── 📄 .gitignore
└── 📄 .editorconfig
```

---

## 🗄️ Banco de Dados

### Schemas Segregados

O PostgreSQL é particionado em **4 schemas lógicos** que isolam os dados de cada microsserviço:

| Schema    | Tabelas                        | Proprietário    |
| --------- | ------------------------------ | --------------- |
| `stock`   | `products`                     | stock-service   |
| `billing` | `invoices`, `invoice_items`    | billing-service |
| `print`   | `print_jobs`                   | print-service   |
| `shared`  | `idempotency_log`, `audit_log` | Compartilhado   |

### Modelo Entidade-Relacionamento

```
stock.products                   billing.invoices                    billing.invoice_items
┌───────────────────┐            ┌────────────────────────┐          ┌──────────────────────┐
│ id          UUID  │◄───────────│ id             UUID    │◄─────── │ id           UUID    │
│ code     VARCHAR  │            │ number         BIGINT  │   1:N   │ invoice_id   UUID FK │
│ description TEXT  │            │ status        VARCHAR  │          │ product_id   UUID    │──► stock.products.id
│ balance      INT  │            │ idempotency_key UUID   │          │ quantity       INT   │
│ version      INT  │            │ created_by   VARCHAR   │          │ unit_price DECIMAL   │
│ created_at TIMESTAMPTZ │       │ created_at TIMESTAMPTZ │          │ created_at TIMESTAMPTZ │
│ updated_at TIMESTAMPTZ │       │ closed_at  TIMESTAMPTZ │          └──────────────────────┘
│ deleted_at TIMESTAMPTZ │       │ deleted_at TIMESTAMPTZ │
└───────────────────┘            └────────────────────────┘

print.print_jobs                 shared.idempotency_log              shared.audit_log
┌────────────────────────┐       ┌─────────────────────────┐         ┌─────────────────────┐
│ id             UUID    │       │ idempotency_key UUID PK │         │ id          UUID     │
│ invoice_id     UUID UK │       │ service       VARCHAR   │         │ service    VARCHAR   │
│ status        VARCHAR  │       │ operation     VARCHAR   │         │ entity_type VARCHAR  │
│ attempts         INT   │       │ request_hash  VARCHAR   │         │ entity_id    UUID    │
│ max_attempts     INT   │       │ response_code    INT    │         │ action     VARCHAR   │
│ last_error      TEXT   │       │ response       JSONB    │         │ old_values   JSONB   │
│ created_at TIMESTAMPTZ │       │ created_at TIMESTAMPTZ  │         │ new_values   JSONB   │
│ completed_at TIMESTAMPTZ│      │ expires_at TIMESTAMPTZ  │         │ user_id    VARCHAR   │
│ deleted_at TIMESTAMPTZ │       └─────────────────────────┘         │ created_at TIMESTAMPTZ│
└────────────────────────┘                                           └─────────────────────┘
```

### Indexes de Performance (Migration 002)

| Index                               | Tipo                                 | Finalidade                                 |
| ----------------------------------- | ------------------------------------ | ------------------------------------------ |
| `idx_products_code_active`          | Partial (`WHERE deleted_at IS NULL`) | Busca rápida de produtos ativos por código |
| `idx_products_balance_active`       | Partial                              | Filtro de estoque disponível               |
| `idx_invoices_status_created`       | Composite + Partial                  | Dashboard: filtros status + data           |
| `idx_invoice_items_product_invoice` | Composite                            | Join otimizado para `enrichInvoiceItems`   |
| `idx_print_jobs_status_active`      | Partial                              | Worker: busca jobs pendentes               |
| `idx_print_jobs_invoice_active`     | Partial                              | Query `GetPrintJobByInvoice`               |
| `idx_idempotency_log_expires`       | Partial                              | Limpeza de entradas expiradas              |

---

## 🌐 API — Rotas e Endpoints

Toda comunicação passa pelo **API Gateway** (`localhost:3000`) que roteia para os microsserviços internos.

### Stock Service (`/api/stock`)

| Método   | Rota                      | Handler          | Descrição                      |
| -------- | ------------------------- | ---------------- | ------------------------------ |
| `POST`   | `/products`               | `CreateProduct`  | Cadastrar novo produto         |
| `GET`    | `/products`               | `ListProducts`   | Listar produtos (paginado)     |
| `GET`    | `/products/:id`           | `GetProduct`     | Detalhe de produto             |
| `PUT`    | `/products/:id`           | `UpdateProduct`  | Atualizar produto              |
| `DELETE` | `/products/:id`           | `DeleteProduct`  | Soft delete                    |
| `POST`   | `/products/:id/reserve`   | `ReserveStock`   | Reservar estoque (lock)        |
| `POST`   | `/products/:id/decrement` | `DecrementStock` | Decrementar estoque definitivo |

### Billing Service (`/api/billing`)

| Método   | Rota                   | Handler         | Descrição                         |
| -------- | ---------------------- | --------------- | --------------------------------- |
| `POST`   | `/invoices`            | `CreateInvoice` | Emitir NF-e (com Idempotency-Key) |
| `GET`    | `/invoices`            | `ListInvoices`  | Listar NF-e (paginado)            |
| `GET`    | `/invoices/:id`        | `GetInvoice`    | Detalhe com itens                 |
| `POST`   | `/invoices/:id/close`  | `CloseInvoice`  | Fechar NF-e                       |
| `POST`   | `/invoices/:id/cancel` | `CancelInvoice` | Cancelar com rollback de estoque  |
| `PUT`    | `/invoices/:id`        | `UpdateInvoice` | Atualizar NF-e                    |
| `DELETE` | `/invoices/:id`        | `DeleteInvoice` | Remover NF-e                      |

### Print Service (`/api/print`)

| Método | Rota                         | Handler                 | Descrição                                            |
| ------ | ---------------------------- | ----------------------- | ---------------------------------------------------- |
| `POST` | `/invoices/:id/print`        | `CreatePrintJob`        | Enfileirar job de impressão (retorna `202 Accepted`) |
| `GET`  | `/invoices/:id/print-status` | `GetInvoicePrintStatus` | Status do print por invoice                          |
| `GET`  | `/print-jobs/:id`            | `GetPrintJobStatus`     | Polling do status do job                             |
| `GET`  | `/print-jobs`                | `ListPrintJobs`         | Listar todos os jobs                                 |
| `POST` | `/print-jobs/:id/retry`      | `RetryPrintJob`         | Forçar retentativa manual                            |

### Invoice Service (`/api/invoices`)

| Método | Rota       | Descrição                                               |
| ------ | ---------- | ------------------------------------------------------- |
| `GET`  | `/history` | Histórico consolidado                                   |
| `GET`  | `/stats`   | Estatísticas agregadas (total, open, closed, cancelled) |

---

## 🎨 Frontend — Angular 17

### Roteamento (Lazy Loading)

| Rota            | Componente               | Carregamento |
| --------------- | ------------------------ | ------------ |
| `/`             | → redirect `/dashboard`  | —            |
| `/dashboard`    | `DashboardComponent`     | Lazy         |
| `/products`     | `ProductsComponent`      | Lazy         |
| `/invoices`     | `InvoicesComponent`      | Lazy         |
| `/invoices/:id` | `InvoiceDetailComponent` | Lazy         |
| `**`            | → redirect `/dashboard`  | —            |

### Componentes Compartilhados (6)

| Componente               | Localização                         | Finalidade                                                                  |
| ------------------------ | ----------------------------------- | --------------------------------------------------------------------------- |
| `BaseComponent`          | `shared/components/`                | Classe abstrata com `Subject` para unsubscribe automático no `ngOnDestroy`  |
| `CardComponent`          | `shared/components/card/`           | Card wrapper reutilizável com `@Input()` para título e projeção de conteúdo |
| `ConfirmDialogComponent` | `shared/components/confirm-dialog/` | Modal nativo para confirmação de ações destrutivas (deleção)                |
| `DataTableComponent`     | `shared/components/data-table/`     | Tabela dinâmica genérica com colunas configuráveis e emissão de eventos     |
| `FormBuilderComponent`   | `shared/components/form-builder/`   | Formulário dinâmico com validação e campos configuráveis                    |
| `HeaderComponent`        | `shared/components/header/`         | Header com título de página e breadcrumb navegável                          |
| `PageContainerComponent` | `shared/components/page-container/` | Container padronizado para layout de páginas                                |

### Services (5)

| Service             | Responsabilidade                                              |
| ------------------- | ------------------------------------------------------------- |
| `ApiService`        | 15 métodos HTTP tipados cobrindo todos os microsserviços      |
| `BreadcrumbService` | Gerenciador reativo de breadcrumb (BehaviorSubject)           |
| `DialogService`     | Abstração centralizada para abertura de modais de confirmação |
| `ErrorService`      | Centraliza notificações de erro para o usuário                |
| `LoadingService`    | BehaviorSubject ↔ Loading indicator global                    |

### Interceptors (2)

| Interceptor          | Responsabilidade                                                                |
| -------------------- | ------------------------------------------------------------------------------- |
| `errorInterceptor`   | Captura erros HTTP (0, 400, 401, 404, 409, 500, 503), traduz mensagens em PT-BR |
| `loadingInterceptor` | Ativa/desativa loading global automaticamente em cada requisição                |

---

## 🎨 Design System

### Paleta de Cores Principal

| Token                   | Valor     | Uso                                   |
| ----------------------- | --------- | ------------------------------------- |
| `$color-primary`        | `#4F46E5` | Botões principais, links ativos, CTAs |
| `$color-primary-hover`  | `#4338CA` | Hover states                          |
| `$color-success`        | `#00BC7D` | Confirmações, badges de sucesso       |
| `$color-warning`        | `#FE9A00` | Alertas                               |
| `$color-danger`         | `#FF2056` | Erros, ações destrutivas              |
| `$color-status-fechada` | `#009966` | Selo de NF Fechada                    |
| `$color-status-aberta`  | `#E17100` | Selo de NF Aberta                     |

### Tipografia

| Propriedade | Valor                                                                        |
| ----------- | ---------------------------------------------------------------------------- |
| Font Family | `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif` |
| Weights     | Regular (400), Medium (500), Semibold (600), Bold (700)                      |
| Scale       | 12px → 13px → 14px → 16px → 18px → 20px → 24px → 28px                        |

### Espaçamento e Layout

| Token          | Valor  | Token            | Valor   |
| -------------- | ------ | ---------------- | ------- |
| `$spacing-xs`  | `4px`  | `$radius-sm`     | `10px`  |
| `$spacing-sm`  | `8px`  | `$radius-md`     | `14px`  |
| `$spacing-md`  | `12px` | `$radius-lg`     | `16px`  |
| `$spacing-lg`  | `16px` | `$radius-xl`     | `20px`  |
| `$spacing-xl`  | `20px` | `$sidebar-width` | `256px` |
| `$spacing-xxl` | `24px` | `$header-height` | `46px`  |

### Gradient e Sombras

```scss
$gradient-primary: linear-gradient(135deg, #4f46e5 0%, ... #7c3aed 100%);
$shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
$shadow-md: 0 6.555px 9.833px -1.967px rgba(0, 0, 0, 0.07);
$shadow-lg: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
```

---

## 🛡️ Padrões de Resiliência

### 1. Circuit Breaker (API Gateway)

```
     CLOSED ────────[falha >= 5]────────► OPEN
       ▲                                    │
       │                              [aguarda 30s]
       │                                    │
       └────[sucesso >= 2]──── HALF_OPEN ◄──┘
```

- **Fail Threshold:** 5 falhas consecutivas abrem o circuito
- **Open Duration:** 30 segundos de quarentena
- **Success Needed:** 2 sucessos no `HALF_OPEN` para fechar
- **Proteção:** Mutex (`sync.RWMutex`) para thread-safety com goroutines do Fiber

### 2. Retry com Exponential Backoff

```go
maxRetries := 3
backoff := 100ms → 200ms → 400ms  // multiplicador 2x
```

### 3. Idempotência (Billing Service)

```
Frontend gera UUID v4 → Header "Idempotency-Key" → Gateway propaga →
Billing consulta shared.idempotency_log → Se existe, retorna resposta cacheada
```

### 4. Pessimistic Locking (Stock Service)

```go
// Nível de isolamento Serializable + SELECT ... FOR UPDATE
tx.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelSerializable})
repo.GetByIDForUpdate(ctx, productID)  // Bloqueio exclusivo na row
product.Balance -= qty
repo.Update(ctx, product)
tx.Commit()
```

### 5. Print Workflow Assíncrono

```
[Frontend]  →  CreatePrintJob (HTTP 202)
                    │
              [print.print_jobs]  status = PENDING
                    │
              [Worker goroutine]  polling de jobs pendentes
                    │
           ┌────────┴────────────┐
           ▼                     ▼
    CloseInvoice()       DecrementStock()
    (billing-service)    (stock-service)
           │                     │
           └─────────┬──────────┘
                     ▼
              status = COMPLETED
                     │
              [Frontend polling]
                     ▼
              window.print()  (CSS @media print)
```

---

## ✅ CI/CD e Qualidade de Código

### GitHub Actions Pipeline (`.github/workflows/ci.yml`)

Executa em todo **push** e **pull request**:

```yaml
Steps:
  1. checkout
  2. setup-node (v22, npm cache)
  3. npm ci
  4. npm run lint          # ESLint + @angular-eslint + Prettier
  5. npx prettier --check  # Verificação de formatação
  6. npm run build         # Build de produção
```

### Go Quality Script (`backend/scripts/go-quality.sh`)

Varre **todos** os Go modules automaticamente:

| Etapa | Ferramenta                          |
| ----- | ----------------------------------- |
| 1     | `go mod download`                   |
| 2     | `gofmt -w` (auto-format)            |
| 3     | `go vet ./...` (análise estática)   |
| 4     | `go test ./...` (testes)            |
| 5     | `golangci-lint run` (se disponível) |

### golangci-lint (`.golangci.yml`)

Linters ativos: `errcheck`, `govet`, `ineffassign`, `staticcheck`, `unused`

### Frontend Quality Stack

| Ferramenta   | Config                                                 |
| ------------ | ------------------------------------------------------ |
| ESLint 8.x   | `@angular-eslint/eslint-plugin` + `@typescript-eslint` |
| Prettier 3.x | `eslint-plugin-prettier` + `eslint-config-prettier`    |
| TypeScript   | `strict: true`                                         |

---

## 🚀 Instalação e Execução

### Pré-requisitos

| Requisito                       | Versão Mínima |
| ------------------------------- | ------------- |
| Node.js                         | v20+          |
| npm                             | v9+           |
| Docker + Docker Compose         | Latest        |
| Go _(opcional, para dev local)_ | 1.21+         |

### Opção 1: Docker Compose (Completo)

Levanta **todos** os serviços (PostgreSQL + 4 microsserviços + API Gateway):

```bash
# Na raiz do projeto
docker-compose up -d --build
```

| Serviço         | Container             | Porta |
| --------------- | --------------------- | ----- |
| PostgreSQL      | `nfe_postgres`        | 5432  |
| API Gateway     | `nfe_api_gateway`     | 3000  |
| Stock Service   | `nfe_stock_service`   | 5001  |
| Billing Service | `nfe_billing_service` | 5002  |
| Print Service   | `nfe_print_service`   | 5003  |
| Invoice Service | `nfe_invoice_service` | 5004  |

### Opção 2: Execução Local (Desenvolvimento)

```bash
# 1. Banco de dados
docker-compose up -d postgres

# 2. Backend (em terminais separados)
cd backend/api-gateway    && go run main.go
cd backend/stock-service  && go run main.go
cd backend/billing-service && go run main.go
cd backend/print-service  && go run main.go
cd backend/invoice-service && go run main.go

# 3. Frontend
cd frontend
npm install
npm start
```

Acesse: **http://localhost:4200/**

### Health Check

```bash
curl http://localhost:3000/health
# {"status":"healthy"}
```

---

## ⚙️ Variáveis de Ambiente

> **Migração 2026-05-07 — `POSTGRES_DB` renomeado.** O nome do banco saiu de `nfe_system` (`_dev` para o ambiente de desenvolvimento) para `sefarius` / `sefarius_dev`, alinhando com a identidade do projeto. Se você já tinha um stack rodando localmente com o nome anterior, derrube o volume antes de subir novamente:
>
> ```bash
> docker compose down -v   # remove containers + o volume sefarius_postgres_data
> make dev                 # sobe stack do zero contra o nome novo
> ```
>
> Sem essa limpeza, o Postgres anuncia o database antigo (`nfe_system_dev`) enquanto os serviços tentam conectar em `sefarius_dev` e crasham na boot. As migrations em `database/migrations/*.sql` são idempotentes e re-executam sem dados de usuário (que ainda eram zero no smoke test de hoje).

As variáveis de ambiente estão documentadas em `.env.example`. Principais:

| Variável                         | Default                                                                  | Descrição                       |
| -------------------------------- | ------------------------------------------------------------------------ | ------------------------------- |
| `DATABASE_URL`                   | `postgres://<POSTGRES_USER>:<POSTGRES_PASSWORD>@localhost:5432/sefarius?sslmode=disable` | Connection string PostgreSQL — gere as credenciais conforme `.env.example` |
| `API_GATEWAY_PORT`               | `3000`                                                                   | Porta do gateway                |
| `STOCK_SERVICE_URL`              | `http://localhost:5001`                                                  | URL interna do stock-service    |
| `BILLING_SERVICE_URL`            | `http://localhost:5002`                                                  | URL interna do billing-service  |
| `PRINT_SERVICE_URL`              | `http://localhost:5003`                                                  | URL interna do print-service    |
| `INVOICE_SERVICE_URL`            | `http://localhost:5004`                                                  | URL interna do invoice-service  |
| `CIRCUIT_BREAKER_FAIL_THRESHOLD` | `5`                                                                      | Falhas para abrir circuito      |
| `CIRCUIT_BREAKER_OPEN_DURATION`  | `30s`                                                                    | Tempo de quarentena             |
| `IDEMPOTENCY_TTL`                | `24h`                                                                    | Tempo de vida das chaves        |
| `CORS_ALLOW_ORIGINS`             | `*`                                                                      | Origens permitidas              |
| `LOG_LEVEL`                      | `info`                                                                   | Nível de log                    |

---

## 📜 Scripts Disponíveis

### Frontend (`cd frontend/`)

| Comando         | Descrição                                     |
| --------------- | --------------------------------------------- |
| `npm start`     | Dev server com hot reload (`ng serve --open`) |
| `npm run build` | Build de produção otimizado                   |
| `npm run lint`  | ESLint + Angular rules                        |
| `npm run watch` | Build watch mode                              |

### Backend

| Comando                              | Descrição                                             |
| ------------------------------------ | ----------------------------------------------------- |
| `bash backend/scripts/go-quality.sh` | Executa gofmt + vet + test + lint em todos os módulos |
| `docker-compose up -d --build`       | Build e start de todos os containers                  |
| `docker-compose logs -f [service]`   | Acompanhar logs de um serviço específico              |
| `docker-compose down -v`             | Parar e limpar tudo (incluindo volumes)               |

---

## 👤 Autor

**Glaucco Siqueira**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/glaucco-siqueira/)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/glauccoeng-prog)

---

<div align="center">
  <sub>Arquitetura de microsserviços com Go + Angular 17 · Clean Architecture · Design System proprietário</sub>
</div>

// Automated improvement step 2 - code quality audit

// Automated improvement step 20 - code quality audit

// Automated improvement step 24 - code quality audit

// Automated improvement step 30 - code quality audit

// Automated improvement step 31 - code quality audit

// Automated improvement step 35 - code quality audit

// Automated improvement step 47 - code quality audit

// Automated improvement step 49 - code quality audit

// Automated improvement step 50 - code quality audit

// Automated improvement step 70 - code quality audit

// Automated improvement step 71 - code quality audit

// Automated improvement step 73 - code quality audit

// Automated improvement step 75 - code quality audit

// Automated improvement step 89 - code quality audit

// Automated improvement step 92 - code quality audit

// Automated improvement step 98 - code quality audit

// Automated improvement step 99 - code quality audit

// Automated improvement step 103 - code quality audit

// Automated improvement step 108 - code quality audit

// Automated improvement step 109 - code quality audit

// Automated improvement step 115 - code quality audit

// Automated improvement step 134 - code quality audit

// Automated improvement step 145 - code quality audit

// Automated improvement step 150 - code quality audit

// Automated improvement step 159 - code quality audit

// Automated improvement step 168 - code quality audit

// Automated improvement step 174 - code quality audit

// Automated improvement step 179 - code quality audit

// Automated improvement step 189 - code quality audit

// Automated improvement step 191 - code quality audit

// Automated improvement step 219 - code quality audit

// Automated improvement step 223 - code quality audit

// Automated improvement step 228 - code quality audit

// Automated improvement step 231 - code quality audit

// Automated improvement step 240 - code quality audit

// Automated improvement step 259 - code quality audit

// Automated improvement step 290 - code quality audit

// Automated improvement step 301 - code quality audit

// Automated improvement step 303 - code quality audit

// Automated improvement step 314 - code quality audit

// Automated improvement step 316 - code quality audit

// Automated improvement step 318 - code quality audit

// Automated improvement step 333 - code quality audit

// Automated improvement step 336 - code quality audit

// Automated improvement step 343 - code quality audit

// Automated improvement step 356 - code quality audit

// Automated improvement step 357 - code quality audit

// Automated improvement step 359 - code quality audit

// Automated improvement step 364 - code quality audit

// Automated improvement step 373 - code quality audit

// Automated improvement step 381 - code quality audit

// Automated improvement step 389 - code quality audit

// Automated improvement step 414 - code quality audit

// Automated improvement step 417 - code quality audit

// Automated improvement step 423 - code quality audit

// Automated improvement step 424 - code quality audit

// Automated improvement step 431 - code quality audit

// Automated improvement step 437 - code quality audit

// Automated improvement step 438 - code quality audit

// Automated improvement step 439 - code quality audit

// Automated improvement step 444 - code quality audit

// Automated improvement step 452 - code quality audit

// Automated improvement step 454 - code quality audit

// Automated improvement step 458 - code quality audit

// Automated improvement step 484 - code quality audit

// Automated improvement step 491 - code quality audit

// Automated improvement step 497 - code quality audit
