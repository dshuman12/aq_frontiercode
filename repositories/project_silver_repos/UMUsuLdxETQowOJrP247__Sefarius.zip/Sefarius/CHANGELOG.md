# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Comprehensive unit test suites for all backend microservices (Go).
- Angular unit tests (`.spec.ts`) for all frontend features.
- System-wide seed data migration for PostgreSQL.
- Standard project documentation (`CONTRIBUTING.md`, `LICENSE`, `SECURITY.md`, `HEALTH.md`).
- Shared logging utility in `backend/shared/logger`.
- Unit tests for `stock-service` and `invoice-service` utilities.
- Unit tests for `Invoice` entity domain logic.
- Tax calculation logic to the `Invoice` entity.
- Makefile for project automation.
- GitHub Actions CI workflow for backend and frontend.
- Docker configuration improvements (`.dockerignore`, `docker-compose.override.yml`).
- Service-specific READMEs for all microservices.

### Fixed
- Consistent indentation settings in `.editorconfig`.

## [0.1.0] - 2026-05-04

### Added
- Initial project scaffold with microservices architecture.
- Angular frontend initial structure.
- Docker Compose configuration for system orchestration.
