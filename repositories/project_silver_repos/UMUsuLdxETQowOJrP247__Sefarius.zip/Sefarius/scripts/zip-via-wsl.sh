#!/usr/bin/env bash
# Build platform-upload zip from inside WSL Linux for guaranteed
# Unix file permissions and clean .git history.
#
# Strategy:
#   1. git clone --no-local — produces a fresh .git via transport
#      protocol, eliminating dangling refs/local artifacts that
#      sometimes confuse strict validators.
#   2. Copy uncommitted files (untracked, like database/seed-data.sql).
#   3. Rename clone dir to NF-System (top folder for the zip).
#   4. chmod tree: 0644 files, 0755 dirs/executables.
#   5. Zip with python3 zipfile, explicit create_system=3 + Unix mode
#      external_attr per entry.
#
# Output: /mnt/c/Users/Glaucco/Documents/Project_Glaucco/Sefarius-wsl-<ts>.zip
set -euo pipefail

SRC="/mnt/c/Users/Glaucco/Documents/Project_Glaucco/Sefarius"
STAGE="/tmp/Sefarius"
OUT="/mnt/c/Users/Glaucco/Documents/Project_Glaucco/Sefarius.zip"

echo "Source:  $SRC"
echo "Stage:   $STAGE"
echo "Output:  $OUT"
echo

# 1. Clean stage and clone fresh
rm -rf "$STAGE"
echo ">> git clone --no-local (gera .git limpo via protocol)..."
git clone --no-local "$SRC" "$STAGE" 2>&1 | tail -5
echo

# 2. Copy untracked + gitignored files that should ship.
#
# .env é gitignored por questão de segurança no repo, mas a plataforma
# exige no upload. Usuário deve rotacionar Resend/JWT/Postgres APÓS.
#
# Outros gitignored (node_modules, .angular, tmp, dist, *.exe, etc.)
# NÃO são copiados — são build artifacts.
echo ">> copiando untracked + .env relevantes..."
EXTRA_FILES=(
    "database/seed-data.sql"
    "scripts/zip-project.py"
    "scripts/zip-via-wsl.sh"
    ".env"
)
for f in "${EXTRA_FILES[@]}"; do
    if [ -f "$SRC/$f" ]; then
        mkdir -p "$STAGE/$(dirname "$f")"
        cp "$SRC/$f" "$STAGE/$f"
        echo "   + $f"
    else
        echo "   - $f (não existe, pulando)"
    fi
done
echo

# 3. chmod normalize
echo ">> chmod (0644 files, 0755 dirs)..."
find "$STAGE" -type d -exec chmod 0755 {} +
find "$STAGE" -type f -exec chmod 0644 {} +
# Restore +x for executables
find "$STAGE" -type f -name "*.sh" -exec chmod 0755 {} +
find "$STAGE/.git/hooks" -type f ! -name "*.sample" -exec chmod 0755 {} + 2>/dev/null || true
echo

# 4. Zip with Python3 zipfile, explicit Unix modes
echo ">> zipping com python3 zipfile (Unix mode preservado)..."
python3 - <<PYEOF
import os, sys, shutil, zipfile

stage = "$STAGE"
out = "$OUT"
top_parent = os.path.dirname(stage)
top_name = os.path.basename(stage)

count = 0
size = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for root, dirs, files in os.walk(stage):
        # dir entry explícito
        rel_root = os.path.relpath(root, top_parent)
        rel_arc = rel_root.replace(os.sep, "/").rstrip("/") + "/"
        zi = zipfile.ZipInfo(rel_arc)
        zi.create_system = 3
        zi.external_attr = (0o755 << 16) | 0x10
        zi.compress_type = zipfile.ZIP_STORED
        zf.writestr(zi, b"")

        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, top_parent).replace(os.sep, "/")
            mode = os.stat(full).st_mode & 0o777
            zi = zipfile.ZipInfo.from_file(full, rel)
            zi.create_system = 3
            zi.external_attr = mode << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            with open(full, "rb") as src, zf.open(zi, "w", force_zip64=True) as dst:
                shutil.copyfileobj(src, dst, length=64 * 1024)
            count += 1
            size += os.path.getsize(full)
            if count % 500 == 0:
                print(f"   ... {count} arquivos")

print()
print(f"OK {count} arquivos, {size/(1024*1024):.1f} MB raw")
print(f"OK Zip final: {os.path.getsize(out)/(1024*1024):.1f} MB")
PYEOF

echo
echo ">> Validação:"
python3 -c "
import zipfile
z = zipfile.ZipFile('$OUT')
samples = [
    'NF-System/.git/HEAD',
    'NF-System/.git/config',
    'NF-System/.git/objects/pack',
    'NF-System/',
]
names = set(z.namelist())
for s in samples:
    found = s in names or any(n.startswith(s) for n in names)
    print(f'   {s:50s} {\"OK\" if found else \"MISSING\"}')
# mode check
import struct
for entry_name in ['NF-System/.git/HEAD', 'NF-System/']:
    try:
        info = z.getinfo(entry_name)
        unix_mode = info.external_attr >> 16
        print(f'   mode {entry_name}: 0{unix_mode:o}')
    except KeyError:
        pass
z.close()
"
echo
echo "OK $OUT"
