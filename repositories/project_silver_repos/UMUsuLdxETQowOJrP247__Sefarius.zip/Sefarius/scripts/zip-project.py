"""
Zip the Sefarius project for upload to a review platform, excluding
install/build/cache directories and sensitive files.

Why Python (and not `zip` from shell): Git Bash on Windows ships with
zip but its CLI flag handling is fiddly with multiple --exclude
patterns. Python's stdlib zipfile is consistent across OSes.

CRITICAL — Unix permissions: the platform extracts on Linux. Default
zipfile.write() on Windows produces zip entries WITHOUT Unix mode
bits, which Linux unzip materializes with permissions that block
git from traversing .git/objects (dirs without +x). Sintoma: erro
"We couldn't read this repository's git history" mesmo com .git/
estruturalmente íntegro. Fix: setar create_system=3 (Unix) e
external_attr explicitamente (0755 dirs, 0644 files).

Usage (from project root):
    python scripts/zip-project.py

Output: ../Sefarius-<timestamp>.zip alongside the project root,
not inside (avoid the zip including itself if re-run).
"""
import os
import shutil
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Nome da pasta top-level dentro do zip. A plataforma de upload exige
# que todos os arquivos estejam aninhados sob um único diretório raiz
# (não na raiz do zip), senão o validador não acha o .git.
#
# "NF-System" (não "sefarius") porque as entradas existentes na
# plataforma estão sob esse nome — usar o mesmo nome permite Replace
# em vez de criar entrada nova (Sefarius é só rebrand interno).
TOP_FOLDER = "NF-System"

# Diretórios excluídos por nome em qualquer profundidade.
#
# Mantém SOMENTE: pastas que recriam-se via build/install:
#   - node_modules: npm install
#   - tmp / dist: build outputs
#   - .angular: cache do Angular CLI (3+ GB, regenerado por `ng serve`)
#   - __pycache__ / .pytest_cache: caches Python
#
# O CÓDIGO-FONTE Angular (frontend/src/) NÃO está aqui — está incluído.
#
# - .git: incluído (history)
# - vendor: incluído (Go vendored deps, se existir)
# - coverage / playwright-report / test-results: incluídos
# - postgres_data: NÃO existe como pasta no projeto (volume Docker
#   nomeado fora do diretório). Por isso não está aqui — não tem
#   como walking incluir.
EXCLUDE_DIRS = {
    "node_modules",
    "tmp",
    "dist",
    ".angular",
    "vendor",
    "bin",
    "__pycache__",
    ".pytest_cache",
    ".vscode",
    ".idea",
}

# Arquivos excluídos por nome ou suffix.
#
# .env INCLUÍDO INTENCIONALMENTE (plataforma exige) — usuário deve
# rotacionar Resend API key, JWT secrets e Postgres password APÓS o
# upload.
EXCLUDE_FILES = {
    ".DS_Store",
    "Thumbs.db",
}

EXCLUDE_SUFFIXES = (
    ".log",
    ".pyc",
    ".swp",
)


def should_skip_dir(path: Path) -> bool:
    return any(part in EXCLUDE_DIRS for part in path.parts)


def should_skip_file(path: Path) -> bool:
    if path.name in EXCLUDE_FILES:
        return True
    if path.name.endswith(EXCLUDE_SUFFIXES):
        return True
    if any(part in EXCLUDE_DIRS for part in path.parts):
        return True
    return False


def _is_executable(rel_posix: str, fname: str) -> bool:
    # Hooks do git são .sample (não exec por padrão), mas qualquer
    # script executável deve manter +x. Marca: .sh, .py em scripts/,
    # e arquivos sob .git/hooks/ sem extensão (post-commit, pre-push).
    if fname.endswith(".sh"):
        return True
    if "/.git/hooks/" in rel_posix and "." not in fname:
        return True
    return False


def _add_file(zf: zipfile.ZipFile, fpath: Path, arcname: str) -> None:
    """Add file to zip with explicit Unix permissions (Linux extractor friendly)."""
    zi = zipfile.ZipInfo.from_file(fpath, arcname)
    zi.create_system = 3  # 3 = Unix; força extractor Linux a honrar mode
    mode = 0o755 if _is_executable(arcname, fpath.name) else 0o644
    zi.external_attr = mode << 16
    zi.compress_type = zipfile.ZIP_DEFLATED

    with open(fpath, "rb") as src, zf.open(zi, "w", force_zip64=True) as dst:
        shutil.copyfileobj(src, dst, length=64 * 1024)


def _add_dir_entry(zf: zipfile.ZipFile, arcname: str, seen: set) -> None:
    """Add explicit directory entry with mode 0755 if not already added."""
    # Garante traversal no Linux mesmo se unzip não criar dirs implicitamente.
    arcname = arcname.rstrip("/") + "/"
    if arcname in seen:
        return
    seen.add(arcname)
    zi = zipfile.ZipInfo(arcname)
    zi.create_system = 3
    zi.external_attr = (0o755 << 16) | 0x10  # 0x10 = MS-DOS directory flag
    zi.compress_type = zipfile.ZIP_STORED
    zf.writestr(zi, b"")


def main() -> int:
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    output = ROOT.parent / f"Sefarius-{timestamp}.zip"

    print(f"Source:  {ROOT}")
    print(f"Output:  {output}")
    print(f"Top folder:  {TOP_FOLDER}/")
    print(f"Excluding dirs:  {sorted(EXCLUDE_DIRS)}")
    print()

    files_added = 0
    bytes_added = 0
    skipped_dirs = 0
    seen_dirs: set = set()

    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        # Top-level dir entry (e.g. NF-System/)
        _add_dir_entry(zf, TOP_FOLDER, seen_dirs)

        for dirpath, dirnames, filenames in os.walk(ROOT):
            current = Path(dirpath)

            # Filtra subdirs in-place pra os.walk não descer neles
            pruned = [d for d in dirnames if d in EXCLUDE_DIRS]
            for d in pruned:
                skipped_dirs += 1
                dirnames.remove(d)

            # Dir entry explícito para o diretório atual (exceto ROOT
            # que já é o TOP_FOLDER) — garante mode 0755 no Linux.
            if current != ROOT:
                rel_dir = current.relative_to(ROOT).as_posix()
                _add_dir_entry(zf, f"{TOP_FOLDER}/{rel_dir}", seen_dirs)

            for fname in filenames:
                fpath = current / fname
                if should_skip_file(fpath):
                    continue
                rel = fpath.relative_to(ROOT)
                arcname = f"{TOP_FOLDER}/{rel.as_posix()}"
                _add_file(zf, fpath, arcname)
                files_added += 1
                bytes_added += fpath.stat().st_size
                if files_added % 500 == 0:
                    print(f"  ... {files_added} arquivos")

    print()
    print(f"OK {files_added} arquivos, {bytes_added / (1024*1024):.1f} MB raw")
    print(f"OK {skipped_dirs} diretórios excluídos durante walk")
    print(f"OK Zip final: {output.stat().st_size / (1024*1024):.1f} MB")
    print(f"OK {output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
