#!/usr/bin/env bash
# Seed the dev environment with realistic data volumes for testing
# pagination and list-page UX. Targets:
#   100 products in stock-service (varied codes/descriptions/balances)
#    50 invoices in billing-service (each consuming 1-3 products)
#    50 NFes in billing-service (varied n_nf, all AUTHORIZED via mock)
#
# Pre-conditions: dev containers running (docker compose up). The DB
# is NOT wiped here — run the TRUNCATE block at the top of this file
# manually if you want a clean slate. We don't bake the truncate in
# because re-running this script accidentally on top of real data
# would silently delete it.
#
# Usage: bash scripts/seed-dev-data.sh
#
# Convention from [[16 - Bug Sweep 3]]: dev-only utilities live under
# scripts/ and never gate on env detection — operator is responsible
# for running them in the right environment.

set -euo pipefail

# Hits the services directly (port-forwarded by docker-compose) rather
# than going through api-gateway:3000. The gateway has a 100-req/min
# rate limiter intended for end users; seed bursts of 100+ requests
# trip it. Direct service URLs have no such limiter, so the seed
# completes in seconds.
STOCK="${STOCK:-http://localhost:5001}"
BILLING="${BILLING:-http://localhost:5002}"
N_PRODUCTS="${N_PRODUCTS:-100}"
N_INVOICES="${N_INVOICES:-50}"
N_NFES="${N_NFES:-50}"

# ASCII-only — bash + curl no Git Bash do Windows mangia bytes UTF-8
# multi-byte (â, ó, í, ã viram U+FFFD na renderização). O loop usa
# echo + heredoc que sofre conversão CP1252; o servidor decodifica
# como UTF-8 e cai no replacement char. Para preservar acentos
# precisaria gravar o body em arquivo (-d @body.json) — overhead que
# não compensa pra fixtures de dev. Mantenha ASCII aqui.
PRODUCT_CATEGORIES=(
  "Cabo HDMI"
  "Mouse Sem Fio"
  "Teclado Mecanico"
  "Monitor LED"
  "Headset Bluetooth"
  "Webcam Full HD"
  "SSD NVMe"
  "Memoria DDR4"
  "Placa de Video"
  "Fonte ATX"
)

NCM_CODES=("85444290" "84716053" "84716052" "85285200" "85183000" "85258910" "84717012" "84733042" "84733099" "85044090")

echo "→ Seeding $N_PRODUCTS products..."
PRODUCT_IDS=()
for i in $(seq 1 "$N_PRODUCTS"); do
  cat_idx=$(( (i - 1) % ${#PRODUCT_CATEGORIES[@]} ))
  category="${PRODUCT_CATEGORIES[$cat_idx]}"
  ncm="${NCM_CODES[$cat_idx]}"
  code=$(printf "PROD-%04d" "$i")
  desc="$category modelo $i"
  # Initial balance 100–500. Foi 10–210 antes mas com 50 invoices ×
  # avg 2 itens × avg 3 qty = 300 saídas, sorteios desbalanceados
  # exauriam produtos com base baixa (insufficient stock 500). Range
  # mais largo dá folga sem comprometer realismo.
  balance=$(( 100 + RANDOM % 400 ))
  price="$(( 50 + RANDOM % 950 )).$(( RANDOM % 100 ))"

  # Body uses default fiscal fields (CFOP 5102, u_com UN, origem 0,
  # CST ICMS 00, p_ICMS 18.00, CST PIS/COFINS 49) so we only have to
  # send code/description/balance/ncm/valor_unitario per product.
  resp=$(curl -sf -X POST "$STOCK/api/stock/products" \
    -H "Content-Type: application/json" \
    -d "{
      \"code\": \"$code\",
      \"description\": \"$desc\",
      \"balance\": $balance,
      \"ncm\": \"$ncm\",
      \"cfop_padrao_saida\": \"5102\",
      \"u_com\": \"UN\",
      \"valor_unitario\": $price,
      \"origem\": \"0\",
      \"cst_icms\": \"00\",
      \"p_icms\": 18.00,
      \"cst_pis\": \"49\",
      \"cst_cofins\": \"49\"
    }") || { echo "  ✗ failed at product $i"; exit 1; }

  # Extract product id from response (no jq — naive sed grep).
  pid=$(echo "$resp" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
  PRODUCT_IDS+=("$pid")
  if (( i % 25 == 0 )); then
    echo "  ✓ $i/$N_PRODUCTS"
  fi
done
echo "  ✓ $N_PRODUCTS products created"

echo "→ Seeding $N_INVOICES invoices..."
RESPONSIBLES=("Glaucco" "Maria Silva" "Joao Santos" "Ana Costa" "Pedro Lima")
for i in $(seq 1 "$N_INVOICES"); do
  resp_idx=$(( (i - 1) % ${#RESPONSIBLES[@]} ))
  responsible="${RESPONSIBLES[$resp_idx]}"

  # Pick 1-3 random products. Each gets quantity 1-5, price from a
  # plausible range. Multi-item invoices exercise the items[] join
  # in the UI list view.
  n_items=$(( 1 + RANDOM % 3 ))
  items_json=""
  for j in $(seq 1 "$n_items"); do
    pidx=$(( RANDOM % ${#PRODUCT_IDS[@]} ))
    pid="${PRODUCT_IDS[$pidx]}"
    qty=$(( 1 + RANDOM % 5 ))
    price="$(( 50 + RANDOM % 500 )).$(printf '%02d' $(( RANDOM % 100 )))"
    if [ -n "$items_json" ]; then items_json+=","; fi
    items_json+="{\"product_id\":\"$pid\",\"quantity\":$qty,\"unit_price\":$price}"
  done

  # Idempotency-Key column is UUID-typed in Postgres, so any free-form
  # string ("seed-1234-1") gets rejected with a syntax error. Use
  # python3 to generate a real v4 UUID per request.
  idem_key=$(python3 -c "import uuid; print(uuid.uuid4())")
  # || true em vez de exit 1: sorteios desbalanceados ocasionalmente
  # picam um produto já exaurido (insufficient stock) ou qty > saldo.
  # Numa seed de dev é aceitável perder 1–2 invoices em 50 — a UI da
  # página /invoices exibe ~50 "notas fiscais" pra exercer paginação.
  curl -sf -X POST "$BILLING/api/billing/invoices" \
    -H "Content-Type: application/json" \
    -H "Idempotency-Key: $idem_key" \
    -d "{\"created_by\":\"$responsible\",\"items\":[$items_json]}" \
    > /dev/null || true

  if (( i % 10 == 0 )); then
    echo "  ✓ $i/$N_INVOICES"
  fi
done
echo "  ✓ $N_INVOICES invoices created"

echo "→ Seeding $N_NFES NFes (via emission pipeline)..."
# NFe emission template — venda interna RS→RS, regime normal.
#
# c_nf inclui um offset baseado no timestamp do seed pra evitar que
# re-runs colidam com chaves que ficaram no MockClient.authorized
# (sync.Map in-memory do processo billing-service): chave igual →
# mock retorna cStat 539 Duplicate em vez de 100 Authorized, e a UI
# fica mostrando "Rejeicao: Duplicidade de NF-e" em todas as 50.
# Restartar o container também resolveria mas é manual; injetar o
# timestamp deixa o seed idempotente entre runs sem ação extra.
SEED_OFFSET=$(date +%s)
for i in $(seq 1 "$N_NFES"); do
  n_nf=$(( 1000 + i ))
  c_nf=$(printf "%08d" $(( (SEED_OFFSET + i * 7) % 100000000 )))

  curl -sf -X POST "$BILLING/api/nfe/" \
    -H "Content-Type: application/json" \
    -d "{
      \"emit\": {
        \"cnpj\": \"05730928000145\",
        \"x_nome\": \"SEFARIUS COMERCIO LTDA\",
        \"ie\": \"1234567890\",
        \"crt\": \"3\",
        \"x_lgr\": \"AV PRINCIPAL\",
        \"nro\": \"100\",
        \"x_bairro\": \"CENTRO\",
        \"c_mun\": \"4314902\",
        \"x_mun\": \"PORTO ALEGRE\",
        \"uf\": \"RS\",
        \"cep\": \"90000000\"
      },
      \"dest\": {
        \"cnpj\": \"11444777000161\",
        \"x_nome\": \"CLIENTE TESTE $i LTDA\",
        \"ind_ie_dest\": \"1\",
        \"ie\": \"9876543210\",
        \"x_lgr\": \"RUA CLIENTE\",
        \"nro\": \"$i\",
        \"x_bairro\": \"BAIRRO\",
        \"c_mun\": \"4314902\",
        \"x_mun\": \"PORTO ALEGRE\",
        \"uf\": \"RS\",
        \"cep\": \"90000001\"
      },
      \"ide\": {
        \"c_uf\": \"43\",
        \"c_nf\": \"$c_nf\",
        \"nat_op\": \"VENDA DE MERCADORIA\",
        \"serie\": \"1\",
        \"n_nf\": \"$n_nf\",
        \"dh_emi\": \"$(date -u +%Y-%m-%dT%H:%M:%S-03:00)\",
        \"tp_nf\": \"1\",
        \"id_dest\": \"1\",
        \"c_mun_fg\": \"4314902\",
        \"tp_amb\": \"2\",
        \"fin_nfe\": \"1\",
        \"ind_pres\": \"1\"
      },
      \"items\": [{
        \"c_prod\": \"PROD-$(printf %04d $(( i % N_PRODUCTS + 1 )))\",
        \"x_prod\": \"Item NFe $i\",
        \"ncm\": \"22021000\",
        \"cfop\": \"5102\",
        \"u_com\": \"UN\",
        \"q_com\": \"1.0000\",
        \"v_un_com\": \"100.0000000000\",
        \"v_prod\": \"100.00\",
        \"v_bc\": \"100.00\",
        \"p_icms\": \"18.00\",
        \"v_pis\": \"1.65\",
        \"v_cofins\": \"7.60\"
      }]
    }" > /dev/null || { echo "  ✗ failed at NFe $i (n_nf=$n_nf)"; exit 1; }

  if (( i % 10 == 0 )); then
    echo "  ✓ $i/$N_NFES"
  fi
done
echo "  ✓ $N_NFES NFes emitted"

echo
echo "✓ Seed complete."
echo "  http://localhost:4200/products  — $N_PRODUCTS produtos"
echo "  http://localhost:4200/invoices  — $N_INVOICES notas fiscais"
echo "  http://localhost:4200/nfe       — $N_NFES NF-es"
