import { setupZoneTestEnv } from 'jest-preset-angular/setup-env/zone';
import { registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';

setupZoneTestEnv();

// Mirror the locale registration done in main.ts so tests that exercise
// pt-BR-aware pipes (currency, date, decimal) don't throw NG0701.
registerLocaleData(localePt, 'pt-BR');
