# Sefarius Frontend

Angular 17 SPA that consumes the Sefarius NF-e API. Standalone components,
Material 17, environment-driven base URL, lazy-loaded feature routes.

## Tech stack

- **Framework:** Angular 17 (standalone, signals, OnPush)
- **UI:** Angular Material 17 (tabs, dialog, toolbar)
- **HTTP:** HttpClient with environment-driven `apiBaseUrl` and global
  loading/error interceptors
- **Tests:** Jest 29 + jest-preset-angular for units, Playwright 1.x for E2E
- **Lint/format:** ESLint + Prettier (run together via `ng lint`)

## Development

```bash
npm install      # at the repo root (npm workspace)
npm start        # dev server at http://localhost:4200
npm run build    # production bundle
npm run lint     # ESLint + Prettier
```

## Tests

### Unit (Jest)

121 specs across 13 suites covering services, interceptors, NFe components,
dialogs, and the BaseComponent infrastructure.

```bash
npm test                # single run
npm run test:watch      # watch mode
npm run test:coverage   # with HTML + lcov report under coverage/
```

Coverage thresholds are scoped per path (see `jest.config.ts`):

| Path | Lines |
|---|---|
| `shared/services/` | 90% |
| `shared/components/base.component.ts` | 100% |
| `shared/components/confirm-dialog/` | 100% |
| `shared/interceptors/` | 95% |
| `features/nfe/` | 85% |

The legacy dashboard, invoices and products components are intentionally
excluded — their fate is being decided in the upcoming F5 sprint.

### E2E (Playwright)

14 tests in 4 spec files, running against a Playwright-managed
`ng serve` with `page.route` interception so a live backend is not
required.

```bash
npm run e2e          # headless run, all specs
npm run e2e:ui       # interactive UI mode
npm run e2e:headed   # watch the browser
npm run e2e:report   # open the latest HTML report
```

Browsers are installed on demand:

```bash
npx playwright install chromium
```

CI installs `--with-deps` so the runner has the system libraries.

## Project structure

```
frontend/
├── src/app/
│   ├── features/
│   │   ├── dashboard/          (legacy)
│   │   ├── invoices/           (legacy)
│   │   ├── products/           (legacy)
│   │   └── nfe/                NF-e list, detail, dialogs
│   ├── shared/
│   │   ├── components/         BaseComponent, ConfirmDialog
│   │   ├── services/           ApiService, dialogs, breadcrumbs, loading, error
│   │   ├── interceptors/       loading, error
│   │   ├── models/             api.models.ts, nfe.models.ts
│   │   └── constants/
│   ├── app.component.*
│   └── app.routes.ts
├── e2e/                        Playwright specs + fixtures
├── src/environments/           dev + prod environment.ts
├── jest.config.ts
├── playwright.config.ts
└── tsconfig.{app,spec,json}.json
```
