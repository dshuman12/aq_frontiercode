import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { BaseComponent } from './base.component';

@Component({
  selector: 'app-test-host',
  standalone: true,
  template: ''
})
class TestHostComponent extends BaseComponent {}

// U+00A0 (NBSP) — Intl emits it between R$ and the digits in pt-BR BRL.
// Kept as an escape so the source stays ASCII (no-irregular-whitespace).
const NBSP = String.fromCharCode(0x00a0);

describe('BaseComponent', () => {
  it('formatCurrency renders BRL with non-breaking space and pt-BR separators', () => {
    const fixture = TestBed.createComponent(TestHostComponent);
    const result = fixture.componentInstance.formatCurrency(1234.5);
    expect(result.replace(new RegExp(NBSP, 'g'), ' ')).toBe('R$ 1.234,50');
  });

  it('formatCurrency handles zero', () => {
    const fixture = TestBed.createComponent(TestHostComponent);
    const out = fixture.componentInstance.formatCurrency(0);
    expect(out.replace(new RegExp(NBSP, 'g'), ' ')).toBe('R$ 0,00');
  });

  it('ngOnDestroy completes the destroy$ subject so takeUntil unsubscribes downstream', () => {
    const fixture = TestBed.createComponent(TestHostComponent);
    const cmp = fixture.componentInstance as unknown as { destroy$: { complete: jest.Mock } };
    const completeSpy = jest.fn();
    (cmp as unknown as { destroy$: { next: jest.Mock; complete: jest.Mock } }).destroy$ = {
      next: jest.fn(),
      complete: completeSpy
    };
    fixture.destroy();
    expect(completeSpy).toHaveBeenCalled();
  });
});
