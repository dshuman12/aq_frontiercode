import { TestBed } from '@angular/core/testing';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { firstValueFrom } from 'rxjs';
import { take } from 'rxjs/operators';

import { AuthService, AuthUser } from './auth.service';
import { environment } from '@env/environment';

const baseUrl = environment.apiBaseUrl;

const mockUser: AuthUser = {
  id: 'u-1',
  name: 'Glaucco',
  email: 'g@example.com',
  activated: true
};

function ok<T>(data: T) {
  return { success: true, data, code: 200 };
}

function flushBootstrap(http: HttpTestingController, user: AuthUser | null = null): void {
  // Toda construção do AuthService dispara um GET /profile pra
  // popular o estado inicial. Em testes flushamos esse request.
  const req = http.expectOne(`${baseUrl}/profile`);
  if (user) {
    req.flush(ok(user));
  } else {
    req.flush(
      { success: false, error: 'not authenticated', code: 401 },
      {
        status: 401,
        statusText: 'Unauthorized'
      }
    );
  }
}

describe('AuthService (HTTP)', () => {
  let service: AuthService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthService,
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
      ]
    });
    service = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  describe('bootstrapSession', () => {
    it('GETs /profile on construction and resolves ready$ when 401 (no session)', async () => {
      flushBootstrap(http, null);
      const ready = await firstValueFrom(service.ready$.pipe(take(1)));
      expect(ready).toBe(true);
      expect(service.isAuthenticated()).toBe(false);
    });

    it('populates currentUser when /profile returns user (sessão válida)', async () => {
      flushBootstrap(http, mockUser);
      expect(service.isAuthenticated()).toBe(true);
      expect(service.currentUser?.email).toBe('g@example.com');
    });
  });

  describe('login', () => {
    beforeEach(() => flushBootstrap(http, null));

    it('POSTs to /auth/login com withCredentials e atualiza currentUser', async () => {
      const promise = firstValueFrom(service.login('g@example.com', 'StrongPass1'));
      const req = http.expectOne(`${baseUrl}/auth/login`);
      expect(req.request.method).toBe('POST');
      expect(req.request.withCredentials).toBe(true);
      expect(req.request.body).toEqual({ email: 'g@example.com', password: 'StrongPass1' });
      req.flush(ok(mockUser));

      const user = await promise;
      expect(user.email).toBe('g@example.com');
      expect(service.isAuthenticated()).toBe(true);
    });

    it('mapeia erro 401 do backend pra Error com mensagem do servidor', async () => {
      const promise = firstValueFrom(service.login('g@example.com', 'wrong'));
      const req = http.expectOne(`${baseUrl}/auth/login`);
      req.flush(
        { success: false, error: 'email ou senha incorretos', code: 401 },
        { status: 401, statusText: 'Unauthorized' }
      );

      await expect(promise).rejects.toThrow(/incorretos/i);
      expect(service.isAuthenticated()).toBe(false);
    });
  });

  describe('logout', () => {
    beforeEach(() => flushBootstrap(http, mockUser));

    it('POSTs /auth/logout e limpa currentUser', async () => {
      expect(service.isAuthenticated()).toBe(true);
      const promise = firstValueFrom(service.logout());
      const req = http.expectOne(`${baseUrl}/auth/logout`);
      expect(req.request.method).toBe('POST');
      req.flush(ok({ ok: true }));

      await promise;
      expect(service.isAuthenticated()).toBe(false);
    });

    it('limpa currentUser mesmo se backend falhar (resiliente a network)', async () => {
      const promise = firstValueFrom(service.logout());
      const req = http.expectOne(`${baseUrl}/auth/logout`);
      req.error(new ProgressEvent('network error'));

      await promise;
      expect(service.isAuthenticated()).toBe(false);
    });
  });

  describe('register', () => {
    beforeEach(() => flushBootstrap(http, null));

    it('POSTs /auth/register e NÃO auto-loga (precisa ativar via email primeiro)', async () => {
      const promise = firstValueFrom(service.register('Novo', 'n@x.com', 'StrongPass1'));
      const req = http.expectOne(`${baseUrl}/auth/register`);
      expect(req.request.body).toEqual({
        name: 'Novo',
        email: 'n@x.com',
        password: 'StrongPass1'
      });
      req.flush(ok({ ...mockUser, activated: false }));

      const user = await promise;
      expect(user.activated).toBe(false);
      // register NÃO loga — usuário precisa abrir email e ativar
      expect(service.isAuthenticated()).toBe(false);
    });

    it('mapeia 409 (email já cadastrado) corretamente', async () => {
      const promise = firstValueFrom(service.register('A', 'dup@x.com', 'StrongPass1'));
      const req = http.expectOne(`${baseUrl}/auth/register`);
      req.flush(
        { success: false, error: 'email já cadastrado', code: 409 },
        { status: 409, statusText: 'Conflict' }
      );
      await expect(promise).rejects.toThrow(/cadastrado/i);
    });
  });

  describe('activate', () => {
    beforeEach(() => flushBootstrap(http, null));

    it('GETs /auth/activate/:token e auto-loga', async () => {
      const promise = firstValueFrom(service.activate('tok-123'));
      const req = http.expectOne(`${baseUrl}/auth/activate/tok-123`);
      expect(req.request.method).toBe('GET');
      req.flush(ok(mockUser));

      const user = await promise;
      expect(user.email).toBe('g@example.com');
      expect(service.isAuthenticated()).toBe(true);
    });
  });

  describe('reset flow', () => {
    beforeEach(() => flushBootstrap(http, null));

    it('requestReset sempre retorna sucesso (anti-enumeration)', async () => {
      const promise = firstValueFrom(service.requestReset('any@x.com'));
      const req = http.expectOne(`${baseUrl}/auth/reset-password`);
      req.flush(ok({ ok: true }));
      await expect(promise).resolves.toBeUndefined();
    });

    it('confirmReset auto-loga após substituir senha', async () => {
      const promise = firstValueFrom(service.confirmReset('rtok', 'NewPass1', 'NewPass1'));
      const req = http.expectOne(`${baseUrl}/auth/reset-password/rtok`);
      expect(req.request.body).toEqual({ password: 'NewPass1', confirmation: 'NewPass1' });
      req.flush(ok(mockUser));

      const user = await promise;
      expect(user.email).toBe('g@example.com');
      expect(service.isAuthenticated()).toBe(true);
    });
  });

  describe('profile', () => {
    beforeEach(() => flushBootstrap(http, mockUser));

    it('changeName PATCH /profile/name e atualiza session', async () => {
      const promise = firstValueFrom(service.changeName('Novo Nome'));
      const req = http.expectOne(`${baseUrl}/profile/name`);
      expect(req.request.method).toBe('PATCH');
      req.flush(ok({ ...mockUser, name: 'Novo Nome' }));

      const user = await promise;
      expect(user.name).toBe('Novo Nome');
      expect(service.currentUser?.name).toBe('Novo Nome');
    });

    it('changePassword PATCH /profile/password com 3 campos', async () => {
      const promise = firstValueFrom(service.changePassword('old', 'NewPass1', 'NewPass1'));
      const req = http.expectOne(`${baseUrl}/profile/password`);
      expect(req.request.body).toEqual({
        oldPassword: 'old',
        newPassword: 'NewPass1',
        confirmation: 'NewPass1'
      });
      req.flush(ok({ ok: true }));
      await expect(promise).resolves.toBeUndefined();
    });
  });
});
