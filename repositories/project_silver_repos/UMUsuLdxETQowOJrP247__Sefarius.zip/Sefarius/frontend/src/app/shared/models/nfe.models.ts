export type NFeLifecycle = 'AUTHORIZED' | 'REJECTED' | 'PENDING' | 'CANCELLED';

export type AuthorizationStatus = 'AUTHORIZED' | 'REJECTED' | 'DUPLICATE' | 'SERVICE_UNAVAILABLE';

export type EventStatus = 'ACCEPTED' | 'REJECTED' | 'SERVICE_UNAVAILABLE';

export type NFeEventType = 'CANCEL' | 'CCE';

export interface Protocol {
  n_prot: string;
  dh_recbto: string;
  ch_nfe: string;
  dig_val: string;
  c_stat: string;
  x_motivo: string;
  tp_amb: string;
}

export interface Rejection {
  CStat: string;
  XMotivo: string;
}

export interface EventProtocol {
  n_prot: string;
  dh_reg_evento: string;
  ch_nfe: string;
  tp_evento: string;
  n_seq_evento: number;
  c_stat: string;
  x_motivo: string;
  tp_amb: string;
}

export interface EventRejection {
  CStat: string;
  XMotivo: string;
}

export interface NFeListItem {
  chave: string;
  lifecycle: NFeLifecycle;
  c_stat: string;
  x_motivo: string;
  created_at: string;
  updated_at: string;
}

export interface NFeRecord {
  chave: string;
  status?: AuthorizationStatus;
  lifecycle: NFeLifecycle;
  c_stat: string;
  x_motivo: string;
  protocol?: Protocol;
  rejection?: Rejection;
}

export interface EventResponse {
  chave: string;
  event_type: NFeEventType;
  seq: number;
  status: EventStatus;
  n_prot?: string;
  c_stat: string;
  x_motivo: string;
  protocol?: EventProtocol;
  rejection?: EventRejection;
}

export interface CancelRequest {
  justification: string;
}

export interface CCeRequest {
  correction: string;
  seq?: number;
}

export interface EmitterDTO {
  cnpj: string;
  x_nome: string;
  ie: string;
  crt: string;
  x_lgr: string;
  nro: string;
  x_bairro: string;
  c_mun: string;
  x_mun: string;
  uf: string;
  cep: string;
}

export interface RecipientDTO {
  cnpj?: string;
  cpf?: string;
  x_nome: string;
  ind_ie_dest: string;
  ie?: string;
  x_lgr: string;
  nro: string;
  x_bairro: string;
  c_mun: string;
  x_mun: string;
  uf: string;
  cep?: string;
}

export interface IdentificationDTO {
  c_uf: string;
  c_nf: string;
  nat_op: string;
  serie: string;
  n_nf: string;
  dh_emi: string;
  tp_nf: string;
  id_dest: string;
  c_mun_fg: string;
  tp_amb: string;
  fin_nfe: string;
  ind_pres: string;
}

export interface ItemDTO {
  c_prod: string;
  x_prod: string;
  ncm: string;
  cfop: string;
  u_com: string;
  q_com: string;
  v_un_com: string;
  v_prod: string;
  v_bc: string;
  p_icms: string;
  v_pis: string;
  v_cofins: string;
}

export interface EmitNFeRequest {
  emit: EmitterDTO;
  dest: RecipientDTO;
  ide: IdentificationDTO;
  items: ItemDTO[];
}

export interface EmitNFeResponse {
  chave: string;
  status: AuthorizationStatus;
  lifecycle: NFeLifecycle;
  c_stat: string;
  x_motivo: string;
  protocol?: Protocol;
  rejection?: Rejection;
}
