import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { LoadingService } from './loading.service';

describe('LoadingService', () => {
  let service: LoadingService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [LoadingService] });
    service = TestBed.inject(LoadingService);
  });

  it('starts not loading', async () => {
    await expect(firstValueFrom(service.loading$)).resolves.toBe(false);
  });

  it('show() flips loading to true and hide() flips back', async () => {
    const states: boolean[] = [];
    const sub = service.loading$.subscribe(v => states.push(v));

    service.show();
    service.hide();
    sub.unsubscribe();

    expect(states).toEqual([false, true, false]);
  });

  it('distinctUntilChanged drops repeated emissions', async () => {
    const states: boolean[] = [];
    const sub = service.loading$.subscribe(v => states.push(v));

    service.show();
    service.show();
    service.show();
    service.hide();
    sub.unsubscribe();

    expect(states).toEqual([false, true, false]);
  });

  it('isLoading() returns the same observable', () => {
    expect(service.isLoading()).toBe(service.loading$);
  });
});
