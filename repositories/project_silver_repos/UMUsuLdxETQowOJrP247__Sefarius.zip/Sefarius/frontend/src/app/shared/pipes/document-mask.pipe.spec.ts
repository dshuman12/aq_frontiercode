import { CnpjPipe, CpfPipe, CepPipe } from './document-mask.pipe';

describe('CnpjPipe', () => {
  const pipe = new CnpjPipe();

  it('formata dígitos puros como XX.XXX.XXX/XXXX-XX', () => {
    expect(pipe.transform('11222333000181')).toBe('11.222.333/0001-81');
  });

  it('é idempotente: já formatado entra e sai igual (strip→format)', () => {
    expect(pipe.transform('11.222.333/0001-81')).toBe('11.222.333/0001-81');
  });

  it('retorna string vazia para null/undefined/empty', () => {
    expect(pipe.transform(null)).toBe('');
    expect(pipe.transform(undefined)).toBe('');
    expect(pipe.transform('')).toBe('');
  });

  it('formato parcial pra valor incompleto (não trava em CNPJ inválido)', () => {
    expect(pipe.transform('1122')).toBe('11.22');
    expect(pipe.transform('11222333')).toBe('11.222.333');
  });
});

describe('CpfPipe', () => {
  const pipe = new CpfPipe();

  it('formata dígitos puros como XXX.XXX.XXX-XX', () => {
    expect(pipe.transform('52998224725')).toBe('529.982.247-25');
  });

  it('é idempotente para CPF já formatado', () => {
    expect(pipe.transform('529.982.247-25')).toBe('529.982.247-25');
  });

  it('retorna string vazia para null/undefined', () => {
    expect(pipe.transform(null)).toBe('');
    expect(pipe.transform(undefined)).toBe('');
  });
});

describe('CepPipe', () => {
  const pipe = new CepPipe();

  it('formata dígitos puros como XXXXX-XXX', () => {
    expect(pipe.transform('90040000')).toBe('90040-000');
  });

  it('é idempotente para CEP já formatado', () => {
    expect(pipe.transform('90040-000')).toBe('90040-000');
  });

  it('retorna string vazia para null/undefined', () => {
    expect(pipe.transform(null)).toBe('');
    expect(pipe.transform(undefined)).toBe('');
  });
});
