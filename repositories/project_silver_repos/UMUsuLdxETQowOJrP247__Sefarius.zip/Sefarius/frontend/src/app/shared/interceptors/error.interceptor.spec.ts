import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ErrorService } from '../services/error.service';
import { errorInterceptor } from './error.interceptor';

describe('errorInterceptor', () => {
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let showError: jest.SpyInstance;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        ErrorService
      ]
    });
    http = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    showError = jest.spyOn(TestBed.inject(ErrorService), 'showError');
  });

  afterEach(() => httpMock.verify());

  function expectMessage(status: number, expected: string) {
    http.get('/api/foo').subscribe({ error: () => undefined });
    httpMock.expectOne('/api/foo').flush('err', { status, statusText: 'err' });
    expect(showError).toHaveBeenCalledWith(expected);
  }

  it('maps status 0 (network) to a connection error', () => {
    expectMessage(0, 'Erro de conexão. Verifique se o servidor está disponível.');
  });

  it('maps status 401 to "Não autorizado"', () => expectMessage(401, 'Não autorizado'));
  it('maps status 404 to "Recurso não encontrado"', () =>
    expectMessage(404, 'Recurso não encontrado'));
  it('maps status 409 to "Conflito nos dados"', () => expectMessage(409, 'Conflito nos dados'));
  it('maps status 500 to "Erro interno do servidor"', () =>
    expectMessage(500, 'Erro interno do servidor'));
  it('maps status 503 to a service-unavailable message', () =>
    expectMessage(503, 'Serviço indisponível. Tente novamente mais tarde.'));

  it('uses the server-provided error string for 400 responses', () => {
    http.get('/api/foo').subscribe({ error: () => undefined });
    httpMock
      .expectOne('/api/foo')
      .flush({ error: 'campo X faltando' }, { status: 400, statusText: 'Bad' });
    expect(showError).toHaveBeenCalledWith('campo X faltando');
  });

  it('falls back to "Requisição inválida" when 400 has no body', () => {
    http.get('/api/foo').subscribe({ error: () => undefined });
    httpMock.expectOne('/api/foo').flush(null, { status: 400, statusText: 'Bad' });
    expect(showError).toHaveBeenCalledWith('Requisição inválida');
  });

  it('does not show error for 404 on print-status URLs (caller handles them)', () => {
    http.get('/api/print/print-status/123').subscribe({ error: () => undefined });
    httpMock
      .expectOne('/api/print/print-status/123')
      .flush(null, { status: 404, statusText: 'NF' });
    expect(showError).not.toHaveBeenCalled();
  });

  it('formats unknown statuses with the body error', () => {
    http.get('/api/foo').subscribe({ error: () => undefined });
    httpMock
      .expectOne('/api/foo')
      .flush({ error: 'pretty bad' }, { status: 418, statusText: 'I am a teapot' });
    expect(showError).toHaveBeenCalledWith(expect.stringContaining('418'));
    expect(showError).toHaveBeenCalledWith(expect.stringContaining('pretty bad'));
  });
});
