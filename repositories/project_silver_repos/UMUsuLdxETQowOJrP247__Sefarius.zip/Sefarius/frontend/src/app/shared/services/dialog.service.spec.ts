import { TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { of } from 'rxjs';
import { DialogService } from './dialog.service';
import { ConfirmDialogComponent } from '../components/confirm-dialog/confirm-dialog.component';

describe('DialogService', () => {
  let service: DialogService;
  let openMock: jest.Mock;
  let afterClosed: jest.Mock;

  beforeEach(() => {
    afterClosed = jest.fn().mockReturnValue(of(true));
    openMock = jest.fn().mockReturnValue({ afterClosed });
    TestBed.configureTestingModule({
      providers: [DialogService, { provide: MatDialog, useValue: { open: openMock } }]
    });
    service = TestBed.inject(DialogService);
  });

  it('confirm() opens ConfirmDialog with passed data and resolves true on accept', async () => {
    const result = await service.confirm({
      title: 't',
      message: 'm',
      confirmLabel: 'OK',
      cancelLabel: 'No'
    });
    expect(openMock).toHaveBeenCalledWith(
      ConfirmDialogComponent,
      expect.objectContaining({
        width: '400px',
        data: expect.objectContaining({ title: 't', message: 'm' })
      })
    );
    expect(result).toBe(true);
  });

  it('confirm() resolves false when dialog returns anything other than true', async () => {
    afterClosed.mockReturnValueOnce(of(false));
    const result = await service.confirm({ title: 't', message: 'm' });
    expect(result).toBe(false);
  });

  it('confirm() resolves false when dialog returns undefined (closed via backdrop)', async () => {
    afterClosed.mockReturnValueOnce(of(undefined));
    const result = await service.confirm({ title: 't', message: 'm' });
    expect(result).toBe(false);
  });

  it('confirmDelete() builds a danger dialog with the item name', async () => {
    await service.confirmDelete('o produto X');
    expect(openMock).toHaveBeenCalledWith(
      ConfirmDialogComponent,
      expect.objectContaining({
        data: expect.objectContaining({
          title: 'Confirmar exclusão',
          message: expect.stringContaining('o produto X'),
          confirmLabel: 'Deletar',
          isDangerous: true
        })
      })
    );
  });

  it('confirmDelete() falls back to "este item" when no name is provided', async () => {
    await service.confirmDelete();
    const args = openMock.mock.calls[0][1];
    expect(args.data.message).toContain('este item');
  });

  it('success() builds an OK-only success dialog', async () => {
    await service.success('done');
    const args = openMock.mock.calls[0][1];
    expect(args.data).toMatchObject({
      title: 'Sucesso',
      message: 'done',
      confirmLabel: 'OK',
      cancelLabel: '',
      isDangerous: false
    });
  });

  it('error() builds an OK-only danger dialog', async () => {
    await service.error('boom');
    const args = openMock.mock.calls[0][1];
    expect(args.data).toMatchObject({
      title: 'Erro',
      message: 'boom',
      isDangerous: true
    });
  });
});
