import { Pipe, PipeTransform } from '@angular/core';

/**
 * Renders a numeric BRL value with a profile that scales by magnitude:
 *   < 10 mil                   -> "R$ 999,99" / "R$ 9.999,99" (BRL completo, 2 casas)
 *   < 1 milhao                 -> "R$ 12,3 mil" (1 casa decimal)
 *   < 1 bilhao                 -> "R$ 1,2 mi"  (1 casa decimal)
 *   < 1 trilhao                -> "R$ 1,2 bi"
 *   >= 1 trilhao               -> "R$ 1,2 tri"
 *
 * Bug B4 (2026-05-07): the threshold for the compact suffix used to be
 * 1 milhão, which left 6-digit values like "R$ 50.895,70" to overflow
 * the .stat-value cell with text-overflow:ellipsis (showing "R$ 50.895,…"
 * — exactly the report's symptom). Lowered to 10 mil so anything that
 * needs more characters than "R$ 9.999,99" gets compacted instead.
 *
 * Operators who need the exact value still get it from the [title]
 * tooltip on the same span.
 *
 * Negative inputs are scaled by absolute value but keep the sign — the
 * BRL formatter already prefixes the minus, so the compact branch
 * preserves it via the divided number passing through Intl directly.
 *
 * Non-breaking spaces produced by Intl.NumberFormat (U+00A0 between
 * the symbol and digits in pt-BR) are normalized to regular spaces so
 * tests, comparisons, and external consumers can match on plain
 * whitespace without ICU-version drift.
 */
@Pipe({ name: 'compactCurrency', standalone: true })
export class CompactCurrencyPipe implements PipeTransform {
  // RegExp built from String.fromCharCode(0xa0) so the source file
  // contains zero literal non-breaking spaces — ESLint's
  // no-irregular-whitespace rule rejects them in regex literals.
  private static readonly NBSP_RE = new RegExp(String.fromCharCode(0xa0), 'g');

  transform(value: number | null | undefined): string {
    if (value === null || value === undefined || Number.isNaN(value)) {
      return '';
    }

    const abs = Math.abs(value);
    let out: string;

    if (abs < 10_000) {
      out = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(value);
    } else {
      let scaled: number;
      let suffix: string;
      if (abs < 1_000_000) {
        scaled = value / 1_000;
        suffix = ' mil';
      } else if (abs < 1_000_000_000) {
        scaled = value / 1_000_000;
        suffix = ' mi';
      } else if (abs < 1_000_000_000_000) {
        scaled = value / 1_000_000_000;
        suffix = ' bi';
      } else {
        scaled = value / 1_000_000_000_000;
        suffix = ' tri';
      }
      const formatted = new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1
      }).format(scaled);
      out = `R$ ${formatted}${suffix}`;
    }

    return out.replace(CompactCurrencyPipe.NBSP_RE, ' ');
  }
}
