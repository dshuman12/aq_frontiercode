import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PaginationComponent } from './pagination.component';

describe('PaginationComponent', () => {
  let component: PaginationComponent;
  let fixture: ComponentFixture<PaginationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaginationComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(PaginationComponent);
    component = fixture.componentInstance;
    component.total = 100;
    component.pageSize = 25;
    component.currentPage = 2;
    fixture.detectChanges();
  });

  // Bug regression — 2026-05-08. Os Inputs `pageSize` e `currentPage`
  // eram declarados só como `set`, sem getter. Em runtime, lê-los via
  // template binding (`[value]="pageSize"`, `[class.is-active]="p === currentPage"`)
  // retornava `undefined`, então o <select> sempre caía na primeira
  // opção (10) e nenhum botão de página ficava ativo, em /products,
  // /invoices e /nfe simultaneamente. Os getters foram adicionados
  // pra fechar o bug. Estes testes falham se alguém remover os getters.
  describe('Input getters (regression: setter-only quebrava template bindings)', () => {
    it('pageSize getter returns the value set via @Input', () => {
      component.pageSize = 50;
      expect(component.pageSize).toBe(50);
    });

    it('currentPage getter returns the value set via @Input', () => {
      component.currentPage = 7;
      expect(component.currentPage).toBe(7);
    });

    it('total getter returns the value set via @Input', () => {
      component.total = 247;
      expect(component.total).toBe(247);
    });

    it('select element rendered value reflects pageSize input', () => {
      component.pageSize = 50;
      fixture.detectChanges();
      const select = fixture.nativeElement.querySelector('.page-size-select') as HTMLSelectElement;
      expect(select.value).toBe('50');
    });

    it('the active page button has is-active class matching currentPage', () => {
      component.total = 100;
      component.pageSize = 10;
      component.currentPage = 3;
      fixture.detectChanges();
      const activeButtons = fixture.nativeElement.querySelectorAll('.page-btn-num.is-active');
      expect(activeButtons.length).toBe(1);
      expect(activeButtons[0].textContent.trim()).toBe('3');
    });
  });

  describe('Input clamping', () => {
    it('pageSize clamps to >= 1', () => {
      component.pageSize = 0;
      expect(component.pageSize).toBe(1);
      component.pageSize = -5;
      expect(component.pageSize).toBe(1);
    });

    it('currentPage clamps to >= 1', () => {
      component.currentPage = 0;
      expect(component.currentPage).toBe(1);
    });

    it('total clamps to >= 0', () => {
      component.total = -10;
      expect(component.total).toBe(0);
    });
  });

  describe('totalPages', () => {
    it('returns 1 when total is 0 (avoids division-by-zero UI)', () => {
      component.total = 0;
      expect(component.totalPages()).toBe(1);
    });

    it('rounds up partial pages (101 / 25 = 5)', () => {
      component.total = 101;
      component.pageSize = 25;
      expect(component.totalPages()).toBe(5);
    });
  });

  describe('visiblePages window', () => {
    it('returns all pages when totalPages <= 7 (no ellipsis)', () => {
      component.total = 50;
      component.pageSize = 10;
      component.currentPage = 3;
      expect(component.visiblePages()).toEqual([1, 2, 3, 4, 5]);
    });

    it('inserts ellipsis on the right edge when current is near the start', () => {
      component.total = 200;
      component.pageSize = 10;
      component.currentPage = 1;
      expect(component.visiblePages()).toEqual([1, 2, null, 20]);
    });

    it('inserts ellipsis on both sides when current is in the middle', () => {
      component.total = 200;
      component.pageSize = 10;
      component.currentPage = 10;
      expect(component.visiblePages()).toEqual([1, null, 9, 10, 11, null, 20]);
    });

    it('inserts ellipsis on the left edge when current is near the end', () => {
      component.total = 200;
      component.pageSize = 10;
      component.currentPage = 20;
      expect(component.visiblePages()).toEqual([1, null, 19, 20]);
    });
  });

  describe('rangeLabel', () => {
    // itemLabel é @Input() simples (não signal); o pattern é "configure
    // once" via template binding e não muda em runtime — por isso os
    // testes abaixo usam o default 'itens'. O computed só recompute
    // quando _total/_pageSize/_currentPage mudam.
    it('formats "X–Y de N itens" with default itemLabel', () => {
      component.total = 100;
      component.pageSize = 25;
      component.currentPage = 2;
      expect(component.rangeLabel()).toBe('26–50 de 100 itens');
    });

    it('clamps the upper bound on the last partial page', () => {
      component.total = 47;
      component.pageSize = 25;
      component.currentPage = 2;
      expect(component.rangeLabel()).toBe('26–47 de 47 itens');
    });

    it('shows "0 itens" when there is nothing to paginate', () => {
      component.total = 0;
      expect(component.rangeLabel()).toBe('0 itens');
    });
  });

  describe('canPrev / canNext', () => {
    it('canPrev is false on page 1', () => {
      component.currentPage = 1;
      expect(component.canPrev()).toBe(false);
    });

    it('canNext is false on the last page', () => {
      component.total = 50;
      component.pageSize = 25;
      component.currentPage = 2;
      expect(component.canNext()).toBe(false);
    });

    it('both true in the middle', () => {
      component.total = 100;
      component.pageSize = 10;
      component.currentPage = 5;
      expect(component.canPrev()).toBe(true);
      expect(component.canNext()).toBe(true);
    });
  });

  describe('navigation events', () => {
    it('goToPage emits pageChange with the new page', () => {
      const spy = jest.fn();
      component.pageChange.subscribe(spy);
      component.goToPage(3);
      expect(spy).toHaveBeenCalledWith(3);
    });

    it('goToPage is a no-op for the current page', () => {
      const spy = jest.fn();
      component.pageChange.subscribe(spy);
      component.currentPage = 2;
      component.goToPage(2);
      expect(spy).not.toHaveBeenCalled();
    });

    it('goToPage clamps out-of-range and does not emit', () => {
      const spy = jest.fn();
      component.pageChange.subscribe(spy);
      component.total = 100;
      component.pageSize = 25;
      component.goToPage(0);
      component.goToPage(5);
      expect(spy).not.toHaveBeenCalled();
    });

    it('prev / next emit the adjacent page', () => {
      const spy = jest.fn();
      component.pageChange.subscribe(spy);
      component.total = 100;
      component.pageSize = 10;
      component.currentPage = 5;
      component.next();
      expect(spy).toHaveBeenCalledWith(6);
      component.prev();
      expect(spy).toHaveBeenCalledWith(4);
    });

    it('onPageSizeChange emits pageSizeChange with the parsed int', () => {
      const spy = jest.fn();
      component.pageSizeChange.subscribe(spy);
      component.onPageSizeChange('50');
      expect(spy).toHaveBeenCalledWith(50);
    });

    it('onPageSizeChange ignores garbage input (does not emit NaN)', () => {
      const spy = jest.fn();
      component.pageSizeChange.subscribe(spy);
      component.onPageSizeChange('abc');
      component.onPageSizeChange('-5');
      expect(spy).not.toHaveBeenCalled();
    });
  });
});
