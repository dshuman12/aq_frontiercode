import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { LoadingService } from '../services/loading.service';
import { loadingInterceptor } from './loading.interceptor';

describe('loadingInterceptor', () => {
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let loadingService: LoadingService;
  let showSpy: jest.SpyInstance;
  let hideSpy: jest.SpyInstance;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([loadingInterceptor])),
        provideHttpClientTesting(),
        LoadingService
      ]
    });
    http = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    loadingService = TestBed.inject(LoadingService);
    showSpy = jest.spyOn(loadingService, 'show');
    hideSpy = jest.spyOn(loadingService, 'hide');
  });

  afterEach(() => httpMock.verify());

  it('show() before the request and hide() after success', () => {
    http.get('/api/foo').subscribe();
    expect(showSpy).toHaveBeenCalledTimes(1);
    expect(hideSpy).not.toHaveBeenCalled();

    httpMock.expectOne('/api/foo').flush({});
    expect(hideSpy).toHaveBeenCalledTimes(1);
  });

  it('still hides after an error response', () => {
    http.get('/api/foo').subscribe({ error: () => undefined });
    httpMock.expectOne('/api/foo').flush('boom', { status: 500, statusText: 'err' });
    expect(hideSpy).toHaveBeenCalledTimes(1);
  });

  it('does not toggle loading on /health checks', () => {
    http.get('/api/health').subscribe();
    httpMock.expectOne('/api/health').flush({});
    expect(showSpy).not.toHaveBeenCalled();
    expect(hideSpy).not.toHaveBeenCalled();
  });
});
