import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';

/** Bloqueia rotas privadas para visitantes não autenticados. Espera o
 * AuthService terminar o bootstrap (GET /profile inicial) antes de
 * decidir — sem isso, navegação direta pra rota protegida sempre
 * cairia em /login mesmo com sessão válida no cookie. */
export const authGuard: CanActivateFn = (): Observable<boolean | UrlTree> => {
  const auth = inject(AuthService);
  const router = inject(Router);
  return auth
    .whenReady()
    .pipe(map(() => (auth.isAuthenticated() ? true : router.createUrlTree(['/login']))));
};

/** Bloqueia rotas de visitante (login/register/etc) para usuários já logados. */
export const guestGuard: CanActivateFn = (): Observable<boolean | UrlTree> => {
  const auth = inject(AuthService);
  const router = inject(Router);
  return auth
    .whenReady()
    .pipe(map(() => (auth.isAuthenticated() ? router.createUrlTree(['/dashboard']) : true)));
};
