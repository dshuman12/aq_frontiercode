import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

/**
 * Subset of the ViaCEP response we consume. The real API returns more
 * fields (complemento, ddd, gia, siafi) which we ignore — only the
 * pieces that map directly onto the EmitNFeRequest emit/dest blocks
 * are typed, so a future API change to the trailing fields can't
 * silently break the wizard.
 */
export interface ViaCepResponse {
  cep: string;
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
  /** IBGE 7-digit municipality code; the wizard's c_mun field. */
  ibge: string;
  /** Truthy when ViaCEP cannot resolve the CEP. */
  erro?: boolean;
}

/**
 * Looks up a Brazilian ZIP code via the public ViaCEP service. The
 * service is anonymous, free, and has no auth — but it is OUTSIDE our
 * stack, so the wizard treats every lookup as best-effort. Errors are
 * mapped to `null` and the form falls back to manual entry; a 404
 * from ViaCEP also surfaces as `null` (the API uses `{ erro: true }`
 * with HTTP 200 for unknown CEPs, which would otherwise slip past a
 * naive HTTP-error guard).
 */
@Injectable({ providedIn: 'root' })
export class ViaCepService {
  private static readonly BASE = 'https://viacep.com.br/ws';

  constructor(private http: HttpClient) {}

  /**
   * Returns the resolved address or null. Strips non-digits before
   * dispatching, so callers can pass "01310-100" or "01310100" alike.
   * Length validation is the caller's job — passing fewer than 8
   * digits returns null without an HTTP call.
   */
  lookup(cep: string): Observable<ViaCepResponse | null> {
    const digits = (cep ?? '').replace(/\D/g, '');
    if (digits.length !== 8) {
      return of(null);
    }
    return this.http.get<ViaCepResponse>(`${ViaCepService.BASE}/${digits}/json/`).pipe(
      map(resp => (resp && resp.erro ? null : resp)),
      catchError(() => of(null))
    );
  }
}
