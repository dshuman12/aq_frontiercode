import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { shareReplay, distinctUntilChanged } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ErrorService {
  private errorSubject = new BehaviorSubject<string | null>(null);
  public error$ = this.errorSubject.asObservable().pipe(distinctUntilChanged(), shareReplay(1));

  showError(message: string, duration = 5000): void {
    this.errorSubject.next(message);

    if (duration > 0) {
      setTimeout(() => {
        this.clearError();
      }, duration);
    }
  }

  clearError(): void {
    this.errorSubject.next(null);
  }

  getError(): Observable<string | null> {
    return this.error$;
  }
}
