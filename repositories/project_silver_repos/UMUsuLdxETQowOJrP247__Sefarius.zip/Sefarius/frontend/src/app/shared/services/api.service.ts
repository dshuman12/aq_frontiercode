import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { v4 as uuidv4 } from 'uuid';
import { environment } from '@env/environment';
import {
  ActionResult,
  ApiResponse,
  CreateInvoiceRequest,
  CreateProductRequest,
  Invoice,
  InvoiceStats,
  PaginatedResponse,
  PrintJob,
  PrintJobStatus,
  Product,
  UpdateProductRequest
} from '@app/shared/models/api.models';
import {
  CancelRequest,
  CCeRequest,
  EmitNFeRequest,
  EmitNFeResponse,
  EventResponse,
  NFeListItem,
  NFeRecord
} from '@app/shared/models/nfe.models';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  // Stock

  getProducts(limit = 20, offset = 0): Observable<ApiResponse<PaginatedResponse<Product>>> {
    return this.http.get<ApiResponse<PaginatedResponse<Product>>>(
      `${this.baseUrl}/stock/products`,
      { params: { limit, offset } }
    );
  }

  /**
   * Searches products by code OR description via the backend's q-mode.
   * The backend enforces a 2-char minimum and caps the result at
   * `limit` (default 20 server-side); requests under that floor are
   * answered with an empty list, so the autocomplete consumer can
   * call this on every keystroke without rate-limiting.
   */
  searchProducts(query: string, limit = 20): Observable<ApiResponse<PaginatedResponse<Product>>> {
    return this.http.get<ApiResponse<PaginatedResponse<Product>>>(
      `${this.baseUrl}/stock/products`,
      { params: { q: query, limit } }
    );
  }

  getProduct(id: string): Observable<ApiResponse<Product>> {
    return this.http.get<ApiResponse<Product>>(`${this.baseUrl}/stock/products/${id}`);
  }

  createProduct(data: CreateProductRequest): Observable<ApiResponse<Product>> {
    return this.http.post<ApiResponse<Product>>(`${this.baseUrl}/stock/products`, data);
  }

  updateProduct(id: string, data: UpdateProductRequest): Observable<ApiResponse<Product>> {
    return this.http.put<ApiResponse<Product>>(`${this.baseUrl}/stock/products/${id}`, data);
  }

  deleteProduct(id: string): Observable<ApiResponse<ActionResult>> {
    return this.http.delete<ApiResponse<ActionResult>>(`${this.baseUrl}/stock/products/${id}`);
  }

  // Billing (legacy invoice management)

  getInvoices(limit = 20, offset = 0): Observable<ApiResponse<PaginatedResponse<Invoice>>> {
    return this.http.get<ApiResponse<PaginatedResponse<Invoice>>>(
      `${this.baseUrl}/billing/invoices`,
      { params: { limit, offset } }
    );
  }

  getInvoice(id: string): Observable<ApiResponse<Invoice>> {
    return this.http.get<ApiResponse<Invoice>>(`${this.baseUrl}/billing/invoices/${id}`);
  }

  createInvoice(data: CreateInvoiceRequest): Observable<ApiResponse<Invoice>> {
    const idempotencyKey = uuidv4();
    const headers = new HttpHeaders({ 'Idempotency-Key': idempotencyKey });
    return this.http.post<ApiResponse<Invoice>>(
      `${this.baseUrl}/billing/invoices`,
      { ...data, idempotency_key: idempotencyKey },
      { headers }
    );
  }

  closeInvoice(id: string): Observable<ApiResponse<Invoice>> {
    return this.http.post<ApiResponse<Invoice>>(`${this.baseUrl}/billing/invoices/${id}/close`, {});
  }

  cancelInvoice(id: string): Observable<ApiResponse<Invoice>> {
    return this.http.post<ApiResponse<Invoice>>(
      `${this.baseUrl}/billing/invoices/${id}/cancel`,
      {}
    );
  }

  deleteInvoice(id: string): Observable<ApiResponse<ActionResult>> {
    return this.http.delete<ApiResponse<ActionResult>>(`${this.baseUrl}/billing/invoices/${id}`);
  }

  // Print

  createPrintJob(invoiceId: string): Observable<ApiResponse<PrintJob>> {
    const idempotencyKey = uuidv4();
    const headers = new HttpHeaders({ 'Idempotency-Key': idempotencyKey });
    return this.http.post<ApiResponse<PrintJob>>(
      `${this.baseUrl}/print/invoices/${invoiceId}/print`,
      {},
      { headers }
    );
  }

  getPrintJobStatus(jobId: string): Observable<ApiResponse<PrintJobStatus>> {
    return this.http.get<ApiResponse<PrintJobStatus>>(`${this.baseUrl}/print/print-jobs/${jobId}`);
  }

  getInvoicePrintStatus(invoiceId: string): Observable<ApiResponse<PrintJobStatus | null>> {
    return this.http.get<ApiResponse<PrintJobStatus | null>>(
      `${this.baseUrl}/print/invoices/${invoiceId}/print-status`
    );
  }

  retryPrintJob(jobId: string): Observable<ApiResponse<PrintJob>> {
    return this.http.post<ApiResponse<PrintJob>>(
      `${this.baseUrl}/print/print-jobs/${jobId}/retry`,
      {}
    );
  }

  // Invoice history / stats

  getInvoiceHistory(): Observable<ApiResponse<Invoice[]>> {
    return this.http.get<ApiResponse<Invoice[]>>(`${this.baseUrl}/invoices/history`);
  }

  getInvoiceStats(): Observable<ApiResponse<InvoiceStats>> {
    return this.http.get<ApiResponse<InvoiceStats>>(`${this.baseUrl}/invoices/stats`);
  }

  // NFe

  emitNFe(req: EmitNFeRequest): Observable<ApiResponse<EmitNFeResponse>> {
    return this.http.post<ApiResponse<EmitNFeResponse>>(`${this.baseUrl}/nfe`, req);
  }

  listNFe(limit = 50, offset = 0): Observable<ApiResponse<PaginatedResponse<NFeListItem>>> {
    return this.http.get<ApiResponse<PaginatedResponse<NFeListItem>>>(`${this.baseUrl}/nfe`, {
      params: { limit, offset }
    });
  }

  getNFe(chave: string): Observable<ApiResponse<NFeRecord>> {
    return this.http.get<ApiResponse<NFeRecord>>(`${this.baseUrl}/nfe/${chave}`);
  }

  nfeXMLUrl(chave: string): string {
    return `${this.baseUrl}/nfe/${chave}/xml`;
  }

  nfeDanfeUrl(chave: string): string {
    return `${this.baseUrl}/nfe/${chave}/danfe`;
  }

  cancelNFe(chave: string, body: CancelRequest): Observable<ApiResponse<EventResponse>> {
    return this.http.post<ApiResponse<EventResponse>>(`${this.baseUrl}/nfe/${chave}/cancel`, body);
  }

  getCancel(chave: string): Observable<ApiResponse<EventResponse>> {
    return this.http.get<ApiResponse<EventResponse>>(`${this.baseUrl}/nfe/${chave}/cancel`);
  }

  cancelXMLUrl(chave: string): string {
    return `${this.baseUrl}/nfe/${chave}/cancel/xml`;
  }

  cancelPDFUrl(chave: string): string {
    return `${this.baseUrl}/nfe/${chave}/cancel/pdf`;
  }

  sendCCe(chave: string, body: CCeRequest): Observable<ApiResponse<EventResponse>> {
    return this.http.post<ApiResponse<EventResponse>>(`${this.baseUrl}/nfe/${chave}/cce`, body);
  }

  listCCe(chave: string): Observable<ApiResponse<EventResponse[]>> {
    return this.http.get<ApiResponse<EventResponse[]>>(`${this.baseUrl}/nfe/${chave}/cce`);
  }

  getCCe(chave: string, seq: number): Observable<ApiResponse<EventResponse>> {
    return this.http.get<ApiResponse<EventResponse>>(`${this.baseUrl}/nfe/${chave}/cce/${seq}`);
  }

  cceXMLUrl(chave: string, seq: number): string {
    return `${this.baseUrl}/nfe/${chave}/cce/${seq}/xml`;
  }

  ccePDFUrl(chave: string, seq: number): string {
    return `${this.baseUrl}/nfe/${chave}/cce/${seq}/pdf`;
  }
}
