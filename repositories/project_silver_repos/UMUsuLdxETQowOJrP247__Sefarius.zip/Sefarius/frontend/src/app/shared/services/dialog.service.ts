import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  ConfirmDialogComponent,
  DialogData
} from '../components/confirm-dialog/confirm-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  constructor(private matDialog: MatDialog) {}

  confirm(data: DialogData): Promise<boolean> {
    return this.matDialog
      .open(ConfirmDialogComponent, {
        width: '400px',
        disableClose: false,
        data
      })
      .afterClosed()
      .toPromise()
      .then(result => result === true);
  }

  confirmDelete(itemName?: string): Promise<boolean> {
    return this.confirm({
      title: 'Confirmar exclusão',
      message: `Tem certeza que deseja deletar ${itemName || 'este item'}?`,
      confirmLabel: 'Deletar',
      cancelLabel: 'Cancelar',
      isDangerous: true
    });
  }

  success(message: string): Promise<boolean> {
    return this.confirm({
      title: 'Sucesso',
      message: message,
      confirmLabel: 'OK',
      cancelLabel: '',
      isDangerous: false
    });
  }

  error(message: string): Promise<boolean> {
    return this.confirm({
      title: 'Erro',
      message: message,
      confirmLabel: 'OK',
      cancelLabel: '',
      isDangerous: true
    });
  }
}
