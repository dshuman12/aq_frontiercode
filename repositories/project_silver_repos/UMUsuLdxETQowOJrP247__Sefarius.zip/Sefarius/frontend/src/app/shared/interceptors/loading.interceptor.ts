import { HttpInterceptorFn, HttpRequest, HttpEvent } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { LoadingService } from '../services/loading.service';

export const loadingInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next
): Observable<HttpEvent<unknown>> => {
  const loadingService = inject(LoadingService);

  // Don't show loading for health checks
  const isHealthCheck = req.url.includes('/health');

  if (!isHealthCheck) {
    loadingService.show();
  }

  return next(req).pipe(
    finalize(() => {
      if (!isHealthCheck) {
        loadingService.hide();
      }
    })
  );
};
