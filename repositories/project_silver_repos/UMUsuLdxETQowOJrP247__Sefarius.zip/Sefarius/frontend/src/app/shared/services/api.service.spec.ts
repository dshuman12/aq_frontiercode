import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from './api.service';
import { environment } from '@env/environment';

describe('ApiService', () => {
  let service: ApiService;
  let httpMock: HttpTestingController;
  const base = environment.apiBaseUrl;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ApiService]
    });
    service = TestBed.inject(ApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  // ─── URL helpers (synchronous, no HTTP) ──────────────────────────────────

  describe('URL helpers', () => {
    const chave = '52260101010101000100550010000000011000000011';

    it('nfeXMLUrl', () => {
      expect(service.nfeXMLUrl(chave)).toBe(`${base}/nfe/${chave}/xml`);
    });

    it('nfeDanfeUrl', () => {
      expect(service.nfeDanfeUrl(chave)).toBe(`${base}/nfe/${chave}/danfe`);
    });

    it('cancelXMLUrl', () => {
      expect(service.cancelXMLUrl(chave)).toBe(`${base}/nfe/${chave}/cancel/xml`);
    });

    it('cancelPDFUrl', () => {
      expect(service.cancelPDFUrl(chave)).toBe(`${base}/nfe/${chave}/cancel/pdf`);
    });

    it('cceXMLUrl includes seq', () => {
      expect(service.cceXMLUrl(chave, 3)).toBe(`${base}/nfe/${chave}/cce/3/xml`);
    });

    it('ccePDFUrl includes seq', () => {
      expect(service.ccePDFUrl(chave, 1)).toBe(`${base}/nfe/${chave}/cce/1/pdf`);
    });
  });

  // ─── Stock endpoints ─────────────────────────────────────────────────────

  describe('Stock endpoints', () => {
    it('getProducts uses default pagination 20/0', () => {
      service.getProducts().subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/stock/products`);
      expect(req.request.method).toBe('GET');
      expect(req.request.params.get('limit')).toBe('20');
      expect(req.request.params.get('offset')).toBe('0');
      req.flush({ success: true, data: { items: [], total: 0, limit: 20, offset: 0 }, code: 200 });
    });

    it('getProducts respects explicit pagination', () => {
      service.getProducts(50, 100).subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/stock/products`);
      expect(req.request.params.get('limit')).toBe('50');
      expect(req.request.params.get('offset')).toBe('100');
      req.flush({
        success: true,
        data: { items: [], total: 0, limit: 50, offset: 100 },
        code: 200
      });
    });

    it('searchProducts adds ?q= to /stock/products and respects limit', () => {
      service.searchProducts('Note', 10).subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/stock/products`);
      expect(req.request.method).toBe('GET');
      expect(req.request.params.get('q')).toBe('Note');
      expect(req.request.params.get('limit')).toBe('10');
      // No offset is set in q-mode; the autocomplete consumer wants
      // top-N matches, not paginated lists.
      expect(req.request.params.has('offset')).toBe(false);
      req.flush({ success: true, data: { items: [], total: 0, limit: 10, offset: 0 }, code: 200 });
    });

    it('searchProducts default limit is 20', () => {
      service.searchProducts('foo').subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/stock/products`);
      expect(req.request.params.get('limit')).toBe('20');
      req.flush({ success: true, data: { items: [], total: 0, limit: 20, offset: 0 }, code: 200 });
    });

    it('getProduct hits /stock/products/:id', () => {
      service.getProduct('id-123').subscribe();
      const req = httpMock.expectOne(`${base}/stock/products/id-123`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('createProduct posts the payload', () => {
      const payload = { code: 'P1', description: 'Item', balance: 10 };
      service.createProduct(payload).subscribe();
      const req = httpMock.expectOne(`${base}/stock/products`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(payload);
      req.flush({ success: true, code: 201 });
    });

    it('updateProduct PUTs to /stock/products/:id', () => {
      service.updateProduct('id-1', { description: 'new' }).subscribe();
      const req = httpMock.expectOne(`${base}/stock/products/id-1`);
      expect(req.request.method).toBe('PUT');
      req.flush({ success: true, code: 200 });
    });

    it('deleteProduct DELETEs /stock/products/:id', () => {
      service.deleteProduct('id-1').subscribe();
      const req = httpMock.expectOne(`${base}/stock/products/id-1`);
      expect(req.request.method).toBe('DELETE');
      req.flush({ success: true, code: 200 });
    });
  });

  // ─── Billing (legacy invoice) endpoints ──────────────────────────────────

  describe('Billing endpoints', () => {
    it('getInvoices issues GET /billing/invoices', () => {
      service.getInvoices().subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/billing/invoices`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('createInvoice generates an Idempotency-Key header and forwards it in the body', () => {
      service.createInvoice({ created_by: 'me', items: [] }).subscribe();
      const req = httpMock.expectOne(`${base}/billing/invoices`);
      expect(req.request.method).toBe('POST');

      const headerKey = req.request.headers.get('Idempotency-Key');
      expect(headerKey).toBeTruthy();
      expect(req.request.body.idempotency_key).toBe(headerKey);

      req.flush({ success: true, code: 201 });
    });

    it('createInvoice generates a different key on each call', () => {
      service.createInvoice({ created_by: 'a', items: [] }).subscribe();
      service.createInvoice({ created_by: 'b', items: [] }).subscribe();
      const reqs = httpMock.match(`${base}/billing/invoices`);
      expect(reqs).toHaveLength(2);
      const k1 = reqs[0].request.headers.get('Idempotency-Key');
      const k2 = reqs[1].request.headers.get('Idempotency-Key');
      expect(k1).not.toBe(k2);
      reqs.forEach(r => r.flush({ success: true, code: 201 }));
    });

    it('closeInvoice POSTs /:id/close', () => {
      service.closeInvoice('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/billing/invoices/inv-1/close`);
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, code: 200 });
    });

    it('cancelInvoice POSTs /:id/cancel', () => {
      service.cancelInvoice('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/billing/invoices/inv-1/cancel`);
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, code: 200 });
    });
  });

  // ─── Print endpoints ─────────────────────────────────────────────────────

  describe('Print endpoints', () => {
    it('createPrintJob includes Idempotency-Key header', () => {
      service.createPrintJob('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/print/invoices/inv-1/print`);
      expect(req.request.headers.get('Idempotency-Key')).toBeTruthy();
      req.flush({ success: true, code: 201 });
    });

    it('getPrintJobStatus GETs /print/print-jobs/:id', () => {
      service.getPrintJobStatus('job-1').subscribe();
      const req = httpMock.expectOne(`${base}/print/print-jobs/job-1`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('getInvoicePrintStatus GETs /print/invoices/:id/print-status', () => {
      service.getInvoicePrintStatus('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/print/invoices/inv-1/print-status`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, data: null, code: 200 });
    });

    it('retryPrintJob POSTs /print/print-jobs/:id/retry', () => {
      service.retryPrintJob('job-1').subscribe();
      const req = httpMock.expectOne(`${base}/print/print-jobs/job-1/retry`);
      expect(req.request.method).toBe('POST');
      req.flush({ success: true, code: 200 });
    });
  });

  describe('Misc legacy endpoints', () => {
    it('getInvoice GETs /billing/invoices/:id', () => {
      service.getInvoice('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/billing/invoices/inv-1`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('deleteInvoice DELETEs /billing/invoices/:id', () => {
      service.deleteInvoice('inv-1').subscribe();
      const req = httpMock.expectOne(`${base}/billing/invoices/inv-1`);
      expect(req.request.method).toBe('DELETE');
      req.flush({ success: true, code: 200 });
    });

    it('getInvoiceHistory GETs /invoices/history', () => {
      service.getInvoiceHistory().subscribe();
      const req = httpMock.expectOne(`${base}/invoices/history`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('getInvoiceStats GETs /invoices/stats', () => {
      service.getInvoiceStats().subscribe();
      const req = httpMock.expectOne(`${base}/invoices/stats`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });
  });

  // ─── NFe endpoints ───────────────────────────────────────────────────────

  describe('NFe endpoints', () => {
    const chave = '52260101010101000100550010000000011000000011';

    it('emitNFe POSTs the request body to /nfe', () => {
      const payload = {
        emit: {
          cnpj: '11222333000181',
          x_nome: 'Empresa Teste',
          ie: '0123456789',
          crt: '3',
          x_lgr: 'Rua A',
          nro: '1',
          x_bairro: 'Centro',
          c_mun: '4314902',
          x_mun: 'Porto Alegre',
          uf: 'RS',
          cep: '90010000'
        },
        dest: {
          x_nome: 'Cliente',
          ind_ie_dest: '9',
          x_lgr: 'Rua B',
          nro: '2',
          x_bairro: 'Bairro',
          c_mun: '4314902',
          x_mun: 'Porto Alegre',
          uf: 'RS'
        },
        ide: {
          c_uf: '43',
          c_nf: '12345678',
          nat_op: 'Venda',
          serie: '1',
          n_nf: '1',
          dh_emi: '2026-05-07T10:00:00-03:00',
          tp_nf: '1',
          id_dest: '1',
          c_mun_fg: '4314902',
          tp_amb: '2',
          fin_nfe: '1',
          ind_pres: '1'
        },
        items: [
          {
            c_prod: 'P1',
            x_prod: 'Item',
            ncm: '12345678',
            cfop: '5102',
            u_com: 'UN',
            q_com: '1.0000',
            v_un_com: '100.00',
            v_prod: '100.00',
            v_bc: '100.00',
            p_icms: '18.00',
            v_pis: '0.00',
            v_cofins: '0.00'
          }
        ]
      };
      service.emitNFe(payload).subscribe();
      const req = httpMock.expectOne(`${base}/nfe`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(payload);
      req.flush({ success: true, code: 201 });
    });

    it('listNFe defaults to limit 50 / offset 0', () => {
      service.listNFe().subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/nfe`);
      expect(req.request.method).toBe('GET');
      expect(req.request.params.get('limit')).toBe('50');
      expect(req.request.params.get('offset')).toBe('0');
      req.flush({ success: true, data: [], code: 200 });
    });

    it('listNFe respects explicit pagination', () => {
      service.listNFe(10, 200).subscribe();
      const req = httpMock.expectOne(r => r.url === `${base}/nfe`);
      expect(req.request.params.get('limit')).toBe('10');
      expect(req.request.params.get('offset')).toBe('200');
      req.flush({ success: true, data: [], code: 200 });
    });

    it('getNFe hits /nfe/:chave', () => {
      service.getNFe(chave).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('cancelNFe POSTs justification body to /:chave/cancel', () => {
      service.cancelNFe(chave, { justification: 'Erro de digitação no item 2' }).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}/cancel`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual({ justification: 'Erro de digitação no item 2' });
      req.flush({ success: true, code: 201 });
    });

    it('getCancel GETs /:chave/cancel', () => {
      service.getCancel(chave).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}/cancel`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });

    it('sendCCe POSTs correction body and seq to /:chave/cce', () => {
      service.sendCCe(chave, { correction: 'Correção do item 3', seq: 2 }).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}/cce`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual({ correction: 'Correção do item 3', seq: 2 });
      req.flush({ success: true, code: 201 });
    });

    it('listCCe GETs /:chave/cce', () => {
      service.listCCe(chave).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}/cce`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, data: [], code: 200 });
    });

    it('getCCe GETs /:chave/cce/:seq', () => {
      service.getCCe(chave, 4).subscribe();
      const req = httpMock.expectOne(`${base}/nfe/${chave}/cce/4`);
      expect(req.request.method).toBe('GET');
      req.flush({ success: true, code: 200 });
    });
  });
});
