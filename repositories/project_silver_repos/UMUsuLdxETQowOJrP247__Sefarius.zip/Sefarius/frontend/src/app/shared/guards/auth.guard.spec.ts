import { TestBed } from '@angular/core/testing';
import {
  ActivatedRouteSnapshot,
  CanActivateFn,
  Router,
  RouterStateSnapshot,
  UrlTree
} from '@angular/router';
import { firstValueFrom, of, BehaviorSubject } from 'rxjs';

import { authGuard, guestGuard } from './auth.guard';
import { AuthService, AuthUser } from '../services/auth.service';

class FakeAuthService {
  private user: AuthUser | null = null;
  private ready$ = new BehaviorSubject<boolean>(true);

  whenReady() {
    return of(true);
  }

  isAuthenticated(): boolean {
    return this.user !== null;
  }

  setUser(u: AuthUser | null): void {
    this.user = u;
  }
}

function runGuard(guard: CanActivateFn): boolean | UrlTree | Promise<boolean | UrlTree> {
  return TestBed.runInInjectionContext(() => {
    const result = guard({} as ActivatedRouteSnapshot, { url: '/x' } as RouterStateSnapshot);
    if (result instanceof Promise || (result as { subscribe?: unknown })?.subscribe) {
      // CanActivateFn pode retornar Observable; convertemos pra Promise
      // pra simplificar asserts.
      return firstValueFrom(result as never);
    }
    return result as boolean | UrlTree;
  });
}

describe('auth.guard', () => {
  let fake: FakeAuthService;

  beforeEach(() => {
    fake = new FakeAuthService();
    TestBed.configureTestingModule({
      providers: [{ provide: AuthService, useValue: fake }]
    });
  });

  describe('authGuard', () => {
    it('allows when authenticated', async () => {
      fake.setUser({ id: '1', name: 'A', email: 'a@x.com', activated: true });
      const result = await runGuard(authGuard);
      expect(result).toBe(true);
    });

    it('redirects to /login when not authenticated', async () => {
      fake.setUser(null);
      const result = await runGuard(authGuard);
      const router = TestBed.inject(Router);
      const expected = router.createUrlTree(['/login']);
      expect((result as UrlTree).toString()).toBe(expected.toString());
    });
  });

  describe('guestGuard', () => {
    it('allows when not authenticated', async () => {
      fake.setUser(null);
      const result = await runGuard(guestGuard);
      expect(result).toBe(true);
    });

    it('redirects authenticated users to /dashboard', async () => {
      fake.setUser({ id: '1', name: 'A', email: 'a@x.com', activated: true });
      const result = await runGuard(guestGuard);
      const router = TestBed.inject(Router);
      const expected = router.createUrlTree(['/dashboard']);
      expect((result as UrlTree).toString()).toBe(expected.toString());
    });
  });
});
