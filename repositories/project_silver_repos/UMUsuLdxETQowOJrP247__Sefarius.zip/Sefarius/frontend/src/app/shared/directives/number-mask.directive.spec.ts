import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { NumberMaskDirective, formatMask, stripDigits } from './number-mask.directive';

describe('mask helpers', () => {
  describe('stripDigits', () => {
    it('removes everything that is not a digit', () => {
      expect(stripDigits('12.345.678/9012-34', 14)).toBe('12345678901234');
      expect(stripDigits('a1b2c3', 10)).toBe('123');
    });

    it('clamps to max digits (extra digits dropped)', () => {
      expect(stripDigits('12345678901234567', 14)).toBe('12345678901234');
      expect(stripDigits('12345678901234567', 11)).toBe('12345678901');
      expect(stripDigits('123456789', 8)).toBe('12345678');
    });

    it('returns empty string for null / undefined / non-string', () => {
      expect(stripDigits(null, 14)).toBe('');
      expect(stripDigits(undefined, 14)).toBe('');
      expect(stripDigits('', 14)).toBe('');
    });
  });

  describe('formatMask cnpj', () => {
    // Formato canônico SEFAZ: XX.XXX.XXX/XXXX-XX
    it('formata progressivamente conforme o user digita', () => {
      expect(formatMask('1', 'cnpj')).toBe('1');
      expect(formatMask('12', 'cnpj')).toBe('12');
      expect(formatMask('123', 'cnpj')).toBe('12.3');
      expect(formatMask('12345', 'cnpj')).toBe('12.345');
      expect(formatMask('123456', 'cnpj')).toBe('12.345.6');
      expect(formatMask('12345678', 'cnpj')).toBe('12.345.678');
      expect(formatMask('123456789', 'cnpj')).toBe('12.345.678/9');
      expect(formatMask('1234567890', 'cnpj')).toBe('12.345.678/90');
      expect(formatMask('123456789012', 'cnpj')).toBe('12.345.678/9012');
      expect(formatMask('1234567890123', 'cnpj')).toBe('12.345.678/9012-3');
      expect(formatMask('12345678901234', 'cnpj')).toBe('12.345.678/9012-34');
    });
  });

  describe('formatMask cpf', () => {
    // Formato canônico: XXX.XXX.XXX-XX
    it('formata progressivamente conforme o user digita', () => {
      expect(formatMask('1', 'cpf')).toBe('1');
      expect(formatMask('123', 'cpf')).toBe('123');
      expect(formatMask('1234', 'cpf')).toBe('123.4');
      expect(formatMask('123456', 'cpf')).toBe('123.456');
      expect(formatMask('1234567', 'cpf')).toBe('123.456.7');
      expect(formatMask('123456789', 'cpf')).toBe('123.456.789');
      expect(formatMask('1234567890', 'cpf')).toBe('123.456.789-0');
      expect(formatMask('12345678901', 'cpf')).toBe('123.456.789-01');
    });
  });

  describe('formatMask cep', () => {
    // Formato canônico: XXXXX-XXX
    it('formata progressivamente conforme o user digita', () => {
      expect(formatMask('1', 'cep')).toBe('1');
      expect(formatMask('12345', 'cep')).toBe('12345');
      expect(formatMask('123456', 'cep')).toBe('12345-6');
      expect(formatMask('12345678', 'cep')).toBe('12345-678');
    });
  });

  it('formatMask returns empty for empty input', () => {
    expect(formatMask('', 'cnpj')).toBe('');
    expect(formatMask('', 'cpf')).toBe('');
    expect(formatMask('', 'cep')).toBe('');
  });
});

@Component({
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, NumberMaskDirective],
  template: `
    <form [formGroup]="form">
      <input id="cnpj" formControlName="cnpj" appNumberMask="cnpj" />
      <input id="cpf" formControlName="cpf" appNumberMask="cpf" />
      <input id="cep" formControlName="cep" appNumberMask="cep" />
    </form>
  `
})
class HostComponent {
  form = new FormGroup({
    cnpj: new FormControl(''),
    cpf: new FormControl(''),
    cep: new FormControl('')
  });
}

describe('NumberMaskDirective (host integration)', () => {
  let fixture: ComponentFixture<HostComponent>;
  let host: HostComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HostComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(HostComponent);
    host = fixture.componentInstance;
    fixture.detectChanges();
  });

  function getInput(id: string): HTMLInputElement {
    return fixture.nativeElement.querySelector(`#${id}`) as HTMLInputElement;
  }

  function typeInto(input: HTMLInputElement, text: string): void {
    input.value = text;
    input.dispatchEvent(new Event('input'));
  }

  it('CNPJ: digitando dígitos puros, FormControl recebe só dígitos e input mostra formatado', () => {
    const input = getInput('cnpj');
    typeInto(input, '12345678901234');
    expect(input.value).toBe('12.345.678/9012-34');
    expect(host.form.get('cnpj')!.value).toBe('12345678901234');
  });

  it('CNPJ: paste com formatação extrai dígitos e re-formata', () => {
    const input = getInput('cnpj');
    typeInto(input, '12.345.678/9012-34');
    expect(input.value).toBe('12.345.678/9012-34');
    expect(host.form.get('cnpj')!.value).toBe('12345678901234');
  });

  it('CNPJ: digitando além de 14, é clampado', () => {
    const input = getInput('cnpj');
    typeInto(input, '123456789012345678');
    expect(host.form.get('cnpj')!.value).toBe('12345678901234');
    expect(input.value).toBe('12.345.678/9012-34');
  });

  it('CPF: input progressivo formata e FormControl guarda só dígitos', () => {
    const input = getInput('cpf');
    typeInto(input, '12345');
    expect(input.value).toBe('123.45');
    expect(host.form.get('cpf')!.value).toBe('12345');
    typeInto(input, '12345678901');
    expect(input.value).toBe('123.456.789-01');
    expect(host.form.get('cpf')!.value).toBe('12345678901');
  });

  it('CEP: input progressivo formata e FormControl guarda só dígitos', () => {
    const input = getInput('cep');
    typeInto(input, '12345678');
    expect(input.value).toBe('12345-678');
    expect(host.form.get('cep')!.value).toBe('12345678');
  });

  it('writeValue (FormControl.setValue) reformata o display', () => {
    const input = getInput('cnpj');
    host.form.get('cnpj')!.setValue('11222333000181');
    fixture.detectChanges();
    expect(input.value).toBe('11.222.333/0001-81');
  });

  it('letras digitadas são silenciosamente ignoradas', () => {
    const input = getInput('cpf');
    typeInto(input, 'abc123def456');
    expect(input.value).toBe('123.456');
    expect(host.form.get('cpf')!.value).toBe('123456');
  });

  it('disabled state via FormControl propaga pro input', () => {
    const input = getInput('cnpj');
    host.form.get('cnpj')!.disable();
    expect(input.disabled).toBe(true);
    host.form.get('cnpj')!.enable();
    expect(input.disabled).toBe(false);
  });
});
