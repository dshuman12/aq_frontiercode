/**
 * Status representativo do ciclo de vida de uma nota fiscal.
 * - OPEN: Tabela editável, ainda não congelada.
 * - CLOSED: Impede adições, nota pronta para listagem oficial.
 * - CANCELLED: Anulada logicamente com devolução de itens para estoque.
 */
export type InvoiceStatus = 'OPEN' | 'CLOSED' | 'CANCELLED';

export type PrintJobStatusType = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';

/**
 * Container genérico padronizado que envelopa qualquer chamada REST vinda dos Microsserviços Golang.
 */
export interface ApiResponse<T> {
  /** Indica sucesso binário HTTP 2xx da requisição */
  success: boolean;
  /** Payload de negócio tipado genérico */
  data?: T;
  /** Representação em string do Domain Error (ex: ErrProductNotFound) quando aplicável */
  error?: string;
  /** Código numérico amigável retornado para facilitar debug direto no Fiber */
  code: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export type ActionResult = Record<string, unknown>;

/**
 * Representação direta da tabela de Produtos do \`stock-service\`.
 */
export interface Product {
  /** UUID do produto */
  id: string;
  /** Código único SKU, ex: PROD01 */
  code: string;
  description: string;
  /** Saldo dinâmico (qnt.) existente, calculado retroativamente por transações */
  balance: number;
  /** Versão incremental para Optimistic Locking na persistência concorrente (Concurrency Control) */
  version: number;

  // Sprint Catálogo Fiscal (migration 006). NCM e valor_unitario são
  // nullable; os outros 7 têm default razoável aplicado pelo backend
  // (CFOP 5102, u_com UN, origem 0, CST ICMS 00, p_ICMS 18.00, CST PIS/COFINS 49).
  ncm?: string | null;
  cfop_padrao_saida: string;
  u_com: string;
  valor_unitario?: number | null;
  origem: string;
  cst_icms: string;
  p_icms: number;
  cst_pis: string;
  cst_cofins: string;

  created_at: string;
  updated_at: string;
}

export interface CreateProductRequest {
  code: string;
  description: string;
  balance: number;
  ncm?: string | null;
  cfop_padrao_saida?: string;
  u_com?: string;
  valor_unitario?: number | null;
  origem?: string;
  cst_icms?: string;
  p_icms?: number;
  cst_pis?: string;
  cst_cofins?: string;
}

export interface UpdateProductRequest {
  description?: string;
  balance?: number;
  ncm?: string | null;
  cfop_padrao_saida?: string;
  u_com?: string;
  valor_unitario?: number | null;
  origem?: string;
  cst_icms?: string;
  p_icms?: number;
  cst_pis?: string;
  cst_cofins?: string;
}

export interface InvoiceItem {
  id: string;
  product_id: string;
  product_code?: string;
  product_description?: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
  created_at?: string;
}

/**
 * Representação hierárquica base (*Aggregate Root*) da Nota Fiscal.
 * Contém detalhes vitais como Chave de Idempotência e soma total armazenada.
 */
export interface Invoice {
  id: string;
  /** Número sequencial garantido pela tabela do \`billing-service\` na inserção */
  number: number;
  status: InvoiceStatus;
  /** Código rastreador enviado pelo front-end para evitar inserção duplicada por Retry (crossover limit) */
  idempotency_key: string;
  /** Autor da emissão na interface administrativa */
  created_by: string;
  items: InvoiceItem[];
  /** Acumulado financeiro (somatório da quantidade X valor unitário de cada InvoiceItem) */
  total_amount: number;
  created_at: string;
  closed_at?: string | null;
}

export interface CreateInvoiceItemRequest {
  product_id: string;
  quantity: number;
  unit_price: number;
}

export interface CreateInvoiceRequest {
  created_by: string;
  items: CreateInvoiceItemRequest[];
}

export interface PrintJob {
  id: string;
  invoice_id: string;
  status: PrintJobStatusType;
  attempts: number;
  max_attempts: number;
  last_error?: string;
  created_at: string;
  completed_at?: string | null;
}

export interface PrintJobStatus {
  job_id: string;
  invoice_id: string;
  status: PrintJobStatusType;
  progress: number;
  message?: string;
}

export type InvoiceStats = Record<string, number | undefined> & {
  total?: number;
  open?: number;
  closed?: number;
  cancelled?: number;
};
