import { Component, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * Um componente primário altamente reutilizável projetado para prevenir "Memory Leaks" (Vazamentos de Memória)
 * gerados pelo motor do Angular.
 *
 * Componentes de interface que assumem subscriptions RxJS (\`.subscribe()\`)
 * DEVEM estender esta classe. Dessa forma, recebem a injeção do ciclo de vida nativo de destruição
 * (\`destroy$\`), ao invés de implementar manualmente \`OnDestroy\` múltiplas vezes.
 *
 * Exemplo de uso:
 * \`aObservable$.pipe(takeUntil(this.destroy$)).subscribe(...)\`
 */
@Component({
  template: ''
})
export abstract class BaseComponent implements OnDestroy {
  /** Observer emitido e completado atomicamente assim que Angular engatilha \`ngOnDestroy()\` */
  protected destroy$ = new Subject<void>();

  /**
   * Método nativo do Lifecycle compensado na destruição da View/Rota.
   * Cancela automaticamente todos os Observables ligados ao \`takeUntil(destroy$)\`.
   */
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Método auxiliar comum herdado pelas views para imprimir estritamente
   * dados financeiros no formato do Real do Brasil (BRL - "R$ 1.000,00").
   * @param value Referência quantitativa do valor em ponto flutuante.
   */
  public formatCurrency(value: number): string {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  }
}
