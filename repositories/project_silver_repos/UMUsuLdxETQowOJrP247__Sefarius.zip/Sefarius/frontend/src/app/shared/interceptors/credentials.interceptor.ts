import { HttpInterceptorFn, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';

/**
 * Adiciona `withCredentials: true` automaticamente em todo request
 * pra apiBaseUrl. Necessário pra cookies httpOnly de sessão fluírem
 * (ApiService, AuthService, etc.).
 *
 * Sem isso, cada call HTTP precisaria passar `{ withCredentials: true }`
 * manualmente — fácil de esquecer (foi exatamente o bug que o
 * dashboard encontrou: AuthService passava o flag mas ApiService não).
 *
 * Aplicado pelo URL — não pra todo HttpClient call (ex.: chamadas pra
 * CDNs externos NÃO devem mandar credentials).
 */
export const credentialsInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next
): Observable<HttpEvent<unknown>> => {
  if (req.url.startsWith(environment.apiBaseUrl)) {
    return next(req.clone({ withCredentials: true }));
  }
  return next(req);
};
