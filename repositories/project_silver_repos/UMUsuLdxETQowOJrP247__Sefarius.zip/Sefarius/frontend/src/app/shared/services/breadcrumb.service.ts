import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class BreadcrumbService {
  private dynamicLabels = new Map<string, string>();
  dynamicLabels$ = new Subject<void>();

  setLabel(segment: string, label: string) {
    this.dynamicLabels.set(segment, label);
    this.dynamicLabels$.next();
  }

  getLabel(segment: string): string {
    return this.dynamicLabels.get(segment) || segment;
  }
}
