import { Injectable, inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

/**
 * Thin wrapper around MatSnackBar so feature components don't need to
 * know which transport they're using. Sprint Bug Sweep 2 (2026-05-07)
 * introduced this in response to the QA reviewer asking for "toast/
 * notificação de sucesso ou erro no envio (em vez de só uma faixa
 * vermelha estática)".
 *
 * Two methods only — success/error. Anything more nuanced belongs in
 * the existing feedback-banner mechanic on the wizard, which already
 * handles per-step error rendering with markup richer than a snackbar
 * supports.
 */
@Injectable({ providedIn: 'root' })
export class ToastService {
  private snack = inject(MatSnackBar);

  success(message: string, durationMs = 3500): void {
    this.snack.open(message, 'Fechar', {
      duration: durationMs,
      panelClass: ['toast-success'],
      horizontalPosition: 'right',
      verticalPosition: 'top'
    });
  }

  error(message: string, durationMs = 5000): void {
    this.snack.open(message, 'Fechar', {
      duration: durationMs,
      panelClass: ['toast-error'],
      horizontalPosition: 'right',
      verticalPosition: 'top'
    });
  }
}
