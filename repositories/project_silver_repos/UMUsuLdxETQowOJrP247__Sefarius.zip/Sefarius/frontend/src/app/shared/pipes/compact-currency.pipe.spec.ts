import { CompactCurrencyPipe } from './compact-currency.pipe';

describe('CompactCurrencyPipe', () => {
  let pipe: CompactCurrencyPipe;

  beforeEach(() => {
    pipe = new CompactCurrencyPipe();
  });

  // The pipe normalizes NBSP to regular spaces, so tests can compare on
  // plain " " without depending on the local Node.js / ICU build.
  it('formats 0 as "R$ 0,00"', () => {
    expect(pipe.transform(0)).toBe('R$ 0,00');
  });

  it('formats 999.99 as "R$ 999,99" (full BRL, 2 decimals)', () => {
    expect(pipe.transform(999.99)).toBe('R$ 999,99');
  });

  it('formats 1000 as "R$ 1.000,00" (still full BRL under 10 mil)', () => {
    expect(pipe.transform(1000)).toBe('R$ 1.000,00');
  });

  it('formats 9999.99 as "R$ 9.999,99" (just below the 10 mil compact threshold)', () => {
    expect(pipe.transform(9999.99)).toBe('R$ 9.999,99');
  });

  // Bug B4 (2026-05-07): the dashboard "Faturamento" card was truncating
  // values like R$ 50.895,70 to "R$ 50.895,…" because the previous
  // threshold (1 milhão) let 6-digit BRL strings through to a fixed-width
  // .stat-value cell. Lowered to 10 mil so anything wider than
  // "R$ 9.999,99" gets compacted with a "mil" suffix that fits.
  it('formats 50635.70 as "R$ 50,6 mil" (compact mil suffix — B4)', () => {
    expect(pipe.transform(50635.7)).toBe('R$ 50,6 mil');
  });

  it('formats 12000 as "R$ 12,0 mil" (just above the threshold)', () => {
    expect(pipe.transform(12000)).toBe('R$ 12,0 mil');
  });

  it('formats 999999 as "R$ 1.000,0 mil" (just below 1 mi)', () => {
    expect(pipe.transform(999_999)).toBe('R$ 1.000,0 mil');
  });

  it('formats 1.5 milhões as "R$ 1,5 mi" (compact + 1 decimal)', () => {
    expect(pipe.transform(1_500_000)).toBe('R$ 1,5 mi');
  });

  it('formats 1.2 bilhões as "R$ 1,2 bi"', () => {
    expect(pipe.transform(1_200_000_000)).toBe('R$ 1,2 bi');
  });

  it('formats 1.5 trilhões as "R$ 1,5 tri"', () => {
    expect(pipe.transform(1_500_000_000_000)).toBe('R$ 1,5 tri');
  });

  // Defensive branches — not in the original list but lock the
  // behavior so a refactor doesn't accidentally render "NaN" or
  // "undefined" on a partially-loaded dashboard.
  it('returns empty string for null / undefined / NaN', () => {
    expect(pipe.transform(null)).toBe('');
    expect(pipe.transform(undefined)).toBe('');
    expect(pipe.transform(Number.NaN)).toBe('');
  });
});
