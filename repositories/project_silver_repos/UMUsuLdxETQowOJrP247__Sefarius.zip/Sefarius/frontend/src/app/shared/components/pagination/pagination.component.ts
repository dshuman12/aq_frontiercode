import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  computed,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Numerical pagination control. Renders:
 *   « Anterior   1 ... 4 5 [6] 7 8 ... 20   Próxima »
 *   Itens por página: [10|25|50|100]   181–200 de 247
 *
 * Designed to be reused across /products, /invoices, /nfe — every list
 * page that does server-side pagination plugs in the same UX. The
 * parent owns the loading state and reacts to (pageChange) /
 * (pageSizeChange) by re-fetching with the new offset+limit.
 *
 * Inputs are 1-indexed (currentPage starts at 1, not 0) because page
 * NUMBERS as humans read them are 1-indexed; the conversion to offset
 * (0-indexed) lives in the parent so the URL/persistence stays
 * consistent with backend conventions (offset=0 means "first page").
 *
 * Page size selector emits the new size; the parent decides whether
 * to keep the user on the same page (re-clamping if total/newSize
 * pages went down) or to reset to page 1. Default UX: reset to 1 on
 * size change to avoid the "I clicked 50 and now I'm on page 14"
 * confusion that follows from preserving the offset.
 */
@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pagination.component.html',
  styleUrl: './pagination.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaginationComponent {
  // Os 3 inputs precisam de getter+setter (não só setter) porque o
  // template lê `pageSize` e `currentPage` em bindings (`[value]`,
  // `[class.is-active]`). Property com só `set` retorna `undefined` na
  // leitura — o select caía na primeira opção (10) e nenhum botão de
  // página ficava marcado como ativo, em todos os 3 listings.
  @Input({ required: true }) set total(value: number) {
    this._total.set(Math.max(0, value));
  }
  get total(): number {
    return this._total();
  }
  @Input({ required: true }) set pageSize(value: number) {
    this._pageSize.set(Math.max(1, value));
  }
  get pageSize(): number {
    return this._pageSize();
  }
  @Input({ required: true }) set currentPage(value: number) {
    this._currentPage.set(Math.max(1, value));
  }
  get currentPage(): number {
    return this._currentPage();
  }
  /** Page size options shown in the dropdown. Defaults to a typical
   *  set; pages with very long rows can override (e.g. [10, 25, 50]). */
  @Input() pageSizeOptions: readonly number[] = [10, 25, 50, 100];
  /** Optional label override for the entity being paginated (used in
   *  the "X–Y de N items" line). Defaults to "itens". */
  @Input() itemLabel = 'itens';

  @Output() pageChange = new EventEmitter<number>();
  @Output() pageSizeChange = new EventEmitter<number>();

  // Internal signals so the template can reactively recompute the
  // visible page numbers without manual change detection.
  private readonly _total = signal(0);
  private readonly _pageSize = signal(10);
  private readonly _currentPage = signal(1);

  readonly totalPages = computed(() => {
    const total = this._total();
    const size = this._pageSize();
    if (total === 0) {
      return 1;
    }
    return Math.max(1, Math.ceil(total / size));
  });

  /**
   * Window of page numbers to render. Always includes 1 and totalPages.
   * Around the current page we show ±1; gaps are represented by null
   * (template renders "…"). Examples for totalPages=20:
   *   currentPage=1   → [1, 2, 3, null, 20]
   *   currentPage=10  → [1, null, 9, 10, 11, null, 20]
   *   currentPage=20  → [1, null, 18, 19, 20]
   *   totalPages=5    → [1, 2, 3, 4, 5]   (no gaps when small)
   */
  readonly visiblePages = computed<(number | null)[]>(() => {
    const total = this.totalPages();
    const current = this._currentPage();
    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    const pages: (number | null)[] = [1];
    const left = Math.max(2, current - 1);
    const right = Math.min(total - 1, current + 1);
    if (left > 2) {
      pages.push(null);
    }
    for (let i = left; i <= right; i++) {
      pages.push(i);
    }
    if (right < total - 1) {
      pages.push(null);
    }
    pages.push(total);
    return pages;
  });

  /** Range string "X–Y de N itens" for the footer. */
  readonly rangeLabel = computed(() => {
    const total = this._total();
    if (total === 0) {
      return `0 ${this.itemLabel}`;
    }
    const size = this._pageSize();
    const current = this._currentPage();
    const from = (current - 1) * size + 1;
    const to = Math.min(current * size, total);
    return `${from}–${to} de ${total} ${this.itemLabel}`;
  });

  readonly canPrev = computed(() => this._currentPage() > 1);
  readonly canNext = computed(() => this._currentPage() < this.totalPages());

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages() || page === this._currentPage()) {
      return;
    }
    this.pageChange.emit(page);
  }

  prev(): void {
    if (this.canPrev()) {
      this.goToPage(this._currentPage() - 1);
    }
  }

  next(): void {
    if (this.canNext()) {
      this.goToPage(this._currentPage() + 1);
    }
  }

  onPageSizeChange(value: string): void {
    const size = parseInt(value, 10);
    if (!Number.isNaN(size) && size > 0) {
      this.pageSizeChange.emit(size);
    }
  }
}
