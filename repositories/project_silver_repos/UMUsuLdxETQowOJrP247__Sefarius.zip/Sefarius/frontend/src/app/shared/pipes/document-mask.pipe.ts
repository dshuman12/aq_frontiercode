import { Pipe, PipeTransform } from '@angular/core';
import { formatMask, stripDigits } from '../directives/number-mask.directive';

// Pipes pra display de documentos fiscais (CNPJ, CPF, CEP) em telas
// onde o FormControl não tem `appNumberMask` aplicada — tipo a tela
// de revisão do nfe-emit, que mostra os valores armazenados (só
// dígitos) e precisa formatar pra leitura humana.
//
// As 3 reusam `formatMask`/`stripDigits` da NumberMaskDirective —
// invariante: strip → format. Garantia: o pipe é idempotente
// (formato já formatado entra, dígitos saem, formato igual sai).

@Pipe({ name: 'cnpj', standalone: true, pure: true })
export class CnpjPipe implements PipeTransform {
  transform(value: string | null | undefined): string {
    return formatMask(stripDigits(value, 14), 'cnpj');
  }
}

@Pipe({ name: 'cpf', standalone: true, pure: true })
export class CpfPipe implements PipeTransform {
  transform(value: string | null | undefined): string {
    return formatMask(stripDigits(value, 11), 'cpf');
  }
}

@Pipe({ name: 'cep', standalone: true, pure: true })
export class CepPipe implements PipeTransform {
  transform(value: string | null | undefined): string {
    return formatMask(stripDigits(value, 8), 'cep');
  }
}
