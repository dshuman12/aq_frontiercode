import { TestBed } from '@angular/core/testing';
import { BreadcrumbService } from './breadcrumb.service';

describe('BreadcrumbService', () => {
  let service: BreadcrumbService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [BreadcrumbService] });
    service = TestBed.inject(BreadcrumbService);
  });

  it('returns the segment unchanged when no label is registered', () => {
    expect(service.getLabel('any-id')).toBe('any-id');
  });

  it('setLabel registers a label and emits on the dynamicLabels$ subject', () => {
    const observed: number[] = [];
    const sub = service.dynamicLabels$.subscribe(() => observed.push(1));

    service.setLabel('abc-123', 'Cliente XYZ');
    expect(service.getLabel('abc-123')).toBe('Cliente XYZ');
    expect(observed).toHaveLength(1);

    sub.unsubscribe();
  });

  it('setLabel overrides a previously registered label', () => {
    service.setLabel('id', 'first');
    service.setLabel('id', 'second');
    expect(service.getLabel('id')).toBe('second');
  });
});
