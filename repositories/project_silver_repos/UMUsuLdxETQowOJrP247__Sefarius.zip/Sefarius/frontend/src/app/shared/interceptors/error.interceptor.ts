import { HttpInterceptorFn, HttpRequest, HttpEvent } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ErrorService } from '../services/error.service';

export const errorInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next
): Observable<HttpEvent<unknown>> => {
  const errorService = inject(ErrorService);

  return next(req).pipe(
    catchError(error => {
      let errorMessage = 'Erro desconhecido';

      if (error.error instanceof ErrorEvent) {
        // Client-side error
        errorMessage = `Erro: ${error.error.message}`;
      } else {
        // Server-side error
        if (error.status === 0) {
          errorMessage = 'Erro de conexão. Verifique se o servidor está disponível.';
        } else if (error.status === 400) {
          errorMessage = error.error?.error || 'Requisição inválida';
        } else if (error.status === 401) {
          errorMessage = 'Não autorizado';
        } else if (error.status === 404) {
          if (req.url.includes('print-status')) {
            return throwError(() => error);
          }
          errorMessage = 'Recurso não encontrado';
        } else if (error.status === 409) {
          errorMessage = 'Conflito nos dados';
        } else if (error.status === 500) {
          errorMessage = 'Erro interno do servidor';
        } else if (error.status === 503) {
          errorMessage = 'Serviço indisponível. Tente novamente mais tarde.';
        } else {
          errorMessage = `Erro ${error.status}: ${error.error?.error || error.message}`;
        }
      }

      errorService.showError(errorMessage);
      return throwError(() => error);
    })
  );
};
