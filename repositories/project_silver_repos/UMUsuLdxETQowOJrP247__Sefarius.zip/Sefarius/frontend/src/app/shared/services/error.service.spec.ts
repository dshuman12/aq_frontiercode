import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { ErrorService } from './error.service';

describe('ErrorService', () => {
  let service: ErrorService;

  beforeEach(() => {
    jest.useFakeTimers();
    TestBed.configureTestingModule({ providers: [ErrorService] });
    service = TestBed.inject(ErrorService);
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it('starts with null', async () => {
    await expect(firstValueFrom(service.error$)).resolves.toBeNull();
  });

  it('showError emits the message and auto-clears after the default 5s', () => {
    const states: (string | null)[] = [];
    const sub = service.error$.subscribe(v => states.push(v));

    service.showError('boom');
    expect(states).toEqual([null, 'boom']);

    jest.advanceTimersByTime(5000);
    expect(states).toEqual([null, 'boom', null]);
    sub.unsubscribe();
  });

  it('showError respects a custom duration', () => {
    const states: (string | null)[] = [];
    const sub = service.error$.subscribe(v => states.push(v));

    service.showError('boom', 1000);
    jest.advanceTimersByTime(999);
    expect(states[states.length - 1]).toBe('boom');
    jest.advanceTimersByTime(1);
    expect(states[states.length - 1]).toBeNull();
    sub.unsubscribe();
  });

  it('showError(message, 0) does not auto-clear', () => {
    const states: (string | null)[] = [];
    const sub = service.error$.subscribe(v => states.push(v));

    service.showError('persistent', 0);
    jest.advanceTimersByTime(60_000);
    expect(states[states.length - 1]).toBe('persistent');
    sub.unsubscribe();
  });

  it('getError() returns the same observable as error$', () => {
    expect(service.getError()).toBe(service.error$);
  });

  it('clearError() emits null synchronously', () => {
    const states: (string | null)[] = [];
    const sub = service.error$.subscribe(v => states.push(v));

    service.showError('boom', 0);
    service.clearError();
    expect(states).toEqual([null, 'boom', null]);
    sub.unsubscribe();
  });
});
