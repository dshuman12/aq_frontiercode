import { Directive, ElementRef, HostListener, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

export type MaskType = 'cnpj' | 'cpf' | 'cep';

const MAX_DIGITS: Record<MaskType, number> = {
  cnpj: 14,
  cpf: 11,
  cep: 8
};

/**
 * Mantém só dígitos no value (extrai ao digitar) mas limita ao
 * tamanho do tipo. Usado tanto pra writeValue (carregar valor
 * inicial vindo do FormControl) quanto pra processar input do user.
 */
export function stripDigits(value: string | null | undefined, max: number): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.replace(/\D/g, '').slice(0, max);
}

/**
 * Formata uma string de dígitos no padrão da máscara. Resultados
 * parciais são intencionais — o user vê o separador aparecer
 * gradualmente enquanto digita (ex.: "12" → "12", "123" → "12.3",
 * "12345" → "12.345").
 *
 *   cnpj: "12345678901234" → "12.345.678/9012-34"
 *   cpf:  "12345678901"    → "123.456.789-01"
 *   cep:  "12345678"       → "12345-678"
 */
export function formatMask(digits: string, type: MaskType): string {
  if (!digits) {
    return '';
  }
  if (type === 'cnpj') {
    return digits
      .replace(/^(\d{2})(\d)/, '$1.$2')
      .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1/$2')
      .replace(/(\d{4})(\d)/, '$1-$2');
  }
  if (type === 'cpf') {
    return digits
      .replace(/^(\d{3})(\d)/, '$1.$2')
      .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1-$2');
  }
  // cep
  return digits.replace(/^(\d{5})(\d)/, '$1-$2');
}

/**
 * Mascaração progressiva pra inputs de CNPJ/CPF/CEP. O FormControl
 * recebe e armazena APENAS dígitos (ex.: "12345678901234"); o `<input>`
 * mostra o valor formatado (ex.: "12.345.678/9012-34"). Isso preserva
 * os validators existentes (cnpjValidator/cpfValidator/digitsValidator),
 * mantém o payload do backend inalterado (toRequest envia dígitos), e
 * deixa a UX certa pra desktop e mobile.
 *
 * Uso no template:
 *   <input formControlName="cnpj" appNumberMask="cnpj" inputmode="numeric" />
 *
 * Implementa ControlValueAccessor pra interceptar o I/O do FormControl
 * — sem isso, o reactive forms grava no value o que está visível no
 * input (formatado), o que quebraria validators e payload.
 */
@Directive({
  selector: 'input[appNumberMask]',
  standalone: true,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => NumberMaskDirective),
      multi: true
    }
  ]
})
export class NumberMaskDirective implements ControlValueAccessor {
  @Input('appNumberMask') maskType: MaskType = 'cnpj';

  // Substituídas pelos callbacks reais via registerOnChange/Touched
  // assim que o FormControl bind acontece. Iniciam como no-op pra
  // não exigir null-checks no input/blur listeners.
  private onChange: (value: string) => void = () => undefined;
  private onTouched: () => void = () => undefined;

  constructor(private el: ElementRef<HTMLInputElement>) {}

  // Caret position é restaurado de forma simples: sempre ao fim da
  // string formatada. Pra inputs em modo "preencher do começo" — caso
  // de uso normal pra CNPJ/CPF/CEP — isso é o comportamento certo.
  // Edição no meio (raro pra esses campos) cai pro mesmo lugar.
  @HostListener('input')
  onInput(): void {
    const max = MAX_DIGITS[this.maskType];
    const digits = stripDigits(this.el.nativeElement.value, max);
    const formatted = formatMask(digits, this.maskType);
    this.el.nativeElement.value = formatted;
    this.onChange(digits);
  }

  @HostListener('blur')
  onBlur(): void {
    this.onTouched();
  }

  writeValue(value: string | null): void {
    const max = MAX_DIGITS[this.maskType];
    const digits = stripDigits(value ?? '', max);
    this.el.nativeElement.value = formatMask(digits, this.maskType);
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.el.nativeElement.disabled = isDisabled;
  }
}
