/**
 * Constantes globais da aplicação.
 * Utilizado para centralizar "magic strings" e "magic numbers" garantindo
 * tipagem estrita (as const) e proteção contra erros de digitação, além de
 * facilitar refatorações e localização.
 */
export const APP_CONSTANTS = {
  /**
   * Mapeamento de status da Nota Fiscal para validação unificada no front-end.
   * Inclui mapeamento bilingue por retrocompatibilidade e constantes de exibição (DISPLAY).
   */
  INVOICE_STATUS: {
    OPEN: 'open',
    ABERTA: 'aberta',
    CLOSED: 'closed',
    FECHADA: 'fechada',
    CANCELLED: 'cancelled',
    DISPLAY: {
      OPEN: 'Aberta',
      CLOSED: 'Fechada',
      CANCELLED: 'Cancelada'
    }
  },
  /**
   * Status espelho da entidade PrintJob na fila do backend.
   * Usado para travar ou liberar as requisições de polling.
   */
  PRINT_JOB_STATUS: {
    PENDING: 'PENDING',
    PROCESSING: 'PROCESSING',
    COMPLETED: 'COMPLETED',
    FAILED: 'FAILED'
  },
  PAGINATION: {
    DEFAULT_LIMIT: 20,
    MAX_LIMIT: 100
  },
  POLLING: {
    /** Frequência (em ms) de consulta (ping) de serviços assíncronos (ex: Status da Impressão) */
    PRINT_JOB_INTERVAL_MS: 1000,
    /** Desistência máxima de espera para um Job preso na fila (5 minutos) */
    PRINT_JOB_TIMEOUT_MS: 300000
  },
  ROUTES: {
    DASHBOARD: '/dashboard',
    PRODUCTS: '/products',
    INVOICES: '/invoices'
  }
} as const;
