import { TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ConfirmDialogComponent, DialogData } from './confirm-dialog.component';

describe('ConfirmDialogComponent', () => {
  let dialogRefClose: jest.Mock;

  function setup(data: DialogData) {
    dialogRefClose = jest.fn();
    TestBed.configureTestingModule({
      imports: [ConfirmDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: { close: dialogRefClose } },
        { provide: MAT_DIALOG_DATA, useValue: data }
      ]
    });
    return TestBed.createComponent(ConfirmDialogComponent).componentInstance;
  }

  it('fills missing labels with defaults', () => {
    const cmp = setup({ title: 't', message: 'm' });
    expect(cmp.data.confirmLabel).toBe('Confirmar');
    expect(cmp.data.cancelLabel).toBe('Cancelar');
  });

  it('preserves provided labels', () => {
    const cmp = setup({ title: 't', message: 'm', confirmLabel: 'Sim', cancelLabel: 'Não' });
    expect(cmp.data.confirmLabel).toBe('Sim');
    expect(cmp.data.cancelLabel).toBe('Não');
  });

  it('onConfirm closes with true', () => {
    const cmp = setup({ title: 't', message: 'm' });
    cmp.onConfirm();
    expect(dialogRefClose).toHaveBeenCalledWith(true);
  });

  it('onCancel closes with false', () => {
    const cmp = setup({ title: 't', message: 'm' });
    cmp.onCancel();
    expect(dialogRefClose).toHaveBeenCalledWith(false);
  });
});
