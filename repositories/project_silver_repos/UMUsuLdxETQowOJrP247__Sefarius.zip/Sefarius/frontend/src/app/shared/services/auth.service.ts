import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { environment } from '@env/environment';
import { ApiResponse } from '@app/shared/models/api.models';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  activated: boolean;
}

/**
 * AuthService chama o backend Go (auth-service via api-gateway) para
 * todos os fluxos: register/activate/login/logout/reset/profile.
 *
 * Sessão = cookies httpOnly setados pelo backend (sefarius_access +
 * sefarius_refresh). Frontend nunca lê o token — só envia
 * `withCredentials: true` em cada request pra cookies fluírem.
 *
 * Estado local é só `currentUser$` (BehaviorSubject), populado por:
 *   - bootstrap: GET /api/profile na construção do service
 *   - login/activate/confirmReset: respostas que retornam o user
 *   - logout: limpa pra null
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly baseUrl = environment.apiBaseUrl;

  private currentUserSubject = new BehaviorSubject<AuthUser | null>(null);
  public currentUser$: Observable<AuthUser | null> = this.currentUserSubject.asObservable();

  // ready$ vira true após o GET /profile inicial (sucesso OU 401).
  // Guards usam isso pra esperar a checagem de sessão antes de
  // redirecionar — sem isso, navegar direto pra /dashboard
  // sempre cairia no /login mesmo com sessão válida.
  private readySubject = new BehaviorSubject<boolean>(false);
  public ready$: Observable<boolean> = this.readySubject.asObservable();

  constructor(private http: HttpClient) {
    this.bootstrapSession();
  }

  get currentUser(): AuthUser | null {
    return this.currentUserSubject.value;
  }

  isAuthenticated(): boolean {
    return this.currentUserSubject.value !== null;
  }

  // Espera ready$ emitir true. Usado pelo guard.
  whenReady(): Observable<boolean> {
    if (this.readySubject.value) {
      return of(true);
    }
    return new Observable<boolean>(subscriber => {
      const sub = this.readySubject.subscribe(ready => {
        if (ready) {
          subscriber.next(true);
          subscriber.complete();
        }
      });
      return () => sub.unsubscribe();
    });
  }

  register(name: string, email: string, password: string): Observable<AuthUser> {
    return this.http
      .post<
        ApiResponse<AuthUser>
      >(`${this.baseUrl}/auth/register`, { name, email, password }, { withCredentials: true })
      .pipe(
        map(r => this.unwrap(r)),
        catchError(err => this.toError(err))
      );
  }

  activate(token: string): Observable<AuthUser> {
    return this.http
      .get<ApiResponse<AuthUser>>(`${this.baseUrl}/auth/activate/${token}`, {
        withCredentials: true
      })
      .pipe(
        map(r => this.unwrap(r)),
        tap(u => this.currentUserSubject.next(u)),
        catchError(err => this.toError(err))
      );
  }

  login(email: string, password: string): Observable<AuthUser> {
    return this.http
      .post<
        ApiResponse<AuthUser>
      >(`${this.baseUrl}/auth/login`, { email, password }, { withCredentials: true })
      .pipe(
        map(r => this.unwrap(r)),
        tap(u => this.currentUserSubject.next(u)),
        catchError(err => this.toError(err))
      );
  }

  logout(): Observable<void> {
    return this.http
      .post<ApiResponse<unknown>>(`${this.baseUrl}/auth/logout`, {}, { withCredentials: true })
      .pipe(
        tap(() => this.currentUserSubject.next(null)),
        map(() => undefined),
        catchError(() => {
          // Mesmo se logout no backend falhar (rede), limpamos a sessão
          // local — o cookie está httpOnly, mas o usuário esperaria
          // ficar deslogado.
          this.currentUserSubject.next(null);
          return of(undefined);
        })
      );
  }

  requestReset(email: string): Observable<void> {
    return this.http
      .post<
        ApiResponse<unknown>
      >(`${this.baseUrl}/auth/reset-password`, { email }, { withCredentials: true })
      .pipe(
        map(() => undefined),
        catchError(err => this.toError(err))
      );
  }

  confirmReset(token: string, password: string, confirmation: string): Observable<AuthUser> {
    return this.http
      .post<
        ApiResponse<AuthUser>
      >(`${this.baseUrl}/auth/reset-password/${token}`, { password, confirmation }, { withCredentials: true })
      .pipe(
        map(r => this.unwrap(r)),
        tap(u => this.currentUserSubject.next(u)),
        catchError(err => this.toError(err))
      );
  }

  changeName(name: string): Observable<AuthUser> {
    return this.http
      .patch<
        ApiResponse<AuthUser>
      >(`${this.baseUrl}/profile/name`, { name }, { withCredentials: true })
      .pipe(
        map(r => this.unwrap(r)),
        tap(u => this.currentUserSubject.next(u)),
        catchError(err => this.toError(err))
      );
  }

  changePassword(oldPassword: string, newPassword: string, confirmation: string): Observable<void> {
    return this.http
      .patch<
        ApiResponse<unknown>
      >(`${this.baseUrl}/profile/password`, { oldPassword, newPassword, confirmation }, { withCredentials: true })
      .pipe(
        map(() => undefined),
        catchError(err => this.toError(err))
      );
  }

  private bootstrapSession(): void {
    this.http
      .get<ApiResponse<AuthUser>>(`${this.baseUrl}/profile`, { withCredentials: true })
      .subscribe({
        next: resp => {
          this.currentUserSubject.next(resp.data ?? null);
          this.readySubject.next(true);
        },
        error: () => {
          // 401 esperado quando não há sessão. Outros erros (rede, 500)
          // também resolvem o ready$ — caso contrário o app trava em
          // splash screen indefinidamente.
          this.currentUserSubject.next(null);
          this.readySubject.next(true);
        }
      });
  }

  private unwrap<T>(resp: ApiResponse<T>): T {
    if (!resp.success || resp.data === undefined) {
      throw new Error(resp.error || 'Erro desconhecido');
    }
    return resp.data;
  }

  private toError(err: unknown): Observable<never> {
    if (err instanceof HttpErrorResponse) {
      const apiErr = err.error as ApiResponse<unknown> | undefined;
      const message = apiErr?.error || err.message || 'Erro de conexão';
      return throwError(() => new Error(message));
    }
    if (err instanceof Error) {
      return throwError(() => err);
    }
    return throwError(() => new Error('Erro desconhecido'));
  }
}
