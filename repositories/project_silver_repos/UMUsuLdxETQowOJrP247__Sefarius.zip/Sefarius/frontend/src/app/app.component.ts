import {
  Component,
  ChangeDetectionStrategy,
  signal,
  OnInit,
  OnDestroy,
  HostListener,
  effect
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ActivatedRoute,
  RouterModule,
  RouterLinkActive,
  RouterLink,
  Router,
  NavigationEnd
} from '@angular/router';
import { LoadingService } from './shared/services/loading.service';
import { ErrorService } from './shared/services/error.service';
import { BreadcrumbService } from './shared/services/breadcrumb.service';
import { AuthService, AuthUser } from './shared/services/auth.service';
import { Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

interface Breadcrumb {
  label: string;
  url: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterLinkActive, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnDestroy {
  loading$: Observable<boolean>;
  error$: Observable<string | null>;
  sidebarOpen = signal(false);
  breadcrumbs = signal<Breadcrumb[]>([]);
  isAuthLayout = signal(false);
  userMenuOpen = signal(false);
  currentUser = signal<AuthUser | null>(null);
  private routerSub!: Subscription;
  private breadcrumbSub!: Subscription;
  private authSub!: Subscription;

  constructor(
    private loadingService: LoadingService,
    private errorService: ErrorService,
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private authService: AuthService
  ) {
    this.loading$ = this.loadingService.loading$;
    this.error$ = this.errorService.error$;

    // Sprint Responsive Sweep: lock body scroll when the mobile sidebar
    // is open. Without this, scrolling inside the overlay drags the
    // page underneath, which feels broken on iOS Safari especially.
    // The effect runs in the constructor's injection context and
    // cleans up itself when the component dies.
    effect(() => {
      const open = this.sidebarOpen();
      if (typeof document !== 'undefined' && document.body) {
        document.body.style.overflow = open ? 'hidden' : '';
      }
    });
  }

  // Esc anywhere closes the mobile sidebar. Listener is on document
  // because individual sidebar children would intercept the event.
  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.sidebarOpen()) {
      this.closeSidebar();
    }
    if (this.userMenuOpen()) {
      this.userMenuOpen.set(false);
    }
  }

  ngOnInit(): void {
    this.updateBreadcrumbs(this.router.url);
    this.updateLayoutFlag();
    this.routerSub = this.router.events
      .pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe(event => {
        this.updateBreadcrumbs(event.urlAfterRedirects || event.url);
        this.updateLayoutFlag();
        this.userMenuOpen.set(false);
      });

    this.breadcrumbSub = this.breadcrumbService.dynamicLabels$.subscribe(() => {
      this.updateBreadcrumbs(this.router.url);
    });

    this.authSub = this.authService.currentUser$.subscribe(u => this.currentUser.set(u));
  }

  ngOnDestroy(): void {
    if (this.routerSub) {
      this.routerSub.unsubscribe();
    }
    if (this.breadcrumbSub) {
      this.breadcrumbSub.unsubscribe();
    }
    if (this.authSub) {
      this.authSub.unsubscribe();
    }
  }

  toggleSidebar(): void {
    this.sidebarOpen.update(v => !v);
  }

  closeSidebar(): void {
    this.sidebarOpen.set(false);
  }

  toggleUserMenu(): void {
    this.userMenuOpen.update(v => !v);
  }

  logout(): void {
    this.userMenuOpen.set(false);
    this.authService.logout().subscribe({
      complete: () => this.router.navigate(['/login'])
    });
  }

  initial(): string {
    return this.currentUser()?.name?.charAt(0)?.toUpperCase() || 'U';
  }

  dismissError(): void {
    this.errorService.clearError();
  }

  // Walk down the active route's children to find the deepest data
  // payload — that's where the matched lazy-loaded route lives. The
  // root snapshot has no data of its own.
  private updateLayoutFlag(): void {
    let current = this.route.snapshot;
    while (current.firstChild) {
      current = current.firstChild;
    }
    const isAuth = current.data?.['layout'] === 'auth';
    this.isAuthLayout.set(isAuth);
  }

  private updateBreadcrumbs(url: string): void {
    const urlSegments = url
      .split('?')[0]
      .split('/')
      .filter(s => s);
    const crumbs: Breadcrumb[] = [{ label: 'Home', url: '/dashboard' }];

    let currentUrl = '';
    for (const segment of urlSegments) {
      if (segment === 'dashboard') {
        continue;
      }
      currentUrl += `/${segment}`;

      let label = segment;
      if (segment === 'products') {
        label = 'Produtos';
      } else if (segment === 'invoices') {
        label = 'Notas';
      } else if (segment === 'nfe') {
        label = 'NF-e';
      } else if (segment === 'profile') {
        label = 'Perfil';
      } else {
        label = this.breadcrumbService.getLabel(segment);
      }

      crumbs.push({ label, url: currentUrl });
    }

    this.breadcrumbs.set(crumbs);
  }
}
