import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { DashboardComponent } from './dashboard.component';
import { Invoice, Product } from '@app/shared/models/api.models';

// Fiscal-field defaults match migration 006 / backend defaults so a
// fixture Product has the same wire shape as one fetched live.
const fiscalDefaults = {
  ncm: null,
  valor_unitario: null,
  cfop_padrao_saida: '5102',
  u_com: 'UN',
  origem: '0',
  cst_icms: '00',
  p_icms: 18,
  cst_pis: '49',
  cst_cofins: '49'
};

const products: Product[] = [
  {
    id: 'p1',
    code: 'P-01',
    description: 'a',
    balance: 4,
    version: 1,
    ...fiscalDefaults,
    created_at: '',
    updated_at: ''
  },
  {
    id: 'p2',
    code: 'P-02',
    description: 'b',
    balance: 6,
    version: 1,
    ...fiscalDefaults,
    created_at: '',
    updated_at: ''
  }
];

const baseInvoice: Invoice = {
  id: 'i1',
  number: 1,
  status: 'OPEN',
  idempotency_key: 'k',
  created_by: 'me',
  items: [],
  total_amount: 100,
  created_at: '2026-05-06T10:00:00Z'
};

function makeInvoices(): Invoice[] {
  // The DashboardComponent normalizes status case-insensitively; we keep
  // the typed InvoiceStatus union but the component also accepts 'aberta'
  // / 'fechada' from older payloads. Cast through unknown to exercise that
  // tolerance branch.
  return [
    { ...baseInvoice, id: 'i1', number: 1, status: 'OPEN', total_amount: 100 },
    { ...baseInvoice, id: 'i2', number: 2, status: 'CLOSED', total_amount: 250 },
    {
      ...baseInvoice,
      id: 'i3',
      number: 3,
      status: 'aberta' as unknown as Invoice['status'],
      total_amount: 50
    },
    {
      ...baseInvoice,
      id: 'i4',
      number: 4,
      status: 'fechada' as unknown as Invoice['status'],
      total_amount: 200
    },
    { ...baseInvoice, id: 'i5', number: 5, status: 'OPEN', total_amount: 75 }
  ];
}

describe('DashboardComponent', () => {
  let fixture: ComponentFixture<DashboardComponent>;
  let component: DashboardComponent;
  let apiMock: { getProducts: jest.Mock; getInvoices: jest.Mock; listNFe: jest.Mock };

  function build() {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  }

  beforeEach(async () => {
    apiMock = {
      getProducts: jest.fn(),
      getInvoices: jest.fn(),
      // Bug Sweep 2: dashboard now also requests NFe on load. Default
      // returns empty so existing tests don't have to seed NFe data.
      listNFe: jest
        .fn()
        .mockReturnValue(
          of({ success: true, data: { items: [], total: 0, limit: 50, offset: 0 }, code: 200 })
        )
    };
    await TestBed.configureTestingModule({
      imports: [DashboardComponent, NoopAnimationsModule],
      providers: [
        { provide: ApiService, useValue: apiMock },
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();
  });

  it('starts with loading=true and zero counters', () => {
    apiMock.getProducts.mockReturnValue(
      of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
    );
    apiMock.getInvoices.mockReturnValue(
      of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
    );
    build();
    expect(component.loading).toBe(true);
    expect(component.productsCount).toBe(0);
    // Bug Sweep 2.1: totalRevenue → faturamento, type number, formatted
    // by the compactCurrency pipe in the template.
    expect(component.faturamento).toBe(0);
  });

  it('aggregates counts, total stock, revenue, open invoices and recentNotes after load', () => {
    apiMock.getProducts.mockReturnValue(
      of({ success: true, data: { items: products, total: 2, limit: 100, offset: 0 }, code: 200 })
    );
    apiMock.getInvoices.mockReturnValue(
      of({
        success: true,
        data: { items: makeInvoices(), total: 5, limit: 100, offset: 0 },
        code: 200
      })
    );

    build();
    fixture.detectChanges();

    expect(component.productsCount).toBe(2);
    expect(component.totalStock).toBe(10);
    expect(component.invoicesCount).toBe(5);
    expect(component.openInvoicesCount).toBe(3); // OPEN, OPEN, aberta
    expect(component.faturamento).toBe(675); // 100 + 250 + 50 + 200 + 75
    expect(component.recentNotes).toHaveLength(4); // first 4 only
    expect(component.recentNotes[0]).toMatchObject({
      number: '#1',
      status: 'Aberta'
    });
    expect(component.loading).toBe(false);
  });

  it('caps recentNotes at 4 entries even when more invoices exist', () => {
    const many = Array.from({ length: 10 }, (_, i) => ({
      ...baseInvoice,
      id: `i${i}`,
      number: i + 1
    }));
    apiMock.getProducts.mockReturnValue(
      of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
    );
    apiMock.getInvoices.mockReturnValue(
      of({
        success: true,
        data: { items: many, total: 10, limit: 100, offset: 0 },
        code: 200
      })
    );

    build();
    fixture.detectChanges();

    expect(component.recentNotes).toHaveLength(4);
  });

  it('keeps loading=false on error so the spinner does not hang', () => {
    apiMock.getProducts.mockReturnValue(throwError(() => ({ status: 500, message: 'fail' })));
    apiMock.getInvoices.mockReturnValue(throwError(() => ({ status: 500, message: 'fail' })));
    build();
    fixture.detectChanges();
    expect(component.loading).toBe(false);
  });

  describe('Bug Sweep 2 (2026-05-07) — NFe stats + recent NFe', () => {
    it('aggregates NFe lifecycle counts', () => {
      apiMock.getProducts.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.getInvoices.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.listNFe.mockReturnValue(
        of({
          success: true,
          data: {
            items: [
              {
                chave: 'A',
                lifecycle: 'AUTHORIZED',
                c_stat: '100',
                x_motivo: '',
                created_at: '2026-05-06',
                updated_at: ''
              },
              {
                chave: 'B',
                lifecycle: 'AUTHORIZED',
                c_stat: '100',
                x_motivo: '',
                created_at: '2026-05-06',
                updated_at: ''
              },
              {
                chave: 'C',
                lifecycle: 'CANCELLED',
                c_stat: '101',
                x_motivo: '',
                created_at: '2026-05-06',
                updated_at: ''
              },
              {
                chave: 'D',
                lifecycle: 'REJECTED',
                c_stat: '539',
                x_motivo: '',
                created_at: '2026-05-06',
                updated_at: ''
              }
            ],
            total: 4,
            limit: 50,
            offset: 0
          },
          code: 200
        })
      );
      build();
      fixture.detectChanges();
      expect(component.nfeCount).toBe(4);
      expect(component.nfeAuthorizedCount).toBe(2);
      expect(component.nfeCancelledCount).toBe(1);
      expect(component.nfeRejectedCount).toBe(1);
    });

    it('caps recentNFe at 5 entries and shortens chave for display', () => {
      const long = '4324050000000000000000000010000000004200000000';
      apiMock.getProducts.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.getInvoices.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.listNFe.mockReturnValue(
        of({
          success: true,
          data: {
            items: Array.from({ length: 8 }, (_, i) => ({
              chave: long.slice(0, -2) + String(i).padStart(2, '0'),
              lifecycle: 'AUTHORIZED' as const,
              c_stat: '100',
              x_motivo: '',
              created_at: '2026-05-06T10:00:00Z',
              updated_at: ''
            })),
            total: 8,
            limit: 50,
            offset: 0
          },
          code: 200
        })
      );
      build();
      fixture.detectChanges();
      expect(component.recentNFe).toHaveLength(5);
      // Chave is shortened to first8…last8 (17 chars total).
      expect(component.recentNFe[0].chaveShort.length).toBeLessThan(long.length);
      expect(component.recentNFe[0].chaveShort).toContain('…');
    });

    it('keeps the dashboard usable when listNFe errors out', () => {
      apiMock.getProducts.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.getInvoices.mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
      );
      apiMock.listNFe.mockReturnValue(throwError(() => ({ status: 502 })));
      build();
      fixture.detectChanges();
      expect(component.loading).toBe(false);
      expect(component.nfeCount).toBe(0);
      expect(component.recentNFe).toEqual([]);
    });
  });

  it('formats invoice currency in pt-BR', () => {
    apiMock.getProducts.mockReturnValue(
      of({ success: true, data: { items: [], total: 0, limit: 100, offset: 0 }, code: 200 })
    );
    apiMock.getInvoices.mockReturnValue(
      of({
        success: true,
        data: {
          items: [{ ...baseInvoice, total_amount: 1234.56 }],
          total: 1,
          limit: 100,
          offset: 0
        },
        code: 200
      })
    );

    build();
    fixture.detectChanges();
    expect(component.recentNotes[0].value).toMatch(/1\.234,56/);
  });
});
