import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '@app/shared/services/auth.service';
import { AuthShellComponent } from '../auth-shell/auth-shell.component';

interface PasswordRule {
  label: string;
  test: (p: string) => boolean;
}

@Component({
  selector: 'app-reset-confirm',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, AuthShellComponent],
  templateUrl: './reset-confirm.component.html',
  styleUrls: ['./reset-confirm.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ResetConfirmComponent implements OnInit {
  password = '';
  confirmation = '';
  token = signal<string | null>(null);
  success = signal(false);
  serverError = signal('');
  isSubmitting = signal(false);
  showPassword = signal(false);
  showConfirmation = signal(false);

  readonly passwordRules: PasswordRule[] = [
    { label: '8+ caracteres', test: p => p.length >= 8 },
    { label: '1 maiúscula', test: p => /[A-Z]/.test(p) },
    { label: '1 minúscula', test: p => /[a-z]/.test(p) },
    { label: '1 número', test: p => /\d/.test(p) }
  ];

  constructor(
    private auth: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.token.set(this.route.snapshot.paramMap.get('token'));
  }

  ruleMet(rule: PasswordRule): boolean {
    return rule.test(this.password);
  }

  togglePassword(): void {
    this.showPassword.update(v => !v);
  }

  toggleConfirmation(): void {
    this.showConfirmation.update(v => !v);
  }

  submit(): void {
    const tokenValue = this.token();
    if (!tokenValue) {
      this.serverError.set('Link inválido.');
      return;
    }
    if (this.password !== this.confirmation) {
      this.serverError.set('As senhas não coincidem.');
      return;
    }
    this.serverError.set('');
    this.isSubmitting.set(true);
    this.auth.confirmReset(tokenValue, this.password, this.confirmation).subscribe({
      next: () => {
        // confirmReset() já abriu a sessão; vamos direto pra área
        // logada (mesma estratégia do activate). Evita o trap de
        // re-digitar credenciais que acabaram de ser definidas.
        this.success.set(true);
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
        setTimeout(() => this.router.navigate(['/dashboard']), 1600);
      },
      error: err => {
        this.serverError.set(err?.message || 'Link inválido ou expirado.');
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
      }
    });
  }
}
