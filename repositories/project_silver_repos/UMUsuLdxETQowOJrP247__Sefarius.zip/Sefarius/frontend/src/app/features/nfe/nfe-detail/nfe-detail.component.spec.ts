import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { NFeDetailComponent, prettyPrintXml } from './nfe-detail.component';
import { EventResponse, NFeRecord } from '@app/shared/models/nfe.models';

const CHAVE = '52260101010101000100550010000000011000000011';

const baseRecord: NFeRecord = {
  chave: CHAVE,
  lifecycle: 'AUTHORIZED',
  c_stat: '100',
  x_motivo: 'Autorizado o uso da NF-e'
};

interface ApiMock {
  getNFe: jest.Mock;
  getCancel: jest.Mock;
  listCCe: jest.Mock;
  cancelNFe: jest.Mock;
  sendCCe: jest.Mock;
  nfeXMLUrl: jest.Mock;
  nfeDanfeUrl: jest.Mock;
  cancelXMLUrl: jest.Mock;
  cancelPDFUrl: jest.Mock;
  cceXMLUrl: jest.Mock;
  ccePDFUrl: jest.Mock;
}

function makeApiMock(): ApiMock {
  return {
    getNFe: jest.fn().mockReturnValue(of({ success: true, data: baseRecord, code: 200 })),
    // The backend returns 404 from GET /:chave/cancel when no cancel
    // event is registered (the normal state for an AUTHORIZED NFe).
    // Mocking it as a 200 here would not reflect production and was the
    // exact reason the forkJoin error-swallow bug shipped without test
    // coverage — every spec ran against an unrealistic mock where
    // getCancel "always succeeds".
    getCancel: jest.fn().mockReturnValue(throwError(() => ({ status: 404 }))),
    listCCe: jest.fn().mockReturnValue(of({ success: true, data: [], code: 200 })),
    cancelNFe: jest.fn(),
    sendCCe: jest.fn(),
    nfeXMLUrl: jest.fn().mockReturnValue('http://x/xml'),
    nfeDanfeUrl: jest.fn().mockReturnValue('http://x/danfe'),
    cancelXMLUrl: jest.fn().mockReturnValue('http://x/cancel/xml'),
    cancelPDFUrl: jest.fn().mockReturnValue('http://x/cancel/pdf'),
    cceXMLUrl: jest.fn().mockReturnValue('http://x/cce/xml'),
    ccePDFUrl: jest.fn().mockReturnValue('http://x/cce/pdf')
  };
}

function buildModule(opts: { api: ApiMock; dialogOpen?: jest.Mock; paramMapGet?: jest.Mock }) {
  const dialog = { open: opts.dialogOpen ?? jest.fn() };
  const route = {
    snapshot: { paramMap: { get: opts.paramMapGet ?? jest.fn().mockReturnValue(CHAVE) } }
  };
  TestBed.resetTestingModule();
  TestBed.configureTestingModule({
    imports: [NFeDetailComponent, NoopAnimationsModule],
    providers: [
      provideRouter([]),
      provideHttpClient(),
      provideHttpClientTesting(),
      { provide: ApiService, useValue: opts.api },
      { provide: MatDialog, useValue: dialog },
      // ActivatedRoute must come AFTER provideRouter() so the mock wins
      // over the router's own ActivatedRoute provider.
      { provide: ActivatedRoute, useValue: route }
    ]
  });
  return { dialog, route };
}

describe('NFeDetailComponent', () => {
  let fixture: ComponentFixture<NFeDetailComponent>;
  let api: ApiMock;
  let dialog: { open: jest.Mock };

  beforeEach(() => {
    api = makeApiMock();
    const built = buildModule({ api });
    dialog = built.dialog;
    fixture = TestBed.createComponent(NFeDetailComponent);
  });

  afterEach(() => {
    if (fixture) {
      fixture.destroy();
    }
  });

  describe('Initial load', () => {
    it('reads chave from the route, sets danfe url, and loads record + events on init', () => {
      fixture.detectChanges();

      expect(fixture.componentInstance.chave).toBe(CHAVE);
      expect(fixture.componentInstance.record).toEqual(baseRecord);
      expect(fixture.componentInstance.loading).toBe(false);
      expect(api.getNFe).toHaveBeenCalledWith(CHAVE);
      expect(api.getCancel).toHaveBeenCalledWith(CHAVE);
      expect(api.listCCe).toHaveBeenCalledWith(CHAVE);
      expect(fixture.componentInstance.danfeUrl).not.toBeNull();
    });

    it('renders a 404-specific error message when getNFe returns 404', () => {
      api.getNFe.mockReturnValueOnce(throwError(() => ({ status: 404 })));
      fixture.detectChanges();
      expect(fixture.componentInstance.errorMsg).toBe('NF-e não encontrada');
      expect(fixture.componentInstance.record).toBeNull();
      expect(fixture.componentInstance.loading).toBe(false);
    });

    it('falls back to a generic error message for non-404 failures', () => {
      api.getNFe.mockReturnValueOnce(throwError(() => ({ status: 500, message: 'srv off' })));
      fixture.detectChanges();
      expect(fixture.componentInstance.errorMsg).toBe('srv off');
    });

    it('sets errorMsg when chave is missing from the route', () => {
      api = makeApiMock();
      buildModule({ api, paramMapGet: jest.fn().mockReturnValue(null) });
      fixture = TestBed.createComponent(NFeDetailComponent);
      fixture.detectChanges();
      expect(fixture.componentInstance.errorMsg).toBe('Chave não informada');
    });
  });

  describe('Action gating', () => {
    it('canCancel and canSendCCe are true on AUTHORIZED with no existing cancel', () => {
      fixture.detectChanges();
      expect(fixture.componentInstance.canCancel).toBe(true);
      expect(fixture.componentInstance.canSendCCe).toBe(true);
    });

    it('canCancel becomes false after a cancel event is loaded', () => {
      const cancelEvent: EventResponse = {
        chave: CHAVE,
        event_type: 'CANCEL',
        seq: 1,
        status: 'ACCEPTED',
        c_stat: '135',
        x_motivo: 'Cancelamento aceito'
      };
      api.getCancel.mockReturnValueOnce(of({ success: true, data: cancelEvent, code: 200 }));
      fixture.detectChanges();
      expect(fixture.componentInstance.canCancel).toBe(false);
    });

    it('canCancel and canSendCCe are false when lifecycle is REJECTED', () => {
      api.getNFe.mockReturnValueOnce(
        of({
          success: true,
          data: { ...baseRecord, lifecycle: 'REJECTED' as const },
          code: 200
        })
      );
      fixture.detectChanges();
      expect(fixture.componentInstance.canCancel).toBe(false);
      expect(fixture.componentInstance.canSendCCe).toBe(false);
    });
  });

  describe('loadEvents resilience (regression for forkJoin error swallow)', () => {
    it('still populates cceList when getCancel errors with 404 — the normal AUTHORIZED + no-cancel state', () => {
      // Default mock already throws 404 from getCancel. listCCe returns
      // a populated list. Before the catchError fix, forkJoin would
      // abort on the 404 and cceList would stay [] even though listCCe
      // succeeded — exactly the user-reported bug.
      const cce: EventResponse = {
        chave: CHAVE,
        event_type: 'CCE',
        seq: 1,
        status: 'ACCEPTED',
        c_stat: '135',
        x_motivo: 'Evento registrado e vinculado a NF-e'
      };
      api.listCCe.mockReturnValueOnce(of({ success: true, data: [cce], code: 200 }));

      fixture.detectChanges();

      expect(fixture.componentInstance.cancel).toBeNull();
      expect(fixture.componentInstance.cceList).toEqual([cce]);
    });

    it('keeps cancel populated when getCancel returns 200 with data (existing cancel)', () => {
      const cancelEvt: EventResponse = {
        chave: CHAVE,
        event_type: 'CANCEL',
        seq: 1,
        status: 'ACCEPTED',
        c_stat: '135',
        x_motivo: 'Cancelamento homologado'
      };
      api.getCancel.mockReturnValueOnce(of({ success: true, data: cancelEvt, code: 200 }));
      api.listCCe.mockReturnValueOnce(of({ success: true, data: [], code: 200 }));

      fixture.detectChanges();

      expect(fixture.componentInstance.cancel).toEqual(cancelEvt);
      expect(fixture.componentInstance.cceList).toEqual([]);
    });

    it('keeps cceList empty (not undefined) when listCCe itself errors', () => {
      api.listCCe.mockReturnValueOnce(throwError(() => ({ status: 500 })));
      fixture.detectChanges();
      expect(fixture.componentInstance.cceList).toEqual([]);
    });
  });

  describe('nextCCeSeq', () => {
    it('returns 1 when no CCe exists', () => {
      fixture.detectChanges();
      expect(fixture.componentInstance.nextCCeSeq).toBe(1);
    });

    it('returns max(seq) + 1 from loaded CCe events', () => {
      api.listCCe.mockReturnValueOnce(
        of({
          success: true,
          data: [
            {
              chave: CHAVE,
              event_type: 'CCE',
              seq: 1,
              status: 'ACCEPTED',
              c_stat: '135',
              x_motivo: ''
            },
            {
              chave: CHAVE,
              event_type: 'CCE',
              seq: 3,
              status: 'ACCEPTED',
              c_stat: '135',
              x_motivo: ''
            }
          ] as EventResponse[],
          code: 200
        })
      );
      fixture.detectChanges();
      expect(fixture.componentInstance.nextCCeSeq).toBe(4);
    });
  });

  describe('Cancel submit', () => {
    it('on ACCEPTED outcome stores success feedback and reloads the record', () => {
      api.cancelNFe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: CHAVE,
            event_type: 'CANCEL',
            seq: 1,
            status: 'ACCEPTED',
            c_stat: '135',
            x_motivo: 'Cancelamento homologado'
          } as EventResponse,
          code: 201
        })
      );
      fixture.detectChanges();
      api.getNFe.mockClear();

      dialog.open.mockReturnValueOnce({
        afterClosed: () => of({ justification: 'razão válida com mais de 15 chars' })
      });
      fixture.componentInstance.openCancelDialog();

      expect(api.cancelNFe).toHaveBeenCalledWith(CHAVE, {
        justification: 'razão válida com mais de 15 chars'
      });
      expect(fixture.componentInstance.feedback).toEqual({
        kind: 'success',
        text: expect.stringContaining('Cancelamento aceito')
      });
      expect(api.getNFe).toHaveBeenCalled();
    });

    it('on REJECTED outcome shows error feedback with the SEFAZ hint', () => {
      api.cancelNFe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: CHAVE,
            event_type: 'CANCEL',
            seq: 1,
            status: 'REJECTED',
            c_stat: '218',
            x_motivo: 'NF-e já cancelada'
          } as EventResponse,
          code: 200
        })
      );
      fixture.detectChanges();

      dialog.open.mockReturnValueOnce({
        afterClosed: () => of({ justification: 'razão válida bem longa' })
      });
      fixture.componentInstance.openCancelDialog();

      expect(fixture.componentInstance.feedback?.kind).toBe('error');
      expect(fixture.componentInstance.feedback?.text).toContain('218');
      expect(fixture.componentInstance.feedback?.text).toContain('NF-e já cancelada');
    });

    it('502 from the API surfaces "SEFAZ indisponível"', () => {
      api.cancelNFe.mockReturnValue(throwError(() => ({ status: 502 })));
      fixture.detectChanges();

      dialog.open.mockReturnValueOnce({
        afterClosed: () => of({ justification: 'razão válida bem longa' })
      });
      fixture.componentInstance.openCancelDialog();

      expect(fixture.componentInstance.feedback).toEqual({
        kind: 'error',
        text: expect.stringContaining('SEFAZ indisponível')
      });
    });

    it('does nothing when the dialog is dismissed', () => {
      fixture.detectChanges();
      dialog.open.mockReturnValueOnce({ afterClosed: () => of(null) });
      fixture.componentInstance.openCancelDialog();
      expect(api.cancelNFe).not.toHaveBeenCalled();
    });
  });

  describe('CCe submit', () => {
    it('on ACCEPTED reloads only events, not the record', () => {
      api.sendCCe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: CHAVE,
            event_type: 'CCE',
            seq: 1,
            status: 'ACCEPTED',
            c_stat: '135',
            x_motivo: 'CCe homologada'
          } as EventResponse,
          code: 201
        })
      );
      fixture.detectChanges();
      api.getNFe.mockClear();
      api.listCCe.mockClear();

      dialog.open.mockReturnValueOnce({
        afterClosed: () =>
          of({ correction: 'Correção válida com pelo menos 15 chars de texto', seq: 1 })
      });
      fixture.componentInstance.openCCeDialog();

      expect(api.sendCCe).toHaveBeenCalled();
      expect(fixture.componentInstance.feedback?.kind).toBe('success');
      expect(api.getNFe).not.toHaveBeenCalled();
      expect(api.listCCe).toHaveBeenCalled();
    });
  });

  describe('Feedback dismiss', () => {
    it('clears the banner', () => {
      fixture.detectChanges();
      fixture.componentInstance.feedback = { kind: 'success', text: 'ok' };
      fixture.componentInstance.dismissFeedback();
      expect(fixture.componentInstance.feedback).toBeNull();
    });
  });

  describe('XML lazy load', () => {
    it('onTabChange(1) issues an HTTP GET to fetch the XML', () => {
      fixture.detectChanges();
      const httpMock = TestBed.inject(HttpTestingController);
      fixture.componentInstance.onTabChange(1);
      const req = httpMock.expectOne('http://x/xml');
      expect(req.request.responseType).toBe('text');
      req.flush('<NFe>…</NFe>');
      expect(fixture.componentInstance.xml).toBe('<NFe>…</NFe>');
      expect(fixture.componentInstance.xmlLoading).toBe(false);
      httpMock.verify();
    });

    it('onTabChange(0) does not trigger XML loading', () => {
      fixture.detectChanges();
      const httpMock = TestBed.inject(HttpTestingController);
      fixture.componentInstance.onTabChange(0);
      httpMock.expectNone('http://x/xml');
    });

    it('does not refetch XML once loaded', () => {
      fixture.detectChanges();
      const httpMock = TestBed.inject(HttpTestingController);
      fixture.componentInstance.onTabChange(1);
      httpMock.expectOne('http://x/xml').flush('<x/>');
      fixture.componentInstance.onTabChange(1);
      httpMock.expectNone('http://x/xml');
      httpMock.verify();
    });

    it('pretty-prints the fetched XML so leaf elements line up under their parents', () => {
      fixture.detectChanges();
      const httpMock = TestBed.inject(HttpTestingController);
      fixture.componentInstance.onTabChange(1);
      // Single-line input, the shape Go's encoding/xml emits.
      httpMock
        .expectOne('http://x/xml')
        .flush('<NFe><infNFe Id="X"><emit><CNPJ>1</CNPJ></emit></infNFe></NFe>');
      const xml = fixture.componentInstance.xml;
      // Each element on its own line, indented by depth.
      expect(xml).toBe(
        '<NFe>\n  <infNFe Id="X">\n    <emit>\n      <CNPJ>1</CNPJ>\n    </emit>\n  </infNFe>\n</NFe>'
      );
      // Negative assertion: the previous behavior — dumping the raw
      // single-line text into the <pre> — must not regress.
      expect(xml).not.toContain('><');
    });
  });

  describe('prettyPrintXml helper', () => {
    it('preserves leaf text nodes without forcing a line break inside', () => {
      expect(prettyPrintXml('<UF>RS</UF>')).toBe('<UF>RS</UF>');
    });

    it('handles self-closing tags without changing depth', () => {
      expect(prettyPrintXml('<a><b/><c/></a>')).toBe('<a>\n  <b/>\n  <c/>\n</a>');
    });

    it('keeps the xml declaration outside the depth tracker', () => {
      expect(prettyPrintXml('<?xml version="1.0"?><root><x>1</x></root>')).toBe(
        '<?xml version="1.0"?>\n<root>\n  <x>1</x>\n</root>'
      );
    });
  });

  describe('Helpers', () => {
    beforeEach(() => fixture.detectChanges());

    it('lifecycleLabel handles undefined and known values', () => {
      const c = fixture.componentInstance;
      expect(c.lifecycleLabel(undefined)).toBe('—');
      expect(c.lifecycleLabel('AUTHORIZED')).toBe('Autorizada');
    });

    it('lifecycleClass returns empty for undefined', () => {
      expect(fixture.componentInstance.lifecycleClass(undefined)).toBe('');
    });

    it('formatDate handles undefined and invalid dates', () => {
      const c = fixture.componentInstance;
      expect(c.formatDate(undefined)).toBe('');
      expect(c.formatDate('not-a-date')).toBe('not-a-date');
    });

    it('URL helpers proxy to ApiService', () => {
      const c = fixture.componentInstance;
      expect(c.danfeRawUrl()).toBe('http://x/danfe');
      expect(c.xmlRawUrl()).toBe('http://x/xml');
      expect(c.cancelPDFUrl()).toBe('http://x/cancel/pdf');
      expect(c.cancelXMLUrl()).toBe('http://x/cancel/xml');
      expect(c.ccePDFUrl(2)).toBe('http://x/cce/pdf');
      expect(c.cceXMLUrl(2)).toBe('http://x/cce/xml');
    });
  });

  describe('loadEvents tolerance', () => {
    it('swallows errors silently — record stays loaded even if /cancel fails', () => {
      api.getCancel.mockReturnValueOnce(throwError(() => new Error('404 normal')));
      fixture.detectChanges();
      expect(fixture.componentInstance.record).toEqual(baseRecord);
      expect(fixture.componentInstance.errorMsg).toBeNull();
    });
  });
});
