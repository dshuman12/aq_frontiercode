import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';
import { readFileSync } from 'fs';
import { join } from 'path';

import { ApiService } from '@app/shared/services/api.service';
import { DialogService } from '@app/shared/services/dialog.service';
import { ToastService } from '@app/shared/services/toast.service';
import { Product } from '@app/shared/models/api.models';
import { ProductsComponent } from './products.component';

// Fiscal-field defaults shared by all sample fixtures — match the
// backend's migration 006 defaults so a Product fetched in tests has
// the same shape as one fetched live.
const fiscalDefaults = {
  cfop_padrao_saida: '5102',
  u_com: 'UN',
  origem: '0',
  cst_icms: '00',
  p_icms: 18,
  cst_pis: '49',
  cst_cofins: '49'
};

// Fixture reflects post-bug-#5 reality: NCM and valor_unitario are
// REQUIRED at the form layer, so any product the user is allowed to
// save will have them. Legacy products without these fields exist in
// the DB but cannot be edited until completed (covered by a dedicated
// "legacy product" test below).
const sampleProducts: Product[] = [
  {
    id: 'p1',
    code: 'P-01',
    description: 'Cabo HDMI 2m',
    balance: 10,
    version: 1,
    ncm: '85444290',
    valor_unitario: 25.5,
    ...fiscalDefaults,
    created_at: '2026-05-01T10:00:00Z',
    updated_at: '2026-05-01T10:00:00Z'
  },
  {
    id: 'p2',
    code: 'P-02',
    description: 'Cabo HDMI 1m',
    balance: 5,
    version: 1,
    ncm: '85444290',
    valor_unitario: 18.9,
    ...fiscalDefaults,
    created_at: '2026-05-01T10:00:00Z',
    updated_at: '2026-05-01T10:00:00Z'
  }
];

// Represents a row that was created BEFORE migration 006 + bug #5
// fix. The DB allows it (NCM/valor_unitario are nullable), but the
// form rejects it as invalid until the operator backfills.
const legacyIncompleteProduct: Product = {
  id: 'legacy',
  code: 'TEST001',
  description: 'Produto antigo',
  balance: 1,
  version: 1,
  ncm: null,
  valor_unitario: null,
  ...fiscalDefaults,
  created_at: '2026-04-01T10:00:00Z',
  updated_at: '2026-04-01T10:00:00Z'
};

describe('ProductsComponent', () => {
  let fixture: ComponentFixture<ProductsComponent>;
  let component: ProductsComponent;
  let apiMock: {
    getProducts: jest.Mock;
    createProduct: jest.Mock;
    updateProduct: jest.Mock;
    deleteProduct: jest.Mock;
  };
  let dialogMock: { confirmDelete: jest.Mock };
  let toastMock: { success: jest.Mock; error: jest.Mock };

  beforeEach(async () => {
    apiMock = {
      getProducts: jest.fn().mockReturnValue(
        of({
          success: true,
          data: { items: sampleProducts, total: 2, limit: 20, offset: 0 },
          code: 200
        })
      ),
      createProduct: jest.fn(),
      updateProduct: jest.fn(),
      deleteProduct: jest.fn()
    };
    dialogMock = { confirmDelete: jest.fn() };
    toastMock = { success: jest.fn(), error: jest.fn() };

    await TestBed.configureTestingModule({
      imports: [ProductsComponent, NoopAnimationsModule],
      providers: [
        { provide: ApiService, useValue: apiMock },
        { provide: DialogService, useValue: dialogMock },
        { provide: ToastService, useValue: toastMock },
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
  });

  it('loads products on init', () => {
    fixture.detectChanges();
    expect(apiMock.getProducts).toHaveBeenCalled();
    expect(component.productsSignal()).toHaveLength(2);
  });

  it('keeps products empty and does not throw on error', () => {
    apiMock.getProducts.mockReturnValueOnce(throwError(() => new Error('fail')));
    fixture.detectChanges();
    expect(component.productsSignal()).toEqual([]);
  });

  it('starts with form invalid (required fields empty)', () => {
    fixture.detectChanges();
    expect(component.productForm.invalid).toBe(true);
    expect(component.code?.errors).toMatchObject({ required: true });
  });

  it('rejects negative balance', () => {
    fixture.detectChanges();
    component.productForm.patchValue({ code: 'X', description: 'Y', balance: -1 });
    expect(component.balance?.errors).toMatchObject({ min: expect.anything() });
  });

  it('openNewProductForm resets the form and shows it', () => {
    fixture.detectChanges();
    component.productForm.patchValue({ code: 'old' });
    component.editingProductId = 'p9';
    component.openNewProductForm();
    expect(component.showForm).toBe(true);
    expect(component.editingProductId).toBeNull();
    // openNewProductForm now seeds defaults rather than null-resetting,
    // so code lands on '' (no SKU yet) and balance on 0. The 7 fiscal
    // fields with defaults also get seeded so the form is immediately
    // valid for create as soon as code/description are filled.
    expect(component.code?.value).toBe('');
    expect(component.balance?.value).toBe(0);
    expect(component.productForm.value.cfop_padrao_saida).toBe('5102');
    expect(component.productForm.value.u_com).toBe('UN');
    expect(component.productForm.value.cst_icms).toBe('00');
    // Bug Sweep 2: p_icms is now string-typed in the form (text input
    // preserves trailing zeros). toRequestPayload coerces back to number.
    expect(component.productForm.value.p_icms).toBe('18.00');
  });

  it('cancelForm hides the form and clears edit state', () => {
    fixture.detectChanges();
    component.editingProductId = 'p9';
    component.showForm = true;
    component.cancelForm();
    expect(component.showForm).toBe(false);
    expect(component.editingProductId).toBeNull();
  });

  it('submitForm noop when invalid', () => {
    fixture.detectChanges();
    component.submitForm();
    expect(apiMock.createProduct).not.toHaveBeenCalled();
    expect(apiMock.updateProduct).not.toHaveBeenCalled();
  });

  it('submitForm creates a new product when not editing', () => {
    fixture.detectChanges();
    const created: Product = { ...sampleProducts[0], id: 'p3', code: 'P-03' };
    apiMock.createProduct.mockReturnValue(of({ success: true, data: created, code: 201 }));

    component.openNewProductForm();
    // Bug #5 fix: NCM and valor_unitario are now required at the form
    // layer. Bug Sweep 2: valor_unitario is string-typed in the form
    // and coerced to number by toRequestPayload before posting.
    component.productForm.patchValue({
      code: 'P-03',
      description: 'Novo',
      balance: 7,
      ncm: '85171300',
      valor_unitario: '99.90'
    });
    component.submitForm();

    expect(apiMock.createProduct).toHaveBeenCalledWith({
      code: 'P-03',
      description: 'Novo',
      balance: 7,
      ncm: '85171300',
      valor_unitario: 99.9,
      cfop_padrao_saida: '5102',
      u_com: 'UN',
      origem: '0',
      cst_icms: '00',
      p_icms: 18,
      cst_pis: '49',
      cst_cofins: '49'
    });
    expect(component.productsSignal()).toContain(created);
    expect(component.showForm).toBe(false);
    // Bug Sweep 2: success toast fires after create.
    expect(toastMock.success).toHaveBeenCalled();
  });

  it('submitForm refuses to save when NCM is missing (bug #5 fix)', () => {
    fixture.detectChanges();
    component.openNewProductForm();
    // Everything filled EXCEPT NCM — historically this would create a
    // half-baked product that breaks the autocomplete. The form now
    // gates the save until NCM is present.
    component.productForm.patchValue({
      code: 'P-99',
      description: 'Produto teste',
      balance: 1,
      valor_unitario: 10
    });
    expect(component.productForm.valid).toBe(false);
    component.submitForm();
    expect(apiMock.createProduct).not.toHaveBeenCalled();
  });

  it('submitForm refuses to save when valor_unitario is missing (bug #5 fix)', () => {
    fixture.detectChanges();
    component.openNewProductForm();
    component.productForm.patchValue({
      code: 'P-99',
      description: 'Produto teste',
      balance: 1,
      ncm: '85171300'
    });
    expect(component.productForm.valid).toBe(false);
    component.submitForm();
    expect(apiMock.createProduct).not.toHaveBeenCalled();
  });

  it('editProduct preserves trailing zeros in valor_unitario (bug Sweep 2: 199.9 → "199.90")', () => {
    // Lock-in: with type=number the browser stripped the trailing zero
    // and the user saw "199,9". With type=text + toFixed(2) seed the
    // input renders the full "199.90". The form value is the string,
    // toRequestPayload coerces back to number.
    const product: Product = { ...sampleProducts[0], valor_unitario: 199.9, p_icms: 18 };
    fixture.detectChanges();
    component.editProduct(product);
    expect(component.productForm.value.valor_unitario).toBe('199.90');
    expect(component.productForm.value.p_icms).toBe('18.00');
  });

  it('editProduct on a legacy incomplete product surfaces the form as invalid', () => {
    // The DB still allows ncm/valor_unitario nullable for legacy rows,
    // but the form must surface them as required so the operator
    // backfills before saving. Without this gate the legacy product
    // would silently round-trip as still-empty.
    fixture.detectChanges();
    component.editProduct(legacyIncompleteProduct);
    expect(component.showForm).toBe(true);
    expect(component.productForm.valid).toBe(false);
    expect(component.productForm.get('ncm')?.errors).toMatchObject({ required: true });
    expect(component.productForm.get('valor_unitario')?.errors).toMatchObject({
      required: true
    });
  });

  it('submitForm updates an existing product when editing', () => {
    fixture.detectChanges();
    const updated: Product = { ...sampleProducts[0], description: 'Cabo HDMI 2m PLUS' };
    apiMock.updateProduct.mockReturnValue(of({ success: true, data: updated, code: 200 }));

    component.editProduct(sampleProducts[0]);
    component.productForm.patchValue({ description: 'Cabo HDMI 2m PLUS' });
    component.submitForm();

    expect(apiMock.updateProduct).toHaveBeenCalledWith(
      'p1',
      expect.objectContaining({ description: 'Cabo HDMI 2m PLUS' })
    );
    expect(component.productsSignal().find(p => p.id === 'p1')?.description).toBe(
      'Cabo HDMI 2m PLUS'
    );
  });

  it('editProduct preloads the form and switches to edit mode', () => {
    fixture.detectChanges();
    component.editProduct(sampleProducts[0]);
    expect(component.showForm).toBe(true);
    expect(component.editingProductId).toBe('p1');
    expect(component.productForm.value).toMatchObject({
      code: 'P-01',
      description: 'Cabo HDMI 2m',
      balance: 10
    });
  });

  it('deleteProduct does nothing when the user cancels the confirmation', async () => {
    fixture.detectChanges();
    dialogMock.confirmDelete.mockResolvedValueOnce(false);
    await component.deleteProduct('p1');
    expect(apiMock.deleteProduct).not.toHaveBeenCalled();
  });

  it('deleteProduct removes the product on confirmation', async () => {
    fixture.detectChanges();
    dialogMock.confirmDelete.mockResolvedValueOnce(true);
    apiMock.deleteProduct.mockReturnValue(of({ success: true, code: 200 }));

    await component.deleteProduct('p1');
    expect(apiMock.deleteProduct).toHaveBeenCalledWith('p1');
    expect(component.productsSignal().find(p => p.id === 'p1')).toBeUndefined();
  });

  it('formatBalance renders pt-BR locale + suffix', () => {
    fixture.detectChanges();
    expect(component.formatBalance(1234)).toBe('1.234 un');
  });

  describe('Multi-view mode (sprint 3)', () => {
    it('search filters by code, description and NCM (case + accent insensitive)', () => {
      fixture.detectChanges();
      // Direct signal write bypasses the debounce, which is what we
      // want — the debounce is wired to the input event subject and
      // the filtering itself is what we're locking in.
      component.searchTerm.set('cabo');
      expect(component.displayedProducts()).toHaveLength(2);
      component.searchTerm.set('hdmi 2m');
      expect(component.displayedProducts()).toHaveLength(1);
      expect(component.displayedProducts()[0].code).toBe('P-01');
      // Search by NCM digits — fixture has '85444290' on both rows.
      component.searchTerm.set('854442');
      expect(component.displayedProducts()).toHaveLength(2);
    });

    it('search strips diacritics — "sao" matches "São"', () => {
      // Insert a fixture with accent so the strip path is exercised.
      component.productsSignal.update(list => [
        ...list,
        {
          id: 'p3',
          code: 'P-03',
          description: 'Cabo São Paulo',
          balance: 1,
          version: 1,
          ncm: '12345678',
          valor_unitario: 5,
          ...fiscalDefaults,
          created_at: '',
          updated_at: ''
        }
      ]);
      component.searchTerm.set('sao paulo');
      expect(component.displayedProducts().some(p => p.id === 'p3')).toBe(true);
    });

    it('setSort flips direction when called on the already-active key', () => {
      // Default sort is code asc — first setSort('code') hits the
      // "same key" branch and flips to desc, matching the standard
      // table-header sort affordance.
      fixture.detectChanges();
      expect(component.sortKey()).toBe('code');
      expect(component.sortDir()).toBe('asc');
      component.setSort('code');
      expect(component.sortDir()).toBe('desc');
      component.setSort('code');
      expect(component.sortDir()).toBe('asc');
    });

    it('setSort changing key resets direction to asc', () => {
      fixture.detectChanges();
      component.setSort('code'); // flip code to desc
      component.setSort('description');
      expect(component.sortKey()).toBe('description');
      expect(component.sortDir()).toBe('asc');
    });

    it('displayedProducts sorts by code asc by default', () => {
      fixture.detectChanges();
      const codes = component.displayedProducts().map(p => p.code);
      expect(codes).toEqual([...codes].sort());
    });

    it('displayedProducts sorts by balance desc when requested', () => {
      fixture.detectChanges();
      component.setSort('balance');
      component.setSort('balance'); // flip to desc
      const balances = component.displayedProducts().map(p => p.balance);
      expect(balances[0]).toBeGreaterThanOrEqual(balances[balances.length - 1]);
    });

    it('keyboard shortcut G/L/T toggles view mode', () => {
      fixture.detectChanges();
      const fire = (key: string) => {
        const evt = new KeyboardEvent('keydown', { key });
        // Stub preventDefault since the signal scheduler doesn't run
        // a full DOM dispatch path here.
        Object.defineProperty(evt, 'target', { value: document.body, writable: false });
        component.handleKeydown(evt);
      };
      fire('l');
      expect(component.viewService.mode()).toBe('list');
      fire('t');
      expect(component.viewService.mode()).toBe('table');
      fire('g');
      expect(component.viewService.mode()).toBe('grid');
    });

    it('keyboard shortcut ignored when typing into an input', () => {
      fixture.detectChanges();
      component.viewService.setMode('grid');
      const input = document.createElement('input');
      const evt = new KeyboardEvent('keydown', { key: 'l' });
      Object.defineProperty(evt, 'target', { value: input, writable: false });
      component.handleKeydown(evt);
      // The shortcut must NOT fire — the user was just typing the
      // letter "l" inside a text field.
      expect(component.viewService.mode()).toBe('grid');
    });

    it('keyboard shortcut ignored when modifier key is held', () => {
      fixture.detectChanges();
      component.viewService.setMode('grid');
      const evt = new KeyboardEvent('keydown', { key: 'l', ctrlKey: true });
      Object.defineProperty(evt, 'target', { value: document.body, writable: false });
      component.handleKeydown(evt);
      expect(component.viewService.mode()).toBe('grid');
    });

    it('T shortcut is suppressed on mobile (table mode is hidden)', () => {
      fixture.detectChanges();
      component.viewService.setMode('grid');
      component.viewService.__setMobileForTesting(true);
      const evt = new KeyboardEvent('keydown', { key: 't' });
      Object.defineProperty(evt, 'target', { value: document.body, writable: false });
      component.handleKeydown(evt);
      expect(component.viewService.mode()).toBe('grid');
    });

    it('handles 100 mocked products without exceeding sort/search budget', () => {
      const many: Product[] = Array.from({ length: 100 }, (_, i) => ({
        id: `p${i}`,
        code: `P-${String(i).padStart(3, '0')}`,
        description: `Produto ${i}`,
        balance: i,
        version: 1,
        ncm: '85444290',
        valor_unitario: 10 + i,
        ...fiscalDefaults,
        created_at: '',
        updated_at: ''
      }));
      component.productsSignal.set(many);
      expect(component.displayedProducts()).toHaveLength(100);
      // Search narrows to 11 (codes ending in "01..09" + "010" + "100"
      // — actually only "P-001" through "P-009" and "P-010"–"P-019"
      // contain "01"... computing exact count is brittle, just ensure
      // it scales down).
      component.searchTerm.set('P-05');
      expect(component.displayedProducts().length).toBeGreaterThan(0);
      expect(component.displayedProducts().length).toBeLessThan(100);
    });

    it('handles 0 products (empty state) and 1 product without throwing', () => {
      component.productsSignal.set([]);
      expect(component.displayedProducts()).toEqual([]);
      component.productsSignal.set([sampleProducts[0]]);
      expect(component.displayedProducts()).toHaveLength(1);
    });

    it('setViewMode bumps modeRevision so the fade-in re-keys', () => {
      fixture.detectChanges();
      const before = component.modeRevision();
      component.setViewMode('list');
      expect(component.modeRevision()).toBe(before + 1);
    });
  });

  // Regression: 2026-05-08. .products-list é a cdk-virtual-scroll-viewport;
  // o CDK aplica overflow:auto via classe interna. Tinha overflow:hidden no
  // host sobrescrevendo, o que travava o scroll virtual e cortava as últimas
  // linhas quando page size > altura visível. Esse teste lê o SCSS direto
  // pra falhar imediatamente se alguém voltar a propriedade.
  describe('CSS regression', () => {
    it('.products-list keeps overflow:auto (cdk-virtual-scroll needs it to scroll internally)', () => {
      const scss = readFileSync(join(__dirname, 'products.component.scss'), 'utf-8');
      const block = scss.match(/\.products-list\s*\{[^}]*\}/)?.[0];
      expect(block).toBeTruthy();
      expect(block).not.toMatch(/overflow:\s*hidden/);
      expect(block).toMatch(/overflow:\s*auto/);
    });
  });
});
