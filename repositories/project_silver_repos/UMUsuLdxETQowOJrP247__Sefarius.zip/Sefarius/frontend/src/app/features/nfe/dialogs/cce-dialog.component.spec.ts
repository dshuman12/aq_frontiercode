import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { CCeDialogComponent, CCeDialogData, CCeDialogResult } from './cce-dialog.component';

describe('CCeDialogComponent', () => {
  let fixture: ComponentFixture<CCeDialogComponent>;
  let component: CCeDialogComponent;
  let dialogRefClose: jest.Mock;

  function setup(data: CCeDialogData) {
    dialogRefClose = jest.fn();
    TestBed.configureTestingModule({
      imports: [CCeDialogComponent, NoopAnimationsModule],
      providers: [
        { provide: MatDialogRef, useValue: { close: dialogRefClose } },
        { provide: MAT_DIALOG_DATA, useValue: data }
      ]
    });
    fixture = TestBed.createComponent(CCeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => setup({ chave: 'abc-44', nextSeq: 2 }));

  it('starts invalid with empty correction', () => {
    expect(component.form.invalid).toBe(true);
    expect(component.correctionLength).toBe(0);
  });

  it('rejects corrections shorter than 15 chars', () => {
    component.form.patchValue({ correction: 'curta' });
    expect(component.form.controls['correction'].errors).toMatchObject({
      minlength: expect.anything()
    });
  });

  it('rejects corrections longer than 1000 chars', () => {
    component.form.patchValue({ correction: 'a'.repeat(1001) });
    expect(component.form.controls['correction'].errors).toMatchObject({
      maxlength: expect.anything()
    });
  });

  it('accepts a correction in the 15-1000 range', () => {
    component.form.patchValue({
      correction: 'No item 3, leia-se cabo HDMI 1.5m em vez de 2m'
    });
    expect(component.form.valid).toBe(true);
  });

  it('onConfirm() with invalid form does NOT close', () => {
    component.onConfirm();
    expect(dialogRefClose).not.toHaveBeenCalled();
  });

  it('onConfirm() emits the trimmed correction and the data.nextSeq', () => {
    component.form.patchValue({
      correction: '  Correção do item 3 — substitua descrição    '
    });
    component.onConfirm();
    expect(dialogRefClose).toHaveBeenCalledWith({
      correction: 'Correção do item 3 — substitua descrição',
      seq: 2
    } satisfies CCeDialogResult);
  });

  it('onConfirm() forwards data.nextSeq verbatim (no auto-increment in the dialog)', () => {
    // Default beforeEach already used nextSeq=2; trust that data.nextSeq is
    // forwarded verbatim. Re-instantiating TestBed mid-test is not allowed.
    component.form.patchValue({
      correction: 'Outra correção válida com mais de 15 chars'
    });
    component.onConfirm();
    expect(dialogRefClose).toHaveBeenCalledWith({
      correction: 'Outra correção válida com mais de 15 chars',
      seq: 2
    });
  });

  it('onCancel() closes with null', () => {
    component.onCancel();
    expect(dialogRefClose).toHaveBeenCalledWith(null);
  });
});
