import { FormControl, FormGroup, Validators } from '@angular/forms';
import {
  CFOP_INTERESTADUAL_WHITELIST,
  CFOP_INTERNA_WHITELIST,
  UF_LIST,
  cUfFor,
  cfopValidator,
  cnpjValidator,
  cpfValidator,
  decimalValidator,
  destDocXorValidator,
  digitsOnly,
  digitsValidator,
  flipCfopForIdDest,
  idDestConsistencyValidator,
  isValidCNPJ,
  isValidCPF,
  ufValidator
} from './nfe-validators';

describe('UF table', () => {
  it('contains all 27 Brazilian UFs', () => {
    expect(UF_LIST).toHaveLength(27);
  });

  it('cUfFor returns the IBGE 2-digit code for valid UF', () => {
    expect(cUfFor('RS')).toBe('43');
    expect(cUfFor('SP')).toBe('35');
    expect(cUfFor('DF')).toBe('53');
  });

  it('cUfFor returns empty string for invalid UF', () => {
    expect(cUfFor('XX')).toBe('');
    expect(cUfFor('')).toBe('');
  });
});

describe('CFOP whitelist', () => {
  it('exposes a non-empty list of venda interna CFOPs (5xxx)', () => {
    expect(CFOP_INTERNA_WHITELIST.length).toBeGreaterThan(0);
    for (const c of CFOP_INTERNA_WHITELIST) {
      expect(c.code).toMatch(/^5\d{3}$/);
    }
  });

  it('exposes a non-empty list of venda interestadual CFOPs (6xxx)', () => {
    expect(CFOP_INTERESTADUAL_WHITELIST.length).toBeGreaterThan(0);
    for (const c of CFOP_INTERESTADUAL_WHITELIST) {
      expect(c.code).toMatch(/^6\d{3}$/);
    }
  });

  it('interna and interestadual lists have parallel codes (5xxx ↔ 6xxx)', () => {
    const internaSuffixes = CFOP_INTERNA_WHITELIST.map(c => c.code.slice(1)).sort();
    const interestadualSuffixes = CFOP_INTERESTADUAL_WHITELIST.map(c => c.code.slice(1)).sort();
    expect(internaSuffixes).toEqual(interestadualSuffixes);
  });
});

describe('flipCfopForIdDest', () => {
  it('flips 5102 → 6102 when id_dest=2', () => {
    expect(flipCfopForIdDest('5102', '2')).toBe('6102');
  });

  it('flips 6102 → 5102 when id_dest=1', () => {
    expect(flipCfopForIdDest('6102', '1')).toBe('5102');
  });

  it('leaves 5102 unchanged when already correct (id_dest=1)', () => {
    expect(flipCfopForIdDest('5102', '1')).toBe('5102');
  });

  it('leaves 6102 unchanged when already correct (id_dest=2)', () => {
    expect(flipCfopForIdDest('6102', '2')).toBe('6102');
  });

  it('leaves out-of-range CFOPs alone (1xxx entradas, 7xxx exterior)', () => {
    expect(flipCfopForIdDest('1102', '2')).toBe('1102');
    expect(flipCfopForIdDest('7102', '1')).toBe('7102');
  });

  it('handles empty/malformed input without throwing', () => {
    expect(flipCfopForIdDest('', '1')).toBe('');
    expect(flipCfopForIdDest('510', '1')).toBe('510');
  });
});

describe('digitsOnly', () => {
  it('strips all non-digit characters', () => {
    expect(digitsOnly('12.345.678/0001-99')).toBe('12345678000199');
    expect(digitsOnly('')).toBe('');
    expect(digitsOnly('abc')).toBe('');
  });

  it('returns empty string for non-string inputs', () => {
    expect(digitsOnly(null)).toBe('');
    expect(digitsOnly(undefined)).toBe('');
    expect(digitsOnly(123 as unknown)).toBe('');
  });
});

describe('isValidCNPJ', () => {
  it('accepts a known-valid CNPJ', () => {
    expect(isValidCNPJ('11222333000181')).toBe(true);
  });

  it('rejects a CNPJ with wrong check digits', () => {
    expect(isValidCNPJ('11222333000180')).toBe(false);
    expect(isValidCNPJ('11222333000100')).toBe(false);
  });

  it('rejects all-same-digit CNPJs (a known degenerate-pass)', () => {
    expect(isValidCNPJ('00000000000000')).toBe(false);
    expect(isValidCNPJ('11111111111111')).toBe(false);
  });

  it('rejects strings of wrong length', () => {
    expect(isValidCNPJ('11222333')).toBe(false);
    expect(isValidCNPJ('1122233300018111')).toBe(false);
    expect(isValidCNPJ('')).toBe(false);
  });

  it('strips formatting characters before validating', () => {
    expect(isValidCNPJ('11.222.333/0001-81')).toBe(true);
  });
});

describe('isValidCPF', () => {
  it('accepts a known-valid CPF', () => {
    expect(isValidCPF('39053344705')).toBe(true);
  });

  it('rejects a CPF with wrong check digits', () => {
    expect(isValidCPF('39053344700')).toBe(false);
  });

  it('rejects all-same-digit CPFs', () => {
    expect(isValidCPF('00000000000')).toBe(false);
    expect(isValidCPF('99999999999')).toBe(false);
  });

  it('rejects strings of wrong length', () => {
    expect(isValidCPF('390533447')).toBe(false);
    expect(isValidCPF('')).toBe(false);
  });
});

describe('cnpjValidator', () => {
  const v = cnpjValidator();

  it('returns null for empty value (non-required)', () => {
    expect(v(new FormControl(''))).toBeNull();
  });

  it('returns null for valid CNPJ', () => {
    expect(v(new FormControl('11222333000181'))).toBeNull();
  });

  it('returns {cnpj: true} for invalid CNPJ', () => {
    expect(v(new FormControl('11222333000180'))).toEqual({ cnpj: true });
  });

  // Regression: a draft restore or copy-paste with whitespace would
  // make `!v` false (a space is truthy), and the format check would
  // then run against the whitespace and fail — surfacing a "CNPJ
  // inválido" message on a field the user never typed in.
  it('returns null for whitespace-only value', () => {
    expect(v(new FormControl(' '))).toBeNull();
    expect(v(new FormControl('   '))).toBeNull();
    expect(v(new FormControl('\t'))).toBeNull();
  });
});

describe('cpfValidator', () => {
  const v = cpfValidator();

  it('returns null for empty value', () => {
    expect(v(new FormControl(''))).toBeNull();
  });

  it('returns null for valid CPF', () => {
    expect(v(new FormControl('39053344705'))).toBeNull();
  });

  it('returns {cpf: true} for invalid CPF', () => {
    expect(v(new FormControl('39053344700'))).toEqual({ cpf: true });
  });

  // Regression for the QA report: invalid CNPJ with empty CPF in dest
  // showed "CPF inválido" alongside "CNPJ inválido". Root cause: a
  // whitespace-only value (from paste, draft restore, or tab focus
  // through an empty field) bypassed the `!v` empty guard. After the
  // fix, the validator must treat whitespace as blank.
  it('returns null for whitespace-only value', () => {
    expect(v(new FormControl(' '))).toBeNull();
    expect(v(new FormControl('   '))).toBeNull();
  });
});

describe('ufValidator', () => {
  const v = ufValidator();

  it('returns null for known UF', () => {
    expect(v(new FormControl('RS'))).toBeNull();
    expect(v(new FormControl('SP'))).toBeNull();
  });

  it('returns {uf: true} for unknown UF', () => {
    expect(v(new FormControl('XX'))).toEqual({ uf: true });
  });

  it('returns null when control empty', () => {
    expect(v(new FormControl(''))).toBeNull();
  });
});

describe('digitsValidator', () => {
  it('accepts string with exact digit count', () => {
    const v = digitsValidator(7, 'cMun');
    expect(v(new FormControl('4314902'))).toBeNull();
  });

  it('rejects shorter or longer strings', () => {
    const v = digitsValidator(7, 'cMun');
    expect(v(new FormControl('431490'))).toEqual({ cMun: true });
    expect(v(new FormControl('43149020'))).toEqual({ cMun: true });
  });

  it('rejects non-digit characters', () => {
    const v = digitsValidator(7, 'cMun');
    expect(v(new FormControl('431490a'))).toEqual({ cMun: true });
  });

  it('returns null for empty (non-required)', () => {
    const v = digitsValidator(7, 'cMun');
    expect(v(new FormControl(''))).toBeNull();
  });
});

describe('cfopValidator', () => {
  const v = cfopValidator();

  it('accepts 4-digit CFOP starting with 1-7', () => {
    expect(v(new FormControl('5102'))).toBeNull();
    expect(v(new FormControl('1101'))).toBeNull();
    expect(v(new FormControl('7102'))).toBeNull();
  });

  it('rejects too-short, too-long or wrong-prefix codes', () => {
    expect(v(new FormControl('510'))).toEqual({ cfop: true });
    expect(v(new FormControl('51022'))).toEqual({ cfop: true });
    expect(v(new FormControl('8102'))).toEqual({ cfop: true });
  });
});

describe('decimalValidator', () => {
  const v = decimalValidator();

  it('accepts strings matching ^\\d+\\.\\d{2}$', () => {
    expect(v(new FormControl('100.00'))).toBeNull();
    expect(v(new FormControl('0.00'))).toBeNull();
    expect(v(new FormControl('1234567890.99'))).toBeNull();
  });

  it('rejects too-few or too-many decimals', () => {
    expect(v(new FormControl('100'))).toEqual({ decimal: true });
    expect(v(new FormControl('100.0'))).toEqual({ decimal: true });
    expect(v(new FormControl('100.000'))).toEqual({ decimal: true });
  });

  it('rejects negative or comma-decimal forms', () => {
    expect(v(new FormControl('-1.00'))).toEqual({ decimal: true });
    expect(v(new FormControl('1,00'))).toEqual({ decimal: true });
  });

  it('returns null for empty', () => {
    expect(v(new FormControl(''))).toBeNull();
    expect(v(new FormControl(null))).toBeNull();
  });
});

describe('destDocXorValidator', () => {
  function makeGroup(cnpj: string, cpf: string): FormGroup {
    return new FormGroup({
      cnpj: new FormControl(cnpj),
      cpf: new FormControl(cpf)
    });
  }

  it('returns {destDocXor: "both"} when both present', () => {
    expect(destDocXorValidator(makeGroup('11222333000181', '39053344705'))).toEqual({
      destDocXor: 'both'
    });
  });

  it('returns {destDocXor: "none"} when neither present', () => {
    expect(destDocXorValidator(makeGroup('', ''))).toEqual({ destDocXor: 'none' });
  });

  it('returns null when only CNPJ present', () => {
    expect(destDocXorValidator(makeGroup('11222333000181', ''))).toBeNull();
  });

  it('returns null when only CPF present', () => {
    expect(destDocXorValidator(makeGroup('', '39053344705'))).toBeNull();
  });

  it('treats whitespace-only as empty', () => {
    expect(destDocXorValidator(makeGroup('   ', '39053344705'))).toBeNull();
  });
});

describe('integration with reactive forms', () => {
  it('a control with cnpjValidator + Validators.required errors on empty', () => {
    const c = new FormControl('', [Validators.required, cnpjValidator()]);
    expect(c.valid).toBe(false);
    expect(c.errors).toEqual({ required: true });
    c.setValue('11222333000181');
    expect(c.valid).toBe(true);
  });
});

describe('idDestConsistencyValidator', () => {
  // Builds the same nested shape the wizard form has — emit.uf,
  // dest.uf, ide.id_dest as siblings under the root group. Bug #3
  // regression test: when this returned `null` for inconsistent
  // pairs, the user only saw the validation error after submit.
  function makeRoot(emitUf: string, destUf: string, idDest: string): FormGroup {
    return new FormGroup({
      emit: new FormGroup({ uf: new FormControl(emitUf) }),
      dest: new FormGroup({ uf: new FormControl(destUf) }),
      ide: new FormGroup({ id_dest: new FormControl(idDest) })
    });
  }

  it('returns null when UFs equal and id_dest=1', () => {
    expect(idDestConsistencyValidator(makeRoot('RS', 'RS', '1'))).toBeNull();
  });

  it('returns null when UFs differ and id_dest=2', () => {
    expect(idDestConsistencyValidator(makeRoot('RS', 'SP', '2'))).toBeNull();
  });

  it('returns shouldBeInternal when UFs equal but id_dest=2', () => {
    expect(idDestConsistencyValidator(makeRoot('RS', 'RS', '2'))).toEqual({
      idDestMismatch: 'shouldBeInternal'
    });
  });

  it('returns shouldBeInterstate when UFs differ but id_dest=1', () => {
    expect(idDestConsistencyValidator(makeRoot('RS', 'SP', '1'))).toEqual({
      idDestMismatch: 'shouldBeInterstate'
    });
  });

  it('skips validation when id_dest=3 (operator chose exterior)', () => {
    expect(idDestConsistencyValidator(makeRoot('RS', 'RS', '3'))).toBeNull();
    expect(idDestConsistencyValidator(makeRoot('RS', 'SP', '3'))).toBeNull();
  });

  it('returns null when any of the three values is blank', () => {
    expect(idDestConsistencyValidator(makeRoot('', 'SP', '1'))).toBeNull();
    expect(idDestConsistencyValidator(makeRoot('RS', '', '1'))).toBeNull();
    expect(idDestConsistencyValidator(makeRoot('RS', 'SP', ''))).toBeNull();
  });
});
