import { Injectable, computed, effect, signal } from '@angular/core';

export type NFeListViewMode = 'grid' | 'list' | 'table';

const STORAGE_KEY = 'sefarius:nfe:viewMode';
const VALID_MODES: readonly NFeListViewMode[] = ['grid', 'list', 'table'] as const;
const MOBILE_MEDIA = '(max-width: 768px)';

/**
 * View-mode controller for the /nfe list. Same shape as
 * ProductsViewService and InvoicesViewService — a parallel class so
 * /nfe persists its own preference (operators of the SEFAZ flow tend
 * to want the dense table; the trio of services keeps each feature's
 * default independent).
 */
@Injectable({ providedIn: 'root' })
export class NFeListViewService {
  private readonly _preferred = signal<NFeListViewMode>(this.loadFromStorage());
  private readonly _isMobile = signal<boolean>(this.matchesMobile());

  readonly preferred = this._preferred.asReadonly();
  readonly isMobile = this._isMobile.asReadonly();
  readonly mode = computed<NFeListViewMode>(() => {
    if (this._isMobile() && this._preferred() === 'table') {
      return 'list';
    }
    return this._preferred();
  });

  constructor() {
    effect(() => {
      const value = this._preferred();
      try {
        localStorage.setItem(STORAGE_KEY, value);
      } catch {
        // ignore — in-memory signal still works for the session
      }
    });

    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const mql = window.matchMedia(MOBILE_MEDIA);
      const handler = (e: MediaQueryListEvent) => this._isMobile.set(e.matches);
      if (typeof mql.addEventListener === 'function') {
        mql.addEventListener('change', handler);
      }
    }
  }

  setMode(mode: NFeListViewMode): void {
    if ((VALID_MODES as readonly string[]).includes(mode)) {
      this._preferred.set(mode);
    }
  }

  __setMobileForTesting(isMobile: boolean): void {
    this._isMobile.set(isMobile);
  }

  private loadFromStorage(): NFeListViewMode {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw && (VALID_MODES as readonly string[]).includes(raw)) {
        return raw as NFeListViewMode;
      }
    } catch {
      // ignore
    }
    // Default 'table' — NFe operators want dense audit-friendly rows.
    return 'table';
  }

  private matchesMobile(): boolean {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return false;
    }
    return window.matchMedia(MOBILE_MEDIA).matches;
  }
}
