import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import {
  CancelNFeDialogComponent,
  CancelNFeDialogData,
  CancelNFeDialogResult
} from './cancel-nfe-dialog.component';

describe('CancelNFeDialogComponent', () => {
  let fixture: ComponentFixture<CancelNFeDialogComponent>;
  let component: CancelNFeDialogComponent;
  let dialogRefClose: jest.Mock;

  beforeEach(async () => {
    dialogRefClose = jest.fn();
    await TestBed.configureTestingModule({
      imports: [CancelNFeDialogComponent, NoopAnimationsModule],
      providers: [
        { provide: MatDialogRef, useValue: { close: dialogRefClose } },
        { provide: MAT_DIALOG_DATA, useValue: { chave: 'abc-44' } as CancelNFeDialogData }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(CancelNFeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('starts invalid and reports the live justification length', () => {
    expect(component.form.invalid).toBe(true);
    expect(component.justificationLength).toBe(0);
  });

  it('rejects justifications shorter than 15 chars', () => {
    component.form.patchValue({ justification: 'curto' });
    expect(component.form.controls['justification'].errors).toMatchObject({
      minlength: expect.anything()
    });
  });

  it('rejects justifications longer than 255 chars', () => {
    component.form.patchValue({ justification: 'a'.repeat(256) });
    expect(component.form.controls['justification'].errors).toMatchObject({
      maxlength: expect.anything()
    });
  });

  it('accepts a justification in the 15-255 range', () => {
    component.form.patchValue({
      justification: 'Erro de digitação no item 2 — reemissão correta autorizada'
    });
    expect(component.form.valid).toBe(true);
  });

  it('onConfirm() with invalid form does NOT close the dialog', () => {
    component.onConfirm();
    expect(dialogRefClose).not.toHaveBeenCalled();
  });

  it('onConfirm() trims whitespace and closes with the result payload', () => {
    component.form.patchValue({
      justification: '   Erro no item dois, reemissão autorizada    '
    });
    component.onConfirm();
    expect(dialogRefClose).toHaveBeenCalledWith({
      justification: 'Erro no item dois, reemissão autorizada'
    } satisfies CancelNFeDialogResult);
  });

  it('onCancel() closes with null', () => {
    component.onCancel();
    expect(dialogRefClose).toHaveBeenCalledWith(null);
  });
});
