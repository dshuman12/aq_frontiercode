import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

export interface CCeDialogData {
  chave: string;
  nextSeq: number;
}

export interface CCeDialogResult {
  correction: string;
  seq: number;
}

@Component({
  selector: 'app-cce-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatDialogModule],
  templateUrl: './cce-dialog.component.html',
  styleUrls: ['./cce-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CCeDialogComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<CCeDialogComponent, CCeDialogResult | null>,
    @Inject(MAT_DIALOG_DATA) public data: CCeDialogData
  ) {
    this.form = this.fb.group({
      correction: ['', [Validators.required, Validators.minLength(15), Validators.maxLength(1000)]]
    });
  }

  get correctionLength(): number {
    return (this.form.value.correction || '').length;
  }

  onConfirm(): void {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.dialogRef.close({
      correction: this.form.value.correction.trim(),
      seq: this.data.nextSeq
    });
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }
}
