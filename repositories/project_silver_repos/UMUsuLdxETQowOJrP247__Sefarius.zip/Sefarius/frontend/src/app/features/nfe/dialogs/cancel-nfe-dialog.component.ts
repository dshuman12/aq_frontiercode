import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

export interface CancelNFeDialogData {
  chave: string;
}

export interface CancelNFeDialogResult {
  justification: string;
}

@Component({
  selector: 'app-cancel-nfe-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatDialogModule],
  templateUrl: './cancel-nfe-dialog.component.html',
  styleUrls: ['./cancel-nfe-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CancelNFeDialogComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<CancelNFeDialogComponent, CancelNFeDialogResult | null>,
    @Inject(MAT_DIALOG_DATA) public data: CancelNFeDialogData
  ) {
    this.form = this.fb.group({
      justification: [
        '',
        [Validators.required, Validators.minLength(15), Validators.maxLength(255)]
      ]
    });
  }

  get justificationLength(): number {
    return (this.form.value.justification || '').length;
  }

  onConfirm(): void {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.dialogRef.close({ justification: this.form.value.justification.trim() });
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }
}
