import { ChangeDetectionStrategy, ChangeDetectorRef, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '@app/shared/services/auth.service';
import { AuthShellComponent } from '../auth-shell/auth-shell.component';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, AuthShellComponent],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ResetPasswordComponent {
  email = '';
  sent = signal(false);
  isSubmitting = signal(false);

  constructor(
    private auth: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  submit(): void {
    this.isSubmitting.set(true);
    this.auth.requestReset(this.email).subscribe({
      next: () => {
        // Backend sempre retorna sucesso (anti-enumeration). Email vai
        // por Resend pra inbox do user. Frontend só confirma envio.
        this.sent.set(true);
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.sent.set(true);
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
      }
    });
  }
}
