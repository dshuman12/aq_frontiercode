import { ChangeDetectionStrategy, ChangeDetectorRef, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '@app/shared/services/auth.service';
import { AuthShellComponent } from '../auth-shell/auth-shell.component';

interface PasswordRule {
  label: string;
  test: (p: string) => boolean;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, AuthShellComponent],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  showPassword = signal(false);
  serverError = signal('');
  message = signal('');
  isSubmitting = signal(false);

  readonly passwordRules: PasswordRule[] = [
    { label: '8+ caracteres', test: p => p.length >= 8 },
    { label: '1 maiúscula', test: p => /[A-Z]/.test(p) },
    { label: '1 minúscula', test: p => /[a-z]/.test(p) },
    { label: '1 número', test: p => /\d/.test(p) }
  ];

  constructor(
    private auth: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  togglePassword(): void {
    this.showPassword.update(v => !v);
  }

  ruleMet(rule: PasswordRule): boolean {
    return rule.test(this.password);
  }

  submit(): void {
    this.serverError.set('');
    this.message.set('');
    this.isSubmitting.set(true);
    this.auth.register(this.name, this.email, this.password).subscribe({
      next: () => {
        this.message.set('Conta criada! Verifique seu email para ativar — o link expira em 24h.');
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
      },
      error: err => {
        this.serverError.set(err?.message || 'Erro ao criar conta.');
        this.isSubmitting.set(false);
        this.cdr.markForCheck();
      }
    });
  }
}
