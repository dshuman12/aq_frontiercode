import { Injectable, computed, effect, signal } from '@angular/core';

export type InvoicesViewMode = 'grid' | 'list' | 'table';

const STORAGE_KEY = 'sefarius:invoices:viewMode';
const VALID_MODES: readonly InvoicesViewMode[] = ['grid', 'list', 'table'] as const;
const MOBILE_MEDIA = '(max-width: 768px)';

/**
 * View-mode controller for the /invoices list. Same shape as
 * ProductsViewService — separate class so each feature persists its
 * own preference (an operator who likes cards for products may want
 * a table for invoices). Keeping them as siblings rather than a
 * generic factory avoids over-coupling: features can drift their
 * default mode or add feature-specific modes later without touching
 * each other.
 */
@Injectable({ providedIn: 'root' })
export class InvoicesViewService {
  private readonly _preferred = signal<InvoicesViewMode>(this.loadFromStorage());
  private readonly _isMobile = signal<boolean>(this.matchesMobile());

  readonly preferred = this._preferred.asReadonly();
  readonly isMobile = this._isMobile.asReadonly();
  readonly mode = computed<InvoicesViewMode>(() => {
    if (this._isMobile() && this._preferred() === 'table') {
      return 'list';
    }
    return this._preferred();
  });

  constructor() {
    effect(() => {
      const value = this._preferred();
      try {
        localStorage.setItem(STORAGE_KEY, value);
      } catch {
        // ignore — in-memory signal still works for the session
      }
    });

    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const mql = window.matchMedia(MOBILE_MEDIA);
      const handler = (e: MediaQueryListEvent) => this._isMobile.set(e.matches);
      if (typeof mql.addEventListener === 'function') {
        mql.addEventListener('change', handler);
      }
    }
  }

  setMode(mode: InvoicesViewMode): void {
    if ((VALID_MODES as readonly string[]).includes(mode)) {
      this._preferred.set(mode);
    }
  }

  __setMobileForTesting(isMobile: boolean): void {
    this._isMobile.set(isMobile);
  }

  private loadFromStorage(): InvoicesViewMode {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw && (VALID_MODES as readonly string[]).includes(raw)) {
        return raw as InvoicesViewMode;
      }
    } catch {
      // ignore — fall through to default
    }
    // Default to 'table' for invoices: transactional data lists are
    // most useful in tabular form. Operators can switch to grid/list
    // and the choice will persist.
    return 'table';
  }

  private matchesMobile(): boolean {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return false;
    }
    return window.matchMedia(MOBILE_MEDIA).matches;
  }
}
