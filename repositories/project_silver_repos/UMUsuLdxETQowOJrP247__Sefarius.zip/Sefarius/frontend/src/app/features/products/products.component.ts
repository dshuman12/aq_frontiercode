import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  HostListener,
  OnInit,
  computed,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatMenuModule } from '@angular/material/menu';
import { ApiService } from '@app/shared/services/api.service';
import { DialogService } from '@app/shared/services/dialog.service';
import { ToastService } from '@app/shared/services/toast.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { CreateProductRequest, Product, UpdateProductRequest } from '@app/shared/models/api.models';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { ProductsViewMode, ProductsViewService } from './products-view.service';
import { PaginationComponent } from '@app/shared/components/pagination/pagination.component';

type SortKey = 'code' | 'description' | 'balance';
type SortDir = 'asc' | 'desc';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatMenuModule,
    PaginationComponent
  ],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductsComponent extends BaseComponent implements OnInit {
  // Source of truth for the catalog. Wrapped in a signal so the
  // computed `displayedProducts` re-runs filter/sort whenever the API
  // populates / mutates this list.
  readonly productsSignal = signal<Product[]>([]);
  showForm = false;
  productForm: FormGroup;
  editingProductId: string | null = null;

  // View-mode service is shared with the segmented control + the
  // template's *ngIf-on-mode branches.
  readonly viewService = inject(ProductsViewService);

  // Search runs through a Subject so we can apply a 250 ms debounce
  // before pushing into the signal — avoids re-filtering on every
  // keystroke when the user types fast.
  readonly searchTerm = signal<string>('');
  private readonly searchInput$ = new Subject<string>();

  readonly sortKey = signal<SortKey>('code');
  readonly sortDir = signal<SortDir>('asc');

  // ─── Pagination state ─────────────────────────────────────────────
  // Numerical pagination over the product catalog. Server-side: each
  // page is its own GET /api/stock/products?limit=&offset=. When the
  // user searches, we switch to the search endpoint (top-N ILIKE
  // matches, no pagination) — see fetchData() below. The dual mode
  // matches what the backend was designed for and avoids the trap
  // where client-side filter on a paginated view misses matches on
  // pages we haven't loaded yet.
  readonly currentPage = signal(1);
  readonly pageSize = signal(25);
  readonly totalCount = signal(0);
  /** True when the user has typed a search term. Pagination hides in
   *  this mode because the search endpoint returns top-N matches. */
  readonly isSearching = computed(() => this.searchTerm().trim().length > 0);

  // Computed pipeline: source → filter (client-side) → sort. The
  // client-side filter runs IN ADDITION to the server-side search
  // mode triggered by debounced onSearchInput — together they give
  // (a) instant feedback as the user types (client filter on the
  // currently loaded page) and (b) broader matches once the search
  // request completes (server returns top-N). When productsSignal is
  // replaced by search-mode results, the client filter is effectively
  // a no-op (results already match).
  readonly displayedProducts = computed<Product[]>(() => {
    const term = this.normalizeForSearch(this.searchTerm());
    const sortKey = this.sortKey();
    const sortDir = this.sortDir();
    let list = this.productsSignal();
    if (term.length > 0) {
      list = list.filter(p => {
        const code = this.normalizeForSearch(p.code);
        const desc = this.normalizeForSearch(p.description);
        const ncm = this.normalizeForSearch(p.ncm ?? '');
        return code.includes(term) || desc.includes(term) || ncm.includes(term);
      });
    }
    return list.slice().sort((a, b) => this.compareBy(a, b, sortKey, sortDir));
  });

  // Drives the 150 ms fade-in on the products container when the user
  // switches between grid/list/table. Bumped by setMode().
  readonly modeRevision = signal<number>(0);

  constructor(
    private apiService: ApiService,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private dialogService: DialogService,
    private toast: ToastService
  ) {
    super();
    // Wire the debounced search Subject → searchTerm signal. 250 ms
    // matches typical "type-and-pause" UX without waiting so long
    // that the list feels stale. Errors here aren't possible (pure
    // string passthrough) so no error branch.
    this.searchInput$.pipe(debounceTime(250), takeUntil(this.destroy$)).subscribe(value => {
      this.searchTerm.set(value);
      // Reset to page 1 when the search term changes — staying on
      // page 5 of an old result set would be misleading.
      this.currentPage.set(1);
      this.fetchData();
    });

    this.productForm = this.fb.group({
      code: ['', Validators.required],
      description: ['', Validators.required],
      balance: [0, [Validators.required, Validators.min(0)]],
      // Bug #5 fix (sprint Bug Sweep 2026-05-07): NCM e valor_unitario
      // tornam-se obrigatórios também no frontend. Backend continua
      // aceitando nulo (compat com produtos legados); o form impede
      // criar/salvar produtos novos incompletos. Editar legados sem
      // esses campos bloqueia o "Salvar" até o operador corrigir.
      ncm: ['', [Validators.required, Validators.pattern(/^\d{8}$/)]],
      cfop_padrao_saida: ['5102', [Validators.required, Validators.pattern(/^[1-7]\d{3}$/)]],
      u_com: ['UN', [Validators.required, Validators.maxLength(6)]],
      // Bug Sweep 2: valor_unitario e p_icms switched from type=number
      // to type=text to preserve trailing-zero display ("199.90" stayed
      // visible as "199,9" with type=number because the browser strips
      // them). The form value is now a string; toRequestPayload coerces
      // back to number before posting.
      valor_unitario: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,4})?$/)]],
      origem: ['0', [Validators.required, Validators.pattern(/^[0-8]$/)]],
      cst_icms: ['00', [Validators.required, Validators.pattern(/^\d{2}$/)]],
      p_icms: ['18.00', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)]],
      cst_pis: ['49', [Validators.required, Validators.pattern(/^\d{2}$/)]],
      cst_cofins: ['49', [Validators.required, Validators.pattern(/^\d{2}$/)]]
    });
  }

  ngOnInit(): void {
    this.fetchData();
  }

  /**
   * Single fetch entry point — picks browse vs search mode based on
   * `searchTerm`. Browse mode hits the paginated list endpoint; search
   * mode hits the dedicated `?q=` endpoint (top-50 ILIKE matches), and
   * pagination is hidden in the template via `isSearching`. Triggered
   * on init, on page change, on page-size change, and on debounced
   * search input.
   */
  fetchData(): void {
    if (this.isSearching()) {
      this.apiService
        .searchProducts(this.searchTerm().trim(), 50)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: response => {
            const items = response.data?.items ?? [];
            this.productsSignal.set(items);
            this.totalCount.set(response.data?.total ?? items.length);
            this.cdr.markForCheck();
          },
          error: () => {
            this.cdr.markForCheck();
          }
        });
      return;
    }

    const page = this.currentPage();
    const size = this.pageSize();
    const offset = (page - 1) * size;
    this.apiService
      .getProducts(size, offset)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: response => {
          if (response.data) {
            this.productsSignal.set(response.data.items ?? []);
            this.totalCount.set(response.data.total ?? 0);
          }
          this.cdr.markForCheck();
        },
        error: () => {
          this.cdr.markForCheck();
        }
      });
  }

  /** Backward-compatible alias used by toggleNewProduct/onSubmit
   *  flows that historically called loadProducts(). */
  loadProducts(): void {
    this.fetchData();
  }

  // ─── Pagination handlers (consumed by <app-pagination>) ───────────

  onPageChange(page: number): void {
    this.currentPage.set(page);
    this.fetchData();
  }

  onPageSizeChange(size: number): void {
    this.pageSize.set(size);
    // Reset to first page so the user isn't dropped into an empty
    // page (size grew → fewer pages exist).
    this.currentPage.set(1);
    this.fetchData();
  }

  // ─── View mode + search + sort wiring ──────────────────────────────

  setViewMode(mode: ProductsViewMode): void {
    this.viewService.setMode(mode);
    // Bump revision so the *@for-rendered container re-keys and the
    // 150 ms fade-in animation fires fresh on every mode switch.
    this.modeRevision.update(n => n + 1);
    this.cdr.markForCheck();
  }

  onSearchInput(value: string): void {
    this.searchInput$.next(value);
  }

  setSort(key: SortKey): void {
    if (this.sortKey() === key) {
      // Same column → flip direction. Standard table-sort affordance.
      this.sortDir.update(d => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      this.sortKey.set(key);
      this.sortDir.set('asc');
    }
    this.cdr.markForCheck();
  }

  // Keyboard shortcuts: G/L/T pick a mode. Listener is gated on the
  // hasFocusableTarget check so the user typing into the inline form
  // (search box, code/description inputs) doesn't accidentally toggle
  // the layout. We also bail when modifier keys are held — they
  // belong to OS shortcuts, not us.
  @HostListener('document:keydown', ['$event'])
  handleKeydown(event: KeyboardEvent): void {
    if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) {
      return;
    }
    const target = event.target as HTMLElement | null;
    if (this.isFieldTarget(target)) {
      return;
    }
    const key = event.key.toLowerCase();
    if (key === 'g') {
      this.setViewMode('grid');
      event.preventDefault();
    } else if (key === 'l') {
      this.setViewMode('list');
      event.preventDefault();
    } else if (key === 't') {
      // Mobile force routes table → list anyway, but blocking the
      // shortcut here keeps the saved preference clean ("user picked
      // table on a phone" never enters localStorage from a shortcut).
      if (!this.viewService.isMobile()) {
        this.setViewMode('table');
        event.preventDefault();
      }
    }
  }

  private isFieldTarget(el: HTMLElement | null): boolean {
    if (!el) {
      return false;
    }
    const tag = el.tagName;
    return (
      tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable === true
    );
  }

  // NFD + diacritic strip + lowercase. "São Paulo" → "sao paulo" so the
  // search matches both "são" and "sao".
  private normalizeForSearch(s: string): string {
    return (s ?? '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  }

  private compareBy(a: Product, b: Product, key: SortKey, dir: SortDir): number {
    let av: string | number;
    let bv: string | number;
    if (key === 'balance') {
      av = a.balance ?? 0;
      bv = b.balance ?? 0;
    } else {
      av = (a[key] ?? '').toString().toLocaleLowerCase('pt-BR');
      bv = (b[key] ?? '').toString().toLocaleLowerCase('pt-BR');
    }
    if (av < bv) {
      return dir === 'asc' ? -1 : 1;
    }
    if (av > bv) {
      return dir === 'asc' ? 1 : -1;
    }
    return 0;
  }

  // Used by the table mode to render the sort-direction caret next to
  // the active column header. Returns '' for inactive columns so the
  // template can fall through to a neutral state.
  sortIndicator(key: SortKey): string {
    if (this.sortKey() !== key) {
      return '';
    }
    return this.sortDir() === 'asc' ? '▲' : '▼';
  }

  trackById(_index: number, p: Product): string {
    return p.id;
  }

  // Reset values that match the form defaults — keeps the operator
  // landing on a Product that the wizard autocomplete can already use
  // partially (the 7 default fields), with only NCM and valor_unitario
  // left for them to fill.
  private get defaultFormValues() {
    return {
      code: '',
      description: '',
      balance: 0,
      ncm: '',
      cfop_padrao_saida: '5102',
      u_com: 'UN',
      valor_unitario: '',
      origem: '0',
      cst_icms: '00',
      // Bug Sweep 2: text-typed inputs need string defaults to render
      // their trailing zero ("18" would render as "18", "18.00" stays
      // "18.00").
      p_icms: '18.00',
      cst_pis: '49',
      cst_cofins: '49'
    };
  }

  openNewProductForm(): void {
    this.productForm.reset(this.defaultFormValues);
    this.editingProductId = null;
    this.showForm = true;
  }

  cancelForm(): void {
    this.showForm = false;
    this.productForm.reset(this.defaultFormValues);
    this.editingProductId = null;
  }

  submitForm(): void {
    if (!this.productForm.valid) {
      return;
    }

    const payload = this.toRequestPayload(this.productForm.value);

    if (this.editingProductId) {
      const id = this.editingProductId;
      this.apiService
        .updateProduct(id, payload)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: response => {
            if (response.data) {
              this.productsSignal.update(list => list.map(p => (p.id === id ? response.data! : p)));
            }
            this.cancelForm();
            this.toast.success(`Produto ${response.data?.code ?? ''} atualizado.`);
            this.cdr.markForCheck();
          },
          error: err => {
            this.toast.error(this.extractError(err, 'Erro ao atualizar produto.'));
            this.cdr.markForCheck();
          }
        });
    } else {
      this.apiService
        .createProduct(payload)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: response => {
            if (response.data) {
              this.productsSignal.update(list => [...list, response.data!]);
            }
            this.cancelForm();
            this.toast.success(`Produto ${response.data?.code ?? ''} criado.`);
            this.cdr.markForCheck();
          },
          error: err => {
            this.toast.error(this.extractError(err, 'Erro ao criar produto.'));
            this.cdr.markForCheck();
          }
        });
    }
  }

  // Pulls a sensible message out of an HttpErrorResponse-shaped error.
  // Backend domain errors come on `error.error` (string); unknown
  // failures fall through to the caller's default copy.
  private extractError(err: unknown, fallback: string): string {
    const e = err as { error?: { error?: string }; message?: string };
    return e?.error?.error || e?.message || fallback;
  }

  editProduct(product: Product): void {
    // Bug Sweep 2 (2026-05-07): valor_unitario stored as 199.9 was
    // rendering as "199,9" in <input type="number">. Switch to text
    // inputs in the template + seed the string form with .toFixed(2)
    // ensures "199.9" displays as "199.90". toRequestPayload re-coerces
    // the strings back to numbers before posting.
    const valorUnitario =
      product.valor_unitario !== null && product.valor_unitario !== undefined
        ? product.valor_unitario.toFixed(2)
        : '';
    this.productForm.patchValue({
      code: product.code,
      description: product.description,
      balance: product.balance,
      ncm: product.ncm ?? '',
      cfop_padrao_saida: product.cfop_padrao_saida,
      u_com: product.u_com,
      valor_unitario: valorUnitario,
      origem: product.origem,
      cst_icms: product.cst_icms,
      p_icms: product.p_icms.toFixed(2),
      cst_pis: product.cst_pis,
      cst_cofins: product.cst_cofins
    });
    this.editingProductId = product.id;
    this.showForm = true;
  }

  /**
   * Strips the optional fiscal fields that should be sent as null/omitted
   * (NCM as empty string, valor_unitario unset) so the backend treats
   * them as "not provided" rather than "explicitly empty/zero". The
   * backend rejects `valor_unitario: 0` via the positive constraint;
   * empty NCM passes the regex check because the validator skips
   * empty/whitespace input.
   *
   * Returns the intersection so a single helper serves both create
   * (where code/description/balance are required) and update (where
   * everything is optional). Form validators upstream guarantee
   * code/description/balance are present when createProduct is called.
   */
  private toRequestPayload(
    formValue: Record<string, unknown>
  ): CreateProductRequest & UpdateProductRequest {
    const out: Record<string, unknown> = { ...formValue };
    if (out['ncm'] === '' || out['ncm'] === null) {
      delete out['ncm'];
    }
    // Bug Sweep 2: valor_unitario and p_icms are now string-typed in
    // the form (text inputs preserve trailing zeros). Coerce back to
    // number for the wire — the backend DTO expects numeric.
    if (
      out['valor_unitario'] === null ||
      out['valor_unitario'] === '' ||
      out['valor_unitario'] === undefined
    ) {
      delete out['valor_unitario'];
    } else {
      const n = Number(out['valor_unitario']);
      out['valor_unitario'] = Number.isNaN(n) ? out['valor_unitario'] : n;
    }
    if (typeof out['p_icms'] === 'string' && out['p_icms'] !== '') {
      const n = Number(out['p_icms']);
      out['p_icms'] = Number.isNaN(n) ? out['p_icms'] : n;
    }
    return out as unknown as CreateProductRequest & UpdateProductRequest;
  }

  async deleteProduct(id: string): Promise<void> {
    const confirmed = await this.dialogService.confirmDelete('este produto');
    if (confirmed) {
      this.apiService
        .deleteProduct(id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.productsSignal.update(list => list.filter(p => p.id !== id));
            this.toast.success('Produto removido.');
            this.cdr.markForCheck();
          },
          error: err => {
            this.toast.error(this.extractError(err, 'Erro ao remover produto.'));
            this.cdr.markForCheck();
          }
        });
    }
  }

  formatBalance(balance: number): string {
    return balance.toLocaleString('pt-BR') + ' un';
  }

  get code() {
    return this.productForm.get('code');
  }
  get description() {
    return this.productForm.get('description');
  }
  get balance() {
    return this.productForm.get('balance');
  }
}
