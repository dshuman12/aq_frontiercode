import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

/**
 * Shell visual compartilhado pelas páginas de visitante (login, register,
 * activate, reset-password). Centraliza o card branco + branding +
 * background gradient para garantir consistência entre as cinco telas.
 */
@Component({
  selector: 'app-auth-shell',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './auth-shell.component.html',
  styleUrls: ['./auth-shell.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AuthShellComponent {
  @Input() title = '';
  @Input() subtitle = '';
}
