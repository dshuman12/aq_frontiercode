import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { BreadcrumbService } from '@app/shared/services/breadcrumb.service';
import { InvoiceDetailComponent } from './invoice-detail.component';

const baseInvoice = {
  id: 'inv-1',
  number: 42,
  status: 'OPEN',
  created_by: 'alice',
  total_amount: 250,
  created_at: '2026-05-06T10:00:00Z',
  items: [
    {
      id: 'it-1',
      product_id: 'p1',
      product_code: 'P-01',
      product_description: 'Item A',
      quantity: 2,
      unit_price: 50,
      subtotal: 100
    }
  ]
};

describe('InvoiceDetailComponent', () => {
  let fixture: ComponentFixture<InvoiceDetailComponent>;
  let component: InvoiceDetailComponent;
  let apiMock: {
    getInvoice: jest.Mock;
    createPrintJob: jest.Mock;
    getInvoicePrintStatus: jest.Mock;
  };
  let breadcrumbMock: { setLabel: jest.Mock };

  beforeEach(async () => {
    apiMock = {
      getInvoice: jest.fn().mockReturnValue(of({ success: true, data: baseInvoice, code: 200 })),
      createPrintJob: jest.fn(),
      getInvoicePrintStatus: jest.fn()
    };
    breadcrumbMock = { setLabel: jest.fn() };

    await TestBed.configureTestingModule({
      imports: [InvoiceDetailComponent, NoopAnimationsModule],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: ApiService, useValue: apiMock },
        { provide: BreadcrumbService, useValue: breadcrumbMock },
        // ActivatedRoute mock comes after provideRouter so it wins.
        {
          provide: ActivatedRoute,
          useValue: { params: of({ id: 'inv-1' }) }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(InvoiceDetailComponent);
    component = fixture.componentInstance;
  });

  it('loads the invoice on init and registers a breadcrumb label', () => {
    fixture.detectChanges();
    expect(apiMock.getInvoice).toHaveBeenCalledWith('inv-1');
    expect(component.invoice?.id).toBe('inv-1');
    expect(breadcrumbMock.setLabel).toHaveBeenCalledWith('inv-1', '42');
  });

  describe('Status / responsible / total helpers', () => {
    beforeEach(() => fixture.detectChanges());

    it('getStatus returns "Aberta" for OPEN/aberta', () => {
      component.invoice = { ...baseInvoice, status: 'OPEN' };
      expect(component.getStatus()).toBe('Aberta');
      component.invoice = { ...baseInvoice, status: 'aberta' };
      expect(component.getStatus()).toBe('Aberta');
    });

    it('getStatus returns "Fechada" for any other status', () => {
      component.invoice = { ...baseInvoice, status: 'CLOSED' };
      expect(component.getStatus()).toBe('Fechada');
    });

    it('getStatus returns "Fechada" when invoice is null (UI default)', () => {
      component.invoice = null;
      expect(component.getStatus()).toBe('Fechada');
    });

    it('getResponsible prefers responsible over created_by', () => {
      component.invoice = { ...baseInvoice, responsible: 'bob' };
      expect(component.getResponsible()).toBe('bob');
    });

    it('getResponsible falls back to created_by when responsible is missing', () => {
      component.invoice = { ...baseInvoice };
      expect(component.getResponsible()).toBe('alice');
    });

    it('getTotalValue prefers total_value, falls back to total_amount, then 0', () => {
      component.invoice = { ...baseInvoice, total_value: 500 };
      expect(component.getTotalValue()).toBe(500);

      component.invoice = { ...baseInvoice };
      expect(component.getTotalValue()).toBe(250);

      component.invoice = null;
      expect(component.getTotalValue()).toBe(0);
    });

    it('getItemSubtotal uses subtotal when present, else qty * price', () => {
      const item = { ...baseInvoice.items[0] };
      expect(component.getItemSubtotal(item)).toBe(100);

      const noSubtotal = { ...item, subtotal: 0 };
      expect(component.getItemSubtotal(noSubtotal)).toBe(2 * 50);
    });

    it('getProductLabel falls back through code → description → product_id', () => {
      const item = { ...baseInvoice.items[0] };
      expect(component.getProductLabel(item)).toBe('P-01');

      const noCode = { ...item, product_code: undefined };
      expect(component.getProductLabel(noCode)).toBe('Item A');

      const onlyId = { ...noCode, product_description: undefined };
      expect(component.getProductLabel(onlyId)).toBe('p1');
    });

    it('formatDate renders pt-BR locale', () => {
      expect(component.formatDate('2026-05-06T10:00:00Z')).toMatch(/06\/05\/2026/);
    });

    it('formatCurrency renders BRL', () => {
      expect(component.formatCurrency(1234.5)).toMatch(/1\.234,50/);
    });
  });

  describe('printAndClose flow', () => {
    beforeEach(() => fixture.detectChanges());

    it('does nothing when invoice is null', () => {
      component.invoice = null;
      component.printAndClose();
      expect(apiMock.createPrintJob).not.toHaveBeenCalled();
    });

    it('does nothing when already printing (re-entrance guard)', () => {
      component.isPrinting = true;
      component.printAndClose();
      expect(apiMock.createPrintJob).not.toHaveBeenCalled();
    });

    it('clears isPrinting on createPrintJob error', () => {
      const alertSpy = jest.spyOn(window, 'alert').mockImplementation(() => undefined);
      apiMock.createPrintJob.mockReturnValueOnce(throwError(() => new Error('fail')));
      component.printAndClose();
      expect(component.isPrinting).toBe(false);
      expect(alertSpy).toHaveBeenCalled();
      alertSpy.mockRestore();
    });
  });

  it('cleans up subscriptions in ngOnDestroy', () => {
    fixture.detectChanges();
    expect(() => fixture.destroy()).not.toThrow();
  });
});
