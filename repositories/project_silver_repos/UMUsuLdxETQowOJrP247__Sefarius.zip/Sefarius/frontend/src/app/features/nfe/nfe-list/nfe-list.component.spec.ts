import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { NFeListComponent } from './nfe-list.component';
import { NFeListItem } from '@app/shared/models/nfe.models';

function makeItems(n: number, prefix = 'a'): NFeListItem[] {
  return Array.from({ length: n }, (_, i) => ({
    chave: `${prefix}${String(i).padStart(43, '0')}`,
    lifecycle: 'AUTHORIZED',
    c_stat: '100',
    x_motivo: 'Autorizado o uso da NF-e',
    created_at: '2026-05-06T12:00:00Z',
    updated_at: '2026-05-06T12:00:00Z'
  }));
}

/**
 * Wraps a list of items in the new PaginatedResponse shape (introduced
 * 2026-05-08 along with numerical pagination). Old shape was a bare
 * array; new shape exposes total/limit/offset so the frontend can
 * render "1 2 3 ... N" page indicators.
 */
function paginatedOf(items: NFeListItem[], total = items.length, limit = 25, offset = 0) {
  return { items, total, limit, offset };
}

describe('NFeListComponent', () => {
  let fixture: ComponentFixture<NFeListComponent>;
  let component: NFeListComponent;
  let apiMock: { listNFe: jest.Mock };

  beforeEach(async () => {
    apiMock = { listNFe: jest.fn() };
    await TestBed.configureTestingModule({
      imports: [NFeListComponent, NoopAnimationsModule],
      providers: [
        { provide: ApiService, useValue: apiMock },
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(NFeListComponent);
    component = fixture.componentInstance;
  });

  it('truncateChave returns the input untouched when ≤16 chars', () => {
    expect(component.truncateChave('123')).toBe('123');
  });

  it('truncateChave keeps first/last 8 chars with ellipsis for long chaves', () => {
    const chave = '52260101010101000100550010000000011000000011';
    expect(component.truncateChave(chave)).toBe('52260101…00000011');
  });

  it('lifecycleClass derives a CSS class from the lifecycle', () => {
    expect(component.lifecycleClass('AUTHORIZED')).toBe('lc-authorized');
    expect(component.lifecycleClass('CANCELLED')).toBe('lc-cancelled');
  });

  it('lifecycleLabel translates each known lifecycle to PT-BR', () => {
    expect(component.lifecycleLabel('AUTHORIZED')).toBe('Autorizada');
    expect(component.lifecycleLabel('REJECTED')).toBe('Rejeitada');
    expect(component.lifecycleLabel('PENDING')).toBe('Pendente');
    expect(component.lifecycleLabel('CANCELLED')).toBe('Cancelada');
  });

  it('formatDate renders pt-BR locale, returns empty for falsy and the input for invalid', () => {
    expect(component.formatDate('')).toBe('');
    expect(component.formatDate('not-a-date')).toBe('not-a-date');
    const out = component.formatDate('2026-05-06T12:00:00Z');
    expect(out).toMatch(/06\/05\/2026/);
  });

  it('ngOnInit triggers a list call with the default page size and renders items on success', () => {
    apiMock.listNFe.mockReturnValue(
      of({ success: true, data: paginatedOf(makeItems(3), 3), code: 200 })
    );
    fixture.detectChanges();
    // Default pageSize is 25 (changed from 50 in 2026-05-08 along
    // with the introduction of <app-pagination>'s 25 default).
    expect(apiMock.listNFe).toHaveBeenCalledWith(25, 0);
    expect(component.items).toHaveLength(3);
    expect(component.loading).toBe(false);
    expect(component.errorMsg).toBeNull();
    // hasMore is now derived from totalCount vs currentPage*pageSize:
    // total=3, page=1, size=25 → 1*25 >= 3, so no more pages.
    expect(component.hasMore).toBe(false);
  });

  it('hasMore stays true when total exceeds the current page window', () => {
    // 50 items returned, but total=200 → there are more pages.
    apiMock.listNFe.mockReturnValue(
      of({ success: true, data: paginatedOf(makeItems(50), 200), code: 200 })
    );
    fixture.detectChanges();
    expect(component.hasMore).toBe(true);
  });

  it('next() advances offset by pageSize only when hasMore', () => {
    apiMock.listNFe.mockReturnValue(
      of({ success: true, data: paginatedOf(makeItems(25), 100), code: 200 })
    );
    fixture.detectChanges();

    apiMock.listNFe.mockReturnValueOnce(
      of({ success: true, data: paginatedOf(makeItems(25, 'b'), 100), code: 200 })
    );
    component.next();
    // pageSize=25 → next() calls load(25), so listNFe is invoked with (25, 25).
    expect(apiMock.listNFe).toHaveBeenLastCalledWith(25, 25);

    // No more pages after this: total=100, page=2*25=50, but the
    // response sets currentPage=2; hasMore is false when 2*25 >= 100.
    apiMock.listNFe.mockReturnValueOnce(
      of({ success: true, data: paginatedOf(makeItems(25), 50), code: 200 })
    );
    component.onPageChange(2); // total drops to 50 → page 2 is the last
    apiMock.listNFe.mockClear();
    component.next();
    expect(apiMock.listNFe).not.toHaveBeenCalled();
  });

  it('prev() decrements offset and clamps at 0', () => {
    apiMock.listNFe.mockReturnValue(
      of({ success: true, data: paginatedOf(makeItems(25), 200), code: 200 })
    );
    fixture.detectChanges();
    component.offset = 100; // synthetic jump (legacy spec setter)
    apiMock.listNFe.mockClear();

    apiMock.listNFe.mockReturnValueOnce(
      of({ success: true, data: paginatedOf(makeItems(25), 200), code: 200 })
    );
    component.prev();
    expect(apiMock.listNFe).toHaveBeenLastCalledWith(25, 75);

    component.offset = 0;
    apiMock.listNFe.mockClear();
    component.prev();
    expect(apiMock.listNFe).not.toHaveBeenCalled();
  });

  it('renders the "Nova NF-e" link pointing to /nfe/new', () => {
    apiMock.listNFe.mockReturnValue(of({ success: true, data: paginatedOf([], 0), code: 200 }));
    fixture.detectChanges();
    const link = fixture.nativeElement.querySelector('a.btn-new-nfe') as HTMLAnchorElement;
    expect(link).not.toBeNull();
    expect(link.textContent).toContain('Nova NF-e');
    expect(link.getAttribute('href')).toBe('/nfe/new');
  });

  it('exposes a helpful errorMsg on API failure', () => {
    apiMock.listNFe.mockReturnValue(
      throwError(() => ({ status: 500, error: { error: 'serv off' } }))
    );
    fixture.detectChanges();
    expect(component.errorMsg).toBe('serv off');
    expect(component.loading).toBe(false);
  });
});
