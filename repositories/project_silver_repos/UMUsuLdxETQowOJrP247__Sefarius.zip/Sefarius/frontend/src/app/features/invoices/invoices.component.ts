import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  computed,
  signal,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { ApiService } from '@app/shared/services/api.service';
import { DialogService } from '@app/shared/services/dialog.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { Invoice, Product } from '@app/shared/models/api.models';
import { APP_CONSTANTS } from '@app/shared/constants/app.constants';
import { forkJoin } from 'rxjs';
import { takeUntil, retry } from 'rxjs/operators';
import { InvoicesViewService } from './invoices-view.service';
import { PaginationComponent } from '@app/shared/components/pagination/pagination.component';

interface InvoiceItemEntry {
  product_id: string;
  quantity: number;
  unit_price: number;
  product_code?: string;
}

type InvoiceSortKey = 'number' | 'created_at' | 'total_amount' | 'status';
type SortDir = 'asc' | 'desc';

@Component({
  selector: 'app-invoices',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ReactiveFormsModule, PaginationComponent],
  templateUrl: './invoices.component.html',
  styleUrl: './invoices.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InvoicesComponent extends BaseComponent implements OnInit {
  // Signals power the toolbar (search + sort + view) so the template
  // can react via OnPush + signal-driven CD without manual markForCheck
  // per state change. The legacy `invoices`/`products` arrays stay as
  // regular fields (loaded once) to avoid touching the existing form
  // flow that still uses cdr.markForCheck.
  readonly invoicesSignal = signal<Invoice[]>([]);
  products: Product[] = [];
  showNewInvoiceForm = false;
  invoiceForm: FormGroup;
  itemForm: FormGroup;
  invoiceItems: InvoiceItemEntry[] = [];

  // Toolbar state — same shape products uses.
  readonly searchTerm = signal<string>('');
  readonly sortKey = signal<InvoiceSortKey>('created_at');
  readonly sortDir = signal<SortDir>('desc');
  readonly viewService = inject(InvoicesViewService);

  // ─── Pagination state ────────────────────────────────────────────
  // Server-side numerical pagination. Invoices doesn't have a /q=
  // search endpoint (unlike Products), so search filters within the
  // currently loaded page only — limitation acceptable until the
  // catalog grows past a few hundred. The subtitle line in the
  // template hints that the filter is local when applicable.
  readonly currentPage = signal(1);
  readonly pageSize = signal(25);
  readonly totalCount = signal(0);

  /**
   * displayedInvoices = filter(searchTerm) → sort(sortKey, sortDir).
   * Recomputes via computed() whenever any input signal changes; cheap
   * for typical invoice counts (< 10k rows).
   */
  readonly displayedInvoices = computed<Invoice[]>(() => {
    const term = this.searchTerm().trim().toLowerCase();
    const key = this.sortKey();
    const dir = this.sortDir();
    let list = this.invoicesSignal();
    if (term) {
      list = list.filter(inv => {
        const number = String(inv.number ?? '').toLowerCase();
        const responsible = (inv.created_by ?? '').toLowerCase();
        return number.includes(term) || responsible.includes(term);
      });
    }
    const sorted = [...list].sort((a, b) => {
      const av = this.sortValue(a, key);
      const bv = this.sortValue(b, key);
      if (av < bv) {
        return dir === 'asc' ? -1 : 1;
      }
      if (av > bv) {
        return dir === 'asc' ? 1 : -1;
      }
      return 0;
    });
    return sorted;
  });

  constructor(
    private apiService: ApiService,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private dialogService: DialogService
  ) {
    super();
    this.invoiceForm = this.fb.group({
      created_by: ['', Validators.required]
    });
    this.itemForm = this.fb.group({
      product_id: ['', Validators.required],
      quantity: [1, [Validators.required, Validators.min(1)]],
      unit_price: [0, [Validators.required, Validators.min(0.01)]]
    });
  }

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    const size = this.pageSize();
    const offset = (this.currentPage() - 1) * size;
    forkJoin([
      this.apiService.getInvoices(size, offset).pipe(retry(1)),
      this.apiService.getProducts(200, 0).pipe(retry(1))
    ])
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: ([invoicesResp, productsResp]) => {
          if (invoicesResp.data) {
            this.invoicesSignal.set(invoicesResp.data.items ?? []);
            this.totalCount.set(invoicesResp.data.total ?? 0);
          }
          if (productsResp.data?.items) {
            this.products = productsResp.data.items;
          }
          this.cdr.markForCheck();
        },
        error: () => {
          this.cdr.markForCheck();
        }
      });
  }

  // ─── Pagination handlers ─────────────────────────────────────────

  onPageChange(page: number): void {
    this.currentPage.set(page);
    this.loadData();
  }

  onPageSizeChange(size: number): void {
    this.pageSize.set(size);
    this.currentPage.set(1);
    this.loadData();
  }

  // ─── Toolbar handlers ─────────────────────────────────────────────

  onSearchInput(value: string): void {
    this.searchTerm.set(value ?? '');
  }

  setSort(key: InvoiceSortKey): void {
    if (this.sortKey() === key) {
      this.sortDir.set(this.sortDir() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortKey.set(key);
      // First click on a fresh column: ascending for text, descending
      // for date/number — matches the convention products uses.
      this.sortDir.set(key === 'created_at' || key === 'total_amount' ? 'desc' : 'asc');
    }
  }

  setViewMode(mode: 'grid' | 'list' | 'table'): void {
    this.viewService.setMode(mode);
  }

  sortIndicator(key: InvoiceSortKey): string {
    if (this.sortKey() !== key) {
      return '';
    }
    return this.sortDir() === 'asc' ? '▲' : '▼';
  }

  trackById(_index: number, invoice: Invoice): string {
    return invoice.id;
  }

  private sortValue(invoice: Invoice, key: InvoiceSortKey): string | number {
    switch (key) {
      case 'number':
        return invoice.number ?? 0;
      case 'created_at':
        return invoice.created_at ? new Date(invoice.created_at).getTime() : 0;
      case 'total_amount':
        return invoice.total_amount ?? 0;
      case 'status':
        return (invoice.status ?? '').toLowerCase();
    }
  }

  toggleNewInvoice(): void {
    this.showNewInvoiceForm = !this.showNewInvoiceForm;
    if (!this.showNewInvoiceForm) {
      this.invoiceForm.reset();
      this.itemForm.reset({ quantity: 1, unit_price: 0 });
      this.invoiceItems = [];
    }
  }

  addItem(): void {
    if (this.itemForm.valid) {
      const product = this.products.find(p => p.id === this.itemForm.value.product_id);
      this.invoiceItems.push({ ...this.itemForm.value, product_code: product?.code });
      this.itemForm.reset({ quantity: 1, unit_price: 0 });
      this.cdr.markForCheck();
    }
  }

  removeItem(index: number): void {
    this.invoiceItems.splice(index, 1);
    this.cdr.markForCheck();
  }

  calculateTotal(): number {
    return this.invoiceItems.reduce((total, item) => total + item.quantity * item.unit_price, 0);
  }

  submitInvoice(): void {
    if (!this.invoiceForm.valid || this.invoiceItems.length === 0) {
      return;
    }
    const payload = {
      created_by: this.invoiceForm.value.created_by,
      items: this.invoiceItems.map(item => ({
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price
      }))
    };
    this.apiService
      .createInvoice(payload)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.toggleNewInvoice();
          this.loadData();
        },
        error: () => {
          this.cdr.markForCheck();
        }
      });
  }

  async deleteInvoice(id: string): Promise<void> {
    const confirmed = await this.dialogService.confirmDelete('esta nota fiscal');
    if (confirmed) {
      this.apiService
        .deleteInvoice(id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: () => {
            this.invoicesSignal.update(list => list.filter(i => i.id !== id));
            this.cdr.markForCheck();
          },
          error: () => {
            this.cdr.markForCheck();
          }
        });
    }
  }

  getInvoiceStatus(invoice: Invoice): string {
    const s = invoice.status?.toLowerCase();
    if (s === APP_CONSTANTS.INVOICE_STATUS.OPEN || s === APP_CONSTANTS.INVOICE_STATUS.ABERTA) {
      return APP_CONSTANTS.INVOICE_STATUS.DISPLAY.OPEN;
    }
    return APP_CONSTANTS.INVOICE_STATUS.DISPLAY.CLOSED;
  }

  getInvoiceValue(invoice: Invoice): string {
    const val = invoice.total_amount ?? 0;
    return this.formatCurrency(val);
  }

  getResponsible(invoice: Invoice): string {
    return invoice.created_by || '';
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('pt-BR');
  }
}
