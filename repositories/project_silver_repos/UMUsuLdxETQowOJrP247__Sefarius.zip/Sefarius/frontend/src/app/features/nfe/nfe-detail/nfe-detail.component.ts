import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { forkJoin, of } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';

import { ApiService } from '@app/shared/services/api.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { EventResponse, NFeLifecycle, NFeRecord } from '@app/shared/models/nfe.models';
import {
  CancelNFeDialogComponent,
  CancelNFeDialogResult
} from '../dialogs/cancel-nfe-dialog.component';
import { CCeDialogComponent, CCeDialogResult } from '../dialogs/cce-dialog.component';

interface ActionFeedback {
  kind: 'success' | 'error';
  text: string;
}

/**
 * Indents XML emitted as a single line (Go encoding/xml output) into a
 * 2-space tree. Splits on adjacent tags `><`, then walks the resulting
 * lines tracking depth from open/close shape — works for NFe XML which
 * is element-only with no significant whitespace. Self-closing tags and
 * the `<?xml ?>` declaration do not change depth.
 */
export function prettyPrintXml(xml: string): string {
  const split = xml.replace(/>\s*</g, '>\n<');
  let depth = 0;
  return split
    .split('\n')
    .map(line => {
      const trimmed = line.trim();
      if (!trimmed) {
        return '';
      }
      const isClosing = /^<\//.test(trimmed);
      const isXmlDecl = /^<\?/.test(trimmed);
      const isSelfClosing = /\/>$/.test(trimmed);
      const isLeafTextNode = /^<[^/?][^>]*>[^<]+<\/[^>]+>$/.test(trimmed);
      if (isClosing) {
        depth = Math.max(0, depth - 1);
      }
      const indented = '  '.repeat(depth) + trimmed;
      if (!isClosing && !isXmlDecl && !isSelfClosing && !isLeafTextNode) {
        depth++;
      }
      return indented;
    })
    .filter(line => line.length > 0)
    .join('\n');
}

@Component({
  selector: 'app-nfe-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, MatTabsModule],
  templateUrl: './nfe-detail.component.html',
  styleUrls: ['./nfe-detail.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NFeDetailComponent extends BaseComponent implements OnInit {
  chave = '';
  loading = true;
  errorMsg: string | null = null;

  record: NFeRecord | null = null;
  cancel: EventResponse | null = null;
  cceList: EventResponse[] = [];

  danfeUrl: SafeResourceUrl | null = null;
  xml: string | null = null;
  xmlLoading = false;

  submitting = false;
  feedback: ActionFeedback | null = null;

  constructor(
    private apiService: ApiService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private dialog: MatDialog
  ) {
    super();
  }

  get canCancel(): boolean {
    return this.record?.lifecycle === 'AUTHORIZED' && !this.cancel && !this.submitting;
  }

  get canSendCCe(): boolean {
    return this.record?.lifecycle === 'AUTHORIZED' && !this.submitting;
  }

  get nextCCeSeq(): number {
    if (this.cceList.length === 0) {
      return 1;
    }
    return Math.max(...this.cceList.map(c => c.seq)) + 1;
  }

  ngOnInit(): void {
    this.chave = this.route.snapshot.paramMap.get('chave') ?? '';
    if (!this.chave) {
      this.errorMsg = 'Chave não informada';
      this.loading = false;
      return;
    }
    this.danfeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.apiService.nfeDanfeUrl(this.chave)
    );
    this.loadRecord();
  }

  private loadRecord(): void {
    this.apiService
      .getNFe(this.chave)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          this.record = resp.data ?? null;
          this.loading = false;
          this.loadEvents();
          this.cdr.markForCheck();
        },
        error: err => {
          this.errorMsg =
            err?.status === 404
              ? 'NF-e não encontrada'
              : err?.error?.error || err?.message || 'Erro ao carregar NF-e';
          this.loading = false;
          this.cdr.markForCheck();
        }
      });
  }

  private loadEvents(): void {
    // Each branch must catchError independently. forkJoin aborts on the
    // first source error and skips `next` for ALL sources — so a 404
    // from /cancel (the normal "no cancel registered" state for an
    // AUTHORIZED NFe) was previously hiding a successfully-loaded CCe
    // list. Mapping each error to a benign default keeps both fetches
    // observable on their own merits.
    forkJoin({
      cancel: this.apiService.getCancel(this.chave).pipe(
        catchError(() =>
          of({ success: false, data: null, code: 0 } as {
            success: boolean;
            data: EventResponse | null;
            code: number;
          })
        )
      ),
      cce: this.apiService
        .listCCe(this.chave)
        .pipe(catchError(() => of({ success: false, data: [] as EventResponse[], code: 0 })))
    })
      .pipe(takeUntil(this.destroy$))
      .subscribe(({ cancel, cce }) => {
        this.cancel = cancel.data ?? null;
        this.cceList = cce.data ?? [];
        this.cdr.markForCheck();
      });
  }

  loadXml(): void {
    if (this.xml !== null || this.xmlLoading) {
      return;
    }
    this.xmlLoading = true;
    this.cdr.markForCheck();
    this.http
      .get(this.apiService.nfeXMLUrl(this.chave), { responseType: 'text' })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: text => {
          this.xml = prettyPrintXml(text);
          this.xmlLoading = false;
          this.cdr.markForCheck();
        },
        error: err => {
          this.xml = `# erro ao carregar XML: ${err?.message || err}`;
          this.xmlLoading = false;
          this.cdr.markForCheck();
        }
      });
  }

  onTabChange(index: number): void {
    if (index === 1) {
      this.loadXml();
    }
  }

  lifecycleClass(lifecycle: NFeLifecycle | undefined): string {
    return lifecycle ? `lc-${lifecycle.toLowerCase()}` : '';
  }

  lifecycleLabel(lifecycle: NFeLifecycle | undefined): string {
    switch (lifecycle) {
      case 'AUTHORIZED':
        return 'Autorizada';
      case 'REJECTED':
        return 'Rejeitada';
      case 'PENDING':
        return 'Pendente';
      case 'CANCELLED':
        return 'Cancelada';
      default:
        return '—';
    }
  }

  formatDate(iso: string | undefined): string {
    if (!iso) {
      return '';
    }
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? iso : d.toLocaleString('pt-BR');
  }

  danfeRawUrl(): string {
    return this.apiService.nfeDanfeUrl(this.chave);
  }

  xmlRawUrl(): string {
    return this.apiService.nfeXMLUrl(this.chave);
  }

  cancelPDFUrl(): string {
    return this.apiService.cancelPDFUrl(this.chave);
  }

  cancelXMLUrl(): string {
    return this.apiService.cancelXMLUrl(this.chave);
  }

  ccePDFUrl(seq: number): string {
    return this.apiService.ccePDFUrl(this.chave, seq);
  }

  cceXMLUrl(seq: number): string {
    return this.apiService.cceXMLUrl(this.chave, seq);
  }

  openCancelDialog(): void {
    if (!this.canCancel) {
      return;
    }
    const ref = this.dialog.open<
      CancelNFeDialogComponent,
      { chave: string },
      CancelNFeDialogResult | null
    >(CancelNFeDialogComponent, {
      width: '520px',
      data: { chave: this.chave }
    });
    ref.afterClosed().subscribe(result => {
      if (result) {
        this.submitCancel(result.justification);
      }
    });
  }

  openCCeDialog(): void {
    if (!this.canSendCCe) {
      return;
    }
    const ref = this.dialog.open<
      CCeDialogComponent,
      { chave: string; nextSeq: number },
      CCeDialogResult | null
    >(CCeDialogComponent, {
      width: '560px',
      data: { chave: this.chave, nextSeq: this.nextCCeSeq }
    });
    ref.afterClosed().subscribe(result => {
      if (result) {
        this.submitCCe(result.correction, result.seq);
      }
    });
  }

  private submitCancel(justification: string): void {
    this.submitting = true;
    this.feedback = null;
    this.cdr.markForCheck();

    this.apiService
      .cancelNFe(this.chave, { justification })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          const ev = resp.data;
          this.submitting = false;
          if (ev?.status === 'ACCEPTED') {
            this.feedback = {
              kind: 'success',
              text: `Cancelamento aceito (cStat ${ev.c_stat} — ${ev.x_motivo}).`
            };
            this.loadRecord();
          } else {
            this.feedback = {
              kind: 'error',
              text: this.formatRejection('Cancelamento rejeitado', ev)
            };
          }
          this.cdr.markForCheck();
        },
        error: err => {
          this.submitting = false;
          this.feedback = { kind: 'error', text: this.formatHttpError(err) };
          this.cdr.markForCheck();
        }
      });
  }

  private submitCCe(correction: string, seq: number): void {
    this.submitting = true;
    this.feedback = null;
    this.cdr.markForCheck();

    this.apiService
      .sendCCe(this.chave, { correction, seq })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          const ev = resp.data;
          this.submitting = false;
          if (ev?.status === 'ACCEPTED') {
            this.feedback = {
              kind: 'success',
              text: `CCe #${ev.seq} aceita (cStat ${ev.c_stat} — ${ev.x_motivo}).`
            };
            this.loadEvents();
          } else {
            this.feedback = {
              kind: 'error',
              text: this.formatRejection(`CCe #${seq} rejeitada`, ev)
            };
          }
          this.cdr.markForCheck();
        },
        error: err => {
          this.submitting = false;
          this.feedback = { kind: 'error', text: this.formatHttpError(err) };
          this.cdr.markForCheck();
        }
      });
  }

  private formatRejection(prefix: string, ev: EventResponse | undefined): string {
    if (!ev) {
      return prefix;
    }
    const cStat = ev.rejection?.CStat ?? ev.c_stat;
    const motivo = ev.rejection?.XMotivo ?? ev.x_motivo;
    const hint = sefazHint(cStat);
    return `${prefix}: cStat ${cStat} — ${motivo}${hint ? ` (${hint})` : ''}`;
  }

  private formatHttpError(err: unknown): string {
    const e = err as { status?: number; error?: { error?: string }; message?: string };
    if (e?.status === 502) {
      return 'SEFAZ indisponível. Tente novamente em alguns instantes.';
    }
    if (e?.status === 422) {
      return e.error?.error || 'Dados do evento inválidos.';
    }
    return e?.error?.error || e?.message || 'Erro ao submeter evento.';
  }

  dismissFeedback(): void {
    this.feedback = null;
    this.cdr.markForCheck();
  }
}

function sefazHint(cStat: string): string {
  switch (cStat) {
    case '218':
    case '501':
      return 'NF-e já cancelada';
    case '220':
      return 'prazo de cancelamento (24h) expirado';
    case '228':
      return 'data do evento posterior à data atual';
    case '490':
      return 'rejeição por validação de integridade';
    case '573':
      return 'evento duplicado';
    case '108':
    case '109':
    case '110':
      return 'serviço SEFAZ paralisado';
    default:
      return '';
  }
}
