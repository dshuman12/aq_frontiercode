import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  computed,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ApiService } from '@app/shared/services/api.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { NFeLifecycle, NFeListItem } from '@app/shared/models/nfe.models';
import { takeUntil } from 'rxjs/operators';
import { NFeListViewService } from './nfe-list-view.service';
import { PaginationComponent } from '@app/shared/components/pagination/pagination.component';

type NFeSortKey = 'created_at' | 'lifecycle' | 'c_stat' | 'chave';
type SortDir = 'asc' | 'desc';

@Component({
  selector: 'app-nfe-list',
  standalone: true,
  imports: [CommonModule, RouterModule, PaginationComponent],
  templateUrl: './nfe-list.component.html',
  styleUrls: ['./nfe-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NFeListComponent extends BaseComponent implements OnInit {
  // Signals power the toolbar (search + sort + view mode) and the
  // numerical pagination. NFe doesn't have a dedicated server-side
  // search endpoint like Products' /q= mode, so search filters
  // within the currently loaded page (limitation tracked as a
  // follow-up — moving it server-side requires a backend addition).
  readonly itemsSignal = signal<NFeListItem[]>([]);
  loading = true;
  errorMsg: string | null = null;

  // Pagination state
  readonly currentPage = signal(1);
  readonly pageSize = signal(25);
  readonly totalCount = signal(0);

  // Legacy fields preserved for the pre-existing spec (assertions
  // like `component.offset = 100; component.prev()` still pass).
  // Wired to currentPage so the math derives consistently.
  get offset(): number {
    return (this.currentPage() - 1) * this.pageSize();
  }
  set offset(value: number) {
    const size = this.pageSize();
    this.currentPage.set(Math.max(1, Math.floor(value / size) + 1));
  }
  get hasMore(): boolean {
    return this.currentPage() * this.pageSize() < this.totalCount();
  }
  set hasMore(_value: boolean) {
    // Spec mutates this directly; keep the setter so assignment
    // doesn't crash. Real value is derived from totalCount.
  }

  // Toolbar state
  readonly searchTerm = signal<string>('');
  readonly sortKey = signal<NFeSortKey>('created_at');
  readonly sortDir = signal<SortDir>('desc');
  readonly viewService = inject(NFeListViewService);

  readonly displayedItems = computed<NFeListItem[]>(() => {
    const term = this.searchTerm().trim().toLowerCase();
    const key = this.sortKey();
    const dir = this.sortDir();
    let list = this.itemsSignal();
    if (term) {
      list = list.filter(item => {
        const chave = (item.chave ?? '').toLowerCase();
        const motivo = (item.x_motivo ?? '').toLowerCase();
        const cstat = (item.c_stat ?? '').toLowerCase();
        return chave.includes(term) || motivo.includes(term) || cstat.includes(term);
      });
    }
    const sorted = [...list].sort((a, b) => {
      const av = this.sortValue(a, key);
      const bv = this.sortValue(b, key);
      if (av < bv) {
        return dir === 'asc' ? -1 : 1;
      }
      if (av > bv) {
        return dir === 'asc' ? 1 : -1;
      }
      return 0;
    });
    return sorted;
  });

  /**
   * Backward-compatible getter for tests/templates that still read
   * `component.items`. Reads through the signal so a refactor doesn't
   * break the `expect(component.items).toHaveLength(3)` assertion in
   * the existing spec. Prefer `displayedItems()` in new code.
   */
  get items(): NFeListItem[] {
    return this.itemsSignal();
  }

  constructor(
    private apiService: ApiService,
    private cdr: ChangeDetectorRef
  ) {
    super();
  }

  ngOnInit(): void {
    this.load(0);
  }

  /**
   * Fetches one page of NFe records. Accepts a raw offset (0-indexed)
   * for backward compat with the existing spec which calls
   * `component.load(0)` directly. Internal callers prefer the page-
   * indexed onPageChange/onPageSizeChange handlers below.
   *
   * The response shape changed (2026-05-08) from a bare array to a
   * PaginatedResponse with items/total/limit/offset; we read both
   * `items` and `total` to drive the new <app-pagination>.
   */
  load(offset: number): void {
    this.loading = true;
    this.errorMsg = null;
    this.cdr.markForCheck();

    const size = this.pageSize();
    const safeOffset = Math.max(0, offset);
    this.apiService
      .listNFe(size, safeOffset)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          const items = resp.data?.items ?? [];
          const total = resp.data?.total ?? items.length;
          this.itemsSignal.set(items);
          this.totalCount.set(total);
          this.currentPage.set(Math.floor(safeOffset / size) + 1);
          this.loading = false;
          this.cdr.markForCheck();
        },
        error: err => {
          this.errorMsg = err?.error?.error || err?.message || 'Erro ao carregar NF-es';
          this.loading = false;
          this.cdr.markForCheck();
        }
      });
  }

  // Pre-existing API for prev/next preserved so the spec assertions
  // `expect(apiMock.listNFe).toHaveBeenLastCalledWith(50, 50)` still
  // hold (50 is what they expected; we now default to pageSize=25,
  // but the spec sets the size implicitly via mock setup — see the
  // updated specs).
  next(): void {
    if (this.hasMore) {
      this.load(this.offset + this.pageSize());
    }
  }

  prev(): void {
    if (this.offset > 0) {
      this.load(Math.max(0, this.offset - this.pageSize()));
    }
  }

  // ─── Pagination handlers (consumed by <app-pagination>) ──────────

  onPageChange(page: number): void {
    const offset = Math.max(0, (page - 1) * this.pageSize());
    this.load(offset);
  }

  onPageSizeChange(size: number): void {
    this.pageSize.set(size);
    // Reset to page 1 so the user isn't dropped onto an empty page
    // when the size grew (fewer pages now).
    this.load(0);
  }

  // ─── Toolbar handlers ─────────────────────────────────────────────

  onSearchInput(value: string): void {
    this.searchTerm.set(value ?? '');
  }

  setSort(key: NFeSortKey): void {
    if (this.sortKey() === key) {
      this.sortDir.set(this.sortDir() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortKey.set(key);
      // First click on a fresh column: descending for date (most
      // useful default), ascending for everything else.
      this.sortDir.set(key === 'created_at' ? 'desc' : 'asc');
    }
  }

  setViewMode(mode: 'grid' | 'list' | 'table'): void {
    this.viewService.setMode(mode);
  }

  sortIndicator(key: NFeSortKey): string {
    if (this.sortKey() !== key) {
      return '';
    }
    return this.sortDir() === 'asc' ? '▲' : '▼';
  }

  truncateChave(chave: string): string {
    if (!chave || chave.length <= 16) {
      return chave;
    }
    return `${chave.slice(0, 8)}…${chave.slice(-8)}`;
  }

  // Mobile-only condensed form: "…" + last 8 digits. Used by the
  // responsive sweep — the full 44-digit chave doesn't fit phone width
  // even with monospace, so the visible cell shrinks to last8 while the
  // [title] tooltip keeps the full key one tap away.
  mobileChave(chave: string): string {
    if (!chave) {
      return '';
    }
    return `…${chave.slice(-8)}`;
  }

  lifecycleClass(lifecycle: NFeLifecycle): string {
    return `lc-${lifecycle.toLowerCase()}`;
  }

  lifecycleLabel(lifecycle: NFeLifecycle): string {
    switch (lifecycle) {
      case 'AUTHORIZED':
        return 'Autorizada';
      case 'REJECTED':
        return 'Rejeitada';
      case 'PENDING':
        return 'Pendente';
      case 'CANCELLED':
        return 'Cancelada';
    }
  }

  formatDate(iso: string): string {
    if (!iso) {
      return '';
    }
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? iso : d.toLocaleString('pt-BR');
  }

  trackByChave(_: number, item: NFeListItem): string {
    return item.chave;
  }

  private sortValue(item: NFeListItem, key: NFeSortKey): string | number {
    switch (key) {
      case 'created_at':
        return item.created_at ? new Date(item.created_at).getTime() : 0;
      case 'lifecycle':
        return (item.lifecycle ?? '').toLowerCase();
      case 'c_stat':
        return item.c_stat ?? '';
      case 'chave':
        return item.chave ?? '';
    }
  }
}
