import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService, AuthUser } from '@app/shared/services/auth.service';

type Tab = 'name' | 'password';

interface PasswordRule {
  label: string;
  test: (p: string) => boolean;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileComponent implements OnInit {
  user = signal<AuthUser | null>(null);
  activeTab = signal<Tab>('name');
  loading = signal(false);
  message = signal('');
  errorMsg = signal('');
  showOldPassword = signal(false);
  showNewPassword = signal(false);
  showConfirmation = signal(false);

  nameForm = { name: '' };
  passForm = { oldPassword: '', newPassword: '', confirmation: '' };

  readonly passwordRules: PasswordRule[] = [
    { label: '8+ caracteres', test: p => p.length >= 8 },
    { label: '1 maiúscula', test: p => /[A-Z]/.test(p) },
    { label: '1 minúscula', test: p => /[a-z]/.test(p) },
    { label: '1 número', test: p => /\d/.test(p) }
  ];

  constructor(
    private auth: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.user.set(this.auth.currentUser);
    this.nameForm.name = this.auth.currentUser?.name || '';
  }

  setTab(tab: Tab): void {
    this.activeTab.set(tab);
    this.message.set('');
    this.errorMsg.set('');
  }

  initial(): string {
    return this.user()?.name?.charAt(0)?.toUpperCase() || 'U';
  }

  toggleOldPassword(): void {
    this.showOldPassword.update(v => !v);
  }

  toggleNewPassword(): void {
    this.showNewPassword.update(v => !v);
  }

  toggleConfirmation(): void {
    this.showConfirmation.update(v => !v);
  }

  ruleMet(rule: PasswordRule): boolean {
    return rule.test(this.passForm.newPassword);
  }

  private clear(): void {
    this.message.set('');
    this.errorMsg.set('');
  }

  saveName(): void {
    this.clear();
    this.loading.set(true);
    this.auth.changeName(this.nameForm.name).subscribe({
      next: u => {
        this.user.set(u);
        this.message.set('Nome atualizado com sucesso!');
        this.loading.set(false);
        this.cdr.markForCheck();
      },
      error: err => {
        this.errorMsg.set(err?.message || 'Erro ao atualizar nome.');
        this.loading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  savePassword(): void {
    this.clear();
    if (this.passForm.newPassword !== this.passForm.confirmation) {
      this.errorMsg.set('As senhas não coincidem.');
      return;
    }
    this.loading.set(true);
    this.auth
      .changePassword(
        this.passForm.oldPassword,
        this.passForm.newPassword,
        this.passForm.confirmation
      )
      .subscribe({
        next: () => {
          this.message.set('Senha alterada com sucesso!');
          this.passForm = { oldPassword: '', newPassword: '', confirmation: '' };
          this.loading.set(false);
          this.cdr.markForCheck();
        },
        error: err => {
          this.errorMsg.set(err?.message || 'Erro ao alterar senha.');
          this.loading.set(false);
          this.cdr.markForCheck();
        }
      });
  }
}
