import { TestBed } from '@angular/core/testing';
import { ProductsViewService } from './products-view.service';

const STORAGE_KEY = 'sefarius:products:viewMode';

describe('ProductsViewService', () => {
  beforeEach(() => {
    localStorage.removeItem(STORAGE_KEY);
    TestBed.resetTestingModule();
  });

  function makeService(): ProductsViewService {
    TestBed.configureTestingModule({});
    return TestBed.inject(ProductsViewService);
  }

  it('defaults to grid when localStorage is empty', () => {
    const svc = makeService();
    expect(svc.preferred()).toBe('grid');
    expect(svc.mode()).toBe('grid');
  });

  it('hydrates from localStorage on construction', () => {
    localStorage.setItem(STORAGE_KEY, 'table');
    const svc = makeService();
    expect(svc.preferred()).toBe('table');
  });

  it('ignores invalid values in localStorage', () => {
    localStorage.setItem(STORAGE_KEY, 'cubist');
    const svc = makeService();
    expect(svc.preferred()).toBe('grid');
  });

  it('persists the chosen mode to localStorage', () => {
    const svc = makeService();
    svc.setMode('list');
    // Effect runs synchronously inside Angular's signal scheduler
    // during change detection, so we trigger a flush by reading the
    // signal value back. setItem is invoked.
    TestBed.flushEffects();
    expect(localStorage.getItem(STORAGE_KEY)).toBe('list');
  });

  it('falls back to "list" on mobile when preferred is "table"', () => {
    const svc = makeService();
    svc.setMode('table');
    expect(svc.mode()).toBe('table');
    svc.__setMobileForTesting(true);
    expect(svc.mode()).toBe('list');
    // Preferred is preserved — flipping back to desktop restores it.
    expect(svc.preferred()).toBe('table');
    svc.__setMobileForTesting(false);
    expect(svc.mode()).toBe('table');
  });

  it('does not force "list" on mobile when user already chose grid/list', () => {
    const svc = makeService();
    svc.__setMobileForTesting(true);
    svc.setMode('grid');
    expect(svc.mode()).toBe('grid');
    svc.setMode('list');
    expect(svc.mode()).toBe('list');
  });

  it('rejects unknown modes via setMode (defensive)', () => {
    const svc = makeService();
    svc.setMode('grid');
    // Cast to bypass the type system to simulate a regression that
    // tries to feed in a stale string value.
    svc.setMode('mosaic' as unknown as 'grid');
    expect(svc.preferred()).toBe('grid');
  });

  it('does not crash when localStorage is unavailable', () => {
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = jest.fn(() => {
      throw new Error('quota');
    });
    expect(() => {
      const svc = makeService();
      svc.setMode('table');
      TestBed.flushEffects();
    }).not.toThrow();
    Storage.prototype.setItem = original;
  });
});
