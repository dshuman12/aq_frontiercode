import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '@app/shared/services/api.service';
import { BreadcrumbService } from '@app/shared/services/breadcrumb.service';
import { Subject, timer, Subscription } from 'rxjs';
import { takeUntil, switchMap } from 'rxjs/operators';

interface Invoice {
  id: string;
  number: number;
  status: string;
  created_by: string;
  responsible?: string;
  total_amount: number;
  total_value?: number;
  created_at: string;
  items: InvoiceItem[];
}

interface InvoiceItem {
  id: string;
  product_id: string;
  product_code?: string;
  product_description?: string;
  quantity: number;
  unit_price: number;
  subtotal: number;
}

@Component({
  selector: 'app-invoice-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './invoice-detail.component.html',
  styleUrl: './invoice-detail.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InvoiceDetailComponent implements OnInit, OnDestroy {
  invoice: Invoice | null = null;
  isPrinting = false;
  private pollingSub?: Subscription;
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private apiService: ApiService,
    private cdr: ChangeDetectorRef,
    private breadcrumbService: BreadcrumbService
  ) {}

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      this.loadInvoice(params['id']);
    });
  }

  ngOnDestroy(): void {
    if (this.pollingSub) {
      this.pollingSub.unsubscribe();
    }
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadInvoice(id: string, onComplete?: () => void): void {
    this.apiService
      .getInvoice(id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: response => {
          if (response.data) {
            this.invoice = response.data;
            if (this.invoice.number) {
              this.breadcrumbService.setLabel(id, this.invoice.number.toString());
            }
          }
          this.cdr.markForCheck();
          if (onComplete) {
            onComplete();
          }
        }
      });
  }

  printAndClose(): void {
    if (!this.invoice || this.isPrinting) {
      return;
    }

    this.isPrinting = true;
    this.cdr.markForCheck();

    this.apiService
      .createPrintJob(this.invoice.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          // Iniciar polling para validar processamento do backend
          this.pollingSub = timer(1000, 2000)
            .pipe(
              switchMap(() => this.apiService.getInvoicePrintStatus(this.invoice!.id)),
              takeUntil(this.destroy$)
            )
            .subscribe({
              next: statusResp => {
                const status = statusResp.data?.status;
                if (status === 'COMPLETED') {
                  this.isPrinting = false;
                  this.pollingSub?.unsubscribe();
                  // Força o recarregamento pra buscar o novo 'status' como 'FECHADA' do banco de dados
                  // e dispara window.print() assim que a interface for atualizada.
                  this.loadInvoice(this.invoice!.id, () => {
                    setTimeout(() => {
                      window.print();
                    }, 150);
                  });
                } else if (status === 'FAILED') {
                  this.isPrinting = false;
                  this.pollingSub?.unsubscribe();
                  this.cdr.markForCheck();
                  alert('Ocorreu um erro ao imprimir a nota fiscal.');
                }
              },
              error: () => {
                this.isPrinting = false;
                this.pollingSub?.unsubscribe();
                this.cdr.markForCheck();
              }
            });
        },
        error: () => {
          this.isPrinting = false;
          this.cdr.markForCheck();
          alert('Erro na comunicação do fechamento da nota.');
        }
      });
  }

  getStatus(): string {
    const s = this.invoice?.status?.toLowerCase();
    if (s === 'open' || s === 'aberta') {
      return 'Aberta';
    }
    return 'Fechada';
  }

  getResponsible(): string {
    return this.invoice?.responsible || this.invoice?.created_by || '';
  }

  getTotalValue(): number {
    return this.invoice?.total_value ?? this.invoice?.total_amount ?? 0;
  }

  getItemSubtotal(item: InvoiceItem): number {
    return item.subtotal || item.quantity * item.unit_price;
  }

  getProductLabel(item: InvoiceItem): string {
    if (item.product_code) {
      return item.product_code;
    }
    if (item.product_description) {
      return item.product_description;
    }
    return item.product_id;
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('pt-BR');
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  }
}
