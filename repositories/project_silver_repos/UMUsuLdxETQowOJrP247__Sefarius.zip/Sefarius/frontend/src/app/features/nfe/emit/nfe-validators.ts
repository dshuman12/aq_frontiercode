import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Treats null, undefined, empty string, AND whitespace-only strings as
 * "no value entered" so optional fields and the empty branch of
 * destDocXor do not erroneously trigger format validators. Without
 * the trim() guard, a paste with trailing whitespace or a Tab into an
 * empty field followed by markAllAsTouched would surface "CPF
 * inválido" on a CPF the user never typed in.
 */
function isBlank(v: unknown): boolean {
  return v === null || v === undefined || (typeof v === 'string' && v.trim() === '');
}

export const UF_LIST: readonly { uf: string; c_uf: string; name: string }[] = [
  { uf: 'AC', c_uf: '12', name: 'Acre' },
  { uf: 'AL', c_uf: '27', name: 'Alagoas' },
  { uf: 'AM', c_uf: '13', name: 'Amazonas' },
  { uf: 'AP', c_uf: '16', name: 'Amapá' },
  { uf: 'BA', c_uf: '29', name: 'Bahia' },
  { uf: 'CE', c_uf: '23', name: 'Ceará' },
  { uf: 'DF', c_uf: '53', name: 'Distrito Federal' },
  { uf: 'ES', c_uf: '32', name: 'Espírito Santo' },
  { uf: 'GO', c_uf: '52', name: 'Goiás' },
  { uf: 'MA', c_uf: '21', name: 'Maranhão' },
  { uf: 'MG', c_uf: '31', name: 'Minas Gerais' },
  { uf: 'MS', c_uf: '50', name: 'Mato Grosso do Sul' },
  { uf: 'MT', c_uf: '51', name: 'Mato Grosso' },
  { uf: 'PA', c_uf: '15', name: 'Pará' },
  { uf: 'PB', c_uf: '25', name: 'Paraíba' },
  { uf: 'PE', c_uf: '26', name: 'Pernambuco' },
  { uf: 'PI', c_uf: '22', name: 'Piauí' },
  { uf: 'PR', c_uf: '41', name: 'Paraná' },
  { uf: 'RJ', c_uf: '33', name: 'Rio de Janeiro' },
  { uf: 'RN', c_uf: '24', name: 'Rio Grande do Norte' },
  { uf: 'RO', c_uf: '11', name: 'Rondônia' },
  { uf: 'RR', c_uf: '14', name: 'Roraima' },
  { uf: 'RS', c_uf: '43', name: 'Rio Grande do Sul' },
  { uf: 'SC', c_uf: '42', name: 'Santa Catarina' },
  { uf: 'SE', c_uf: '28', name: 'Sergipe' },
  { uf: 'SP', c_uf: '35', name: 'São Paulo' },
  { uf: 'TO', c_uf: '17', name: 'Tocantins' }
];

const UF_CODES = new Set(UF_LIST.map(u => u.uf));

export function cUfFor(uf: string): string {
  return UF_LIST.find(u => u.uf === uf)?.c_uf ?? '';
}

export const CFOP_INTERNA_WHITELIST: readonly { code: string; label: string }[] = [
  { code: '5101', label: '5101 — Venda de produção do estabelecimento' },
  { code: '5102', label: '5102 — Venda de mercadoria adquirida de terceiros' },
  { code: '5103', label: '5103 — Venda de produção, fora do estabelecimento' },
  { code: '5104', label: '5104 — Venda de mercadoria de terceiros, fora do estabelecimento' },
  { code: '5109', label: '5109 — Venda destinada à ZFM/ALC (produção própria)' },
  { code: '5110', label: '5110 — Venda destinada à ZFM/ALC (mercadoria de terceiros)' }
];

/**
 * CFOPs de SAÍDA INTERESTADUAL (6xxx) — operações entre UFs distintas.
 * Sprint Bug Sweep 2 (2026-05-07): antes só existia o whitelist 5xxx,
 * tornando emissão interestadual impossível pelo wizard. Mantemos os
 * mesmos 6 códigos paralelos da whitelist interna; o template escolhe
 * qual exibir com base em ide.id_dest (1 = interna → 5xxx, 2 =
 * interestadual → 6xxx).
 */
export const CFOP_INTERESTADUAL_WHITELIST: readonly { code: string; label: string }[] = [
  { code: '6101', label: '6101 — Venda de produção do estabelecimento (interestadual)' },
  { code: '6102', label: '6102 — Venda de mercadoria adquirida de terceiros (interestadual)' },
  { code: '6103', label: '6103 — Venda de produção, fora do estabelecimento (interestadual)' },
  {
    code: '6104',
    label: '6104 — Venda de mercadoria de terceiros, fora do estabelecimento (interestadual)'
  },
  { code: '6109', label: '6109 — Venda destinada à ZFM/ALC (produção própria, interestadual)' },
  {
    code: '6110',
    label: '6110 — Venda destinada à ZFM/ALC (mercadoria de terceiros, interestadual)'
  }
];

/**
 * Converts a CFOP between intra-state (5xxx) and interstate (6xxx)
 * variants when only the prefix differs. Returns the input unchanged
 * if it is not a 5xxx/6xxx code so other CFOP families (1xxx entradas,
 * 7xxx exterior) survive the auto-adjust.
 */
export function flipCfopForIdDest(cfop: string, idDest: string): string {
  if (!/^[56]\d{3}$/.test(cfop)) {
    return cfop;
  }
  if (idDest === '1' && cfop.startsWith('6')) {
    return '5' + cfop.slice(1);
  }
  if (idDest === '2' && cfop.startsWith('5')) {
    return '6' + cfop.slice(1);
  }
  return cfop;
}

export function digitsOnly(value: unknown): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.replace(/\D/g, '');
}

export function isValidCNPJ(value: string): boolean {
  const digits = digitsOnly(value);
  if (digits.length !== 14) {
    return false;
  }
  if (/^(\d)\1{13}$/.test(digits)) {
    return false;
  }
  const calc = (slice: string, weights: number[]): number => {
    const sum = weights.reduce((acc, w, i) => acc + Number(slice[i]) * w, 0);
    const mod = sum % 11;
    return mod < 2 ? 0 : 11 - mod;
  };
  const w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const d1 = calc(digits.slice(0, 12), w1);
  const d2 = calc(digits.slice(0, 13), w2);
  return d1 === Number(digits[12]) && d2 === Number(digits[13]);
}

export function isValidCPF(value: string): boolean {
  const digits = digitsOnly(value);
  if (digits.length !== 11) {
    return false;
  }
  if (/^(\d)\1{10}$/.test(digits)) {
    return false;
  }
  const calc = (slice: string, start: number): number => {
    let sum = 0;
    for (let i = 0; i < slice.length; i++) {
      sum += Number(slice[i]) * (start - i);
    }
    const mod = sum % 11;
    return mod < 2 ? 0 : 11 - mod;
  };
  const d1 = calc(digits.slice(0, 9), 10);
  const d2 = calc(digits.slice(0, 10), 11);
  return d1 === Number(digits[9]) && d2 === Number(digits[10]);
}

export function cnpjValidator(): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (isBlank(v)) {
      return null;
    }
    return isValidCNPJ(v) ? null : { cnpj: true };
  };
}

export function cpfValidator(): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (isBlank(v)) {
      return null;
    }
    return isValidCPF(v) ? null : { cpf: true };
  };
}

export function ufValidator(): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (isBlank(v)) {
      return null;
    }
    return UF_CODES.has(v) ? null : { uf: true };
  };
}

export function digitsValidator(length: number, key: string): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (isBlank(v)) {
      return null;
    }
    return digitsOnly(v).length === length && /^\d+$/.test(v) ? null : { [key]: true };
  };
}

export function cfopValidator(): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (isBlank(v)) {
      return null;
    }
    return /^[1-7]\d{3}$/.test(v) ? null : { cfop: true };
  };
}

export function decimalValidator(): ValidatorFn {
  return (ctrl: AbstractControl): ValidationErrors | null => {
    const v = ctrl.value;
    if (v === null || v === undefined || v === '') {
      return null;
    }
    return /^\d+\.\d{2}$/.test(String(v)) ? null : { decimal: true };
  };
}

export function destDocXorValidator(group: AbstractControl): ValidationErrors | null {
  const cnpj = group.get('cnpj')?.value as string | null;
  const cpf = group.get('cpf')?.value as string | null;
  const hasCnpj = !isBlank(cnpj);
  const hasCpf = !isBlank(cpf);
  if (hasCnpj && hasCpf) {
    return { destDocXor: 'both' };
  }
  if (!hasCnpj && !hasCpf) {
    return { destDocXor: 'none' };
  }
  return null;
}

/**
 * Cross-field validator on the wizard root: enforces SEFAZ rule that
 * id_dest must reflect the emit/dest UF relationship.
 *  - id_dest=1 (interna)         requires emit.uf === dest.uf
 *  - id_dest=2 (interestadual)   requires emit.uf !== dest.uf
 *  - id_dest=3 (exterior)        skipped — dest UF dropdown is BR-only,
 *                                 so this branch is unreachable from the
 *                                 current form. Validator stays permissive
 *                                 there to avoid false positives if the
 *                                 model later opens up.
 *
 * Returns `{ idDestMismatch: 'shouldBeInternal' | 'shouldBeInterstate' }`
 * which the template surfaces in Step 3 BEFORE the user advances to
 * Step 4. Prior to this validator, the inconsistency only surfaced as
 * a 422 from the backend on submit (Step 5), forcing the user to walk
 * back through 3 steps to fix.
 */
export function idDestConsistencyValidator(group: AbstractControl): ValidationErrors | null {
  const emitUf = group.get('emit.uf')?.value as string | null;
  const destUf = group.get('dest.uf')?.value as string | null;
  const idDest = group.get('ide.id_dest')?.value as string | null;
  if (isBlank(emitUf) || isBlank(destUf) || isBlank(idDest)) {
    return null;
  }
  if (idDest === '3') {
    return null;
  }
  const sameUf = emitUf === destUf;
  if (sameUf && idDest !== '1') {
    return { idDestMismatch: 'shouldBeInternal' };
  }
  if (!sameUf && idDest !== '2') {
    return { idDestMismatch: 'shouldBeInterstate' };
  }
  return null;
}
