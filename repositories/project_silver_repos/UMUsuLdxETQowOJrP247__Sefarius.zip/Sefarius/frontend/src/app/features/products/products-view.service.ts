import { Injectable, computed, effect, signal } from '@angular/core';

export type ProductsViewMode = 'grid' | 'list' | 'table';

const STORAGE_KEY = 'sefarius:products:viewMode';
const VALID_MODES: readonly ProductsViewMode[] = ['grid', 'list', 'table'] as const;
const MOBILE_MEDIA = '(max-width: 768px)';

/**
 * Tracks which layout the Products page should render. Three goals:
 *
 * 1. Persist the user's explicit choice in localStorage so a reload
 *    keeps the same mode.
 * 2. Force "list" on narrow viewports because the table has too many
 *    columns to fit a phone — but DON'T overwrite the saved preference,
 *    so resizing back to a desktop window restores the user's choice.
 * 3. Stay reactive: components read `mode()` (the effective mode) and
 *    re-render via OnPush + signal-driven change detection.
 *
 * The split between `preferred` (what the user picked) and `mode` (what
 * we actually render) is the load-bearing detail — it's what lets us
 * treat the mobile force as a presentation rule instead of a state
 * mutation.
 */
@Injectable({ providedIn: 'root' })
export class ProductsViewService {
  private readonly _preferred = signal<ProductsViewMode>(this.loadFromStorage());
  private readonly _isMobile = signal<boolean>(this.matchesMobile());

  /** What the user picked (may be 'table' even on mobile). */
  readonly preferred = this._preferred.asReadonly();
  /** True when the viewport matches the mobile media query. */
  readonly isMobile = this._isMobile.asReadonly();
  /** Effective mode the UI should render right now. */
  readonly mode = computed<ProductsViewMode>(() => {
    if (this._isMobile() && this._preferred() === 'table') {
      return 'list';
    }
    return this._preferred();
  });

  constructor() {
    // Persist on every preferred-mode change. Wrapped in try/catch
    // because localStorage may be unavailable (private mode, quota).
    effect(() => {
      const value = this._preferred();
      try {
        localStorage.setItem(STORAGE_KEY, value);
      } catch {
        // ignore — the in-memory signal still works for the session
      }
    });

    // Listen for viewport changes so resize / orientation flip toggles
    // the mobile state without a reload. Older browsers used .addListener
    // (now deprecated); modern API is addEventListener.
    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const mql = window.matchMedia(MOBILE_MEDIA);
      const handler = (e: MediaQueryListEvent) => this._isMobile.set(e.matches);
      if (typeof mql.addEventListener === 'function') {
        mql.addEventListener('change', handler);
      }
    }
  }

  setMode(mode: ProductsViewMode): void {
    if ((VALID_MODES as readonly string[]).includes(mode)) {
      this._preferred.set(mode);
    }
  }

  // Test hooks — let the spec drive mobile state without spawning real
  // matchMedia events. Marked with the `__` prefix to make their
  // testing-only nature obvious at call sites.
  __setMobileForTesting(isMobile: boolean): void {
    this._isMobile.set(isMobile);
  }

  private loadFromStorage(): ProductsViewMode {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw && (VALID_MODES as readonly string[]).includes(raw)) {
        return raw as ProductsViewMode;
      }
    } catch {
      // ignore — fall through to default
    }
    return 'grid';
  }

  private matchesMobile(): boolean {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return false;
    }
    return window.matchMedia(MOBILE_MEDIA).matches;
  }
}
