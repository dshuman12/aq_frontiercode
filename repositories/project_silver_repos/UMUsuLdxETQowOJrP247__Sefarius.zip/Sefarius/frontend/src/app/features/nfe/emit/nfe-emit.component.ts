import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { MatStepper, MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {
  MatAutocompleteModule,
  MatAutocompleteSelectedEvent
} from '@angular/material/autocomplete';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

import { ApiService } from '@app/shared/services/api.service';
import { ViaCepService } from '@app/shared/services/viacep.service';
import { ToastService } from '@app/shared/services/toast.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { NumberMaskDirective } from '@app/shared/directives/number-mask.directive';
import { CnpjPipe, CpfPipe, CepPipe } from '@app/shared/pipes/document-mask.pipe';
import { Product } from '@app/shared/models/api.models';
import { EmitNFeRequest, EmitNFeResponse, ItemDTO } from '@app/shared/models/nfe.models';
import {
  CFOP_INTERESTADUAL_WHITELIST,
  CFOP_INTERNA_WHITELIST,
  UF_LIST,
  cfopValidator,
  cnpjValidator,
  cpfValidator,
  cUfFor,
  decimalValidator,
  destDocXorValidator,
  digitsValidator,
  flipCfopForIdDest,
  idDestConsistencyValidator,
  ufValidator
} from './nfe-validators';

const DRAFT_KEY = 'sefarius:nfe-emit-draft';

interface SubmitFeedback {
  kind: 'success' | 'error' | 'rejection';
  text: string;
  cStat?: string;
  motivo?: string;
}

@Component({
  selector: 'app-nfe-emit',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatAutocompleteModule,
    NumberMaskDirective,
    CnpjPipe,
    CpfPipe,
    CepPipe
  ],
  templateUrl: './nfe-emit.component.html',
  styleUrls: ['./nfe-emit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NFeEmitComponent extends BaseComponent implements OnInit {
  @ViewChild(MatStepper) stepper?: MatStepper;

  // Sprint Responsive Sweep: tracks the active step index so the mobile
  // progress bar / "Etapa N de 5" label can re-render. Mat-stepper
  // emits selectionChange with the new index — we mirror it here.
  currentStepIndex = 0;
  readonly totalSteps = 5;
  readonly stepLabels = ['Identificação', 'Emitente', 'Destinatário', 'Itens', 'Revisão'];

  readonly ufList = UF_LIST;
  readonly cfopInternaList = CFOP_INTERNA_WHITELIST;
  readonly cfopInterestadualList = CFOP_INTERESTADUAL_WHITELIST;

  // Bug Sweep 2: template picks the CFOP options based on the current
  // id_dest. id_dest=1 → 5xxx; id_dest=2 → 6xxx; id_dest=3 → leave 5xxx
  // as a fallback (the user is on exterior territory and CFOP is on
  // 7xxx range, which is out of our scope today).
  cfopOptionsFor(idDest: string): readonly { code: string; label: string }[] {
    if (idDest === '2') {
      return this.cfopInterestadualList;
    }
    return this.cfopInternaList;
  }

  form!: FormGroup;
  submitting = false;
  feedback: SubmitFeedback | null = null;
  draftRestored = false;

  // Per-item autocomplete results, indexed in lock-step with the
  // items FormArray. addItem/removeItem manage this array; the
  // template iterates it via itemSearchResults[i].
  itemSearchResults: Product[][] = [[]];

  // Per-item warning state — set when the user selects a product that
  // is missing NCM and/or valor_unitario from the catalog. The wizard
  // doesn't block submission (operator may still type the values
  // manually for that single NFe), but the warning makes it explicit
  // that the catalog entry should be completed back at /products.
  itemIncompleteWarning: (string | null)[] = [null];

  // Bug #3 + suggestion (a): set true when the wizard auto-adjusted
  // id_dest because emit.uf vs dest.uf changed. Step 3 surfaces a
  // notice so the user understands the picker re-flipped under them.
  // Reset to false once the user manually overrides id_dest after the
  // fact, otherwise the notice would stick forever.
  idDestAutoAdjusted = false;

  // Bug Sweep 2 — ViaCEP undo notice. When the lookup overwrites
  // address fields the user already typed, we surface a per-scope
  // banner with what was overwritten + an "Desfazer" button that
  // restores the pre-lookup snapshot. Tracking is per scope ('emit'
  // | 'dest') so the two address blocks don't compete for the same
  // notice.
  viaCepNotice: Record<'emit' | 'dest', string | null> = {
    emit: null,
    dest: null
  };
  private viaCepUndo: Record<'emit' | 'dest', Record<string, string> | null> = {
    emit: null,
    dest: null
  };

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private viaCep: ViaCepService,
    private toast: ToastService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    super();
  }

  get ide(): FormGroup {
    return this.form.get('ide') as FormGroup;
  }

  get emit(): FormGroup {
    return this.form.get('emit') as FormGroup;
  }

  get dest(): FormGroup {
    return this.form.get('dest') as FormGroup;
  }

  get items(): FormArray {
    return this.form.get('items') as FormArray;
  }

  ngOnInit(): void {
    this.form = this.buildForm();
    this.tryRestoreDraft();
    this.wireDraftAutosave();
    this.wireUfDerivation();
    this.wireIdDestDerivation();
    this.wireManualIdDestOverride();
    this.wireCepLookup(this.emit, 'emit');
    this.wireCepLookup(this.dest, 'dest');
    // Wire autocomplete for every item already in the FormArray —
    // fresh form starts with 1, but tryRestoreDraft may have pushed
    // additional items from localStorage before this point.
    for (let i = 0; i < this.items.length; i++) {
      if (i >= this.itemSearchResults.length) {
        this.itemSearchResults.push([]);
      }
      if (i >= this.itemIncompleteWarning.length) {
        this.itemIncompleteWarning.push(null);
      }
      this.wireProductSearch(i);
      this.wireItemRecompute(i);
    }
    // Bug Sweep 2: pre-fill n_nf with the next sequential number
    // based on existing NFe records. Best-effort — if the API errors
    // or the user already restored a draft with a custom n_nf, we
    // skip the suggestion. Operator can still override manually.
    this.suggestNextNNf();
  }

  // Suggests n_nf = max(existing) + 1. Only runs when the field is
  // empty (so a draft restore wins) and only updates the form when
  // the API returns at least one NFe — otherwise we'd suggest "1"
  // when the user might already be number 1 in their bookkeeping.
  private suggestNextNNf(): void {
    if (this.ide.get('n_nf')?.value) {
      return;
    }
    this.apiService
      .listNFe(50, 0)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          // listNFe response shape changed (2026-05-08) from a bare
          // array to a PaginatedResponse with items/total. Drill in.
          const items = resp.data?.items ?? [];
          if (items.length === 0) {
            return;
          }
          // chave is 44 chars; positions 25-33 (0-indexed) carry n_nf
          // (9 digits). We slice rather than parsing the full key
          // because it is cheaper and immune to lifecycle-only changes
          // in the response shape.
          let max = 0;
          for (const it of items) {
            const chave = it.chave ?? '';
            if (chave.length >= 34) {
              const n = parseInt(chave.slice(25, 34), 10);
              if (!Number.isNaN(n) && n > max) {
                max = n;
              }
            }
          }
          if (max > 0) {
            this.ide.patchValue({ n_nf: String(max + 1) }, { emitEvent: false });
            this.cdr.markForCheck();
          }
        },
        error: () => {
          // Silent — operator types it manually.
        }
      });
  }

  private buildForm(): FormGroup {
    const now = new Date();
    const isoLocal = this.toLocalIsoMinutes(now);
    const cNf = this.randomCnf();

    return this.fb.group(
      {
        ide: this.fb.group({
          c_uf: ['43', [Validators.required, digitsValidator(2, 'cUf')]],
          c_nf: [cNf, [Validators.required, digitsValidator(8, 'cNf')]],
          nat_op: ['Venda de mercadoria', [Validators.required, Validators.maxLength(60)]],
          serie: ['1', [Validators.required, Validators.pattern(/^\d{1,3}$/)]],
          n_nf: ['', [Validators.required, Validators.pattern(/^\d{1,9}$/)]],
          dh_emi: [isoLocal, [Validators.required]],
          tp_nf: ['1', [Validators.required]],
          id_dest: ['1', [Validators.required]],
          c_mun_fg: ['', [Validators.required, digitsValidator(7, 'cMunFg')]],
          tp_amb: ['2', [Validators.required]],
          fin_nfe: ['1', [Validators.required]],
          ind_pres: ['1', [Validators.required]]
        }),
        emit: this.fb.group({
          cnpj: ['', [Validators.required, cnpjValidator()]],
          x_nome: ['', [Validators.required, Validators.maxLength(60)]],
          ie: ['', [Validators.required, Validators.pattern(/^\d{2,14}$/)]],
          crt: ['3', [Validators.required]],
          x_lgr: ['', [Validators.required, Validators.maxLength(60)]],
          nro: ['', [Validators.required, Validators.maxLength(60)]],
          x_bairro: ['', [Validators.required, Validators.maxLength(60)]],
          c_mun: ['', [Validators.required, digitsValidator(7, 'cMun')]],
          x_mun: ['', [Validators.required, Validators.maxLength(60)]],
          uf: ['RS', [Validators.required, ufValidator()]],
          cep: ['', [Validators.required, digitsValidator(8, 'cep')]]
        }),
        dest: this.fb.group(
          {
            cnpj: ['', [cnpjValidator()]],
            cpf: ['', [cpfValidator()]],
            x_nome: ['', [Validators.required, Validators.maxLength(60)]],
            ind_ie_dest: ['9', [Validators.required]],
            ie: [''],
            x_lgr: ['', [Validators.required, Validators.maxLength(60)]],
            nro: ['', [Validators.required, Validators.maxLength(60)]],
            x_bairro: ['', [Validators.required, Validators.maxLength(60)]],
            c_mun: ['', [Validators.required, digitsValidator(7, 'cMunDest')]],
            x_mun: ['', [Validators.required, Validators.maxLength(60)]],
            uf: ['RS', [Validators.required, ufValidator()]],
            cep: ['', [digitsValidator(8, 'cepDest')]]
          },
          { validators: [destDocXorValidator] }
        ),
        items: this.fb.array([this.buildItem()])
      },
      { validators: [idDestConsistencyValidator] }
    );
  }

  buildItem(): FormGroup {
    return this.fb.group({
      // productSearch is the autocomplete-only control. It is stripped
      // from the payload by toRequest() so it never reaches the wire.
      productSearch: [''],
      c_prod: ['', [Validators.required, Validators.maxLength(60)]],
      x_prod: ['', [Validators.required, Validators.maxLength(120)]],
      ncm: ['', [Validators.required, digitsValidator(8, 'ncm')]],
      cfop: ['5102', [Validators.required, cfopValidator()]],
      u_com: ['UN', [Validators.required, Validators.maxLength(6)]],
      // Bug Sweep 2 (2026-05-07): q_com and v_un_com now accept any
      // decimal form ("2", "2.0", "2.00", "2.0000"). The blur handlers
      // formatQty / formatUnitValue normalize to 4 decimals on focus
      // exit. Without the loosened pattern, typing "2" was flagged
      // "Formato 0.0000 (4 casas)" before the user even left the field
      // and the autocomplete could not be debugged because operators
      // assumed the field was broken.
      q_com: ['1.0000', [Validators.required, Validators.pattern(/^\d+(\.\d{1,4})?$/)]],
      v_un_com: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,10})?$/)]],
      // v_prod and v_bc are derived: q_com × v_un_com, formatted to 2
      // decimals. Read-only in the template; the recompute lives in
      // wireItemRecompute(index). Kept inside the form (instead of as
      // a getter) so the value lands in the EmitNFeRequest payload
      // without extra mapping at submit time.
      v_prod: ['', [Validators.required, decimalValidator()]],
      v_bc: ['', [Validators.required, decimalValidator()]],
      p_icms: ['18.00', [Validators.required, decimalValidator()]],
      v_pis: ['0.00', [Validators.required, decimalValidator()]],
      v_cofins: ['0.00', [Validators.required, decimalValidator()]]
    });
  }

  // Bug Sweep 2: q_com / v_un_com value changes recompute v_prod and
  // v_bc on the same item. Subscribed once at addItem / restoreDraft
  // boot. emitEvent:false on the patch prevents an infinite loop
  // because v_prod/v_bc are not in the dependency chain anyway, but
  // belt-and-suspenders.
  private wireItemRecompute(index: number): void {
    const item = this.itemControl(index);
    const trigger = () => this.recomputeItemTotals(index);
    item.get('q_com')?.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(trigger);
    item.get('v_un_com')?.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(trigger);
  }

  private recomputeItemTotals(index: number): void {
    const item = this.itemControl(index);
    const q = parseFloat(String(item.get('q_com')?.value ?? '').replace(',', '.')) || 0;
    const u = parseFloat(String(item.get('v_un_com')?.value ?? '').replace(',', '.')) || 0;
    if (q <= 0 || u <= 0) {
      return;
    }
    const total = (q * u).toFixed(2);
    item.patchValue({ v_prod: total, v_bc: total }, { emitEvent: false });
    this.cdr.markForCheck();
  }

  // Blur normalization for qty: "2" → "2.0000", "2.5" → "2.5000".
  // The wizard accepts looser input on the way in and tightens on
  // exit so SEFAZ always sees the canonical 4-decimal form.
  formatQty(index: number): void {
    const ctrl = this.itemControl(index).get('q_com');
    const num = parseFloat(String(ctrl?.value ?? '').replace(',', '.'));
    if (!Number.isNaN(num) && num >= 0) {
      ctrl?.setValue(num.toFixed(4), { emitEvent: false });
      this.recomputeItemTotals(index);
    }
  }

  // Blur normalization for unit value: same pattern but 2-decimal
  // canonical form (some catalogs use 4 — both are accepted by the
  // backend; we keep 2 for human readability of the catalog listing).
  formatUnitValue(index: number): void {
    const ctrl = this.itemControl(index).get('v_un_com');
    const num = parseFloat(String(ctrl?.value ?? '').replace(',', '.'));
    if (!Number.isNaN(num) && num >= 0) {
      ctrl?.setValue(num.toFixed(4), { emitEvent: false });
      this.recomputeItemTotals(index);
    }
  }

  addItem(): void {
    this.items.push(this.buildItem());
    this.itemSearchResults.push([]);
    this.itemIncompleteWarning.push(null);
    this.wireProductSearch(this.items.length - 1);
    this.wireItemRecompute(this.items.length - 1);
    this.cdr.markForCheck();
  }

  removeItem(index: number): void {
    if (this.items.length > 1) {
      this.items.removeAt(index);
      this.itemSearchResults.splice(index, 1);
      this.itemIncompleteWarning.splice(index, 1);
      this.cdr.markForCheck();
    }
  }

  // Returns true when the product entry is missing NCM or valor_unitario
  // (the two columns that stayed nullable in migration 006). Used both
  // by the autocomplete dropdown to badge the option AND by
  // onProductSelected to populate itemIncompleteWarning.
  isProductIncomplete(p: Product | null | undefined): boolean {
    if (!p) {
      return false;
    }
    const ncmMissing = !p.ncm || !/^\d{8}$/.test(p.ncm);
    const valorMissing =
      p.valor_unitario === null || p.valor_unitario === undefined || p.valor_unitario <= 0;
    return ncmMissing || valorMissing;
  }

  // Wires the productSearch control of an item to the backend search
  // endpoint with debounce + distinct + length-2 floor. Results land
  // in itemSearchResults[index] which the template renders via
  // <mat-autocomplete>. Errors are swallowed silently — the user can
  // still type the item manually if the catalog is unreachable.
  private wireProductSearch(index: number): void {
    const ctrl = this.itemControl(index).get('productSearch');
    if (!ctrl) {
      return;
    }
    ctrl.valueChanges
      .pipe(debounceTime(250), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe(raw => {
        const query = typeof raw === 'string' ? raw.trim() : '';
        if (query.length < 2) {
          this.itemSearchResults[index] = [];
          this.cdr.markForCheck();
          return;
        }
        this.apiService
          .searchProducts(query, 10)
          .pipe(takeUntil(this.destroy$))
          .subscribe({
            next: resp => {
              this.itemSearchResults[index] = resp.data?.items ?? [];
              this.cdr.markForCheck();
            },
            error: () => {
              this.itemSearchResults[index] = [];
              this.cdr.markForCheck();
            }
          });
      });
  }

  // Format the option label rendered in the autocomplete dropdown
  // and (when an option is selected) in the input itself. The user
  // sees "CODE — Description" and the selected event below maps it
  // back to a Product so we never search for the formatted string.
  productLabel = (p: Product | string): string => {
    if (!p || typeof p === 'string') {
      return typeof p === 'string' ? p : '';
    }
    return `${p.code} — ${p.description}`;
  };

  // On select, the 9 fiscal fields plus c_prod / x_prod / u_com are
  // pulled from the product into the item form group. Quantity stays
  // at the form's current value (default 1.0000); v_un_com seeds from
  // the product's valor_unitario when present, leaving operator to
  // override for promo prices. v_prod / v_bc are recomputed from
  // q_com × v_un_com so totals match SEFAZ reconciliation rules.
  onProductSelected(event: MatAutocompleteSelectedEvent, index: number): void {
    const product = event.option.value as Product;
    if (!product || typeof product !== 'object') {
      return;
    }
    const item = this.itemControl(index);
    const qCom = Number(item.get('q_com')?.value ?? 1) || 1;
    const vUn = product.valor_unitario ?? 0;
    const vProd = (qCom * vUn).toFixed(2);
    const pICMS = Number(product.p_icms ?? 18);

    item.patchValue(
      {
        c_prod: product.code,
        x_prod: product.description,
        ncm: product.ncm ?? '',
        cfop: product.cfop_padrao_saida,
        u_com: product.u_com,
        v_un_com: vUn > 0 ? vUn.toFixed(4) : '',
        v_prod: vUn > 0 ? vProd : '',
        v_bc: vUn > 0 ? vProd : '',
        p_icms: pICMS.toFixed(2)
      },
      { emitEvent: false }
    );
    // Replace the search-input text with a stable summary so the user
    // sees what was selected; without this, the input keeps whatever
    // partial term they typed.
    item.get('productSearch')?.setValue(this.productLabel(product), { emitEvent: false });

    // Bug #1 fix: surface a per-item warning when the catalog entry is
    // missing NCM / valor_unitario, so the user understands why those
    // fields stayed empty after the patch. Required-form on Products
    // (bug #5 fix) prevents new occurrences; legacy products keep
    // surfacing this until edited.
    if (this.isProductIncomplete(product)) {
      const missing: string[] = [];
      if (!product.ncm || !/^\d{8}$/.test(product.ncm)) {
        missing.push('NCM');
      }
      if (
        product.valor_unitario === null ||
        product.valor_unitario === undefined ||
        product.valor_unitario <= 0
      ) {
        missing.push('valor unitário');
      }
      this.itemIncompleteWarning[index] =
        `Produto cadastrado sem ${missing.join(' e ')}. Preencha manualmente abaixo ou edite o produto em /products para completar o cadastro fiscal.`;
    } else {
      this.itemIncompleteWarning[index] = null;
    }
    this.cdr.markForCheck();
  }

  private wireUfDerivation(): void {
    this.emit
      .get('uf')
      ?.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe(uf => {
        const code = cUfFor(uf);
        if (code && this.ide.get('c_uf')?.value !== code) {
          this.ide.patchValue({ c_uf: code }, { emitEvent: false });
        }
      });
  }

  // Bug #3 + suggestion (a): whenever emit.uf or dest.uf settles, infer
  // id_dest from the relationship (interna vs interestadual). Patched
  // with emitEvent:false so we don't trip the form-level validator
  // mid-flight; the validator re-runs on the next tick anyway because
  // the UF value changes upstream.
  private wireIdDestDerivation(): void {
    const recompute = () => {
      const emitUf = this.emit.get('uf')?.value as string;
      const destUf = this.dest.get('uf')?.value as string;
      if (!emitUf || !destUf) {
        return;
      }
      // id_dest=3 (exterior) is operator-driven and out of dropdown
      // scope today — leave it untouched if already chosen.
      const current = this.ide.get('id_dest')?.value as string;
      if (current === '3') {
        return;
      }
      const expected = emitUf === destUf ? '1' : '2';
      if (current !== expected) {
        this.ide.patchValue({ id_dest: expected }, { emitEvent: false });
        this.idDestAutoAdjusted = true;
        this.cdr.markForCheck();
      }
    };
    this.emit
      .get('uf')
      ?.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe(() => recompute());
    this.dest
      .get('uf')
      ?.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe(() => recompute());
  }

  // Suggestion (b): when CEP reaches 8 digits, query ViaCEP and patch
  // logradouro / bairro / cidade / UF / IBGE municipality code into the
  // matching emit or dest group. Patches use emitEvent:false so a
  // single CEP lookup doesn't fan out into a derivation chain (UF
  // change → c_uf re-derivation → id_dest re-derivation).
  //
  // Lookup is best-effort: any error or `{erro:true}` from ViaCEP is
  // silently swallowed and the user continues to type manually. We
  // also bail when the CEP control is the same digits as last time —
  // otherwise patching x_lgr/x_bairro could overwrite operator edits.
  private cepCache = new Map<string, string>();
  private wireCepLookup(group: FormGroup, scope: 'emit' | 'dest'): void {
    const ctrl = group.get('cep');
    if (!ctrl) {
      return;
    }
    ctrl.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(raw => {
      const digits = (typeof raw === 'string' ? raw : '').replace(/\D/g, '');
      if (digits.length !== 8) {
        return;
      }
      const cacheKey = `${scope}:${digits}`;
      if (this.cepCache.get(cacheKey) === digits) {
        return;
      }
      this.cepCache.set(cacheKey, digits);
      this.viaCep
        .lookup(digits)
        .pipe(takeUntil(this.destroy$))
        .subscribe(resp => {
          if (!resp) {
            return;
          }
          // Bug Sweep 2 — capture pre-lookup snapshot so the user can
          // undo the overwrite. Only fields ViaCEP actually changes
          // are tracked, so an undo doesn't trample untouched fields.
          const fields = ['x_lgr', 'x_bairro', 'x_mun', 'uf', 'c_mun'] as const;
          const before: Record<string, string> = {};
          const overwritten: string[] = [];
          for (const f of fields) {
            before[f] = String(group.get(f)?.value ?? '');
          }
          const next = {
            x_lgr: resp.logradouro || before['x_lgr'] || '',
            x_bairro: resp.bairro || before['x_bairro'] || '',
            x_mun: resp.localidade || before['x_mun'] || '',
            uf: resp.uf || before['uf'] || '',
            c_mun: resp.ibge || before['c_mun'] || ''
          };
          for (const f of fields) {
            if (before[f] && before[f] !== next[f]) {
              overwritten.push(f);
            }
          }
          group.patchValue(next, { emitEvent: false });
          // emit's UF drives ide.c_uf; we suppressed emitEvent above to
          // avoid noise, so re-run the derivation manually for the emit
          // scope. dest doesn't drive c_uf, so no extra work there.
          if (scope === 'emit') {
            const code = cUfFor(resp.uf);
            if (code) {
              this.ide.patchValue({ c_uf: code }, { emitEvent: false });
            }
          }
          // Recompute id_dest after either UF change so the cross-rule
          // stays consistent with the new UF.
          this.recomputeIdDest();

          this.viaCepUndo[scope] = before;
          if (overwritten.length > 0) {
            this.viaCepNotice[scope] =
              `Endereço preenchido pelo ViaCEP. ${overwritten.length} campo(s) sobrescrito(s) (${overwritten.join(', ')}).`;
          } else {
            this.viaCepNotice[scope] = 'Endereço preenchido pelo ViaCEP a partir do CEP.';
          }
          this.cdr.markForCheck();
        });
    });
  }

  // Restore the snapshot taken right before the most-recent ViaCEP
  // patch on this scope. Clears the notice; the cache stays so the
  // same CEP doesn't re-trigger the lookup if the user types it again
  // — they'd have to type a different CEP to retry.
  undoViaCep(scope: 'emit' | 'dest'): void {
    const snapshot = this.viaCepUndo[scope];
    if (!snapshot) {
      return;
    }
    const group = scope === 'emit' ? this.emit : this.dest;
    group.patchValue(snapshot, { emitEvent: false });
    if (scope === 'emit') {
      const code = cUfFor(snapshot['uf']);
      if (code) {
        this.ide.patchValue({ c_uf: code }, { emitEvent: false });
      }
    }
    this.recomputeIdDest();
    this.viaCepNotice[scope] = null;
    this.viaCepUndo[scope] = null;
    this.cdr.markForCheck();
  }

  dismissViaCepNotice(scope: 'emit' | 'dest'): void {
    this.viaCepNotice[scope] = null;
    this.viaCepUndo[scope] = null;
    this.cdr.markForCheck();
  }

  private recomputeIdDest(): void {
    const emitUf = this.emit.get('uf')?.value as string;
    const destUf = this.dest.get('uf')?.value as string;
    if (!emitUf || !destUf) {
      return;
    }
    const current = this.ide.get('id_dest')?.value as string;
    if (current === '3') {
      return;
    }
    const expected = emitUf === destUf ? '1' : '2';
    if (current !== expected) {
      this.ide.patchValue({ id_dest: expected }, { emitEvent: false });
      this.idDestAutoAdjusted = true;
    }
  }

  // If the user manually edits id_dest after the auto-adjust banner
  // appears, drop the banner — they've taken explicit ownership of
  // the field. Without this, the banner would persist forever once
  // shown, even after the user picks a value of their own.
  // Bug Sweep 2: also re-flips CFOPs across all items so a switch
  // to interestadual silently rewrites 5102→6102 (and back). Without
  // this, SEFAZ rejects on submit with "CFOP=5102 não casa com idDest=2"
  // and the operator has to walk back to Step 4 to fix N items by hand.
  private wireManualIdDestOverride(): void {
    this.ide
      .get('id_dest')
      ?.valueChanges.pipe(takeUntil(this.destroy$))
      .subscribe(idDest => {
        if (this.idDestAutoAdjusted) {
          this.idDestAutoAdjusted = false;
        }
        if (typeof idDest === 'string') {
          this.adjustItemsCfopForIdDest(idDest);
        }
        this.cdr.markForCheck();
      });
  }

  private adjustItemsCfopForIdDest(idDest: string): void {
    if (idDest === '3') {
      return;
    }
    for (const item of this.items.controls) {
      const ctrl = item.get('cfop');
      const current = String(ctrl?.value ?? '');
      const next = flipCfopForIdDest(current, idDest);
      if (next !== current) {
        ctrl?.setValue(next, { emitEvent: false });
      }
    }
  }

  private wireDraftAutosave(): void {
    this.form.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(value => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(value));
      } catch {
        // localStorage may be unavailable (private mode, quota); silent.
      }
    });
  }

  private tryRestoreDraft(): void {
    let raw: string | null = null;
    try {
      raw = localStorage.getItem(DRAFT_KEY);
    } catch {
      raw = null;
    }
    if (!raw) {
      return;
    }
    try {
      const parsed = JSON.parse(raw) as { items?: unknown[] };
      const targetItemCount = Array.isArray(parsed.items) ? parsed.items.length : 1;
      while (this.items.length < targetItemCount) {
        this.items.push(this.buildItem());
      }
      while (this.items.length > targetItemCount && this.items.length > 1) {
        this.items.removeAt(this.items.length - 1);
      }
      this.form.patchValue(parsed, { emitEvent: false });
      this.draftRestored = true;
    } catch {
      // Corrupt draft — silently ignore. Don't trash localStorage on parse error
      // because the user might want to inspect it manually.
    }
  }

  clearDraft(): void {
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {
      // ignore
    }
    this.draftRestored = false;
    this.cdr.markForCheck();
  }

  submit(): void {
    if (this.form.invalid || this.submitting) {
      this.form.markAllAsTouched();
      this.cdr.markForCheck();
      return;
    }

    const payload = this.toRequest();
    this.submitting = true;
    this.feedback = null;
    this.cdr.markForCheck();

    this.apiService
      .emitNFe(payload)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resp => {
          this.submitting = false;
          const out = resp.data;
          if (!out) {
            this.feedback = { kind: 'error', text: 'Resposta inesperada do servidor.' };
            this.cdr.markForCheck();
            return;
          }
          if (out.status === 'AUTHORIZED') {
            this.clearDraft();
            this.feedback = {
              kind: 'success',
              text: `NF-e autorizada (cStat ${out.c_stat} — ${out.x_motivo}). Redirecionando…`
            };
            // Bug Sweep 2: complement the static banner with a toast so
            // the success is visible even after the redirect timer fires.
            this.toast.success(`NF-e ${out.chave.slice(-8)} autorizada.`);
            this.cdr.markForCheck();
            setTimeout(() => this.router.navigate(['/nfe', out.chave]), 1200);
          } else {
            this.feedback = {
              kind: 'rejection',
              text: this.formatRejection(out),
              cStat: out.rejection?.CStat ?? out.c_stat,
              motivo: out.rejection?.XMotivo ?? out.x_motivo
            };
            this.toast.error(`NF-e rejeitada (cStat ${out.rejection?.CStat ?? out.c_stat}).`);
            this.cdr.markForCheck();
          }
        },
        error: err => {
          this.submitting = false;
          const msg = this.formatHttpError(err);
          this.feedback = { kind: 'error', text: msg };
          // Toast carries a 1-line summary; the banner keeps the
          // multi-line validation issue list when the backend returns 422.
          this.toast.error(msg.split('\n')[0]);
          this.cdr.markForCheck();
        }
      });
  }

  private toRequest(): EmitNFeRequest {
    const raw = this.form.getRawValue();
    // Strip productSearch — autocomplete-only control, not part of
    // the EmitNFeRequest contract.
    // delete on a clone rather than destructuring with an underscore
    // alias because ESLint's no-unused-vars config in this project
    // does not exempt the _-prefix.
    const items: ItemDTO[] = (raw.items as (ItemDTO & { productSearch?: string })[]).map(it => {
      const clone: Partial<ItemDTO & { productSearch?: string }> = { ...it };
      delete clone.productSearch;
      return clone as ItemDTO;
    });
    const dest = { ...raw.dest };
    if (!dest.cnpj) {
      delete dest.cnpj;
    }
    if (!dest.cpf) {
      delete dest.cpf;
    }
    if (!dest.ie) {
      delete dest.ie;
    }
    if (!dest.cep) {
      delete dest.cep;
    }
    return {
      ide: this.normalizeIde(raw.ide),
      emit: raw.emit,
      dest,
      items
    };
  }

  private normalizeIde(ide: Record<string, string>): EmitNFeRequest['ide'] {
    const dh = ide['dh_emi'];
    return {
      ...ide,
      dh_emi: this.toIsoWithOffset(dh)
    } as EmitNFeRequest['ide'];
  }

  private toIsoWithOffset(local: string): string {
    if (!local) {
      return '';
    }
    if (local.includes('+') || /[Z]$/.test(local) || /-\d{2}:\d{2}$/.test(local.slice(10))) {
      return local;
    }
    const trimmed = local.length === 16 ? `${local}:00` : local;
    return `${trimmed}-03:00`;
  }

  private toLocalIsoMinutes(d: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  private randomCnf(): string {
    let s = '';
    for (let i = 0; i < 8; i++) {
      s += Math.floor(Math.random() * 10).toString();
    }
    return s;
  }

  private formatRejection(out: EmitNFeResponse): string {
    const cStat = out.rejection?.CStat ?? out.c_stat;
    const motivo = out.rejection?.XMotivo ?? out.x_motivo;
    return `NF-e rejeitada: cStat ${cStat} — ${motivo}`;
  }

  private formatHttpError(err: unknown): string {
    const e = err as {
      status?: number;
      error?: { error?: string; data?: { field?: string; message?: string }[] };
      message?: string;
    };
    if (e?.status === 502) {
      return 'SEFAZ indisponível. Tente novamente em alguns instantes.';
    }
    if (e?.status === 422) {
      const issues = e.error?.data;
      if (Array.isArray(issues) && issues.length > 0) {
        const lines = issues
          .slice(0, 5)
          .map(i => `  • ${i.field ?? '?'}: ${i.message ?? '(sem mensagem)'}`)
          .join('\n');
        return `Validação falhou:\n${lines}`;
      }
      return e.error?.error || 'Dados da NF-e inválidos.';
    }
    return e?.error?.error || e?.message || 'Erro ao emitir NF-e.';
  }

  isFieldInvalid(group: FormGroup, name: string): boolean {
    const c = group.get(name) as FormControl | null;
    return !!c && c.invalid && (c.touched || c.dirty);
  }

  // Marks every descendant control as touched so the per-field error
  // spans (gated by `touched || dirty`) become visible. Used as a
  // (click) handler on the "Próximo" buttons of each step alongside the
  // matStepperNext directive: when the group is valid the stepper
  // advances normally; when invalid the stepper stays put AND the user
  // now sees the field-level errors instead of a silently disabled
  // button. markAllAsTouched recurses into FormArrays so step 4 (items)
  // works without extra wiring.
  markStepTouched(group: AbstractControl): void {
    group.markAllAsTouched();
    this.cdr.markForCheck();
  }

  fieldErrorKey(group: FormGroup, name: string): string | null {
    const c = group.get(name);
    if (!c || !c.errors) {
      return null;
    }
    const keys = Object.keys(c.errors);
    return keys[0] ?? null;
  }

  itemControl(index: number): FormGroup {
    return this.items.at(index) as FormGroup;
  }

  totalItems(): string {
    let total = 0;
    for (const item of this.items.controls) {
      const v = Number((item.value as ItemDTO).v_prod);
      if (!Number.isNaN(v)) {
        total += v;
      }
    }
    return total.toFixed(2);
  }

  cancelEmit(): void {
    this.router.navigate(['/nfe']);
  }

  dismissFeedback(): void {
    this.feedback = null;
    this.cdr.markForCheck();
  }

  onStepChange(index: number): void {
    this.currentStepIndex = index;
    this.cdr.markForCheck();
  }

  mobileProgressPercent(): number {
    return Math.round(((this.currentStepIndex + 1) / this.totalSteps) * 100);
  }
}
