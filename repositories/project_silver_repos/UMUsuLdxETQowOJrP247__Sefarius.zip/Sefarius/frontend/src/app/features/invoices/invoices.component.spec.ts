import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { DialogService } from '@app/shared/services/dialog.service';
import { Invoice, Product } from '@app/shared/models/api.models';
import { InvoicesComponent } from './invoices.component';

const sampleProducts: Product[] = [
  {
    id: 'p1',
    code: 'P-01',
    description: 'Item A',
    balance: 5,
    version: 1,
    // Fiscal defaults from migration 006.
    ncm: null,
    valor_unitario: null,
    cfop_padrao_saida: '5102',
    u_com: 'UN',
    origem: '0',
    cst_icms: '00',
    p_icms: 18,
    cst_pis: '49',
    cst_cofins: '49',
    created_at: '',
    updated_at: ''
  }
];

const sampleInvoices: Invoice[] = [
  {
    id: 'i1',
    number: 1,
    status: 'OPEN',
    idempotency_key: 'k1',
    created_by: 'me',
    items: [],
    total_amount: 100,
    created_at: '2026-05-06T10:00:00Z'
  }
];

describe('InvoicesComponent', () => {
  let fixture: ComponentFixture<InvoicesComponent>;
  let component: InvoicesComponent;
  let apiMock: {
    getInvoices: jest.Mock;
    getProducts: jest.Mock;
    createInvoice: jest.Mock;
    deleteInvoice: jest.Mock;
  };
  let dialogMock: { confirmDelete: jest.Mock };

  beforeEach(async () => {
    apiMock = {
      getInvoices: jest.fn().mockReturnValue(
        of({
          success: true,
          data: { items: sampleInvoices, total: 1, limit: 20, offset: 0 },
          code: 200
        })
      ),
      getProducts: jest.fn().mockReturnValue(
        of({
          success: true,
          data: { items: sampleProducts, total: 1, limit: 20, offset: 0 },
          code: 200
        })
      ),
      createInvoice: jest.fn(),
      deleteInvoice: jest.fn()
    };
    dialogMock = { confirmDelete: jest.fn() };

    await TestBed.configureTestingModule({
      imports: [InvoicesComponent, NoopAnimationsModule],
      providers: [
        { provide: ApiService, useValue: apiMock },
        { provide: DialogService, useValue: dialogMock },
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(InvoicesComponent);
    component = fixture.componentInstance;
  });

  it('loads invoices and products on init in parallel', () => {
    fixture.detectChanges();
    expect(apiMock.getInvoices).toHaveBeenCalled();
    expect(apiMock.getProducts).toHaveBeenCalled();
    expect(component.invoicesSignal()).toHaveLength(1);
    expect(component.products).toHaveLength(1);
  });

  it('toggleNewInvoice opens the form and resets state on close', () => {
    fixture.detectChanges();
    component.toggleNewInvoice();
    expect(component.showNewInvoiceForm).toBe(true);

    component.invoiceForm.patchValue({ created_by: 'someone' });
    component.invoiceItems.push({ product_id: 'p1', quantity: 1, unit_price: 5 });

    component.toggleNewInvoice();
    expect(component.showNewInvoiceForm).toBe(false);
    expect(component.invoiceItems).toEqual([]);
    expect(component.invoiceForm.value.created_by).toBeNull();
  });

  it('addItem appends a row only when itemForm is valid', () => {
    fixture.detectChanges();
    component.itemForm.patchValue({ product_id: '', quantity: 0, unit_price: 0 });
    component.addItem();
    expect(component.invoiceItems).toHaveLength(0);

    component.itemForm.patchValue({ product_id: 'p1', quantity: 2, unit_price: 10 });
    component.addItem();
    expect(component.invoiceItems).toHaveLength(1);
    expect(component.invoiceItems[0]).toMatchObject({
      product_id: 'p1',
      quantity: 2,
      unit_price: 10,
      product_code: 'P-01'
    });
  });

  it('removeItem drops the row at the given index', () => {
    fixture.detectChanges();
    component.invoiceItems = [
      { product_id: 'p1', quantity: 1, unit_price: 5 },
      { product_id: 'p2', quantity: 2, unit_price: 7 }
    ];
    component.removeItem(0);
    expect(component.invoiceItems).toHaveLength(1);
    expect(component.invoiceItems[0].product_id).toBe('p2');
  });

  it('calculateTotal sums quantity * unit_price across items', () => {
    fixture.detectChanges();
    component.invoiceItems = [
      { product_id: 'p1', quantity: 2, unit_price: 10 },
      { product_id: 'p2', quantity: 3, unit_price: 5.5 }
    ];
    expect(component.calculateTotal()).toBe(2 * 10 + 3 * 5.5);
  });

  it('submitInvoice noop when form invalid or no items', () => {
    fixture.detectChanges();
    component.submitInvoice();
    expect(apiMock.createInvoice).not.toHaveBeenCalled();

    component.invoiceForm.patchValue({ created_by: 'me' });
    component.submitInvoice(); // no items
    expect(apiMock.createInvoice).not.toHaveBeenCalled();
  });

  it('submitInvoice posts created_by + items and reloads on success', () => {
    fixture.detectChanges();
    apiMock.createInvoice.mockReturnValue(
      of({ success: true, data: sampleInvoices[0], code: 201 })
    );
    apiMock.getInvoices.mockClear();

    component.toggleNewInvoice();
    component.invoiceForm.patchValue({ created_by: 'me' });
    component.invoiceItems = [{ product_id: 'p1', quantity: 2, unit_price: 10 }];
    component.submitInvoice();

    expect(apiMock.createInvoice).toHaveBeenCalledWith({
      created_by: 'me',
      items: [{ product_id: 'p1', quantity: 2, unit_price: 10 }]
    });
    expect(component.showNewInvoiceForm).toBe(false);
    expect(apiMock.getInvoices).toHaveBeenCalled(); // reload
  });

  it('deleteInvoice does nothing when the dialog is dismissed', async () => {
    fixture.detectChanges();
    dialogMock.confirmDelete.mockResolvedValueOnce(false);
    await component.deleteInvoice('i1');
    expect(apiMock.deleteInvoice).not.toHaveBeenCalled();
  });

  it('deleteInvoice removes the row on confirmation', async () => {
    fixture.detectChanges();
    dialogMock.confirmDelete.mockResolvedValueOnce(true);
    apiMock.deleteInvoice.mockReturnValue(of({ success: true, code: 200 }));

    await component.deleteInvoice('i1');
    expect(apiMock.deleteInvoice).toHaveBeenCalledWith('i1');
    expect(component.invoicesSignal().find(i => i.id === 'i1')).toBeUndefined();
  });

  it('getInvoiceStatus maps OPEN / aberta to "Aberta", everything else to "Fechada"', () => {
    fixture.detectChanges();
    expect(component.getInvoiceStatus({ ...sampleInvoices[0], status: 'OPEN' })).toBe('Aberta');
    expect(
      component.getInvoiceStatus({
        ...sampleInvoices[0],
        status: 'aberta' as unknown as Invoice['status']
      })
    ).toBe('Aberta');
    expect(component.getInvoiceStatus({ ...sampleInvoices[0], status: 'CLOSED' })).toBe('Fechada');
  });

  it('getInvoiceValue formats BRL', () => {
    fixture.detectChanges();
    expect(component.getInvoiceValue({ ...sampleInvoices[0], total_amount: 1234.5 })).toMatch(
      /1\.234,50/
    );
  });

  it('getResponsible returns created_by', () => {
    fixture.detectChanges();
    expect(component.getResponsible({ ...sampleInvoices[0], created_by: 'alice' })).toBe('alice');
    expect(
      component.getResponsible({ ...sampleInvoices[0], created_by: '' as unknown as string })
    ).toBe('');
  });

  it('formatDate renders pt-BR locale', () => {
    fixture.detectChanges();
    expect(component.formatDate('2026-05-06T10:00:00Z')).toMatch(/06\/05\/2026/);
  });
});
