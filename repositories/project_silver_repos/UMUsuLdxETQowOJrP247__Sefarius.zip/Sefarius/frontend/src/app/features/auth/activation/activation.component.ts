import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '@app/shared/services/auth.service';
import { AuthShellComponent } from '../auth-shell/auth-shell.component';

type ActivationStatus = 'loading' | 'success' | 'error';

@Component({
  selector: 'app-activation',
  standalone: true,
  imports: [CommonModule, RouterLink, AuthShellComponent],
  templateUrl: './activation.component.html',
  styleUrls: ['./activation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivationComponent implements OnInit {
  status = signal<ActivationStatus>('loading');

  constructor(
    private auth: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const token = this.route.snapshot.paramMap.get('token');
    if (!token) {
      this.status.set('error');
      return;
    }
    this.auth.activate(token).subscribe({
      next: () => {
        // activate() já abriu a sessão; mandamos direto para a área
        // logada para evitar que o usuário tenha de re-digitar
        // email/senha (era onde a maioria dos logins falhavam).
        this.status.set('success');
        this.cdr.markForCheck();
        setTimeout(() => this.router.navigate(['/dashboard']), 1600);
      },
      error: () => {
        this.status.set('error');
        this.cdr.markForCheck();
      }
    });
  }
}
