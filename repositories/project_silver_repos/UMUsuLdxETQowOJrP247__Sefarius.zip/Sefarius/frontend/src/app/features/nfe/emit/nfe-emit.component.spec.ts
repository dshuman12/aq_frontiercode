import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { ApiService } from '@app/shared/services/api.service';
import { ViaCepService } from '@app/shared/services/viacep.service';
import { ToastService } from '@app/shared/services/toast.service';
import { NFeEmitComponent } from './nfe-emit.component';
import { EmitNFeResponse } from '@app/shared/models/nfe.models';
import { Product } from '@app/shared/models/api.models';

const DRAFT_KEY = 'sefarius:nfe-emit-draft';

interface ApiMock {
  emitNFe: jest.Mock;
  searchProducts: jest.Mock;
  listNFe: jest.Mock;
}

interface ViaCepMock {
  lookup: jest.Mock;
}

interface ToastMock {
  success: jest.Mock;
  error: jest.Mock;
}

function makeApiMock(): ApiMock {
  return {
    emitNFe: jest.fn(),
    searchProducts: jest
      .fn()
      .mockReturnValue(of({ success: true, data: { items: [] }, code: 200 })),
    // Bug Sweep 2: NFeEmitComponent calls listNFe on init for the
    // n_nf auto-suggest. Default returns an empty list — tests that
    // exercise the suggestion override this explicitly.
    listNFe: jest
      .fn()
      .mockReturnValue(
        of({ success: true, data: { items: [], total: 0, limit: 50, offset: 0 }, code: 200 })
      )
  };
}

function makeToastMock(): ToastMock {
  return {
    success: jest.fn(),
    error: jest.fn()
  };
}

// Default ViaCEP mock returns null so the lookup is a no-op for the
// wide majority of tests that just want to fill CEP fields. Tests
// that exercise the CEP autopopulation override .lookup explicitly.
function makeViaCepMock(): ViaCepMock {
  return {
    lookup: jest.fn().mockReturnValue(of(null))
  };
}

// Sample product wired exactly like the backend would respond after
// commit 2/6 — 7 fiscal defaults + ncm/valor_unitario set so the
// onProductSelected patches end up exercising every branch.
const sampleProduct: Product = {
  id: 'prod-1',
  code: 'P-001',
  description: 'Produto teste',
  balance: 10,
  version: 1,
  ncm: '85171300',
  cfop_padrao_saida: '5102',
  u_com: 'PC',
  valor_unitario: 250.5,
  origem: '0',
  cst_icms: '00',
  p_icms: 18,
  cst_pis: '49',
  cst_cofins: '49',
  created_at: '',
  updated_at: ''
};

function buildModule(api: ApiMock, navigate?: jest.Mock, viaCep?: ViaCepMock, toast?: ToastMock) {
  TestBed.resetTestingModule();
  TestBed.configureTestingModule({
    imports: [NFeEmitComponent, NoopAnimationsModule],
    providers: [
      { provide: ApiService, useValue: api },
      { provide: ViaCepService, useValue: viaCep ?? makeViaCepMock() },
      { provide: ToastService, useValue: toast ?? makeToastMock() },
      provideRouter([]),
      provideHttpClient(),
      provideHttpClientTesting()
    ]
  });
  if (navigate) {
    const router = TestBed.inject(Router);
    Object.defineProperty(router, 'navigate', {
      value: navigate,
      writable: true,
      configurable: true
    });
  }
  return TestBed;
}

function fillValidForm(component: NFeEmitComponent): void {
  component.ide.patchValue({
    n_nf: '1',
    c_mun_fg: '4314902'
  });
  component.emit.patchValue({
    cnpj: '11222333000181',
    x_nome: 'Empresa Teste LTDA',
    ie: '0123456789',
    x_lgr: 'Rua das Flores',
    nro: '100',
    x_bairro: 'Centro',
    c_mun: '4314902',
    x_mun: 'Porto Alegre',
    uf: 'RS',
    cep: '90010000'
  });
  component.dest.patchValue({
    cnpj: '11444777000161',
    x_nome: 'Cliente Teste',
    x_lgr: 'Av. Brasil',
    nro: '200',
    x_bairro: 'Bairro',
    c_mun: '4314902',
    x_mun: 'Porto Alegre',
    uf: 'RS'
  });
  // Bug Sweep 2: v_prod and v_bc are auto-derived from q_com × v_un_com.
  // Setting v_un_com triggers the recompute subscription which writes
  // v_prod/v_bc back. q_com defaults to '1.0000', so total is 100.00.
  component.itemControl(0).patchValue({
    c_prod: 'P001',
    x_prod: 'Produto teste',
    ncm: '12345678',
    v_un_com: '100.00'
  });
}

describe('NFeEmitComponent', () => {
  let fixture: ComponentFixture<NFeEmitComponent>;
  let component: NFeEmitComponent;
  let api: ApiMock;
  let navigate: jest.Mock;

  beforeEach(() => {
    localStorage.removeItem(DRAFT_KEY);
    api = makeApiMock();
    navigate = jest.fn();
    buildModule(api, navigate);
    fixture = TestBed.createComponent(NFeEmitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    localStorage.removeItem(DRAFT_KEY);
  });

  it('initializes with sensible defaults', () => {
    expect(component.ide.value['serie']).toBe('1');
    expect(component.ide.value['tp_amb']).toBe('2');
    expect(component.ide.value['c_uf']).toBe('43');
    expect(component.emit.value['uf']).toBe('RS');
    expect(component.emit.value['crt']).toBe('3');
    expect(component.dest.value['ind_ie_dest']).toBe('9');
    expect(component.items.length).toBe(1);
  });

  it('starts with form invalid (n_nf and c_mun_fg are empty)', () => {
    expect(component.form.invalid).toBe(true);
  });

  it('addItem appends a new item formgroup, removeItem removes by index', () => {
    component.addItem();
    expect(component.items.length).toBe(2);
    component.removeItem(0);
    expect(component.items.length).toBe(1);
  });

  it('removeItem refuses to drop the last item', () => {
    expect(component.items.length).toBe(1);
    component.removeItem(0);
    expect(component.items.length).toBe(1);
  });

  it('changing emit.uf derives ide.c_uf to the matching IBGE code', () => {
    component.emit.get('uf')!.setValue('SP');
    expect(component.ide.value['c_uf']).toBe('35');

    component.emit.get('uf')!.setValue('PR');
    expect(component.ide.value['c_uf']).toBe('41');
  });

  it('does not overwrite c_uf when uf is unknown', () => {
    component.ide.patchValue({ c_uf: '43' });
    component.emit.get('uf')!.setValue('XX');
    expect(component.ide.value['c_uf']).toBe('43');
  });

  it('rejects invalid CNPJ on emit.cnpj', () => {
    component.emit.get('cnpj')!.setValue('11222333000180');
    expect(component.emit.get('cnpj')!.errors).toEqual({ cnpj: true });
    component.emit.get('cnpj')!.setValue('11222333000181');
    expect(component.emit.get('cnpj')!.valid).toBe(true);
  });

  it('flags destDocXor when both CNPJ and CPF given', () => {
    component.dest.patchValue({ cnpj: '11222333000181', cpf: '39053344705' });
    expect(component.dest.errors).toEqual({ destDocXor: 'both' });
  });

  it('flags destDocXor when neither given', () => {
    component.dest.patchValue({ cnpj: '', cpf: '' });
    expect(component.dest.errors).toEqual({ destDocXor: 'none' });
  });

  it('totalItems sums v_prod across all items in the array', () => {
    component.itemControl(0).patchValue({ v_prod: '100.00' });
    component.addItem();
    component.itemControl(1).patchValue({ v_prod: '50.50' });
    expect(component.totalItems()).toBe('150.50');
  });

  it('autosaves draft to localStorage on form changes', () => {
    component.ide.patchValue({ n_nf: '42' });
    fixture.detectChanges();
    const stored = localStorage.getItem(DRAFT_KEY);
    expect(stored).toBeTruthy();
    const parsed = JSON.parse(stored!);
    expect(parsed.ide.n_nf).toBe('42');
  });

  it('clearDraft removes the localStorage entry', () => {
    component.ide.patchValue({ n_nf: '7' });
    fixture.detectChanges();
    expect(localStorage.getItem(DRAFT_KEY)).toBeTruthy();
    component.clearDraft();
    expect(localStorage.getItem(DRAFT_KEY)).toBeNull();
    expect(component.draftRestored).toBe(false);
  });

  it('restores draft from localStorage on init (with 2 items)', () => {
    const draft = {
      ide: { n_nf: '99', nat_op: 'Compra', c_mun_fg: '3550308' },
      emit: { x_nome: 'Restored Co' },
      dest: {},
      items: [
        { c_prod: 'A', x_prod: 'Item A' },
        { c_prod: 'B', x_prod: 'Item B' }
      ]
    };
    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));

    buildModule(api, navigate);
    const f = TestBed.createComponent(NFeEmitComponent);
    f.detectChanges();

    expect(f.componentInstance.draftRestored).toBe(true);
    expect(f.componentInstance.ide.value['n_nf']).toBe('99');
    expect(f.componentInstance.items.length).toBe(2);
    expect(f.componentInstance.itemControl(0).value['c_prod']).toBe('A');
    expect(f.componentInstance.itemControl(1).value['c_prod']).toBe('B');
  });

  it('ignores corrupt draft JSON without throwing', () => {
    localStorage.setItem(DRAFT_KEY, '{not json');

    buildModule(api, navigate);
    expect(() => {
      const f = TestBed.createComponent(NFeEmitComponent);
      f.detectChanges();
    }).not.toThrow();
  });

  it('submit() while invalid does NOT call api.emitNFe and marks all touched', () => {
    component.submit();
    expect(api.emitNFe).not.toHaveBeenCalled();
    expect(component.ide.get('n_nf')!.touched).toBe(true);
  });

  it('submit() with valid form posts the request payload', () => {
    fillValidForm(component);
    expect(component.form.valid).toBe(true);

    const okResp: EmitNFeResponse = {
      chave: 'C44',
      status: 'AUTHORIZED',
      lifecycle: 'AUTHORIZED',
      c_stat: '100',
      x_motivo: 'Autorizado o uso da NF-e'
    };
    api.emitNFe.mockReturnValue(of({ success: true, data: okResp, code: 201 }));

    component.submit();

    expect(api.emitNFe).toHaveBeenCalledTimes(1);
    const payload = api.emitNFe.mock.calls[0][0];
    expect(payload.emit.cnpj).toBe('11222333000181');
    expect(payload.dest.cnpj).toBe('11444777000161');
    expect(payload.dest.cpf).toBeUndefined();
    expect(payload.items).toHaveLength(1);
    expect(payload.ide.dh_emi).toMatch(/-03:00$/);
  });

  it('submit() AUTHORIZED → success feedback, draft cleared, navigate after delay', fakeAsync(() => {
    fillValidForm(component);
    api.emitNFe.mockReturnValue(
      of({
        success: true,
        data: {
          chave: 'CHAVE_OK',
          status: 'AUTHORIZED',
          lifecycle: 'AUTHORIZED',
          c_stat: '100',
          x_motivo: 'Autorizado o uso da NF-e'
        },
        code: 201
      })
    );

    component.submit();
    expect(component.feedback?.kind).toBe('success');
    tick(1500);
    expect(navigate).toHaveBeenCalledWith(['/nfe', 'CHAVE_OK']);
    expect(localStorage.getItem(DRAFT_KEY)).toBeNull();
  }));

  it('submit() REJECTED → rejection feedback with cStat and motivo', () => {
    fillValidForm(component);
    api.emitNFe.mockReturnValue(
      of({
        success: true,
        data: {
          chave: 'CHAVE_REJ',
          status: 'REJECTED',
          lifecycle: 'REJECTED',
          c_stat: '539',
          x_motivo: 'Duplicidade de NF-e',
          rejection: { CStat: '539', XMotivo: 'Duplicidade de NF-e' }
        },
        code: 201
      })
    );

    component.submit();

    expect(component.feedback?.kind).toBe('rejection');
    expect(component.feedback?.cStat).toBe('539');
    expect(component.feedback?.text).toContain('539');
    expect(component.feedback?.text).toContain('Duplicidade');
    expect(navigate).not.toHaveBeenCalled();
  });

  it('submit() with HTTP 502 → "SEFAZ indisponível" message', () => {
    fillValidForm(component);
    api.emitNFe.mockReturnValue(throwError(() => ({ status: 502 })));

    component.submit();

    expect(component.feedback?.kind).toBe('error');
    expect(component.feedback?.text).toContain('SEFAZ indisponível');
  });

  it('submit() with HTTP 422 + issue array → renders validation issues', () => {
    // Wire contract: backend ValidationIssue marshals as lowercase JSON
    // keys (json tags in domain/nfe/validator.go). Locked in by
    // backend TestValidationIssue_JSONShape — if those tags regress to
    // PascalCase, the user sees "?: (sem mensagem)" in formatHttpError
    // instead of the field/message text.
    fillValidForm(component);
    api.emitNFe.mockReturnValue(
      throwError(() => ({
        status: 422,
        error: {
          error: 'validation failed',
          data: [
            {
              severity: 'error',
              field: 'Total.ICMSTot.vPIS',
              message: 'declarado=3.71 itens somam=8.35'
            },
            { severity: 'error', field: 'items[0].ncm', message: 'NCM must be 8 digits' }
          ]
        }
      }))
    );

    component.submit();

    expect(component.feedback?.kind).toBe('error');
    expect(component.feedback?.text).toContain('Total.ICMSTot.vPIS');
    expect(component.feedback?.text).toContain('declarado=3.71');
    // Negative assertion locks the bug: if formatHttpError reads the
    // wrong key (e.g. PascalCase from a regressed backend without json
    // tags), it falls back to "?: (sem mensagem)" — this string must
    // never appear when the issue array is well-formed.
    expect(component.feedback?.text).not.toContain('(sem mensagem)');
  });

  it('submit() with generic error falls back to message', () => {
    fillValidForm(component);
    api.emitNFe.mockReturnValue(throwError(() => ({ message: 'network down' })));

    component.submit();

    expect(component.feedback?.kind).toBe('error');
    expect(component.feedback?.text).toContain('network down');
  });

  it('cancelEmit navigates to /nfe', () => {
    component.cancelEmit();
    expect(navigate).toHaveBeenCalledWith(['/nfe']);
  });

  it('dismissFeedback clears the feedback object', () => {
    component.feedback = { kind: 'error', text: 'x' };
    component.dismissFeedback();
    expect(component.feedback).toBeNull();
  });

  it('isFieldInvalid returns true only after touched/dirty', () => {
    const ctrl = component.emit.get('cnpj')!;
    ctrl.setValue('bad');
    expect(component.isFieldInvalid(component.emit, 'cnpj')).toBe(false);
    ctrl.markAsTouched();
    expect(component.isFieldInvalid(component.emit, 'cnpj')).toBe(true);
  });

  it('toRequest strips empty optional dest fields (ie, cep, cpf when cnpj set)', () => {
    fillValidForm(component);
    api.emitNFe.mockReturnValue(
      of({
        success: true,
        data: {
          chave: 'X',
          status: 'AUTHORIZED' as const,
          lifecycle: 'AUTHORIZED' as const,
          c_stat: '100',
          x_motivo: 'ok'
        },
        code: 201
      })
    );
    component.submit();
    const payload = api.emitNFe.mock.calls[0][0];
    expect('cpf' in payload.dest).toBe(false);
    expect('ie' in payload.dest).toBe(false);
    expect('cep' in payload.dest).toBe(false);
  });

  it('markStepTouched(group) marks every descendant control as touched (regression: stepper Next was disabled, hiding the validation feedback the user was supposed to see)', () => {
    // ide starts with n_nf and c_mun_fg empty and untouched. Without
    // markStepTouched the per-field error spans (gated by touched ||
    // dirty) never render, so when the user clicks "Próximo" they see
    // a silently disabled-feeling button and no inline feedback. After
    // the fix, calling markStepTouched marks the whole subgroup so
    // isFieldInvalid flips to true everywhere and the spans render.
    const nNf = component.ide.get('n_nf')!;
    const cMunFg = component.ide.get('c_mun_fg')!;
    expect(nNf.touched).toBe(false);
    expect(cMunFg.touched).toBe(false);
    expect(component.isFieldInvalid(component.ide, 'n_nf')).toBe(false);
    expect(component.isFieldInvalid(component.ide, 'c_mun_fg')).toBe(false);

    component.markStepTouched(component.ide);

    expect(nNf.touched).toBe(true);
    expect(cMunFg.touched).toBe(true);
    expect(component.isFieldInvalid(component.ide, 'n_nf')).toBe(true);
    expect(component.isFieldInvalid(component.ide, 'c_mun_fg')).toBe(true);
  });

  it('markStepTouched on the items FormArray recurses into each item group', () => {
    component.addItem();
    expect(component.items.length).toBe(2);
    const cProd0 = component.items.at(0).get('c_prod')!;
    const ncm1 = component.items.at(1).get('ncm')!;
    expect(cProd0.touched).toBe(false);
    expect(ncm1.touched).toBe(false);

    component.markStepTouched(component.items);

    expect(cProd0.touched).toBe(true);
    expect(ncm1.touched).toBe(true);
  });

  describe('Step 4 product autocomplete (sprint Catálogo Fiscal)', () => {
    it('skips searchProducts when query is shorter than 2 chars', fakeAsync(() => {
      api.searchProducts.mockClear();
      component.itemControl(0).get('productSearch')?.setValue('a');
      tick(300); // past the 250ms debounce
      expect(api.searchProducts).not.toHaveBeenCalled();
      expect(component.itemSearchResults[0]).toEqual([]);
    }));

    it('debounces and calls searchProducts after 2+ chars', fakeAsync(() => {
      api.searchProducts.mockReturnValueOnce(
        of({ success: true, data: { items: [sampleProduct] }, code: 200 })
      );
      component.itemControl(0).get('productSearch')?.setValue('Pro');
      // Before debounce expires, no call yet.
      tick(100);
      expect(api.searchProducts).not.toHaveBeenCalled();
      // After debounce, the call fires once.
      tick(200);
      expect(api.searchProducts).toHaveBeenCalledWith('Pro', 10);
      expect(component.itemSearchResults[0]).toEqual([sampleProduct]);
    }));

    it('trims whitespace and uses the trimmed length for the floor', fakeAsync(() => {
      api.searchProducts.mockClear();
      component.itemControl(0).get('productSearch')?.setValue('  a  ');
      tick(300);
      expect(api.searchProducts).not.toHaveBeenCalled();
      expect(component.itemSearchResults[0]).toEqual([]);
    }));

    it('clears results on subsequent search error and never throws', fakeAsync(() => {
      api.searchProducts.mockReturnValueOnce(throwError(() => ({ status: 500 })));
      component.itemControl(0).get('productSearch')?.setValue('xyz');
      tick(300);
      expect(component.itemSearchResults[0]).toEqual([]);
    }));

    it('onProductSelected patches the item with all fiscal fields and recomputes totals', () => {
      // Quantity defaults to 1.0000 — leave it; with valor_unitario 250.50
      // the recomputed v_prod and v_bc must equal "250.50".
      const event = { option: { value: sampleProduct } } as unknown as Parameters<
        NFeEmitComponent['onProductSelected']
      >[0];
      component.onProductSelected(event, 0);

      const item = component.itemControl(0).value;
      expect(item.c_prod).toBe('P-001');
      expect(item.x_prod).toBe('Produto teste');
      expect(item.ncm).toBe('85171300');
      expect(item.cfop).toBe('5102');
      expect(item.u_com).toBe('PC');
      expect(item.v_un_com).toBe('250.5000');
      expect(item.v_prod).toBe('250.50');
      expect(item.v_bc).toBe('250.50');
      expect(item.p_icms).toBe('18.00');
      // The search input becomes the formatted summary so the user sees
      // what was selected.
      expect(item.productSearch).toBe('P-001 — Produto teste');
    });

    it('preserves later manual edits to v_un_com after a product is selected', () => {
      const event = { option: { value: sampleProduct } } as unknown as Parameters<
        NFeEmitComponent['onProductSelected']
      >[0];
      component.onProductSelected(event, 0);
      // Operator overrides the unit price (promo).
      component.itemControl(0).patchValue({ v_un_com: '199.0000' });
      expect(component.itemControl(0).value.v_un_com).toBe('199.0000');
      // c_prod stays linked to the selected product.
      expect(component.itemControl(0).value.c_prod).toBe('P-001');
    });

    it('strips productSearch from the EmitNFeRequest payload', () => {
      fillValidForm(component);
      component.itemControl(0).patchValue({ productSearch: 'P-001 — Produto teste' });
      api.emitNFe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: 'X',
            status: 'AUTHORIZED' as const,
            lifecycle: 'AUTHORIZED' as const,
            c_stat: '100',
            x_motivo: 'ok'
          },
          code: 201
        })
      );
      component.submit();
      const payload = api.emitNFe.mock.calls[0][0];
      expect('productSearch' in payload.items[0]).toBe(false);
    });

    it('addItem grows itemSearchResults in lock-step with the FormArray', () => {
      const before = component.itemSearchResults.length;
      component.addItem();
      expect(component.itemSearchResults.length).toBe(before + 1);
      expect(component.itemSearchResults[before]).toEqual([]);
    });

    it('removeItem shrinks itemSearchResults at the same index', () => {
      component.addItem();
      component.itemSearchResults[0] = [sampleProduct];
      component.itemSearchResults[1] = [];
      component.removeItem(0);
      // After removing index 0, what was at index 1 should now be at 0.
      expect(component.itemSearchResults.length).toBe(1);
      expect(component.itemSearchResults[0]).toEqual([]);
    });
  });

  it('handles localStorage write errors silently', () => {
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = jest.fn(() => {
      throw new Error('quota');
    });
    expect(() => component.ide.patchValue({ n_nf: '5' })).not.toThrow();
    Storage.prototype.setItem = original;
  });

  describe('Bug Sweep 2026-05-07 — incomplete-product handling', () => {
    it('isProductIncomplete returns true when NCM is missing', () => {
      const partial: Product = { ...sampleProduct, ncm: null };
      expect(component.isProductIncomplete(partial)).toBe(true);
    });

    it('isProductIncomplete returns true when valor_unitario is null', () => {
      const partial: Product = { ...sampleProduct, valor_unitario: null };
      expect(component.isProductIncomplete(partial)).toBe(true);
    });

    it('isProductIncomplete returns false when NCM 8 digits and valor > 0', () => {
      expect(component.isProductIncomplete(sampleProduct)).toBe(false);
    });

    it('onProductSelected sets itemIncompleteWarning when NCM is missing', () => {
      const partial: Product = { ...sampleProduct, ncm: null };
      const event = { option: { value: partial } } as unknown as Parameters<
        NFeEmitComponent['onProductSelected']
      >[0];
      component.onProductSelected(event, 0);
      // Lock-in: when the user picks an incomplete product, a per-item
      // warning identifies *which* fields are missing (NCM, here) so
      // they understand why the patch left fields blank. Regression
      // here would mean the autocomplete silently dumps half of an
      // item and the user discovers the gaps only at submit time.
      expect(component.itemIncompleteWarning[0]).toContain('NCM');
      expect(component.itemIncompleteWarning[0]).not.toContain('valor unitário');
    });

    it('onProductSelected mentions both NCM and valor unitário when both missing', () => {
      const partial: Product = { ...sampleProduct, ncm: null, valor_unitario: null };
      const event = { option: { value: partial } } as unknown as Parameters<
        NFeEmitComponent['onProductSelected']
      >[0];
      component.onProductSelected(event, 0);
      expect(component.itemIncompleteWarning[0]).toContain('NCM');
      expect(component.itemIncompleteWarning[0]).toContain('valor unitário');
    });

    it('onProductSelected clears itemIncompleteWarning when product is complete', () => {
      // Pre-seed a warning, then select a complete product — the
      // warning must clear, otherwise it sticks across selections.
      component.itemIncompleteWarning[0] = 'stale warning';
      const event = { option: { value: sampleProduct } } as unknown as Parameters<
        NFeEmitComponent['onProductSelected']
      >[0];
      component.onProductSelected(event, 0);
      expect(component.itemIncompleteWarning[0]).toBeNull();
    });
  });

  describe('Bug Sweep 2026-05-07 — id_dest auto-adjust + cross-validator', () => {
    it('auto-adjusts id_dest to 2 when dest.uf differs from emit.uf', () => {
      // Defaults: emit.uf=RS, dest.uf=RS, id_dest=1 — consistent.
      expect(component.ide.value['id_dest']).toBe('1');
      component.dest.get('uf')!.setValue('SP');
      expect(component.ide.value['id_dest']).toBe('2');
      expect(component.idDestAutoAdjusted).toBe(true);
    });

    it('auto-adjusts id_dest back to 1 when UFs become equal again', () => {
      component.dest.get('uf')!.setValue('SP');
      expect(component.ide.value['id_dest']).toBe('2');
      component.dest.get('uf')!.setValue('RS');
      expect(component.ide.value['id_dest']).toBe('1');
    });

    it('manual id_dest edit clears the auto-adjusted banner state', () => {
      component.dest.get('uf')!.setValue('SP');
      expect(component.idDestAutoAdjusted).toBe(true);
      component.ide.get('id_dest')!.setValue('3');
      expect(component.idDestAutoAdjusted).toBe(false);
    });

    it('does not overwrite id_dest=3 (operator chose exterior)', () => {
      component.ide.get('id_dest')!.setValue('3');
      // The manual override flips idDestAutoAdjusted off.
      component.dest.get('uf')!.setValue('SP');
      expect(component.ide.value['id_dest']).toBe('3');
    });

    it('cross-validator flags shouldBeInternal when UFs equal but id_dest=2', () => {
      // Force the inconsistency directly without going through the
      // auto-adjust subscription so we exercise the validator's own
      // logic, not the side-effect that masks it in normal flow.
      component.emit.get('uf')!.setValue('RS');
      component.dest.get('uf')!.setValue('RS');
      component.ide.patchValue({ id_dest: '2' }, { emitEvent: false });
      component.form.updateValueAndValidity();
      expect(component.form.errors).toEqual({ idDestMismatch: 'shouldBeInternal' });
    });

    it('cross-validator flags shouldBeInterstate when UFs differ but id_dest=1', () => {
      component.emit.get('uf')!.setValue('RS');
      component.dest.get('uf')!.setValue('SP');
      component.ide.patchValue({ id_dest: '1' }, { emitEvent: false });
      component.form.updateValueAndValidity();
      expect(component.form.errors).toEqual({ idDestMismatch: 'shouldBeInterstate' });
    });

    it('cross-validator stays null when id_dest matches the UF relationship', () => {
      component.emit.get('uf')!.setValue('RS');
      component.dest.get('uf')!.setValue('SP');
      component.ide.patchValue({ id_dest: '2' }, { emitEvent: false });
      component.form.updateValueAndValidity();
      expect(component.form.errors).toBeNull();
    });
  });

  describe('Bug Sweep 2 (2026-05-07) — item totals auto-recompute', () => {
    it('changing q_com recomputes v_prod and v_bc', () => {
      component.itemControl(0).patchValue({ v_un_com: '100.00' });
      expect(component.itemControl(0).value.v_prod).toBe('100.00');
      component.itemControl(0).patchValue({ q_com: '3' });
      // q × u = 3 × 100 = 300.00
      expect(component.itemControl(0).value.v_prod).toBe('300.00');
      expect(component.itemControl(0).value.v_bc).toBe('300.00');
    });

    it('changing v_un_com recomputes v_prod and v_bc', () => {
      component.itemControl(0).patchValue({ q_com: '2' });
      component.itemControl(0).patchValue({ v_un_com: '50.00' });
      expect(component.itemControl(0).value.v_prod).toBe('100.00');
      expect(component.itemControl(0).value.v_bc).toBe('100.00');
    });

    it('formatQty normalizes "2" to "2.0000" on blur', () => {
      component.itemControl(0).patchValue({ q_com: '2' });
      component.formatQty(0);
      expect(component.itemControl(0).value.q_com).toBe('2.0000');
    });

    it('formatQty handles comma decimal separator on blur', () => {
      component.itemControl(0).patchValue({ q_com: '2,5' });
      component.formatQty(0);
      expect(component.itemControl(0).value.q_com).toBe('2.5000');
    });

    it('formatUnitValue normalizes "100" to "100.0000" on blur', () => {
      component.itemControl(0).patchValue({ v_un_com: '100' });
      component.formatUnitValue(0);
      expect(component.itemControl(0).value.v_un_com).toBe('100.0000');
    });

    it('q_com pattern accepts loose decimal forms (regression: "2" was rejected)', () => {
      // Lock-in: with the previous strict pattern /^\d+\.\d{4}$/ the
      // user got "Formato 0.0000 (4 casas)" the moment they typed "2".
      // The new pattern accepts the looser form and the blur handler
      // normalizes it to 4 decimals.
      const ctrl = component.itemControl(0).get('q_com')!;
      ctrl.setValue('2');
      expect(ctrl.errors).toBeNull();
      ctrl.setValue('2.5');
      expect(ctrl.errors).toBeNull();
      ctrl.setValue('2.0000');
      expect(ctrl.errors).toBeNull();
    });
  });

  describe('Bug Sweep 2 (2026-05-07) — CFOP filtering by id_dest', () => {
    it('cfopOptionsFor("1") returns 5xxx interna list', () => {
      const opts = component.cfopOptionsFor('1');
      expect(opts.length).toBeGreaterThan(0);
      for (const o of opts) {
        expect(o.code.startsWith('5')).toBe(true);
      }
    });

    it('cfopOptionsFor("2") returns 6xxx interestadual list', () => {
      const opts = component.cfopOptionsFor('2');
      expect(opts.length).toBeGreaterThan(0);
      for (const o of opts) {
        expect(o.code.startsWith('6')).toBe(true);
      }
    });

    it('changing id_dest from 1 to 2 auto-converts item CFOP from 5102 to 6102', () => {
      // Item starts with cfop=5102 by default.
      expect(component.itemControl(0).value.cfop).toBe('5102');
      component.ide.get('id_dest')!.setValue('2');
      expect(component.itemControl(0).value.cfop).toBe('6102');
    });

    it('changing id_dest from 2 back to 1 reverses the CFOP flip', () => {
      component.ide.get('id_dest')!.setValue('2');
      expect(component.itemControl(0).value.cfop).toBe('6102');
      component.ide.get('id_dest')!.setValue('1');
      expect(component.itemControl(0).value.cfop).toBe('5102');
    });

    it('id_dest=3 (exterior) does NOT touch the item CFOP', () => {
      component.itemControl(0).patchValue({ cfop: '5101' });
      component.ide.get('id_dest')!.setValue('3');
      expect(component.itemControl(0).value.cfop).toBe('5101');
    });
  });

  describe('Bug Sweep 2 (2026-05-07) — ViaCEP undo notice', () => {
    it('populates viaCepNotice.emit and viaCepUndo on successful overwrite', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      // Pre-fill emit address as if user typed something.
      component.emit.patchValue({ x_lgr: 'Rua Original', x_bairro: 'Bairro Original' });
      viaCep.lookup.mockReturnValue(
        of({
          cep: '01310-100',
          logradouro: 'Avenida Paulista',
          bairro: 'Bela Vista',
          localidade: 'São Paulo',
          uf: 'SP',
          ibge: '3550308'
        })
      );
      component.emit.get('cep')!.setValue('01310100');
      expect(component.viaCepNotice.emit).toContain('ViaCEP');
      expect(component.viaCepNotice.emit).toContain('sobrescrito');
    });

    it('undoViaCep restores the pre-lookup snapshot', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      component.emit.patchValue({
        x_lgr: 'Rua Original',
        x_bairro: 'Bairro Original',
        x_mun: 'Cidade Original',
        uf: 'RS',
        c_mun: '4314902'
      });
      viaCep.lookup.mockReturnValue(
        of({
          cep: '01310-100',
          logradouro: 'Avenida Paulista',
          bairro: 'Bela Vista',
          localidade: 'São Paulo',
          uf: 'SP',
          ibge: '3550308'
        })
      );
      component.emit.get('cep')!.setValue('01310100');
      expect(component.emit.value['x_lgr']).toBe('Avenida Paulista');
      component.undoViaCep('emit');
      expect(component.emit.value['x_lgr']).toBe('Rua Original');
      expect(component.emit.value['uf']).toBe('RS');
      expect(component.viaCepNotice.emit).toBeNull();
    });

    it('dismissViaCepNotice clears notice without restoring values', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      component.emit.patchValue({ x_lgr: 'Rua Original' });
      viaCep.lookup.mockReturnValue(
        of({
          cep: '01310-100',
          logradouro: 'Avenida Paulista',
          bairro: '',
          localidade: '',
          uf: '',
          ibge: ''
        })
      );
      component.emit.get('cep')!.setValue('01310100');
      expect(component.viaCepNotice.emit).not.toBeNull();
      component.dismissViaCepNotice('emit');
      expect(component.viaCepNotice.emit).toBeNull();
      // Value stays patched.
      expect(component.emit.value['x_lgr']).toBe('Avenida Paulista');
    });
  });

  describe('Bug Sweep 2 (2026-05-07) — n_nf auto-suggest', () => {
    it('suggests next n_nf as max(existing) + 1 from chave digits', () => {
      // Real NF-e chave is exactly 44 digits with n_nf at positions
      // 25-33 (9 digits). Layout: 2 cUF + 4 AAMM + 14 CNPJ + 2 mod
      // + 3 série + 9 nNF + 1 tpEmis + 8 cNF + 1 cDV = 44.
      // Prefix is exactly 25 chars: 2 cUF + 4 AAMM + 14 CNPJ + 2 mod + 3 série.
      // listNFe response was wrapped in PaginatedResponse on 2026-05-08
      // (commit d414bc4) — the mock below mirrors {items, total, limit,
      // offset}; suggestNextNNf reads resp.data?.items.
      const chave = (n: string) => `4324051234567800018155001${n.padStart(9, '0')}1123456789`;
      const api = makeApiMock();
      api.listNFe.mockReturnValue(
        of({
          success: true,
          data: {
            items: [
              {
                chave: chave('42'),
                lifecycle: 'AUTHORIZED',
                c_stat: '100',
                x_motivo: 'ok',
                created_at: '',
                updated_at: ''
              },
              {
                chave: chave('39'),
                lifecycle: 'AUTHORIZED',
                c_stat: '100',
                x_motivo: 'ok',
                created_at: '',
                updated_at: ''
              }
            ],
            total: 2,
            limit: 50,
            offset: 0
          },
          code: 200
        })
      );
      buildModule(api, navigate);
      const f = TestBed.createComponent(NFeEmitComponent);
      f.detectChanges();
      // max=42 → suggest 43.
      expect(f.componentInstance.ide.value['n_nf']).toBe('43');
    });

    it('does not overwrite n_nf when a draft already restored a value', () => {
      const draft = {
        ide: { n_nf: '999', nat_op: 'Compra', c_mun_fg: '3550308' },
        emit: {},
        dest: {},
        items: [{ c_prod: 'A' }]
      };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      // Prefix is exactly 25 chars: 2 cUF + 4 AAMM + 14 CNPJ + 2 mod + 3 série.
      const chave = (n: string) => `4324051234567800018155001${n.padStart(9, '0')}1123456789`;
      const api = makeApiMock();
      api.listNFe.mockReturnValue(
        of({
          success: true,
          data: {
            items: [
              {
                chave: chave('42'),
                lifecycle: 'AUTHORIZED',
                c_stat: '100',
                x_motivo: 'ok',
                created_at: '',
                updated_at: ''
              }
            ],
            total: 1,
            limit: 50,
            offset: 0
          },
          code: 200
        })
      );
      buildModule(api, navigate);
      const f = TestBed.createComponent(NFeEmitComponent);
      f.detectChanges();
      expect(f.componentInstance.ide.value['n_nf']).toBe('999');
    });
  });

  describe('Bug Sweep 2 (2026-05-07) — toast on emit outcomes', () => {
    it('AUTHORIZED triggers a success toast in addition to the banner', () => {
      const toastMock = makeToastMock();
      buildModule(api, navigate, undefined, toastMock);
      const f = TestBed.createComponent(NFeEmitComponent);
      f.detectChanges();
      const c = f.componentInstance;
      fillValidForm(c);
      api.emitNFe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: '4324050000000000000000000010000000004200000000',
            status: 'AUTHORIZED' as const,
            lifecycle: 'AUTHORIZED' as const,
            c_stat: '100',
            x_motivo: 'ok'
          },
          code: 201
        })
      );
      c.submit();
      expect(toastMock.success).toHaveBeenCalled();
    });

    it('REJECTED triggers an error toast', () => {
      const toastMock = makeToastMock();
      buildModule(api, navigate, undefined, toastMock);
      const f = TestBed.createComponent(NFeEmitComponent);
      f.detectChanges();
      const c = f.componentInstance;
      fillValidForm(c);
      api.emitNFe.mockReturnValue(
        of({
          success: true,
          data: {
            chave: 'C',
            status: 'REJECTED' as const,
            lifecycle: 'REJECTED' as const,
            c_stat: '539',
            x_motivo: 'Duplicidade',
            rejection: { CStat: '539', XMotivo: 'Duplicidade' }
          },
          code: 201
        })
      );
      c.submit();
      expect(toastMock.error).toHaveBeenCalled();
    });
  });

  describe('Bug Sweep 2026-05-07 — ViaCEP autocomplete', () => {
    it('triggers ViaCEP lookup when CEP reaches 8 digits', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockClear();
      component.emit.get('cep')!.setValue('90010000');
      expect(viaCep.lookup).toHaveBeenCalledWith('90010000');
    });

    it('does not trigger ViaCEP lookup when CEP is shorter than 8 digits', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockClear();
      component.emit.get('cep')!.setValue('9001000');
      expect(viaCep.lookup).not.toHaveBeenCalled();
    });

    it('patches emit address fields when ViaCEP returns a valid response', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockReturnValue(
        of({
          cep: '01310-100',
          logradouro: 'Avenida Paulista',
          bairro: 'Bela Vista',
          localidade: 'São Paulo',
          uf: 'SP',
          ibge: '3550308'
        })
      );
      component.emit.get('cep')!.setValue('01310100');
      expect(component.emit.value['x_lgr']).toBe('Avenida Paulista');
      expect(component.emit.value['x_bairro']).toBe('Bela Vista');
      expect(component.emit.value['x_mun']).toBe('São Paulo');
      expect(component.emit.value['uf']).toBe('SP');
      expect(component.emit.value['c_mun']).toBe('3550308');
      // c_uf must follow emit.uf (3550308 = SP, c_uf 35).
      expect(component.ide.value['c_uf']).toBe('35');
    });

    it('does not patch when ViaCEP returns null (unknown CEP / network error)', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockReturnValue(of(null));
      const before = component.emit.value['x_lgr'];
      component.emit.get('cep')!.setValue('00000000');
      expect(component.emit.value['x_lgr']).toBe(before);
    });

    it('caches by digits + scope so re-typing the same CEP only hits the network once', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockReturnValue(of(null));
      viaCep.lookup.mockClear();
      component.emit.get('cep')!.setValue('90010000');
      component.emit.get('cep')!.setValue('90010001');
      component.emit.get('cep')!.setValue('90010000');
      // 90010000 was looked up once, 90010001 once — total 2.
      expect(viaCep.lookup).toHaveBeenCalledTimes(2);
    });

    it('emit and dest CEPs are cached independently', () => {
      const viaCep = TestBed.inject(ViaCepService) as unknown as ViaCepMock;
      viaCep.lookup.mockReturnValue(of(null));
      viaCep.lookup.mockClear();
      component.emit.get('cep')!.setValue('90010000');
      component.dest.get('cep')!.setValue('90010000');
      // Same digits but different scope keys → ViaCEP called twice.
      expect(viaCep.lookup).toHaveBeenCalledTimes(2);
    });
  });
});
