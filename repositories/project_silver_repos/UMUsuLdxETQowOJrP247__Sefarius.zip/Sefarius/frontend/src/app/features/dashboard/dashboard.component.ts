/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../shared/services/api.service';
import { BaseComponent } from '@app/shared/components/base.component';
import { APP_CONSTANTS } from '@app/shared/constants/app.constants';
import { Invoice, Product } from '@app/shared/models/api.models';
import { NFeListItem } from '@app/shared/models/nfe.models';
import { CompactCurrencyPipe } from '@app/shared/pipes/compact-currency.pipe';
import { forkJoin, of } from 'rxjs';
import { takeUntil, retry, catchError } from 'rxjs/operators';

/**
 * Componente principal da aplicação (Página Inicial).
 * Herda de BaseComponent para não vazar a inscrição (subscription) de \`forkJoin\`.
 * Utiliza ChangeDetectionStrategy.OnPush focando em alta performance de renderização
 * exigindo o acionamento de \`this.cdr.markForCheck()\` quando o payload assíncrono chega.
 */
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, CompactCurrencyPipe],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent extends BaseComponent implements OnInit {
  productsCount = 0;
  invoicesCount = 0;
  openInvoicesCount = 0;
  // Bug Sweep 2.1 (2026-05-08): faturamento now stored as a raw number
  // so the compactCurrency pipe (display) and Angular's currency pipe
  // (tooltip) can each format it. Previously this was a pre-formatted
  // string ("R$ 0,00"), which the new clamp-and-ellipsis layout could
  // truncate and the tooltip could not "fall back" to the full value.
  faturamento = 0;
  totalStock = 0;

  // Bug Sweep 2 (2026-05-07): NFe stats card on the Visão Geral row.
  // Reviewer flagged the dashboard for showing only legacy /invoices
  // counts while /nfe lived in a parallel section. We surface the 3
  // lifecycle buckets so operators see at a glance what's healthy.
  nfeCount = 0;
  nfeAuthorizedCount = 0;
  nfeCancelledCount = 0;
  nfeRejectedCount = 0;

  /** Lista reduzida e formatada localmente para alimentar a tabela "Últimas Notas Fiscais" */
  recentNotes: {
    number: string;
    status: string;
    responsible: string;
    value: string;
    date: string;
  }[] = [];

  // Bug Sweep 2: separate "NF-e Recentes" section so users see SEFAZ
  // documents alongside the legacy invoices. Truncated chave + status
  // pill + date renders compactly in the same card grid layout.
  recentNFe: {
    chave: string;
    chaveShort: string;
    statusLabel: string;
    statusClass: string;
    date: string;
  }[] = [];

  loading = true;

  constructor(
    private apiService: ApiService,
    private cdr: ChangeDetectorRef
  ) {
    super();
  }

  /**
   * Gatilho de inicialização do ciclo de vida do Angular.
   * Invoca a carga dos dados massivos.
   */
  ngOnInit(): void {
    this.loadData();
  }

  /**
   * Paraleliza o download de ambos os serviços (Stock e Billing)
   * utilizando RXJS \`forkJoin\` para emitir a árvore virtual do Angular
   * apenas uma vez quando todos os dados simultâneos chegarem, evitando flicker.
   */
  private loadData(): void {
    // NFe listing is best-effort — if the endpoint 502s the rest of
    // the dashboard still renders. catchError(() => of empty array)
    // keeps forkJoin from short-circuiting to its global error branch.
    forkJoin([
      this.apiService.getProducts(APP_CONSTANTS.PAGINATION.MAX_LIMIT).pipe(retry(1)),
      this.apiService.getInvoices(APP_CONSTANTS.PAGINATION.MAX_LIMIT).pipe(retry(1)),
      this.apiService
        .listNFe(50, 0)
        .pipe(
          catchError(() =>
            of({ success: false, data: { items: [], total: 0, limit: 0, offset: 0 }, code: 0 })
          )
        )
    ])
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: ([productsResp, invoicesResp, nfeResp]) => {
          const products: Product[] = productsResp.data?.items || [];
          const invoices: Invoice[] = invoicesResp.data?.items || [];
          const nfes: NFeListItem[] = nfeResp.data?.items || [];

          this.productsCount = products.length;
          // Agregação manual do Array inteiro ao invés de endpoints pesados separadamente
          this.totalStock = products.reduce((sum, p) => sum + (p.balance || 0), 0);

          this.invoicesCount = invoices.length;
          this.openInvoicesCount = invoices.filter(i => {
            const s = i.status?.toLowerCase();
            return (
              s === APP_CONSTANTS.INVOICE_STATUS.OPEN || s === APP_CONSTANTS.INVOICE_STATUS.ABERTA
            );
          }).length;

          // Agregação do faturamento absoluto (ignora Notas canceladas para MVP simples).
          // Stored as a raw number so the template can run it through
          // compactCurrency (display) and currency (tooltip) pipes.
          this.faturamento = invoices.reduce((sum, i) => sum + (i.total_amount || 0), 0);

          // NFe lifecycle aggregation. PENDING is intentionally folded
          // into "AUTHORIZED" for the high-level card — operators care
          // about "did this make it through SEFAZ" vs "stuck/rejected".
          this.nfeCount = nfes.length;
          this.nfeAuthorizedCount = nfes.filter(n => n.lifecycle === 'AUTHORIZED').length;
          this.nfeCancelledCount = nfes.filter(n => n.lifecycle === 'CANCELLED').length;
          this.nfeRejectedCount = nfes.filter(n => n.lifecycle === 'REJECTED').length;

          // Pega apenas as 4 primeiras para a mini-tabela e já as deixa formatadas pro template
          this.recentNotes = invoices.slice(0, 4).map(i => ({
            number: `#${i.number}`,
            status: this.getStatus(i),
            responsible: i.created_by || '',
            value: this.formatCurrency(i.total_amount || 0),
            date: i.created_at ? new Date(i.created_at).toLocaleDateString('pt-BR') : ''
          }));

          this.recentNFe = nfes.slice(0, 5).map(n => ({
            chave: n.chave,
            chaveShort: this.shortChave(n.chave),
            statusLabel: this.nfeStatusLabel(n.lifecycle),
            statusClass: this.nfeStatusClass(n.lifecycle),
            date: n.created_at ? new Date(n.created_at).toLocaleDateString('pt-BR') : ''
          }));

          this.loading = false;
          // Sinaliza para o OnPush Engine que o estado foi montado
          this.cdr.markForCheck();
        },
        error: () => {
          this.loading = false;
          this.cdr.markForCheck();
        }
      });
  }

  private shortChave(chave: string): string {
    if (!chave || chave.length <= 16) {
      return chave;
    }
    return `${chave.slice(0, 8)}…${chave.slice(-8)}`;
  }

  private nfeStatusLabel(lc: string): string {
    switch (lc) {
      case 'AUTHORIZED':
        return 'Autorizada';
      case 'REJECTED':
        return 'Rejeitada';
      case 'CANCELLED':
        return 'Cancelada';
      case 'PENDING':
        return 'Pendente';
      default:
        return lc;
    }
  }

  private nfeStatusClass(lc: string): string {
    switch (lc) {
      case 'AUTHORIZED':
        return 'status-fechada';
      case 'REJECTED':
      case 'CANCELLED':
        return 'status-cancelada';
      default:
        return 'status-aberta';
    }
  }

  /**
   * Converte a identificação crua do banco em um selo de Status traduzido para a view.
   */
  private getStatus(invoice: Invoice): string {
    const s = invoice.status?.toLowerCase();
    if (s === APP_CONSTANTS.INVOICE_STATUS.OPEN || s === APP_CONSTANTS.INVOICE_STATUS.ABERTA) {
      return APP_CONSTANTS.INVOICE_STATUS.DISPLAY.OPEN;
    }
    return APP_CONSTANTS.INVOICE_STATUS.DISPLAY.CLOSED;
  }
}
