import { routes } from './app.routes';

describe('appRoutes', () => {
  it('redirects the empty path to /login', () => {
    const root = routes.find(r => r.path === '');
    expect(root).toBeDefined();
    expect(root?.redirectTo).toBe('login');
    expect(root?.pathMatch).toBe('full');
  });

  it('registers all guest auth routes with layout=auth flag', () => {
    const guestPaths = [
      'login',
      'register',
      'activate/:token',
      'reset-password',
      'reset-password/:token'
    ];
    for (const p of guestPaths) {
      const route = routes.find(r => r.path === p);
      expect(route).toBeDefined();
      expect(route?.data?.['layout']).toBe('auth');
    }
  });

  it('protects login/register/reset-password with the guest guard', () => {
    const guarded = ['login', 'register', 'reset-password'];
    for (const p of guarded) {
      const route = routes.find(r => r.path === p);
      expect(route?.canActivate?.length).toBe(1);
    }
  });

  it('registers the four feature routes plus their detail paths', () => {
    const paths = routes.map(r => r.path);
    expect(paths).toEqual(
      expect.arrayContaining([
        'dashboard',
        'products',
        'invoices',
        'invoices/:id',
        'nfe',
        'nfe/new',
        'nfe/:chave',
        'profile'
      ])
    );
  });

  it('orders nfe/new before nfe/:chave so the new wizard is not captured as a chave', () => {
    const newIdx = routes.findIndex(r => r.path === 'nfe/new');
    const chaveIdx = routes.findIndex(r => r.path === 'nfe/:chave');
    expect(newIdx).toBeGreaterThan(-1);
    expect(chaveIdx).toBeGreaterThan(-1);
    expect(newIdx).toBeLessThan(chaveIdx);
  });

  it('protects every feature route (dashboard, products, invoices, nfe, profile) with authGuard', () => {
    const protectedPaths = [
      'dashboard',
      'products',
      'invoices',
      'invoices/:id',
      'nfe',
      'nfe/new',
      'nfe/:chave',
      'profile'
    ];
    for (const p of protectedPaths) {
      const route = routes.find(r => r.path === p);
      expect(route?.canActivate?.length).toBe(1);
    }
  });

  it('uses lazy loadComponent for every feature route', () => {
    const featurePaths = [
      'dashboard',
      'products',
      'invoices',
      'invoices/:id',
      'nfe',
      'nfe/new',
      'nfe/:chave',
      'profile'
    ];
    for (const p of featurePaths) {
      const route = routes.find(r => r.path === p);
      expect(route?.loadComponent).toBeInstanceOf(Function);
    }
  });

  it('catches unknown paths with a wildcard redirect to login', () => {
    const wildcard = routes.find(r => r.path === '**');
    expect(wildcard).toBeDefined();
    expect(wildcard?.redirectTo).toBe('login');
  });
});
