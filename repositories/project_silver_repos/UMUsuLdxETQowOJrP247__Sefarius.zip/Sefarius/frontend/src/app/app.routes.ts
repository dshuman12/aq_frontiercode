import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './shared/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  // Guest-only routes (no sidebar/topbar). data.layout flags the shell
  // in app.component to hide its chrome on these screens.
  {
    path: 'login',
    canActivate: [guestGuard],
    data: { layout: 'auth' },
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    data: { layout: 'auth' },
    loadComponent: () =>
      import('./features/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'activate/:token',
    data: { layout: 'auth' },
    loadComponent: () =>
      import('./features/auth/activation/activation.component').then(m => m.ActivationComponent)
  },
  {
    path: 'reset-password',
    canActivate: [guestGuard],
    data: { layout: 'auth' },
    loadComponent: () =>
      import('./features/auth/reset-password/reset-password.component').then(
        m => m.ResetPasswordComponent
      )
  },
  {
    path: 'reset-password/:token',
    data: { layout: 'auth' },
    loadComponent: () =>
      import('./features/auth/reset-confirm/reset-confirm.component').then(
        m => m.ResetConfirmComponent
      )
  },

  // Protected routes
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  {
    path: 'products',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/products/products.component').then(m => m.ProductsComponent)
  },
  {
    path: 'invoices',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/invoices/invoices.component').then(m => m.InvoicesComponent)
  },
  {
    path: 'invoices/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/invoices/invoice-detail/invoice-detail.component').then(
        m => m.InvoiceDetailComponent
      )
  },
  {
    path: 'nfe',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/nfe/nfe-list/nfe-list.component').then(m => m.NFeListComponent)
  },
  {
    path: 'nfe/new',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/nfe/emit/nfe-emit.component').then(m => m.NFeEmitComponent)
  },
  {
    path: 'nfe/:chave',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/nfe/nfe-detail/nfe-detail.component').then(m => m.NFeDetailComponent)
  },
  {
    path: 'profile',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/auth/profile/profile.component').then(m => m.ProfileComponent)
  },

  {
    path: '**',
    redirectTo: 'login'
  }
];
