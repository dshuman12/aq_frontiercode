import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NavigationEnd, Router } from '@angular/router';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Subject } from 'rxjs';

import { AppComponent } from './app.component';
import { BreadcrumbService } from './shared/services/breadcrumb.service';
import { LoadingService } from './shared/services/loading.service';
import { ErrorService } from './shared/services/error.service';
import { AuthService } from './shared/services/auth.service';
import { environment } from '@env/environment';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let component: AppComponent;
  let routerEvents$: Subject<NavigationEnd>;
  let breadcrumbService: BreadcrumbService;
  let http: HttpTestingController;

  beforeEach(async () => {
    routerEvents$ = new Subject<NavigationEnd>();

    await TestBed.configureTestingModule({
      imports: [AppComponent, NoopAnimationsModule],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        BreadcrumbService,
        LoadingService,
        ErrorService,
        AuthService
      ]
    }).compileComponents();

    // Patch the router events stream so we can drive NavigationEnd manually.
    const router = TestBed.inject(Router);
    Object.defineProperty(router, 'events', { value: routerEvents$, configurable: true });
    Object.defineProperty(router, 'url', { value: '/', configurable: true });

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    breadcrumbService = TestBed.inject(BreadcrumbService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    // AuthService dispara GET /profile no construtor. Em testes que
    // não chamam fixture.detectChanges() esse request pode não chegar;
    // match() (vs expectOne) consome se existir, sem reclamar se não.
    const reqs = http.match(`${environment.apiBaseUrl}/profile`);
    reqs.forEach(r =>
      r.flush(
        { success: false, error: 'no session', code: 401 },
        {
          status: 401,
          statusText: 'Unauthorized'
        }
      )
    );
    http.verify();
  });

  it('starts with sidebar closed', () => {
    fixture.detectChanges();
    expect(component.sidebarOpen()).toBe(false);
  });

  it('toggleSidebar flips the signal each call', () => {
    fixture.detectChanges();
    component.toggleSidebar();
    expect(component.sidebarOpen()).toBe(true);
    component.toggleSidebar();
    expect(component.sidebarOpen()).toBe(false);
  });

  it('closeSidebar always returns false', () => {
    fixture.detectChanges();
    component.toggleSidebar();
    component.closeSidebar();
    expect(component.sidebarOpen()).toBe(false);
  });

  describe('breadcrumbs', () => {
    function navigate(url: string) {
      Object.defineProperty(TestBed.inject(Router), 'url', { value: url, configurable: true });
      routerEvents$.next(new NavigationEnd(1, url, url));
    }

    it('starts on /dashboard with a single Home crumb', () => {
      Object.defineProperty(TestBed.inject(Router), 'url', {
        value: '/dashboard',
        configurable: true
      });
      fixture.detectChanges();
      expect(component.breadcrumbs()).toEqual([{ label: 'Home', url: '/dashboard' }]);
    });

    it('translates the products segment to "Produtos"', () => {
      fixture.detectChanges();
      navigate('/products');
      expect(component.breadcrumbs()).toEqual([
        { label: 'Home', url: '/dashboard' },
        { label: 'Produtos', url: '/products' }
      ]);
    });

    it('translates the invoices segment to "Notas"', () => {
      fixture.detectChanges();
      navigate('/invoices');
      expect(component.breadcrumbs().map(c => c.label)).toEqual(['Home', 'Notas']);
    });

    it('translates the nfe segment to "NF-e"', () => {
      fixture.detectChanges();
      navigate('/nfe');
      expect(component.breadcrumbs().map(c => c.label)).toEqual(['Home', 'NF-e']);
    });

    it('uses BreadcrumbService.getLabel for unknown segments', () => {
      fixture.detectChanges();
      breadcrumbService.setLabel('abc-123', 'Cliente XYZ');
      navigate('/clients/abc-123');
      expect(component.breadcrumbs().map(c => c.label)).toEqual(['Home', 'clients', 'Cliente XYZ']);
    });

    it('refreshes breadcrumbs when BreadcrumbService emits dynamicLabels$', () => {
      Object.defineProperty(TestBed.inject(Router), 'url', {
        value: '/nfe/abc-123',
        configurable: true
      });
      fixture.detectChanges();

      breadcrumbService.setLabel('abc-123', 'NFe #42');
      const last = component.breadcrumbs().at(-1);
      expect(last?.label).toBe('NFe #42');
    });
  });

  it('cleans up subscriptions on destroy', () => {
    fixture.detectChanges();
    expect(() => fixture.destroy()).not.toThrow();
  });

  it('exposes loading$ and error$ from the corresponding services', () => {
    fixture.detectChanges();
    expect(component.loading$).toBeDefined();
    expect(component.error$).toBeDefined();
  });

  it('dismissError delegates to ErrorService', () => {
    fixture.detectChanges();
    const errorService = TestBed.inject(ErrorService);
    const spy = jest.spyOn(errorService, 'clearError');
    component.dismissError();
    expect(spy).toHaveBeenCalled();
  });
});
