import { LOCALE_ID } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import { AppComponent } from './app/app.component';
import { routes } from './app/app.routes';
import { credentialsInterceptor } from './app/shared/interceptors/credentials.interceptor';
import { errorInterceptor } from './app/shared/interceptors/error.interceptor';
import { loadingInterceptor } from './app/shared/interceptors/loading.interceptor';

// Register pt-BR locale data so Angular's CurrencyPipe / DatePipe /
// DecimalPipe accept "pt-BR" as a locale arg without throwing
// NG0701. The default Angular bundle ships only en-US.
registerLocaleData(localePt, 'pt-BR');

bootstrapApplication(AppComponent, {
  providers: [
    // App-wide LOCALE_ID makes all Angular pipes default to pt-BR
    // formatting (currency → R$, decimal → comma separator, date →
    // dd/MM/yyyy) without needing an explicit ':pt-BR' argument at
    // every call site. Existing explicit ':pt-BR' usages stay valid.
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    provideAnimations(),
    provideRouter(routes),
    // credentialsInterceptor PRIMEIRO — adiciona withCredentials antes
    // de qualquer outra mutação. Sem ele, ApiService e qualquer service
    // que use HttpClient sem flag explícito perde o cookie de sessão.
    provideHttpClient(
      withInterceptors([credentialsInterceptor, errorInterceptor, loadingInterceptor])
    )
  ]
}).catch(err => console.error(err));
