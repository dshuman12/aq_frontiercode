import type { Page } from '@playwright/test';

export const SAMPLE_CHAVE = '52260101010101000100550010000000011000000011';

export const sampleListItem = {
  chave: SAMPLE_CHAVE,
  lifecycle: 'AUTHORIZED',
  c_stat: '100',
  x_motivo: 'Autorizado o uso da NF-e',
  created_at: '2026-05-06T15:30:00Z',
  updated_at: '2026-05-06T15:30:00Z'
};

export const sampleRecord = {
  chave: SAMPLE_CHAVE,
  lifecycle: 'AUTHORIZED',
  c_stat: '100',
  x_motivo: 'Autorizado o uso da NF-e',
  protocol: {
    n_prot: '352260000000001',
    dh_recbto: '2026-05-06T15:30:05Z',
    ch_nfe: SAMPLE_CHAVE,
    dig_val: 'abc123==',
    c_stat: '100',
    x_motivo: 'Autorizado o uso da NF-e',
    tp_amb: '2'
  }
};

interface MockOptions {
  list?: Array<typeof sampleListItem>;
  record?: typeof sampleRecord;
  cancelData?: unknown;
  cceList?: unknown[];
  cancelStatus?: number;
  cceStatus?: number;
}

export async function mockNFeApi(page: Page, options: MockOptions = {}): Promise<void> {
  const list = options.list ?? [sampleListItem];
  const record = options.record ?? sampleRecord;
  const cancelData = options.cancelData ?? null;
  const cceList = options.cceList ?? [];

  await page.route('**/api/nfe?**', async route => {
    if (route.request().method() === 'GET') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: list, code: 200 })
      });
    } else {
      await route.continue();
    }
  });

  await page.route(`**/api/nfe/${SAMPLE_CHAVE}`, async route => {
    if (route.request().method() === 'GET') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: record, code: 200 })
      });
    } else {
      await route.continue();
    }
  });

  await page.route(`**/api/nfe/${SAMPLE_CHAVE}/cancel`, async route => {
    if (route.request().method() === 'GET') {
      const status = options.cancelStatus ?? 200;
      await route.fulfill({
        status,
        contentType: 'application/json',
        body: cancelData
          ? JSON.stringify({ success: true, data: cancelData, code: status })
          : JSON.stringify({ success: true, data: null, code: status })
      });
    } else {
      await route.continue();
    }
  });

  await page.route(`**/api/nfe/${SAMPLE_CHAVE}/cce`, async route => {
    if (route.request().method() === 'GET') {
      const status = options.cceStatus ?? 200;
      await route.fulfill({
        status,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: cceList, code: status })
      });
    } else {
      await route.continue();
    }
  });

  await page.route(`**/api/nfe/${SAMPLE_CHAVE}/danfe`, async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/pdf',
      body: Buffer.from('%PDF-1.4 fake')
    });
  });

  await page.route(`**/api/nfe/${SAMPLE_CHAVE}/xml`, async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/xml',
      body: '<?xml version="1.0"?><nfeProc><infNFe><emit><CNPJ>00000000000000</CNPJ></emit></infNFe></nfeProc>'
    });
  });
}
