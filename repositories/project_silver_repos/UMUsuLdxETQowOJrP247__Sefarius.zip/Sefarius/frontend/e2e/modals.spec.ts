import { test, expect } from '@playwright/test';
import { mockNFeApi, SAMPLE_CHAVE } from './fixtures/api-mocks';

test.describe('Cancel + CCe modals', () => {
  test.beforeEach(async ({ page }) => {
    await mockNFeApi(page);
    await page.goto(`/nfe/${SAMPLE_CHAVE}`);
    await page.waitForSelector('.lifecycle-badge.lc-authorized');
  });

  test('Cancelar NF-e button opens the modal with disabled submit until 15 chars', async ({ page }) => {
    await page.getByRole('button', { name: 'Cancelar NF-e' }).click();

    const dialog = page.getByRole('dialog');
    await expect(dialog).toBeVisible();
    await expect(dialog.getByRole('heading', { name: 'Cancelar NF-e' })).toBeVisible();

    const submit = dialog.getByRole('button', { name: 'Cancelar NF-e' });
    await expect(submit).toBeDisabled();

    await dialog.locator('textarea#justification').fill('curto');
    await expect(submit).toBeDisabled();

    await dialog.locator('textarea#justification').fill('texto válido com mais de 15 chars');
    await expect(submit).toBeEnabled();

    // Voltar fecha o modal sem submeter
    await dialog.getByRole('button', { name: 'Voltar' }).click();
    await expect(dialog).not.toBeVisible();
  });

  test('Cancel submit ACCEPTED shows a success banner and reloads', async ({ page }) => {
    await page.route(`**/api/nfe/${SAMPLE_CHAVE}/cancel`, async route => {
      if (route.request().method() === 'POST') {
        await route.fulfill({
          status: 201,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              chave: SAMPLE_CHAVE,
              event_type: 'CANCEL',
              seq: 1,
              status: 'ACCEPTED',
              c_stat: '135',
              x_motivo: 'Evento registrado e vinculado a NF-e'
            },
            code: 201
          })
        });
        return;
      }
      await route.continue();
    });

    await page.getByRole('button', { name: 'Cancelar NF-e' }).click();
    const dialog = page.getByRole('dialog');
    await dialog
      .locator('textarea#justification')
      .fill('Erro de digitação no item 2 — reemissão correta autorizada');
    await dialog.getByRole('button', { name: 'Cancelar NF-e' }).click();

    await expect(page.locator('.feedback-banner.feedback-success')).toContainText(
      'Cancelamento aceito'
    );
  });

  test('Cancel submit REJECTED with cStat 218 surfaces the SEFAZ hint', async ({ page }) => {
    await page.route(`**/api/nfe/${SAMPLE_CHAVE}/cancel`, async route => {
      if (route.request().method() === 'POST') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              chave: SAMPLE_CHAVE,
              event_type: 'CANCEL',
              seq: 1,
              status: 'REJECTED',
              c_stat: '218',
              x_motivo: 'NF-e já cancelada'
            },
            code: 200
          })
        });
        return;
      }
      await route.continue();
    });

    await page.getByRole('button', { name: 'Cancelar NF-e' }).click();
    const dialog = page.getByRole('dialog');
    await dialog.locator('textarea#justification').fill('texto suficientemente longo');
    await dialog.getByRole('button', { name: 'Cancelar NF-e' }).click();

    const banner = page.locator('.feedback-banner.feedback-error');
    await expect(banner).toContainText('218');
    await expect(banner).toContainText('NF-e já cancelada');
  });

  test('Nova CCe modal validates 15-1000 chars and shows the next sequence', async ({ page }) => {
    await page.getByRole('button', { name: 'Nova CCe' }).click();

    const dialog = page.getByRole('dialog');
    await expect(dialog).toBeVisible();
    await expect(dialog.getByText('#1')).toBeVisible(); // first sequence

    const submit = dialog.getByRole('button', { name: 'Enviar CCe' });
    await expect(submit).toBeDisabled();

    await dialog.locator('textarea#correction').fill('texto válido com mais de 15 chars');
    await expect(submit).toBeEnabled();
  });
});
