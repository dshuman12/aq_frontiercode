import { test, expect, Page } from '@playwright/test';

const NEW_CHAVE = '43260512345678000181550010000000999000000999';

interface EmitMockOptions {
  status?: 'AUTHORIZED' | 'REJECTED';
  cStat?: string;
  motivo?: string;
  httpStatus?: number;
}

async function mockEmitFlow(page: Page, opts: EmitMockOptions = {}): Promise<void> {
  await page.route('**/api/nfe', async route => {
    if (route.request().method() === 'POST') {
      const httpStatus = opts.httpStatus ?? 201;
      const status = opts.status ?? 'AUTHORIZED';
      const cStat = opts.cStat ?? (status === 'AUTHORIZED' ? '100' : '539');
      const motivo =
        opts.motivo ??
        (status === 'AUTHORIZED' ? 'Autorizado o uso da NF-e' : 'Duplicidade de NF-e');
      await route.fulfill({
        status: httpStatus,
        contentType: 'application/json',
        body: JSON.stringify({
          success: httpStatus < 400,
          data: {
            chave: NEW_CHAVE,
            status,
            lifecycle: status === 'AUTHORIZED' ? 'AUTHORIZED' : 'REJECTED',
            c_stat: cStat,
            x_motivo: motivo,
            ...(status === 'REJECTED'
              ? { rejection: { CStat: cStat, XMotivo: motivo } }
              : {})
          },
          code: httpStatus
        })
      });
    } else {
      await route.continue();
    }
  });

  // Detail page after redirect
  await page.route(`**/api/nfe/${NEW_CHAVE}`, async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        success: true,
        data: {
          chave: NEW_CHAVE,
          lifecycle: 'AUTHORIZED',
          c_stat: '100',
          x_motivo: 'Autorizado o uso da NF-e'
        },
        code: 200
      })
    });
  });
  await page.route(`**/api/nfe/${NEW_CHAVE}/cancel`, async route => {
    await route.fulfill({ status: 200, contentType: 'application/json', body: '{}' });
  });
  await page.route(`**/api/nfe/${NEW_CHAVE}/cce`, async route => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ success: true, data: [], code: 200 })
    });
  });
}

// Bug Sweep 2026-05-07: ViaCEP autocomplete fires on 8-digit CEP; in
// e2e we intercept and reply 404 so the wizard falls back to manual
// entry without depending on the public API or letting a delayed
// response race against our explicit input.fill calls.
async function mockViaCep(page: Page): Promise<void> {
  await page.route('**/viacep.com.br/**', async route => {
    await route.fulfill({ status: 404, contentType: 'application/json', body: '{}' });
  });
}

async function fillWizard(page: Page): Promise<void> {
  const ide = page.locator('[formGroupName="ide"]');
  const emit = page.locator('[formGroupName="emit"]');
  const dest = page.locator('[formGroupName="dest"]');
  const itemsArr = page.locator('[formArrayName="items"]');

  // Step 1: Identificação — only n_nf and c_mun_fg need filling.
  await ide.locator('input[formControlName="n_nf"]').fill('1');
  await ide.locator('input[formControlName="c_mun_fg"]').fill('4314902');
  await page.getByRole('button', { name: /Próximo: Emitente/ }).click();

  // Step 2: Emitente
  await emit.locator('input[formControlName="cnpj"]').fill('11222333000181');
  await emit.locator('input[formControlName="x_nome"]').fill('Empresa Teste LTDA');
  await emit.locator('input[formControlName="ie"]').fill('0123456789');
  await emit.locator('input[formControlName="x_lgr"]').fill('Rua das Flores');
  await emit.locator('input[formControlName="nro"]').fill('100');
  await emit.locator('input[formControlName="x_bairro"]').fill('Centro');
  await emit.locator('input[formControlName="x_mun"]').fill('Porto Alegre');
  await emit.locator('input[formControlName="c_mun"]').fill('4314902');
  await emit.locator('input[formControlName="cep"]').fill('90010000');
  await page.getByRole('button', { name: /Próximo: Destinatário/ }).click();

  // Step 3: Destinatário
  await dest.locator('input[formControlName="cnpj"]').fill('11444777000161');
  await dest.locator('input[formControlName="x_nome"]').fill('Cliente Teste');
  await dest.locator('input[formControlName="x_lgr"]').fill('Av Brasil');
  await dest.locator('input[formControlName="nro"]').fill('200');
  await dest.locator('input[formControlName="x_bairro"]').fill('Bairro');
  await dest.locator('input[formControlName="x_mun"]').fill('Porto Alegre');
  await dest.locator('input[formControlName="c_mun"]').fill('4314902');
  await page.getByRole('button', { name: /Próximo: Itens/ }).click();

  // Step 4: Itens (one item, defaults already populated for cfop/q_com/p_icms/v_pis/v_cofins)
  const item0 = itemsArr.locator('.item-card').first();
  await item0.locator('input[formControlName="c_prod"]').fill('P001');
  await item0.locator('input[formControlName="x_prod"]').fill('Produto teste');
  await item0.locator('input[formControlName="ncm"]').fill('12345678');
  await item0.locator('input[formControlName="v_un_com"]').fill('100.00');
  await item0.locator('input[formControlName="v_prod"]').fill('100.00');
  await item0.locator('input[formControlName="v_bc"]').fill('100.00');
  await page.getByRole('button', { name: /Próximo: Revisão/ }).click();
}

test.describe('NFe emit wizard', () => {
  test.beforeEach(async ({ context }) => {
    // Wipe localStorage between tests so draft restore doesn't bleed across.
    await context.clearCookies();
  });

  test('"+ Nova NF-e" button on /nfe navigates to /nfe/new', async ({ page }) => {
    await page.route('**/api/nfe?**', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: [], code: 200 })
      });
    });
    await page.goto('/nfe');
    await page.getByRole('link', { name: /Nova NF-e/ }).click();
    await expect(page).toHaveURL(/\/nfe\/new$/);
    await expect(page.getByRole('heading', { name: 'Nova NF-e' })).toBeVisible();
  });

  test('happy path — fill 5 steps, submit, redirect to /nfe/:chave', async ({ page }) => {
    await mockEmitFlow(page, { status: 'AUTHORIZED' });
    await mockViaCep(page);
    await page.goto('/nfe/new');
    await fillWizard(page);

    // Review step renders the totals
    await expect(page.locator('.review-items-table tfoot')).toContainText('R$ 100.00');

    await page.getByRole('button', { name: 'Emitir NF-e' }).click();
    await expect(page.locator('.feedback-success')).toContainText('autorizada');
    await expect(page).toHaveURL(new RegExp(`/nfe/${NEW_CHAVE}$`), { timeout: 5000 });
  });

  test('rejection path — surfaces cStat and motivo without redirecting', async ({ page }) => {
    await mockEmitFlow(page, { status: 'REJECTED', cStat: '539', motivo: 'Duplicidade de NF-e' });
    await mockViaCep(page);
    await page.goto('/nfe/new');
    await fillWizard(page);

    await page.getByRole('button', { name: 'Emitir NF-e' }).click();
    const feedback = page.locator('.feedback-error');
    await expect(feedback).toContainText('539');
    await expect(feedback).toContainText('Duplicidade');
    await expect(page).toHaveURL(/\/nfe\/new$/);
  });

  test('502 SEFAZ unreachable surfaces a friendly error', async ({ page }) => {
    await page.route('**/api/nfe', async route => {
      if (route.request().method() === 'POST') {
        await route.fulfill({
          status: 502,
          contentType: 'application/json',
          body: JSON.stringify({ success: false, error: 'sefaz unreachable', code: 502 })
        });
      } else {
        await route.continue();
      }
    });
    await mockViaCep(page);
    await page.goto('/nfe/new');
    await fillWizard(page);
    await page.getByRole('button', { name: 'Emitir NF-e' }).click();
    await expect(page.locator('.feedback-error')).toContainText('SEFAZ indisponível');
  });

  test('cancel button on Step 1 navigates back to /nfe', async ({ page }) => {
    await page.route('**/api/nfe?**', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: [], code: 200 })
      });
    });
    await page.goto('/nfe/new');
    await page.getByRole('button', { name: 'Cancelar' }).click();
    await expect(page).toHaveURL(/\/nfe$/);
  });
});

