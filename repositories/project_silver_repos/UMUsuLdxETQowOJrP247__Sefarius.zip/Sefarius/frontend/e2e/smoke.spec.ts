import { test, expect } from '@playwright/test';
import { mockNFeApi } from './fixtures/api-mocks';

test.describe('App shell', () => {
  test('boots and shows the Sefarius sidebar with NF-e nav link', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto('/');

    await expect(page.locator('.sidebar-logo-text')).toHaveText('Sefarius');
    await expect(page.locator('a.nav-link', { hasText: 'NF-e' })).toBeVisible();
    await expect(page.locator('a.nav-link', { hasText: 'Notas Fiscais' })).toBeVisible();
    await expect(page.locator('a.nav-link', { hasText: 'Produtos' })).toBeVisible();
    await expect(page.locator('a.nav-link', { hasText: 'Dashboard' })).toBeVisible();
  });

  test('default route redirects to /dashboard', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto('/');
    await expect(page).toHaveURL(/\/dashboard$/);
  });
});
