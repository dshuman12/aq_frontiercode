import { test, expect } from '@playwright/test';
import { mockNFeApi, SAMPLE_CHAVE } from './fixtures/api-mocks';

test.describe('NFe detail', () => {
  test('renders the summary card with lifecycle, cStat and protocol info', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto(`/nfe/${SAMPLE_CHAVE}`);

    await expect(page.getByRole('heading', { name: 'NF-e' })).toBeVisible();
    await expect(page.locator('.lifecycle-badge.lc-authorized')).toContainText('Autorizada');
    await expect(page.getByText('352260000000001')).toBeVisible();
  });

  test('renders the DANFE tab with an iframe pointing at the API endpoint', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto(`/nfe/${SAMPLE_CHAVE}`);

    const iframe = page.locator('iframe.danfe-iframe');
    await expect(iframe).toBeVisible();
    const src = await iframe.getAttribute('src');
    expect(src).toContain(`/nfe/${SAMPLE_CHAVE}/danfe`);
  });

  test('switching to XML tab triggers the lazy fetch and shows raw text', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto(`/nfe/${SAMPLE_CHAVE}`);

    await page.getByRole('tab', { name: 'XML' }).click();
    await expect(page.locator('pre.xml-pre')).toContainText('<nfeProc>');
  });

  test('Eventos tab shows empty messaging when no cancel + no CCe', async ({ page }) => {
    await mockNFeApi(page);
    await page.goto(`/nfe/${SAMPLE_CHAVE}`);

    await page.getByRole('tab', { name: 'Eventos' }).click();
    await expect(page.getByText('Nenhum cancelamento registrado.')).toBeVisible();
    await expect(page.getByText('Nenhuma carta de correção registrada.')).toBeVisible();
  });

  test('shows error banner when the chave is unknown (404)', async ({ page }) => {
    const unknown = '99999999999999999999999999999999999999999999';
    await page.route(`**/api/nfe/${unknown}`, async route => {
      await route.fulfill({ status: 404, contentType: 'application/json', body: '{}' });
    });
    await page.route(`**/api/nfe/${unknown}/**`, async route => {
      await route.fulfill({ status: 404, contentType: 'application/json', body: '{}' });
    });
    await page.goto(`/nfe/${unknown}`);
    await expect(page.getByText('NF-e não encontrada')).toBeVisible();
  });
});
