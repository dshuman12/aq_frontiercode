import { test, expect } from '@playwright/test';
import { mockNFeApi, sampleListItem, SAMPLE_CHAVE } from './fixtures/api-mocks';

test.describe('NFe list', () => {
  test('shows an empty state when the API returns no items', async ({ page }) => {
    await mockNFeApi(page, { list: [] });
    await page.goto('/nfe');
    await expect(page.getByText('Nenhuma NF-e encontrada')).toBeVisible();
  });

  test('renders one row per item with truncated chave and lifecycle badge', async ({ page }) => {
    await mockNFeApi(page, { list: [sampleListItem] });
    await page.goto('/nfe');

    const row = page.locator('tr.nfe-row');
    await expect(row).toHaveCount(1);
    await expect(row).toContainText('Autorizada');
    await expect(row).toContainText('100');
    // truncation collapses 44-char chave to "first8…last8" — 17 chars total
    await expect(row.locator('td.nfe-chave')).toHaveText(/^.{17}$/);
  });

  test('clicking the eye icon navigates to /nfe/:chave', async ({ page }) => {
    await mockNFeApi(page, { list: [sampleListItem] });
    await page.goto('/nfe');
    await page.locator(`a[href="/nfe/${SAMPLE_CHAVE}"]`).first().click();
    await expect(page).toHaveURL(new RegExp(`/nfe/${SAMPLE_CHAVE}$`));
  });
});
