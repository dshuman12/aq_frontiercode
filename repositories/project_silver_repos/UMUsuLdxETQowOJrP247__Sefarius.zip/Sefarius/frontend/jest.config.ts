import type { Config } from 'jest';

const config: Config = {
  preset: 'jest-preset-angular',
  setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
  testPathIgnorePatterns: ['/node_modules/', '/dist/', '/e2e/'],
  testMatch: ['<rootDir>/src/**/*.spec.ts'],
  transformIgnorePatterns: ['node_modules/(?!(.*\\.mjs$|uuid|@angular|rxjs|tslib))'],
  moduleNameMapper: {
    '^@app/(.*)$': '<rootDir>/src/app/$1',
    '^@shared/(.*)$': '<rootDir>/src/app/shared/$1',
    '^@features/(.*)$': '<rootDir>/src/app/features/$1',
    '^@env/environment$': '<rootDir>/src/environments/environment'
  },
  collectCoverageFrom: [
    'src/app/**/*.ts',
    '!src/app/**/*.spec.ts',
    '!src/app/**/*.module.ts',
    '!src/app/**/index.ts',
    // Type-only or pure declaration files — TS already validates them.
    '!src/app/shared/models/**',
    '!src/app/shared/constants/**',
    // Lazy loadComponent thunks are wired but never invoked in unit
    // tests (Angular Router resolves them at runtime). The route table
    // itself is exercised by app.routes.spec.ts.
    '!src/app/app.routes.ts'
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'html'],
  // Thresholds are scoped to the actively maintained code paths. Legacy
  // features (dashboard / invoices / products / app shell) are excluded
  // because their fate is being decided in sprint F5; tightening their
  // coverage now would couple us to code that may be deleted.
  coverageThreshold: {
    // Project-wide floor. The legacy app.routes.ts brings the average
    // down because lazy loadComponent thunks are not invoked in unit
    // tests, but the rest of the codebase clears 90%+ comfortably.
    global: { lines: 85, branches: 70, functions: 80, statements: 85 },
    './src/app/shared/services/': { lines: 100, branches: 100, functions: 100, statements: 100 },
    './src/app/shared/components/base.component.ts': { lines: 100, statements: 100 },
    './src/app/shared/components/confirm-dialog/': { lines: 100, statements: 100 },
    './src/app/shared/interceptors/': { lines: 95, branches: 90, statements: 95 },
    './src/app/features/nfe/': { lines: 85, branches: 60, functions: 90, statements: 85 },
    './src/app/features/dashboard/': { lines: 95, functions: 95 },
    './src/app/features/products/': { lines: 90, functions: 80 },
    './src/app/features/invoices/invoices.component.ts': { lines: 90, functions: 85 },
    './src/app/features/invoices/invoice-detail/': { lines: 70, functions: 70 },
    './src/app/app.component.ts': { lines: 95, branches: 85, functions: 100 }
  }
};

export default config;
