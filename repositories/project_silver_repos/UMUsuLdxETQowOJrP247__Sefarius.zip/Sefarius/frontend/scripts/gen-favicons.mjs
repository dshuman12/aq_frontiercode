// Gera todos os favicons (PNG + ICO) a partir do master SVG.
//
// Por que Playwright e não sharp/imagemagick: o projeto já tem Playwright
// instalado para os e2e. sharp exige binários nativos por OS, e ImageMagick
// não está no ambiente. Renderizando o SVG numa página em branco e tirando
// screenshot do <body>, conseguimos PNGs nítidos sem dependência extra.

import { chromium } from 'playwright';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ICONS_DIR = resolve(__dirname, '..', 'src', 'icons');
const SVG_PATH = resolve(ICONS_DIR, 'favicon.svg');

const PNG_SIZES = [
  { name: 'favicon-16.png', size: 16 },
  { name: 'favicon-32.png', size: 32 },
  { name: 'favicon-48.png', size: 48 },
  { name: 'apple-touch-icon.png', size: 180 },
  { name: 'icon-192.png', size: 192 },
  { name: 'icon-512.png', size: 512 },
];

// Tamanhos que entram no .ico multi-resolução (browsers escolhem o melhor).
const ICO_SIZES = [16, 32, 48];

mkdirSync(ICONS_DIR, { recursive: true });

const svg = readFileSync(SVG_PATH, 'utf-8');

const html = (size) => `<!doctype html>
<html><head><meta charset="utf-8"><style>
  html,body{margin:0;padding:0;background:transparent;}
  svg{display:block;width:${size}px;height:${size}px;}
</style></head><body>${svg}</body></html>`;

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 600, height: 600 }, deviceScaleFactor: 1 });
const page = await context.newPage();

const pngBuffers = {};

for (const { name, size } of PNG_SIZES) {
  await page.setViewportSize({ width: size, height: size });
  await page.setContent(html(size), { waitUntil: 'load' });
  const buf = await page.locator('svg').screenshot({ omitBackground: true, type: 'png' });
  writeFileSync(resolve(ICONS_DIR, name), buf);
  pngBuffers[size] = buf;
  console.log(`wrote ${name} (${size}x${size}, ${buf.length} bytes)`);
}

await browser.close();

// ICO file format (multi-image):
//   ICONDIR (6 bytes): reserved=0(2), type=1(2), count(2)
//   ICONDIRENTRY × count (16 bytes each): w(1), h(1), pal(1), res(1),
//     planes(2), bitcount(2), size(4), offset(4)
//   image data × count (PNG bytes — ICO supports embedded PNG since Vista)
function buildIco(buffers) {
  const count = buffers.length;
  const headerSize = 6 + 16 * count;
  let dataOffset = headerSize;

  const dir = Buffer.alloc(headerSize);
  dir.writeUInt16LE(0, 0); // reserved
  dir.writeUInt16LE(1, 2); // type = icon
  dir.writeUInt16LE(count, 4);

  for (let i = 0; i < count; i++) {
    const { size, png } = buffers[i];
    const off = 6 + i * 16;
    // 256-pixel images use 0 in the byte field (per spec).
    dir.writeUInt8(size >= 256 ? 0 : size, off + 0); // width
    dir.writeUInt8(size >= 256 ? 0 : size, off + 1); // height
    dir.writeUInt8(0, off + 2); // palette
    dir.writeUInt8(0, off + 3); // reserved
    dir.writeUInt16LE(1, off + 4); // color planes
    dir.writeUInt16LE(32, off + 6); // bits per pixel
    dir.writeUInt32LE(png.length, off + 8); // image size
    dir.writeUInt32LE(dataOffset, off + 12); // offset
    dataOffset += png.length;
  }

  return Buffer.concat([dir, ...buffers.map((b) => b.png)]);
}

const icoEntries = ICO_SIZES.map((size) => ({ size, png: pngBuffers[size] }));
const ico = buildIco(icoEntries);
writeFileSync(resolve(ICONS_DIR, 'favicon.ico'), ico);
console.log(`wrote favicon.ico (${ICO_SIZES.join('+')}, ${ico.length} bytes)`);
