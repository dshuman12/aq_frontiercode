#!/usr/bin/env bash
# Generate Go types from SEFAZ NFe XSDs via xgen.
#
# Usage:
#   tools/generate-nfe-types.sh                # core schema package (default)
#   tools/generate-nfe-types.sh --smoke        # 4-XSD smoke set in core
#   tools/generate-nfe-types.sh --group <name> # sub-package: evento, cce, canc, dist
#   tools/generate-nfe-types.sh --all          # core + all four sub-packages
#
# Idempotent. Preserves schema/README.md and schema/xsd/. Sub-packages
# exist because xgen redeclares shared base types per XSD and collides
# when multiple XSDs target one Go package.

set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

SCHEMA_DIR="backend/billing-service/domain/nfe/schema"
XSD_DIR="$SCHEMA_DIR/xsd"

if [[ ! -d "$XSD_DIR" ]]; then
  echo "ERROR: $XSD_DIR not found. Run tools/download-nfe-xsd.sh first." >&2
  exit 1
fi

# ─── Set definitions ─────────────────────────────────────────────────────────

# Smoke — minimal end-to-end pipeline check
SMOKE=(
  "tiposBasico_v4.00.xsd"
  "leiauteNFe_v4.00.xsd"
  "nfe_v4.00.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)

# Core — emission, authorization, status/situation queries, inutilization,
# cadastro lookup, signature. Compiles into schema/ as package schema.
ESSENTIALS=(
  "tiposBasico_v4.00.xsd"
  "leiauteNFe_v4.00.xsd"
  "nfe_v4.00.xsd"
  "procNFe_v4.00.xsd"
  "enviNFe_v4.00.xsd"
  "retEnviNFe_v4.00.xsd"
  "consReciNFe_v4.00.xsd"
  "retConsReciNFe_v4.00.xsd"
  "consSitNFe_v4.00.xsd"
  "retConsSitNFe_v4.00.xsd"
  "consStatServ_v4.00.xsd"
  "retConsStatServ_v4.00.xsd"
  "inutNFe_v4.00.xsd"
  "retInutNFe_v4.00.xsd"
  "consCad_v2.00.xsd"
  "retConsCad_v2.00.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)

# Sub-packages — one set each, generated into schema/<name>/ as package <name>.
GROUP_EVENTO=(
  "tiposBasico_v1.03.xsd"
  "leiauteEvento_v1.00.xsd"
  "envEvento_v1.00.xsd"
  "retEnvEvento_v1.00.xsd"
  "procEventoNFe_v1.00.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)
GROUP_CCE=(
  "tiposBasico_v1.03.xsd"
  "leiauteCCe_v1.00.xsd"
  "CCe_v1.00.xsd"
  "envCCe_v1.00.xsd"
  "retEnvCCe_v1.00.xsd"
  "procCCeNFe_v1.00.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)
GROUP_CANC=(
  "tiposBasico_v1.03.xsd"
  "leiauteEventoCancNFe_v1.00.xsd"
  "eventoCancNFe_v1.00.xsd"
  "envEventoCancNFe_v1.00.xsd"
  "retEnvEventoCancNFe_v1.00.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)
GROUP_DIST=(
  "tiposDistDFe_v1.01.xsd"
  "distDFeInt_v1.01.xsd"
  "retDistDFeInt_v1.01.xsd"
  "xmldsig-core-schema_v1.01.xsd"
)

# ─── Argument parsing ────────────────────────────────────────────────────────

generate_one() {
  local label="$1"
  local pkg="$2"
  local out_dir="$3"
  shift 3
  local files=("$@")

  echo "==========================================="
  echo "  $label  (package $pkg → $out_dir)"
  echo "==========================================="
  echo "Files: ${#files[@]}"

  # Project-local temp so Docker Desktop on Windows/macOS can bind-mount
  local temp_dir="$SCHEMA_DIR/.xgen-input"
  rm -rf "$temp_dir"
  mkdir -p "$temp_dir"

  local missing=0
  for f in "${files[@]}"; do
    if [[ -f "$XSD_DIR/$f" ]]; then
      cp "$XSD_DIR/$f" "$temp_dir/"
    else
      echo "  MISSING: $f"
      missing=$((missing+1))
    fi
  done

  if [[ $missing -gt 0 ]]; then
    rm -rf "$temp_dir"
    echo "ERROR: $missing XSDs missing — aborting." >&2
    return 1
  fi

  mkdir -p "$out_dir"
  find "$out_dir" -maxdepth 1 -name "*.go" -delete

  # MSYS_NO_PATHCONV=1 prevents Git Bash on Windows from rewriting /in /out
  MSYS_NO_PATHCONV=1 docker run --rm \
    -v "$(pwd)/$temp_dir:/in:ro" \
    -v "$(pwd)/$out_dir:/out" \
    golang:1.23-alpine \
    sh -c "
      set -e
      apk add --no-cache git >/dev/null
      go install github.com/xuri/xgen/cmd/xgen@latest 2>&1 | tail -n 1
      xgen -i /in -o /out -l Go -p $pkg 2>&1
    "

  rm -rf "$temp_dir"

  local generated
  generated=$(find "$out_dir" -maxdepth 1 -name "*.go" | wc -l | tr -d ' ')
  echo "Generated $generated Go file(s) in $out_dir/"

  bash "$(dirname "$0")/refine-nfe-types.sh" "$out_dir" || true
}

case "${1:-}" in
  --smoke)
    generate_one "SMOKE" "schema" "$SCHEMA_DIR" "${SMOKE[@]}"
    ;;
  --group)
    case "${2:-}" in
      evento) generate_one "GROUP evento"  "evento" "$SCHEMA_DIR/evento"  "${GROUP_EVENTO[@]}" ;;
      cce)    generate_one "GROUP cce"     "cce"    "$SCHEMA_DIR/cce"     "${GROUP_CCE[@]}" ;;
      canc)   generate_one "GROUP canc"    "canc"   "$SCHEMA_DIR/canc"    "${GROUP_CANC[@]}" ;;
      dist)   generate_one "GROUP dist"    "dist"   "$SCHEMA_DIR/dist"    "${GROUP_DIST[@]}" ;;
      *)      echo "Usage: $0 --group {evento|cce|canc|dist}" >&2; exit 1 ;;
    esac
    ;;
  --all)
    generate_one "CORE"        "schema" "$SCHEMA_DIR"          "${ESSENTIALS[@]}"
    generate_one "GROUP evento" "evento" "$SCHEMA_DIR/evento"  "${GROUP_EVENTO[@]}"
    generate_one "GROUP cce"    "cce"    "$SCHEMA_DIR/cce"     "${GROUP_CCE[@]}"
    generate_one "GROUP canc"   "canc"   "$SCHEMA_DIR/canc"    "${GROUP_CANC[@]}"
    generate_one "GROUP dist"   "dist"   "$SCHEMA_DIR/dist"    "${GROUP_DIST[@]}"
    ;;
  "")
    generate_one "CORE" "schema" "$SCHEMA_DIR" "${ESSENTIALS[@]}"
    ;;
  -h|--help)
    sed -n '2,11p' "$0"
    ;;
  *)
    echo "Usage: $0 [--smoke|--all|--group <name>]" >&2
    exit 1
    ;;
esac
