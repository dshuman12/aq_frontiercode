#!/usr/bin/env bash
# Post-process xgen output. Three passes:
#   1. *interface{} → *string, interface{} → string. xgen emits these for
#      XSD restrictions it cannot synthesise; for NF-e every such field
#      is a string in practice.
#   2. ,omitempty on pointer-typed xml tags. xgen omits it; without it a
#      *string pointing at "" marshals as <name></name>, which the
#      SEFAZ pattern facets reject.
#   3. KNOWN_OPTIONAL retypes value-typed fields the XSD marks
#      minOccurs="0" but xgen emitted as `string`. Allow-list keyed by
#      Go field + xml tag.
#
# Usage:
#   tools/refine-nfe-types.sh                    # whole schema tree
#   tools/refine-nfe-types.sh <path-to-go-file>  # single file

set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

DEFAULT_TARGET="backend/billing-service/domain/nfe/schema"
TARGET="${1:-$DEFAULT_TARGET}"

if [[ ! -e "$TARGET" ]]; then
  echo "ERROR: $TARGET does not exist." >&2
  exit 1
fi

# Find files to refine
if [[ -d "$TARGET" ]]; then
  mapfile -t files < <(find "$TARGET" -name "*.xsd.go" -type f)
else
  files=("$TARGET")
fi

total_before=0
total_after=0
total_omitempty_added=0

count() {
  # grep -o returns 1 when there are no matches; with `set -e` the whole
  # pipeline would propagate that. Force success and let wc count zero.
  { grep -o "interface{}" "$1" 2>/dev/null || true; } | wc -l | tr -d ' \r\n'
}

count_omitempty() {
  { grep -oE 'xml:"[^",]+,omitempty"' "$1" 2>/dev/null || true; } | wc -l | tr -d ' \r\n'
}

for f in "${files[@]}"; do
  before=$(count "$f")
  if [[ "${before:-0}" -gt 0 ]]; then
    # Pointer fields (optional in XSD) → *string
    sed -i 's/\*interface{}/*string/g' "$f"
    # Non-pointer fields (required in XSD) → string
    sed -i 's/\binterface{}/string/g' "$f"
    after=$(count "$f")
    total_before=$((total_before + before))
    total_after=$((total_after + after))
  fi

  # Pass 2: ,omitempty on pointer-typed xml tags. Idempotent — the regex
  # requires no comma inside the tag string. Attr tags (",attr") are
  # therefore skipped. Slice fields ([]*T) match too but Go's xml
  # encoder no-ops omitempty on slices, so it's harmless.
  before_o=$(count_omitempty "$f")
  sed -E -i 's/(\*[A-Za-z_][A-Za-z0-9_.]*[[:space:]]+)`xml:"([^",]+)"`/\1`xml:"\2,omitempty"`/g' "$f"
  after_o=$(count_omitempty "$f")
  total_omitempty_added=$((total_omitempty_added + after_o - before_o))
done

# Pass 3: known-optional value-typed fields → *string + ,omitempty.
# xgen sometimes emits `string` for XSD minOccurs="0" fields. Blanket
# conversion would mask required-field violations, so we maintain an
# allow-list keyed by Go field name + xml tag. To extend: run xmllint
# against a seeded NFe, find elements flagged with facet 'pattern' or
# 'minLength' and value '', add them below. Idempotent (regex requires
# literal `string`, no leading `*`).
KNOWN_OPTIONAL=(
  "DhCont:dhCont"       # Ide — contingency emission timestamp (only set when tpEmis≠1)
  "XJust:xJust"         # Ide — contingency justification (paired with DhCont)
  "IM:IM"               # Emit — Inscricao Municipal (only set for ISSQN issuers)
  "CEST:CEST"           # Prod — Codigo Especificador da ST (only items subject to ST)
  "VFrete:vFrete"       # ICMSTot — total frete (zero-friendly elsewhere; missing if no transport)
  "VSeg:vSeg"           # ICMSTot — total seguro
  "VDesc:vDesc"         # ICMSTot — total desconto
  "VII:vII"             # ICMSTot — total imposto importacao (only on import flows)
  "VIPI:vIPI"           # ICMSTot — total IPI
  "VIPIDevol:vIPIDevol" # ICMSTot — total IPI devolvido
  "VOutro:vOutro"       # ICMSTot — total outras despesas
  "CNPJPag:CNPJPag"     # Card — CNPJ do pagador (only for non-cash payments)
  "UFPag:UFPag"         # Card — UF do pagador
  "CMsg:cMsg"           # InfProt + TRetConsReciNFe — codigo de mensagem opcional
  "XMsg:xMsg"           # InfProt + TRetConsReciNFe — texto de mensagem opcional
)

total_value_to_ptr=0
for f in "${files[@]}"; do
  for entry in "${KNOWN_OPTIONAL[@]}"; do
    go_field="${entry%%:*}"
    xml_name="${entry##*:}"
    before_p=$({ grep -cE "[[:space:]]\\*string[[:space:]]+\`xml:\"${xml_name},omitempty\"\`" "$f" 2>/dev/null || true; } | tr -d ' \r\n')
    # Pattern requires literal "string" (no leading `*`) so already-
    # pointer fields are not double-asterisked.
    sed -E -i "s/(\\b${go_field}[[:space:]]+)string([[:space:]]+)\`xml:\"${xml_name}\"\`/\\1*string\\2\`xml:\"${xml_name},omitempty\"\`/g" "$f"
    after_p=$({ grep -cE "[[:space:]]\\*string[[:space:]]+\`xml:\"${xml_name},omitempty\"\`" "$f" 2>/dev/null || true; } | tr -d ' \r\n')
    total_value_to_ptr=$((total_value_to_ptr + after_p - before_p))
  done
done

echo "Refined ${#files[@]} file(s)"
echo "  interface{} occurrences: $total_before -> $total_after"
echo "  ,omitempty added to $total_omitempty_added pointer field tag(s)"
echo "  value-type optionals retyped to *string: $total_value_to_ptr"

if [[ "$total_after" -gt 0 ]]; then
  echo "WARN: $total_after interface{} occurrences remain — inspect manually:" >&2
  grep -rn "interface{}" "$TARGET" >&2 || true
  exit 1
fi
