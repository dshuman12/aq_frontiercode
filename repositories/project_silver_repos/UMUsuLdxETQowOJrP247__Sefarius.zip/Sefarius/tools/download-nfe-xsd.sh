#!/usr/bin/env bash
# Download official SEFAZ NFe XSDs (package PL_009_V4) from the public mirror at
# https://github.com/nfephp-org/sped-nfe and place them under
# backend/billing-service/domain/nfe/schema/xsd/.
#
# Idempotent — re-running overwrites with the latest from the upstream mirror.
# Usage:
#   tools/download-nfe-xsd.sh

set -euo pipefail

REPO="nfephp-org/sped-nfe"
SUBDIR="schemes/PL_009_V4"
TARGET="backend/billing-service/domain/nfe/schema/xsd"

cd "$(git rev-parse --show-toplevel)"
mkdir -p "$TARGET"

echo "Listing $REPO/$SUBDIR ..."
files=$(curl -fsS "https://api.github.com/repos/$REPO/contents/$SUBDIR" \
  | python -c "import json,sys; [print(f['name']+'\\t'+f['download_url']) for f in json.load(sys.stdin) if f['name'].endswith('.xsd')]" \
  | tr -d '\r')

count=$(echo "$files" | wc -l | tr -d ' ')
echo "Downloading $count XSD files into $TARGET/ ..."

i=0
while IFS=$'\t' read -r name url; do
  i=$((i+1))
  printf "  [%3d/%s] %s\n" "$i" "$count" "$name"
  curl -fsS -o "$TARGET/$name" "$url"
done <<< "$files"

echo ""
echo "Done. $count XSDs in $TARGET/"
echo "Total size: $(du -sh "$TARGET" | cut -f1)"
