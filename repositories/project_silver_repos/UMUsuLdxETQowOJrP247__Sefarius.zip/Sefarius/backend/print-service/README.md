# Print Service

The Print Service provides document generation capabilities, allowing users to create printable versions of invoices and reports.

## Features
- Document formatting
- Integration with Billing and Stock services for data aggregation
- Print-ready output generation

## Configuration
- `PORT`: Service port (default: 5003)
- `DATABASE_URL`: Connection string
- `BILLING_SERVICE_URL`: Source for billing data
- `STOCK_SERVICE_URL`: Source for product data

## Development
```bash
go run main.go
```
