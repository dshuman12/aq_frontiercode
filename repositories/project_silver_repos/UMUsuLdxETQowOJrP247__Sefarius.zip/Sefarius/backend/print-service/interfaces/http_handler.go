package interfaces

import (
	"fmt"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/sefarius/print-service/application"
	"github.com/sefarius/print-service/domain"
)

// PrintJobHandler handles HTTP requests for print jobs
type PrintJobHandler struct {
	service domain.PrintJobUseCase
	worker  domain.PrintServiceWorker
}

// NewPrintJobHandler creates a new print job handler
func NewPrintJobHandler(service domain.PrintJobUseCase, worker domain.PrintServiceWorker) *PrintJobHandler {
	return &PrintJobHandler{
		service: service,
		worker:  worker,
	}
}

// CreatePrintJobHandler handles POST /invoices/:id/print
func (h *PrintJobHandler) CreatePrintJob(c *fiber.Ctx) error {
	invoiceID := c.Params("id")

	if invoiceID == "" {
		return ErrorResponse(c, fiber.StatusBadRequest, "invoice id is required")
	}

	idempotencyKey := c.Get("Idempotency-Key")

	input := &domain.CreatePrintJobInput{
		InvoiceID:      invoiceID,
		IdempotencyKey: idempotencyKey,
	}

	job, err := h.service.CreatePrintJob(c.Context(), input)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	jobDTO := toPrintJobDTO(job)

	// Return 202 Accepted since processing is async
	return SuccessResponse(c, fiber.StatusAccepted, jobDTO)
}

// GetPrintJobStatusHandler handles GET /print-jobs/:id
func (h *PrintJobHandler) GetPrintJobStatus(c *fiber.Ctx) error {
	id := c.Params("id")

	job, err := h.service.GetPrintJob(c.Context(), id)
	if err != nil {
		return ErrorResponse(c, fiber.StatusNotFound, "print job not found")
	}

	// Calculate progress
	progress := calculateProgress(job)

	statusResponse := application.PrintJobStatusResponse{
		JobID:     job.ID,
		InvoiceID: job.InvoiceID,
		Status:    string(job.Status),
		Progress:  progress,
		Message:   getStatusMessage(job),
	}

	return SuccessResponse(c, fiber.StatusOK, statusResponse)
}

// ListPrintJobsHandler handles GET /print-jobs
func (h *PrintJobHandler) ListPrintJobs(c *fiber.Ctx) error {
	limit := 20
	offset := 0

	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 {
			limit = l
		}
	}

	if offsetStr := c.Query("offset"); offsetStr != "" {
		if o, err := strconv.Atoi(offsetStr); err == nil && o >= 0 {
			offset = o
		}
	}

	jobs, err := h.service.ListPrintJobs(c.Context(), limit, offset)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "failed to list print jobs")
	}

	dtos := make([]application.PrintJobDTO, 0, len(jobs))
	for _, job := range jobs {
		dtos = append(dtos, toPrintJobDTO(job))
	}

	return SuccessResponse(c, fiber.StatusOK, application.PaginatedResponse{
		Items:  dtos,
		Total:  len(dtos),
		Limit:  limit,
		Offset: offset,
	})
}

// RetryPrintJobHandler handles POST /print-jobs/:id/retry
func (h *PrintJobHandler) RetryPrintJob(c *fiber.Ctx) error {
	id := c.Params("id")

	job, err := h.service.RetryPrintJob(c.Context(), id)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if err.Error() == "print job not found" {
			statusCode = fiber.StatusNotFound
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	jobDTO := toPrintJobDTO(job)

	return SuccessResponse(c, fiber.StatusOK, jobDTO)
}

// GetInvoicePrintStatusHandler handles GET /invoices/:id/print-status
func (h *PrintJobHandler) GetInvoicePrintStatus(c *fiber.Ctx) error {
	invoiceID := c.Params("id")

	job, err := h.service.GetPrintJobByInvoice(c.Context(), invoiceID)
	if err != nil {
		return SuccessResponse(c, fiber.StatusOK, nil)
	}

	progress := calculateProgress(job)

	statusResponse := application.PrintJobStatusResponse{
		JobID:     job.ID,
		InvoiceID: job.InvoiceID,
		Status:    string(job.Status),
		Progress:  progress,
		Message:   getStatusMessage(job),
	}

	return SuccessResponse(c, fiber.StatusOK, statusResponse)
}

// HealthHandler handles GET /health
func (h *PrintJobHandler) Health(c *fiber.Ctx) error {
	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"status":  "healthy",
		"service": "print-service",
		"time":    time.Now().Unix(),
	})
}

// Helper functions

func toPrintJobDTO(job *domain.PrintJob) application.PrintJobDTO {
	return application.PrintJobDTO{
		ID:          job.ID,
		InvoiceID:   job.InvoiceID,
		Status:      string(job.Status),
		Attempts:    job.Attempts,
		MaxAttempts: job.MaxAttempts,
		LastError:   job.LastError,
		CreatedAt:   job.CreatedAt,
		CompletedAt: job.CompletedAt,
	}
}

func calculateProgress(job *domain.PrintJob) int {
	switch job.Status {
	case domain.StatusPending:
		return 0
	case domain.StatusProcessing:
		return 50
	case domain.StatusCompleted:
		return 100
	case domain.StatusFailed:
		return int((float64(job.Attempts) / float64(job.MaxAttempts)) * 100)
	default:
		return 0
	}
}

func getStatusMessage(job *domain.PrintJob) string {
	switch job.Status {
	case domain.StatusPending:
		return "Waiting to be processed"
	case domain.StatusProcessing:
		return fmt.Sprintf("Processing... (Attempt %d of %d)", job.Attempts, job.MaxAttempts)
	case domain.StatusCompleted:
		return "Print completed successfully"
	case domain.StatusFailed:
		if job.Attempts < job.MaxAttempts {
			return fmt.Sprintf("Failed: %s. Retrying...", job.LastError)
		}
		return fmt.Sprintf("Failed after %d attempts: %s", job.MaxAttempts, job.LastError)
	default:
		return "Unknown status"
	}
}
