package domain

import "context"

// PrintJobRepository defines the contract for print job persistence
type PrintJobRepository interface {
	Create(ctx context.Context, job *PrintJob) error
	GetByID(ctx context.Context, id string) (*PrintJob, error)
	GetByInvoiceID(ctx context.Context, invoiceID string) (*PrintJob, error)
	GetAll(ctx context.Context, limit, offset int) ([]*PrintJob, error)
	Update(ctx context.Context, job *PrintJob) error
	Delete(ctx context.Context, id string) error

	// Get print job with lock
	GetByIDForUpdate(ctx context.Context, id string) (*PrintJob, error)

	// Get pending and failed jobs for retry
	GetRetryableJobs(ctx context.Context, limit int) ([]*PrintJob, error)
}

// PrintJobUseCase defines the contract for print job business logic
type PrintJobUseCase interface {
	CreatePrintJob(ctx context.Context, input *CreatePrintJobInput) (*PrintJob, error)
	GetPrintJob(ctx context.Context, id string) (*PrintJob, error)
	ListPrintJobs(ctx context.Context, limit, offset int) ([]*PrintJob, error)
	ProcessPrintJob(ctx context.Context, jobID string) (*PrintJob, error)
	RetryPrintJob(ctx context.Context, jobID string) (*PrintJob, error)
	GetPrintJobByInvoice(ctx context.Context, invoiceID string) (*PrintJob, error)
}

// BillingServiceClient defines the contract for calling the billing service
type BillingServiceClient interface {
	GetInvoice(ctx context.Context, invoiceID string) (interface{}, error)
	CloseInvoice(ctx context.Context, invoiceID string) (interface{}, error)
}

// StockServiceClient defines the contract for calling the stock service
type StockServiceClient interface {
	DecrementStock(ctx context.Context, productID string, quantity int) error
	GetProduct(ctx context.Context, productID string) (interface{}, error)
}

// PrintServiceWorker defines the contract for async print processing
type PrintServiceWorker interface {
	ProcessJob(ctx context.Context, job *PrintJob) error
	Start(ctx context.Context)
	Stop()
}
