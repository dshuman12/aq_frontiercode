package domain

import (
	"time"
)

// PrintJobStatus represents the status of a print job
type PrintJobStatus string

const (
	StatusPending    PrintJobStatus = "PENDING"
	StatusProcessing PrintJobStatus = "PROCESSING"
	StatusCompleted  PrintJobStatus = "COMPLETED"
	StatusFailed     PrintJobStatus = "FAILED"
)

// PrintJob represents a print job entity
type PrintJob struct {
	ID          string         `json:"id"`
	InvoiceID   string         `json:"invoice_id"`
	Status      PrintJobStatus `json:"status"`
	Attempts    int            `json:"attempts"`
	MaxAttempts int            `json:"max_attempts"`
	LastError   string         `json:"last_error,omitempty"`
	CreatedAt   time.Time      `json:"created_at"`
	CompletedAt *time.Time     `json:"completed_at,omitempty"`
}

// CreatePrintJobInput represents input for creating a print job
type CreatePrintJobInput struct {
	InvoiceID      string `json:"invoice_id" validate:"required"`
	IdempotencyKey string `json:"idempotency_key" validate:"required"`
}

// ProcessPrintJobInput represents input for processing a print job
type ProcessPrintJobInput struct {
	InvoiceID string `json:"invoice_id" validate:"required"`
}

// PrintJobError represents a print domain error
type PrintJobError struct {
	Code    string
	Message string
}

func (e *PrintJobError) Error() string {
	return e.Message
}

// CanBeProcessed checks if the print job can be processed
func (p *PrintJob) CanBeProcessed() bool {
	return p.Status == StatusPending || (p.Status == StatusFailed && p.Attempts < p.MaxAttempts)
}

// MarkProcessing marks the job as processing
func (p *PrintJob) MarkProcessing() {
	p.Status = StatusProcessing
	p.Attempts++
}

// MarkCompleted marks the job as completed
func (p *PrintJob) MarkCompleted() {
	now := time.Now()
	p.Status = StatusCompleted
	p.CompletedAt = &now
}

// MarkFailed marks the job as failed
func (p *PrintJob) MarkFailed(errorMsg string) {
	p.Status = StatusFailed
	p.LastError = errorMsg
}
