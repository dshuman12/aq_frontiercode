package infrastructure

import (
	"context"
	"log"
	"time"

	"github.com/sefarius/print-service/domain"
)

// PrintJobWorker implements the PrintServiceWorker interface
// This worker processes print jobs asynchronously
type PrintJobWorker struct {
	repo         domain.PrintJobRepository
	useCase      domain.PrintJobUseCase
	pollInterval time.Duration
	stopChan     chan struct{}
	isRunning    bool
}

// NewPrintJobWorker creates a new print job worker
func NewPrintJobWorker(
	repo domain.PrintJobRepository,
	useCase domain.PrintJobUseCase,
) *PrintJobWorker {
	return &PrintJobWorker{
		repo:         repo,
		useCase:      useCase,
		pollInterval: 5 * time.Second,
		stopChan:     make(chan struct{}),
	}
}

// Start starts the async worker
func (w *PrintJobWorker) Start(ctx context.Context) {
	if w.isRunning {
		log.Println("Print job worker is already running")
		return
	}

	w.isRunning = true
	log.Println("[WORKER] Starting print job worker...")

	go func() {
		ticker := time.NewTicker(w.pollInterval)
		defer ticker.Stop()

		for {
			select {
			case <-w.stopChan:
				log.Println("[WORKER] Print job worker stopped")
				w.isRunning = false
				return
			case <-ticker.C:
				w.processRetryableJobs(ctx)
			}
		}
	}()
}

// Stop stops the async worker
func (w *PrintJobWorker) Stop() {
	if !w.isRunning {
		return
	}

	log.Println("[WORKER] Stopping print job worker...")
	close(w.stopChan)
	w.isRunning = false
}

// ProcessJob processes a single print job
func (w *PrintJobWorker) ProcessJob(ctx context.Context, job *domain.PrintJob) error {
	log.Printf("[WORKER] Processing print job %s for invoice %s", job.ID, job.InvoiceID)

	// Process the job through the use case
	_, err := w.useCase.ProcessPrintJob(ctx, job.ID)
	if err != nil {
		log.Printf("[WORKER] Error processing job %s: %v", job.ID, err)
		return err
	}

	return nil
}

// processRetryableJobs retrieves and processes retryable jobs
func (w *PrintJobWorker) processRetryableJobs(ctx context.Context) {
	jobs, err := w.repo.GetRetryableJobs(ctx, 10) // Process up to 10 jobs per interval
	if err != nil {
		log.Printf("[WORKER] Error retrieving retryable jobs: %v", err)
		return
	}

	if len(jobs) == 0 {
		return
	}

	log.Printf("[WORKER] Found %d jobs to process", len(jobs))

	for _, job := range jobs {
		if err := w.ProcessJob(ctx, job); err != nil {
			log.Printf("[WORKER] Failed to process job %s: %v", job.ID, err)
		}
	}
}

// Ensure PrintJobWorker implements PrintServiceWorker
var _ domain.PrintServiceWorker = (*PrintJobWorker)(nil)
