package infrastructure

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	_ "github.com/lib/pq"
	"github.com/sefarius/print-service/domain"
)

// PostgresPrintJobRepository implements the PrintJobRepository interface
type PostgresPrintJobRepository struct {
	db *sql.DB
}

// NewPostgresPrintJobRepository creates a new PostgreSQL print job repository
func NewPostgresPrintJobRepository(db *sql.DB) *PostgresPrintJobRepository {
	return &PostgresPrintJobRepository{db: db}
}

// Create inserts a new print job
func (r *PostgresPrintJobRepository) Create(ctx context.Context, job *domain.PrintJob) error {
	query := `
		INSERT INTO print.print_jobs (id, invoice_id, status, attempts, max_attempts, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
	`

	_, err := r.db.ExecContext(ctx, query,
		job.ID,
		job.InvoiceID,
		string(job.Status),
		job.Attempts,
		job.MaxAttempts,
		job.CreatedAt,
	)

	if err != nil {
		return fmt.Errorf("failed to create print job: %w", err)
	}

	return nil
}

// GetByID retrieves a print job by ID
func (r *PostgresPrintJobRepository) GetByID(ctx context.Context, id string) (*domain.PrintJob, error) {
	query := `
		SELECT id, invoice_id, status, attempts, max_attempts, last_error, created_at, completed_at
		FROM print.print_jobs
		WHERE id = $1 AND deleted_at IS NULL
	`

	job := &domain.PrintJob{}
	var lastError sql.NullString
	var completedAt sql.NullTime
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&job.ID,
		&job.InvoiceID,
		(*string)(&job.Status),
		&job.Attempts,
		&job.MaxAttempts,
		&lastError,
		&job.CreatedAt,
		&completedAt,
	)
	if lastError.Valid {
		job.LastError = lastError.String
	}
	if completedAt.Valid {
		job.CompletedAt = &completedAt.Time
	}

	if err == sql.ErrNoRows {
		return nil, errors.New("print job not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get print job: %w", err)
	}

	return job, nil
}

// GetByInvoiceID retrieves a print job by invoice ID
func (r *PostgresPrintJobRepository) GetByInvoiceID(ctx context.Context, invoiceID string) (*domain.PrintJob, error) {
	query := `
		SELECT id, invoice_id, status, attempts, max_attempts, last_error, created_at, completed_at
		FROM print.print_jobs
		WHERE invoice_id = $1 AND deleted_at IS NULL
	`

	job := &domain.PrintJob{}
	var lastError sql.NullString
	var completedAt sql.NullTime
	err := r.db.QueryRowContext(ctx, query, invoiceID).Scan(
		&job.ID,
		&job.InvoiceID,
		(*string)(&job.Status),
		&job.Attempts,
		&job.MaxAttempts,
		&lastError,
		&job.CreatedAt,
		&completedAt,
	)
	if lastError.Valid {
		job.LastError = lastError.String
	}
	if completedAt.Valid {
		job.CompletedAt = &completedAt.Time
	}

	if err == sql.ErrNoRows {
		return nil, errors.New("print job not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get print job: %w", err)
	}

	return job, nil
}

// GetAll retrieves all print jobs with pagination
func (r *PostgresPrintJobRepository) GetAll(ctx context.Context, limit, offset int) ([]*domain.PrintJob, error) {
	query := `
		SELECT id, invoice_id, status, attempts, max_attempts, last_error, created_at, completed_at
		FROM print.print_jobs
		WHERE deleted_at IS NULL
		ORDER BY created_at DESC
		LIMIT $1 OFFSET $2
	`

	rows, err := r.db.QueryContext(ctx, query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to query print jobs: %w", err)
	}
	defer rows.Close()

	var jobs []*domain.PrintJob
	for rows.Next() {
		job := &domain.PrintJob{}
		var lastError sql.NullString
		var completedAt sql.NullTime
		err := rows.Scan(
			&job.ID,
			&job.InvoiceID,
			(*string)(&job.Status),
			&job.Attempts,
			&job.MaxAttempts,
			&lastError,
			&job.CreatedAt,
			&completedAt,
		)
		if lastError.Valid {
			job.LastError = lastError.String
		}
		if completedAt.Valid {
			job.CompletedAt = &completedAt.Time
		}
		if err != nil {
			return nil, fmt.Errorf("failed to scan print job: %w", err)
		}
		jobs = append(jobs, job)
	}

	return jobs, rows.Err()
}

// Update updates a print job
func (r *PostgresPrintJobRepository) Update(ctx context.Context, job *domain.PrintJob) error {
	query := `
		UPDATE print.print_jobs
		SET status = $1, attempts = $2, last_error = $3, completed_at = $4
		WHERE id = $5 AND deleted_at IS NULL
	`

	result, err := r.db.ExecContext(ctx, query,
		string(job.Status),
		job.Attempts,
		job.LastError,
		job.CompletedAt,
		job.ID,
	)

	if err != nil {
		return fmt.Errorf("failed to update print job: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to check update result: %w", err)
	}

	if rows == 0 {
		return errors.New("print job not found")
	}

	return nil
}

// Delete performs a soft delete on a print job
func (r *PostgresPrintJobRepository) Delete(ctx context.Context, id string) error {
	query := `
		UPDATE print.print_jobs
		SET deleted_at = $1
		WHERE id = $2 AND deleted_at IS NULL
	`

	result, err := r.db.ExecContext(ctx, query, time.Now(), id)
	if err != nil {
		return fmt.Errorf("failed to delete print job: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to check delete result: %w", err)
	}

	if rows == 0 {
		return errors.New("print job not found")
	}

	return nil
}

// GetByIDForUpdate retrieves a print job with a pessimistic lock
func (r *PostgresPrintJobRepository) GetByIDForUpdate(ctx context.Context, id string) (*domain.PrintJob, error) {
	query := `
		SELECT id, invoice_id, status, attempts, max_attempts, last_error, created_at, completed_at
		FROM print.print_jobs
		WHERE id = $1 AND deleted_at IS NULL
		FOR UPDATE
	`

	job := &domain.PrintJob{}
	var lastError sql.NullString
	var completedAt sql.NullTime
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&job.ID,
		&job.InvoiceID,
		(*string)(&job.Status),
		&job.Attempts,
		&job.MaxAttempts,
		&lastError,
		&job.CreatedAt,
		&completedAt,
	)
	if lastError.Valid {
		job.LastError = lastError.String
	}
	if completedAt.Valid {
		job.CompletedAt = &completedAt.Time
	}

	if err == sql.ErrNoRows {
		return nil, errors.New("print job not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get print job for update: %w", err)
	}

	return job, nil
}

// GetRetryableJobs retrieves pending and failed jobs for retry
func (r *PostgresPrintJobRepository) GetRetryableJobs(ctx context.Context, limit int) ([]*domain.PrintJob, error) {
	query := `
		SELECT id, invoice_id, status, attempts, max_attempts, last_error, created_at, completed_at
		FROM print.print_jobs
		WHERE (status = 'PENDING' OR status = 'FAILED')
		AND attempts < max_attempts
		AND deleted_at IS NULL
		ORDER BY created_at ASC
		LIMIT $1
	`

	rows, err := r.db.QueryContext(ctx, query, limit)
	if err != nil {
		return nil, fmt.Errorf("failed to query retryable jobs: %w", err)
	}
	defer rows.Close()

	var jobs []*domain.PrintJob
	for rows.Next() {
		job := &domain.PrintJob{}
		var lastError sql.NullString
		var completedAt sql.NullTime
		err := rows.Scan(
			&job.ID,
			&job.InvoiceID,
			(*string)(&job.Status),
			&job.Attempts,
			&job.MaxAttempts,
			&lastError,
			&job.CreatedAt,
			&completedAt,
		)
		if lastError.Valid {
			job.LastError = lastError.String
		}
		if completedAt.Valid {
			job.CompletedAt = &completedAt.Time
		}
		if err != nil {
			return nil, fmt.Errorf("failed to scan print job: %w", err)
		}
		jobs = append(jobs, job)
	}

	return jobs, rows.Err()
}
