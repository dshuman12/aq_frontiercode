package infrastructure

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/sefarius/print-service/domain"
)

// HTTPBillingServiceClient implements the BillingServiceClient interface
type HTTPBillingServiceClient struct {
	baseURL string
	client  *http.Client
}

// NewHTTPBillingServiceClient creates a new HTTP billing service client
func NewHTTPBillingServiceClient(baseURL string) *HTTPBillingServiceClient {
	return &HTTPBillingServiceClient{
		baseURL: baseURL,
		client: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

// GetInvoice retrieves invoice information from the billing service
func (c *HTTPBillingServiceClient) GetInvoice(ctx context.Context, invoiceID string) (interface{}, error) {
	url := fmt.Sprintf("%s/api/billing/invoices/%s", c.baseURL, invoiceID)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call billing service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("billing service returned status %d: %s", resp.StatusCode, string(body))
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return result, nil
}

// CloseInvoice closes an invoice in the billing service
func (c *HTTPBillingServiceClient) CloseInvoice(ctx context.Context, invoiceID string) (interface{}, error) {
	url := fmt.Sprintf("%s/api/billing/invoices/%s/close", c.baseURL, invoiceID)

	req, err := http.NewRequestWithContext(ctx, "POST", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call billing service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("billing service returned status %d: %s", resp.StatusCode, string(body))
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return result, nil
}

// Ensure HTTPBillingServiceClient implements BillingServiceClient
var _ domain.BillingServiceClient = (*HTTPBillingServiceClient)(nil)

// ============================================================================
// Stock Service Client
// ============================================================================

// HTTPStockServiceClient implements the StockServiceClient interface
type HTTPStockServiceClient struct {
	baseURL string
	client  *http.Client
}

// NewHTTPStockServiceClient creates a new HTTP stock service client
func NewHTTPStockServiceClient(baseURL string) *HTTPStockServiceClient {
	return &HTTPStockServiceClient{
		baseURL: baseURL,
		client: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

// DecrementStock decrements stock in the stock service
func (c *HTTPStockServiceClient) DecrementStock(ctx context.Context, productID string, quantity int) error {
	url := fmt.Sprintf("%s/api/stock/products/%s/decrement", c.baseURL, productID)

	payload := map[string]int{"quantity": quantity}
	bodyBytes, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to call stock service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("stock service returned status %d: %s", resp.StatusCode, string(body))
	}

	return nil
}

// GetProduct retrieves product information from the stock service
func (c *HTTPStockServiceClient) GetProduct(ctx context.Context, productID string) (interface{}, error) {
	url := fmt.Sprintf("%s/api/stock/products/%s", c.baseURL, productID)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call stock service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("stock service returned status %d", resp.StatusCode)
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return result, nil
}

// Ensure HTTPStockServiceClient implements StockServiceClient
var _ domain.StockServiceClient = (*HTTPStockServiceClient)(nil)
