package application

import (
	"context"
	"errors"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/sefarius/print-service/domain"
)

// PrintJobService isola a lógica de negócio (Use Cases) inerente ao processamento 
// de filas de impressão. Implementa a interface PrintJobUseCase.
type PrintJobService struct {
	repo            domain.PrintJobRepository
	billingService  domain.BillingServiceClient
	stockService    domain.StockServiceClient
	idempotencyRepo domain.PrintJobRepository // Simplificado referenciando o mesmo repo
}

// NewPrintJobService é o construtor das dependências do serviço de relógio assíncrono.
func NewPrintJobService(
	repo domain.PrintJobRepository,
	billingService domain.BillingServiceClient,
	stockService domain.StockServiceClient,
) *PrintJobService {
	return &PrintJobService{
		repo:            repo,
		billingService:  billingService,
		stockService:    stockService,
		idempotencyRepo: repo,
	}
}

// CreatePrintJob creates a new async print job
func (s *PrintJobService) CreatePrintJob(ctx context.Context, input *domain.CreatePrintJobInput) (*domain.PrintJob, error) {
	if input == nil {
		return nil, errors.New("input cannot be nil")
	}

	if input.InvoiceID == "" {
		return nil, errors.New("invoice id is required")
	}

	// Check if invoice exists
	_, err := s.billingService.GetInvoice(ctx, input.InvoiceID)
	if err != nil {
		return nil, fmt.Errorf("invoice not found: %w", err)
	}

	// Check if print job already exists for this invoice
	existing, _ := s.repo.GetByInvoiceID(ctx, input.InvoiceID)
	if existing != nil && existing.Status != domain.StatusFailed {
		return existing, nil
	}

	// Create print job
	job := &domain.PrintJob{
		ID:          uuid.New().String(),
		InvoiceID:   input.InvoiceID,
		Status:      domain.StatusPending,
		Attempts:    0,
		MaxAttempts: 3,
		CreatedAt:   time.Now(),
	}

	if err := s.repo.Create(ctx, job); err != nil {
		log.Printf("Error creating print job: %v", err)
		return nil, errors.New("failed to create print job")
	}

	log.Printf("[PRINT] Created print job %s for invoice %s", job.ID, job.InvoiceID)
	return job, nil
}

// GetPrintJob retrieves a print job by ID
func (s *PrintJobService) GetPrintJob(ctx context.Context, id string) (*domain.PrintJob, error) {
	if id == "" {
		return nil, errors.New("print job id is required")
	}

	job, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("print job not found: %w", err)
	}

	return job, nil
}

// ListPrintJobs retrieves all print jobs with pagination
func (s *PrintJobService) ListPrintJobs(ctx context.Context, limit, offset int) ([]*domain.PrintJob, error) {
	if limit <= 0 {
		limit = 20
	}
	if limit > 100 {
		limit = 100
	}
	if offset < 0 {
		offset = 0
	}

	jobs, err := s.repo.GetAll(ctx, limit, offset)
	if err != nil {
		log.Printf("Error listing print jobs: %v", err)
		return nil, errors.New("failed to list print jobs")
	}

	return jobs, nil
}

// ProcessPrintJob processes a print job (called by async worker)
func (s *PrintJobService) ProcessPrintJob(ctx context.Context, jobID string) (*domain.PrintJob, error) {
	if jobID == "" {
		return nil, errors.New("print job id is required")
	}

	// Get job with lock
	job, err := s.repo.GetByIDForUpdate(ctx, jobID)
	if err != nil {
		return nil, fmt.Errorf("print job not found: %w", err)
	}

	// Check if job can be processed
	if !job.CanBeProcessed() {
		return nil, fmt.Errorf("print job cannot be processed (status: %s)", job.Status)
	}

	// Mark as processing
	job.MarkProcessing()
	if err := s.repo.Update(ctx, job); err != nil {
		return nil, err
	}

	// Get invoice details
	invoiceData, err := s.billingService.GetInvoice(ctx, job.InvoiceID)
	if err != nil {
		job.MarkFailed(fmt.Sprintf("Failed to get invoice: %v", err))
		_ = s.repo.Update(ctx, job)
		return nil, fmt.Errorf("failed to get invoice: %w", err)
	}

	// In production, we would use the invoice data to:
	// 1. Extract items and quantities
	// 2. Decrement stock for each item via StockService
	// 3. Generate PDF or print document
	log.Printf("[PRINT] Processing print job %s for invoice %s", job.ID, job.InvoiceID)
	log.Printf("[PRINT] Invoice data: %v", invoiceData)

	// Simulate print processing (in real implementation, call actual print service)
	time.Sleep(1 * time.Second)

	// Mark as completed
	job.MarkCompleted()
	if err := s.repo.Update(ctx, job); err != nil {
		job.MarkFailed(fmt.Sprintf("Failed to update job: %v", err))
		_ = s.repo.Update(ctx, job)
		return nil, err
	}

	// Close invoice in billing service
	if _, err := s.billingService.CloseInvoice(ctx, job.InvoiceID); err != nil {
		log.Printf("Warning: Failed to close invoice: %v", err)
		// Don't fail the print job if invoice close fails
	}

	log.Printf("[PRINT] Completed print job %s", job.ID)
	return job, nil
}

// RetryPrintJob retries a failed print job
func (s *PrintJobService) RetryPrintJob(ctx context.Context, jobID string) (*domain.PrintJob, error) {
	if jobID == "" {
		return nil, errors.New("print job id is required")
	}

	job, err := s.repo.GetByIDForUpdate(ctx, jobID)
	if err != nil {
		return nil, fmt.Errorf("print job not found: %w", err)
	}

	if job.Status != domain.StatusFailed {
		return nil, errors.New("can only retry failed jobs")
	}

	if job.Attempts >= job.MaxAttempts {
		return nil, fmt.Errorf("max retry attempts exceeded (%d)", job.MaxAttempts)
	}

	// Reset status to pending for retry
	job.Status = domain.StatusPending
	job.LastError = ""

	if err := s.repo.Update(ctx, job); err != nil {
		return nil, err
	}

	log.Printf("[PRINT] Retrying print job %s (attempt %d/%d)", job.ID, job.Attempts+1, job.MaxAttempts)
	return job, nil
}

// GetPrintJobByInvoice retrieves the print job for an invoice
func (s *PrintJobService) GetPrintJobByInvoice(ctx context.Context, invoiceID string) (*domain.PrintJob, error) {
	if invoiceID == "" {
		return nil, errors.New("invoice id is required")
	}

	job, err := s.repo.GetByInvoiceID(ctx, invoiceID)
	if err != nil {
		return nil, fmt.Errorf("print job not found: %w", err)
	}

	return job, nil
}
