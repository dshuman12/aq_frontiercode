package application

import "time"

// PrintJobDTO represents a PrintJob data transfer object
type PrintJobDTO struct {
	ID          string     `json:"id"`
	InvoiceID   string     `json:"invoice_id"`
	Status      string     `json:"status"`
	Attempts    int        `json:"attempts"`
	MaxAttempts int        `json:"max_attempts"`
	LastError   string     `json:"last_error,omitempty"`
	CreatedAt   time.Time  `json:"created_at"`
	CompletedAt *time.Time `json:"completed_at,omitempty"`
}

// CreatePrintJobRequest represents the request to create a print job
type CreatePrintJobRequest struct {
	InvoiceID      string `json:"invoice_id" validate:"required"`
	IdempotencyKey string `json:"idempotency_key" validate:"required"`
}

// PrintJobStatusResponse represents the response for print job status
type PrintJobStatusResponse struct {
	JobID     string `json:"job_id"`
	InvoiceID string `json:"invoice_id"`
	Status    string `json:"status"`
	Progress  int    `json:"progress"` // 0-100
	Message   string `json:"message,omitempty"`
}

// APIResponse represents a standard API response wrapper
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Code    int         `json:"code"`
}

// PaginatedResponse represents a paginated response
type PaginatedResponse struct {
	Items  interface{} `json:"items"`
	Total  int         `json:"total"`
	Limit  int         `json:"limit"`
	Offset int         `json:"offset"`
}
