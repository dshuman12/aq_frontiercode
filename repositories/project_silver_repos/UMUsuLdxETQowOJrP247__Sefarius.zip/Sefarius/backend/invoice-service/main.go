package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	_ "github.com/lib/pq"
)

func main() {
	// Database initialization. Fail fast if DATABASE_URL is missing —
	// a hardcoded fallback used to live here, which leaked the dev
	// credential into the repo (RF-01).
	dbConnStr := getEnv("DATABASE_URL", "")
	if dbConnStr == "" {
		log.Fatal("DATABASE_URL is required (copy .env.example to .env)")
	}
	db, err := initializeDatabase(dbConnStr)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v\n", err)
	}
	defer db.Close()

	// Fiber app initialization
	app := fiber.New(fiber.Config{
		AppName:      "Invoice Service v1.0",
		ErrorHandler: customErrorHandler,
		WriteTimeout: 30 * time.Second,
		ReadTimeout:  30 * time.Second,
	})

	// Middleware
	app.Use(recover.New())
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${status} - ${method} ${path} - ${latency}\n",
	}))
	app.Use(cors.New(cors.Config{
		AllowOrigins: "*",
		AllowMethods: "GET,POST,PUT,DELETE,OPTIONS",
		AllowHeaders: "Origin,Content-Type,Accept",
	}))

	// Health check
	app.Get("/health", func(c *fiber.Ctx) error {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"status":  "healthy",
			"service": "invoice-service",
			"time":    time.Now().Unix(),
		})
	})

	// Reporting endpoints
	api := app.Group("/api/invoices")

	api.Get("/history", func(c *fiber.Ctx) error {
		// Get invoice history from database
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"success": true,
			"data": fiber.Map{
				"items":  []interface{}{},
				"total":  0,
				"limit":  20,
				"offset": 0,
			},
		})
	})

	api.Get("/stats", func(c *fiber.Ctx) error {
		// Get invoice statistics from database
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"success": true,
			"data": fiber.Map{
				"total_invoices":     0,
				"total_revenue":      0.0,
				"average_value":      0.0,
				"closed_invoices":    0,
				"open_invoices":      0,
				"cancelled_invoices": 0,
			},
		})
	})

	// Start server
	port := getEnv("PORT", "5004")
	go func() {
		log.Printf("Starting Invoice Service on port %s...\n", port)
		if err := app.Listen(":" + port); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v\n", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	log.Println("Shutting down Invoice Service...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := app.ShutdownWithContext(ctx); err != nil {
		log.Fatalf("Shutdown error: %v\n", err)
	}
	log.Println("Invoice Service stopped")
}

func initializeDatabase(dbConnStr string) (*sql.DB, error) {
	db, err := sql.Open("postgres", dbConnStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(5 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	log.Println("Database connection established")
	return db, nil
}

func customErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	var msg string

	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		msg = fe.Message
	} else {
		msg = err.Error()
	}

	return c.Status(code).JSON(fiber.Map{
		"success": false,
		"error":   msg,
		"code":    code,
	})
}

func getEnv(key, defaultValue string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return defaultValue
}
