# Invoice Service

The Invoice Service manages the creation, history, and statistics of invoices. It provides reporting capabilities and maintains the lifecycle of generated documents.

## Features
- Invoice history retrieval
- Sales and revenue statistics
- Database persistence for reporting
- Graceful shutdown support

## Configuration
- `PORT`: Service port (default: 5004)
- `DATABASE_URL`: PostgreSQL connection string

## Endpoints
- `GET /health`: Service status
- `GET /api/invoices/history`: Retrieve full invoice history
- `GET /api/invoices/stats`: Get overview statistics (revenue, volume)

## Development
```bash
go run main.go
```
