package domain

import "time"

// InvoiceReport represents aggregated invoice statistics
type InvoiceReport struct {
	ID                string    `json:"id"`
	TotalInvoices     int       `json:"total_invoices"`
	TotalRevenue      float64   `json:"total_revenue"`
	AverageValue      float64   `json:"average_value"`
	ClosedInvoices    int       `json:"closed_invoices"`
	OpenInvoices      int       `json:"open_invoices"`
	CancelledInvoices int       `json:"cancelled_invoices"`
	GeneratedAt       time.Time `json:"generated_at"`
}

// InvoiceHistory represents a historical record of invoice operations
type InvoiceHistory struct {
	ID        string    `json:"id"`
	InvoiceID string    `json:"invoice_id"`
	Action    string    `json:"action"`
	OldStatus string    `json:"old_status,omitempty"`
	NewStatus string    `json:"new_status,omitempty"`
	Details   string    `json:"details,omitempty"`
	UserID    string    `json:"user_id,omitempty"`
	CreatedAt time.Time `json:"created_at"`
}

// InvoiceStats represents invoice statistics
type InvoiceStats struct {
	DateRange        string  `json:"date_range"`
	InvoicesCreated  int     `json:"invoices_created"`
	InvoicesClosed   int     `json:"invoices_closed"`
	InvoicesCanceled int     `json:"invoices_canceled"`
	TotalAmount      float64 `json:"total_amount"`
	AverageAmount    float64 `json:"average_amount"`
	MaxAmount        float64 `json:"max_amount"`
	MinAmount        float64 `json:"min_amount"`
}
