package main

import (
	"os"
	"testing"
)

func TestGetEnv(t *testing.T) {
	key := "TEST_ENV_VAR"
	defaultValue := "default"

	// Test default value
	if result := getEnv(key, defaultValue); result != defaultValue {
		t.Errorf("Expected %s, got %s", defaultValue, result)
	}

	// Test set value
	expectedValue := "expected"
	os.Setenv(key, expectedValue)
	defer os.Unsetenv(key)

	if result := getEnv(key, defaultValue); result != expectedValue {
		t.Errorf("Expected %s, got %s", expectedValue, result)
	}
}
