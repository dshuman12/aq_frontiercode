package domain

import "context"

// ProductRepository defines the contract for product persistence
type ProductRepository interface {
	Create(ctx context.Context, product *Product) error
	GetByID(ctx context.Context, id string) (*Product, error)
	GetByCode(ctx context.Context, code string) (*Product, error)
	GetAll(ctx context.Context, limit, offset int) ([]*Product, error)
	// Count returns the total number of products. Required by paginated
	// listings — Total in PaginatedResponse used to be set to the page
	// size (a bug), making numerical pagination impossible to compute
	// on the frontend.
	Count(ctx context.Context) (int, error)
	// Search runs a case-insensitive ILIKE match on code OR description.
	// Returns up to limit rows ordered by code. Used by the wizard
	// autocomplete where the operator is typing a partial term.
	Search(ctx context.Context, query string, limit int) ([]*Product, error)
	Update(ctx context.Context, product *Product) error
	Delete(ctx context.Context, id string) error

	// Pessimistic locking for concurrency control
	GetByIDForUpdate(ctx context.Context, id string) (*Product, error)

	// Reserve stock with pessimistic lock
	ReserveStock(ctx context.Context, productID string, quantity int) (*Product, error)

	// Release reserved stock
	ReleaseStock(ctx context.Context, productID string, quantity int) error
}

// ProductUseCase defines the contract for product business logic
type ProductUseCase interface {
	CreateProduct(ctx context.Context, input *CreateProductInput) (*Product, error)
	GetProduct(ctx context.Context, id string) (*Product, error)
	ListProducts(ctx context.Context, limit, offset int) ([]*Product, error)
	CountProducts(ctx context.Context) (int, error)
	// SearchProducts is the q-mode of the listing endpoint — code or
	// description ILIKE. Bounded by limit; offset omitted because the
	// autocomplete consumer wants top-N matches, not paginated lists.
	SearchProducts(ctx context.Context, query string, limit int) ([]*Product, error)
	UpdateProduct(ctx context.Context, id string, input *UpdateProductInput) (*Product, error)
	DeleteProduct(ctx context.Context, id string) error

	// Stock reservation for invoices
	ReserveStock(ctx context.Context, productID string, quantity int) (*StockReservation, error)
	ReleaseStock(ctx context.Context, productID string, quantity int) error

	// Decrement stock (called during print)
	DecrementStock(ctx context.Context, productID string, quantity int) (*Product, error)
}
