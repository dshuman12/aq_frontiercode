package domain

import (
	"time"
)

// Product representa o núcleo absoluto (Core Entity) do Produto no domínio de Estoque.
//
// Sprint Catálogo Fiscal (migration 006) added the fiscal fields so a
// product can populate an NF-e item without manual re-typing. NCM and
// ValorUnitario are pointers because they are nullable in the DB —
// they have no universal default and the operator must fill them in
// before the autocomplete in the wizard can use the product.
type Product struct {
	ID          string    `json:"id"`
	Code        string    `json:"code"`
	Description string    `json:"description"`
	Balance     int       `json:"balance"`
	// Version é estritamente usado para controle de concorrência sintético (Optimistic Locking)
	// Impedindo que duas transações baixem o estoque fora de sincronia.
	Version int `json:"version"`

	// Fiscal fields (sprint Catálogo Fiscal, migration 006).
	NCM             *string  `json:"ncm,omitempty"`
	CFOPPadraoSaida string   `json:"cfop_padrao_saida"`
	UCom            string   `json:"u_com"`
	ValorUnitario   *float64 `json:"valor_unitario,omitempty"`
	Origem          string   `json:"origem"`
	CSTICMS         string   `json:"cst_icms"`
	PICMS           float64  `json:"p_icms"`
	CSTPIS          string   `json:"cst_pis"`
	CSTCofins       string   `json:"cst_cofins"`

	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// CreateProductInput representa a DTO (Data Transfer Object) de inserção.
// Fiscal fields are all optional on insert — the DB has defaults for the
// 7 NOT NULL ones and accepts NULL for NCM + ValorUnitario.
type CreateProductInput struct {
	Code            string   `json:"code" validate:"required,max=50"`
	Description     string   `json:"description" validate:"required"`
	Balance         int      `json:"balance" validate:"min=0"`
	NCM             *string  `json:"ncm,omitempty"`
	CFOPPadraoSaida *string  `json:"cfop_padrao_saida,omitempty"`
	UCom            *string  `json:"u_com,omitempty"`
	ValorUnitario   *float64 `json:"valor_unitario,omitempty"`
	Origem          *string  `json:"origem,omitempty"`
	CSTICMS         *string  `json:"cst_icms,omitempty"`
	PICMS           *float64 `json:"p_icms,omitempty"`
	CSTPIS          *string  `json:"cst_pis,omitempty"`
	CSTCofins       *string  `json:"cst_cofins,omitempty"`
}

// UpdateProductInput suporta mutações parciais restritas do Produto (PATCH behavior).
// Every fiscal field is a pointer so the caller can update one without
// having to round-trip the others (PATCH semantics). A nil pointer
// means "do not touch"; a non-nil pointer to the zero value means
// "set to that value".
type UpdateProductInput struct {
	Description     *string  `json:"description,omitempty"`
	Balance         *int     `json:"balance,omitempty" validate:"omitempty,min=0"`
	NCM             *string  `json:"ncm,omitempty"`
	CFOPPadraoSaida *string  `json:"cfop_padrao_saida,omitempty"`
	UCom            *string  `json:"u_com,omitempty"`
	ValorUnitario   *float64 `json:"valor_unitario,omitempty"`
	Origem          *string  `json:"origem,omitempty"`
	CSTICMS         *string  `json:"cst_icms,omitempty"`
	PICMS           *float64 `json:"p_icms,omitempty"`
	CSTPIS          *string  `json:"cst_pis,omitempty"`
	CSTCofins       *string  `json:"cst_cofins,omitempty"`
}

// UpdateBalanceInput transfere a intencionalidade de mudança de valor em um estoque de item.
type UpdateBalanceInput struct {
	Quantity int `json:"quantity" validate:"required,min=1"`
}

// ReserveStockInput aciona a transação que congela o saldo do produto.
type ReserveStockInput struct {
	ProductID string `json:"product_id" validate:"required"`
	Quantity  int    `json:"quantity" validate:"required,min=1"`
}

// StockReservation descreve o log/snapshot do processamento de uma requisição de inventário.
type StockReservation struct {
	ProductID string
	Quantity  int
	Success   bool
	Error     string
}
