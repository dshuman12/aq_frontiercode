package domain

const (
	// Pagination defaults
	DefaultPageLimit = 20
	MaxPageLimit     = 100
	MinPageLimit     = 1
)
