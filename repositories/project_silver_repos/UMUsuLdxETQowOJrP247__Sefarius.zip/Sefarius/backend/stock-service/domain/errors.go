package domain

import "fmt"

// DomainError represents a domain-specific error with a code for programmatic identification
type DomainError struct {
	Code    string
	Message string
}

func (e *DomainError) Error() string {
	return e.Message
}

// IsDomainError checks if an error is a specific domain error
func IsDomainError(err error, target *DomainError) bool {
	de, ok := err.(*DomainError)
	if !ok {
		return false
	}
	return de.Code == target.Code
}

// Predefined domain errors
var (
	ErrProductNotFound = &DomainError{
		Code:    "PRODUCT_NOT_FOUND",
		Message: "product not found",
	}

	ErrInsufficientStock = &DomainError{
		Code:    "INSUFFICIENT_STOCK",
		Message: "insufficient stock available",
	}

	ErrDuplicateCode = &DomainError{
		Code:    "DUPLICATE_CODE",
		Message: "product code already exists",
	}

	ErrInputNil = &DomainError{
		Code:    "INPUT_NIL",
		Message: "input cannot be nil",
	}

	ErrCodeRequired = &DomainError{
		Code:    "CODE_REQUIRED",
		Message: "product code is required",
	}

	ErrDescriptionRequired = &DomainError{
		Code:    "DESCRIPTION_REQUIRED",
		Message: "product description is required",
	}

	ErrBalanceNegative = &DomainError{
		Code:    "BALANCE_NEGATIVE",
		Message: "balance cannot be negative",
	}

	ErrIDRequired = &DomainError{
		Code:    "ID_REQUIRED",
		Message: "product id is required",
	}

	ErrQuantityInvalid = &DomainError{
		Code:    "QUANTITY_INVALID",
		Message: "quantity must be positive",
	}
)

// NewInsufficientStockError creates a detailed insufficient stock error
func NewInsufficientStockError(available, requested int) *DomainError {
	return &DomainError{
		Code:    "INSUFFICIENT_STOCK",
		Message: fmt.Sprintf("insufficient stock: available=%d, requested=%d", available, requested),
	}
}
