package interfaces

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/sefarius/stock-service/application"
	"github.com/sefarius/stock-service/domain"
)

// ProductHandler handles HTTP requests for products
type ProductHandler struct {
	service domain.ProductUseCase
}

// NewProductHandler creates a new product handler
func NewProductHandler(service domain.ProductUseCase) *ProductHandler {
	return &ProductHandler{
		service: service,
	}
}

// CreateProductHandler handles POST /products
func (h *ProductHandler) CreateProduct(c *fiber.Ctx) error {
	var req application.CreateProductRequest
	if err := ParseAndValidate(c, &req); err != nil {
		return err
	}

	input := &domain.CreateProductInput{
		Code:            req.Code,
		Description:     req.Description,
		Balance:         req.Balance,
		NCM:             req.NCM,
		CFOPPadraoSaida: req.CFOPPadraoSaida,
		UCom:            req.UCom,
		ValorUnitario:   req.ValorUnitario,
		Origem:          req.Origem,
		CSTICMS:         req.CSTICMS,
		PICMS:           req.PICMS,
		CSTPIS:          req.CSTPIS,
		CSTCofins:       req.CSTCofins,
	}

	product, err := h.service.CreateProduct(c.Context(), input)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsDomainError(err, domain.ErrCodeRequired) ||
			domain.IsDomainError(err, domain.ErrDescriptionRequired) ||
			domain.IsDomainError(err, domain.ErrBalanceNegative) ||
			domain.IsDomainError(err, domain.ErrInputNil) ||
			isFiscalFormatError(err) {
			statusCode = fiber.StatusBadRequest
		} else if domain.IsDomainError(err, domain.ErrDuplicateCode) {
			statusCode = fiber.StatusConflict
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	return SuccessResponse(c, fiber.StatusCreated, application.ToProductDTO(product))
}

// isFiscalFormatError reports whether an error is one of the fiscal
// format violations raised by application.validateFiscalFields. They
// all map to HTTP 400 instead of 500. Identification by Code prefix
// keeps the handler decoupled from the validator's enum.
func isFiscalFormatError(err error) bool {
	de, ok := err.(*domain.DomainError)
	if !ok {
		return false
	}
	switch de.Code {
	case "NCM_INVALID", "CFOP_INVALID", "UCOM_TOO_LONG",
		"VALOR_UNITARIO_NOT_POSITIVE", "ORIGEM_INVALID",
		"CST_ICMS_INVALID", "P_ICMS_OUT_OF_RANGE",
		"CST_PIS_INVALID", "CST_COFINS_INVALID":
		return true
	}
	return false
}

// GetProductHandler handles GET /products/:id
func (h *ProductHandler) GetProduct(c *fiber.Ctx) error {
	id := c.Params("id")

	product, err := h.service.GetProduct(c.Context(), id)
	if err != nil {
		if domain.IsDomainError(err, domain.ErrProductNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "product not found")
		}
		return ErrorResponse(c, fiber.StatusNotFound, "product not found")
	}

	return SuccessResponse(c, fiber.StatusOK, application.ToProductDTO(product))
}

// ListProductsHandler handles GET /products
func (h *ProductHandler) ListProducts(c *fiber.Ctx) error {
	limit := domain.DefaultPageLimit
	offset := 0

	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 {
			limit = l
		}
	}

	if offsetStr := c.Query("offset"); offsetStr != "" {
		if o, err := strconv.Atoi(offsetStr); err == nil && o >= 0 {
			offset = o
		}
	}

	// q-mode: when ?q=<term> is present, the endpoint switches from
	// paginated listing to ILIKE search on code OR description. Used
	// by the wizard autocomplete to surface "top N matches as user
	// types". Limit defaults to 20 in this mode (top-N ergonomics);
	// offset is ignored — autocomplete consumers want best matches,
	// not pagination.
	if q := c.Query("q"); q != "" {
		searchLimit := limit
		if searchLimit <= 0 || searchLimit > 20 {
			searchLimit = 20
		}
		products, err := h.service.SearchProducts(c.Context(), q, searchLimit)
		if err != nil {
			return ErrorResponse(c, fiber.StatusInternalServerError, "failed to search products")
		}
		dtos := make([]application.ProductDTO, 0, len(products))
		for _, product := range products {
			dtos = append(dtos, application.ToProductDTO(product))
		}
		return SuccessResponse(c, fiber.StatusOK, application.PaginatedResponse{
			Items:  dtos,
			Total:  len(dtos),
			Limit:  searchLimit,
			Offset: 0,
		})
	}

	products, err := h.service.ListProducts(c.Context(), limit, offset)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "failed to list products")
	}

	// Pull the real total from the DB so the frontend can render
	// numerical pagination ("1 2 3 ... N"). Previously Total was set
	// to len(dtos) (the page size), making the page count uncomputable.
	total, err := h.service.CountProducts(c.Context())
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "failed to count products")
	}

	dtos := make([]application.ProductDTO, 0, len(products))
	for _, product := range products {
		dtos = append(dtos, application.ToProductDTO(product))
	}

	return SuccessResponse(c, fiber.StatusOK, application.PaginatedResponse{
		Items:  dtos,
		Total:  total,
		Limit:  limit,
		Offset: offset,
	})
}

// UpdateProductHandler handles PUT /products/:id
func (h *ProductHandler) UpdateProduct(c *fiber.Ctx) error {
	id := c.Params("id")

	var req application.UpdateProductRequest
	if err := ParseAndValidate(c, &req); err != nil {
		return err
	}

	input := &domain.UpdateProductInput{
		Description:     req.Description,
		Balance:         req.Balance,
		NCM:             req.NCM,
		CFOPPadraoSaida: req.CFOPPadraoSaida,
		UCom:            req.UCom,
		ValorUnitario:   req.ValorUnitario,
		Origem:          req.Origem,
		CSTICMS:         req.CSTICMS,
		PICMS:           req.PICMS,
		CSTPIS:          req.CSTPIS,
		CSTCofins:       req.CSTCofins,
	}

	product, err := h.service.UpdateProduct(c.Context(), id, input)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsDomainError(err, domain.ErrProductNotFound) {
			statusCode = fiber.StatusNotFound
		} else if domain.IsDomainError(err, domain.ErrBalanceNegative) || isFiscalFormatError(err) {
			statusCode = fiber.StatusBadRequest
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	return SuccessResponse(c, fiber.StatusOK, application.ToProductDTO(product))
}

// DeleteProductHandler handles DELETE /products/:id
func (h *ProductHandler) DeleteProduct(c *fiber.Ctx) error {
	id := c.Params("id")

	if err := h.service.DeleteProduct(c.Context(), id); err != nil {
		if domain.IsDomainError(err, domain.ErrProductNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, err.Error())
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	return c.Status(http.StatusNoContent).Send(nil)
}

// ReserveStockHandler handles POST /products/:id/reserve
func (h *ProductHandler) ReserveStock(c *fiber.Ctx) error {
	id := c.Params("id")

	var req struct {
		Quantity int `json:"quantity"`
	}
	if err := ParseAndValidate(c, &req); err != nil {
		return err
	}

	reservation, err := h.service.ReserveStock(c.Context(), id, req.Quantity)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	return SuccessResponse(c, fiber.StatusOK, application.ReserveStockResponse{
		ProductID: reservation.ProductID,
		Quantity:  reservation.Quantity,
		Success:   reservation.Success,
		Error:     reservation.Error,
	})
}

// DecrementStockHandler handles POST /products/:id/decrement
func (h *ProductHandler) DecrementStock(c *fiber.Ctx) error {
	id := c.Params("id")

	var req struct {
		Quantity int `json:"quantity"`
	}
	if err := ParseAndValidate(c, &req); err != nil {
		return err
	}

	product, err := h.service.DecrementStock(c.Context(), id, req.Quantity)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsDomainError(err, domain.ErrProductNotFound) {
			statusCode = fiber.StatusNotFound
		} else if domain.IsDomainError(err, domain.ErrInsufficientStock) {
			statusCode = fiber.StatusConflict
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	return SuccessResponse(c, fiber.StatusOK, application.ToProductDTO(product))
}

// HealthHandler handles GET /health
func (h *ProductHandler) Health(c *fiber.Ctx) error {
	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"status":  "healthy",
		"service": "stock-service",
		"time":    time.Now().Unix(),
	})
}
