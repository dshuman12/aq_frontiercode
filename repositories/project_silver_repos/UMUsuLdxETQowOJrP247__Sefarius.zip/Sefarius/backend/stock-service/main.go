package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	_ "github.com/lib/pq"

	"github.com/sefarius/stock-service/application"
	"github.com/sefarius/stock-service/infrastructure"
	"github.com/sefarius/stock-service/interfaces"
)

func main() {
	// Database initialization. Fail fast if DATABASE_URL is missing —
	// a hardcoded fallback used to live here, which leaked the dev
	// credential into the repo (RF-01).
	dbConnStr := getEnv("DATABASE_URL", "")
	if dbConnStr == "" {
		log.Fatal("DATABASE_URL is required (copy .env.example to .env)")
	}
	db, err := initializeDatabase(dbConnStr)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v\n", err)
	}
	defer db.Close()

	// Repository & Service initialization (Dependency Injection)
	repo := infrastructure.NewPostgresProductRepository(db)
	svc := application.NewProductService(repo)
	handler := interfaces.NewProductHandler(svc)

	// Fiber app initialization
	app := fiber.New(fiber.Config{
		AppName:      "Stock Service v1.0",
		ErrorHandler: customErrorHandler,
		WriteTimeout: 30 * time.Second,
		ReadTimeout:  30 * time.Second,
	})

	// Middleware
	app.Use(recover.New())
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${status} - ${method} ${path} - ${latency}\n",
	}))
	app.Use(cors.New(cors.Config{
		AllowOrigins: getEnv("CORS_ORIGINS", "*"),
		AllowMethods: "GET,POST,PUT,DELETE,OPTIONS",
		AllowHeaders: "Origin,Content-Type,Accept",
	}))

	// Routes
	setupRoutes(app, handler)

	// Start server
	port := getEnv("PORT", "5001")
	go func() {
		log.Printf("Starting Stock Service on port %s...\n", port)
		if err := app.Listen(":" + port); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v\n", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	log.Println("Shutting down Stock Service...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := app.ShutdownWithContext(ctx); err != nil {
		log.Fatalf("Shutdown error: %v\n", err)
	}
	log.Println("Stock Service stopped")
}

// setupRoutes configures all HTTP routes
func setupRoutes(app *fiber.App, handler *interfaces.ProductHandler) {
	// Health check
	app.Get("/health", handler.Health)

	// Products endpoints
	api := app.Group("/api/stock")
	api.Post("/products", handler.CreateProduct)
	api.Get("/products", handler.ListProducts)
	api.Get("/products/:id", handler.GetProduct)
	api.Put("/products/:id", handler.UpdateProduct)
	api.Delete("/products/:id", handler.DeleteProduct)

	// Stock management endpoints
	api.Post("/products/:id/reserve", handler.ReserveStock)
	api.Post("/products/:id/decrement", handler.DecrementStock)
}

// initializeDatabase initializes database connection and runs migrations
func initializeDatabase(dbConnStr string) (*sql.DB, error) {
	db, err := sql.Open("postgres", dbConnStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	// Connection pool settings - configurable via environment variables
	db.SetMaxOpenConns(getEnvInt("DB_MAX_CONNECTIONS", 25))
	db.SetMaxIdleConns(getEnvInt("DB_MAX_IDLE_CONNECTIONS", 5))
	db.SetConnMaxLifetime(time.Duration(getEnvInt("DB_CONN_MAX_LIFETIME_SECONDS", 300)) * time.Second)
	db.SetConnMaxIdleTime(2 * time.Minute)

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	log.Println("Database connection established")
	return db, nil
}

// customErrorHandler handles all errors
func customErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	var msg string

	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		msg = fe.Message
	} else {
		msg = err.Error()
	}

	return c.Status(code).JSON(fiber.Map{
		"success": false,
		"error":   msg,
		"code":    code,
	})
}

// getEnv gets environment variable with default fallback
func getEnv(key, defaultValue string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return defaultValue
}

// getEnvInt gets integer environment variable with default fallback
func getEnvInt(key string, defaultVal int) int {
	val := os.Getenv(key)
	if val == "" {
		return defaultVal
	}
	intVal, err := strconv.Atoi(val)
	if err != nil {
		return defaultVal
	}
	return intVal
}
