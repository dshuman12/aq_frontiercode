package application

import (
	"testing"

	"github.com/sefarius/stock-service/domain"
)

// TestValidateFiscalFields_AllNilIsValid asserts that the helper does
// not fire on nil pointers — Create with no fiscal fields supplied is
// the canonical "use DB defaults" path and must not be rejected.
func TestValidateFiscalFields_AllNilIsValid(t *testing.T) {
	if err := validateFiscalFields(nil, nil, nil, nil, nil, nil, nil, nil, nil); err != nil {
		t.Errorf("expected nil for all-nil input, got %v", err)
	}
}

func TestValidateFiscalFields_NCM(t *testing.T) {
	cases := []struct {
		name     string
		ncm      string
		wantCode string // empty = expect nil
	}{
		{"valid 8 digits", "12345678", ""},
		{"empty allowed", "", ""},
		{"whitespace allowed", "   ", ""},
		{"7 digits rejected", "1234567", "NCM_INVALID"},
		{"9 digits rejected", "123456789", "NCM_INVALID"},
		{"letters rejected", "abcdefgh", "NCM_INVALID"},
		{"hyphen rejected", "1234-678", "NCM_INVALID"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			ncm := tc.ncm
			got := validateFiscalFields(&ncm, nil, nil, nil, nil, nil, nil, nil, nil)
			assertDomainCode(t, got, tc.wantCode)
		})
	}
}

func TestValidateFiscalFields_CFOP(t *testing.T) {
	cases := []struct {
		name, cfop, wantCode string
	}{
		{"5102 valid", "5102", ""},
		{"6102 valid (interestadual)", "6102", ""},
		{"empty allowed", "", ""},
		{"3 digits rejected", "510", "CFOP_INVALID"},
		{"5 digits rejected", "51023", "CFOP_INVALID"},
		{"starts with 0 rejected", "0102", "CFOP_INVALID"},
		{"starts with 8 rejected", "8102", "CFOP_INVALID"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfop := tc.cfop
			got := validateFiscalFields(nil, &cfop, nil, nil, nil, nil, nil, nil, nil)
			assertDomainCode(t, got, tc.wantCode)
		})
	}
}

func TestValidateFiscalFields_ValorUnitario(t *testing.T) {
	zero, neg, pos := 0.0, -10.0, 1500.50
	if got := validateFiscalFields(nil, nil, nil, &pos, nil, nil, nil, nil, nil); got != nil {
		t.Errorf("positive value should be valid, got %v", got)
	}
	assertDomainCode(t, validateFiscalFields(nil, nil, nil, &zero, nil, nil, nil, nil, nil), "VALOR_UNITARIO_NOT_POSITIVE")
	assertDomainCode(t, validateFiscalFields(nil, nil, nil, &neg, nil, nil, nil, nil, nil), "VALOR_UNITARIO_NOT_POSITIVE")
}

func TestValidateFiscalFields_Origem(t *testing.T) {
	cases := []struct {
		name, origem, wantCode string
	}{
		{"0 valid (nacional)", "0", ""},
		{"8 valid (nacional CMI)", "8", ""},
		{"9 rejected (out of range)", "9", "ORIGEM_INVALID"},
		{"two digits rejected", "10", "ORIGEM_INVALID"},
		{"letter rejected", "A", "ORIGEM_INVALID"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			o := tc.origem
			got := validateFiscalFields(nil, nil, nil, nil, &o, nil, nil, nil, nil)
			assertDomainCode(t, got, tc.wantCode)
		})
	}
}

func TestValidateFiscalFields_PICMS(t *testing.T) {
	zero, mid, hundred, neg, over := 0.0, 18.0, 100.0, -1.0, 100.5
	cases := []struct {
		name     string
		val      *float64
		wantCode string
	}{
		{"zero allowed", &zero, ""},
		{"18 allowed", &mid, ""},
		{"100 allowed (boundary)", &hundred, ""},
		{"negative rejected", &neg, "P_ICMS_OUT_OF_RANGE"},
		{"100.5 rejected (above max)", &over, "P_ICMS_OUT_OF_RANGE"},
		{"nil unchanged", nil, ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := validateFiscalFields(nil, nil, nil, nil, nil, nil, tc.val, nil, nil)
			assertDomainCode(t, got, tc.wantCode)
		})
	}
}

// All three CST fields share the same 2-digit format check. Test each
// pointer position to catch a copy-paste bug where one pointer is
// validated against a different field's check.
func TestValidateFiscalFields_CSTTwoDigits(t *testing.T) {
	good, bad := "00", "AB"

	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, &good, nil, nil, nil), "")
	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, &bad, nil, nil, nil), "CST_ICMS_INVALID")

	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, nil, nil, &good, nil), "")
	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, nil, nil, &bad, nil), "CST_PIS_INVALID")

	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, nil, nil, nil, &good), "")
	assertDomainCode(t, validateFiscalFields(nil, nil, nil, nil, nil, nil, nil, nil, &bad), "CST_COFINS_INVALID")
}

func TestValidateFiscalFields_UCom(t *testing.T) {
	short := "UN"
	long := "UNIDADE" // 7 chars > 6 max
	assertDomainCode(t, validateFiscalFields(nil, nil, &short, nil, nil, nil, nil, nil, nil), "")
	assertDomainCode(t, validateFiscalFields(nil, nil, &long, nil, nil, nil, nil, nil, nil), "UCOM_TOO_LONG")
}

// assertDomainCode compares a *domain.DomainError result against an
// expected Code. Empty wantCode means the result must be nil.
func assertDomainCode(t *testing.T, got *domain.DomainError, wantCode string) {
	t.Helper()
	if wantCode == "" {
		if got != nil {
			t.Errorf("expected nil, got code=%s message=%q", got.Code, got.Message)
		}
		return
	}
	if got == nil {
		t.Errorf("expected error code %q, got nil", wantCode)
		return
	}
	if got.Code != wantCode {
		t.Errorf("got code %q, want %q (message: %q)", got.Code, wantCode, got.Message)
	}
}
