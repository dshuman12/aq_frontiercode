package application

import (
	"time"

	"github.com/sefarius/stock-service/domain"
)

// ProductDTO represents a Product data transfer object.
// Fiscal fields land here as JSON keys the frontend autocomplete reads.
type ProductDTO struct {
	ID              string    `json:"id"`
	Code            string    `json:"code"`
	Description     string    `json:"description"`
	Balance         int       `json:"balance"`
	Version         int       `json:"version"`
	NCM             *string   `json:"ncm,omitempty"`
	CFOPPadraoSaida string    `json:"cfop_padrao_saida"`
	UCom            string    `json:"u_com"`
	ValorUnitario   *float64  `json:"valor_unitario,omitempty"`
	Origem          string    `json:"origem"`
	CSTICMS         string    `json:"cst_icms"`
	PICMS           float64   `json:"p_icms"`
	CSTPIS          string    `json:"cst_pis"`
	CSTCofins       string    `json:"cst_cofins"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

// ToProductDTO maps a domain Product to its wire DTO. Centralised so
// all 5 handler endpoints (Create, GetByID, List, Update, DecrementStock)
// share one source of truth — adding a fiscal field touches one place
// instead of five.
func ToProductDTO(p *domain.Product) ProductDTO {
	return ProductDTO{
		ID:              p.ID,
		Code:            p.Code,
		Description:     p.Description,
		Balance:         p.Balance,
		Version:         p.Version,
		NCM:             p.NCM,
		CFOPPadraoSaida: p.CFOPPadraoSaida,
		UCom:            p.UCom,
		ValorUnitario:   p.ValorUnitario,
		Origem:          p.Origem,
		CSTICMS:         p.CSTICMS,
		PICMS:           p.PICMS,
		CSTPIS:          p.CSTPIS,
		CSTCofins:       p.CSTCofins,
		CreatedAt:       p.CreatedAt,
		UpdatedAt:       p.UpdatedAt,
	}
}

// CreateProductRequest represents the request to create a product.
// Fiscal fields are optional on create — DB defaults apply for the
// 7 NOT NULL ones, NCM and ValorUnitario stay NULL until edited.
type CreateProductRequest struct {
	Code            string   `json:"code" validate:"required,max=50"`
	Description     string   `json:"description" validate:"required"`
	Balance         int      `json:"balance" validate:"min=0"`
	NCM             *string  `json:"ncm,omitempty"`
	CFOPPadraoSaida *string  `json:"cfop_padrao_saida,omitempty"`
	UCom            *string  `json:"u_com,omitempty"`
	ValorUnitario   *float64 `json:"valor_unitario,omitempty"`
	Origem          *string  `json:"origem,omitempty"`
	CSTICMS         *string  `json:"cst_icms,omitempty"`
	PICMS           *float64 `json:"p_icms,omitempty"`
	CSTPIS          *string  `json:"cst_pis,omitempty"`
	CSTCofins       *string  `json:"cst_cofins,omitempty"`
}

// UpdateProductRequest represents a PATCH request — every field is a
// pointer so nil means "leave alone" and a non-nil pointer means
// "set to this value". Caller can update one fiscal field without
// having to round-trip the others.
type UpdateProductRequest struct {
	Description     *string  `json:"description,omitempty"`
	Balance         *int     `json:"balance,omitempty" validate:"omitempty,min=0"`
	NCM             *string  `json:"ncm,omitempty"`
	CFOPPadraoSaida *string  `json:"cfop_padrao_saida,omitempty"`
	UCom            *string  `json:"u_com,omitempty"`
	ValorUnitario   *float64 `json:"valor_unitario,omitempty"`
	Origem          *string  `json:"origem,omitempty"`
	CSTICMS         *string  `json:"cst_icms,omitempty"`
	PICMS           *float64 `json:"p_icms,omitempty"`
	CSTPIS          *string  `json:"cst_pis,omitempty"`
	CSTCofins       *string  `json:"cst_cofins,omitempty"`
}

// ReserveStockRequest represents the request to reserve stock
type ReserveStockRequest struct {
	ProductID string `json:"product_id" validate:"required"`
	Quantity  int    `json:"quantity" validate:"required,min=1"`
}

// ReserveStockResponse represents the response of stock reservation
type ReserveStockResponse struct {
	ProductID string `json:"product_id"`
	Quantity  int    `json:"quantity"`
	Success   bool   `json:"success"`
	Error     string `json:"error,omitempty"`
}

// APIResponse represents a standard API response wrapper
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Code    int         `json:"code"`
}

// PaginatedResponse represents a paginated response
type PaginatedResponse struct {
	Items  interface{} `json:"items"`
	Total  int         `json:"total"`
	Limit  int         `json:"limit"`
	Offset int         `json:"offset"`
}
