package application

import (
	"context"
	"fmt"
	"log"
	"regexp"
	"strings"

	"github.com/sefarius/stock-service/domain"
)

// Format validators for the fiscal fields introduced by migration 006.
// These are intentionally format-only — semantic validation (e.g. CST 00
// requires p_ICMS > 0, CFOP family must match tpNF + idDest) lives in
// billing-service's domain/nfe/validator.go where the full NF-e context
// is available. Per sprint plan D3.b: fail-fast at this layer prevents
// data lixo from entering the table; fail-double-fast at billing layer
// catches cross-block inconsistencies before submission.
var (
	ncmRe       = regexp.MustCompile(`^\d{8}$`)
	cfopRe      = regexp.MustCompile(`^[1-7]\d{3}$`)
	origemRe    = regexp.MustCompile(`^[0-8]$`)
	twoDigitsRe = regexp.MustCompile(`^\d{2}$`)
)

// validateFiscalFields runs each non-nil/non-empty fiscal pointer
// through its format check. A nil pointer means "not changing" or
// "use default" depending on the caller (Create vs Update); an empty
// string is treated the same way to tolerate whitespace-only payloads
// upstream. Returns the first violation as a DomainError so the HTTP
// handler maps it to 400, matching the existing pattern for required
// fields.
func validateFiscalFields(
	ncm *string,
	cfop *string,
	uCom *string,
	valorUnitario *float64,
	origem *string,
	cstICMS *string,
	pICMS *float64,
	cstPIS *string,
	cstCofins *string,
) *domain.DomainError {
	if isPresent(ncm) && !ncmRe.MatchString(*ncm) {
		return &domain.DomainError{Code: "NCM_INVALID", Message: "ncm deve ter exatamente 8 dígitos"}
	}
	if isPresent(cfop) && !cfopRe.MatchString(*cfop) {
		return &domain.DomainError{Code: "CFOP_INVALID", Message: "cfop_padrao_saida deve ter formato [1-7]\\d{3}"}
	}
	if isPresent(uCom) && len(*uCom) > 6 {
		return &domain.DomainError{Code: "UCOM_TOO_LONG", Message: "u_com deve ter no máximo 6 caracteres"}
	}
	if valorUnitario != nil && *valorUnitario <= 0 {
		return &domain.DomainError{Code: "VALOR_UNITARIO_NOT_POSITIVE", Message: "valor_unitario deve ser maior que zero"}
	}
	if isPresent(origem) && !origemRe.MatchString(*origem) {
		return &domain.DomainError{Code: "ORIGEM_INVALID", Message: "origem deve estar entre 0 e 8"}
	}
	if isPresent(cstICMS) && !twoDigitsRe.MatchString(*cstICMS) {
		return &domain.DomainError{Code: "CST_ICMS_INVALID", Message: "cst_icms deve ter exatamente 2 dígitos"}
	}
	if pICMS != nil && (*pICMS < 0 || *pICMS > 100) {
		return &domain.DomainError{Code: "P_ICMS_OUT_OF_RANGE", Message: "p_icms deve estar entre 0 e 100"}
	}
	if isPresent(cstPIS) && !twoDigitsRe.MatchString(*cstPIS) {
		return &domain.DomainError{Code: "CST_PIS_INVALID", Message: "cst_pis deve ter exatamente 2 dígitos"}
	}
	if isPresent(cstCofins) && !twoDigitsRe.MatchString(*cstCofins) {
		return &domain.DomainError{Code: "CST_COFINS_INVALID", Message: "cst_cofins deve ter exatamente 2 dígitos"}
	}
	return nil
}

func isPresent(s *string) bool {
	return s != nil && strings.TrimSpace(*s) != ""
}

// ProductService implementa a interface ProductUseCase definida dentro da camada de domínio.
// Ele orquestra o fluxo central de negócios não ligado ao HTTP (Clean Architecture).
type ProductService struct {
	repo domain.ProductRepository
}

// NewProductService é a fábrica de injeção de dependência.
// Instancia o serviço atrelando-o à camada de banco de dados (Repository).
func NewProductService(repo domain.ProductRepository) *ProductService {
	return &ProductService{
		repo: repo,
	}
}

// CreateProduct orquestra a criação de um novo produto executando sanitização,
// verificando dependências únicas (ex: SKU Duplicado) e repassando para inserção no banco.
func (s *ProductService) CreateProduct(ctx context.Context, input *domain.CreateProductInput) (*domain.Product, error) {
	if input == nil {
		return nil, domain.ErrInputNil
	}

	code := strings.TrimSpace(input.Code)
	if code == "" {
		return nil, domain.ErrCodeRequired
	}

	desc := strings.TrimSpace(input.Description)
	if desc == "" {
		return nil, domain.ErrDescriptionRequired
	}

	if input.Balance < 0 {
		return nil, domain.ErrBalanceNegative
	}

	if vErr := validateFiscalFields(
		input.NCM, input.CFOPPadraoSaida, input.UCom, input.ValorUnitario,
		input.Origem, input.CSTICMS, input.PICMS, input.CSTPIS, input.CSTCofins,
	); vErr != nil {
		return nil, vErr
	}

	// Check if product with same code already exists
	existing, err := s.repo.GetByCode(ctx, code)
	if err == nil && existing != nil {
		return nil, &domain.DomainError{
			Code:    "DUPLICATE_CODE",
			Message: fmt.Sprintf("product with code '%s' already exists", code),
		}
	}

	product := &domain.Product{
		Code:        code,
		Description: desc,
		Balance:     input.Balance,
		Version:     0,
		// Fiscal fields with DB-side defaults: only set when caller
		// provided a value, otherwise let the DEFAULT clause win.
		// Pointer-to-pointer assignments preserve "explicit empty" vs
		// "absent" semantics on insert.
		NCM:           input.NCM,
		ValorUnitario: input.ValorUnitario,
	}
	applyOptionalString(&product.CFOPPadraoSaida, input.CFOPPadraoSaida, "5102")
	applyOptionalString(&product.UCom, input.UCom, "UN")
	applyOptionalString(&product.Origem, input.Origem, "0")
	applyOptionalString(&product.CSTICMS, input.CSTICMS, "00")
	applyOptionalFloat(&product.PICMS, input.PICMS, 18.00)
	applyOptionalString(&product.CSTPIS, input.CSTPIS, "49")
	applyOptionalString(&product.CSTCofins, input.CSTCofins, "49")

	if err := s.repo.Create(ctx, product); err != nil {
		log.Printf("Error creating product: %v", err)
		return nil, fmt.Errorf("failed to create product: %w", err)
	}

	return product, nil
}

// applyOptionalString sets dst to *src when src is non-nil, otherwise
// to fallback. Used for the 7 fiscal fields that have DB-side defaults
// but also need to be present in the in-memory entity returned to the
// caller (so the response DTO carries the default value, not "" on a
// fresh Create that did not set it).
func applyOptionalString(dst *string, src *string, fallback string) {
	if src != nil {
		*dst = *src
	} else {
		*dst = fallback
	}
}

func applyOptionalFloat(dst *float64, src *float64, fallback float64) {
	if src != nil {
		*dst = *src
	} else {
		*dst = fallback
	}
}

// GetProduct retrieves a product by ID
func (s *ProductService) GetProduct(ctx context.Context, id string) (*domain.Product, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	product, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, domain.ErrProductNotFound
	}

	return product, nil
}

// ListProducts retrieves all products with pagination
func (s *ProductService) ListProducts(ctx context.Context, limit, offset int) ([]*domain.Product, error) {
	if limit <= 0 {
		limit = domain.DefaultPageLimit
	}
	if limit > domain.MaxPageLimit {
		limit = domain.MaxPageLimit
	}
	if offset < 0 {
		offset = 0
	}

	products, err := s.repo.GetAll(ctx, limit, offset)
	if err != nil {
		log.Printf("Error listing products: %v", err)
		return nil, fmt.Errorf("failed to list products: %w", err)
	}

	return products, nil
}

// CountProducts returns the total number of non-deleted products in
// the catalog. Pairs with ListProducts to expose accurate Total in
// PaginatedResponse — the frontend's numerical pagination needs this
// to render "1 2 3 ... N" page indicators.
func (s *ProductService) CountProducts(ctx context.Context) (int, error) {
	n, err := s.repo.Count(ctx)
	if err != nil {
		log.Printf("Error counting products: %v", err)
		return 0, fmt.Errorf("failed to count products: %w", err)
	}
	return n, nil
}

// SearchProducts runs an ILIKE search on code OR description. Whitespace
// is trimmed and minimum-length-2 enforced so a focus-only "type one
// char" autocomplete request does not stream the full table back. An
// empty query returns an empty slice, NOT every product — callers that
// want everything use ListProducts.
func (s *ProductService) SearchProducts(ctx context.Context, query string, limit int) ([]*domain.Product, error) {
	query = strings.TrimSpace(query)
	if len(query) < 2 {
		return []*domain.Product{}, nil
	}
	if limit <= 0 {
		limit = domain.DefaultPageLimit
	}
	if limit > domain.MaxPageLimit {
		limit = domain.MaxPageLimit
	}
	products, err := s.repo.Search(ctx, query, limit)
	if err != nil {
		log.Printf("Error searching products: %v", err)
		return nil, fmt.Errorf("failed to search products: %w", err)
	}
	return products, nil
}

// UpdateProduct updates a product
func (s *ProductService) UpdateProduct(ctx context.Context, id string, input *domain.UpdateProductInput) (*domain.Product, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	product, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, domain.ErrProductNotFound
	}

	if input.Description != nil {
		desc := strings.TrimSpace(*input.Description)
		if desc == "" {
			return nil, domain.ErrDescriptionRequired
		}
		product.Description = desc
	}

	if input.Balance != nil {
		if *input.Balance < 0 {
			return nil, domain.ErrBalanceNegative
		}
		product.Balance = *input.Balance
	}

	if vErr := validateFiscalFields(
		input.NCM, input.CFOPPadraoSaida, input.UCom, input.ValorUnitario,
		input.Origem, input.CSTICMS, input.PICMS, input.CSTPIS, input.CSTCofins,
	); vErr != nil {
		return nil, vErr
	}

	// Apply patches: nil pointer = leave alone, non-nil = overwrite.
	// NCM and ValorUnitario remain nullable so passing a nil-pointer
	// on those means "unchanged"; a non-nil pointer to "" or 0 means
	// the operator deliberately set the value.
	if input.NCM != nil {
		product.NCM = input.NCM
	}
	if input.CFOPPadraoSaida != nil {
		product.CFOPPadraoSaida = *input.CFOPPadraoSaida
	}
	if input.UCom != nil {
		product.UCom = *input.UCom
	}
	if input.ValorUnitario != nil {
		product.ValorUnitario = input.ValorUnitario
	}
	if input.Origem != nil {
		product.Origem = *input.Origem
	}
	if input.CSTICMS != nil {
		product.CSTICMS = *input.CSTICMS
	}
	if input.PICMS != nil {
		product.PICMS = *input.PICMS
	}
	if input.CSTPIS != nil {
		product.CSTPIS = *input.CSTPIS
	}
	if input.CSTCofins != nil {
		product.CSTCofins = *input.CSTCofins
	}

	if err := s.repo.Update(ctx, product); err != nil {
		log.Printf("Error updating product: %v", err)
		return nil, fmt.Errorf("failed to update product: %w", err)
	}

	return product, nil
}

// DeleteProduct deletes a product (soft delete)
func (s *ProductService) DeleteProduct(ctx context.Context, id string) error {
	if id == "" {
		return domain.ErrIDRequired
	}

	if err := s.repo.Delete(ctx, id); err != nil {
		log.Printf("Error deleting product: %v", err)
		return domain.ErrProductNotFound
	}

	return nil
}

// ReserveStock reserves stock with pessimistic locking
func (s *ProductService) ReserveStock(ctx context.Context, productID string, quantity int) (*domain.StockReservation, error) {
	if productID == "" {
		return &domain.StockReservation{
			ProductID: productID,
			Success:   false,
			Error:     domain.ErrIDRequired.Message,
		}, nil
	}

	if quantity <= 0 {
		return &domain.StockReservation{
			ProductID: productID,
			Quantity:  quantity,
			Success:   false,
			Error:     domain.ErrQuantityInvalid.Message,
		}, nil
	}

	// Use pessimistic lock to prevent race conditions
	product, err := s.repo.GetByIDForUpdate(ctx, productID)
	if err != nil {
		return &domain.StockReservation{
			ProductID: productID,
			Quantity:  quantity,
			Success:   false,
			Error:     fmt.Sprintf("product not found: %v", err),
		}, nil
	}

	// Check if sufficient balance
	if product.Balance < quantity {
		return &domain.StockReservation{
			ProductID: productID,
			Quantity:  quantity,
			Success:   false,
			Error:     domain.NewInsufficientStockError(product.Balance, quantity).Message,
		}, nil
	}

	// Stock is reserved (lock is held until transaction commits)
	return &domain.StockReservation{
		ProductID: productID,
		Quantity:  quantity,
		Success:   true,
	}, nil
}

// ReleaseStock releases reserved stock
func (s *ProductService) ReleaseStock(ctx context.Context, productID string, quantity int) error {
	if productID == "" {
		return domain.ErrIDRequired
	}

	if quantity <= 0 {
		return domain.ErrQuantityInvalid
	}

	return s.repo.ReleaseStock(ctx, productID, quantity)
}

// DecrementStock decrements product balance (used during invoice printing)
func (s *ProductService) DecrementStock(ctx context.Context, productID string, quantity int) (*domain.Product, error) {
	if productID == "" {
		return nil, domain.ErrIDRequired
	}

	if quantity <= 0 {
		return nil, domain.ErrQuantityInvalid
	}

	// Use pessimistic lock
	product, err := s.repo.GetByIDForUpdate(ctx, productID)
	if err != nil {
		return nil, domain.ErrProductNotFound
	}

	if product.Balance < quantity {
		return nil, domain.NewInsufficientStockError(product.Balance, quantity)
	}

	product.Balance -= quantity
	product.Version++ // Increment version for optimistic locking fallback

	if err := s.repo.Update(ctx, product); err != nil {
		return nil, fmt.Errorf("failed to update stock: %w", err)
	}

	return product, nil
}
