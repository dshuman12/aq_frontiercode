package infrastructure

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	_ "github.com/lib/pq"
	"github.com/sefarius/stock-service/domain"
)

// PostgresProductRepository implements the ProductRepository interface
type PostgresProductRepository struct {
	db *sql.DB
}

// NewPostgresProductRepository creates a new PostgreSQL product repository
func NewPostgresProductRepository(db *sql.DB) *PostgresProductRepository {
	return &PostgresProductRepository{db: db}
}

// productSelectColumns is the canonical column list for SELECT
// statements. Centralised so all 5 reading queries (GetByID,
// GetByCode, GetAll, GetAllWithSearch, GetByIDForUpdate) stay in sync
// when sprint commits add columns.
const productSelectColumns = `id, code, description, balance, version,
	ncm, cfop_padrao_saida, u_com, valor_unitario, origem,
	cst_icms, p_icms, cst_pis, cst_cofins,
	created_at, updated_at`

// scanProductRow scans a row positionally matching productSelectColumns.
func scanProductRow(scanner interface{ Scan(...interface{}) error }, p *domain.Product) error {
	return scanner.Scan(
		&p.ID, &p.Code, &p.Description, &p.Balance, &p.Version,
		&p.NCM, &p.CFOPPadraoSaida, &p.UCom, &p.ValorUnitario, &p.Origem,
		&p.CSTICMS, &p.PICMS, &p.CSTPIS, &p.CSTCofins,
		&p.CreatedAt, &p.UpdatedAt,
	)
}

// Create inserts a new product. Fiscal fields with DB-side defaults
// are still passed explicitly so the response carries the canonical
// stored value rather than the in-memory snapshot.
func (r *PostgresProductRepository) Create(ctx context.Context, product *domain.Product) error {
	query := `
		INSERT INTO stock.products (
			code, description, balance, version,
			ncm, cfop_padrao_saida, u_com, valor_unitario, origem,
			cst_icms, p_icms, cst_pis, cst_cofins,
			created_at, updated_at
		)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
		RETURNING id, created_at, updated_at
	`

	now := time.Now()
	err := r.db.QueryRowContext(ctx, query,
		product.Code,
		product.Description,
		product.Balance,
		product.Version,
		product.NCM,
		product.CFOPPadraoSaida,
		product.UCom,
		product.ValorUnitario,
		product.Origem,
		product.CSTICMS,
		product.PICMS,
		product.CSTPIS,
		product.CSTCofins,
		now,
		now,
	).Scan(&product.ID, &product.CreatedAt, &product.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create product: %w", err)
	}

	return nil
}

// GetByID retrieves a product by ID
func (r *PostgresProductRepository) GetByID(ctx context.Context, id string) (*domain.Product, error) {
	query := `SELECT ` + productSelectColumns + ` FROM stock.products WHERE id = $1 AND deleted_at IS NULL`

	product := &domain.Product{}
	err := scanProductRow(r.db.QueryRowContext(ctx, query, id), product)

	if err == sql.ErrNoRows {
		return nil, domain.ErrProductNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get product: %w", err)
	}

	return product, nil
}

// GetByCode retrieves a product by code
func (r *PostgresProductRepository) GetByCode(ctx context.Context, code string) (*domain.Product, error) {
	query := `SELECT ` + productSelectColumns + ` FROM stock.products WHERE code = $1 AND deleted_at IS NULL`

	product := &domain.Product{}
	err := scanProductRow(r.db.QueryRowContext(ctx, query, code), product)

	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get product by code: %w", err)
	}

	return product, nil
}

// GetAll retrieves all products with pagination
func (r *PostgresProductRepository) GetAll(ctx context.Context, limit, offset int) ([]*domain.Product, error) {
	query := `SELECT ` + productSelectColumns + `
		FROM stock.products
		WHERE deleted_at IS NULL
		ORDER BY created_at DESC
		LIMIT $1 OFFSET $2`

	rows, err := r.db.QueryContext(ctx, query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to query products: %w", err)
	}
	defer rows.Close()

	products := make([]*domain.Product, 0, limit)
	for rows.Next() {
		product := &domain.Product{}
		if err := scanProductRow(rows, product); err != nil {
			return nil, fmt.Errorf("failed to scan product: %w", err)
		}
		products = append(products, product)
	}

	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating products: %w", err)
	}

	return products, nil
}

// Count returns the number of non-deleted products. Used by the
// paginated list endpoint to populate Total in the response — without
// this, the frontend can't render numerical pagination (1 2 3 ... N)
// because it has no way to know how many pages exist.
func (r *PostgresProductRepository) Count(ctx context.Context) (int, error) {
	var n int
	err := r.db.QueryRowContext(ctx, `SELECT count(*) FROM stock.products WHERE deleted_at IS NULL`).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("failed to count products: %w", err)
	}
	return n, nil
}

// Search runs an ILIKE match on code OR description. The query
// argument arrives already trimmed by the use case; this layer just
// wraps it in % wildcards. Postgres ILIKE is case-insensitive but
// accent-sensitive — "São Paulo" will not match "sao paulo". For the
// MVP we accept that; if it bites we add the unaccent extension via
// a follow-up migration.
func (r *PostgresProductRepository) Search(ctx context.Context, query string, limit int) ([]*domain.Product, error) {
	sql := `SELECT ` + productSelectColumns + `
		FROM stock.products
		WHERE deleted_at IS NULL
		  AND (code ILIKE $1 OR description ILIKE $1)
		ORDER BY code
		LIMIT $2`

	pattern := "%" + query + "%"
	rows, err := r.db.QueryContext(ctx, sql, pattern, limit)
	if err != nil {
		return nil, fmt.Errorf("failed to search products: %w", err)
	}
	defer rows.Close()

	products := make([]*domain.Product, 0, limit)
	for rows.Next() {
		product := &domain.Product{}
		if err := scanProductRow(rows, product); err != nil {
			return nil, fmt.Errorf("failed to scan product: %w", err)
		}
		products = append(products, product)
	}
	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating products: %w", err)
	}
	return products, nil
}

// Update writes the full entity back. The use case loads the product,
// applies non-nil patches in memory, then calls this — so all 12
// mutable columns are written every time. Version increments
// monotonically for optimistic-locking callers downstream.
func (r *PostgresProductRepository) Update(ctx context.Context, product *domain.Product) error {
	query := `
		UPDATE stock.products
		SET description = $1, balance = $2,
		    ncm = $3, cfop_padrao_saida = $4, u_com = $5, valor_unitario = $6,
		    origem = $7, cst_icms = $8, p_icms = $9, cst_pis = $10, cst_cofins = $11,
		    version = version + 1, updated_at = $12
		WHERE id = $13 AND deleted_at IS NULL
		RETURNING version, updated_at
	`

	now := time.Now()
	err := r.db.QueryRowContext(ctx, query,
		product.Description,
		product.Balance,
		product.NCM,
		product.CFOPPadraoSaida,
		product.UCom,
		product.ValorUnitario,
		product.Origem,
		product.CSTICMS,
		product.PICMS,
		product.CSTPIS,
		product.CSTCofins,
		now,
		product.ID,
	).Scan(&product.Version, &product.UpdatedAt)

	if err == sql.ErrNoRows {
		return domain.ErrProductNotFound
	}
	if err != nil {
		return fmt.Errorf("failed to update product: %w", err)
	}

	return nil
}

// Delete performs a soft delete on a product
func (r *PostgresProductRepository) Delete(ctx context.Context, id string) error {
	query := `
		UPDATE stock.products
		SET deleted_at = $1
		WHERE id = $2 AND deleted_at IS NULL
	`

	result, err := r.db.ExecContext(ctx, query, time.Now(), id)
	if err != nil {
		return fmt.Errorf("failed to delete product: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to check delete result: %w", err)
	}

	if rows == 0 {
		return domain.ErrProductNotFound
	}

	return nil
}

// GetByIDForUpdate retrieves a product with a pessimistic lock (FOR UPDATE)
// This prevents concurrent modifications on the same row
func (r *PostgresProductRepository) GetByIDForUpdate(ctx context.Context, id string) (*domain.Product, error) {
	query := `SELECT ` + productSelectColumns + `
		FROM stock.products
		WHERE id = $1 AND deleted_at IS NULL
		FOR UPDATE`

	product := &domain.Product{}
	err := scanProductRow(r.db.QueryRowContext(ctx, query, id), product)

	if err == sql.ErrNoRows {
		return nil, domain.ErrProductNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get product for update: %w", err)
	}

	return product, nil
}

// ReserveStock reserves stock with pessimistic locking
func (r *PostgresProductRepository) ReserveStock(ctx context.Context, productID string, quantity int) (*domain.Product, error) {
	product, err := r.GetByIDForUpdate(ctx, productID)
	if err != nil {
		return nil, err
	}

	if product.Balance < quantity {
		return nil, fmt.Errorf("insufficient stock: available=%d, requested=%d", product.Balance, quantity)
	}

	return product, nil
}

// ReleaseStock releases reserved stock (no-op in this case since we use transactions)
func (r *PostgresProductRepository) ReleaseStock(ctx context.Context, productID string, quantity int) error {
	// In a transaction-based system, releases happen via transaction rollback
	// This is a placeholder for other locking strategies
	return nil
}

// BeginTx begins a new database transaction
func (r *PostgresProductRepository) BeginTx(ctx context.Context) (*sql.Tx, error) {
	return r.db.BeginTx(ctx, &sql.TxOptions{
		Isolation: sql.LevelSerializable,
	})
}
