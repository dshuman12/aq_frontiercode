# Stock Service

The Stock Service is responsible for managing product inventory and stock levels within the Sefarius. It handles product creation, stock reservations, and updates.

## Features
- Product CRUD (Create, Read, Update, Delete)
- Inventory management
- Stock reservation logic
- PostgreSQL persistence

## Configuration
- `PORT`: Service port (default: 5001)
- `DATABASE_URL`: PostgreSQL connection string
- `CORS_ORIGINS`: Allowed origins for CORS

## Endpoints
- `GET /health`: Health check
- `POST /api/stock/products`: Create a new product
- `GET /api/stock/products`: List all products
- `POST /api/stock/products/:id/reserve`: Reserve stock for an order
- `POST /api/stock/products/:id/decrement`: Update stock levels

## Development
```bash
go run main.go
```
