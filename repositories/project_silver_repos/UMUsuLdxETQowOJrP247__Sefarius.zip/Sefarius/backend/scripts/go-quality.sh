#!/usr/bin/env bash
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"

if [[ ! -d "$BACKEND_DIR" ]]; then
  echo "backend directory not found: $BACKEND_DIR"
  exit 1
fi

mapfile -t MODULE_DIRS < <(find "$BACKEND_DIR" -name go.mod -print0 | xargs -0 -n1 dirname | sort)

if [[ ${#MODULE_DIRS[@]} -eq 0 ]]; then
  echo "No Go modules found under $BACKEND_DIR"
  exit 1
fi

echo "Found ${#MODULE_DIRS[@]} Go modules"

overall_status=0

for module_dir in "${MODULE_DIRS[@]}"; do
  echo
  echo "==> Module: $module_dir"

  echo " - go mod download"
  if ! (cd "$module_dir" && GOFLAGS=-mod=mod go mod download); then
    echo "   failed: unable to download dependencies"
    overall_status=1
    continue
  fi

  echo " - gofmt"
  if ! find "$module_dir" -name '*.go' -not -path '*/vendor/*' -exec gofmt -w {} +; then
    echo "   failed: gofmt"
    overall_status=1
  fi

  echo " - go vet"
  if ! (cd "$module_dir" && GOFLAGS=-mod=mod go vet ./...); then
    echo "   failed: go vet"
    overall_status=1
  fi

  echo " - go test"
  if ! (cd "$module_dir" && GOFLAGS=-mod=mod go test ./...); then
    echo "   failed: go test"
    overall_status=1
  fi

  if command -v golangci-lint >/dev/null 2>&1; then
    echo " - golangci-lint"
    if ! (cd "$module_dir" && GOFLAGS=-mod=mod golangci-lint run ./...); then
      echo "   failed: golangci-lint"
      overall_status=1
    fi
  else
    echo " - golangci-lint not found in PATH, skipping"
  fi
done

echo
if [[ $overall_status -eq 0 ]]; then
  echo "Go quality checks completed successfully."
else
  echo "Go quality checks completed with failures."
fi

exit "$overall_status"
