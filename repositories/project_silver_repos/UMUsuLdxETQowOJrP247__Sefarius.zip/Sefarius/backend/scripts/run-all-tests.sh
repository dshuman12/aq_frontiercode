#!/bin/bash

# Script to run tests for all microservices

SERVICES=("api-gateway" "billing-service" "invoice-service" "print-service" "stock-service")

echo "Starting tests for all microservices..."
echo "----------------------------------------"

for service in "${SERVICES[@]}"; do
    echo "Running tests for: $service"
    cd "backend/$service"
    if [ -f "go.mod" ]; then
        go test ./... -v
    else
        echo "No go.mod found for $service, skipping."
    fi
    cd ../..
    echo "----------------------------------------"
done

echo "All tests completed."
