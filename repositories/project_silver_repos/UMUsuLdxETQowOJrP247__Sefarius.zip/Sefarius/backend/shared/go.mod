module github.com/sefarius/shared

go 1.21
