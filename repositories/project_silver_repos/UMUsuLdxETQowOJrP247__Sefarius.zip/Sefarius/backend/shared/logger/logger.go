package logger

import (
	"log"
	"os"
)

type Logger struct {
	*log.Logger
}

func NewLogger(serviceName string) *Logger {
	return &Logger{
		Logger: log.New(os.Stdout, "["+serviceName+"] ", log.LstdFlags|log.Lshortfile),
	}
}

func (l *Logger) Info(format string, v ...interface{}) {
	l.Printf("INFO: "+format, v...)
}

func (l *Logger) Error(format string, v ...interface{}) {
	l.Printf("ERROR: "+format, v...)
}

func (l *Logger) Debug(format string, v ...interface{}) {
	if os.Getenv("LOG_LEVEL") == "debug" {
		l.Printf("DEBUG: "+format, v...)
	}
}
