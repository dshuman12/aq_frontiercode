package application

import (
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"fmt"
	"strings"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// EmitNFeUseCase orchestrates the canonical NF-e emission pipeline:
//
//	build (typed leiaute) -> semantic + totals validation -> sign (XMLDSig)
//	-> authorize via SefazClient -> persist NFeRecord -> return outcome.
//
// Sprint 1.6 kept the use case stateless because persistence wasn't
// wired yet. Sprint 1.8 makes the repository a hard dependency: every
// Emit call that reaches the post-Authorize stage is persisted so
// downstream queries (status check, DANFE rendering, list-by-emit)
// can find it without the caller having to hand-roll a save.
//
// Recovery semantics from sprint 1.6 D4 are unchanged: if the process
// crashes between Authorize and Save, re-emitting the same NF-e hits
// SEFAZ duplicate detection (cStat 539), echoes the original protocol,
// and Save then upserts the record into a consistent state.
type EmitNFeUseCase struct {
	cert   *nfe.Certificate
	client nfe.SefazClient
	repo   nfe.NFeRepository
}

// ErrUseCaseNotConfigured is returned when Emit is called on a use
// case whose certificate, SEFAZ client, or repository is nil. This is
// a programming error, not a fiscal one — distinct from
// nfe.ErrEmitenteSemCert, which signals a runtime CNPJ-without-cert
// lookup miss in a multi-tenant scenario (sprint future).
var ErrUseCaseNotConfigured = errors.New("nfe.EmitNFeUseCase: certificate, SefazClient, and NFeRepository are required")

// NewEmitNFeUseCase wires the dependencies. All three must be non-nil.
// In production the cert comes from a secrets store; in dev/tests
// nfe.GenerateSelfSignedTest + sefaz.MockClient + InMemoryNFeRepository
// give a fully working stack with no external services.
func NewEmitNFeUseCase(cert *nfe.Certificate, client nfe.SefazClient, repo nfe.NFeRepository) *EmitNFeUseCase {
	return &EmitNFeUseCase{cert: cert, client: client, repo: repo}
}

// EmitInput is the minimal envelope the use case needs. The TNFe must
// already be assembled (via nfe.Builder); validation, signing, and
// SEFAZ submission are owned by the use case so that callers can't
// skip a step by accident.
type EmitInput struct {
	NFe *schema.TNFe
}

// EmitOutcome reports the result of an emission attempt.
//
// SignedXML is populated for both authorized and rejected outcomes —
// rejected NF-es still produce signed bytes useful for diagnostics
// and for the contestation flow. Protocol is only set when authorized
// (or duplicate, which echoes the original protocol).
type EmitOutcome struct {
	Status    nfe.AuthorizationStatus
	Chave     nfe.Chave
	SignedXML []byte
	Protocol  *nfe.Protocol  // populated when Status is AUTHORIZED or DUPLICATE
	Rejection *nfe.Rejection // populated when Status is REJECTED
	CStat     string
	XMotivo   string
}

// ErrValidation is returned when ValidateSemantic or
// ValidateTotalsAgainstItems flag any issue. Wraps a slice of
// nfe.ValidationIssue so the caller (HTTP handler in sprint 1.8) can
// surface field-level errors back to the client.
type ErrValidation struct {
	Issues []nfe.ValidationIssue
}

func (e *ErrValidation) Error() string {
	return fmt.Sprintf("nfe.Emit: %d validation issue(s) before submission", len(e.Issues))
}

// Emit runs the full pipeline. The pipeline short-circuits on the
// first failure: validation errors abort before signing (no point
// signing a doc SEFAZ would reject); signing errors abort before
// submitting. SEFAZ rejections come back as a structured Outcome,
// not a Go error — they are an expected business outcome.
func (uc *EmitNFeUseCase) Emit(ctx context.Context, in EmitInput) (*EmitOutcome, error) {
	if uc.cert == nil || uc.client == nil || uc.repo == nil {
		return nil, ErrUseCaseNotConfigured
	}
	if in.NFe == nil || in.NFe.InfNFe == nil {
		return nil, errors.New("nfe.Emit: TNFe.InfNFe is required")
	}

	if issues := nfe.ValidateSemantic(in.NFe); len(issues) > 0 {
		return nil, &ErrValidation{Issues: issues}
	}
	if issues := nfe.ValidateTotalsAgainstItems(in.NFe); len(issues) > 0 {
		return nil, &ErrValidation{Issues: issues}
	}

	xmlBytes, err := marshalNFe(in.NFe)
	if err != nil {
		return nil, fmt.Errorf("nfe.Emit: marshal: %w", err)
	}

	signed, err := nfe.Sign(xmlBytes, uc.cert)
	if err != nil {
		return nil, fmt.Errorf("nfe.Emit: sign: %w", err)
	}

	res, err := uc.client.Authorize(ctx, signed)
	if err != nil {
		return nil, fmt.Errorf("nfe.Emit: authorize: %w", err)
	}

	// Post-validation the IdAttr is guaranteed to be "NFe" + 44 digits;
	// any deviation is a Builder bug, not a runtime case to handle.
	chave := nfe.Chave(strings.TrimPrefix(in.NFe.InfNFe.IdAttr, "NFe"))

	record := &nfe.NFeRecord{
		Chave:     chave,
		Status:    lifecycleStatusFor(res.Status),
		SignedXML: signed,
		Protocol:  res.Protocol,
		Rejection: res.Rejection,
		CStat:     res.CStat,
		XMotivo:   res.XMotivo,
	}
	if err := uc.repo.Save(ctx, record); err != nil {
		return nil, fmt.Errorf("nfe.Emit: persist: %w", err)
	}

	return &EmitOutcome{
		Status:    res.Status,
		Chave:     chave,
		SignedXML: signed,
		Protocol:  res.Protocol,
		Rejection: res.Rejection,
		CStat:     res.CStat,
		XMotivo:   res.XMotivo,
	}, nil
}

// lifecycleStatusFor maps the wire-level AuthorizationStatus to the
// persisted NFeStatus. AUTHORIZED and DUPLICATE collapse to the same
// stored state because the protocol is identical in either case;
// SERVICE_UNAVAILABLE becomes PENDING so a future re-submitter can
// query for "not yet authorized" docs without parsing CStat.
func lifecycleStatusFor(s nfe.AuthorizationStatus) nfe.NFeStatus {
	switch s {
	case nfe.AuthorizationStatusAuthorized, nfe.AuthorizationStatusDuplicate:
		return nfe.NFeStatusAuthorized
	case nfe.AuthorizationStatusRejected:
		return nfe.NFeStatusRejected
	case nfe.AuthorizationStatusServiceUnavailable:
		return nfe.NFeStatusPending
	default:
		return nfe.NFeStatusPending
	}
}

// nfeNamespace is the SEFAZ NF-e XML namespace the leiaute v4.00
// requires on the <NFe> root. Without it, xmllint validation against
// nfe_v4.00.xsd fails ("element NFe is in no namespace; schema target
// is http://www.portalfiscal.inf.br/nfe"). Sprint 1.5 / 1.6 deferred
// this; sprint 1.10 closes the tech debt as part of wiring XSD-validated
// integration tests.
const nfeNamespace = "http://www.portalfiscal.inf.br/nfe"

// marshalNFe serializes a *schema.TNFe under a <NFe xmlns="..."> root.
// The schema-generated TNFe type does not declare XMLName so a plain
// xml.Marshal would emit <TNFe>...</TNFe>; we wrap it explicitly via
// EncodeElement, matching the wire format SEFAZ expects.
//
// Tech debt: xgen-generated structs declare optional leiaute fields
// as plain `string` without `omitempty`, so absent values surface as
// empty `<vDesc></vDesc>` elements that the SEFAZ XSD's pattern
// facets reject. The xs:sequence in the XSD is also strict about
// element ordering, and several of the generated structs declare
// fields in an order that diverges from the XSD sequence (e.g.
// vFCPST before vFCPSTRet). Both gaps require regenerating the
// types with corrected tags and field order. Sprint 1.10 closes the
// namespace half of the XSD compliance work; the pattern + ordering
// half is sprint future.
func marshalNFe(tnfe *schema.TNFe) ([]byte, error) {
	var buf bytes.Buffer
	enc := xml.NewEncoder(&buf)
	start := xml.StartElement{
		Name: xml.Name{Local: "NFe"},
		Attr: []xml.Attr{{Name: xml.Name{Local: "xmlns"}, Value: nfeNamespace}},
	}
	if err := enc.EncodeElement(tnfe, start); err != nil {
		return nil, err
	}
	if err := enc.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
