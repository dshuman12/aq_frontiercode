package application_test

import (
	"context"
	"errors"
	"testing"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

const cceChave = nfe.Chave("43260505730928000145550010000001006123456789")

type cceTestStack struct {
	uc        *application.SendCCeUseCase
	mock      *sefaz.MockClient
	nfeRepo   *infrastructure.InMemoryNFeRepository
	eventRepo *infrastructure.InMemoryNFeEventRepository
}

func newCCeStack(t *testing.T) *cceTestStack {
	t.Helper()
	cert, err := nfe.GenerateSelfSignedTest("sefarius test")
	if err != nil {
		t.Fatalf("generate cert: %v", err)
	}
	mock := sefaz.NewMockClient()
	nfeRepo := infrastructure.NewInMemoryNFeRepository()
	eventRepo := infrastructure.NewInMemoryNFeEventRepository()
	uc := application.NewSendCCeUseCase(cert, mock, nfeRepo, eventRepo)
	return &cceTestStack{uc: uc, mock: mock, nfeRepo: nfeRepo, eventRepo: eventRepo}
}

func (s *cceTestStack) seedAuthorized(t *testing.T, chave nfe.Chave) {
	t.Helper()
	signedXML := []byte(`<NFe><infNFe Id="NFe` + string(chave) + `"><emit><CNPJ>05730928000145</CNPJ></emit></infNFe></NFe>`)
	rec := &nfe.NFeRecord{
		Chave:     chave,
		Status:    nfe.NFeStatusAuthorized,
		SignedXML: signedXML,
		Protocol: &nfe.Protocol{
			NProt: "143260000000099",
			ChNFe: string(chave),
			TpAmb: "2",
		},
	}
	if err := s.nfeRepo.Save(context.Background(), rec); err != nil {
		t.Fatalf("seed authorized: %v", err)
	}
}

func TestSendCCe_AutoAllocateFirstSeq(t *testing.T) {
	s := newCCeStack(t)
	s.seedAuthorized(t, cceChave)

	out, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave:      cceChave,
		Correction: "endereco do destinatario corrigido",
	})
	if err != nil {
		t.Fatalf("Send: %v", err)
	}
	if out.Seq != 1 {
		t.Errorf("first auto-seq = %d, want 1", out.Seq)
	}
	if out.Status != nfe.EventStatusAccepted {
		t.Errorf("Status = %s, want ACCEPTED", out.Status)
	}

	// Second call also auto: seq must be 2.
	out2, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave:      cceChave,
		Correction: "natureza da operacao corrigida",
	})
	if err != nil {
		t.Fatalf("second Send: %v", err)
	}
	if out2.Seq != 2 {
		t.Errorf("second auto-seq = %d, want 2", out2.Seq)
	}
}

func TestSendCCe_ExplicitSeqMustBeNext(t *testing.T) {
	s := newCCeStack(t)
	s.seedAuthorized(t, cceChave)

	// First call — explicit seq=1 (== MaxSeq+1=1) — accepted.
	if _, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave: cceChave, Correction: "primeira correcao explicita", Seq: 1,
	}); err != nil {
		t.Fatalf("seq=1: %v", err)
	}

	// Second call — caller supplies seq=3 (gap; expected 2). Refused.
	_, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave: cceChave, Correction: "tenta pular sequencia diretamente", Seq: 3,
	})
	if !errors.Is(err, nfe.ErrCCeSeqOutOfOrder) {
		t.Errorf("err = %v, want ErrCCeSeqOutOfOrder", err)
	}

	// Caller supplies seq=1 again — duplicate, also refused.
	_, err = s.uc.Send(context.Background(), application.CCeInput{
		Chave: cceChave, Correction: "tenta repetir a primeira sequencia", Seq: 1,
	})
	if !errors.Is(err, nfe.ErrCCeSeqOutOfOrder) {
		t.Errorf("dup err = %v, want ErrCCeSeqOutOfOrder", err)
	}

	// Sanity: only one event row exists.
	list, _ := s.eventRepo.ListByChave(context.Background(), cceChave)
	if len(list) != 1 {
		t.Errorf("expected 1 event row after seq guard, got %d", len(list))
	}
}

func TestSendCCe_RejectsShortCorrection(t *testing.T) {
	s := newCCeStack(t)
	s.seedAuthorized(t, cceChave)

	_, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave:      cceChave,
		Correction: "muito curto", // 11 chars, below CCeCorrectionMin=15
	})
	var ve *application.ErrValidation
	if !errors.As(err, &ve) {
		t.Fatalf("err = %v, want *ErrValidation", err)
	}
	if len(ve.Issues) != 1 || ve.Issues[0].Field != "xCorrecao" {
		t.Errorf("issues: %+v", ve.Issues)
	}
}

func TestSendCCe_RefusesNonAuthorizedRecord(t *testing.T) {
	s := newCCeStack(t)
	rec := &nfe.NFeRecord{
		Chave:     cceChave,
		Status:    nfe.NFeStatusCancelled,
		SignedXML: []byte(`<NFe><infNFe><emit><CNPJ>05730928000145</CNPJ></emit></infNFe></NFe>`),
		Protocol:  &nfe.Protocol{TpAmb: "2"},
	}
	if err := s.nfeRepo.Save(context.Background(), rec); err != nil {
		t.Fatalf("seed cancelled: %v", err)
	}

	_, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave:      cceChave,
		Correction: "tentativa de cce em nfe cancelada",
	})
	if !errors.Is(err, nfe.ErrNFeNotCancellable) {
		t.Errorf("err = %v, want ErrNFeNotCancellable", err)
	}
}

// TestSendCCe_DoesNotMutateNFeStatus is the contract distinction
// between cancel (flips status) and CCe (never flips). Easy to break
// during a refactor — explicit lock-in.
func TestSendCCe_DoesNotMutateNFeStatus(t *testing.T) {
	s := newCCeStack(t)
	s.seedAuthorized(t, cceChave)
	priorStatus := nfe.NFeStatusAuthorized

	if _, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave: cceChave, Correction: "qualquer correcao valida apenas",
	}); err != nil {
		t.Fatalf("Send: %v", err)
	}

	rec, _ := s.nfeRepo.GetByChave(context.Background(), cceChave)
	if rec.Status != priorStatus {
		t.Errorf("Status mutated by CCe: %s -> %s", priorStatus, rec.Status)
	}
}

func TestSendCCe_SefazRejectionPersistsRow(t *testing.T) {
	s := newCCeStack(t)
	s.seedAuthorized(t, cceChave)
	s.mock.RejectEventChavePrefix(string(cceChave[:4]), &nfe.EventRejection{
		CStat: "573", XMotivo: "Duplicidade do evento",
	})

	out, err := s.uc.Send(context.Background(), application.CCeInput{
		Chave:      cceChave,
		Correction: "correcao que sera rejeitada pelo mock",
	})
	if err != nil {
		t.Fatalf("Send: %v", err)
	}
	if out.Status != nfe.EventStatusRejected {
		t.Errorf("Status = %s, want REJECTED", out.Status)
	}
	if out.Rejection == nil || out.Rejection.CStat != "573" {
		t.Errorf("Rejection: %+v", out.Rejection)
	}

	// Event row persisted with REJECTED status — auditable.
	evt, err := s.eventRepo.GetByKey(context.Background(), cceChave, nfe.NFeEventTypeCCe, 1)
	if err != nil {
		t.Fatalf("event row missing: %v", err)
	}
	if evt.Status != nfe.EventStatusRejected || evt.NProt != "" {
		t.Errorf("event row: %+v", evt)
	}
}
