package application

import "time"

// InvoiceDTO represents an Invoice data transfer object
type InvoiceDTO struct {
	ID             string           `json:"id"`
	Number         int64            `json:"number"`
	Status         string           `json:"status"`
	IdempotencyKey string           `json:"idempotency_key"`
	CreatedBy      string           `json:"created_by"`
	Items          []InvoiceItemDTO `json:"items"`
	TotalAmount    float64          `json:"total_amount"`
	CreatedAt      time.Time        `json:"created_at"`
	ClosedAt       *time.Time       `json:"closed_at,omitempty"`
}

// InvoiceItemDTO represents an InvoiceItem DTO
type InvoiceItemDTO struct {
	ID                 string    `json:"id"`
	ProductID          string    `json:"product_id"`
	ProductCode        string    `json:"product_code,omitempty"`
	ProductDescription string    `json:"product_description,omitempty"`
	Quantity           int       `json:"quantity"`
	UnitPrice          float64   `json:"unit_price"`
	Subtotal           float64   `json:"subtotal"`
	CreatedAt          time.Time `json:"created_at"`
}

// CreateInvoiceRequest represents the request to create an invoice
type CreateInvoiceRequest struct {
	CreatedBy      string                     `json:"created_by" validate:"required"`
	Items          []CreateInvoiceItemRequest `json:"items" validate:"required,min=1"`
	IdempotencyKey string                     `json:"idempotency_key" validate:"required"`
}

// CreateInvoiceItemRequest represents an item in create invoice request
type CreateInvoiceItemRequest struct {
	ProductID string  `json:"product_id" validate:"required"`
	Quantity  int     `json:"quantity" validate:"required,min=1"`
	UnitPrice float64 `json:"unit_price" validate:"required,min=0.01"`
}

// UpdateInvoiceStatusRequest represents the request to update invoice status
type UpdateInvoiceStatusRequest struct {
	Status string `json:"status" validate:"required,oneof=OPEN CLOSED CANCELLED"`
}

// CloseInvoiceRequest represents the request to close an invoice
type CloseInvoiceRequest struct {
	IdempotencyKey string `json:"idempotency_key" validate:"required"`
}

// APIResponse represents a standard API response wrapper
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Code    int         `json:"code"`
}

// PaginatedResponse represents a paginated response
type PaginatedResponse struct {
	Items  interface{} `json:"items"`
	Total  int         `json:"total"`
	Limit  int         `json:"limit"`
	Offset int         `json:"offset"`
}
