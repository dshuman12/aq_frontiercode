package application_test

import (
	"bytes"
	"context"
	"errors"
	"testing"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

// strPtr is a tiny helper for the leiaute's optional pointer fields.
func strPtr(s string) *string { return &s }

// baselineNFe assembles a sale-of-merchandise NF-e in the same shape
// the domain-level tests use. Duplicated rather than imported because
// the original lives in nfe_test (internal-only); duplicating keeps
// both call sites honest to the leiaute's required fields.
func baselineNFe(t *testing.T) *schema.TNFe {
	t.Helper()
	cnpj := "05730928000145"
	cMun := "4314902"

	det, err := nfe.NewDetRegimeNormalCST00(
		&schema.Prod{
			CProd:    "001",
			CEAN:     "SEM GTIN",
			XProd:    "PRODUTO TESTE",
			NCM:      "22021000",
			CFOP:     "5102",
			UCom:     "UN",
			QCom:     "1.0000",
			VUnCom:   "100.0000000000",
			VProd:    "100.00",
			CEANTrib: "SEM GTIN",
			UTrib:    "UN",
			QTrib:    "1.0000",
			VUnTrib:  "100.0000000000",
			IndTot:   "1",
		},
		"100.00", "18.00", "1.65", "7.60",
	)
	if err != nil {
		t.Fatalf("NewDetRegimeNormalCST00: %v", err)
	}

	tnfe, err := nfe.New().
		Ide(&schema.Ide{
			CUF: "43", CNF: "12345678", NatOp: "VENDA DE MERCADORIA",
			Mod: string(nfe.ModeloNFe), Serie: "1", NNF: "100",
			DhEmi: "2026-05-06T10:00:00-03:00", TpNF: "1",
			IdDest: string(nfe.IdDestInterna), CMunFG: cMun,
			TpImp: "1", TpEmis: string(nfe.TpEmisNormal),
			TpAmb: string(nfe.TpAmbHomologacao),
			FinNFe: string(nfe.FinNFeNormal), IndFinal: "1",
			IndPres: string(nfe.IndPresPresencial),
			ProcEmi: string(nfe.ProcEmiContribuinte), VerProc: "sefarius 0.1",
		}).
		Emit(&schema.Emit{
			CNPJ: &cnpj, XNome: "EMPRESA TESTE LTDA",
			EnderEmit: &schema.TEnderEmi{
				XLgr: "AV TESTE", Nro: "100", XBairro: "CENTRO",
				CMun: cMun, XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000000",
			},
			IE: "1234567890", CRT: "3",
		}).
		Dest(&schema.Dest{
			CNPJ: strPtr("11444777000161"),
			XNome: strPtr("CLIENTE TESTE LTDA"),
			EnderDest: &schema.TEndereco{
				XLgr: "RUA EXEMPLO", Nro: "200", XBairro: "BAIRRO",
				CMun: cMun, XMun: "PORTO ALEGRE", UF: "RS", CEP: strPtr("90000001"),
			},
			IndIEDest: string(nfe.IndIEDestContribuinte),
			IE:        strPtr("9876543210"),
		}).
		AddDet(det).
		Total(&schema.Total{
			ICMSTot: &schema.ICMSTot{
				VBC: "100.00", VICMS: "18.00", VICMSDeson: "0.00",
				VFCP: "0.00", VBCST: "0.00", VST: "0.00",
				VFCPST: "0.00", VFCPSTRet: "0.00",
				VProd:    "100.00",
				VPIS:     "1.65",
				VCOFINS:  "7.60",
			},
		}).
		Transp(&schema.Transp{ModFrete: "9"}).
		Pag(&schema.Pag{DetPag: []*schema.DetPag{{TPag: "01", VPag: "118.00"}}}).
		Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	return tnfe
}

func newUseCase(t *testing.T, mock *sefaz.MockClient) (*application.EmitNFeUseCase, *infrastructure.InMemoryNFeRepository) {
	t.Helper()
	cert, err := nfe.GenerateSelfSignedTest("emit-test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	repo := infrastructure.NewInMemoryNFeRepository()
	return application.NewEmitNFeUseCase(cert, mock, repo), repo
}

// TestEmit_HappyPath is the headline contract: the use case takes a
// validated NF-e through validation+sign+authorize and reports
// AUTHORIZED with the protocol that the SefazClient returned.
func TestEmit_HappyPath(t *testing.T) {
	mock := sefaz.NewMockClient()
	uc, _ := newUseCase(t, mock)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("Emit: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusAuthorized {
		t.Errorf("Status = %s, want AUTHORIZED", out.Status)
	}
	if out.Protocol == nil {
		t.Fatal("Protocol is nil on AUTHORIZED outcome")
	}
	if len(out.Chave) != 44 {
		t.Errorf("Chave = %q (len %d), want 44 digits", out.Chave, len(out.Chave))
	}
	if out.Protocol.ChNFe != string(out.Chave) {
		t.Errorf("Protocol.ChNFe %s != Outcome.Chave %s", out.Protocol.ChNFe, out.Chave)
	}
	if !bytes.Contains(out.SignedXML, []byte("<ds:Signature")) {
		t.Error("SignedXML missing Signature block")
	}
	if mock.CallCount() != 1 {
		t.Errorf("SefazClient.Authorize called %d times, want 1", mock.CallCount())
	}
}

// TestEmit_ShortCircuitsOnValidationFailure proves the pipeline
// refuses to sign a document SEFAZ would reject. SefazClient must NOT
// be called when ValidateSemantic flags an issue — saves a round trip
// and prevents the mock-vs-real divergence where mocks happily
// authorize garbage but real SEFAZ returns rejection 215+.
func TestEmit_ShortCircuitsOnValidationFailure(t *testing.T) {
	mock := sefaz.NewMockClient()
	uc, _ := newUseCase(t, mock)

	tnfe := baselineNFe(t)
	tnfe.InfNFe.Emit.CRT = "9" // semantic violation: invalid CRT

	_, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
	if err == nil {
		t.Fatal("Emit returned nil error for invalid NF-e")
	}
	var ve *application.ErrValidation
	if !errors.As(err, &ve) {
		t.Fatalf("err type = %T, want *application.ErrValidation", err)
	}
	if len(ve.Issues) == 0 {
		t.Error("ErrValidation.Issues is empty")
	}
	if mock.CallCount() != 0 {
		t.Errorf("SefazClient.Authorize called %d times on validation failure, want 0", mock.CallCount())
	}
}

// TestEmit_RejectionFromSefaz is a structural test: a SEFAZ rejection
// is a *business outcome*, not a Go error. The use case must surface
// it as Outcome.Status=REJECTED with the diagnostic populated, leaving
// the caller free to decide whether to retry, contest, or notify.
func TestEmit_RejectionFromSefaz(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.QueueOutcome(&nfe.AuthorizationResult{
		Status:  nfe.AuthorizationStatusRejected,
		CStat:   "228",
		XMotivo: "Rejeicao: Data de Emissao muito atrasada",
		Rejection: &nfe.Rejection{
			CStat:   "228",
			XMotivo: "Rejeicao: Data de Emissao muito atrasada",
		},
	})
	uc, _ := newUseCase(t, mock)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("Emit returned error %v on SEFAZ rejection (want structured outcome)", err)
	}
	if out.Status != nfe.AuthorizationStatusRejected {
		t.Errorf("Status = %s, want REJECTED", out.Status)
	}
	if out.Rejection == nil || out.Rejection.CStat != "228" {
		t.Errorf("Rejection = %+v, want CStat 228", out.Rejection)
	}
	if len(out.SignedXML) == 0 {
		t.Error("SignedXML empty on rejection — diagnostic file is needed for contestation")
	}
}

// TestEmit_SefazUnreachableSurfacedAsError distinguishes transport
// failures (errors) from fiscal rejections (outcomes). Caller code
// branches on errors.Is to know whether retry is reasonable.
func TestEmit_SefazUnreachableSurfacedAsError(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.FailWithError(nfe.ErrSefazUnreachable)
	uc, _ := newUseCase(t, mock)

	_, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if !errors.Is(err, nfe.ErrSefazUnreachable) {
		t.Errorf("err = %v, want ErrSefazUnreachable", err)
	}
}

// TestEmit_DuplicateResubmissionEchoesPriorProtocol locks in the
// idempotent-recovery semantics. If the caller resubmits the same
// NF-e (e.g. after a crash between authorize and persistence), the
// outcome must surface the original protocol, not a brand-new one.
func TestEmit_DuplicateResubmissionEchoesPriorProtocol(t *testing.T) {
	mock := sefaz.NewMockClient()
	uc, _ := newUseCase(t, mock)

	first, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("first Emit: %v", err)
	}
	second, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("second Emit: %v", err)
	}
	if second.Status != nfe.AuthorizationStatusDuplicate {
		t.Errorf("second Status = %s, want DUPLICATE", second.Status)
	}
	if second.Protocol == nil || second.Protocol.NProt != first.Protocol.NProt {
		t.Errorf("duplicate Protocol.NProt = %v, want %s", second.Protocol, first.Protocol.NProt)
	}
}

func TestEmit_RejectsNilNFe(t *testing.T) {
	uc, _ := newUseCase(t, sefaz.NewMockClient())
	_, err := uc.Emit(context.Background(), application.EmitInput{})
	if err == nil {
		t.Fatal("Emit accepted nil NFe input")
	}
}

func TestEmit_RejectsMissingCertificate(t *testing.T) {
	uc := application.NewEmitNFeUseCase(nil, sefaz.NewMockClient(), infrastructure.NewInMemoryNFeRepository())
	_, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if !errors.Is(err, application.ErrUseCaseNotConfigured) {
		t.Errorf("err = %v, want ErrUseCaseNotConfigured", err)
	}
}

func TestEmit_RejectsMissingClient(t *testing.T) {
	cert, err := nfe.GenerateSelfSignedTest("client-nil")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	uc := application.NewEmitNFeUseCase(cert, nil, infrastructure.NewInMemoryNFeRepository())
	_, err = uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if !errors.Is(err, application.ErrUseCaseNotConfigured) {
		t.Errorf("err = %v, want ErrUseCaseNotConfigured", err)
	}
}

func TestEmit_RejectsMissingRepo(t *testing.T) {
	cert, err := nfe.GenerateSelfSignedTest("repo-nil")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	uc := application.NewEmitNFeUseCase(cert, sefaz.NewMockClient(), nil)
	_, err = uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if !errors.Is(err, application.ErrUseCaseNotConfigured) {
		t.Errorf("err = %v, want ErrUseCaseNotConfigured", err)
	}
}

// TestEmit_PersistsAuthorizedRecord locks in the sprint 1.8 contract:
// every Emit that reaches Authorize must leave a queryable record in
// the repository. Without this, downstream HTTP handlers and DANFE
// printing have to round-trip via SEFAZ to recover state — exactly
// the failure mode we used to have.
func TestEmit_PersistsAuthorizedRecord(t *testing.T) {
	mock := sefaz.NewMockClient()
	uc, repo := newUseCase(t, mock)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("Emit: %v", err)
	}

	rec, err := repo.GetByChave(context.Background(), out.Chave)
	if err != nil {
		t.Fatalf("GetByChave: %v", err)
	}
	if rec.Status != nfe.NFeStatusAuthorized {
		t.Errorf("persisted Status = %s, want AUTHORIZED", rec.Status)
	}
	if rec.Protocol == nil || rec.Protocol.NProt != out.Protocol.NProt {
		t.Errorf("persisted Protocol mismatches outcome")
	}
	if !bytes.Equal(rec.SignedXML, out.SignedXML) {
		t.Error("persisted SignedXML differs from outcome SignedXML")
	}
	if rec.CreatedAt.IsZero() || rec.UpdatedAt.IsZero() {
		t.Error("repo did not stamp CreatedAt / UpdatedAt")
	}
}

// TestEmit_PersistsRejectedRecord — fiscal rejections also produce a
// stored record, with status REJECTED and the rejection diagnostics.
// Operators need this for contestation flows.
func TestEmit_PersistsRejectedRecord(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.QueueOutcome(&nfe.AuthorizationResult{
		Status:    nfe.AuthorizationStatusRejected,
		CStat:     "228",
		XMotivo:   "Rejeicao: Data de Emissao muito atrasada",
		Rejection: &nfe.Rejection{CStat: "228", XMotivo: "Rejeicao: Data de Emissao muito atrasada"},
	})
	uc, repo := newUseCase(t, mock)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})
	if err != nil {
		t.Fatalf("Emit: %v", err)
	}

	rec, err := repo.GetByChave(context.Background(), out.Chave)
	if err != nil {
		t.Fatalf("GetByChave: %v", err)
	}
	if rec.Status != nfe.NFeStatusRejected {
		t.Errorf("persisted Status = %s, want REJECTED", rec.Status)
	}
	if rec.Rejection == nil || rec.Rejection.CStat != "228" {
		t.Errorf("persisted Rejection = %+v, want CStat 228", rec.Rejection)
	}
}

// TestEmit_DoesNotPersistOnTransportFailure proves the symmetry: when
// Authorize never returns a fiscal outcome, nothing reaches the repo.
// Otherwise we'd accumulate ghost rows for every transient SEFAZ
// outage.
func TestEmit_DoesNotPersistOnTransportFailure(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.FailWithError(nfe.ErrSefazUnreachable)
	uc, repo := newUseCase(t, mock)

	_, _ = uc.Emit(context.Background(), application.EmitInput{NFe: baselineNFe(t)})

	all, err := repo.List(context.Background(), 0, 0)
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if len(all) != 0 {
		t.Errorf("repo has %d records after transport failure, want 0", len(all))
	}
}
