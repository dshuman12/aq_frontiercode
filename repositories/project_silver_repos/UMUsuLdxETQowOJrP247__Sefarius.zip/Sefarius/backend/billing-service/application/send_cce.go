package application

import (
	"context"
	"errors"
	"fmt"

	"github.com/sefarius/billing-service/domain/nfe"
)

// SendCCeUseCase orchestrates the Carta de Correção pipeline:
//
//	validate input → load NFeRecord → enforce AUTHORIZED state →
//	resolve nSeqEvento (auto-increment from MAX+1, or validate
//	caller-supplied) → build cce.TEvento → marshal → sign → submit →
//	persist event row.
//
// Unlike Cancel, SendCCe does NOT mutate NFeRecord.Status — a CCe
// corrects non-fiscal fields and the NFe stays AUTHORIZED. The CCe
// row in nfe_events is the only persisted side-effect.
//
// Sequence allocation: when in.Seq is 0 the use case computes
// MaxSeqByChaveType+1 from the event repo and uses that. When in.Seq
// is non-zero the use case validates that it is exactly MaxSeq+1 —
// any other value (gap or duplicate) is ErrCCeSeqOutOfOrder. This
// auto/explicit hybrid lets HTTP callers either delegate sequence
// allocation or pass a value for idempotent retry.
type SendCCeUseCase struct {
	cert      *nfe.Certificate
	client    nfe.SefazClient
	nfeRepo   nfe.NFeRepository
	eventRepo nfe.NFeEventRepository
}

// NewSendCCeUseCase wires the dependencies. All four must be non-nil.
func NewSendCCeUseCase(cert *nfe.Certificate, client nfe.SefazClient, nfeRepo nfe.NFeRepository, eventRepo nfe.NFeEventRepository) *SendCCeUseCase {
	return &SendCCeUseCase{cert: cert, client: client, nfeRepo: nfeRepo, eventRepo: eventRepo}
}

// CCeInput captures the variable inputs. Seq=0 means auto-increment.
type CCeInput struct {
	Chave      nfe.Chave
	Correction string
	Seq        int // 0 = auto-increment from MaxSeqByChaveType+1
}

// CCeOutcome reports the result. Seq is the resolved nSeqEvento (the
// value SEFAZ saw, regardless of whether it was caller-supplied or
// auto-allocated) so the HTTP caller can echo it back to the client.
type CCeOutcome struct {
	Chave       nfe.Chave
	Seq         int
	Status      nfe.EventStatus
	NProt       string
	CStat       string
	XMotivo     string
	Protocol    *nfe.EventProtocol
	Rejection   *nfe.EventRejection
	SignedXML   []byte
	ResponseXML []byte
}

// Send runs the pipeline.
func (uc *SendCCeUseCase) Send(ctx context.Context, in CCeInput) (*CCeOutcome, error) {
	if uc.cert == nil || uc.client == nil || uc.nfeRepo == nil || uc.eventRepo == nil {
		return nil, errors.New("nfe.SendCCe: use case not configured")
	}

	if issue := nfe.ValidateCCeCorrection(in.Correction); issue != nil {
		return nil, &ErrValidation{Issues: []nfe.ValidationIssue{*issue}}
	}

	rec, err := uc.nfeRepo.GetByChave(ctx, in.Chave)
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: load nfe: %w", err)
	}
	if rec.Status != nfe.NFeStatusAuthorized {
		return nil, nfe.ErrNFeNotCancellable
	}
	if rec.Protocol == nil {
		return nil, errors.New("nfe.SendCCe: AUTHORIZED record has no protocol")
	}

	// Resolve nSeqEvento. The lookup runs against the event repo and
	// is not transactional with Save further down — under high
	// concurrency two callers could both compute the same MaxSeq+1
	// and one would get a SEFAZ rejection (cStat 573). Sprint 2.1
	// accepts that race; a serializable transaction or advisory lock
	// is listed under "Out of scope" alongside the outbox pattern.
	maxSeq, err := uc.eventRepo.MaxSeqByChaveType(ctx, in.Chave, nfe.NFeEventTypeCCe)
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: max seq lookup: %w", err)
	}
	nextSeq := maxSeq + 1
	resolvedSeq := nextSeq
	if in.Seq != 0 {
		if in.Seq != nextSeq {
			return nil, nfe.ErrCCeSeqOutOfOrder
		}
		resolvedSeq = in.Seq
	}

	cnpj, cpf := emitterDocsFromRecord(rec)
	evt, err := nfe.BuildCCeEvent(nfe.CCeEventInput{
		Chave:       in.Chave,
		EmitterCNPJ: cnpj,
		EmitterCPF:  cpf,
		TpAmb:       rec.Protocol.TpAmb,
		NSeqEvento:  resolvedSeq,
		Correction:  in.Correction,
	})
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: build event: %w", err)
	}

	xmlBytes, err := marshalEvent(evt, "evento")
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: marshal: %w", err)
	}
	signed, err := nfe.SignEvent(xmlBytes, uc.cert)
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: sign: %w", err)
	}

	res, err := uc.client.SendCCe(ctx, signed)
	if err != nil {
		return nil, fmt.Errorf("nfe.SendCCe: submit: %w", err)
	}

	if res.Status != nfe.EventStatusServiceUnavailable {
		nProt := ""
		if res.Protocol != nil {
			nProt = res.Protocol.NProt
		}
		eventRec := &nfe.NFeEventRecord{
			Chave:       in.Chave,
			EventType:   nfe.NFeEventTypeCCe,
			NSeq:        resolvedSeq,
			NProt:       nProt,
			Status:      res.Status,
			CStat:       res.CStat,
			XMotivo:     res.XMotivo,
			SignedXML:   signed,
			ResponseXML: res.ResponseXML,
		}
		if err := uc.eventRepo.Save(ctx, eventRec); err != nil {
			return nil, fmt.Errorf("nfe.SendCCe: persist event: %w", err)
		}
	}

	out := &CCeOutcome{
		Chave:       in.Chave,
		Seq:         resolvedSeq,
		Status:      res.Status,
		CStat:       res.CStat,
		XMotivo:     res.XMotivo,
		Protocol:    res.Protocol,
		Rejection:   res.Rejection,
		SignedXML:   signed,
		ResponseXML: res.ResponseXML,
	}
	if res.Protocol != nil {
		out.NProt = res.Protocol.NProt
	}
	return out, nil
}
