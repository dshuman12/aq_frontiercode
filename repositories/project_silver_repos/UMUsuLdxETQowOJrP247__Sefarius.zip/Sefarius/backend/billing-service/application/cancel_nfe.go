package application

import (
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"fmt"

	"github.com/sefarius/billing-service/domain/nfe"
)

// CancelNFeUseCase orchestrates the cancel pipeline:
//
//	validate input → load NFeRecord → enforce AUTHORIZED state →
//	build canc.TEvento → marshal → sign (SignEvent) → submit (SefazClient.Cancel)
//	→ persist event row → flip NFeRecord.Status to CANCELLED on ACCEPTED.
//
// The status flip and the event persist happen in two separate Save
// calls (different repos). A crash between them leaves an ACCEPTED
// event row but a stale AUTHORIZED status — recoverable on next read
// by deriving status from event presence, but for sprint 2.1 the ~ms
// inconsistency window is accepted. An outbox-pattern atomic flip is
// listed under "Out of scope" in the sprint plan.
type CancelNFeUseCase struct {
	cert      *nfe.Certificate
	client    nfe.SefazClient
	nfeRepo   nfe.NFeRepository
	eventRepo nfe.NFeEventRepository
}

// NewCancelNFeUseCase wires the dependencies. All four must be non-nil.
func NewCancelNFeUseCase(cert *nfe.Certificate, client nfe.SefazClient, nfeRepo nfe.NFeRepository, eventRepo nfe.NFeEventRepository) *CancelNFeUseCase {
	return &CancelNFeUseCase{cert: cert, client: client, nfeRepo: nfeRepo, eventRepo: eventRepo}
}

// CancelInput is the minimal envelope. Justification length is
// validated against CancelJustificationMin/Max before any I/O.
type CancelInput struct {
	Chave         nfe.Chave
	Justification string
}

// CancelOutcome reports the result. Status mirrors EventResult.Status
// (ACCEPTED / REJECTED / SERVICE_UNAVAILABLE). On ACCEPTED, NFe
// lifecycle has been flipped to CANCELLED in the same transaction
// flow as Save (eventually consistent — see use-case godoc).
type CancelOutcome struct {
	Chave       nfe.Chave
	Status      nfe.EventStatus
	NProt       string
	CStat       string
	XMotivo     string
	Protocol    *nfe.EventProtocol
	Rejection   *nfe.EventRejection
	SignedXML   []byte
	ResponseXML []byte
}

// Cancel runs the pipeline. Validation errors return *ErrValidation
// (mapped to HTTP 422 by the handler). Domain refusals return typed
// errors (ErrNFeNotCancellable for non-AUTHORIZED state, ErrNFeNotFound
// for missing chave). SEFAZ rejections come back as a structured
// Outcome with Status=REJECTED, not a Go error — the handler surfaces
// these as HTTP 200 with the rejection payload.
func (uc *CancelNFeUseCase) Cancel(ctx context.Context, in CancelInput) (*CancelOutcome, error) {
	if uc.cert == nil || uc.client == nil || uc.nfeRepo == nil || uc.eventRepo == nil {
		return nil, errors.New("nfe.Cancel: use case not configured")
	}

	// Validation phase — collect all issues before failing fast.
	if issue := nfe.ValidateCancelJustification(in.Justification); issue != nil {
		return nil, &ErrValidation{Issues: []nfe.ValidationIssue{*issue}}
	}

	// Load the NFe — must exist and must be AUTHORIZED.
	rec, err := uc.nfeRepo.GetByChave(ctx, in.Chave)
	if err != nil {
		return nil, fmt.Errorf("nfe.Cancel: load nfe: %w", err)
	}
	if rec.Status != nfe.NFeStatusAuthorized {
		return nil, nfe.ErrNFeNotCancellable
	}
	if rec.Protocol == nil {
		// AUTHORIZED without a Protocol means a previous emit ran in
		// a corrupted state. Distinct error so the caller can
		// distinguish data-integrity issues from cancellable refusals.
		return nil, errors.New("nfe.Cancel: AUTHORIZED record has no protocol")
	}

	// Build → marshal → sign.
	cnpj, cpf := emitterDocsFromRecord(rec)
	evt, err := nfe.BuildCancelEvent(nfe.CancelEventInput{
		Chave:         in.Chave,
		EmitterCNPJ:   cnpj,
		EmitterCPF:    cpf,
		TpAmb:         rec.Protocol.TpAmb,
		NProtAuth:     rec.Protocol.NProt,
		Justification: in.Justification,
	})
	if err != nil {
		return nil, fmt.Errorf("nfe.Cancel: build event: %w", err)
	}

	xmlBytes, err := marshalEvent(evt, "evento")
	if err != nil {
		return nil, fmt.Errorf("nfe.Cancel: marshal: %w", err)
	}
	signed, err := nfe.SignEvent(xmlBytes, uc.cert)
	if err != nil {
		return nil, fmt.Errorf("nfe.Cancel: sign: %w", err)
	}

	// Submit.
	res, err := uc.client.Cancel(ctx, signed)
	if err != nil {
		return nil, fmt.Errorf("nfe.Cancel: submit: %w", err)
	}

	// Persist event row — both ACCEPTED and REJECTED produce a row so
	// the caller can audit the rejection. SERVICE_UNAVAILABLE produces
	// no row (we never reached SEFAZ); the caller retries.
	if res.Status != nfe.EventStatusServiceUnavailable {
		eventStatus := res.Status
		nProt := ""
		cStat := res.CStat
		xMotivo := res.XMotivo
		if res.Protocol != nil {
			nProt = res.Protocol.NProt
		}
		eventRec := &nfe.NFeEventRecord{
			Chave:       in.Chave,
			EventType:   nfe.NFeEventTypeCancel,
			NSeq:        1, // cancel is single-shot
			NProt:       nProt,
			Status:      eventStatus,
			CStat:       cStat,
			XMotivo:     xMotivo,
			SignedXML:   signed,
			ResponseXML: res.ResponseXML,
		}
		if err := uc.eventRepo.Save(ctx, eventRec); err != nil {
			return nil, fmt.Errorf("nfe.Cancel: persist event: %w", err)
		}
	}

	// Flip NFe status on ACCEPTED. Reuses the existing nfeRepo Save
	// upsert — preserves CreatedAt, advances UpdatedAt.
	if res.Status == nfe.EventStatusAccepted {
		rec.Status = nfe.NFeStatusCancelled
		rec.CStat = res.CStat
		rec.XMotivo = res.XMotivo
		if err := uc.nfeRepo.Save(ctx, rec); err != nil {
			return nil, fmt.Errorf("nfe.Cancel: flip nfe status: %w", err)
		}
	}

	out := &CancelOutcome{
		Chave:       in.Chave,
		Status:      res.Status,
		CStat:       res.CStat,
		XMotivo:     res.XMotivo,
		Protocol:    res.Protocol,
		Rejection:   res.Rejection,
		SignedXML:   signed,
		ResponseXML: res.ResponseXML,
	}
	if res.Protocol != nil {
		out.NProt = res.Protocol.NProt
	}
	return out, nil
}

// marshalEvent emits the typed event under the given root element
// name with the SEFAZ namespace declared inline. The xgen-generated
// TEvento for cancel and CCe does not carry XMLName, so xml.Marshal
// would use the Go type name; we wrap explicitly via EncodeElement
// to control the local element name.
//
// Note: encoding/xml's Encoder does not prepend <?xml ?> — the
// returned bytes are a fragment ready to be concatenated into a
// procEventoNFe envelope.
func marshalEvent(event any, rootName string) ([]byte, error) {
	var buf bytes.Buffer
	enc := xml.NewEncoder(&buf)
	start := xml.StartElement{
		Name: xml.Name{Local: rootName},
		Attr: []xml.Attr{{Name: xml.Name{Local: "xmlns"}, Value: nfeNamespace}},
	}
	if err := enc.EncodeElement(event, start); err != nil {
		return nil, err
	}
	if err := enc.Flush(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// emitterDocsFromRecord pulls the emitter CNPJ/CPF out of the stored
// signed XML of the NF-e being cancelled. SEFAZ requires the event to
// echo the emitter document — this is what binds a cancel to "the
// emitter cancelling their own NFe" rather than "anyone with the
// chave cancelling someone else's NFe".
//
// Implementation: walk the XML stream with encoding/xml.Decoder and
// stop at the first <CNPJ> or <CPF> *inside* an <emit> ancestor.
// Robust to whitespace between tags, namespace prefixes, and a
// future pretty-printed marshal — earlier sprint 2.1 used a literal
// substring scan that worked only for the current marshalNFe shape.
func emitterDocsFromRecord(rec *nfe.NFeRecord) (cnpj, cpf string) {
	dec := xml.NewDecoder(bytes.NewReader(rec.SignedXML))
	insideEmit := false
	for {
		tok, err := dec.Token()
		if err != nil {
			return "", ""
		}
		switch t := tok.(type) {
		case xml.StartElement:
			switch t.Name.Local {
			case "emit":
				insideEmit = true
			case "CNPJ":
				if insideEmit {
					var v string
					if err := dec.DecodeElement(&v, &t); err == nil && v != "" {
						return v, ""
					}
				}
			case "CPF":
				if insideEmit {
					var v string
					if err := dec.DecodeElement(&v, &t); err == nil && v != "" {
						return "", v
					}
				}
			}
		case xml.EndElement:
			if t.Name.Local == "emit" {
				// Past the <emit> block without finding either tag —
				// the SignedXML is malformed for our purposes.
				return "", ""
			}
		}
	}
}
