package application

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/sefarius/billing-service/domain"
)

// InvoiceService concretiza o caso de uso InvoiceUseCase.
// Age como orquestrador isolado das lógicas de emissão, garantindo transações e Sagas.
type InvoiceService struct {
	invoiceRepo  domain.InvoiceRepository
	idempotency  domain.IdempotencyRepository
	stockService domain.StockServiceClient
}

// NewInvoiceService injeta as dependências de acesso a dados (repositórios)
// bem como o client gRPC/HTTP do serviço de estoque adjacente.
func NewInvoiceService(
	invoiceRepo domain.InvoiceRepository,
	idempotency domain.IdempotencyRepository,
	stockService domain.StockServiceClient,
) *InvoiceService {
	return &InvoiceService{
		invoiceRepo:  invoiceRepo,
		idempotency:  idempotency,
		stockService: stockService,
	}
}

// CreateInvoice creates a new invoice with idempotency
func (s *InvoiceService) CreateInvoice(ctx context.Context, input *domain.CreateInvoiceInput) (*domain.Invoice, error) {
	if input == nil {
		return nil, domain.ErrInputNil
	}

	if input.IdempotencyKey == "" {
		return nil, domain.ErrIdempotencyKeyRequired
	}

	// Check idempotency - if already processed, return cached response
	if cachedResp, found, err := s.idempotency.Check(ctx, input.IdempotencyKey); found {
		log.Printf("[IDEMPOTENCY] Returning cached response for key: %s", input.IdempotencyKey)
		return cachedResp.(*domain.Invoice), nil
	} else if err != nil {
		log.Printf("Error checking idempotency: %v", err)
		// Continue with creation if idempotency check fails
	}

	// Validate input
	if len(input.Items) == 0 {
		return nil, domain.ErrNoItems
	}

	if input.CreatedBy == "" {
		return nil, domain.ErrCreatedByRequired
	}

	// Create invoice
	invoice := &domain.Invoice{
		ID:             uuid.New().String(),
		Status:         domain.StatusOpen,
		IdempotencyKey: input.IdempotencyKey,
		CreatedBy:      input.CreatedBy,
		Items:          make([]*domain.InvoiceItem, 0),
		CreatedAt:      time.Now(),
	}

	// Reserve (lock+check) and then decrement persisted balance for
	// each item. Reserve alone is a no-op against the balance — bug
	// report #6 (2026-05-07) caught the dashboard showing pre-sale
	// totals after every sale because nothing in this path was
	// calling DecrementStock. We do reserve + decrement in two calls
	// (rather than collapsing to just decrement) because reserve also
	// validates "sufficient balance" and returns a structured error
	// our callers already understand; collapsing would change error
	// shape on the unhappy path.
	for _, itemInput := range input.Items {
		success, err := s.stockService.ReserveStock(ctx, itemInput.ProductID, itemInput.Quantity)
		if err != nil || !success {
			return nil, fmt.Errorf("failed to reserve stock for product %s: %v", itemInput.ProductID, err)
		}
		if err := s.stockService.DecrementStock(ctx, itemInput.ProductID, itemInput.Quantity); err != nil {
			return nil, fmt.Errorf("failed to decrement stock for product %s: %w", itemInput.ProductID, err)
		}

		item := &domain.InvoiceItem{
			ID:        uuid.New().String(),
			InvoiceID: invoice.ID,
			ProductID: itemInput.ProductID,
			Quantity:  itemInput.Quantity,
			UnitPrice: itemInput.UnitPrice,
			CreatedAt: time.Now(),
		}
		invoice.Items = append(invoice.Items, item)
	}

	// Persist invoice
	if err := s.invoiceRepo.Create(ctx, invoice); err != nil {
		log.Printf("Error creating invoice: %v", err)
		// Release reserved stock on error
		for _, item := range invoice.Items {
			_ = s.stockService.ReleaseStock(ctx, item.ProductID, item.Quantity)
		}
		return nil, fmt.Errorf("failed to create invoice")
	}

	// Store in idempotency log
	responseCode := 201
	if err := s.idempotency.Store(ctx, input.IdempotencyKey, responseCode, invoice); err != nil {
		log.Printf("Warning: Failed to store idempotency log: %v", err)
		// Don't fail the operation if idempotency log fails
	}

	return invoice, nil
}

// GetInvoice retrieves an invoice by ID
func (s *InvoiceService) GetInvoice(ctx context.Context, id string) (*domain.Invoice, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	invoice, err := s.invoiceRepo.GetByID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("invoice not found: %w", err)
	}

	s.enrichInvoiceItems(ctx, invoice)

	return invoice, nil
}

// CountInvoices returns the total number of non-deleted invoices.
// Pairs with ListInvoices to expose accurate Total in PaginatedResponse.
func (s *InvoiceService) CountInvoices(ctx context.Context) (int, error) {
	n, err := s.invoiceRepo.Count(ctx)
	if err != nil {
		log.Printf("Error counting invoices: %v", err)
		return 0, fmt.Errorf("failed to count invoices: %w", err)
	}
	return n, nil
}

// ListInvoices retrieves all invoices with pagination
func (s *InvoiceService) ListInvoices(ctx context.Context, limit, offset int) ([]*domain.Invoice, error) {
	if limit <= 0 {
		limit = domain.DefaultPageLimit
	}
	if limit > domain.MaxPageLimit {
		limit = domain.MaxPageLimit
	}
	if offset < 0 {
		offset = 0
	}

	invoices, err := s.invoiceRepo.GetAll(ctx, limit, offset)
	if err != nil {
		log.Printf("Error listing invoices: %v", err)
		return nil, fmt.Errorf("failed to list invoices")
	}

	for _, invoice := range invoices {
		s.enrichInvoiceItems(ctx, invoice)
	}

	return invoices, nil
}

// UpdateInvoiceStatus updates the status of an invoice
func (s *InvoiceService) UpdateInvoiceStatus(ctx context.Context, id string, input *domain.UpdateInvoiceStatusInput) (*domain.Invoice, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	invoice, err := s.invoiceRepo.GetByIDForUpdate(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("invoice not found: %w", err)
	}

	invoice.Status = input.Status

	if err := s.invoiceRepo.Update(ctx, invoice); err != nil {
		log.Printf("Error updating invoice status: %v", err)
		return nil, fmt.Errorf("failed to update invoice")
	}

	return invoice, nil
}

// CloseInvoice closes an invoice (used during print)
func (s *InvoiceService) CloseInvoice(ctx context.Context, id string) (*domain.Invoice, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	// Get invoice with lock to prevent concurrent modifications
	invoice, err := s.invoiceRepo.GetByIDForUpdate(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("invoice not found: %w", err)
	}

	// Try to close the invoice
	if err := invoice.Close(); err != nil {
		return nil, err
	}

	// Persist changes
	if err := s.invoiceRepo.Update(ctx, invoice); err != nil {
		log.Printf("Error closing invoice: %v", err)
		return nil, fmt.Errorf("failed to close invoice")
	}

	return invoice, nil
}

// CancelInvoice cancels an invoice
func (s *InvoiceService) CancelInvoice(ctx context.Context, id string) (*domain.Invoice, error) {
	if id == "" {
		return nil, domain.ErrIDRequired
	}

	invoice, err := s.invoiceRepo.GetByIDForUpdate(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("invoice not found: %w", err)
	}

	if invoice.Status != domain.StatusOpen {
		return nil, domain.ErrOnlyOpenCanCancel
	}

	invoice.Status = domain.StatusCancelled

	// Release reserved stock
	for _, item := range invoice.Items {
		_ = s.stockService.ReleaseStock(ctx, item.ProductID, item.Quantity)
	}

	if err := s.invoiceRepo.Update(ctx, invoice); err != nil {
		log.Printf("Error cancelling invoice: %v", err)
		return nil, fmt.Errorf("failed to cancel invoice")
	}

	return invoice, nil
}

// DeleteInvoice deletes an invoice
func (s *InvoiceService) DeleteInvoice(ctx context.Context, id string) error {
	if id == "" {
		return domain.ErrIDRequired
	}

	return s.invoiceRepo.Delete(ctx, id)
}

// CalculateRequestHash calculates SHA256 hash of request body
func CalculateRequestHash(input interface{}) (string, error) {
	jsonBytes, err := json.Marshal(input)
	if err != nil {
		return "", err
	}

	hash := sha256.Sum256(jsonBytes)
	return hex.EncodeToString(hash[:]), nil
}

func (s *InvoiceService) enrichInvoiceItems(ctx context.Context, invoice *domain.Invoice) {
	if invoice == nil || s.stockService == nil || len(invoice.Items) == 0 {
		return
	}

	// Collect unique product IDs to avoid duplicate fetches within the same invoice.
	seen := make(map[string]struct{})
	var uniqueIDs []string
	for _, item := range invoice.Items {
		if item == nil || item.ProductID == "" {
			continue
		}
		if _, ok := seen[item.ProductID]; !ok {
			seen[item.ProductID] = struct{}{}
			uniqueIDs = append(uniqueIDs, item.ProductID)
		}
	}

	if len(uniqueIDs) == 0 {
		return
	}

	// Fetch all unique products concurrently.
	type result struct {
		productID   string
		code        string
		description string
	}
	results := make([]result, len(uniqueIDs))
	var wg sync.WaitGroup

	for i, id := range uniqueIDs {
		wg.Add(1)
		go func(idx int, productID string) {
			defer wg.Done()
			resp, err := s.stockService.GetProduct(ctx, productID)
			if err != nil {
				log.Printf("Warning: failed to fetch product metadata for %s: %v", productID, err)
				return
			}
			code, desc := extractProductMetadata(resp)
			results[idx] = result{productID: productID, code: code, description: desc}
		}(i, id)
	}
	wg.Wait()

	// Build lookup map.
	meta := make(map[string]result, len(results))
	for _, r := range results {
		if r.productID != "" {
			meta[r.productID] = r
		}
	}

	// Apply metadata to items.
	for _, item := range invoice.Items {
		if item == nil {
			continue
		}
		if r, ok := meta[item.ProductID]; ok {
			if r.code != "" {
				item.ProductCode = r.code
			}
			if r.description != "" {
				item.ProductDescription = r.description
			}
		}
	}
}

func extractProductMetadata(productResp interface{}) (string, string) {
	rootMap, ok := productResp.(map[string]interface{})
	if !ok {
		return "", ""
	}

	data, ok := rootMap["data"].(map[string]interface{})
	if !ok {
		return "", ""
	}

	productCode, _ := data["code"].(string)
	productDescription, _ := data["description"].(string)

	return productCode, productDescription
}
