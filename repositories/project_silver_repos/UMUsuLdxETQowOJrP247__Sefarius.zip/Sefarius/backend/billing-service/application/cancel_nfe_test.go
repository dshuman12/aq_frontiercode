package application_test

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

const (
	cancelChave    = nfe.Chave("43260505730928000145550010000001005123456787")
	cancelEmitCNPJ = "05730928000145"
	cancelTpAmb    = "2"
)

// cancelTestStack assembles the dependencies a cancel test needs.
// Returns the use case plus the repos so tests can pre-seed the NFe
// being cancelled and assert on the persisted event row afterward.
type cancelTestStack struct {
	uc        *application.CancelNFeUseCase
	mock      *sefaz.MockClient
	nfeRepo   *infrastructure.InMemoryNFeRepository
	eventRepo *infrastructure.InMemoryNFeEventRepository
	cert      *nfe.Certificate
}

func newCancelStack(t *testing.T) *cancelTestStack {
	t.Helper()
	cert, err := nfe.GenerateSelfSignedTest("sefarius test")
	if err != nil {
		t.Fatalf("generate cert: %v", err)
	}
	mock := sefaz.NewMockClient()
	nfeRepo := infrastructure.NewInMemoryNFeRepository()
	eventRepo := infrastructure.NewInMemoryNFeEventRepository()
	uc := application.NewCancelNFeUseCase(cert, mock, nfeRepo, eventRepo)
	return &cancelTestStack{uc: uc, mock: mock, nfeRepo: nfeRepo, eventRepo: eventRepo, cert: cert}
}

// seedAuthorized pre-populates an AUTHORIZED NFe record. The signed
// XML embeds an <emit><CNPJ>...</CNPJ></emit> block so
// emitterDocsFromRecord finds the issuer document.
func (s *cancelTestStack) seedAuthorized(t *testing.T, chave nfe.Chave) *nfe.NFeRecord {
	t.Helper()
	signedXML := []byte(`<NFe><infNFe Id="NFe` + string(chave) + `"><emit><CNPJ>` + cancelEmitCNPJ + `</CNPJ></emit></infNFe></NFe>`)
	rec := &nfe.NFeRecord{
		Chave:     chave,
		Status:    nfe.NFeStatusAuthorized,
		SignedXML: signedXML,
		Protocol: &nfe.Protocol{
			NProt: "143260000000001",
			ChNFe: string(chave),
			TpAmb: cancelTpAmb,
		},
		CStat:   "100",
		XMotivo: "Autorizado o uso da NF-e",
	}
	if err := s.nfeRepo.Save(context.Background(), rec); err != nil {
		t.Fatalf("seed authorized: %v", err)
	}
	return rec
}

func TestCancelNFe_HappyPath(t *testing.T) {
	s := newCancelStack(t)
	s.seedAuthorized(t, cancelChave)

	out, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "cancelado por solicitacao do cliente",
	})
	if err != nil {
		t.Fatalf("Cancel: %v", err)
	}
	if out.Status != nfe.EventStatusAccepted {
		t.Errorf("Status = %s, want ACCEPTED", out.Status)
	}
	if out.NProt == "" {
		t.Error("NProt should be populated on ACCEPTED")
	}
	if out.Protocol == nil || out.Protocol.NSeqEvento != 1 {
		t.Errorf("Protocol round-trip: %+v", out.Protocol)
	}

	// NFe lifecycle flipped to CANCELLED.
	rec, err := s.nfeRepo.GetByChave(context.Background(), cancelChave)
	if err != nil {
		t.Fatalf("GetByChave after cancel: %v", err)
	}
	if rec.Status != nfe.NFeStatusCancelled {
		t.Errorf("post-cancel Status = %s, want CANCELLED", rec.Status)
	}

	// Event row persisted at seq 1.
	evt, err := s.eventRepo.GetByKey(context.Background(), cancelChave, nfe.NFeEventTypeCancel, 1)
	if err != nil {
		t.Fatalf("GetByKey event: %v", err)
	}
	if evt.Status != nfe.EventStatusAccepted || evt.NProt == "" {
		t.Errorf("event row payload: %+v", evt)
	}
	if !strings.Contains(string(evt.SignedXML), "ID110111") {
		t.Errorf("event SignedXML lacks cancel Id: %s", evt.SignedXML)
	}
}

func TestCancelNFe_RejectsShortJustification(t *testing.T) {
	s := newCancelStack(t)
	s.seedAuthorized(t, cancelChave)

	_, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "curto", // 5 chars, below CancelJustificationMin=15
	})
	var ve *application.ErrValidation
	if !errors.As(err, &ve) {
		t.Fatalf("err = %v, want *ErrValidation", err)
	}
	if len(ve.Issues) != 1 || ve.Issues[0].Field != "xJust" {
		t.Errorf("validation issues: %+v", ve.Issues)
	}

	// No event row should have been written for a pre-submission failure.
	if _, err := s.eventRepo.GetByKey(context.Background(), cancelChave, nfe.NFeEventTypeCancel, 1); !errors.Is(err, nfe.ErrNFeEventNotFound) {
		t.Errorf("event row exists despite validation failure")
	}
}

func TestCancelNFe_RefusesNonAuthorizedRecord(t *testing.T) {
	s := newCancelStack(t)
	// Seed a REJECTED NFe instead of AUTHORIZED.
	rec := &nfe.NFeRecord{
		Chave:     cancelChave,
		Status:    nfe.NFeStatusRejected,
		SignedXML: []byte(`<NFe><infNFe><emit><CNPJ>` + cancelEmitCNPJ + `</CNPJ></emit></infNFe></NFe>`),
		Rejection: &nfe.Rejection{CStat: "228", XMotivo: "rejeicao teste"},
	}
	if err := s.nfeRepo.Save(context.Background(), rec); err != nil {
		t.Fatalf("seed: %v", err)
	}

	_, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "tentativa invalida de cancelamento",
	})
	if !errors.Is(err, nfe.ErrNFeNotCancellable) {
		t.Errorf("err = %v, want ErrNFeNotCancellable", err)
	}
}

func TestCancelNFe_MissingChaveSurfacesNotFound(t *testing.T) {
	s := newCancelStack(t)
	// No seed — chave does not exist.
	_, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "tentativa invalida de cancelamento",
	})
	if !errors.Is(err, nfe.ErrNFeNotFound) {
		t.Errorf("err = %v, want ErrNFeNotFound", err)
	}
}

// TestCancelNFe_SefazRejectionDoesNotFlipStatus exercises the cStat
// 218 ("NFe ja cancelada") path. SEFAZ rejection is an Outcome with
// Status=REJECTED — not a Go error. The use case persists the event
// row but does NOT flip the NFe lifecycle.
func TestCancelNFe_SefazRejectionDoesNotFlipStatus(t *testing.T) {
	s := newCancelStack(t)
	s.seedAuthorized(t, cancelChave)
	s.mock.ForcePrazoExpirado(true)

	out, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "tentativa de cancelamento apos prazo",
	})
	if err != nil {
		t.Fatalf("Cancel: %v", err)
	}
	if out.Status != nfe.EventStatusRejected {
		t.Errorf("Status = %s, want REJECTED", out.Status)
	}
	if out.Rejection == nil || out.Rejection.CStat != "218" {
		t.Errorf("Rejection: %+v", out.Rejection)
	}

	// NFe still AUTHORIZED.
	rec, _ := s.nfeRepo.GetByChave(context.Background(), cancelChave)
	if rec.Status != nfe.NFeStatusAuthorized {
		t.Errorf("Status flipped despite SEFAZ rejection: %s", rec.Status)
	}

	// Event row still written so the rejection is auditable.
	evt, err := s.eventRepo.GetByKey(context.Background(), cancelChave, nfe.NFeEventTypeCancel, 1)
	if err != nil {
		t.Fatalf("event row missing: %v", err)
	}
	if evt.Status != nfe.EventStatusRejected || evt.NProt != "" {
		t.Errorf("rejection event payload: %+v", evt)
	}
}

func TestCancelNFe_TransportFailureBubblesUp(t *testing.T) {
	s := newCancelStack(t)
	s.seedAuthorized(t, cancelChave)
	s.mock.FailEventWithError(nfe.ErrSefazUnreachable)

	_, err := s.uc.Cancel(context.Background(), application.CancelInput{
		Chave:         cancelChave,
		Justification: "tentativa em ambiente indisponivel",
	})
	if !errors.Is(err, nfe.ErrSefazUnreachable) {
		t.Errorf("err = %v, want ErrSefazUnreachable in chain", err)
	}

	// No event row, no status flip — same as InMemory record before.
	rec, _ := s.nfeRepo.GetByChave(context.Background(), cancelChave)
	if rec.Status != nfe.NFeStatusAuthorized {
		t.Errorf("status changed on transport failure: %s", rec.Status)
	}
}
