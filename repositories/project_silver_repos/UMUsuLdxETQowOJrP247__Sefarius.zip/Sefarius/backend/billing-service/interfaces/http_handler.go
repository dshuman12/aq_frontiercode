package interfaces

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain"
)

// InvoiceHandler handles HTTP requests for invoices
type InvoiceHandler struct {
	service domain.InvoiceUseCase
}

// NewInvoiceHandler creates a new invoice handler
func NewInvoiceHandler(service domain.InvoiceUseCase) *InvoiceHandler {
	return &InvoiceHandler{
		service: service,
	}
}

// CreateInvoiceHandler handles POST /invoices
func (h *InvoiceHandler) CreateInvoice(c *fiber.Ctx) error {
	var req application.CreateInvoiceRequest
	if err := ParseAndValidate(c, &req); err != nil {
		return err
	}

	// Check idempotency key header
	idempotencyKey := c.Get("Idempotency-Key")
	if idempotencyKey == "" {
		idempotencyKey = req.IdempotencyKey
	}

	// Create input
	items := make([]domain.CreateInvoiceItemInput, len(req.Items))
	for i, item := range req.Items {
		items[i] = domain.CreateInvoiceItemInput{
			ProductID: item.ProductID,
			Quantity:  item.Quantity,
			UnitPrice: item.UnitPrice,
		}
	}

	input := &domain.CreateInvoiceInput{
		CreatedBy:      req.CreatedBy,
		Items:          items,
		IdempotencyKey: idempotencyKey,
	}

	invoice, err := h.service.CreateInvoice(c.Context(), input)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsInvoiceError(err, domain.ErrInputNil) ||
			domain.IsInvoiceError(err, domain.ErrCreatedByRequired) ||
			domain.IsInvoiceError(err, domain.ErrNoItems) ||
			domain.IsInvoiceError(err, domain.ErrIdempotencyKeyRequired) {
			statusCode = fiber.StatusBadRequest
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	// Convert to DTO
	invoiceDTO := toInvoiceDTO(invoice)

	return SuccessResponse(c, fiber.StatusCreated, invoiceDTO)
}

// GetInvoiceHandler handles GET /invoices/:id
func (h *InvoiceHandler) GetInvoice(c *fiber.Ctx) error {
	id := c.Params("id")

	invoice, err := h.service.GetInvoice(c.Context(), id)
	if err != nil {
		return ErrorResponse(c, fiber.StatusNotFound, "invoice not found")
	}

	invoiceDTO := toInvoiceDTO(invoice)

	return SuccessResponse(c, fiber.StatusOK, invoiceDTO)
}

// ListInvoicesHandler handles GET /invoices
func (h *InvoiceHandler) ListInvoices(c *fiber.Ctx) error {
	limit := domain.DefaultPageLimit
	offset := 0

	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 {
			limit = l
		}
	}

	if offsetStr := c.Query("offset"); offsetStr != "" {
		if o, err := strconv.Atoi(offsetStr); err == nil && o >= 0 {
			offset = o
		}
	}

	invoices, err := h.service.ListInvoices(c.Context(), limit, offset)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "failed to list invoices")
	}

	// Real total from DB so the frontend can render numerical pagination.
	// Previous code set Total=len(dtos) which only equals the page size.
	total, err := h.service.CountInvoices(c.Context())
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "failed to count invoices")
	}

	dtos := make([]application.InvoiceDTO, 0, len(invoices))
	for _, inv := range invoices {
		dtos = append(dtos, toInvoiceDTO(inv))
	}

	return SuccessResponse(c, fiber.StatusOK, application.PaginatedResponse{
		Items:  dtos,
		Total:  total,
		Limit:  limit,
		Offset: offset,
	})
}

// CloseInvoiceHandler handles POST /invoices/:id/close
func (h *InvoiceHandler) CloseInvoice(c *fiber.Ctx) error {
	id := c.Params("id")

	invoice, err := h.service.CloseInvoice(c.Context(), id)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsInvoiceError(err, domain.ErrInvoiceNotFound) {
			statusCode = fiber.StatusNotFound
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	invoiceDTO := toInvoiceDTO(invoice)

	return SuccessResponse(c, fiber.StatusOK, invoiceDTO)
}

// CancelInvoiceHandler handles POST /invoices/:id/cancel
func (h *InvoiceHandler) CancelInvoice(c *fiber.Ctx) error {
	id := c.Params("id")

	invoice, err := h.service.CancelInvoice(c.Context(), id)
	if err != nil {
		statusCode := fiber.StatusInternalServerError
		if domain.IsInvoiceError(err, domain.ErrInvoiceNotFound) {
			statusCode = fiber.StatusNotFound
		} else if domain.IsInvoiceError(err, domain.ErrOnlyOpenCanCancel) {
			statusCode = fiber.StatusBadRequest
		}
		return ErrorResponse(c, statusCode, err.Error())
	}

	invoiceDTO := toInvoiceDTO(invoice)

	return SuccessResponse(c, fiber.StatusOK, invoiceDTO)
}

// DeleteInvoiceHandler handles DELETE /invoices/:id
func (h *InvoiceHandler) DeleteInvoice(c *fiber.Ctx) error {
	id := c.Params("id")

	if err := h.service.DeleteInvoice(c.Context(), id); err != nil {
		if domain.IsInvoiceError(err, domain.ErrInvoiceNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, err.Error())
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	return c.Status(http.StatusNoContent).Send(nil)
}

// HealthHandler handles GET /health
func (h *InvoiceHandler) Health(c *fiber.Ctx) error {
	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"status":  "healthy",
		"service": "billing-service",
		"time":    time.Now().Unix(),
	})
}

// Helper function to convert Invoice to InvoiceDTO
func toInvoiceDTO(invoice *domain.Invoice) application.InvoiceDTO {
	items := make([]application.InvoiceItemDTO, len(invoice.Items))
	totalAmount := 0.0

	for i, item := range invoice.Items {
		subtotal := item.UnitPrice * float64(item.Quantity)
		items[i] = application.InvoiceItemDTO{
			ID:                 item.ID,
			ProductID:          item.ProductID,
			ProductCode:        item.ProductCode,
			ProductDescription: item.ProductDescription,
			Quantity:           item.Quantity,
			UnitPrice:          item.UnitPrice,
			Subtotal:           subtotal,
			CreatedAt:          item.CreatedAt,
		}
		totalAmount += subtotal
	}

	return application.InvoiceDTO{
		ID:             invoice.ID,
		Number:         invoice.Number,
		Status:         string(invoice.Status),
		IdempotencyKey: invoice.IdempotencyKey,
		CreatedBy:      invoice.CreatedBy,
		Items:          items,
		TotalAmount:    totalAmount,
		CreatedAt:      invoice.CreatedAt,
		ClosedAt:       invoice.ClosedAt,
	}
}
