package interfaces_test

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/danfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
	"github.com/sefarius/billing-service/interfaces"
)

const (
	eventHandlerChave = nfe.Chave("43260505730928000145550010000001007123456787")
)

// newEventTestApp wires the cancel + cce handlers against in-memory
// repos and registers the seven sprint 2.1 routes. Returns the app
// plus the mock so tests can drive SEFAZ outcomes, and the repos so
// tests can pre-seed an AUTHORIZED NFe and assert on persistence.
func newEventTestApp(t *testing.T) (*fiber.App, *sefaz.MockClient, *infrastructure.InMemoryNFeRepository, *infrastructure.InMemoryNFeEventRepository) {
	t.Helper()

	cert, err := nfe.GenerateSelfSignedTest("event-handler-test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	nfeRepo := infrastructure.NewInMemoryNFeRepository()
	eventRepo := infrastructure.NewInMemoryNFeEventRepository()
	cancelUC := application.NewCancelNFeUseCase(cert, mock, nfeRepo, eventRepo)
	cceUC := application.NewSendCCeUseCase(cert, mock, nfeRepo, eventRepo)
	handler := interfaces.NewNFeEventHandler(cancelUC, cceUC, eventRepo, nfeRepo, danfe.NewGenerator())

	app := fiber.New()
	api := app.Group("/api/nfe")
	// More-specific routes first so /cancel/xml, /cce/:seq/xml, etc.
	// are not swallowed by /:chave/xml or /:chave.
	api.Post("/:chave/cancel", handler.Cancel)
	api.Post("/:chave/cce", handler.SendCCe)
	api.Get("/:chave/cancel/pdf", handler.GetCancelPDF)
	api.Get("/:chave/cce/:seq/pdf", handler.GetCCePDF)
	api.Get("/:chave/cancel/xml", handler.GetCancelXML)
	api.Get("/:chave/cancel", handler.GetCancel)
	api.Get("/:chave/cce/:seq/xml", handler.GetCCeXML)
	api.Get("/:chave/cce/:seq", handler.GetCCe)
	api.Get("/:chave/cce", handler.ListCCe)

	return app, mock, nfeRepo, eventRepo
}

// seedAuthorizedForHandler pre-populates an AUTHORIZED NFe so cancel
// and cce calls have a target. The signed XML carries the Ide / Emit
// / Dest blocks the sprint 2.2 PDF comprovantes parse for context —
// the cancel/CCe use cases themselves only need <emit><CNPJ>, so the
// richer fixture is a superset that satisfies both consumers.
func seedAuthorizedForHandler(t *testing.T, repo *infrastructure.InMemoryNFeRepository, chave nfe.Chave) {
	t.Helper()
	signedXML := []byte(`<?xml version="1.0" encoding="UTF-8"?>` +
		`<NFe xmlns="http://www.portalfiscal.inf.br/nfe">` +
		`<infNFe Id="NFe` + string(chave) + `" versao="4.00">` +
		`<ide><cUF>43</cUF><cNF>12345678</cNF><natOp>VENDA</natOp>` +
		`<mod>55</mod><serie>1</serie><nNF>100</nNF>` +
		`<dhEmi>2026-05-06T10:00:00-03:00</dhEmi>` +
		`<tpNF>1</tpNF><idDest>1</idDest><cMunFG>4314902</cMunFG>` +
		`<tpImp>1</tpImp><tpEmis>1</tpEmis><cDV>7</cDV>` +
		`<tpAmb>2</tpAmb><finNFe>1</finNFe><indFinal>1</indFinal>` +
		`<indPres>1</indPres><procEmi>0</procEmi><verProc>sefarius 0.1</verProc>` +
		`</ide>` +
		`<emit><CNPJ>05730928000145</CNPJ><xNome>EMPRESA HANDLER TESTE LTDA</xNome>` +
		`<enderEmit><xLgr>AV TESTE</xLgr><nro>100</nro><xBairro>CENTRO</xBairro>` +
		`<cMun>4314902</cMun><xMun>PORTO ALEGRE</xMun><UF>RS</UF><CEP>90000000</CEP></enderEmit>` +
		`<IE>1234567890</IE><CRT>3</CRT></emit>` +
		`<dest><CNPJ>11444777000161</CNPJ><xNome>CLIENTE HANDLER TESTE LTDA</xNome>` +
		`<enderDest><xLgr>RUA DEST</xLgr><nro>200</nro><xBairro>BAIRRO</xBairro>` +
		`<cMun>4314902</cMun><xMun>PORTO ALEGRE</xMun><UF>RS</UF></enderDest>` +
		`<indIEDest>1</indIEDest></dest>` +
		`</infNFe></NFe>`)
	rec := &nfe.NFeRecord{
		Chave:     chave,
		Status:    nfe.NFeStatusAuthorized,
		SignedXML: signedXML,
		Protocol: &nfe.Protocol{
			NProt: "143260000000777",
			ChNFe: string(chave),
			TpAmb: "2",
		},
	}
	if err := repo.Save(context.Background(), rec); err != nil {
		t.Fatalf("seed: %v", err)
	}
}

func doEventRequest(t *testing.T, app *fiber.App, method, path string, body []byte) (int, application.APIResponse, []byte) {
	t.Helper()
	var bodyReader io.Reader
	if body != nil {
		bodyReader = bytes.NewReader(body)
	}
	req := httptest.NewRequest(method, path, bodyReader)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	rawBody, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()

	var envelope application.APIResponse
	_ = json.Unmarshal(rawBody, &envelope)
	return resp.StatusCode, envelope, rawBody
}

func TestCancelHTTP_HappyPath(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"justification":"cancelado por solicitacao do cliente"}`)
	status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cancel", body)
	if status != fiber.StatusCreated {
		t.Fatalf("status = %d, want 201; envelope=%+v", status, env)
	}
	if !env.Success {
		t.Errorf("envelope.Success false: error=%q", env.Error)
	}
	data := env.Data.(map[string]any)
	if data["status"] != "ACCEPTED" {
		t.Errorf("status = %v, want ACCEPTED", data["status"])
	}
	if data["event_type"] != "CANCEL" {
		t.Errorf("event_type = %v, want CANCEL", data["event_type"])
	}

	// GET /cancel returns the persisted summary.
	status, env, _ = doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cancel", nil)
	if status != fiber.StatusOK {
		t.Errorf("GET /cancel status = %d, want 200", status)
	}
	if !env.Success {
		t.Errorf("GET /cancel envelope.Success false: %q", env.Error)
	}
}

func TestCancelHTTP_ShortJustificationReturns422(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"justification":"curto"}`) // 5 chars
	status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cancel", body)
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("status = %d, want 422", status)
	}
	if env.Success {
		t.Errorf("envelope.Success true on validation failure")
	}
}

func TestCancelHTTP_UnknownChaveReturns404(t *testing.T) {
	app, _, _, _ := newEventTestApp(t)

	body := []byte(`{"justification":"cancelando uma chave inexistente"}`)
	status, _, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cancel", body)
	if status != fiber.StatusNotFound {
		t.Errorf("status = %d, want 404", status)
	}
}

func TestCCeHTTP_AutoSeqHappyPath(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"correction":"endereco do destinatario corrigido"}`)
	status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cce", body)
	if status != fiber.StatusCreated {
		t.Fatalf("status = %d, want 201; envelope=%+v", status, env)
	}
	data := env.Data.(map[string]any)
	if int(data["seq"].(float64)) != 1 {
		t.Errorf("seq = %v, want 1", data["seq"])
	}

	// Second post — auto-seq should advance to 2.
	body2 := []byte(`{"correction":"natureza da operacao corrigida"}`)
	status, env, _ = doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cce", body2)
	if status != fiber.StatusCreated {
		t.Fatalf("status2 = %d, want 201", status)
	}
	data2 := env.Data.(map[string]any)
	if int(data2["seq"].(float64)) != 2 {
		t.Errorf("seq2 = %v, want 2", data2["seq"])
	}

	// GET /cce returns 2 entries.
	status, env, _ = doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cce", nil)
	if status != fiber.StatusOK {
		t.Errorf("GET /cce status = %d", status)
	}
	list := env.Data.([]any)
	if len(list) != 2 {
		t.Errorf("GET /cce list len = %d, want 2", len(list))
	}
}

func TestCCeHTTP_GetSeqXMLReturnsXML(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"correction":"correcao de teste para validar xml"}`)
	if status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cce", body); status != fiber.StatusCreated {
		t.Fatalf("POST /cce status = %d, env=%+v", status, env)
	}

	req := httptest.NewRequest("GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/1/xml", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	rawBody, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()

	if resp.StatusCode != fiber.StatusOK {
		t.Errorf("status = %d, want 200; body=%s", resp.StatusCode, rawBody)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "application/xml; charset=utf-8" {
		t.Errorf("Content-Type = %q, want application/xml", ct)
	}
	if !bytes.Contains(rawBody, []byte("procEventoNFe")) {
		t.Errorf("XML body does not contain procEventoNFe: %s", rawBody)
	}
}

func TestCCeHTTP_BadSeqReturns400(t *testing.T) {
	app, _, _, _ := newEventTestApp(t)
	status, _, _ := doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/abc", nil)
	if status != fiber.StatusBadRequest {
		t.Errorf("status = %d, want 400 for non-numeric seq", status)
	}
	status, _, _ = doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/0", nil)
	if status != fiber.StatusBadRequest {
		t.Errorf("status = %d, want 400 for seq=0", status)
	}
}

// ─── Sprint 2.2: PDF comprovantes ──────────────────────────────────

func TestCancelPDFHTTP_HappyPath(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"justification":"cancelado por solicitacao do cliente"}`)
	if status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cancel", body); status != fiber.StatusCreated {
		t.Fatalf("POST /cancel status = %d, env=%+v", status, env)
	}

	req := httptest.NewRequest("GET", "/api/nfe/"+string(eventHandlerChave)+"/cancel/pdf", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	rawBody, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()

	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200; body=%s", resp.StatusCode, rawBody)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "application/pdf" {
		t.Errorf("Content-Type = %q, want application/pdf", ct)
	}
	if !bytes.HasPrefix(rawBody, []byte("%PDF-")) {
		t.Errorf("body does not start with %%PDF- magic: %x", rawBody[:8])
	}
}

func TestCancelPDFHTTP_NotFoundWhenNoEvent(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	status, _, _ := doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cancel/pdf", nil)
	if status != fiber.StatusNotFound {
		t.Errorf("status = %d, want 404 when no cancel event has been issued", status)
	}
}

func TestCCePDFHTTP_HappyPath(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	body := []byte(`{"correction":"correcao de teste para pdf comprovante"}`)
	if status, env, _ := doEventRequest(t, app, "POST", "/api/nfe/"+string(eventHandlerChave)+"/cce", body); status != fiber.StatusCreated {
		t.Fatalf("POST /cce status = %d, env=%+v", status, env)
	}

	req := httptest.NewRequest("GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/1/pdf", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	rawBody, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()

	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200; body=%s", resp.StatusCode, rawBody)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "application/pdf" {
		t.Errorf("Content-Type = %q, want application/pdf", ct)
	}
	if !bytes.HasPrefix(rawBody, []byte("%PDF-")) {
		t.Errorf("body does not start with %%PDF- magic")
	}
}

func TestCCePDFHTTP_NotFoundWhenSeqMissing(t *testing.T) {
	app, _, nfeRepo, _ := newEventTestApp(t)
	seedAuthorizedForHandler(t, nfeRepo, eventHandlerChave)

	status, _, _ := doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/1/pdf", nil)
	if status != fiber.StatusNotFound {
		t.Errorf("status = %d, want 404 when no CCe has been issued for seq", status)
	}
}

func TestCCePDFHTTP_BadSeqReturns400(t *testing.T) {
	app, _, _, _ := newEventTestApp(t)
	status, _, _ := doEventRequest(t, app, "GET", "/api/nfe/"+string(eventHandlerChave)+"/cce/abc/pdf", nil)
	if status != fiber.StatusBadRequest {
		t.Errorf("status = %d, want 400 for non-numeric seq", status)
	}
}
