package interfaces

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure/danfe"
)

// NFeEventHandler exposes the cancel + CCe lifecycle over HTTP.
// Sprint 2.1 introduced JSON + XML endpoints; sprint 2.2 added the PDF
// comprovante endpoints (/pdf), which is why the handler now also
// holds nfeRepo (for the original-NFe context block) and a DANFE
// generator.
//
// Validation refusals → 422; missing chaves → 404; SEFAZ rejections
// → 200 with the structured outcome (they are expected business
// signals, not transport errors); transport failures → 502.
type NFeEventHandler struct {
	cancelUC  *application.CancelNFeUseCase
	cceUC     *application.SendCCeUseCase
	eventRepo nfe.NFeEventRepository
	nfeRepo   nfe.NFeRepository
	danfeGen  *danfe.Generator
}

// NewNFeEventHandler wires the dependencies. All five must be non-nil.
// nfeRepo + danfeGen are sprint 2.2 additions used by GetCancelPDF /
// GetCCePDF — the existing JSON/XML routes do not consume them.
func NewNFeEventHandler(
	cancelUC *application.CancelNFeUseCase,
	cceUC *application.SendCCeUseCase,
	eventRepo nfe.NFeEventRepository,
	nfeRepo nfe.NFeRepository,
	danfeGen *danfe.Generator,
) *NFeEventHandler {
	return &NFeEventHandler{
		cancelUC:  cancelUC,
		cceUC:     cceUC,
		eventRepo: eventRepo,
		nfeRepo:   nfeRepo,
		danfeGen:  danfeGen,
	}
}

// ─── Request DTOs ──────────────────────────────────────────────────

type cancelRequest struct {
	Justification string `json:"justification"`
}

type cceRequest struct {
	Correction string `json:"correction"`
	Seq        int    `json:"seq,omitempty"` // 0 = auto-increment
}

// ─── Response DTOs ─────────────────────────────────────────────────

// EventResponse is the JSON form of a CancelOutcome / CCeOutcome
// summary. SignedXML and ResponseXML are NOT included — the caller
// fetches those from /xml endpoints (raw bytes; potentially large).
type EventResponse struct {
	Chave     string              `json:"chave"`
	EventType string              `json:"event_type"`
	Seq       int                 `json:"seq"`
	Status    string              `json:"status"`
	NProt     string              `json:"n_prot,omitempty"`
	CStat     string              `json:"c_stat"`
	XMotivo   string              `json:"x_motivo"`
	Protocol  *eventProtocolDTO   `json:"protocol,omitempty"`
	Rejection *nfe.EventRejection `json:"rejection,omitempty"`
}

type eventProtocolDTO struct {
	NProt       string `json:"n_prot"`
	DhRegEvento string `json:"dh_reg_evento"`
	ChNFe       string `json:"ch_nfe"`
	TpEvento    string `json:"tp_evento"`
	NSeqEvento  int    `json:"n_seq_evento"`
	CStat       string `json:"c_stat"`
	XMotivo     string `json:"x_motivo"`
	TpAmb       string `json:"tp_amb"`
}

// ─── POST /api/nfe/:chave/cancel ───────────────────────────────────

func (h *NFeEventHandler) Cancel(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	var req cancelRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid JSON body: "+err.Error())
	}

	out, err := h.cancelUC.Cancel(c.Context(), application.CancelInput{
		Chave:         chave,
		Justification: req.Justification,
	})
	if err != nil {
		return mapCancelError(c, err)
	}

	resp := EventResponse{
		Chave:     string(out.Chave),
		EventType: string(nfe.NFeEventTypeCancel),
		Seq:       1,
		Status:    string(out.Status),
		NProt:     out.NProt,
		CStat:     out.CStat,
		XMotivo:   out.XMotivo,
		Rejection: out.Rejection,
	}
	if out.Protocol != nil {
		resp.Protocol = protocolToEventDTO(out.Protocol)
	}
	return SuccessResponse(c, fiber.StatusCreated, resp)
}

// ─── POST /api/nfe/:chave/cce ──────────────────────────────────────

func (h *NFeEventHandler) SendCCe(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	var req cceRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid JSON body: "+err.Error())
	}

	out, err := h.cceUC.Send(c.Context(), application.CCeInput{
		Chave:      chave,
		Correction: req.Correction,
		Seq:        req.Seq,
	})
	if err != nil {
		return mapCCeError(c, err)
	}

	resp := EventResponse{
		Chave:     string(out.Chave),
		EventType: string(nfe.NFeEventTypeCCe),
		Seq:       out.Seq,
		Status:    string(out.Status),
		NProt:     out.NProt,
		CStat:     out.CStat,
		XMotivo:   out.XMotivo,
		Rejection: out.Rejection,
	}
	if out.Protocol != nil {
		resp.Protocol = protocolToEventDTO(out.Protocol)
	}
	return SuccessResponse(c, fiber.StatusCreated, resp)
}

// ─── GET /api/nfe/:chave/cancel ────────────────────────────────────

func (h *NFeEventHandler) GetCancel(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	rec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCancel, 1)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cancel event not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	return SuccessResponse(c, fiber.StatusOK, recordToEventResponse(rec))
}

// ─── GET /api/nfe/:chave/cancel/xml ────────────────────────────────

func (h *NFeEventHandler) GetCancelXML(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	rec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCancel, 1)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cancel event not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	return sendEventXML(c, rec)
}

// ─── GET /api/nfe/:chave/cce ───────────────────────────────────────

func (h *NFeEventHandler) ListCCe(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	all, err := h.eventRepo.ListByChave(c.Context(), chave)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	out := make([]EventResponse, 0, len(all))
	for _, rec := range all {
		if rec.EventType != nfe.NFeEventTypeCCe {
			continue
		}
		out = append(out, recordToEventResponse(rec))
	}
	return SuccessResponse(c, fiber.StatusOK, out)
}

// ─── GET /api/nfe/:chave/cce/:seq ──────────────────────────────────

func (h *NFeEventHandler) GetCCe(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	seq, err := strconv.Atoi(c.Params("seq"))
	if err != nil || seq < 1 {
		return ErrorResponse(c, fiber.StatusBadRequest, "seq must be a positive integer")
	}
	rec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCCe, seq)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cce not found for that seq")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	return SuccessResponse(c, fiber.StatusOK, recordToEventResponse(rec))
}

// ─── GET /api/nfe/:chave/cce/:seq/xml ──────────────────────────────

func (h *NFeEventHandler) GetCCeXML(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	seq, err := strconv.Atoi(c.Params("seq"))
	if err != nil || seq < 1 {
		return ErrorResponse(c, fiber.StatusBadRequest, "seq must be a positive integer")
	}
	rec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCCe, seq)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cce not found for that seq")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	return sendEventXML(c, rec)
}

// ─── GET /api/nfe/:chave/cancel/pdf ────────────────────────────────

// GetCancelPDF renders the comprovante de cancelamento PDF.
// Mirrors GetNFeDANFE: the persisted XML bytes are the authoritative
// source, both for the cancel event itself and for the original NFe
// context block. Re-rendering on demand keeps the layout malleable
// without invalidating stored PDFs and avoids paying the PDF CPU cost
// on every cancel call (most cancels are never printed).
func (h *NFeEventHandler) GetCancelPDF(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	eventRec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCancel, 1)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cancel event not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	nfeRec, err := h.nfeRepo.GetByChave(c.Context(), chave)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "nfe not found for context")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	pdf, err := h.danfeGen.GenerateCancel(eventRec, nfeRec)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "render cancel pdf: "+err.Error())
	}
	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", `inline; filename="cancel-`+string(chave)+`.pdf"`)
	return c.Send(pdf)
}

// ─── GET /api/nfe/:chave/cce/:seq/pdf ──────────────────────────────

func (h *NFeEventHandler) GetCCePDF(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	seq, err := strconv.Atoi(c.Params("seq"))
	if err != nil || seq < 1 {
		return ErrorResponse(c, fiber.StatusBadRequest, "seq must be a positive integer")
	}
	eventRec, err := h.eventRepo.GetByKey(c.Context(), chave, nfe.NFeEventTypeCCe, seq)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeEventNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "cce not found for that seq")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	nfeRec, err := h.nfeRepo.GetByChave(c.Context(), chave)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "nfe not found for context")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	pdf, err := h.danfeGen.GenerateCCe(eventRec, nfeRec)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "render cce pdf: "+err.Error())
	}
	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", `inline; filename="cce-`+string(chave)+`-`+strconv.Itoa(seq)+`.pdf"`)
	return c.Send(pdf)
}

// ─── Helpers ───────────────────────────────────────────────────────

// sendEventXML returns the procEventoNFe envelope for an event row.
// Falls back to the raw signed evento when ResponseXML is empty (the
// SERVICE_UNAVAILABLE branch — but those rows are not even persisted
// today, so this is mostly a safety net).
func sendEventXML(c *fiber.Ctx, rec *nfe.NFeEventRecord) error {
	xml := rec.ResponseXML
	if len(xml) == 0 {
		xml = rec.SignedXML
	}
	c.Set("Content-Type", "application/xml; charset=utf-8")
	c.Set("Content-Disposition", `inline; filename="event-`+string(rec.Chave)+`-`+string(rec.EventType)+`-`+strconv.Itoa(rec.NSeq)+`.xml"`)
	return c.Send(xml)
}

func mapCancelError(c *fiber.Ctx, err error) error {
	var ve *application.ErrValidation
	if errors.As(err, &ve) {
		return c.Status(fiber.StatusUnprocessableEntity).JSON(application.APIResponse{
			Success: false,
			Error:   ve.Error(),
			Data:    ve.Issues,
			Code:    fiber.StatusUnprocessableEntity,
		})
	}
	if errors.Is(err, nfe.ErrNFeNotFound) {
		return ErrorResponse(c, fiber.StatusNotFound, "nfe not found")
	}
	if errors.Is(err, nfe.ErrNFeNotCancellable) {
		return ErrorResponse(c, fiber.StatusUnprocessableEntity, "nfe is not in AUTHORIZED state")
	}
	if errors.Is(err, nfe.ErrSefazUnreachable) {
		return ErrorResponse(c, fiber.StatusBadGateway, err.Error())
	}
	return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
}

func mapCCeError(c *fiber.Ctx, err error) error {
	var ve *application.ErrValidation
	if errors.As(err, &ve) {
		return c.Status(fiber.StatusUnprocessableEntity).JSON(application.APIResponse{
			Success: false,
			Error:   ve.Error(),
			Data:    ve.Issues,
			Code:    fiber.StatusUnprocessableEntity,
		})
	}
	if errors.Is(err, nfe.ErrNFeNotFound) {
		return ErrorResponse(c, fiber.StatusNotFound, "nfe not found")
	}
	if errors.Is(err, nfe.ErrNFeNotCancellable) {
		return ErrorResponse(c, fiber.StatusUnprocessableEntity, "nfe is not in AUTHORIZED state")
	}
	if errors.Is(err, nfe.ErrCCeSeqOutOfOrder) {
		return ErrorResponse(c, fiber.StatusUnprocessableEntity, "nSeqEvento must be the next sequential value")
	}
	if errors.Is(err, nfe.ErrSefazUnreachable) {
		return ErrorResponse(c, fiber.StatusBadGateway, err.Error())
	}
	return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
}

func recordToEventResponse(rec *nfe.NFeEventRecord) EventResponse {
	return EventResponse{
		Chave:     string(rec.Chave),
		EventType: string(rec.EventType),
		Seq:       rec.NSeq,
		Status:    string(rec.Status),
		NProt:     rec.NProt,
		CStat:     rec.CStat,
		XMotivo:   rec.XMotivo,
	}
}

func protocolToEventDTO(p *nfe.EventProtocol) *eventProtocolDTO {
	return &eventProtocolDTO{
		NProt:       p.NProt,
		DhRegEvento: p.DhRegEvento.UTC().Format("2006-01-02T15:04:05Z"),
		ChNFe:       p.ChNFe,
		TpEvento:    p.TpEvento,
		NSeqEvento:  p.NSeqEvento,
		CStat:       p.CStat,
		XMotivo:     p.XMotivo,
		TpAmb:       p.TpAmb,
	}
}
