package interfaces

import (
	"errors"
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/infrastructure/danfe"
)

// NFeHandler exposes the NF-e emission lifecycle over HTTP. The
// handler is intentionally thin: it translates JSON DTOs to typed
// schema structs, delegates to EmitNFeUseCase, and maps outcomes back
// to HTTP responses. All fiscal logic stays in the application and
// domain layers.
type NFeHandler struct {
	useCase   *application.EmitNFeUseCase
	repo      nfe.NFeRepository
	danfeGen  *danfe.Generator
}

// NewNFeHandler wires the dependencies. Use case, repo, and DANFE
// generator must all be non-nil.
func NewNFeHandler(uc *application.EmitNFeUseCase, repo nfe.NFeRepository, gen *danfe.Generator) *NFeHandler {
	return &NFeHandler{useCase: uc, repo: repo, danfeGen: gen}
}

// EmitNFeRequest is the minimal JSON payload to emit a single NF-e.
// The shape is a deliberate subset of the SEFAZ leiaute v4.00 — enough
// to construct a "venda interna mod 55, RS->RS, regime normal" via
// the Builder. Richer payloads (multi-CFOP per item, multiple regimes,
// transport blocks) are sprint-future expansion; right now this is
// what gives the AfterQuery reviewer a working end-to-end emission
// without a ~3000-field JSON spec.
type EmitNFeRequest struct {
	Emit  EmitterDTO       `json:"emit"`
	Dest  RecipientDTO     `json:"dest"`
	Ide   IdentificationDTO `json:"ide"`
	Items []ItemDTO        `json:"items"`
}

// EmitterDTO carries emitter (issuer) data.
type EmitterDTO struct {
	CNPJ    string `json:"cnpj"`
	XNome   string `json:"x_nome"`
	IE      string `json:"ie"`
	CRT     string `json:"crt"`
	XLgr    string `json:"x_lgr"`
	Nro     string `json:"nro"`
	XBairro string `json:"x_bairro"`
	CMun    string `json:"c_mun"`
	XMun    string `json:"x_mun"`
	UF      string `json:"uf"`
	CEP     string `json:"cep"`
}

// RecipientDTO carries recipient data. CNPJ and CPF are mutually
// exclusive — the translator picks whichever is non-empty.
type RecipientDTO struct {
	CNPJ      string `json:"cnpj,omitempty"`
	CPF       string `json:"cpf,omitempty"`
	XNome     string `json:"x_nome"`
	IndIEDest string `json:"ind_ie_dest"`
	IE        string `json:"ie,omitempty"`
	XLgr      string `json:"x_lgr"`
	Nro       string `json:"nro"`
	XBairro   string `json:"x_bairro"`
	CMun      string `json:"c_mun"`
	XMun      string `json:"x_mun"`
	UF        string `json:"uf"`
	CEP       string `json:"cep,omitempty"`
}

// IdentificationDTO carries the NF-e identification block.
type IdentificationDTO struct {
	CUF     string `json:"c_uf"`
	CNF     string `json:"c_nf"`
	NatOp   string `json:"nat_op"`
	Serie   string `json:"serie"`
	NNF     string `json:"n_nf"`
	DhEmi   string `json:"dh_emi"`
	TpNF    string `json:"tp_nf"`
	IdDest  string `json:"id_dest"`
	CMunFG  string `json:"c_mun_fg"`
	TpAmb   string `json:"tp_amb"`
	FinNFe  string `json:"fin_nfe"`
	IndPres string `json:"ind_pres"`
}

// ItemDTO is a single product line. The translator maps it to a Det
// via the existing CST 00 facade — sufficient for regime normal venda
// interna; other CSTs/CSOSNs are sprint-future work.
type ItemDTO struct {
	CProd   string `json:"c_prod"`
	XProd   string `json:"x_prod"`
	NCM     string `json:"ncm"`
	CFOP    string `json:"cfop"`
	UCom    string `json:"u_com"`
	QCom    string `json:"q_com"`
	VUnCom  string `json:"v_un_com"`
	VProd   string `json:"v_prod"`
	VBC     string `json:"v_bc"`
	PICMS   string `json:"p_icms"`
	VPIS    string `json:"v_pis"`
	VCOFINS string `json:"v_cofins"`
}

// EmitNFeResponse is the JSON form of an EmitOutcome. The signed XML
// is returned base64-encoded in a separate endpoint (GET .../xml) so
// the JSON stays small for browsers and proxies.
type EmitNFeResponse struct {
	Chave     string                 `json:"chave"`
	Status    string                 `json:"status"`     // wire-level AuthorizationStatus
	Lifecycle string                 `json:"lifecycle"`  // persisted NFeStatus
	CStat     string                 `json:"c_stat"`
	XMotivo   string                 `json:"x_motivo"`
	Protocol  *ProtocolDTO           `json:"protocol,omitempty"`
	Rejection *nfe.Rejection         `json:"rejection,omitempty"`
}

// ProtocolDTO renders nfe.Protocol with JSON-friendly field names.
type ProtocolDTO struct {
	NProt    string `json:"n_prot"`
	DhRecbto string `json:"dh_recbto"`
	ChNFe    string `json:"ch_nfe"`
	DigVal   string `json:"dig_val"`
	CStat    string `json:"c_stat"`
	XMotivo  string `json:"x_motivo"`
	TpAmb    string `json:"tp_amb"`
}

// EmitNFe handles POST /api/nfe.
//
// Validation failures and fiscal rejections both return HTTP 200 with
// the structured outcome — they are *expected* business signals, not
// transport errors. Only programming errors (nil deps, malformed JSON)
// and transport failures (SEFAZ unreachable) translate to 4xx/5xx.
func (h *NFeHandler) EmitNFe(c *fiber.Ctx) error {
	var req EmitNFeRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid JSON body: "+err.Error())
	}

	tnfe, err := requestToTNFe(req)
	if err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, err.Error())
	}

	out, err := h.useCase.Emit(c.Context(), application.EmitInput{NFe: tnfe})
	if err != nil {
		var ve *application.ErrValidation
		if errors.As(err, &ve) {
			return c.Status(fiber.StatusUnprocessableEntity).JSON(application.APIResponse{
				Success: false,
				Error:   ve.Error(),
				Data:    ve.Issues,
				Code:    fiber.StatusUnprocessableEntity,
			})
		}
		if errors.Is(err, nfe.ErrSefazUnreachable) {
			return ErrorResponse(c, fiber.StatusBadGateway, err.Error())
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	return SuccessResponse(c, fiber.StatusCreated, outcomeToResponse(out))
}

// GetNFe handles GET /api/nfe/:chave — returns the persisted record
// summary (without the XML, which has its own endpoint).
func (h *NFeHandler) GetNFe(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	rec, err := h.repo.GetByChave(c.Context(), chave)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "nfe not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	return SuccessResponse(c, fiber.StatusOK, recordToResponse(rec))
}

// ListNFe handles GET /api/nfe — paginated list ordered by recency.
//
// Response shape changed (2026-05-08): used to be a bare array; now
// wraps in PaginatedResponse with total/limit/offset so the frontend
// can render numerical pagination ("1 2 3 ... N"). The frontend's
// ApiService.listNFe was updated in lockstep — clients pinned to the
// old bare-array shape will need to read response.data.items.
func (h *NFeHandler) ListNFe(c *fiber.Ctx) error {
	limit := c.QueryInt("limit", 50)
	offset := c.QueryInt("offset", 0)

	records, err := h.repo.List(c.Context(), limit, offset)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	total, err := h.repo.Count(c.Context())
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	items := make([]map[string]any, 0, len(records))
	for _, rec := range records {
		items = append(items, map[string]any{
			"chave":      string(rec.Chave),
			"lifecycle":  string(rec.Status),
			"c_stat":     rec.CStat,
			"x_motivo":   rec.XMotivo,
			"created_at": rec.CreatedAt,
			"updated_at": rec.UpdatedAt,
		})
	}
	return SuccessResponse(c, fiber.StatusOK, fiber.Map{
		"items":  items,
		"total":  total,
		"limit":  limit,
		"offset": offset,
	})
}

// GetNFeXML handles GET /api/nfe/:chave/xml — returns the raw signed
// XML with the appropriate content type. Useful for debugging and
// for re-exporting to SEFAZ.
func (h *NFeHandler) GetNFeXML(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	rec, err := h.repo.GetByChave(c.Context(), chave)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "nfe not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}
	c.Set("Content-Type", "application/xml; charset=utf-8")
	return c.Send(rec.SignedXML)
}

// GetNFeDANFE handles GET /api/nfe/:chave/danfe — generates the PDF
// using the sprint 1.7 generator. We render on demand rather than at
// emit time because (a) PDF generation has a non-trivial CPU cost,
// (b) the layout may evolve, and (c) most NF-es are never printed.
func (h *NFeHandler) GetNFeDANFE(c *fiber.Ctx) error {
	chave := nfe.Chave(c.Params("chave"))
	rec, err := h.repo.GetByChave(c.Context(), chave)
	if err != nil {
		if errors.Is(err, nfe.ErrNFeNotFound) {
			return ErrorResponse(c, fiber.StatusNotFound, "nfe not found")
		}
		return ErrorResponse(c, fiber.StatusInternalServerError, err.Error())
	}

	// Re-parse the stored signed XML back into a TNFe. The DANFE
	// renderer wants the typed model, and the persisted bytes are the
	// authoritative source — re-parsing avoids a stale-cache bug
	// where a record's XML and decoded model could diverge.
	tnfe, err := nfe.ParseSignedNFe(rec.SignedXML)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "decode stored xml: "+err.Error())
	}

	pdf, err := h.danfeGen.Generate(tnfe, rec.Protocol)
	if err != nil {
		return ErrorResponse(c, fiber.StatusInternalServerError, "render danfe: "+err.Error())
	}

	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", `inline; filename="danfe-`+string(chave)+`.pdf"`)
	return c.Send(pdf)
}

// outcomeToResponse mirrors EmitOutcome to the JSON shape.
func outcomeToResponse(out *application.EmitOutcome) EmitNFeResponse {
	resp := EmitNFeResponse{
		Chave:     string(out.Chave),
		Status:    string(out.Status),
		Lifecycle: string(lifecycleFor(out.Status)),
		CStat:     out.CStat,
		XMotivo:   out.XMotivo,
		Rejection: out.Rejection,
	}
	if out.Protocol != nil {
		resp.Protocol = protocolToDTO(out.Protocol)
	}
	return resp
}

func recordToResponse(rec *nfe.NFeRecord) EmitNFeResponse {
	resp := EmitNFeResponse{
		Chave:     string(rec.Chave),
		Lifecycle: string(rec.Status),
		CStat:     rec.CStat,
		XMotivo:   rec.XMotivo,
		Rejection: rec.Rejection,
	}
	if rec.Protocol != nil {
		resp.Protocol = protocolToDTO(rec.Protocol)
	}
	return resp
}

func protocolToDTO(p *nfe.Protocol) *ProtocolDTO {
	return &ProtocolDTO{
		NProt:    p.NProt,
		DhRecbto: p.DhRecbto.UTC().Format("2006-01-02T15:04:05Z"),
		ChNFe:    p.ChNFe,
		DigVal:   p.DigVal,
		CStat:    p.CStat,
		XMotivo:  p.XMotivo,
		TpAmb:    p.TpAmb,
	}
}

// lifecycleFor mirrors application.lifecycleStatusFor (kept private
// there); duplicated rather than exported because the mapping is a
// presentation concern at the HTTP layer.
func lifecycleFor(s nfe.AuthorizationStatus) nfe.NFeStatus {
	switch s {
	case nfe.AuthorizationStatusAuthorized, nfe.AuthorizationStatusDuplicate:
		return nfe.NFeStatusAuthorized
	case nfe.AuthorizationStatusRejected:
		return nfe.NFeStatusRejected
	default:
		return nfe.NFeStatusPending
	}
}

// requestToTNFe builds a *schema.TNFe from the JSON DTO via the
// existing nfe.Builder + CST 00 facade. The function only handles the
// "venda interna regime normal, single-CST per item" path; richer
// shapes need different facades (Simples, ICMS-ST, etc.) and are out
// of scope for sprint 1.8.
func requestToTNFe(req EmitNFeRequest) (*schema.TNFe, error) {
	if len(req.Items) == 0 {
		return nil, errors.New("at least one item is required")
	}
	if req.Emit.CNPJ == "" {
		return nil, errors.New("emit.cnpj is required")
	}

	emit := &schema.Emit{
		CNPJ:  &req.Emit.CNPJ,
		XNome: req.Emit.XNome,
		EnderEmit: &schema.TEnderEmi{
			XLgr:    req.Emit.XLgr,
			Nro:     req.Emit.Nro,
			XBairro: req.Emit.XBairro,
			CMun:    req.Emit.CMun,
			XMun:    req.Emit.XMun,
			UF:      req.Emit.UF,
			CEP:     req.Emit.CEP,
		},
		IE:  req.Emit.IE,
		CRT: req.Emit.CRT,
	}

	dest := &schema.Dest{
		XNome: ptrIfNonEmpty(req.Dest.XNome),
		EnderDest: &schema.TEndereco{
			XLgr:    req.Dest.XLgr,
			Nro:     req.Dest.Nro,
			XBairro: req.Dest.XBairro,
			CMun:    req.Dest.CMun,
			XMun:    req.Dest.XMun,
			UF:      req.Dest.UF,
			CEP:     ptrIfNonEmpty(req.Dest.CEP),
		},
		IndIEDest: req.Dest.IndIEDest,
		IE:        ptrIfNonEmpty(req.Dest.IE),
	}
	if req.Dest.CNPJ != "" {
		dest.CNPJ = &req.Dest.CNPJ
	} else if req.Dest.CPF != "" {
		dest.CPF = &req.Dest.CPF
	}

	ide := &schema.Ide{
		CUF: req.Ide.CUF, CNF: req.Ide.CNF, NatOp: req.Ide.NatOp,
		Mod: "55", Serie: req.Ide.Serie, NNF: req.Ide.NNF,
		DhEmi: req.Ide.DhEmi, TpNF: req.Ide.TpNF,
		IdDest: req.Ide.IdDest, CMunFG: req.Ide.CMunFG,
		TpImp: "1", TpEmis: "1",
		TpAmb: req.Ide.TpAmb,
		FinNFe: req.Ide.FinNFe, IndFinal: "1",
		IndPres: req.Ide.IndPres,
		ProcEmi: "0", VerProc: "sefarius 0.1",
	}

	builder := nfe.New().
		Ide(ide).
		Emit(emit).
		Dest(dest).
		Transp(&schema.Transp{ModFrete: "9"}).
		Pag(&schema.Pag{DetPag: []*schema.DetPag{{TPag: "01", VPag: req.Items[0].VProd}}})

	for _, item := range req.Items {
		det, err := nfe.NewDetRegimeNormalCST00(
			&schema.Prod{
				CProd: item.CProd, CEAN: "SEM GTIN", XProd: item.XProd,
				NCM: item.NCM, CFOP: item.CFOP, UCom: item.UCom,
				QCom: item.QCom, VUnCom: item.VUnCom, VProd: item.VProd,
				CEANTrib: "SEM GTIN", UTrib: item.UCom, QTrib: item.QCom,
				VUnTrib: item.VUnCom, IndTot: "1",
			},
			item.VBC, item.PICMS, item.VPIS, item.VCOFINS,
		)
		if err != nil {
			return nil, err
		}
		builder.AddDet(det)
	}

	// Totals are computed from the (single-item) request — keeping
	// totals reconciliation simple for 1.8. Sprint future will compute
	// from the full Det set if multi-item bodies become common.
	//
	// vICMS = vBC * pICMS / 100. We use float64 here only to format
	// the totals string; the exact-decimal arithmetic that the
	// validator compares against runs in nfe.NewDetRegimeNormalCST00
	// via *big.Rat — totals just need to round to two decimals to
	// match what the items sum to.
	first := req.Items[0]
	vICMS := first.VBC // assume pICMS produces the same rounded value the item carries
	if vbc, errBC := strconv.ParseFloat(first.VBC, 64); errBC == nil {
		if pICMS, errP := strconv.ParseFloat(first.PICMS, 64); errP == nil {
			vICMS = fmt.Sprintf("%.2f", vbc*pICMS/100)
		}
	}
	builder.Total(&schema.Total{
		ICMSTot: &schema.ICMSTot{
			VBC: first.VBC, VICMS: vICMS, VICMSDeson: "0.00",
			VFCP: "0.00", VBCST: "0.00", VST: "0.00",
			VFCPST: "0.00", VFCPSTRet: "0.00",
			VProd: first.VProd, VPIS: first.VPIS, VCOFINS: first.VCOFINS,
			VNF: first.VProd,
		},
	})

	return builder.Build()
}

func ptrIfNonEmpty(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

