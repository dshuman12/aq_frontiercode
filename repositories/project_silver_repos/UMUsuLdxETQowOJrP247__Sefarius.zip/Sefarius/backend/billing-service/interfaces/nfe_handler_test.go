package interfaces_test

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/danfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
	"github.com/sefarius/billing-service/interfaces"
)

// newTestApp wires the full stack with in-memory implementations and
// returns the Fiber app + the underlying mock so tests can configure
// SEFAZ outcomes per scenario.
func newTestApp(t *testing.T) (*fiber.App, *sefaz.MockClient, nfe.NFeRepository) {
	t.Helper()

	cert, err := nfe.GenerateSelfSignedTest("handler-test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, mock, repo)
	handler := interfaces.NewNFeHandler(uc, repo, danfe.NewGenerator())

	app := fiber.New()
	api := app.Group("/api/nfe")
	api.Post("/", handler.EmitNFe)
	api.Get("/", handler.ListNFe)
	api.Get("/:chave", handler.GetNFe)
	api.Get("/:chave/xml", handler.GetNFeXML)
	api.Get("/:chave/danfe", handler.GetNFeDANFE)

	return app, mock, repo
}

// validRequestBody returns a JSON body that translates into a valid
// venda interna mod 55 NF-e — same fixture shape the unit-test layer
// uses for happy-path scenarios.
func validRequestBody() []byte {
	req := interfaces.EmitNFeRequest{
		Emit: interfaces.EmitterDTO{
			CNPJ: "05730928000145", XNome: "EMPRESA HTTP TESTE LTDA", IE: "1234567890", CRT: "3",
			XLgr: "AV TESTE", Nro: "100", XBairro: "CENTRO",
			CMun: "4314902", XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000000",
		},
		Dest: interfaces.RecipientDTO{
			CNPJ: "11444777000161", XNome: "CLIENTE HTTP TESTE LTDA",
			IndIEDest: "1", IE: "9876543210",
			XLgr: "RUA EXEMPLO", Nro: "200", XBairro: "BAIRRO",
			CMun: "4314902", XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000001",
		},
		Ide: interfaces.IdentificationDTO{
			CUF: "43", CNF: "12345678", NatOp: "VENDA DE MERCADORIA",
			Serie: "1", NNF: "100", DhEmi: "2026-05-06T10:00:00-03:00",
			TpNF: "1", IdDest: "1", CMunFG: "4314902",
			TpAmb: "2", FinNFe: "1", IndPres: "1",
		},
		Items: []interfaces.ItemDTO{{
			CProd: "001", XProd: "PRODUTO HTTP TESTE", NCM: "22021000", CFOP: "5102",
			UCom: "UN", QCom: "1.0000", VUnCom: "100.0000000000", VProd: "100.00",
			VBC: "100.00", PICMS: "18.00", VPIS: "1.65", VCOFINS: "7.60",
		}},
	}
	b, _ := json.Marshal(req)
	return b
}

// doRequest runs a request through the test Fiber app and returns the
// decoded JSON envelope plus the raw body for tests that need to
// inspect non-JSON responses (XML, PDF).
func doRequest(t *testing.T, app *fiber.App, method, path string, body []byte) (int, application.APIResponse, []byte) {
	t.Helper()
	var bodyReader io.Reader
	if body != nil {
		bodyReader = bytes.NewReader(body)
	}
	req := httptest.NewRequest(method, path, bodyReader)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	rawBody, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()

	var envelope application.APIResponse
	_ = json.Unmarshal(rawBody, &envelope)
	return resp.StatusCode, envelope, rawBody
}

func TestEmitNFeHTTP_HappyPath(t *testing.T) {
	app, _, repo := newTestApp(t)

	status, env, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	if status != fiber.StatusCreated {
		t.Fatalf("status = %d, want 201; envelope = %+v", status, env)
	}
	if !env.Success {
		t.Errorf("envelope.Success = false: error=%q", env.Error)
	}

	data, ok := env.Data.(map[string]any)
	if !ok {
		t.Fatalf("Data is not an object: %T", env.Data)
	}
	chave, _ := data["chave"].(string)
	if len(chave) != 44 {
		t.Errorf("chave = %q (len %d), want 44 digits", chave, len(chave))
	}
	if data["status"] != "AUTHORIZED" {
		t.Errorf("status = %v, want AUTHORIZED", data["status"])
	}
	if data["lifecycle"] != "AUTHORIZED" {
		t.Errorf("lifecycle = %v, want AUTHORIZED", data["lifecycle"])
	}

	// Persisted side-effect: repo holds the record.
	rec, err := repo.GetByChave(t.Context(), nfe.Chave(chave))
	if err != nil {
		t.Fatalf("repo.GetByChave after POST: %v", err)
	}
	if rec.Status != nfe.NFeStatusAuthorized {
		t.Errorf("persisted Status = %s, want AUTHORIZED", rec.Status)
	}
}

func TestEmitNFeHTTP_RejectsMalformedJSON(t *testing.T) {
	app, _, _ := newTestApp(t)
	status, env, _ := doRequest(t, app, "POST", "/api/nfe/", []byte(`{not json`))
	if status != fiber.StatusBadRequest {
		t.Errorf("status = %d, want 400", status)
	}
	if env.Success {
		t.Error("envelope.Success = true on malformed JSON")
	}
}

// TestEmitNFeHTTP_FiscalRejectionIs201WithRejectedPayload — a SEFAZ
// rejection is a *business outcome*, not an HTTP error. The handler
// returns 201 Created with the structured outcome so the client can
// branch on data.status. Reserving 4xx for malformed-request errors
// and 5xx for our bugs keeps the HTTP semantics clean.
func TestEmitNFeHTTP_FiscalRejectionIs201WithRejectedPayload(t *testing.T) {
	app, mock, _ := newTestApp(t)
	mock.QueueOutcome(&nfe.AuthorizationResult{
		Status:    nfe.AuthorizationStatusRejected,
		CStat:     "228",
		XMotivo:   "Rejeicao: Data de Emissao muito atrasada",
		Rejection: &nfe.Rejection{CStat: "228", XMotivo: "Rejeicao: Data de Emissao muito atrasada"},
	})

	// SEFAZ rejection comes back as a successful Emit with REJECTED
	// status — handler returns 201 with the structured outcome, not
	// 4xx. ValidationError (pre-Authorize) is what gets 422; SEFAZ
	// rejection is a 201-with-Rejected-payload.
	status, env, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	if status != fiber.StatusCreated {
		t.Fatalf("status = %d, want 201 (rejection is not an HTTP error)", status)
	}
	data := env.Data.(map[string]any)
	if data["status"] != "REJECTED" {
		t.Errorf("data.status = %v, want REJECTED", data["status"])
	}
	rejection := data["rejection"].(map[string]any)
	if rejection["CStat"] != "228" {
		t.Errorf("rejection.CStat = %v, want 228", rejection["CStat"])
	}
}

// TestEmitNFeHTTP_ValidationFailureIs422 — pre-Authorize validation
// errors (semantic, totals) get 422 with the issues list embedded so
// the client can highlight specific fields.
func TestEmitNFeHTTP_ValidationFailureIs422(t *testing.T) {
	app, _, _ := newTestApp(t)

	body := validRequestBody()
	// Sabotage the CRT to trip ValidateSemantic.
	body = bytes.Replace(body, []byte(`"crt":"3"`), []byte(`"crt":"9"`), 1)

	status, env, _ := doRequest(t, app, "POST", "/api/nfe/", body)
	if status != fiber.StatusUnprocessableEntity {
		t.Errorf("status = %d, want 422", status)
	}
	if env.Success {
		t.Error("envelope.Success = true for a validation failure")
	}
	if env.Error == "" {
		t.Error("envelope.Error empty for a validation failure")
	}
}

func TestEmitNFeHTTP_SefazUnreachableIs502(t *testing.T) {
	app, mock, _ := newTestApp(t)
	mock.FailWithError(nfe.ErrSefazUnreachable)

	status, _, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	if status != fiber.StatusBadGateway {
		t.Errorf("status = %d, want 502", status)
	}
}

func TestGetNFeHTTP_RetrievesPersistedRecord(t *testing.T) {
	app, _, _ := newTestApp(t)

	_, env, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	chave := env.Data.(map[string]any)["chave"].(string)

	status, getEnv, _ := doRequest(t, app, "GET", "/api/nfe/"+chave, nil)
	if status != fiber.StatusOK {
		t.Fatalf("GET status = %d, want 200", status)
	}
	got := getEnv.Data.(map[string]any)
	if got["chave"] != chave {
		t.Errorf("retrieved chave = %v, want %s", got["chave"], chave)
	}
	if got["lifecycle"] != "AUTHORIZED" {
		t.Errorf("lifecycle = %v, want AUTHORIZED", got["lifecycle"])
	}
}

func TestGetNFeHTTP_UnknownChaveIs404(t *testing.T) {
	app, _, _ := newTestApp(t)
	const noChave = "99999999999999999999999999999999999999999999"

	status, _, _ := doRequest(t, app, "GET", "/api/nfe/"+noChave, nil)
	if status != fiber.StatusNotFound {
		t.Errorf("status = %d, want 404", status)
	}
}

func TestListNFeHTTP_OrderedByRecency(t *testing.T) {
	app, _, _ := newTestApp(t)

	// Emit two with different nNF so the chaves differ.
	first := validRequestBody()
	_, _, _ = doRequest(t, app, "POST", "/api/nfe/", first)

	second := bytes.Replace(validRequestBody(), []byte(`"n_nf":"100"`), []byte(`"n_nf":"101"`), 1)
	_, _, _ = doRequest(t, app, "POST", "/api/nfe/", second)

	status, env, _ := doRequest(t, app, "GET", "/api/nfe/", nil)
	if status != fiber.StatusOK {
		t.Fatalf("status = %d, want 200", status)
	}
	// Response shape changed (2026-05-08) from a bare array to a
	// PaginatedResponse-shaped map with items/total/limit/offset so
	// the frontend can render numerical pagination. Old assertion was
	// `list := env.Data.([]any)`; new shape requires drilling through
	// the wrapper before counting.
	wrap := env.Data.(map[string]any)
	list := wrap["items"].([]any)
	if len(list) != 2 {
		t.Fatalf("List returned %d records, want 2", len(list))
	}
	if total, ok := wrap["total"].(float64); !ok || int(total) != 2 {
		t.Fatalf("Total = %v, want 2", wrap["total"])
	}
}

func TestGetNFeXML_ReturnsRawSignedBytes(t *testing.T) {
	app, _, _ := newTestApp(t)
	_, env, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	chave := env.Data.(map[string]any)["chave"].(string)

	req := httptest.NewRequest("GET", "/api/nfe/"+chave+"/xml", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}
	if ct := resp.Header.Get("Content-Type"); !strings.HasPrefix(ct, "application/xml") {
		t.Errorf("Content-Type = %s, want application/xml*", ct)
	}
	body, _ := io.ReadAll(resp.Body)
	if !bytes.Contains(body, []byte("<infNFe")) || !bytes.Contains(body, []byte("<ds:Signature")) {
		t.Error("response body missing infNFe or Signature; not a signed XML")
	}
}

func TestGetNFeDANFE_ReturnsPDF(t *testing.T) {
	app, _, _ := newTestApp(t)
	_, env, _ := doRequest(t, app, "POST", "/api/nfe/", validRequestBody())
	chave := env.Data.(map[string]any)["chave"].(string)

	req := httptest.NewRequest("GET", "/api/nfe/"+chave+"/danfe", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "application/pdf" {
		t.Errorf("Content-Type = %s, want application/pdf", ct)
	}
	body, _ := io.ReadAll(resp.Body)
	if !bytes.HasPrefix(body, []byte("%PDF-")) {
		t.Errorf("body does not start with %%PDF- magic: %x", body[:8])
	}
}
