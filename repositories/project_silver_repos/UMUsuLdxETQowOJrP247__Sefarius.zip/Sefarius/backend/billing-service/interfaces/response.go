package interfaces

import (
	"github.com/gofiber/fiber/v2"
	"github.com/sefarius/billing-service/application"
)

// ErrorResponse sends a standardized error response
func ErrorResponse(c *fiber.Ctx, statusCode int, message string) error {
	return c.Status(statusCode).JSON(application.APIResponse{
		Success: false,
		Error:   message,
		Code:    statusCode,
	})
}

// SuccessResponse sends a standardized success response
func SuccessResponse(c *fiber.Ctx, statusCode int, data interface{}) error {
	return c.Status(statusCode).JSON(application.APIResponse{
		Success: true,
		Data:    data,
		Code:    statusCode,
	})
}

// ParseAndValidate parses request body and returns error response if invalid
func ParseAndValidate(c *fiber.Ctx, req interface{}) error {
	if err := c.BodyParser(req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	return nil
}
