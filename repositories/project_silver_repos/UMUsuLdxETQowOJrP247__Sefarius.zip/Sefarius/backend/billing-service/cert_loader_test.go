package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	pkcs12 "software.sslmate.com/src/go-pkcs12"

	"github.com/sefarius/billing-service/domain/nfe"
)

// fakeEnv builds an envFunc that returns values from the given map and
// the provided default when a key is missing. Mirrors the contract of
// the real getEnv in main.go.
func fakeEnv(values map[string]string) envFunc {
	return func(key, defaultValue string) string {
		if v, ok := values[key]; ok {
			return v
		}
		return defaultValue
	}
}

// writeTestPFX encodes a *Certificate as a PKCS#12 blob using the modern
// PBES2+AES profile and writes it to a temp file. Returns the path. The
// fixture lives only for the duration of the test.
func writeTestPFX(t *testing.T, cert *nfe.Certificate, password string) string {
	t.Helper()
	// LegacyDES (3DES + SHA1 MAC) is the format real A1 ICP-Brasil PFX
	// files use and the only one the frozen golang.org/x/crypto/pkcs12
	// decoder can read. Modern2023 (PBES2 + SHA256) would round-trip via
	// sslmate's package but trip the frozen decoder we use in
	// production via nfe.LoadPFX.
	pfxBytes, err := pkcs12.LegacyDES.Encode(cert.PrivateKey, cert.X509, nil, password)
	if err != nil {
		t.Fatalf("pkcs12.Modern.Encode: %v", err)
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "test.pfx")
	if err := os.WriteFile(path, pfxBytes, 0o600); err != nil {
		t.Fatalf("os.WriteFile: %v", err)
	}
	return path
}

func TestLoadCertificate_DevMode_ReturnsSelfSigned(t *testing.T) {
	cert, isDev, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_DEV_MODE": "true",
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !isDev {
		t.Fatalf("expected isDev=true for dev cert")
	}
	if cert == nil || cert.X509 == nil {
		t.Fatal("expected non-nil cert")
	}
	if got := cert.X509.Subject.CommonName; got != "sefarius dev" {
		t.Fatalf("CommonName = %q, want %q", got, "sefarius dev")
	}
}

func TestLoadCertificate_ProdMode_ReturnsRealCert(t *testing.T) {
	source, err := nfe.GenerateSelfSignedTest("Sefarius Prod Test CN")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	pfxPath := writeTestPFX(t, source, "secret123")

	cert, isDev, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_CERT_PATH":     pfxPath,
		"NFE_CERT_PASSWORD": "secret123",
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if isDev {
		t.Fatalf("expected isDev=false when loading from PFX")
	}
	if cert == nil || cert.X509 == nil {
		t.Fatal("expected non-nil cert")
	}
	if got := cert.X509.Subject.CommonName; got != "Sefarius Prod Test CN" {
		t.Fatalf("CommonName = %q, want %q", got, "Sefarius Prod Test CN")
	}
}

func TestLoadCertificate_DevModeWinsWhenBothSet(t *testing.T) {
	source, err := nfe.GenerateSelfSignedTest("must-not-be-used")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	pfxPath := writeTestPFX(t, source, "secret123")

	cert, isDev, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_DEV_MODE":      "true",
		"NFE_CERT_PATH":     pfxPath,
		"NFE_CERT_PASSWORD": "secret123",
	}))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !isDev {
		t.Fatalf("expected isDev=true (NFE_DEV_MODE precedence)")
	}
	if got := cert.X509.Subject.CommonName; got != "sefarius dev" {
		t.Fatalf("expected dev cert; got CommonName %q", got)
	}
}

func TestLoadCertificate_NeitherSet_Errors(t *testing.T) {
	_, _, err := loadCertificate(fakeEnv(nil))
	if err == nil {
		t.Fatal("expected error when neither NFE_DEV_MODE nor NFE_CERT_PATH is set")
	}
	msg := err.Error()
	// The error must name BOTH escape hatches so an operator reading
	// the boot log knows which env var to add.
	if !strings.Contains(msg, "NFE_DEV_MODE") {
		t.Errorf("error must mention NFE_DEV_MODE; got %q", msg)
	}
	if !strings.Contains(msg, "NFE_CERT_PATH") {
		t.Errorf("error must mention NFE_CERT_PATH; got %q", msg)
	}
}

func TestLoadCertificate_DevModeWrongValue_FallsThroughToProdPath(t *testing.T) {
	// "1", "yes", "TRUE" — anything other than the literal "true" is
	// treated as not-dev. The same strict check shipped in 6934d5d to
	// keep production from ever silently using the dev cert.
	for _, v := range []string{"1", "yes", "TRUE", "True", " true"} {
		_, _, err := loadCertificate(fakeEnv(map[string]string{
			"NFE_DEV_MODE": v,
		}))
		if err == nil {
			t.Errorf("NFE_DEV_MODE=%q should NOT enable dev path", v)
		}
	}
}

func TestLoadCertificate_ProdMode_MissingPassword_Errors(t *testing.T) {
	_, _, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_CERT_PATH": "/tmp/whatever.pfx",
	}))
	if err == nil {
		t.Fatal("expected error when NFE_CERT_PATH set but password missing")
	}
	if !strings.Contains(err.Error(), "NFE_CERT_PASSWORD") {
		t.Errorf("error must name NFE_CERT_PASSWORD; got %q", err.Error())
	}
}

func TestLoadCertificate_ProdMode_MissingFile_Errors(t *testing.T) {
	missing := filepath.Join(t.TempDir(), "does-not-exist.pfx")
	_, _, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_CERT_PATH":     missing,
		"NFE_CERT_PASSWORD": "anything",
	}))
	if err == nil {
		t.Fatal("expected error when cert file does not exist")
	}
	if !strings.Contains(err.Error(), filepath.Base(missing)) {
		t.Errorf("error must include the bad path; got %q", err.Error())
	}
}

func TestLoadCertificate_ProdMode_WrongPassword_Errors(t *testing.T) {
	source, err := nfe.GenerateSelfSignedTest("test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	pfxPath := writeTestPFX(t, source, "correct-password")

	_, _, err = loadCertificate(fakeEnv(map[string]string{
		"NFE_CERT_PATH":     pfxPath,
		"NFE_CERT_PASSWORD": "wrong-password",
	}))
	if err == nil {
		t.Fatal("expected error when password does not match PFX")
	}
	// The wrapping message must include the path to help an operator
	// spot which file failed in a multi-cert deploy. Compare by basename
	// to avoid Windows path escaping mismatches with %q error wrapping.
	if !strings.Contains(err.Error(), filepath.Base(pfxPath)) {
		t.Errorf("error must include the cert path; got %q", err.Error())
	}
}

func TestLoadCertificate_ProdMode_CorruptFile_Errors(t *testing.T) {
	dir := t.TempDir()
	corrupt := filepath.Join(dir, "corrupt.pfx")
	if err := os.WriteFile(corrupt, []byte("this is not a PKCS#12 file"), 0o600); err != nil {
		t.Fatalf("os.WriteFile: %v", err)
	}

	_, _, err := loadCertificate(fakeEnv(map[string]string{
		"NFE_CERT_PATH":     corrupt,
		"NFE_CERT_PASSWORD": "irrelevant",
	}))
	if err == nil {
		t.Fatal("expected error decoding corrupt PFX bytes")
	}
}
