package domain

// Predefined billing domain errors
var (
	ErrInvoiceNotFound = &InvoiceError{
		Code:    "INVOICE_NOT_FOUND",
		Message: "invoice not found",
	}

	ErrIDRequired = &InvoiceError{
		Code:    "ID_REQUIRED",
		Message: "invoice id is required",
	}

	ErrIdempotencyKeyRequired = &InvoiceError{
		Code:    "IDEMPOTENCY_KEY_REQUIRED",
		Message: "idempotency key is required",
	}

	ErrCreatedByRequired = &InvoiceError{
		Code:    "CREATED_BY_REQUIRED",
		Message: "created_by is required",
	}

	ErrNoItems = &InvoiceError{
		Code:    "NO_ITEMS",
		Message: "invoice must have at least one item",
	}

	ErrInputNil = &InvoiceError{
		Code:    "INPUT_NIL",
		Message: "input cannot be nil",
	}

	ErrOnlyOpenCanCancel = &InvoiceError{
		Code:    "ONLY_OPEN_CAN_CANCEL",
		Message: "can only cancel open invoices",
	}
)

// IsInvoiceError checks if an error is a specific billing domain error
func IsInvoiceError(err error, target *InvoiceError) bool {
	ie, ok := err.(*InvoiceError)
	if !ok {
		return false
	}
	return ie.Code == target.Code
}

// Pagination constants
const (
	DefaultPageLimit = 20
	MaxPageLimit     = 100
)
