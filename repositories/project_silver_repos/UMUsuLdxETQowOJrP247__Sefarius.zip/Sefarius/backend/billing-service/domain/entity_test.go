package domain

import (
	"testing"
)

func TestInvoice_SubtotalAmount(t *testing.T) {
	invoice := &Invoice{
		Items: []*InvoiceItem{
			{Quantity: 2, UnitPrice: 10.0},
			{Quantity: 1, UnitPrice: 5.0},
		},
	}

	expectedSubtotal := 25.0
	if result := invoice.SubtotalAmount(); result != expectedSubtotal {
		t.Errorf("Expected subtotal %f, got %f", expectedSubtotal, result)
	}
}

func TestInvoice_CalculateTax(t *testing.T) {
	invoice := &Invoice{
		Items: []*InvoiceItem{
			{Quantity: 2, UnitPrice: 50.0},
		},
		TaxRate: 10.0,
	}

	invoice.CalculateTax()
	expectedTax := 10.0
	if invoice.TaxAmount != expectedTax {
		t.Errorf("Expected tax amount %f, got %f", expectedTax, invoice.TaxAmount)
	}

	expectedTotal := 110.0
	if result := invoice.TotalAmount(); result != expectedTotal {
		t.Errorf("Expected total %f, got %f", expectedTotal, result)
	}
}

func TestInvoice_CanBeClosed(t *testing.T) {
	invoice := &Invoice{Status: StatusOpen}
	if !invoice.CanBeClosed() {
		t.Error("Expected invoice to be closable")
	}

	invoice.Status = StatusClosed
	if invoice.CanBeClosed() {
		t.Error("Expected closed invoice not to be closable")
	}
}
