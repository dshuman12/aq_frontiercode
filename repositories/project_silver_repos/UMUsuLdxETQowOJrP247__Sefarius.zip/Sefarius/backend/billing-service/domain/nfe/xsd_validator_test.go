package nfe_test

import (
	"errors"
	"os"
	"os/exec"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
)

// xmllintAvailable reports whether the xmllint binary is resolvable.
// Used to skip XSD-dependent tests in dev environments without the tool
// (Windows, fresh containers); CI is expected to install it.
func xmllintAvailable(t *testing.T) bool {
	t.Helper()
	_, err := exec.LookPath("xmllint")
	return err == nil
}

func TestValidateXSD_ReportsMissingTool(t *testing.T) {
	if xmllintAvailable(t) {
		t.Skip("xmllint is in PATH; this test only verifies the not-installed code path")
	}
	err := nfe.ValidateXSD([]byte(`<x/>`), "schema/xsd/nfe_v4.00.xsd", "")
	if !errors.Is(err, nfe.ErrXmllintNotAvailable) {
		t.Errorf("err = %v, want ErrXmllintNotAvailable", err)
	}
}

// TestValidateXSD_FixtureValidatesAgainstSchema confirms the canonical
// procNFe fixture (a real signed NF-e from the sped-nfe upstream) passes
// XSD validation when the leiaute directory is on --path. This is the
// strongest evidence we have that ValidateXSD is wired correctly.
func TestValidateXSD_FixtureValidatesAgainstSchema(t *testing.T) {
	if !xmllintAvailable(t) {
		t.Skip("xmllint not in PATH; install libxml2-utils to run this test")
	}
	xmlBytes, err := os.ReadFile("schema/testdata/procNFe.xml")
	if err != nil {
		t.Fatalf("read fixture: %v", err)
	}
	err = nfe.ValidateXSD(xmlBytes,
		"schema/xsd/procNFe_v4.00.xsd",
		"schema/xsd")
	if err != nil {
		t.Errorf("expected procNFe.xml to validate against procNFe_v4.00.xsd: %v", err)
	}
}

func TestValidateXSD_RejectsInvalidXML(t *testing.T) {
	if !xmllintAvailable(t) {
		t.Skip("xmllint not in PATH")
	}
	// XML that parses but doesn't match the procNFe schema (wrong root).
	bogus := []byte(`<?xml version="1.0"?><wrongRoot/>`)
	err := nfe.ValidateXSD(bogus, "schema/xsd/procNFe_v4.00.xsd", "schema/xsd")
	if err == nil {
		t.Fatal("expected validation error, got nil")
	}
	if !strings.Contains(err.Error(), "XSD validation failed") {
		t.Errorf("err message = %q, want 'XSD validation failed' prefix", err.Error())
	}
}
