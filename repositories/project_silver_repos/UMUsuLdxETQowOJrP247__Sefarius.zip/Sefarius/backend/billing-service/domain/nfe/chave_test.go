package nfe

import (
	"errors"
	"strings"
	"testing"
	"time"
)

// chaveVectors holds NF-e access keys whose DV is verified to be correct.
// Sourced from public sped-nfe fixtures committed under
// domain/nfe/schema/{cce,evento}/testdata.
//
// Note: req_evento_cancela.xml and retEnviNFe.xml from the same upstream
// carry keys with malformed DVs (see TestChave_KnownInvalidFixtureDVs
// below) — likely artifacts of test data hand-edited without recomputing
// the check digit. Those are useful negative cases, not positive ones.
var chaveVectors = []struct {
	name  string
	chave Chave
	want  ChaveComponents
}{
	{
		name:  "CCe fixture (NF-e mod 55, SP, 2015)",
		chave: "35150300822602000124550010009923461099234656",
		want: ChaveComponents{
			CUF:    35,
			DhEmi:  time.Date(2015, 3, 1, 0, 0, 0, 0, time.UTC),
			CNPJ:   "00822602000124",
			Modelo: ModeloNFe,
			Serie:  1,
			NNF:    992346,
			TpEmis: TpEmisNormal,
			CNF:    "09923465",
		},
	},
	{
		name:  "Manifestacao fixture (NF-e mod 55, AM, 2016)",
		chave: "29161211351930000106550010000000151000000151",
		want: ChaveComponents{
			CUF:    29,
			DhEmi:  time.Date(2016, 12, 1, 0, 0, 0, 0, time.UTC),
			CNPJ:   "11351930000106",
			Modelo: ModeloNFe,
			Serie:  1,
			NNF:    15,
			TpEmis: TpEmisNormal,
			CNF:    "00000015",
		},
	},
	// The next two vectors exercise calcDV's "if dv >= 10 → 0" branch,
	// which the real-world fixtures above never hit (their DVs are 6 and 1).
	// Constructed by perturbing the CCe key's cNF until the módulo-11 sum
	// lands on 0 or 1 (DV would be 11 or 10 respectively, both clamped to 0).
	{
		name:  "synthetic — DV=0 via 11→0 branch (sum mod 11 == 0)",
		chave: "35150300822602000124550010009923461099234680",
		want: ChaveComponents{
			CUF:    35,
			DhEmi:  time.Date(2015, 3, 1, 0, 0, 0, 0, time.UTC),
			CNPJ:   "00822602000124",
			Modelo: ModeloNFe,
			Serie:  1,
			NNF:    992346,
			TpEmis: TpEmisNormal,
			CNF:    "09923468",
		},
	},
	{
		name:  "synthetic — DV=0 via 10→0 branch (sum mod 11 == 1)",
		chave: "35150300822602000124550010009923461299234650",
		want: ChaveComponents{
			CUF:    35,
			DhEmi:  time.Date(2015, 3, 1, 0, 0, 0, 0, time.UTC),
			CNPJ:   "00822602000124",
			Modelo: ModeloNFe,
			Serie:  1,
			NNF:    992346,
			TpEmis: TpEmisNormal,
			CNF:    "29923465",
		},
	},
}

func TestNewChave_KnownVectors(t *testing.T) {
	for _, tc := range chaveVectors {
		t.Run(tc.name, func(t *testing.T) {
			got, err := NewChave(tc.want)
			if err != nil {
				t.Fatalf("NewChave returned error: %v", err)
			}
			if got != tc.chave {
				t.Errorf("NewChave =\n  got:  %s\n  want: %s", got, tc.chave)
			}
		})
	}
}

func TestChave_Validate_KnownVectors(t *testing.T) {
	for _, tc := range chaveVectors {
		t.Run(tc.name, func(t *testing.T) {
			if err := tc.chave.Validate(); err != nil {
				t.Errorf("Validate failed for known-good key %s: %v", tc.chave, err)
			}
		})
	}
}

func TestChave_Decompose_KnownVectors(t *testing.T) {
	for _, tc := range chaveVectors {
		t.Run(tc.name, func(t *testing.T) {
			got, err := tc.chave.Decompose()
			if err != nil {
				t.Fatalf("Decompose returned error: %v", err)
			}
			if got.CUF != tc.want.CUF {
				t.Errorf("CUF: got %d, want %d", got.CUF, tc.want.CUF)
			}
			if got.AAMM != tc.want.DhEmi.Format("0601") {
				t.Errorf("AAMM: got %s, want %s", got.AAMM, tc.want.DhEmi.Format("0601"))
			}
			if got.CNPJ != tc.want.CNPJ {
				t.Errorf("CNPJ: got %s, want %s", got.CNPJ, tc.want.CNPJ)
			}
			if got.Modelo != tc.want.Modelo {
				t.Errorf("Modelo: got %s, want %s", got.Modelo, tc.want.Modelo)
			}
			if got.Serie != tc.want.Serie {
				t.Errorf("Serie: got %d, want %d", got.Serie, tc.want.Serie)
			}
			if got.NNF != tc.want.NNF {
				t.Errorf("NNF: got %d, want %d", got.NNF, tc.want.NNF)
			}
			if got.TpEmis != tc.want.TpEmis {
				t.Errorf("TpEmis: got %s, want %s", got.TpEmis, tc.want.TpEmis)
			}
			if got.CNF != tc.want.CNF {
				t.Errorf("CNF: got %s, want %s", got.CNF, tc.want.CNF)
			}
		})
	}
}

// TestChave_RoundTrip exercises the inverse: build a key, decompose it,
// build again from the decomposed parts, and confirm the result matches.
// Catches off-by-one errors in slice boundaries within Decompose.
func TestChave_RoundTrip(t *testing.T) {
	for _, tc := range chaveVectors {
		t.Run(tc.name, func(t *testing.T) {
			dec, err := tc.chave.Decompose()
			if err != nil {
				t.Fatalf("Decompose: %v", err)
			}

			year, _ := time.Parse("06", dec.AAMM[:2])
			month, _ := time.Parse("01", dec.AAMM[2:])
			rebuilt := ChaveComponents{
				CUF:    dec.CUF,
				DhEmi:  time.Date(year.Year(), month.Month(), 1, 0, 0, 0, 0, time.UTC),
				CNPJ:   dec.CNPJ,
				Modelo: dec.Modelo,
				Serie:  dec.Serie,
				NNF:    dec.NNF,
				TpEmis: dec.TpEmis,
				CNF:    dec.CNF,
			}
			got, err := NewChave(rebuilt)
			if err != nil {
				t.Fatalf("NewChave from decomposed: %v", err)
			}
			if got != tc.chave {
				t.Errorf("round-trip mismatch:\n  rebuilt: %s\n  want:    %s", got, tc.chave)
			}
		})
	}
}

func TestNewChave_Validation(t *testing.T) {
	base := chaveVectors[0].want // known-valid baseline

	tests := []struct {
		name    string
		mutate  func(*ChaveComponents)
		wantErr error
	}{
		{
			name:    "cUF below range",
			mutate:  func(c *ChaveComponents) { c.CUF = 9 },
			wantErr: ErrInvalidUF,
		},
		{
			name:    "cUF above range",
			mutate:  func(c *ChaveComponents) { c.CUF = 100 },
			wantErr: ErrInvalidUF,
		},
		{
			name:    "dhEmi zero",
			mutate:  func(c *ChaveComponents) { c.DhEmi = time.Time{} },
			wantErr: ErrInvalidDhEmi,
		},
		{
			name:    "CNPJ has separators",
			mutate:  func(c *ChaveComponents) { c.CNPJ = "00.822.602/0001-24" },
			wantErr: ErrInvalidCNPJ,
		},
		{
			name:    "CNPJ too short",
			mutate:  func(c *ChaveComponents) { c.CNPJ = "0082260200" },
			wantErr: ErrInvalidCNPJ,
		},
		{
			name:    "modelo unsupported",
			mutate:  func(c *ChaveComponents) { c.Modelo = Modelo("01") },
			wantErr: ErrInvalidModelo,
		},
		{
			name:    "serie negative",
			mutate:  func(c *ChaveComponents) { c.Serie = -1 },
			wantErr: ErrInvalidSerie,
		},
		{
			name:    "serie above 999",
			mutate:  func(c *ChaveComponents) { c.Serie = 1000 },
			wantErr: ErrInvalidSerie,
		},
		{
			name:    "nNF zero",
			mutate:  func(c *ChaveComponents) { c.NNF = 0 },
			wantErr: ErrInvalidNNF,
		},
		{
			name:    "tpEmis unsupported",
			mutate:  func(c *ChaveComponents) { c.TpEmis = TpEmis("8") },
			wantErr: ErrInvalidTpEmis,
		},
		{
			name:    "cNF too short",
			mutate:  func(c *ChaveComponents) { c.CNF = "1234567" },
			wantErr: ErrInvalidCNF,
		},
		{
			name:    "cNF non-numeric",
			mutate:  func(c *ChaveComponents) { c.CNF = "1234567A" },
			wantErr: ErrInvalidCNF,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := base
			tt.mutate(&c)
			_, err := NewChave(c)
			if !errors.Is(err, tt.wantErr) {
				t.Errorf("err = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

func TestChave_Validate_BadInputs(t *testing.T) {
	tests := []struct {
		name    string
		chave   Chave
		wantErr error
	}{
		{
			name:    "length 43",
			chave:   "3515030082260200012455001000992346109923465",
			wantErr: ErrInvalidChaveLength,
		},
		{
			name:    "length 45",
			chave:   "351503008226020001245500100099234610992346566",
			wantErr: ErrInvalidChaveLength,
		},
		{
			name:    "non-digit",
			chave:   "3515030082260200012455001000992346109923465A",
			wantErr: ErrInvalidChaveDigit,
		},
		{
			name:    "DV mismatch (last digit flipped)",
			chave:   "35150300822602000124550010009923461099234650",
			wantErr: ErrInvalidChaveDV,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.chave.Validate()
			if !errors.Is(err, tt.wantErr) {
				t.Errorf("err = %v, want %v", err, tt.wantErr)
			}
		})
	}
}

// TestCalcDV_KnownDV is a sanity check on the algorithm itself, decoupled
// from the rest of the API. Uses the body from chaveVectors[0].
func TestCalcDV_KnownDV(t *testing.T) {
	body := strings.TrimSuffix(string(chaveVectors[0].chave), "6")
	got := calcDV(body)
	if got != 6 {
		t.Errorf("calcDV(%s) = %d, want 6", body, got)
	}
}

// TestNewChave_TimezoneAffectsAAMM documents and locks in the timezone
// semantics of DhEmi. AAMM is derived from the instant in the time.Time's
// OWN location — the same physical moment in different zones yields
// different keys. This is intentional (the leiaute encodes "ano/mês de
// emissão" as observed at the issuing establishment) but it's a common
// foot-gun, so this test exists to prevent silent regression.
func TestNewChave_TimezoneAffectsAAMM(t *testing.T) {
	brt := time.FixedZone("BRT", -3*3600)
	// 2025-12-31 22:00 BRT == 2026-01-01 01:00 UTC (same instant, different
	// year/month). Pick a moment that straddles UTC midnight so AAMM diverges.
	tBRT := time.Date(2025, 12, 31, 22, 0, 0, 0, brt)
	tUTC := tBRT.UTC()

	base := ChaveComponents{
		CUF: 35, CNPJ: "00822602000124", Modelo: ModeloNFe,
		Serie: 1, NNF: 1, TpEmis: TpEmisNormal, CNF: "00000001",
	}
	a := base
	a.DhEmi = tBRT
	chaveBRT, err := NewChave(a)
	if err != nil {
		t.Fatalf("NewChave BRT: %v", err)
	}
	b := base
	b.DhEmi = tUTC
	chaveUTC, err := NewChave(b)
	if err != nil {
		t.Fatalf("NewChave UTC: %v", err)
	}
	if chaveBRT == chaveUTC {
		t.Fatal("expected different chaves; same instant in different zones must yield different AAMM")
	}

	decBRT, _ := chaveBRT.Decompose()
	decUTC, _ := chaveUTC.Decompose()
	if decBRT.AAMM != "2512" {
		t.Errorf("BRT AAMM = %q, want 2512 (dec/2025)", decBRT.AAMM)
	}
	if decUTC.AAMM != "2601" {
		t.Errorf("UTC AAMM = %q, want 2601 (jan/2026)", decUTC.AAMM)
	}
}

// TestChave_KnownInvalidFixtureDVs documents the two sped-nfe fixture keys
// whose declared DV does not match what módulo 11 would compute. These
// failures are not algorithm bugs — they are upstream artifacts of test
// data edited without recomputing the check digit (e.g. mod 55 → 65
// without bumping cDV). Locking them in as a negative test prevents
// future mistakes where someone copies these into a "known good" list.
func TestChave_KnownInvalidFixtureDVs(t *testing.T) {
	bad := []Chave{
		"35150300822602000124650010009923461099234656", // canc fixture (real DV would be 9)
		"43211105730928000145650010000002401717268120", // retEnviNFe fixture (real DV would be 9)
	}
	for _, c := range bad {
		t.Run(string(c), func(t *testing.T) {
			err := c.Validate()
			if !errors.Is(err, ErrInvalidChaveDV) {
				t.Errorf("expected ErrInvalidChaveDV, got %v", err)
			}
		})
	}
}
