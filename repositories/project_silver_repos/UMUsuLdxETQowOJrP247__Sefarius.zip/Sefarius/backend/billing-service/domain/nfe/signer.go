package nfe

import (
	"crypto"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"errors"
	"fmt"

	"github.com/beevik/etree"
	dsig "github.com/russellhaering/goxmldsig"
)

// ErrInfNFeMissing is returned by Sign when the input XML does not contain
// the required <infNFe> element.
var ErrInfNFeMissing = errors.New("nfe.Sign: <infNFe> element not found")

// ErrInfEventoMissing is returned by SignEvent when the input XML does
// not contain the required <infEvento> element. Cancel and CCe events
// share this error sentinel since their signature target is the same.
var ErrInfEventoMissing = errors.New("nfe.SignEvent: <infEvento> element not found")

// ErrSignatureMissing is returned by VerifySignature when the input XML
// has no <Signature> element to verify.
var ErrSignatureMissing = errors.New("nfe.VerifySignature: <Signature> element not found")

// ErrAlreadySigned is returned by Sign when the input XML already contains
// a <Signature> element. SEFAZ rejects an NF-e with two signatures, and
// silently appending a second one would mask a caller bug. Strip the
// existing signature first if re-signing is intentional.
var ErrAlreadySigned = errors.New("nfe.Sign: document already contains a <Signature>; strip it before re-signing")

// Sign computes a SEFAZ-compliant XMLDSig enveloped signature over the
// <infNFe> element of xmlBytes and returns the signed XML.
//
// The wire format follows leiaute v4.00 + the chain of legacy SEFAZ
// technical notes (NT2014.002 v1.20):
//
//   - Reference URI = "#" + value of infNFe@Id ("NFe" + 44-digit chave)
//   - Transforms: enveloped-signature + C14N 1.0 inclusive
//   - DigestMethod = SHA-1
//   - CanonicalizationMethod = C14N 1.0 inclusive (REC-xml-c14n-20010315)
//   - SignatureMethod = RSA-SHA1
//   - <Signature> placed as a sibling of <infNFe>, inside <NFe>
//   - <KeyInfo> embeds the X.509 certificate that owns the signing key
//
// SHA-1 is mandated by SEFAZ for backwards compatibility across all UF
// authorization servers — modernizing requires a coordinated leiaute bump
// nationwide. Do not "upgrade" to SHA-256 unless the leiaute itself does.
func Sign(xmlBytes []byte, cert *Certificate) ([]byte, error) {
	return signAtElement(xmlBytes, "//infNFe", ErrInfNFeMissing, cert)
}

// SignEvent computes a SEFAZ-compliant XMLDSig enveloped signature over
// the <infEvento> element of xmlBytes and returns the signed XML. Used
// by cancelamento (tpEvento 110111) and CCe (tpEvento 110110) — the
// signature parameters and placement are the same as Sign, only the
// signed-element XPath differs.
//
// The reference URI uses infEvento@Id, which the event builders set
// to "ID110111" + chave + "01" for cancel and "ID110110" + chave +
// formatted nSeqEvento for CCe.
func SignEvent(xmlBytes []byte, cert *Certificate) ([]byte, error) {
	return signAtElement(xmlBytes, "//infEvento", ErrInfEventoMissing, cert)
}

// signAtElement is the shared implementation. The caller picks which
// element to sign and which sentinel to return when it is missing —
// keeping public API errors stable across both Sign and SignEvent.
func signAtElement(xmlBytes []byte, xpath string, missingErr error, cert *Certificate) ([]byte, error) {
	if cert == nil || cert.PrivateKey == nil || cert.X509 == nil {
		return nil, errors.New("nfe.Sign: certificate is incomplete")
	}

	doc := etree.NewDocument()
	if err := doc.ReadFromBytes(xmlBytes); err != nil {
		return nil, fmt.Errorf("nfe.Sign: parse xml: %w", err)
	}

	target := doc.FindElement(xpath)
	if target == nil {
		return nil, missingErr
	}
	parent := target.Parent()
	if parent == nil {
		return nil, fmt.Errorf("nfe.Sign: %s has no parent", xpath)
	}
	if findSignatureElement(doc) != nil {
		return nil, ErrAlreadySigned
	}

	ctx := newSigningContext(cert)
	sig, err := ctx.ConstructSignature(target, true)
	if err != nil {
		return nil, fmt.Errorf("nfe.Sign: construct signature: %w", err)
	}
	parent.AddChild(sig)

	return doc.WriteToBytes()
}

// VerifySignature parses xmlBytes, locates the enveloped <Signature>, and
// validates the signed digest against the X.509 certificate embedded in
// the signature's <KeyInfo>. Returns nil on success.
//
// This is a self-contained verification useful for tests and for a
// post-signing sanity check before submitting to SEFAZ. It does NOT walk
// an ICP-Brasil chain — SEFAZ does that on receipt. The certificate
// embedded in the signature is treated as its own trust anchor.
func VerifySignature(xmlBytes []byte) error {
	return verifyAtElement(xmlBytes, "//infNFe", ErrInfNFeMissing)
}

// VerifyEventSignature is the cancel/CCe analogue of VerifySignature —
// it validates an enveloped signature that targets <infEvento>.
func VerifyEventSignature(xmlBytes []byte) error {
	return verifyAtElement(xmlBytes, "//infEvento", ErrInfEventoMissing)
}

func verifyAtElement(xmlBytes []byte, xpath string, missingErr error) error {
	doc := etree.NewDocument()
	if err := doc.ReadFromBytes(xmlBytes); err != nil {
		return fmt.Errorf("nfe.VerifySignature: parse xml: %w", err)
	}

	sigEl := findSignatureElement(doc)
	if sigEl == nil {
		return ErrSignatureMissing
	}
	certEl := findX509CertificateElement(sigEl)
	if certEl == nil {
		return errors.New("nfe.VerifySignature: <X509Certificate> missing from <KeyInfo>")
	}
	der, err := base64.StdEncoding.DecodeString(stripWhitespace(certEl.Text()))
	if err != nil {
		return fmt.Errorf("nfe.VerifySignature: decode embedded cert: %w", err)
	}
	cert, err := x509.ParseCertificate(der)
	if err != nil {
		return fmt.Errorf("nfe.VerifySignature: parse embedded cert: %w", err)
	}

	vctx := &dsig.ValidationContext{
		CertificateStore: &dsig.MemoryX509CertificateStore{
			Roots: []*x509.Certificate{cert},
		},
		IdAttribute: "Id",
	}

	view, err := buildValidationView(doc, xpath, missingErr)
	if err != nil {
		return fmt.Errorf("nfe.VerifySignature: %w", err)
	}
	if _, err := vctx.Validate(view); err != nil {
		return fmt.Errorf("nfe.VerifySignature: %w", err)
	}
	return nil
}

// buildValidationView returns an isolated etree.Element that goxmldsig
// can validate: a copy of the signed element (infNFe or infEvento) with
// the sibling <Signature> attached as the last child. The original
// document is untouched.
//
// Namespace contract: when the document declares a default namespace
// on its root (the SEFAZ-mandated form for NFe since sprint 1.10, and
// the same shape for events), the inherited xmlns is invisible to a
// copied subtree because etree.Copy does not pull ancestor declarations
// along. The signing-side C14N output, however, includes that xmlns
// inline since the parent is outside the canonicalized subtree. To make
// the validation-side canonical form match, we re-declare the inherited
// xmlns directly on the copied element — a no-op for unscoped documents
// and an equivalence-preserving rewrite for namespaced ones.
func buildValidationView(doc *etree.Document, xpath string, missingErr error) (*etree.Element, error) {
	target := doc.FindElement(xpath)
	if target == nil {
		return nil, missingErr
	}
	sig := findSignatureElement(doc)
	if sig == nil {
		return nil, ErrSignatureMissing
	}
	view := target.Copy()
	if ns := target.NamespaceURI(); ns != "" && view.SelectAttr("xmlns") == nil {
		view.CreateAttr("xmlns", ns)
	}
	view.AddChild(sig.Copy())
	return view, nil
}

func newSigningContext(cert *Certificate) *dsig.SigningContext {
	ctx := dsig.NewDefaultSigningContext(&certKeyStore{cert: cert})
	ctx.Hash = crypto.SHA1
	ctx.Canonicalizer = dsig.MakeC14N10RecCanonicalizer()
	ctx.IdAttribute = "Id"
	// SetSignatureMethod here is best-effort: the only error it can return
	// is "unsupported method", and RSA-SHA1 is hard-coded in the lib.
	_ = ctx.SetSignatureMethod(dsig.RSASHA1SignatureMethod)
	return ctx
}

// certKeyStore adapts our *Certificate to dsig.X509KeyStore.
type certKeyStore struct {
	cert *Certificate
}

func (k *certKeyStore) GetKeyPair() (*rsa.PrivateKey, []byte, error) {
	return k.cert.PrivateKey, k.cert.X509.Raw, nil
}

// findSignatureElement locates the XMLDSig <Signature> element regardless
// of whether the document uses the "ds:" prefix (goxmldsig output, also
// what SEFAZ tools commonly emit) or the unprefixed default-namespace form
// (also valid per the XMLDSig spec and accepted by SEFAZ).
func findSignatureElement(doc *etree.Document) *etree.Element {
	if el := doc.FindElement("//ds:Signature"); el != nil {
		return el
	}
	return doc.FindElement("//Signature")
}

// findX509CertificateElement is the same dual-lookup as findSignatureElement,
// scoped to the <KeyInfo> subtree of a Signature.
func findX509CertificateElement(sig *etree.Element) *etree.Element {
	if el := sig.FindElement(".//ds:X509Certificate"); el != nil {
		return el
	}
	return sig.FindElement(".//X509Certificate")
}

// stripWhitespace removes ASCII whitespace from a base64 string. PEM-style
// line breaks inside <X509Certificate> are valid per the spec but base64
// decoders reject them.
func stripWhitespace(s string) string {
	out := make([]byte, 0, len(s))
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == ' ' || c == '\n' || c == '\r' || c == '\t' {
			continue
		}
		out = append(out, c)
	}
	return string(out)
}
