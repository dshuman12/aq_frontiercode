package nfe

import (
	"math/big"
	"testing"
)

// formatDecimal and parseDecimal are package-private; tested directly here
// (in-package _test.go file with same package name) so the helpers can be
// exercised without going through the public calculators.

func TestFormatDecimal(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		decimals int
		want     string
	}{
		{"integer to 2 decimals", "100", 2, "100.00"},
		{"already 2 decimals", "100.00", 2, "100.00"},
		{"truncate to 2 decimals (no round)", "100.001", 2, "100.00"},
		{"round half-up at 2 decimals", "100.005", 2, "100.01"},
		{"round half-up exceeds carry", "0.995", 2, "1.00"},
		{"round half-up at 4 decimals", "1.23445", 4, "1.2345"},
		{"banker's rounding would differ — 0.5 to 0 decimals", "0.5", 0, "1"},
		{"banker's rounding would differ — 2.5 to 0 decimals", "2.5", 0, "3"},
		{"negative half-up rounds away from zero", "-0.005", 2, "-0.01"},
		{"zero padding when value < 1", "0.05", 2, "0.05"},
		{"zero padding when value < 0.1 with 4 decimals", "0.0001", 4, "0.0001"},
		{"trailing zeros at 4 decimals", "18", 4, "18.0000"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, ok := new(big.Rat).SetString(tt.input)
			if !ok {
				t.Fatalf("could not parse %q", tt.input)
			}
			got := formatDecimal(r, tt.decimals)
			if got != tt.want {
				t.Errorf("formatDecimal(%s, %d) = %q, want %q",
					tt.input, tt.decimals, got, tt.want)
			}
		})
	}
}

func TestParseDecimal(t *testing.T) {
	r, err := parseDecimal("100.50")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if formatDecimal(r, 2) != "100.50" {
		t.Errorf("roundtrip failed: %q", formatDecimal(r, 2))
	}

	if _, err := parseDecimal("not a number"); err == nil {
		t.Error("expected error for invalid input")
	}
}

func TestICMSNormalCST00_Computation(t *testing.T) {
	tests := []struct {
		name      string
		vBC       string
		pICMS     string
		wantVBC   string
		wantPICMS string
		wantVICMS string
	}{
		{
			name: "happy path 100×18%", vBC: "100.00", pICMS: "18.00",
			wantVBC: "100.00", wantPICMS: "18.0000", wantVICMS: "18.00",
		},
		{
			name: "rounding required", vBC: "1234.56", pICMS: "17.00",
			wantVBC: "1234.56", wantPICMS: "17.0000", wantVICMS: "209.88", // 209.8752 → 209.88
		},
		{
			name: "zero base", vBC: "0", pICMS: "18.00",
			wantVBC: "0.00", wantPICMS: "18.0000", wantVICMS: "0.00",
		},
		{
			name: "zero rate", vBC: "100", pICMS: "0",
			wantVBC: "100.00", wantPICMS: "0.0000", wantVICMS: "0.00",
		},
		{
			name: "rate at 100", vBC: "50.00", pICMS: "100",
			wantVBC: "50.00", wantPICMS: "100.0000", wantVICMS: "50.00",
		},
		{
			name: "input with 4-decimal rate", vBC: "100.00", pICMS: "17.5000",
			wantVBC: "100.00", wantPICMS: "17.5000", wantVICMS: "17.50",
		},
		{
			name: "0.005 forces half-up rounding", vBC: "10.00", pICMS: "0.05",
			wantVBC: "10.00", wantPICMS: "0.0500", wantVICMS: "0.01", // 10 × 0.05 / 100 = 0.005 → 0.01
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			icms, err := ICMSNormalCST00(tt.vBC, tt.pICMS)
			if err != nil {
				t.Fatalf("err = %v", err)
			}
			if *icms.Orig != "0" {
				t.Errorf("Orig = %q, want 0", *icms.Orig)
			}
			if *icms.CST != "00" {
				t.Errorf("CST = %q, want 00", *icms.CST)
			}
			if *icms.ModBC != "3" {
				t.Errorf("ModBC = %q, want 3", *icms.ModBC)
			}
			if *icms.VBC != tt.wantVBC {
				t.Errorf("VBC = %q, want %q", *icms.VBC, tt.wantVBC)
			}
			if *icms.PICMS != tt.wantPICMS {
				t.Errorf("PICMS = %q, want %q", *icms.PICMS, tt.wantPICMS)
			}
			if *icms.VICMS != tt.wantVICMS {
				t.Errorf("VICMS = %q, want %q", *icms.VICMS, tt.wantVICMS)
			}
		})
	}
}

func TestICMSNormalCST00_Validation(t *testing.T) {
	tests := []struct {
		name        string
		vBC, pICMS  string
		wantSubstr  string
	}{
		{"vBC malformed", "abc", "18.00", "vBC"},
		{"vBC negative", "-1.00", "18.00", "negativa"},
		{"pICMS malformed", "100.00", "xx", "pICMS"},
		{"pICMS negative", "100.00", "-1.00", "negativa"},
		{"pICMS over 100", "100.00", "101.00", "excede"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := ICMSNormalCST00(tt.vBC, tt.pICMS)
			if err == nil {
				t.Fatal("expected error, got nil")
			}
			if !contains(err.Error(), tt.wantSubstr) {
				t.Errorf("err = %v, want substring %q", err, tt.wantSubstr)
			}
		})
	}
}

func TestPISAliq01(t *testing.T) {
	pis, err := PISAliq01("1000.00", "1.65")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if *pis.CST != "01" {
		t.Errorf("CST = %q", *pis.CST)
	}
	if *pis.VBC != "1000.00" {
		t.Errorf("VBC = %q", *pis.VBC)
	}
	if *pis.PPIS != "1.6500" {
		t.Errorf("PPIS = %q", *pis.PPIS)
	}
	if *pis.VPIS != "16.50" {
		t.Errorf("VPIS = %q, want 16.50", *pis.VPIS)
	}
}

func TestCOFINSAliq01(t *testing.T) {
	cofins, err := COFINSAliq01("1000.00", "7.60")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if *cofins.CST != "01" {
		t.Errorf("CST = %q", *cofins.CST)
	}
	if *cofins.VBC != "1000.00" {
		t.Errorf("VBC = %q", *cofins.VBC)
	}
	if *cofins.PCOFINS != "7.6000" {
		t.Errorf("PCOFINS = %q", *cofins.PCOFINS)
	}
	if *cofins.VCOFINS != "76.00" {
		t.Errorf("VCOFINS = %q, want 76.00", *cofins.VCOFINS)
	}
}

// TestCalculadoras_ReproduceRealSEFAZ verifies that the calculator outputs
// match values that the actual SEFAZ produced for a real NF-e — item 1
// of schema/testdata/nfe_v4.xml. These vectors are independently
// generated (by SEFAZ + the issuing ERP), so they catch arithmetic bugs
// that test cases derived from manual mental math would miss.
//
// Note that the real fixture has separate vBC for ICMS (40.79, includes
// freight) and PIS/COFINS (33.45, excludes freight). The per-block
// calculators are tested with each correct vBC; the facade test is
// covered separately by TestFacades_RoundtripViaXML.
func TestCalculadoras_ReproduceRealSEFAZ(t *testing.T) {
	t.Run("ICMS00 vBC=40.79 pICMS=12.00 -> vICMS=4.89", func(t *testing.T) {
		icms, err := ICMSNormalCST00("40.79", "12.00")
		if err != nil {
			t.Fatalf("err = %v", err)
		}
		if *icms.VICMS != "4.89" {
			t.Errorf("vICMS = %q, want 4.89 (per nfe_v4.xml item 1)", *icms.VICMS)
		}
	})
	t.Run("PIS01 vBC=33.45 pPIS=1.65 -> vPIS=0.55", func(t *testing.T) {
		pis, err := PISAliq01("33.45", "1.65")
		if err != nil {
			t.Fatalf("err = %v", err)
		}
		if *pis.VPIS != "0.55" {
			t.Errorf("vPIS = %q, want 0.55 (per nfe_v4.xml item 1)", *pis.VPIS)
		}
	})
	t.Run("COFINS01 vBC=33.45 pCOFINS=7.60 -> vCOFINS=2.54", func(t *testing.T) {
		cofins, err := COFINSAliq01("33.45", "7.60")
		if err != nil {
			t.Fatalf("err = %v", err)
		}
		if *cofins.VCOFINS != "2.54" {
			t.Errorf("vCOFINS = %q, want 2.54 (per nfe_v4.xml item 1)", *cofins.VCOFINS)
		}
	})
}

func TestICMSSimplesCSOSN102(t *testing.T) {
	t.Run("happy path origem 0", func(t *testing.T) {
		icms, err := ICMSSimplesCSOSN102("0")
		if err != nil {
			t.Fatalf("err = %v", err)
		}
		if *icms.Orig != "0" {
			t.Errorf("Orig = %q", *icms.Orig)
		}
		if *icms.CSOSN != "102" {
			t.Errorf("CSOSN = %q, want 102", *icms.CSOSN)
		}
	})
	t.Run("non-default origem", func(t *testing.T) {
		icms, err := ICMSSimplesCSOSN102("3")
		if err != nil {
			t.Fatalf("err = %v", err)
		}
		if *icms.Orig != "3" {
			t.Errorf("Orig = %q", *icms.Orig)
		}
	})
	t.Run("invalid origem", func(t *testing.T) {
		_, err := ICMSSimplesCSOSN102("9")
		if err == nil {
			t.Fatal("expected error for orig=9")
		}
	})
}

func TestICMSNormalCST40(t *testing.T) {
	icms, err := ICMSNormalCST40("0")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if *icms.CST != "40" {
		t.Errorf("CST = %q, want 40", *icms.CST)
	}
	if *icms.Orig != "0" {
		t.Errorf("Orig = %q", *icms.Orig)
	}
	if icms.VICMSDeson != nil {
		t.Errorf("VICMSDeson should be nil for non-desonerada CST 40")
	}

	if _, err := ICMSNormalCST40("9"); err == nil {
		t.Error("expected error for invalid orig")
	}
}

func TestICMSSimplesCSOSN400(t *testing.T) {
	icms, err := ICMSSimplesCSOSN400("0")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if *icms.CSOSN != "400" {
		t.Errorf("CSOSN = %q, want 400", *icms.CSOSN)
	}
	if *icms.Orig != "0" {
		t.Errorf("Orig = %q", *icms.Orig)
	}
}

func TestPISCST49_Zeroed(t *testing.T) {
	pis := PISCST49()
	if *pis.CST != "49" {
		t.Errorf("CST = %q, want 49", *pis.CST)
	}
	if *pis.VBC != "0.00" {
		t.Errorf("VBC = %q", *pis.VBC)
	}
	if *pis.PPIS != "0.0000" {
		t.Errorf("PPIS = %q", *pis.PPIS)
	}
	if *pis.VPIS != "0.00" {
		t.Errorf("VPIS = %q", *pis.VPIS)
	}
}

func TestCOFINSCST49_Zeroed(t *testing.T) {
	cofins := COFINSCST49()
	if *cofins.CST != "49" {
		t.Errorf("CST = %q, want 49", *cofins.CST)
	}
	if *cofins.VBC != "0.00" {
		t.Errorf("VBC = %q", *cofins.VBC)
	}
	if *cofins.PCOFINS != "0.0000" {
		t.Errorf("PCOFINS = %q", *cofins.PCOFINS)
	}
	if *cofins.VCOFINS != "0.00" {
		t.Errorf("VCOFINS = %q", *cofins.VCOFINS)
	}
}

// contains is a tiny strings.Contains shim so this file doesn't import
// "strings" just for one substring check.
func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
