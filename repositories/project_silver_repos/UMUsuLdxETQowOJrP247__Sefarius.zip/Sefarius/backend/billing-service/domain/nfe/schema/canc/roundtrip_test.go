package canc

import (
	"testing"

	"github.com/sefarius/billing-service/internal/xmltest"
)

func TestUnmarshalEnvEvento_Cancela(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_cancela.xml")
	var env TEnvEvento
	xmltest.UnmarshalElement(t, data, "envEvento", &env)

	if env.VersaoAttr != "1.00" {
		t.Errorf("versao = %q, want 1.00", env.VersaoAttr)
	}
	if env.IdLote != "201711170826540" {
		t.Errorf("idLote = %q", env.IdLote)
	}
	if len(env.Evento) != 1 {
		t.Fatalf("expected 1 evento, got %d", len(env.Evento))
	}
	ev := env.Evento[0]
	if ev.InfEvento == nil {
		t.Fatal("infEvento nil")
	}
	if ev.InfEvento.TpEvento != "110111" {
		t.Errorf("tpEvento = %q, want 110111 (Cancelamento)", ev.InfEvento.TpEvento)
	}
}

func TestRoundtripEnvEvento_Cancela(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_cancela.xml")
	var s1, s2 TEnvEvento
	xmltest.AssertIdempotent(t, data, "envEvento", &s1, &s2)
}
