package nfe

import (
	"context"
	"errors"
	"time"
)

// SefazClient is the port through which the application layer talks
// to SEFAZ. The real implementation (sprint future) speaks SOAP against
// the per-UF NFeAutorizacao4 + NFeRecepcaoEvento webservices; the mock
// in infrastructure/sefaz returns canned receipts for development and
// tests. Both implementations satisfy this interface so callers can
// swap them at composition time.
//
// Sprint 1.6 introduced Authorize. Sprint 2.1 added Cancel and SendCCe
// — both submit a signed event envelope to the same SEFAZ endpoint
// (recepção de eventos), but their wire-level tpEvento and the shape
// of the body differ enough that separate methods keep the use-case
// surface tighter than a generic SubmitEvent(tpEvento, xml) would.
//
// CheckStatus, manifestação destinatário, EPEC, and inutilização are
// deliberately still out of scope.
type SefazClient interface {
	Authorize(ctx context.Context, signedXML []byte) (*AuthorizationResult, error)
	Cancel(ctx context.Context, signedEventXML []byte) (*EventResult, error)
	SendCCe(ctx context.Context, signedEventXML []byte) (*EventResult, error)
}

// AuthorizationResult is the structured return of SefazClient.Authorize.
//
// Field population by Status:
//
//	AUTHORIZED          Protocol set,    Rejection nil
//	DUPLICATE           Protocol set    (echoes the prior submission's protocol)
//	REJECTED            Protocol nil,    Rejection set
//	SERVICE_UNAVAILABLE both nil        (no fiscal outcome was reached)
//
// SEFAZ returns a numeric cStat code on every response. Callers branch on
// AuthorizationStatus rather than parsing cStat directly so they don't
// have to memorize all 700+ codes — but the raw CStat + XMotivo are
// preserved for logging and for correlating support tickets with SEFAZ
// rejection messages.
type AuthorizationResult struct {
	Status    AuthorizationStatus
	CStat     string     // raw SEFAZ status code (e.g. "100" = authorized, "539" = duplicate)
	XMotivo   string     // human-readable reason from SEFAZ
	Protocol  *Protocol  // see Status table above
	Rejection *Rejection // see Status table above
}

// AuthorizationStatus is the coarse-grained outcome of an authorization
// attempt. It collapses the dozens of SEFAZ cStat codes into the four
// branches that callers actually need to handle differently.
type AuthorizationStatus string

const (
	// AuthorizationStatusAuthorized — NF-e was authorized for use.
	// Result.Protocol holds the wire-level protocol receipt.
	AuthorizationStatusAuthorized AuthorizationStatus = "AUTHORIZED"

	// AuthorizationStatusRejected — NF-e was rejected for a content
	// or schema reason. Result.Rejection holds the diagnosis. The
	// document MUST NOT be re-submitted unchanged.
	AuthorizationStatusRejected AuthorizationStatus = "REJECTED"

	// AuthorizationStatusDuplicate — NF-e is already authorized
	// (typical cStat 539 / 204). The protocol of the prior submission
	// is returned in Result.Protocol so callers can recover idempotently
	// instead of treating this as an error.
	AuthorizationStatusDuplicate AuthorizationStatus = "DUPLICATE"

	// AuthorizationStatusServiceUnavailable — SEFAZ infra is unreachable
	// or returned a 5xx-equivalent cStat (108, 109, 110). Caller should
	// retry with backoff or queue for asynchronous re-submission.
	AuthorizationStatusServiceUnavailable AuthorizationStatus = "SERVICE_UNAVAILABLE"
)

// Protocol is the authorization receipt emitted by SEFAZ. It corresponds
// to the <protNFe><infProt> block in the response XML. The protocol must
// be persisted alongside the signed NF-e — together they form the
// "procNFe" file that is the legally valid fiscal document.
type Protocol struct {
	NProt    string    // protocol number assigned by SEFAZ
	DhRecbto time.Time // SEFAZ-side receipt timestamp
	ChNFe    string    // 44-digit chave (echoed for cross-check)
	DigVal   string    // base64 digest of the authorized infNFe
	CStat    string    // status code (always 100 for an authorized NF-e)
	XMotivo  string    // status motive (always "Autorizado o uso da NF-e" etc.)
	TpAmb    string    // environment: "1"=production, "2"=homologation
}

// Rejection is the structured form of a SEFAZ refusal. SEFAZ returns one
// rejection per NF-e — there is no batch/partial mode at this layer.
//
// The rejection codes are stable across UFs and documented in the
// "Manual de Orientação do Contribuinte" annex. Common ones:
//
//   - 215: Reference URI does not match infNFe Id
//   - 220: NF-e issued more than 30 days ago
//   - 252: Production environment but tpAmb=2
//   - 539: Duplicate (handled separately as Duplicate status)
type Rejection struct {
	CStat   string // numeric rejection code
	XMotivo string // human-readable reason
}

// ErrSefazUnreachable is returned by SefazClient when the SEFAZ
// endpoint is not reachable or the response is malformed beyond
// recovery. Distinct from a structured rejection — wrap or branch on
// errors.Is to distinguish transport failures from fiscal rejections.
var ErrSefazUnreachable = errors.New("SEFAZ endpoint unreachable")
