package cce

import (
	"testing"

	"github.com/sefarius/billing-service/internal/xmltest"
)

func TestUnmarshalEnvEvento_CCe(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_cce.xml")
	var env TEnvEvento
	xmltest.UnmarshalElement(t, data, "envEvento", &env)

	if env.VersaoAttr != "1.00" {
		t.Errorf("versao = %q, want 1.00", env.VersaoAttr)
	}
	if env.IdLote != "201705171838471" {
		t.Errorf("idLote = %q, want 201705171838471", env.IdLote)
	}
	if len(env.Evento) != 1 {
		t.Fatalf("expected 1 evento, got %d", len(env.Evento))
	}
	ev := env.Evento[0]
	if ev.InfEvento == nil {
		t.Fatal("infEvento nil")
	}
	if ev.InfEvento.TpEvento != "110110" {
		t.Errorf("tpEvento = %q, want 110110 (CCe)", ev.InfEvento.TpEvento)
	}
	if ev.InfEvento.DetEvento == nil {
		t.Fatal("detEvento nil")
	}
}

func TestRoundtripEnvEvento_CCe(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_cce.xml")
	var s1, s2 TEnvEvento
	xmltest.AssertIdempotent(t, data, "envEvento", &s1, &s2)
}
