package nfe

import (
	"fmt"
	"math/big"
	"strings"

	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// Severity classifies a validation finding. Errors block emission;
// Warnings are informational (caller decides whether to gate on them).
type Severity string

const (
	SeverityError   Severity = "error"
	SeverityWarning Severity = "warning"
)

// ValidationIssue is a single finding from a validator. Field uses dotted
// path notation matching the leiaute layout — e.g. "ide.cUF" or
// "det[2].prod.CFOP" — so messages are unambiguous in NF-e with hundreds
// of fields.
//
// JSON tags use lowercase to follow web conventions and match the
// frontend's expected shape. Without these tags, encoding/json defaults
// to the Go field name (PascalCase) and the frontend reads "?: (sem
// mensagem)" because it expects lowercase keys — see emit-component
// formatHttpError contract test.
type ValidationIssue struct {
	Severity Severity `json:"severity"`
	Field    string   `json:"field"`
	Message  string   `json:"message"`
}

func (i ValidationIssue) String() string {
	return fmt.Sprintf("[%s] %s: %s", i.Severity, i.Field, i.Message)
}

// ValidateSemantic walks the assembled NF-e and returns all cross-block
// consistency findings. The validator does not stop at the first error —
// caller gets the complete picture in one pass.
//
// Coverage (sprint 1.4 step 1):
//   - ide.cUF must match the IBGE code of emit.enderEmit.UF
//   - ide.idDest must agree with emit/dest UFs (interna/interestadual/exterior)
//   - emit.CRT in {1,2,3,4}
//   - ide.mod in {55, 65}
//   - det[].prod.CFOP family coherent with ide.tpNF + ide.idDest
//
// Total ↔ items reconciliation (step 2) and XSD validation (step 3) live
// in separate functions. Caller can compose them as needed.
func ValidateSemantic(nfe *schema.TNFe) []ValidationIssue {
	if nfe == nil || nfe.InfNFe == nil {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "infNFe",
			Message:  "infNFe is nil",
		}}
	}

	inf := nfe.InfNFe
	var issues []ValidationIssue
	issues = append(issues, validateChaveConsistency(inf)...)
	issues = append(issues, validateCUFMatchesEmit(inf)...)
	issues = append(issues, validateCMunPrefixesUF(inf)...)
	issues = append(issues, validateIdDestMatchesUFs(inf)...)
	issues = append(issues, validateCRT(inf)...)
	issues = append(issues, validateModelo(inf)...)
	issues = append(issues, validateCFOPFamily(inf)...)
	return issues
}

// validateChaveConsistency confirms the 44-digit access key embedded in
// infNFe.Id is well-formed AND that its components match what the rest of
// the document declares (cUF, AAMM via dhEmi, CNPJ, mod, serie, nNF,
// tpEmis, cNF, plus ide.cDV being the last digit). The chave is the
// central invariant the Builder establishes — anyone tampering with the
// document afterwards leaves a fingerprint here.
func validateChaveConsistency(inf *schema.InfNFe) []ValidationIssue {
	var issues []ValidationIssue
	if inf.IdAttr == "" {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "infNFe.Id",
			Message:  "Id ausente",
		}}
	}
	if !strings.HasPrefix(inf.IdAttr, "NFe") {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "infNFe.Id",
			Message:  fmt.Sprintf("Id deve ter prefixo 'NFe'; got %q", inf.IdAttr),
		}}
	}
	chave := Chave(strings.TrimPrefix(inf.IdAttr, "NFe"))
	if err := chave.Validate(); err != nil {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "infNFe.Id",
			Message:  fmt.Sprintf("chave inválida: %v", err),
		}}
	}

	dec, err := chave.Decompose()
	if err != nil {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "infNFe.Id",
			Message:  fmt.Sprintf("decompose: %v", err),
		}}
	}

	if inf.Ide != nil {
		if inf.Ide.CDV != "" && inf.Ide.CDV != fmt.Sprintf("%d", dec.DV) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.cDV",
				Message: fmt.Sprintf("ide.cDV=%q não casa com último dígito da chave (%d)",
					inf.Ide.CDV, dec.DV),
			})
		}
		if inf.Ide.CUF != "" && inf.Ide.CUF != fmt.Sprintf("%02d", dec.CUF) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.cUF",
				Message: fmt.Sprintf("ide.cUF=%q não casa com chave[0:2]=%02d",
					inf.Ide.CUF, dec.CUF),
			})
		}
		if inf.Ide.Mod != "" && inf.Ide.Mod != string(dec.Modelo) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.mod",
				Message: fmt.Sprintf("ide.mod=%q não casa com chave (%s)",
					inf.Ide.Mod, dec.Modelo),
			})
		}
		if inf.Ide.Serie != "" && !numEqualsString(dec.Serie, inf.Ide.Serie) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.serie",
				Message: fmt.Sprintf("ide.serie=%q não casa com chave (%d)",
					inf.Ide.Serie, dec.Serie),
			})
		}
		if inf.Ide.NNF != "" && !numEqualsString(dec.NNF, inf.Ide.NNF) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.nNF",
				Message: fmt.Sprintf("ide.nNF=%q não casa com chave (%d)",
					inf.Ide.NNF, dec.NNF),
			})
		}
		if inf.Ide.TpEmis != "" && inf.Ide.TpEmis != string(dec.TpEmis) {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.tpEmis",
				Message: fmt.Sprintf("ide.tpEmis=%q não casa com chave (%s)",
					inf.Ide.TpEmis, dec.TpEmis),
			})
		}
		if inf.Ide.CNF != "" && inf.Ide.CNF != dec.CNF {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.cNF",
				Message: fmt.Sprintf("ide.cNF=%q não casa com chave (%s)",
					inf.Ide.CNF, dec.CNF),
			})
		}
	}

	if inf.Emit != nil && inf.Emit.CNPJ != nil && *inf.Emit.CNPJ != dec.CNPJ {
		issues = append(issues, ValidationIssue{
			Severity: SeverityError,
			Field:    "emit.CNPJ",
			Message: fmt.Sprintf("emit.CNPJ=%q não casa com chave (%s)",
				*inf.Emit.CNPJ, dec.CNPJ),
		})
	}

	return issues
}

// numEqualsString compares an int to a numeric-string ignoring leading
// zeros — "001" equals 1, "0" equals 0, etc.
func numEqualsString(n int, s string) bool {
	return fmt.Sprintf("%d", n) == strings.TrimLeft(s, "0") ||
		(n == 0 && strings.TrimLeft(s, "0") == "")
}

// ufCodeToSigla maps IBGE UF codes (cUF, 2 digits) to two-letter UF sigla.
// Source: tabela IBGE oficial (códigos de UF). 27 unidades federativas.
var ufCodeToSigla = map[string]string{
	"11": "RO", "12": "AC", "13": "AM", "14": "RR", "15": "PA",
	"16": "AP", "17": "TO", "21": "MA", "22": "PI", "23": "CE",
	"24": "RN", "25": "PB", "26": "PE", "27": "AL", "28": "SE",
	"29": "BA", "31": "MG", "32": "ES", "33": "RJ", "35": "SP",
	"41": "PR", "42": "SC", "43": "RS", "50": "MS", "51": "MT",
	"52": "GO", "53": "DF",
}

// ufSiglaToCode is the inverse of ufCodeToSigla, used by
// validateCMunPrefixesUF to translate an address's UF sigla back to
// the cUF prefix that municipal codes (cMun, 7 digits) must start
// with. Built once at init from ufCodeToSigla so the two never drift.
var ufSiglaToCode = func() map[string]string {
	m := make(map[string]string, len(ufCodeToSigla))
	for code, sigla := range ufCodeToSigla {
		m[sigla] = code
	}
	return m
}()

func validateCUFMatchesEmit(inf *schema.InfNFe) []ValidationIssue {
	if inf.Ide == nil || inf.Emit == nil || inf.Emit.EnderEmit == nil {
		return nil // missing-block validation belongs elsewhere
	}
	expected, ok := ufCodeToSigla[inf.Ide.CUF]
	if !ok {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "ide.cUF",
			Message:  fmt.Sprintf("código IBGE de UF inválido: %q", inf.Ide.CUF),
		}}
	}
	actual := inf.Emit.EnderEmit.UF
	if expected != actual {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "ide.cUF / emit.enderEmit.UF",
			Message: fmt.Sprintf("ide.cUF=%s (mapeia para %s) não casa com enderEmit.UF=%q",
				inf.Ide.CUF, expected, actual),
		}}
	}
	return nil
}

// validateCMunPrefixesUF guards against internally inconsistent
// addresses where the IBGE municipal code (cMun, 7 digits, first two
// being the state code) does not belong to the declared UF. Without
// this check a NF-e can be authorized with cMun=4314902 (Porto Alegre,
// RS) under enderEmit.UF=SP — validateCUFMatchesEmit passes if the
// user also flipped ide.cUF to 35, but the DANFE renders the literal
// stored data ("Porto Alegre/SP") and the document is fiscally
// nonsense. SEFAZ would reject in production; the homologation mock
// does not, hence the defensive validation here.
//
// Covers emit.enderEmit, dest.enderDest, and ide.cMunFG (the latter
// scoped against ide.cUF since it is the município de fato gerador).
func validateCMunPrefixesUF(inf *schema.InfNFe) []ValidationIssue {
	var issues []ValidationIssue
	if inf.Emit != nil && inf.Emit.EnderEmit != nil {
		issues = append(issues, checkMunUFPair("emit.enderEmit", inf.Emit.EnderEmit.CMun, inf.Emit.EnderEmit.UF)...)
	}
	if inf.Dest != nil && inf.Dest.EnderDest != nil {
		issues = append(issues, checkMunUFPair("dest.enderDest", inf.Dest.EnderDest.CMun, inf.Dest.EnderDest.UF)...)
	}
	if inf.Ide != nil && inf.Ide.CMunFG != "" && inf.Ide.CUF != "" && len(inf.Ide.CMunFG) >= 2 {
		if inf.Ide.CMunFG[:2] != inf.Ide.CUF {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.cMunFG",
				Message: fmt.Sprintf("ide.cMunFG=%s prefixo %s não casa com ide.cUF=%s",
					inf.Ide.CMunFG, inf.Ide.CMunFG[:2], inf.Ide.CUF),
			})
		}
	}
	return issues
}

func checkMunUFPair(prefix, cMun, uf string) []ValidationIssue {
	if cMun == "" || uf == "" {
		return nil
	}
	if len(cMun) < 2 {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    prefix + ".cMun",
			Message:  fmt.Sprintf("cMun=%q deve ter ao menos 7 dígitos", cMun),
		}}
	}
	expectedCUF, ok := ufSiglaToCode[uf]
	if !ok {
		return nil // UF sigla inválida é capturada pelo XSD enum
	}
	if cMun[:2] != expectedCUF {
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    prefix + ".cMun",
			Message: fmt.Sprintf("cMun=%s prefixo %s não casa com %s.UF=%s (esperado prefixo %s)",
				cMun, cMun[:2], prefix, uf, expectedCUF),
		}}
	}
	return nil
}

func validateIdDestMatchesUFs(inf *schema.InfNFe) []ValidationIssue {
	if inf.Ide == nil || inf.Emit == nil || inf.Emit.EnderEmit == nil {
		return nil
	}
	if inf.Dest == nil || inf.Dest.EnderDest == nil {
		return nil
	}
	emitUF := inf.Emit.EnderEmit.UF
	destUF := inf.Dest.EnderDest.UF

	switch inf.Ide.IdDest {
	case "1": // Interna
		if emitUF != destUF {
			return []ValidationIssue{{
				Severity: SeverityError,
				Field:    "ide.idDest",
				Message: fmt.Sprintf("idDest=1 (interna) requer UFs iguais; got emit=%s dest=%s",
					emitUF, destUF),
			}}
		}
	case "2": // Interestadual
		var issues []ValidationIssue
		if emitUF == destUF {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.idDest",
				Message: fmt.Sprintf("idDest=2 (interestadual) requer UFs distintas; got ambas %s",
					emitUF),
			})
		}
		if destUF == "EX" {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    "ide.idDest",
				Message:  "idDest=2 (interestadual) inconsistente com dest.UF=EX (esperado idDest=3)",
			})
		}
		return issues
	case "3": // Exterior
		if destUF != "EX" {
			return []ValidationIssue{{
				Severity: SeverityError,
				Field:    "ide.idDest",
				Message: fmt.Sprintf("idDest=3 (exterior) requer dest.UF=EX; got %s",
					destUF),
			}}
		}
	default:
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "ide.idDest",
			Message: fmt.Sprintf("idDest=%q inválido (esperado 1=interna, 2=interestadual, 3=exterior)",
				inf.Ide.IdDest),
		}}
	}
	return nil
}

func validateCRT(inf *schema.InfNFe) []ValidationIssue {
	if inf.Emit == nil {
		return nil
	}
	switch inf.Emit.CRT {
	case "1", "2", "3", "4":
		return nil
	default:
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "emit.CRT",
			Message: fmt.Sprintf("CRT=%q inválido (esperado 1=Simples Nacional, 2=Simples excesso sublimite, 3=Regime Normal, 4=MEI)",
				inf.Emit.CRT),
		}}
	}
}

func validateModelo(inf *schema.InfNFe) []ValidationIssue {
	if inf.Ide == nil {
		return nil
	}
	switch inf.Ide.Mod {
	case "55", "65":
		return nil
	default:
		return []ValidationIssue{{
			Severity: SeverityError,
			Field:    "ide.mod",
			Message: fmt.Sprintf("modelo=%q inválido (esperado 55=NF-e ou 65=NFC-e)",
				inf.Ide.Mod),
		}}
	}
}

// cfopFirstDigit holds the expected first digit of CFOP for each
// (tpNF, idDest) combination. tpNF: 0=entrada, 1=saída. idDest: 1=interna,
// 2=interestadual, 3=exterior. The convention encodes the operation as a
// 4-digit code where the first digit identifies origin × destination.
var cfopFirstDigit = map[string]map[string]byte{
	"0": {"1": '1', "2": '2', "3": '3'}, // entrada (raro em NF-e de venda)
	"1": {"1": '5', "2": '6', "3": '7'}, // saída
}

// ValidateTotalsAgainstItems compares Total.ICMSTot fields against sums
// computed from det[] line items. Returns issues when any total diverges
// by more than 1 cent (rounding cumulativo é normal em NF-e com muitos
// itens; tolerância evita falsos positivos).
//
// Coverage scope:
//   - vBC, vICMS: somados de det[].imposto.icms.ICMS00 (regime normal CST 00)
//   - vPIS:       somado de det[].imposto.pis.PISAliq (CST 01)
//   - vCOFINS:    somado de det[].imposto.cofins.COFINSAliq (CST 01)
//   - vProd:      somado de det[].prod.vProd
//
// Items with non-tributada variants (CSOSN 102/400, CST 40/41/50, etc.)
// don't contribute to vBC/vICMS at the totalization level — silently
// skipped. Same for PIS/COFINS Outr/NT variants. Future sprints can
// expand to other CSTs as the calculadoras grow.
func ValidateTotalsAgainstItems(nfe *schema.TNFe) []ValidationIssue {
	if nfe == nil || nfe.InfNFe == nil || nfe.InfNFe.Total == nil || nfe.InfNFe.Total.ICMSTot == nil {
		return nil
	}
	inf := nfe.InfNFe

	sumVBC := new(big.Rat)
	sumVICMS := new(big.Rat)
	sumVPIS := new(big.Rat)
	sumVCOFINS := new(big.Rat)
	sumVProd := new(big.Rat)

	for _, det := range inf.Det {
		if det == nil {
			continue
		}
		if det.Prod != nil {
			addStringToRat(sumVProd, det.Prod.VProd)
		}
		if det.Imposto == nil {
			continue
		}
		if det.Imposto.ICMS != nil && det.Imposto.ICMS.ICMS00 != nil {
			icms00 := det.Imposto.ICMS.ICMS00
			if icms00.VBC != nil {
				addStringToRat(sumVBC, *icms00.VBC)
			}
			if icms00.VICMS != nil {
				addStringToRat(sumVICMS, *icms00.VICMS)
			}
		}
		if det.Imposto.PIS != nil && det.Imposto.PIS.PISAliq != nil && det.Imposto.PIS.PISAliq.VPIS != nil {
			addStringToRat(sumVPIS, *det.Imposto.PIS.PISAliq.VPIS)
		}
		if det.Imposto.COFINS != nil && det.Imposto.COFINS.COFINSAliq != nil && det.Imposto.COFINS.COFINSAliq.VCOFINS != nil {
			addStringToRat(sumVCOFINS, *det.Imposto.COFINS.COFINSAliq.VCOFINS)
		}
	}

	tot := inf.Total.ICMSTot
	var issues []ValidationIssue
	for _, check := range []struct {
		field    string
		computed *big.Rat
		declared string
	}{
		{"Total.ICMSTot.vBC", sumVBC, tot.VBC},
		{"Total.ICMSTot.vICMS", sumVICMS, tot.VICMS},
		{"Total.ICMSTot.vPIS", sumVPIS, tot.VPIS},
		{"Total.ICMSTot.vCOFINS", sumVCOFINS, tot.VCOFINS},
		{"Total.ICMSTot.vProd", sumVProd, tot.VProd},
	} {
		if issue := compareTotal(check.field, check.computed, check.declared); issue != nil {
			issues = append(issues, *issue)
		}
	}
	return issues
}

// addStringToRat parses a SEFAZ-formatted decimal and adds it to acc.
// Silently skips empty or unparseable values — those surface as 0.00
// declared elsewhere and the comparison flags any mismatch.
func addStringToRat(acc *big.Rat, s string) {
	if s == "" {
		return
	}
	v, err := parseDecimal(s)
	if err != nil {
		return
	}
	acc.Add(acc, v)
}

// compareTotal flags a divergence > 1 cent between declared total and
// computed sum. Empty declared is skipped (caller didn't populate; no
// claim to compare against).
func compareTotal(field string, computed *big.Rat, declared string) *ValidationIssue {
	if declared == "" {
		return nil
	}
	decl, err := parseDecimal(declared)
	if err != nil {
		return &ValidationIssue{
			Severity: SeverityError,
			Field:    field,
			Message:  fmt.Sprintf("não foi possível parsear o total declarado %q", declared),
		}
	}
	diff := new(big.Rat).Sub(decl, computed)
	diff.Abs(diff)
	cent := big.NewRat(1, 100)
	if diff.Cmp(cent) > 0 {
		return &ValidationIssue{
			Severity: SeverityError,
			Field:    field,
			Message: fmt.Sprintf("declarado=%s itens somam=%s (diff=%s, tolerância=0.01)",
				declared, computed.FloatString(2), diff.FloatString(4)),
		}
	}
	return nil
}

func validateCFOPFamily(inf *schema.InfNFe) []ValidationIssue {
	if inf.Ide == nil {
		return nil
	}
	tpNFMap, ok := cfopFirstDigit[inf.Ide.TpNF]
	if !ok {
		return nil // tpNF coverage handled elsewhere
	}
	expected, ok := tpNFMap[inf.Ide.IdDest]
	if !ok {
		return nil
	}

	var issues []ValidationIssue
	for i, det := range inf.Det {
		if det == nil || det.Prod == nil {
			continue
		}
		cfop := det.Prod.CFOP
		if len(cfop) != 4 {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    fmt.Sprintf("det[%d].prod.CFOP", i),
				Message:  fmt.Sprintf("CFOP deve ter 4 dígitos; got %q", cfop),
			})
			continue
		}
		if cfop[0] != expected {
			issues = append(issues, ValidationIssue{
				Severity: SeverityError,
				Field:    fmt.Sprintf("det[%d].prod.CFOP", i),
				Message: fmt.Sprintf("CFOP=%s não casa com tpNF=%s + idDest=%s (esperado começar com %c)",
					cfop, inf.Ide.TpNF, inf.Ide.IdDest, expected),
			})
		}
	}
	return issues
}
