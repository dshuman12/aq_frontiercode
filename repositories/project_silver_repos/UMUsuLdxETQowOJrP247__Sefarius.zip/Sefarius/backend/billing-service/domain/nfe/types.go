package nfe

// Strongly typed enums extracted from SEFAZ leiaute NF-e v4.00.
// Reference: Manual de Orientacao do Contribuinte (MOC) and tabela de codigos.

// ─── TpAmb — Tipo de Ambiente ────────────────────────────────────────────────

// TpAmb identifies whether the document targets Producao or Homologacao SEFAZ.
type TpAmb string

const (
	TpAmbProducao    TpAmb = "1"
	TpAmbHomologacao TpAmb = "2"
)

// IsValid reports whether the value is one of the two allowed codes.
func (t TpAmb) IsValid() bool {
	return t == TpAmbProducao || t == TpAmbHomologacao
}

// ─── Modelo — Modelo do Documento Fiscal ─────────────────────────────────────

// Modelo distinguishes NF-e (55) from NFC-e (65). Other models exist in the
// broader SPED family but are out of scope for this service.
type Modelo string

const (
	ModeloNFe  Modelo = "55"
	ModeloNFCe Modelo = "65"
)

// IsValid reports whether the value is a recognized fiscal-document model.
func (m Modelo) IsValid() bool {
	return m == ModeloNFe || m == ModeloNFCe
}

// ─── TpEmis — Forma de Emissao ───────────────────────────────────────────────

// TpEmis describes whether the issue happens normally or under any of the
// contingency modes defined by SEFAZ.
type TpEmis string

const (
	TpEmisNormal      TpEmis = "1" // Emissao normal (default path)
	TpEmisContFSIA    TpEmis = "2" // Contingencia FS-IA com DANFE em formulario de seguranca
	TpEmisContSCAN    TpEmis = "3" // Contingencia SCAN (descontinuado mas mantido por historico)
	TpEmisContDPEC    TpEmis = "4" // Contingencia DPEC (Declaracao Previa de Emissao em Contingencia)
	TpEmisContFSDA    TpEmis = "5" // Contingencia FS-DA com DANFE em formulario de seguranca
	TpEmisContSVCAN   TpEmis = "6" // Contingencia SVC-AN (SEFAZ Virtual de Contingencia do AN)
	TpEmisContSVCRS   TpEmis = "7" // Contingencia SVC-RS
	TpEmisContOffNFCe TpEmis = "9" // Contingencia off-line para NFC-e
)

// IsValid reports whether the value is one of the leiaute-defined emission modes.
func (t TpEmis) IsValid() bool {
	switch t {
	case TpEmisNormal, TpEmisContFSIA, TpEmisContSCAN, TpEmisContDPEC,
		TpEmisContFSDA, TpEmisContSVCAN, TpEmisContSVCRS, TpEmisContOffNFCe:
		return true
	}
	return false
}

// IsContingencia reports whether the emission mode is any contingency variant.
func (t TpEmis) IsContingencia() bool {
	return t.IsValid() && t != TpEmisNormal
}

// ─── IdDest — Local de Destino da Operacao ───────────────────────────────────

// IdDest classifies the operation as intra-state, inter-state or with exterior.
type IdDest string

const (
	IdDestInterna       IdDest = "1" // Operacao interna (mesma UF)
	IdDestInterestadual IdDest = "2" // Operacao interestadual
	IdDestExterior      IdDest = "3" // Operacao com exterior
)

// IsValid reports whether the value is one of the three allowed codes.
func (i IdDest) IsValid() bool {
	return i == IdDestInterna || i == IdDestInterestadual || i == IdDestExterior
}

// ─── FinNFe — Finalidade da Emissao ──────────────────────────────────────────

// FinNFe describes the purpose of issuance: normal, complementary, adjustment,
// or a return of merchandise.
type FinNFe string

const (
	FinNFeNormal       FinNFe = "1"
	FinNFeComplementar FinNFe = "2"
	FinNFeAjuste       FinNFe = "3"
	FinNFeDevolucao    FinNFe = "4"
)

// IsValid reports whether the value is one of the leiaute-defined purposes.
func (f FinNFe) IsValid() bool {
	switch f {
	case FinNFeNormal, FinNFeComplementar, FinNFeAjuste, FinNFeDevolucao:
		return true
	}
	return false
}

// ─── IndPres — Indicador de Presenca do Comprador ────────────────────────────

// IndPres signals the buyer presence at the moment of the operation.
type IndPres string

const (
	IndPresNaoSeAplica       IndPres = "0" // Nao se aplica (NF-e complementar/ajuste)
	IndPresPresencial        IndPres = "1" // Operacao presencial
	IndPresInternet          IndPres = "2" // Operacao nao presencial, pela Internet
	IndPresTeleatendimento   IndPres = "3" // Operacao nao presencial, Teleatendimento
	IndPresEntregaDomicilio  IndPres = "4" // NFC-e em operacao com entrega em domicilio
	IndPresPresencialForaEst IndPres = "5" // Operacao presencial, fora do estabelecimento
	IndPresOutros            IndPres = "9" // Operacao nao presencial, outros
)

// IsValid reports whether the value is one of the seven defined codes.
func (i IndPres) IsValid() bool {
	switch i {
	case IndPresNaoSeAplica, IndPresPresencial, IndPresInternet,
		IndPresTeleatendimento, IndPresEntregaDomicilio,
		IndPresPresencialForaEst, IndPresOutros:
		return true
	}
	return false
}

// ─── IndIEDest — Indicador de IE do Destinatario ─────────────────────────────

// IndIEDest classifies the recipient with respect to ICMS contributorship.
type IndIEDest string

const (
	IndIEDestContribuinte    IndIEDest = "1" // Contribuinte ICMS
	IndIEDestIsento          IndIEDest = "2" // Contribuinte isento de Inscricao Estadual
	IndIEDestNaoContribuinte IndIEDest = "9" // Nao Contribuinte
)

// IsValid reports whether the value is one of the three defined codes.
func (i IndIEDest) IsValid() bool {
	return i == IndIEDestContribuinte || i == IndIEDestIsento || i == IndIEDestNaoContribuinte
}

// ─── ProcEmi — Processo de Emissao da NF-e ───────────────────────────────────

// ProcEmi identifies which application produced the NF-e.
type ProcEmi string

const (
	ProcEmiContribuinte         ProcEmi = "0" // Emissao com aplicativo do contribuinte
	ProcEmiAvulsaFisco          ProcEmi = "1" // Emissao avulsa pelo Fisco
	ProcEmiAvulsaCertificado    ProcEmi = "2" // Emissao avulsa, contribuinte com certificado em aplicativo Fisco
	ProcEmiContribuinteAplFisco ProcEmi = "3" // Emissao pelo contribuinte com aplicativo do Fisco
)

// IsValid reports whether the value is one of the four defined codes.
func (p ProcEmi) IsValid() bool {
	switch p {
	case ProcEmiContribuinte, ProcEmiAvulsaFisco,
		ProcEmiAvulsaCertificado, ProcEmiContribuinteAplFisco:
		return true
	}
	return false
}

// ─── CStat — Codigos de Status SEFAZ (subset frequente) ──────────────────────

// CStat enumerates the most-handled SEFAZ status codes returned by the
// authorization, query and event webservices. The leiaute defines hundreds
// of codes; this subset covers the success and decision-affecting cases.
type CStat string

const (
	CStatAutorizado          CStat = "100" // Autorizado o uso da NF-e
	CStatCancelamentoHomolog CStat = "101" // Cancelamento de NF-e homologado
	CStatInutilizacaoHomolog CStat = "102" // Inutilizacao de numero homologada
	CStatLoteRecebido        CStat = "103" // Lote recebido com sucesso
	CStatLoteProcessado      CStat = "104" // Lote processado
	CStatLoteEmProcessamento CStat = "105" // Lote em processamento
	CStatServicoEmOperacao   CStat = "107" // Servico em Operacao
	CStatUsoDenegado         CStat = "110" // Uso Denegado
	CStatEventoVinculado     CStat = "135" // Evento registrado e vinculado a NF-e
	CStatNaoConsta           CStat = "217" // NF-e nao consta na base da SEFAZ
	CStatPrazoCancelExpirado CStat = "220" // NF-e autorizada ha mais de 168 horas
	CStatDuplicidade         CStat = "539" // Duplicidade de NF-e
)

// IsSuccess reports whether the code indicates the requested operation
// succeeded (vs an error or pending state).
func (c CStat) IsSuccess() bool {
	switch c {
	case CStatAutorizado, CStatCancelamentoHomolog, CStatInutilizacaoHomolog,
		CStatLoteProcessado, CStatServicoEmOperacao, CStatEventoVinculado:
		return true
	}
	return false
}

// IsTransientFailure reports whether retrying the request makes sense:
// service down, batch still processing, queue saturated.
func (c CStat) IsTransientFailure() bool {
	return c == CStatLoteEmProcessamento
}
