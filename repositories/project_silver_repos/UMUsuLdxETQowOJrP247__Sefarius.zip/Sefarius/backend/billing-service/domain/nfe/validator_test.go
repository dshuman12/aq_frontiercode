package nfe_test

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// TestValidationIssue_JSONShape locks the wire contract that the Angular
// frontend depends on. Without explicit json tags, encoding/json marshals
// Go field names verbatim — Field, Message, Severity (PascalCase) — and
// the frontend reads `?: (sem mensagem)` because it expects lowercase
// keys per JSON convention. This test fails if anyone removes the json
// tags from ValidationIssue or renames a key.
func TestValidationIssue_JSONShape(t *testing.T) {
	issue := nfe.ValidationIssue{
		Severity: nfe.SeverityError,
		Field:    "Total.ICMSTot.vPIS",
		Message:  "declarado=3.71 itens somam=8.35",
	}
	b, err := json.Marshal(issue)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	got := string(b)
	for _, want := range []string{`"severity":"error"`, `"field":"Total.ICMSTot.vPIS"`, `"message":"declarado=3.71 itens somam=8.35"`} {
		if !strings.Contains(got, want) {
			t.Errorf("JSON missing %s; got: %s", want, got)
		}
	}
	for _, forbidden := range []string{`"Severity"`, `"Field"`, `"Message"`} {
		if strings.Contains(got, forbidden) {
			t.Errorf("JSON contains PascalCase key %s — frontend reads lowercase; got: %s", forbidden, got)
		}
	}
}

func TestValidateSemantic_HappyPath(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	issues := nfe.ValidateSemantic(tnfe)
	if len(issues) > 0 {
		for _, i := range issues {
			t.Logf("%s", i)
		}
		t.Fatalf("expected zero issues for the canonical happy path, got %d", len(issues))
	}
}

func TestValidateSemantic_NilInputs(t *testing.T) {
	if got := nfe.ValidateSemantic(nil); len(got) != 1 {
		t.Errorf("expected 1 issue for nil NFe, got %d", len(got))
	}
	if got := nfe.ValidateSemantic(&schema.TNFe{}); len(got) != 1 {
		t.Errorf("expected 1 issue for empty TNFe, got %d", len(got))
	}
}

// findIssue is a test helper — returns the first issue whose Field contains
// the substring, or fails the test.
func findIssue(t *testing.T, issues []nfe.ValidationIssue, fieldSubstr string) nfe.ValidationIssue {
	t.Helper()
	for _, i := range issues {
		if strings.Contains(i.Field, fieldSubstr) {
			return i
		}
	}
	t.Fatalf("no issue found mentioning %q; got: %+v", fieldSubstr, issues)
	return nfe.ValidationIssue{}
}

func TestValidateSemantic_ChaveMissing(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.IdAttr = ""
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "infNFe.Id")
	if !strings.Contains(got.Message, "ausente") {
		t.Errorf("expected message about missing Id; got %q", got.Message)
	}
}

func TestValidateSemantic_ChaveWrongPrefix(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.IdAttr = "XYZ" + strings.TrimPrefix(tnfe.InfNFe.IdAttr, "NFe")
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "infNFe.Id")
	if !strings.Contains(got.Message, "prefixo") {
		t.Errorf("expected message about prefix; got %q", got.Message)
	}
}

func TestValidateSemantic_ChaveCDVMismatch(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// Sabotage cDV without touching the chave.
	originalCDV := tnfe.InfNFe.Ide.CDV
	if originalCDV == "9" {
		tnfe.InfNFe.Ide.CDV = "0"
	} else {
		tnfe.InfNFe.Ide.CDV = "9"
	}
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "ide.cDV")
	if !strings.Contains(got.Message, "último dígito") {
		t.Errorf("expected message about last digit; got %q", got.Message)
	}
}

func TestValidateSemantic_ChaveSerieDivergesFromIde(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// Chave was built with serie=1; if we change ide.serie to 2 without
	// rebuilding, the chave consistency check must flag the divergence.
	tnfe.InfNFe.Ide.Serie = "2"
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "ide.serie")
	if !strings.Contains(got.Message, "não casa com chave") {
		t.Errorf("expected message about chave divergence; got %q", got.Message)
	}
}

func TestValidateSemantic_ChaveCNPJDivergesFromEmit(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	bogusCNPJ := "00000000000000"
	tnfe.InfNFe.Emit.CNPJ = &bogusCNPJ
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "emit.CNPJ")
	if !strings.Contains(got.Message, "não casa com chave") {
		t.Errorf("expected message about chave divergence; got %q", got.Message)
	}
}

func TestValidateSemantic_CUFMismatch(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// minimalNFe is cUF=43 (RS), UF=RS — force mismatch.
	tnfe.InfNFe.Emit.EnderEmit.UF = "SP"
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "cUF")
	if got.Severity != nfe.SeverityError {
		t.Errorf("expected Error severity, got %s", got.Severity)
	}
}

func TestValidateSemantic_InvalidCUFCode(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.CUF = "99" // 99 is not a valid IBGE UF code
	issues := nfe.ValidateSemantic(tnfe)
	if len(issues) == 0 {
		t.Fatal("expected at least one issue for unknown cUF")
	}
	findIssue(t, issues, "ide.cUF")
}

// TestValidateSemantic_CMunDoesNotMatchEmitUF reproduces the exact
// data shape of NF-e 35260511222333000181550010000000021375935694
// observed in the dev DB on 2026-05-07: emit.enderEmit.cMun=4314902
// (Porto Alegre, IBGE prefix 43=RS) under enderEmit.UF=SP and
// ide.cUF=35. validateCUFMatchesEmit is happy (35 maps cleanly to SP),
// but the document is fiscally nonsense — the DANFE renders
// "Porto Alegre/SP" because that is exactly what is stored. SEFAZ
// production rejects this; the homologation mock did not, so the
// validator must catch it before the use case ever submits.
func TestValidateSemantic_CMunDoesNotMatchEmitUF(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.CUF = "35"
	tnfe.InfNFe.Emit.EnderEmit.UF = "SP"
	// Keep cMun=4314902 (Porto Alegre/RS) — the inconsistency we are
	// asserting the validator catches.

	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "emit.enderEmit.cMun")
	if got.Severity != nfe.SeverityError {
		t.Errorf("expected Error severity, got %s", got.Severity)
	}
	if !strings.Contains(got.Message, "4314902") || !strings.Contains(got.Message, "SP") {
		t.Errorf("issue message must name the offending cMun + UF; got %q", got.Message)
	}
}

// TestValidateSemantic_CMunFGDoesNotMatchCUF mirrors the previous test
// for ide.cMunFG — the município de fato gerador must lie within the
// issuer's UF. Same incident: cMunFG=4314902 with cUF=35.
func TestValidateSemantic_CMunFGDoesNotMatchCUF(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.CUF = "35"
	tnfe.InfNFe.Emit.EnderEmit.UF = "SP"
	tnfe.InfNFe.Emit.EnderEmit.CMun = "3550308" // SP municipal code so the cMun↔UF check passes
	tnfe.InfNFe.Dest.EnderDest.UF = "SP"
	tnfe.InfNFe.Dest.EnderDest.CMun = "3550308"
	tnfe.InfNFe.Ide.IdDest = "1" // intra-state to avoid idDest noise
	// Force the inconsistency we want to catch:
	tnfe.InfNFe.Ide.CMunFG = "4314902" // Porto Alegre/RS under cUF=35 (SP)

	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "ide.cMunFG")
}

func TestValidateSemantic_IdDestInternalUFsDiffer(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// idDest=1 (interna) declared but dest in another UF.
	tnfe.InfNFe.Dest.EnderDest.UF = "SP"
	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "ide.idDest")
}

func TestValidateSemantic_IdDestInterstateUFsEqual(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.IdDest = "2" // interestadual but UFs are both RS
	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "ide.idDest")
}

func TestValidateSemantic_IdDestExteriorRequiresEX(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.IdDest = "3" // exterior but dest UF is RS
	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "ide.idDest")
}

func TestValidateSemantic_CRTRange(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Emit.CRT = "9"
	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "emit.CRT")
}

func TestValidateSemantic_ModeloUnsupported(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Ide.Mod = "01"
	issues := nfe.ValidateSemantic(tnfe)
	findIssue(t, issues, "ide.mod")
}

func TestValidateSemantic_CFOPFamilyMismatch(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// minimalNFe has tpNF=1 + idDest=1 → CFOP must start with 5.
	// Inject 6102 (interestadual) to provoke mismatch.
	tnfe.InfNFe.Det[0].Prod.CFOP = "6102"
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "det[0].prod.CFOP")
	if !strings.Contains(got.Message, "começar com 5") {
		t.Errorf("expected message about expected first digit 5; got %q", got.Message)
	}
}

func TestValidateSemantic_CFOPMalformed(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Det[0].Prod.CFOP = "510" // 3 digits
	issues := nfe.ValidateSemantic(tnfe)
	got := findIssue(t, issues, "det[0].prod.CFOP")
	if !strings.Contains(got.Message, "4 dígitos") {
		t.Errorf("expected message about 4 digits; got %q", got.Message)
	}
}

func TestValidateTotalsAgainstItems_HappyPath(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// Replace the manual single-item Det with one built via the facade so
	// that vICMS=18.00 (from vBC=100, pICMS=18) matches the Total declared
	// in minimalNFe (vBC=100, vICMS=18).
	det, err := nfe.NewDetRegimeNormalCST00(tnfe.InfNFe.Det[0].Prod, "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// minimalNFe's Total has vBC=100, vICMS=18 already — but vProd/vPIS/vCOFINS
	// were not populated. Skipping those is OK since compareTotal skips empty.

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	if len(issues) > 0 {
		for _, i := range issues {
			t.Logf("%s", i)
		}
		t.Fatalf("expected zero issues, got %d", len(issues))
	}
}

func TestValidateTotalsAgainstItems_VBCDivergence(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	det, err := nfe.NewDetRegimeNormalCST00(tnfe.InfNFe.Det[0].Prod, "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// Sabotage the declared total — items sum to 100.00 but declared is 200.00.
	tnfe.InfNFe.Total.ICMSTot.VBC = "200.00"

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	got := findIssue(t, issues, "Total.ICMSTot.vBC")
	if !strings.Contains(got.Message, "declarado=200.00") || !strings.Contains(got.Message, "100.00") {
		t.Errorf("expected message with declarado=200.00 and itens=100.00; got %q", got.Message)
	}
}

func TestValidateTotalsAgainstItems_OneCentToleranceAccepted(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	det, err := nfe.NewDetRegimeNormalCST00(tnfe.InfNFe.Det[0].Prod, "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// Declared 100.01 vs computed 100.00 — within 1 cent tolerance, no issue.
	tnfe.InfNFe.Total.ICMSTot.VBC = "100.01"

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	for _, i := range issues {
		if strings.Contains(i.Field, "vBC") {
			t.Errorf("unexpected issue within 1-cent tolerance: %s", i)
		}
	}
}

// TestValidateTotalsAgainstItems_SimplesNacional_TotalsZero confirms the
// happy path for an SN issuer: items use CSOSN 102 (no contribution to
// vBC/vICMS), Total declares 0.00 — no issues. This documents the
// expected pattern for SN.
func TestValidateTotalsAgainstItems_SimplesNacional_TotalsZero(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	det, err := nfe.NewDetSimplesCSOSN102(tnfe.InfNFe.Det[0].Prod, "0")
	if err != nil {
		t.Fatalf("NewDetSimplesCSOSN102: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// SN: ICMS totals must be zero.
	tnfe.InfNFe.Total.ICMSTot.VBC = "0.00"
	tnfe.InfNFe.Total.ICMSTot.VICMS = "0.00"

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	for _, i := range issues {
		if strings.Contains(i.Field, "vBC") || strings.Contains(i.Field, "vICMS") {
			t.Errorf("unexpected issue for SN with zero totals: %s", i)
		}
	}
}

// TestValidateTotalsAgainstItems_SimplesNacional_NonZeroDeclaredFlagged
// covers the failure path: SN items contribute zero, but Total declares
// a non-zero vBC. The diff > 1 cent must surface — this test was the
// gap registered in the 1.4 review.
func TestValidateTotalsAgainstItems_SimplesNacional_NonZeroDeclaredFlagged(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	det, err := nfe.NewDetSimplesCSOSN102(tnfe.InfNFe.Det[0].Prod, "0")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// minimalNFe leaves VBC=100.00, VICMS=18.00 — wrong for SN.

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	findIssue(t, issues, "Total.ICMSTot.vBC")
	findIssue(t, issues, "Total.ICMSTot.vICMS")
}

func TestValidateTotalsAgainstItems_TwoCentsExceedsTolerance(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	det, err := nfe.NewDetRegimeNormalCST00(tnfe.InfNFe.Det[0].Prod, "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	tnfe.InfNFe.Det = []*schema.Det{det}
	// Declared 100.02 vs computed 100.00 — diff > 0.01, expected issue.
	tnfe.InfNFe.Total.ICMSTot.VBC = "100.02"

	issues := nfe.ValidateTotalsAgainstItems(tnfe)
	findIssue(t, issues, "Total.ICMSTot.vBC")
}

// TestValidateSemantic_AccumulatesIssues confirms multiple independent
// violations are returned in a single call (validator does not stop at
// first error).
func TestValidateSemantic_AccumulatesIssues(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	tnfe.InfNFe.Emit.CRT = "9"
	tnfe.InfNFe.Ide.Mod = "01"
	tnfe.InfNFe.Det[0].Prod.CFOP = "6102"

	issues := nfe.ValidateSemantic(tnfe)
	if len(issues) < 3 {
		t.Errorf("expected at least 3 issues, got %d: %+v", len(issues), issues)
	}
}
