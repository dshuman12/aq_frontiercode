package nfe

import (
	"context"
	"errors"
	"time"
)

// NFeStatus is the persisted lifecycle state of an NF-e in our system.
//
// Note: the SEFAZ wire protocol has many cStat codes (~700); this is
// the small enum the application layer uses to drive UI, queries, and
// retry logic. Mapping from the wire-level AuthorizationStatus to
// NFeStatus happens in EmitNFeUseCase.
type NFeStatus string

const (
	// NFeStatusAuthorized — SEFAZ returned cStat 100 and the NF-e is
	// fiscally valid. Both first-time authorizations and the duplicate
	// recovery path (cStat 539, AuthorizationStatusDuplicate) collapse
	// to this state because the protocol is the same in either case.
	NFeStatusAuthorized NFeStatus = "AUTHORIZED"

	// NFeStatusRejected — SEFAZ refused the document. The signed XML is
	// kept for diagnostic and contestation purposes; the rejection
	// fields explain why.
	NFeStatusRejected NFeStatus = "REJECTED"

	// NFeStatusPending — Authorize attempt did not reach a fiscal
	// outcome (transport failure, timeout, AuthorizationStatusServiceUnavailable).
	// The document is signed and ready to re-submit.
	NFeStatusPending NFeStatus = "PENDING"

	// NFeStatusCancelled — A successful cancellation event was
	// processed against this NF-e. Set by the (future) cancel use
	// case; preserved here so the repository contract is complete.
	NFeStatusCancelled NFeStatus = "CANCELLED"
)

// NFeRecord is the persisted form of an emitted NF-e. The signed XML
// + protocol together form the legally valid "procNFe" file; storing
// them as separate columns lets queries answer "give me the protocol
// for chave X" without re-parsing XML, while preserving the bytes
// exactly so a future re-export to SEFAZ stays byte-identical.
type NFeRecord struct {
	Chave      Chave
	Status     NFeStatus
	SignedXML  []byte
	Protocol   *Protocol  // populated when Status is AUTHORIZED
	Rejection  *Rejection // populated when Status is REJECTED
	CStat      string     // raw SEFAZ status code from the last Authorize attempt
	XMotivo    string     // human-readable motive from SEFAZ
	CreatedAt  time.Time  // when our system first persisted the record
	UpdatedAt  time.Time  // when the record last changed (status transition or re-auth)
}

// ErrNFeNotFound is returned by NFeRepository.GetByChave when no
// record exists for the given chave. Distinct sentinel because callers
// often branch on "first time we see this chave" vs other DB errors.
var ErrNFeNotFound = errors.New("nfe: record not found for chave")

// NFeRepository persists emitted NF-e records keyed by chave.
//
// Save is upsert semantics: if a record with the same chave already
// exists, it is overwritten. This matches the recovery semantics
// documented in sprint 1.6 (D4) — a re-emit that hits SEFAZ duplicate
// detection should leave a single, up-to-date record, not pile copies.
//
// GetByChave returns ErrNFeNotFound when the chave is unknown so
// callers can distinguish a missing record from an infrastructure
// error.
type NFeRepository interface {
	Save(ctx context.Context, record *NFeRecord) error
	GetByChave(ctx context.Context, chave Chave) (*NFeRecord, error)
	List(ctx context.Context, limit, offset int) ([]*NFeRecord, error)
	// Count returns the total number of stored NFe records. Used by
	// the paginated list endpoint to expose an accurate Total in the
	// response — without it the frontend cannot render numerical
	// pagination ("1 2 3 ... N") because the page count is unknown.
	Count(ctx context.Context) (int, error)
}
