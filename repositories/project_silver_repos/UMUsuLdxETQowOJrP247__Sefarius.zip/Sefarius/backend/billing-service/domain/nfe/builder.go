package nfe

import (
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// Builder assembles a *schema.TNFe from typed leiaute blocks, validates the
// required fields and computes the access key + Id attribute automatically.
//
// Scope (sprint 1.2): minimal happy path for a sale operation —
// internal mod 55, regime normal, no IPI/ICMS-ST, payment in cash. The
// builder accepts the leiaute structs already populated by the caller; its
// value is the cross-block consistency it enforces (chave matches Id, cDV
// matches last digit, item numbering is sequential), not field-level
// ergonomics. Later sprints (1.3+) layer richer fluent helpers on top.
type Builder struct {
	ide    *schema.Ide
	emit   *schema.Emit
	dest   *schema.Dest
	items  []*schema.Det
	total  *schema.Total
	transp *schema.Transp
	pag    *schema.Pag
}

// New returns an empty Builder. Chain Ide/Emit/Dest/AddDet/Total/Transp/Pag
// then call Build.
func New() *Builder { return &Builder{} }

func (b *Builder) Ide(ide *schema.Ide) *Builder       { b.ide = ide; return b }
func (b *Builder) Emit(emit *schema.Emit) *Builder    { b.emit = emit; return b }
func (b *Builder) Dest(dest *schema.Dest) *Builder    { b.dest = dest; return b }
func (b *Builder) Total(t *schema.Total) *Builder     { b.total = t; return b }
func (b *Builder) Transp(t *schema.Transp) *Builder   { b.transp = t; return b }
func (b *Builder) Pag(p *schema.Pag) *Builder         { b.pag = p; return b }
func (b *Builder) AddDet(det *schema.Det) *Builder {
	b.items = append(b.items, det)
	return b
}

// Build validates the assembled blocks, computes the 44-digit chave from
// (cUF, dhEmi, CNPJ, mod, serie, nNF, tpEmis, cNF) and populates:
//
//   - infNFe.Id  = "NFe" + chave
//   - ide.cDV    = last digit of the chave
//   - det.nItem  = 1, 2, 3, ... in insertion order
//
// Returns ErrEmptyItens / ErrTooManyItens when the item slice is out of range.
// Returns an error if any det has nil Prod or Imposto. Wraps NewChave
// validation errors when individual fields are malformed.
//
// IMPORTANT — mutation contract: Build modifies the caller's structs in
// place. ide.CDV is written; each det.NItemAttr is reassigned. Calling
// Build twice on the same Builder is idempotent (same writes), but reusing
// any pointer (a *schema.Det, a *schema.Ide, ...) across two distinct
// Builders causes silent corruption. Treat each block as exclusive to one
// Builder for one NF-e.
func (b *Builder) Build() (*schema.TNFe, error) {
	if b.ide == nil {
		return nil, errors.New("nfe.Builder: ide is required")
	}
	if b.emit == nil {
		return nil, errors.New("nfe.Builder: emit is required")
	}
	if b.dest == nil {
		return nil, errors.New("nfe.Builder: dest is required")
	}
	if b.transp == nil {
		return nil, errors.New("nfe.Builder: transp is required")
	}
	if b.pag == nil {
		return nil, errors.New("nfe.Builder: pag is required")
	}
	if len(b.items) == 0 {
		return nil, ErrEmptyItens
	}
	if len(b.items) > 990 {
		return nil, ErrTooManyItens
	}
	if b.emit.CNPJ == nil {
		return nil, fmt.Errorf("%w: builder requires emit.CNPJ (CPF issuer out of scope)", ErrInvalidCNPJ)
	}

	cUF, err := strconv.Atoi(b.ide.CUF)
	if err != nil {
		return nil, fmt.Errorf("%w: ide.cUF must be numeric, got %q", ErrInvalidUF, b.ide.CUF)
	}
	serie, err := strconv.Atoi(b.ide.Serie)
	if err != nil {
		return nil, fmt.Errorf("%w: ide.serie must be numeric, got %q", ErrInvalidSerie, b.ide.Serie)
	}
	nNF, err := strconv.Atoi(b.ide.NNF)
	if err != nil {
		return nil, fmt.Errorf("%w: ide.nNF must be numeric, got %q", ErrInvalidNNF, b.ide.NNF)
	}
	dhEmi, err := time.Parse(time.RFC3339, b.ide.DhEmi)
	if err != nil {
		return nil, fmt.Errorf("%w: ide.dhEmi must be RFC3339, got %q", ErrInvalidDhEmi, b.ide.DhEmi)
	}

	chave, err := NewChave(ChaveComponents{
		CUF:    cUF,
		DhEmi:  dhEmi,
		CNPJ:   *b.emit.CNPJ,
		Modelo: Modelo(b.ide.Mod),
		Serie:  serie,
		NNF:    nNF,
		TpEmis: TpEmis(b.ide.TpEmis),
		CNF:    b.ide.CNF,
	})
	if err != nil {
		return nil, fmt.Errorf("nfe.Builder: %w", err)
	}

	b.ide.CDV = string(chave[43])

	for i, det := range b.items {
		if det == nil {
			return nil, fmt.Errorf("nfe.Builder: det[%d] is nil", i)
		}
		if det.Prod == nil {
			return nil, fmt.Errorf("nfe.Builder: det[%d].Prod is nil", i)
		}
		if det.Imposto == nil {
			return nil, fmt.Errorf("nfe.Builder: det[%d].Imposto is nil", i)
		}
		det.NItemAttr = strconv.Itoa(i + 1)
	}

	return &schema.TNFe{
		InfNFe: &schema.InfNFe{
			VersaoAttr: "4.00",
			IdAttr:     "NFe" + string(chave),
			Ide:        b.ide,
			Emit:       b.emit,
			Dest:       b.dest,
			Det:        b.items,
			Total:      b.total,
			Transp:     b.transp,
			Pag:        b.pag,
		},
	}, nil
}
