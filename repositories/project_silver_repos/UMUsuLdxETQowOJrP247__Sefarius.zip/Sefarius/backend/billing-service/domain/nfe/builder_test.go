package nfe_test

import (
	"errors"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/internal/xmltest"
)

// strPtr is a tiny helper for constructing pointer-to-string fields
// that the leiaute uses for optional values.
func strPtr(s string) *string { return &s }

// minimalNFe returns a fully-populated builder with sensible defaults for a
// venda interna mod 55, RS → RS, regime normal, single item, payment in
// cash. Used as the baseline for happy-path tests; mutate fields to exercise
// edge cases.
func minimalNFe(t *testing.T) *nfe.Builder {
	t.Helper()
	cnpj := "05730928000145"
	uf := "43" // RS
	cMun := "4314902"
	xMun := "PORTO ALEGRE"

	ide := &schema.Ide{
		CUF:      uf,
		CNF:      "12345678",
		NatOp:    "VENDA DE MERCADORIA",
		Mod:      string(nfe.ModeloNFe),
		Serie:    "1",
		NNF:      "100",
		DhEmi:    "2026-05-06T10:00:00-03:00",
		TpNF:     "1",
		IdDest:   string(nfe.IdDestInterna),
		CMunFG:   cMun,
		TpImp:    "1",
		TpEmis:   string(nfe.TpEmisNormal),
		TpAmb:    string(nfe.TpAmbHomologacao),
		FinNFe:   string(nfe.FinNFeNormal),
		IndFinal: "1",
		IndPres:  string(nfe.IndPresPresencial),
		ProcEmi:  string(nfe.ProcEmiContribuinte),
		VerProc:  "sefarius 0.1",
	}

	emit := &schema.Emit{
		CNPJ:  &cnpj,
		XNome: "EMPRESA TESTE LTDA",
		EnderEmit: &schema.TEnderEmi{
			XLgr:    "AV TESTE",
			Nro:     "100",
			XBairro: "CENTRO",
			CMun:    cMun,
			XMun:    xMun,
			UF:      "RS",
			CEP:     "90000000",
		},
		IE:  "1234567890",
		CRT: "3", // Regime Normal
	}

	destCNPJ := "11444777000161"
	dest := &schema.Dest{
		CNPJ:  &destCNPJ,
		XNome: strPtr("CLIENTE TESTE LTDA"),
		EnderDest: &schema.TEndereco{
			XLgr:    "RUA EXEMPLO",
			Nro:     "200",
			XBairro: "BAIRRO",
			CMun:    cMun,
			XMun:    xMun,
			UF:      "RS",
			CEP:     strPtr("90000001"),
		},
		IndIEDest: string(nfe.IndIEDestContribuinte),
		IE:        strPtr("9876543210"),
	}

	det := &schema.Det{
		Prod: &schema.Prod{
			CProd:    "001",
			CEAN:     "SEM GTIN",
			XProd:    "PRODUTO TESTE",
			NCM:      "22021000",
			CFOP:     "5102", // venda mercadoria interna
			UCom:     "UN",
			QCom:     "1.0000",
			VUnCom:   "100.0000000000",
			VProd:    "100.00",
			CEANTrib: "SEM GTIN",
			UTrib:    "UN",
			QTrib:    "1.0000",
			VUnTrib:  "100.0000000000",
			IndTot:   "1",
		},
		Imposto: &schema.Imposto{
			ICMS: &schema.ICMS{
				ICMS00: &schema.ICMS00{
					Orig:  strPtr("0"),
					CST:   strPtr("00"),
					ModBC: strPtr("3"),
					VBC:   strPtr("100.00"),
					PICMS: strPtr("18.00"),
					VICMS: strPtr("18.00"),
				},
			},
		},
	}

	total := &schema.Total{
		ICMSTot: &schema.ICMSTot{
			VBC:        "100.00",
			VICMS:      "18.00",
			VICMSDeson: "0.00",
			VFCP:       "0.00",
			VBCST:      "0.00",
			VST:        "0.00",
			VFCPST:     "0.00",
			VFCPSTRet:  "0.00",
		},
	}

	transp := &schema.Transp{
		ModFrete: "9", // sem ocorrência de transporte
	}

	pag := &schema.Pag{
		DetPag: []*schema.DetPag{{
			TPag: "01", // dinheiro
			VPag: "118.00",
		}},
	}

	return nfe.New().
		Ide(ide).
		Emit(emit).
		Dest(dest).
		AddDet(det).
		Total(total).
		Transp(transp).
		Pag(pag)
}

func TestBuilder_HappyPath(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}

	if tnfe.InfNFe == nil {
		t.Fatal("InfNFe is nil")
	}
	if tnfe.InfNFe.VersaoAttr != "4.00" {
		t.Errorf("versao = %q, want 4.00", tnfe.InfNFe.VersaoAttr)
	}
	if !strings.HasPrefix(tnfe.InfNFe.IdAttr, "NFe") {
		t.Errorf("Id missing NFe prefix: %q", tnfe.InfNFe.IdAttr)
	}
	if len(tnfe.InfNFe.IdAttr) != 47 { // "NFe" + 44 digits
		t.Errorf("Id length = %d, want 47", len(tnfe.InfNFe.IdAttr))
	}

	chave := nfe.Chave(strings.TrimPrefix(tnfe.InfNFe.IdAttr, "NFe"))
	if err := chave.Validate(); err != nil {
		t.Errorf("chave from Id is invalid: %v", err)
	}

	if tnfe.InfNFe.Ide.CDV != string(chave[43]) {
		t.Errorf("ide.cDV = %q, want %q (last digit of chave)",
			tnfe.InfNFe.Ide.CDV, string(chave[43]))
	}

	if len(tnfe.InfNFe.Det) != 1 {
		t.Fatalf("expected 1 det, got %d", len(tnfe.InfNFe.Det))
	}
	if tnfe.InfNFe.Det[0].NItemAttr != "1" {
		t.Errorf("det[0].nItem = %q, want 1", tnfe.InfNFe.Det[0].NItemAttr)
	}
}

func TestBuilder_ChaveDecomposeMatchesInputs(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	chave := nfe.Chave(strings.TrimPrefix(tnfe.InfNFe.IdAttr, "NFe"))
	dec, err := chave.Decompose()
	if err != nil {
		t.Fatalf("Decompose: %v", err)
	}
	if dec.CUF != 43 {
		t.Errorf("decomposed cUF = %d, want 43", dec.CUF)
	}
	if dec.CNPJ != "05730928000145" {
		t.Errorf("decomposed CNPJ = %q", dec.CNPJ)
	}
	if dec.Modelo != nfe.ModeloNFe {
		t.Errorf("decomposed modelo = %q", dec.Modelo)
	}
	if dec.Serie != 1 {
		t.Errorf("decomposed serie = %d", dec.Serie)
	}
	if dec.NNF != 100 {
		t.Errorf("decomposed nNF = %d", dec.NNF)
	}
	if dec.AAMM != "2605" {
		t.Errorf("decomposed AAMM = %q, want 2605", dec.AAMM)
	}
	if dec.CNF != "12345678" {
		t.Errorf("decomposed cNF = %q", dec.CNF)
	}
}

// TestBuilder_MultipleItemsNumberedSequentially asserts that AddDet calls in
// any order produce nItem=1,2,3,... starting from 1 and matching insertion.
func TestBuilder_MultipleItemsNumberedSequentially(t *testing.T) {
	b := minimalNFe(t)

	// add two more items beyond the baseline single one
	for i := 0; i < 2; i++ {
		b.AddDet(&schema.Det{
			Prod: &schema.Prod{
				CProd: "extra", CEAN: "SEM GTIN", XProd: "X",
				NCM: "22021000", CFOP: "5102", UCom: "UN",
				QCom: "1.0000", VUnCom: "1.0000000000", VProd: "1.00",
				CEANTrib: "SEM GTIN", UTrib: "UN", QTrib: "1.0000",
				VUnTrib: "1.0000000000", IndTot: "1",
			},
			Imposto: &schema.Imposto{
				ICMS: &schema.ICMS{ICMS00: &schema.ICMS00{
					Orig: strPtr("0"), CST: strPtr("00"), ModBC: strPtr("3"),
					VBC: strPtr("1.00"), PICMS: strPtr("18.00"), VICMS: strPtr("0.18"),
				}},
			},
		})
	}

	tnfe, err := b.Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	if len(tnfe.InfNFe.Det) != 3 {
		t.Fatalf("got %d items, want 3", len(tnfe.InfNFe.Det))
	}
	for i, det := range tnfe.InfNFe.Det {
		want := []string{"1", "2", "3"}[i]
		if det.NItemAttr != want {
			t.Errorf("Det[%d].nItem = %q, want %q", i, det.NItemAttr, want)
		}
	}
}

// TestBuilder_RoundtripViaXML proves the full pipeline: build → marshal →
// unmarshal → confirm the chave survives intact and is still valid.
// This is the integration test the sprint plan specifies.
func TestBuilder_RoundtripViaXML(t *testing.T) {
	original, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	originalChave := nfe.Chave(strings.TrimPrefix(original.InfNFe.IdAttr, "NFe"))

	xmlBytes := xmltest.MarshalElement(t, "NFe", original)

	var parsed schema.TNFe
	xmltest.UnmarshalElement(t, xmlBytes, "NFe", &parsed)

	if parsed.InfNFe == nil {
		t.Fatal("parsed InfNFe is nil")
	}
	if parsed.InfNFe.IdAttr != original.InfNFe.IdAttr {
		t.Errorf("Id changed across roundtrip:\n  before: %s\n  after:  %s",
			original.InfNFe.IdAttr, parsed.InfNFe.IdAttr)
	}

	parsedChave := nfe.Chave(strings.TrimPrefix(parsed.InfNFe.IdAttr, "NFe"))
	if parsedChave != originalChave {
		t.Errorf("chave changed: %s -> %s", originalChave, parsedChave)
	}
	if err := parsedChave.Validate(); err != nil {
		t.Errorf("parsed chave invalid: %v", err)
	}

	// Idempotência: re-marshal and confirm bytes match.
	xmlBytes2 := xmltest.MarshalElement(t, "NFe", &parsed)
	if string(xmlBytes) != string(xmlBytes2) {
		t.Error("non-idempotent: marshal(parse(marshal(build()))) differs from marshal(build())")
	}
}

func TestBuilder_MissingFields(t *testing.T) {
	t.Run("empty builder reports ide first", func(t *testing.T) {
		_, err := nfe.New().Build()
		if err == nil || !strings.Contains(err.Error(), "ide is required") {
			t.Errorf("err = %v, want 'ide is required'", err)
		}
	})

	t.Run("everything except items reports ErrEmptyItens", func(t *testing.T) {
		// minimalNFe attached one item; rebuild manually without AddDet.
		full := minimalNFe(t)
		stripped := nfe.New()
		// use reflection-free path: re-feed the same blocks except items.
		// The builder's setters are stable, so this stays readable.
		tnfeBaseline, err := full.Build()
		if err != nil {
			t.Fatalf("baseline Build: %v", err)
		}
		stripped.
			Ide(tnfeBaseline.InfNFe.Ide).
			Emit(tnfeBaseline.InfNFe.Emit).
			Dest(tnfeBaseline.InfNFe.Dest).
			Total(tnfeBaseline.InfNFe.Total).
			Transp(tnfeBaseline.InfNFe.Transp).
			Pag(tnfeBaseline.InfNFe.Pag)
		_, err = stripped.Build()
		if !errors.Is(err, nfe.ErrEmptyItens) {
			t.Errorf("err = %v, want ErrEmptyItens", err)
		}
	})

	t.Run("missing transp", func(t *testing.T) {
		full := minimalNFe(t)
		tnfeBaseline, _ := full.Build()
		b := nfe.New().
			Ide(tnfeBaseline.InfNFe.Ide).
			Emit(tnfeBaseline.InfNFe.Emit).
			Dest(tnfeBaseline.InfNFe.Dest).
			AddDet(tnfeBaseline.InfNFe.Det[0]).
			Total(tnfeBaseline.InfNFe.Total).
			Pag(tnfeBaseline.InfNFe.Pag)
		_, err := b.Build()
		if err == nil || !strings.Contains(err.Error(), "transp is required") {
			t.Errorf("err = %v, want 'transp is required'", err)
		}
	})
}

// TestBuilder_BuildIsIdempotent confirms that calling Build twice on the
// same Builder produces structurally equal results — the documented
// contract is that the writes Build performs (ide.cDV, det.nItem) are
// idempotent rewrites of values it computes deterministically.
func TestBuilder_BuildIsIdempotent(t *testing.T) {
	b := minimalNFe(t)
	first, err := b.Build()
	if err != nil {
		t.Fatalf("first Build: %v", err)
	}
	second, err := b.Build()
	if err != nil {
		t.Fatalf("second Build: %v", err)
	}
	if first.InfNFe.IdAttr != second.InfNFe.IdAttr {
		t.Errorf("Id changed across Build calls:\n  first:  %s\n  second: %s",
			first.InfNFe.IdAttr, second.InfNFe.IdAttr)
	}
	if first.InfNFe.Ide.CDV != second.InfNFe.Ide.CDV {
		t.Errorf("cDV changed: %q -> %q", first.InfNFe.Ide.CDV, second.InfNFe.Ide.CDV)
	}
	for i := range first.InfNFe.Det {
		if first.InfNFe.Det[i].NItemAttr != second.InfNFe.Det[i].NItemAttr {
			t.Errorf("Det[%d].nItem changed: %q -> %q",
				i, first.InfNFe.Det[i].NItemAttr, second.InfNFe.Det[i].NItemAttr)
		}
	}
}

// TestBuilder_RejectsIncompleteItems locks in the validation that prevents
// a Det with nil Prod or Imposto from silently producing an invalid NF-e.
func TestBuilder_RejectsIncompleteItems(t *testing.T) {
	t.Run("nil det", func(t *testing.T) {
		b := minimalNFe(t)
		b.AddDet(nil)
		_, err := b.Build()
		if err == nil || !strings.Contains(err.Error(), "is nil") {
			t.Errorf("err = %v, want 'det[1] is nil'", err)
		}
	})
	t.Run("missing Prod", func(t *testing.T) {
		b := minimalNFe(t)
		b.AddDet(&schema.Det{Imposto: &schema.Imposto{}})
		_, err := b.Build()
		if err == nil || !strings.Contains(err.Error(), "Prod is nil") {
			t.Errorf("err = %v, want 'Prod is nil'", err)
		}
	})
	t.Run("missing Imposto", func(t *testing.T) {
		b := minimalNFe(t)
		b.AddDet(&schema.Det{Prod: &schema.Prod{}})
		_, err := b.Build()
		if err == nil || !strings.Contains(err.Error(), "Imposto is nil") {
			t.Errorf("err = %v, want 'Imposto is nil'", err)
		}
	})
}

// TestBuilder_PropagatesChaveValidationErrors verifies that NewChave
// rejection (e.g. malformed CNPJ) bubbles up via errors.Is.
func TestBuilder_PropagatesChaveValidationErrors(t *testing.T) {
	b := minimalNFe(t)
	bogusCNPJ := "12345" // not 14 digits
	b.Emit(&schema.Emit{
		CNPJ:  &bogusCNPJ,
		XNome: "BOGUS",
		EnderEmit: &schema.TEnderEmi{
			XLgr: "X", Nro: "1", XBairro: "X",
			CMun: "4314902", XMun: "X", UF: "RS", CEP: "90000000",
		},
		IE: "1", CRT: "3",
	})
	_, err := b.Build()
	if !errors.Is(err, nfe.ErrInvalidCNPJ) {
		t.Errorf("err = %v, want ErrInvalidCNPJ", err)
	}
}
