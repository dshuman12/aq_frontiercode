package nfe

import "errors"

// Sentinel errors raised by the nfe domain. Wrap them with fmt.Errorf("...: %w", err)
// when adding context; consumers can use errors.Is to branch on cause.

var (
	// Field-level validation
	ErrInvalidTpAmb     = errors.New("tpAmb invalido (esperado 1=Producao ou 2=Homologacao)")
	ErrInvalidModelo    = errors.New("modelo invalido (esperado 55=NF-e ou 65=NFC-e)")
	ErrInvalidTpEmis    = errors.New("tpEmis invalido (esperado 1, 2, 3, 4, 5, 6, 7 ou 9)")
	ErrInvalidIdDest    = errors.New("idDest invalido (esperado 1=interna, 2=interestadual, 3=exterior)")
	ErrInvalidFinNFe    = errors.New("finNFe invalido (esperado 1=normal, 2=complementar, 3=ajuste, 4=devolucao)")
	ErrInvalidIndPres   = errors.New("indPres invalido")
	ErrInvalidIndIEDest = errors.New("indIEDest invalido (esperado 1=contribuinte, 2=isento, 9=nao contribuinte)")
	ErrInvalidProcEmi   = errors.New("procEmi invalido")

	// Identification
	ErrInvalidCNPJ        = errors.New("CNPJ invalido")
	ErrInvalidCPF         = errors.New("CPF invalido")
	ErrInvalidIE          = errors.New("Inscricao Estadual invalida para a UF")
	ErrInvalidUF          = errors.New("UF invalida")
	ErrInvalidNCM         = errors.New("NCM invalido (esperado 8 digitos)")
	ErrInvalidCFOP        = errors.New("CFOP invalido")
	ErrInvalidCNF         = errors.New("cNF invalido (esperado 8 digitos numericos)")
	ErrInvalidDhEmi       = errors.New("dhEmi invalido (timestamp zero ou ausente)")
	ErrInvalidChaveLength = errors.New("chave NF-e deve ter exatamente 44 digitos")
	ErrInvalidChaveDV     = errors.New("digito verificador (DV) da chave NF-e invalido")
	ErrInvalidChaveDigit  = errors.New("chave NF-e contem caractere nao numerico")

	// Structural
	ErrEmptyItens         = errors.New("NF-e deve conter ao menos um item")
	ErrTooManyItens       = errors.New("NF-e excedeu o limite de 990 itens definido no leiaute")
	ErrInvalidSerie       = errors.New("serie invalida (esperado 0-999)")
	ErrInvalidNNF         = errors.New("numero da NF-e invalido (esperado 1-999999999)")
	ErrInvalidValorTotal  = errors.New("valor total inconsistente com a soma dos itens")
	ErrAmbienteIncorreto  = errors.New("operacao nao permitida para o ambiente atual")
	ErrEmitenteSemCert    = errors.New("emitente nao possui certificado digital configurado")

	// Lifecycle
	ErrNotAuthorized      = errors.New("operacao requer NF-e em estado AUTORIZADA")
	ErrCancelWindowClosed = errors.New("janela legal de cancelamento (24h) expirou; emitir CCe ou cancelamento extemporaneo")
	ErrTooManyCCe         = errors.New("limite de 20 cartas de correcao por NF-e atingido")
	ErrFieldNotCorrigible = errors.New("campo nao corrigible via CCe (valor, NCM, dados emitente/destinatario)")

	// Wire / SEFAZ
	ErrSefazUnavailable = errors.New("servico SEFAZ indisponivel")
	ErrSefazRejected    = errors.New("SEFAZ rejeitou a operacao")
)
