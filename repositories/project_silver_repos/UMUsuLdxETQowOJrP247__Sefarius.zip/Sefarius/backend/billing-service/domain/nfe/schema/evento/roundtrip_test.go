package evento

import (
	"testing"

	"github.com/sefarius/billing-service/internal/xmltest"
)

// Manifestação Destinatário (tpEvento 210210 — Ciência da Operação) uses the
// generic event envelope, so it exercises types in this sub-package rather
// than the CCe/canc specializations.
func TestUnmarshalEnvEvento_Manifestacao(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_manifesta.xml")
	var env TEnvEvento
	xmltest.UnmarshalElement(t, data, "envEvento", &env)

	if env.VersaoAttr != "1.00" {
		t.Errorf("versao = %q, want 1.00", env.VersaoAttr)
	}
	if env.IdLote != "201704091147536" {
		t.Errorf("idLote = %q, want 201704091147536", env.IdLote)
	}
	if len(env.Evento) != 1 {
		t.Fatalf("expected 1 evento, got %d", len(env.Evento))
	}
	ev := env.Evento[0]
	if ev.InfEvento == nil {
		t.Fatal("infEvento nil")
	}
	if ev.InfEvento.TpEvento != "210210" {
		t.Errorf("tpEvento = %q, want 210210 (Ciência da Operação)", ev.InfEvento.TpEvento)
	}
	if ev.InfEvento.ChNFe != "29161211351930000106550010000000151000000151" {
		t.Errorf("chNFe mismatch: %q", ev.InfEvento.ChNFe)
	}
}

func TestRoundtripEnvEvento_Manifestacao(t *testing.T) {
	data := xmltest.MustReadFixture(t, "testdata/req_evento_manifesta.xml")
	var s1, s2 TEnvEvento
	xmltest.AssertIdempotent(t, data, "envEvento", &s1, &s2)
}
