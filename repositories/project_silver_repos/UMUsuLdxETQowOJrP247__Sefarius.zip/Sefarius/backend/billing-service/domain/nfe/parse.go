package nfe

import (
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"io"

	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// ParseSignedNFe decodes a stored signed NFe XML back into a typed
// *schema.TNFe. The <ds:Signature> sibling of <infNFe> is ignored —
// callers consuming the typed model (DANFE renderers, the HTTP layer
// that exports re-decoded summaries, etc.) read fields off InfNFe and
// a parsing failure on the signature would block legitimate work even
// though the bytes are the authoritative fiscal source. Strict
// signature verification is the job of nfe.VerifySignature, not this
// helper.
//
// Consolidated in sprint 2.2 follow-up so the renderer (in danfe) and
// the HTTP handler (in interfaces) share one implementation. Drift
// between two private copies was a real risk and reviewing-time
// surprise.
func ParseSignedNFe(b []byte) (*schema.TNFe, error) {
	dec := xml.NewDecoder(bytes.NewReader(b))
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			return nil, errors.New("nfe.ParseSignedNFe: NFe element not found in stored XML")
		}
		if err != nil {
			return nil, fmt.Errorf("nfe.ParseSignedNFe: decode token: %w", err)
		}
		start, ok := tok.(xml.StartElement)
		if !ok || start.Name.Local != "NFe" {
			continue
		}
		tnfe := &schema.TNFe{}
		if err := dec.DecodeElement(tnfe, &start); err != nil {
			return nil, fmt.Errorf("nfe.ParseSignedNFe: decode NFe: %w", err)
		}
		return tnfe, nil
	}
}
