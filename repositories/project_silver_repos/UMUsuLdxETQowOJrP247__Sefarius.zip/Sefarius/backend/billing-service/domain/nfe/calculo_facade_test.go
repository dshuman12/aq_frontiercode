package nfe_test

import (
	"math/big"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/internal/xmltest"
)

// makeProd returns a minimal Prod block for tests. The xProd is the only
// field that varies test-to-test in this file.
func makeProd(xProd string) *schema.Prod {
	return &schema.Prod{
		CProd:    "001",
		CEAN:     "SEM GTIN",
		XProd:    xProd,
		NCM:      "22021000",
		CFOP:     "5102",
		UCom:     "UN",
		QCom:     "1.0000",
		VUnCom:   "100.0000000000",
		VProd:    "100.00",
		CEANTrib: "SEM GTIN",
		UTrib:    "UN",
		QTrib:    "1.0000",
		VUnTrib:  "100.0000000000",
		IndTot:   "1",
	}
}

func TestNewDetRegimeNormalCST00(t *testing.T) {
	det, err := nfe.NewDetRegimeNormalCST00(makeProd("VENDA TRIB"), "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	if det.Prod == nil || det.Imposto == nil {
		t.Fatal("Prod or Imposto nil")
	}
	icms := det.Imposto.ICMS.ICMS00
	if icms == nil {
		t.Fatal("ICMS00 nil")
	}
	if *icms.VICMS != "18.00" {
		t.Errorf("vICMS = %q, want 18.00", *icms.VICMS)
	}
	if det.Imposto.PIS.PISAliq == nil || *det.Imposto.PIS.PISAliq.VPIS != "1.65" {
		t.Errorf("vPIS missing or wrong")
	}
	if det.Imposto.COFINS.COFINSAliq == nil || *det.Imposto.COFINS.COFINSAliq.VCOFINS != "7.60" {
		t.Errorf("vCOFINS missing or wrong")
	}
}

func TestNewDetRegimeNormalCST00_PropagatesErrors(t *testing.T) {
	_, err := nfe.NewDetRegimeNormalCST00(makeProd("X"), "abc", "18.00", "1.65", "7.60")
	if err == nil {
		t.Fatal("expected error from bad vBC")
	}
}

func TestNewDetRegimeNormalCST00_NilProd(t *testing.T) {
	_, err := nfe.NewDetRegimeNormalCST00(nil, "100", "18", "1.65", "7.60")
	if err == nil || !strings.Contains(err.Error(), "prod is nil") {
		t.Errorf("err = %v, want 'prod is nil'", err)
	}
}

func TestNewDetSimplesCSOSN102(t *testing.T) {
	det, err := nfe.NewDetSimplesCSOSN102(makeProd("VENDA SN"), "0")
	if err != nil {
		t.Fatalf("err = %v", err)
	}
	icmsSN := det.Imposto.ICMS.ICMSSN102
	if icmsSN == nil || *icmsSN.CSOSN != "102" {
		t.Errorf("CSOSN missing or wrong")
	}
	if det.Imposto.PIS.PISOutr == nil || *det.Imposto.PIS.PISOutr.CST != "49" {
		t.Errorf("PIS CST 49 missing")
	}
	if det.Imposto.COFINS.COFINSOutr == nil || *det.Imposto.COFINS.COFINSOutr.CST != "49" {
		t.Errorf("COFINS CST 49 missing")
	}
	// SN: per-item tax amounts are zero
	if *det.Imposto.PIS.PISOutr.VPIS != "0.00" {
		t.Errorf("PIS VPIS = %q, want 0.00", *det.Imposto.PIS.PISOutr.VPIS)
	}
}

// TestFacades_MultipleItemsAccumulate locks the cross-item invariant: the
// sum of per-item rounded values must survive a marshal/unmarshal cycle
// unchanged. Building 3 items via the facade, summing each block before
// the cycle, and comparing with the post-cycle sum catches the most
// common ERP bug class — "centavos faltando" caused by accumulation
// mistakes between round-by-item and round-of-sum.
func TestFacades_MultipleItemsAccumulate(t *testing.T) {
	specs := []struct {
		xProd                            string
		vBC, pICMS, pPIS, pCOFINS        string
	}{
		{"PRODUTO A", "40.79", "12.00", "1.65", "7.60"},
		{"PRODUTO B", "33.45", "18.00", "1.65", "7.60"},
		{"PRODUTO C", "1234.56", "17.00", "1.65", "7.60"},
	}

	preSumVICMS := new(big.Rat)
	preSumVPIS := new(big.Rat)
	preSumVCOFINS := new(big.Rat)
	dets := make([]*schema.Det, 0, len(specs))

	for _, s := range specs {
		det, err := nfe.NewDetRegimeNormalCST00(makeProd(s.xProd), s.vBC, s.pICMS, s.pPIS, s.pCOFINS)
		if err != nil {
			t.Fatalf("%s: %v", s.xProd, err)
		}
		addRat(t, preSumVICMS, *det.Imposto.ICMS.ICMS00.VICMS)
		addRat(t, preSumVPIS, *det.Imposto.PIS.PISAliq.VPIS)
		addRat(t, preSumVCOFINS, *det.Imposto.COFINS.COFINSAliq.VCOFINS)
		dets = append(dets, det)
	}

	// Build NFe with all 3 items and roundtrip via XML.
	baseline, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("baseline Build: %v", err)
	}
	b := nfe.New().
		Ide(baseline.InfNFe.Ide).Emit(baseline.InfNFe.Emit).Dest(baseline.InfNFe.Dest).
		Total(baseline.InfNFe.Total).Transp(baseline.InfNFe.Transp).Pag(baseline.InfNFe.Pag)
	for _, d := range dets {
		b.AddDet(d)
	}
	rebuilt, err := b.Build()
	if err != nil {
		t.Fatalf("rebuild: %v", err)
	}

	xmlBytes := xmltest.MarshalElement(t, "NFe", rebuilt)
	var parsed schema.TNFe
	xmltest.UnmarshalElement(t, xmlBytes, "NFe", &parsed)

	if len(parsed.InfNFe.Det) != 3 {
		t.Fatalf("expected 3 dets, got %d", len(parsed.InfNFe.Det))
	}

	postSumVICMS := new(big.Rat)
	postSumVPIS := new(big.Rat)
	postSumVCOFINS := new(big.Rat)
	for _, d := range parsed.InfNFe.Det {
		addRat(t, postSumVICMS, *d.Imposto.ICMS.ICMS00.VICMS)
		addRat(t, postSumVPIS, *d.Imposto.PIS.PISAliq.VPIS)
		addRat(t, postSumVCOFINS, *d.Imposto.COFINS.COFINSAliq.VCOFINS)
	}

	if preSumVICMS.Cmp(postSumVICMS) != 0 {
		t.Errorf("ICMS sum diverged: pre=%s post=%s",
			preSumVICMS.FloatString(2), postSumVICMS.FloatString(2))
	}
	if preSumVPIS.Cmp(postSumVPIS) != 0 {
		t.Errorf("PIS sum diverged: pre=%s post=%s",
			preSumVPIS.FloatString(2), postSumVPIS.FloatString(2))
	}
	if preSumVCOFINS.Cmp(postSumVCOFINS) != 0 {
		t.Errorf("COFINS sum diverged: pre=%s post=%s",
			preSumVCOFINS.FloatString(2), postSumVCOFINS.FloatString(2))
	}
}

func addRat(t *testing.T, acc *big.Rat, decimal string) {
	t.Helper()
	v, ok := new(big.Rat).SetString(decimal)
	if !ok {
		t.Fatalf("could not parse %q as decimal", decimal)
	}
	acc.Add(acc, v)
}

// TestFacades_RoundtripViaXML is the integration test the sprint specifies:
// build a complete NFe using the facades, marshal it through xml.Encoder,
// re-parse it, and confirm the chave is valid AND the per-item tax values
// are byte-identical.
func TestFacades_RoundtripViaXML(t *testing.T) {
	det, err := nfe.NewDetRegimeNormalCST00(makeProd("PRODUTO TESTE"), "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDetRegimeNormalCST00: %v", err)
	}

	// Reuse minimalNFe but swap its Det for one built via the facade.
	b := minimalNFe(t)
	original, err := b.Build()
	if err != nil {
		t.Fatalf("baseline Build: %v", err)
	}
	// Replace the single Det with one built via the facade and rebuild.
	original.InfNFe.Det = []*schema.Det{det}
	b2 := nfe.New().
		Ide(original.InfNFe.Ide).
		Emit(original.InfNFe.Emit).
		Dest(original.InfNFe.Dest).
		AddDet(det).
		Total(original.InfNFe.Total).
		Transp(original.InfNFe.Transp).
		Pag(original.InfNFe.Pag)
	rebuilt, err := b2.Build()
	if err != nil {
		t.Fatalf("rebuild with facade Det: %v", err)
	}

	xmlBytes := xmltest.MarshalElement(t, "NFe", rebuilt)
	var parsed schema.TNFe
	xmltest.UnmarshalElement(t, xmlBytes, "NFe", &parsed)

	chave := nfe.Chave(strings.TrimPrefix(parsed.InfNFe.IdAttr, "NFe"))
	if err := chave.Validate(); err != nil {
		t.Errorf("chave invalid after roundtrip: %v", err)
	}

	parsedDet := parsed.InfNFe.Det[0]
	if *parsedDet.Imposto.ICMS.ICMS00.VICMS != "18.00" {
		t.Errorf("vICMS lost across roundtrip: got %q", *parsedDet.Imposto.ICMS.ICMS00.VICMS)
	}
	if *parsedDet.Imposto.PIS.PISAliq.VPIS != "1.65" {
		t.Errorf("vPIS lost across roundtrip: got %q", *parsedDet.Imposto.PIS.PISAliq.VPIS)
	}
	if *parsedDet.Imposto.COFINS.COFINSAliq.VCOFINS != "7.60" {
		t.Errorf("vCOFINS lost across roundtrip: got %q", *parsedDet.Imposto.COFINS.COFINSAliq.VCOFINS)
	}
}
