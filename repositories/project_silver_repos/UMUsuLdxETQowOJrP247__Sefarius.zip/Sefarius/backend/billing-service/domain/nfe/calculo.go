package nfe

import (
	"fmt"
	"math/big"
	"strings"

	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// Decimal helpers backed by math/big.Rat.
//
// Why not float64: SEFAZ requires exact decimal output ("100.00", not
// "99.999999..."). float64 cannot represent 0.1 + 0.2 == 0.3, which is
// catastrophic when adding line totals. *big.Rat is exact.
//
// Why not big.Float: also produces non-deterministic IEEE-754-ish output
// when formatted; Rat normalizes to exact rationals so the rounding step
// is the only place precision is lost — and we control that step.

// parseDecimal converts a SEFAZ-formatted decimal string into a *big.Rat.
// Accepts any precision ("100", "100.00", "18.0000", "-1.5").
func parseDecimal(s string) (*big.Rat, error) {
	r := new(big.Rat)
	if _, ok := r.SetString(s); !ok {
		return nil, fmt.Errorf("invalid decimal %q", s)
	}
	return r, nil
}

// formatDecimal renders a *big.Rat with `decimals` decimal places using
// arithmetic rounding (half away from zero) — the convention SEFAZ
// requires. math/big.Rat.FloatString uses banker's rounding, which
// disagrees on half-cases (e.g. 0.005), so this is a manual implementation.
func formatDecimal(r *big.Rat, decimals int) string {
	if decimals < 0 {
		decimals = 0
	}
	// Scale by 10^decimals, then round-to-integer half-up.
	scale := new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(decimals)), nil)
	scaled := new(big.Rat).Mul(r, new(big.Rat).SetInt(scale))

	n, d := scaled.Num(), scaled.Denom() // d is always positive after normalization
	quot := new(big.Int).Quo(n, d)
	rem := new(big.Int).Rem(n, d)

	// Round half-up: if 2*|rem| >= d, step away from zero.
	twoAbsRem := new(big.Int).Lsh(new(big.Int).Abs(rem), 1)
	if twoAbsRem.Cmp(d) >= 0 {
		if n.Sign() >= 0 {
			quot.Add(quot, big.NewInt(1))
		} else {
			quot.Sub(quot, big.NewInt(1))
		}
	}

	sign := ""
	if quot.Sign() < 0 {
		sign = "-"
		quot.Abs(quot)
	}
	digits := quot.String()
	if decimals == 0 {
		return sign + digits
	}
	if len(digits) <= decimals {
		digits = strings.Repeat("0", decimals-len(digits)+1) + digits
	}
	return sign + digits[:len(digits)-decimals] + "." + digits[len(digits)-decimals:]
}

// computeTax returns vBC × rate / 100 as an unrounded *big.Rat.
// Rounding happens at format time (via formatDecimal).
func computeTax(vBC, rate *big.Rat) *big.Rat {
	out := new(big.Rat).Mul(vBC, rate)
	return out.Quo(out, big.NewRat(100, 1))
}

// validateBase rejects negative values for tax bases — SEFAZ doesn't
// accept negative bases on any CST/CSOSN this sprint covers.
func validateBase(vBC *big.Rat) error {
	if vBC.Sign() < 0 {
		return fmt.Errorf("base de cálculo negativa: %s", formatDecimal(vBC, 2))
	}
	return nil
}

// validateRate rejects rates outside [0, 100].
func validateRate(rate *big.Rat, name string) error {
	if rate.Sign() < 0 {
		return fmt.Errorf("%s negativa: %s", name, formatDecimal(rate, 4))
	}
	if rate.Cmp(big.NewRat(100, 1)) > 0 {
		return fmt.Errorf("%s excede 100%%: %s", name, formatDecimal(rate, 4))
	}
	return nil
}

// validOrigens enumerates the leiaute v4 origin codes (campo "orig") for
// merchandise. 0-2 are domestic vs imported categories; 3-8 distinguish
// Conteúdo de Importação tiers and processos básicos exemptions.
var validOrigens = map[string]bool{
	"0": true, "1": true, "2": true, "3": true, "4": true,
	"5": true, "6": true, "7": true, "8": true,
}

// validateOrig accepts only the 9 codes defined by the leiaute.
func validateOrig(orig string) error {
	if !validOrigens[orig] {
		return fmt.Errorf("origem %q invalida (esperado 0-8)", orig)
	}
	return nil
}

// ─── Calculators ─────────────────────────────────────────────────────────────

// ICMSNormalCST00 builds an ICMS00 block — regime normal, tributada
// integralmente. Inputs are decimal strings:
//
//   - vBC:   base de cálculo (e.g. "100.00")
//   - pICMS: alíquota em percentual (e.g. "18.00" for 18%)
//
// Computes vICMS = vBC × pICMS / 100, rounded half-up to 2 decimals.
// Origem defaults to "0" (Nacional); modBC to "3" (valor da operação,
// most common). FCP variants (PFCP/VFCP) are not populated — those need
// a separate helper when FCP applies.
func ICMSNormalCST00(vBC, pICMS string) (*schema.ICMS00, error) {
	base, err := parseDecimal(vBC)
	if err != nil {
		return nil, fmt.Errorf("ICMSNormalCST00 vBC: %w", err)
	}
	if err := validateBase(base); err != nil {
		return nil, fmt.Errorf("ICMSNormalCST00: %w", err)
	}
	rate, err := parseDecimal(pICMS)
	if err != nil {
		return nil, fmt.Errorf("ICMSNormalCST00 pICMS: %w", err)
	}
	if err := validateRate(rate, "pICMS"); err != nil {
		return nil, fmt.Errorf("ICMSNormalCST00: %w", err)
	}

	vICMS := computeTax(base, rate)

	orig := "0"
	cst := "00"
	modBC := "3"
	vBCFmt := formatDecimal(base, 2)
	pICMSFmt := formatDecimal(rate, 4)
	vICMSFmt := formatDecimal(vICMS, 2)

	return &schema.ICMS00{
		Orig:  &orig,
		CST:   &cst,
		ModBC: &modBC,
		VBC:   &vBCFmt,
		PICMS: &pICMSFmt,
		VICMS: &vICMSFmt,
	}, nil
}

// PISAliq01 builds a PISAliq block — CST 01, "Operação Tributável com
// Alíquota Básica". vPIS = vBC × pPIS / 100, rounded half-up to 2 decimals.
func PISAliq01(vBC, pPIS string) (*schema.PISAliq, error) {
	base, err := parseDecimal(vBC)
	if err != nil {
		return nil, fmt.Errorf("PISAliq01 vBC: %w", err)
	}
	if err := validateBase(base); err != nil {
		return nil, fmt.Errorf("PISAliq01: %w", err)
	}
	rate, err := parseDecimal(pPIS)
	if err != nil {
		return nil, fmt.Errorf("PISAliq01 pPIS: %w", err)
	}
	if err := validateRate(rate, "pPIS"); err != nil {
		return nil, fmt.Errorf("PISAliq01: %w", err)
	}

	vPIS := computeTax(base, rate)

	cst := "01"
	vBCFmt := formatDecimal(base, 2)
	pPISFmt := formatDecimal(rate, 4)
	vPISFmt := formatDecimal(vPIS, 2)

	return &schema.PISAliq{
		CST:  &cst,
		VBC:  &vBCFmt,
		PPIS: &pPISFmt,
		VPIS: &vPISFmt,
	}, nil
}

// ICMSSimplesCSOSN102 builds an ICMSSN102 block — Simples Nacional, CSOSN
// 102 ("Tributada pelo Simples Nacional sem permissão de crédito"). The
// per-item ICMS amount is zero on the NF-e because Simples Nacional
// issuers pay ICMS unified via DAS; only origem and CSOSN are emitted.
//
// orig is one of "0"-"8" per the leiaute (see validOrigens for meanings).
// The same struct shape covers CSOSN 103, 300 and 400; this helper is
// specifically for CSOSN 102 — the most common SN code.
func ICMSSimplesCSOSN102(orig string) (*schema.ICMSSN102, error) {
	if err := validateOrig(orig); err != nil {
		return nil, fmt.Errorf("ICMSSimplesCSOSN102: %w", err)
	}
	csosn := "102"
	return &schema.ICMSSN102{
		Orig:  &orig,
		CSOSN: &csosn,
	}, nil
}

// ICMSNormalCST40 builds an ICMS40 block — CST 40 ("Isenta") for regime
// normal, without desoneração. The struct shape (ICMS40) also serves
// CST 41 ("Não tributada") and CST 50 ("Suspensão") in the leiaute, but
// this helper is specifically for CST 40 — the most common isenção code.
// For desonerada variants (vICMSDeson + motDesICMS + indDeduzDeson),
// add a dedicated helper in a future sprint.
func ICMSNormalCST40(orig string) (*schema.ICMS40, error) {
	if err := validateOrig(orig); err != nil {
		return nil, fmt.Errorf("ICMSNormalCST40: %w", err)
	}
	cst := "40"
	return &schema.ICMS40{
		Orig: &orig,
		CST:  &cst,
	}, nil
}

// ICMSSimplesCSOSN400 builds an ICMSSN102 block with CSOSN 400 — "Não
// tributada pelo Simples Nacional". Same struct shape as CSOSN 102.
func ICMSSimplesCSOSN400(orig string) (*schema.ICMSSN102, error) {
	if err := validateOrig(orig); err != nil {
		return nil, fmt.Errorf("ICMSSimplesCSOSN400: %w", err)
	}
	csosn := "400"
	return &schema.ICMSSN102{
		Orig:  &orig,
		CSOSN: &csosn,
	}, nil
}

// PISCST49 builds a zeroed PISOutr block with CST 49 ("Outras Operações
// de Saída"). Typical for Simples Nacional issuers, where PIS is paid
// unified via DAS so the per-item amount is zero. Returned struct has
// vBC=0.00, pPIS=0.0000, vPIS=0.00.
func PISCST49() *schema.PISOutr {
	cst := "49"
	vbc := "0.00"
	ppis := "0.0000"
	vpis := "0.00"
	return &schema.PISOutr{
		CST:  &cst,
		VBC:  &vbc,
		PPIS: &ppis,
		VPIS: &vpis,
	}
}

// COFINSCST49 builds a zeroed COFINSOutr block with CST 49. Same SN
// rationale as PISCST49.
func COFINSCST49() *schema.COFINSOutr {
	cst := "49"
	vbc := "0.00"
	pcofins := "0.0000"
	vcofins := "0.00"
	return &schema.COFINSOutr{
		CST:     &cst,
		VBC:     &vbc,
		PCOFINS: &pcofins,
		VCOFINS: &vcofins,
	}
}

// ─── Facades — pre-assembled Det for the most common scenarios ──────────────
//
// These compose Prod with the right ICMS/PIS/COFINS sub-blocks for each
// canonical fiscal scenario, returning a *schema.Det ready to be passed
// to Builder.AddDet. They are higher-level than the per-block calculators
// above and represent the 80% case that callers will actually need.

// NewDetRegimeNormalCST00 builds a Det for the most common Brazilian sale:
// regime normal issuer, mercadoria tributada integralmente (ICMS CST 00),
// with PIS/COFINS CST 01. All three rates (pICMS, pPIS, pCOFINS) are
// applied to the same vBC.
//
// TODO(future): allow distinct vBC for PIS/COFINS. In real operations the
// PIS/COFINS base can diverge from the ICMS base — typically when
// vICMSDeson, frete or seguro adjustments differ between estadual and
// federal tributes. The fixture nfe_v4.xml shows this divergence in the
// wild (ICMS vBC=40.79 with frete vs PIS/COFINS vBC=33.45 without). For
// now, callers needing divergent bases should compose the per-block
// calculators (ICMSNormalCST00 + PISAliq01 + COFINSAliq01) directly.
func NewDetRegimeNormalCST00(prod *schema.Prod, vBC, pICMS, pPIS, pCOFINS string) (*schema.Det, error) {
	if prod == nil {
		return nil, fmt.Errorf("NewDetRegimeNormalCST00: prod is nil")
	}
	icms00, err := ICMSNormalCST00(vBC, pICMS)
	if err != nil {
		return nil, fmt.Errorf("NewDetRegimeNormalCST00: %w", err)
	}
	pis, err := PISAliq01(vBC, pPIS)
	if err != nil {
		return nil, fmt.Errorf("NewDetRegimeNormalCST00: %w", err)
	}
	cofins, err := COFINSAliq01(vBC, pCOFINS)
	if err != nil {
		return nil, fmt.Errorf("NewDetRegimeNormalCST00: %w", err)
	}
	return &schema.Det{
		Prod: prod,
		Imposto: &schema.Imposto{
			ICMS:   &schema.ICMS{ICMS00: icms00},
			PIS:    &schema.PIS{PISAliq: pis},
			COFINS: &schema.COFINS{COFINSAliq: cofins},
		},
	}, nil
}

// NewDetSimplesCSOSN102 builds a Det for a Simples Nacional issuer with
// CSOSN 102 ("Tributada sem permissão de crédito") combined with
// PIS/COFINS CST 49 zeroed.
//
// FISCAL CAVEAT: the CST 49 + zero values combination is the dominant
// pattern for SN issuers (validated against the procNFe.xml upstream
// fixture, which uses the same shape) because regime SN pays PIS/COFINS
// unified via DAS. However it is NOT universal — specific regimes
// (Simples-MEI, monofásico de combustíveis, contribuições sobre vendas a
// órgãos públicos) may legally require PIS/COFINS CST 04 (alíquota zero)
// or CST 06. Confirm against your accountant for non-standard cases; when
// in doubt, compose the per-block calculators (ICMSSimplesCSOSN102 + a
// PIS/COFINS pair chosen for the specific scenario) directly.
//
// orig is one of "0"-"8" per validOrigens.
func NewDetSimplesCSOSN102(prod *schema.Prod, orig string) (*schema.Det, error) {
	if prod == nil {
		return nil, fmt.Errorf("NewDetSimplesCSOSN102: prod is nil")
	}
	icmsSN, err := ICMSSimplesCSOSN102(orig)
	if err != nil {
		return nil, fmt.Errorf("NewDetSimplesCSOSN102: %w", err)
	}
	return &schema.Det{
		Prod: prod,
		Imposto: &schema.Imposto{
			ICMS:   &schema.ICMS{ICMSSN102: icmsSN},
			PIS:    &schema.PIS{PISOutr: PISCST49()},
			COFINS: &schema.COFINS{COFINSOutr: COFINSCST49()},
		},
	}, nil
}

// ICMS CST 40 has no companion Det facade because federal CSTs are
// determined independently from the ICMS estadual CST. PIS/COFINS for an
// isenção scenario may legitimately be CST 06 (alíquota zero), CST 07
// (isenta), CST 09 (suspensão) or CST 49 (outras) — depends on product and
// legal regime, no safe one-size-fits-all. Use ICMSNormalCST40 paired with
// a PIS/COFINS calculator chosen for the specific case.

// COFINSAliq01 builds a COFINSAliq block — CST 01. Same shape as PIS.
func COFINSAliq01(vBC, pCOFINS string) (*schema.COFINSAliq, error) {
	base, err := parseDecimal(vBC)
	if err != nil {
		return nil, fmt.Errorf("COFINSAliq01 vBC: %w", err)
	}
	if err := validateBase(base); err != nil {
		return nil, fmt.Errorf("COFINSAliq01: %w", err)
	}
	rate, err := parseDecimal(pCOFINS)
	if err != nil {
		return nil, fmt.Errorf("COFINSAliq01 pCOFINS: %w", err)
	}
	if err := validateRate(rate, "pCOFINS"); err != nil {
		return nil, fmt.Errorf("COFINSAliq01: %w", err)
	}

	vCOFINS := computeTax(base, rate)

	cst := "01"
	vBCFmt := formatDecimal(base, 2)
	pCOFINSFmt := formatDecimal(rate, 4)
	vCOFINSFmt := formatDecimal(vCOFINS, 2)

	return &schema.COFINSAliq{
		CST:     &cst,
		VBC:     &vBCFmt,
		PCOFINS: &pCOFINSFmt,
		VCOFINS: &vCOFINSFmt,
	}, nil
}
