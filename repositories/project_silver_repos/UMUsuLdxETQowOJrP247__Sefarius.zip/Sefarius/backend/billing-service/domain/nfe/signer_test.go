package nfe_test

import (
	"bytes"
	"crypto/rsa"
	"errors"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/internal/xmltest"
)

// signedNFe builds the canonical baseline NF-e, marshals it under a <NFe>
// root, and signs it with a freshly generated self-signed certificate.
// Returns the signed bytes plus the cert (in case the test needs to inspect
// the public key).
func signedNFe(t *testing.T) ([]byte, *nfe.Certificate) {
	t.Helper()

	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	xmlBytes := xmltest.MarshalElement(t, "NFe", tnfe)

	cert, err := nfe.GenerateSelfSignedTest("Sefarius Test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}

	signed, err := nfe.Sign(xmlBytes, cert)
	if err != nil {
		t.Fatalf("Sign: %v", err)
	}
	return signed, cert
}

// TestSign_ProducesVerifiableSignature is the headline contract of the
// sprint: a Builder-produced NF-e signed with a fresh self-signed cert
// must verify against itself.
func TestSign_ProducesVerifiableSignature(t *testing.T) {
	signed, _ := signedNFe(t)

	// goxmldsig emits the XMLDSig namespace as the "ds:" prefix; both the
	// prefixed and default-namespace forms are valid XMLDSig per W3C, and
	// SEFAZ accepts both. We assert against the prefixed form because that
	// is what our pipeline produces today.
	if !bytes.Contains(signed, []byte("<ds:Signature")) {
		t.Fatalf("signed XML missing <ds:Signature> element:\n%s", signed)
	}
	if !bytes.Contains(signed, []byte("<ds:X509Certificate>")) {
		t.Fatal("signed XML missing <ds:X509Certificate> in KeyInfo")
	}
	if err := nfe.VerifySignature(signed); err != nil {
		t.Fatalf("VerifySignature: %v", err)
	}
}

// TestSign_UsesRSASHA1AndC14N10 locks in the SEFAZ-mandated wire
// algorithms. SHA-1 + RSA-SHA1 + C14N 1.0 inclusive is the leiaute v4.00
// contract — drifting away breaks every UF authorization server.
func TestSign_UsesRSASHA1AndC14N10(t *testing.T) {
	signed, _ := signedNFe(t)
	expected := []string{
		`Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"`, // C14N 1.0 inclusive
		`Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"`,
		`Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"`,
		`Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"`,
	}
	for _, want := range expected {
		if !bytes.Contains(signed, []byte(want)) {
			t.Errorf("signed XML missing %q:\n%s", want, signed)
		}
	}
}

// TestSign_ReferencesInfNFeId asserts the Reference URI matches the
// infNFe Id attribute. Bug class: signing the wrong element yields a
// signature that verifies cryptographically but SEFAZ rejects with
// "ID da Assinatura difere do ID do XML" (rejection 215).
func TestSign_ReferencesInfNFeId(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	xmlBytes := xmltest.MarshalElement(t, "NFe", tnfe)
	cert, err := nfe.GenerateSelfSignedTest("ref-test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	signed, err := nfe.Sign(xmlBytes, cert)
	if err != nil {
		t.Fatalf("Sign: %v", err)
	}

	wantURI := `URI="#` + tnfe.InfNFe.IdAttr + `"`
	if !bytes.Contains(signed, []byte(wantURI)) {
		t.Errorf("Reference URI missing %s:\n%s", wantURI, signed)
	}
}

// TestVerifySignature_DetectsTampering proves the signature actually
// guards content. Modifying any part of <infNFe> after signing must
// break verification.
func TestVerifySignature_DetectsTampering(t *testing.T) {
	signed, _ := signedNFe(t)

	tampered := bytes.Replace(signed, []byte("EMPRESA TESTE LTDA"), []byte("EMPRESA HACKED LTDA"), 1)
	if bytes.Equal(tampered, signed) {
		t.Fatal("test setup error: replacement target not found in signed XML")
	}

	if err := nfe.VerifySignature(tampered); err == nil {
		t.Fatal("VerifySignature accepted tampered XML")
	}
}

// TestSign_RejectsXMLWithoutInfNFe documents the precondition: callers
// must marshal a <NFe> wrapper before signing. We surface a sentinel
// error so the missing-element case is distinguishable from generic
// parse failures in upstream handlers.
func TestSign_RejectsXMLWithoutInfNFe(t *testing.T) {
	cert, err := nfe.GenerateSelfSignedTest("no-infNFe")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	_, err = nfe.Sign([]byte(`<root><wrong/></root>`), cert)
	if !errors.Is(err, nfe.ErrInfNFeMissing) {
		t.Errorf("err = %v, want ErrInfNFeMissing", err)
	}
}

// TestVerifySignature_RejectsUnsignedXML symmetrical to the above:
// the unsigned NFe has no <Signature>, and verification surfaces a
// distinct sentinel rather than a vague parse error.
func TestVerifySignature_RejectsUnsignedXML(t *testing.T) {
	tnfe, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	xmlBytes := xmltest.MarshalElement(t, "NFe", tnfe)

	if err := nfe.VerifySignature(xmlBytes); !errors.Is(err, nfe.ErrSignatureMissing) {
		t.Errorf("err = %v, want ErrSignatureMissing", err)
	}
}

// TestGenerateSelfSignedTest_ProducesUsableRSAKey is a sanity guard
// against accidental refactors: the test cert factory must yield a
// 2048-bit RSA key with NotAfter in the future. Sprint 1.5 takes a hard
// dependency on RSA — SEFAZ XMLDSig does not accept anything else.
func TestGenerateSelfSignedTest_ProducesUsableRSAKey(t *testing.T) {
	cert, err := nfe.GenerateSelfSignedTest("CN-check")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	if cert.PrivateKey == nil {
		t.Fatal("PrivateKey is nil")
	}
	if _, ok := any(cert.PrivateKey).(*rsa.PrivateKey); !ok {
		t.Fatal("PrivateKey is not *rsa.PrivateKey")
	}
	if got := cert.PrivateKey.N.BitLen(); got != 2048 {
		t.Errorf("RSA modulus bit length = %d, want 2048", got)
	}
	if !strings.Contains(cert.X509.Subject.CommonName, "CN-check") {
		t.Errorf("Subject CN = %q, want it to contain %q", cert.X509.Subject.CommonName, "CN-check")
	}
}

// TestSign_RejectsAlreadySignedDocument guards against silent duplicate
// signing. SEFAZ rejection 252 ("rejeição: ambiente de homologação...")
// is one of several rejections that fire when an NF-e arrives with two
// <Signature> elements; it's the kind of bug that survives unit tests if
// signing is allowed to no-op-append.
func TestSign_RejectsAlreadySignedDocument(t *testing.T) {
	signed, _ := signedNFe(t)
	cert, err := nfe.GenerateSelfSignedTest("re-sign")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	_, err = nfe.Sign(signed, cert)
	if !errors.Is(err, nfe.ErrAlreadySigned) {
		t.Errorf("err = %v, want ErrAlreadySigned", err)
	}
}

// TestVerifySignature_IsIdempotent confirms VerifySignature does not
// mutate the input bytes — calling it twice on the same document must
// succeed both times. Regression guard against future refactors that
// might mutate the parsed etree.Document in place.
func TestVerifySignature_IsIdempotent(t *testing.T) {
	signed, _ := signedNFe(t)
	original := append([]byte(nil), signed...)

	if err := nfe.VerifySignature(signed); err != nil {
		t.Fatalf("first VerifySignature: %v", err)
	}
	if err := nfe.VerifySignature(signed); err != nil {
		t.Fatalf("second VerifySignature: %v", err)
	}
	if !bytes.Equal(signed, original) {
		t.Fatal("VerifySignature mutated input bytes")
	}
}

// TestLoadPFX_RejectsBadPassword guards the password check path. A wrong
// password on a real A1 PFX produces an opaque pkcs12 error; the wrapper
// in nfe.LoadPFX should surface it without panicking.
func TestLoadPFX_RejectsBadPassword(t *testing.T) {
	// A minimal byte string that pkcs12.Decode will reject regardless of password.
	_, err := nfe.LoadPFX([]byte("not a valid pfx"), "anything")
	if err == nil {
		t.Fatal("LoadPFX accepted invalid PFX bytes")
	}
	if !strings.Contains(err.Error(), "nfe.LoadPFX") {
		t.Errorf("err = %v, want wrapped under nfe.LoadPFX", err)
	}
}
