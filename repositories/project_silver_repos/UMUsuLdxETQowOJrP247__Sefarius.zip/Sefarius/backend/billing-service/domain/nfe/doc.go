// Package nfe implements the domain types and business rules for Brazilian
// NF-e (Nota Fiscal Eletronica), following the official SEFAZ leiaute v4.00
// (PL_009d).
//
// The package is organized as follows:
//
//	schema/      Generated Go types from official XSDs (populated in sprint 1.1.c)
//	types.go     Strongly typed enums for the leiaute (TpAmb, Modelo, FinNFe, ...)
//	errors.go    Sentinel errors for the domain
//	chave.go     44-digit access key generator + mod 11 DV (sprint 1.2)
//	builder.go   Fluent builder for constructing NF-e documents (sprint 1.2)
//	calculo.go   Tax calculations by tax regime (sprint 1.3)
//	validador.go XSD validation + business rules (sprint 1.4)
//	certificate.go A1 certificate (PFX) loader + self-signed test factory (sprint 1.5)
//	signer.go    XMLDSig enveloped signature over <infNFe> using SHA-1 +
//	             RSA-SHA1 + C14N 1.0 inclusive — the algorithms mandated by
//	             SEFAZ leiaute v4.00 (sprint 1.5)
//	sefaz_client.go SefazClient port + AuthorizationResult / Protocol /
//	             Rejection types consumed by application/emit_nfe.go and
//	             implemented by infrastructure/sefaz/MockClient (sprint 1.6)
//
// DANFE PDF rendering lives in infrastructure/danfe/ rather than under
// this package because it is an output adapter, not part of the fiscal
// model (sprint 1.7).
//
// See Projects/Sefarius/05 - NF-e Implementation Strategy.md in the Obsidian
// vault for the full implementation plan.
package nfe
