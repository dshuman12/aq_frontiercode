package nfe

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"errors"
	"fmt"
	"math/big"
	"time"

	"golang.org/x/crypto/pkcs12"
)

// Certificate bundles an A1 X.509 certificate with its RSA private key.
//
// In production the caller loads an ICP-Brasil A1 PFX file via LoadPFX. For
// tests and local development GenerateSelfSignedTest builds an equivalent
// in-memory pair without external infrastructure — sufficient to exercise
// XMLDSig mechanics, never accepted by SEFAZ on the wire.
//
// Design rule: the domain layer treats certificate provisioning as a black
// box. Whether bytes come from a Vault secret, a KMS-wrapped blob, or an
// HSM driver is an infrastructure concern. The signer only needs *Certificate.
type Certificate struct {
	X509       *x509.Certificate
	PrivateKey *rsa.PrivateKey
}

// LoadPFX decodes an A1 certificate (PKCS#12 / PFX) and returns the bundled
// cert + key pair. SEFAZ accepts only RSA keys for XMLDSig, so a PFX with an
// EC or DSA key is rejected even though Go can parse it.
//
// The password is required by the PFX format. Most A1 certs ship with a
// vendor-set password the holder is expected to change on first import.
func LoadPFX(data []byte, password string) (*Certificate, error) {
	key, cert, err := pkcs12.Decode(data, password)
	if err != nil {
		return nil, fmt.Errorf("nfe.LoadPFX: %w", err)
	}
	rsaKey, ok := key.(*rsa.PrivateKey)
	if !ok {
		return nil, errors.New("nfe.LoadPFX: SEFAZ XMLDSig requires RSA keys; PFX provided non-RSA")
	}
	return &Certificate{X509: cert, PrivateKey: rsaKey}, nil
}

// GenerateSelfSignedTest creates an in-memory RSA-2048 key + self-signed
// certificate with the given CommonName. Not for production — SEFAZ rejects
// signatures whose chain does not terminate at an ICP-Brasil root.
//
// IsCA + KeyUsageCertSign are set so the certificate is structurally valid
// as its own trust anchor for any downstream code that walks the chain via
// x509.Certificate.Verify. VerifySignature itself does not need the flags
// (goxmldsig matches the embedded cert against trusted roots by byte
// equality, not by chain walk), but emitting a structurally complete cert
// avoids surprises if a caller hands the same Certificate to a stricter
// verifier.
func GenerateSelfSignedTest(commonName string) (*Certificate, error) {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, fmt.Errorf("nfe.GenerateSelfSignedTest: rsa.GenerateKey: %w", err)
	}

	template := &x509.Certificate{
		SerialNumber: big.NewInt(time.Now().UnixNano()),
		Subject: pkix.Name{
			CommonName:   commonName,
			Organization: []string{"Sefarius Test"},
			Country:      []string{"BR"},
		},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(365 * 24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment | x509.KeyUsageCertSign,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth},
		BasicConstraintsValid: true,
		IsCA:                  true,
	}

	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	if err != nil {
		return nil, fmt.Errorf("nfe.GenerateSelfSignedTest: x509.CreateCertificate: %w", err)
	}
	cert, err := x509.ParseCertificate(der)
	if err != nil {
		return nil, fmt.Errorf("nfe.GenerateSelfSignedTest: x509.ParseCertificate: %w", err)
	}
	return &Certificate{X509: cert, PrivateKey: key}, nil
}
