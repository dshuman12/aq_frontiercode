package nfe

import (
	"bytes"
	"errors"
	"fmt"
	"os/exec"
	"strings"
)

// ErrXmllintNotAvailable indicates the xmllint binary is not in PATH.
// Callers can branch on errors.Is for ergonomic dev-vs-prod handling.
var ErrXmllintNotAvailable = errors.New("xmllint not found in PATH")

// ValidateXSD validates xmlBytes against the XSD schema at xsdPath via
// the xmllint command. Returns nil on successful validation; an error
// describing the violations otherwise.
//
// xmllint is the de-facto standard XSD validator for Linux/CI pipelines.
// We shell out instead of binding libxml2 via CGO because CGO complicates
// cross-compilation and Docker layering. The expected deployment context
// (Alpine/Debian Docker images, GitHub Actions runners) has xmllint via:
//
//	apk add --no-cache libxml2-utils      # Alpine
//	apt-get install -y libxml2-utils      # Debian/Ubuntu
//
// extraPath is an optional directory passed via --path so xmllint can
// resolve <xs:import> references to schemas in the same directory (the
// SEFAZ leiaute splits the layout across ~20 XSDs that import each other).
// Pass "" if the schema is self-contained.
func ValidateXSD(xmlBytes []byte, xsdPath, extraPath string) error {
	if _, err := exec.LookPath("xmllint"); err != nil {
		return fmt.Errorf("%w: %v", ErrXmllintNotAvailable, err)
	}

	args := []string{"--noout", "--schema", xsdPath}
	if extraPath != "" {
		args = append(args, "--path", extraPath)
	}
	args = append(args, "-") // read XML from stdin

	cmd := exec.Command("xmllint", args...)
	cmd.Stdin = bytes.NewReader(xmlBytes)

	var stderr bytes.Buffer
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return fmt.Errorf("XSD validation failed: %s", msg)
	}
	return nil
}
