package nfe

import (
	"fmt"
	"regexp"
	"strconv"
	"time"
)

// Chave is the canonical 44-digit NF-e access key.
//
// Layout per leiaute v4.00:
//
//	cUF (2) + AAMM (4) + CNPJ (14) + mod (2) + serie (3) +
//	nNF (9) + tpEmis (1) + cNF (8) + cDV (1)
//
// The check digit (cDV) is computed by módulo 11 with cyclic weights 2-9
// applied right-to-left over the first 43 digits.
type Chave string

// ChaveComponents carries the inputs required to assemble a Chave.
// Each field is validated by NewChave; this struct is just a carrier.
type ChaveComponents struct {
	CUF int // IBGE UF code (e.g. 35=SP, 43=RS), range [11,99]

	// DhEmi is the emission timestamp. AAMM (year/month) is formatted from
	// this instant in the time.Time's OWN location — caller must pass the
	// value in the timezone of the issuing establishment. The same physical
	// moment in different zones produces different keys; e.g. 2026-01-01
	// 01:00 BRT (UTC-3) and 2025-12-31 22:00 UTC are the same instant but
	// yield AAMM=2601 vs AAMM=2512. Convention in BR fiscal context: pass
	// dhEmi in America/Sao_Paulo (or the establishment's local zone).
	DhEmi time.Time

	CNPJ   string // Issuer CNPJ — exactly 14 digits, no separators
	Modelo Modelo // 55 (NF-e) or 65 (NFC-e)
	Serie  int    // 0-999
	NNF    int    // 1-999999999
	TpEmis TpEmis // Emission mode (1=normal, 2-7,9=contingência)
	CNF    string // 8 numeric digits, anti-collision random component
}

// ChaveDecomposed is the inverse of ChaveComponents — the result of parsing
// a 44-digit string back into its constituent fields.
type ChaveDecomposed struct {
	CUF    int
	AAMM   string // YYMM as written in the key
	CNPJ   string
	Modelo Modelo
	Serie  int
	NNF    int
	TpEmis TpEmis
	CNF    string
	DV     byte // 0-9
}

var (
	rxCNPJ14   = regexp.MustCompile(`^\d{14}$`)
	rxCNF8     = regexp.MustCompile(`^\d{8}$`)
	rxAllDigit = regexp.MustCompile(`^\d+$`)
)

// NewChave builds a 44-digit NF-e access key from its components.
// All fields are validated before assembly; the returned Chave includes
// the computed check digit.
func NewChave(c ChaveComponents) (Chave, error) {
	if c.CUF < 11 || c.CUF > 99 {
		return "", fmt.Errorf("%w: cUF=%d fora de [11,99]", ErrInvalidUF, c.CUF)
	}
	if c.DhEmi.IsZero() {
		return "", ErrInvalidDhEmi
	}
	if !rxCNPJ14.MatchString(c.CNPJ) {
		return "", fmt.Errorf("%w: esperado 14 digitos, got %q", ErrInvalidCNPJ, c.CNPJ)
	}
	if !c.Modelo.IsValid() {
		return "", fmt.Errorf("%w: modelo=%q", ErrInvalidModelo, c.Modelo)
	}
	if c.Serie < 0 || c.Serie > 999 {
		return "", fmt.Errorf("%w: serie=%d", ErrInvalidSerie, c.Serie)
	}
	if c.NNF < 1 || c.NNF > 999_999_999 {
		return "", fmt.Errorf("%w: nNF=%d", ErrInvalidNNF, c.NNF)
	}
	if !c.TpEmis.IsValid() {
		return "", fmt.Errorf("%w: tpEmis=%q", ErrInvalidTpEmis, c.TpEmis)
	}
	if !rxCNF8.MatchString(c.CNF) {
		return "", fmt.Errorf("%w: cNF=%q", ErrInvalidCNF, c.CNF)
	}

	body := fmt.Sprintf("%02d%s%s%s%03d%09d%s%s",
		c.CUF,
		c.DhEmi.Format("0601"),
		c.CNPJ,
		c.Modelo,
		c.Serie,
		c.NNF,
		c.TpEmis,
		c.CNF,
	)
	if len(body) != 43 {
		// Defensive: should be unreachable given the validations above.
		return "", fmt.Errorf("%w: body interno tem %d digitos", ErrInvalidChaveLength, len(body))
	}

	dv := calcDV(body)
	return Chave(body + string(rune('0'+dv))), nil
}

// Validate reports whether c is a well-formed 44-digit key with a matching
// check digit. Use this when consuming keys from external sources (XML,
// user input).
func (c Chave) Validate() error {
	if len(c) != 44 {
		return fmt.Errorf("%w: got %d", ErrInvalidChaveLength, len(c))
	}
	if !rxAllDigit.MatchString(string(c)) {
		return ErrInvalidChaveDigit
	}
	expectedDV := calcDV(string(c[:43]))
	actualDV := byte(c[43] - '0')
	if expectedDV != actualDV {
		return fmt.Errorf("%w: esperado %d, got %d", ErrInvalidChaveDV, expectedDV, actualDV)
	}
	return nil
}

// Decompose parses the key back into its components. Returns an error if
// the key fails Validate.
func (c Chave) Decompose() (ChaveDecomposed, error) {
	if err := c.Validate(); err != nil {
		return ChaveDecomposed{}, err
	}
	s := string(c)
	cuf, _ := strconv.Atoi(s[0:2])
	serie, _ := strconv.Atoi(s[22:25])
	nnf, _ := strconv.Atoi(s[25:34])
	return ChaveDecomposed{
		CUF:    cuf,
		AAMM:   s[2:6],
		CNPJ:   s[6:20],
		Modelo: Modelo(s[20:22]),
		Serie:  serie,
		NNF:    nnf,
		TpEmis: TpEmis(s[34:35]),
		CNF:    s[35:43],
		DV:     c[43] - '0',
	}, nil
}

// String returns the chave as plain string. Useful when interfacing with
// fmt or with code that expects string explicitly.
func (c Chave) String() string { return string(c) }

// calcDV computes the módulo 11 check digit. Cyclic weights 2..9 are applied
// right-to-left to the body. If the result is 10 or 11, the DV is 0 (per
// the official spec).
func calcDV(body string) byte {
	sum := 0
	weight := 2
	for i := len(body) - 1; i >= 0; i-- {
		sum += int(body[i]-'0') * weight
		weight++
		if weight > 9 {
			weight = 2
		}
	}
	dv := 11 - (sum % 11)
	if dv >= 10 {
		dv = 0
	}
	return byte(dv)
}
