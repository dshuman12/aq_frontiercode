package nfe

import (
	"context"
	"errors"
	"fmt"
	"time"
)

// ─── NF-e events: domain-level types ─────────────────────────────────────────
//
// SEFAZ exposes "events" against an authorized NF-e via a single
// generic webservice (NFeRecepcaoEvento) that carries different
// payloads depending on tpEvento. Sprint 2.1 ships two of those:
//
//   - tpEvento "110111" — Cancelamento da NF-e
//   - tpEvento "110110" — Carta de Correção Eletrônica (CCe)
//
// Other event types that share the same envelope and webservice are
// out of scope for now: manifestação destinatário (210200/210210/...),
// EPEC, declaração prévia de emissão em contingência, etc. The types
// in this file are deliberately event-type-agnostic — adding a new
// tpEvento later means a new builder + a new use case, not new
// transport plumbing.

// NFeEventType identifies which SEFAZ event flavor a record represents.
type NFeEventType string

const (
	NFeEventTypeCancel NFeEventType = "CANCEL"
	NFeEventTypeCCe    NFeEventType = "CCE"
)

// IsValid reports whether the value is one of the recognized event
// types persisted by sprint 2.1.
func (t NFeEventType) IsValid() bool {
	return t == NFeEventTypeCancel || t == NFeEventTypeCCe
}

// TpEvento returns the SEFAZ wire-level tpEvento code corresponding
// to this domain event type. Used by the builders to populate the
// outgoing envelope and by the persistence layer to translate back.
func (t NFeEventType) TpEvento() string {
	switch t {
	case NFeEventTypeCancel:
		return "110111"
	case NFeEventTypeCCe:
		return "110110"
	}
	return ""
}

// EventStatus is the coarse-grained outcome of a single event submission.
//
// Field population by Status:
//
//	ACCEPTED            Protocol set,    Rejection nil  (cStat 135 / 136)
//	REJECTED            Protocol nil,    Rejection set  (any other cStat)
//	SERVICE_UNAVAILABLE both nil         (transport failure or 5xx-equivalent)
//
// Unlike Authorize, events do not have a DUPLICATE branch — SEFAZ
// returns cStat 573 ("duplicidade do evento") which we collapse into
// REJECTED with that motivo. The caller can branch on Rejection.CStat
// when it specifically needs to detect a duplicate retry.
type EventStatus string

const (
	EventStatusAccepted           EventStatus = "ACCEPTED"
	EventStatusRejected           EventStatus = "REJECTED"
	EventStatusServiceUnavailable EventStatus = "SERVICE_UNAVAILABLE"
)

// EventProtocol is the receipt SEFAZ returns for a successful event,
// analogous to nfe.Protocol for an authorized NF-e. Persisted alongside
// the signed event XML; together they form the legally valid
// procEventoNFe document.
type EventProtocol struct {
	NProt    string    // protocol number assigned by SEFAZ for this event
	DhRegEvento time.Time // SEFAZ-side registration timestamp
	ChNFe    string    // 44-digit chave (echoed for cross-check)
	TpEvento string    // event type code (110111, 110110, ...)
	NSeqEvento int     // sequence — 1 for cancel, 1..N for CCe
	CStat    string    // raw SEFAZ status code (135 / 136 on success)
	XMotivo  string    // human-readable status motive
	TpAmb    string    // environment: "1"=production, "2"=homologation
}

// EventRejection is the structured form of a SEFAZ refusal of an
// event. Common rejection cStat codes seen for events:
//
//   - 218: NF-e already cancelled
//   - 220: Cancellation deadline expired (24h after authorization)
//   - 228: Event date later than current date
//   - 490: rejection by integrity validation
//   - 573: duplicate event (same chave + tpEvento + nSeqEvento)
type EventRejection struct {
	CStat   string
	XMotivo string
}

// EventResult is the structured return of SefazClient.Cancel /
// SefazClient.SendCCe. ResponseXML carries the full procEventoNFe
// envelope (the submitted evento + the retEvento receipt) so the
// caller can persist it as a single legally valid blob.
type EventResult struct {
	Status      EventStatus
	CStat       string          // raw cStat from the retEvento
	XMotivo     string          // human-readable from the retEvento
	Protocol    *EventProtocol  // populated when Status is ACCEPTED
	Rejection   *EventRejection // populated when Status is REJECTED
	ResponseXML []byte          // procEventoNFe (evento + retEvento), legally valid
}

// NFeEventRecord is the persisted form of a single submitted event.
// One row per (chave, event_type, n_seq) — see migration 005.
//
// The repository uses upsert semantics by the (chave, event_type,
// n_seq) tuple so that a re-submission produces a single up-to-date
// row, not duplicates. SEFAZ duplicate detection (cStat 573) is
// handled by the use case before reaching the repo.
type NFeEventRecord struct {
	Chave       Chave
	EventType   NFeEventType
	NSeq        int
	NProt       string // empty when Status is REJECTED
	Status      EventStatus
	CStat       string
	XMotivo     string
	SignedXML   []byte // signed evento as submitted to SEFAZ
	ResponseXML []byte // procEventoNFe receipt envelope
	OccurredAt  time.Time
}

// ─── Repository port ────────────────────────────────────────────────────────

// NFeEventRepository persists submitted events keyed by
// (chave, event_type, n_seq). The composite key is the primary key in
// the billing.nfe_events table — see migration 005 — and prevents
// duplicate sequence allocation in concurrent SendCCe calls.
//
// Save uses upsert semantics on the composite key: a re-submission of
// the same (chave, event_type, n_seq) tuple updates in place rather
// than producing duplicates. This matches the recovery story where a
// crash between SEFAZ ack and our Save is recoverable by re-submitting.
//
// Implementations:
//
//   - InMemoryNFeEventRepository (infrastructure/nfe_event_repository.go)
//   - PostgresNFeEventRepository (infrastructure/nfe_event_repository_postgres.go)
//
// Both pass the parametrized contract test in
// nfe_event_repository_contract_test.go — change one, run the other.
type NFeEventRepository interface {
	// Save upserts an event row. Stamps OccurredAt if zero.
	Save(ctx context.Context, record *NFeEventRecord) error

	// GetByKey returns ErrNFeEventNotFound when no row exists for the
	// given tuple. n_seq=1 is canonical for cancel.
	GetByKey(ctx context.Context, chave Chave, eventType NFeEventType, nSeq int) (*NFeEventRecord, error)

	// ListByChave returns every event row for the given chave, ordered
	// by occurred_at ASC (chronological — useful for replay / audit
	// listings). Returns an empty slice (not an error) when the chave
	// has no events yet.
	ListByChave(ctx context.Context, chave Chave) ([]*NFeEventRecord, error)

	// MaxSeqByChaveType returns the highest n_seq stored for the given
	// (chave, event_type). Returns 0 when no rows exist — callers add 1
	// to compute the next sequence. Restricted to non-rejected events
	// would be wrong: a REJECTED CCe still consumes a sequence number
	// because the next attempt must use the next integer (re-using N
	// would also be REJECTED with cStat 573 / 595).
	MaxSeqByChaveType(ctx context.Context, chave Chave, eventType NFeEventType) (int, error)
}

// ─── Errors ─────────────────────────────────────────────────────────────────

// ErrNFeEventNotFound is returned by NFeEventRepository.GetByKey when
// no event row exists for the given (chave, event_type, n_seq) tuple.
// Distinct sentinel so callers can distinguish "no event yet" (the
// 99% case for cancel) from infrastructure errors.
var ErrNFeEventNotFound = errors.New("nfe: event not found for chave/type/seq")

// ErrNFeNotCancellable is returned by the cancel use case when the
// target NF-e is not in the AUTHORIZED state (already cancelled,
// rejected on emit, or never persisted). The HTTP layer maps this to
// 422 Unprocessable Entity — distinct from a missing chave (404).
var ErrNFeNotCancellable = errors.New("nfe: not cancellable; record must be in AUTHORIZED state")

// ErrCCeSeqOutOfOrder is returned by the SendCCe use case when the
// caller-supplied nSeqEvento is not exactly MAX(existing) + 1. SEFAZ
// rejects sequence gaps (cStat 595 "duplicidade ou sequência errada")
// and we surface a domain-level error before submission to keep the
// rejection round-trip tight.
var ErrCCeSeqOutOfOrder = errors.New("nfe.SendCCe: nSeqEvento must be the next sequential value")

// ─── Validation helpers ─────────────────────────────────────────────────────

// CancelJustificationLen is the SEFAZ-mandated length range for the
// cancellation justification (xJust). Outside this range the document
// is rejected at the schema layer (cStat 215 / 226). Validated in the
// use case before signing to fail fast with a clean ErrValidation.
const (
	CancelJustificationMin = 15
	CancelJustificationMax = 255
)

// CCeCorrectionLen is the SEFAZ-mandated length range for the CCe
// correction text (xCorrecao). 15-1000 chars per Manual de Eventos
// v1.07 (NT2017.001).
const (
	CCeCorrectionMin = 15
	CCeCorrectionMax = 1000
)

// CCeCondicaoUsoText is the legal disclaimer SEFAZ requires inside
// every CCe (xCondUso). The text is fixed in the leiaute — it is the
// statement that the CCe cannot fix tax-relevant fields. Embedded as
// a constant so the builder cannot accidentally drift from the
// regulation.
const CCeCondicaoUsoText = "A Carta de Correcao e disciplinada pelo paragrafo " +
	"1o-A do art. 7o do Convenio S/N, de 15 de dezembro de 1970 e pode ser " +
	"utilizada para regularizacao de erro ocorrido na emissao de documento " +
	"fiscal, desde que o erro nao esteja relacionado com: I - as variaveis " +
	"que determinam o valor do imposto tais como: base de calculo, aliquota, " +
	"diferenca de preco, quantidade, valor da operacao ou da prestacao; II - " +
	"a correcao de dados cadastrais que implique mudanca do remetente ou do " +
	"destinatario; III - a data de emissao ou de saida."

// ValidateCancelJustification checks the xJust length range. Returns
// a ValidationIssue (not an error) so the use case can collect issues
// and surface them as a single ErrValidation, matching the EmitNFe
// pattern.
func ValidateCancelJustification(xJust string) *ValidationIssue {
	n := len([]rune(xJust))
	if n < CancelJustificationMin || n > CancelJustificationMax {
		return &ValidationIssue{
			Severity: SeverityError,
			Field:    "xJust",
			Message:  fmt.Sprintf("justificativa must be between %d and %d characters (got %d)", CancelJustificationMin, CancelJustificationMax, n),
		}
	}
	return nil
}

// ValidateCCeCorrection checks the xCorrecao length range.
func ValidateCCeCorrection(xCorrecao string) *ValidationIssue {
	n := len([]rune(xCorrecao))
	if n < CCeCorrectionMin || n > CCeCorrectionMax {
		return &ValidationIssue{
			Severity: SeverityError,
			Field:    "xCorrecao",
			Message:  fmt.Sprintf("correcao must be between %d and %d characters (got %d)", CCeCorrectionMin, CCeCorrectionMax, n),
		}
	}
	return nil
}
