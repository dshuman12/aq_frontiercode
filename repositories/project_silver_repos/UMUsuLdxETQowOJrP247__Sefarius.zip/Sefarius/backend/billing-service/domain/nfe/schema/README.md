# schema/

Official SEFAZ NF-e XSD schemas (leiaute v4.00, package PL_009_V4) and the
generated Go types they back.

## Layout

```
schema/         Core: nfe, enviNFe, retEnviNFe, consSitNFe, consStatServ,
                inutNFe, consCad, signature.   Package `schema`.
schema/xsd/     192 .xsd files mirrored from upstream (see PROVENANCE).
schema/evento/  Generic event envelope. Package `evento`.
schema/cce/     Carta de Correção Eletrônica. Package `cce`.
schema/canc/    Cancelamento. Package `canc`.
schema/dist/    DistDFe (consulta NF-e contra CNPJ). Package `dist`.
```

Each sub-package is self-contained because xgen treats every XSD as
standalone and re-declares shared base types (`TCnpj`, `TStat`,
`DetEvento`, ...) per file, causing collisions when generated into a
single Go package. Callers import only the sub-package they need.

## Provenance

The 192 files under `xsd/` mirror
[`schemes/PL_009_V4`](https://github.com/nfephp-org/sped-nfe/tree/master/schemes/PL_009_V4)
from [nfephp-org/sped-nfe](https://github.com/nfephp-org/sped-nfe). The
SEFAZ portal itself ships the same XSDs inside a captcha-gated ZIP.

Refresh from upstream:

```bash
tools/download-nfe-xsd.sh
```

Idempotent.

## Coverage

| Category | Examples |
|---|---|
| Core layout | `nfe_v4.00.xsd`, `leiauteNFe_v4.00.xsd`, `tiposBasico_v4.00.xsd` |
| Authorization webservice | `enviNFe_v4.00.xsd`, `retEnviNFe_v4.00.xsd`, `consReciNFe_v4.00.xsd`, `retConsReciNFe_v4.00.xsd`, `procNFe_v4.00.xsd` |
| Status query | `consStatServ_v4.00.xsd`, `retConsStatServ_v4.00.xsd` |
| Situation query | `consSitNFe_v4.00.xsd`, `retConsSitNFe_v4.00.xsd` |
| Inutilization | `inutNFe_v4.00.xsd`, `retInutNFe_v4.00.xsd` |
| Events (envelope) | `envEvento_v1.00.xsd`, `retEnvEvento_v1.00.xsd` |
| Event payloads | `CCe_v1.00.xsd`, `EPEC_v1.00.xsd`, manifestation events (`e210200`, `e210210`, `e210220`, `e210240`), insucesso na entrega |
| Distribution | `distDFeInt_v1.01.xsd` |
| Digital signature | `xmldsig-core-schema_v1.01.xsd` (W3C XMLDSig) |
| Misc | `consGTIN_v1.00.xsd`, `consCad_v2.00.xsd`, SUFRAMA, averbações |

Out of scope: CT-e, MDF-e, NFS-e (municipal), NFC-e REST/JSON.

## Regenerating types

```bash
tools/generate-nfe-types.sh           # core only (default)
tools/generate-nfe-types.sh --smoke   # 4-XSD smoke set
tools/generate-nfe-types.sh --group <name>   # evento|cce|canc|dist
tools/generate-nfe-types.sh --all     # core + every sub-package
```

The script runs `xgen` inside `golang:1.23-alpine` so the host needs no
Go install. Output is byte-deterministic given the same inputs.
`refine-nfe-types.sh` runs automatically after generation to fix three
xgen quirks: `*interface{}` → `*string`, missing `,omitempty` on pointer
optionals, and value-typed fields that the XSD marks `minOccurs="0"`
(see `KNOWN_OPTIONAL` in that script).
