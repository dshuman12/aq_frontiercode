package nfe_test

import (
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// TestIntegration_FullValidationHappyPath orchestrates Builder + facades
// + ValidateSemantic + ValidateTotalsAgainstItems on a single canonical
// NF-e. XSD validation against the SEFAZ schema is covered separately in
// xsd_validator_test.go because the builder does not emit the xmlns
// namespace yet (registered tech debt for sprint 1.6 SefazClient real).
func TestIntegration_FullValidationHappyPath(t *testing.T) {
	det, err := nfe.NewDetRegimeNormalCST00(makeProd("PRODUTO INTEGRADO"), "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}

	baseline, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("baseline Build: %v", err)
	}
	// Replace the manually-built det with one composed via facade so totals
	// computed by the calculator match the Total declared in minimalNFe.
	baseline.InfNFe.Det = []*schema.Det{det}
	// Populate PIS/COFINS totals so they get checked too.
	baseline.InfNFe.Total.ICMSTot.VPIS = "1.65"
	baseline.InfNFe.Total.ICMSTot.VCOFINS = "7.60"
	baseline.InfNFe.Total.ICMSTot.VProd = "100.00"

	if issues := nfe.ValidateSemantic(baseline); len(issues) > 0 {
		for _, i := range issues {
			t.Logf("semantic issue: %s", i)
		}
		t.Errorf("ValidateSemantic returned %d issues; expected 0", len(issues))
	}

	if issues := nfe.ValidateTotalsAgainstItems(baseline); len(issues) > 0 {
		for _, i := range issues {
			t.Logf("totals issue: %s", i)
		}
		t.Errorf("ValidateTotalsAgainstItems returned %d issues; expected 0", len(issues))
	}
}

// TestIntegration_SabotagedNFeFlagsAllInconsistencies confirms each
// validator catches its own class of error in a single sabotaged NF-e.
// Confidence that callers get a complete picture of what's wrong.
func TestIntegration_SabotagedNFeFlagsAllInconsistencies(t *testing.T) {
	det, err := nfe.NewDetRegimeNormalCST00(makeProd("PRODUTO X"), "100.00", "18.00", "1.65", "7.60")
	if err != nil {
		t.Fatalf("NewDet: %v", err)
	}
	baseline, err := minimalNFe(t).Build()
	if err != nil {
		t.Fatalf("baseline Build: %v", err)
	}
	baseline.InfNFe.Det = []*schema.Det{det}

	// Sabotage each layer:
	baseline.InfNFe.Emit.EnderEmit.UF = "SP"      // semantic — cUF mismatch
	baseline.InfNFe.Emit.CRT = "9"                // semantic — invalid CRT
	baseline.InfNFe.Total.ICMSTot.VBC = "999.99"  // totals — vBC divergence

	semantic := nfe.ValidateSemantic(baseline)
	if !containsField(semantic, "cUF") {
		t.Error("expected semantic to flag cUF mismatch")
	}
	if !containsField(semantic, "emit.CRT") {
		t.Error("expected semantic to flag CRT")
	}

	totals := nfe.ValidateTotalsAgainstItems(baseline)
	if !containsField(totals, "Total.ICMSTot.vBC") {
		t.Error("expected totals to flag vBC divergence")
	}
}

func containsField(issues []nfe.ValidationIssue, fieldSubstr string) bool {
	for _, i := range issues {
		if strings.Contains(i.Field, fieldSubstr) {
			return true
		}
	}
	return false
}
