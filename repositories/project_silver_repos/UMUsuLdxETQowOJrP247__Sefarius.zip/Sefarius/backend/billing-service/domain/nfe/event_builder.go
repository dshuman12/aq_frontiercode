package nfe

import (
	"errors"
	"fmt"
	"time"

	"github.com/sefarius/billing-service/domain/nfe/schema/canc"
	"github.com/sefarius/billing-service/domain/nfe/schema/cce"
)

// ─── NF-e event builders ─────────────────────────────────────────────────────
//
// Both builders produce a *canc.TEvento or *cce.TEvento ready to be
// XML-marshalled, signed (SignEvent), wrapped in an envEvento envelope,
// and submitted via SefazClient. They mirror the role of nfe.Builder
// for NF-e emission: enforce the rules SEFAZ would otherwise reject at
// the schema layer (Id format, required cOrgao, dhEvento format) so
// the use case can stay focused on business logic.

// CancelEventInput captures the variable inputs for a cancel event.
// EmitterCNPJ and EmitterCPF are mutually exclusive — exactly one must
// be non-empty (the emitter of the NF-e being cancelled).
type CancelEventInput struct {
	Chave         Chave
	EmitterCNPJ   string
	EmitterCPF    string
	TpAmb         string    // "1" production, "2" homologation
	NProtAuth     string    // protocol number of the original authorization
	Justification string    // xJust, 15-255 chars (already validated by use case)
	DhEvento      time.Time // event timestamp; if zero, time.Now() is used
}

// CCeEventInput captures the variable inputs for a CCe (Carta de
// Correção Eletrônica) event.
type CCeEventInput struct {
	Chave       Chave
	EmitterCNPJ string
	EmitterCPF  string
	TpAmb       string    // "1" production, "2" homologation
	NSeqEvento  int       // 1..20 per the leiaute; use case resolves auto-increment before calling
	Correction  string    // xCorrecao, 15-1000 chars (already validated by use case)
	DhEvento    time.Time
}

const (
	eventVersion         = "1.00"
	cancelDescEvento     = "Cancelamento"
	cceDescEvento        = "Carta de Correcao"
	cancelTpEvento       = "110111"
	cceTpEvento          = "110110"
	cancelNSeqEvento     = "1" // cancel is single-shot
	chaveLengthForBuild  = 44
)

// BuildCancelEvent assembles a canc.TEvento for cancellation of an
// authorized NF-e. The returned event is unsigned — pass it through
// xml.Marshal + nfe.SignEvent before submission.
//
// The Id attribute follows the SEFAZ format
// "ID" + tpEvento + chave + nSeqEvento(2 digits, zero-padded) — for
// cancel that is "ID110111" + chave + "01". The signer's reference URI
// is "#" + this Id.
func BuildCancelEvent(in CancelEventInput) (*canc.TEvento, error) {
	if err := validateChaveForEvent(in.Chave); err != nil {
		return nil, fmt.Errorf("nfe.BuildCancelEvent: %w", err)
	}
	if err := validateEmitterDocs(in.EmitterCNPJ, in.EmitterCPF); err != nil {
		return nil, fmt.Errorf("nfe.BuildCancelEvent: %w", err)
	}
	if in.TpAmb == "" {
		return nil, errors.New("nfe.BuildCancelEvent: TpAmb is required")
	}
	if in.NProtAuth == "" {
		return nil, errors.New("nfe.BuildCancelEvent: NProtAuth is required (original authorization protocol)")
	}

	dh := in.DhEvento
	if dh.IsZero() {
		dh = time.Now()
	}
	cOrgao := orgaoFromChave(in.Chave)
	id := "ID" + cancelTpEvento + string(in.Chave) + "01"
	xJust := canc.TString(in.Justification)

	evt := &canc.TEvento{
		VersaoAttr: eventVersion,
		InfEvento: &canc.InfEvento{
			IdAttr:     id,
			COrgao:     cOrgao,
			TpAmb:      in.TpAmb,
			ChNFe:      string(in.Chave),
			DhEvento:   formatEventTimestamp(dh),
			TpEvento:   cancelTpEvento,
			NSeqEvento: cancelNSeqEvento,
			VerEvento:  eventVersion,
			DetEvento: &canc.DetEvento{
				VersaoAttr: eventVersion,
				DescEvento: cancelDescEvento,
				NProt:      in.NProtAuth,
				XJust:      &xJust,
			},
		},
	}
	if in.EmitterCNPJ != "" {
		cnpj := in.EmitterCNPJ
		evt.InfEvento.CNPJ = &cnpj
	} else {
		cpf := in.EmitterCPF
		evt.InfEvento.CPF = &cpf
	}
	return evt, nil
}

// BuildCCeEvent assembles a cce.TEvento for a Carta de Correção
// Eletrônica. The returned event is unsigned. xCondUso is set to the
// SEFAZ-mandated legal disclaimer (CCeCondicaoUsoText) — caller does
// not (and must not) supply it.
//
// nSeqEvento must be a valid integer in [1, 20] per the leiaute. The
// use case is responsible for resolving auto-increment from the
// repository before calling.
func BuildCCeEvent(in CCeEventInput) (*cce.TEvento, error) {
	if err := validateChaveForEvent(in.Chave); err != nil {
		return nil, fmt.Errorf("nfe.BuildCCeEvent: %w", err)
	}
	if err := validateEmitterDocs(in.EmitterCNPJ, in.EmitterCPF); err != nil {
		return nil, fmt.Errorf("nfe.BuildCCeEvent: %w", err)
	}
	if in.TpAmb == "" {
		return nil, errors.New("nfe.BuildCCeEvent: TpAmb is required")
	}
	// nSeqEvento upper bound comes from the SEFAZ "Manual de Eventos
	// v1.07" (NT2017.001) — currently capped at 20 corrections per
	// chave. If a future technical note bumps this limit, update both
	// the bound and any UX docs that promise the cap. The use case
	// surfaces this as a build-time error instead of letting SEFAZ
	// reject after a wasted submission.
	if in.NSeqEvento < 1 || in.NSeqEvento > 20 {
		return nil, fmt.Errorf("nfe.BuildCCeEvent: NSeqEvento must be in [1,20], got %d", in.NSeqEvento)
	}

	dh := in.DhEvento
	if dh.IsZero() {
		dh = time.Now()
	}
	cOrgao := orgaoFromChave(in.Chave)
	id := fmt.Sprintf("ID%s%s%02d", cceTpEvento, string(in.Chave), in.NSeqEvento)
	nSeqStr := fmt.Sprintf("%d", in.NSeqEvento)

	evt := &cce.TEvento{
		VersaoAttr: eventVersion,
		InfEvento: &cce.InfEvento{
			IdAttr:     id,
			COrgao:     cOrgao,
			TpAmb:      in.TpAmb,
			ChNFe:      string(in.Chave),
			DhEvento:   formatEventTimestamp(dh),
			TpEvento:   cceTpEvento,
			NSeqEvento: nSeqStr,
			VerEvento:  eventVersion,
			DetEvento: &cce.DetEvento{
				VersaoAttr: eventVersion,
				DescEvento: cceDescEvento,
				XCorrecao:  in.Correction,
				XCondUso:   CCeCondicaoUsoText,
			},
		},
	}
	if in.EmitterCNPJ != "" {
		cnpj := in.EmitterCNPJ
		evt.InfEvento.CNPJ = &cnpj
	} else {
		cpf := in.EmitterCPF
		evt.InfEvento.CPF = &cpf
	}
	return evt, nil
}

// orgaoFromChave extracts the cUF (UF code) from the first two digits
// of the 44-digit chave. SEFAZ events go to the UF that authorized the
// original NF-e, except for a small set that route to AN (cOrgao=91)
// — none of those are in scope for sprint 2.1.
func orgaoFromChave(chave Chave) string {
	if len(chave) < 2 {
		return ""
	}
	return string(chave)[:2]
}

// formatEventTimestamp emits the dhEvento format SEFAZ expects:
// AAAA-MM-DDThh:mm:ssTZD where TZD is the offset like -03:00. Go's
// time.RFC3339 is almost it but uses "Z" for UTC; SEFAZ wants the
// numeric offset always, so we format with "-07:00" explicitly.
func formatEventTimestamp(t time.Time) string {
	return t.Format("2006-01-02T15:04:05-07:00")
}

// validateChaveForEvent enforces the 44-digit length contract before
// the chave is embedded in the Id attribute. A malformed chave here
// would produce an Id that SEFAZ rejects at schema parsing — easier
// to catch one layer up.
func validateChaveForEvent(chave Chave) error {
	if len(chave) != chaveLengthForBuild {
		return ErrInvalidChaveLength
	}
	return nil
}

// validateEmitterDocs enforces the CNPJ XOR CPF contract that the
// SEFAZ leiaute defines for the emitter on an event. Exactly one
// must be set; both empty or both populated is invalid.
func validateEmitterDocs(cnpj, cpf string) error {
	switch {
	case cnpj != "" && cpf != "":
		return errors.New("emitter: CNPJ and CPF are mutually exclusive")
	case cnpj == "" && cpf == "":
		return errors.New("emitter: one of CNPJ or CPF is required")
	}
	return nil
}
