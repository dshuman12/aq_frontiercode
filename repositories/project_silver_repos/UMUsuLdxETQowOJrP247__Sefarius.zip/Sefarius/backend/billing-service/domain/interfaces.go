package domain

import "context"

// InvoiceRepository defines the contract for invoice persistence
type InvoiceRepository interface {
	Create(ctx context.Context, invoice *Invoice) error
	GetByID(ctx context.Context, id string) (*Invoice, error)
	GetByNumber(ctx context.Context, number int64) (*Invoice, error)
	GetAll(ctx context.Context, limit, offset int) ([]*Invoice, error)
	// Count returns the number of non-deleted invoices. Required by
	// numerical pagination on the frontend.
	Count(ctx context.Context) (int, error)
	Update(ctx context.Context, invoice *Invoice) error
	Delete(ctx context.Context, id string) error

	// Get invoice with lock for concurrent access
	GetByIDForUpdate(ctx context.Context, id string) (*Invoice, error)

	// Invoice items operations
	AddItem(ctx context.Context, item *InvoiceItem) error
	GetItems(ctx context.Context, invoiceID string) ([]*InvoiceItem, error)
}

// IdempotencyRepository defines the contract for idempotency log persistence
type IdempotencyRepository interface {
	Check(ctx context.Context, key string) (interface{}, bool, error)
	Store(ctx context.Context, key string, responseCode int, response interface{}) error
	Delete(ctx context.Context, key string) error
}

// InvoiceUseCase defines the contract for invoice business logic
type InvoiceUseCase interface {
	CreateInvoice(ctx context.Context, input *CreateInvoiceInput) (*Invoice, error)
	GetInvoice(ctx context.Context, id string) (*Invoice, error)
	ListInvoices(ctx context.Context, limit, offset int) ([]*Invoice, error)
	CountInvoices(ctx context.Context) (int, error)
	UpdateInvoiceStatus(ctx context.Context, id string, input *UpdateInvoiceStatusInput) (*Invoice, error)
	CloseInvoice(ctx context.Context, id string) (*Invoice, error)
	CancelInvoice(ctx context.Context, id string) (*Invoice, error)
	DeleteInvoice(ctx context.Context, id string) error
}

// StockServiceClient defines the contract for calling the stock service.
//
// ReserveStock checks balance and acquires a pessimistic lock without
// touching the persisted balance — the lock holds only for the duration
// of the call. DecrementStock is what actually subtracts the balance,
// and is the call invoice creation must make for stock dashboards to
// reflect sales. Earlier code relied only on ReserveStock and the
// dashboard kept showing the bruto balance after every sale; bug
// report #6 (2026-05-07) flagged it.
type StockServiceClient interface {
	ReserveStock(ctx context.Context, productID string, quantity int) (bool, error)
	ReleaseStock(ctx context.Context, productID string, quantity int) error
	DecrementStock(ctx context.Context, productID string, quantity int) error
	GetProduct(ctx context.Context, productID string) (interface{}, error)
}
