package domain

import (
	"time"
)

// InvoiceStatus represents the status of an invoice
type InvoiceStatus string

const (
	StatusOpen      InvoiceStatus = "OPEN"
	StatusClosed    InvoiceStatus = "CLOSED"
	StatusCancelled InvoiceStatus = "CANCELLED"
)

// Invoice represents an invoice entity
type Invoice struct {
	ID             string         `json:"id"`
	Number         int64          `json:"number"`
	Status         InvoiceStatus  `json:"status"`
	IdempotencyKey string         `json:"idempotency_key"`
	CreatedBy      string         `json:"created_by"`
	Items          []*InvoiceItem `json:"items"`
	TaxRate        float64        `json:"tax_rate"`
	TaxAmount      float64        `json:"tax_amount"`
	CreatedAt      time.Time      `json:"created_at"`
	ClosedAt       *time.Time     `json:"closed_at,omitempty"`
}

// InvoiceItem represents a line item in an invoice
type InvoiceItem struct {
	ID                 string    `json:"id"`
	InvoiceID          string    `json:"invoice_id"`
	ProductID          string    `json:"product_id"`
	ProductCode        string    `json:"product_code,omitempty"`
	ProductDescription string    `json:"product_description,omitempty"`
	Quantity           int       `json:"quantity"`
	UnitPrice          float64   `json:"unit_price"`
	CreatedAt          time.Time `json:"created_at"`
}

// CreateInvoiceInput represents input for creating an invoice
type CreateInvoiceInput struct {
	CreatedBy      string                   `json:"created_by" validate:"required"`
	Items          []CreateInvoiceItemInput `json:"items" validate:"required,min=1"`
	IdempotencyKey string                   `json:"idempotency_key" validate:"required"`
}

// CreateInvoiceItemInput represents an item in create invoice request
type CreateInvoiceItemInput struct {
	ProductID string  `json:"product_id" validate:"required"`
	Quantity  int     `json:"quantity" validate:"required,min=1"`
	UnitPrice float64 `json:"unit_price" validate:"required,min=0.01"`
}

// UpdateInvoiceStatusInput represents input for updating invoice status
type UpdateInvoiceStatusInput struct {
	Status InvoiceStatus `json:"status" validate:"required"`
}

// SubtotalAmount calculates the subtotal amount of the invoice before tax
func (i *Invoice) SubtotalAmount() float64 {
	total := 0.0
	for _, item := range i.Items {
		total += item.UnitPrice * float64(item.Quantity)
	}
	return total
}

// CalculateTax calculates the tax amount based on subtotal and tax rate
func (i *Invoice) CalculateTax() {
	i.TaxAmount = i.SubtotalAmount() * (i.TaxRate / 100)
}

// TotalAmount calculates the total amount of the invoice including tax
func (i *Invoice) TotalAmount() float64 {
	return i.SubtotalAmount() + i.TaxAmount
}

// CanBeClosed checks if invoice can be closed
func (i *Invoice) CanBeClosed() bool {
	return i.Status == StatusOpen
}

// Close closes the invoice
func (i *Invoice) Close() error {
	if !i.CanBeClosed() {
		return &InvoiceError{
			Code:    "INVALID_STATUS",
			Message: "invoice cannot be closed when status is " + string(i.Status),
		}
	}
	now := time.Now()
	i.Status = StatusClosed
	i.ClosedAt = &now
	return nil
}

// InvoiceError represents a domain error
type InvoiceError struct {
	Code    string
	Message string
}

func (e *InvoiceError) Error() string {
	return e.Message
}
