# Billing Service

Handles invoice billing and the NF-e emission lifecycle for the Sefarius.

## Features

- Invoice billing (create / close / cancel)
- Stock-Service integration for inventory-linked billing
- NF-e emission pipeline (build → validate → sign → authorize → persist)
- Persistent NF-e records in `billing.nfe_records` (sprint 1.11)
- DANFE PDF rendering on demand

## Configuration

| Variable | Default | Notes |
|---|---|---|
| `PORT` | `5002` | HTTP port |
| `DATABASE_URL` | required | Postgres connection string |
| `STOCK_SERVICE_URL` | `http://localhost:5001` | Stock service base URL |
| `NFE_DEV_MODE` | — | If exactly `"true"`, the service starts with a self-signed RSA-2048 cert and the mock SEFAZ client. Used by `make dev`. Wins if both modes are set. |
| `NFE_CERT_PATH` | — | Absolute path inside the container to an A1 ICP-Brasil `.pfx`. Mutually exclusive with `NFE_DEV_MODE=true`. Real SOAP `SefazClient` lands in Sprint 3.2; until then the prod path loads the cert successfully and exits with a clear "not yet implemented" message. |
| `NFE_CERT_PASSWORD` | — | Password for the PKCS#12 file in `NFE_CERT_PATH`. Required whenever `NFE_CERT_PATH` is set. |

The decision tree (`cert_loader.go`):

```
NFE_DEV_MODE=true                    → self-signed dev cert + mock SEFAZ ✅
NFE_CERT_PATH set + password set     → A1 PKCS#12 loaded; prod SOAP TODO (3.2) ⚠
NFE_CERT_PATH set + password missing → fatal error
neither                              → fatal error (prevents accidental dev cert in prod)
```

## NF-e endpoints

Sprint 1.11 — emission + lifecycle:

```
POST   /api/nfe                — emit a single NF-e
GET    /api/nfe                — list (paginated, ?limit&offset)
GET    /api/nfe/:chave         — record summary
GET    /api/nfe/:chave/xml     — raw signed XML
GET    /api/nfe/:chave/danfe   — DANFE PDF (rendered on demand)
```

Sprint 2.1 — cancel + Carta de Correção Eletrônica (CCe):

```
POST   /api/nfe/:chave/cancel        — body {"justification": "..."}; flips lifecycle to CANCELLED on ACCEPTED
POST   /api/nfe/:chave/cce           — body {"correction": "...", "seq": 0|N}; seq=0 auto-increments
GET    /api/nfe/:chave/cancel        — cancel event summary (404 if none)
GET    /api/nfe/:chave/cancel/xml    — procEventoNFe (signed event + retEvento), legally valid
GET    /api/nfe/:chave/cce           — list of CCe events for a chave
GET    /api/nfe/:chave/cce/:seq      — single CCe summary
GET    /api/nfe/:chave/cce/:seq/xml  — procEventoNFe for that seq
```

Validation refusals (xJust 15-255 chars; xCorrecao 15-1000 chars; CCe seq must equal MAX+1) return HTTP 422 with the `data` field listing the failed checks. SEFAZ rejections (cStat 218 prazo expirado, 573 duplicidade, etc.) return HTTP 200 with the rejection payload — they are expected business signals, not transport errors.

## Tests

```bash
go test ./...
```

Default run uses the in-memory NF-e repository — no external services required.

To exercise the Postgres branch of the NF-e repository contract suite, point at a freshly migrated dev DB and re-run:

```bash
TEST_DATABASE_URL=postgres://dev_user:dev_password@localhost:5432/sefarius_dev?sslmode=disable \
  go test ./infrastructure -run TestNFeRepoContract -v
```

The contract suite runs identical assertions against both `InMemoryNFeRepository` and `PostgresNFeRepository`. If you change one implementation, run both branches.

## Migrations

Applied via the Postgres `docker-entrypoint-initdb.d` mechanism (see `database/migrations/`). This **only runs on a fresh volume** — to pick up a new migration in an existing dev environment:

```bash
docker compose down -v   # destroys postgres_data volume
docker compose up
```

A real migration runner (golang-migrate / atlas) is a planned follow-up sprint.
