module github.com/sefarius/billing-service

go 1.25.0

require (
	github.com/gofiber/fiber/v2 v2.50.0
	github.com/google/uuid v1.5.0
	github.com/lib/pq v1.10.9
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/beevik/etree v1.6.0 // indirect
	github.com/boombuler/barcode v1.1.0 // indirect
	github.com/go-pdf/fpdf v0.9.0 // indirect
	github.com/jonboulle/clockwork v0.5.0 // indirect
	github.com/klauspost/compress v1.17.3 // indirect
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mattn/go-runewidth v0.0.15 // indirect
	github.com/rivo/uniseg v0.4.4 // indirect
	github.com/russellhaering/goxmldsig v1.6.0 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	github.com/valyala/fasthttp v1.50.0 // indirect
	github.com/valyala/tcplisten v1.0.0 // indirect
	golang.org/x/crypto v0.50.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	software.sslmate.com/src/go-pkcs12 v0.7.1 // indirect
)
