package main

import (
	"errors"
	"fmt"
	"os"

	"github.com/sefarius/billing-service/domain/nfe"
)

// envFunc abstracts os.LookupEnv-style env access so cert loading can be
// unit-tested without manipulating real process environment.
type envFunc func(key, defaultValue string) string

// loadCertificate decides which Certificate to use based on env vars.
//
// Two mutually-exclusive modes:
//
//   - NFE_DEV_MODE=true  → in-memory self-signed RSA-2048 cert. Mock SEFAZ.
//     Used by docker-compose dev stack and unit tests. SEFAZ rejects this
//     cert on the wire because it does not chain to ICP-Brasil — that's
//     fine for the dev path.
//
//   - NFE_CERT_PATH set  → A1 PKCS#12 (.pfx) loaded from disk with
//     NFE_CERT_PASSWORD. Loaded via nfe.LoadPFX which enforces RSA
//     (SEFAZ XMLDSig forbids EC/DSA keys). This is the production path.
//
// NFE_DEV_MODE=true takes precedence — if both are set, the dev path
// wins and the prod cert is ignored. This keeps `make dev` working in
// environments where a stray NFE_CERT_PATH was left in the shell.
//
// The bool return is `isDev`: true when the dev cert was generated,
// false when a real PKCS#12 was decoded. main.go uses this to pick the
// SefazClient (mock for dev, real SOAP for prod). Until Sprint 3.2
// lands real_client.go, the prod branch in main.go fails fast with a
// "not yet implemented" message — but cert loading itself is wired
// and tested here.
func loadCertificate(env envFunc) (*nfe.Certificate, bool, error) {
	if env("NFE_DEV_MODE", "") == "true" {
		cert, err := nfe.GenerateSelfSignedTest("sefarius dev")
		if err != nil {
			return nil, true, fmt.Errorf("loadCertificate(dev): %w", err)
		}
		return cert, true, nil
	}

	certPath := env("NFE_CERT_PATH", "")
	if certPath == "" {
		return nil, false, errors.New(
			"certificate not configured: set NFE_DEV_MODE=true (self-signed) " +
				"OR NFE_CERT_PATH=<path-to-A1-pfx> + NFE_CERT_PASSWORD=<pwd>",
		)
	}

	password := env("NFE_CERT_PASSWORD", "")
	if password == "" {
		return nil, false, errors.New(
			"NFE_CERT_PASSWORD is required when NFE_CERT_PATH is set",
		)
	}

	data, err := os.ReadFile(certPath)
	if err != nil {
		return nil, false, fmt.Errorf("loadCertificate: read %q: %w", certPath, err)
	}

	cert, err := nfe.LoadPFX(data, password)
	if err != nil {
		return nil, false, fmt.Errorf("loadCertificate: decode %q: %w", certPath, err)
	}

	return cert, false, nil
}
