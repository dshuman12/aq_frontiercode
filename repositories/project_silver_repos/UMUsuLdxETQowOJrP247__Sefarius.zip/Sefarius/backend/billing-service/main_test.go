package main

import (
	"os"
	"testing"
)

func TestGetEnv(t *testing.T) {
	key := "TEST_ENV_VAR"
	defaultValue := "default"

	// Test default value
	if result := getEnv(key, defaultValue); result != defaultValue {
		t.Errorf("Expected %s, got %s", defaultValue, result)
	}

	// Test set value
	expectedValue := "expected"
	os.Setenv(key, expectedValue)
	defer os.Unsetenv(key)

	if result := getEnv(key, defaultValue); result != expectedValue {
		t.Errorf("Expected %s, got %s", expectedValue, result)
	}
}

func TestGetEnvInt(t *testing.T) {
	key := "TEST_ENV_INT_VAR"
	defaultValue := 10

	// Test default value
	if result := getEnvInt(key, defaultValue); result != defaultValue {
		t.Errorf("Expected %d, got %d", defaultValue, result)
	}

	// Test set valid value
	expectedValue := 20
	os.Setenv(key, "20")
	defer os.Unsetenv(key)

	if result := getEnvInt(key, defaultValue); result != expectedValue {
		t.Errorf("Expected %d, got %d", expectedValue, result)
	}

	// Test set invalid value
	os.Setenv(key, "invalid")
	if result := getEnvInt(key, defaultValue); result != defaultValue {
		t.Errorf("Expected %d, got %d", defaultValue, result)
	}
}
