// Package xmltest provides shared helpers for testing XML marshal/unmarshal
// against the xgen-generated SEFAZ NF-e schema types under domain/nfe/schema.
//
// All helpers receive *testing.T and call t.Fatalf on failure — they are
// only meant for use inside _test.go files.
package xmltest

import (
	"bytes"
	"encoding/xml"
	"errors"
	"io"
	"os"
	"testing"
)

// UnmarshalElement decodes the first XML element with the given local name
// into v. It walks past wrapping content (typically SOAP envelopes) until it
// finds the target start element.
func UnmarshalElement(t *testing.T, data []byte, localName string, v any) {
	t.Helper()
	dec := xml.NewDecoder(bytes.NewReader(data))
	for {
		tok, err := dec.Token()
		if errors.Is(err, io.EOF) {
			t.Fatalf("element %q not found in fixture", localName)
		}
		if err != nil {
			t.Fatalf("decode token: %v", err)
		}
		start, ok := tok.(xml.StartElement)
		if !ok || start.Name.Local != localName {
			continue
		}
		if err := dec.DecodeElement(v, &start); err != nil {
			t.Fatalf("DecodeElement(%s): %v", localName, err)
		}
		return
	}
}

// MarshalElement encodes v as a single root element with the given local name.
// xgen-generated root types (TNfeProc, TRetEnviNFe, TEnvEvento) do not declare
// XMLName, so xml.Marshal(v) would use the Go type name as element name.
func MarshalElement(t *testing.T, localName string, v any) []byte {
	t.Helper()
	var buf bytes.Buffer
	enc := xml.NewEncoder(&buf)
	if err := enc.EncodeElement(v, xml.StartElement{Name: xml.Name{Local: localName}}); err != nil {
		t.Fatalf("encode <%s>: %v", localName, err)
	}
	if err := enc.Close(); err != nil {
		t.Fatalf("encoder close: %v", err)
	}
	return buf.Bytes()
}

// MustReadFixture reads a testdata file or fails the test.
func MustReadFixture(t *testing.T, path string) []byte {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read fixture %s: %v", path, err)
	}
	return b
}

// AssertIdempotent verifies that marshal(parse(marshal(parse(data)))) ==
// marshal(parse(data)). After the first parse+marshal pass the pipeline must
// reach a fixed point — that is the property that matters in production.
//
// fresh1 and fresh2 are pointers to two zero-valued instances of the target
// schema type (e.g. &TNfeProc{}). Caller declares them explicitly because the
// concrete type lives in the package under test.
func AssertIdempotent(t *testing.T, data []byte, localName string, fresh1, fresh2 any) {
	t.Helper()
	UnmarshalElement(t, data, localName, fresh1)
	b1 := MarshalElement(t, localName, fresh1)

	UnmarshalElement(t, b1, localName, fresh2)
	b2 := MarshalElement(t, localName, fresh2)

	if !bytes.Equal(b1, b2) {
		t.Fatalf("non-idempotent <%s>:\n--- pass 1 (%d bytes) ---\n%s\n--- pass 2 (%d bytes) ---\n%s",
			localName, len(b1), b1, len(b2), b2)
	}
}

// CountStartElements returns the number of XML start tags in data.
// Coarse proxy for "did the parse/marshal pipeline preserve document structure?"
func CountStartElements(t *testing.T, data []byte) int {
	t.Helper()
	dec := xml.NewDecoder(bytes.NewReader(data))
	n := 0
	for {
		tok, err := dec.Token()
		if errors.Is(err, io.EOF) {
			return n
		}
		if err != nil {
			t.Fatalf("count tokens: %v", err)
		}
		if _, ok := tok.(xml.StartElement); ok {
			n++
		}
	}
}

// AssertElementsPreserved fails the test if marshalling the parsed data
// drops more than dropTolerance fraction of the start tags relative to the
// input. Detects field loss when the schema struct does not cover all
// elements of a real fixture.
//
// Only meaningful when input has no extra wrapping (no SOAP envelope) — the
// comparison is over the whole document.
func AssertElementsPreserved(t *testing.T, original, marshaled []byte, dropTolerance float64) {
	t.Helper()
	o := CountStartElements(t, original)
	m := CountStartElements(t, marshaled)
	if o == 0 {
		return
	}
	drop := float64(o-m) / float64(o)
	if drop > dropTolerance {
		t.Fatalf("element count dropped %.1f%% (orig=%d, marshaled=%d) — possible field loss",
			drop*100, o, m)
	}
}
