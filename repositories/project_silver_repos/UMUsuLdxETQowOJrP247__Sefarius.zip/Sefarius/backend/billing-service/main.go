package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	_ "github.com/lib/pq"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/danfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
	"github.com/sefarius/billing-service/interfaces"
)

func main() {
	// Database initialization. Fail fast if DATABASE_URL is missing —
	// a hardcoded fallback used to live here, which leaked the dev
	// credential into the repo (RF-01).
	dbConnStr := getEnv("DATABASE_URL", "")
	if dbConnStr == "" {
		log.Fatal("DATABASE_URL is required (copy .env.example to .env)")
	}
	db, err := initializeDatabase(dbConnStr)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v\n", err)
	}
	defer db.Close()

	// Initialize repositories and dependencies
	invoiceRepo := infrastructure.NewPostgresInvoiceRepository(db)
	idempotencyRepo := infrastructure.NewPostgresIdempotencyRepository(db)
	nfeRepo := infrastructure.NewPostgresNFeRepository(db)
	stockServiceURL := getEnv("STOCK_SERVICE_URL", "http://localhost:5001")
	stockClient := infrastructure.NewHTTPStockServiceClient(stockServiceURL)

	// Service initialization (Dependency Injection)
	svc := application.NewInvoiceService(invoiceRepo, idempotencyRepo, stockClient)
	handler := interfaces.NewInvoiceHandler(svc)

	// NF-e wiring. Sprint 1.11 mounted /api/nfe/* in main.go. Sprint 3.1
	// extracts cert loading into the testable loadCertificate (cert_loader.go)
	// which branches on NFE_DEV_MODE vs NFE_CERT_PATH+NFE_CERT_PASSWORD. The
	// dev branch (self-signed + MockClient) is the same as before; the prod
	// branch loads an A1 PKCS#12 successfully but then refuses to start
	// because the real SOAP SefazClient lands in Sprint 3.2.
	cert, isDev, err := loadCertificate(getEnv)
	if err != nil {
		log.Fatalf("certificate loading failed: %v", err)
	}

	// Sprint 3.3: prod path now boots. RealClient routes per-UF via the
	// 27-UF endpoint registry from Sprint 3.2 (cStat dispatch + mTLS
	// http.Client). Dev path keeps the self-signed cert + mock SEFAZ.
	var sefazClient nfe.SefazClient
	if isDev {
		log.Println("WARNING: using self-signed dev certificate; not valid for SEFAZ submission")
		sefazClient = sefaz.NewMockClient()
	} else {
		log.Printf("Loaded ICP-Brasil certificate: subject=%q expires=%s",
			cert.X509.Subject.CommonName,
			cert.X509.NotAfter.UTC().Format("2006-01-02"))
		realClient, err := sefaz.NewRealClient(cert, sefaz.NewDefaultRegistry())
		if err != nil {
			log.Fatalf("Failed to build real SefazClient: %v", err)
		}
		sefazClient = realClient
		log.Println("SefazClient: RealClient (SOAP, 27-UF registry)")
	}
	emitNFeUC := application.NewEmitNFeUseCase(cert, sefazClient, nfeRepo)
	danfeGen := danfe.NewGenerator()
	nfeHandler := interfaces.NewNFeHandler(emitNFeUC, nfeRepo, danfeGen)

	// Sprint 2.1: cancel + CCe event flow. Sprint 2.2 added the PDF
	// comprovantes which need nfeRepo (for original-NFe context) and
	// the shared DANFE generator.
	nfeEventRepo := infrastructure.NewPostgresNFeEventRepository(db)
	cancelUC := application.NewCancelNFeUseCase(cert, sefazClient, nfeRepo, nfeEventRepo)
	cceUC := application.NewSendCCeUseCase(cert, sefazClient, nfeRepo, nfeEventRepo)
	nfeEventHandler := interfaces.NewNFeEventHandler(cancelUC, cceUC, nfeEventRepo, nfeRepo, danfeGen)

	// Fiber app initialization
	app := fiber.New(fiber.Config{
		AppName:      "Billing Service v1.0",
		ErrorHandler: customErrorHandler,
		WriteTimeout: 30 * time.Second,
		ReadTimeout:  30 * time.Second,
	})

	// Middleware
	app.Use(recover.New())
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${status} - ${method} ${path} - ${latency}\n",
	}))
	app.Use(cors.New(cors.Config{
		AllowOrigins: getEnv("CORS_ORIGINS", "*"),
		AllowMethods: "GET,POST,PUT,DELETE,OPTIONS",
		AllowHeaders: "Origin,Content-Type,Accept,Idempotency-Key",
	}))

	// Routes
	setupRoutes(app, handler, nfeHandler, nfeEventHandler)

	// Start server
	port := getEnv("PORT", "5002")
	go func() {
		log.Printf("Starting Billing Service on port %s...\n", port)
		if err := app.Listen(":" + port); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v\n", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	log.Println("Shutting down Billing Service...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := app.ShutdownWithContext(ctx); err != nil {
		log.Fatalf("Shutdown error: %v\n", err)
	}
	log.Println("Billing Service stopped")
}

// setupRoutes configures all HTTP routes
func setupRoutes(app *fiber.App, handler *interfaces.InvoiceHandler, nfeHandler *interfaces.NFeHandler, nfeEventHandler *interfaces.NFeEventHandler) {
	// Health check
	app.Get("/health", handler.Health)

	// Invoice endpoints
	api := app.Group("/api/billing")
	api.Post("/invoices", handler.CreateInvoice)
	api.Get("/invoices", handler.ListInvoices)
	api.Get("/invoices/:id", handler.GetInvoice)
	api.Post("/invoices/:id/close", handler.CloseInvoice)
	api.Post("/invoices/:id/cancel", handler.CancelInvoice)
	api.Delete("/invoices/:id", handler.DeleteInvoice)

	// NF-e endpoints. Order matters: more specific routes first so
	// /:chave/cancel/xml, /:chave/cce/:seq, etc. are not swallowed by
	// the broader /:chave/* patterns.
	nfeAPI := app.Group("/api/nfe")
	nfeAPI.Post("/", nfeHandler.EmitNFe)
	nfeAPI.Get("/", nfeHandler.ListNFe)
	// Sprint 2.1 cancel + CCe — keep these above /:chave/xml.
	nfeAPI.Post("/:chave/cancel", nfeEventHandler.Cancel)
	nfeAPI.Post("/:chave/cce", nfeEventHandler.SendCCe)
	// Sprint 2.2 comprovante PDFs. /pdf must come before the bare
	// /:chave/cancel and /:chave/cce/:seq routes so the more-specific
	// segment wins.
	nfeAPI.Get("/:chave/cancel/pdf", nfeEventHandler.GetCancelPDF)
	nfeAPI.Get("/:chave/cce/:seq/pdf", nfeEventHandler.GetCCePDF)
	nfeAPI.Get("/:chave/cancel/xml", nfeEventHandler.GetCancelXML)
	nfeAPI.Get("/:chave/cancel", nfeEventHandler.GetCancel)
	nfeAPI.Get("/:chave/cce/:seq/xml", nfeEventHandler.GetCCeXML)
	nfeAPI.Get("/:chave/cce/:seq", nfeEventHandler.GetCCe)
	nfeAPI.Get("/:chave/cce", nfeEventHandler.ListCCe)
	// Sprint 1.11 NFe lifecycle — keep these last.
	nfeAPI.Get("/:chave/xml", nfeHandler.GetNFeXML)
	nfeAPI.Get("/:chave/danfe", nfeHandler.GetNFeDANFE)
	nfeAPI.Get("/:chave", nfeHandler.GetNFe)
}

// initializeDatabase initializes database connection
func initializeDatabase(dbConnStr string) (*sql.DB, error) {
	db, err := sql.Open("postgres", dbConnStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	// Connection pool settings - configurable via environment variables
	db.SetMaxOpenConns(getEnvInt("DB_MAX_CONNECTIONS", 25))
	db.SetMaxIdleConns(getEnvInt("DB_MAX_IDLE_CONNECTIONS", 5))
	db.SetConnMaxLifetime(time.Duration(getEnvInt("DB_CONN_MAX_LIFETIME_SECONDS", 300)) * time.Second)
	db.SetConnMaxIdleTime(2 * time.Minute)

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	log.Println("Database connection established")
	return db, nil
}

// customErrorHandler handles all errors
func customErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	var msg string

	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		msg = fe.Message
	} else {
		msg = err.Error()
	}

	return c.Status(code).JSON(fiber.Map{
		"success": false,
		"error":   msg,
		"code":    code,
	})
}

// getEnv gets environment variable with default fallback
func getEnv(key, defaultValue string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return defaultValue
}

// getEnvInt gets integer environment variable with default fallback
func getEnvInt(key string, defaultVal int) int {
	val := os.Getenv(key)
	if val == "" {
		return defaultVal
	}
	intVal, err := strconv.Atoi(val)
	if err != nil {
		return defaultVal
	}
	return intVal
}
