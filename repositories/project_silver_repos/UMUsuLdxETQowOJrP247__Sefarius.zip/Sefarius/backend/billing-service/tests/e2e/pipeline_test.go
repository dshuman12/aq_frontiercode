// Package e2e holds end-to-end tests that drive the entire NF-e
// emission pipeline through every layer: seeder -> validate -> sign
// -> authorize (mock SEFAZ) -> persist -> retrieve -> render DANFE.
//
// These are *unit* tests in the Go sense (no external services), but
// they exercise the integration story Sprint 1.10 promised: the
// system works as a whole, not just per layer.
package e2e_test

import (
	"bytes"
	"context"
	"math/rand"
	"testing"
	"time"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/danfe"
	"github.com/sefarius/billing-service/infrastructure/seeder"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

// TestPipeline_SingleNFeAllStages walks one seeded NF-e through every
// stage and asserts the post-condition each layer guarantees:
//
//  1. Seeder produces a TNFe whose chave validates and whose totals reconcile.
//  2. Use case signs, authorizes (mock), and persists.
//  3. Repository round-trips the record.
//  4. Stored signed XML still verifies cryptographically.
//  5. DANFE renderer produces a non-empty PDF carrying the chave.
//
// This is the *single* test the AfterQuery reviewer can read to
// understand the whole pipeline. Per-layer tests cover edge cases;
// this one covers the happy seam.
func TestPipeline_SingleNFeAllStages(t *testing.T) {
	// Stage 1: deterministic seeder
	s := seeder.New(seeder.Options{
		Rng:        rand.New(rand.NewSource(2026)),
		InitialNNF: 1,
		StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
	})
	tnfe, err := s.Generate()
	if err != nil {
		t.Fatalf("seeder.Generate: %v", err)
	}
	if issues := nfe.ValidateSemantic(tnfe); len(issues) > 0 {
		t.Fatalf("seeded NF-e has %d semantic issues", len(issues))
	}
	if issues := nfe.ValidateTotalsAgainstItems(tnfe); len(issues) > 0 {
		t.Fatalf("seeded NF-e has %d totals issues", len(issues))
	}
	chave := nfe.Chave(tnfe.InfNFe.IdAttr[3:]) // strip "NFe" prefix
	if err := chave.Validate(); err != nil {
		t.Fatalf("seeded chave is invalid: %v", err)
	}

	// Stage 2-3: emit + persist via the wired use case
	cert, err := nfe.GenerateSelfSignedTest("e2e-pipeline")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, mock, repo)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
	if err != nil {
		t.Fatalf("Emit: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusAuthorized {
		t.Fatalf("Status = %s, want AUTHORIZED", out.Status)
	}
	if out.Chave != chave {
		t.Errorf("Outcome.Chave %s != seeded chave %s", out.Chave, chave)
	}

	// Stage 4: repository round-trip + signature still verifies
	rec, err := repo.GetByChave(context.Background(), chave)
	if err != nil {
		t.Fatalf("repo.GetByChave: %v", err)
	}
	if !bytes.Equal(rec.SignedXML, out.SignedXML) {
		t.Error("persisted SignedXML differs from outcome SignedXML")
	}
	if err := nfe.VerifySignature(rec.SignedXML); err != nil {
		t.Fatalf("VerifySignature on stored XML: %v", err)
	}

	// Stage 4.b: namespace was actually emitted (sprint 1.10 fix)
	if !bytes.Contains(rec.SignedXML, []byte(`xmlns="http://www.portalfiscal.inf.br/nfe"`)) {
		t.Error("stored XML missing SEFAZ NF-e namespace declaration on <NFe>")
	}

	// Stage 5: DANFE renders a real PDF that carries the chave
	gen := danfe.NewGenerator()
	pdf, err := gen.Generate(tnfe, rec.Protocol)
	if err != nil {
		t.Fatalf("danfe.Generate: %v", err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Errorf("DANFE bytes do not start with %%PDF-: %x", pdf[:8])
	}
	if len(pdf) < 1000 {
		t.Errorf("DANFE suspiciously small (%d bytes)", len(pdf))
	}
}

// TestPipeline_DeterministicEndToEnd asserts a stronger property than
// per-layer determinism (which the seeder package already locks in
// via TestSeeder_DeterministicForFixedSeed): the *full pipeline* —
// seed -> Build -> sign -> Authorize via mock -> persist — produces
// the same chave AND the same protocol number across consecutive
// runs with identical seeds. This catches drift in any layer
// silently mutating state across calls (e.g. a counter not reset, a
// rng leaking between fresh-instance constructors).
//
// Note: signed XML bytes are NOT byte-identical across runs because
// nfe.GenerateSelfSignedTest creates a fresh RSA key + time-based
// serial each call, so the embedded cert differs. The chave + the
// mock-side protocol number are the layers that *should* be stable,
// and they are.
func TestPipeline_DeterministicEndToEnd(t *testing.T) {
	run := func() (nfe.Chave, string) {
		s := seeder.New(seeder.Options{
			Rng:        rand.New(rand.NewSource(7)),
			InitialNNF: 1,
			StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
		})
		tnfe, err := s.Generate()
		if err != nil {
			t.Fatalf("seeder.Generate: %v", err)
		}
		cert, err := nfe.GenerateSelfSignedTest("determinism")
		if err != nil {
			t.Fatalf("GenerateSelfSignedTest: %v", err)
		}
		mock := sefaz.NewMockClient()
		repo := infrastructure.NewInMemoryNFeRepository()
		uc := application.NewEmitNFeUseCase(cert, mock, repo)
		out, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
		if err != nil {
			t.Fatalf("Emit: %v", err)
		}
		return out.Chave, out.Protocol.NProt
	}
	chave1, prot1 := run()
	chave2, prot2 := run()
	if chave1 != chave2 {
		t.Errorf("chave drifted across runs: %s vs %s", chave1, chave2)
	}
	if prot1 != prot2 {
		t.Errorf("protocol number drifted across runs: %s vs %s", prot1, prot2)
	}
}

// TestPipeline_BatchOf50ThroughDANFE extends the sprint 1.9 50-NFe
// pipeline test with the DANFE rendering step the strategy doc spec'd
// for sprint 1.10 ("criar -> validar -> assinar -> DANFE"). All 50
// must produce a renderable PDF; failures here would point to a
// data-shape edge case the per-layer tests miss.
func TestPipeline_BatchOf50ThroughDANFE(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping 50-NFe batch test in -short mode")
	}
	s := seeder.New(seeder.Options{
		Rng:        rand.New(rand.NewSource(123)),
		InitialNNF: 1,
		StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
	})
	cert, err := nfe.GenerateSelfSignedTest("e2e-batch")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, mock, repo)
	gen := danfe.NewGenerator()

	const n = 50
	batch, err := s.GenerateBatch(n)
	if err != nil {
		t.Fatalf("GenerateBatch: %v", err)
	}
	for i, tnfe := range batch {
		out, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
		if err != nil {
			t.Fatalf("element %d Emit: %v", i, err)
		}
		pdf, err := gen.Generate(tnfe, out.Protocol)
		if err != nil {
			t.Fatalf("element %d danfe.Generate: %v", i, err)
		}
		if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
			t.Fatalf("element %d DANFE bytes do not start with %%PDF-", i)
		}
		if err := nfe.VerifySignature(out.SignedXML); err != nil {
			t.Fatalf("element %d VerifySignature: %v", i, err)
		}
	}
	if mock.CallCount() != int64(n) {
		t.Errorf("mock.CallCount = %d, want %d", mock.CallCount(), n)
	}
}
