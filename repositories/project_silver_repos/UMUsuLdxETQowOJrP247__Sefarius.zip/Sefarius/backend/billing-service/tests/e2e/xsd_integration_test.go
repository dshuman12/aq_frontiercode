//go:build integration

package e2e_test

import (
	"context"
	"errors"
	"math/rand"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/seeder"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

const (
	xsdRelativePath = "../../domain/nfe/schema/xsd/nfe_v4.00.xsd"
	xsdSearchDir    = "../../domain/nfe/schema/xsd"
)

// TestXSD_NamespaceResolutionWorks is the lock-in for sprint 1.10's
// namespace fix. Before the fix, the marshalled <NFe> root sat in the
// no-namespace, and xmllint refused to even relate the document to
// the SEFAZ XSD ("element NFe is in no namespace"). After the fix,
// xmllint resolves element names against http://www.portalfiscal.inf.br/nfe
// and reports schema-level errors (pattern, sequence, enumeration)
// instead — proof the document is now SEFAZ-namespaced.
//
// What this test asserts:
//
//   - xmllint runs successfully (the schema loaded from the XSD set)
//   - any errors it reports cite SEFAZ-namespaced element names like
//     '{http://www.portalfiscal.inf.br/nfe}vBC' — i.e. the parser
//     engaged with the schema at the namespace level
//   - no "is in no namespace" / "no DTD found" / "element ... not
//     declared" errors appear (which would indicate the namespace
//     fix regressed)
//
// What this test does NOT assert:
//
//   - full XSD compliance. Pattern facet violations on empty optional
//     elements (omitempty gap in xgen-generated structs) and a
//     handful of xs:sequence ordering mismatches (also from xgen)
//     are remaining tech debt for sprint future. Documented in
//     application/emit_nfe.go::marshalNFe godoc.
//
// Build tag: requires xmllint in PATH. The Makefile target test-xsd
// runs this inside an Alpine container with libxml2-utils preinstalled.
func TestXSD_NamespaceResolutionWorks(t *testing.T) {
	xsdPath, err := filepath.Abs(xsdRelativePath)
	if err != nil {
		t.Fatalf("resolve XSD path: %v", err)
	}
	searchPath, err := filepath.Abs(xsdSearchDir)
	if err != nil {
		t.Fatalf("resolve search path: %v", err)
	}

	signedXML := emitOneSeededNFe(t, 2026)

	err = nfe.ValidateXSD(signedXML, xsdPath, searchPath)
	if errors.Is(err, nfe.ErrXmllintNotAvailable) {
		t.Skipf("xmllint not in PATH; install libxml2-utils to enable. (%v)", err)
	}
	// We expect xmllint to find pattern errors (sprint future tech
	// debt) — but the failure must NOT be a namespace resolution
	// failure. Anything else means the namespace fix regressed.
	if err == nil {
		t.Logf("XSD validation passed cleanly — pattern + ordering tech debt may have been closed")
		return
	}
	msg := err.Error()
	regressionMarkers := []string{
		"is in no namespace",
		"No DTD found",
		"Element 'NFe': No matching global declaration",
		"Element 'NFe': This element is not expected",
	}
	for _, marker := range regressionMarkers {
		if strings.Contains(msg, marker) {
			t.Errorf("XSD regression detected — namespace fix broke: %q\nfull error:\n%v", marker, err)
		}
	}
	// Sanity: the error should cite SEFAZ-namespaced element names,
	// proving xmllint engaged with the schema at the namespace level.
	if !strings.Contains(msg, "{http://www.portalfiscal.inf.br/nfe}") {
		t.Errorf("xmllint output does not cite SEFAZ namespace; either schema didn't load or message format changed:\n%v", err)
	}
}

// TestXSD_NoFacetErrorsOnSeededNFe is the lock-in for the post-review
// of sprint 1.10 D5 gap #1 (and the value-to-pointer half — gap #3).
// Before the fix, a freshly marshaled NFe carried ~16 facet violations
// because xgen typed optional fields as Go value-strings; they
// marshaled as <elem></elem>, which the SEFAZ XSD pattern facets
// reject (e.g. vFrete must match `0|0\.[0-9]{2}|...`; "" doesn't).
//
// After the fix (refine-nfe-types.sh adds ,omitempty to pointer
// optionals AND retypes a curated list of mistyped value-string
// optionals to *string), facet errors must be zero.
//
// Sequence-ordering errors (xmllint "X is not expected. Expected is
// Y") are deliberately NOT asserted here — that is sprint 1.10 D5
// gap #2, which requires an XSD-aware tool to reorder Go struct
// fields and is out of scope for this sprint.
func TestXSD_NoFacetErrorsOnSeededNFe(t *testing.T) {
	xsdPath, err := filepath.Abs(xsdRelativePath)
	if err != nil {
		t.Fatalf("resolve XSD path: %v", err)
	}
	searchPath, err := filepath.Abs(xsdSearchDir)
	if err != nil {
		t.Fatalf("resolve search path: %v", err)
	}
	signedXML := emitOneSeededNFe(t, 2026)

	err = nfe.ValidateXSD(signedXML, xsdPath, searchPath)
	if errors.Is(err, nfe.ErrXmllintNotAvailable) {
		t.Skipf("xmllint not in PATH; install libxml2-utils to enable. (%v)", err)
	}
	if err == nil {
		// Schema fully clean — even gap #2 is closed. Best outcome.
		return
	}
	msg := err.Error()
	patternErrs := strings.Count(msg, "facet 'pattern'")
	minLengthErrs := strings.Count(msg, "facet 'minLength'")
	enumErrs := strings.Count(msg, "facet 'enumeration'")
	if patternErrs > 0 || minLengthErrs > 0 || enumErrs > 0 {
		t.Errorf("expected 0 facet errors after the omitempty + value-to-pointer fix; got pattern=%d, minLength=%d, enumeration=%d.\nfull xmllint output:\n%v",
			patternErrs, minLengthErrs, enumErrs, err)
	}
}

// emitOneSeededNFe drives a single NF-e through the full emit
// pipeline and returns its signed XML bytes. Shared helper for the
// XSD tests and any future integration test that needs a real signed
// document.
func emitOneSeededNFe(t *testing.T, seed int64) []byte {
	t.Helper()
	s := seeder.New(seeder.Options{
		Rng:        rand.New(rand.NewSource(seed)),
		InitialNNF: 1,
		StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
	})
	tnfe, err := s.Generate()
	if err != nil {
		t.Fatalf("seeder.Generate: %v", err)
	}
	cert, err := nfe.GenerateSelfSignedTest("xsd-integration")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, mock, repo)

	out, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
	if err != nil {
		t.Fatalf("Emit: %v", err)
	}
	return out.SignedXML
}
