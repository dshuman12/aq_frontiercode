package e2e_test

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/danfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
	"github.com/sefarius/billing-service/interfaces"
)

// TestHTTPIntegration_AllFiveEndpointsInSequence drives the entire
// HTTP surface as a single user journey:
//
//	POST /api/nfe        -> emit a fresh NF-e
//	GET  /api/nfe        -> see it in the list
//	GET  /api/nfe/:chave -> get the record summary
//	GET  /api/nfe/:chave/xml   -> raw signed XML
//	GET  /api/nfe/:chave/danfe -> DANFE PDF
//
// Per-endpoint tests in interfaces/nfe_handler_test.go cover error
// paths and edge cases; this test asserts the *sequence* works without
// per-call setup, so the AfterQuery reviewer can copy the requests
// into curl and watch the journey end-to-end.
func TestHTTPIntegration_AllFiveEndpointsInSequence(t *testing.T) {
	app := buildIntegrationApp(t)

	// Step 1: emit
	postBody := canonicalEmitRequest()
	req := httptest.NewRequest("POST", "/api/nfe/", bytes.NewReader(postBody))
	req.Header.Set("Content-Type", "application/json")
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	if resp.StatusCode != fiber.StatusCreated {
		t.Fatalf("POST status = %d, want 201", resp.StatusCode)
	}
	emitEnv := decodeEnvelope(t, resp)
	emitData := emitEnv.Data.(map[string]any)
	chave, _ := emitData["chave"].(string)
	if len(chave) != 44 {
		t.Fatalf("emitted chave = %q (len %d), want 44 digits", chave, len(chave))
	}
	if emitData["status"] != "AUTHORIZED" {
		t.Errorf("status = %v, want AUTHORIZED", emitData["status"])
	}

	// Step 2: list — record must appear. Response shape changed
	// (2026-05-08) from bare array to PaginatedResponse-shaped map
	// (items/total/limit/offset) for numerical pagination support.
	listEnv := getEnvelope(t, app, "/api/nfe/")
	wrap := listEnv.Data.(map[string]any)
	list := wrap["items"].([]any)
	if len(list) != 1 {
		t.Errorf("list returned %d records, want 1", len(list))
	}
	if list[0].(map[string]any)["chave"] != chave {
		t.Errorf("list[0].chave = %v, want %s", list[0].(map[string]any)["chave"], chave)
	}
	if total, ok := wrap["total"].(float64); !ok || int(total) != 1 {
		t.Errorf("total = %v, want 1", wrap["total"])
	}

	// Step 3: get record by chave
	getEnv := getEnvelope(t, app, "/api/nfe/"+chave)
	if getEnv.Data.(map[string]any)["lifecycle"] != "AUTHORIZED" {
		t.Errorf("get lifecycle = %v, want AUTHORIZED", getEnv.Data.(map[string]any)["lifecycle"])
	}

	// Step 4: raw signed XML — must declare the SEFAZ namespace and
	// embed the Signature block.
	xmlBytes := rawBody(t, app, "GET", "/api/nfe/"+chave+"/xml")
	wantSubstrings := []string{
		`xmlns="http://www.portalfiscal.inf.br/nfe"`,
		`<infNFe`,
		`<ds:Signature`,
	}
	for _, want := range wantSubstrings {
		if !strings.Contains(string(xmlBytes), want) {
			t.Errorf("retrieved XML missing %q", want)
		}
	}
	// Step 4.b: the XML retrieved over HTTP still verifies cryptographically
	// — the wire round-trip preserves the signature exactly.
	if err := nfe.VerifySignature(xmlBytes); err != nil {
		t.Errorf("VerifySignature on HTTP-retrieved XML: %v", err)
	}

	// Step 5: DANFE PDF
	danfeReq := httptest.NewRequest("GET", "/api/nfe/"+chave+"/danfe", nil)
	danfeResp, err := app.Test(danfeReq, -1)
	if err != nil {
		t.Fatalf("GET danfe: %v", err)
	}
	defer danfeResp.Body.Close()
	if danfeResp.StatusCode != fiber.StatusOK {
		t.Fatalf("GET danfe status = %d, want 200", danfeResp.StatusCode)
	}
	if ct := danfeResp.Header.Get("Content-Type"); ct != "application/pdf" {
		t.Errorf("danfe Content-Type = %q, want application/pdf", ct)
	}
	pdfBytes, _ := io.ReadAll(danfeResp.Body)
	if !bytes.HasPrefix(pdfBytes, []byte("%PDF-")) {
		t.Errorf("DANFE bytes do not start with %%PDF-: %x", pdfBytes[:8])
	}
}

// rawBody fetches a non-JSON response (XML, PDF) and returns the raw
// bytes. Centralizes the error-handling + body-close idiom so tests
// don't accumulate copies of the same boilerplate (and don't ignore
// app.Test errors, as the original step-4/step-5 code did).
func rawBody(t *testing.T, app *fiber.App, method, path string) []byte {
	t.Helper()
	req := httptest.NewRequest(method, path, nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("%s %s: %v", method, path, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("%s %s status = %d, want 200", method, path, resp.StatusCode)
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("%s %s read body: %v", method, path, err)
	}
	return body
}

// buildIntegrationApp wires the full Fiber app with in-memory
// implementations — the same composition main.go would use in
// production, minus the database. Use case and handler share one
// repository so persistence side-effects from POST /api/nfe are
// visible to subsequent GET requests.
func buildIntegrationApp(t *testing.T) *fiber.App {
	t.Helper()
	cert, err := nfe.GenerateSelfSignedTest("http-integration")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, sefaz.NewMockClient(), repo)
	handler := interfaces.NewNFeHandler(uc, repo, danfe.NewGenerator())

	app := fiber.New()
	api := app.Group("/api/nfe")
	api.Post("/", handler.EmitNFe)
	api.Get("/", handler.ListNFe)
	api.Get("/:chave", handler.GetNFe)
	api.Get("/:chave/xml", handler.GetNFeXML)
	api.Get("/:chave/danfe", handler.GetNFeDANFE)
	return app
}

func canonicalEmitRequest() []byte {
	req := interfaces.EmitNFeRequest{
		Emit: interfaces.EmitterDTO{
			CNPJ: "05730928000145", XNome: "EMPRESA E2E LTDA", IE: "1234567890", CRT: "3",
			XLgr: "AV TESTE", Nro: "100", XBairro: "CENTRO",
			CMun: "4314902", XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000000",
		},
		Dest: interfaces.RecipientDTO{
			CNPJ: "11444777000161", XNome: "CLIENTE E2E LTDA",
			IndIEDest: "1", IE: "9876543210",
			XLgr: "RUA EXEMPLO", Nro: "200", XBairro: "BAIRRO",
			CMun: "4314902", XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000001",
		},
		Ide: interfaces.IdentificationDTO{
			CUF: "43", CNF: "12345678", NatOp: "VENDA DE MERCADORIA",
			Serie: "1", NNF: "100", DhEmi: "2026-05-06T10:00:00-03:00",
			TpNF: "1", IdDest: "1", CMunFG: "4314902",
			TpAmb: "2", FinNFe: "1", IndPres: "1",
		},
		Items: []interfaces.ItemDTO{{
			CProd: "001", XProd: "PRODUTO E2E", NCM: "22021000", CFOP: "5102",
			UCom: "UN", QCom: "1.0000", VUnCom: "100.0000000000", VProd: "100.00",
			VBC: "100.00", PICMS: "18.00", VPIS: "1.65", VCOFINS: "7.60",
		}},
	}
	b, _ := json.Marshal(req)
	return b
}

func decodeEnvelope(t *testing.T, resp *http.Response) application.APIResponse {
	t.Helper()
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var env application.APIResponse
	if err := json.Unmarshal(body, &env); err != nil {
		t.Fatalf("decode envelope: %v\nbody: %s", err, body)
	}
	return env
}

func getEnvelope(t *testing.T, app *fiber.App, path string) application.APIResponse {
	t.Helper()
	req := httptest.NewRequest("GET", path, nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("GET %s: %v", path, err)
	}
	if resp.StatusCode != fiber.StatusOK {
		t.Fatalf("GET %s status = %d, want 200", path, resp.StatusCode)
	}
	return decodeEnvelope(t, resp)
}
