package infrastructure

import (
	"context"
	"sort"
	"sync"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
)

// InMemoryNFeRepository implements nfe.NFeRepository against an
// in-process map. It exists for two reasons:
//
//  1. The default repository for development and unit tests that
//     should not depend on Docker or a running Postgres.
//  2. The reference implementation against which a future
//     PostgresNFeRepository is contract-tested.
//
// Concurrency-safe via sync.Mutex. Records are deep-copied on read so
// callers can mutate the returned struct without leaking back into
// the store — this matches how a real database would behave.
type InMemoryNFeRepository struct {
	mu      sync.Mutex
	records map[nfe.Chave]*nfe.NFeRecord
}

// NewInMemoryNFeRepository returns an empty in-memory repository.
func NewInMemoryNFeRepository() *InMemoryNFeRepository {
	return &InMemoryNFeRepository{
		records: make(map[nfe.Chave]*nfe.NFeRecord),
	}
}

// Save upserts a record by chave. If the record is new, CreatedAt is
// stamped; UpdatedAt always advances. The caller is expected to leave
// CreatedAt zero on first save and let the repo own the timestamps —
// this prevents clock drift across services from corrupting the audit
// trail.
func (r *InMemoryNFeRepository) Save(ctx context.Context, record *nfe.NFeRecord) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if record == nil || record.Chave == "" {
		return nfe.ErrInvalidChaveLength
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	now := time.Now().UTC()
	stored := cloneRecord(record)
	if existing, ok := r.records[record.Chave]; ok {
		stored.CreatedAt = existing.CreatedAt
	} else {
		stored.CreatedAt = now
	}
	stored.UpdatedAt = now
	r.records[record.Chave] = stored

	// Refresh caller's timestamps so they match what was persisted.
	record.CreatedAt = stored.CreatedAt
	record.UpdatedAt = stored.UpdatedAt
	return nil
}

// GetByChave returns ErrNFeNotFound when the chave is unknown.
func (r *InMemoryNFeRepository) GetByChave(ctx context.Context, chave nfe.Chave) (*nfe.NFeRecord, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	rec, ok := r.records[chave]
	if !ok {
		return nil, nfe.ErrNFeNotFound
	}
	return cloneRecord(rec), nil
}

// Count returns the number of stored NFe records. Pairs with List
// to expose Total in the paginated HTTP response.
func (r *InMemoryNFeRepository) Count(ctx context.Context) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.records), nil
}

// List returns records ordered by CreatedAt descending — the natural
// "most recent first" order for an audit-style listing. limit<=0 is
// treated as "all"; offset<0 as 0.
func (r *InMemoryNFeRepository) List(ctx context.Context, limit, offset int) ([]*nfe.NFeRecord, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	out := make([]*nfe.NFeRecord, 0, len(r.records))
	for _, rec := range r.records {
		out = append(out, cloneRecord(rec))
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].CreatedAt.After(out[j].CreatedAt)
	})

	if offset < 0 {
		offset = 0
	}
	if offset >= len(out) {
		return []*nfe.NFeRecord{}, nil
	}
	out = out[offset:]
	if limit > 0 && limit < len(out) {
		out = out[:limit]
	}
	return out, nil
}

// cloneRecord deep-copies a record so the store and the caller never
// share mutable state. Slices and pointer fields get their own
// allocations; primitives are copied implicitly.
func cloneRecord(src *nfe.NFeRecord) *nfe.NFeRecord {
	if src == nil {
		return nil
	}
	dst := *src
	if src.SignedXML != nil {
		dst.SignedXML = append([]byte(nil), src.SignedXML...)
	}
	if src.Protocol != nil {
		p := *src.Protocol
		dst.Protocol = &p
	}
	if src.Rejection != nil {
		r := *src.Rejection
		dst.Rejection = &r
	}
	return &dst
}

// Compile-time guarantee InMemoryNFeRepository satisfies the contract.
var _ nfe.NFeRepository = (*InMemoryNFeRepository)(nil)
