package seeder

import (
	"fmt"
	"math/rand"
	"strconv"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// Seeder produces a stream of structurally valid *schema.TNFe values
// suitable for demos, dev environments, and integration tests.
//
// One Seeder represents one fixed emitter ("the merchant"). Each
// Generate call yields a fresh NF-e *from* that emitter to a random
// recipient with a random subset of the catalog. Sequential calls use
// a monotonic nNF so the chaves are unique within the batch.
//
// All randomness flows through the *rand.Rand passed at construction,
// so identical seeds reproduce identical outputs — the property
// integration tests rely on for stable assertions.
type Seeder struct {
	rng       *rand.Rand
	emitter   *seededEmitter
	nNF       int       // monotonic nNF counter; starts at the configured initial value
	startTime time.Time // dhEmi anchor; each generate spaces by ~1 minute
}

// seededEmitter caches the constant fields of the emitter so each
// generate call doesn't have to re-roll them. The naming is internal
// because the public API never exposes this struct directly.
type seededEmitter struct {
	cnpj    string
	xnome   string
	ie      string
	city    City
	xLgr    string
	nro     string
	xBairro string
	cep     string
}

// Options configures a Seeder. Zero values are valid: rng falls back
// to time-seeded math/rand, InitialNNF defaults to 1, StartTime to
// 30 minutes ago. Pass non-zero values when reproducibility matters.
type Options struct {
	Rng        *rand.Rand
	InitialNNF int
	StartTime  time.Time
}

// New returns a Seeder configured per opts. The emitter identity is
// rolled once here and stays fixed for the Seeder's lifetime — so
// tests can produce 50 NF-es from the same company, the way a real
// merchant looks in their daily emissions.
func New(opts Options) *Seeder {
	rng := opts.Rng
	if rng == nil {
		rng = rand.New(rand.NewSource(time.Now().UnixNano()))
	}
	nNF := opts.InitialNNF
	if nNF <= 0 {
		nNF = 1
	}
	start := opts.StartTime
	if start.IsZero() {
		start = time.Now().Add(-30 * time.Minute)
	}
	city := brazilianCities[rng.Intn(len(brazilianCities))]
	emit := &seededEmitter{
		cnpj:    GenerateCNPJ(rng),
		xnome:   emitterNames[rng.Intn(len(emitterNames))],
		ie:      GenerateIE(rng),
		city:    city,
		xLgr:    streetNames[rng.Intn(len(streetNames))],
		nro:     strconv.Itoa(100 + rng.Intn(2000)),
		xBairro: neighborhoods[rng.Intn(len(neighborhoods))],
		cep:     fmt.Sprintf("%05d000", rng.Intn(100000)),
	}
	return &Seeder{rng: rng, emitter: emit, nNF: nNF, startTime: start}
}

// Generate returns one fresh *schema.TNFe. The result is post-Build
// (chave + Id + cDV computed) and passes both ValidateSemantic and
// ValidateTotalsAgainstItems — so callers can sign and submit
// without further checks.
func (s *Seeder) Generate() (*schema.TNFe, error) {
	emit := s.buildEmit()
	dest, isInterstate := s.buildDest()
	ide := s.buildIde(isInterstate)
	dets, total := s.buildItemsAndTotal(isInterstate)

	builder := nfe.New().
		Ide(ide).
		Emit(emit).
		Dest(dest).
		Total(total).
		Transp(&schema.Transp{ModFrete: "9"}).
		Pag(&schema.Pag{DetPag: []*schema.DetPag{{TPag: "01", VPag: total.ICMSTot.VNF}}})
	for _, det := range dets {
		builder.AddDet(det)
	}
	tnfe, err := builder.Build()
	if err != nil {
		return nil, fmt.Errorf("seeder.Generate: build: %w", err)
	}

	s.nNF++
	return tnfe, nil
}

// GenerateBatch returns n consecutive NF-es. If any generation fails,
// the function returns the partial slice plus the error so callers
// can inspect what was produced before the failure.
func (s *Seeder) GenerateBatch(n int) ([]*schema.TNFe, error) {
	out := make([]*schema.TNFe, 0, n)
	for i := 0; i < n; i++ {
		tnfe, err := s.Generate()
		if err != nil {
			return out, fmt.Errorf("batch element %d: %w", i, err)
		}
		out = append(out, tnfe)
	}
	return out, nil
}

func (s *Seeder) buildEmit() *schema.Emit {
	cnpj := s.emitter.cnpj
	return &schema.Emit{
		CNPJ:  &cnpj,
		XNome: s.emitter.xnome,
		EnderEmit: &schema.TEnderEmi{
			XLgr:    s.emitter.xLgr,
			Nro:     s.emitter.nro,
			XBairro: s.emitter.xBairro,
			CMun:    s.emitter.city.IBGECode,
			XMun:    s.emitter.city.Name,
			UF:      s.emitter.city.UF,
			CEP:     s.emitter.cep,
		},
		IE:  s.emitter.ie,
		CRT: "3", // Regime Normal — Simples Nacional has different math handled by separate facade
	}
}

// buildDest picks a recipient. Roughly 70% juridical (CNPJ), 30%
// natural (CPF). Returns whether the operation is interestadual so
// the caller can choose the correct CFOP / pICMS.
func (s *Seeder) buildDest() (*schema.Dest, bool) {
	dest := &schema.Dest{
		IndIEDest: "9", // default: nao contribuinte; flipped to "1" below if CNPJ
	}

	city := brazilianCities[s.rng.Intn(len(brazilianCities))]
	dest.EnderDest = &schema.TEndereco{
		XLgr:    streetNames[s.rng.Intn(len(streetNames))],
		Nro:     strconv.Itoa(100 + s.rng.Intn(2000)),
		XBairro: neighborhoods[s.rng.Intn(len(neighborhoods))],
		CMun:    city.IBGECode,
		XMun:    city.Name,
		UF:      city.UF,
		CEP:     stringPtr(fmt.Sprintf("%05d000", s.rng.Intn(100000))),
	}
	isInterstate := city.UF != s.emitter.city.UF

	if s.rng.Float64() < 0.7 {
		// Juridical recipient
		cnpj := GenerateCNPJ(s.rng)
		dest.CNPJ = &cnpj
		dest.XNome = stringPtr(recipientNamesCNPJ[s.rng.Intn(len(recipientNamesCNPJ))])
		dest.IndIEDest = "1" // contribuinte
		ie := GenerateIE(s.rng)
		dest.IE = &ie
	} else {
		// Natural-person recipient
		cpf := GenerateCPF(s.rng)
		dest.CPF = &cpf
		dest.XNome = stringPtr(recipientNamesCPF[s.rng.Intn(len(recipientNamesCPF))])
		dest.IndIEDest = "9" // nao contribuinte
	}
	return dest, isInterstate
}

// brasiliaTZ is the fixed -03:00 offset SEFAZ accepts on dhEmi. Using
// time.UTC + RFC3339 produces "Z"-suffixed strings that the leiaute
// pattern rejects ("must be ±NN:00, never Z"); pinning to a fixed
// non-UTC zone makes the formatter emit the expected "-03:00" form.
var brasiliaTZ = time.FixedZone("BRT", -3*3600)

func (s *Seeder) buildIde(isInterstate bool) *schema.Ide {
	dhEmi := s.startTime.Add(time.Duration(s.nNF) * time.Minute).In(brasiliaTZ).Format(time.RFC3339)
	idDest := string(nfe.IdDestInterna)
	if isInterstate {
		idDest = string(nfe.IdDestInterestadual)
	}
	return &schema.Ide{
		CUF:      s.emitter.city.IBGECode[:2],
		CNF:      fmt.Sprintf("%08d", s.rng.Intn(100000000)),
		NatOp:    "VENDA DE MERCADORIA",
		Mod:      string(nfe.ModeloNFe),
		Serie:    "1",
		NNF:      strconv.Itoa(s.nNF),
		DhEmi:    dhEmi,
		TpNF:     "1",
		IdDest:   idDest,
		CMunFG:   s.emitter.city.IBGECode,
		TpImp:    "1",
		TpEmis:   string(nfe.TpEmisNormal),
		TpAmb:    string(nfe.TpAmbHomologacao),
		FinNFe:   string(nfe.FinNFeNormal),
		IndFinal: "1",
		IndPres:  string(nfe.IndPresPresencial),
		ProcEmi:  string(nfe.ProcEmiContribuinte),
		VerProc:  "sefarius 0.1",
	}
}

// Tax rates the seeder applies. pICMS is 12% interestadual / 18% interna —
// the simplest split that matches what real-world venda interna SP-RS /
// SP-SP looks like. pPIS = 1.65%, pCOFINS = 7.60% (regime cumulativo /
// não-cumulativo uniform on the wire — distinction lives in the regime
// selector, out of seeder scope).
const (
	pICMSInterna    = 18.0
	pICMSInterstate = 12.0
	pPIS            = 1.65
	pCOFINS         = 7.60
)

// buildItemsAndTotal generates 1-5 line items, calls the CST 00
// facade for the per-item tax math, and sums into the Total block so
// ValidateTotalsAgainstItems passes without further work.
func (s *Seeder) buildItemsAndTotal(isInterstate bool) ([]*schema.Det, *schema.Total) {
	pICMS := pICMSInterna
	if isInterstate {
		pICMS = pICMSInterstate
	}
	cfop := pickCFOP(s.rng, isInterstate)

	itemCount := 1 + s.rng.Intn(5)
	dets := make([]*schema.Det, 0, itemCount)
	var sumVBC, sumVICMS, sumVPIS, sumVCOFINS float64

	for i := 0; i < itemCount; i++ {
		product := productCatalog[s.rng.Intn(len(productCatalog))]
		qty := 1.0 + float64(s.rng.Intn(10))
		unitPrice := product.UnitPriceMin + s.rng.Float64()*(product.UnitPriceMax-product.UnitPriceMin)
		vProd := qty * unitPrice

		vBC := round2(vProd)
		vICMSItem := round2(vBC * pICMS / 100)
		vPISItem := round2(vBC * pPIS / 100)
		vCOFINSItem := round2(vBC * pCOFINS / 100)

		det, err := nfe.NewDetRegimeNormalCST00(
			&schema.Prod{
				CProd:    product.Code,
				CEAN:     "SEM GTIN",
				XProd:    product.Name,
				NCM:      product.NCM,
				CFOP:     cfop,
				UCom:     product.Unit,
				QCom:     fmt.Sprintf("%.4f", qty),
				VUnCom:   fmt.Sprintf("%.10f", unitPrice),
				VProd:    fmt.Sprintf("%.2f", vBC),
				CEANTrib: "SEM GTIN",
				UTrib:    product.Unit,
				QTrib:    fmt.Sprintf("%.4f", qty),
				VUnTrib:  fmt.Sprintf("%.10f", unitPrice),
				IndTot:   "1",
			},
			fmt.Sprintf("%.2f", vBC),
			fmt.Sprintf("%.2f", pICMS),
			fmt.Sprintf("%.2f", pPIS),
			fmt.Sprintf("%.2f", pCOFINS),
		)
		if err != nil {
			// programming error — facade rejects malformed input.
			// Fail loudly because tests using the seeder rely on every
			// generate succeeding.
			panic(fmt.Sprintf("seeder: facade rejected item %d: %v", i, err))
		}
		dets = append(dets, det)

		sumVBC += vBC
		sumVICMS += vICMSItem
		sumVPIS += vPISItem
		sumVCOFINS += vCOFINSItem
	}

	total := &schema.Total{
		ICMSTot: &schema.ICMSTot{
			VBC:        fmt.Sprintf("%.2f", sumVBC),
			VICMS:      fmt.Sprintf("%.2f", sumVICMS),
			VICMSDeson: "0.00",
			VFCP:       "0.00",
			VBCST:      "0.00",
			VST:        "0.00",
			VFCPST:     "0.00",
			VFCPSTRet:  "0.00",
			VProd:      fmt.Sprintf("%.2f", sumVBC),
			VPIS:       fmt.Sprintf("%.2f", sumVPIS),
			VCOFINS:    fmt.Sprintf("%.2f", sumVCOFINS),
			VNF:        fmt.Sprintf("%.2f", sumVBC),
		},
	}
	return dets, total
}

func pickCFOP(rng *rand.Rand, interstate bool) string {
	candidates := make([]cfopEntry, 0, len(cfops))
	for _, c := range cfops {
		if c.IsInterstate == interstate {
			candidates = append(candidates, c)
		}
	}
	return candidates[rng.Intn(len(candidates))].Code
}

func round2(v float64) float64 {
	// Half-up rounding to two decimals. SEFAZ uses arithmetic rounding
	// for fiscal totals; the *big.Rat-backed math in domain/nfe/calculo.go
	// is exact, but the seeder is producing presentation-layer totals
	// where 2-decimal precision is enough to match the validator's 0.01
	// tolerance.
	return float64(int64(v*100+0.5)) / 100
}

func stringPtr(s string) *string { return &s }
