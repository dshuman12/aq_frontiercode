package seeder

// Reference data embedded at compile time. The lists are deliberately
// short — what matters is that every entry is a real value pulled
// from a public source, so the seeded data passes "looks plausible"
// inspection by anyone familiar with Brazilian fiscal docs.
//
// Sources:
//
//   - NCMs: Tabela TIPI 2022 (public, Receita Federal)
//   - CFOPs: Convênio S/Nº 70, anexo II
//   - Municipalities: IBGE códigos de município (top BR cities)
//
// To extend the catalog, append entries here — no other file needs
// to change.

// City pairs an IBGE 7-digit municipality code with its name and UF.
// IBGE codes encode the UF in the first two digits.
type City struct {
	IBGECode string
	Name     string
	UF       string
}

// brazilianCities holds a small but representative list spanning the
// major regions. Adding more is safe and free — the seeder only ever
// reads from the slice.
var brazilianCities = []City{
	{IBGECode: "3550308", Name: "SAO PAULO", UF: "SP"},
	{IBGECode: "3304557", Name: "RIO DE JANEIRO", UF: "RJ"},
	{IBGECode: "3106200", Name: "BELO HORIZONTE", UF: "MG"},
	{IBGECode: "4314902", Name: "PORTO ALEGRE", UF: "RS"},
	{IBGECode: "4106902", Name: "CURITIBA", UF: "PR"},
	{IBGECode: "4205407", Name: "FLORIANOPOLIS", UF: "SC"},
	{IBGECode: "5300108", Name: "BRASILIA", UF: "DF"},
	{IBGECode: "2927408", Name: "SALVADOR", UF: "BA"},
	{IBGECode: "2304400", Name: "FORTALEZA", UF: "CE"},
	{IBGECode: "2611606", Name: "RECIFE", UF: "PE"},
	{IBGECode: "5208707", Name: "GOIANIA", UF: "GO"},
	{IBGECode: "1302603", Name: "MANAUS", UF: "AM"},
}

// CFOP code paired with a short purpose tag. The seeder picks an
// appropriate code based on whether the operation is interna (same
// UF on emitter + recipient) or interestadual.
type cfopEntry struct {
	Code         string
	Purpose      string // human-readable label, used only for logging/debugging
	IsInterstate bool   // true = interestadual (6xxx), false = interna (5xxx)
}

var cfops = []cfopEntry{
	{Code: "5102", Purpose: "venda de mercadoria adquirida", IsInterstate: false},
	{Code: "5101", Purpose: "venda de producao do estabelecimento", IsInterstate: false},
	{Code: "5405", Purpose: "venda de mercadoria com substituicao tributaria", IsInterstate: false},
	{Code: "6102", Purpose: "venda de mercadoria adquirida (interestadual)", IsInterstate: true},
	{Code: "6101", Purpose: "venda de producao do estabelecimento (interestadual)", IsInterstate: true},
}

// Product is a row in the seeded product catalog. NCM is the canonical
// 8-digit Tarifa Externa Comum code; UnitPriceMin/Max bound the random
// price so generated NF-es have plausible amounts.
type Product struct {
	Code          string // cProd
	Name          string // xProd
	NCM           string
	Unit          string // uCom (UN, KG, M2, ...)
	UnitPriceMin  float64
	UnitPriceMax  float64
}

// productCatalog covers a small spread of NCMs across food, hardware,
// and services. Each entry maps to a real NCM from the TIPI table.
var productCatalog = []Product{
	{Code: "AGUA-500", Name: "AGUA MINERAL SEM GAS 500ML", NCM: "22011000", Unit: "UN", UnitPriceMin: 2.50, UnitPriceMax: 5.00},
	{Code: "REFR-COLA", Name: "REFRIGERANTE COLA 350ML", NCM: "22021000", Unit: "UN", UnitPriceMin: 4.00, UnitPriceMax: 7.50},
	{Code: "CAFE-500G", Name: "CAFE TORRADO MOIDO 500G", NCM: "09012100", Unit: "UN", UnitPriceMin: 18.00, UnitPriceMax: 32.00},
	{Code: "ARROZ-5KG", Name: "ARROZ BRANCO TIPO 1 5KG", NCM: "10063021", Unit: "UN", UnitPriceMin: 22.00, UnitPriceMax: 38.00},
	{Code: "FEIJ-1KG", Name: "FEIJAO PRETO TIPO 1 1KG", NCM: "07133390", Unit: "UN", UnitPriceMin: 8.00, UnitPriceMax: 14.50},
	{Code: "PARAF-50", Name: "PARAFUSO SEXTAVADO 1/2 X 2", NCM: "73181500", Unit: "UN", UnitPriceMin: 0.30, UnitPriceMax: 1.20},
	{Code: "TINTA-18L", Name: "TINTA LATEX BRANCO 18L", NCM: "32099000", Unit: "UN", UnitPriceMin: 180.00, UnitPriceMax: 320.00},
	{Code: "PAPEL-A4", Name: "PAPEL SULFITE A4 75G 500F", NCM: "48025610", Unit: "UN", UnitPriceMin: 22.00, UnitPriceMax: 38.00},
	{Code: "CANE-AZL", Name: "CANETA ESFEROGRAFICA AZUL", NCM: "96081000", Unit: "UN", UnitPriceMin: 1.50, UnitPriceMax: 4.00},
	{Code: "MOUSE-USB", Name: "MOUSE OPTICO USB", NCM: "84716053", Unit: "UN", UnitPriceMin: 25.00, UnitPriceMax: 95.00},
	{Code: "TECL-USB", Name: "TECLADO ABNT2 USB", NCM: "84716052", Unit: "UN", UnitPriceMin: 60.00, UnitPriceMax: 220.00},
	{Code: "MONIT-22", Name: "MONITOR LCD 22 POLEGADAS", NCM: "85285200", Unit: "UN", UnitPriceMin: 600.00, UnitPriceMax: 1500.00},
}

// emitterNames is the pool the seeder draws from when assigning a
// company name to a generated emitter. Uses fictional but
// realistic-looking razões sociais.
var emitterNames = []string{
	"COMERCIAL UNIAO LTDA",
	"INDUSTRIA E COMERCIO BANDEIRANTES SA",
	"DISTRIBUIDORA SUL ATACADO LTDA",
	"NORTE EXPRESSO LOGISTICA LTDA",
	"ATACADO CENTRO OESTE EIRELI",
	"VAREJO MERIDIONAL COMERCIO LTDA",
	"CONSUMO DIRETO ATACADISTA SA",
	"COMERCIAL ATLANTICO LTDA",
}

// recipientNames covers both juridical (LTDA / EIRELI / SA) and
// natural-person-shaped names. The seeder picks a juridical name when
// the destinatário gets a CNPJ and a natural name when it gets a CPF.
var recipientNamesCNPJ = []string{
	"REVENDEDOR PADRAO LTDA",
	"COMERCIO REGIONAL EIRELI",
	"ALIMENTOS DO INTERIOR LTDA",
	"COOPERATIVA AGRICOLA LITORAL LTDA",
	"DISTRIBUIDORA NORDESTE COMERCIO SA",
}

var recipientNamesCPF = []string{
	"JOSE DA SILVA",
	"MARIA OLIVEIRA",
	"PEDRO SANTOS",
	"ANA SOUZA",
	"CARLOS PEREIRA",
	"FERNANDA LIMA",
}

var streetNames = []string{
	"AV BRASIL",
	"AV PAULISTA",
	"R DAS FLORES",
	"AV ATLANTICA",
	"R DOS ANDRADAS",
	"AV INDEPENDENCIA",
	"R XV DE NOVEMBRO",
	"AV GETULIO VARGAS",
}

var neighborhoods = []string{
	"CENTRO",
	"VILA NOVA",
	"JARDIM AMERICA",
	"BELA VISTA",
	"INDUSTRIAL",
	"BOA VISTA",
}
