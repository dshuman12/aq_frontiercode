package seeder_test

import (
	"context"
	"math/rand"
	"strings"
	"testing"
	"time"

	"github.com/sefarius/billing-service/application"
	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
	"github.com/sefarius/billing-service/infrastructure/seeder"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

// ---------- document generators ----------

func TestGenerateCNPJ_AlwaysValid(t *testing.T) {
	rng := rand.New(rand.NewSource(42))
	for i := 0; i < 1000; i++ {
		c := seeder.GenerateCNPJ(rng)
		if !seeder.ValidateCNPJ(c) {
			t.Fatalf("iteration %d: GenerateCNPJ produced invalid %q", i, c)
		}
		if len(c) != 14 {
			t.Errorf("CNPJ length = %d, want 14: %q", len(c), c)
		}
	}
}

func TestGenerateCPF_AlwaysValid(t *testing.T) {
	rng := rand.New(rand.NewSource(42))
	for i := 0; i < 1000; i++ {
		c := seeder.GenerateCPF(rng)
		if !seeder.ValidateCPF(c) {
			t.Fatalf("iteration %d: GenerateCPF produced invalid %q", i, c)
		}
	}
}

// TestValidateCNPJ_KnownGoodAndBad anchors the validator against
// hand-verified vectors so a future change to the DV math doesn't
// silently accept malformed CNPJs.
//
// Note on the 00000000000000 quirk: mod-11 with all-zero input
// produces zero check digits, so by structural math the all-zeros
// CNPJ passes validation. Rejecting it would be an application-level
// concern (no real CNPJ is registered as 00000000000000 in the
// cadastro), not a structural one. Kept out of both vector lists so
// the test asserts exactly what the validator promises.
func TestValidateCNPJ_KnownGoodAndBad(t *testing.T) {
	goodCNPJs := []string{
		"05730928000145", // emitter CNPJ canonical across the project — Receita-verified
	}
	malformedCNPJs := []string{
		"05730928000146", // wrong DV2
		"05730928000144", // wrong DV1
		"123",            // too short
		"abcdefghijklmn", // non-digits
	}

	for _, c := range goodCNPJs {
		if !seeder.ValidateCNPJ(c) {
			t.Errorf("known-good CNPJ %q rejected by ValidateCNPJ", c)
		}
	}
	for _, c := range malformedCNPJs {
		if seeder.ValidateCNPJ(c) {
			t.Errorf("malformed CNPJ %q accepted by ValidateCNPJ", c)
		}
	}
}

// TestSeeder_DeterministicForFixedSeed locks in the reproducibility
// contract: identical Options yield identical output. Without this
// the integration test below would flake on the chave assertions.
func TestSeeder_DeterministicForFixedSeed(t *testing.T) {
	mk := func() *seeder.Seeder {
		return seeder.New(seeder.Options{
			Rng:        rand.New(rand.NewSource(7)),
			InitialNNF: 1,
			StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
		})
	}
	a, err := mk().GenerateBatch(5)
	if err != nil {
		t.Fatalf("first batch: %v", err)
	}
	b, err := mk().GenerateBatch(5)
	if err != nil {
		t.Fatalf("second batch: %v", err)
	}
	if len(a) != len(b) {
		t.Fatalf("batches differ in length: %d vs %d", len(a), len(b))
	}
	for i := range a {
		if a[i].InfNFe.IdAttr != b[i].InfNFe.IdAttr {
			t.Errorf("element %d Id differs across runs: %s vs %s",
				i, a[i].InfNFe.IdAttr, b[i].InfNFe.IdAttr)
		}
	}
}

// TestSeeder_GeneratedNFePassesValidators is the contract that
// integration tests rely on: every Generate output must be acceptable
// to ValidateSemantic + ValidateTotalsAgainstItems with no further
// adjustment.
func TestSeeder_GeneratedNFePassesValidators(t *testing.T) {
	s := seeder.New(seeder.Options{Rng: rand.New(rand.NewSource(1))})
	for i := 0; i < 20; i++ {
		tnfe, err := s.Generate()
		if err != nil {
			t.Fatalf("iteration %d: Generate: %v", i, err)
		}
		if issues := nfe.ValidateSemantic(tnfe); len(issues) > 0 {
			for _, is := range issues {
				t.Logf("semantic issue [%d]: %s", i, is)
			}
			t.Errorf("iteration %d: ValidateSemantic returned %d issues", i, len(issues))
		}
		if issues := nfe.ValidateTotalsAgainstItems(tnfe); len(issues) > 0 {
			for _, is := range issues {
				t.Logf("totals issue [%d]: %s", i, is)
			}
			t.Errorf("iteration %d: ValidateTotalsAgainstItems returned %d issues", i, len(issues))
		}
	}
}

// TestSeeder_GeneratesUniqueChavesAcrossBatch — the chave is composed
// of nNF + cNF + emitter CNPJ + AAMM. Same emitter + same month means
// the differentiator must be nNF (monotonic). If the seeder ever reused
// nNF, two NF-es would collide on chave and the upsert in repo would
// silently drop one.
func TestSeeder_GeneratesUniqueChavesAcrossBatch(t *testing.T) {
	s := seeder.New(seeder.Options{Rng: rand.New(rand.NewSource(13))})
	const n = 50
	batch, err := s.GenerateBatch(n)
	if err != nil {
		t.Fatalf("GenerateBatch: %v", err)
	}
	seen := make(map[string]int, n)
	for i, tnfe := range batch {
		id := tnfe.InfNFe.IdAttr
		if prior, ok := seen[id]; ok {
			t.Errorf("chave collision: index %d and %d share Id %s", prior, i, id)
		}
		seen[id] = i
	}
}

// TestSeeder_HasFixedEmitter — one Seeder represents one merchant
// emitting many NF-es. Verifying the emitter CNPJ + UF stay constant
// across the batch protects the "daily emissions of one company" demo
// shape we want for the AfterQuery reviewer.
func TestSeeder_HasFixedEmitter(t *testing.T) {
	s := seeder.New(seeder.Options{Rng: rand.New(rand.NewSource(2))})
	batch, err := s.GenerateBatch(10)
	if err != nil {
		t.Fatalf("GenerateBatch: %v", err)
	}
	firstCNPJ := *batch[0].InfNFe.Emit.CNPJ
	firstUF := batch[0].InfNFe.Emit.EnderEmit.UF
	for i, tnfe := range batch[1:] {
		if cnpj := *tnfe.InfNFe.Emit.CNPJ; cnpj != firstCNPJ {
			t.Errorf("element %d: emitter CNPJ drifted (%s -> %s)", i+1, firstCNPJ, cnpj)
		}
		if uf := tnfe.InfNFe.Emit.EnderEmit.UF; uf != firstUF {
			t.Errorf("element %d: emitter UF drifted (%s -> %s)", i+1, firstUF, uf)
		}
	}
}

// ---------- end-to-end integration ----------

// TestSeeder_50NFesThroughFullPipeline is the headline of sprint 1.9:
// 50 generated NF-es flow through validate -> sign -> authorize ->
// persist with no manual intervention. Without this, the seeder is
// just unverified data — this proves it produces fiscal documents
// the production pipeline accepts.
func TestSeeder_50NFesThroughFullPipeline(t *testing.T) {
	s := seeder.New(seeder.Options{
		Rng:        rand.New(rand.NewSource(99)),
		InitialNNF: 1,
		StartTime:  time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
	})
	cert, err := nfe.GenerateSelfSignedTest("seeder-pipeline-test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	mock := sefaz.NewMockClient()
	repo := infrastructure.NewInMemoryNFeRepository()
	uc := application.NewEmitNFeUseCase(cert, mock, repo)

	const target = 50
	batch, err := s.GenerateBatch(target)
	if err != nil {
		t.Fatalf("GenerateBatch: %v", err)
	}

	authorized := 0
	for i, tnfe := range batch {
		out, err := uc.Emit(context.Background(), application.EmitInput{NFe: tnfe})
		if err != nil {
			t.Fatalf("emit element %d: %v", i, err)
		}
		if out.Status != nfe.AuthorizationStatusAuthorized {
			t.Errorf("element %d Status = %s, want AUTHORIZED", i, out.Status)
		}
		authorized++
	}

	if authorized != target {
		t.Errorf("authorized=%d, want %d", authorized, target)
	}

	stored, err := repo.List(context.Background(), 0, 0)
	if err != nil {
		t.Fatalf("repo.List: %v", err)
	}
	if len(stored) != target {
		t.Errorf("repo holds %d records, want %d", len(stored), target)
	}
	for _, rec := range stored {
		if rec.Status != nfe.NFeStatusAuthorized {
			t.Errorf("stored record %s status = %s, want AUTHORIZED", rec.Chave, rec.Status)
		}
		if !strings.HasPrefix(string(rec.Chave), "") || len(rec.Chave) != 44 {
			t.Errorf("stored chave %q is not 44 digits", rec.Chave)
		}
		if rec.Protocol == nil {
			t.Errorf("stored record %s has nil protocol", rec.Chave)
		}
	}

	if mock.CallCount() != int64(target) {
		t.Errorf("mock.CallCount = %d, want %d", mock.CallCount(), target)
	}
}
