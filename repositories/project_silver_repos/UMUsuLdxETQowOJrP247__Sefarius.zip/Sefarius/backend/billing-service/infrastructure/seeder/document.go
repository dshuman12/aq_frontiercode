// Package seeder generates realistic-looking Brazilian fiscal data for
// demos, local development, and integration tests.
//
// The data the seeder produces is *structurally* valid — CNPJs and
// CPFs carry correct mod-11 check digits, NCMs come from the real
// TIPI table, CFOPs from the real Convênio S/Nº 70 annex II, and
// IBGE municipality codes are real numbers from the embedded list.
// Nothing here is real-world identifying: the CNPJ/CPF generator
// runs over random base digits, so collisions with actual taxpayers
// are statistically possible but legally unlinkable.
//
// Not for production: this package is *intentionally* not in the
// domain layer. Real fiscal flows must come from real data sources
// (cadastro, ERP, EDI), never from a randomized seeder.
package seeder

import (
	"fmt"
	"math/rand"
	"strings"
)

// GenerateCNPJ returns a 14-digit CNPJ string with valid first and
// second mod-11 check digits, using the supplied random source.
//
// CNPJ DV math (Receita Federal IN RFB 1863/2018, anexo I):
//
//	first12 = random root + branch ("0001")
//	dv1 = mod11(first12, weights1)
//	dv2 = mod11(first12+dv1, weights2)
//
// The first 12 digits we generate use a real-looking base (8 random
// digits + "0001" branch suffix) so the result reads as a plausible
// matriz CNPJ instead of a totally random string.
func GenerateCNPJ(r *rand.Rand) string {
	digits := make([]int, 14)
	for i := 0; i < 8; i++ {
		digits[i] = r.Intn(10)
	}
	digits[8], digits[9], digits[10], digits[11] = 0, 0, 0, 1 // matriz branch
	digits[12] = cnpjCheckDigit(digits[:12], cnpjWeights1)
	digits[13] = cnpjCheckDigit(digits[:13], cnpjWeights2)
	return digitsToString(digits)
}

// GenerateCPF returns an 11-digit CPF string with valid mod-11 check
// digits. Used for B2C destinatário scenarios where the recipient is
// a natural person.
func GenerateCPF(r *rand.Rand) string {
	digits := make([]int, 11)
	for i := 0; i < 9; i++ {
		digits[i] = r.Intn(10)
	}
	digits[9] = cpfCheckDigit(digits[:9], cpfWeights1)
	digits[10] = cpfCheckDigit(digits[:10], cpfWeights2)
	return digitsToString(digits)
}

// ValidateCNPJ returns true when s is exactly 14 digits and both
// check digits match. The seeder uses it in tests to lock in the
// generator's contract; callers in production should keep validating
// against the real cadastro instead of trusting structural validity.
func ValidateCNPJ(s string) bool {
	if len(s) != 14 {
		return false
	}
	digits := make([]int, 14)
	for i, c := range s {
		if c < '0' || c > '9' {
			return false
		}
		digits[i] = int(c - '0')
	}
	if digits[12] != cnpjCheckDigit(digits[:12], cnpjWeights1) {
		return false
	}
	if digits[13] != cnpjCheckDigit(digits[:13], cnpjWeights2) {
		return false
	}
	return true
}

// ValidateCPF mirrors ValidateCNPJ for 11-digit CPF strings.
func ValidateCPF(s string) bool {
	if len(s) != 11 {
		return false
	}
	digits := make([]int, 11)
	for i, c := range s {
		if c < '0' || c > '9' {
			return false
		}
		digits[i] = int(c - '0')
	}
	if digits[9] != cpfCheckDigit(digits[:9], cpfWeights1) {
		return false
	}
	if digits[10] != cpfCheckDigit(digits[:10], cpfWeights2) {
		return false
	}
	return true
}

// GenerateIE returns a 10-digit "Inscrição Estadual"-shaped string.
// Real IE math is per-UF and complex (each state has its own
// algorithm — IN-Receita anexo XVII has 27 different formulas). For
// the seeder we generate a syntactically plausible 10-digit number;
// the SEFAZ mock does not validate IE, and the real wire validation
// belongs to a dedicated UF-specific module that doesn't exist yet.
func GenerateIE(r *rand.Rand) string {
	var b strings.Builder
	b.Grow(10)
	for i := 0; i < 10; i++ {
		fmt.Fprintf(&b, "%d", r.Intn(10))
	}
	return b.String()
}

// cnpjWeights1 / cnpjWeights2 are the multiplier sequences for the
// first and second CNPJ check digits, per Receita Federal IN 1863.
var (
	cnpjWeights1 = []int{5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2}
	cnpjWeights2 = []int{6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2}
	cpfWeights1  = []int{10, 9, 8, 7, 6, 5, 4, 3, 2}
	cpfWeights2  = []int{11, 10, 9, 8, 7, 6, 5, 4, 3, 2}
)

// cnpjCheckDigit and cpfCheckDigit share the same mod-11 rule:
// remainder < 2 -> 0, otherwise 11 - remainder. The factoring keeps
// each generator's math one-line and obviously parallel.
func cnpjCheckDigit(digits []int, weights []int) int { return mod11(digits, weights) }
func cpfCheckDigit(digits []int, weights []int) int  { return mod11(digits, weights) }

func mod11(digits []int, weights []int) int {
	if len(digits) != len(weights) {
		// Programming error — weights and digits must align. Panic
		// because catching this at test time is what we want.
		panic(fmt.Sprintf("seeder: mod11 length mismatch (digits=%d, weights=%d)", len(digits), len(weights)))
	}
	sum := 0
	for i, d := range digits {
		sum += d * weights[i]
	}
	rem := sum % 11
	if rem < 2 {
		return 0
	}
	return 11 - rem
}

func digitsToString(digits []int) string {
	var b strings.Builder
	b.Grow(len(digits))
	for _, d := range digits {
		b.WriteByte(byte('0' + d))
	}
	return b.String()
}
