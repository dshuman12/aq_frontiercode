package infrastructure

import (
	"context"
	"sort"
	"sync"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
)

// InMemoryNFeEventRepository implements nfe.NFeEventRepository against
// an in-process map keyed by (chave, event_type, n_seq).
//
// Like InMemoryNFeRepository it exists for two reasons: a default for
// dev / unit tests with no Postgres, and the reference implementation
// the contract test pins both repos to.
//
// Concurrency-safe via sync.Mutex. Records are deep-copied on read.
type InMemoryNFeEventRepository struct {
	mu      sync.Mutex
	records map[eventKey]*nfe.NFeEventRecord
}

type eventKey struct {
	chave     nfe.Chave
	eventType nfe.NFeEventType
	nSeq      int
}

// NewInMemoryNFeEventRepository returns an empty event repository.
func NewInMemoryNFeEventRepository() *InMemoryNFeEventRepository {
	return &InMemoryNFeEventRepository{
		records: make(map[eventKey]*nfe.NFeEventRecord),
	}
}

// Save upserts an event by composite key. OccurredAt is owned by the
// repo: stamped to time.Now().UTC() on first save and preserved across
// re-saves of the same key (matching the Postgres impl, where the
// ON CONFLICT clause omits occurred_at from the SET list).
func (r *InMemoryNFeEventRepository) Save(ctx context.Context, record *nfe.NFeEventRecord) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if record == nil {
		return nfe.ErrInvalidChaveLength
	}
	if !record.EventType.IsValid() {
		return nfe.ErrInvalidChaveLength
	}
	if record.NSeq < 1 {
		return nfe.ErrCCeSeqOutOfOrder
	}
	if record.Chave == "" {
		return nfe.ErrInvalidChaveLength
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	k := eventKey{record.Chave, record.EventType, record.NSeq}
	stored := cloneEventRecord(record)
	if existing, ok := r.records[k]; ok {
		stored.OccurredAt = existing.OccurredAt
	} else if stored.OccurredAt.IsZero() {
		stored.OccurredAt = time.Now().UTC()
	}
	r.records[k] = stored

	// Refresh caller's timestamp so subsequent reads of the same struct
	// match what was persisted.
	record.OccurredAt = stored.OccurredAt
	return nil
}

// GetByKey returns ErrNFeEventNotFound when no record exists.
func (r *InMemoryNFeEventRepository) GetByKey(ctx context.Context, chave nfe.Chave, eventType nfe.NFeEventType, nSeq int) (*nfe.NFeEventRecord, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	rec, ok := r.records[eventKey{chave, eventType, nSeq}]
	if !ok {
		return nil, nfe.ErrNFeEventNotFound
	}
	return cloneEventRecord(rec), nil
}

// ListByChave returns events for a chave ordered by OccurredAt ASC.
// Empty chave returns an empty slice (not an error) so callers can
// treat "no events yet" the same way they treat "no events at all".
func (r *InMemoryNFeEventRepository) ListByChave(ctx context.Context, chave nfe.Chave) ([]*nfe.NFeEventRecord, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	out := make([]*nfe.NFeEventRecord, 0)
	for k, rec := range r.records {
		if k.chave == chave {
			out = append(out, cloneEventRecord(rec))
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].OccurredAt.Before(out[j].OccurredAt)
	})
	return out, nil
}

// MaxSeqByChaveType returns the highest n_seq stored for the given
// (chave, event_type). Returns 0 when no rows exist.
func (r *InMemoryNFeEventRepository) MaxSeqByChaveType(ctx context.Context, chave nfe.Chave, eventType nfe.NFeEventType) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	max := 0
	for k := range r.records {
		if k.chave == chave && k.eventType == eventType && k.nSeq > max {
			max = k.nSeq
		}
	}
	return max, nil
}

// cloneEventRecord deep-copies a record so the store and the caller
// never share mutable state. Slices and pointer fields get their own
// allocations; primitives copy implicitly.
func cloneEventRecord(src *nfe.NFeEventRecord) *nfe.NFeEventRecord {
	if src == nil {
		return nil
	}
	dst := *src
	if src.SignedXML != nil {
		dst.SignedXML = append([]byte(nil), src.SignedXML...)
	}
	if src.ResponseXML != nil {
		dst.ResponseXML = append([]byte(nil), src.ResponseXML...)
	}
	return &dst
}

// Compile-time guarantee InMemoryNFeEventRepository satisfies the contract.
var _ nfe.NFeEventRepository = (*InMemoryNFeEventRepository)(nil)
