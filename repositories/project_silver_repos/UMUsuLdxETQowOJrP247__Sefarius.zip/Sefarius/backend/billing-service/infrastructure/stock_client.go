package infrastructure

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/sefarius/billing-service/domain"
)

// HTTPStockServiceClient implements the StockServiceClient interface
type HTTPStockServiceClient struct {
	baseURL string
	client  *http.Client
}

// NewHTTPStockServiceClient creates a new HTTP stock service client
func NewHTTPStockServiceClient(baseURL string) *HTTPStockServiceClient {
	return &HTTPStockServiceClient{
		baseURL: baseURL,
		client: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

// ReserveStock reserves stock from the stock service
func (c *HTTPStockServiceClient) ReserveStock(ctx context.Context, productID string, quantity int) (bool, error) {
	url := fmt.Sprintf("%s/api/stock/products/%s/reserve", c.baseURL, productID)

	payload := map[string]int{"quantity": quantity}
	bodyBytes, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return false, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return false, fmt.Errorf("failed to call stock service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return false, fmt.Errorf("stock service returned status %d: %s", resp.StatusCode, string(body))
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return false, fmt.Errorf("failed to parse response: %w", err)
	}

	// Check if reservation was successful
	if data, ok := result["data"].(map[string]interface{}); ok {
		if success, ok := data["success"].(bool); ok {
			return success, nil
		}
	}

	return false, nil
}

// ReleaseStock releases reserved stock from the stock service
func (c *HTTPStockServiceClient) ReleaseStock(ctx context.Context, productID string, quantity int) error {
	// In a real implementation, this would call the stock service to release reserved stock
	// For now, this is a no-op since we use transactions
	return nil
}

// DecrementStock subtracts `quantity` from the product's persisted
// balance. Called by invoice creation so the dashboard's "Estoque
// Total" reflects sales as soon as the invoice is created (the
// previous code only called ReserveStock, which checks but does not
// subtract — the dashboard kept showing pre-sale balances).
func (c *HTTPStockServiceClient) DecrementStock(ctx context.Context, productID string, quantity int) error {
	url := fmt.Sprintf("%s/api/stock/products/%s/decrement", c.baseURL, productID)

	payload := map[string]int{"quantity": quantity}
	bodyBytes, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to call stock service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("stock service returned status %d: %s", resp.StatusCode, string(body))
	}
	return nil
}

// GetProduct retrieves product information from the stock service
func (c *HTTPStockServiceClient) GetProduct(ctx context.Context, productID string) (interface{}, error) {
	url := fmt.Sprintf("%s/api/stock/products/%s", c.baseURL, productID)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call stock service: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("stock service returned status %d", resp.StatusCode)
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return result, nil
}

// Ensure HTTPStockServiceClient implements StockServiceClient
var _ domain.StockServiceClient = (*HTTPStockServiceClient)(nil)
