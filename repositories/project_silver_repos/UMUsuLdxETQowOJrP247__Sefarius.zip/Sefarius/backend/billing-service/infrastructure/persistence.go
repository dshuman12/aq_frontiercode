package infrastructure

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	_ "github.com/lib/pq"
	"github.com/sefarius/billing-service/domain"
)

// PostgresInvoiceRepository implements the InvoiceRepository interface
type PostgresInvoiceRepository struct {
	db *sql.DB
}

// NewPostgresInvoiceRepository creates a new PostgreSQL invoice repository
func NewPostgresInvoiceRepository(db *sql.DB) *PostgresInvoiceRepository {
	return &PostgresInvoiceRepository{db: db}
}

// Create inserts a new invoice with its items
func (r *PostgresInvoiceRepository) Create(ctx context.Context, invoice *domain.Invoice) error {
	// Start transaction
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{
		Isolation: sql.LevelSerializable,
	})
	if err != nil {
		return fmt.Errorf("failed to begin transaction: %w", err)
	}
	defer tx.Rollback()

	// Insert invoice
	query := `
		INSERT INTO billing.invoices (id, status, idempotency_key, created_by, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`

	_, err = tx.ExecContext(ctx, query,
		invoice.ID,
		string(invoice.Status),
		invoice.IdempotencyKey,
		invoice.CreatedBy,
		invoice.CreatedAt,
	)
	if err != nil {
		return fmt.Errorf("failed to insert invoice: %w", err)
	}

	// Insert invoice items
	itemQuery := `
		INSERT INTO billing.invoice_items (id, invoice_id, product_id, quantity, unit_price, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
	`

	for _, item := range invoice.Items {
		_, err := tx.ExecContext(ctx, itemQuery,
			item.ID,
			item.InvoiceID,
			item.ProductID,
			item.Quantity,
			item.UnitPrice,
			item.CreatedAt,
		)
		if err != nil {
			return fmt.Errorf("failed to insert invoice item: %w", err)
		}
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("failed to commit transaction: %w", err)
	}

	return nil
}

// GetByID retrieves an invoice by ID with all items
func (r *PostgresInvoiceRepository) GetByID(ctx context.Context, id string) (*domain.Invoice, error) {
	query := `
		SELECT id, number, status, idempotency_key, created_by, created_at, closed_at
		FROM billing.invoices
		WHERE id = $1 AND deleted_at IS NULL
	`

	invoice := &domain.Invoice{}
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&invoice.ID,
		&invoice.Number,
		(*string)(&invoice.Status),
		&invoice.IdempotencyKey,
		&invoice.CreatedBy,
		&invoice.CreatedAt,
		&invoice.ClosedAt,
	)

	if err == sql.ErrNoRows {
		return nil, errors.New("invoice not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get invoice: %w", err)
	}

	// Load items
	items, err := r.GetItems(ctx, id)
	if err != nil {
		return nil, err
	}
	invoice.Items = items

	return invoice, nil
}

// GetByNumber retrieves an invoice by number
func (r *PostgresInvoiceRepository) GetByNumber(ctx context.Context, number int64) (*domain.Invoice, error) {
	query := `
		SELECT id, number, status, idempotency_key, created_by, created_at, closed_at
		FROM billing.invoices
		WHERE number = $1 AND deleted_at IS NULL
	`

	invoice := &domain.Invoice{}
	err := r.db.QueryRowContext(ctx, query, number).Scan(
		&invoice.ID,
		&invoice.Number,
		(*string)(&invoice.Status),
		&invoice.IdempotencyKey,
		&invoice.CreatedBy,
		&invoice.CreatedAt,
		&invoice.ClosedAt,
	)

	if err == sql.ErrNoRows {
		return nil, errors.New("invoice not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get invoice: %w", err)
	}

	// Load items
	items, err := r.GetItems(ctx, invoice.ID)
	if err != nil {
		return nil, err
	}
	invoice.Items = items

	return invoice, nil
}

// Count returns the number of non-deleted invoices. Used by the
// paginated list endpoint to populate Total — without it the frontend
// can't render numerical pagination indicators.
func (r *PostgresInvoiceRepository) Count(ctx context.Context) (int, error) {
	var n int
	err := r.db.QueryRowContext(ctx, `SELECT count(*) FROM billing.invoices WHERE deleted_at IS NULL`).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("failed to count invoices: %w", err)
	}
	return n, nil
}

// GetAll retrieves all invoices with pagination
func (r *PostgresInvoiceRepository) GetAll(ctx context.Context, limit, offset int) ([]*domain.Invoice, error) {
	query := `
		SELECT id, number, status, idempotency_key, created_by, created_at, closed_at
		FROM billing.invoices
		WHERE deleted_at IS NULL
		ORDER BY created_at DESC
		LIMIT $1 OFFSET $2
	`

	rows, err := r.db.QueryContext(ctx, query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to query invoices: %w", err)
	}
	defer rows.Close()

	var invoices []*domain.Invoice
	for rows.Next() {
		invoice := &domain.Invoice{}
		err := rows.Scan(
			&invoice.ID,
			&invoice.Number,
			(*string)(&invoice.Status),
			&invoice.IdempotencyKey,
			&invoice.CreatedBy,
			&invoice.CreatedAt,
			&invoice.ClosedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan invoice: %w", err)
		}

		// Load items for each invoice
		items, err := r.GetItems(ctx, invoice.ID)
		if err != nil {
			return nil, err
		}
		invoice.Items = items

		invoices = append(invoices, invoice)
	}

	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating invoices: %w", err)
	}

	return invoices, nil
}

// Update updates an invoice
func (r *PostgresInvoiceRepository) Update(ctx context.Context, invoice *domain.Invoice) error {
	query := `
		UPDATE billing.invoices
		SET status = $1, closed_at = $2
		WHERE id = $3 AND deleted_at IS NULL
	`

	result, err := r.db.ExecContext(ctx, query,
		string(invoice.Status),
		invoice.ClosedAt,
		invoice.ID,
	)
	if err != nil {
		return fmt.Errorf("failed to update invoice: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to check update result: %w", err)
	}

	if rows == 0 {
		return errors.New("invoice not found")
	}

	return nil
}

// Delete performs a soft delete on an invoice
func (r *PostgresInvoiceRepository) Delete(ctx context.Context, id string) error {
	query := `
		UPDATE billing.invoices
		SET deleted_at = $1
		WHERE id = $2 AND deleted_at IS NULL
	`

	result, err := r.db.ExecContext(ctx, query, time.Now(), id)
	if err != nil {
		return fmt.Errorf("failed to delete invoice: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to check delete result: %w", err)
	}

	if rows == 0 {
		return errors.New("invoice not found")
	}

	return nil
}

// GetByIDForUpdate retrieves an invoice with a pessimistic lock
func (r *PostgresInvoiceRepository) GetByIDForUpdate(ctx context.Context, id string) (*domain.Invoice, error) {
	query := `
		SELECT id, number, status, idempotency_key, created_by, created_at, closed_at
		FROM billing.invoices
		WHERE id = $1 AND deleted_at IS NULL
		FOR UPDATE
	`

	invoice := &domain.Invoice{}
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&invoice.ID,
		&invoice.Number,
		(*string)(&invoice.Status),
		&invoice.IdempotencyKey,
		&invoice.CreatedBy,
		&invoice.CreatedAt,
		&invoice.ClosedAt,
	)

	if err == sql.ErrNoRows {
		return nil, errors.New("invoice not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get invoice for update: %w", err)
	}

	// Load items
	items, err := r.GetItems(ctx, id)
	if err != nil {
		return nil, err
	}
	invoice.Items = items

	return invoice, nil
}

// AddItem adds an item to an invoice
func (r *PostgresInvoiceRepository) AddItem(ctx context.Context, item *domain.InvoiceItem) error {
	query := `
		INSERT INTO billing.invoice_items (id, invoice_id, product_id, quantity, unit_price, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
	`

	_, err := r.db.ExecContext(ctx, query,
		item.ID,
		item.InvoiceID,
		item.ProductID,
		item.Quantity,
		item.UnitPrice,
		item.CreatedAt,
	)

	if err != nil {
		return fmt.Errorf("failed to add invoice item: %w", err)
	}

	return nil
}

// GetItems retrieves all items of an invoice
func (r *PostgresInvoiceRepository) GetItems(ctx context.Context, invoiceID string) ([]*domain.InvoiceItem, error) {
	query := `
		SELECT id, invoice_id, product_id, quantity, unit_price, created_at
		FROM billing.invoice_items
		WHERE invoice_id = $1
		ORDER BY created_at ASC
	`

	rows, err := r.db.QueryContext(ctx, query, invoiceID)
	if err != nil {
		return nil, fmt.Errorf("failed to query invoice items: %w", err)
	}
	defer rows.Close()

	var items []*domain.InvoiceItem
	for rows.Next() {
		item := &domain.InvoiceItem{}
		err := rows.Scan(
			&item.ID,
			&item.InvoiceID,
			&item.ProductID,
			&item.Quantity,
			&item.UnitPrice,
			&item.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan invoice item: %w", err)
		}
		items = append(items, item)
	}

	return items, rows.Err()
}

// ============================================================================
// Idempotency Repository Implementation
// ============================================================================

// PostgresIdempotencyRepository implements IdempotencyRepository
type PostgresIdempotencyRepository struct {
	db *sql.DB
}

// NewPostgresIdempotencyRepository creates a new idempotency repository
func NewPostgresIdempotencyRepository(db *sql.DB) *PostgresIdempotencyRepository {
	return &PostgresIdempotencyRepository{db: db}
}

// Check checks if a request has already been processed
func (r *PostgresIdempotencyRepository) Check(ctx context.Context, key string) (interface{}, bool, error) {
	query := `
		SELECT response_code, response
		FROM shared.idempotency_log
		WHERE idempotency_key = $1 AND expires_at > NOW()
	`

	var responseCode int
	var responseJSON []byte

	err := r.db.QueryRowContext(ctx, query, key).Scan(&responseCode, &responseJSON)
	if err == sql.ErrNoRows {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, fmt.Errorf("failed to check idempotency: %w", err)
	}

	var response interface{}
	if err := json.Unmarshal(responseJSON, &response); err != nil {
		return nil, false, fmt.Errorf("failed to unmarshal cached response: %w", err)
	}

	return response, true, nil
}

// Store stores the response of a processed request
func (r *PostgresIdempotencyRepository) Store(ctx context.Context, key string, responseCode int, response interface{}) error {
	responseJSON, err := json.Marshal(response)
	if err != nil {
		return fmt.Errorf("failed to marshal response: %w", err)
	}

	requestHash := key // In production, calculate actual hash

	query := `
		INSERT INTO shared.idempotency_log (idempotency_key, service, operation, request_hash, response_code, response)
		VALUES ($1, $2, $3, $4, $5, $6)
		ON CONFLICT (idempotency_key) DO NOTHING
	`

	_, err = r.db.ExecContext(ctx, query,
		key,
		"billing-service",
		"create_invoice",
		requestHash,
		responseCode,
		string(responseJSON),
	)

	if err != nil {
		return fmt.Errorf("failed to store idempotency log: %w", err)
	}

	return nil
}

// Delete removes an idempotency log entry
func (r *PostgresIdempotencyRepository) Delete(ctx context.Context, key string) error {
	query := `DELETE FROM shared.idempotency_log WHERE idempotency_key = $1`

	_, err := r.db.ExecContext(ctx, query, key)
	return err
}
