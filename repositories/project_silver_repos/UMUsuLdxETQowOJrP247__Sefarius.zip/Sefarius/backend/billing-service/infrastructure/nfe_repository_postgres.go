package infrastructure

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"

	_ "github.com/lib/pq"

	"github.com/sefarius/billing-service/domain/nfe"
)

// PostgresNFeRepository persists NF-e records in billing.nfe_records.
// See migration 004_nfe_records.sql for the schema.
//
// The repo follows the same upsert + timestamp contract as
// InMemoryNFeRepository: Save preserves CreatedAt across re-emissions
// (the database default fires only on INSERT) and always advances
// UpdatedAt to NOW(). The contract test suite in
// nfe_repository_contract_test.go runs identical assertions against
// both implementations; if you change one, run the other.
type PostgresNFeRepository struct {
	db *sql.DB
}

// NewPostgresNFeRepository wires the repo to an opened *sql.DB. The
// caller owns the pool — Close happens at process shutdown in main.go.
func NewPostgresNFeRepository(db *sql.DB) *PostgresNFeRepository {
	return &PostgresNFeRepository{db: db}
}

// Save upserts by chave. CreatedAt is owned by the database (DEFAULT
// CURRENT_TIMESTAMP on INSERT, preserved on conflict). UpdatedAt is
// always set to NOW() so the caller cannot smuggle a stale value in.
//
// Both timestamps are returned to the caller via record so subsequent
// reads of the same struct match what was persisted — this matches the
// behavior the InMemory contract test asserts.
func (r *PostgresNFeRepository) Save(ctx context.Context, record *nfe.NFeRecord) error {
	if record == nil || record.Chave == "" {
		return nfe.ErrInvalidChaveLength
	}

	protocolJSON, err := marshalProtocol(record.Protocol)
	if err != nil {
		return fmt.Errorf("nfe.Save: marshal protocol: %w", err)
	}
	rejectionJSON, err := marshalRejection(record.Rejection)
	if err != nil {
		return fmt.Errorf("nfe.Save: marshal rejection: %w", err)
	}

	const query = `
		INSERT INTO billing.nfe_records
			(chave, status, signed_xml, protocol, rejection, cstat, xmotivo, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
		ON CONFLICT (chave) DO UPDATE SET
			status     = EXCLUDED.status,
			signed_xml = EXCLUDED.signed_xml,
			protocol   = EXCLUDED.protocol,
			rejection  = EXCLUDED.rejection,
			cstat      = EXCLUDED.cstat,
			xmotivo    = EXCLUDED.xmotivo,
			updated_at = NOW()
		RETURNING created_at, updated_at
	`

	err = r.db.QueryRowContext(ctx, query,
		string(record.Chave),
		string(record.Status),
		record.SignedXML,
		protocolJSON,
		rejectionJSON,
		record.CStat,
		record.XMotivo,
	).Scan(&record.CreatedAt, &record.UpdatedAt)
	if err != nil {
		return fmt.Errorf("nfe.Save: %w", err)
	}
	return nil
}

// GetByChave returns nfe.ErrNFeNotFound when the chave has no record.
func (r *PostgresNFeRepository) GetByChave(ctx context.Context, chave nfe.Chave) (*nfe.NFeRecord, error) {
	const query = `
		SELECT chave, status, signed_xml, protocol, rejection, cstat, xmotivo, created_at, updated_at
		FROM billing.nfe_records
		WHERE chave = $1
	`
	row := r.db.QueryRowContext(ctx, query, string(chave))
	rec, err := scanNFeRecord(row)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nfe.ErrNFeNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("nfe.GetByChave: %w", err)
	}
	return rec, nil
}

// Count returns the number of records in billing.nfe_records.
// Pairs with List to expose accurate Total in paginated HTTP responses.
func (r *PostgresNFeRepository) Count(ctx context.Context) (int, error) {
	var n int
	err := r.db.QueryRowContext(ctx, `SELECT count(*) FROM billing.nfe_records`).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("nfe.Count: %w", err)
	}
	return n, nil
}

// List returns records ordered by CreatedAt DESC (most recent first).
// limit<=0 means "no cap"; offset<0 is treated as 0.
func (r *PostgresNFeRepository) List(ctx context.Context, limit, offset int) ([]*nfe.NFeRecord, error) {
	if offset < 0 {
		offset = 0
	}

	// Postgres LIMIT does not accept negative integers; the literal
	// keyword ALL is the only way to say "no cap". Two query strings
	// avoid string-building from an int parameter.
	const baseSelect = `
		SELECT chave, status, signed_xml, protocol, rejection, cstat, xmotivo, created_at, updated_at
		FROM billing.nfe_records
		ORDER BY created_at DESC
	`
	var (
		rows *sql.Rows
		err  error
	)
	if limit <= 0 {
		rows, err = r.db.QueryContext(ctx, baseSelect+`LIMIT ALL OFFSET $1`, offset)
	} else {
		rows, err = r.db.QueryContext(ctx, baseSelect+`LIMIT $1 OFFSET $2`, limit, offset)
	}
	if err != nil {
		return nil, fmt.Errorf("nfe.List: %w", err)
	}
	defer rows.Close()

	out := make([]*nfe.NFeRecord, 0)
	for rows.Next() {
		rec, err := scanNFeRecord(rows)
		if err != nil {
			return nil, fmt.Errorf("nfe.List: scan: %w", err)
		}
		out = append(out, rec)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("nfe.List: iterate: %w", err)
	}
	return out, nil
}

// rowScanner abstracts *sql.Row and *sql.Rows so scanNFeRecord can
// serve both single-row and iterating callers.
type rowScanner interface {
	Scan(dest ...any) error
}

// scanNFeRecord reads one row produced by the SELECT clause used in
// GetByChave and List. Protocol/Rejection are unmarshalled lazily —
// NULL JSONB columns become nil pointers, which is how the InMemory
// repo represents "no protocol / no rejection".
func scanNFeRecord(row rowScanner) (*nfe.NFeRecord, error) {
	var (
		chave         string
		status        string
		signedXML     []byte
		protocolBytes []byte
		rejectionBytes []byte
		cstat         sql.NullString
		xmotivo       sql.NullString
		rec           = &nfe.NFeRecord{}
	)
	if err := row.Scan(
		&chave, &status, &signedXML,
		&protocolBytes, &rejectionBytes,
		&cstat, &xmotivo,
		&rec.CreatedAt, &rec.UpdatedAt,
	); err != nil {
		return nil, err
	}

	rec.Chave = nfe.Chave(chave)
	rec.Status = nfe.NFeStatus(status)
	rec.SignedXML = signedXML
	if cstat.Valid {
		rec.CStat = cstat.String
	}
	if xmotivo.Valid {
		rec.XMotivo = xmotivo.String
	}
	if len(protocolBytes) > 0 {
		var p nfe.Protocol
		if err := json.Unmarshal(protocolBytes, &p); err != nil {
			return nil, fmt.Errorf("decode protocol jsonb: %w", err)
		}
		rec.Protocol = &p
	}
	if len(rejectionBytes) > 0 {
		var rj nfe.Rejection
		if err := json.Unmarshal(rejectionBytes, &rj); err != nil {
			return nil, fmt.Errorf("decode rejection jsonb: %w", err)
		}
		rec.Rejection = &rj
	}
	return rec, nil
}

// marshalProtocol returns nil (driver-encoded as SQL NULL) when the
// protocol pointer is nil; otherwise its JSON form encoded as a string.
//
// Why string and not []byte: lib/pq sends []byte as Postgres bytea, and
// the bytea-to-jsonb cast fails ("invalid input syntax for type json").
// Passing a string makes the driver use the text protocol, which
// Postgres parses straight into jsonb. This keeps nil ↔ SQL NULL
// symmetric so GetByChave round-trips cleanly.
func marshalProtocol(p *nfe.Protocol) (any, error) {
	if p == nil {
		return nil, nil
	}
	b, err := json.Marshal(p)
	if err != nil {
		return nil, err
	}
	return string(b), nil
}

func marshalRejection(r *nfe.Rejection) (any, error) {
	if r == nil {
		return nil, nil
	}
	b, err := json.Marshal(r)
	if err != nil {
		return nil, err
	}
	return string(b), nil
}

// Compile-time guarantee.
var _ nfe.NFeRepository = (*PostgresNFeRepository)(nil)
