package infrastructure_test

import (
	"context"
	"database/sql"
	"errors"
	"os"
	"sync"
	"testing"
	"time"

	_ "github.com/lib/pq"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
)

// Distinct chaves from the NFe repo contract test (chaveA/chaveB) so
// the two test suites can coexist in the same external test package
// without TRUNCATE order coupling.
const (
	eventChaveA = nfe.Chave("43260505730928000145550010000001005123456787")
	eventChaveB = nfe.Chave("35260505730928000145550010000001006123456789")
)

type eventRepoFactory func(t *testing.T) nfe.NFeEventRepository

// eventImplementations returns the impls under contract test. The
// Postgres branch requires both nfe_records and nfe_events tables —
// the FK on nfe_events.chave forces parent inserts before any event.
// Skipped when TEST_DATABASE_URL is unset.
func eventImplementations(t *testing.T) []struct {
	name    string
	factory eventRepoFactory
} {
	t.Helper()
	out := []struct {
		name    string
		factory eventRepoFactory
	}{
		{
			name: "InMemory",
			factory: func(t *testing.T) nfe.NFeEventRepository {
				return infrastructure.NewInMemoryNFeEventRepository()
			},
		},
	}
	if dsn := os.Getenv("TEST_DATABASE_URL"); dsn != "" {
		out = append(out, struct {
			name    string
			factory eventRepoFactory
		}{
			name: "Postgres",
			factory: func(t *testing.T) nfe.NFeEventRepository {
				db, err := sql.Open("postgres", dsn)
				if err != nil {
					t.Fatalf("open postgres: %v", err)
				}
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()
				if err := db.PingContext(ctx); err != nil {
					t.Fatalf("ping postgres: %v", err)
				}
				// Order matters: nfe_events FK references nfe_records,
				// so events go first when truncating.
				if _, err := db.ExecContext(ctx, "TRUNCATE billing.nfe_events, billing.nfe_records CASCADE"); err != nil {
					t.Fatalf("truncate billing.nfe_events/nfe_records: %v", err)
				}
				// Insert parent NFe rows so the FK is satisfied. Real
				// content does not matter for these contract tests —
				// we are exercising the events table, not nfe_records.
				for _, ch := range []nfe.Chave{eventChaveA, eventChaveB} {
					_, err := db.ExecContext(ctx, `
						INSERT INTO billing.nfe_records (chave, status, signed_xml, cstat, xmotivo)
						VALUES ($1, 'AUTHORIZED', $2, '100', 'Autorizado')
					`, string(ch), []byte("<NFe>fixture</NFe>"))
					if err != nil {
						t.Fatalf("insert parent nfe_record %s: %v", ch, err)
					}
				}
				t.Cleanup(func() {
					_, _ = db.Exec("TRUNCATE billing.nfe_events, billing.nfe_records CASCADE")
					_ = db.Close()
				})
				return infrastructure.NewPostgresNFeEventRepository(db)
			},
		})
	}
	return out
}

func runEventContract(t *testing.T, name string, fn func(t *testing.T, repo nfe.NFeEventRepository)) {
	t.Helper()
	for _, impl := range eventImplementations(t) {
		impl := impl
		t.Run(impl.name+"/"+name, func(t *testing.T) {
			fn(t, impl.factory(t))
		})
	}
}

func sampleCancelEvent(chave nfe.Chave) *nfe.NFeEventRecord {
	return &nfe.NFeEventRecord{
		Chave:       chave,
		EventType:   nfe.NFeEventTypeCancel,
		NSeq:        1,
		NProt:       "141260000000001",
		Status:      nfe.EventStatusAccepted,
		CStat:       "135",
		XMotivo:     "Evento registrado e vinculado a NFe",
		SignedXML:   []byte("<evento>cancel</evento>"),
		ResponseXML: []byte("<procEventoNFe>cancel</procEventoNFe>"),
	}
}

func sampleCCeEvent(chave nfe.Chave, seq int) *nfe.NFeEventRecord {
	return &nfe.NFeEventRecord{
		Chave:       chave,
		EventType:   nfe.NFeEventTypeCCe,
		NSeq:        seq,
		NProt:       "141260000000099",
		Status:      nfe.EventStatusAccepted,
		CStat:       "135",
		XMotivo:     "Evento registrado e vinculado a NFe",
		SignedXML:   []byte("<evento>cce</evento>"),
		ResponseXML: []byte("<procEventoNFe>cce</procEventoNFe>"),
	}
}

func TestNFeEventRepoContract_SaveThenGet(t *testing.T) {
	runEventContract(t, "save_then_get", func(t *testing.T, repo nfe.NFeEventRepository) {
		rec := sampleCancelEvent(eventChaveA)
		if err := repo.Save(context.Background(), rec); err != nil {
			t.Fatalf("Save: %v", err)
		}
		if rec.OccurredAt.IsZero() {
			t.Error("Save must stamp OccurredAt on the input record")
		}

		got, err := repo.GetByKey(context.Background(), eventChaveA, nfe.NFeEventTypeCancel, 1)
		if err != nil {
			t.Fatalf("GetByKey: %v", err)
		}
		if got.Chave != eventChaveA || got.EventType != nfe.NFeEventTypeCancel || got.NSeq != 1 {
			t.Errorf("composite key round-trip mismatch: %+v", got)
		}
		if got.NProt != "141260000000001" || got.Status != nfe.EventStatusAccepted {
			t.Errorf("payload round-trip: NProt=%q Status=%q", got.NProt, got.Status)
		}
		if string(got.SignedXML) != "<evento>cancel</evento>" {
			t.Errorf("SignedXML round-trip: %q", got.SignedXML)
		}
		if string(got.ResponseXML) != "<procEventoNFe>cancel</procEventoNFe>" {
			t.Errorf("ResponseXML round-trip: %q", got.ResponseXML)
		}
	})
}

func TestNFeEventRepoContract_GetUnknown(t *testing.T) {
	runEventContract(t, "get_unknown", func(t *testing.T, repo nfe.NFeEventRepository) {
		_, err := repo.GetByKey(context.Background(), eventChaveA, nfe.NFeEventTypeCancel, 1)
		if !errors.Is(err, nfe.ErrNFeEventNotFound) {
			t.Errorf("err = %v, want ErrNFeEventNotFound", err)
		}
	})
}

// TestNFeEventRepoContract_SaveIsUpsert is the recovery-semantics
// contract: re-saving the same composite key updates payload but
// preserves OccurredAt. Future cancel re-submissions or audit-replay
// need this property — without it, the audit trail loses the original
// submission timestamp.
func TestNFeEventRepoContract_SaveIsUpsert(t *testing.T) {
	runEventContract(t, "save_is_upsert", func(t *testing.T, repo nfe.NFeEventRepository) {
		first := sampleCancelEvent(eventChaveA)
		if err := repo.Save(context.Background(), first); err != nil {
			t.Fatalf("first Save: %v", err)
		}
		originalOccurred := first.OccurredAt

		time.Sleep(10 * time.Millisecond)

		second := sampleCancelEvent(eventChaveA)
		second.NProt = "999999999999999" // payload change
		if err := repo.Save(context.Background(), second); err != nil {
			t.Fatalf("second Save: %v", err)
		}

		got, err := repo.GetByKey(context.Background(), eventChaveA, nfe.NFeEventTypeCancel, 1)
		if err != nil {
			t.Fatalf("GetByKey: %v", err)
		}
		if got.NProt != "999999999999999" {
			t.Errorf("NProt not updated by upsert: %s", got.NProt)
		}
		if !got.OccurredAt.Equal(originalOccurred) {
			t.Errorf("OccurredAt changed across upsert: %v -> %v", originalOccurred, got.OccurredAt)
		}
	})
}

func TestNFeEventRepoContract_ListByChave(t *testing.T) {
	runEventContract(t, "list_by_chave", func(t *testing.T, repo nfe.NFeEventRepository) {
		// Cancel + 2 CCes for chave A; one CCe for chave B.
		if err := repo.Save(context.Background(), sampleCancelEvent(eventChaveA)); err != nil {
			t.Fatalf("Save cancel A: %v", err)
		}
		time.Sleep(5 * time.Millisecond)
		if err := repo.Save(context.Background(), sampleCCeEvent(eventChaveA, 1)); err != nil {
			t.Fatalf("Save cce A.1: %v", err)
		}
		time.Sleep(5 * time.Millisecond)
		if err := repo.Save(context.Background(), sampleCCeEvent(eventChaveA, 2)); err != nil {
			t.Fatalf("Save cce A.2: %v", err)
		}
		time.Sleep(5 * time.Millisecond)
		if err := repo.Save(context.Background(), sampleCCeEvent(eventChaveB, 1)); err != nil {
			t.Fatalf("Save cce B.1: %v", err)
		}

		listA, err := repo.ListByChave(context.Background(), eventChaveA)
		if err != nil {
			t.Fatalf("ListByChave A: %v", err)
		}
		if len(listA) != 3 {
			t.Fatalf("ListByChave A returned %d, want 3", len(listA))
		}
		// Chronological ASC: cancel first, then cce 1, then cce 2.
		if listA[0].EventType != nfe.NFeEventTypeCancel || listA[1].NSeq != 1 || listA[2].NSeq != 2 {
			t.Errorf("ListByChave A wrong order: %+v", listA)
		}

		listB, err := repo.ListByChave(context.Background(), eventChaveB)
		if err != nil {
			t.Fatalf("ListByChave B: %v", err)
		}
		if len(listB) != 1 || listB[0].Chave != eventChaveB {
			t.Errorf("ListByChave B isolation broken: %+v", listB)
		}
	})
}

func TestNFeEventRepoContract_MaxSeqByChaveType(t *testing.T) {
	runEventContract(t, "max_seq", func(t *testing.T, repo nfe.NFeEventRepository) {
		// Empty case → 0 (callers add 1 to get next seq = 1).
		max, err := repo.MaxSeqByChaveType(context.Background(), eventChaveA, nfe.NFeEventTypeCCe)
		if err != nil {
			t.Fatalf("MaxSeqByChaveType empty: %v", err)
		}
		if max != 0 {
			t.Errorf("empty MaxSeq = %d, want 0", max)
		}

		// Save 3 CCes out of order; max should be the largest.
		for _, seq := range []int{2, 1, 3} {
			if err := repo.Save(context.Background(), sampleCCeEvent(eventChaveA, seq)); err != nil {
				t.Fatalf("Save cce seq=%d: %v", seq, err)
			}
		}
		max, err = repo.MaxSeqByChaveType(context.Background(), eventChaveA, nfe.NFeEventTypeCCe)
		if err != nil {
			t.Fatalf("MaxSeqByChaveType: %v", err)
		}
		if max != 3 {
			t.Errorf("MaxSeq = %d, want 3", max)
		}

		// Different event_type (CANCEL) does not pollute the CCe count.
		if err := repo.Save(context.Background(), sampleCancelEvent(eventChaveA)); err != nil {
			t.Fatalf("Save cancel: %v", err)
		}
		max, err = repo.MaxSeqByChaveType(context.Background(), eventChaveA, nfe.NFeEventTypeCCe)
		if err != nil {
			t.Fatalf("MaxSeqByChaveType after cancel: %v", err)
		}
		if max != 3 {
			t.Errorf("CANCEL polluted CCe MaxSeq: got %d, want 3", max)
		}
	})
}

// TestNFeEventRepoContract_ConcurrentSaves runs racing saves on
// distinct seqs of the same chave/type. PK uniqueness must be honored
// — each seq survives as its own row.
func TestNFeEventRepoContract_ConcurrentSaves(t *testing.T) {
	runEventContract(t, "concurrent_saves", func(t *testing.T, repo nfe.NFeEventRepository) {
		var wg sync.WaitGroup
		const n = 20
		for i := 1; i <= n; i++ {
			i := i
			wg.Add(1)
			go func() {
				defer wg.Done()
				_ = repo.Save(context.Background(), sampleCCeEvent(eventChaveA, i))
			}()
		}
		wg.Wait()

		list, err := repo.ListByChave(context.Background(), eventChaveA)
		if err != nil {
			t.Fatalf("ListByChave: %v", err)
		}
		if len(list) != n {
			t.Errorf("expected %d distinct rows, got %d", n, len(list))
		}
	})
}

func TestNFeEventRepoContract_RespectsContextCancellation(t *testing.T) {
	runEventContract(t, "ctx_cancel", func(t *testing.T, repo nfe.NFeEventRepository) {
		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		if err := repo.Save(ctx, sampleCancelEvent(eventChaveA)); !errors.Is(err, context.Canceled) {
			t.Errorf("Save: err = %v, want context.Canceled in chain", err)
		}
		if _, err := repo.GetByKey(ctx, eventChaveA, nfe.NFeEventTypeCancel, 1); !errors.Is(err, context.Canceled) {
			t.Errorf("GetByKey: err = %v, want context.Canceled in chain", err)
		}
		if _, err := repo.ListByChave(ctx, eventChaveA); !errors.Is(err, context.Canceled) {
			t.Errorf("ListByChave: err = %v, want context.Canceled in chain", err)
		}
		if _, err := repo.MaxSeqByChaveType(ctx, eventChaveA, nfe.NFeEventTypeCCe); !errors.Is(err, context.Canceled) {
			t.Errorf("MaxSeqByChaveType: err = %v, want context.Canceled in chain", err)
		}
	})
}

// TestNFeEventRepoContract_RejectionRoundTrip covers the path where
// status=REJECTED and NProt is empty. Both impls must round-trip the
// empty NProt as the empty string (driver semantics: SQL NULL ↔ "").
func TestNFeEventRepoContract_RejectionRoundTrip(t *testing.T) {
	runEventContract(t, "rejection_round_trip", func(t *testing.T, repo nfe.NFeEventRepository) {
		rec := &nfe.NFeEventRecord{
			Chave:     eventChaveA,
			EventType: nfe.NFeEventTypeCancel,
			NSeq:      1,
			Status:    nfe.EventStatusRejected,
			CStat:     "218",
			XMotivo:   "NFe ja cancelada",
			SignedXML: []byte("<evento>cancel</evento>"),
			// NProt empty (no protocol on rejection)
			// ResponseXML can be empty for SERVICE_UNAVAILABLE or
			// non-empty (the retEvento with the rejection) for REJECTED;
			// here we test the empty branch.
		}
		if err := repo.Save(context.Background(), rec); err != nil {
			t.Fatalf("Save rejected: %v", err)
		}
		got, err := repo.GetByKey(context.Background(), eventChaveA, nfe.NFeEventTypeCancel, 1)
		if err != nil {
			t.Fatalf("GetByKey: %v", err)
		}
		if got.Status != nfe.EventStatusRejected {
			t.Errorf("Status round-trip: %s", got.Status)
		}
		if got.NProt != "" {
			t.Errorf("NProt should be empty for rejection, got %q", got.NProt)
		}
		if got.CStat != "218" {
			t.Errorf("CStat round-trip: %s", got.CStat)
		}
	})
}
