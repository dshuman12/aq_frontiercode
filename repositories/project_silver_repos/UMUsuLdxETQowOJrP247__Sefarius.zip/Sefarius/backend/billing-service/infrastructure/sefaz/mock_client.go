// Package sefaz hosts SEFAZ NFeAutorizacao4 client implementations.
//
// MockClient simulates authorization without touching a real UF endpoint —
// it is the default in dev/test, and is the implementation exercised by
// the application-layer use cases under unit tests. RealClient (sprint
// future) speaks SOAP against the production webservice.
//
// Both implementations satisfy nfe.SefazClient so callers can swap them
// at composition time without touching application code.
package sefaz

import (
	"context"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
)

// MockClient is an in-memory SEFAZ stand-in.
//
// Default behavior: every Authorize call returns AUTHORIZED with a
// deterministic protocol receipt computed from the chave + a monotonic
// per-instance counter. Cancel and SendCCe likewise default to
// ACCEPTED with cStat 135. Calls are tracked so tests can assert
// invocation counts without a recording mock library.
//
// Tests force alternative outcomes for authorization via:
//
//   - QueueOutcome(r):     pushes r onto a FIFO; the next Authorize
//     consumes the head instead of computing the default success.
//   - RejectChavePrefix:   any chave starting with the prefix is
//     rejected with the configured rejection.
//   - FailWithError(err):  Authorize returns err on every call until
//     cleared with FailWithError(nil) — simulates ErrSefazUnreachable.
//
// Sprint 2.1 added the parallel knobs for events, with one twist:
// Cancel and SendCCe share the same FIFO queue and reject prefix.
// Tests rarely care to distinguish; a separate FIFO would create
// silent ordering bugs when a test mixes the two paths.
//
//   - QueueEventOutcome(r):       FIFO across Cancel + SendCCe.
//   - RejectEventChavePrefix:     any signed event whose chave starts
//     with the prefix is rejected with the configured EventRejection.
//   - FailEventWithError(err):    both event methods return err until
//     cleared.
//   - ForcePrazoExpirado():       convenience for the cancel-specific
//     "prazo de cancelamento expirado" path (cStat 218). Cancel calls
//     return this rejection until cleared with ForcePrazoExpirado()
//     called again with no effect (idempotent set/clear via sentinel).
//
// MockClient is safe for concurrent use. Protocols echo the tpAmb
// found in the submitted infNFe (or "2" / homologation when the input
// is malformed); the mock used to hard-code "2" but that masked a
// production-vs-homologation display bug — operators selecting tpAmb=1
// in the UI saw "Ambiente: Homologação" because the persisted protocol
// disagreed with the submitted XML. Echoing what was sent keeps the
// mock honest while still being a mock.
type MockClient struct {
	mu           sync.Mutex // guards nextOutcomes, rejectPrefix, rejectWith, failWith, event-* twins
	calls        atomic.Int64
	protocolSeq  atomic.Int64
	eventSeq     atomic.Int64
	nextOutcomes []*nfe.AuthorizationResult
	rejectPrefix string
	rejectWith   *nfe.Rejection
	failWith     error
	authorized   sync.Map // chave -> *nfe.Protocol; written once per chave

	// event-side knobs (sprint 2.1)
	nextEventOutcomes []*nfe.EventResult
	eventRejectPrefix string
	eventRejectWith   *nfe.EventRejection
	eventFailWith     error
	prazoExpirado     bool // toggled by ForcePrazoExpirado; affects Cancel only
}

// defaultMockTpAmb is the fallback environment code used when the
// submitted XML lacks a parseable <tpAmb> element. Production XML
// always has one; this fallback only triggers on malformed input.
const defaultMockTpAmb = "2"

// NewMockClient returns a MockClient with the default
// authorize-everything behavior. Configure rejections or failures via
// QueueOutcome / RejectChavePrefix / FailWithError.
func NewMockClient() *MockClient {
	return &MockClient{}
}

// QueueOutcome appends an outcome to the FIFO queue. The next call to
// Authorize consumes the head of the queue instead of computing the
// default success protocol. Used in tests to drive specific scenarios
// (e.g., "first call rejected, second call authorized").
func (m *MockClient) QueueOutcome(result *nfe.AuthorizationResult) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.nextOutcomes = append(m.nextOutcomes, result)
}

// RejectChavePrefix configures the mock to reject any signed NF-e whose
// chave starts with the given prefix. Pass "" to disable. The rejection
// fields populate Result.Rejection.
func (m *MockClient) RejectChavePrefix(prefix string, rej *nfe.Rejection) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.rejectPrefix = prefix
	m.rejectWith = rej
}

// FailWithError configures the mock to return err on every Authorize
// call. Pass nil to clear. Intended for ErrSefazUnreachable tests.
func (m *MockClient) FailWithError(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.failWith = err
}

// CallCount returns the number of Authorize invocations since the mock
// was created. Useful for asserting retry behavior.
func (m *MockClient) CallCount() int64 {
	return m.calls.Load()
}

// Authorize implements nfe.SefazClient. The signedXML is parsed enough
// to extract the chave (from the infNFe Id attribute); the digest in
// the protocol is computed from the signedXML bytes so replays of the
// same XML produce identical protocol contents — this matches the
// idempotent behavior real SEFAZ exhibits via the duplicate-detection
// path (cStat 539).
func (m *MockClient) Authorize(ctx context.Context, signedXML []byte) (*nfe.AuthorizationResult, error) {
	m.calls.Add(1)

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	m.mu.Lock()
	failWith := m.failWith
	rejectPrefix := m.rejectPrefix
	rejectWith := m.rejectWith
	var queued *nfe.AuthorizationResult
	if len(m.nextOutcomes) > 0 {
		queued = m.nextOutcomes[0]
		m.nextOutcomes = m.nextOutcomes[1:]
	}
	m.mu.Unlock()

	if failWith != nil {
		return nil, failWith
	}
	if queued != nil {
		return queued, nil
	}

	chNFe, err := extractChave(signedXML)
	if err != nil {
		return &nfe.AuthorizationResult{
			Status:  nfe.AuthorizationStatusRejected,
			CStat:   "225",
			XMotivo: "Falha no Schema XML",
			Rejection: &nfe.Rejection{
				CStat:   "225",
				XMotivo: fmt.Sprintf("mock: %v", err),
			},
		}, nil
	}

	if rejectPrefix != "" && rejectWith != nil && strings.HasPrefix(chNFe, rejectPrefix) {
		return &nfe.AuthorizationResult{
			Status:    nfe.AuthorizationStatusRejected,
			CStat:     rejectWith.CStat,
			XMotivo:   rejectWith.XMotivo,
			Rejection: rejectWith,
		}, nil
	}

	// Duplicate detection — same chave already authorized returns the
	// prior protocol with cStat 539, matching real SEFAZ semantics.
	if cached, ok := m.authorized.Load(chNFe); ok {
		prior := cached.(*nfe.Protocol)
		return &nfe.AuthorizationResult{
			Status:   nfe.AuthorizationStatusDuplicate,
			CStat:    "539",
			XMotivo:  "Rejeicao: Duplicidade de NF-e",
			Protocol: prior,
		}, nil
	}

	proto := &nfe.Protocol{
		NProt:    fmt.Sprintf("%015d", 100000000000000+m.protocolSeq.Add(1)),
		DhRecbto: time.Now().UTC().Truncate(time.Second),
		ChNFe:    chNFe,
		DigVal:   computeDigVal(signedXML),
		CStat:    "100",
		XMotivo:  "Autorizado o uso da NF-e",
		TpAmb:    extractTpAmb(signedXML),
	}
	m.authorized.Store(chNFe, proto)

	return &nfe.AuthorizationResult{
		Status:   nfe.AuthorizationStatusAuthorized,
		CStat:    "100",
		XMotivo:  "Autorizado o uso da NF-e",
		Protocol: proto,
	}, nil
}

// extractTpAmb finds the first <tpAmb>X</tpAmb> element in the XML
// and returns the contents. Used by the mock to echo the submitted
// environment back in the protocol it returns, so a producer that
// signs an NF-e (or event) with tpAmb=1 sees tpAmb=1 in the receipt
// rather than the previous always-"2" hard-code. Falls back to
// defaultMockTpAmb when the element is missing or malformed — strict
// XSD validation lives upstream, the mock should not double-validate.
func extractTpAmb(xmlBytes []byte) string {
	const open = "<tpAmb>"
	const close = "</tpAmb>"
	s := string(xmlBytes)
	i := strings.Index(s, open)
	if i < 0 {
		return defaultMockTpAmb
	}
	start := i + len(open)
	end := strings.Index(s[start:], close)
	if end < 0 {
		return defaultMockTpAmb
	}
	v := strings.TrimSpace(s[start : start+end])
	if v != "1" && v != "2" {
		return defaultMockTpAmb
	}
	return v
}

// extractChave pulls the 44-digit chave out of the infNFe Id attribute
// without parsing the full XML. The Id attribute is always
// `Id="NFe<chave>"` and is short enough to find via a substring scan,
// avoiding the etree dependency in this layer.
func extractChave(xml []byte) (string, error) {
	const marker = `Id="NFe`
	s := string(xml)
	i := strings.Index(s, marker)
	if i < 0 {
		return "", fmt.Errorf("infNFe Id attribute not found")
	}
	start := i + len(marker)
	end := start + 44
	if end > len(s) {
		return "", fmt.Errorf("infNFe Id attribute truncated")
	}
	chave := s[start:end]
	if len(chave) != 44 {
		return "", fmt.Errorf("infNFe Id attribute is not 44 digits: %q", chave)
	}
	return chave, nil
}

// computeDigVal returns a stand-in for SEFAZ's digVal field — the
// digest of the authorized infNFe. Real SEFAZ recomputes the digest
// over the canonicalized infNFe; the mock uses SHA-1 of the entire
// signed XML, sufficient to demonstrate that the protocol is bound to
// a specific submission. Length and base64 encoding match the wire
// shape so DANFE printing code (sprint 1.7) sees a realistic value.
func computeDigVal(signedXML []byte) string {
	sum := sha1.Sum(signedXML)
	return base64.StdEncoding.EncodeToString(sum[:])
}

// ─── Event-side knob setters (sprint 2.1) ───────────────────────────────────

// QueueEventOutcome appends an outcome to the shared FIFO consumed by
// the next Cancel or SendCCe call. See MockClient godoc for why the
// queue is shared across both methods.
func (m *MockClient) QueueEventOutcome(result *nfe.EventResult) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.nextEventOutcomes = append(m.nextEventOutcomes, result)
}

// RejectEventChavePrefix configures the mock to reject any signed
// event whose chave starts with the given prefix. Pass "" to disable.
func (m *MockClient) RejectEventChavePrefix(prefix string, rej *nfe.EventRejection) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.eventRejectPrefix = prefix
	m.eventRejectWith = rej
}

// FailEventWithError configures both Cancel and SendCCe to return err.
// Pass nil to clear. Intended for ErrSefazUnreachable tests.
func (m *MockClient) FailEventWithError(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.eventFailWith = err
}

// ForcePrazoExpirado toggles the cancel-specific cStat 218 rejection.
// SendCCe is unaffected — only cancel has a prazo de 24h. Pass true to
// arm, false to clear.
func (m *MockClient) ForcePrazoExpirado(on bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.prazoExpirado = on
}

// ─── Event-side methods ─────────────────────────────────────────────────────

// Cancel implements nfe.SefazClient. The signedEventXML is parsed for
// chNFe and nSeqEvento via simple substring scans; the response wraps
// the input in a procEventoNFe envelope synthesized from the request.
func (m *MockClient) Cancel(ctx context.Context, signedEventXML []byte) (*nfe.EventResult, error) {
	return m.handleEvent(ctx, signedEventXML, true /*isCancel*/)
}

// SendCCe implements nfe.SefazClient.
func (m *MockClient) SendCCe(ctx context.Context, signedEventXML []byte) (*nfe.EventResult, error) {
	return m.handleEvent(ctx, signedEventXML, false /*isCancel*/)
}

// handleEvent is the shared logic across Cancel and SendCCe. The
// isCancel flag only matters for the prazoExpirado knob — every other
// branch (queue, reject prefix, fail-with) is symmetric.
func (m *MockClient) handleEvent(ctx context.Context, signedEventXML []byte, isCancel bool) (*nfe.EventResult, error) {
	m.calls.Add(1)
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	m.mu.Lock()
	failWith := m.eventFailWith
	rejectPrefix := m.eventRejectPrefix
	rejectWith := m.eventRejectWith
	prazoExp := m.prazoExpirado
	var queued *nfe.EventResult
	if len(m.nextEventOutcomes) > 0 {
		queued = m.nextEventOutcomes[0]
		m.nextEventOutcomes = m.nextEventOutcomes[1:]
	}
	m.mu.Unlock()

	if failWith != nil {
		return nil, failWith
	}
	if queued != nil {
		return queued, nil
	}

	chNFe, tpEvento, nSeq, err := extractEventFields(signedEventXML)
	if err != nil {
		return &nfe.EventResult{
			Status:  nfe.EventStatusRejected,
			CStat:   "225",
			XMotivo: "Falha no Schema XML",
			Rejection: &nfe.EventRejection{
				CStat:   "225",
				XMotivo: fmt.Sprintf("mock: %v", err),
			},
		}, nil
	}

	if isCancel && prazoExp {
		return &nfe.EventResult{
			Status:  nfe.EventStatusRejected,
			CStat:   "218",
			XMotivo: "NFe ja cancelada",
			Rejection: &nfe.EventRejection{
				CStat:   "218",
				XMotivo: "NFe ja cancelada",
			},
		}, nil
	}

	if rejectPrefix != "" && rejectWith != nil && strings.HasPrefix(chNFe, rejectPrefix) {
		return &nfe.EventResult{
			Status:    nfe.EventStatusRejected,
			CStat:     rejectWith.CStat,
			XMotivo:   rejectWith.XMotivo,
			Rejection: rejectWith,
		}, nil
	}

	// Default: ACCEPTED with cStat 135 ("Evento registrado e vinculado a NFe").
	nProt := fmt.Sprintf("1%014d", 100000000000+m.eventSeq.Add(1))
	dh := time.Now().UTC().Truncate(time.Second)
	proto := &nfe.EventProtocol{
		NProt:       nProt,
		DhRegEvento: dh,
		ChNFe:       chNFe,
		TpEvento:    tpEvento,
		NSeqEvento:  nSeq,
		CStat:       "135",
		XMotivo:     "Evento registrado e vinculado a NFe",
		TpAmb:       extractTpAmb(signedEventXML),
	}

	return &nfe.EventResult{
		Status:      nfe.EventStatusAccepted,
		CStat:       "135",
		XMotivo:     "Evento registrado e vinculado a NFe",
		Protocol:    proto,
		ResponseXML: synthesizeProcEvento(signedEventXML, proto),
	}, nil
}

// extractEventFields pulls chNFe, tpEvento, and nSeqEvento out of the
// signed event XML via substring scans — same approach as extractChave
// for authorize. The Id attribute alone gives us all three: format is
// "ID" + tpEvento(6) + chave(44) + nSeqEvento(2).
func extractEventFields(xml []byte) (chave, tpEvento string, nSeq int, err error) {
	const marker = `Id="ID`
	s := string(xml)
	i := strings.Index(s, marker)
	if i < 0 {
		return "", "", 0, fmt.Errorf("infEvento Id attribute not found")
	}
	start := i + len(marker)
	if start+6+44+2 > len(s) {
		return "", "", 0, fmt.Errorf("infEvento Id attribute truncated")
	}
	tpEvento = s[start : start+6]
	chave = s[start+6 : start+6+44]
	seqStr := s[start+6+44 : start+6+44+2]
	if _, err := fmt.Sscanf(seqStr, "%d", &nSeq); err != nil {
		return "", "", 0, fmt.Errorf("invalid nSeqEvento %q: %w", seqStr, err)
	}
	return chave, tpEvento, nSeq, nil
}

// synthesizeProcEvento wraps the input signed event in a
// <procEventoNFe> envelope, attaching a synthetic <retEvento> built
// from the Protocol fields. The result is byte-stable for a given
// (signedEvent, protocol) pair so tests can assert against it.
func synthesizeProcEvento(signedEvent []byte, p *nfe.EventProtocol) []byte {
	var buf strings.Builder
	buf.WriteString(`<?xml version="1.0" encoding="UTF-8"?>`)
	buf.WriteString(`<procEventoNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">`)
	buf.Write(signedEvent)
	buf.WriteString(`<retEvento versao="1.00"><infEvento Id="ID`)
	buf.WriteString(p.TpEvento)
	buf.WriteString(p.ChNFe)
	buf.WriteString(fmt.Sprintf("%02d", p.NSeqEvento))
	buf.WriteString(`"><tpAmb>`)
	buf.WriteString(p.TpAmb)
	buf.WriteString(`</tpAmb><cOrgao>`)
	if len(p.ChNFe) >= 2 {
		buf.WriteString(p.ChNFe[:2])
	}
	buf.WriteString(`</cOrgao><cStat>`)
	buf.WriteString(p.CStat)
	buf.WriteString(`</cStat><xMotivo>`)
	buf.WriteString(p.XMotivo)
	buf.WriteString(`</xMotivo><chNFe>`)
	buf.WriteString(p.ChNFe)
	buf.WriteString(`</chNFe><tpEvento>`)
	buf.WriteString(p.TpEvento)
	buf.WriteString(`</tpEvento><nSeqEvento>`)
	buf.WriteString(fmt.Sprintf("%d", p.NSeqEvento))
	buf.WriteString(`</nSeqEvento><dhRegEvento>`)
	buf.WriteString(p.DhRegEvento.Format("2006-01-02T15:04:05-07:00"))
	buf.WriteString(`</dhRegEvento><nProt>`)
	buf.WriteString(p.NProt)
	buf.WriteString(`</nProt></infEvento></retEvento></procEventoNFe>`)
	return []byte(buf.String())
}

// Compile-time guarantee MockClient implements the contract.
var _ nfe.SefazClient = (*MockClient)(nil)
