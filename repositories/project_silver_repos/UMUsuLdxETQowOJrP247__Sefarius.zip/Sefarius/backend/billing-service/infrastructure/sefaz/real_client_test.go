package sefaz_test

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

// minimalAuthorizeNFe builds a valid-enough NFe XML for routing
// extraction. Real signed XML has hundreds of fields; we only need
// what extractAuthorizeRouting reads.
func minimalAuthorizeNFe(cUF, tpAmb, chave string) []byte {
	return []byte(`<NFe xmlns="http://www.portalfiscal.inf.br/nfe">` +
		`<infNFe Id="NFe` + chave + `" versao="4.00">` +
		`<ide><cUF>` + cUF + `</cUF><tpAmb>` + tpAmb + `</tpAmb></ide>` +
		`</infNFe></NFe>`)
}

// minimalEventXML builds a signed-event-shaped XML with cOrgao + tpAmb.
func minimalEventXML(cOrgao, tpAmb, chave, tpEvento string, nSeq int) []byte {
	idAttr := "ID" + tpEvento + chave + padNSeq(nSeq)
	return []byte(`<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">` +
		`<infEvento Id="` + idAttr + `">` +
		`<cOrgao>` + cOrgao + `</cOrgao><tpAmb>` + tpAmb + `</tpAmb>` +
		`<chNFe>` + chave + `</chNFe><tpEvento>` + tpEvento + `</tpEvento>` +
		`</infEvento></evento>`)
}

func padNSeq(n int) string {
	if n < 10 {
		return "0" + string(rune('0'+n))
	}
	return string(rune('0'+n/10)) + string(rune('0'+n%10))
}

// genTestCert returns a self-signed cert for use as the mTLS client
// identity. RealClient does not verify the cert against any chain so
// any RSA cert works for contract tests.
func genTestCert(t *testing.T) *nfe.Certificate {
	t.Helper()
	c, err := nfe.GenerateSelfSignedTest("real_client test")
	if err != nil {
		t.Fatalf("GenerateSelfSignedTest: %v", err)
	}
	return c
}

// soapAutorizadoResponse builds a canned SEFAZ response for the
// "autorizado o uso" path (cStat 100).
func soapAutorizadoResponse(chave, nProt string) string {
	return `<?xml version="1.0" encoding="utf-8"?>` +
		`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">` +
		`<soap:Body>` +
		`<nfeResultMsg>` +
		`<retEnviNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">` +
		`<tpAmb>2</tpAmb><cStat>104</cStat><xMotivo>Lote processado</xMotivo>` +
		`<protNFe versao="4.00"><infProt>` +
		`<tpAmb>2</tpAmb><chNFe>` + chave + `</chNFe>` +
		`<dhRecbto>2026-05-07T10:00:00-03:00</dhRecbto>` +
		`<nProt>` + nProt + `</nProt>` +
		`<digVal>abc123==</digVal>` +
		`<cStat>100</cStat><xMotivo>Autorizado o uso da NF-e</xMotivo>` +
		`</infProt></protNFe>` +
		`</retEnviNFe>` +
		`</nfeResultMsg>` +
		`</soap:Body></soap:Envelope>`
}

func soapRejeitadoResponse(cStat, xMotivo string) string {
	return `<?xml version="1.0" encoding="utf-8"?>` +
		`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">` +
		`<soap:Body><nfeResultMsg>` +
		`<retEnviNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">` +
		`<tpAmb>2</tpAmb><cStat>104</cStat><xMotivo>Lote processado</xMotivo>` +
		`<protNFe versao="4.00"><infProt>` +
		`<tpAmb>2</tpAmb><cStat>` + cStat + `</cStat><xMotivo>` + xMotivo + `</xMotivo>` +
		`</infProt></protNFe>` +
		`</retEnviNFe>` +
		`</nfeResultMsg></soap:Body></soap:Envelope>`
}

func soapServiceParalisado() string {
	return `<?xml version="1.0" encoding="utf-8"?>` +
		`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">` +
		`<soap:Body><nfeResultMsg>` +
		`<retEnviNFe xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">` +
		`<tpAmb>2</tpAmb>` +
		`<cStat>108</cStat><xMotivo>Servico paralisado momentaneamente</xMotivo>` +
		`</retEnviNFe>` +
		`</nfeResultMsg></soap:Body></soap:Envelope>`
}

func soapEventoAceito(chave, tpEvento, nProt string, nSeq int) string {
	return `<?xml version="1.0" encoding="utf-8"?>` +
		`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">` +
		`<soap:Body><nfeResultMsg>` +
		`<retEnvEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">` +
		`<idLote>1</idLote><tpAmb>2</tpAmb><cStat>128</cStat>` +
		`<xMotivo>Lote de Evento Processado</xMotivo>` +
		`<retEvento versao="1.00"><infEvento>` +
		`<tpAmb>2</tpAmb><cOrgao>43</cOrgao>` +
		`<cStat>135</cStat><xMotivo>Evento registrado e vinculado a NF-e</xMotivo>` +
		`<chNFe>` + chave + `</chNFe>` +
		`<tpEvento>` + tpEvento + `</tpEvento>` +
		`<nSeqEvento>` + padNSeq(nSeq) + `</nSeqEvento>` +
		`<dhRegEvento>2026-05-07T10:00:00-03:00</dhRegEvento>` +
		`<nProt>` + nProt + `</nProt>` +
		`</infEvento></retEvento>` +
		`</retEnvEvento>` +
		`</nfeResultMsg></soap:Body></soap:Envelope>`
}

// fakeSEFAZ wraps an httptest.Server with a request-recording handler
// so tests can assert the request URL/headers/body alongside the
// response shape they configure.
type fakeSEFAZ struct {
	server      *httptest.Server
	respBody    string
	respStatus  int
	lastRequest *http.Request
	lastBody    string
}

func newFakeSEFAZ(t *testing.T, status int, body string) *fakeSEFAZ {
	t.Helper()
	f := &fakeSEFAZ{respBody: body, respStatus: status}
	f.server = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		f.lastRequest = r
		b, _ := io.ReadAll(r.Body)
		f.lastBody = string(b)
		w.Header().Set("Content-Type", "application/soap+xml; charset=utf-8")
		w.WriteHeader(f.respStatus)
		_, _ = w.Write([]byte(f.respBody))
	}))
	t.Cleanup(f.server.Close)
	return f
}

// buildRealClient wires a RealClient against the fake server. The
// registry is configured with cUF=43 → fake URL for both services,
// matching the cUF used in the minimal*XML helpers.
func buildRealClient(t *testing.T, fake *fakeSEFAZ) *sefaz.RealClient {
	t.Helper()
	cert := genTestCert(t)
	endpoints := map[string]sefaz.AutorizadoraEndpoints{
		"43": {
			Autorizacao: sefaz.EndpointSet{Homologacao: fake.server.URL, Producao: fake.server.URL},
			Evento:      sefaz.EndpointSet{Homologacao: fake.server.URL, Producao: fake.server.URL},
		},
	}
	registry := sefaz.NewStaticRegistry(endpoints)
	c, err := sefaz.NewRealClient(cert, registry,
		// httptest.Server's URL is plain HTTP; replacing the http.Client
		// strips the production mTLS Transport and lets us test against
		// it without provisioning a TLS cert chain for each test.
		sefaz.WithHTTPClient(fake.server.Client()),
	)
	if err != nil {
		t.Fatalf("NewRealClient: %v", err)
	}
	return c
}

// ─── NewRealClient guards ───────────────────────────────────────────────────

func TestNewRealClient_NilCert_Errors(t *testing.T) {
	_, err := sefaz.NewRealClient(nil, sefaz.NewStaticRegistry(nil))
	if err == nil {
		t.Fatal("expected error for nil cert")
	}
}

func TestNewRealClient_NilRegistry_Errors(t *testing.T) {
	cert := genTestCert(t)
	_, err := sefaz.NewRealClient(cert, nil)
	if err == nil {
		t.Fatal("expected error for nil registry")
	}
}

// ─── Authorize ──────────────────────────────────────────────────────────────

func TestAuthorize_Authorized_PopulatesProtocol(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapAutorizadoResponse(chave, "143260000000001"))
	c := buildRealClient(t, fake)

	out, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusAuthorized {
		t.Fatalf("Status = %v, want AUTHORIZED", out.Status)
	}
	if out.CStat != "100" {
		t.Errorf("CStat = %q, want 100", out.CStat)
	}
	if out.Protocol == nil {
		t.Fatal("Protocol must be non-nil for AUTHORIZED")
	}
	if out.Protocol.NProt != "143260000000001" {
		t.Errorf("NProt = %q", out.Protocol.NProt)
	}
	if out.Protocol.ChNFe != chave {
		t.Errorf("ChNFe round-trip mismatch")
	}
	if out.Protocol.DhRecbto.IsZero() {
		t.Errorf("DhRecbto should be parsed")
	}
}

func TestAuthorize_Duplicate_PopulatesProtocolWithCStat204(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapRejeitadoResponse("204", "Rejeicao: Duplicidade de NF-e"))
	c := buildRealClient(t, fake)

	out, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusDuplicate {
		t.Fatalf("Status = %v, want DUPLICATE", out.Status)
	}
	if out.CStat != "204" {
		t.Errorf("CStat = %q", out.CStat)
	}
}

func TestAuthorize_Rejected_PopulatesRejection(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapRejeitadoResponse("215", "Falha no Schema XML"))
	c := buildRealClient(t, fake)

	out, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusRejected {
		t.Fatalf("Status = %v, want REJECTED", out.Status)
	}
	if out.Rejection == nil || out.Rejection.CStat != "215" {
		t.Errorf("Rejection should carry cStat 215; got %+v", out.Rejection)
	}
	if out.Protocol != nil {
		t.Errorf("Protocol must be nil on rejection; got %+v", out.Protocol)
	}
}

func TestAuthorize_ServiceUnavailable_NoProtocolNoRejection(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapServiceParalisado())
	c := buildRealClient(t, fake)

	out, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if out.Status != nfe.AuthorizationStatusServiceUnavailable {
		t.Fatalf("Status = %v, want SERVICE_UNAVAILABLE", out.Status)
	}
	if out.Protocol != nil || out.Rejection != nil {
		t.Errorf("both Protocol and Rejection must be nil for SERVICE_UNAVAILABLE")
	}
}

func TestAuthorize_Http500_WrapsErrSefazUnreachable(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusInternalServerError, "<html>oops</html>")
	c := buildRealClient(t, fake)

	_, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave))
	if err == nil {
		t.Fatal("expected error on HTTP 500")
	}
	if !errors.Is(err, nfe.ErrSefazUnreachable) {
		t.Errorf("err must wrap ErrSefazUnreachable; got %v", err)
	}
}

func TestAuthorize_TransportError_WrapsErrSefazUnreachable(t *testing.T) {
	cert := genTestCert(t)
	registry := sefaz.NewStaticRegistry(map[string]sefaz.AutorizadoraEndpoints{
		"43": {
			Autorizacao: sefaz.EndpointSet{Homologacao: "http://127.0.0.1:1/dead", Producao: "http://127.0.0.1:1/dead"},
		},
	})
	c, err := sefaz.NewRealClient(cert, registry,
		sefaz.WithHTTPClient(&http.Client{Timeout: 500 * time.Millisecond}),
	)
	if err != nil {
		t.Fatalf("NewRealClient: %v", err)
	}

	_, err = c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", "43260512345678000181550010000000001000000001"))
	if err == nil {
		t.Fatal("expected error connecting to dead address")
	}
	if !errors.Is(err, nfe.ErrSefazUnreachable) {
		t.Errorf("err must wrap ErrSefazUnreachable; got %v", err)
	}
}

func TestAuthorize_UnknownUF_ErrUFNotConfigured(t *testing.T) {
	cert := genTestCert(t)
	registry := sefaz.NewStaticRegistry(nil) // empty
	c, err := sefaz.NewRealClient(cert, registry)
	if err != nil {
		t.Fatalf("NewRealClient: %v", err)
	}

	_, err = c.Authorize(context.Background(), minimalAuthorizeNFe("99", "2", "99260512345678000181550010000000001000000001"))
	if err == nil {
		t.Fatal("expected ErrUFNotConfigured for cUF=99")
	}
	if !errors.Is(err, sefaz.ErrUFNotConfigured) {
		t.Errorf("err must wrap ErrUFNotConfigured; got %v", err)
	}
}

func TestAuthorize_RouteByTpAmb_PicksHomologUrl(t *testing.T) {
	// Two distinct fake servers; assert tpAmb=2 routes to the homolog one.
	homol := newFakeSEFAZ(t, http.StatusOK, soapAutorizadoResponse("43260512345678000181550010000000001000000001", "1"))
	prod := newFakeSEFAZ(t, http.StatusOK, soapAutorizadoResponse("43260512345678000181550010000000001000000001", "2"))

	cert := genTestCert(t)
	registry := sefaz.NewStaticRegistry(map[string]sefaz.AutorizadoraEndpoints{
		"43": {
			Autorizacao: sefaz.EndpointSet{Homologacao: homol.server.URL, Producao: prod.server.URL},
		},
	})
	c, err := sefaz.NewRealClient(cert, registry, sefaz.WithHTTPClient(homol.server.Client()))
	if err != nil {
		t.Fatalf("NewRealClient: %v", err)
	}

	out, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", "43260512345678000181550010000000001000000001"))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if out.Protocol.NProt != "1" {
		t.Errorf("Should have hit homolog server (NProt=1); got NProt=%q (likely hit prod)", out.Protocol.NProt)
	}
	if homol.lastRequest == nil {
		t.Errorf("homolog server was not called")
	}
	if prod.lastRequest != nil {
		t.Errorf("prod server should NOT be called when tpAmb=2")
	}
}

func TestAuthorize_PostsSOAPEnvelopeWithIndSinc1(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapAutorizadoResponse(chave, "1"))
	c := buildRealClient(t, fake)

	if _, err := c.Authorize(context.Background(), minimalAuthorizeNFe("43", "2", chave)); err != nil {
		t.Fatalf("Authorize: %v", err)
	}

	if !strings.Contains(fake.lastBody, `<enviNFe versao="4.00"`) {
		t.Errorf("body must wrap NFe in <enviNFe versao=\"4.00\">; got %q", fake.lastBody)
	}
	if !strings.Contains(fake.lastBody, `<indSinc>1</indSinc>`) {
		t.Errorf("body must include <indSinc>1</indSinc>; got %q", fake.lastBody)
	}
	if !strings.Contains(fake.lastBody, `<idLote>1</idLote>`) {
		t.Errorf("body must include <idLote>1</idLote>")
	}
	if got := fake.lastRequest.Header.Get("Content-Type"); !strings.Contains(got, "soap+xml") {
		t.Errorf("Content-Type = %q, want application/soap+xml", got)
	}
}

func TestAuthorize_MissingCUF_Errors(t *testing.T) {
	cert := genTestCert(t)
	c, err := sefaz.NewRealClient(cert, sefaz.NewStaticRegistry(nil))
	if err != nil {
		t.Fatalf("NewRealClient: %v", err)
	}

	xml := []byte(`<NFe><infNFe Id="NFe43260512345678000181550010000000001000000001"><ide><tpAmb>2</tpAmb></ide></infNFe></NFe>`)
	_, err = c.Authorize(context.Background(), xml)
	if err == nil {
		t.Fatal("expected error when cUF is missing")
	}
}

// ─── Cancel + SendCCe ───────────────────────────────────────────────────────

func TestCancel_Accepted_PopulatesProtocol(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapEventoAceito(chave, "110111", "143260000000999", 1))
	c := buildRealClient(t, fake)

	out, err := c.Cancel(context.Background(), minimalEventXML("43", "2", chave, "110111", 1))
	if err != nil {
		t.Fatalf("Cancel: %v", err)
	}
	if out.Status != nfe.EventStatusAccepted {
		t.Fatalf("Status = %v, want ACCEPTED", out.Status)
	}
	if out.CStat != "135" {
		t.Errorf("CStat = %q, want 135", out.CStat)
	}
	if out.Protocol == nil {
		t.Fatal("Protocol nil on ACCEPTED")
	}
	if out.Protocol.TpEvento != "110111" {
		t.Errorf("TpEvento round-trip; got %q", out.Protocol.TpEvento)
	}
	if len(out.ResponseXML) == 0 {
		t.Errorf("ResponseXML must be populated for legal persistence")
	}
}

func TestSendCCe_RoutesToEventoEndpoint(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	fake := newFakeSEFAZ(t, http.StatusOK, soapEventoAceito(chave, "110110", "143260000000888", 2))
	c := buildRealClient(t, fake)

	out, err := c.SendCCe(context.Background(), minimalEventXML("43", "2", chave, "110110", 2))
	if err != nil {
		t.Fatalf("SendCCe: %v", err)
	}
	if out.Status != nfe.EventStatusAccepted {
		t.Errorf("Status = %v, want ACCEPTED", out.Status)
	}
	if !strings.Contains(fake.lastBody, `nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4"`) {
		t.Errorf("body must namespace under NFeRecepcaoEvento4; got %q", fake.lastBody)
	}
	if !strings.Contains(fake.lastBody, `<envEvento versao="1.00"`) {
		t.Errorf("body must wrap evento in <envEvento versao=\"1.00\">")
	}
}

func TestCancel_PrazoExpirado_RejectsWith218(t *testing.T) {
	const chave = "43260512345678000181550010000000001000000001"
	body := `<?xml version="1.0" encoding="utf-8"?>` +
		`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">` +
		`<soap:Body><nfeResultMsg>` +
		`<retEnvEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">` +
		`<idLote>1</idLote><tpAmb>2</tpAmb><cStat>128</cStat>` +
		`<xMotivo>Lote de Evento Processado</xMotivo>` +
		`<retEvento versao="1.00"><infEvento>` +
		`<tpAmb>2</tpAmb><cOrgao>43</cOrgao>` +
		`<cStat>218</cStat><xMotivo>NFe ja cancelada</xMotivo>` +
		`<chNFe>` + chave + `</chNFe><tpEvento>110111</tpEvento><nSeqEvento>01</nSeqEvento>` +
		`<dhRegEvento>2026-05-07T10:00:00-03:00</dhRegEvento>` +
		`</infEvento></retEvento>` +
		`</retEnvEvento></nfeResultMsg></soap:Body></soap:Envelope>`
	fake := newFakeSEFAZ(t, http.StatusOK, body)
	c := buildRealClient(t, fake)

	out, err := c.Cancel(context.Background(), minimalEventXML("43", "2", chave, "110111", 1))
	if err != nil {
		t.Fatalf("Cancel: %v", err)
	}
	if out.Status != nfe.EventStatusRejected {
		t.Fatalf("Status = %v, want REJECTED", out.Status)
	}
	if out.CStat != "218" {
		t.Errorf("CStat = %q, want 218", out.CStat)
	}
	if out.Rejection == nil || out.Rejection.CStat != "218" {
		t.Errorf("Rejection.CStat = %v, want 218", out.Rejection)
	}
	if out.Protocol != nil {
		t.Errorf("Protocol must be nil on rejection")
	}
}

// ─── Endpoint registry coverage ─────────────────────────────────────────────

func TestDefaultEndpoints_Covers27UFs(t *testing.T) {
	r := sefaz.NewDefaultRegistry()
	if r.UFCount() != 27 {
		t.Errorf("UFCount = %d, want 27", r.UFCount())
	}
}

func TestDefaultEndpoints_AllIBGECodesResolve(t *testing.T) {
	r := sefaz.NewDefaultRegistry()
	// All 27 IBGE 2-digit state codes.
	all := []string{
		"11", "12", "13", "14", "15", "16", "17",
		"21", "22", "23", "24", "25", "26", "27", "28", "29",
		"31", "32", "33", "35",
		"41", "42", "43",
		"50", "51", "52", "53",
	}
	for _, cUF := range all {
		t.Run("cUF_"+cUF, func(t *testing.T) {
			if !r.Has(cUF) {
				t.Fatalf("registry missing cUF=%s", cUF)
			}
			if _, err := r.URL(cUF, "2", sefaz.ServiceAutorizacao); err != nil {
				t.Errorf("homolog Autorizacao for cUF=%s: %v", cUF, err)
			}
			if _, err := r.URL(cUF, "1", sefaz.ServiceAutorizacao); err != nil {
				t.Errorf("prod Autorizacao for cUF=%s: %v", cUF, err)
			}
			if _, err := r.URL(cUF, "2", sefaz.ServiceEvento); err != nil {
				t.Errorf("homolog Evento for cUF=%s: %v", cUF, err)
			}
			if _, err := r.URL(cUF, "1", sefaz.ServiceEvento); err != nil {
				t.Errorf("prod Evento for cUF=%s: %v", cUF, err)
			}
		})
	}
}

func TestStaticRegistry_InvalidTpAmb_Errors(t *testing.T) {
	r := sefaz.NewDefaultRegistry()
	_, err := r.URL("35", "9", sefaz.ServiceAutorizacao)
	if err == nil {
		t.Fatal("expected error for tpAmb=9")
	}
}
