package sefaz

import (
	"errors"
	"fmt"
)

// Service identifies which SEFAZ webservice an URL is for. Sprint 3.2
// only wires the two services Sefarius actually invokes; CheckStatus,
// Inutilização, and Distribuição NFe are sprint-future.
type Service int

const (
	// ServiceAutorizacao = NFeAutorizacao4 (emit / authorize an NF-e).
	ServiceAutorizacao Service = iota
	// ServiceEvento = NFeRecepcaoEvento4 (cancel + Carta de Correção).
	ServiceEvento
)

func (s Service) String() string {
	switch s {
	case ServiceAutorizacao:
		return "NFeAutorizacao4"
	case ServiceEvento:
		return "NFeRecepcaoEvento4"
	default:
		return fmt.Sprintf("unknown(%d)", int(s))
	}
}

// ErrUFNotConfigured is returned by EndpointRegistry when an UF is
// requested but no entry has been registered. Surfaces to the caller
// as an actionable "this state needs an autorizadora mapping" error
// instead of a confusing connection failure.
var ErrUFNotConfigured = errors.New("sefaz: UF has no autorizadora endpoint configured")

// ErrServiceNotConfigured is returned when the requested Service is
// not in the registry for the given UF — e.g. an autorizadora that
// hosts NFeAutorizacao4 but not NFeRecepcaoEvento4.
var ErrServiceNotConfigured = errors.New("sefaz: service not configured for this autorizadora")

// EndpointRegistry resolves a (cUF, tpAmb, service) tuple to the SOAP
// URL of the correct SEFAZ autorizadora. Implementations must be safe
// for concurrent use.
//
//   - cUF:    2-digit IBGE state code ("35" = SP, "43" = RS, etc.)
//   - tpAmb:  "1" for produção, "2" for homologação
//   - svc:    which webservice on that autorizadora
type EndpointRegistry interface {
	URL(cUF, tpAmb string, svc Service) (string, error)
}

// EndpointSet bundles the homolog + prod URLs for a single service on a
// single autorizadora.
type EndpointSet struct {
	Homologacao string
	Producao    string
}

// URLFor picks the right URL for the given tpAmb. Returns an error if
// the requested ambiente is not configured (e.g. an autorizadora that
// only exposes a homolog endpoint).
func (e EndpointSet) URLFor(tpAmb string) (string, error) {
	switch tpAmb {
	case "1":
		if e.Producao == "" {
			return "", fmt.Errorf("%w: tpAmb=1 (produção) not configured", ErrServiceNotConfigured)
		}
		return e.Producao, nil
	case "2":
		if e.Homologacao == "" {
			return "", fmt.Errorf("%w: tpAmb=2 (homologação) not configured", ErrServiceNotConfigured)
		}
		return e.Homologacao, nil
	default:
		return "", fmt.Errorf("invalid tpAmb %q (expected \"1\" or \"2\")", tpAmb)
	}
}

// AutorizadoraEndpoints is the per-autorizadora bundle of services.
// Most autorizadoras host both Autorizacao + Evento; a few only host a
// subset (e.g. SVC-AN/SVC-RS contingency endpoints don't accept events).
type AutorizadoraEndpoints struct {
	Autorizacao EndpointSet
	Evento      EndpointSet
}

// StaticRegistry is the default EndpointRegistry — a static map from
// cUF → autorizadora bundle. Built at process boot from the canonical
// SEFAZ portal URLs (see endpoints_data.go in Sprint 3.2 closure).
//
// The registry is read-only after construction. To override URLs in
// tests, build a fresh StaticRegistry and inject it via NewRealClient.
type StaticRegistry struct {
	byUF map[string]AutorizadoraEndpoints
}

// NewStaticRegistry builds a StaticRegistry from a UF → endpoints map.
// The map is copied so the caller can mutate the source freely.
func NewStaticRegistry(byUF map[string]AutorizadoraEndpoints) *StaticRegistry {
	cp := make(map[string]AutorizadoraEndpoints, len(byUF))
	for k, v := range byUF {
		cp[k] = v
	}
	return &StaticRegistry{byUF: cp}
}

// URL implements EndpointRegistry.
func (r *StaticRegistry) URL(cUF, tpAmb string, svc Service) (string, error) {
	bundle, ok := r.byUF[cUF]
	if !ok {
		return "", fmt.Errorf("%w: cUF=%q", ErrUFNotConfigured, cUF)
	}
	switch svc {
	case ServiceAutorizacao:
		return bundle.Autorizacao.URLFor(tpAmb)
	case ServiceEvento:
		return bundle.Evento.URLFor(tpAmb)
	default:
		return "", fmt.Errorf("unknown service %v", svc)
	}
}

// Has returns true if the registry has an entry for the given UF.
// Useful in tests to assert coverage without invoking URL.
func (r *StaticRegistry) Has(cUF string) bool {
	_, ok := r.byUF[cUF]
	return ok
}

// UFCount returns the number of configured UFs. Sprint 3.2 ships with
// 27 UFs covering all Brazilian states; the count is asserted in tests
// to flag accidental drops.
func (r *StaticRegistry) UFCount() int {
	return len(r.byUF)
}
