package sefaz_test

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure/sefaz"
)

// signedXMLFixture returns a minimal byte string whose substring shape
// matches what nfe.Sign produces (Id="NFe<chave>"). Avoids dragging the
// full nfe.Builder + Sign pipeline into a unit test for the mock; the
// emit_nfe use case test exercises the real pipeline end-to-end.
func signedXMLFixture(chave string) []byte {
	if len(chave) != 44 {
		panic("test fixture chave must be 44 digits")
	}
	return []byte(`<NFe><infNFe Id="NFe` + chave + `" versao="4.00"></infNFe></NFe>`)
}

// signedXMLFixtureWithTpAmb mirrors signedXMLFixture but injects the
// requested <tpAmb> element so tests can assert that the mock echoes
// the submitted environment back in the protocol.
func signedXMLFixtureWithTpAmb(chave, tpAmb string) []byte {
	if len(chave) != 44 {
		panic("test fixture chave must be 44 digits")
	}
	return []byte(`<NFe><infNFe Id="NFe` + chave + `" versao="4.00"><ide><tpAmb>` + tpAmb + `</tpAmb></ide></infNFe></NFe>`)
}

const validChave1 = "43260505730928000145550010000001001123456787"
const validChave2 = "35260505730928000145550010000001002123456789"

func TestMockClient_DefaultAuthorizesSuccessfully(t *testing.T) {
	mock := sefaz.NewMockClient()
	res, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if res.Status != nfe.AuthorizationStatusAuthorized {
		t.Errorf("Status = %s, want AUTHORIZED", res.Status)
	}
	if res.CStat != "100" {
		t.Errorf("CStat = %s, want 100", res.CStat)
	}
	if res.Protocol == nil {
		t.Fatal("Protocol is nil on authorized result")
	}
	if res.Protocol.ChNFe != validChave1 {
		t.Errorf("Protocol.ChNFe = %s, want %s", res.Protocol.ChNFe, validChave1)
	}
	if res.Protocol.NProt == "" {
		t.Error("Protocol.NProt is empty")
	}
	if res.Protocol.TpAmb != "2" {
		t.Errorf("Protocol.TpAmb = %s, want 2 (homologation default)", res.Protocol.TpAmb)
	}
	if mock.CallCount() != 1 {
		t.Errorf("CallCount = %d, want 1", mock.CallCount())
	}
}

// TestMockClient_DuplicateDetection guards the idempotent-resubmit
// behavior. Real SEFAZ returns cStat 539 with the prior protocol when
// the same chave is submitted twice; the mock must mirror that or the
// emit_nfe use case will think a duplicate is a brand-new approval.
func TestMockClient_DuplicateDetection(t *testing.T) {
	mock := sefaz.NewMockClient()
	first, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	second, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if err != nil {
		t.Fatalf("second Authorize: %v", err)
	}
	if second.Status != nfe.AuthorizationStatusDuplicate {
		t.Errorf("second Status = %s, want DUPLICATE", second.Status)
	}
	if second.CStat != "539" {
		t.Errorf("second CStat = %s, want 539", second.CStat)
	}
	if second.Protocol == nil {
		t.Fatal("Protocol is nil on duplicate result")
	}
	// The duplicate response must echo the *original* protocol —
	// callers rely on this to reconstruct the procNFe file when the
	// only thing they have is a chave they previously submitted.
	if second.Protocol.NProt != first.Protocol.NProt {
		t.Errorf("duplicate NProt = %s, want first NProt %s", second.Protocol.NProt, first.Protocol.NProt)
	}
}

// TestMockClient_DistinctChavesGetDistinctProtocols guards the protocol
// generator: two submissions in the same instance must not collide.
func TestMockClient_DistinctChavesGetDistinctProtocols(t *testing.T) {
	mock := sefaz.NewMockClient()
	r1, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	r2, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave2))
	if r1.Protocol.NProt == r2.Protocol.NProt {
		t.Errorf("protocol collision between distinct chaves: %s", r1.Protocol.NProt)
	}
}

func TestMockClient_RejectChavePrefix(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.RejectChavePrefix("4326", &nfe.Rejection{
		CStat:   "220",
		XMotivo: "Rejeicao: NF-e emitida ha mais de 30 dias",
	})

	res, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if res.Status != nfe.AuthorizationStatusRejected {
		t.Errorf("Status = %s, want REJECTED", res.Status)
	}
	if res.Rejection == nil || res.Rejection.CStat != "220" {
		t.Errorf("Rejection = %+v, want CStat 220", res.Rejection)
	}

	// A chave that does not match the prefix should still authorize.
	ok, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave2))
	if ok.Status != nfe.AuthorizationStatusAuthorized {
		t.Errorf("non-matching chave Status = %s, want AUTHORIZED", ok.Status)
	}
}

func TestMockClient_QueueOutcomeOverridesDefault(t *testing.T) {
	mock := sefaz.NewMockClient()
	queued := &nfe.AuthorizationResult{
		Status:  nfe.AuthorizationStatusServiceUnavailable,
		CStat:   "108",
		XMotivo: "Servico Paralisado Momentaneamente (curto prazo)",
	}
	mock.QueueOutcome(queued)

	res, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if res.Status != nfe.AuthorizationStatusServiceUnavailable {
		t.Errorf("Status = %s, want SERVICE_UNAVAILABLE", res.Status)
	}

	// After consuming the queued outcome, default behavior resumes.
	next, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if next.Status != nfe.AuthorizationStatusAuthorized {
		t.Errorf("next Status = %s, want AUTHORIZED (queue exhausted)", next.Status)
	}
}

func TestMockClient_FailWithErrorPropagates(t *testing.T) {
	mock := sefaz.NewMockClient()
	mock.FailWithError(nfe.ErrSefazUnreachable)

	_, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if !errors.Is(err, nfe.ErrSefazUnreachable) {
		t.Errorf("err = %v, want ErrSefazUnreachable", err)
	}
}

func TestMockClient_RejectsXMLWithoutInfNFeId(t *testing.T) {
	mock := sefaz.NewMockClient()
	res, err := mock.Authorize(context.Background(), []byte(`<NFe></NFe>`))
	if err != nil {
		t.Fatalf("Authorize returned error %v; want structured rejection", err)
	}
	if res.Status != nfe.AuthorizationStatusRejected {
		t.Errorf("Status = %s, want REJECTED", res.Status)
	}
	if res.CStat != "225" {
		t.Errorf("CStat = %s, want 225 (Falha no Schema XML)", res.CStat)
	}
}

// TestMockClient_AuthorizeEchoesSubmittedTpAmb closes bug B1 (2026-05-07):
// the mock used to hard-code Protocol.TpAmb="2", which made the NF-e
// detail screen show "Ambiente: Homologação" even when the operator had
// selected Produção (tpAmb=1) and the signed XML carried <tpAmb>1</tpAmb>.
// The fix extracts tpAmb from the input XML; this test fails if the
// mock regresses to ignoring the submitted environment.
func TestMockClient_AuthorizeEchoesSubmittedTpAmb(t *testing.T) {
	mock := sefaz.NewMockClient()

	prodRes, err := mock.Authorize(context.Background(), signedXMLFixtureWithTpAmb(validChave1, "1"))
	if err != nil {
		t.Fatalf("Authorize(prod): %v", err)
	}
	if prodRes.Protocol == nil {
		t.Fatal("Protocol nil for tpAmb=1 submission")
	}
	if prodRes.Protocol.TpAmb != "1" {
		t.Errorf("Protocol.TpAmb = %q, want %q (production echo)", prodRes.Protocol.TpAmb, "1")
	}

	homologRes, err := mock.Authorize(context.Background(), signedXMLFixtureWithTpAmb(validChave2, "2"))
	if err != nil {
		t.Fatalf("Authorize(homolog): %v", err)
	}
	if homologRes.Protocol.TpAmb != "2" {
		t.Errorf("Protocol.TpAmb = %q, want %q (homologation echo)", homologRes.Protocol.TpAmb, "2")
	}
}

// TestMockClient_AuthorizeFallsBackToHomologationWhenTpAmbMissing
// guards the safe default for malformed input — fixtures without a
// <tpAmb> element (like the legacy signedXMLFixture) must still get
// a non-empty TpAmb so downstream renderers don't crash on an
// empty-string environment.
func TestMockClient_AuthorizeFallsBackToHomologationWhenTpAmbMissing(t *testing.T) {
	mock := sefaz.NewMockClient()
	res, err := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if err != nil {
		t.Fatalf("Authorize: %v", err)
	}
	if res.Protocol == nil || res.Protocol.TpAmb != "2" {
		t.Errorf("fallback TpAmb = %q, want %q", res.Protocol.TpAmb, "2")
	}
}

func TestMockClient_RespectsContextCancellation(t *testing.T) {
	mock := sefaz.NewMockClient()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := mock.Authorize(ctx, signedXMLFixture(validChave1))
	if !errors.Is(err, context.Canceled) {
		t.Errorf("err = %v, want context.Canceled", err)
	}
}

func TestMockClient_ProtocolDigestIsStableForSameInput(t *testing.T) {
	mock := sefaz.NewMockClient()
	r1, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	// Re-submitting the same XML hits the duplicate path and echoes
	// the same protocol — including the same digVal. The digVal is
	// the only protocol field bound to the XML bytes themselves.
	r2, _ := mock.Authorize(context.Background(), signedXMLFixture(validChave1))
	if r1.Protocol.DigVal != r2.Protocol.DigVal {
		t.Errorf("DigVal changed across resubmits: %s != %s", r1.Protocol.DigVal, r2.Protocol.DigVal)
	}
	if !strings.HasSuffix(r1.Protocol.DigVal, "=") && len(r1.Protocol.DigVal) != 28 {
		// SHA-1 base64 is 28 chars including padding.
		t.Errorf("DigVal shape unexpected: %q (len=%d)", r1.Protocol.DigVal, len(r1.Protocol.DigVal))
	}
}
