package sefaz

// DefaultEndpoints returns the canonical SEFAZ NFe v4.00 endpoint
// registry covering all 27 Brazilian UFs. Built from the SEFAZ portal
// webServices.aspx page and per-UF SEFAZ portals as of 2026-05-07.
//
// Source pinning (re-sync each sprint until the migrations settle):
//   - Portal Nacional: https://www.nfe.fazenda.gov.br/portal/webServices.aspx
//   - Canonical XML:   sped-nfe storage/wsnfe_4.00_mod55.xml
//   - CE migrated to SVRS in 2022-01-10 (NFe modelo 55).
//   - SVAN/SVC-AN homolog unified to sefazvirtual.fazenda.gov.br on 2024-07-15.
//   - SVAN production still on www.svan.fazenda.gov.br (legacy host) —
//     migration to www.sefazvirtual.fazenda.gov.br tracked but not yet
//     mandatory. Both hosts return identical responses.
//
// URLs flagged with "VERIFY:" comments are pattern-derived because the
// canonical SEFAZ portal documents only the homolog endpoint; the prod
// hostname is the conventional "drop-the-h prefix" swap. Confirm
// against the autorizadora's portal before any prod deployment.
func DefaultEndpoints() map[string]AutorizadoraEndpoints {
	// ─── Per-autorizadora endpoint bundles ──────────────────────────────────
	sp := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://homologacao.nfe.fazenda.sp.gov.br/ws/nfeautorizacao4.asmx",
			Producao:    "https://nfe.fazenda.sp.gov.br/ws/nfeautorizacao4.asmx",
		},
		Evento: EndpointSet{
			Homologacao: "https://homologacao.nfe.fazenda.sp.gov.br/ws/nferecepcaoevento4.asmx",
			Producao:    "https://nfe.fazenda.sp.gov.br/ws/nferecepcaoevento4.asmx",
		},
	}

	mg := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://hnfe.fazenda.mg.gov.br/nfe2/services/NFeAutorizacao4",
			Producao:    "https://nfe.fazenda.mg.gov.br/nfe2/services/NFeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://hnfe.fazenda.mg.gov.br/nfe2/services/NFeRecepcaoEvento4",
			Producao:    "https://nfe.fazenda.mg.gov.br/nfe2/services/NFeRecepcaoEvento4",
		},
	}

	// SVRS hosts both RS's own production NFe and the shared service
	// for 16 other UFs (AC, AL, AP, CE, DF, ES, PA, PB, PI, RJ, RN, RO,
	// RR, SC, SE, TO). Same URLs used by RS-direct and SVRS-routed UFs.
	svrs := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://nfe-homologacao.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx",
			Producao:    "https://nfe.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx",
		},
		Evento: EndpointSet{
			Homologacao: "https://nfe-homologacao.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx",
			Producao:    "https://nfe.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx",
		},
	}

	pr := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://homologacao.nfe.sefa.pr.gov.br/nfe/NFeAutorizacao4",
			Producao:    "https://nfe.sefa.pr.gov.br/nfe/NFeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://homologacao.nfe.sefa.pr.gov.br/nfe/NFeRecepcaoEvento4",
			// VERIFY: pattern-derived from homolog hostname swap. SPED-PR
			// portal canonical URL is the source of truth — confirm before
			// production deployment.
			Producao: "https://nfe.sefa.pr.gov.br/nfe/NFeRecepcaoEvento4",
		},
	}

	ba := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://hnfe.sefaz.ba.gov.br/webservices/NFeAutorizacao4/NFeAutorizacao4.asmx",
			// VERIFY: BA prod URLs were pattern-derived (hnfe → nfe).
			// Confirm against Sefaz-BA portal before any prod-up.
			Producao: "https://nfe.sefaz.ba.gov.br/webservices/NFeAutorizacao4/NFeAutorizacao4.asmx",
		},
		Evento: EndpointSet{
			Homologacao: "https://hnfe.sefaz.ba.gov.br/webservices/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx",
			Producao:    "https://nfe.sefaz.ba.gov.br/webservices/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx",
		},
	}

	pe := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://nfehomolog.sefaz.pe.gov.br/nfe-service/services/NFeAutorizacao4",
			Producao:    "https://nfe.sefaz.pe.gov.br/nfe-service/services/NFeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://nfehomolog.sefaz.pe.gov.br/nfe-service/services/NFeRecepcaoEvento4",
			Producao:    "https://nfe.sefaz.pe.gov.br/nfe-service/services/NFeRecepcaoEvento4",
		},
	}

	mt := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://homologacao.sefaz.mt.gov.br/nfews/v2/services/NfeAutorizacao4",
			Producao:    "https://nfe.sefaz.mt.gov.br/nfews/v2/services/NfeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://homologacao.sefaz.mt.gov.br/nfews/v2/services/RecepcaoEvento4",
			Producao:    "https://nfe.sefaz.mt.gov.br/nfews/v2/services/RecepcaoEvento4",
		},
	}

	am := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://homnfe.sefaz.am.gov.br/services2/services/NfeAutorizacao4",
			Producao:    "https://nfe.sefaz.am.gov.br/services2/services/NfeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://homnfe.sefaz.am.gov.br/services2/services/RecepcaoEvento4",
			Producao:    "https://nfe.sefaz.am.gov.br/services2/services/RecepcaoEvento4",
		},
	}

	go_ := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://homolog.sefaz.go.gov.br/nfe/services/NFeAutorizacao4",
			// VERIFY: GO prod hostname pattern-derived from homolog
			// (homolog.sefaz.go.gov.br → nfe.sefaz.go.gov.br). Goiás
			// portal documents only the homolog endpoint explicitly.
			Producao: "https://nfe.sefaz.go.gov.br/nfe/services/NFeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://homolog.sefaz.go.gov.br/nfe/services/NFeRecepcaoEvento4",
			Producao:    "https://nfe.sefaz.go.gov.br/nfe/services/NFeRecepcaoEvento4",
		},
	}

	ms := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://hom.nfe.sefaz.ms.gov.br/ws/NFeAutorizacao4",
			Producao:    "https://nfe.sefaz.ms.gov.br/ws/NFeAutorizacao4",
		},
		Evento: EndpointSet{
			Homologacao: "https://hom.nfe.sefaz.ms.gov.br/ws/NFeRecepcaoEvento4",
			Producao:    "https://nfe.sefaz.ms.gov.br/ws/NFeRecepcaoEvento4",
		},
	}

	// SVAN handles MA only. Production still on the legacy
	// www.svan.fazenda.gov.br host; homologação unified to
	// sefazvirtual.fazenda.gov.br on 2024-07-15.
	svan := AutorizadoraEndpoints{
		Autorizacao: EndpointSet{
			Homologacao: "https://hom.sefazvirtual.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx",
			// VERIFY: SVAN production migration to sefazvirtual.fazenda.gov.br
			// is in flight (2024-2025). Legacy host www.svan.fazenda.gov.br
			// still accepts submissions; both hosts return identical responses.
			Producao: "https://www.svan.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx",
		},
		Evento: EndpointSet{
			Homologacao: "https://hom.sefazvirtual.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx",
			Producao:    "https://www.svan.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx",
		},
	}

	// ─── UF → autorizadora mapping (canonical 2026-05-07) ───────────────────
	// 10 own autorizadoras + MA on SVAN + 16 on SVRS = 27 UFs.
	// CE migrated NFe modelo 55 from SVAN to SVRS on 2022-01-10.
	return map[string]AutorizadoraEndpoints{
		// Own autorizadoras
		"35": sp,    // SP
		"31": mg,    // MG
		"43": svrs,  // RS uses SVRS infrastructure (same URLs)
		"41": pr,    // PR
		"29": ba,    // BA
		"26": pe,    // PE
		"51": mt,    // MT
		"13": am,    // AM
		"52": go_,   // GO (note: 'go' is a Go keyword; var renamed)
		"50": ms,    // MS
		"21": svan,  // MA → SVAN
		// Routed via SVRS (16 UFs)
		"12": svrs, // AC
		"27": svrs, // AL
		"16": svrs, // AP
		"23": svrs, // CE (post-2022-01-10 migration)
		"53": svrs, // DF
		"32": svrs, // ES
		"15": svrs, // PA
		"25": svrs, // PB
		"22": svrs, // PI
		"33": svrs, // RJ
		"24": svrs, // RN
		"11": svrs, // RO
		"14": svrs, // RR
		"42": svrs, // SC
		"28": svrs, // SE
		"17": svrs, // TO
	}
}

// NewDefaultRegistry is the convenience builder used by main.go to wire
// production. Equivalent to NewStaticRegistry(DefaultEndpoints()).
func NewDefaultRegistry() *StaticRegistry {
	return NewStaticRegistry(DefaultEndpoints())
}
