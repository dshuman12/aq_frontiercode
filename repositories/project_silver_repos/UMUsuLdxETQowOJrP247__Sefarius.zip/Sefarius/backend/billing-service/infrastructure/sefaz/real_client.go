package sefaz

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
)

// defaultTimeout is the per-request timeout for SOAP calls. SEFAZ
// homologação routinely takes 5-15s under load; production sees 1-3s.
// 30s gives slack without letting hung connections leak.
const defaultTimeout = 30 * time.Second

// RealClient implements nfe.SefazClient over the SEFAZ NFeAutorizacao4
// and NFeRecepcaoEvento4 SOAP webservices, with mTLS using an A1
// ICP-Brasil certificate.
//
// The client is stateless beyond the cert + endpoint registry — each
// call routes itself by extracting cUF + tpAmb from the signed XML.
// This preserves the SefazClient contract (no per-call routing args)
// and matches the technique MockClient already uses.
//
// Concurrency: safe. http.Client is concurrency-safe and the registry
// is read-only after construction.
type RealClient struct {
	cert       *nfe.Certificate
	httpClient *http.Client
	registry   EndpointRegistry
}

// RealClientOption configures a RealClient. The variadic constructor
// keeps test ergonomics clean (override transport, timeout) without
// bloating the production call site.
type RealClientOption func(*RealClient)

// WithHTTPClient overrides the default mTLS http.Client. Tests use
// this to inject httptest.Server's tls-aware client; production code
// does not need to touch it.
func WithHTTPClient(c *http.Client) RealClientOption {
	return func(r *RealClient) { r.httpClient = c }
}

// WithTimeout overrides the per-request timeout. Default is 30s.
func WithTimeout(d time.Duration) RealClientOption {
	return func(r *RealClient) {
		if r.httpClient == nil {
			return
		}
		r.httpClient.Timeout = d
	}
}

// NewRealClient builds a RealClient with the given cert and registry.
// Returns an error for nil dependencies — these are programming bugs,
// not runtime conditions, so failing loud at composition is correct.
//
// The default http.Client uses TLS 1.2+ with cert as the client
// identity (mTLS). SEFAZ requires the same cert on the wire and
// inside the XMLDSig signature; using two different certs is a 280
// rejection ("certificado do transmissor difere do assinante").
func NewRealClient(cert *nfe.Certificate, registry EndpointRegistry, opts ...RealClientOption) (*RealClient, error) {
	if cert == nil {
		return nil, errors.New("sefaz.NewRealClient: cert is required")
	}
	if registry == nil {
		return nil, errors.New("sefaz.NewRealClient: registry is required")
	}

	tlsCert := tls.Certificate{
		Certificate: [][]byte{cert.X509.Raw},
		PrivateKey:  cert.PrivateKey,
		Leaf:        cert.X509,
	}

	c := &RealClient{
		cert:     cert,
		registry: registry,
		httpClient: &http.Client{
			Timeout: defaultTimeout,
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{
					Certificates: []tls.Certificate{tlsCert},
					MinVersion:   tls.VersionTLS12,
				},
				MaxIdleConns:        10,
				IdleConnTimeout:     90 * time.Second,
				TLSHandshakeTimeout: 10 * time.Second,
			},
		},
	}
	for _, opt := range opts {
		opt(c)
	}
	return c, nil
}

// Authorize implements nfe.SefazClient. Routes by extracting cUF +
// tpAmb from the signed XML, wraps the NFe in an enviNFe + soap
// envelope, posts, and parses the retEnviNFe + protNFe reply.
func (c *RealClient) Authorize(ctx context.Context, signedXML []byte) (*nfe.AuthorizationResult, error) {
	cUF, tpAmb, err := extractAuthorizeRouting(signedXML)
	if err != nil {
		return nil, fmt.Errorf("sefaz.Authorize: %w", err)
	}

	url, err := c.registry.URL(cUF, tpAmb, ServiceAutorizacao)
	if err != nil {
		return nil, fmt.Errorf("sefaz.Authorize: %w", err)
	}

	envelope := wrapAutorizacaoEnvelope(signedXML)
	respBody, err := c.postSOAP(ctx, url, envelope)
	if err != nil {
		return nil, err
	}

	return parseAutorizacaoResponse(respBody)
}

// Cancel implements nfe.SefazClient. Same routing strategy as Authorize
// but extracts from <infEvento> + targets the Evento webservice.
func (c *RealClient) Cancel(ctx context.Context, signedEventXML []byte) (*nfe.EventResult, error) {
	return c.submitEvent(ctx, signedEventXML)
}

// SendCCe implements nfe.SefazClient. Same SEFAZ endpoint as Cancel
// (NFeRecepcaoEvento4); SEFAZ dispatches by tpEvento inside the body.
func (c *RealClient) SendCCe(ctx context.Context, signedEventXML []byte) (*nfe.EventResult, error) {
	return c.submitEvent(ctx, signedEventXML)
}

// submitEvent is shared between Cancel and SendCCe. The two only differ
// in the tpEvento embedded in the signed XML; SEFAZ-side dispatch and
// Sefarius-side response handling are identical.
func (c *RealClient) submitEvent(ctx context.Context, signedEventXML []byte) (*nfe.EventResult, error) {
	cOrgao, tpAmb, err := extractEventRouting(signedEventXML)
	if err != nil {
		return nil, fmt.Errorf("sefaz.submitEvent: %w", err)
	}

	url, err := c.registry.URL(cOrgao, tpAmb, ServiceEvento)
	if err != nil {
		return nil, fmt.Errorf("sefaz.submitEvent: %w", err)
	}

	envelope := wrapEventoEnvelope(signedEventXML)
	respBody, err := c.postSOAP(ctx, url, envelope)
	if err != nil {
		return nil, err
	}

	return parseEventoResponse(signedEventXML, respBody)
}

// postSOAP sends a SOAP envelope and returns the response body. Wraps
// transport errors and SEFAZ 5xx in nfe.ErrSefazUnreachable so the
// application layer can branch on it consistently.
func (c *RealClient) postSOAP(ctx context.Context, url string, body []byte) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}
	// SEFAZ NFe v4.00 services use SOAP 1.2 with the application/soap+xml
	// content type. Some autorizadoras tolerate text/xml; we send the
	// strict media type to match the WSDL.
	req.Header.Set("Content-Type", "application/soap+xml; charset=utf-8")
	req.Header.Set("Accept", "application/soap+xml, text/xml")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", nfe.ErrSefazUnreachable, err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(io.LimitReader(resp.Body, 5<<20)) // 5 MiB safety
	if err != nil {
		return nil, fmt.Errorf("%w: read body: %v", nfe.ErrSefazUnreachable, err)
	}

	if resp.StatusCode >= 500 {
		return nil, fmt.Errorf("%w: HTTP %d", nfe.ErrSefazUnreachable, resp.StatusCode)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("SEFAZ HTTP %d: %s", resp.StatusCode, truncate(string(respBody), 200))
	}
	return respBody, nil
}

// truncate keeps error messages bounded so a 5 MB SEFAZ HTML error
// page doesn't blow up logs.
func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "..."
}

// ─── Routing extraction ──────────────────────────────────────────────────────

// extractAuthorizeRouting pulls cUF + tpAmb from a signed NFe XML. Both
// fields live inside <infNFe><ide>; we use a tolerant minimal parser
// (encoding/xml decoder) instead of a string-scan because the signed
// XML may contain whitespace, namespace prefixes, or attribute order
// differences that break naive substring matching.
func extractAuthorizeRouting(signedXML []byte) (cUF, tpAmb string, err error) {
	dec := xml.NewDecoder(bytes.NewReader(signedXML))
	var inIde bool
	var depth int
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return "", "", fmt.Errorf("xml decode: %w", err)
		}
		switch t := tok.(type) {
		case xml.StartElement:
			depth++
			if t.Name.Local == "ide" {
				inIde = true
			} else if inIde && (t.Name.Local == "cUF" || t.Name.Local == "tpAmb") {
				val, err := readElementText(dec)
				if err != nil {
					return "", "", fmt.Errorf("read %s: %w", t.Name.Local, err)
				}
				switch t.Name.Local {
				case "cUF":
					cUF = val
				case "tpAmb":
					tpAmb = val
				}
				if cUF != "" && tpAmb != "" {
					return cUF, tpAmb, nil
				}
			}
		case xml.EndElement:
			depth--
			if t.Name.Local == "ide" {
				inIde = false
			}
		}
	}
	if cUF == "" {
		return "", "", errors.New("cUF not found in <ide>")
	}
	if tpAmb == "" {
		return "", "", errors.New("tpAmb not found in <ide>")
	}
	return cUF, tpAmb, nil
}

// extractEventRouting pulls cOrgao + tpAmb from a signed evento XML.
// In events, cOrgao plays the role cUF plays in authorize — it
// indicates which autorizadora processes the event. For most UFs
// cOrgao == cUF; for contingency events (SVC-AN, SVC-RS) it differs.
func extractEventRouting(signedEventXML []byte) (cOrgao, tpAmb string, err error) {
	dec := xml.NewDecoder(bytes.NewReader(signedEventXML))
	var inInfEvento bool
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return "", "", fmt.Errorf("xml decode: %w", err)
		}
		switch t := tok.(type) {
		case xml.StartElement:
			if t.Name.Local == "infEvento" {
				inInfEvento = true
			} else if inInfEvento && (t.Name.Local == "cOrgao" || t.Name.Local == "tpAmb") {
				val, err := readElementText(dec)
				if err != nil {
					return "", "", fmt.Errorf("read %s: %w", t.Name.Local, err)
				}
				switch t.Name.Local {
				case "cOrgao":
					cOrgao = val
				case "tpAmb":
					tpAmb = val
				}
				if cOrgao != "" && tpAmb != "" {
					return cOrgao, tpAmb, nil
				}
			}
		case xml.EndElement:
			if t.Name.Local == "infEvento" {
				inInfEvento = false
			}
		}
	}
	if cOrgao == "" {
		return "", "", errors.New("cOrgao not found in <infEvento>")
	}
	if tpAmb == "" {
		return "", "", errors.New("tpAmb not found in <infEvento>")
	}
	return cOrgao, tpAmb, nil
}

// readElementText reads CharData until the matching EndElement. Used
// when the parser is positioned just after a StartElement.
func readElementText(dec *xml.Decoder) (string, error) {
	var b strings.Builder
	for {
		tok, err := dec.Token()
		if err != nil {
			return "", err
		}
		switch t := tok.(type) {
		case xml.CharData:
			b.Write(t)
		case xml.EndElement:
			return strings.TrimSpace(b.String()), nil
		}
	}
}

// ─── SOAP envelope wrappers ──────────────────────────────────────────────────

// wrapAutorizacaoEnvelope wraps a signed NFe in the SOAP body that
// NFeAutorizacao4 expects. The body is the XML payload SEFAZ stamps
// against the WSDL contract:
//
//	<soap:Envelope>
//	  <soap:Body>
//	    <nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4">
//	      <enviNFe versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">
//	        <idLote>1</idLote>
//	        <indSinc>1</indSinc>
//	        <NFe>...</NFe>
//	      </enviNFe>
//	    </nfeDadosMsg>
//	  </soap:Body>
//	</soap:Envelope>
//
// indSinc=1 picks the synchronous response mode — the protocol comes
// back in the same call instead of via a separate consultaRecibo. All
// modern SEFAZ deploys support sync; async is legacy.
func wrapAutorizacaoEnvelope(signedNFe []byte) []byte {
	var buf bytes.Buffer
	buf.WriteString(`<?xml version="1.0" encoding="utf-8"?>`)
	buf.WriteString(`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">`)
	buf.WriteString(`<soap:Body>`)
	buf.WriteString(`<nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeAutorizacao4">`)
	buf.WriteString(`<enviNFe versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">`)
	buf.WriteString(`<idLote>1</idLote>`)
	buf.WriteString(`<indSinc>1</indSinc>`)
	buf.Write(signedNFe)
	buf.WriteString(`</enviNFe>`)
	buf.WriteString(`</nfeDadosMsg>`)
	buf.WriteString(`</soap:Body>`)
	buf.WriteString(`</soap:Envelope>`)
	return buf.Bytes()
}

// wrapEventoEnvelope wraps a signed evento in the SOAP body that
// NFeRecepcaoEvento4 expects.
func wrapEventoEnvelope(signedEvento []byte) []byte {
	var buf bytes.Buffer
	buf.WriteString(`<?xml version="1.0" encoding="utf-8"?>`)
	buf.WriteString(`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">`)
	buf.WriteString(`<soap:Body>`)
	buf.WriteString(`<nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4">`)
	buf.WriteString(`<envEvento versao="1.00" xmlns="http://www.portalfiscal.inf.br/nfe">`)
	buf.WriteString(`<idLote>1</idLote>`)
	buf.Write(signedEvento)
	buf.WriteString(`</envEvento>`)
	buf.WriteString(`</nfeDadosMsg>`)
	buf.WriteString(`</soap:Body>`)
	buf.WriteString(`</soap:Envelope>`)
	return buf.Bytes()
}

// ─── Response parsers ────────────────────────────────────────────────────────

// retEnviNFe is the SEFAZ response shape for synchronous authorize.
// The envelope nesting is: soap:Envelope > soap:Body > nfeResultMsg >
// retEnviNFe. We unmarshal directly to retEnviNFe via a local helper
// that strips the outer SOAP wrappers.
type retEnviNFe struct {
	XMLName xml.Name `xml:"retEnviNFe"`
	TpAmb   string   `xml:"tpAmb"`
	CStat   string   `xml:"cStat"`
	XMotivo string   `xml:"xMotivo"`
	ProtNFe *protNFe `xml:"protNFe"`
}

type protNFe struct {
	InfProt struct {
		TpAmb    string `xml:"tpAmb"`
		ChNFe    string `xml:"chNFe"`
		DhRecbto string `xml:"dhRecbto"`
		NProt    string `xml:"nProt"`
		DigVal   string `xml:"digVal"`
		CStat    string `xml:"cStat"`
		XMotivo  string `xml:"xMotivo"`
	} `xml:"infProt"`
}

// parseAutorizacaoResponse maps a SOAP response body to an
// AuthorizationResult. The cStat dispatch follows the SEFAZ Manual de
// Orientação do Contribuinte annex; codes not in the explicit branches
// fall through to REJECTED.
//
// The response shape is soap:Envelope > soap:Body > nfeResultMsg >
// retEnviNFe. We scan for the retEnviNFe start element and decode just
// that subtree — sidesteps SOAP envelope namespace gymnastics.
func parseAutorizacaoResponse(body []byte) (*nfe.AuthorizationResult, error) {
	var ret retEnviNFe
	if err := decodeNamedElement(body, "retEnviNFe", &ret); err != nil {
		return nil, fmt.Errorf("decode retEnviNFe: %w", err)
	}

	// The outer cStat reflects the ENVELOPE status. When sync mode
	// succeeds (most common), the protNFe child carries the per-NFe
	// outcome — and that's the cStat we want to dispatch on.
	cStat := ret.CStat
	xMotivo := ret.XMotivo
	if ret.ProtNFe != nil && ret.ProtNFe.InfProt.CStat != "" {
		cStat = ret.ProtNFe.InfProt.CStat
		xMotivo = ret.ProtNFe.InfProt.XMotivo
	}

	switch authorizationStatusFor(cStat) {
	case nfe.AuthorizationStatusAuthorized:
		dh, _ := time.Parse(time.RFC3339, ret.ProtNFe.InfProt.DhRecbto)
		return &nfe.AuthorizationResult{
			Status:  nfe.AuthorizationStatusAuthorized,
			CStat:   cStat,
			XMotivo: xMotivo,
			Protocol: &nfe.Protocol{
				NProt:    ret.ProtNFe.InfProt.NProt,
				DhRecbto: dh.UTC(),
				ChNFe:    ret.ProtNFe.InfProt.ChNFe,
				DigVal:   ret.ProtNFe.InfProt.DigVal,
				CStat:    cStat,
				XMotivo:  xMotivo,
				TpAmb:    ret.ProtNFe.InfProt.TpAmb,
			},
		}, nil

	case nfe.AuthorizationStatusDuplicate:
		// SEFAZ returns the prior authorization protocol on cStat 204.
		// If it's missing (some autorizadoras drop it), the duplicate
		// is still a valid signal — populate Protocol with what we have.
		var proto *nfe.Protocol
		if ret.ProtNFe != nil {
			dh, _ := time.Parse(time.RFC3339, ret.ProtNFe.InfProt.DhRecbto)
			proto = &nfe.Protocol{
				NProt:    ret.ProtNFe.InfProt.NProt,
				DhRecbto: dh.UTC(),
				ChNFe:    ret.ProtNFe.InfProt.ChNFe,
				DigVal:   ret.ProtNFe.InfProt.DigVal,
				CStat:    cStat,
				XMotivo:  xMotivo,
				TpAmb:    ret.ProtNFe.InfProt.TpAmb,
			}
		}
		return &nfe.AuthorizationResult{
			Status:   nfe.AuthorizationStatusDuplicate,
			CStat:    cStat,
			XMotivo:  xMotivo,
			Protocol: proto,
		}, nil

	case nfe.AuthorizationStatusServiceUnavailable:
		return &nfe.AuthorizationResult{
			Status:  nfe.AuthorizationStatusServiceUnavailable,
			CStat:   cStat,
			XMotivo: xMotivo,
		}, nil

	default: // REJECTED
		return &nfe.AuthorizationResult{
			Status:  nfe.AuthorizationStatusRejected,
			CStat:   cStat,
			XMotivo: xMotivo,
			Rejection: &nfe.Rejection{
				CStat:   cStat,
				XMotivo: xMotivo,
			},
		}, nil
	}
}

// retEnvEvento + retEvento are the SEFAZ response shapes for events.
type retEnvEvento struct {
	XMLName   xml.Name    `xml:"retEnvEvento"`
	IdLote    string      `xml:"idLote"`
	TpAmb     string      `xml:"tpAmb"`
	CStat     string      `xml:"cStat"`
	XMotivo   string      `xml:"xMotivo"`
	RetEvento []retEvento `xml:"retEvento"`
}

type retEvento struct {
	InfEvento struct {
		TpAmb       string `xml:"tpAmb"`
		COrgao      string `xml:"cOrgao"`
		CStat       string `xml:"cStat"`
		XMotivo     string `xml:"xMotivo"`
		ChNFe       string `xml:"chNFe"`
		TpEvento    string `xml:"tpEvento"`
		NSeqEvento  int    `xml:"nSeqEvento"`
		DhRegEvento string `xml:"dhRegEvento"`
		NProt       string `xml:"nProt"`
	} `xml:"infEvento"`
}

// parseEventoResponse maps a SOAP response body to an EventResult.
// The sefaz returns the original signed event echoed inside a
// procEventoNFe + the retEvento. We synthesize a minimal procEventoNFe
// from (signedEvent, retEvento) for ResponseXML so the caller can
// persist it as a single legally valid blob — same shape as MockClient.
func parseEventoResponse(signedEventXML, body []byte) (*nfe.EventResult, error) {
	var ret retEnvEvento
	if err := decodeNamedElement(body, "retEnvEvento", &ret); err != nil {
		return nil, fmt.Errorf("decode retEnvEvento: %w", err)
	}

	// Sefarius submits one event per envelope (idLote=1); take the
	// first retEvento. SEFAZ may return zero retEvento on envelope-level
	// rejection (cStat 215, 216, etc.); in that case fall back to the
	// envelope cStat.
	var ev retEvento
	if len(ret.RetEvento) > 0 {
		ev = ret.RetEvento[0]
	}

	cStat := ret.CStat
	xMotivo := ret.XMotivo
	if ev.InfEvento.CStat != "" {
		cStat = ev.InfEvento.CStat
		xMotivo = ev.InfEvento.XMotivo
	}

	switch eventStatusFor(cStat) {
	case nfe.EventStatusAccepted:
		dh, _ := time.Parse(time.RFC3339, ev.InfEvento.DhRegEvento)
		proto := &nfe.EventProtocol{
			NProt:       ev.InfEvento.NProt,
			DhRegEvento: dh.UTC(),
			ChNFe:       ev.InfEvento.ChNFe,
			TpEvento:    ev.InfEvento.TpEvento,
			NSeqEvento:  ev.InfEvento.NSeqEvento,
			CStat:       cStat,
			XMotivo:     xMotivo,
			TpAmb:       ev.InfEvento.TpAmb,
		}
		return &nfe.EventResult{
			Status:      nfe.EventStatusAccepted,
			CStat:       cStat,
			XMotivo:     xMotivo,
			Protocol:    proto,
			ResponseXML: synthesizeProcEvento(signedEventXML, proto),
		}, nil

	case nfe.EventStatusServiceUnavailable:
		return &nfe.EventResult{
			Status:  nfe.EventStatusServiceUnavailable,
			CStat:   cStat,
			XMotivo: xMotivo,
		}, nil

	default: // REJECTED
		return &nfe.EventResult{
			Status:  nfe.EventStatusRejected,
			CStat:   cStat,
			XMotivo: xMotivo,
			Rejection: &nfe.EventRejection{
				CStat:   cStat,
				XMotivo: xMotivo,
			},
		}, nil
	}
}

// authorizationStatusFor maps the SEFAZ cStat code to the coarse
// AuthorizationStatus the application layer branches on. Codes are
// from the Manual de Orientação do Contribuinte v6.0.
func authorizationStatusFor(cStat string) nfe.AuthorizationStatus {
	switch cStat {
	case "100", "150": // 100 Autorizado o uso, 150 Autorizado fora de prazo
		return nfe.AuthorizationStatusAuthorized
	case "204", "539": // duplicidade (sync), duplicidade (async)
		return nfe.AuthorizationStatusDuplicate
	case "108", "109", "110", "111", "151", "656": // serviço paralisado / em manutenção / consumo indevido
		return nfe.AuthorizationStatusServiceUnavailable
	default:
		return nfe.AuthorizationStatusRejected
	}
}

// eventStatusFor maps the cStat to EventStatus. Different code set
// from authorize because events have their own response codes.
func eventStatusFor(cStat string) nfe.EventStatus {
	switch cStat {
	case "135", "136", "155": // 135 evento registrado, 136 vinculado, 155 fora de prazo
		return nfe.EventStatusAccepted
	case "108", "109", "110", "111": // serviço SEFAZ unavailable
		return nfe.EventStatusServiceUnavailable
	default:
		return nfe.EventStatusRejected
	}
}

// decodeNamedElement scans the body for a start element with the given
// local name (namespace-agnostic) and decodes that subtree into target.
// Returns an error if the element is not found or decode fails.
//
// This sidesteps the SOAP namespace declaration trickery that would
// otherwise force us to spell out soap:Envelope > soap:Body wrappers in
// a typed struct — a fragile match because some autorizadoras use
// `xmlns:soap` and others use `xmlns:soap12`, and the prefix shows up
// in the StartElement name.
func decodeNamedElement(body []byte, localName string, target any) error {
	dec := xml.NewDecoder(bytes.NewReader(body))
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			return fmt.Errorf("element <%s> not found in response", localName)
		}
		if err != nil {
			return err
		}
		start, ok := tok.(xml.StartElement)
		if !ok {
			continue
		}
		if start.Name.Local == localName {
			return dec.DecodeElement(target, &start)
		}
	}
}

// Compile-time guarantee RealClient implements the contract.
var _ nfe.SefazClient = (*RealClient)(nil)
