package danfe_test

import (
	"bytes"
	"errors"
	"strings"
	"testing"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure/danfe"
)

// fixtureCancelEventXML returns a parseable signed-evento blob for a
// cancel event. Hand-written rather than round-tripped through the
// builder because the renderer only consumes a stable subset of the
// schema; using a literal keeps the test independent of changes in
// the canc.TEvento marshalling path.
func fixtureCancelEventXML(chave string, dhEvento, xJust string, tpAmb string) []byte {
	return []byte(`<?xml version="1.0" encoding="UTF-8"?>` +
		`<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">` +
		`<infEvento Id="ID110111` + chave + `01">` +
		`<cOrgao>43</cOrgao>` +
		`<tpAmb>` + tpAmb + `</tpAmb>` +
		`<CNPJ>05730928000145</CNPJ>` +
		`<chNFe>` + chave + `</chNFe>` +
		`<dhEvento>` + dhEvento + `</dhEvento>` +
		`<tpEvento>110111</tpEvento>` +
		`<nSeqEvento>1</nSeqEvento>` +
		`<verEvento>1.00</verEvento>` +
		`<detEvento versao="1.00">` +
		`<descEvento>Cancelamento</descEvento>` +
		`<nProt>143260000000001</nProt>` +
		`<xJust>` + xJust + `</xJust>` +
		`</detEvento>` +
		`</infEvento>` +
		`</evento>`)
}

func fixtureCCeEventXML(chave string, dhEvento, xCorrecao string, seq int, tpAmb string) []byte {
	return []byte(`<?xml version="1.0" encoding="UTF-8"?>` +
		`<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">` +
		`<infEvento Id="ID110110` + chave + `0` + itoa(seq) + `">` +
		`<cOrgao>43</cOrgao>` +
		`<tpAmb>` + tpAmb + `</tpAmb>` +
		`<CNPJ>05730928000145</CNPJ>` +
		`<chNFe>` + chave + `</chNFe>` +
		`<dhEvento>` + dhEvento + `</dhEvento>` +
		`<tpEvento>110110</tpEvento>` +
		`<nSeqEvento>` + itoa(seq) + `</nSeqEvento>` +
		`<verEvento>1.00</verEvento>` +
		`<detEvento versao="1.00">` +
		`<descEvento>Carta de Correcao</descEvento>` +
		`<xCorrecao>` + xCorrecao + `</xCorrecao>` +
		`<xCondUso>` + nfe.CCeCondicaoUsoText + `</xCondUso>` +
		`</detEvento>` +
		`</infEvento>` +
		`</evento>`)
}

func itoa(i int) string {
	if i < 10 {
		return string(rune('0' + i))
	}
	return string(rune('0'+i/10)) + string(rune('0'+i%10))
}

// fixtureNFeRecord builds a *nfe.NFeRecord whose SignedXML is a
// minimal but parseable NFe — the renderer only reads Ide, Emit, Dest
// fields off TNFe.InfNFe so we keep the fixture minimal. The chave
// argument lets event tests reuse the same chave across the NFe and
// the event row.
func fixtureNFeRecord(chave string) *nfe.NFeRecord {
	signedXML := []byte(`<?xml version="1.0" encoding="UTF-8"?>` +
		`<NFe xmlns="http://www.portalfiscal.inf.br/nfe">` +
		`<infNFe Id="NFe` + chave + `" versao="4.00">` +
		`<ide>` +
		`<cUF>43</cUF><cNF>12345678</cNF><natOp>VENDA</natOp>` +
		`<mod>55</mod><serie>1</serie><nNF>100</nNF>` +
		`<dhEmi>2026-05-06T10:00:00-03:00</dhEmi>` +
		`<tpNF>1</tpNF><idDest>1</idDest><cMunFG>4314902</cMunFG>` +
		`<tpImp>1</tpImp><tpEmis>1</tpEmis><cDV>7</cDV>` +
		`<tpAmb>2</tpAmb><finNFe>1</finNFe><indFinal>1</indFinal>` +
		`<indPres>1</indPres><procEmi>0</procEmi><verProc>sefarius 0.1</verProc>` +
		`</ide>` +
		`<emit>` +
		`<CNPJ>05730928000145</CNPJ>` +
		`<xNome>EMPRESA EVENTO TESTE LTDA</xNome>` +
		`<enderEmit>` +
		`<xLgr>AV TESTE</xLgr><nro>100</nro><xBairro>CENTRO</xBairro>` +
		`<cMun>4314902</cMun><xMun>PORTO ALEGRE</xMun><UF>RS</UF><CEP>90000000</CEP>` +
		`</enderEmit>` +
		`<IE>1234567890</IE><CRT>3</CRT>` +
		`</emit>` +
		`<dest>` +
		`<CNPJ>11444777000161</CNPJ>` +
		`<xNome>CLIENTE EVENTO TESTE LTDA</xNome>` +
		`<enderDest>` +
		`<xLgr>RUA DEST</xLgr><nro>200</nro><xBairro>BAIRRO</xBairro>` +
		`<cMun>4314902</cMun><xMun>PORTO ALEGRE</xMun><UF>RS</UF>` +
		`</enderDest>` +
		`<indIEDest>1</indIEDest><IE>9876543210</IE>` +
		`</dest>` +
		`</infNFe>` +
		`</NFe>`)
	return &nfe.NFeRecord{
		Chave:     nfe.Chave(chave),
		Status:    nfe.NFeStatusAuthorized,
		SignedXML: signedXML,
	}
}

const eventTestChave = "43260505730928000145550010000001005123456787"

// ─── GenerateCancel ─────────────────────────────────────────────────

func TestGenerateCancel_HappyPath(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "cancelamento solicitado pelo cliente", "2"),
	}
	nfeRec := fixtureNFeRecord(eventTestChave)

	pdf, err := gen.GenerateCancel(eventRec, nfeRec)
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Errorf("output does not start with %%PDF- magic: %x", pdf[:8])
	}
	if !bytes.HasSuffix(bytes.TrimRight(pdf, "\r\n"), []byte("%%EOF")) {
		t.Errorf("output does not end with %%EOF marker")
	}
	if len(pdf) < 1000 {
		t.Errorf("PDF suspiciously small (%d bytes)", len(pdf))
	}
}

func TestGenerateCancel_EmbedsCoreFields(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "cancelamento solicitado pelo cliente", "2"),
	}
	nfeRec := fixtureNFeRecord(eventTestChave)

	pdf, err := gen.GenerateCancel(eventRec, nfeRec)
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	mustContain := []string{
		"COMPROVANTE DE CANCELAMENTO DE NF-E",
		"CHAVE DE ACESSO DA NF-E",
		"NF-E CANCELADA",
		"EMPRESA EVENTO TESTE LTDA",
		"CLIENTE EVENTO TESTE LTDA",
		"143260000000999",                       // event protocol
		"06/05/2026 10:30:00",                   // formatted dhEvento
		"cancelamento solicitado pelo cliente", // xJust
		"JUSTIFICATIVA DO CANCELAMENTO",
	}
	for _, needle := range mustContain {
		if !strings.Contains(text, needle) {
			t.Errorf("rendered cancel PDF missing %q", needle)
		}
	}
}

func TestGenerateCancel_HomologationWatermark(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "justificativa qualquer com texto valido", "2"),
	}
	pdf, err := gen.GenerateCancel(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if !strings.Contains(text, "SEM VALOR FISCAL") {
		t.Error("homologation cancel PDF missing SEM VALOR FISCAL watermark")
	}
}

func TestGenerateCancel_ProductionHasNoWatermark(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "justificativa producao", "1"),
	}
	pdf, err := gen.GenerateCancel(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if strings.Contains(text, "SEM VALOR FISCAL") {
		t.Error("production cancel PDF rendered SEM VALOR FISCAL — watermark must only appear in tpAmb=2")
	}
}

func TestGenerateCancel_RejectsBadInputs(t *testing.T) {
	gen := danfe.NewGenerator()
	good := fixtureNFeRecord(eventTestChave)
	goodEvent := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "texto valido", "2"),
	}
	tests := []struct {
		name      string
		eventRec  *nfe.NFeEventRecord
		nfeRec    *nfe.NFeRecord
		wantErrIs error
	}{
		{"nil event", nil, good, danfe.ErrInvalidEventRecord},
		{"nil nfe", goodEvent, nil, danfe.ErrInvalidEventRecord},
		{"empty signed event", &nfe.NFeEventRecord{
			Chave:     eventTestChave,
			EventType: nfe.NFeEventTypeCancel,
		}, good, danfe.ErrInvalidEventRecord},
		{"wrong event type", &nfe.NFeEventRecord{
			Chave:     eventTestChave,
			EventType: nfe.NFeEventTypeCCe,
			SignedXML: []byte("<evento/>"),
		}, good, danfe.ErrInvalidEventRecord},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			_, err := gen.GenerateCancel(tc.eventRec, tc.nfeRec)
			if !errors.Is(err, tc.wantErrIs) {
				t.Errorf("err = %v, want ErrInvalidEventRecord", err)
			}
		})
	}
}

// ─── GenerateCCe ────────────────────────────────────────────────────

func TestGenerateCCe_HappyPath(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCCe,
		NSeq:      1,
		NProt:     "143260000000888",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCCeEventXML(eventTestChave, "2026-05-06T11:00:00-03:00", "Onde se le AV TESTE leia-se RUA TESTE", 1, "2"),
	}
	pdf, err := gen.GenerateCCe(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCCe: %v", err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Errorf("output does not start with %%PDF- magic")
	}
	if len(pdf) < 1000 {
		t.Errorf("PDF suspiciously small (%d bytes)", len(pdf))
	}
}

func TestGenerateCCe_EmbedsCoreFields(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCCe,
		NSeq:      3,
		NProt:     "143260000000888",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCCeEventXML(eventTestChave, "2026-05-06T11:00:00-03:00", "Onde se le AV TESTE leia-se RUA TESTE", 3, "2"),
	}
	pdf, err := gen.GenerateCCe(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCCe: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	mustContain := []string{
		"CARTA DE CORRECAO ELETRONICA",
		"CHAVE DE ACESSO DA NF-E",
		"NF-E DE REFERENCIA",
		"EMPRESA EVENTO TESTE LTDA",
		"143260000000888",                      // event protocol
		"06/05/2026 11:00:00",                  // formatted dhEvento
		"Sequencia: 3",                         // CCe seq surfaces
		"Onde se le AV TESTE leia-se RUA TESTE",
		"CORRECAO",
		"CONDICOES DE USO",
		// Anchor of the SEFAZ-mandated disclaimer — locked in to catch
		// accidental drift from the regulation text.
		"Carta de Correcao",
	}
	for _, needle := range mustContain {
		if !strings.Contains(text, needle) {
			t.Errorf("rendered CCe PDF missing %q", needle)
		}
	}
}

// TestGenerateCancel_RejectedRendersWithStripe locks in the post-review
// fix from sprint 2.2 follow-up: a non-ACCEPTED comprovante must carry
// the "EVENTO NAO ACEITO" stripe AND a footer that does NOT claim the
// XML was authorized by SEFAZ. Without this differentiation a printed
// REJECTED comprovante looks identical to an ACCEPTED one apart from
// the cStat field — easy for an operator to miss when scanning a
// printout.
func TestGenerateCancel_RejectedRendersWithStripe(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "",
		Status:    nfe.EventStatusRejected,
		CStat:     "218",
		XMotivo:   "NFe ja cancelada",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "tentativa de re-cancelamento", "2"),
	}
	pdf, err := gen.GenerateCancel(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if !strings.Contains(text, "EVENTO NAO ACEITO PELA SEFAZ") {
		t.Error("rejected cancel PDF missing EVENTO NAO ACEITO stripe")
	}
	if !strings.Contains(text, "documento sem efeito legal") {
		t.Error("rejected cancel PDF footer missing 'sem efeito legal' disclaimer")
	}
	if strings.Contains(text, "XML autorizado pela SEFAZ") {
		t.Error("rejected cancel PDF must NOT claim XML was authorized — that text is for ACCEPTED only")
	}
}

func TestGenerateCCe_RejectedRendersWithStripe(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCCe,
		NSeq:      1,
		Status:    nfe.EventStatusRejected,
		CStat:     "595",
		XMotivo:   "Sequencia ja utilizada",
		SignedXML: fixtureCCeEventXML(eventTestChave, "2026-05-06T11:00:00-03:00", "tentativa duplicada de seq", 1, "2"),
	}
	pdf, err := gen.GenerateCCe(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCCe: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if !strings.Contains(text, "EVENTO NAO ACEITO PELA SEFAZ") {
		t.Error("rejected CCe PDF missing EVENTO NAO ACEITO stripe")
	}
}

// TestGenerateCancel_AcceptedHasNoRejectionStripe is the explicit
// negative pair to TestGenerateCancel_RejectedRendersWithStripe so a
// future change that flips the stripe condition can't pass with only
// the positive test.
func TestGenerateCancel_AcceptedHasNoRejectionStripe(t *testing.T) {
	gen := danfe.NewGenerator()
	eventRec := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel,
		NSeq:      1,
		NProt:     "143260000000999",
		Status:    nfe.EventStatusAccepted,
		CStat:     "135",
		XMotivo:   "Evento registrado e vinculado a NFe",
		SignedXML: fixtureCancelEventXML(eventTestChave, "2026-05-06T10:30:00-03:00", "cancelado por solicitacao do cliente", "2"),
	}
	pdf, err := gen.GenerateCancel(eventRec, fixtureNFeRecord(eventTestChave))
	if err != nil {
		t.Fatalf("GenerateCancel: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if strings.Contains(text, "EVENTO NAO ACEITO") {
		t.Error("accepted cancel PDF must NOT carry the EVENTO NAO ACEITO stripe")
	}
	if !strings.Contains(text, "XML autorizado pela SEFAZ") {
		t.Error("accepted cancel PDF footer should mention 'XML autorizado pela SEFAZ'")
	}
}

func TestGenerateCCe_RejectsWrongEventType(t *testing.T) {
	gen := danfe.NewGenerator()
	bad := &nfe.NFeEventRecord{
		Chave:     eventTestChave,
		EventType: nfe.NFeEventTypeCancel, // wrong — handler called CCe
		NSeq:      1,
		SignedXML: []byte("<evento/>"),
	}
	_, err := gen.GenerateCCe(bad, fixtureNFeRecord(eventTestChave))
	if !errors.Is(err, danfe.ErrInvalidEventRecord) {
		t.Errorf("err = %v, want ErrInvalidEventRecord", err)
	}
}
