package danfe

import (
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"

	"github.com/go-pdf/fpdf"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/domain/nfe/schema/canc"
	"github.com/sefarius/billing-service/domain/nfe/schema/cce"
)

// Sprint 2.2 — comprovantes PDF for post-issuance events.
//
// Unlike the DANFE-NFe (which has an officially mandated SEFAZ layout
// in the "Manual de Layout do DANFE"), the cancel and CCe events have
// no official PDF spec. Brazilian fiscal-software vendors converged on
// a de-facto pattern: a single-page sheet with the chave + barcode of
// the original NFe, the original-NFe context block, the event protocol
// metadata, and the event body (justificativa for cancel, correção +
// xCondUso for CCe). Sprint 2.2 ships that pattern.
//
// The persisted bytes are the authoritative fiscal source — both
// generators re-parse the stored signed XML rather than reading mutable
// in-memory state.

// ErrInvalidEventRecord is returned when GenerateCancel / GenerateCCe
// receive inputs missing fields the layout depends on (nil records,
// empty SignedXML, mismatched event type, or an NFe record whose
// SignedXML cannot be parsed). Mirrors ErrInvalidNFe in scope: the use
// case layer should validate before calling, but a clean sentinel
// guards against silent blank PDFs.
var ErrInvalidEventRecord = errors.New("danfe: event record is missing fields the comprovante layout requires")

// GenerateCancel renders a "Comprovante de Cancelamento de NF-e" PDF.
// The event record must be the persisted cancel row (eventRec.EventType
// == NFeEventTypeCancel) with non-empty SignedXML; the NFe record
// supplies original-NFe context (emitter, número, série) so the
// printed comprovante stands alone without requiring the reader to
// fetch the NFe separately.
//
// The function does not check Status — a REJECTED cancel still
// produces a comprovante (useful for audit) but the protocol stripe
// reflects the rejection cStat instead of a 135 success.
func (g *Generator) GenerateCancel(eventRec *nfe.NFeEventRecord, nfeRec *nfe.NFeRecord) ([]byte, error) {
	if err := validateEventInputs(eventRec, nfeRec, nfe.NFeEventTypeCancel); err != nil {
		return nil, err
	}

	evt, err := unmarshalCancelEvent(eventRec.SignedXML)
	if err != nil {
		return nil, fmt.Errorf("danfe: parse cancel event: %w", err)
	}
	tnfe, err := nfe.ParseSignedNFe(nfeRec.SignedXML)
	if err != nil {
		return nil, fmt.Errorf("danfe: parse nfe: %w", err)
	}

	pdf := newEventPDF()
	tr := pdf.UnicodeTranslatorFromDescriptor("") // see generator.go for rationale
	if isHomologation(evt.InfEvento.TpAmb) {
		drawHomologationWatermark(pdf)
	}
	drawEventTitle(pdf, "COMPROVANTE DE CANCELAMENTO DE NF-E")
	if eventRec.Status != nfe.EventStatusAccepted {
		drawRejectedStripe(pdf)
	}
	if err := drawChaveBlock(pdf, string(eventRec.Chave)); err != nil {
		return nil, err
	}
	drawNFeContext(pdf, tnfe.InfNFe, "NF-E CANCELADA", tr)
	drawEventProtocolBlock(pdf, eventRec, evt.InfEvento.DhEvento, tr)
	drawCancelBody(pdf, evt.InfEvento.DetEvento, tr)
	drawComprovanteFooter(pdf, eventRec.Status)

	return finalizePDF(pdf)
}

// GenerateCCe renders a "Comprovante de Carta de Correção Eletrônica"
// PDF. eventRec must be a CCe row (NFeEventTypeCCe) with a non-empty
// SignedXML. The fixed legal disclaimer (xCondUso) is rendered in a
// smaller font at the bottom because every CCe carries the same text
// — it must be visible on the printed comprovante for legal validity
// but it is not the operationally interesting part.
func (g *Generator) GenerateCCe(eventRec *nfe.NFeEventRecord, nfeRec *nfe.NFeRecord) ([]byte, error) {
	if err := validateEventInputs(eventRec, nfeRec, nfe.NFeEventTypeCCe); err != nil {
		return nil, err
	}

	evt, err := unmarshalCCeEvent(eventRec.SignedXML)
	if err != nil {
		return nil, fmt.Errorf("danfe: parse cce event: %w", err)
	}
	tnfe, err := nfe.ParseSignedNFe(nfeRec.SignedXML)
	if err != nil {
		return nil, fmt.Errorf("danfe: parse nfe: %w", err)
	}

	pdf := newEventPDF()
	tr := pdf.UnicodeTranslatorFromDescriptor("") // see generator.go for rationale
	if isHomologation(evt.InfEvento.TpAmb) {
		drawHomologationWatermark(pdf)
	}
	drawEventTitle(pdf, "CARTA DE CORRECAO ELETRONICA")
	if eventRec.Status != nfe.EventStatusAccepted {
		drawRejectedStripe(pdf)
	}
	if err := drawChaveBlock(pdf, string(eventRec.Chave)); err != nil {
		return nil, err
	}
	drawNFeContext(pdf, tnfe.InfNFe, "NF-E DE REFERENCIA", tr)
	drawEventProtocolBlock(pdf, eventRec, evt.InfEvento.DhEvento, tr)
	drawCCeBody(pdf, evt.InfEvento.DetEvento, tr)
	drawComprovanteFooter(pdf, eventRec.Status)

	return finalizePDF(pdf)
}

// ─── Validation ────────────────────────────────────────────────────

func validateEventInputs(eventRec *nfe.NFeEventRecord, nfeRec *nfe.NFeRecord, expected nfe.NFeEventType) error {
	if eventRec == nil || nfeRec == nil {
		return ErrInvalidEventRecord
	}
	if eventRec.EventType != expected {
		return ErrInvalidEventRecord
	}
	if len(eventRec.SignedXML) == 0 || len(nfeRec.SignedXML) == 0 {
		return ErrInvalidEventRecord
	}
	if string(eventRec.Chave) == "" {
		return ErrInvalidEventRecord
	}
	return nil
}

// ─── PDF lifecycle ─────────────────────────────────────────────────

func newEventPDF() *fpdf.Fpdf {
	pdf := fpdf.New("P", "mm", "A4", "")
	pdf.SetMargins(10, 10, 10)
	pdf.SetAutoPageBreak(true, 15)
	pdf.AddPage()
	return pdf
}

func finalizePDF(pdf *fpdf.Fpdf) ([]byte, error) {
	if pdf.Err() {
		return nil, fmt.Errorf("danfe: pdf builder error: %w", pdf.Error())
	}
	var buf bytes.Buffer
	if err := pdf.Output(&buf); err != nil {
		return nil, fmt.Errorf("danfe: pdf output: %w", err)
	}
	return buf.Bytes(), nil
}

// ─── Drawing primitives ────────────────────────────────────────────

func drawEventTitle(pdf *fpdf.Fpdf, title string) {
	pdf.SetFont("Helvetica", "B", 11)
	pdf.SetXY(10, 10)
	pdf.CellFormat(190, 7, title, "1", 1, "C", false, 0, "")
}

// drawRejectedStripe is the cancel/CCe analog of the DANFE-NFe
// "NAO AUTORIZADA" banner: a red horizontal bar that makes a
// non-ACCEPTED comprovante visually distinct from an authorized one
// at a glance. Without it, a printed REJECTED comprovante looks
// nearly identical to an ACCEPTED one — only the cStat field differs,
// which a reader scanning the page can easily miss.
func drawRejectedStripe(pdf *fpdf.Fpdf) {
	pdf.SetFont("Helvetica", "B", 10)
	pdf.SetTextColor(180, 0, 0)
	pdf.CellFormat(190, 6, "EVENTO NAO ACEITO PELA SEFAZ - SEM EFEITO LEGAL", "1", 1, "C", false, 0, "")
	pdf.SetTextColor(0, 0, 0)
}

// drawChaveBlock renders the 44-digit chave as the grouped human
// label plus a Code-128 barcode underneath. The barcode is what
// downstream fiscal scanners read; a chave without a scannable
// barcode breaks the audit trail.
func drawChaveBlock(pdf *fpdf.Fpdf, chave string) error {
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, "CHAVE DE ACESSO DA NF-E", "LR", 1, "L", false, 0, "")
	pdf.SetFont("Courier", "", 9)
	pdf.CellFormat(190, 6, formatChave(chave), "LR", 1, "C", false, 0, "")

	barcodeBytes, err := buildCode128(chave)
	if err != nil {
		return fmt.Errorf("danfe: chave barcode: %w", err)
	}
	pngOpts := fpdf.ImageOptions{ImageType: "PNG"}
	barcodeY := pdf.GetY() + 1
	pdf.RegisterImageOptionsReader("event-chave-barcode", pngOpts, bytes.NewReader(barcodeBytes))
	pdf.ImageOptions("event-chave-barcode", 30, barcodeY, 150, 12, false, pngOpts, 0, "")
	pdf.SetY(barcodeY + 14)
	// Close the chave block with a bottom rule.
	pdf.CellFormat(190, 0, "", "T", 1, "", false, 0, "")
	return nil
}

// drawNFeContext renders the original-NFe identification block. Title
// varies by event flavor ("NF-E CANCELADA" vs "NF-E DE REFERENCIA").
// The block intentionally lists only the human-readable fields a
// reader scanning the comprovante actually checks against the
// original NFe — full-detail information lives in the DANFE-NFe.
func drawNFeContext(pdf *fpdf.Fpdf, inf *schema.InfNFe, title string, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, title, "1", 1, "L", false, 0, "")

	pdf.SetFont("Helvetica", "", 8)
	if inf == nil {
		pdf.CellFormat(190, 5, "(dados da NF-e indisponiveis)", "LRB", 1, "L", false, 0, "")
		return
	}

	if inf.Ide != nil {
		pdf.CellFormat(60, 5, "Numero: "+inf.Ide.NNF, "L", 0, "L", false, 0, "")
		pdf.CellFormat(60, 5, "Serie: "+inf.Ide.Serie, "", 0, "L", false, 0, "")
		pdf.CellFormat(70, 5, "Emissao: "+formatDhEvento(inf.Ide.DhEmi), "R", 1, "L", false, 0, "")
	}
	if inf.Emit != nil {
		pdf.CellFormat(120, 5, "Emitente: "+tr(inf.Emit.XNome), "L", 0, "L", false, 0, "")
		pdf.CellFormat(70, 5, "CNPJ: "+derefStr(inf.Emit.CNPJ), "R", 1, "L", false, 0, "")
	}
	if inf.Dest != nil {
		doc := derefStr(inf.Dest.CNPJ)
		docLabel := "CNPJ"
		if doc == "" {
			doc = derefStr(inf.Dest.CPF)
			docLabel = "CPF"
		}
		pdf.CellFormat(120, 5, "Destinatario: "+tr(derefStr(inf.Dest.XNome)), "L", 0, "L", false, 0, "")
		pdf.CellFormat(70, 5, docLabel+": "+doc, "R", 1, "L", false, 0, "")
	}
	pdf.CellFormat(190, 0, "", "T", 1, "", false, 0, "")
}

// drawEventProtocolBlock renders the SEFAZ-side metadata: when the
// event was issued, the SEFAZ protocol number, and the cStat motive.
// dhEventoStr is the issuer-side timestamp pulled from the signed
// evento (canonical AAAA-MM-DDThh:mm:ssTZD format); the persisted
// OccurredAt would also work but the in-XML value is what SEFAZ
// processed and is the natural source of truth.
func drawEventProtocolBlock(pdf *fpdf.Fpdf, rec *nfe.NFeEventRecord, dhEventoStr string, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, "EVENTO", "1", 1, "L", false, 0, "")

	pdf.SetFont("Helvetica", "", 8)
	pdf.CellFormat(95, 5, "Data/Hora do evento: "+formatDhEvento(dhEventoStr), "L", 0, "L", false, 0, "")
	pdf.CellFormat(95, 5, "Sequencia: "+strconv.Itoa(rec.NSeq), "R", 1, "L", false, 0, "")

	pdf.CellFormat(95, 5, "Protocolo do evento: "+rec.NProt, "L", 0, "L", false, 0, "")
	// XMotivo carries SEFAZ messages with accents ("Evento registrado e
	// vinculado à NF-e"); pass through the translator. The "Status: " /
	// numeric cStat prefix is ASCII and could be left as-is, but
	// translating ASCII is a no-op so we keep the call simple.
	pdf.CellFormat(95, 5, tr("Status: "+rec.CStat+" - "+rec.XMotivo), "R", 1, "L", false, 0, "")
	pdf.CellFormat(190, 0, "", "T", 1, "", false, 0, "")
}

func drawCancelBody(pdf *fpdf.Fpdf, det *canc.DetEvento, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, "JUSTIFICATIVA DO CANCELAMENTO", "1", 1, "L", false, 0, "")

	pdf.SetFont("Helvetica", "", 9)
	xJust := ""
	if det != nil && det.XJust != nil {
		xJust = string(*det.XJust)
	}
	pdf.MultiCell(190, 5, tr(xJust), "LRB", "L", false)
}

func drawCCeBody(pdf *fpdf.Fpdf, det *cce.DetEvento, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, "CORRECAO", "1", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 9)
	xCorrecao := ""
	if det != nil {
		xCorrecao = det.XCorrecao
	}
	pdf.MultiCell(190, 5, tr(xCorrecao), "LRB", "L", false)

	// xCondUso — fixed legal disclaimer SEFAZ requires every CCe to
	// carry. Smaller font because the text is the same on every CCe
	// and the operationally interesting block is xCorrecao above.
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 7)
	pdf.CellFormat(190, 4, "CONDICOES DE USO", "1", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 7)
	xCondUso := ""
	if det != nil {
		xCondUso = det.XCondUso
	}
	pdf.MultiCell(190, 3.2, tr(xCondUso), "LRB", "J", false)
}

// drawComprovanteFooter prints the disclaimer line. The text differs
// for ACCEPTED vs non-ACCEPTED events because "XML autorizado pela
// SEFAZ" would be a lie on a rejection comprovante — these documents
// are persisted for audit but the wire-side outcome was a refusal,
// not an authorization.
func drawComprovanteFooter(pdf *fpdf.Fpdf, status nfe.EventStatus) {
	pdf.Ln(3)
	pdf.SetFont("Helvetica", "I", 7)
	text := "Comprovante gerado a partir do XML autorizado pela SEFAZ. Em caso de duvida, consulte o XML original."
	if status != nfe.EventStatusAccepted {
		text = "Comprovante gerado a partir do XML do evento submetido. Evento NAO foi aceito pela SEFAZ - documento sem efeito legal, mantido apenas para auditoria."
	}
	pdf.CellFormat(190, 4, text, "", 1, "L", false, 0, "")
}

// ─── XML decoding helpers ──────────────────────────────────────────

// unmarshalCancelEvent decodes the persisted SignedXML (a signed
// <evento> element) into a typed canc.TEvento. The <ds:Signature>
// child is ignored — the renderer reads only typed fields off
// InfEvento.DetEvento, and a signature parse failure should not block
// the comprovante since the bytes themselves are the legally valid
// blob. Callers with strict signature requirements use VerifySignature
// upstream.
func unmarshalCancelEvent(b []byte) (*canc.TEvento, error) {
	dec := xml.NewDecoder(bytes.NewReader(b))
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			return nil, errors.New("evento element not found in signed XML")
		}
		if err != nil {
			return nil, fmt.Errorf("decode token: %w", err)
		}
		start, ok := tok.(xml.StartElement)
		if !ok || start.Name.Local != "evento" {
			continue
		}
		evt := &canc.TEvento{}
		if err := dec.DecodeElement(evt, &start); err != nil {
			return nil, fmt.Errorf("decode evento: %w", err)
		}
		if evt.InfEvento == nil {
			return nil, errors.New("evento has no infEvento")
		}
		return evt, nil
	}
}

func unmarshalCCeEvent(b []byte) (*cce.TEvento, error) {
	dec := xml.NewDecoder(bytes.NewReader(b))
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			return nil, errors.New("evento element not found in signed XML")
		}
		if err != nil {
			return nil, fmt.Errorf("decode token: %w", err)
		}
		start, ok := tok.(xml.StartElement)
		if !ok || start.Name.Local != "evento" {
			continue
		}
		evt := &cce.TEvento{}
		if err := dec.DecodeElement(evt, &start); err != nil {
			return nil, fmt.Errorf("decode evento: %w", err)
		}
		if evt.InfEvento == nil {
			return nil, errors.New("evento has no infEvento")
		}
		return evt, nil
	}
}

// formatDhEvento normalizes a SEFAZ AAAA-MM-DDThh:mm:ssTZD timestamp
// into the "DD/MM/YYYY HH:MM:SS" form humans read off the
// comprovante. Returns the input unchanged when the format does not
// match — better to print the raw value than to swallow a malformed
// input. The 19-char prefix check keeps this allocation-free; the
// timestamp shape SEFAZ emits is fixed-width so anything shorter is
// not a valid dhEvento we should be reformatting.
func formatDhEvento(s string) string {
	if len(s) < 19 {
		return s
	}
	// Expect: 2026-05-06T10:30:00-03:00 — slice positions are stable.
	year, month, day := s[0:4], s[5:7], s[8:10]
	hour, minute, second := s[11:13], s[14:16], s[17:19]
	if !allDigits(year) || !allDigits(month) || !allDigits(day) ||
		!allDigits(hour) || !allDigits(minute) || !allDigits(second) {
		return s
	}
	var b strings.Builder
	b.Grow(19)
	b.WriteString(day)
	b.WriteByte('/')
	b.WriteString(month)
	b.WriteByte('/')
	b.WriteString(year)
	b.WriteByte(' ')
	b.WriteString(hour)
	b.WriteByte(':')
	b.WriteString(minute)
	b.WriteByte(':')
	b.WriteString(second)
	return b.String()
}

func allDigits(s string) bool {
	for i := 0; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}
