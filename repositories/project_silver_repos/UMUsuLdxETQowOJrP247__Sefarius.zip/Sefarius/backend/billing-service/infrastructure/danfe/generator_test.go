package danfe_test

import (
	"bytes"
	"compress/zlib"
	"errors"
	"io"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
	"github.com/sefarius/billing-service/infrastructure/danfe"
)

func strPtr(s string) *string { return &s }

// fixtureNFe assembles a baseline single-item NF-e in homologation,
// the same shape the rest of the suite uses. Duplicated here rather
// than imported because nfe_test and application_test are
// internal-only; duplicating keeps fixture independence so a layout
// change in DANFE does not transitively pull builder helpers along.
func fixtureNFe(t *testing.T) *schema.TNFe {
	t.Helper()
	cnpj := "05730928000145"
	cMun := "4314902"

	det, err := nfe.NewDetRegimeNormalCST00(
		&schema.Prod{
			CProd: "001", CEAN: "SEM GTIN", XProd: "PRODUTO DANFE TESTE",
			NCM: "22021000", CFOP: "5102", UCom: "UN",
			QCom: "1.0000", VUnCom: "100.0000000000", VProd: "100.00",
			CEANTrib: "SEM GTIN", UTrib: "UN", QTrib: "1.0000",
			VUnTrib: "100.0000000000", IndTot: "1",
		},
		"100.00", "18.00", "1.65", "7.60",
	)
	if err != nil {
		t.Fatalf("NewDetRegimeNormalCST00: %v", err)
	}
	tnfe, err := nfe.New().
		Ide(&schema.Ide{
			CUF: "43", CNF: "12345678", NatOp: "VENDA DE MERCADORIA",
			Mod: "55", Serie: "1", NNF: "100",
			DhEmi: "2026-05-06T10:00:00-03:00", TpNF: "1",
			IdDest: "1", CMunFG: cMun, TpImp: "1",
			TpEmis: "1", TpAmb: "2",
			FinNFe: "1", IndFinal: "1", IndPres: "1",
			ProcEmi: "0", VerProc: "sefarius 0.1",
		}).
		Emit(&schema.Emit{
			CNPJ: &cnpj, XNome: "EMPRESA DANFE TESTE LTDA",
			EnderEmit: &schema.TEnderEmi{
				XLgr: "AV TESTE", Nro: "100", XBairro: "CENTRO",
				CMun: cMun, XMun: "PORTO ALEGRE", UF: "RS", CEP: "90000000",
			},
			IE: "1234567890", CRT: "3",
		}).
		Dest(&schema.Dest{
			CNPJ: strPtr("11444777000161"),
			XNome: strPtr("CLIENTE DANFE TESTE LTDA"),
			EnderDest: &schema.TEndereco{
				XLgr: "RUA EXEMPLO", Nro: "200", XBairro: "BAIRRO",
				CMun: cMun, XMun: "PORTO ALEGRE", UF: "RS", CEP: strPtr("90000001"),
			},
			IndIEDest: "1", IE: strPtr("9876543210"),
		}).
		AddDet(det).
		Total(&schema.Total{
			ICMSTot: &schema.ICMSTot{
				VBC: "100.00", VICMS: "18.00", VICMSDeson: "0.00",
				VFCP: "0.00", VBCST: "0.00", VST: "0.00",
				VFCPST: "0.00", VFCPSTRet: "0.00",
				VProd: "100.00", VPIS: "1.65", VCOFINS: "7.60",
				VNF: "100.00",
			},
		}).
		Transp(&schema.Transp{ModFrete: "9"}).
		Pag(&schema.Pag{DetPag: []*schema.DetPag{{TPag: "01", VPag: "100.00"}}}).
		Build()
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	return tnfe
}

// readPDFTextStreams flattens the PDF, decompressing any FlateDecode
// streams it finds, so test assertions can search for plain text the
// layout placed in the document. Real PDF text-extraction libraries
// would be sturdier, but for assertion-style tests against a known
// generator output a streaming flate-decode pass is enough.
func readPDFTextStreams(t *testing.T, raw []byte) string {
	t.Helper()
	streamRe := regexp.MustCompile(`(?s)stream\r?\n(.*?)\r?\nendstream`)
	var out bytes.Buffer
	out.Write(raw) // include uncompressed parts (text not always in flate streams)
	for _, m := range streamRe.FindAllSubmatch(raw, -1) {
		zr, err := zlib.NewReader(bytes.NewReader(m[1]))
		if err != nil {
			continue // not a flate stream — image, or already inline
		}
		decoded, err := io.ReadAll(zr)
		_ = zr.Close()
		if err == nil {
			out.Write(decoded)
		}
	}
	return out.String()
}

func TestGenerator_HappyPathProducesValidPDF(t *testing.T) {
	gen := danfe.NewGenerator()
	protocol := &nfe.Protocol{
		NProt:    "143260000000001",
		DhRecbto: time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
		ChNFe:    "43260505730928000145550010000001001123456787",
		DigVal:   "tJ+U83jDZVbAaMs1RoAL3nCaxh0=",
		CStat:    "100",
		XMotivo:  "Autorizado o uso da NF-e",
		TpAmb:    "2",
	}

	pdf, err := gen.Generate(fixtureNFe(t), protocol)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Errorf("output does not start with %%PDF- magic: %x", pdf[:8])
	}
	if !bytes.HasSuffix(bytes.TrimRight(pdf, "\r\n"), []byte("%%EOF")) {
		t.Errorf("output does not end with %%EOF marker")
	}
	if len(pdf) < 1000 {
		t.Errorf("PDF suspiciously small (%d bytes)", len(pdf))
	}
}

func TestGenerator_EmbedsCoreFields(t *testing.T) {
	gen := danfe.NewGenerator()
	protocol := &nfe.Protocol{
		NProt:    "143260000000042",
		DhRecbto: time.Date(2026, 5, 6, 10, 0, 0, 0, time.UTC),
	}
	pdf, err := gen.Generate(fixtureNFe(t), protocol)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}

	text := readPDFTextStreams(t, pdf)
	mustContain := []string{
		"DANFE",
		"CHAVE DE ACESSO",
		"EMPRESA DANFE TESTE LTDA",
		"CLIENTE DANFE TESTE LTDA",
		"PRODUTO DANFE TESTE",
		"143260000000042", // protocol number
	}
	for _, needle := range mustContain {
		if !strings.Contains(text, needle) {
			t.Errorf("rendered DANFE missing %q", needle)
		}
	}
}

// TestGenerator_HomologationWatermarkPresent locks in the safety
// stamp. A homologation DANFE without "SEM VALOR FISCAL" can be
// confused with a production document, which is exactly the failure
// SEFAZ rejection 252 punishes on the wire side.
func TestGenerator_HomologationWatermarkPresent(t *testing.T) {
	gen := danfe.NewGenerator()
	pdf, err := gen.Generate(fixtureNFe(t), nil)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if !strings.Contains(text, "SEM VALOR FISCAL") {
		t.Error("homologation DANFE missing SEM VALOR FISCAL watermark")
	}
}

func TestGenerator_ProductionHasNoWatermark(t *testing.T) {
	gen := danfe.NewGenerator()
	tnfe := fixtureNFe(t)
	tnfe.InfNFe.Ide.TpAmb = "1" // production
	pdf, err := gen.Generate(tnfe, nil)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if strings.Contains(text, "SEM VALOR FISCAL") {
		t.Error("production DANFE rendered SEM VALOR FISCAL watermark — must only appear in tpAmb=2")
	}
}

func TestGenerator_NilProtocolRendersNotAuthorized(t *testing.T) {
	gen := danfe.NewGenerator()
	pdf, err := gen.Generate(fixtureNFe(t), nil)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	if !strings.Contains(text, "NAO AUTORIZADA") {
		t.Error("DANFE with nil protocol must announce NAO AUTORIZADA so a printed copy can't be mistaken for a valid one")
	}
}

func TestGenerator_RejectsIncompleteNFe(t *testing.T) {
	gen := danfe.NewGenerator()
	tests := []struct {
		name string
		nfe  *schema.TNFe
	}{
		{"nil tnfe", nil},
		{"nil InfNFe", &schema.TNFe{}},
		{"nil Ide", &schema.TNFe{InfNFe: &schema.InfNFe{Emit: &schema.Emit{}, Det: []*schema.Det{{}}}}},
		{"nil Emit", &schema.TNFe{InfNFe: &schema.InfNFe{Ide: &schema.Ide{}, Det: []*schema.Det{{}}}}},
		{"empty Det", &schema.TNFe{InfNFe: &schema.InfNFe{Ide: &schema.Ide{}, Emit: &schema.Emit{}}}},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			_, err := gen.Generate(tc.nfe, nil)
			if !errors.Is(err, danfe.ErrInvalidNFe) {
				t.Errorf("err = %v, want ErrInvalidNFe", err)
			}
		})
	}
}

func TestGenerator_MultipleItemsAllRendered(t *testing.T) {
	gen := danfe.NewGenerator()
	tnfe := fixtureNFe(t)

	for i := 2; i <= 5; i++ {
		extra, err := nfe.NewDetRegimeNormalCST00(
			&schema.Prod{
				CProd: "00" + string(rune('0'+i)),
				CEAN:  "SEM GTIN",
				XProd: "ITEM EXTRA " + string(rune('0'+i)),
				NCM:   "22021000", CFOP: "5102", UCom: "UN",
				QCom: "1.0000", VUnCom: "10.0000000000", VProd: "10.00",
				CEANTrib: "SEM GTIN", UTrib: "UN", QTrib: "1.0000",
				VUnTrib: "10.0000000000", IndTot: "1",
			},
			"10.00", "18.00", "1.65", "7.60",
		)
		if err != nil {
			t.Fatalf("NewDet: %v", err)
		}
		tnfe.InfNFe.Det = append(tnfe.InfNFe.Det, extra)
	}

	pdf, err := gen.Generate(tnfe, nil)
	if err != nil {
		t.Fatalf("Generate: %v", err)
	}
	text := readPDFTextStreams(t, pdf)
	for i := 2; i <= 5; i++ {
		needle := "ITEM EXTRA " + string(rune('0'+i))
		if !strings.Contains(text, needle) {
			t.Errorf("rendered DANFE missing item description %q", needle)
		}
	}
}
