// Package danfe renders a *schema.TNFe + nfe.Protocol pair as a
// human-readable PDF — the DANFE (Documento Auxiliar da Nota Fiscal
// Eletronica) that travels with the goods or is delivered to the
// recipient.
//
// Scope of sprint 1.7: a recognizable A4 layout containing the fields
// the SEFAZ "Manual de Layout do DANFE" treats as mandatory —
// identification block, chave + Code-128 barcode, emitter, recipient,
// items table, totals, authorization protocol, and the homologation
// watermark when tpAmb=2. Pixel-perfect compliance with SEFAZ's exact
// box positions is not the goal here; the visual layout is meant to
// look like a DANFE without being one a fiscal auditor would accept
// in lieu of the official template. Polish lands in a later sprint.
package danfe

import (
	"bytes"
	"errors"
	"fmt"
	"image/png"
	"strings"

	"github.com/boombuler/barcode"
	"github.com/boombuler/barcode/code128"
	"github.com/go-pdf/fpdf"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/domain/nfe/schema"
)

// Generator renders DANFEs. The struct is empty for now — keeping it
// as a struct rather than a free function leaves room for future
// configuration (logo bytes, font choice, paper size) without breaking
// callers.
type Generator struct{}

// NewGenerator returns a Generator with default settings.
func NewGenerator() *Generator { return &Generator{} }

// ErrInvalidNFe is returned when the input is missing required fields
// the DANFE layout depends on (InfNFe, Ide, Emit, Det). The use case
// layer validates before signing, so a Generator caller should not
// see this in practice; we surface it as a sentinel anyway because a
// silent blank PDF would be a worse failure mode.
var ErrInvalidNFe = errors.New("danfe: NF-e is missing fields the DANFE layout requires")

// Generate renders the DANFE for the given NF-e and authorization
// protocol. Pass protocol=nil to render a "NAO AUTORIZADA" DANFE
// useful for previewing or for the contestation flow; the layout is
// otherwise identical.
func (g *Generator) Generate(tnfe *schema.TNFe, protocol *nfe.Protocol) ([]byte, error) {
	if tnfe == nil || tnfe.InfNFe == nil || tnfe.InfNFe.Ide == nil || tnfe.InfNFe.Emit == nil || len(tnfe.InfNFe.Det) == 0 {
		return nil, ErrInvalidNFe
	}

	pdf := fpdf.New("P", "mm", "A4", "")
	pdf.SetMargins(10, 10, 10)
	pdf.SetAutoPageBreak(true, 15)
	pdf.AddPage()

	// gofpdf's built-in fonts (Helvetica, Courier) are CP1252-encoded —
	// passing raw UTF-8 emits mojibake ("São Paulo" → "SÃ£o Paulo")
	// because each multi-byte UTF-8 sequence is rendered as multiple
	// CP1252 glyphs. The descriptor-based translator maps UTF-8 → CP1252
	// for the Latin-1 character set, which covers all Portuguese
	// diacritics that appear on a Brazilian DANFE (á, é, ã, ç, ó, etc).
	// Wrap every user-provided string (XNome, XLgr, XProd, XMotivo, ...)
	// before feeding it to CellFormat.
	tr := pdf.UnicodeTranslatorFromDescriptor("")

	chave := strings.TrimPrefix(tnfe.InfNFe.IdAttr, "NFe")

	if isHomologation(tnfe.InfNFe.Ide.TpAmb) {
		drawHomologationWatermark(pdf)
	}

	if err := drawHeader(pdf, tnfe.InfNFe, chave, protocol, tr); err != nil {
		return nil, err
	}
	drawEmitter(pdf, tnfe.InfNFe.Emit, tr)
	drawRecipient(pdf, tnfe.InfNFe.Dest, tr)
	drawItems(pdf, tnfe.InfNFe.Det, tr)
	if tnfe.InfNFe.Total != nil && tnfe.InfNFe.Total.ICMSTot != nil {
		drawTotals(pdf, tnfe.InfNFe.Total.ICMSTot)
	}
	drawProtocolFooter(pdf, protocol, tr)

	if pdf.Err() {
		return nil, fmt.Errorf("danfe: pdf builder error: %w", pdf.Error())
	}

	var buf bytes.Buffer
	if err := pdf.Output(&buf); err != nil {
		return nil, fmt.Errorf("danfe: pdf output: %w", err)
	}
	return buf.Bytes(), nil
}

// drawHomologationWatermark prints the diagonal "SEM VALOR FISCAL"
// stamp every DANFE issued in the homologation environment must
// carry. Without it, a homologation PDF could be mistaken for a real
// fiscal document — which is exactly the failure mode SEFAZ rejection
// 252 exists to catch on the wire side.
func drawHomologationWatermark(pdf *fpdf.Fpdf) {
	pdf.SetTextColor(220, 220, 220)
	pdf.SetFont("Helvetica", "B", 60)
	pdf.TransformBegin()
	pdf.TransformRotate(45, 105, 148)
	pdf.SetXY(20, 130)
	pdf.CellFormat(170, 20, "SEM VALOR FISCAL", "", 0, "C", false, 0, "")
	pdf.TransformEnd()
	pdf.SetTextColor(0, 0, 0)
}

func drawHeader(pdf *fpdf.Fpdf, inf *schema.InfNFe, chave string, protocol *nfe.Protocol, tr func(string) string) error {
	const startY = 10.0
	pdf.SetFont("Helvetica", "B", 10)
	pdf.SetXY(10, startY)
	pdf.CellFormat(190, 6, "DANFE - Documento Auxiliar da Nota Fiscal Eletronica", "1", 1, "C", false, 0, "")

	// Operation direction (Entrada/Saida) inferred from ide.TpNF: "0"=entrada, "1"=saida
	opDir := "SAIDA"
	if inf.Ide.TpNF == "0" {
		opDir = "ENTRADA"
	}
	// Ambient line — labels the environment the NF-e was authorized in
	// so a printed DANFE can't be mistaken for a different environment's
	// document. Printed even on the unauthorized branch (preview/contestation).
	ambLabel := "PRODUCAO"
	if isHomologation(inf.Ide.TpAmb) {
		ambLabel = "HOMOLOGACAO"
	}
	pdf.SetFont("Helvetica", "", 8)
	pdf.CellFormat(50, 5, "Operacao: "+opDir, "L", 0, "L", false, 0, "")
	pdf.CellFormat(45, 5, "Ambiente: "+ambLabel, "", 0, "L", false, 0, "")
	pdf.CellFormat(45, 5, "Serie: "+inf.Ide.Serie, "", 0, "L", false, 0, "")
	pdf.CellFormat(50, 5, "NF-e n.: "+inf.Ide.NNF, "R", 1, "L", false, 0, "")

	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 5, "CHAVE DE ACESSO", "LR", 1, "L", false, 0, "")
	pdf.SetFont("Courier", "", 9)
	pdf.CellFormat(190, 6, formatChave(chave), "LRB", 1, "C", false, 0, "")

	// Code-128 barcode of the chave — the strip every fiscal scanner
	// reads. A DANFE without a scannable barcode breaks downstream
	// logistics, so a barcode failure aborts the render rather than
	// silently producing a barcode-less PDF.
	barcodeBytes, err := buildCode128(chave)
	if err != nil {
		return fmt.Errorf("danfe: chave barcode: %w", err)
	}
	pngOpts := fpdf.ImageOptions{ImageType: "PNG"}
	barcodeY := pdf.GetY() + 1
	pdf.RegisterImageOptionsReader("chave-barcode", pngOpts, bytes.NewReader(barcodeBytes))
	pdf.ImageOptions("chave-barcode", 30, barcodeY, 150, 12, false, pngOpts, 0, "")
	pdf.SetY(barcodeY + 14)

	// Protocol stripe — visible separation between issued NF-e and
	// authorized NF-e is what distinguishes a "rascunho" from a
	// fiscally valid document at a glance.
	pdf.SetFont("Helvetica", "B", 8)
	if protocol != nil {
		pdf.CellFormat(190, 5,
			fmt.Sprintf("PROTOCOLO DE AUTORIZACAO DE USO: %s  -  %s",
				protocol.NProt, protocol.DhRecbto.Format("02/01/2006 15:04:05")),
			"1", 1, "C", false, 0, "")
	} else {
		pdf.SetTextColor(180, 0, 0)
		pdf.CellFormat(190, 5, "NAO AUTORIZADA - SEM PROTOCOLO SEFAZ", "1", 1, "C", false, 0, "")
		pdf.SetTextColor(0, 0, 0)
	}
	return nil
}

func drawEmitter(pdf *fpdf.Fpdf, emit *schema.Emit, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 4, "EMITENTE", "1", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 8)
	pdf.CellFormat(120, 5, "Razao social: "+tr(emit.XNome), "L", 0, "L", false, 0, "")
	pdf.CellFormat(70, 5, "CNPJ: "+derefStr(emit.CNPJ), "R", 1, "L", false, 0, "")
	if e := emit.EnderEmit; e != nil {
		addr := fmt.Sprintf("%s, %s - %s, %s/%s, CEP: %s",
			e.XLgr, e.Nro, e.XBairro, e.XMun, e.UF, e.CEP)
		pdf.CellFormat(190, 5, tr(addr), "LRB", 1, "L", false, 0, "")
	}
}

func drawRecipient(pdf *fpdf.Fpdf, dest *schema.Dest, tr func(string) string) {
	if dest == nil {
		return
	}
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 4, "DESTINATARIO", "1", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 8)
	doc := derefStr(dest.CNPJ)
	docLabel := "CNPJ"
	if doc == "" {
		doc = derefStr(dest.CPF)
		docLabel = "CPF"
	}
	pdf.CellFormat(120, 5, "Nome: "+tr(derefStr(dest.XNome)), "L", 0, "L", false, 0, "")
	pdf.CellFormat(70, 5, docLabel+": "+doc, "R", 1, "L", false, 0, "")
	if e := dest.EnderDest; e != nil {
		addr := fmt.Sprintf("%s, %s - %s, %s/%s, CEP: %s",
			e.XLgr, e.Nro, e.XBairro, e.XMun, e.UF, derefStr(e.CEP))
		pdf.CellFormat(190, 5, tr(addr), "LRB", 1, "L", false, 0, "")
	}
}

func drawItems(pdf *fpdf.Fpdf, items []*schema.Det, tr func(string) string) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 4, "DADOS DO PRODUTO/SERVICO", "1", 1, "L", false, 0, "")

	pdf.SetFont("Helvetica", "B", 7)
	// Column widths must sum to 190 (page minus margins). Code grew
	// from 15→24mm to fit codes like "TESTE-CLAUDE-01" without
	// overflowing into the description cell; description shrank
	// 75→66mm to compensate. Long descriptions still get clipped by
	// the cell border (gofpdf draws right edge over content) which
	// is acceptable — the full data lives in the XML for queries.
	headers := []struct {
		w     float64
		label string
		align string
	}{
		{24, "Codigo", "L"},
		{66, "Descricao", "L"},
		{15, "NCM", "L"},
		{12, "CFOP", "L"},
		{10, "Un", "C"},
		{15, "Qtd", "R"},
		{20, "Vl. Unit.", "R"},
		{28, "Vl. Total", "R"},
	}
	for _, h := range headers {
		pdf.CellFormat(h.w, 5, h.label, "1", 0, h.align, false, 0, "")
	}
	pdf.Ln(-1)

	pdf.SetFont("Helvetica", "", 7)
	for _, det := range items {
		if det == nil || det.Prod == nil {
			continue
		}
		p := det.Prod
		row := []struct {
			w     float64
			text  string
			align string
		}{
			{24, p.CProd, "L"},
			{66, p.XProd, "L"},
			{15, p.NCM, "L"},
			{12, p.CFOP, "L"},
			{10, p.UCom, "C"},
			{15, p.QCom, "R"},
			{20, p.VUnCom, "R"},
			{28, p.VProd, "R"},
		}
		for _, c := range row {
			pdf.CellFormat(c.w, 4, tr(c.text), "LR", 0, c.align, false, 0, "")
		}
		pdf.Ln(-1)
	}
	// close the table with a bottom border on the last row
	pdf.CellFormat(190, 0, "", "T", 1, "", false, 0, "")
}

func drawTotals(pdf *fpdf.Fpdf, t *schema.ICMSTot) {
	pdf.Ln(2)
	pdf.SetFont("Helvetica", "B", 8)
	pdf.CellFormat(190, 4, "CALCULO DO IMPOSTO", "1", 1, "L", false, 0, "")
	pdf.SetFont("Helvetica", "", 8)
	totals := []struct {
		label string
		value string
	}{
		{"Base ICMS", t.VBC},
		{"Vl. ICMS", t.VICMS},
		{"Vl. Produtos", t.VProd},
		// vFrete/vSeg/vDesc are SEFAZ-optional fields that the
		// schema regen retyped from `string` to `*string` so empty
		// values get omitted from the wire. The DANFE prints "0,00"
		// for missing totals (loop below), so deref-or-empty is the
		// right shape here.
		{"Vl. Frete", derefStr(t.VFrete)},
		{"Vl. Seguro", derefStr(t.VSeg)},
		{"Vl. Desc.", derefStr(t.VDesc)},
		{"Vl. PIS", t.VPIS},
		{"Vl. COFINS", t.VCOFINS},
		{"VALOR TOTAL NF", t.VNF},
	}
	pdf.SetFont("Helvetica", "B", 7)
	for _, c := range totals {
		pdf.CellFormat(190/float64(len(totals)), 4, c.label, "LR", 0, "C", false, 0, "")
	}
	pdf.Ln(-1)
	pdf.SetFont("Helvetica", "", 7)
	for _, c := range totals {
		v := c.value
		if v == "" {
			v = "0,00"
		}
		pdf.CellFormat(190/float64(len(totals)), 4, v, "LRB", 0, "R", false, 0, "")
	}
	pdf.Ln(-1)
}

func drawProtocolFooter(pdf *fpdf.Fpdf, protocol *nfe.Protocol, tr func(string) string) {
	if protocol == nil {
		return
	}
	pdf.Ln(3)
	pdf.SetFont("Helvetica", "", 7)
	pdf.CellFormat(190, 4,
		tr(fmt.Sprintf("Autorizado em %s pela SEFAZ. Protocolo: %s. Digest: %s.",
			protocol.DhRecbto.Format("02/01/2006 15:04:05"),
			protocol.NProt,
			protocol.DigVal)),
		"", 1, "L", false, 0, "")
}

// formatChave breaks the 44-digit chave into 11 groups of 4 separated
// by spaces. The grouped form is what humans read off the DANFE when
// they need to type the chave into the SEFAZ portal.
func formatChave(chave string) string {
	if len(chave) != 44 {
		return chave
	}
	var b strings.Builder
	for i := 0; i < 44; i += 4 {
		if i > 0 {
			b.WriteByte(' ')
		}
		b.WriteString(chave[i : i+4])
	}
	return b.String()
}

// buildCode128 renders the chave as a Code-128 barcode and returns the
// PNG bytes the PDF can embed via RegisterImageOptionsReader.
func buildCode128(chave string) ([]byte, error) {
	bc, err := code128.Encode(chave)
	if err != nil {
		return nil, fmt.Errorf("encode: %w", err)
	}
	scaled, err := barcode.Scale(bc, 600, 80)
	if err != nil {
		return nil, fmt.Errorf("scale: %w", err)
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, scaled); err != nil {
		return nil, fmt.Errorf("encode png: %w", err)
	}
	return buf.Bytes(), nil
}

func isHomologation(tpAmb string) bool { return tpAmb == "2" }

func derefStr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}
