package infrastructure_test

import (
	"context"
	"errors"
	"sync"
	"testing"
	"time"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
)

const (
	chaveA = nfe.Chave("43260505730928000145550010000001001123456787")
	chaveB = nfe.Chave("35260505730928000145550010000001002123456789")
)

func sampleRecord(chave nfe.Chave) *nfe.NFeRecord {
	return &nfe.NFeRecord{
		Chave:     chave,
		Status:    nfe.NFeStatusAuthorized,
		SignedXML: []byte("<NFe>...</NFe>"),
		Protocol:  &nfe.Protocol{NProt: "143260000000001", ChNFe: string(chave), CStat: "100"},
		CStat:     "100",
		XMotivo:   "Autorizado o uso da NF-e",
	}
}

func TestInMemoryRepo_SaveThenGet(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	rec := sampleRecord(chaveA)

	if err := repo.Save(context.Background(), rec); err != nil {
		t.Fatalf("Save: %v", err)
	}
	got, err := repo.GetByChave(context.Background(), chaveA)
	if err != nil {
		t.Fatalf("GetByChave: %v", err)
	}
	if got.Chave != chaveA || got.Protocol.NProt != "143260000000001" {
		t.Errorf("recovered record mismatch: %+v", got)
	}
	if got.CreatedAt.IsZero() || got.UpdatedAt.IsZero() {
		t.Error("Save must stamp CreatedAt and UpdatedAt")
	}
}

func TestInMemoryRepo_GetUnknownChave(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	_, err := repo.GetByChave(context.Background(), chaveA)
	if !errors.Is(err, nfe.ErrNFeNotFound) {
		t.Errorf("err = %v, want ErrNFeNotFound", err)
	}
}

// TestInMemoryRepo_SaveIsUpsert is the contract sprint 1.6 D4 relies on:
// re-saving the same chave overwrites the existing record (so a duplicate
// re-emission updates instead of duplicating) but preserves CreatedAt
// (so the audit trail remembers when the chave first appeared).
func TestInMemoryRepo_SaveIsUpsert(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	first := sampleRecord(chaveA)
	if err := repo.Save(context.Background(), first); err != nil {
		t.Fatalf("first Save: %v", err)
	}
	originalCreated := first.CreatedAt
	time.Sleep(2 * time.Millisecond) // distinguishable timestamps

	second := sampleRecord(chaveA)
	second.Status = nfe.NFeStatusRejected // status flipped
	if err := repo.Save(context.Background(), second); err != nil {
		t.Fatalf("second Save: %v", err)
	}

	got, _ := repo.GetByChave(context.Background(), chaveA)
	if got.Status != nfe.NFeStatusRejected {
		t.Errorf("Status not updated by upsert: %s", got.Status)
	}
	if !got.CreatedAt.Equal(originalCreated) {
		t.Errorf("CreatedAt changed across upsert: %v -> %v", originalCreated, got.CreatedAt)
	}
	if !got.UpdatedAt.After(originalCreated) {
		t.Errorf("UpdatedAt did not advance: created=%v updated=%v", got.CreatedAt, got.UpdatedAt)
	}
}

// TestInMemoryRepo_StoredRecordsAreIsolated guards the deep-copy
// contract. Mutating a record returned by GetByChave (or returned via
// Save's argument) must not leak back into the store, mirroring the
// isolation a real Postgres repo provides for free.
func TestInMemoryRepo_StoredRecordsAreIsolated(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	rec := sampleRecord(chaveA)
	if err := repo.Save(context.Background(), rec); err != nil {
		t.Fatalf("Save: %v", err)
	}

	rec.Protocol.NProt = "MUTATED"          // mutate the input the caller still holds
	rec.SignedXML = append(rec.SignedXML, '!')

	got, _ := repo.GetByChave(context.Background(), chaveA)
	if got.Protocol.NProt == "MUTATED" {
		t.Error("post-Save mutation of caller struct leaked into store")
	}
	if string(got.SignedXML) != "<NFe>...</NFe>" {
		t.Errorf("post-Save mutation of caller SignedXML leaked: %s", got.SignedXML)
	}

	got.Protocol.NProt = "MUTATED-VIA-GET"
	got2, _ := repo.GetByChave(context.Background(), chaveA)
	if got2.Protocol.NProt == "MUTATED-VIA-GET" {
		t.Error("post-Get mutation of returned record leaked into store")
	}
}

func TestInMemoryRepo_ListOrderAndPaging(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	if err := repo.Save(context.Background(), sampleRecord(chaveA)); err != nil {
		t.Fatalf("Save A: %v", err)
	}
	time.Sleep(2 * time.Millisecond)
	if err := repo.Save(context.Background(), sampleRecord(chaveB)); err != nil {
		t.Fatalf("Save B: %v", err)
	}

	all, err := repo.List(context.Background(), 0, 0)
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if len(all) != 2 {
		t.Fatalf("List returned %d records, want 2", len(all))
	}
	// Most recent (B) must come first.
	if all[0].Chave != chaveB || all[1].Chave != chaveA {
		t.Errorf("List order wrong: got [%s, %s]", all[0].Chave, all[1].Chave)
	}

	// Paging — limit=1 should return only B.
	page, _ := repo.List(context.Background(), 1, 0)
	if len(page) != 1 || page[0].Chave != chaveB {
		t.Errorf("limit=1 returned %d records, first=%s", len(page), page[0].Chave)
	}

	// Offset past end returns empty, not an error.
	empty, err := repo.List(context.Background(), 10, 99)
	if err != nil || len(empty) != 0 {
		t.Errorf("offset>=len: got %d records, err=%v", len(empty), err)
	}
}

func TestInMemoryRepo_ConcurrentSaves(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	var wg sync.WaitGroup
	const n = 100
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			rec := sampleRecord(chaveA)
			_ = repo.Save(context.Background(), rec)
		}()
	}
	wg.Wait()

	got, err := repo.GetByChave(context.Background(), chaveA)
	if err != nil {
		t.Fatalf("GetByChave: %v", err)
	}
	if got == nil {
		t.Fatal("expected one record after concurrent saves")
	}
	all, _ := repo.List(context.Background(), 0, 0)
	if len(all) != 1 {
		t.Errorf("expected exactly 1 record, got %d (upsert by chave)", len(all))
	}
}

func TestInMemoryRepo_RespectsContextCancellation(t *testing.T) {
	repo := infrastructure.NewInMemoryNFeRepository()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	if err := repo.Save(ctx, sampleRecord(chaveA)); !errors.Is(err, context.Canceled) {
		t.Errorf("Save: err = %v, want context.Canceled", err)
	}
	if _, err := repo.GetByChave(ctx, chaveA); !errors.Is(err, context.Canceled) {
		t.Errorf("GetByChave: err = %v, want context.Canceled", err)
	}
	if _, err := repo.List(ctx, 0, 0); !errors.Is(err, context.Canceled) {
		t.Errorf("List: err = %v, want context.Canceled", err)
	}
}
