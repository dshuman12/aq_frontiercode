package infrastructure

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	_ "github.com/lib/pq"

	"github.com/sefarius/billing-service/domain/nfe"
)

// PostgresNFeEventRepository persists submitted events in
// billing.nfe_events. See migration 005_nfe_events.sql for the schema.
//
// Save uses INSERT ... ON CONFLICT (chave, event_type, n_seq) DO UPDATE
// so the repo owns occurred_at — the database default fires on insert,
// and re-saves preserve it. This matches the timestamp contract the
// contract test enforces against both implementations.
type PostgresNFeEventRepository struct {
	db *sql.DB
}

// NewPostgresNFeEventRepository wires the repo to an opened *sql.DB.
func NewPostgresNFeEventRepository(db *sql.DB) *PostgresNFeEventRepository {
	return &PostgresNFeEventRepository{db: db}
}

// Save upserts the event. occurred_at is taken from the row default on
// first insert and preserved on conflict; the refreshed timestamp is
// written back to the caller's record so subsequent reads match the
// persisted value.
func (r *PostgresNFeEventRepository) Save(ctx context.Context, record *nfe.NFeEventRecord) error {
	if record == nil || record.Chave == "" {
		return nfe.ErrInvalidChaveLength
	}
	if !record.EventType.IsValid() {
		return nfe.ErrInvalidChaveLength
	}
	if record.NSeq < 1 {
		return nfe.ErrCCeSeqOutOfOrder
	}

	const query = `
		INSERT INTO billing.nfe_events
			(chave, event_type, n_seq, n_prot, status, cstat, xmotivo, signed_xml, response_xml)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		ON CONFLICT (chave, event_type, n_seq) DO UPDATE SET
			n_prot       = EXCLUDED.n_prot,
			status       = EXCLUDED.status,
			cstat        = EXCLUDED.cstat,
			xmotivo      = EXCLUDED.xmotivo,
			signed_xml   = EXCLUDED.signed_xml,
			response_xml = EXCLUDED.response_xml
		RETURNING occurred_at
	`

	err := r.db.QueryRowContext(ctx, query,
		string(record.Chave),
		string(record.EventType),
		record.NSeq,
		nullStringFromString(record.NProt),
		string(record.Status),
		nullStringFromString(record.CStat),
		nullStringFromString(record.XMotivo),
		record.SignedXML,
		record.ResponseXML,
	).Scan(&record.OccurredAt)
	if err != nil {
		return fmt.Errorf("nfe_event.Save: %w", err)
	}
	return nil
}

// GetByKey returns nfe.ErrNFeEventNotFound when the tuple has no row.
func (r *PostgresNFeEventRepository) GetByKey(ctx context.Context, chave nfe.Chave, eventType nfe.NFeEventType, nSeq int) (*nfe.NFeEventRecord, error) {
	const query = `
		SELECT chave, event_type, n_seq, n_prot, status, cstat, xmotivo, signed_xml, response_xml, occurred_at
		FROM billing.nfe_events
		WHERE chave = $1 AND event_type = $2 AND n_seq = $3
	`
	row := r.db.QueryRowContext(ctx, query, string(chave), string(eventType), nSeq)
	rec, err := scanEventRecord(row)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nfe.ErrNFeEventNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("nfe_event.GetByKey: %w", err)
	}
	return rec, nil
}

// ListByChave returns the events for a chave ordered chronologically.
func (r *PostgresNFeEventRepository) ListByChave(ctx context.Context, chave nfe.Chave) ([]*nfe.NFeEventRecord, error) {
	const query = `
		SELECT chave, event_type, n_seq, n_prot, status, cstat, xmotivo, signed_xml, response_xml, occurred_at
		FROM billing.nfe_events
		WHERE chave = $1
		ORDER BY occurred_at ASC
	`
	rows, err := r.db.QueryContext(ctx, query, string(chave))
	if err != nil {
		return nil, fmt.Errorf("nfe_event.ListByChave: %w", err)
	}
	defer rows.Close()

	out := make([]*nfe.NFeEventRecord, 0)
	for rows.Next() {
		rec, err := scanEventRecord(rows)
		if err != nil {
			return nil, fmt.Errorf("nfe_event.ListByChave: scan: %w", err)
		}
		out = append(out, rec)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("nfe_event.ListByChave: iterate: %w", err)
	}
	return out, nil
}

// MaxSeqByChaveType returns 0 when no rows exist for the tuple.
func (r *PostgresNFeEventRepository) MaxSeqByChaveType(ctx context.Context, chave nfe.Chave, eventType nfe.NFeEventType) (int, error) {
	const query = `
		SELECT COALESCE(MAX(n_seq), 0)
		FROM billing.nfe_events
		WHERE chave = $1 AND event_type = $2
	`
	var max int
	if err := r.db.QueryRowContext(ctx, query, string(chave), string(eventType)).Scan(&max); err != nil {
		return 0, fmt.Errorf("nfe_event.MaxSeqByChaveType: %w", err)
	}
	return max, nil
}

// scanEventRecord reads one row from the standard SELECT clause used
// in GetByKey and ListByChave. n_prot, cstat, and xmotivo are nullable
// in the schema (a rejected event without a SEFAZ protocol number
// still has cstat/xmotivo, but a transport-layer failure that never
// reached SEFAZ has all three null), so they are read into NullString.
func scanEventRecord(row rowScanner) (*nfe.NFeEventRecord, error) {
	var (
		chave       string
		eventType   string
		status      string
		nProt       sql.NullString
		cstat       sql.NullString
		xmotivo     sql.NullString
		signedXML   []byte
		responseXML []byte
		rec         = &nfe.NFeEventRecord{}
	)
	if err := row.Scan(
		&chave, &eventType, &rec.NSeq,
		&nProt, &status, &cstat, &xmotivo,
		&signedXML, &responseXML,
		&rec.OccurredAt,
	); err != nil {
		return nil, err
	}
	rec.Chave = nfe.Chave(chave)
	rec.EventType = nfe.NFeEventType(eventType)
	rec.Status = nfe.EventStatus(status)
	rec.SignedXML = signedXML
	rec.ResponseXML = responseXML
	if nProt.Valid {
		rec.NProt = nProt.String
	}
	if cstat.Valid {
		rec.CStat = cstat.String
	}
	if xmotivo.Valid {
		rec.XMotivo = xmotivo.String
	}
	return rec, nil
}

// nullStringFromString converts an empty string to SQL NULL so the
// database column stays semantically distinct from "the empty string".
func nullStringFromString(s string) any {
	if s == "" {
		return nil
	}
	return s
}

// Compile-time guarantee.
var _ nfe.NFeEventRepository = (*PostgresNFeEventRepository)(nil)
