package infrastructure_test

import (
	"context"
	"database/sql"
	"errors"
	"os"
	"sync"
	"testing"
	"time"

	_ "github.com/lib/pq"

	"github.com/sefarius/billing-service/domain/nfe"
	"github.com/sefarius/billing-service/infrastructure"
)

// repoFactory builds a fresh repo for one subtest. Each implementation
// returns a function the test calls in t.Run; that function does any
// setup (truncate, open conn) and returns the repo plus a cleanup hook.
type repoFactory func(t *testing.T) nfe.NFeRepository

// implementations is the table the contract tests iterate. The Postgres
// branch is skipped when TEST_DATABASE_URL is unset so the default
// `go test ./...` stays fast and offline.
//
// Postgres setup expectation: migration 004_nfe_records.sql has already
// been applied (the dev compose file mounts ./database/migrations into
// docker-entrypoint-initdb.d). Each subtest TRUNCATEs the table before
// running so cases don't leak state into each other.
func implementations(t *testing.T) []struct {
	name    string
	factory repoFactory
} {
	t.Helper()
	out := []struct {
		name    string
		factory repoFactory
	}{
		{
			name: "InMemory",
			factory: func(t *testing.T) nfe.NFeRepository {
				return infrastructure.NewInMemoryNFeRepository()
			},
		},
	}
	if dsn := os.Getenv("TEST_DATABASE_URL"); dsn != "" {
		out = append(out, struct {
			name    string
			factory repoFactory
		}{
			name: "Postgres",
			factory: func(t *testing.T) nfe.NFeRepository {
				db, err := sql.Open("postgres", dsn)
				if err != nil {
					t.Fatalf("open postgres: %v", err)
				}
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()
				if err := db.PingContext(ctx); err != nil {
					t.Fatalf("ping postgres: %v", err)
				}
				if _, err := db.ExecContext(ctx, "TRUNCATE billing.nfe_records CASCADE"); err != nil {
					t.Fatalf("truncate billing.nfe_records: %v", err)
				}
				t.Cleanup(func() {
					_, _ = db.Exec("TRUNCATE billing.nfe_records CASCADE")
					_ = db.Close()
				})
				return infrastructure.NewPostgresNFeRepository(db)
			},
		})
	}
	return out
}

// runContract runs the given assertion against every implementation.
// Each implementation gets its own subtest so failures localize to the
// affected backend. Helper because the boilerplate adds noise and
// easily drifts across tests.
func runContract(t *testing.T, name string, fn func(t *testing.T, repo nfe.NFeRepository)) {
	t.Helper()
	for _, impl := range implementations(t) {
		impl := impl
		t.Run(impl.name+"/"+name, func(t *testing.T) {
			fn(t, impl.factory(t))
		})
	}
}

func TestNFeRepoContract_SaveThenGet(t *testing.T) {
	runContract(t, "save_then_get", func(t *testing.T, repo nfe.NFeRepository) {
		rec := sampleRecord(chaveA)
		if err := repo.Save(context.Background(), rec); err != nil {
			t.Fatalf("Save: %v", err)
		}
		if rec.CreatedAt.IsZero() || rec.UpdatedAt.IsZero() {
			t.Error("Save must stamp CreatedAt and UpdatedAt on the input record")
		}

		got, err := repo.GetByChave(context.Background(), chaveA)
		if err != nil {
			t.Fatalf("GetByChave: %v", err)
		}
		if got.Chave != chaveA {
			t.Errorf("Chave round-trip: got %q, want %q", got.Chave, chaveA)
		}
		if got.Status != nfe.NFeStatusAuthorized {
			t.Errorf("Status round-trip: got %q, want AUTHORIZED", got.Status)
		}
		if string(got.SignedXML) != string(rec.SignedXML) {
			t.Errorf("SignedXML round-trip mismatch")
		}
		if got.Protocol == nil || got.Protocol.NProt != "143260000000001" {
			t.Errorf("Protocol round-trip: %+v", got.Protocol)
		}
		if got.CStat != "100" {
			t.Errorf("CStat round-trip: got %q, want 100", got.CStat)
		}
	})
}

func TestNFeRepoContract_GetUnknownChave(t *testing.T) {
	runContract(t, "get_unknown", func(t *testing.T, repo nfe.NFeRepository) {
		_, err := repo.GetByChave(context.Background(), chaveA)
		if !errors.Is(err, nfe.ErrNFeNotFound) {
			t.Errorf("err = %v, want ErrNFeNotFound", err)
		}
	})
}

// TestNFeRepoContract_SaveIsUpsert is the contract sprint 1.6 D4 leans
// on: re-saving the same chave overwrites status but preserves
// CreatedAt and advances UpdatedAt. Both impls own timestamps internally
// so the caller cannot smuggle a stale one in.
func TestNFeRepoContract_SaveIsUpsert(t *testing.T) {
	runContract(t, "save_is_upsert", func(t *testing.T, repo nfe.NFeRepository) {
		first := sampleRecord(chaveA)
		if err := repo.Save(context.Background(), first); err != nil {
			t.Fatalf("first Save: %v", err)
		}
		originalCreated := first.CreatedAt

		// Postgres timestamp resolution is microseconds; sleep enough
		// to make CreatedAt vs UpdatedAt distinguishable across both
		// impls without flaking on Windows clock granularity.
		time.Sleep(10 * time.Millisecond)

		second := sampleRecord(chaveA)
		second.Status = nfe.NFeStatusRejected
		if err := repo.Save(context.Background(), second); err != nil {
			t.Fatalf("second Save: %v", err)
		}

		got, err := repo.GetByChave(context.Background(), chaveA)
		if err != nil {
			t.Fatalf("GetByChave: %v", err)
		}
		if got.Status != nfe.NFeStatusRejected {
			t.Errorf("Status not updated by upsert: %s", got.Status)
		}
		if !got.CreatedAt.Equal(originalCreated) {
			t.Errorf("CreatedAt changed across upsert: %v -> %v", originalCreated, got.CreatedAt)
		}
		if !got.UpdatedAt.After(originalCreated) {
			t.Errorf("UpdatedAt did not advance: created=%v updated=%v", got.CreatedAt, got.UpdatedAt)
		}
	})
}

func TestNFeRepoContract_ListOrderAndPaging(t *testing.T) {
	runContract(t, "list_order_paging", func(t *testing.T, repo nfe.NFeRepository) {
		if err := repo.Save(context.Background(), sampleRecord(chaveA)); err != nil {
			t.Fatalf("Save A: %v", err)
		}
		time.Sleep(10 * time.Millisecond)
		if err := repo.Save(context.Background(), sampleRecord(chaveB)); err != nil {
			t.Fatalf("Save B: %v", err)
		}

		all, err := repo.List(context.Background(), 0, 0)
		if err != nil {
			t.Fatalf("List: %v", err)
		}
		if len(all) != 2 {
			t.Fatalf("List returned %d records, want 2", len(all))
		}
		if all[0].Chave != chaveB || all[1].Chave != chaveA {
			t.Errorf("List order wrong: got [%s, %s], want [B, A]", all[0].Chave, all[1].Chave)
		}

		page, err := repo.List(context.Background(), 1, 0)
		if err != nil {
			t.Fatalf("List(1,0): %v", err)
		}
		if len(page) != 1 || page[0].Chave != chaveB {
			t.Errorf("limit=1 returned %d records, first=%s", len(page), page[0].Chave)
		}

		empty, err := repo.List(context.Background(), 10, 99)
		if err != nil {
			t.Fatalf("List(10,99): %v", err)
		}
		if len(empty) != 0 {
			t.Errorf("offset>=len: got %d records, want 0", len(empty))
		}
	})
}

// TestNFeRepoContract_ConcurrentSaves runs 100 racing Saves of the same
// chave. The repository must serialize the upsert (mutex for InMemory,
// row-level lock for Postgres) so the final state is consistent and
// only one row survives.
func TestNFeRepoContract_ConcurrentSaves(t *testing.T) {
	runContract(t, "concurrent_saves", func(t *testing.T, repo nfe.NFeRepository) {
		var wg sync.WaitGroup
		const n = 100
		for i := 0; i < n; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				_ = repo.Save(context.Background(), sampleRecord(chaveA))
			}()
		}
		wg.Wait()

		got, err := repo.GetByChave(context.Background(), chaveA)
		if err != nil || got == nil {
			t.Fatalf("expected one record after concurrent saves, got err=%v", err)
		}
		all, _ := repo.List(context.Background(), 0, 0)
		if len(all) != 1 {
			t.Errorf("expected exactly 1 record, got %d (upsert by chave)", len(all))
		}
	})
}

func TestNFeRepoContract_RespectsContextCancellation(t *testing.T) {
	runContract(t, "ctx_cancel", func(t *testing.T, repo nfe.NFeRepository) {
		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		// Postgres surfaces context cancellation as a wrapped error; we
		// only need errors.Is to find context.Canceled at any depth.
		if err := repo.Save(ctx, sampleRecord(chaveA)); !errors.Is(err, context.Canceled) {
			t.Errorf("Save: err = %v, want context.Canceled in chain", err)
		}
		if _, err := repo.GetByChave(ctx, chaveA); !errors.Is(err, context.Canceled) {
			t.Errorf("GetByChave: err = %v, want context.Canceled in chain", err)
		}
		if _, err := repo.List(ctx, 0, 0); !errors.Is(err, context.Canceled) {
			t.Errorf("List: err = %v, want context.Canceled in chain", err)
		}
	})
}

// TestNFeRepoContract_RejectionRoundTrip validates the path that
// produced no Protocol and a non-nil Rejection. Sprint 1.6 D2's
// rejection branch must persist with the same shape both impls can
// load back.
func TestNFeRepoContract_RejectionRoundTrip(t *testing.T) {
	runContract(t, "rejection_round_trip", func(t *testing.T, repo nfe.NFeRepository) {
		rec := &nfe.NFeRecord{
			Chave:     chaveA,
			Status:    nfe.NFeStatusRejected,
			SignedXML: []byte("<NFe>...</NFe>"),
			Rejection: &nfe.Rejection{CStat: "228", XMotivo: "Data de Emissao posterior"},
			CStat:     "228",
			XMotivo:   "Data de Emissao posterior",
		}
		if err := repo.Save(context.Background(), rec); err != nil {
			t.Fatalf("Save rejected: %v", err)
		}
		got, err := repo.GetByChave(context.Background(), chaveA)
		if err != nil {
			t.Fatalf("GetByChave: %v", err)
		}
		if got.Protocol != nil {
			t.Errorf("Protocol must be nil for rejected record, got %+v", got.Protocol)
		}
		if got.Rejection == nil || got.Rejection.CStat != "228" {
			t.Errorf("Rejection round-trip: %+v", got.Rejection)
		}
	})
}
