package main

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gofiber/fiber/v2"
)

// TestProxyForwardsContentTypeWithoutConcatenation guards the DANFE iframe
// fix. Before the fix, forwardRequest used c.Append for every upstream
// header, which concatenated Fiber's default Content-Type with the upstream
// "application/pdf" producing the malformed header
// "text/plain; charset=utf-8, application/pdf" — browsers refused to render
// the PDF in an iframe. The proxy must Set (overwrite) the first value of
// each header so Fiber defaults are replaced rather than appended to.
func TestProxyForwardsContentTypeWithoutConcatenation(t *testing.T) {
	pdfBody := []byte("%PDF-1.5\n%fake-test-pdf-body")

	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/pdf")
		w.Header().Set("Content-Disposition", `inline; filename="danfe.pdf"`)
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(pdfBody)
	}))
	defer upstream.Close()

	app := fiber.New()
	app.Get("/api/nfe/:chave/danfe", forwardRequest(upstream.URL, "GET", NewCircuitBreaker(), &http.Client{}))

	req, _ := http.NewRequest("GET", "/api/nfe/12345/danfe", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}

	cts := resp.Header.Values("Content-Type")
	if len(cts) != 1 {
		t.Fatalf("Content-Type appears %d times (%v); proxy concatenated upstream onto a default", len(cts), cts)
	}
	if cts[0] != "application/pdf" {
		t.Fatalf("Content-Type = %q, want exactly %q (upstream value, not concatenated with a Fiber default)", cts[0], "application/pdf")
	}
	if strings.Contains(cts[0], ",") {
		t.Fatalf("Content-Type contains a comma (%q) — the prior c.Append bug regressed", cts[0])
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	if !strings.HasPrefix(string(body), "%PDF-") {
		t.Fatalf("body lost PDF magic bytes: got %q", string(body[:min(20, len(body))]))
	}
}

// TestProxyPreservesMultiValueHeaders ensures the Set/Append fix did not
// flatten genuinely multi-value headers (Set-Cookie). Set is used for the
// first value (overwriting Fiber defaults), Append for subsequent values
// (so multiple Set-Cookie lines survive).
func TestProxyPreservesMultiValueHeaders(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Add("Set-Cookie", "session=abc; Path=/")
		w.Header().Add("Set-Cookie", "tracking=xyz; Path=/")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer upstream.Close()

	app := fiber.New()
	app.Get("/cookies", forwardRequest(upstream.URL, "GET", NewCircuitBreaker(), &http.Client{}))

	req, _ := http.NewRequest("GET", "/cookies", nil)
	resp, err := app.Test(req, -1)
	if err != nil {
		t.Fatalf("app.Test: %v", err)
	}
	defer resp.Body.Close()

	cookies := resp.Header.Values("Set-Cookie")
	if len(cookies) != 2 {
		t.Fatalf("Set-Cookie count = %d (%v), want 2 — Set without Append would drop one", len(cookies), cookies)
	}
}
