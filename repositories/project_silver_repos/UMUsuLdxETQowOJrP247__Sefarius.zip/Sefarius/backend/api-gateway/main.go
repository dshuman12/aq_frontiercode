package main

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/golang-jwt/jwt/v5"
)

// accessCookieName precisa bater com o nome usado pelo auth-service
// (interfaces/cookie.go: AccessCookieName). Hardcoded aqui em vez de
// import porque não vale criar pacote shared só pra uma constante.
const accessCookieName = "sefarius_access"

// requireAuth verifica o JWT do cookie. Falha = 401, Sucesso = next.
// Mantemos a validação local (sem chamar auth-service) pra evitar
// hop extra em todo request — o gateway já tem o secret via env.
func requireAuth(jwtSecret []byte) fiber.Handler {
	return func(c *fiber.Ctx) error {
		token := c.Cookies(accessCookieName)
		if token == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "not authenticated",
				"code":    fiber.StatusUnauthorized,
			})
		}
		_, err := jwt.Parse(token, func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
			}
			return jwtSecret, nil
		})
		if err != nil {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "invalid or expired session",
				"code":    fiber.StatusUnauthorized,
			})
		}
		return c.Next()
	}
}

// ServiceRegistry concentra os endereços internos de todos os microsserviços do backend.
// É utilizado pelo Gateway para rotear as chamadas (Reverse Proxy).
type ServiceRegistry struct {
	StockServiceURL   string
	BillingServiceURL string
	PrintServiceURL   string
	InvoiceServiceURL string
	AuthServiceURL    string
}

// CircuitBreakerState mantém as métricas de saúde atuais de cada microsserviço rastreado.
type CircuitBreakerState struct {
	// State pode ser "CLOSED" (saudável), "OPEN" (falhando, bloqueia requisições) ou "HALF_OPEN" (testando recuperação).
	State         string
	FailCount     int
	SuccessCount  int
	LastFailTime  time.Time
	NextCheckTime time.Time
	FailThreshold int
	SuccessNeeded int
	OpenDuration  time.Duration
}

// CircuitBreaker gerencia a resiliência das chamadas HTTP via API Gateway.
// Previne que requisições se acumulem quando um microsserviço vizinho cai (Cascading Failure),
// permitindo fail-fast até o serviço voltar a responder.
type CircuitBreaker struct {
	mu     sync.RWMutex
	states map[string]*CircuitBreakerState
}

// NewCircuitBreaker inicializa um gerenciador de resiliência com mapa vazio.
func NewCircuitBreaker() *CircuitBreaker {
	return &CircuitBreaker{
		states: make(map[string]*CircuitBreakerState),
	}
}

// getState retorna o estado atual do Circuit Breaker para um serviço específico.
// Se ainda não existir, cria a máquina de estados padrão iniciando em "CLOSED".
func (cb *CircuitBreaker) getState(service string) *CircuitBreakerState {
	if _, ok := cb.states[service]; !ok {
		cb.states[service] = &CircuitBreakerState{
			State:         "CLOSED",
			FailThreshold: 5,
			SuccessNeeded: 2,
			OpenDuration:  30 * time.Second,
		}
	}
	return cb.states[service]
}

// Call embrulha uma função (\`fn\`) assíncrona com o escudo de proteção (Circuit Breaker).
// Bloqueia com Mutex (cb.mu) para manter consistência das contagens num ambiente altamente
// concorrente (goroutines do Fiber). Analisa o erro retornado da função para alterar a transição.
func (cb *CircuitBreaker) Call(service string, fn func() (interface{}, error)) (interface{}, error) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	state := cb.getState(service)

	switch state.State {
	case "CLOSED":
		result, err := fn()
		if err != nil {
			state.FailCount++
			state.LastFailTime = time.Now()
			// Ao cruzar o limiar de falhas consecutivo, o circuito abre e previne chamadas
			if state.FailCount >= state.FailThreshold {
				state.State = "OPEN"
				state.NextCheckTime = time.Now().Add(state.OpenDuration)
				log.Printf("[CB] Circuit breaker for %s opened", service)
			}
			return nil, err
		}
		// Reset do contador caso haja requisição estável contínua
		state.FailCount = 0
		return result, nil

	case "OPEN":
		// Teste gradativo após OpenDuration ter expirado: tenta 1 requisição
		if time.Now().After(state.NextCheckTime) {
			state.State = "HALF_OPEN"
			state.SuccessCount = 0
			log.Printf("[CB] Circuit breaker for %s entering HALF_OPEN", service)
			result, err := fn()
			if err != nil {
				// Voltou a falhar no estado probatório, retorna pra OPEN e recomeça o relógio
				state.State = "OPEN"
				state.NextCheckTime = time.Now().Add(state.OpenDuration)
				return nil, err
			}
			state.SuccessCount++
			return result, nil
		}
		return nil, fmt.Errorf("circuit breaker for %s is OPEN", service)

	case "HALF_OPEN":
		result, err := fn()
		if err != nil {
			state.State = "OPEN"
			state.NextCheckTime = time.Now().Add(state.OpenDuration)
			return nil, err
		}
		state.SuccessCount++
		// Precisa de múltiplas vitórias para provar real cura do vizinho
		if state.SuccessCount >= state.SuccessNeeded {
			state.State = "CLOSED"
			state.FailCount = 0
			log.Printf("[CB] Circuit breaker for %s closed", service)
		}
		return result, nil
	}

	return nil, fmt.Errorf("unknown circuit breaker state: %s", state.State)
}

// ProxyRequest atua como despachante HTTP customizado enviando payload aos microsserviços do cluster.
// Aplica \`Exponential Backoff\` embutido para Retry Limitado (maxRetries) protegendo
// requisições esporádicas instáveis.
func ProxyRequest(client *http.Client, method, url string, bodyData []byte, headers map[string]string) (*http.Response, error) {
	var resp *http.Response
	var err error

	maxRetries := 3
	backoff := 100 * time.Millisecond

	for i := 0; i < maxRetries; i++ {
		var reqBody io.Reader
		if len(bodyData) > 0 {
			reqBody = bytes.NewBuffer(bodyData)
		}
		req, err := http.NewRequest(method, url, reqBody)
		if err != nil {
			return nil, err
		}

		for k, v := range headers {
			req.Header.Set(k, v)
		}
		if req.Header.Get("Content-Type") == "" {
			req.Header.Set("Content-Type", "application/json")
		}

		resp, err = client.Do(req)
		if err == nil && resp.StatusCode < 500 {
			return resp, nil
		}

		if i < maxRetries-1 {
			time.Sleep(backoff)
			backoff *= 2
		}
	}

	return resp, err
}

func main() {
	app := fiber.New(fiber.Config{
		AppName:      "NF-e API Gateway v1.0",
		ErrorHandler: customErrorHandler,
		WriteTimeout: 30 * time.Second,
		ReadTimeout:  30 * time.Second,
	})

	// Initialize service registry
	services := &ServiceRegistry{
		StockServiceURL:   getEnv("STOCK_SERVICE_URL", "http://localhost:5001"),
		BillingServiceURL: getEnv("BILLING_SERVICE_URL", "http://localhost:5002"),
		PrintServiceURL:   getEnv("PRINT_SERVICE_URL", "http://localhost:5003"),
		InvoiceServiceURL: getEnv("INVOICE_SERVICE_URL", "http://localhost:5004"),
		AuthServiceURL:    getEnv("AUTH_SERVICE_URL", "http://localhost:5005"),
	}

	// JWT secret precisa ser idêntico ao do auth-service. Se não for
	// passado, abortamos — proteger rotas com cookie sem validar JWT
	// seria a pior das possibilidades (passa-tudo achando que filtra).
	jwtAccessSecret := getEnv("JWT_ACCESS_SECRET", "")
	if jwtAccessSecret == "" {
		log.Fatal("JWT_ACCESS_SECRET is required (must match auth-service)")
	}
	authMiddleware := requireAuth([]byte(jwtAccessSecret))

	// Circuit breaker for resilience
	cb := NewCircuitBreaker()

	// Reusable HTTP client with connection pooling
	httpClient := &http.Client{
		Timeout: 10 * time.Second,
		Transport: &http.Transport{
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 25,
			IdleConnTimeout:     90 * time.Second,
		},
	}

	// Middleware
	app.Use(recover.New())
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${status} - ${method} ${path}\n",
	}))

	// CORS — agora COM credentials habilitado pra cookies httpOnly
	// fluírem entre frontend e backend. AllowOrigins não pode ser "*"
	// nesse caso (browser rejeita); precisa ser origem específica do
	// frontend (http://localhost:4200 em dev).
	allowedOrigins := getEnv("CORS_ORIGINS", "http://localhost:4200")
	app.Use(cors.New(cors.Config{
		AllowOrigins:     allowedOrigins,
		AllowMethods:     "GET,POST,PUT,PATCH,DELETE,OPTIONS",
		AllowHeaders:     "Origin,Content-Type,Accept,Idempotency-Key",
		AllowCredentials: true,
	}))

	// Rate Limiting - 100 requests per minute per IP
	app.Use(limiter.New(limiter.Config{
		Max:               100,
		Expiration:        1 * time.Minute,
		LimiterMiddleware: limiter.SlidingWindow{},
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{
				"success": false,
				"error":   "rate limit exceeded, try again later",
				"code":    fiber.StatusTooManyRequests,
			})
		},
	}))

	// Health check
	app.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"status": "healthy"})
	})

	// Auth Service Routes (PUBLIC — auth-service controla acesso interno)
	authGroup := app.Group("/api/auth")
	authGroup.Post("/register", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))
	authGroup.Get("/activate/:token", forwardRequest(services.AuthServiceURL, "GET", cb, httpClient))
	authGroup.Post("/login", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))
	authGroup.Post("/logout", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))
	authGroup.Post("/refresh", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))
	authGroup.Post("/reset-password", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))
	authGroup.Post("/reset-password/:token", forwardRequest(services.AuthServiceURL, "POST", cb, httpClient))

	// Profile Routes (PROTECTED no gateway + RequireAuth no auth-service —
	// dupla validação cobre o caso de proxy mal configurado).
	profileGroup := app.Group("/api/profile", authMiddleware)
	profileGroup.Get("/", forwardRequest(services.AuthServiceURL, "GET", cb, httpClient))
	profileGroup.Patch("/name", forwardRequest(services.AuthServiceURL, "PATCH", cb, httpClient))
	profileGroup.Patch("/password", forwardRequest(services.AuthServiceURL, "PATCH", cb, httpClient))

	// Stock Service Routes (PROTECTED — só usuários autenticados)
	stockGroup := app.Group("/api/stock", authMiddleware)
	stockGroup.Post("/products", forwardRequest(services.StockServiceURL, "POST", cb, httpClient))
	stockGroup.Get("/products", forwardRequest(services.StockServiceURL, "GET", cb, httpClient))
	stockGroup.Get("/products/:id", forwardRequest(services.StockServiceURL, "GET", cb, httpClient))
	stockGroup.Put("/products/:id", forwardRequest(services.StockServiceURL, "PUT", cb, httpClient))
	stockGroup.Delete("/products/:id", forwardRequest(services.StockServiceURL, "DELETE", cb, httpClient))

	// Billing Service Routes (PROTECTED)
	billingGroup := app.Group("/api/billing", authMiddleware)
	billingGroup.Post("/invoices", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))
	billingGroup.Get("/invoices", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	billingGroup.Get("/invoices/:id", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	billingGroup.Put("/invoices/:id", forwardRequest(services.BillingServiceURL, "PUT", cb, httpClient))
	billingGroup.Delete("/invoices/:id", forwardRequest(services.BillingServiceURL, "DELETE", cb, httpClient))
	billingGroup.Post("/invoices/:id/close", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))
	billingGroup.Post("/invoices/:id/cancel", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))

	// Print Service Routes (PROTECTED)
	printGroup := app.Group("/api/print", authMiddleware)
	printGroup.Post("/invoices/:id/print", forwardRequest(services.PrintServiceURL, "POST", cb, httpClient))
	printGroup.Get("/print-jobs/:id", forwardRequest(services.PrintServiceURL, "GET", cb, httpClient))
	printGroup.Get("/invoices/:id/print-status", forwardRequest(services.PrintServiceURL, "GET", cb, httpClient))

	// Invoice Service Routes (PROTECTED)
	invoiceGroup := app.Group("/api/invoices", authMiddleware)
	invoiceGroup.Get("/history", forwardRequest(services.InvoiceServiceURL, "GET", cb, httpClient))
	invoiceGroup.Get("/stats", forwardRequest(services.InvoiceServiceURL, "GET", cb, httpClient))

	// NF-e Routes (PROTECTED — proxied to billing-service). Order matches
	// the billing-service registration: more-specific paths before broader
	// /:chave patterns so /:chave/cancel/pdf is not swallowed by /:chave.
	nfeGroup := app.Group("/api/nfe", authMiddleware)
	nfeGroup.Post("/", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))
	nfeGroup.Get("/", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Post("/:chave/cancel", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))
	nfeGroup.Post("/:chave/cce", forwardRequest(services.BillingServiceURL, "POST", cb, httpClient))
	nfeGroup.Get("/:chave/cancel/pdf", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cce/:seq/pdf", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cancel/xml", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cancel", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cce/:seq/xml", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cce/:seq", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/cce", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/xml", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave/danfe", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))
	nfeGroup.Get("/:chave", forwardRequest(services.BillingServiceURL, "GET", cb, httpClient))

	// Start server
	port := getEnv("PORT", "3000")
	go func() {
		log.Printf("Starting API Gateway on port %s...\n", port)
		if err := app.Listen(":" + port); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v\n", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	log.Println("Shutting down API Gateway...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := app.ShutdownWithContext(ctx); err != nil {
		log.Fatalf("Shutdown error: %v\n", err)
	}
	log.Println("API Gateway stopped")
}

// forwardRequest creates a middleware that forwards requests to a backend service
func forwardRequest(serviceURL string, method string, cb *CircuitBreaker, client *http.Client) fiber.Handler {
	return func(c *fiber.Ctx) error {
		fullURL := fmt.Sprintf("%s%s", serviceURL, c.OriginalURL())

		reqBody := c.Body()
		headers := make(map[string]string)
		c.Request().Header.VisitAll(func(key, value []byte) {
			headers[string(key)] = string(value)
		})

		result, err := cb.Call(serviceURL, func() (interface{}, error) {
			resp, err := ProxyRequest(client, method, fullURL, reqBody, headers)
			return resp, err
		})

		if err != nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"error":   "Service unavailable",
				"details": err.Error(),
			})
		}

		resp := result.(*http.Response)

		bodyBytes, err := io.ReadAll(resp.Body)
		resp.Body.Close()
		if err != nil {
			return c.Status(fiber.StatusInternalServerError).SendString("Error reading proxy response")
		}

		// Replace any default Fiber-set headers with the upstream values.
		// Using Append for the first value would concatenate onto Fiber's
		// defaults (e.g. Content-Type), producing malformed headers like
		// "text/plain; charset=utf-8, application/pdf". Set the first
		// value (overwrite), then Append the rest so multi-value headers
		// such as Set-Cookie still survive intact.
		//
		// Set-Cookie precisa de tratamento especial: Fiber's c.Set faz
		// comma-join em headers multi-value, e c.Append depois mescla
		// o cookie #2 com a vírgula no header existente — quebrando o
		// browser parsing. Sintoma observado: 2 cookies do auth-service
		// (access + refresh) chegam ao browser como 1 cookie malformado.
		// Use Response().Header.Add para preservar headers separados.
		//
		// Headers Access-Control-* do upstream são DESCARTADOS — o gateway
		// é a borda pública e seu cors middleware já setou os corretos.
		// Forwardar os headers CORS do downstream (que muitas vezes têm
		// default `*`) cria combinações inválidas com `credentials: true`
		// (browser rejeita "*" + credentials). Sintoma observado:
		// dashboard recebia status 0 nas requests autenticadas porque
		// stock-service injetava `Access-Control-Allow-Origin: *` na
		// resposta e o browser cancelava o frame.
		for key, values := range resp.Header {
			if len(values) == 0 {
				continue
			}
			if strings.HasPrefix(strings.ToLower(key), "access-control-") {
				continue
			}
			if strings.EqualFold(key, "Set-Cookie") {
				for _, value := range values {
					c.Response().Header.Add(key, value)
				}
				continue
			}
			c.Set(key, values[0])
			for _, value := range values[1:] {
				c.Append(key, value)
			}
		}

		return c.Status(resp.StatusCode).Send(bodyBytes)
	}
}

// customErrorHandler handles all errors
func customErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError

	var msg string
	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		msg = fe.Message
	} else {
		msg = err.Error()
	}

	return c.Status(code).JSON(fiber.Map{
		"error":     msg,
		"code":      code,
		"timestamp": time.Now().Unix(),
	})
}

// getEnv gets environment variable with default fallback
func getEnv(key, defaultValue string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return defaultValue
}
