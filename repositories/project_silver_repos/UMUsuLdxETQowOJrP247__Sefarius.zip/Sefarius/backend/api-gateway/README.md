# API Gateway Service

The API Gateway is the central entry point for all client requests in the Sefarius architecture. It is responsible for routing requests to the appropriate microservices, handling authentication, and potentially performing request/response transformation.

## Features
- Centralized request routing
- Microservice orchestration
- Error handling and aggregation
- Environment-based configuration

## Configuration
The following environment variables are supported:
- `PORT`: The port on which the gateway listens (default: 3000)
- `STOCK_SERVICE_URL`: URL for the Stock Service
- `BILLING_SERVICE_URL`: URL for the Billing Service
- `PRINT_SERVICE_URL`: URL for the Print Service
- `INVOICE_SERVICE_URL`: URL for the Invoice Service

## Development
To run the service locally:
```bash
go run main.go
```
