package domain

import "time"

// User é a entidade autenticada. password_hash, activation_token e
// reset_token NUNCA aparecem em respostas HTTP — só circulam internamente
// entre o repository e o service. Ver application/dto.go para o shape
// público (UserPublic).
type User struct {
	ID                       string
	Name                     string
	Email                    string
	PasswordHash             string
	Activated                bool
	ActivationToken          string
	ActivationTokenExpiresAt *time.Time
	ResetToken               string
	ResetTokenExpiresAt      *time.Time
	CreatedAt                time.Time
	UpdatedAt                time.Time
}

// IsActivationTokenValid retorna true se o token existe e ainda não
// expirou. Tokens expirados são tratados como inválidos pra forçar o
// usuário a pedir um novo link (sem mostrar mensagem de "expirou" que
// permitiria enumeration).
func (u *User) IsActivationTokenValid() bool {
	if u.ActivationToken == "" {
		return false
	}
	if u.ActivationTokenExpiresAt == nil {
		return true
	}
	return time.Now().Before(*u.ActivationTokenExpiresAt)
}

// IsResetTokenValid: mesma lógica do activation. Tokens de reset têm
// TTL mais curto (1h) por padrão pra reduzir janela de ataque.
func (u *User) IsResetTokenValid() bool {
	if u.ResetToken == "" {
		return false
	}
	if u.ResetTokenExpiresAt == nil {
		return true
	}
	return time.Now().Before(*u.ResetTokenExpiresAt)
}
