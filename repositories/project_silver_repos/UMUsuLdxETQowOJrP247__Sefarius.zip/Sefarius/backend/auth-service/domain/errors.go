package domain

import "errors"

// Sentinel errors. Handlers HTTP traduzem cada um pra status code
// específico (400/401/404/409). Mensagens de erro são intencionalmente
// genéricas em casos sensíveis (login, reset) pra prevenir enumeration.

var (
	ErrInvalidCredentials   = errors.New("email ou senha incorretos")
	ErrUserNotFound         = errors.New("usuário não encontrado")
	ErrEmailAlreadyExists   = errors.New("email já cadastrado")
	ErrAccountNotActivated  = errors.New("conta ainda não ativada")
	ErrInvalidToken         = errors.New("token inválido ou expirado")
	ErrPasswordMismatch     = errors.New("as senhas não coincidem")
	ErrWeakPassword         = errors.New("senha não atende aos requisitos mínimos")
	ErrSessionExpired       = errors.New("sessão expirada")
	ErrInvalidEmail         = errors.New("email inválido")
)

// IsDomainError checa se um erro é um dos sentinels conhecidos.
func IsDomainError(err, target error) bool {
	return errors.Is(err, target)
}
