package domain

import "context"

// UserRepository é o contrato que o auth-service espera da camada de
// persistência. infrastructure/persistence.go implementa contra
// Postgres; testes podem mockar contra in-memory.
type UserRepository interface {
	Create(ctx context.Context, user *User) error
	FindByEmail(ctx context.Context, email string) (*User, error)
	FindByID(ctx context.Context, id string) (*User, error)
	FindByActivationToken(ctx context.Context, token string) (*User, error)
	FindByResetToken(ctx context.Context, token string) (*User, error)
	UpdateActivation(ctx context.Context, user *User) error
	UpdateResetToken(ctx context.Context, user *User) error
	UpdatePassword(ctx context.Context, userID, passwordHash string) error
	UpdateName(ctx context.Context, userID, name string) error
}

// EmailSender envia os emails transacionais (ativação + reset).
// infrastructure/email.go implementa contra Resend.
type EmailSender interface {
	SendActivationEmail(ctx context.Context, to, name, token string) error
	SendResetPasswordEmail(ctx context.Context, to, name, token string) error
}

// PasswordHasher abstrai bcrypt — separado pra facilitar swap se um
// dia migrar pra argon2id.
type PasswordHasher interface {
	Hash(password string) (string, error)
	Verify(password, hash string) bool
}

// TokenIssuer gera + valida JWT (access e refresh). Implementação em
// infrastructure/jwt.go usa github.com/golang-jwt/jwt/v5.
type TokenIssuer interface {
	IssueAccessToken(userID, email string) (string, error)
	IssueRefreshToken(userID string) (string, error)
	VerifyAccessToken(token string) (claims *AccessClaims, err error)
	VerifyRefreshToken(token string) (userID string, err error)
}

// AccessClaims é o conteúdo do JWT de acesso. Curto de propósito —
// quanto mais informação no token, mais difícil é invalidar.
type AccessClaims struct {
	UserID string
	Email  string
}
