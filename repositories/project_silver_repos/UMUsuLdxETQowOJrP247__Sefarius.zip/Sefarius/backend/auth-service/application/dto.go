package application

import "github.com/sefarius/auth-service/domain"

// UserPublic é o shape que aparece em respostas HTTP — sem hash, sem
// tokens. Mapeamento via toPublic(user).
type UserPublic struct {
	ID        string `json:"id"`
	Name      string `json:"name"`
	Email     string `json:"email"`
	Activated bool   `json:"activated"`
}

func toPublic(u *domain.User) UserPublic {
	return UserPublic{
		ID:        u.ID,
		Name:      u.Name,
		Email:     u.Email,
		Activated: u.Activated,
	}
}

type RegisterRequest struct {
	Name     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type RequestResetRequest struct {
	Email string `json:"email"`
}

type ConfirmResetRequest struct {
	Password     string `json:"password"`
	Confirmation string `json:"confirmation"`
}

type ChangeNameRequest struct {
	Name string `json:"name"`
}

type ChangePasswordRequest struct {
	OldPassword  string `json:"oldPassword"`
	NewPassword  string `json:"newPassword"`
	Confirmation string `json:"confirmation"`
}

// AuthResult é retornado por register/activate/login/refresh/confirmReset.
// O caller (HTTP handler) usa AccessToken + RefreshToken pra setar
// cookies httpOnly. User é o shape público pro cliente.
type AuthResult struct {
	User         UserPublic `json:"user"`
	AccessToken  string     `json:"-"`
	RefreshToken string     `json:"-"`
}
