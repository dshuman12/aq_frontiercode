package application

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"log"
	"regexp"
	"strings"
	"time"

	"github.com/sefarius/auth-service/domain"
)

const (
	activationTokenTTL = 24 * time.Hour
	resetTokenTTL      = 1 * time.Hour
	tokenByteLength    = 32 // → 64 hex chars
)

var emailRegex = regexp.MustCompile(`^[^\s@]+@[^\s@]+\.[^\s@]+$`)

// AuthService orquestra os use cases de autenticação. Tudo que toca
// senha, geração de token, ou envio de email passa aqui — não nos
// handlers HTTP.
type AuthService struct {
	users  domain.UserRepository
	hasher domain.PasswordHasher
	tokens domain.TokenIssuer
	mailer domain.EmailSender
}

func NewAuthService(
	users domain.UserRepository,
	hasher domain.PasswordHasher,
	tokens domain.TokenIssuer,
	mailer domain.EmailSender,
) *AuthService {
	return &AuthService{users: users, hasher: hasher, tokens: tokens, mailer: mailer}
}

// Register cria usuário inativo, gera token de ativação e dispara email.
// Retorna user (sem auto-login — usuário precisa ativar primeiro).
func (s *AuthService) Register(ctx context.Context, req RegisterRequest) (UserPublic, error) {
	email := normalizeEmail(req.Email)
	name := strings.TrimSpace(req.Name)

	if !emailRegex.MatchString(email) {
		return UserPublic{}, domain.ErrInvalidEmail
	}
	if name == "" {
		return UserPublic{}, domain.ErrInvalidEmail
	}
	if !isPasswordStrong(req.Password) {
		return UserPublic{}, domain.ErrWeakPassword
	}

	existing, err := s.users.FindByEmail(ctx, email)
	if err != nil {
		return UserPublic{}, err
	}
	if existing != nil {
		return UserPublic{}, domain.ErrEmailAlreadyExists
	}

	hash, err := s.hasher.Hash(req.Password)
	if err != nil {
		return UserPublic{}, err
	}

	token, err := generateToken()
	if err != nil {
		return UserPublic{}, err
	}
	expires := time.Now().Add(activationTokenTTL)

	user := &domain.User{
		Name:                     name,
		Email:                    email,
		PasswordHash:             hash,
		Activated:                false,
		ActivationToken:          token,
		ActivationTokenExpiresAt: &expires,
	}
	if err := s.users.Create(ctx, user); err != nil {
		return UserPublic{}, err
	}

	// Email é best-effort: se Resend falha, o user já está criado.
	// Sysadmin pode trigger reenvio manual via reissue endpoint
	// (futuro) ou o user pode pedir "esqueci a senha" pra obter novo
	// token. Logamos o erro pra investigação.
	if err := s.mailer.SendActivationEmail(ctx, user.Email, user.Name, token); err != nil {
		log.Printf("[auth] failed to send activation email to %s: %v", user.Email, err)
	}

	return toPublic(user), nil
}

// Activate consome o token, marca user como ativo, abre sessão (mesma
// estratégia do mock frontend — auto-login depois de ativar).
func (s *AuthService) Activate(ctx context.Context, token string) (AuthResult, error) {
	user, err := s.users.FindByActivationToken(ctx, token)
	if err != nil {
		return AuthResult{}, err
	}
	if user == nil || !user.IsActivationTokenValid() {
		return AuthResult{}, domain.ErrInvalidToken
	}

	user.Activated = true
	user.ActivationToken = ""
	user.ActivationTokenExpiresAt = nil
	if err := s.users.UpdateActivation(ctx, user); err != nil {
		return AuthResult{}, err
	}

	return s.issueAuthResult(user)
}

// Login valida credenciais. Mensagem genérica em qualquer falha
// (user não existe / senha errada / não ativado) é INTENCIONAL —
// previne enumeration de email.
func (s *AuthService) Login(ctx context.Context, req LoginRequest) (AuthResult, error) {
	email := normalizeEmail(req.Email)
	user, err := s.users.FindByEmail(ctx, email)
	if err != nil {
		return AuthResult{}, err
	}
	if user == nil {
		return AuthResult{}, domain.ErrInvalidCredentials
	}
	if !s.hasher.Verify(req.Password, user.PasswordHash) {
		return AuthResult{}, domain.ErrInvalidCredentials
	}
	if !user.Activated {
		return AuthResult{}, domain.ErrAccountNotActivated
	}

	return s.issueAuthResult(user)
}

// Refresh emite novos tokens a partir de um refresh JWT válido.
// Caller (handler) lê o cookie, chama isso, e re-seta os 2 cookies.
func (s *AuthService) Refresh(ctx context.Context, refreshToken string) (AuthResult, error) {
	userID, err := s.tokens.VerifyRefreshToken(refreshToken)
	if err != nil {
		return AuthResult{}, domain.ErrInvalidToken
	}
	user, err := s.users.FindByID(ctx, userID)
	if err != nil {
		return AuthResult{}, err
	}
	if user == nil {
		return AuthResult{}, domain.ErrInvalidToken
	}
	return s.issueAuthResult(user)
}

// RequestReset gera token de reset + envia email. Sempre retorna nil
// mesmo se email não existe (anti-enumeration).
func (s *AuthService) RequestReset(ctx context.Context, req RequestResetRequest) error {
	email := normalizeEmail(req.Email)
	user, err := s.users.FindByEmail(ctx, email)
	if err != nil {
		return err
	}
	if user == nil {
		// Anti-enumeration: pretender sucesso. Tempo de resposta
		// fica um pouco mais rápido (sem hash + sem email send) —
		// constant-time padding seria perfeccionismo.
		return nil
	}

	token, err := generateToken()
	if err != nil {
		return err
	}
	expires := time.Now().Add(resetTokenTTL)
	user.ResetToken = token
	user.ResetTokenExpiresAt = &expires
	if err := s.users.UpdateResetToken(ctx, user); err != nil {
		return err
	}

	if err := s.mailer.SendResetPasswordEmail(ctx, user.Email, user.Name, token); err != nil {
		log.Printf("[auth] failed to send reset email to %s: %v", user.Email, err)
	}
	return nil
}

// ConfirmReset rotaciona a senha + auto-login (espelha o mock —
// re-digitar credenciais que acabaram de ser definidas é onde
// variações de teclado quebram o fluxo).
func (s *AuthService) ConfirmReset(ctx context.Context, token string, req ConfirmResetRequest) (AuthResult, error) {
	if req.Password != req.Confirmation {
		return AuthResult{}, domain.ErrPasswordMismatch
	}
	if !isPasswordStrong(req.Password) {
		return AuthResult{}, domain.ErrWeakPassword
	}

	user, err := s.users.FindByResetToken(ctx, token)
	if err != nil {
		return AuthResult{}, err
	}
	if user == nil || !user.IsResetTokenValid() {
		return AuthResult{}, domain.ErrInvalidToken
	}

	hash, err := s.hasher.Hash(req.Password)
	if err != nil {
		return AuthResult{}, err
	}

	if err := s.users.UpdatePassword(ctx, user.ID, hash); err != nil {
		return AuthResult{}, err
	}

	// Limpa o reset token e ativa a conta (caso edge: usuário pediu
	// reset antes de ativar; acesso ao email já é prova suficiente).
	user.ResetToken = ""
	user.ResetTokenExpiresAt = nil
	user.Activated = true
	if err := s.users.UpdateActivation(ctx, user); err != nil {
		return AuthResult{}, err
	}
	if err := s.users.UpdateResetToken(ctx, user); err != nil {
		return AuthResult{}, err
	}

	user.PasswordHash = hash
	return s.issueAuthResult(user)
}

// GetProfile retorna os dados públicos do user autenticado. Handler
// chama isso passando o userID extraído do cookie/JWT.
func (s *AuthService) GetProfile(ctx context.Context, userID string) (UserPublic, error) {
	user, err := s.users.FindByID(ctx, userID)
	if err != nil {
		return UserPublic{}, err
	}
	if user == nil {
		return UserPublic{}, domain.ErrUserNotFound
	}
	return toPublic(user), nil
}

// ChangeName atualiza nome. Não valida unicidade — decisão de design
// travada nos testes do frontend (nomes podem repetir entre users).
func (s *AuthService) ChangeName(ctx context.Context, userID string, req ChangeNameRequest) (UserPublic, error) {
	name := strings.TrimSpace(req.Name)
	if name == "" {
		return UserPublic{}, domain.ErrInvalidEmail
	}

	if err := s.users.UpdateName(ctx, userID, name); err != nil {
		return UserPublic{}, err
	}
	user, err := s.users.FindByID(ctx, userID)
	if err != nil {
		return UserPublic{}, err
	}
	return toPublic(user), nil
}

// ChangePassword exige senha atual + nova + confirmação.
func (s *AuthService) ChangePassword(ctx context.Context, userID string, req ChangePasswordRequest) error {
	if req.NewPassword != req.Confirmation {
		return domain.ErrPasswordMismatch
	}
	if !isPasswordStrong(req.NewPassword) {
		return domain.ErrWeakPassword
	}

	user, err := s.users.FindByID(ctx, userID)
	if err != nil {
		return err
	}
	if user == nil {
		return domain.ErrUserNotFound
	}
	if !s.hasher.Verify(req.OldPassword, user.PasswordHash) {
		return domain.ErrInvalidCredentials
	}

	hash, err := s.hasher.Hash(req.NewPassword)
	if err != nil {
		return err
	}
	return s.users.UpdatePassword(ctx, userID, hash)
}

func (s *AuthService) issueAuthResult(user *domain.User) (AuthResult, error) {
	access, err := s.tokens.IssueAccessToken(user.ID, user.Email)
	if err != nil {
		return AuthResult{}, err
	}
	refresh, err := s.tokens.IssueRefreshToken(user.ID)
	if err != nil {
		return AuthResult{}, err
	}
	return AuthResult{
		User:         toPublic(user),
		AccessToken:  access,
		RefreshToken: refresh,
	}, nil
}

func normalizeEmail(email string) string {
	return strings.ToLower(strings.TrimSpace(email))
}

func isPasswordStrong(p string) bool {
	if len(p) < 8 {
		return false
	}
	hasUpper := strings.ContainsAny(p, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
	hasLower := strings.ContainsAny(p, "abcdefghijklmnopqrstuvwxyz")
	hasDigit := strings.ContainsAny(p, "0123456789")
	return hasUpper && hasLower && hasDigit
}

func generateToken() (string, error) {
	b := make([]byte, tokenByteLength)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}
