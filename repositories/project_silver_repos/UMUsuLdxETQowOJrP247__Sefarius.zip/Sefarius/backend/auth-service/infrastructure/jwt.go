package infrastructure

import (
	"errors"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/sefarius/auth-service/domain"
)

// JWTIssuer assina/valida tokens HS256. Access e refresh têm secrets
// SEPARADOS — assim, comprometer o access secret não permite forjar
// refresh tokens (e vice-versa). Defesa em profundidade.
type JWTIssuer struct {
	accessSecret     []byte
	refreshSecret    []byte
	accessTTL        time.Duration
	refreshTTL       time.Duration
}

func NewJWTIssuer(accessSecret, refreshSecret string, accessTTL, refreshTTL time.Duration) *JWTIssuer {
	return &JWTIssuer{
		accessSecret:  []byte(accessSecret),
		refreshSecret: []byte(refreshSecret),
		accessTTL:     accessTTL,
		refreshTTL:    refreshTTL,
	}
}

type accessClaimsJWT struct {
	UserID string `json:"sub"`
	Email  string `json:"email"`
	jwt.RegisteredClaims
}

type refreshClaimsJWT struct {
	UserID string `json:"sub"`
	jwt.RegisteredClaims
}

func (j *JWTIssuer) IssueAccessToken(userID, email string) (string, error) {
	claims := accessClaimsJWT{
		UserID: userID,
		Email:  email,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(j.accessTTL)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	t := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return t.SignedString(j.accessSecret)
}

func (j *JWTIssuer) IssueRefreshToken(userID string) (string, error) {
	claims := refreshClaimsJWT{
		UserID: userID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(j.refreshTTL)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	t := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return t.SignedString(j.refreshSecret)
}

func (j *JWTIssuer) VerifyAccessToken(tokenStr string) (*domain.AccessClaims, error) {
	claims := &accessClaimsJWT{}
	_, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		// Garantir que ninguém troque o algoritmo pra "none" ou RS256.
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return j.accessSecret, nil
	})
	if err != nil {
		return nil, err
	}
	if claims.UserID == "" {
		return nil, errors.New("missing sub claim")
	}
	return &domain.AccessClaims{UserID: claims.UserID, Email: claims.Email}, nil
}

func (j *JWTIssuer) VerifyRefreshToken(tokenStr string) (string, error) {
	claims := &refreshClaimsJWT{}
	_, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return "", fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return j.refreshSecret, nil
	})
	if err != nil {
		return "", err
	}
	if claims.UserID == "" {
		return "", errors.New("missing sub claim")
	}
	return claims.UserID, nil
}
