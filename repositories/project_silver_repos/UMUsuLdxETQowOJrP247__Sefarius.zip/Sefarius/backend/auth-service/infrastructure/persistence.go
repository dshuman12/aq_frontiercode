package infrastructure

import (
	"context"
	"database/sql"
	"errors"
	"strings"

	_ "github.com/lib/pq"

	"github.com/sefarius/auth-service/domain"
)

type PostgresUserRepository struct {
	db *sql.DB
}

func NewPostgresUserRepository(db *sql.DB) *PostgresUserRepository {
	return &PostgresUserRepository{db: db}
}

const userColumns = `id, name, email, password_hash, activated,
	COALESCE(activation_token, ''), activation_token_expires_at,
	COALESCE(reset_token, ''), reset_token_expires_at,
	created_at, updated_at`

func (r *PostgresUserRepository) Create(ctx context.Context, user *domain.User) error {
	const q = `INSERT INTO auth.users
	  (name, email, password_hash, activated, activation_token, activation_token_expires_at)
	  VALUES ($1, $2, $3, $4, NULLIF($5, ''), $6)
	  RETURNING id, created_at, updated_at`
	return r.db.QueryRowContext(ctx, q,
		user.Name, user.Email, user.PasswordHash, user.Activated,
		user.ActivationToken, user.ActivationTokenExpiresAt,
	).Scan(&user.ID, &user.CreatedAt, &user.UpdatedAt)
}

func (r *PostgresUserRepository) FindByEmail(ctx context.Context, email string) (*domain.User, error) {
	q := `SELECT ` + userColumns + ` FROM auth.users WHERE LOWER(email) = LOWER($1)`
	return r.scanOne(ctx, q, email)
}

func (r *PostgresUserRepository) FindByID(ctx context.Context, id string) (*domain.User, error) {
	q := `SELECT ` + userColumns + ` FROM auth.users WHERE id = $1`
	return r.scanOne(ctx, q, id)
}

func (r *PostgresUserRepository) FindByActivationToken(ctx context.Context, token string) (*domain.User, error) {
	q := `SELECT ` + userColumns + ` FROM auth.users WHERE activation_token = $1`
	return r.scanOne(ctx, q, token)
}

func (r *PostgresUserRepository) FindByResetToken(ctx context.Context, token string) (*domain.User, error) {
	q := `SELECT ` + userColumns + ` FROM auth.users WHERE reset_token = $1`
	return r.scanOne(ctx, q, token)
}

func (r *PostgresUserRepository) UpdateActivation(ctx context.Context, user *domain.User) error {
	const q = `UPDATE auth.users
	  SET activated = $1, activation_token = NULLIF($2, ''),
	      activation_token_expires_at = $3, updated_at = CURRENT_TIMESTAMP
	  WHERE id = $4`
	_, err := r.db.ExecContext(ctx, q,
		user.Activated, user.ActivationToken, user.ActivationTokenExpiresAt, user.ID)
	return err
}

func (r *PostgresUserRepository) UpdateResetToken(ctx context.Context, user *domain.User) error {
	const q = `UPDATE auth.users
	  SET reset_token = NULLIF($1, ''), reset_token_expires_at = $2,
	      updated_at = CURRENT_TIMESTAMP
	  WHERE id = $3`
	_, err := r.db.ExecContext(ctx, q,
		user.ResetToken, user.ResetTokenExpiresAt, user.ID)
	return err
}

func (r *PostgresUserRepository) UpdatePassword(ctx context.Context, userID, passwordHash string) error {
	const q = `UPDATE auth.users
	  SET password_hash = $1, updated_at = CURRENT_TIMESTAMP
	  WHERE id = $2`
	_, err := r.db.ExecContext(ctx, q, passwordHash, userID)
	return err
}

func (r *PostgresUserRepository) UpdateName(ctx context.Context, userID, name string) error {
	const q = `UPDATE auth.users
	  SET name = $1, updated_at = CURRENT_TIMESTAMP
	  WHERE id = $2`
	_, err := r.db.ExecContext(ctx, q, name, userID)
	return err
}

func (r *PostgresUserRepository) scanOne(ctx context.Context, query string, args ...interface{}) (*domain.User, error) {
	var u domain.User
	err := r.db.QueryRowContext(ctx, query, args...).Scan(
		&u.ID, &u.Name, &u.Email, &u.PasswordHash, &u.Activated,
		&u.ActivationToken, &u.ActivationTokenExpiresAt,
		&u.ResetToken, &u.ResetTokenExpiresAt,
		&u.CreatedAt, &u.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		// Fluxo Create pode receber UNIQUE violation se 2 emails iguais
		// chegarem em paralelo (race entre FindByEmail + Create). O caller
		// trata domain.ErrEmailAlreadyExists; aqui só convertemos.
		if strings.Contains(err.Error(), "duplicate key value") {
			return nil, domain.ErrEmailAlreadyExists
		}
		return nil, err
	}
	return &u, nil
}
