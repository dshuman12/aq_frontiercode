package infrastructure

import "golang.org/x/crypto/bcrypt"

// BcryptHasher implementa domain.PasswordHasher.
// Cost 12 é o sweet-spot atual (~250ms por hash em hardware moderno);
// cost 10 é o default da lib mas considerado fraco hoje. Cost 14
// fica ~1s — bom para apps de alta segurança, mas penaliza UX de
// login. Para esse projeto, 12 é o balanço.
const bcryptCost = 12

type BcryptHasher struct{}

func NewBcryptHasher() *BcryptHasher {
	return &BcryptHasher{}
}

func (b *BcryptHasher) Hash(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcryptCost)
	if err != nil {
		return "", err
	}
	return string(bytes), nil
}

func (b *BcryptHasher) Verify(password, hash string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}
