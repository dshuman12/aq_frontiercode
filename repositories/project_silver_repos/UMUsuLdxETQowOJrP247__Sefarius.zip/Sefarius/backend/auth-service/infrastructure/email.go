package infrastructure

import (
	"context"
	"fmt"

	"github.com/resend/resend-go/v2"
)

// ResendMailer envia activation/reset emails via Resend API.
//
// Configuração:
//   RESEND_API_KEY  — re_xxxxx do dashboard
//   EMAIL_FROM      — endereço from (precisa ser de domínio verificado
//                     no Resend ou usar onboarding@resend.dev em dev)
//   CLIENT_URL      — base do frontend; usado para construir os links
//                     enviados nos emails (https://app.sefarius.com.br
//                     em prod, http://localhost:4200 em dev)
type ResendMailer struct {
	client    *resend.Client
	from      string
	clientURL string
}

func NewResendMailer(apiKey, from, clientURL string) *ResendMailer {
	return &ResendMailer{
		client:    resend.NewClient(apiKey),
		from:      from,
		clientURL: clientURL,
	}
}

func (m *ResendMailer) SendActivationEmail(ctx context.Context, to, name, token string) error {
	link := fmt.Sprintf("%s/activate/%s", m.clientURL, token)
	subject := "Ative sua conta — Sefarius"
	html := activationTemplate(name, link)

	_, err := m.client.Emails.SendWithContext(ctx, &resend.SendEmailRequest{
		From:    m.from,
		To:      []string{to},
		Subject: subject,
		Html:    html,
	})
	return err
}

func (m *ResendMailer) SendResetPasswordEmail(ctx context.Context, to, name, token string) error {
	link := fmt.Sprintf("%s/reset-password/%s", m.clientURL, token)
	subject := "Redefinição de senha — Sefarius"
	html := resetTemplate(name, link)

	_, err := m.client.Emails.SendWithContext(ctx, &resend.SendEmailRequest{
		From:    m.from,
		To:      []string{to},
		Subject: subject,
		Html:    html,
	})
	return err
}

// Templates inline (não há suficiente complexidade pra justificar
// arquivos .html separados). Se evoluir pra branding rico ou múltiplos
// idiomas, mover pra `templates/*.html` + html/template.
func activationTemplate(name, link string) string {
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="pt-BR">
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#f8f9fb; padding:40px 16px;">
  <div style="max-width:480px; margin:0 auto; background:#fff; border-radius:14px; padding:32px; box-shadow:0 6px 18px rgba(0,0,0,0.06);">
    <h1 style="color:#1e1b4b; font-size:22px; margin:0 0 16px;">Olá, %s 👋</h1>
    <p style="color:#4a5565; font-size:15px; line-height:1.55; margin:0 0 24px;">
      Para começar a usar o Sefarius, ative sua conta clicando no botão abaixo.
      O link expira em 24 horas.
    </p>
    <a href="%s" style="display:inline-block; padding:12px 28px; background:linear-gradient(135deg,#4f46e5 0%%,#7c3aed 100%%); color:#fff; text-decoration:none; border-radius:10px; font-weight:600;">
      Ativar minha conta
    </a>
    <p style="color:#6a7282; font-size:13px; margin:28px 0 0;">
      Se o botão não funcionar, copie e cole este link no navegador:<br>
      <a href="%s" style="color:#4f46e5; word-break:break-all;">%s</a>
    </p>
    <p style="color:#99a1af; font-size:12px; margin:28px 0 0;">
      Se você não criou esta conta, ignore este email — nada será criado.
    </p>
  </div>
</body>
</html>`, name, link, link, link)
}

func resetTemplate(name, link string) string {
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="pt-BR">
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#f8f9fb; padding:40px 16px;">
  <div style="max-width:480px; margin:0 auto; background:#fff; border-radius:14px; padding:32px; box-shadow:0 6px 18px rgba(0,0,0,0.06);">
    <h1 style="color:#1e1b4b; font-size:22px; margin:0 0 16px;">Olá, %s</h1>
    <p style="color:#4a5565; font-size:15px; line-height:1.55; margin:0 0 24px;">
      Recebemos um pedido para redefinir sua senha do Sefarius. Clique no
      botão abaixo para criar uma nova senha. O link expira em 1 hora.
    </p>
    <a href="%s" style="display:inline-block; padding:12px 28px; background:linear-gradient(135deg,#4f46e5 0%%,#7c3aed 100%%); color:#fff; text-decoration:none; border-radius:10px; font-weight:600;">
      Redefinir senha
    </a>
    <p style="color:#6a7282; font-size:13px; margin:28px 0 0;">
      Se o botão não funcionar, copie e cole este link no navegador:<br>
      <a href="%s" style="color:#4f46e5; word-break:break-all;">%s</a>
    </p>
    <p style="color:#99a1af; font-size:12px; margin:28px 0 0;">
      Se você não pediu redefinição, ignore este email — sua senha continua
      a mesma.
    </p>
  </div>
</body>
</html>`, name, link, link, link)
}
