package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	_ "github.com/lib/pq"

	"github.com/sefarius/auth-service/application"
	"github.com/sefarius/auth-service/infrastructure"
	"github.com/sefarius/auth-service/interfaces"
)

func main() {
	dbConnStr := getEnv("DATABASE_URL", "")
	if dbConnStr == "" {
		log.Fatal("DATABASE_URL is required (copy .env.example to .env)")
	}

	jwtAccessSecret := getEnv("JWT_ACCESS_SECRET", "")
	jwtRefreshSecret := getEnv("JWT_REFRESH_SECRET", "")
	if jwtAccessSecret == "" || jwtRefreshSecret == "" {
		log.Fatal("JWT_ACCESS_SECRET and JWT_REFRESH_SECRET are required")
	}

	resendAPIKey := getEnv("RESEND_API_KEY", "")
	if resendAPIKey == "" {
		log.Fatal("RESEND_API_KEY is required (cadastrar conta em https://resend.com)")
	}
	emailFrom := getEnv("EMAIL_FROM", "onboarding@resend.dev")
	clientURL := getEnv("CLIENT_URL", "http://localhost:4200")

	accessTTL := getEnvDuration("JWT_ACCESS_EXPIRATION", 15*time.Minute)
	refreshTTL := getEnvDuration("JWT_REFRESH_EXPIRATION", 7*24*time.Hour)

	db, err := initializeDatabase(dbConnStr)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v\n", err)
	}
	defer db.Close()

	// Dependency injection
	repo := infrastructure.NewPostgresUserRepository(db)
	hasher := infrastructure.NewBcryptHasher()
	tokens := infrastructure.NewJWTIssuer(jwtAccessSecret, jwtRefreshSecret, accessTTL, refreshTTL)
	mailer := infrastructure.NewResendMailer(resendAPIKey, emailFrom, clientURL)
	authSvc := application.NewAuthService(repo, hasher, tokens, mailer)

	cookieCfg := &interfaces.CookieConfig{
		Domain:   getEnv("COOKIE_DOMAIN", ""),
		Secure:   getEnvBool("COOKIE_SECURE", false),
		SameSite: getEnv("COOKIE_SAMESITE", "Lax"),
	}
	handler := interfaces.NewAuthHandler(authSvc, tokens, cookieCfg, accessTTL, refreshTTL)

	app := fiber.New(fiber.Config{
		AppName:      "Auth Service v1.0",
		ErrorHandler: customErrorHandler,
		WriteTimeout: 30 * time.Second,
		ReadTimeout:  30 * time.Second,
	})

	app.Use(recover.New())
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${status} - ${method} ${path} - ${latency}\n",
	}))
	app.Use(cors.New(cors.Config{
		// Auth requer credentials:include no fetch — então CORS NÃO pode
		// ser "*" pra rotas autenticadas. Backend tem que ecoar a origem
		// específica. Em dev configure CORS_ORIGINS=http://localhost:4200.
		AllowOrigins:     getEnv("CORS_ORIGINS", "http://localhost:4200"),
		AllowMethods:     "GET,POST,PUT,PATCH,DELETE,OPTIONS",
		AllowHeaders:     "Origin,Content-Type,Accept",
		AllowCredentials: true,
	}))

	setupRoutes(app, handler)

	port := getEnv("PORT", "5005")
	go func() {
		log.Printf("Starting Auth Service on port %s...\n", port)
		if err := app.Listen(":" + port); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v\n", err)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	log.Println("Shutting down Auth Service...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := app.ShutdownWithContext(ctx); err != nil {
		log.Fatalf("Shutdown error: %v\n", err)
	}
	log.Println("Auth Service stopped")
}

func setupRoutes(app *fiber.App, h *interfaces.AuthHandler) {
	app.Get("/health", h.Health)

	// Public auth routes
	auth := app.Group("/api/auth")
	auth.Post("/register", h.Register)
	auth.Get("/activate/:token", h.Activate)
	auth.Post("/login", h.Login)
	auth.Post("/logout", h.Logout)
	auth.Post("/refresh", h.Refresh)
	auth.Post("/reset-password", h.RequestReset)
	auth.Post("/reset-password/:token", h.ConfirmReset)

	// Protected profile routes
	profile := app.Group("/api/profile", h.RequireAuth)
	profile.Get("/", h.GetProfile)
	profile.Patch("/name", h.ChangeName)
	profile.Patch("/password", h.ChangePassword)

	// Token verification helper para o api-gateway (rota interna).
	// Gateway chama isso pra validar JWT antes de proxy de outras
	// rotas (/api/stock, /api/billing, etc.). Devolve user info se
	// válido, 401 caso contrário.
	app.Get("/api/auth/verify", h.RequireAuth, func(c *fiber.Ctx) error {
		return interfaces.SuccessResponse(c, fiber.StatusOK, fiber.Map{
			"userID": c.Locals("userID"),
			"email":  c.Locals("userEmail"),
		})
	})
}

func initializeDatabase(dbConnStr string) (*sql.DB, error) {
	db, err := sql.Open("postgres", dbConnStr)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	db.SetMaxOpenConns(getEnvInt("DB_MAX_CONNECTIONS", 25))
	db.SetMaxIdleConns(getEnvInt("DB_MAX_IDLE_CONNECTIONS", 5))
	db.SetConnMaxLifetime(time.Duration(getEnvInt("DB_CONN_MAX_LIFETIME_SECONDS", 300)) * time.Second)
	db.SetConnMaxIdleTime(2 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	log.Println("Database connection established")
	return db, nil
}

func customErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	msg := err.Error()
	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		msg = fe.Message
	}
	return c.Status(code).JSON(fiber.Map{
		"success": false,
		"error":   msg,
		"code":    code,
	})
}

func getEnv(key, defaultValue string) string {
	if v, ok := os.LookupEnv(key); ok {
		return v
	}
	return defaultValue
}

func getEnvInt(key string, defaultVal int) int {
	v := os.Getenv(key)
	if v == "" {
		return defaultVal
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return defaultVal
	}
	return n
}

func getEnvBool(key string, defaultVal bool) bool {
	v := os.Getenv(key)
	if v == "" {
		return defaultVal
	}
	b, err := strconv.ParseBool(v)
	if err != nil {
		return defaultVal
	}
	return b
}

func getEnvDuration(key string, defaultVal time.Duration) time.Duration {
	v := os.Getenv(key)
	if v == "" {
		return defaultVal
	}
	d, err := time.ParseDuration(v)
	if err != nil {
		return defaultVal
	}
	return d
}
