package interfaces

import (
	"time"

	"github.com/gofiber/fiber/v2"
)

const (
	AccessCookieName  = "sefarius_access"
	RefreshCookieName = "sefarius_refresh"
)

// CookieConfig encapsula as flags de segurança aplicadas em todos os
// cookies de sessão. SameSite=Lax porque o frontend mora em domínio
// diferente do gateway em prod (subdomínio); Strict quebraria refresh
// em navegação entre abas. Secure só em prod (HTTPS) — em dev (HTTP)
// o navegador rejeita Secure cookies, então o flag desliga via env.
type CookieConfig struct {
	Domain   string
	Secure   bool
	SameSite string
}

func (cc *CookieConfig) setCookie(c *fiber.Ctx, name, value string, ttl time.Duration) {
	cookie := &fiber.Cookie{
		Name:     name,
		Value:    value,
		Path:     "/",
		Domain:   cc.Domain,
		Expires:  time.Now().Add(ttl),
		HTTPOnly: true,
		Secure:   cc.Secure,
		SameSite: cc.SameSite,
	}
	c.Cookie(cookie)
}

func (cc *CookieConfig) clearCookie(c *fiber.Ctx, name string) {
	cookie := &fiber.Cookie{
		Name:     name,
		Value:    "",
		Path:     "/",
		Domain:   cc.Domain,
		Expires:  time.Now().Add(-1 * time.Hour),
		HTTPOnly: true,
		Secure:   cc.Secure,
		SameSite: cc.SameSite,
		MaxAge:   -1,
	}
	c.Cookie(cookie)
}

// SetAuthCookies grava access + refresh nos cookies httpOnly. Usado
// após register/activate/login/refresh/confirmReset.
func (cc *CookieConfig) SetAuthCookies(c *fiber.Ctx, accessToken, refreshToken string, accessTTL, refreshTTL time.Duration) {
	cc.setCookie(c, AccessCookieName, accessToken, accessTTL)
	cc.setCookie(c, RefreshCookieName, refreshToken, refreshTTL)
}

// ClearAuthCookies remove ambos os cookies (logout).
func (cc *CookieConfig) ClearAuthCookies(c *fiber.Ctx) {
	cc.clearCookie(c, AccessCookieName)
	cc.clearCookie(c, RefreshCookieName)
}
