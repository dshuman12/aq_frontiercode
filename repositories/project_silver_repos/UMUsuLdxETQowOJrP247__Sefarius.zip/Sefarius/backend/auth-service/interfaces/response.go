package interfaces

import "github.com/gofiber/fiber/v2"

// APIResponse mantém o mesmo shape dos outros services Sefarius
// (`{ success, data, error, code }`) — o frontend já espera isso via
// ApiResponse<T> em shared/models.
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Code    int         `json:"code"`
}

func SuccessResponse(c *fiber.Ctx, status int, data interface{}) error {
	return c.Status(status).JSON(APIResponse{Success: true, Data: data, Code: status})
}

func ErrorResponse(c *fiber.Ctx, status int, msg string) error {
	return c.Status(status).JSON(APIResponse{Success: false, Error: msg, Code: status})
}
