package interfaces

import (
	"errors"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/sefarius/auth-service/application"
	"github.com/sefarius/auth-service/domain"
)

// AuthHandler agrupa todas as rotas /api/auth/* e /api/profile/*.
// Usa application.AuthService como única fonte de regras — handlers
// só fazem parse de request, mapeamento de erro pra HTTP code e
// gerenciamento de cookies.
type AuthHandler struct {
	auth       *application.AuthService
	tokens     domain.TokenIssuer
	cookies    *CookieConfig
	accessTTL  time.Duration
	refreshTTL time.Duration
}

func NewAuthHandler(
	auth *application.AuthService,
	tokens domain.TokenIssuer,
	cookies *CookieConfig,
	accessTTL, refreshTTL time.Duration,
) *AuthHandler {
	return &AuthHandler{
		auth:       auth,
		tokens:     tokens,
		cookies:    cookies,
		accessTTL:  accessTTL,
		refreshTTL: refreshTTL,
	}
}

func (h *AuthHandler) Health(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{"status": "healthy", "service": "auth-service"})
}

// POST /api/auth/register
func (h *AuthHandler) Register(c *fiber.Ctx) error {
	var req application.RegisterRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	user, err := h.auth.Register(c.Context(), req)
	if err != nil {
		return mapError(c, err)
	}
	return SuccessResponse(c, fiber.StatusCreated, user)
}

// GET /api/auth/activate/:token  — auto-login depois de ativar.
func (h *AuthHandler) Activate(c *fiber.Ctx) error {
	token := c.Params("token")
	if token == "" {
		return ErrorResponse(c, fiber.StatusBadRequest, "token is required")
	}
	result, err := h.auth.Activate(c.Context(), token)
	if err != nil {
		return mapError(c, err)
	}
	h.cookies.SetAuthCookies(c, result.AccessToken, result.RefreshToken, h.accessTTL, h.refreshTTL)
	return SuccessResponse(c, fiber.StatusOK, result.User)
}

// POST /api/auth/login
func (h *AuthHandler) Login(c *fiber.Ctx) error {
	var req application.LoginRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	result, err := h.auth.Login(c.Context(), req)
	if err != nil {
		return mapError(c, err)
	}
	h.cookies.SetAuthCookies(c, result.AccessToken, result.RefreshToken, h.accessTTL, h.refreshTTL)
	return SuccessResponse(c, fiber.StatusOK, result.User)
}

// POST /api/auth/logout — limpa cookies. Não invalida tokens server-side
// (stateless JWT); access token continua válido até expirar (15min). Pra
// invalidação imediata real, precisaríamos de blacklist em Redis.
func (h *AuthHandler) Logout(c *fiber.Ctx) error {
	h.cookies.ClearAuthCookies(c)
	return SuccessResponse(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// POST /api/auth/refresh — usa refresh cookie pra emitir novos tokens.
func (h *AuthHandler) Refresh(c *fiber.Ctx) error {
	refreshToken := c.Cookies(RefreshCookieName)
	if refreshToken == "" {
		return ErrorResponse(c, fiber.StatusUnauthorized, "no refresh token")
	}
	result, err := h.auth.Refresh(c.Context(), refreshToken)
	if err != nil {
		h.cookies.ClearAuthCookies(c)
		return mapError(c, err)
	}
	h.cookies.SetAuthCookies(c, result.AccessToken, result.RefreshToken, h.accessTTL, h.refreshTTL)
	return SuccessResponse(c, fiber.StatusOK, result.User)
}

// POST /api/auth/reset-password
func (h *AuthHandler) RequestReset(c *fiber.Ctx) error {
	var req application.RequestResetRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	if err := h.auth.RequestReset(c.Context(), req); err != nil {
		return mapError(c, err)
	}
	// Sempre retorna sucesso (anti-enumeration).
	return SuccessResponse(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// POST /api/auth/reset-password/:token  — auto-login após resetar.
func (h *AuthHandler) ConfirmReset(c *fiber.Ctx) error {
	token := c.Params("token")
	if token == "" {
		return ErrorResponse(c, fiber.StatusBadRequest, "token is required")
	}
	var req application.ConfirmResetRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	result, err := h.auth.ConfirmReset(c.Context(), token, req)
	if err != nil {
		return mapError(c, err)
	}
	h.cookies.SetAuthCookies(c, result.AccessToken, result.RefreshToken, h.accessTTL, h.refreshTTL)
	return SuccessResponse(c, fiber.StatusOK, result.User)
}

// --- Profile (protected) ---

// GET /api/profile — retorna user da sessão. Auth middleware põe userID
// no Locals.
func (h *AuthHandler) GetProfile(c *fiber.Ctx) error {
	userID := userIDFromContext(c)
	if userID == "" {
		return ErrorResponse(c, fiber.StatusUnauthorized, "not authenticated")
	}
	user, err := h.auth.GetProfile(c.Context(), userID)
	if err != nil {
		return mapError(c, err)
	}
	return SuccessResponse(c, fiber.StatusOK, user)
}

// PATCH /api/profile/name
func (h *AuthHandler) ChangeName(c *fiber.Ctx) error {
	userID := userIDFromContext(c)
	if userID == "" {
		return ErrorResponse(c, fiber.StatusUnauthorized, "not authenticated")
	}
	var req application.ChangeNameRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	user, err := h.auth.ChangeName(c.Context(), userID, req)
	if err != nil {
		return mapError(c, err)
	}
	return SuccessResponse(c, fiber.StatusOK, user)
}

// PATCH /api/profile/password
func (h *AuthHandler) ChangePassword(c *fiber.Ctx) error {
	userID := userIDFromContext(c)
	if userID == "" {
		return ErrorResponse(c, fiber.StatusUnauthorized, "not authenticated")
	}
	var req application.ChangePasswordRequest
	if err := c.BodyParser(&req); err != nil {
		return ErrorResponse(c, fiber.StatusBadRequest, "invalid request body")
	}
	if err := h.auth.ChangePassword(c.Context(), userID, req); err != nil {
		return mapError(c, err)
	}
	return SuccessResponse(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// --- Auth middleware ---

// RequireAuth lê access cookie, valida JWT, põe userID e email em
// Locals para os handlers downstream. Em caso de access expirado MAS
// refresh válido, o frontend deve chamar /api/auth/refresh — não
// fazemos refresh implícito aqui pra simplificar (e evitar race se
// múltiplas requests chegarem com access expirado simultaneamente).
func (h *AuthHandler) RequireAuth(c *fiber.Ctx) error {
	accessToken := c.Cookies(AccessCookieName)
	if accessToken == "" {
		return ErrorResponse(c, fiber.StatusUnauthorized, "not authenticated")
	}
	claims, err := h.tokens.VerifyAccessToken(accessToken)
	if err != nil {
		return ErrorResponse(c, fiber.StatusUnauthorized, "invalid or expired token")
	}
	c.Locals("userID", claims.UserID)
	c.Locals("userEmail", claims.Email)
	return c.Next()
}

func userIDFromContext(c *fiber.Ctx) string {
	v := c.Locals("userID")
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

// mapError traduz domain errors → HTTP status code.
func mapError(c *fiber.Ctx, err error) error {
	switch {
	case errors.Is(err, domain.ErrInvalidCredentials):
		return ErrorResponse(c, fiber.StatusUnauthorized, err.Error())
	case errors.Is(err, domain.ErrInvalidToken),
		errors.Is(err, domain.ErrSessionExpired):
		return ErrorResponse(c, fiber.StatusUnauthorized, err.Error())
	case errors.Is(err, domain.ErrUserNotFound):
		return ErrorResponse(c, fiber.StatusNotFound, err.Error())
	case errors.Is(err, domain.ErrEmailAlreadyExists):
		return ErrorResponse(c, fiber.StatusConflict, err.Error())
	case errors.Is(err, domain.ErrAccountNotActivated):
		return ErrorResponse(c, fiber.StatusForbidden, err.Error())
	case errors.Is(err, domain.ErrPasswordMismatch),
		errors.Is(err, domain.ErrWeakPassword),
		errors.Is(err, domain.ErrInvalidEmail):
		return ErrorResponse(c, fiber.StatusBadRequest, err.Error())
	default:
		return ErrorResponse(c, fiber.StatusInternalServerError, "internal error")
	}
}
