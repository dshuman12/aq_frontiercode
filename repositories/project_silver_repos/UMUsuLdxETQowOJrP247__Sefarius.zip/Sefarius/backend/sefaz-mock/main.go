// Package main implements a minimal mock of the SEFAZ NFe webservices for local
// development. It returns canned successful responses by default, and can inject
// random failures when SEFAZ_MOCK_FAILURE_RATE is set (0.0-1.0).
//
// Endpoints implemented (skeleton — payloads are illustrative, not full SOAP):
//   GET  /health
//   POST /ws/NfeAutorizacao4
//   POST /ws/NfeRetAutorizacao4
//   GET  /ws/NfeStatusServico4
//   POST /ws/RecepcaoEvento4
//   POST /ws/NfeInutilizacao4
//
// Real protocol layer (SOAP envelope, XMLDSig validation, etc.) is intentionally
// omitted at this stage — see Projects/Sefarius/05 - NF-e Implementation Strategy.
package main

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"os"
	"strconv"
	"time"
)

func main() {
	port := envOrDefault("PORT", "5099")
	failureRate, _ := strconv.ParseFloat(envOrDefault("SEFAZ_MOCK_FAILURE_RATE", "0"), 64)
	latencyMs, _ := strconv.Atoi(envOrDefault("SEFAZ_MOCK_LATENCY_MS", "0"))

	rng := rand.New(rand.NewSource(time.Now().UnixNano()))

	mux := http.NewServeMux()
	mux.HandleFunc("/health", healthHandler)
	mux.HandleFunc("/ws/NfeAutorizacao4", withChaos(rng, failureRate, latencyMs, autorizacaoHandler))
	mux.HandleFunc("/ws/NfeRetAutorizacao4", withChaos(rng, failureRate, latencyMs, retAutorizacaoHandler))
	mux.HandleFunc("/ws/NfeStatusServico4", withChaos(rng, failureRate, latencyMs, statusServicoHandler))
	mux.HandleFunc("/ws/RecepcaoEvento4", withChaos(rng, failureRate, latencyMs, recepcaoEventoHandler))
	mux.HandleFunc("/ws/NfeInutilizacao4", withChaos(rng, failureRate, latencyMs, inutilizacaoHandler))

	addr := ":" + port
	fmt.Printf("SEFAZ Mock listening on %s (failure_rate=%.2f, latency_ms=%d)\n", addr, failureRate, latencyMs)
	if err := http.ListenAndServe(addr, mux); err != nil {
		log.Fatal(err)
	}
}

func envOrDefault(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

// withChaos optionally injects latency and random failures before delegating to next.
func withChaos(rng *rand.Rand, failureRate float64, latencyMs int, next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if latencyMs > 0 {
			time.Sleep(time.Duration(latencyMs) * time.Millisecond)
		}
		if failureRate > 0 && rng.Float64() < failureRate {
			http.Error(w, `{"error":"injected failure for chaos testing"}`, http.StatusServiceUnavailable)
			return
		}
		next(w, r)
	}
}

func healthHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "service": "sefaz-mock"})
}

func autorizacaoHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"cStat":     "100",
		"xMotivo":   "Autorizado o uso da NF-e",
		"protocolo": fmt.Sprintf("135%015d", time.Now().UnixNano()%1e15),
		"dhRecbto":  time.Now().UTC().Format(time.RFC3339),
	})
}

func retAutorizacaoHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"cStat":   "104",
		"xMotivo": "Lote processado",
	})
}

func statusServicoHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"cStat":     "107",
		"xMotivo":   "Servico em Operacao",
		"tpAmb":     "2", // 2 = homologação
		"verAplic":  "MOCK_1.0",
		"dhRecbto":  time.Now().UTC().Format(time.RFC3339),
	})
}

func recepcaoEventoHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"cStat":   "135",
		"xMotivo": "Evento registrado e vinculado a NF-e",
	})
}

func inutilizacaoHandler(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"cStat":   "102",
		"xMotivo": "Inutilizacao de numero homologado",
	})
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
