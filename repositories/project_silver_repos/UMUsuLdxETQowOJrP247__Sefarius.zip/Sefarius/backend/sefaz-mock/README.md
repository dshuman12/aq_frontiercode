# sefaz-mock

Minimal mock of SEFAZ NFe webservices for local development.

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Liveness check |
| POST | `/ws/NfeAutorizacao4` | Authorize NFe (returns canned protocol) |
| POST | `/ws/NfeRetAutorizacao4` | Query authorization result |
| GET | `/ws/NfeStatusServico4` | SEFAZ service status |
| POST | `/ws/RecepcaoEvento4` | Receive event (CCe, cancellation, manifestation) |
| POST | `/ws/NfeInutilizacao4` | Inutilize numbering range |

All endpoints return `application/json` with the SEFAZ-style fields (`cStat`, `xMotivo`,
etc.) so client code can parse responses with the same code path used against real SEFAZ.

## Chaos injection

| Env var | Default | Effect |
|---|---|---|
| `PORT` | `5099` | Listen port |
| `SEFAZ_MOCK_FAILURE_RATE` | `0` | Probability `[0.0, 1.0]` of returning 503 instead of canned response |
| `SEFAZ_MOCK_LATENCY_MS` | `0` | Fixed latency to add before responding |

Use `SEFAZ_MOCK_FAILURE_RATE=0.1` to exercise retry/circuit-breaker logic locally.

## Limitations

This is a skeleton — payloads are JSON shaped after SEFAZ fields, not actual SOAP envelopes
with XMLDSig. The real client implementation in `billing-service` will translate between
its `SefazClient` interface and either this mock (dev) or real WS-Security SOAP (prod).
See `Projects/Sefarius/05 - NF-e Implementation Strategy.md` in the Obsidian vault.
