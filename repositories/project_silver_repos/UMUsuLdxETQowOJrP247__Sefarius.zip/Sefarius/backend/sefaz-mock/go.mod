module github.com/sefarius/sefaz-mock

go 1.25.0
