-- ============================================================================
-- ADDITIONAL INDEXES FOR PERFORMANCE OPTIMIZATION
-- Run after 001_initial_schema.sql
-- ============================================================================

-- Stock: Partial index for active products (commonly queried with deleted_at IS NULL)
CREATE INDEX IF NOT EXISTS idx_products_code_active
  ON stock.products(code)
  WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_products_balance_active
  ON stock.products(balance)
  WHERE deleted_at IS NULL;

-- Billing: Composite index for status + date queries (dashboard, filtering)
CREATE INDEX IF NOT EXISTS idx_invoices_status_created
  ON billing.invoices(status, created_at)
  WHERE deleted_at IS NULL;

-- Billing: Composite index for item lookups (enrichInvoiceItems)
CREATE INDEX IF NOT EXISTS idx_invoice_items_product_invoice
  ON billing.invoice_items(product_id, invoice_id);

-- Print: Partial index for active print jobs by status
CREATE INDEX IF NOT EXISTS idx_print_jobs_status_active
  ON print.print_jobs(status, created_at)
  WHERE deleted_at IS NULL;

-- Print: Index for invoice lookup (GetPrintJobByInvoice query)
CREATE INDEX IF NOT EXISTS idx_print_jobs_invoice_active
  ON print.print_jobs(invoice_id)
  WHERE deleted_at IS NULL;

-- Shared: Cleanup index for expired idempotency entries.
-- Partial indexes cannot reference CURRENT_TIMESTAMP (Postgres requires
-- IMMUTABLE functions in predicates). A plain B-tree on expires_at is
-- still cheap to scan when the cleanup job runs `WHERE expires_at < NOW()`.
CREATE INDEX IF NOT EXISTS idx_idempotency_log_expires
  ON shared.idempotency_log(expires_at);
