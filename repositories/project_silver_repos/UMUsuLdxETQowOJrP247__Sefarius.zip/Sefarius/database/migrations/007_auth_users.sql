-- Auth schema + users table for the new auth-service.
-- Senhas são armazenadas como hash bcrypt (cost 12 — ver
-- backend/auth-service/infrastructure/password.go); o backend nunca
-- expõe `password_hash` nem `activation_token` / `reset_token` em
-- responses (ver authMapper em application/auth_service.go).

CREATE SCHEMA IF NOT EXISTS auth;

CREATE TABLE IF NOT EXISTS auth.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(120) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    activated BOOLEAN NOT NULL DEFAULT FALSE,
    activation_token VARCHAR(64),
    activation_token_expires_at TIMESTAMP WITH TIME ZONE,
    reset_token VARCHAR(64),
    reset_token_expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Lookup pra activation/reset (fluxos críticos de UX).
CREATE INDEX IF NOT EXISTS idx_users_activation_token ON auth.users(activation_token) WHERE activation_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_reset_token ON auth.users(reset_token) WHERE reset_token IS NOT NULL;

-- Email já tem unique constraint (índice automático), mas convém
-- forçar lookups via lower(email) pra normalização case-insensitive
-- coerente com o normalizeEmail do frontend.
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_lower ON auth.users(LOWER(email));
