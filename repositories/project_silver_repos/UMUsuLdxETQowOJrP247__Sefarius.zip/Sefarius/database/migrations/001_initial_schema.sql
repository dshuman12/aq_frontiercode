-- Create schemas for each service
CREATE SCHEMA IF NOT EXISTS stock;
CREATE SCHEMA IF NOT EXISTS billing;
CREATE SCHEMA IF NOT EXISTS print;
CREATE SCHEMA IF NOT EXISTS shared;

-- ============================================================================
-- STOCK SERVICE SCHEMA
-- ============================================================================

CREATE TABLE IF NOT EXISTS stock.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    balance INT NOT NULL DEFAULT 0 CHECK (balance >= 0),
    version INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_products_code ON stock.products(code);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON stock.products(created_at);

-- ============================================================================
-- BILLING SERVICE SCHEMA
-- ============================================================================

CREATE SEQUENCE IF NOT EXISTS billing.invoice_number_seq START 1000;

CREATE TABLE IF NOT EXISTS billing.invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    number BIGINT UNIQUE NOT NULL DEFAULT nextval('billing.invoice_number_seq'),
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED', 'CANCELLED')),
    idempotency_key UUID UNIQUE NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_invoices_number ON billing.invoices(number);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON billing.invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_created_at ON billing.invoices(created_at);
CREATE INDEX IF NOT EXISTS idx_invoices_idempotency_key ON billing.invoices(idempotency_key);

CREATE TABLE IF NOT EXISTS billing.invoice_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES billing.invoices(id) ON DELETE CASCADE,
    product_id UUID NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price > 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice_id ON billing.invoice_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_invoice_items_product_id ON billing.invoice_items(product_id);

-- ============================================================================
-- PRINT SERVICE SCHEMA
-- ============================================================================

CREATE TABLE IF NOT EXISTS print.print_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID UNIQUE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED')),
    attempts INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 3,
    last_error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_print_jobs_invoice_id ON print.print_jobs(invoice_id);
CREATE INDEX IF NOT EXISTS idx_print_jobs_status ON print.print_jobs(status);
CREATE INDEX IF NOT EXISTS idx_print_jobs_created_at ON print.print_jobs(created_at);

-- ============================================================================
-- SHARED SCHEMA - Idempotency & Logging
-- ============================================================================

CREATE TABLE IF NOT EXISTS shared.idempotency_log (
    idempotency_key UUID PRIMARY KEY,
    service VARCHAR(100) NOT NULL,
    operation VARCHAR(100) NOT NULL,
    request_hash VARCHAR(64) NOT NULL,
    response_code INT NOT NULL,
    response JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP + INTERVAL '24 hours'
);

CREATE INDEX IF NOT EXISTS idx_idempotency_log_created_at ON shared.idempotency_log(created_at);
CREATE INDEX IF NOT EXISTS idx_idempotency_log_expires_at ON shared.idempotency_log(expires_at);

CREATE TABLE IF NOT EXISTS shared.audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    user_id VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON shared.audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON shared.audit_log(created_at);

-- Permissions are handled by the database owner (postgres)
