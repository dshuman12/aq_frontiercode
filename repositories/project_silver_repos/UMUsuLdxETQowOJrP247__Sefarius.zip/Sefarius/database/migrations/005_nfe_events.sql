-- ============================================================================
-- BILLING SCHEMA — NF-e EVENTS (sprint 2.1: Cancel + CCe)
-- ============================================================================
-- One row per (chave, event_type, n_seq). Events are SEFAZ submissions
-- against a previously authorized NF-e — sprint 2.1 ships CANCEL
-- (tpEvento 110111) and CCE (tpEvento 110110); future event types
-- (manifestação destinatário, EPEC, etc.) reuse this table.
--
-- The composite PK enforces sequence uniqueness per chave: it is what
-- makes the off-by-one in CCe nSeqEvento allocation impossible at the
-- database layer — a JSONB array on nfe_records would not catch a
-- duplicate seq across concurrent SendCCe calls.
--
-- signed_xml is the procEvento submitted; response_xml is the
-- procEventoNFe (event + retEvento) returned by SEFAZ. Both are kept
-- because together they form the legally valid event document the
-- contributor may need to download / re-submit.
-- ============================================================================

CREATE TABLE IF NOT EXISTS billing.nfe_events (
    chave        CHAR(44)    NOT NULL REFERENCES billing.nfe_records(chave),
    event_type   VARCHAR(8)  NOT NULL CHECK (event_type IN ('CANCEL','CCE')),
    n_seq        SMALLINT    NOT NULL CHECK (n_seq >= 1),
    n_prot       VARCHAR(20),
    status       VARCHAR(16) NOT NULL CHECK (status IN ('ACCEPTED','REJECTED')),
    cstat        VARCHAR(8),
    xmotivo      TEXT,
    signed_xml   BYTEA       NOT NULL,
    response_xml BYTEA,
    occurred_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (chave, event_type, n_seq)
);

-- Lookup by chave alone is the dominant read pattern (handler.ListCCes
-- and handler.GetCancel both filter by chave first). The PK already
-- supports prefix scans on chave but the leading column makes the
-- planner's job obvious for that path.
CREATE INDEX IF NOT EXISTS idx_nfe_events_chave
    ON billing.nfe_events(chave);

-- Most-recent-first cross-chave listing — useful for the future
-- "all events of all NFes in the last X days" admin query. Cheap
-- because the table is small relative to nfe_records.
CREATE INDEX IF NOT EXISTS idx_nfe_events_occurred_at
    ON billing.nfe_events(occurred_at DESC);
