-- ============================================================================
-- BILLING SCHEMA — NF-e LIFECYCLE PERSISTENCE (sprint 1.11)
-- ============================================================================
-- Backs domain/nfe.NFeRepository. One row per emitted NF-e, keyed by chave.
-- Save semantics are upsert: re-emission of the same chave (e.g. duplicate
-- recovery, sprint 1.6 D4) updates in place; CreatedAt is preserved from the
-- first save, UpdatedAt advances on every save. This matches what the
-- InMemory implementation contract-tests in sprint 1.8 already enforce.
--
-- protocol / rejection are JSONB rather than normalized: both are small
-- structs (Protocol: 7 leaf fields, Rejection: 2), always read/written as a
-- whole, and never queried by inner field. Normalizing would add JOINs for
-- zero query benefit.
-- ============================================================================

CREATE TABLE IF NOT EXISTS billing.nfe_records (
    chave        CHAR(44)    PRIMARY KEY,
    status       VARCHAR(20) NOT NULL
                   CHECK (status IN ('AUTHORIZED','REJECTED','PENDING','CANCELLED')),
    signed_xml   BYTEA       NOT NULL,
    protocol     JSONB,
    rejection    JSONB,
    cstat        VARCHAR(8),
    xmotivo      TEXT,
    created_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT nfe_records_chave_44digits CHECK (chave ~ '^[0-9]{44}$')
);

-- Most-recent-first listing is the dominant query pattern (handler.ListNFe).
CREATE INDEX IF NOT EXISTS idx_nfe_records_created_at
    ON billing.nfe_records(created_at DESC);

-- Compound index supports filtered listings ("show me all REJECTED in last
-- 7 days") that we know are coming in sprint 2.x without needing another
-- migration.
CREATE INDEX IF NOT EXISTS idx_nfe_records_status_created
    ON billing.nfe_records(status, created_at DESC);
