-- Migration 006: Fiscal fields on stock.products
--
-- Sprint Catálogo Fiscal D1.b + D2.c: enrich the product catalog with
-- the minimum fiscal data needed to populate an NF-e item without
-- manual re-typing. The 7 columns with sensible defaults arrive
-- NOT NULL so any new product is fiscally complete on insert; the 2
-- columns without a universal default (ncm, valor_unitario) arrive
-- nullable so the migration does not invent a value the operator has
-- to verify anyway.
--
-- Defaults chosen to match the most common Brazilian sale of physical
-- merchandise (regime normal, venda interna, Simples cumulativo zero):
--   cfop_padrao_saida = '5102'  venda interna mercadoria adquirida de terceiros
--   u_com             = 'UN'     unidade
--   origem            = '0'      mercadoria nacional
--   cst_icms          = '00'     ICMS tributado integralmente
--   p_icms            = 18.00    alíquota geral interna RS/SP
--   cst_pis           = '49'     outras operações
--   cst_cofins        = '49'     outras operações
--
-- ncm and valor_unitario stay NULL on existing rows; the wizard will
-- refuse to populate an item from a product missing these, and the
-- product edit form must mark them as required.
--
-- Idempotent via IF NOT EXISTS so a re-apply on a partially migrated
-- DB does not crash.

ALTER TABLE stock.products
  ADD COLUMN IF NOT EXISTS ncm                VARCHAR(8),
  ADD COLUMN IF NOT EXISTS cfop_padrao_saida  VARCHAR(4)       NOT NULL DEFAULT '5102',
  ADD COLUMN IF NOT EXISTS u_com              VARCHAR(6)       NOT NULL DEFAULT 'UN',
  ADD COLUMN IF NOT EXISTS valor_unitario     NUMERIC(15, 4),
  ADD COLUMN IF NOT EXISTS origem             CHAR(1)          NOT NULL DEFAULT '0',
  ADD COLUMN IF NOT EXISTS cst_icms           VARCHAR(2)       NOT NULL DEFAULT '00',
  ADD COLUMN IF NOT EXISTS p_icms             NUMERIC(5, 2)    NOT NULL DEFAULT 18.00,
  ADD COLUMN IF NOT EXISTS cst_pis            VARCHAR(2)       NOT NULL DEFAULT '49',
  ADD COLUMN IF NOT EXISTS cst_cofins         VARCHAR(2)       NOT NULL DEFAULT '49';

-- Format guards. Each constraint is permissive enough to allow the
-- defaults above but rejects obvious typos (NCM with letters, CFOP
-- with too many digits, origem outside [0-8]). Detailed enum
-- validation lives in the Go validator at the application layer
-- (sprint commit 2) so changes there do not require a new migration.

ALTER TABLE stock.products
  ADD CONSTRAINT products_ncm_format               CHECK (ncm IS NULL OR ncm ~ '^\d{8}$'),
  ADD CONSTRAINT products_cfop_padrao_saida_format CHECK (cfop_padrao_saida ~ '^[1-7]\d{3}$'),
  ADD CONSTRAINT products_origem_format            CHECK (origem ~ '^[0-8]$'),
  ADD CONSTRAINT products_cst_icms_format          CHECK (cst_icms ~ '^\d{2}$'),
  ADD CONSTRAINT products_cst_pis_format           CHECK (cst_pis ~ '^\d{2}$'),
  ADD CONSTRAINT products_cst_cofins_format        CHECK (cst_cofins ~ '^\d{2}$'),
  ADD CONSTRAINT products_p_icms_range             CHECK (p_icms >= 0 AND p_icms <= 100),
  ADD CONSTRAINT products_valor_unitario_positive  CHECK (valor_unitario IS NULL OR valor_unitario > 0);
