# Security Policy

## Supported Versions

Only the latest stable version of Sefarius is currently supported for security updates.

| Version | Supported          |
| ------- | ------------------ |
| v1.x    | :white_check_mark: |
| < v1.x  | :x:                |

## Reporting a Vulnerability

We take the security of Sefarius seriously. If you believe you have found a security vulnerability, please report it to us by following these steps:

1. **Do not disclose the vulnerability publicly.**
2. Send an email to `glauccoeng@gmail.com` with a detailed description of the vulnerability.
3. Include steps to reproduce the issue, along with any relevant proof-of-concept code.

We will acknowledge your report within 48 hours and work with you to resolve the issue as quickly as possible.

## Security Practices

- All backend services run in non-privileged Docker containers.
- Environment variables are used for sensitive configuration.
- Regular linting and security scanning of the codebase.
