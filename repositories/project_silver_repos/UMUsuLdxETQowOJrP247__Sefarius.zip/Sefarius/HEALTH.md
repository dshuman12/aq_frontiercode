# Health Checks

Each microservice in Sefarius provides a `/health` endpoint to monitor its status.

## Standard Response Format

All health endpoints return a JSON response:

```json
{
  "status": "healthy",
  "service": "service-name",
  "time": 1714850000
}
```

## Service Endpoints

- **API Gateway**: `http://localhost:3000/health`
- **Stock Service**: `http://localhost:5001/health`
- **Billing Service**: `http://localhost:5002/health`
- **Print Service**: `http://localhost:5003/health`
- **Invoice Service**: `http://localhost:5004/health`

## Health Check Levels

1. **Liveness**: Checks if the process is running.
2. **Readiness**: Checks if the service is ready to accept traffic (e.g., database connection established).

Our current implementation combines these into a single `/health` endpoint.
