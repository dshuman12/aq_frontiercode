"""Time-bounded and count-bounded sliding aggregates over streaming samples."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Deque, Iterator, Sequence


def _evict_expired(
    chron: Deque[tuple[datetime, float]],
    newest_ts: datetime,
    span: timedelta,
) -> list[tuple[datetime, float]]:
    """Drop samples strictly older than ``newest_ts - span``; return evicted pairs in order."""
    cutoff = newest_ts - span
    evicted: list[tuple[datetime, float]] = []
    while chron and chron[0][0] < cutoff:
        evicted.append(chron.popleft())
    return evicted


@dataclass(slots=True)
class WindowMinMax:
    """Current min and max over an active sliding window (may be empty)."""

    minimum: float | None
    maximum: float | None


class TimeWindowMinMax:
    """Amortized O(1) min/max over samples in ``[t - span, t]`` (half-open on the left)."""

    __slots__ = ("_span", "_chron", "_min_dq", "_max_dq")

    def __init__(self, span: timedelta) -> None:
        if span.total_seconds() <= 0:
            raise ValueError("span must be positive")
        self._span = span
        self._chron: Deque[tuple[datetime, float]] = deque()
        self._min_dq: Deque[tuple[datetime, float]] = deque()
        self._max_dq: Deque[tuple[datetime, float]] = deque()

    @property
    def span(self) -> timedelta:
        return self._span

    def clear(self) -> None:
        self._chron.clear()
        self._min_dq.clear()
        self._max_dq.clear()

    def __len__(self) -> int:
        return len(self._chron)

    def push(self, ts: datetime, value: float) -> None:
        if ts.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        self._evict(ts)
        self._chron.append((ts, value))
        while self._min_dq and self._min_dq[-1][1] >= value:
            self._min_dq.pop()
        self._min_dq.append((ts, value))
        while self._max_dq and self._max_dq[-1][1] <= value:
            self._max_dq.pop()
        self._max_dq.append((ts, value))

    def _evict(self, newest_ts: datetime) -> None:
        cutoff = newest_ts - self._span
        while self._chron and self._chron[0][0] < cutoff:
            oldest_ts, oldest_val = self._chron.popleft()
            if self._min_dq and self._min_dq[0][0] == oldest_ts and self._min_dq[0][1] == oldest_val:
                self._min_dq.popleft()
            if self._max_dq and self._max_dq[0][0] == oldest_ts and self._max_dq[0][1] == oldest_val:
                self._max_dq.popleft()

    def min_max(self) -> WindowMinMax:
        if not self._min_dq or not self._max_dq:
            return WindowMinMax(minimum=None, maximum=None)
        return WindowMinMax(minimum=self._min_dq[0][1], maximum=self._max_dq[0][1])

    def newest_timestamp(self) -> datetime | None:
        if not self._chron:
            return None
        return self._chron[-1][0]


class TimeWindowSum:
    """Running sum over samples retained in ``[t - span, t]``."""

    __slots__ = ("_span", "_chron", "_sum")

    def __init__(self, span: timedelta) -> None:
        if span.total_seconds() <= 0:
            raise ValueError("span must be positive")
        self._span = span
        self._chron: Deque[tuple[datetime, float]] = deque()
        self._sum = 0.0

    @property
    def span(self) -> timedelta:
        return self._span

    def clear(self) -> None:
        self._chron.clear()
        self._sum = 0.0

    def __len__(self) -> int:
        return len(self._chron)

    def push(self, ts: datetime, value: float) -> None:
        if ts.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        for _, old in _evict_expired(self._chron, ts, self._span):
            self._sum -= old
        self._chron.append((ts, value))
        self._sum += value

    def total(self) -> float:
        return self._sum


class TimeWindowMean:
    """Incremental mean with O(1) eviction using paired sum and count."""

    __slots__ = ("_span", "_chron", "_sum", "_count")

    def __init__(self, span: timedelta) -> None:
        if span.total_seconds() <= 0:
            raise ValueError("span must be positive")
        self._span = span
        self._chron: Deque[tuple[datetime, float]] = deque()
        self._sum = 0.0
        self._count = 0

    @property
    def span(self) -> timedelta:
        return self._span

    def clear(self) -> None:
        self._chron.clear()
        self._sum = 0.0
        self._count = 0

    def __len__(self) -> int:
        return len(self._chron)

    def push(self, ts: datetime, value: float) -> None:
        if ts.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        for _, old in _evict_expired(self._chron, ts, self._span):
            self._sum -= old
            self._count -= 1
        self._chron.append((ts, value))
        self._sum += value
        self._count += 1

    def mean(self) -> float | None:
        if self._count == 0:
            return None
        return self._sum / self._count


class CountWindowMinMax:
    """Min/max over the last ``maxlen`` samples (most recent inclusive)."""

    __slots__ = ("_maxlen", "_chron", "_min_dq", "_max_dq")

    def __init__(self, maxlen: int) -> None:
        if maxlen <= 0:
            raise ValueError("maxlen must be positive")
        self._maxlen = maxlen
        self._chron: Deque[tuple[datetime, float]] = deque()
        self._min_dq: Deque[tuple[datetime, float]] = deque()
        self._max_dq: Deque[tuple[datetime, float]] = deque()

    @property
    def maxlen(self) -> int:
        return self._maxlen

    def clear(self) -> None:
        self._chron.clear()
        self._min_dq.clear()
        self._max_dq.clear()

    def push(self, ts: datetime, value: float) -> None:
        if ts.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        if len(self._chron) >= self._maxlen:
            oldest_ts, oldest_val = self._chron.popleft()
            if self._min_dq and self._min_dq[0][0] == oldest_ts and self._min_dq[0][1] == oldest_val:
                self._min_dq.popleft()
            if self._max_dq and self._max_dq[0][0] == oldest_ts and self._max_dq[0][1] == oldest_val:
                self._max_dq.popleft()
        self._chron.append((ts, value))
        while self._min_dq and self._min_dq[-1][1] >= value:
            self._min_dq.pop()
        self._min_dq.append((ts, value))
        while self._max_dq and self._max_dq[-1][1] <= value:
            self._max_dq.pop()
        self._max_dq.append((ts, value))

    def min_max(self) -> WindowMinMax:
        if not self._min_dq:
            return WindowMinMax(minimum=None, maximum=None)
        return WindowMinMax(minimum=self._min_dq[0][1], maximum=self._max_dq[0][1])


def iter_window_min_max(
    points: Sequence[tuple[datetime, float]],
    span: timedelta,
) -> Iterator[tuple[datetime, WindowMinMax]]:
    """Offline sweep: after each push, yield ``(ts, WindowMinMax)`` for that step."""
    win = TimeWindowMinMax(span)
    for ts, v in points:
        win.push(ts, v)
        yield ts, win.min_max()


def merge_adjacent_windows(left: WindowMinMax, right: WindowMinMax) -> WindowMinMax:
    """Combine two disjoint window summaries (e.g. for parallel shards)."""
    if left.minimum is None:
        return right
    if right.minimum is None:
        return left
    return WindowMinMax(
        minimum=min(left.minimum, right.minimum),
        maximum=max(left.maximum, right.maximum),
    )
