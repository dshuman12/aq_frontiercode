"""Command-line entry point for the ``timewindow`` package.

Most subcommands accept a CSV file with ``timestamp,value`` rows so the tool
is useful for ad-hoc inspection, rebucketing and anomaly triage of metric
exports without writing any Python.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from timewindow.bucket import ceil_to_bucket, floor_to_bucket
from timewindow.csvio import read_series_path, write_series_path
from timewindow.cursors import HoppingCursor, TumblingCursor
from timewindow.duration import format_duration_seconds, parse_duration_to_seconds
from timewindow.http_api import HttpServer
from timewindow.intervals import iter_bucket_intervals
from timewindow.query import QueryContext, execute, supported_operators
from timewindow.recipes import (
    DetectionConfig,
    RebucketRequest,
    RollupRequest,
    analyze_series,
    detect_all,
    lint_series,
    rebucket_series,
    run_tiered_rollup,
)
from timewindow.report import (
    histogram_of_values,
    render_anomaly_report_json,
    render_anomaly_report_text,
    render_histogram_text,
    render_series_summary_json,
    render_series_summary_text,
    summarize_anomalies,
    summarize_series,
)
from timewindow.scheduler import IntervalTrigger, Scheduler
from timewindow.serde import format_instant_iso8601, parse_instant_iso8601
from timewindow.storage import SeriesStore, append_csv_to_store, open_store
from timewindow.tiered_rollups import RollupPropagation


def _parse_instant(value: str) -> datetime:
    return parse_instant_iso8601(value)


def _emit(text: str) -> None:
    fp = sys.stdout
    fp.write(text)
    if not text.endswith("\n"):
        fp.write("\n")


def _cmd_floor(args: argparse.Namespace) -> int:
    dt = _parse_instant(args.instant)
    floored = floor_to_bucket(dt, args.bucket)
    _emit(format_instant_iso8601(floored))
    return 0


def _cmd_ceil(args: argparse.Namespace) -> int:
    dt = _parse_instant(args.instant)
    ceiled = ceil_to_bucket(dt, args.bucket)
    _emit(format_instant_iso8601(ceiled))
    return 0


def _cmd_parse_duration(args: argparse.Namespace) -> int:
    seconds = parse_duration_to_seconds(args.text)
    _emit(f"{seconds:.9f}")
    return 0


def _cmd_format_duration(args: argparse.Namespace) -> int:
    _emit(format_duration_seconds(args.seconds))
    return 0


def _cmd_buckets(args: argparse.Namespace) -> int:
    start = _parse_instant(args.start)
    end = _parse_instant(args.end)
    for window in iter_bucket_intervals(start, end, args.width):
        _emit(
            f"{format_instant_iso8601(window.start)} .. {format_instant_iso8601(window.end)}"
        )
    return 0


def _cmd_tumbling(args: argparse.Namespace) -> int:
    moment = _parse_instant(args.instant)
    cursor = TumblingCursor(bucket_seconds=args.bucket)
    window = cursor.window_containing(moment)
    _emit(f"{format_instant_iso8601(window.start)} .. {format_instant_iso8601(window.end)}")
    return 0


def _cmd_hops(args: argparse.Namespace) -> int:
    start = _parse_instant(args.start)
    end = _parse_instant(args.end)
    hopper = HoppingCursor(window_seconds=args.window, hop_seconds=args.hop)
    for window in hopper.windows_covering(start, end):
        _emit(
            f"{format_instant_iso8601(window.start)} .. {format_instant_iso8601(window.end)}"
        )
    return 0


def _cmd_summary(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    summary = summarize_series(points)
    if args.format == "json":
        _emit(render_series_summary_json(summary, indent=2 if args.pretty else None))
    else:
        _emit(render_series_summary_text(summary))
    return 0


def _cmd_histogram(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    bins = histogram_of_values(points, bins=args.bins)
    _emit(render_histogram_text(bins, width=args.width))
    return 0


def _cmd_rebucket(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    request = RebucketRequest(
        bucket_seconds=args.bucket,
        aggregation=args.aggregation,
        fill_method=args.fill,
        fill_value=args.fill_value,
    )
    rolled = rebucket_series(points, request)
    if args.output is None:
        for p in rolled:
            _emit(f"{format_instant_iso8601(p.ts)},{p.value!r}")
        return 0
    n = write_series_path(args.output, rolled)
    _emit(f"wrote {n} rows to {args.output}")
    return 0


def _cmd_detect(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    cfg = DetectionConfig(
        spike_window=args.spike_window,
        spike_threshold=args.spike_threshold,
        spike_warmup=args.spike_warmup,
        level_left_window=args.level_window,
        level_right_window=args.level_window,
        level_min_shift=args.level_min_shift,
        stale_window=args.stale_window,
        stale_max_std=args.stale_max_std,
        expected_step_seconds=args.expected_step,
        gap_tolerance=args.gap_tolerance,
        change_point_window=args.change_point_window,
        change_point_threshold=args.change_point_threshold,
        residual_window=args.residual_window,
        residual_z_threshold=args.residual_threshold,
        merge_gap_seconds=args.merge_gap,
    )
    events = detect_all(points, cfg)
    report = summarize_anomalies(events, top_k=args.top_k)
    if args.format == "json":
        _emit(render_anomaly_report_json(report, indent=2 if args.pretty else None))
    else:
        _emit(render_anomaly_report_text(report))
    return 0 if (not args.fail_on_findings or report.total == 0) else 2


def _cmd_rollup(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    propagation = RollupPropagation.COUNTER if args.propagation == "counter" else RollupPropagation.GAUGE
    request = RollupRequest(
        bucket_widths_seconds=tuple(args.widths),
        propagation=propagation,
    )
    result = run_tiered_rollup(points, request)
    payload: dict[str, list[dict[str, object]]] = {}
    for level, items in sorted(result.layers.items()):
        payload[str(level)] = [
            {
                "bucket_start": format_instant_iso8601(b.bucket_start),
                "bucket_width_seconds": b.bucket_width_seconds,
                "count": b.count,
                "sum": b.sum,
                "min": None if b.count == 0 else b.min,
                "max": None if b.count == 0 else b.max,
                "last": None if b.count == 0 else b.last,
            }
            for b in items
        ]
    indent = 2 if args.pretty else None
    _emit(json.dumps(payload, indent=indent, sort_keys=True))
    return 0


def _cmd_lint(args: argparse.Namespace) -> int:
    points = read_series_path(args.input)
    warnings = lint_series(points)
    if not warnings:
        _emit("ok: no issues detected")
        return 0
    for w in warnings:
        _emit(f"warning: {w}")
    return 0 if not args.strict else 2


def _cmd_store_list(args: argparse.Namespace) -> int:
    store = open_store(args.root, durable=False)
    for name in store.list_series():
        meta = store.stats(name)
        _emit(f"{name}\tpoints={meta.points}\tframes={meta.frames}")
    return 0


def _cmd_store_ingest(args: argparse.Namespace) -> int:
    store = open_store(args.root)
    n = append_csv_to_store(store, args.name, args.input)
    _emit(f"appended {n} points to {args.name}")
    return 0


def _cmd_store_compact(args: argparse.Namespace) -> int:
    store = open_store(args.root)
    n = store.compact(args.name)
    _emit(f"compacted {args.name} to {n} points")
    return 0


def _cmd_store_drop(args: argparse.Namespace) -> int:
    store = open_store(args.root)
    if store.drop(args.name):
        _emit(f"dropped {args.name}")
        return 0
    _emit(f"no such series: {args.name}")
    return 1


def _cmd_query(args: argparse.Namespace) -> int:
    store = open_store(args.root, durable=False)
    result = execute(args.query, QueryContext(store=store))
    payload = {
        "kind": result.kind,
        "scalar": result.scalar,
        "points": [
            {"timestamp": format_instant_iso8601(p.ts), "value": p.value}
            for p in result.points
        ],
    }
    indent = 2 if args.pretty else None
    _emit(json.dumps(payload, indent=indent, sort_keys=True))
    return 0


def _cmd_query_help(_args: argparse.Namespace) -> int:
    for op in supported_operators():
        _emit(op)
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    store = open_store(args.root)
    server = HttpServer(store, host=args.host, port=args.port).start()
    try:
        _emit(f"listening on {server.url} (Ctrl-C to stop)")
        try:
            import signal
            import threading

            stop = threading.Event()

            def _handler(_sig, _frame) -> None:
                stop.set()

            signal.signal(signal.SIGINT, _handler)
            signal.signal(signal.SIGTERM, _handler)
            stop.wait()
        except KeyboardInterrupt:
            pass
    finally:
        server.stop()
    return 0


def _cmd_schedule_demo(args: argparse.Namespace) -> int:
    sched = Scheduler()
    fired: list[str] = []
    sched.schedule(
        "tick",
        lambda when: fired.append(format_instant_iso8601(when)),
        IntervalTrigger(every_seconds=args.every, aligned=False),
    )
    deadline_iso = args.until
    deadline = parse_instant_iso8601(deadline_iso) if deadline_iso else None
    if deadline is None:
        from datetime import timedelta

        deadline = sched.now() + timedelta(seconds=max(1, args.for_seconds))
    sched.run_until(deadline, sleep_seconds=0.05)
    payload = {"fired": fired, "jobs": [j.name for j in sched.jobs()]}
    _emit(json.dumps(payload, indent=2 if args.pretty else None, sort_keys=True))
    return 0


def _cmd_analyze(args: argparse.Namespace) -> int:
    rebucket = (
        RebucketRequest(
            bucket_seconds=args.bucket,
            aggregation=args.aggregation,
            fill_method=args.fill,
            fill_value=args.fill_value,
        )
        if args.bucket
        else None
    )
    points = read_series_path(args.input)
    result = analyze_series(
        points,
        rebucket=rebucket,
        smoothing_window=args.smoothing,
        detrend=args.detrend,
    )
    payload = {
        "summary": result.summary.to_dict(),
        "anomalies": result.anomaly_report.to_dict(),
        "rolled_count": len(result.rolled),
        "cleaned_count": len(result.cleaned),
    }
    indent = 2 if args.pretty else None
    _emit(json.dumps(payload, indent=indent, sort_keys=True))
    return 0


def _add_common_input(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("input", type=Path, help="path to a timestamp,value CSV file")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="timewindow",
        description="Practical UTC bucketing, summary, and anomaly tooling.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_floor = sub.add_parser("floor", help="floor an instant to a bucket boundary")
    p_floor.add_argument("instant", help="ISO-8601 timestamp with timezone or Z")
    p_floor.add_argument("bucket", type=int, help="bucket width in seconds")
    p_floor.set_defaults(func=_cmd_floor)

    p_ceil = sub.add_parser("ceil", help="ceil an instant to the next bucket boundary")
    p_ceil.add_argument("instant")
    p_ceil.add_argument("bucket", type=int)
    p_ceil.set_defaults(func=_cmd_ceil)

    p_pd = sub.add_parser("parse-duration", help="parse a duration string to seconds")
    p_pd.add_argument("text")
    p_pd.set_defaults(func=_cmd_parse_duration)

    p_fd = sub.add_parser("format-duration", help="format seconds as a compact duration")
    p_fd.add_argument("seconds", type=float)
    p_fd.set_defaults(func=_cmd_format_duration)

    p_b = sub.add_parser("buckets", help="print bucket slices covering a range")
    p_b.add_argument("--start", required=True)
    p_b.add_argument("--end", required=True)
    p_b.add_argument("--width", type=int, required=True)
    p_b.set_defaults(func=_cmd_buckets)

    p_t = sub.add_parser("tumbling", help="show the tumbling window containing an instant")
    p_t.add_argument("instant")
    p_t.add_argument("--bucket", type=int, required=True)
    p_t.set_defaults(func=_cmd_tumbling)

    p_h = sub.add_parser("hops", help="print hopping windows covering a range")
    p_h.add_argument("--start", required=True)
    p_h.add_argument("--end", required=True)
    p_h.add_argument("--window", type=int, required=True)
    p_h.add_argument("--hop", type=int, required=True)
    p_h.set_defaults(func=_cmd_hops)

    p_sum = sub.add_parser("summary", help="describe a CSV series (count, range, stats)")
    _add_common_input(p_sum)
    p_sum.add_argument("--format", choices=("text", "json"), default="text")
    p_sum.add_argument("--pretty", action="store_true", help="pretty-print JSON output")
    p_sum.set_defaults(func=_cmd_summary)

    p_hist = sub.add_parser("histogram", help="render a value histogram for a CSV series")
    _add_common_input(p_hist)
    p_hist.add_argument("--bins", type=int, default=10)
    p_hist.add_argument("--width", type=int, default=30)
    p_hist.set_defaults(func=_cmd_histogram)

    p_re = sub.add_parser("rebucket", help="re-aggregate a CSV series to a coarser bucket size")
    _add_common_input(p_re)
    p_re.add_argument("--bucket", type=int, required=True, help="target bucket width in seconds")
    p_re.add_argument("--aggregation", choices=("mean", "sum"), default="mean")
    p_re.add_argument("--fill", choices=("ffill", "zero", "const", "none"), default="ffill")
    p_re.add_argument("--fill-value", type=float, default=0.0)
    p_re.add_argument("--output", type=Path, help="optional CSV output path")
    p_re.set_defaults(func=_cmd_rebucket)

    p_d = sub.add_parser("detect", help="run anomaly detectors against a CSV series")
    _add_common_input(p_d)
    p_d.add_argument("--spike-window", type=int, default=20)
    p_d.add_argument("--spike-threshold", type=float, default=3.5)
    p_d.add_argument("--spike-warmup", type=int, default=10)
    p_d.add_argument("--level-window", type=int, default=20)
    p_d.add_argument("--level-min-shift", type=float, default=2.0)
    p_d.add_argument("--stale-window", type=int, default=30)
    p_d.add_argument("--stale-max-std", type=float, default=1e-9)
    p_d.add_argument("--expected-step", type=float, default=None)
    p_d.add_argument("--gap-tolerance", type=float, default=1.5)
    p_d.add_argument("--change-point-window", type=int, default=21)
    p_d.add_argument("--change-point-threshold", type=float, default=6.0)
    p_d.add_argument("--residual-window", type=int, default=15)
    p_d.add_argument("--residual-threshold", type=float, default=3.0)
    p_d.add_argument("--merge-gap", type=float, default=0.0)
    p_d.add_argument("--top-k", type=int, default=5)
    p_d.add_argument("--format", choices=("text", "json"), default="text")
    p_d.add_argument("--pretty", action="store_true")
    p_d.add_argument(
        "--fail-on-findings",
        action="store_true",
        help="exit code 2 when any anomaly is reported (useful for CI checks)",
    )
    p_d.set_defaults(func=_cmd_detect)

    p_ru = sub.add_parser("rollup", help="run tiered rollups across multiple bucket widths")
    _add_common_input(p_ru)
    p_ru.add_argument(
        "--widths",
        type=int,
        nargs="+",
        required=True,
        help="bucket widths in seconds, finest first (e.g. --widths 60 300 3600)",
    )
    p_ru.add_argument("--propagation", choices=("gauge", "counter"), default="gauge")
    p_ru.add_argument("--pretty", action="store_true")
    p_ru.set_defaults(func=_cmd_rollup)

    p_l = sub.add_parser("lint", help="report common shape issues in a CSV series")
    _add_common_input(p_l)
    p_l.add_argument(
        "--strict",
        action="store_true",
        help="exit code 2 when any warning is emitted (useful for CI checks)",
    )
    p_l.set_defaults(func=_cmd_lint)

    p_an = sub.add_parser(
        "analyze",
        help="end-to-end pipeline: rebucket -> smooth -> detect -> JSON report",
    )
    _add_common_input(p_an)
    p_an.add_argument("--bucket", type=int, default=None, help="optional rebucket width")
    p_an.add_argument("--aggregation", choices=("mean", "sum"), default="mean")
    p_an.add_argument("--fill", choices=("ffill", "zero", "const", "none"), default="ffill")
    p_an.add_argument("--fill-value", type=float, default=0.0)
    p_an.add_argument("--smoothing", type=int, default=0, help="moving-average window (0 disables)")
    p_an.add_argument("--detrend", action="store_true", help="subtract a linear trend before detecting")
    p_an.add_argument("--pretty", action="store_true")
    p_an.set_defaults(func=_cmd_analyze)

    p_sl = sub.add_parser("store-list", help="list series stored under a directory")
    p_sl.add_argument("--root", type=Path, required=True)
    p_sl.set_defaults(func=_cmd_store_list)

    p_si = sub.add_parser("store-ingest", help="append a CSV series into the store")
    p_si.add_argument("--root", type=Path, required=True)
    p_si.add_argument("--name", required=True)
    _add_common_input(p_si)
    p_si.set_defaults(func=_cmd_store_ingest)

    p_sc = sub.add_parser("store-compact", help="rewrite a series file as one dense frame")
    p_sc.add_argument("--root", type=Path, required=True)
    p_sc.add_argument("--name", required=True)
    p_sc.set_defaults(func=_cmd_store_compact)

    p_sd = sub.add_parser("store-drop", help="remove a series from the store")
    p_sd.add_argument("--root", type=Path, required=True)
    p_sd.add_argument("--name", required=True)
    p_sd.set_defaults(func=_cmd_store_drop)

    p_q = sub.add_parser("query", help="run a query DSL against a series store")
    p_q.add_argument("--root", type=Path, required=True)
    p_q.add_argument("query", help="pipeline DSL, e.g. 'series(\"cpu\") | mean()'")
    p_q.add_argument("--pretty", action="store_true")
    p_q.set_defaults(func=_cmd_query)

    p_qh = sub.add_parser("query-help", help="list query DSL operators")
    p_qh.set_defaults(func=_cmd_query_help)

    p_serve = sub.add_parser("serve", help="serve the HTTP API in front of a series store")
    p_serve.add_argument("--root", type=Path, required=True)
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=8910)
    p_serve.set_defaults(func=_cmd_serve)

    p_demo = sub.add_parser("schedule-demo", help="run a tiny in-process scheduler demo")
    p_demo.add_argument("--every", type=int, default=1, help="tick interval in seconds")
    p_demo.add_argument("--for-seconds", type=int, default=2, help="duration to run")
    p_demo.add_argument("--until", default=None, help="optional ISO-8601 stop time")
    p_demo.add_argument("--pretty", action="store_true")
    p_demo.set_defaults(func=_cmd_schedule_demo)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:  # pragma: no cover - CLI surface
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
