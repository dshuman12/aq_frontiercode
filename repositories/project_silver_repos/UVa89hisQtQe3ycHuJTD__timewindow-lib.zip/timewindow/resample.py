from __future__ import annotations

from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Sequence

from timewindow.bucket import floor_to_bucket
from timewindow.intervals import TimeInterval, iter_bucket_intervals


@dataclass(frozen=True, slots=True)
class Sample:
    """A single time-stamped scalar observation."""

    when: datetime
    value: float


def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        raise ValueError("samples must be timezone-aware")
    return dt.astimezone(timezone.utc)


def resample_last_value(
    samples: Iterable[Sample],
    start: datetime,
    end: datetime,
    bucket_seconds: int,
) -> list[tuple[TimeInterval, float | None]]:
    """
    For each bucket in ``[start, end)``, pick the last sample whose timestamp falls
    inside the bucket. Buckets with no samples yield ``None``.
    """
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("start and end must be timezone-aware")
    utc_start = _utc(start)
    utc_end = _utc(end)
    if utc_start >= utc_end:
        raise ValueError("end must be after start")

    last_by_bucket: dict[datetime, float] = {}
    for sample in samples:
        moment = _utc(sample.when)
        if moment < utc_start or moment >= utc_end:
            continue
        bucket_start = floor_to_bucket(moment, bucket_seconds)
        last_by_bucket[bucket_start] = sample.value

    out: list[tuple[TimeInterval, float | None]] = []
    for window in iter_bucket_intervals(utc_start, utc_end, bucket_seconds):
        out.append((window, last_by_bucket.get(window.start)))
    return out


def resample_sum(
    samples: Iterable[Sample],
    start: datetime,
    end: datetime,
    bucket_seconds: int,
) -> list[tuple[TimeInterval, float]]:
    """Sum all samples whose timestamps fall inside each bucket window."""
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    utc_start = _utc(start)
    utc_end = _utc(end)
    sums: dict[datetime, float] = defaultdict(float)
    for sample in samples:
        moment = _utc(sample.when)
        if moment < utc_start or moment >= utc_end:
            continue
        bucket_start = floor_to_bucket(moment, bucket_seconds)
        sums[bucket_start] += sample.value

    out: list[tuple[TimeInterval, float]] = []
    for window in iter_bucket_intervals(utc_start, utc_end, bucket_seconds):
        out.append((window, float(sums.get(window.start, 0.0))))
    return out


def align_samples_to_bucket_starts(
    samples: Sequence[Sample],
    bucket_seconds: int,
) -> list[Sample]:
    """Return new samples with timestamps snapped to bucket starts (UTC)."""
    return [
        Sample(when=floor_to_bucket(_utc(sample.when), bucket_seconds), value=sample.value)
        for sample in samples
    ]


def piecewise_constant_series(
    samples: Sequence[Sample],
) -> tuple[list[datetime], list[float]]:
    """Build step-function arrays suitable for naive plotting."""
    ordered = sorted(samples, key=lambda s: _utc(s.when))
    if not ordered:
        return [], []
    times = [_utc(sample.when) for sample in ordered]
    values = [sample.value for sample in ordered]
    return times, values


def downsample_max(values: Sequence[float], max_points: int) -> list[float]:
    """Combine adjacent groups so at most ``max_points`` remain using ``max``."""
    if max_points <= 0:
        raise ValueError("max_points must be positive")
    if not values:
        return []
    if len(values) <= max_points:
        return list(values)
    chunk = max(1, (len(values) + max_points - 1) // max_points)
    out: list[float] = []
    for i in range(0, len(values), chunk):
        out.append(max(values[i : i + chunk]))
    return out


def value_histogram_per_bucket(
    samples: Iterable[Sample],
    start: datetime,
    end: datetime,
    bucket_seconds: int,
    bin_edges: Sequence[float],
) -> list[tuple[TimeInterval, dict[float, int]]]:
    """
    For each time bucket, count samples whose values fall into ``(prev, edge]`` bins.

    ``bin_edges`` must be strictly increasing finite positive floats.
    """
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    if len(bin_edges) < 1:
        raise ValueError("bin_edges required")
    prev = 0.0
    for edge in bin_edges:
        if edge <= prev:
            raise ValueError("bin_edges must be strictly increasing")
        prev = edge

    utc_start = _utc(start)
    utc_end = _utc(end)

    per_bucket: dict[datetime, dict[float, int]] = defaultdict(lambda: defaultdict(int))
    for sample in samples:
        moment = _utc(sample.when)
        if moment < utc_start or moment >= utc_end:
            continue
        bucket_start = floor_to_bucket(moment, bucket_seconds)
        idx = bisect_right(bin_edges, sample.value)
        if idx <= 0:
            continue
        edge = bin_edges[idx - 1]
        per_bucket[bucket_start][edge] += 1

    out: list[tuple[TimeInterval, dict[float, int]]] = []
    for window in iter_bucket_intervals(utc_start, utc_end, bucket_seconds):
        out.append((window, dict(per_bucket.get(window.start, {}))))
    return out
