"""Anomaly detection helpers for operational time-series."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from statistics import mean, median
from typing import Sequence

from timewindow.series_math import SeriesPoint, ensure_monotonic, moving_average, rolling_std, zscore


@dataclass(frozen=True, slots=True)
class AnomalyEvent:
    ts: datetime
    value: float
    score: float
    kind: str
    detail: str


@dataclass(frozen=True, slots=True)
class ZScoreConfig:
    window: int = 20
    threshold: float = 3.0
    warmup: int = 10


def _mad(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    med = median(values)
    return median([abs(v - med) for v in values])


def detect_spikes_zscore(
    points: Sequence[SeriesPoint],
    *,
    config: ZScoreConfig = ZScoreConfig(),
) -> list[AnomalyEvent]:
    """Detect point spikes using rolling z-score over a trailing window."""
    if config.window <= 1:
        raise ValueError("window must be > 1")
    if config.threshold <= 0:
        raise ValueError("threshold must be positive")
    ensure_monotonic(points)
    if not points:
        return []

    events: list[AnomalyEvent] = []
    trail: list[float] = []
    for p in points:
        trail.append(p.value)
        if len(trail) > config.window:
            trail.pop(0)
        if len(trail) < max(config.warmup, 2):
            continue
        mu = mean(trail[:-1])
        sd = (mean((v - mu) ** 2 for v in trail[:-1])) ** 0.5
        if sd == 0.0:
            if p.value != mu:
                events.append(
                    AnomalyEvent(
                        ts=p.ts,
                        value=p.value,
                        score=float("inf"),
                        kind="spike",
                        detail=f"zero-variance baseline; value={p.value:.3f} mean={mu:.3f}",
                    )
                )
            continue
        s = abs((p.value - mu) / sd)
        if s >= config.threshold:
            events.append(
                AnomalyEvent(
                    ts=p.ts,
                    value=p.value,
                    score=s,
                    kind="spike",
                    detail=f"|z|={s:.3f} >= {config.threshold}",
                )
            )
    return events


def detect_level_shift(
    points: Sequence[SeriesPoint],
    *,
    left_window: int = 20,
    right_window: int = 20,
    min_shift: float = 2.0,
) -> list[AnomalyEvent]:
    """Detect mean-level shifts between trailing and leading windows."""
    if left_window <= 1 or right_window <= 1:
        raise ValueError("window sizes must be > 1")
    if min_shift <= 0:
        raise ValueError("min_shift must be positive")
    ensure_monotonic(points)
    if len(points) < left_window + right_window:
        return []
    events: list[AnomalyEvent] = []
    vals = [p.value for p in points]
    for i in range(left_window, len(points) - right_window):
        left = vals[i - left_window : i]
        right = vals[i : i + right_window]
        lmu = mean(left)
        rmu = mean(right)
        shift = rmu - lmu
        pooled = (mean((v - lmu) ** 2 for v in left) + mean((v - rmu) ** 2 for v in right)) / 2.0
        scale = max(pooled**0.5, 1e-9)
        score = abs(shift) / scale
        if abs(shift) >= min_shift:
            events.append(
                AnomalyEvent(
                    ts=points[i].ts,
                    value=points[i].value,
                    score=score,
                    kind="level_shift",
                    detail=f"shift={shift:.3f}",
                )
            )
    return events


def detect_stale_series(
    points: Sequence[SeriesPoint],
    *,
    window: int = 30,
    max_std: float = 1e-9,
) -> list[AnomalyEvent]:
    """Detect stale flatlines by checking rolling std against a tiny threshold."""
    if window <= 1:
        raise ValueError("window must be > 1")
    if max_std < 0:
        raise ValueError("max_std must be >= 0")
    ensure_monotonic(points)
    if len(points) < window:
        return []
    stds = rolling_std(points, window)
    out: list[AnomalyEvent] = []
    for i, s in enumerate(stds):
        if i < window - 1:
            continue
        if s.value <= max_std:
            p = points[i]
            out.append(
                AnomalyEvent(
                    ts=p.ts,
                    value=p.value,
                    score=(max_std - s.value) + 1.0,
                    kind="stale",
                    detail=f"rolling_std={s.value:.9f}",
                )
            )
    return out


def detect_gaps(
    points: Sequence[SeriesPoint],
    *,
    expected_step: timedelta,
    tolerance: float = 1.5,
) -> list[AnomalyEvent]:
    """Detect missing data gaps based on expected step duration."""
    if expected_step.total_seconds() <= 0:
        raise ValueError("expected_step must be positive")
    if tolerance <= 1.0:
        raise ValueError("tolerance must be > 1")
    ensure_monotonic(points)
    out: list[AnomalyEvent] = []
    target = expected_step.total_seconds() * tolerance
    for prev, cur in zip(points, points[1:]):
        delta = (cur.ts - prev.ts).total_seconds()
        if delta > target:
            out.append(
                AnomalyEvent(
                    ts=cur.ts,
                    value=cur.value,
                    score=delta / expected_step.total_seconds(),
                    kind="gap",
                    detail=f"delta_seconds={delta:.1f}",
                )
            )
    return out


def detect_change_points_mad(
    points: Sequence[SeriesPoint],
    *,
    window: int = 21,
    threshold: float = 6.0,
) -> list[AnomalyEvent]:
    """Robust change-point detector based on median absolute deviation."""
    if window < 5 or window % 2 == 0:
        raise ValueError("window must be odd and >= 5")
    if threshold <= 0:
        raise ValueError("threshold must be positive")
    ensure_monotonic(points)
    if len(points) < window:
        return []
    half = window // 2
    out: list[AnomalyEvent] = []
    vals = [p.value for p in points]
    for i in range(half, len(points) - half):
        segment = vals[i - half : i + half + 1]
        med = median(segment)
        mad = _mad(segment)
        if mad == 0.0:
            if vals[i] != med:
                out.append(
                    AnomalyEvent(
                        ts=points[i].ts,
                        value=points[i].value,
                        score=float("inf"),
                        kind="change_point",
                        detail="zero-mad segment with non-median center",
                    )
                )
            continue
        s = abs(vals[i] - med) / (1.4826 * mad)
        if s >= threshold:
            out.append(
                AnomalyEvent(
                    ts=points[i].ts,
                    value=points[i].value,
                    score=s,
                    kind="change_point",
                    detail=f"mad_score={s:.3f}",
                )
            )
    return out


def detect_residual_anomalies(
    points: Sequence[SeriesPoint],
    *,
    trend_window: int = 15,
    z_threshold: float = 3.0,
) -> list[AnomalyEvent]:
    """Detect anomalies in residuals after subtracting moving-average trend."""
    if trend_window <= 1:
        raise ValueError("trend_window must be > 1")
    ensure_monotonic(points)
    if len(points) < trend_window + 3:
        return []
    trend = moving_average(points, trend_window)
    residuals = [SeriesPoint(p.ts, p.value - t.value) for p, t in zip(points, trend)]
    zs = zscore(residuals)
    out: list[AnomalyEvent] = []
    for p, zr in zip(points, zs):
        s = abs(zr.value)
        if s >= z_threshold:
            out.append(
                AnomalyEvent(
                    ts=p.ts,
                    value=p.value,
                    score=s,
                    kind="residual",
                    detail=f"|z_residual|={s:.3f}",
                )
            )
    return out


def merge_nearby_events(events: Sequence[AnomalyEvent], max_gap: timedelta) -> list[AnomalyEvent]:
    if max_gap.total_seconds() < 0:
        raise ValueError("max_gap must be >= 0")
    if not events:
        return []
    ordered = sorted(events, key=lambda e: e.ts)
    merged: list[AnomalyEvent] = [ordered[0]]
    for e in ordered[1:]:
        prev = merged[-1]
        if e.ts - prev.ts <= max_gap and e.kind == prev.kind:
            merged[-1] = AnomalyEvent(
                ts=e.ts,
                value=e.value,
                score=max(prev.score, e.score),
                kind=e.kind,
                detail=f"{prev.detail}; {e.detail}",
            )
        else:
            merged.append(e)
    return merged


def top_k_events(events: Sequence[AnomalyEvent], k: int) -> list[AnomalyEvent]:
    if k < 0:
        raise ValueError("k must be >= 0")
    ordered = sorted(events, key=lambda e: e.score, reverse=True)
    return ordered[:k]
