"""A small, well-defined query language for ``timewindow`` series.

Grammar (informal):

    query     := pipeline
    pipeline  := source ('|' op)*
    source    := 'series' '(' STRING ')'
                | 'range' '(' STRING ',' STRING ',' DURATION ')'
    op        := 'rebucket' '(' INT (',' AGG)? ')'
                | 'where' '(' expr ')'
                | 'between' '(' STRING ',' STRING ')'
                | 'top' '(' INT ')'
                | 'bottom' '(' INT ')'
                | 'count' '(' ')'
                | 'sum' '(' ')'
                | 'mean' '(' ')'
                | 'min' '(' ')'
                | 'max' '(' ')'
                | 'limit' '(' INT ')'
                | 'offset' '(' INT ')'
                | 'fill' '(' AGG ')'
                | 'detect_spikes' '(' INT ',' FLOAT ')'
    expr      := 'value' OP NUM | 'value' 'in' NUM '..' NUM
    OP        := '>' | '<' | '>=' | '<=' | '==' | '!='
    AGG       := 'mean' | 'sum'
    DURATION  := compact duration string accepted by ``timewindow.duration``

Sources are resolved against a :class:`QueryContext` that wraps a
:class:`SeriesStore`; the pipeline is then evaluated lazily on the points
read from the store.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, Iterable, Sequence

from timewindow.duration import parse_duration_to_seconds
from timewindow.exceptions import ParseError, TimeWindowError
from timewindow.serde import parse_instant_iso8601
from timewindow.series_math import (
    SeriesPoint,
    fill_bucket_gaps,
    rebucket_mean,
    rebucket_sum,
)
from timewindow.storage import SeriesStore


# ---------------------------------------------------------------------------
# Lexer
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Token:
    kind: str
    value: str
    pos: int


_SINGLE = {"(", ")", ",", "|"}
_KEYWORDS = {
    "series",
    "range",
    "rebucket",
    "where",
    "between",
    "top",
    "bottom",
    "count",
    "sum",
    "mean",
    "min",
    "max",
    "limit",
    "offset",
    "fill",
    "detect_spikes",
    "value",
    "in",
}


def lex(source: str) -> list[Token]:
    out: list[Token] = []
    i = 0
    while i < len(source):
        ch = source[i]
        if ch.isspace():
            i += 1
            continue
        if ch in _SINGLE:
            out.append(Token(ch, ch, i))
            i += 1
            continue
        if ch == '"' or ch == "'":
            quote = ch
            j = i + 1
            buf: list[str] = []
            while j < len(source) and source[j] != quote:
                if source[j] == "\\" and j + 1 < len(source):
                    buf.append(source[j + 1])
                    j += 2
                    continue
                buf.append(source[j])
                j += 1
            if j >= len(source):
                raise ParseError(f"unterminated string at {i}")
            out.append(Token("STRING", "".join(buf), i))
            i = j + 1
            continue
        if ch == "." and i + 1 < len(source) and source[i + 1] == ".":
            out.append(Token("..", "..", i))
            i += 2
            continue
        if ch in "<>!=":
            two = source[i : i + 2]
            if two in {"<=", ">=", "==", "!="}:
                out.append(Token("OP", two, i))
                i += 2
                continue
            if ch in "<>":
                out.append(Token("OP", ch, i))
                i += 1
                continue
            raise ParseError(f"unexpected character {ch!r} at {i}")
        if ch.isdigit() or (ch == "-" and i + 1 < len(source) and source[i + 1].isdigit()):
            j = i + 1
            seen_dot = False
            while j < len(source) and (source[j].isdigit() or (source[j] == "." and not seen_dot)):
                if source[j] == ".":
                    if j + 1 < len(source) and source[j + 1] == ".":
                        break  # range operator
                    seen_dot = True
                j += 1
            text = source[i:j]
            kind = "FLOAT" if "." in text else "INT"
            out.append(Token(kind, text, i))
            i = j
            continue
        if ch.isalpha() or ch == "_":
            j = i + 1
            while j < len(source) and (source[j].isalnum() or source[j] == "_"):
                j += 1
            text = source[i:j]
            kind = text if text in _KEYWORDS else "IDENT"
            out.append(Token(kind, text, i))
            i = j
            continue
        raise ParseError(f"unexpected character {ch!r} at {i}")
    out.append(Token("EOF", "", len(source)))
    return out


# ---------------------------------------------------------------------------
# AST nodes
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SourceSeries:
    name: str


@dataclass(frozen=True, slots=True)
class SourceRange:
    name: str
    start: datetime
    bucket_seconds: int


@dataclass(frozen=True, slots=True)
class OpRebucket:
    bucket_seconds: int
    aggregation: str = "mean"


@dataclass(frozen=True, slots=True)
class OpWhere:
    op: str
    threshold: float


@dataclass(frozen=True, slots=True)
class OpRange:
    low: float
    high: float


@dataclass(frozen=True, slots=True)
class OpBetween:
    start: datetime
    end: datetime


@dataclass(frozen=True, slots=True)
class OpTop:
    k: int


@dataclass(frozen=True, slots=True)
class OpBottom:
    k: int


@dataclass(frozen=True, slots=True)
class OpAggregate:
    kind: str  # count, sum, mean, min, max


@dataclass(frozen=True, slots=True)
class OpLimit:
    n: int


@dataclass(frozen=True, slots=True)
class OpOffset:
    n: int


@dataclass(frozen=True, slots=True)
class OpFill:
    aggregation: str


@dataclass(frozen=True, slots=True)
class OpDetectSpikes:
    window: int
    threshold: float


Source = SourceSeries | SourceRange
Op = (
    OpRebucket
    | OpWhere
    | OpRange
    | OpBetween
    | OpTop
    | OpBottom
    | OpAggregate
    | OpLimit
    | OpOffset
    | OpFill
    | OpDetectSpikes
)


@dataclass(frozen=True, slots=True)
class Pipeline:
    source: Source
    ops: tuple[Op, ...]


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class _Parser:
    def __init__(self, tokens: list[Token]) -> None:
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset: int = 0) -> Token:
        return self.tokens[self.pos + offset]

    def eat(self, kind: str, value: str | None = None) -> Token:
        tok = self.peek()
        if tok.kind != kind:
            raise ParseError(f"expected {kind} at {tok.pos}, found {tok.kind} {tok.value!r}")
        if value is not None and tok.value != value:
            raise ParseError(f"expected {value!r} at {tok.pos}, found {tok.value!r}")
        self.pos += 1
        return tok

    def parse_pipeline(self) -> Pipeline:
        source = self.parse_source()
        ops: list[Op] = []
        while self.peek().kind == "|":
            self.eat("|")
            ops.append(self.parse_op())
        if self.peek().kind != "EOF":
            raise ParseError(f"trailing tokens at {self.peek().pos}: {self.peek().value!r}")
        return Pipeline(source=source, ops=tuple(ops))

    def parse_source(self) -> Source:
        tok = self.peek()
        if tok.kind == "series":
            self.eat("series")
            self.eat("(")
            name = self.eat("STRING").value
            self.eat(")")
            return SourceSeries(name=name)
        if tok.kind == "range":
            self.eat("range")
            self.eat("(")
            name = self.eat("STRING").value
            self.eat(",")
            start = parse_instant_iso8601(self.eat("STRING").value)
            self.eat(",")
            duration = self.eat("STRING").value
            self.eat(")")
            return SourceRange(
                name=name,
                start=start,
                bucket_seconds=int(parse_duration_to_seconds(duration)),
            )
        raise ParseError(f"unknown source {tok.value!r} at {tok.pos}")

    def parse_op(self) -> Op:
        tok = self.peek()
        if tok.kind == "rebucket":
            self.eat("rebucket")
            self.eat("(")
            bucket = int(self.eat("INT").value)
            agg = "mean"
            if self.peek().kind == ",":
                self.eat(",")
                agg = self._consume_identifier()
            self.eat(")")
            return OpRebucket(bucket_seconds=bucket, aggregation=agg)
        if tok.kind == "where":
            self.eat("where")
            self.eat("(")
            self.eat("value")
            if self.peek().kind == "in":
                self.eat("in")
                low = float(self._number())
                self.eat("..")
                high = float(self._number())
                self.eat(")")
                return OpRange(low=low, high=high)
            op_tok = self.eat("OP")
            value = float(self._number())
            self.eat(")")
            return OpWhere(op=op_tok.value, threshold=value)
        if tok.kind == "between":
            self.eat("between")
            self.eat("(")
            start = parse_instant_iso8601(self.eat("STRING").value)
            self.eat(",")
            end = parse_instant_iso8601(self.eat("STRING").value)
            self.eat(")")
            return OpBetween(start=start, end=end)
        if tok.kind in {"top", "bottom"}:
            kind = self.eat(tok.kind).kind
            self.eat("(")
            n = int(self.eat("INT").value)
            self.eat(")")
            return OpTop(k=n) if kind == "top" else OpBottom(k=n)
        if tok.kind in {"count", "sum", "mean", "min", "max"}:
            kind = self.eat(tok.kind).kind
            self.eat("(")
            self.eat(")")
            return OpAggregate(kind=kind)
        if tok.kind == "limit":
            self.eat("limit")
            self.eat("(")
            n = int(self.eat("INT").value)
            self.eat(")")
            return OpLimit(n=n)
        if tok.kind == "offset":
            self.eat("offset")
            self.eat("(")
            n = int(self.eat("INT").value)
            self.eat(")")
            return OpOffset(n=n)
        if tok.kind == "fill":
            self.eat("fill")
            self.eat("(")
            agg = self._consume_identifier()
            self.eat(")")
            return OpFill(aggregation=agg)
        if tok.kind == "detect_spikes":
            self.eat("detect_spikes")
            self.eat("(")
            window = int(self.eat("INT").value)
            self.eat(",")
            threshold = float(self._number())
            self.eat(")")
            return OpDetectSpikes(window=window, threshold=threshold)
        raise ParseError(f"unknown operator {tok.value!r} at {tok.pos}")

    def _number(self) -> str:
        tok = self.peek()
        if tok.kind not in {"INT", "FLOAT"}:
            raise ParseError(f"expected number at {tok.pos}, found {tok.kind}")
        self.pos += 1
        return tok.value

    def _consume_identifier(self) -> str:
        """Accept either an IDENT or one of the reserved aggregate keywords."""
        tok = self.peek()
        if tok.kind == "IDENT" or tok.kind in {"mean", "sum", "min", "max", "count"}:
            self.pos += 1
            return tok.value
        raise ParseError(f"expected identifier at {tok.pos}, found {tok.kind}")


def parse_query(text: str) -> Pipeline:
    return _Parser(lex(text)).parse_pipeline()


# ---------------------------------------------------------------------------
# Evaluator
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class QueryResult:
    points: list[SeriesPoint] = field(default_factory=list)
    scalar: float | None = None
    kind: str = "series"

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind,
            "scalar": self.scalar,
            "points": [
                {"timestamp": p.ts.isoformat(), "value": p.value}
                for p in self.points
            ],
        }


@dataclass(frozen=True, slots=True)
class QueryContext:
    store: SeriesStore


def _load_source(ctx: QueryContext, source: Source) -> list[SeriesPoint]:
    if isinstance(source, SourceSeries):
        return ctx.store.read_all(source.name)
    if isinstance(source, SourceRange):
        all_points = ctx.store.read_all(source.name)
        return [p for p in all_points if p.ts >= source.start]
    raise TimeWindowError(f"unsupported source: {source}")


def _filter_points(points: list[SeriesPoint], op: str, threshold: float) -> list[SeriesPoint]:
    cmp_map: dict[str, Callable[[float, float], bool]] = {
        ">": lambda a, b: a > b,
        "<": lambda a, b: a < b,
        ">=": lambda a, b: a >= b,
        "<=": lambda a, b: a <= b,
        "==": lambda a, b: a == b,
        "!=": lambda a, b: a != b,
    }
    if op not in cmp_map:
        raise ParseError(f"unknown comparison operator {op!r}")
    fn = cmp_map[op]
    return [p for p in points if fn(p.value, threshold)]


def _apply_op(points: list[SeriesPoint], op: Op) -> tuple[list[SeriesPoint], float | None, str]:
    if isinstance(op, OpRebucket):
        if op.aggregation == "mean":
            return rebucket_mean(points, op.bucket_seconds), None, "series"
        if op.aggregation == "sum":
            return rebucket_sum(points, op.bucket_seconds), None, "series"
        raise ParseError(f"unsupported aggregation {op.aggregation!r}")
    if isinstance(op, OpWhere):
        return _filter_points(points, op.op, op.threshold), None, "series"
    if isinstance(op, OpRange):
        return [p for p in points if op.low <= p.value <= op.high], None, "series"
    if isinstance(op, OpBetween):
        return [p for p in points if op.start <= p.ts <= op.end], None, "series"
    if isinstance(op, OpTop):
        return sorted(points, key=lambda p: p.value, reverse=True)[: max(0, op.k)], None, "series"
    if isinstance(op, OpBottom):
        return sorted(points, key=lambda p: p.value)[: max(0, op.k)], None, "series"
    if isinstance(op, OpLimit):
        return points[: max(0, op.n)], None, "series"
    if isinstance(op, OpOffset):
        return points[max(0, op.n) :], None, "series"
    if isinstance(op, OpFill):
        if not points:
            return points, None, "series"
        deltas = [
            (b.ts - a.ts).total_seconds() for a, b in zip(points, points[1:])
        ]
        if not deltas:
            return points, None, "series"
        median_delta = sorted(deltas)[len(deltas) // 2] or 1
        return (
            fill_bucket_gaps(
                points,
                int(median_delta),
                method="ffill" if op.aggregation == "mean" else "zero",
            ),
            None,
            "series",
        )
    if isinstance(op, OpDetectSpikes):
        from timewindow.anomaly import ZScoreConfig, detect_spikes_zscore

        events = detect_spikes_zscore(
            points,
            config=ZScoreConfig(window=op.window, threshold=op.threshold, warmup=op.window // 2 or 2),
        )
        return [SeriesPoint(e.ts, e.value) for e in events], None, "series"
    if isinstance(op, OpAggregate):
        if not points:
            return [], None, "scalar"
        vals = [p.value for p in points]
        if op.kind == "count":
            return [], float(len(vals)), "scalar"
        if op.kind == "sum":
            return [], float(sum(vals)), "scalar"
        if op.kind == "mean":
            return [], sum(vals) / len(vals), "scalar"
        if op.kind == "min":
            return [], min(vals), "scalar"
        if op.kind == "max":
            return [], max(vals), "scalar"
    raise TimeWindowError(f"unsupported op: {op}")


def evaluate(pipeline: Pipeline, ctx: QueryContext) -> QueryResult:
    points = _load_source(ctx, pipeline.source)
    scalar: float | None = None
    kind = "series"
    for op in pipeline.ops:
        points, scalar, kind = _apply_op(points, op)
    return QueryResult(points=points, scalar=scalar, kind=kind)


def execute(text: str, ctx: QueryContext) -> QueryResult:
    """Parse and evaluate a query in one shot."""
    return evaluate(parse_query(text), ctx)


def explain(pipeline: Pipeline) -> str:
    """Render a pipeline as a multi-line, indented description."""
    lines = [f"source: {pipeline.source}"]
    for op in pipeline.ops:
        lines.append(f"  | {op}")
    return "\n".join(lines)


def supported_operators() -> list[str]:
    return sorted(
        {
            "series", "range", "rebucket", "where", "between", "top", "bottom",
            "count", "sum", "mean", "min", "max", "limit", "offset", "fill", "detect_spikes",
        }
    )


def query_to_string(pipeline: Pipeline) -> str:
    """Best-effort round-trip of a parsed query back into source text."""
    parts: list[str] = []
    if isinstance(pipeline.source, SourceSeries):
        parts.append(f"series({pipeline.source.name!r})")
    elif isinstance(pipeline.source, SourceRange):
        parts.append(
            f"range({pipeline.source.name!r}, "
            f"{pipeline.source.start.isoformat()!r}, '{pipeline.source.bucket_seconds}s')"
        )
    for op in pipeline.ops:
        if isinstance(op, OpRebucket):
            parts.append(f"rebucket({op.bucket_seconds}, {op.aggregation})")
        elif isinstance(op, OpWhere):
            parts.append(f"where(value {op.op} {op.threshold})")
        elif isinstance(op, OpRange):
            parts.append(f"where(value in {op.low}..{op.high})")
        elif isinstance(op, OpBetween):
            parts.append(f"between({op.start.isoformat()!r}, {op.end.isoformat()!r})")
        elif isinstance(op, OpTop):
            parts.append(f"top({op.k})")
        elif isinstance(op, OpBottom):
            parts.append(f"bottom({op.k})")
        elif isinstance(op, OpAggregate):
            parts.append(f"{op.kind}()")
        elif isinstance(op, OpLimit):
            parts.append(f"limit({op.n})")
        elif isinstance(op, OpOffset):
            parts.append(f"offset({op.n})")
        elif isinstance(op, OpFill):
            parts.append(f"fill({op.aggregation})")
        elif isinstance(op, OpDetectSpikes):
            parts.append(f"detect_spikes({op.window}, {op.threshold})")
    return " | ".join(parts)
