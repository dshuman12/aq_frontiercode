from __future__ import annotations

from datetime import datetime, timezone

from timewindow.exceptions import ParseError


def parse_instant_iso8601(value: str) -> datetime:
    """
    Parse an ISO-8601 instant with explicit offset or ``Z`` suffix.

    Returns a timezone-aware UTC datetime.
    """
    raw = value.strip()
    if not raw:
        raise ParseError("empty timestamp")
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError as exc:  # pragma: no cover - exercised via tests
        raise ParseError(f"invalid ISO-8601 instant: {value!r}") from exc
    if dt.tzinfo is None:
        raise ParseError("timestamp must include a timezone or use Z")
    return dt.astimezone(timezone.utc)


def format_instant_iso8601(moment: datetime) -> str:
    """Render ``moment`` as UTC with ``Z`` suffix."""
    if moment.tzinfo is None:
        raise ValueError("moment must be timezone-aware")
    text = moment.astimezone(timezone.utc).isoformat(timespec="microseconds")
    if text.endswith("+00:00"):
        return text[: -len("+00:00")] + "Z"
    return text
