"""Math and feature engineering helpers for timestamped scalar series."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from statistics import mean
from typing import Iterable, Sequence

from timewindow.bucket import floor_to_bucket


@dataclass(frozen=True, slots=True)
class SeriesPoint:
    ts: datetime
    value: float


def _require_aware(ts: datetime) -> None:
    if ts.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")


def ensure_monotonic(points: Sequence[SeriesPoint]) -> None:
    """Raise if timestamps are not non-decreasing."""
    prev: datetime | None = None
    for p in points:
        _require_aware(p.ts)
        if prev is not None and p.ts < prev:
            raise ValueError("series must be sorted by non-decreasing timestamp")
        prev = p.ts


def to_points(rows: Iterable[tuple[datetime, float]]) -> list[SeriesPoint]:
    out = [SeriesPoint(ts=t, value=v) for t, v in rows]
    ensure_monotonic(out)
    return out


def from_points(points: Iterable[SeriesPoint]) -> list[tuple[datetime, float]]:
    return [(p.ts, p.value) for p in points]


def fill_bucket_gaps(
    points: Sequence[SeriesPoint],
    bucket_seconds: int,
    *,
    method: str = "ffill",
    fill_value: float = 0.0,
) -> list[SeriesPoint]:
    """Fill bucket-aligned gaps between first and last point."""
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    ensure_monotonic(points)
    if not points:
        return []
    first = floor_to_bucket(points[0].ts, bucket_seconds)
    last = floor_to_bucket(points[-1].ts, bucket_seconds)
    by_bucket = {floor_to_bucket(p.ts, bucket_seconds): p.value for p in points}

    out: list[SeriesPoint] = []
    cur = first
    step = timedelta(seconds=bucket_seconds)
    prev = fill_value
    while cur <= last:
        if cur in by_bucket:
            prev = by_bucket[cur]
            out.append(SeriesPoint(cur, by_bucket[cur]))
        else:
            if method == "ffill":
                out.append(SeriesPoint(cur, prev))
            elif method == "zero":
                out.append(SeriesPoint(cur, 0.0))
            elif method == "const":
                out.append(SeriesPoint(cur, fill_value))
            else:
                raise ValueError("method must be one of: ffill, zero, const")
        cur += step
    return out


def moving_average(points: Sequence[SeriesPoint], window: int) -> list[SeriesPoint]:
    if window <= 0:
        raise ValueError("window must be positive")
    ensure_monotonic(points)
    out: list[SeriesPoint] = []
    acc = 0.0
    buf: list[float] = []
    for p in points:
        buf.append(p.value)
        acc += p.value
        if len(buf) > window:
            acc -= buf.pop(0)
        out.append(SeriesPoint(p.ts, acc / len(buf)))
    return out


def exponential_moving_average(
    points: Sequence[SeriesPoint],
    *,
    alpha: float,
) -> list[SeriesPoint]:
    if not (0.0 < alpha <= 1.0):
        raise ValueError("alpha must be in (0, 1]")
    ensure_monotonic(points)
    out: list[SeriesPoint] = []
    ema: float | None = None
    for p in points:
        ema = p.value if ema is None else alpha * p.value + (1.0 - alpha) * ema
        out.append(SeriesPoint(p.ts, ema))
    return out


def delta(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    ensure_monotonic(points)
    if not points:
        return []
    out: list[SeriesPoint] = [SeriesPoint(points[0].ts, 0.0)]
    for prev, cur in zip(points, points[1:]):
        out.append(SeriesPoint(cur.ts, cur.value - prev.value))
    return out


def rate_per_second(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    ensure_monotonic(points)
    if not points:
        return []
    out: list[SeriesPoint] = [SeriesPoint(points[0].ts, 0.0)]
    for prev, cur in zip(points, points[1:]):
        dt = (cur.ts - prev.ts).total_seconds()
        if dt <= 0:
            out.append(SeriesPoint(cur.ts, 0.0))
        else:
            out.append(SeriesPoint(cur.ts, (cur.value - prev.value) / dt))
    return out


def cumulative_sum(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    ensure_monotonic(points)
    out: list[SeriesPoint] = []
    acc = 0.0
    for p in points:
        acc += p.value
        out.append(SeriesPoint(p.ts, acc))
    return out


def minmax_scale(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    ensure_monotonic(points)
    if not points:
        return []
    lo = min(p.value for p in points)
    hi = max(p.value for p in points)
    if hi == lo:
        return [SeriesPoint(p.ts, 0.0) for p in points]
    return [SeriesPoint(p.ts, (p.value - lo) / (hi - lo)) for p in points]


def zscore(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    ensure_monotonic(points)
    if not points:
        return []
    mu = mean(p.value for p in points)
    var = mean((p.value - mu) ** 2 for p in points)
    std = var**0.5
    if std == 0.0:
        return [SeriesPoint(p.ts, 0.0) for p in points]
    return [SeriesPoint(p.ts, (p.value - mu) / std) for p in points]


def clip(points: Sequence[SeriesPoint], *, min_value: float, max_value: float) -> list[SeriesPoint]:
    if min_value > max_value:
        raise ValueError("min_value must be <= max_value")
    ensure_monotonic(points)
    return [SeriesPoint(p.ts, min(max(p.value, min_value), max_value)) for p in points]


def winsorize(points: Sequence[SeriesPoint], *, lower_q: float = 0.05, upper_q: float = 0.95) -> list[SeriesPoint]:
    if not (0.0 <= lower_q < upper_q <= 1.0):
        raise ValueError("quantiles must satisfy 0 <= lower < upper <= 1")
    ensure_monotonic(points)
    if not points:
        return []
    vals = sorted(p.value for p in points)
    lo = vals[int(lower_q * (len(vals) - 1))]
    hi = vals[int(upper_q * (len(vals) - 1))]
    return [SeriesPoint(p.ts, min(max(p.value, lo), hi)) for p in points]


def lag(points: Sequence[SeriesPoint], periods: int) -> list[SeriesPoint]:
    if periods < 0:
        raise ValueError("periods must be >= 0")
    ensure_monotonic(points)
    if periods == 0:
        return list(points)
    out: list[SeriesPoint] = []
    for i, p in enumerate(points):
        if i < periods:
            out.append(SeriesPoint(p.ts, 0.0))
        else:
            out.append(SeriesPoint(p.ts, points[i - periods].value))
    return out


def rolling_std(points: Sequence[SeriesPoint], window: int) -> list[SeriesPoint]:
    if window <= 0:
        raise ValueError("window must be positive")
    ensure_monotonic(points)
    out: list[SeriesPoint] = []
    vals: list[float] = []
    for p in points:
        vals.append(p.value)
        if len(vals) > window:
            vals.pop(0)
        mu = mean(vals)
        var = mean((v - mu) ** 2 for v in vals)
        out.append(SeriesPoint(p.ts, var**0.5))
    return out


def rolling_quantile(points: Sequence[SeriesPoint], window: int, q: float) -> list[SeriesPoint]:
    if window <= 0:
        raise ValueError("window must be positive")
    if not (0.0 <= q <= 1.0):
        raise ValueError("q must be in [0, 1]")
    ensure_monotonic(points)
    out: list[SeriesPoint] = []
    vals: list[float] = []
    for p in points:
        vals.append(p.value)
        if len(vals) > window:
            vals.pop(0)
        s = sorted(vals)
        idx = int(q * (len(s) - 1))
        out.append(SeriesPoint(p.ts, s[idx]))
    return out


def seasonal_residual(points: Sequence[SeriesPoint], period: int) -> list[SeriesPoint]:
    """Residual after removing repeating positional mean over `period`."""
    if period <= 1:
        raise ValueError("period must be > 1")
    ensure_monotonic(points)
    if not points:
        return []
    buckets: dict[int, list[float]] = {}
    for i, p in enumerate(points):
        buckets.setdefault(i % period, []).append(p.value)
    profile = {k: mean(vs) for k, vs in buckets.items()}
    return [SeriesPoint(p.ts, p.value - profile[i % period]) for i, p in enumerate(points)]


def detrend_linear(points: Sequence[SeriesPoint]) -> list[SeriesPoint]:
    """Remove least-squares linear trend from the series."""
    ensure_monotonic(points)
    n = len(points)
    if n <= 1:
        return list(points)
    xs = [float(i) for i in range(n)]
    ys = [p.value for p in points]
    xbar = mean(xs)
    ybar = mean(ys)
    num = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
    den = sum((x - xbar) ** 2 for x in xs)
    slope = 0.0 if den == 0.0 else num / den
    intercept = ybar - slope * xbar
    return [SeriesPoint(p.ts, p.value - (slope * i + intercept)) for i, p in enumerate(points)]


def rebucket_mean(points: Sequence[SeriesPoint], bucket_seconds: int) -> list[SeriesPoint]:
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    ensure_monotonic(points)
    groups: dict[datetime, list[float]] = {}
    for p in points:
        b = floor_to_bucket(p.ts, bucket_seconds)
        groups.setdefault(b, []).append(p.value)
    out = [SeriesPoint(ts=k, value=mean(vs)) for k, vs in groups.items()]
    out.sort(key=lambda p: p.ts)
    return out


def rebucket_sum(points: Sequence[SeriesPoint], bucket_seconds: int) -> list[SeriesPoint]:
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    ensure_monotonic(points)
    groups: dict[datetime, float] = {}
    for p in points:
        b = floor_to_bucket(p.ts, bucket_seconds)
        groups[b] = groups.get(b, 0.0) + p.value
    out = [SeriesPoint(ts=k, value=v) for k, v in groups.items()]
    out.sort(key=lambda p: p.ts)
    return out
