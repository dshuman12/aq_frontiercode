"""Append-only on-disk store for multiple named series.

Layout:

* one **directory** per ``SeriesStore`` instance
* one ``<series>.tw`` file per series, holding concatenated codec frames
* one ``index.json`` file with a small manifest (series name → file, frame count)

The store guarantees:

* atomic appends (``fsync`` after each frame, with an optional ``durable=False`` mode)
* monotonic timestamps within a series
* deterministic listing/iteration
* compact (delta-of-delta) storage thanks to :mod:`timewindow.codec`
"""

from __future__ import annotations

import json
import os
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Iterator, Sequence

from timewindow.codec import (
    decode_points,
    encode_points,
    iter_decode_frames,
    read_header,
)
from timewindow.exceptions import ParseError, TimeWindowError
from timewindow.series_math import SeriesPoint


_SERIES_NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")


def _validate_series_name(name: str) -> None:
    if not _SERIES_NAME_RE.match(name):
        raise TimeWindowError(
            f"invalid series name {name!r}: must match {_SERIES_NAME_RE.pattern}"
        )


@dataclass(slots=True)
class SeriesMeta:
    """Mutable per-series metadata stored in ``index.json``."""

    name: str
    file: str
    frames: int = 0
    points: int = 0
    last_ts_micros: int | None = None


@dataclass(slots=True)
class StoreManifest:
    """Top-level manifest persisted to ``index.json``."""

    version: int = 1
    series: dict[str, SeriesMeta] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "series": {
                name: {
                    "file": m.file,
                    "frames": m.frames,
                    "points": m.points,
                    "last_ts_micros": m.last_ts_micros,
                }
                for name, m in sorted(self.series.items())
            },
        }

    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> "StoreManifest":
        version = int(payload.get("version", 1))
        if version != 1:
            raise ParseError(f"unsupported manifest version: {version}")
        items: dict[str, SeriesMeta] = {}
        raw = payload.get("series", {})
        if not isinstance(raw, dict):
            raise ParseError("manifest series field must be an object")
        for name, body in raw.items():
            if not isinstance(body, dict):
                raise ParseError(f"series {name!r} entry must be an object")
            items[name] = SeriesMeta(
                name=name,
                file=str(body.get("file", f"{name}.tw")),
                frames=int(body.get("frames", 0)),
                points=int(body.get("points", 0)),
                last_ts_micros=(
                    int(body["last_ts_micros"]) if body.get("last_ts_micros") is not None else None
                ),
            )
        return cls(version=version, series=items)


class SeriesStore:
    """Thread-safe append-only series store backed by a directory of ``.tw`` files."""

    def __init__(self, root: str | Path, *, durable: bool = True) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)
        self._durable = durable
        self._lock = threading.RLock()
        self._manifest = self._load_manifest()

    @property
    def root(self) -> Path:
        return self._root

    @property
    def durable(self) -> bool:
        return self._durable

    def _manifest_path(self) -> Path:
        return self._root / "index.json"

    def _series_path(self, name: str) -> Path:
        meta = self._manifest.series.get(name)
        if meta is None:
            return self._root / f"{name}.tw"
        return self._root / meta.file

    def _load_manifest(self) -> StoreManifest:
        path = self._manifest_path()
        if not path.exists():
            return StoreManifest()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ParseError(f"corrupt manifest at {path}: {exc}") from exc
        return StoreManifest.from_dict(data)

    def _save_manifest(self) -> None:
        path = self._manifest_path()
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self._manifest.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
        if self._durable:
            with tmp.open("rb") as fp:
                os.fsync(fp.fileno())
        tmp.replace(path)

    def list_series(self) -> list[str]:
        with self._lock:
            return sorted(self._manifest.series)

    def has_series(self, name: str) -> bool:
        with self._lock:
            return name in self._manifest.series

    def stats(self, name: str) -> SeriesMeta:
        with self._lock:
            meta = self._manifest.series.get(name)
            if meta is None:
                raise TimeWindowError(f"unknown series: {name!r}")
            return SeriesMeta(
                name=meta.name,
                file=meta.file,
                frames=meta.frames,
                points=meta.points,
                last_ts_micros=meta.last_ts_micros,
            )

    def total_points(self) -> int:
        with self._lock:
            return sum(m.points for m in self._manifest.series.values())

    def append(self, name: str, points: Sequence[SeriesPoint], *, bucket_seconds: int = 0) -> int:
        """Append ``points`` to ``name``. Returns the number of points written."""
        _validate_series_name(name)
        if not points:
            return 0
        sorted_points = list(points)
        sorted_points.sort(key=lambda p: p.ts)
        with self._lock:
            meta = self._manifest.series.get(name)
            if meta is None:
                meta = SeriesMeta(name=name, file=f"{name}.tw")
                self._manifest.series[name] = meta
            first_ts = _epoch_micros(sorted_points[0].ts)
            if meta.last_ts_micros is not None and first_ts <= meta.last_ts_micros:
                raise TimeWindowError(
                    f"refusing to append non-monotonic point to series {name!r}"
                )
            buf = encode_points(sorted_points, bucket_seconds=bucket_seconds)
            path = self._root / meta.file
            with path.open("ab") as fp:
                fp.write(buf)
                if self._durable:
                    fp.flush()
                    os.fsync(fp.fileno())
            meta.frames += 1
            meta.points += len(sorted_points)
            meta.last_ts_micros = _epoch_micros(sorted_points[-1].ts)
            self._save_manifest()
            return len(sorted_points)

    def read_all(self, name: str) -> list[SeriesPoint]:
        with self._lock:
            meta = self._manifest.series.get(name)
            if meta is None:
                raise TimeWindowError(f"unknown series: {name!r}")
            path = self._root / meta.file
            if not path.exists():
                return []
            data = path.read_bytes()
        out: list[SeriesPoint] = []
        for frame in iter_decode_frames(data):
            out.extend(frame)
        return out

    def iter_frames(self, name: str) -> Iterator[list[SeriesPoint]]:
        with self._lock:
            meta = self._manifest.series.get(name)
            if meta is None:
                raise TimeWindowError(f"unknown series: {name!r}")
            data = (self._root / meta.file).read_bytes() if (self._root / meta.file).exists() else b""
        for frame in iter_decode_frames(data):
            yield frame

    def head(self, name: str, n: int = 1) -> list[SeriesPoint]:
        if n <= 0:
            return []
        out: list[SeriesPoint] = []
        for frame in self.iter_frames(name):
            out.extend(frame)
            if len(out) >= n:
                return out[:n]
        return out

    def tail(self, name: str, n: int = 1) -> list[SeriesPoint]:
        if n <= 0:
            return []
        all_points = self.read_all(name)
        return all_points[-n:]

    def compact(self, name: str, *, bucket_seconds: int = 0) -> int:
        """Rewrite a series file as a single dense frame. Returns total points."""
        with self._lock:
            meta = self._manifest.series.get(name)
            if meta is None:
                raise TimeWindowError(f"unknown series: {name!r}")
            all_points = self.read_all(name)
            path = self._root / meta.file
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_bytes(encode_points(all_points, bucket_seconds=bucket_seconds))
            if self._durable:
                with tmp.open("rb") as fp:
                    os.fsync(fp.fileno())
            tmp.replace(path)
            meta.frames = 1 if all_points else 0
            meta.points = len(all_points)
            meta.last_ts_micros = _epoch_micros(all_points[-1].ts) if all_points else None
            self._save_manifest()
            return len(all_points)

    def drop(self, name: str) -> bool:
        with self._lock:
            meta = self._manifest.series.pop(name, None)
            if meta is None:
                return False
            path = self._root / meta.file
            if path.exists():
                path.unlink()
            self._save_manifest()
            return True

    def merge_into(self, other: "SeriesStore", *, names: Iterable[str] | None = None) -> int:
        """Copy every (or selected) series into ``other``. Returns total points copied."""
        copied = 0
        targets = list(names) if names is not None else self.list_series()
        for name in targets:
            for frame in self.iter_frames(name):
                if frame:
                    copied += other.append(name, frame)
        return copied

    def verify(self) -> list[str]:
        """Cheap consistency check between the manifest and on-disk frames."""
        problems: list[str] = []
        with self._lock:
            for name, meta in self._manifest.series.items():
                path = self._root / meta.file
                if not path.exists():
                    problems.append(f"{name}: file missing ({path.name})")
                    continue
                try:
                    raw = path.read_bytes()
                    counted = sum(len(frame) for frame in iter_decode_frames(raw))
                except ParseError as exc:
                    problems.append(f"{name}: decode error ({exc})")
                    continue
                if counted != meta.points:
                    problems.append(
                        f"{name}: manifest points={meta.points} but file points={counted}"
                    )
        return problems


def _epoch_micros(ts) -> int:  # type: ignore[no-untyped-def]
    from datetime import datetime, timezone

    if ts.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")
    delta = ts.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return int(delta.total_seconds() * 1_000_000) + delta.microseconds % 1_000_000


def open_store(root: str | Path, *, durable: bool = True) -> SeriesStore:
    """Convenience constructor used by the CLI and HTTP API."""
    return SeriesStore(root, durable=durable)


def append_csv_to_store(store: SeriesStore, name: str, csv_path: str | Path) -> int:
    """Read a series CSV file and append it to ``name`` in ``store``."""
    from timewindow.csvio import read_series_path

    return store.append(name, read_series_path(csv_path))


def export_store_to_directory(store: SeriesStore, out_dir: str | Path) -> dict[str, int]:
    """Dump every series in ``store`` as a CSV file under ``out_dir`` and return per-series row counts."""
    from timewindow.csvio import write_series_path

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written: dict[str, int] = {}
    for name in store.list_series():
        points = store.read_all(name)
        path = out / f"{name}.csv"
        written[name] = write_series_path(path, points)
    return written
