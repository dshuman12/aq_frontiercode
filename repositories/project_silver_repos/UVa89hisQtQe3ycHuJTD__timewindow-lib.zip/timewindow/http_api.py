"""Minimal HTTP API exposing the ``timewindow`` library.

This module intentionally uses only ``http.server`` from the stdlib so it can
run anywhere Python is available — no extra dependencies, no async runtime.

Endpoints:

* ``GET    /health``                       -> ``{"status":"ok"}``
* ``GET    /series``                       -> list of series names
* ``GET    /series/{name}/stats``          -> per-series stats
* ``GET    /series/{name}/points``         -> all points for a series (JSON)
* ``POST   /series/{name}/append``         -> append ``[{"timestamp":..., "value":...}]``
* ``POST   /series/{name}/compact``        -> rewrite as a single dense frame
* ``DELETE /series/{name}``                -> drop a series
* ``POST   /query``                        -> run a query DSL string
* ``POST   /detect``                       -> run anomaly detectors on a series

Designed for testability: the server can be created and shut down in-process,
and every handler returns deterministic JSON.
"""

from __future__ import annotations

import json
import socket
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from urllib.parse import urlsplit

from timewindow.anomaly import (
    AnomalyEvent,
    ZScoreConfig,
    detect_change_points_mad,
    detect_gaps,
    detect_level_shift,
    detect_residual_anomalies,
    detect_spikes_zscore,
    detect_stale_series,
)
from timewindow.exceptions import ParseError, TimeWindowError
from timewindow.query import QueryContext, execute
from timewindow.serde import format_instant_iso8601, parse_instant_iso8601
from timewindow.series_math import SeriesPoint
from timewindow.storage import SeriesStore


_DEFAULT_MAX_BODY_BYTES = 4 * 1024 * 1024


def _json_response(handler: BaseHTTPRequestHandler, status: int, body: dict[str, Any]) -> None:
    payload = json.dumps(body, sort_keys=True).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    handler.end_headers()
    handler.wfile.write(payload)


def _read_json_body(handler: BaseHTTPRequestHandler, *, max_bytes: int) -> Any:
    length = int(handler.headers.get("Content-Length", "0") or 0)
    if length <= 0:
        return None
    if length > max_bytes:
        raise ParseError(f"request body too large ({length} > {max_bytes})")
    raw = handler.rfile.read(length)
    if not raw:
        return None
    return json.loads(raw.decode("utf-8"))


def _points_to_json(points: list[SeriesPoint]) -> list[dict[str, Any]]:
    return [
        {"timestamp": format_instant_iso8601(p.ts), "value": p.value}
        for p in points
    ]


def _events_to_json(events: list[AnomalyEvent]) -> list[dict[str, Any]]:
    return [
        {
            "timestamp": format_instant_iso8601(e.ts),
            "value": e.value,
            "score": (e.score if e.score not in (float("inf"), float("-inf")) else "inf"),
            "kind": e.kind,
            "detail": e.detail,
        }
        for e in events
    ]


def _parse_points_payload(payload: Any) -> list[SeriesPoint]:
    if not isinstance(payload, list):
        raise ParseError("expected a JSON array of {timestamp, value} objects")
    out: list[SeriesPoint] = []
    for item in payload:
        if not isinstance(item, dict):
            raise ParseError("each point must be an object")
        ts = parse_instant_iso8601(str(item["timestamp"]))
        val = float(item["value"])
        out.append(SeriesPoint(ts=ts, value=val))
    return out


def _split_path(path: str) -> tuple[list[str], dict[str, str]]:
    parts = urlsplit(path)
    segments = [seg for seg in parts.path.split("/") if seg]
    params: dict[str, str] = {}
    if parts.query:
        for pair in parts.query.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                params[k] = v
            else:
                params[pair] = ""
    return segments, params


def _make_handler(store: SeriesStore, *, max_body_bytes: int) -> type[BaseHTTPRequestHandler]:
    class TimewindowHandler(BaseHTTPRequestHandler):
        server_version = "timewindow/1"

        def log_message(self, format: str, *args: Any) -> None:  # noqa: ARG002
            return

        def _safely(self, fn: Callable[[], None]) -> None:
            try:
                fn()
            except FileNotFoundError as exc:
                _json_response(self, 404, {"error": str(exc)})
            except (ParseError, TimeWindowError, ValueError, KeyError) as exc:
                _json_response(self, 400, {"error": str(exc)})
            except json.JSONDecodeError as exc:
                _json_response(self, 400, {"error": f"invalid json: {exc.msg}"})
            except Exception as exc:  # noqa: BLE001
                _json_response(self, 500, {"error": f"{type(exc).__name__}: {exc}"})

        def do_GET(self) -> None:  # noqa: N802 - http.server expects this name
            self._safely(self._dispatch_get)

        def do_POST(self) -> None:  # noqa: N802
            self._safely(self._dispatch_post)

        def do_DELETE(self) -> None:  # noqa: N802
            self._safely(self._dispatch_delete)

        def _dispatch_get(self) -> None:
            segments, params = _split_path(self.path)
            if segments == ["health"]:
                _json_response(self, 200, {"status": "ok"})
                return
            if segments == ["series"]:
                _json_response(self, 200, {"series": store.list_series()})
                return
            if len(segments) == 3 and segments[0] == "series" and segments[2] == "stats":
                meta = store.stats(segments[1])
                _json_response(
                    self,
                    200,
                    {
                        "name": meta.name,
                        "frames": meta.frames,
                        "points": meta.points,
                        "last_ts_micros": meta.last_ts_micros,
                    },
                )
                return
            if len(segments) == 3 and segments[0] == "series" and segments[2] == "points":
                points = store.read_all(segments[1])
                limit = int(params.get("limit", "0") or 0)
                offset = int(params.get("offset", "0") or 0)
                if offset:
                    points = points[offset:]
                if limit > 0:
                    points = points[:limit]
                _json_response(self, 200, {"points": _points_to_json(points)})
                return
            _json_response(self, 404, {"error": f"no such route: GET {self.path}"})

        def _dispatch_post(self) -> None:
            segments, _params = _split_path(self.path)
            payload = _read_json_body(self, max_bytes=max_body_bytes)
            if (
                len(segments) == 3
                and segments[0] == "series"
                and segments[2] == "append"
            ):
                points = _parse_points_payload(payload)
                written = store.append(segments[1], points)
                _json_response(self, 200, {"written": written})
                return
            if (
                len(segments) == 3
                and segments[0] == "series"
                and segments[2] == "compact"
            ):
                total = store.compact(segments[1])
                _json_response(self, 200, {"points": total})
                return
            if segments == ["query"]:
                if not isinstance(payload, dict) or "query" not in payload:
                    raise ParseError("expected JSON body with a 'query' field")
                result = execute(str(payload["query"]), QueryContext(store=store))
                _json_response(
                    self,
                    200,
                    {
                        "kind": result.kind,
                        "scalar": result.scalar,
                        "points": _points_to_json(result.points),
                    },
                )
                return
            if segments == ["detect"]:
                if not isinstance(payload, dict) or "series" not in payload:
                    raise ParseError("expected JSON body with a 'series' field")
                series = str(payload["series"])
                kind = str(payload.get("kind", "spikes"))
                points = store.read_all(series)
                events = _run_detector(kind, points, payload)
                _json_response(self, 200, {"events": _events_to_json(events)})
                return
            _json_response(self, 404, {"error": f"no such route: POST {self.path}"})

        def _dispatch_delete(self) -> None:
            segments, _params = _split_path(self.path)
            if len(segments) == 2 and segments[0] == "series":
                dropped = store.drop(segments[1])
                _json_response(self, 200 if dropped else 404, {"dropped": dropped})
                return
            _json_response(self, 404, {"error": f"no such route: DELETE {self.path}"})

    return TimewindowHandler


def _run_detector(kind: str, points: list[SeriesPoint], payload: dict[str, Any]) -> list[AnomalyEvent]:
    if kind == "spikes":
        cfg = ZScoreConfig(
            window=int(payload.get("window", 20)),
            threshold=float(payload.get("threshold", 3.0)),
            warmup=int(payload.get("warmup", 10)),
        )
        return detect_spikes_zscore(points, config=cfg)
    if kind == "level_shift":
        return detect_level_shift(
            points,
            left_window=int(payload.get("left_window", 20)),
            right_window=int(payload.get("right_window", 20)),
            min_shift=float(payload.get("min_shift", 2.0)),
        )
    if kind == "stale":
        return detect_stale_series(
            points,
            window=int(payload.get("window", 30)),
            max_std=float(payload.get("max_std", 1e-9)),
        )
    if kind == "gap":
        from datetime import timedelta

        step = float(payload.get("expected_step_seconds", 60.0))
        return detect_gaps(
            points,
            expected_step=timedelta(seconds=step),
            tolerance=float(payload.get("tolerance", 1.5)),
        )
    if kind == "change_point":
        return detect_change_points_mad(
            points,
            window=int(payload.get("window", 21)),
            threshold=float(payload.get("threshold", 6.0)),
        )
    if kind == "residual":
        return detect_residual_anomalies(
            points,
            trend_window=int(payload.get("trend_window", 15)),
            z_threshold=float(payload.get("z_threshold", 3.0)),
        )
    raise ParseError(f"unknown detector kind: {kind!r}")


class HttpServer:
    """Owning wrapper around a ``ThreadingHTTPServer`` for in-process use."""

    def __init__(
        self,
        store: SeriesStore,
        *,
        host: str = "127.0.0.1",
        port: int = 0,
        max_body_bytes: int = _DEFAULT_MAX_BODY_BYTES,
    ) -> None:
        handler_cls = _make_handler(store, max_body_bytes=max_body_bytes)
        self._httpd = ThreadingHTTPServer((host, port), handler_cls)
        self._thread: threading.Thread | None = None
        self._store = store

    @property
    def port(self) -> int:
        return self._httpd.server_address[1]

    @property
    def host(self) -> str:
        return self._httpd.server_address[0]

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    @property
    def store(self) -> SeriesStore:
        return self._store

    def start(self) -> "HttpServer":
        if self._thread is not None:
            return self
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return self

    def stop(self, *, timeout: float = 2.0) -> None:
        if self._thread is None:
            return
        self._httpd.shutdown()
        self._httpd.server_close()
        self._thread.join(timeout=timeout)
        self._thread = None

    def __enter__(self) -> "HttpServer":
        return self.start()

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.stop()


def serialize_event(event: AnomalyEvent) -> dict[str, Any]:
    return _events_to_json([event])[0]


def serialize_points(points: list[SeriesPoint]) -> list[dict[str, Any]]:
    return _points_to_json(points)


def find_free_port() -> int:
    """Return an OS-assigned free TCP port (used by tests)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]
