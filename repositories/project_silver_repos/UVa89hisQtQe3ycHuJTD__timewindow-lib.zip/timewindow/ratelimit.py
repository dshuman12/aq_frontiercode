from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass(slots=True)
class SlidingWindowCounter:
    """Counts events inside a sliding wall-clock window (monotonic-based)."""

    window_seconds: float
    _events: list[float] = field(default_factory=list, init=False)

    def __post_init__(self) -> None:
        if self.window_seconds <= 0:
            raise ValueError("window_seconds must be positive")
        self._events = []

    def _prune(self, now: float) -> None:
        cutoff = now - self.window_seconds
        self._events = [t for t in self._events if t >= cutoff]

    def hit(self, *, now: float | None = None) -> int:
        ts = time.monotonic() if now is None else now
        self._prune(ts)
        self._events.append(ts)
        self._prune(ts)
        return len(self._events)

    def count(self, *, now: float | None = None) -> int:
        ts = time.monotonic() if now is None else now
        self._prune(ts)
        return len(self._events)


@dataclass(slots=True)
class FixedWindowCounter:
    """Bucketed counter aligned to monotonic windows."""

    window_seconds: float
    _epoch: float | None = field(default=None, init=False)
    _current: int = 0
    _bucket: int = 0

    def __post_init__(self) -> None:
        if self.window_seconds <= 0:
            raise ValueError("window_seconds must be positive")
        self._epoch = None

    def hit(self, *, now: float | None = None) -> int:
        ts = time.monotonic() if now is None else now
        if self._epoch is None:
            self._epoch = ts
        bucket = int((ts - self._epoch) // self.window_seconds)
        if bucket != self._bucket:
            self._bucket = bucket
            self._current = 0
        self._current += 1
        return self._current
