from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from timewindow.exceptions import ParseError
from timewindow.labels import LabelSet


@dataclass(frozen=True, slots=True)
class EqualsMatcher:
    key: str
    value: str

    def matches(self, labels: LabelSet) -> bool:
        data = dict(labels.pairs)
        return data.get(self.key) == self.value


@dataclass(frozen=True, slots=True)
class RegexMatcher:
    key: str
    pattern: re.Pattern[str]

    def matches(self, labels: LabelSet) -> bool:
        data = dict(labels.pairs)
        if self.key not in data:
            return False
        return self.pattern.fullmatch(data[self.key]) is not None


@dataclass(frozen=True, slots=True)
class ExistsMatcher:
    key: str

    def matches(self, labels: LabelSet) -> bool:
        return self.key in dict(labels.pairs)


@dataclass(frozen=True, slots=True)
class AndMatcher:
    left: Matcher
    right: Matcher

    def matches(self, labels: LabelSet) -> bool:
        return self.left.matches(labels) and self.right.matches(labels)


@dataclass(frozen=True, slots=True)
class OrMatcher:
    left: Matcher
    right: Matcher

    def matches(self, labels: LabelSet) -> bool:
        return self.left.matches(labels) or self.right.matches(labels)


@dataclass(frozen=True, slots=True)
class NotMatcher:
    inner: Matcher

    def matches(self, labels: LabelSet) -> bool:
        return not self.inner.matches(labels)


@dataclass(frozen=True, slots=True)
class TrueMatcher:
    def matches(self, labels: LabelSet) -> bool:  # noqa: ARG002
        return True


@dataclass(frozen=True, slots=True)
class FalseMatcher:
    def matches(self, labels: LabelSet) -> bool:  # noqa: ARG002
        return False


Matcher = (
    EqualsMatcher
    | RegexMatcher
    | ExistsMatcher
    | AndMatcher
    | OrMatcher
    | NotMatcher
    | TrueMatcher
    | FalseMatcher
)


def parse_matcher(text: str) -> Matcher:
    """
    Parse a tiny matcher language:

    - ``k="v"`` equality
    - ``k=~"regex"`` full-string regex match
    - ``k`` exists
    - ``expr AND expr``, ``expr OR expr``
    - ``NOT expr`` with highest precedence after parentheses
    """
    tokens = _tokenize(text)
    if not tokens:
        raise ParseError("empty matcher")
    pos = 0

    def peek() -> str | None:
        return tokens[pos] if pos < len(tokens) else None

    def consume(expected: str | None = None) -> str:
        nonlocal pos
        if pos >= len(tokens):
            raise ParseError("unexpected end of matcher")
        tok = tokens[pos]
        pos += 1
        if expected is not None and tok != expected:
            raise ParseError(f"expected {expected!r} but found {tok!r}")
        return tok

    def parse_primary() -> Matcher:
        nonlocal pos
        tok = peek()
        if tok == "(":
            consume("(")
            inner = parse_or()
            consume(")")
            return inner
        if tok == "NOT":
            consume("NOT")
            return NotMatcher(parse_primary())
        if tok is None:
            raise ParseError("missing primary")
        if tok == "AND" or tok == "OR":
            raise ParseError("unexpected logical operator")
        key = consume()
        if peek() == "=~":
            consume("=~")
            pattern = consume()
            try:
                compiled = re.compile(pattern)
            except re.error as exc:
                raise ParseError(f"invalid regex: {pattern!r}") from exc
            return RegexMatcher(key=key, pattern=compiled)
        if peek() == "=":
            consume("=")
            value = consume()
            return EqualsMatcher(key=key, value=value)
        return ExistsMatcher(key=key)

    def parse_and() -> Matcher:
        left = parse_primary()
        while peek() == "AND":
            consume("AND")
            right = parse_primary()
            left = AndMatcher(left=left, right=right)
        return left

    def parse_or() -> Matcher:
        left = parse_and()
        while peek() == "OR":
            consume("OR")
            right = parse_and()
            left = OrMatcher(left=left, right=right)
        return left

    expr = parse_or()
    if pos != len(tokens):
        raise ParseError(f"trailing tokens: {tokens[pos:]}")
    return expr


def _tokenize(text: str) -> list[str]:
    raw = text.strip()
    if not raw:
        return []
    out: list[str] = []
    i = 0
    while i < len(raw):
        ch = raw[i]
        if ch.isspace():
            i += 1
            continue
        if ch in "()":
            out.append(ch)
            i += 1
            continue
        if raw[i:].startswith("AND") and (i + 3 == len(raw) or raw[i + 3].isspace() or raw[i + 3] in "()"):
            out.append("AND")
            i += 3
            continue
        if raw[i:].startswith("OR") and (i + 2 == len(raw) or raw[i + 2].isspace() or raw[i + 2] in "()"):
            out.append("OR")
            i += 2
            continue
        if raw[i:].startswith("NOT") and (i + 3 == len(raw) or raw[i + 3].isspace() or raw[i + 3] in "()"):
            out.append("NOT")
            i += 3
            continue
        if ch == "=":
            if raw.startswith("=~", i):
                out.append("=~")
                i += 2
            else:
                out.append("=")
                i += 1
            continue
        if ch == '"':
            j = i + 1
            buf: list[str] = []
            while j < len(raw):
                c = raw[j]
                if c == "\\":
                    if j + 1 >= len(raw):
                        raise ParseError("dangling escape")
                    buf.append(raw[j + 1])
                    j += 2
                    continue
                if c == '"':
                    j += 1
                    break
                buf.append(c)
                j += 1
            else:
                raise ParseError("unterminated string")
            out.append("".join(buf))
            i = j
            continue
        j = i
        while j < len(raw) and (raw[j].isalnum() or raw[j] in {"_", ".", "-", "/"}):
            j += 1
        if j == i:
            raise ParseError(f"unexpected character {raw[i]!r}")
        out.append(raw[i:j])
        i = j
    return out


def filter_label_sets(matcher: Matcher, items: Iterable[LabelSet]) -> list[LabelSet]:
    return [ls for ls in items if matcher.matches(ls)]


def explain_matcher(matcher: Matcher) -> str:
    return matcher.__class__.__name__


def matcher_to_debug(matcher: Matcher) -> str:
    return repr(matcher)


def simplify_or(matcher: Matcher) -> Matcher:
    if isinstance(matcher, OrMatcher):
        if isinstance(matcher.left, EqualsMatcher) and isinstance(matcher.right, EqualsMatcher):
            if matcher.left.key == matcher.right.key and matcher.left.value == matcher.right.value:
                return matcher.left
    return matcher


def matcher_keys_referenced(matcher: Matcher) -> set[str]:
    if isinstance(matcher, EqualsMatcher | RegexMatcher | ExistsMatcher):
        return {matcher.key}
    if isinstance(matcher, AndMatcher | OrMatcher):
        return matcher_keys_referenced(matcher.left) | matcher_keys_referenced(matcher.right)
    if isinstance(matcher, NotMatcher):
        return matcher_keys_referenced(matcher.inner)
    if isinstance(matcher, TrueMatcher | FalseMatcher):
        return set()
    return set()


def matcher_depth(matcher: Matcher) -> int:
    if isinstance(matcher, AndMatcher | OrMatcher):
        return 1 + max(matcher_depth(matcher.left), matcher_depth(matcher.right))
    if isinstance(matcher, NotMatcher):
        return 1 + matcher_depth(matcher.inner)
    if isinstance(matcher, TrueMatcher | FalseMatcher):
        return 1
    return 1


def always_true() -> Matcher:
    return TrueMatcher()


def always_false() -> Matcher:
    return FalseMatcher()


def rewrite_exists_as_equals(key: str, value: str) -> Matcher:
    return OrMatcher(ExistsMatcher(key=key), EqualsMatcher(key=key, value=value))


def combine_and_all(parts: list[Matcher]) -> Matcher:
    if not parts:
        raise ValueError("parts required")
    acc = parts[0]
    for p in parts[1:]:
        acc = AndMatcher(left=acc, right=p)
    return acc


def combine_or_all(parts: list[Matcher]) -> Matcher:
    if not parts:
        raise ValueError("parts required")
    acc = parts[0]
    for p in parts[1:]:
        acc = OrMatcher(left=acc, right=p)
    return acc


def negate(matcher: Matcher) -> Matcher:
    return NotMatcher(matcher)


def parse_many(texts: Iterable[str]) -> list[Matcher]:
    return [parse_matcher(t) for t in texts]


def all_match(matchers: Iterable[Matcher], labels: LabelSet) -> bool:
    return all(m.matches(labels) for m in matchers)


def any_match(matchers: Iterable[Matcher], labels: LabelSet) -> bool:
    return any(m.matches(labels) for m in matchers)
