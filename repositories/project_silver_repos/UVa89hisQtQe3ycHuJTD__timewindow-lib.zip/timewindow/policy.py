from __future__ import annotations

from datetime import datetime, timedelta, timezone

from timewindow.duration import parse_duration_to_seconds
from timewindow.exceptions import ParseError


def retention_timedelta(text: str) -> timedelta:
    """Convert a positive duration string into a :class:`datetime.timedelta`."""
    seconds = parse_duration_to_seconds(text)
    if seconds <= 0:
        raise ParseError("retention duration must be positive")
    return timedelta(seconds=seconds)


def cutoff_utc(now: datetime, retention: str) -> datetime:
    """
    Return the oldest instant to keep when applying ``retention`` relative to ``now``.

    ``now`` must be timezone-aware. The result is returned in UTC.
    """
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    delta = retention_timedelta(retention)
    return (now.astimezone(timezone.utc) - delta).replace(microsecond=0)


def clamp_to_future(reference: datetime, candidate: datetime) -> datetime:
    """Return ``max(reference, candidate)`` in UTC."""
    if reference.tzinfo is None or candidate.tzinfo is None:
        raise ValueError("datetimes must be timezone-aware")
    a = reference.astimezone(timezone.utc)
    b = candidate.astimezone(timezone.utc)
    return a if a >= b else b
