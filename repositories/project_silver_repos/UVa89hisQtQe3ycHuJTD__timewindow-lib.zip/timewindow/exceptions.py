"""Domain-specific errors for timewindow."""


class TimeWindowError(ValueError):
    """Base class for timewindow validation errors."""


class ParseError(TimeWindowError):
    """Raised when a user-supplied string cannot be parsed."""


class IntervalError(TimeWindowError):
    """Raised when interval bounds are inconsistent."""
