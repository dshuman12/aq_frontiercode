from __future__ import annotations

from timewindow.intervals import TimeInterval


def merge_intervals(intervals: list[TimeInterval]) -> list[TimeInterval]:
    """
    Merge a list of half-open intervals, combining overlaps and adjacency.

    Adjacent intervals ``[a, b)`` and ``[b, c)`` merge into ``[a, c)``.
    """
    if not intervals:
        return []
    ordered = sorted(intervals, key=lambda item: (item.start, item.end))
    merged: list[TimeInterval] = []
    current = ordered[0]
    for nxt in ordered[1:]:
        if nxt.start <= current.end:
            end = max(current.end, nxt.end)
            if end <= current.start:
                raise ValueError("invalid interval ordering after merge attempt")
            current = TimeInterval(start=current.start, end=end)
        else:
            merged.append(current)
            current = nxt
    merged.append(current)
    return merged
