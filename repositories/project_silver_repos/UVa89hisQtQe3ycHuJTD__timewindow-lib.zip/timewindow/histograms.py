from __future__ import annotations

from bisect import bisect_left
from dataclasses import dataclass
from math import inf, isfinite
from typing import Iterable, Sequence

from timewindow.exceptions import ParseError


def default_latency_buckets_seconds() -> tuple[float, ...]:
    """Classic Prometheus-style latency buckets (upper bounds in seconds)."""
    return (
        0.005,
        0.01,
        0.025,
        0.05,
        0.075,
        0.1,
        0.25,
        0.5,
        0.75,
        1.0,
        2.5,
        5.0,
        7.5,
        10.0,
    )


def validate_buckets(buckets: Sequence[float]) -> tuple[float, ...]:
    if not buckets:
        raise ParseError("histogram requires at least one bucket upper bound")
    prev = -inf
    cleaned: list[float] = []
    for raw in buckets:
        if not isfinite(raw) or raw <= 0:
            raise ParseError("bucket upper bounds must be finite positive numbers")
        if raw <= prev:
            raise ParseError("bucket upper bounds must be strictly increasing")
        cleaned.append(float(raw))
        prev = raw
    return tuple(cleaned)


@dataclass(slots=True)
class Histogram:
    """Fixed-bucket histogram with +Inf overflow bucket."""

    buckets: tuple[float, ...]
    counts: list[int]
    sum_seconds: float = 0.0
    total: int = 0

    def __init__(self, buckets: Sequence[float]) -> None:
        self.buckets = validate_buckets(buckets)
        self.counts = [0] * (len(self.buckets) + 1)
        self.sum_seconds = 0.0
        self.total = 0

    def observe(self, value_seconds: float) -> None:
        if not isfinite(value_seconds) or value_seconds < 0:
            raise ValueError("observed latency must be a finite non-negative number")
        idx = bisect_left(self.buckets, value_seconds)
        self.counts[idx] += 1
        self.sum_seconds += value_seconds
        self.total += 1

    def bucket_counts(self) -> tuple[tuple[float | str, int], ...]:
        """Return cumulative counts for each finite upper bound plus ``+Inf``."""
        cumulative = 0
        out: list[tuple[float | str, int]] = []
        for i, upper in enumerate(self.buckets):
            cumulative += self.counts[i]
            out.append((upper, cumulative))
        cumulative += self.counts[-1]
        out.append((inf, cumulative))
        return tuple(out)

    def clone(self) -> Histogram:
        other = Histogram(self.buckets)
        other.counts = list(self.counts)
        other.sum_seconds = self.sum_seconds
        other.total = self.total
        return other

    def merge(self, other: Histogram) -> None:
        if other.buckets != self.buckets:
            raise ValueError("cannot merge histograms with different bucket layouts")
        for i in range(len(self.counts)):
            self.counts[i] += other.counts[i]
        self.sum_seconds += other.sum_seconds
        self.total += other.total

    def quantile(self, q: float) -> float | None:
        """Return a coarse quantile estimate from cumulative bucket counts."""
        if not (0.0 <= q <= 1.0):
            raise ValueError("q must be between 0 and 1")
        if self.total == 0:
            return None
        target = q * self.total
        prev_upper = 0.0
        for upper, cum in self.bucket_counts():
            if isinstance(upper, float) and isfinite(upper):
                if cum >= target:
                    return float((prev_upper + upper) / 2.0)
                prev_upper = upper
            else:
                return float(prev_upper)
        return None


def merge_histograms(items: Iterable[Histogram]) -> Histogram:
    it = iter(items)
    try:
        first = next(it)
    except StopIteration as exc:
        raise ValueError("merge_histograms requires at least one histogram") from exc
    merged = first.clone()
    for nxt in it:
        merged.merge(nxt)
    return merged


def histogram_from_observations(
    buckets: Sequence[float],
    observations: Sequence[float],
) -> Histogram:
    hist = Histogram(buckets)
    for sample in observations:
        hist.observe(sample)
    return hist
