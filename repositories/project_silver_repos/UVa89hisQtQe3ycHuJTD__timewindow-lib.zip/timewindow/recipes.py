"""End-to-end pipelines composed from the lower-level ``timewindow`` modules.

These are intentionally small, opinionated recipes that take real inputs
(file paths and lists of points) and return concrete outputs. They are the
fastest way to use ``timewindow`` in production code or scripts.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterable, Sequence

from timewindow.anomaly import (
    AnomalyEvent,
    ZScoreConfig,
    detect_change_points_mad,
    detect_gaps,
    detect_level_shift,
    detect_residual_anomalies,
    detect_spikes_zscore,
    detect_stale_series,
    merge_nearby_events,
)
from timewindow.csvio import read_series_path, write_series_path
from timewindow.intervals import iter_bucket_intervals
from timewindow.report import (
    AnomalyReport,
    SeriesSummary,
    summarize_anomalies,
    summarize_series,
)
from timewindow.series_math import (
    SeriesPoint,
    detrend_linear,
    fill_bucket_gaps,
    moving_average,
    rebucket_mean,
    rebucket_sum,
)
from timewindow.tiered_rollups import (
    BucketStats,
    RollupPropagation,
    TieredRollupEngine,
)


@dataclass(frozen=True, slots=True)
class RebucketRequest:
    bucket_seconds: int
    aggregation: str = "mean"
    fill_method: str = "ffill"
    fill_value: float = 0.0


def rebucket_series(points: Sequence[SeriesPoint], request: RebucketRequest) -> list[SeriesPoint]:
    """Re-aggregate a series to a coarser bucket size and (optionally) fill gaps."""
    if request.bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    if request.aggregation == "mean":
        rebucketed = rebucket_mean(points, request.bucket_seconds)
    elif request.aggregation == "sum":
        rebucketed = rebucket_sum(points, request.bucket_seconds)
    else:
        raise ValueError("aggregation must be 'mean' or 'sum'")
    if request.fill_method == "none":
        return rebucketed
    return fill_bucket_gaps(
        rebucketed,
        request.bucket_seconds,
        method=request.fill_method,
        fill_value=request.fill_value,
    )


@dataclass(frozen=True, slots=True)
class RollupRequest:
    bucket_widths_seconds: tuple[int, ...]
    propagation: RollupPropagation = RollupPropagation.GAUGE


@dataclass(frozen=True, slots=True)
class RollupResult:
    layers: dict[int, list[BucketStats]]


def run_tiered_rollup(points: Sequence[SeriesPoint], request: RollupRequest) -> RollupResult:
    """Stream a series through a :class:`TieredRollupEngine` and collect layers."""
    engine = TieredRollupEngine(
        list(request.bucket_widths_seconds),
        propagation=request.propagation,
    )
    layers: dict[int, list[BucketStats]] = {}
    for p in points:
        snapshot = engine.observe(p.ts, p.value)
        for level, items in snapshot.items():
            if items:
                layers.setdefault(level, []).extend(items)
    final = engine.flush_all()
    for level, items in final.items():
        layers.setdefault(level, []).extend(items)
    return RollupResult(layers=layers)


@dataclass(frozen=True, slots=True)
class DetectionConfig:
    spike_window: int = 20
    spike_threshold: float = 3.5
    spike_warmup: int = 10
    level_left_window: int = 20
    level_right_window: int = 20
    level_min_shift: float = 2.0
    stale_window: int = 30
    stale_max_std: float = 1e-9
    expected_step_seconds: float | None = None
    gap_tolerance: float = 1.5
    change_point_window: int = 21
    change_point_threshold: float = 6.0
    residual_window: int = 15
    residual_z_threshold: float = 3.0
    merge_gap_seconds: float = 0.0


def detect_all(points: Sequence[SeriesPoint], config: DetectionConfig = DetectionConfig()) -> list[AnomalyEvent]:
    """Run all detectors and merge nearby events of the same kind."""
    events: list[AnomalyEvent] = []
    events.extend(
        detect_spikes_zscore(
            points,
            config=ZScoreConfig(
                window=config.spike_window,
                threshold=config.spike_threshold,
                warmup=config.spike_warmup,
            ),
        )
    )
    events.extend(
        detect_level_shift(
            points,
            left_window=config.level_left_window,
            right_window=config.level_right_window,
            min_shift=config.level_min_shift,
        )
    )
    events.extend(
        detect_stale_series(
            points,
            window=config.stale_window,
            max_std=config.stale_max_std,
        )
    )
    if config.expected_step_seconds is not None and config.expected_step_seconds > 0:
        events.extend(
            detect_gaps(
                points,
                expected_step=timedelta(seconds=config.expected_step_seconds),
                tolerance=config.gap_tolerance,
            )
        )
    events.extend(
        detect_change_points_mad(
            points,
            window=config.change_point_window,
            threshold=config.change_point_threshold,
        )
    )
    events.extend(
        detect_residual_anomalies(
            points,
            trend_window=config.residual_window,
            z_threshold=config.residual_z_threshold,
        )
    )
    if config.merge_gap_seconds > 0:
        events = merge_nearby_events(events, timedelta(seconds=config.merge_gap_seconds))
    events.sort(key=lambda e: e.ts)
    return events


@dataclass(frozen=True, slots=True)
class PipelineResult:
    summary: SeriesSummary
    cleaned: list[SeriesPoint]
    rolled: list[SeriesPoint]
    anomalies: list[AnomalyEvent]
    anomaly_report: AnomalyReport


def analyze_series(
    points: Sequence[SeriesPoint],
    *,
    rebucket: RebucketRequest | None = None,
    smoothing_window: int = 0,
    detrend: bool = False,
    detection: DetectionConfig = DetectionConfig(),
    top_k_events: int = 10,
) -> PipelineResult:
    """Run the standard ingest -> rebucket -> smooth -> detrend -> detect pipeline."""
    cleaned = list(points)
    if rebucket is not None:
        cleaned = rebucket_series(cleaned, rebucket)
    if detrend:
        cleaned = detrend_linear(cleaned)
    rolled = moving_average(cleaned, smoothing_window) if smoothing_window > 1 else list(cleaned)
    anomalies = detect_all(cleaned, detection)
    return PipelineResult(
        summary=summarize_series(cleaned),
        cleaned=cleaned,
        rolled=rolled,
        anomalies=anomalies,
        anomaly_report=summarize_anomalies(anomalies, top_k=top_k_events),
    )


def analyze_csv_file(
    path: str | Path,
    *,
    rebucket: RebucketRequest | None = None,
    smoothing_window: int = 0,
    detrend: bool = False,
    detection: DetectionConfig = DetectionConfig(),
    top_k_events: int = 10,
) -> PipelineResult:
    """Convenience wrapper: read CSV, then run :func:`analyze_series`."""
    points = read_series_path(path)
    return analyze_series(
        points,
        rebucket=rebucket,
        smoothing_window=smoothing_window,
        detrend=detrend,
        detection=detection,
        top_k_events=top_k_events,
    )


def write_cleaned_csv(path: str | Path, result: PipelineResult) -> int:
    """Persist the cleaned (post-rebucket / detrend) series back to disk."""
    return write_series_path(path, result.cleaned)


def expected_bucket_count(start: datetime, end: datetime, bucket_seconds: int) -> int:
    """How many full buckets cover ``[start, end)``?"""
    intervals = list(iter_bucket_intervals(start, end, bucket_seconds))
    return len(intervals)


def coverage_ratio(points: Sequence[SeriesPoint], bucket_seconds: int) -> float:
    """Fraction of expected buckets that contain at least one observation."""
    if not points:
        return 0.0
    expected = expected_bucket_count(points[0].ts, points[-1].ts + timedelta(seconds=bucket_seconds), bucket_seconds)
    if expected == 0:
        return 0.0
    seen: set[datetime] = set()
    from timewindow.bucket import floor_to_bucket

    for p in points:
        seen.add(floor_to_bucket(p.ts, bucket_seconds))
    return min(1.0, len(seen) / expected)


def lint_series(points: Sequence[SeriesPoint]) -> list[str]:
    """Return human-readable warnings about the series shape."""
    warnings: list[str] = []
    if not points:
        return ["empty series"]
    if len(points) < 2:
        return warnings
    deltas = [
        (b.ts - a.ts).total_seconds()
        for a, b in zip(points, points[1:])
    ]
    if any(d <= 0 for d in deltas):
        warnings.append("non-increasing timestamps detected")
    median_delta = sorted(deltas)[len(deltas) // 2]
    if median_delta > 0:
        irregular = sum(1 for d in deltas if d > median_delta * 5)
        if irregular > 0:
            warnings.append(f"{irregular} large gap(s) (>5x median step)")
    seen_ts = set()
    duplicates = 0
    for p in points:
        if p.ts in seen_ts:
            duplicates += 1
        else:
            seen_ts.add(p.ts)
    if duplicates:
        warnings.append(f"{duplicates} duplicate timestamp(s)")
    return warnings


def union_series(*series: Iterable[SeriesPoint]) -> list[SeriesPoint]:
    """Flatten multiple series into one chronologically-sorted list."""
    out: list[SeriesPoint] = []
    for s in series:
        out.extend(s)
    out.sort(key=lambda p: p.ts)
    return out
