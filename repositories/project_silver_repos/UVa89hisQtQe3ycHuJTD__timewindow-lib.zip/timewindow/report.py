"""Human- and machine-readable summaries for series and anomaly events."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from statistics import median
from typing import Iterable, Sequence

from timewindow.anomaly import AnomalyEvent
from timewindow.serde import format_instant_iso8601
from timewindow.series_math import SeriesPoint


@dataclass(frozen=True, slots=True)
class SeriesSummary:
    """Summary statistics for a single series."""

    count: int
    first_ts: datetime | None
    last_ts: datetime | None
    minimum: float | None
    maximum: float | None
    mean: float | None
    median: float | None
    span_seconds: float | None

    def to_dict(self) -> dict[str, object]:
        return {
            "count": self.count,
            "first_ts": format_instant_iso8601(self.first_ts) if self.first_ts else None,
            "last_ts": format_instant_iso8601(self.last_ts) if self.last_ts else None,
            "minimum": self.minimum,
            "maximum": self.maximum,
            "mean": self.mean,
            "median": self.median,
            "span_seconds": self.span_seconds,
        }


def summarize_series(points: Sequence[SeriesPoint]) -> SeriesSummary:
    """Compute a non-streaming summary over the full series."""
    if not points:
        return SeriesSummary(0, None, None, None, None, None, None, None)
    vals = [p.value for p in points]
    return SeriesSummary(
        count=len(points),
        first_ts=points[0].ts,
        last_ts=points[-1].ts,
        minimum=min(vals),
        maximum=max(vals),
        mean=sum(vals) / len(vals),
        median=median(vals),
        span_seconds=(points[-1].ts - points[0].ts).total_seconds(),
    )


def render_series_summary_text(summary: SeriesSummary) -> str:
    """Render a multi-line, aligned text view suitable for a terminal."""
    if summary.count == 0:
        return "series: empty"
    lines = [
        f"count       : {summary.count}",
        f"first_ts    : {format_instant_iso8601(summary.first_ts)}",
        f"last_ts     : {format_instant_iso8601(summary.last_ts)}",
        f"span_seconds: {summary.span_seconds:.3f}",
        f"minimum     : {summary.minimum:.6f}",
        f"maximum     : {summary.maximum:.6f}",
        f"mean        : {summary.mean:.6f}",
        f"median      : {summary.median:.6f}",
    ]
    return "\n".join(lines)


def render_series_summary_json(summary: SeriesSummary, *, indent: int | None = 2) -> str:
    return json.dumps(summary.to_dict(), indent=indent, sort_keys=True)


@dataclass(frozen=True, slots=True)
class AnomalyReport:
    total: int
    by_kind: dict[str, int]
    top: list[AnomalyEvent]

    def to_dict(self) -> dict[str, object]:
        return {
            "total": self.total,
            "by_kind": dict(self.by_kind),
            "top": [_event_to_dict(e) for e in self.top],
        }


def summarize_anomalies(events: Iterable[AnomalyEvent], *, top_k: int = 5) -> AnomalyReport:
    by_kind: dict[str, int] = {}
    items = list(events)
    for e in items:
        by_kind[e.kind] = by_kind.get(e.kind, 0) + 1
    top = sorted(items, key=lambda e: e.score, reverse=True)[: max(0, top_k)]
    return AnomalyReport(total=len(items), by_kind=by_kind, top=top)


def render_anomaly_report_text(report: AnomalyReport) -> str:
    if report.total == 0:
        return "anomalies: none"
    lines = [f"total       : {report.total}"]
    for kind, count in sorted(report.by_kind.items()):
        lines.append(f"  {kind:<14}: {count}")
    if report.top:
        lines.append("top events:")
        for e in report.top:
            lines.append(
                f"  {format_instant_iso8601(e.ts)}  kind={e.kind:<13}  "
                f"score={_format_score(e.score)}  value={e.value:.4f}  detail={e.detail}"
            )
    return "\n".join(lines)


def render_anomaly_report_json(report: AnomalyReport, *, indent: int | None = 2) -> str:
    return json.dumps(report.to_dict(), indent=indent, sort_keys=True)


def _event_to_dict(event: AnomalyEvent) -> dict[str, object]:
    base = asdict(event)
    base["ts"] = format_instant_iso8601(event.ts)
    base["score"] = event.score if _finite(event.score) else "inf"
    return base


def _finite(value: float) -> bool:
    return value == value and value not in (float("inf"), float("-inf"))


def _format_score(score: float) -> str:
    if not _finite(score):
        return "inf"
    return f"{score:.4f}"


def histogram_of_values(points: Sequence[SeriesPoint], *, bins: int = 10) -> list[tuple[float, float, int]]:
    """Compute equal-width histogram bins as ``(low, high, count)``."""
    if bins <= 0:
        raise ValueError("bins must be positive")
    if not points:
        return []
    vals = [p.value for p in points]
    lo, hi = min(vals), max(vals)
    if lo == hi:
        return [(lo, hi, len(vals))]
    width = (hi - lo) / bins
    counts = [0] * bins
    for v in vals:
        idx = min(int((v - lo) / width), bins - 1)
        counts[idx] += 1
    return [(lo + i * width, lo + (i + 1) * width, counts[i]) for i in range(bins)]


def render_histogram_text(bins: Sequence[tuple[float, float, int]], *, width: int = 30) -> str:
    if not bins:
        return "histogram: empty"
    peak = max(c for _, _, c in bins) or 1
    lines = []
    for lo, hi, count in bins:
        bar = "#" * max(1, int(count / peak * width)) if count > 0 else ""
        lines.append(f"[{lo:>10.4f} .. {hi:>10.4f}) {count:>6}  {bar}")
    return "\n".join(lines)
