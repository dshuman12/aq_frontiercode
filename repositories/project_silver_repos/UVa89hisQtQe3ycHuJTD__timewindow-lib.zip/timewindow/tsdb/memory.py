from __future__ import annotations

import math
from bisect import bisect_left, bisect_right
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Callable, Iterable, Iterator, Mapping, MutableMapping, Sequence

from timewindow.bucket import floor_to_bucket
from timewindow.exceptions import ParseError
from timewindow.labels import LabelSet
from timewindow.resample import Sample


def _utc(moment: datetime) -> datetime:
    if moment.tzinfo is None:
        raise ValueError("timestamps must be timezone-aware")
    return moment.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class SeriesPoint:
    when: datetime
    value: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "when", _utc(self.when))
        if not math.isfinite(self.value):
            raise ValueError("value must be finite")


@dataclass(slots=True)
class SeriesStats:
    count: int = 0
    minimum: float = math.inf
    maximum: float = -math.inf
    total: float = 0.0
    last: float | None = None
    last_at: datetime | None = None

    def observe(self, point: SeriesPoint) -> None:
        self.count += 1
        self.minimum = min(self.minimum, point.value)
        self.maximum = max(self.maximum, point.value)
        self.total += point.value
        self.last = point.value
        self.last_at = point.when

    def merge(self, other: SeriesStats) -> None:
        if other.count == 0:
            return
        self.count += other.count
        self.minimum = min(self.minimum, other.minimum)
        self.maximum = max(self.maximum, other.maximum)
        self.total += other.total
        if other.last_at is not None:
            if self.last_at is None or other.last_at >= self.last_at:
                self.last = other.last
                self.last_at = other.last_at


class SeriesCursor:
    """Streaming iterator over a bounded slice of points for one series."""

    __slots__ = ("_points", "_start_idx", "_end_idx", "_idx")

    def __init__(self, points: list[SeriesPoint], start_idx: int, end_idx: int) -> None:
        if start_idx < 0 or end_idx > len(points) or start_idx > end_idx:
            raise ValueError("invalid cursor bounds")
        self._points = points
        self._start_idx = start_idx
        self._end_idx = end_idx
        self._idx = start_idx

    def __iter__(self) -> Iterator[SeriesPoint]:
        return self

    def __next__(self) -> SeriesPoint:
        if self._idx >= self._end_idx:
            raise StopIteration
        item = self._points[self._idx]
        self._idx += 1
        return item


class MemorySeriesTable:
    """
    Multi-series in-memory table keyed by canonical :class:`LabelSet` strings.

    Each series keeps points sorted by ``when`` ascending. Inserts are ``O(log n)``
    per point with ``bisect``; scans are linear in the slice returned.
    """

    __slots__ = ("_series", "_stats", "_capacity_per_series")

    def __init__(self, *, capacity_per_series: int | None = None) -> None:
        if capacity_per_series is not None and capacity_per_series <= 0:
            raise ValueError("capacity_per_series must be positive when set")
        self._capacity_per_series = capacity_per_series
        self._series: dict[str, list[SeriesPoint]] = {}
        self._stats: dict[str, SeriesStats] = {}

    @staticmethod
    def series_key(labels: LabelSet) -> str:
        return labels.to_canonical_string()

    def has_series(self, labels: LabelSet) -> bool:
        return self.series_key(labels) in self._series

    def ensure_series(self, labels: LabelSet) -> str:
        key = self.series_key(labels)
        if key not in self._series:
            self._series[key] = []
            self._stats[key] = SeriesStats()
        return key

    def append(self, labels: LabelSet, point: SeriesPoint) -> None:
        key = self.ensure_series(labels)
        pts = self._series[key]
        t = point.when
        pos = bisect_left(pts, t, key=lambda p: p.when)
        if pos < len(pts) and pts[pos].when == t:
            pts[pos] = point
        else:
            pts.insert(pos, point)
        if self._capacity_per_series is not None and len(pts) > self._capacity_per_series:
            overflow = len(pts) - self._capacity_per_series
            if overflow > 0:
                del pts[:overflow]
        self._stats[key].observe(point)

    def append_sample(self, labels: LabelSet, sample: Sample) -> None:
        self.append(labels, SeriesPoint(when=sample.when, value=sample.value))

    def _points(self, key: str) -> list[SeriesPoint]:
        return self._series.get(key, [])

    def count(self, labels: LabelSet) -> int:
        return len(self._points(self.series_key(labels)))

    def stats(self, labels: LabelSet) -> SeriesStats:
        key = self.series_key(labels)
        if key not in self._stats:
            return SeriesStats()
        existing = self._stats[key]
        return SeriesStats(
            count=existing.count,
            minimum=existing.minimum,
            maximum=existing.maximum,
            total=existing.total,
            last=existing.last,
            last_at=existing.last_at,
        )

    def cursor_range(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
    ) -> SeriesCursor:
        key = self.series_key(labels)
        pts = self._points(key)
        if not pts:
            return SeriesCursor(pts, 0, 0)
        utc_start = _utc(start)
        utc_end = _utc(end)
        if utc_start > utc_end:
            raise ValueError("start must be <= end")
        lo = bisect_left(pts, utc_start, key=lambda p: p.when)
        hi = bisect_right(pts, utc_end, key=lambda p: p.when)
        return SeriesCursor(pts, lo, hi)

    def query_range_list(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
    ) -> list[SeriesPoint]:
        return list(self.cursor_range(labels, start, end))

    def first_after(self, labels: LabelSet, moment: datetime) -> SeriesPoint | None:
        pts = self._points(self.series_key(labels))
        if not pts:
            return None
        idx = bisect_right(pts, _utc(moment), key=lambda p: p.when)
        if idx >= len(pts):
            return None
        return pts[idx]

    def last_before(self, labels: LabelSet, moment: datetime) -> SeriesPoint | None:
        pts = self._points(self.series_key(labels))
        if not pts:
            return None
        idx = bisect_left(pts, _utc(moment), key=lambda p: p.when)
        if idx == 0:
            return None
        return pts[idx - 1]

    def prune_older_than(self, cutoff: datetime) -> int:
        """Drop points strictly before ``cutoff`` across all series. Returns removed count."""
        utc = _utc(cutoff)
        removed = 0
        for key, pts in self._series.items():
            if not pts:
                continue
            idx = bisect_left(pts, utc, key=lambda p: p.when)
            if idx <= 0:
                continue
            removed += idx
            del pts[:idx]
        self._rebuild_stats()
        return removed

    def _rebuild_stats(self) -> None:
        self._stats.clear()
        for key, pts in self._series.items():
            stats = SeriesStats()
            for p in pts:
                stats.observe(p)
            self._stats[key] = stats

    def drop_series(self, labels: LabelSet) -> bool:
        key = self.series_key(labels)
        existed = key in self._series
        self._series.pop(key, None)
        self._stats.pop(key, None)
        return existed

    def series_keys(self) -> list[str]:
        return sorted(self._series.keys())

    def map_reduce(
        self,
        mapper: Callable[[str, list[SeriesPoint]], float],
    ) -> dict[str, float]:
        out: dict[str, float] = {}
        for key, pts in self._series.items():
            out[key] = mapper(key, pts)
        return out

    def fold_series(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        *,
        initial: float,
        folder: Callable[[float, SeriesPoint], float],
    ) -> float:
        acc = initial
        for point in self.cursor_range(labels, start, end):
            acc = folder(acc, point)
        return acc

    def aggregate_bucket(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        bucket_seconds: int,
        reducer: Callable[[Sequence[float]], float],
    ) -> list[tuple[datetime, float]]:
        """Reduce values inside each aligned UTC bucket using ``reducer``."""
        if bucket_seconds <= 0:
            raise ValueError("bucket_seconds must be positive")
        pts = self.query_range_list(labels, start, end)
        if not pts:
            return []
        buckets: MutableMapping[datetime, list[float]] = {}
        for p in pts:
            b = floor_to_bucket(p.when, bucket_seconds)
            buckets.setdefault(b, []).append(p.value)
        ordered = sorted(buckets.items(), key=lambda item: item[0])
        return [(b, reducer(vals)) for b, vals in ordered]

    def export_points(self, labels: LabelSet) -> list[SeriesPoint]:
        key = self.series_key(labels)
        return list(self._points(key))

    def import_points(self, labels: LabelSet, points: Iterable[SeriesPoint]) -> None:
        for p in points:
            self.append(labels, p)

    def merge_into(self, target: LabelSet, source: LabelSet) -> int:
        """Append all points from ``source`` into ``target``. Returns moved count."""
        src_key = self.series_key(source)
        pts = list(self._series.get(src_key, []))
        for p in pts:
            self.append(target, p)
        self.drop_series(source)
        return len(pts)

    def compact_duplicate_timestamps(self, labels: LabelSet) -> int:
        """Collapse runs with identical timestamps by keeping the last value."""
        key = self.series_key(labels)
        pts = self._series.get(key)
        if not pts:
            return 0
        merged: list[SeriesPoint] = []
        removed = 0
        for p in pts:
            if merged and merged[-1].when == p.when:
                merged[-1] = p
                removed += 1
            else:
                merged.append(p)
        self._series[key] = merged
        self._rebuild_stats()
        return removed

    def windowed_average(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        window: timedelta,
    ) -> list[tuple[datetime, float]]:
        if window.total_seconds() <= 0:
            raise ValueError("window must be positive")
        pts = self.query_range_list(labels, start, end)
        if not pts:
            return []
        out: list[tuple[datetime, float]] = []
        idx = 0
        while idx < len(pts):
            anchor = pts[idx].when
            limit = anchor + window
            total = 0.0
            count = 0
            j = idx
            while j < len(pts) and pts[j].when < limit:
                total += pts[j].value
                count += 1
                j += 1
            if count:
                out.append((anchor, total / count))
            idx = j if j > idx else idx + 1
        return out

    def derivative(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
    ) -> list[tuple[datetime, float]]:
        pts = self.query_range_list(labels, start, end)
        if len(pts) < 2:
            return []
        out: list[tuple[datetime, float]] = []
        for prev, nxt in zip(pts, pts[1:], strict=False):
            dt = (nxt.when - prev.when).total_seconds()
            if dt <= 0:
                continue
            out.append((nxt.when, (nxt.value - prev.value) / dt))
        return out

    def percentile_nearest_rank(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        p: float,
    ) -> float | None:
        if not (0.0 <= p <= 1.0):
            raise ValueError("p must be between 0 and 1")
        values = [pt.value for pt in self.cursor_range(labels, start, end)]
        if not values:
            return None
        values.sort()
        if p == 0:
            return values[0]
        if p == 1:
            return values[-1]
        k = max(1, math.ceil(p * len(values)) - 1)
        return values[k]

    def zscore_last(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
    ) -> float | None:
        pts = self.query_range_list(labels, start, end)
        if len(pts) < 2:
            return None
        mean = sum(p.value for p in pts) / len(pts)
        var = sum((p.value - mean) ** 2 for p in pts) / len(pts)
        std = math.sqrt(var)
        if std == 0:
            return 0.0
        last = pts[-1].value
        return (last - mean) / std

    def resample_max(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        bucket_seconds: int,
    ) -> list[tuple[datetime, float]]:
        return self.aggregate_bucket(
            labels,
            start,
            end,
            bucket_seconds,
            reducer=lambda vals: max(vals),
        )

    def resample_min(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        bucket_seconds: int,
    ) -> list[tuple[datetime, float]]:
        return self.aggregate_bucket(
            labels,
            start,
            end,
            bucket_seconds,
            reducer=lambda vals: min(vals),
        )

    def resample_mean(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        bucket_seconds: int,
    ) -> list[tuple[datetime, float]]:
        return self.aggregate_bucket(
            labels,
            start,
            end,
            bucket_seconds,
            reducer=lambda vals: sum(vals) / len(vals),
        )

    def total_bytes_estimate(self) -> int:
        """Very rough footprint estimate for dashboards."""
        total = 0
        for key, pts in self._series.items():
            total += len(key)
            for p in pts:
                total += 32 + 8
        return total

    def clone(self) -> MemorySeriesTable:
        other = MemorySeriesTable(capacity_per_series=self._capacity_per_series)
        for key, pts in self._series.items():
            other._series[key] = [SeriesPoint(p.when, p.value) for p in pts]
        other._rebuild_stats()
        return other

    def validate_monotonic(self, labels: LabelSet) -> bool:
        pts = self._points(self.series_key(labels))
        return all(pts[i].when <= pts[i + 1].when for i in range(len(pts) - 1))

    def split_by_time(
        self,
        labels: LabelSet,
        split_at: datetime,
    ) -> tuple[list[SeriesPoint], list[SeriesPoint]]:
        utc = _utc(split_at)
        pts = self.export_points(labels)
        left = [p for p in pts if p.when < utc]
        right = [p for p in pts if p.when >= utc]
        return left, right

    def replace_series(self, labels: LabelSet, points: Sequence[SeriesPoint]) -> None:
        key = self.ensure_series(labels)
        cleaned = sorted((_utc(p.when), p.value) for p in points)
        self._series[key] = [SeriesPoint(when=t, value=v) for t, v in cleaned]
        self._rebuild_stats()

    def histogram_values(
        self,
        labels: LabelSet,
        start: datetime,
        end: datetime,
        bin_edges: Sequence[float],
    ) -> dict[float, int]:
        counts: dict[float, int] = {}
        for edge in bin_edges:
            counts[edge] = 0
        for p in self.cursor_range(labels, start, end):
            idx = bisect_right(bin_edges, p.value)
            if idx == 0:
                continue
            edge = bin_edges[idx - 1]
            counts[edge] = counts.get(edge, 0) + 1
        return counts

    def correlate(
        self,
        left: LabelSet,
        right: LabelSet,
        start: datetime,
        end: datetime,
        *,
        max_delta: timedelta,
    ) -> list[tuple[SeriesPoint, SeriesPoint | None]]:
        """Greedy match nearest right-series point within ``max_delta`` for each left point."""
        left_pts = self.query_range_list(left, start, end)
        right_pts = self.query_range_list(right, start, end)
        if not left_pts:
            return []
        out: list[tuple[SeriesPoint, SeriesPoint | None]] = []
        r_idx = 0
        for lp in left_pts:
            best: SeriesPoint | None = None
            best_delta: timedelta | None = None
            while r_idx < len(right_pts) and right_pts[r_idx].when < lp.when - max_delta:
                r_idx += 1
            scan = r_idx
            while scan < len(right_pts) and right_pts[scan].when <= lp.when + max_delta:
                cand = right_pts[scan]
                delta = abs(cand.when - lp.when)
                if best_delta is None or delta < best_delta:
                    best = cand
                    best_delta = delta
                scan += 1
            out.append((lp, best))
        return out

    def to_samples(self, labels: LabelSet) -> list[Sample]:
        return [Sample(when=p.when, value=p.value) for p in self.export_points(labels)]

    def from_samples(self, labels: LabelSet, samples: Iterable[Sample]) -> None:
        for s in samples:
            self.append_sample(labels, s)

    def apply_mapper(
        self,
        labels: LabelSet,
        fn: Callable[[SeriesPoint], SeriesPoint],
    ) -> int:
        key = self.series_key(labels)
        pts = self._series.get(key)
        if not pts:
            return 0
        new_pts = [fn(p) for p in pts]
        self._series[key] = sorted(new_pts, key=lambda p: p.when)
        self._rebuild_stats()
        return len(new_pts)

    def filter_in_place(
        self,
        labels: LabelSet,
        predicate: Callable[[SeriesPoint], bool],
    ) -> int:
        key = self.series_key(labels)
        pts = self._series.get(key)
        if not pts:
            return 0
        before = len(pts)
        kept = [p for p in pts if predicate(p)]
        self._series[key] = kept
        self._rebuild_stats()
        return before - len(kept)

    def rename_series(self, old: LabelSet, new: LabelSet) -> None:
        old_key = self.series_key(old)
        new_key = self.series_key(new)
        if old_key not in self._series:
            raise KeyError("unknown series")
        pts = self._series.pop(old_key)
        self._stats.pop(old_key, None)
        self._series[new_key] = pts
        self._rebuild_stats()

    def snapshot_labels(self) -> list[LabelSet]:
        out: list[LabelSet] = []
        for key in sorted(self._series.keys()):
            out.append(LabelSet.parse(key))
        return out

    def assert_label_roundtrip(self) -> None:
        for key in self._series.keys():
            LabelSet.parse(key)


def build_table_from_mapping(
    mapping: Mapping[str, list[SeriesPoint]],
    *,
    capacity_per_series: int | None = None,
) -> MemorySeriesTable:
    table = MemorySeriesTable(capacity_per_series=capacity_per_series)
    for key, pts in mapping.items():
        labels = LabelSet.parse(key)
        table.import_points(labels, pts)
    return table


def memory_table_from_labels(
    labels: LabelSet,
    points: Sequence[SeriesPoint],
    *,
    capacity_per_series: int | None = None,
) -> MemorySeriesTable:
    table = MemorySeriesTable(capacity_per_series=capacity_per_series)
    table.import_points(labels, points)
    return table


def assert_finite_path(table: MemorySeriesTable, labels: LabelSet) -> None:
    for p in table.export_points(labels):
        if not math.isfinite(p.value):
            raise ParseError("non-finite value encountered in series export")
