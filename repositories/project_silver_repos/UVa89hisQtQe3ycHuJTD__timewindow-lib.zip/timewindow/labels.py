from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, Mapping

from timewindow.exceptions import ParseError

_LABEL_KEY = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _validate_key(key: str) -> None:
    if not key:
        raise ParseError("label key must be non-empty")
    if key.startswith("__") and key.endswith("__"):
        raise ParseError("dunder-like label keys are reserved")
    if not _LABEL_KEY.match(key):
        raise ParseError(f"invalid label key {key!r}")


def _escape_value(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace('"', '\\"')
    )


def _read_quoted_value(text: str, start: int) -> tuple[str, int]:
    if start >= len(text) or text[start] != '"':
        raise ParseError("expected opening quote for label value")
    i = start + 1
    out: list[str] = []
    while i < len(text):
        ch = text[i]
        if ch == '"':
            return "".join(out), i + 1
        if ch == "\\":
            if i + 1 >= len(text):
                raise ParseError("dangling escape in label value")
            nxt = text[i + 1]
            if nxt == "n":
                out.append("\n")
            elif nxt in {"\\", '"'}:
                out.append(nxt)
            else:
                out.append(nxt)
            i += 2
            continue
        out.append(ch)
        i += 1
    raise ParseError("unterminated quoted label value")


def validate_label_value(value: str, *, max_len: int = 1024) -> None:
    if len(value) > max_len:
        raise ParseError("label value exceeds maximum length")
    if "\x00" in value:
        raise ParseError("label value must not contain NUL")


@dataclass(frozen=True, slots=True)
class LabelSet:
    """Immutable ordered label set suitable for series identification."""

    pairs: tuple[tuple[str, str], ...]

    @staticmethod
    def from_mapping(mapping: Mapping[str, str]) -> LabelSet:
        items: list[tuple[str, str]] = []
        for key in sorted(mapping.keys()):
            _validate_key(key)
            value = mapping[key]
            validate_label_value(value)
            items.append((key, value))
        return LabelSet(tuple(items))

    def to_canonical_string(self) -> str:
        parts = [f'{k}="{_escape_value(v)}"' for k, v in self.pairs]
        return "{" + ",".join(parts) + "}"

    @staticmethod
    def parse(text: str) -> LabelSet:
        raw = text.strip()
        if not raw.startswith("{") or not raw.endswith("}"):
            raise ParseError("label set must be wrapped in braces")
        inner = raw[1:-1].strip()
        if not inner:
            return LabelSet(())
        pairs: list[tuple[str, str]] = []
        pos = 0
        while pos < len(inner):
            while pos < len(inner) and inner[pos].isspace():
                pos += 1
            if pos >= len(inner):
                break
            eq = inner.find("=", pos)
            if eq == -1:
                raise ParseError("malformed label pair")
            key = inner[pos:eq].strip()
            _validate_key(key)
            pos = eq + 1
            while pos < len(inner) and inner[pos].isspace():
                pos += 1
            value, pos = _read_quoted_value(inner, pos)
            validate_label_value(value)
            pairs.append((key, value))
            while pos < len(inner) and inner[pos].isspace():
                pos += 1
            if pos < len(inner) and inner[pos] == ",":
                pos += 1
                continue
            if pos < len(inner):
                raise ParseError("expected comma between label pairs")
        pairs.sort(key=lambda item: item[0])
        return LabelSet(tuple(pairs))

    def merge(self, other: Mapping[str, str]) -> LabelSet:
        data = {k: v for k, v in self.pairs}
        data.update(other)
        return LabelSet.from_mapping(data)

    def without(self, *keys: str) -> LabelSet:
        drop = set(keys)
        kept = [(k, v) for k, v in self.pairs if k not in drop]
        return LabelSet(tuple(kept))


def label_pairs_equal(a: LabelSet, b: LabelSet) -> bool:
    return a.pairs == b.pairs


def render_selector(labels: Mapping[str, str]) -> str:
    """Render a simple equality selector ``k="v",...`` without braces."""
    ls = LabelSet.from_mapping(labels)
    inner = ls.to_canonical_string()
    return inner[1:-1]


def iter_label_keys(labels: LabelSet) -> Iterable[str]:
    return (k for k, _ in labels.pairs)
