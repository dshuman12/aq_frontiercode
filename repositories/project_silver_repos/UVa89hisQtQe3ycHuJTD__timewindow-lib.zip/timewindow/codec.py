"""Compact binary codecs for timestamped scalar series.

The on-disk and on-the-wire encoding uses three primitives:

* **varint** — LEB128 unsigned integers
* **zigzag varint** — signed integers folded into unsigned varints
* **delta-of-delta** — timestamps stored as zigzag varints relative to the
  predicted next sample (``2 * prev - prev_prev``), which compresses regularly
  spaced series down to a handful of bytes per point

A single :class:`SeriesFrame` carries a header (``magic``, ``version``,
``count``, ``bucket_seconds``) followed by the encoded points. Frames are
self-describing and can be concatenated.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Iterator, Sequence

from timewindow.exceptions import ParseError
from timewindow.series_math import SeriesPoint


MAGIC = b"TWND"
VERSION = 1
HEADER_FMT = "<4sBII"  # magic, version, count, bucket_seconds
HEADER_SIZE = struct.calcsize(HEADER_FMT)


def encode_varint(value: int) -> bytes:
    """LEB128-encode a non-negative integer."""
    if value < 0:
        raise ValueError("varint cannot encode negative values")
    out = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        if value:
            out.append(byte | 0x80)
        else:
            out.append(byte)
            return bytes(out)


def decode_varint(buf: bytes, offset: int = 0) -> tuple[int, int]:
    """Decode a varint and return ``(value, new_offset)``."""
    result = 0
    shift = 0
    while True:
        if offset >= len(buf):
            raise ParseError("varint truncated")
        byte = buf[offset]
        offset += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, offset
        shift += 7
        if shift > 63:
            raise ParseError("varint too large")


def zigzag_encode(value: int) -> int:
    """Fold a signed int into an unsigned int (small magnitudes => small bytes)."""
    return (value << 1) ^ (value >> 63)


def zigzag_decode(value: int) -> int:
    return (value >> 1) ^ -(value & 1)


def encode_signed_varint(value: int) -> bytes:
    return encode_varint(zigzag_encode(value))


def decode_signed_varint(buf: bytes, offset: int = 0) -> tuple[int, int]:
    raw, offset = decode_varint(buf, offset)
    return zigzag_decode(raw), offset


def encode_float(value: float) -> bytes:
    return struct.pack("<d", value)


def decode_float(buf: bytes, offset: int = 0) -> tuple[float, int]:
    if offset + 8 > len(buf):
        raise ParseError("float truncated")
    (v,) = struct.unpack_from("<d", buf, offset)
    return v, offset + 8


@dataclass(frozen=True, slots=True)
class FrameHeader:
    magic: bytes
    version: int
    count: int
    bucket_seconds: int


def write_header(count: int, bucket_seconds: int) -> bytes:
    if count < 0:
        raise ValueError("count must be non-negative")
    if bucket_seconds < 0:
        raise ValueError("bucket_seconds must be non-negative")
    return struct.pack(HEADER_FMT, MAGIC, VERSION, count, bucket_seconds)


def read_header(buf: bytes, offset: int = 0) -> tuple[FrameHeader, int]:
    if len(buf) < offset + HEADER_SIZE:
        raise ParseError("header truncated")
    magic, version, count, bucket = struct.unpack_from(HEADER_FMT, buf, offset)
    if magic != MAGIC:
        raise ParseError(f"invalid magic bytes: {magic!r}")
    if version != VERSION:
        raise ParseError(f"unsupported codec version: {version}")
    return FrameHeader(magic=magic, version=version, count=count, bucket_seconds=bucket), offset + HEADER_SIZE


def _epoch_micros(ts: datetime) -> int:
    if ts.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")
    delta = ts.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return int(delta.total_seconds() * 1_000_000) + delta.microseconds % 1_000_000


def _from_epoch_micros(micros: int) -> datetime:
    seconds, fraction = divmod(micros, 1_000_000)
    return datetime.fromtimestamp(seconds, tz=timezone.utc).replace(microsecond=fraction)


def encode_points(points: Sequence[SeriesPoint], *, bucket_seconds: int = 0) -> bytes:
    """Encode a series with delta-of-delta timestamps + double values."""
    out = bytearray(write_header(len(points), bucket_seconds))
    if not points:
        return bytes(out)
    prev_ts = _epoch_micros(points[0].ts)
    out.extend(encode_signed_varint(prev_ts))
    out.extend(encode_float(points[0].value))
    if len(points) == 1:
        return bytes(out)
    second_ts = _epoch_micros(points[1].ts)
    delta = second_ts - prev_ts
    out.extend(encode_signed_varint(delta))
    out.extend(encode_float(points[1].value))
    prev_delta = delta
    prev_ts = second_ts
    for p in points[2:]:
        cur_ts = _epoch_micros(p.ts)
        delta = cur_ts - prev_ts
        dod = delta - prev_delta
        out.extend(encode_signed_varint(dod))
        out.extend(encode_float(p.value))
        prev_delta = delta
        prev_ts = cur_ts
    return bytes(out)


def decode_points(buf: bytes, offset: int = 0) -> tuple[list[SeriesPoint], int]:
    """Decode a frame written by :func:`encode_points`. Returns the points and offset after the frame."""
    header, offset = read_header(buf, offset)
    points: list[SeriesPoint] = []
    if header.count == 0:
        return points, offset
    first_ts, offset = decode_signed_varint(buf, offset)
    first_val, offset = decode_float(buf, offset)
    points.append(SeriesPoint(ts=_from_epoch_micros(first_ts), value=first_val))
    if header.count == 1:
        return points, offset
    delta, offset = decode_signed_varint(buf, offset)
    second_val, offset = decode_float(buf, offset)
    second_ts = first_ts + delta
    points.append(SeriesPoint(ts=_from_epoch_micros(second_ts), value=second_val))
    prev_ts = second_ts
    prev_delta = delta
    for _ in range(header.count - 2):
        dod, offset = decode_signed_varint(buf, offset)
        val, offset = decode_float(buf, offset)
        delta = prev_delta + dod
        cur_ts = prev_ts + delta
        points.append(SeriesPoint(ts=_from_epoch_micros(cur_ts), value=val))
        prev_delta = delta
        prev_ts = cur_ts
    return points, offset


def iter_decode_frames(buf: bytes) -> Iterator[list[SeriesPoint]]:
    """Iterate every frame contained in ``buf`` in order."""
    offset = 0
    while offset < len(buf):
        points, offset = decode_points(buf, offset)
        yield points


def encode_many_frames(frames: Iterable[Sequence[SeriesPoint]], *, bucket_seconds: int = 0) -> bytes:
    """Concatenate multiple encoded frames sharing the same ``bucket_seconds``."""
    out = bytearray()
    for frame in frames:
        out.extend(encode_points(frame, bucket_seconds=bucket_seconds))
    return bytes(out)


def round_trip(points: Sequence[SeriesPoint], *, bucket_seconds: int = 0) -> list[SeriesPoint]:
    """Helper used by tests and tooling to sanity-check the codec."""
    encoded = encode_points(points, bucket_seconds=bucket_seconds)
    decoded, _ = decode_points(encoded)
    return decoded


def estimate_size(points: Sequence[SeriesPoint], *, bucket_seconds: int = 0) -> int:
    return len(encode_points(points, bucket_seconds=bucket_seconds))


def compression_ratio(points: Sequence[SeriesPoint]) -> float:
    """Bytes per point ratio compared with naive ``8 + 8 = 16`` bytes."""
    if not points:
        return 0.0
    raw = len(points) * 16
    return estimate_size(points) / raw if raw else 0.0


def merge_frames(buf_a: bytes, buf_b: bytes) -> bytes:
    """Concatenate two encoded frame buffers without re-encoding."""
    return buf_a + buf_b


def count_frames(buf: bytes) -> int:
    n = 0
    offset = 0
    while offset < len(buf):
        header, offset = read_header(buf, offset)
        if header.count > 0:
            _ts, offset = decode_signed_varint(buf, offset)
            offset += 8
        if header.count > 1:
            _delta, offset = decode_signed_varint(buf, offset)
            offset += 8
            for _ in range(header.count - 2):
                _dod, offset = decode_signed_varint(buf, offset)
                offset += 8
        n += 1
    return n
