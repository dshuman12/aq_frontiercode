from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterator

from timewindow.bucket import ceil_to_bucket, floor_to_bucket
from timewindow.intervals import TimeInterval


@dataclass(slots=True)
class TumblingCursor:
    """Tracks tumbling windows for a fixed bucket width."""

    bucket_seconds: int

    def __post_init__(self) -> None:
        if self.bucket_seconds <= 0:
            raise ValueError("bucket_seconds must be positive")

    def window_containing(self, moment: datetime) -> TimeInterval:
        start = floor_to_bucket(moment, self.bucket_seconds)
        end = start + timedelta(seconds=self.bucket_seconds)
        return TimeInterval(start=start, end=end)

    def align(self, moment: datetime) -> datetime:
        """Return the bucket start containing ``moment``."""
        return floor_to_bucket(moment, self.bucket_seconds)

    def next_boundary_after(self, moment: datetime) -> datetime:
        """Smallest bucket boundary strictly greater than ``moment`` (UTC)."""
        return ceil_to_bucket(moment, self.bucket_seconds)


@dataclass(slots=True)
class HoppingCursor:
    """
    Emit windows of ``window_seconds`` length, advancing ``hop_seconds`` each step.
    """

    window_seconds: int
    hop_seconds: int

    def __post_init__(self) -> None:
        if self.window_seconds <= 0 or self.hop_seconds <= 0:
            raise ValueError("window and hop must be positive")

    def windows_covering(self, start: datetime, end: datetime) -> Iterator[TimeInterval]:
        if start.tzinfo is None or end.tzinfo is None:
            raise ValueError("start and end must be timezone-aware")
        utc_start = start.astimezone(timezone.utc)
        utc_end = end.astimezone(timezone.utc)
        if utc_start >= utc_end:
            return
        width = timedelta(seconds=self.window_seconds)
        hop = timedelta(seconds=self.hop_seconds)
        cursor = utc_start
        while cursor < utc_end:
            w_end = cursor + width
            seg_start = max(cursor, utc_start)
            seg_end = min(w_end, utc_end)
            if seg_start < seg_end:
                yield TimeInterval(start=seg_start, end=seg_end)
            cursor += hop
