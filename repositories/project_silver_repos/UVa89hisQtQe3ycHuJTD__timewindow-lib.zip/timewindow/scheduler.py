"""Lightweight in-process scheduler for periodic ``timewindow`` jobs.

Two trigger types are supported:

* :class:`IntervalTrigger` — fire every N seconds, optionally aligned to UTC
  bucket boundaries (``aligned=True``).
* :class:`CronTrigger` — fire on calendar boundaries described by a small
  cron-like grammar (``minute``, ``hour``, ``day``, ``month``, ``weekday``).

Jobs are :class:`Job` records with a callable, a trigger, and bookkeeping
fields. The :class:`Scheduler` loop is single-threaded and tickless: it sleeps
until the next due job, fires it, records the outcome, then sleeps again.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from timewindow.bucket import floor_to_bucket
from timewindow.exceptions import ParseError, TimeWindowError


JobFn = Callable[[datetime], Any]


@dataclass(frozen=True, slots=True)
class IntervalTrigger:
    every_seconds: int
    aligned: bool = False

    def next_after(self, now: datetime) -> datetime:
        if self.every_seconds <= 0:
            raise ValueError("every_seconds must be positive")
        if self.aligned:
            base = floor_to_bucket(now, self.every_seconds)
            nxt = base + timedelta(seconds=self.every_seconds)
            return nxt if nxt > now else nxt + timedelta(seconds=self.every_seconds)
        return now + timedelta(seconds=self.every_seconds)


def _parse_cron_field(text: str, *, low: int, high: int) -> set[int]:
    if text == "*":
        return set(range(low, high + 1))
    out: set[int] = set()
    for part in text.split(","):
        if not part:
            raise ParseError(f"empty cron field part in {text!r}")
        if "/" in part:
            base, step_s = part.split("/", 1)
            step = int(step_s)
            if step <= 0:
                raise ParseError(f"cron step must be positive: {part!r}")
            if base == "*":
                values = range(low, high + 1, step)
            elif "-" in base:
                start_s, end_s = base.split("-", 1)
                values = range(int(start_s), int(end_s) + 1, step)
            else:
                values = range(int(base), high + 1, step)
            out.update(int(v) for v in values)
            continue
        if "-" in part:
            start_s, end_s = part.split("-", 1)
            for v in range(int(start_s), int(end_s) + 1):
                out.add(int(v))
            continue
        out.add(int(part))
    if any(v < low or v > high for v in out):
        raise ParseError(f"cron value out of range in {text!r} (allowed {low}..{high})")
    return out


@dataclass(frozen=True, slots=True)
class CronTrigger:
    minute: str = "*"
    hour: str = "*"
    day: str = "*"
    month: str = "*"
    weekday: str = "*"

    def next_after(self, now: datetime) -> datetime:
        minutes = _parse_cron_field(self.minute, low=0, high=59)
        hours = _parse_cron_field(self.hour, low=0, high=23)
        days = _parse_cron_field(self.day, low=1, high=31)
        months = _parse_cron_field(self.month, low=1, high=12)
        weekdays = _parse_cron_field(self.weekday, low=0, high=6)
        candidate = (now + timedelta(minutes=1)).replace(second=0, microsecond=0)
        for _ in range(60 * 24 * 366 * 4):  # at most 4 years lookahead
            if (
                candidate.minute in minutes
                and candidate.hour in hours
                and candidate.day in days
                and candidate.month in months
                and (candidate.weekday() % 7) in weekdays
            ):
                return candidate
            candidate += timedelta(minutes=1)
        raise TimeWindowError("could not find a matching cron tick")


@dataclass(slots=True)
class Job:
    """Mutable record describing one scheduled task."""

    name: str
    fn: JobFn
    trigger: IntervalTrigger | CronTrigger
    next_run: datetime
    last_run: datetime | None = None
    last_status: str | None = None
    last_error: str | None = None
    successes: int = 0
    failures: int = 0
    enabled: bool = True

    def schedule_next(self, now: datetime) -> None:
        self.next_run = self.trigger.next_after(now)


@dataclass(slots=True)
class JobOutcome:
    """Recorded result of one job execution."""

    name: str
    started_at: datetime
    finished_at: datetime
    status: str
    error: str | None = None
    return_value: Any = None


class Scheduler:
    """Tickless single-thread scheduler with manual ``run_pending`` advance."""

    def __init__(self, *, clock: Callable[[], datetime] | None = None) -> None:
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._jobs: dict[str, Job] = {}
        self._outcomes: list[JobOutcome] = []
        self._lock = threading.RLock()
        self._stop = threading.Event()

    def now(self) -> datetime:
        return self._clock()

    def schedule(
        self,
        name: str,
        fn: JobFn,
        trigger: IntervalTrigger | CronTrigger,
    ) -> Job:
        if not name:
            raise ValueError("job name cannot be empty")
        with self._lock:
            if name in self._jobs:
                raise TimeWindowError(f"job {name!r} already scheduled")
            now = self.now()
            job = Job(name=name, fn=fn, trigger=trigger, next_run=trigger.next_after(now))
            self._jobs[name] = job
            return job

    def unschedule(self, name: str) -> bool:
        with self._lock:
            return self._jobs.pop(name, None) is not None

    def disable(self, name: str) -> None:
        with self._lock:
            self._jobs[name].enabled = False

    def enable(self, name: str) -> None:
        with self._lock:
            self._jobs[name].enabled = True

    def jobs(self) -> list[Job]:
        with self._lock:
            return list(self._jobs.values())

    def outcomes(self) -> list[JobOutcome]:
        with self._lock:
            return list(self._outcomes)

    def clear_outcomes(self) -> None:
        with self._lock:
            self._outcomes.clear()

    def next_due(self) -> Job | None:
        with self._lock:
            due = [j for j in self._jobs.values() if j.enabled]
            return min(due, key=lambda j: j.next_run, default=None)

    def run_pending(self) -> list[JobOutcome]:
        """Fire every job whose ``next_run`` is <= now."""
        out: list[JobOutcome] = []
        now = self.now()
        with self._lock:
            ready = [j for j in self._jobs.values() if j.enabled and j.next_run <= now]
        for job in sorted(ready, key=lambda j: j.next_run):
            outcome = self._fire(job, now=now)
            out.append(outcome)
        return out

    def run_until(self, deadline: datetime, *, sleep_seconds: float = 0.05) -> int:
        """Loop ``run_pending`` until the wall clock reaches ``deadline``. Returns fires."""
        fired = 0
        while not self._stop.is_set() and self.now() < deadline:
            outcomes = self.run_pending()
            fired += len(outcomes)
            time.sleep(sleep_seconds)
        return fired

    def stop(self) -> None:
        self._stop.set()

    def _fire(self, job: Job, *, now: datetime) -> JobOutcome:
        started = self.now()
        outcome: JobOutcome
        try:
            value = job.fn(started)
            finished = self.now()
            outcome = JobOutcome(
                name=job.name,
                started_at=started,
                finished_at=finished,
                status="ok",
                return_value=value,
            )
            with self._lock:
                job.successes += 1
                job.last_status = "ok"
                job.last_error = None
        except Exception as exc:  # capture and record, never propagate
            finished = self.now()
            outcome = JobOutcome(
                name=job.name,
                started_at=started,
                finished_at=finished,
                status="error",
                error=f"{type(exc).__name__}: {exc}",
            )
            with self._lock:
                job.failures += 1
                job.last_status = "error"
                job.last_error = outcome.error
        with self._lock:
            job.last_run = started
            job.schedule_next(self.now())
            self._outcomes.append(outcome)
            if len(self._outcomes) > 1024:
                self._outcomes = self._outcomes[-1024:]
        return outcome


def parse_cron_expression(expr: str) -> CronTrigger:
    """Parse a 5-field cron expression (``minute hour day month weekday``)."""
    parts = expr.split()
    if len(parts) != 5:
        raise ParseError(
            f"expected 5 cron fields, got {len(parts)} in {expr!r}"
        )
    return CronTrigger(
        minute=parts[0],
        hour=parts[1],
        day=parts[2],
        month=parts[3],
        weekday=parts[4],
    )


def describe_job(job: Job) -> str:
    return (
        f"{job.name} next={job.next_run.isoformat()} successes={job.successes} "
        f"failures={job.failures} enabled={job.enabled}"
    )
