from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field


def _stable_u64(data: bytes) -> int:
    digest = hashlib.blake2b(data, digest_size=8).digest()
    return int.from_bytes(digest, "big", signed=False)


@dataclass(slots=True)
class ConsistentSampler:
    """Deterministic 0..1 sampling decision from a string key."""

    salt: bytes = b"timewindow.v1"
    threshold_q16: int = 0  # out of 65536

    def __post_init__(self) -> None:
        if not (0 <= self.threshold_q16 <= 65536):
            raise ValueError("threshold_q16 must be in [0, 65536]")

    def keep(self, key: str) -> bool:
        h = _stable_u64(self.salt + key.encode("utf-8"))
        slot = h % 65536
        return slot < self.threshold_q16

    @staticmethod
    def from_rate(rate: float) -> ConsistentSampler:
        if not (0.0 <= rate <= 1.0):
            raise ValueError("rate must be between 0 and 1")
        threshold = int(round(rate * 65536))
        return ConsistentSampler(threshold_q16=threshold)


@dataclass(slots=True)
class TokenBucket:
    """Simple token bucket for bursty admission control."""

    rate_per_sec: float
    burst: float
    _tokens: float = field(init=False)
    _last: float = field(init=False)

    def __post_init__(self) -> None:
        if self.rate_per_sec <= 0 or self.burst <= 0:
            raise ValueError("rate and burst must be positive")
        self._tokens = float(self.burst)
        self._last = time.monotonic()

    def _refill(self, now: float) -> None:
        delta = max(0.0, now - self._last)
        self._tokens = min(self.burst, self._tokens + delta * self.rate_per_sec)
        self._last = now

    def allow(self, *, now: float | None = None, cost: float = 1.0) -> bool:
        if cost <= 0:
            raise ValueError("cost must be positive")
        ts = time.monotonic() if now is None else now
        self._refill(ts)
        if self._tokens >= cost:
            self._tokens -= cost
            return True
        return False
