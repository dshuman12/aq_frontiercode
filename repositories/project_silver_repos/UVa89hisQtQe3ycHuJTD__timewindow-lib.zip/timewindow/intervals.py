from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterator

from timewindow.bucket import ceil_to_bucket, floor_to_bucket
from timewindow.exceptions import IntervalError


@dataclass(frozen=True, slots=True)
class TimeInterval:
    """
    Half-open interval ``[start, end)`` expressed in absolute time.

    Both bounds must be timezone-aware datetimes in UTC after normalization.
    """

    start: datetime
    end: datetime

    def __post_init__(self) -> None:
        if self.start.tzinfo is None or self.end.tzinfo is None:
            raise IntervalError("interval bounds must be timezone-aware")
        s = self.start.astimezone(timezone.utc)
        e = self.end.astimezone(timezone.utc)
        object.__setattr__(self, "start", s)
        object.__setattr__(self, "end", e)
        if self.start >= self.end:
            raise IntervalError("interval end must be strictly after start")

    @property
    def duration(self) -> timedelta:
        return self.end - self.start

    def contains(self, moment: datetime) -> bool:
        if moment.tzinfo is None:
            raise ValueError("moment must be timezone-aware")
        m = moment.astimezone(timezone.utc)
        return self.start <= m < self.end

    def overlaps(self, other: TimeInterval) -> bool:
        return self.start < other.end and other.start < self.end

    def intersection(self, other: TimeInterval) -> TimeInterval | None:
        if not self.overlaps(other):
            return None
        start = max(self.start, other.start)
        end = min(self.end, other.end)
        if start >= end:
            return None
        return TimeInterval(start=start, end=end)


def iter_bucket_intervals(
    start: datetime,
    end: datetime,
    bucket_seconds: int,
) -> Iterator[TimeInterval]:
    """
    Yield half-open bucket intervals covering ``[start, end)`` in UTC.

    Buckets are aligned using the same rules as :func:`timewindow.bucket.floor_to_bucket`.
    """
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("start and end must be timezone-aware")
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")

    utc_start = start.astimezone(timezone.utc)
    utc_end = end.astimezone(timezone.utc)
    if utc_start >= utc_end:
        raise IntervalError("end must be after start")

    cursor = floor_to_bucket(utc_start, bucket_seconds)
    step = timedelta(seconds=bucket_seconds)
    while cursor < utc_end:
        nxt = cursor + step
        seg_start = max(cursor, utc_start)
        seg_end = min(nxt, utc_end)
        if seg_start < seg_end:
            yield TimeInterval(start=seg_start, end=seg_end)
        cursor = nxt


def count_buckets(start: datetime, end: datetime, bucket_seconds: int) -> int:
    """Count how many full bucket boundaries lie in ``[floor(start), ceil(end))``."""
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("start and end must be timezone-aware")
    if bucket_seconds <= 0:
        raise ValueError("bucket_seconds must be positive")
    a = floor_to_bucket(start, bucket_seconds)
    b = ceil_to_bucket(end, bucket_seconds)
    delta = b - a
    return int(delta.total_seconds() // bucket_seconds)
