"""Multi-resolution UTC bucket rollups with explicit completion events.

Finest resolution ingests raw ``(timestamp, value)`` pairs. Each time the UTC
bucket advances, a :class:`BucketStats` snapshot is emitted and optionally fed
into coarser resolutions so gauges and counters can be propagated consistently.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Iterator, Sequence

from timewindow.bucket import floor_to_bucket


class RollupPropagation(str, Enum):
    """How child bucket aggregates are folded into the parent resolution."""

    GAUGE = "gauge"
    COUNTER = "counter"


@dataclass(frozen=True, slots=True)
class BucketStats:
    """Closed UTC-aligned bucket with scalar aggregates."""

    bucket_start: datetime
    bucket_width_seconds: int
    count: int
    sum: float
    min: float
    max: float
    last: float

    def synthetic_value(self, mode: RollupPropagation) -> float:
        if mode is RollupPropagation.COUNTER:
            return self.sum
        return self.last


class _OpenBucket:
    __slots__ = ("start", "width", "count", "_sum", "_min", "_max", "_last")

    def __init__(self, start: datetime, width: int) -> None:
        self.start = start
        self.width = width
        self.count = 0
        self._sum = 0.0
        self._min = float("inf")
        self._max = float("-inf")
        self._last = 0.0

    def add_sample(self, value: float) -> None:
        self.count += 1
        self._sum += value
        if value < self._min:
            self._min = value
        if value > self._max:
            self._max = value
        self._last = value

    def freeze(self) -> BucketStats:
        if self.count == 0:
            return BucketStats(
                bucket_start=self.start,
                bucket_width_seconds=self.width,
                count=0,
                sum=0.0,
                min=float("nan"),
                max=float("nan"),
                last=float("nan"),
            )
        return BucketStats(
            bucket_start=self.start,
            bucket_width_seconds=self.width,
            count=self.count,
            sum=self._sum,
            min=self._min,
            max=self._max,
            last=self._last,
        )


class MonotonicBucketReducer:
    """Aggregate samples into fixed-width UTC buckets with monotonic timestamps."""

    __slots__ = ("_width", "_open")

    def __init__(self, bucket_width_seconds: int) -> None:
        if bucket_width_seconds <= 0:
            raise ValueError("bucket_width_seconds must be positive")
        self._width = bucket_width_seconds
        self._open: _OpenBucket | None = None

    @property
    def bucket_width_seconds(self) -> int:
        return self._width

    def reset(self) -> None:
        self._open = None

    def observe(self, ts: datetime, value: float) -> list[BucketStats]:
        """Add ``value`` at ``ts`` (UTC-aware). Returns any buckets closed before the new open bucket."""
        if ts.tzinfo is None:
            raise ValueError("timestamp must be timezone-aware")
        start = floor_to_bucket(ts, self._width)
        closed: list[BucketStats] = []
        if self._open is None:
            self._open = _OpenBucket(start, self._width)
        elif start > self._open.start:
            closed.append(self._open.freeze())
            step = timedelta(seconds=self._width)
            cur = self._open.start + step
            while cur < start:
                ob = _OpenBucket(cur, self._width)
                closed.append(ob.freeze())
                cur += step
            self._open = _OpenBucket(start, self._width)
        elif start < self._open.start:
            raise ValueError("timestamps must be non-decreasing for MonotonicBucketReducer")
        self._open.add_sample(value)
        return closed

    def flush(self) -> BucketStats | None:
        if self._open is None:
            return None
        stats = self._open.freeze()
        self._open = None
        return stats


class TieredRollupEngine:
    """Feed finest resolution raw points; each closed child bucket becomes a parent sample."""

    __slots__ = ("_widths", "_layers", "_mode")

    def __init__(
        self,
        bucket_widths_seconds: Sequence[int],
        *,
        propagation: RollupPropagation = RollupPropagation.GAUGE,
    ) -> None:
        widths = list(bucket_widths_seconds)
        if len(widths) < 1:
            raise ValueError("at least one bucket width is required")
        if any(w <= 0 for w in widths):
            raise ValueError("bucket widths must be positive")
        if len(widths) > 1 and any(widths[i] >= widths[i + 1] for i in range(len(widths) - 1)):
            raise ValueError("bucket widths must be strictly increasing from finest to coarsest")
        self._widths = widths
        self._mode = propagation
        self._layers = [MonotonicBucketReducer(w) for w in widths]

    @property
    def widths(self) -> tuple[int, ...]:
        return tuple(self._widths)

    @property
    def propagation(self) -> RollupPropagation:
        return self._mode

    def reset(self) -> None:
        for layer in self._layers:
            layer.reset()

    def observe(self, ts: datetime, value: float) -> dict[int, list[BucketStats]]:
        """Return map ``level -> closed buckets`` where ``0`` is the finest resolution."""
        closed0 = self._layers[0].observe(ts, value)
        out: dict[int, list[BucketStats]] = {0: list(closed0)}
        wave: list[BucketStats] = [b for b in closed0 if b.count > 0]
        for level_idx in range(1, len(self._layers)):
            layer = self._layers[level_idx]
            next_wave: list[BucketStats] = []
            for st in wave:
                v = st.synthetic_value(self._mode)
                next_wave.extend(layer.observe(st.bucket_start, v))
            wave = [b for b in next_wave if b.count > 0]
            if next_wave:
                out[level_idx] = list(next_wave)
        return out

    def flush_all(self) -> dict[int, list[BucketStats]]:
        """Drain every layer and return the final map of ``level -> trailing buckets``."""
        out: dict[int, list[BucketStats]] = {}
        wave: list[BucketStats] = []
        tail0 = self._layers[0].flush()
        if tail0 is not None:
            out.setdefault(0, []).append(tail0)
            if tail0.count > 0:
                wave.append(tail0)
        for level_idx in range(1, len(self._layers)):
            layer = self._layers[level_idx]
            next_wave: list[BucketStats] = []
            for st in wave:
                v = st.synthetic_value(self._mode)
                next_wave.extend(layer.observe(st.bucket_start, v))
            tail = layer.flush()
            if tail is not None:
                next_wave.append(tail)
            if next_wave:
                out.setdefault(level_idx, []).extend(next_wave)
            wave = [b for b in next_wave if b.count > 0]
        return out


def iter_bucket_stats_series(
    points: Sequence[tuple[datetime, float]],
    bucket_width_seconds: int,
) -> Iterator[BucketStats]:
    """Offline helper: monotonic scan producing completed :class:`BucketStats` objects."""
    reducer = MonotonicBucketReducer(bucket_width_seconds)
    for ts, v in points:
        for b in reducer.observe(ts, v):
            yield b
    tail = reducer.flush()
    if tail is not None and tail.count:
        yield tail
