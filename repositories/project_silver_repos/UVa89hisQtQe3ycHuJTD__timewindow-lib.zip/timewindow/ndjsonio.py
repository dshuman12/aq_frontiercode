from __future__ import annotations

import io
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO, Iterable, Iterator, TextIO

from timewindow.exceptions import ParseError


def _record_strings_have_line_breaks(obj: Any) -> bool:
    if isinstance(obj, str):
        return "\n" in obj or "\r" in obj
    if isinstance(obj, dict):
        return any(_record_strings_have_line_breaks(v) for v in obj.values())
    if isinstance(obj, list):
        return any(_record_strings_have_line_breaks(v) for v in obj)
    return False


@dataclass(slots=True)
class NdjsonWriter:
    """Buffered newline-delimited JSON writer with UTF-8 encoding."""

    stream: TextIO
    flush_every: int = 128
    _buffer: list[str] = field(default_factory=list, init=False)
    _lines: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        if self.flush_every <= 0:
            raise ValueError("flush_every must be positive")
        self._buffer = []
        self._lines = 0

    def write_obj(self, obj: Any) -> None:
        if _record_strings_have_line_breaks(obj):
            raise ParseError("NDJSON records must not contain raw newlines in string fields")
        line = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
        if "\n" in line or "\r" in line:
            raise ParseError("NDJSON records must not contain raw newlines")
        self._buffer.append(line)
        self._lines += 1
        if self._lines >= self.flush_every:
            self.flush()

    def flush(self) -> None:
        if not self._buffer:
            return
        chunk = "\n".join(self._buffer) + "\n"
        self.stream.write(chunk)
        self.stream.flush()
        self._buffer.clear()
        self._lines = 0

    def close(self) -> None:
        self.flush()


@dataclass(slots=True)
class NdjsonReader:
    """Streaming NDJSON reader with optional max line length guard."""

    stream: TextIO
    max_line_bytes: int = 1 << 20

    def __post_init__(self) -> None:
        if self.max_line_bytes <= 0:
            raise ValueError("max_line_bytes must be positive")

    def iter_objects(self) -> Iterator[Any]:
        for raw in self.stream:
            if len(raw.encode("utf-8")) > self.max_line_bytes:
                raise ParseError("NDJSON line exceeds max_line_bytes")
            line = raw.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ParseError(f"invalid json: {line[:120]!r}") from exc


def write_ndjson_path(path: Path, rows: Iterable[dict[str, Any]], *, flush_every: int = 64) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        writer = NdjsonWriter(handle, flush_every=flush_every)
        for row in rows:
            writer.write_obj(row)
        writer.close()


def read_ndjson_path(path: Path, *, max_line_bytes: int = 1 << 20) -> list[Any]:
    with path.open("r", encoding="utf-8") as handle:
        reader = NdjsonReader(handle, max_line_bytes=max_line_bytes)
        return list(reader.iter_objects())


def ndjson_from_text(text: str) -> list[Any]:
    reader = NdjsonReader(io.StringIO(text))
    return list(reader.iter_objects())


def ndjson_to_text(rows: Iterable[dict[str, Any]]) -> str:
    buf = io.StringIO()
    writer = NdjsonWriter(buf, flush_every=1)
    for row in rows:
        writer.write_obj(row)
    writer.close()
    return buf.getvalue()


def validate_record_shape(obj: Any, required_keys: set[str]) -> dict[str, Any]:
    if not isinstance(obj, dict):
        raise ParseError("record must be a JSON object")
    missing = required_keys - obj.keys()
    if missing:
        raise ParseError(f"missing keys: {sorted(missing)}")
    return obj


def coerce_record(obj: Any) -> dict[str, Any]:
    if isinstance(obj, dict):
        return dict(obj)
    raise ParseError("record must be object")


def append_only_file(path: Path, line: str) -> None:
    if "\n" in line or "\r" in line:
        raise ValueError("single-line append must not include newline characters")
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(line + "\n")
        handle.flush()


def tail_lines(path: Path, max_lines: int) -> list[str]:
    if max_lines <= 0:
        raise ValueError("max_lines must be positive")
    data = path.read_text(encoding="utf-8").splitlines()
    return data[-max_lines:]


def count_lines(path: Path) -> int:
    total = 0
    with path.open("r", encoding="utf-8", errors="strict") as handle:
        for _ in handle:
            total += 1
    return total


def stream_bytes_as_text(stream: BinaryIO) -> TextIO:
    data = stream.read().decode("utf-8")
    return io.StringIO(data)


def partition_batches(rows: list[dict[str, Any]], batch_size: int) -> list[list[dict[str, Any]]]:
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    return [rows[i : i + batch_size] for i in range(0, len(rows), batch_size)]


def merge_ndjson_strings(chunks: Iterable[str]) -> list[Any]:
    out: list[Any] = []
    for chunk in chunks:
        out.extend(ndjson_from_text(chunk))
    return out


def stable_dumps(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def rewrite_compact(path: Path) -> int:
    rows = read_ndjson_path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    write_ndjson_path(tmp, (coerce_record(r) for r in rows), flush_every=256)
    tmp.replace(path)
    return len(rows)


def sniff_array_or_ndjson(text: str) -> str:
    stripped = text.lstrip()
    if stripped.startswith("["):
        return "json-array"
    return "ndjson"


def load_any_json_collection(text: str) -> list[Any]:
    mode = sniff_array_or_ndjson(text)
    if mode == "json-array":
        data = json.loads(text)
        if not isinstance(data, list):
            raise ParseError("expected JSON array")
        return data
    return ndjson_from_text(text)


def redact_keys(record: dict[str, Any], keys: set[str]) -> dict[str, Any]:
    return {k: ("***" if k in keys else v) for k, v in record.items()}


def project_columns(record: dict[str, Any], columns: Sequence[str]) -> dict[str, Any]:
    missing = [c for c in columns if c not in record]
    if missing:
        raise KeyError(f"missing columns: {missing}")
    return {c: record[c] for c in columns}


def widen_records(rows: list[dict[str, Any]], defaults: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in rows:
        merged = dict(defaults)
        merged.update(row)
        out.append(merged)
    return out


def numeric_field(record: dict[str, Any], key: str) -> float:
    if key not in record:
        raise KeyError(key)
    value = record[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ParseError("field must be numeric")
    return float(value)


def string_field(record: dict[str, Any], key: str) -> str:
    if key not in record:
        raise KeyError(key)
    value = record[key]
    if not isinstance(value, str):
        raise ParseError("field must be string")
    return value


def sort_records(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    return sorted(rows, key=lambda r: r.get(key))


def dedupe_last_wins(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    seen: dict[Any, dict[str, Any]] = {}
    for row in rows:
        seen[row[key]] = row
    return list(seen.values())


def checksum_records(rows: Iterable[dict[str, Any]]) -> int:
    total = 0
    for row in rows:
        blob = stable_dumps(row).encode("utf-8")
        total += len(blob)
    return total


def limit_records(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    if limit < 0:
        raise ValueError("limit must be non-negative")
    return rows[:limit]


def offset_records(rows: list[dict[str, Any]], offset: int) -> list[dict[str, Any]]:
    if offset < 0:
        raise ValueError("offset must be non-negative")
    return rows[offset:]


def window_slice(rows: list[dict[str, Any]], offset: int, limit: int) -> list[dict[str, Any]]:
    return limit_records(offset_records(rows, offset), limit)


def explode_tags(record: dict[str, Any], prefix: str = "tag_") -> dict[str, Any]:
    tags = record.get("tags")
    if not isinstance(tags, dict):
        return dict(record)
    out = dict(record)
    out.pop("tags", None)
    for k, v in tags.items():
        out[f"{prefix}{k}"] = v
    return out


def implode_tags(record: dict[str, Any], prefix: str = "tag_") -> dict[str, Any]:
    out: dict[str, Any] = {}
    tags: dict[str, Any] = {}
    for k, v in record.items():
        if k.startswith(prefix):
            tags[k[len(prefix) :]] = v
        else:
            out[k] = v
    if tags:
        out["tags"] = tags
    return out


def validate_utf8_file(path: Path) -> None:
    path.read_bytes().decode("utf-8", errors="strict")


def file_size(path: Path) -> int:
    return path.stat().st_size
