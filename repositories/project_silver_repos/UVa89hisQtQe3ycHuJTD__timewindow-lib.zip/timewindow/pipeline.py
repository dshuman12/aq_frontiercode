from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Callable, Deque, Generic, TypeVar

T = TypeVar("T")


@dataclass(slots=True)
class BufferedBatch(Generic[T]):
    """Buffer items until a count or wall-clock watermark is reached."""

    max_items: int
    max_wait: timedelta
    clock: Callable[[], datetime]

    _buffer: list[T] = field(default_factory=list, init=False)
    _first: datetime | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if self.max_items <= 0:
            raise ValueError("max_items must be positive")
        if self.max_wait.total_seconds() <= 0:
            raise ValueError("max_wait must be positive")

    def push(self, item: T) -> list[T] | None:
        now = self.clock().astimezone(timezone.utc)
        if self._first is None:
            self._first = now
        elif self._buffer and now - self._first >= self.max_wait:
            flushed = self._flush()
            self._first = now
            self._buffer.append(item)
            if len(self._buffer) >= self.max_items:
                return flushed + self._flush()
            return flushed
        self._buffer.append(item)
        if len(self._buffer) >= self.max_items:
            return self._flush()
        return None

    def _flush(self) -> list[T]:
        out = self._buffer
        self._buffer = []
        self._first = None
        return out

    def flush(self) -> list[T]:
        if not self._buffer:
            return []
        return self._flush()


@dataclass(slots=True)
class MonotonicWatermark:
    """Track the maximum observed timestamp for idempotent watermark advancement."""

    value: datetime | None = None

    def observe(self, moment: datetime) -> datetime:
        if moment.tzinfo is None:
            raise ValueError("moment must be timezone-aware")
        utc = moment.astimezone(timezone.utc)
        if self.value is None or utc > self.value:
            self.value = utc
        return self.value


@dataclass(slots=True)
class RecentDeque(Generic[T]):
    """Deque with explicit maxlen for hot-path metrics."""

    maxlen: int
    _dq: Deque[T] = field(init=False)

    def __post_init__(self) -> None:
        if self.maxlen <= 0:
            raise ValueError("maxlen must be positive")
        self._dq = deque(maxlen=self.maxlen)

    def append(self, item: T) -> None:
        self._dq.append(item)

    def __len__(self) -> int:  # pragma: no cover - trivial
        return len(self._dq)

    def snapshot(self) -> list[T]:
        return list(self._dq)
