from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone

from timewindow.exceptions import ParseError
from timewindow.serde import parse_instant_iso8601

_TS_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (
        re.compile(
            r"(?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))"
        ),
        "iso",
    ),
    (
        re.compile(r"(?P<ts>\d{10})"),
        "unix_s",
    ),
    (
        re.compile(r"(?P<ts>\d{13})"),
        "unix_ms",
    ),
)


@dataclass(frozen=True, slots=True)
class ParsedLogLine:
    raw: str
    timestamp: datetime | None
    kind: str | None


def extract_timestamp(line: str) -> ParsedLogLine:
    """Best-effort timestamp extraction for common log formats."""
    text = line.rstrip("\n")
    for pattern, kind in _TS_PATTERNS:
        m = pattern.search(text)
        if not m:
            continue
        token = m.group("ts")
        try:
            if kind == "iso":
                dt = parse_instant_iso8601(token.replace(" ", "T"))
            elif kind == "unix_s":
                dt = datetime.fromtimestamp(int(token), tz=timezone.utc)
            elif kind == "unix_ms":
                dt = datetime.fromtimestamp(int(token) / 1000.0, tz=timezone.utc)
            else:  # pragma: no cover
                continue
        except (ParseError, OSError, OverflowError, ValueError):
            continue
        return ParsedLogLine(raw=text, timestamp=dt, kind=kind)
    return ParsedLogLine(raw=text, timestamp=None, kind=None)


def iter_ndjson_timestamps(lines: list[str]) -> list[datetime]:
    """Parse NDJSON-ish lines and return timestamps in file order (skips failures)."""
    out: list[datetime] = []
    for line in lines:
        parsed = extract_timestamp(line)
        if parsed.timestamp is not None:
            out.append(parsed.timestamp)
    return out
