from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class RunningMean:
    """Welford's online algorithm for mean and population variance."""

    count: int = 0
    mean: float = 0.0
    _m2: float = 0.0

    def update(self, value: float) -> None:
        self.count += 1
        delta = value - self.mean
        self.mean += delta / self.count
        delta2 = value - self.mean
        self._m2 += delta * delta2

    @property
    def variance(self) -> float:
        if self.count < 2:
            return 0.0
        return self._m2 / self.count

    @property
    def sample_variance(self) -> float:
        if self.count < 2:
            return 0.0
        return self._m2 / (self.count - 1)


class RingBufferFloat:
    """Fixed-capacity ring buffer for floats."""

    __slots__ = ("capacity", "_data", "_index", "_size")

    def __init__(self, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self._data: list[float | None] = [None] * capacity
        self._index = 0
        self._size = 0

    def push(self, value: float) -> None:
        self._data[self._index] = value
        self._index = (self._index + 1) % self.capacity
        self._size = min(self.capacity, self._size + 1)

    def snapshot(self) -> list[float]:
        if self._size == 0:
            return []
        if self._size < self.capacity:
            return [float(x) for x in self._data[: self._size] if x is not None]
        ordered = self._data[self._index :] + self._data[: self._index]
        return [float(x) for x in ordered if x is not None]

    def clear(self) -> None:
        self._data = [None] * self.capacity
        self._index = 0
        self._size = 0
