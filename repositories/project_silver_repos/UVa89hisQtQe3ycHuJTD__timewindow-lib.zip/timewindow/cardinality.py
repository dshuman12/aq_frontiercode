from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field

from timewindow.labels import LabelSet


@dataclass(slots=True)
class CardinalityTracker:
    """Track up to ``max_series`` distinct label sets with LRU eviction."""

    max_series: int
    _order: OrderedDict[str, LabelSet] = field(default_factory=OrderedDict, init=False)

    def __post_init__(self) -> None:
        if self.max_series <= 0:
            raise ValueError("max_series must be positive")

    def touch(self, labels: LabelSet) -> bool:
        """
        Register ``labels``.

        Returns ``True`` if the label set is new after eviction policy, else ``False``.
        """
        key = labels.to_canonical_string()
        existed = key in self._order
        if existed:
            self._order.move_to_end(key, last=True)
            return False
        self._order[key] = labels
        if len(self._order) > self.max_series:
            self._order.popitem(last=False)
        return True

    def __len__(self) -> int:  # pragma: no cover - trivial
        return len(self._order)

    def snapshot(self) -> list[LabelSet]:
        return list(self._order.values())
