"""CSV reading and writing for timestamped scalar series.

The CSV format is intentionally minimal so it interoperates with Excel,
``pandas.read_csv`` and ``cut``/``awk``: the first line is a header,
followed by ``timestamp,value`` rows where ``timestamp`` is an ISO-8601
instant (``Z`` accepted) and ``value`` is a finite float.
"""

from __future__ import annotations

import csv
import io
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Iterator, Sequence, TextIO

from timewindow.exceptions import ParseError
from timewindow.serde import format_instant_iso8601, parse_instant_iso8601
from timewindow.series_math import SeriesPoint, ensure_monotonic


DEFAULT_TS_COLUMN = "timestamp"
DEFAULT_VALUE_COLUMN = "value"


@dataclass(frozen=True, slots=True)
class CsvSchema:
    """Column layout for a series CSV file."""

    timestamp_column: str = DEFAULT_TS_COLUMN
    value_column: str = DEFAULT_VALUE_COLUMN
    delimiter: str = ","

    def header(self) -> list[str]:
        return [self.timestamp_column, self.value_column]


def _coerce_value(raw: str, line_no: int, column: str) -> float:
    text = raw.strip()
    if not text:
        raise ParseError(f"line {line_no}: empty value in column {column!r}")
    try:
        v = float(text)
    except ValueError as exc:
        raise ParseError(f"line {line_no}: {raw!r} is not a number") from exc
    if not math.isfinite(v):
        raise ParseError(f"line {line_no}: non-finite value {v!r}")
    return v


def _coerce_timestamp(raw: str, line_no: int) -> datetime:
    text = raw.strip()
    if not text:
        raise ParseError(f"line {line_no}: empty timestamp")
    try:
        return parse_instant_iso8601(text)
    except Exception as exc:  # narrowed below in unit tests
        raise ParseError(f"line {line_no}: invalid timestamp {raw!r}") from exc


def read_series_stream(
    stream: TextIO,
    *,
    schema: CsvSchema = CsvSchema(),
    skip_blank_lines: bool = True,
) -> Iterator[SeriesPoint]:
    """Yield :class:`SeriesPoint` rows from an open text stream."""
    reader = csv.reader(stream, delimiter=schema.delimiter)
    try:
        header = next(reader)
    except StopIteration:
        raise ParseError("empty CSV (no header row)")

    norm = [c.strip() for c in header]
    if schema.timestamp_column not in norm:
        raise ParseError(f"missing timestamp column {schema.timestamp_column!r}")
    if schema.value_column not in norm:
        raise ParseError(f"missing value column {schema.value_column!r}")
    ts_idx = norm.index(schema.timestamp_column)
    val_idx = norm.index(schema.value_column)

    for line_no, row in enumerate(reader, start=2):
        if not row:
            if skip_blank_lines:
                continue
            raise ParseError(f"line {line_no}: blank row not allowed")
        if max(ts_idx, val_idx) >= len(row):
            raise ParseError(f"line {line_no}: row has fewer columns than the header")
        ts = _coerce_timestamp(row[ts_idx], line_no)
        value = _coerce_value(row[val_idx], line_no, schema.value_column)
        yield SeriesPoint(ts=ts, value=value)


def read_series_text(
    text: str,
    *,
    schema: CsvSchema = CsvSchema(),
    skip_blank_lines: bool = True,
) -> list[SeriesPoint]:
    """Parse an entire CSV string into a sorted list of :class:`SeriesPoint`."""
    points = list(read_series_stream(io.StringIO(text), schema=schema, skip_blank_lines=skip_blank_lines))
    ensure_monotonic(points)
    return points


def read_series_path(
    path: str | Path,
    *,
    schema: CsvSchema = CsvSchema(),
    skip_blank_lines: bool = True,
) -> list[SeriesPoint]:
    """Read CSV from disk and return a list of :class:`SeriesPoint`."""
    p = Path(path)
    with p.open("r", encoding="utf-8", newline="") as handle:
        points = list(read_series_stream(handle, schema=schema, skip_blank_lines=skip_blank_lines))
    ensure_monotonic(points)
    return points


def write_series_stream(
    stream: TextIO,
    points: Iterable[SeriesPoint],
    *,
    schema: CsvSchema = CsvSchema(),
) -> int:
    """Write series rows to ``stream`` and return the number of data rows emitted."""
    writer = csv.writer(stream, delimiter=schema.delimiter, lineterminator="\n")
    writer.writerow(schema.header())
    n = 0
    for p in points:
        if p.ts.tzinfo is None:
            raise ParseError("series points must have timezone-aware timestamps")
        if not math.isfinite(p.value):
            raise ParseError(f"non-finite value at {p.ts.isoformat()}")
        writer.writerow([format_instant_iso8601(p.ts), repr(p.value)])
        n += 1
    return n


def write_series_text(points: Iterable[SeriesPoint], *, schema: CsvSchema = CsvSchema()) -> str:
    """Render series rows as a CSV string (header + data)."""
    buf = io.StringIO()
    write_series_stream(buf, points, schema=schema)
    return buf.getvalue()


def write_series_path(
    path: str | Path,
    points: Iterable[SeriesPoint],
    *,
    schema: CsvSchema = CsvSchema(),
) -> int:
    """Atomically write CSV rows to disk via a sibling ``.tmp`` file rename."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        n = write_series_stream(handle, points, schema=schema)
    tmp.replace(p)
    return n


def detect_schema(text: str) -> CsvSchema:
    """Best-effort schema detection from the first non-empty line.

    Falls back to the default schema if the header looks like it already has
    ``timestamp`` and ``value`` columns. Otherwise the first column is treated
    as the timestamp and the second as the value.
    """
    sample = text.lstrip().splitlines()
    if not sample:
        raise ParseError("empty input")
    first = sample[0]
    delim = "," if "," in first else ("\t" if "\t" in first else ";")
    cols = [c.strip() for c in first.split(delim)]
    if DEFAULT_TS_COLUMN in cols and DEFAULT_VALUE_COLUMN in cols:
        return CsvSchema(delimiter=delim)
    if len(cols) < 2:
        raise ParseError("could not detect at least two columns")
    return CsvSchema(timestamp_column=cols[0], value_column=cols[1], delimiter=delim)


def merge_series_files(
    paths: Sequence[str | Path],
    *,
    schema: CsvSchema = CsvSchema(),
    sort_output: bool = True,
) -> list[SeriesPoint]:
    """Concatenate multiple CSV files and (optionally) sort the result."""
    out: list[SeriesPoint] = []
    for p in paths:
        out.extend(read_series_path(p, schema=schema))
    if sort_output:
        out.sort(key=lambda sp: sp.ts)
    return out


def split_series_by_day(points: Sequence[SeriesPoint]) -> dict[str, list[SeriesPoint]]:
    """Group points by ``YYYY-MM-DD`` UTC day for sharded archival."""
    out: dict[str, list[SeriesPoint]] = {}
    for p in points:
        key = p.ts.astimezone(p.ts.tzinfo).strftime("%Y-%m-%d")
        out.setdefault(key, []).append(p)
    return out


def count_rows_path(path: str | Path, *, schema: CsvSchema = CsvSchema()) -> int:
    """Count data rows in a CSV without materializing them."""
    n = 0
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        for _ in read_series_stream(handle, schema=schema):
            n += 1
    return n
