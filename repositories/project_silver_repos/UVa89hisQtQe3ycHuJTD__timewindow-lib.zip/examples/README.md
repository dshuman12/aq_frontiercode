# timewindow examples

Runnable examples that show how to use the library on small, realistic datasets.

| File | Purpose |
| --- | --- |
| `sample_metrics.csv` | Per-second metric series with a planted spike, level shift, and gap. |
| `sample_events.ndjson` | Tiny NDJSON stream used by `analyze_events.py`. |
| `analyze_metrics.py` | Load CSV, run rebucket + smoothing + anomaly detection, print a report. |
| `rollup_pipeline.py` | Demonstrates `TieredRollupEngine` across 1m/5m/1h. |
| `window_aggregates.py` | Streams points through `TimeWindowSum` and `TimeWindowMinMax`. |
| `analyze_events.py` | Reads NDJSON events and rebuckets them into per-minute counts. |

Run any of them after `pip install -e .`:

```bash
python examples/analyze_metrics.py
python examples/rollup_pipeline.py
python examples/window_aggregates.py
python examples/analyze_events.py
```

Each script is short enough to copy as a starting point for your own pipeline.
