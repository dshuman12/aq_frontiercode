"""Read an NDJSON event stream and rebucket events into per-minute counts."""

from __future__ import annotations

import sys
from pathlib import Path

from timewindow.bucket import floor_to_bucket
from timewindow.ndjsonio import ndjson_from_text
from timewindow.serde import format_instant_iso8601, parse_instant_iso8601


def main(argv: list[str]) -> int:
    path = Path(argv[1]) if len(argv) > 1 else Path(__file__).with_name("sample_events.ndjson")
    text = path.read_text(encoding="utf-8")
    events = ndjson_from_text(text)
    print(f"loaded {len(events)} events from {path}")

    bucket_seconds = 60
    counts: dict[str, int] = {}
    by_kind: dict[str, dict[str, int]] = {}
    for ev in events:
        ts = parse_instant_iso8601(str(ev["timestamp"]))
        bucket_start = floor_to_bucket(ts, bucket_seconds)
        bkey = format_instant_iso8601(bucket_start)
        counts[bkey] = counts.get(bkey, 0) + 1
        kind = str(ev.get("event", "unknown"))
        by_kind.setdefault(bkey, {})[kind] = by_kind.setdefault(bkey, {}).get(kind, 0) + 1

    print()
    print("=== events per minute ===")
    for bkey in sorted(counts):
        breakdown = ", ".join(f"{k}={v}" for k, v in sorted(by_kind.get(bkey, {}).items()))
        print(f"  {bkey}  total={counts[bkey]:>3}  ({breakdown})")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
