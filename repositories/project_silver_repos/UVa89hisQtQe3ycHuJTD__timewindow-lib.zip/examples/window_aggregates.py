"""Stream points through ``TimeWindowSum`` and ``TimeWindowMinMax``."""

from __future__ import annotations

import sys
from datetime import timedelta
from pathlib import Path

from timewindow.csvio import read_series_path
from timewindow.serde import format_instant_iso8601
from timewindow.sliding_windows import TimeWindowMinMax, TimeWindowSum


def main(argv: list[str]) -> int:
    path = Path(argv[1]) if len(argv) > 1 else Path(__file__).with_name("sample_metrics.csv")
    points = read_series_path(path)

    span = timedelta(seconds=10)
    sums = TimeWindowSum(span)
    extremes = TimeWindowMinMax(span)

    print(f"streaming {len(points)} points with a {span.total_seconds():.0f}s window")
    print(f"{'timestamp':<25}  {'value':>8}  {'window_sum':>12}  {'min':>8}  {'max':>8}")
    for p in points[: min(40, len(points))]:
        sums.push(p.ts, p.value)
        extremes.push(p.ts, p.value)
        mm = extremes.min_max()
        print(
            f"{format_instant_iso8601(p.ts):<25}  {p.value:>8.3f}  "
            f"{sums.total():>12.3f}  "
            f"{(mm.minimum if mm.minimum is not None else 0.0):>8.3f}  "
            f"{(mm.maximum if mm.maximum is not None else 0.0):>8.3f}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
