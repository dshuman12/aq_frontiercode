"""Analyze a CSV metrics file: rebucket, smooth, detect anomalies, and report.

Usage:

    python examples/analyze_metrics.py [path]

If no path is given the bundled ``sample_metrics.csv`` is used.
"""

from __future__ import annotations

import sys
from pathlib import Path

from timewindow.csvio import read_series_path
from timewindow.recipes import (
    DetectionConfig,
    RebucketRequest,
    analyze_series,
)
from timewindow.report import (
    histogram_of_values,
    render_anomaly_report_text,
    render_histogram_text,
    render_series_summary_text,
)


def run(path: Path) -> int:
    points = read_series_path(path)
    print(f"loaded {len(points)} points from {path}")

    result = analyze_series(
        points,
        rebucket=RebucketRequest(bucket_seconds=5, aggregation="mean", fill_method="ffill"),
        smoothing_window=3,
        detrend=False,
        detection=DetectionConfig(
            spike_window=10,
            spike_threshold=2.5,
            spike_warmup=4,
            level_left_window=4,
            level_right_window=4,
            level_min_shift=4.0,
            stale_window=8,
            expected_step_seconds=5.0,
            gap_tolerance=2.0,
            change_point_window=7,
            change_point_threshold=4.0,
            residual_window=5,
            residual_z_threshold=2.5,
            merge_gap_seconds=10.0,
        ),
        top_k_events=5,
    )

    print()
    print("=== series summary (after rebucketing) ===")
    print(render_series_summary_text(result.summary))

    print()
    print("=== value histogram ===")
    print(render_histogram_text(histogram_of_values(result.cleaned, bins=8)))

    print()
    print("=== anomaly report ===")
    print(render_anomaly_report_text(result.anomaly_report))
    return 0


def main(argv: list[str]) -> int:
    if len(argv) > 1:
        path = Path(argv[1])
    else:
        path = Path(__file__).with_name("sample_metrics.csv")
    if not path.exists():
        print(f"input file not found: {path}", file=sys.stderr)
        return 1
    return run(path)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
