"""Stream a CSV series through tiered rollups (1m / 5m / 1h)."""

from __future__ import annotations

import sys
from pathlib import Path

from timewindow.csvio import read_series_path
from timewindow.recipes import RollupRequest, run_tiered_rollup
from timewindow.serde import format_instant_iso8601
from timewindow.tiered_rollups import RollupPropagation


def main(argv: list[str]) -> int:
    path = Path(argv[1]) if len(argv) > 1 else Path(__file__).with_name("sample_metrics.csv")
    points = read_series_path(path)
    request = RollupRequest(
        bucket_widths_seconds=(60, 300, 3600),
        propagation=RollupPropagation.GAUGE,
    )
    result = run_tiered_rollup(points, request)
    for level, items in sorted(result.layers.items()):
        width = request.bucket_widths_seconds[level]
        print(f"--- layer {level} (width={width}s, {len(items)} buckets) ---")
        for b in items:
            label = format_instant_iso8601(b.bucket_start)
            if b.count == 0:
                print(f"  {label}: empty")
            else:
                print(
                    f"  {label}: count={b.count} sum={b.sum:.3f}"
                    f" min={b.min:.3f} max={b.max:.3f} last={b.last:.3f}"
                )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
