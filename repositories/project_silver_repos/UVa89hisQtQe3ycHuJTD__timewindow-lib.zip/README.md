# timewindow

Practical time-series toolkit for Python: UTC bucketing, rebucketing, tiered
rollups, anomaly detection, an append-only on-disk store, a small query DSL,
and a stdlib HTTP API. Use it as a library, a `timewindow` CLI, or a tiny
self-contained service.

## Install

```bash
pip install -e ".[dev]"
```

## At a glance

```python
from datetime import datetime, timezone
from timewindow import floor_to_bucket, ceil_to_bucket

ts = datetime(2026, 5, 1, 17, 42, 9, tzinfo=timezone.utc)
start = floor_to_bucket(ts, 3600)   # 2026-05-01 17:00:00+00:00
end = ceil_to_bucket(ts, 3600)      # 2026-05-01 18:00:00+00:00
```

All inputs must be timezone-aware; naive datetimes raise `ValueError`.
`bucket_seconds` should evenly divide common day lengths if you care about
calendar-day alignment — the math itself is pure epoch seconds.

## End-to-end pipeline

```python
from timewindow import (
    DetectionConfig,
    RebucketRequest,
    analyze_csv_file,
    render_anomaly_report_text,
    render_series_summary_text,
)

result = analyze_csv_file(
    "examples/sample_metrics.csv",
    rebucket=RebucketRequest(bucket_seconds=5, aggregation="mean"),
    smoothing_window=3,
    detection=DetectionConfig(spike_threshold=2.5, spike_window=10, spike_warmup=4),
)
print(render_series_summary_text(result.summary))
print(render_anomaly_report_text(result.anomaly_report))
```

## CLI

```bash
timewindow summary    examples/sample_metrics.csv
timewindow histogram  examples/sample_metrics.csv --bins 12
timewindow rebucket   examples/sample_metrics.csv --bucket 60 --aggregation mean
timewindow detect     examples/sample_metrics.csv --format json --pretty
timewindow rollup     examples/sample_metrics.csv --widths 60 300 --pretty
timewindow lint       examples/sample_metrics.csv --strict
timewindow analyze    examples/sample_metrics.csv --bucket 5 --smoothing 3 --pretty
timewindow store-ingest  --root ./db --name cpu examples/sample_metrics.csv
timewindow query     --root ./db 'series("cpu") | rebucket(60, mean) | top(3)' --pretty
timewindow serve     --root ./db --host 127.0.0.1 --port 8910
```

See [`docs/quickstart.md`](docs/quickstart.md) and [`docs/cli.md`](docs/cli.md)
for full walkthroughs, and [`examples/`](examples/) for runnable scripts and
sample datasets.

## Modules

| Module | Purpose |
| --- | --- |
| `timewindow.bucket` | `floor_to_bucket` / `ceil_to_bucket` aligned to UTC epoch seconds |
| `timewindow.duration` | Parse/print compact duration strings (`1h30m`, `250ms`, …) |
| `timewindow.intervals` | Half-open `TimeInterval` helpers and bucket slicing iterators |
| `timewindow.cursors` | Tumbling and hopping window iterators for streaming rollups |
| `timewindow.policy` | Retention cutoffs derived from duration strings |
| `timewindow.merge` | Merge overlapping/adjacent intervals |
| `timewindow.serde` | Strict ISO-8601 instants with `Z` normalization |
| `timewindow.stats` | Tiny helpers (`RunningMean`, `RingBufferFloat`) for windowed aggregates |
| `timewindow.resample` | Last-value / sum rollups, downsampling, per-bucket value histograms |
| `timewindow.labels` | Prometheus-style label sets, canonical rendering, parsing |
| `timewindow.histograms` | Fixed-bucket latency histograms with merges and defaults |
| `timewindow.sampling` | Deterministic sampling + token buckets for hot paths |
| `timewindow.pipeline` | Buffered batches, watermarks, and small bounded deques |
| `timewindow.textlog` | Timestamp extraction from common log line shapes |
| `timewindow.ratelimit` | Sliding/fixed window counters using monotonic clocks |
| `timewindow.cardinality` | LRU-tracked label-set cardinality guard |
| `timewindow.tsdb` | In-memory multi-series table, cursors, and bucket aggregates |
| `timewindow.ndjsonio` | NDJSON read/write, compaction, redaction, and record utilities |
| `timewindow.matchers` | Tiny label-set matcher language (`k="v"`, `k=~"regex"`, `AND` / `OR` / `NOT`) |
| `timewindow.tiered_rollups` | Monotonic UTC bucket reducer, multi-resolution rollup engine, offline iterators |
| `timewindow.sliding_windows` | Time-span and count windows for streaming min/max, sum, and mean |
| `timewindow.series_math` | Series transformations: moving averages, rebucketing, rates, scaling, trend/seasonality residuals |
| `timewindow.anomaly` | Spike/level-shift/gap/stale/change-point detection and anomaly event post-processing |
| `timewindow.csvio` | CSV reader/writer for `timestamp,value` series with atomic writes and day-sharding |
| `timewindow.report` | Text/JSON summaries and value histograms for series and anomaly events |
| `timewindow.recipes` | End-to-end pipelines (`rebucket_series`, `run_tiered_rollup`, `detect_all`, `analyze_csv_file`) |
| `timewindow.codec` | Compact binary frames with varint timestamps and delta-of-delta compression |
| `timewindow.storage` | Append-only `SeriesStore` (one file per series, JSON manifest, atomic compaction, verification) |
| `timewindow.query` | Pipeline DSL (lexer/parser/evaluator): `series("cpu") \| rebucket(60, mean) \| top(5)` |
| `timewindow.scheduler` | Tickless in-process scheduler with interval and cron triggers |
| `timewindow.http_api` | Stdlib HTTP API for ingest, query, detect, and series management |
| `timewindow.cli` | `timewindow` CLI with `summary`, `rebucket`, `detect`, `rollup`, `analyze`, `query`, `serve`, `store-*` |
