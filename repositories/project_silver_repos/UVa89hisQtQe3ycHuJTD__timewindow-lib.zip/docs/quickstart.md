# Quickstart

`timewindow` is a UTC bucketing toolkit for metric series. Once you `pip install
-e .` it gives you both a Python API and a `timewindow` CLI.

## 1. Read a CSV series

```python
from timewindow.csvio import read_series_path

points = read_series_path("examples/sample_metrics.csv")
print(len(points), "points")
print(points[0])
```

Each row in the CSV must look like `timestamp,value`, where `timestamp` is an
ISO-8601 instant (`Z` accepted). `read_series_path` returns a list of
`SeriesPoint(ts, value)` objects sorted by timestamp.

## 2. Summarize and detect anomalies

```python
from timewindow.recipes import (
    DetectionConfig,
    RebucketRequest,
    analyze_series,
)
from timewindow.report import render_anomaly_report_text, render_series_summary_text

result = analyze_series(
    points,
    rebucket=RebucketRequest(bucket_seconds=5, aggregation="mean"),
    smoothing_window=3,
    detection=DetectionConfig(
        spike_window=10,
        spike_threshold=2.5,
        spike_warmup=4,
        level_min_shift=4.0,
    ),
)
print(render_series_summary_text(result.summary))
print(render_anomaly_report_text(result.anomaly_report))
```

`analyze_series` returns the rebucketed series, the smoothed series, the raw
anomaly events, and a `summarize_anomalies` report.

## 3. Tiered rollups (1m / 5m / 1h)

```python
from timewindow.recipes import RollupRequest, run_tiered_rollup
from timewindow.tiered_rollups import RollupPropagation

result = run_tiered_rollup(
    points,
    RollupRequest(bucket_widths_seconds=(60, 300, 3600), propagation=RollupPropagation.GAUGE),
)
for level, items in sorted(result.layers.items()):
    print(f"layer {level}: {len(items)} buckets")
```

Each level produces `BucketStats` snapshots that you can persist or stream
to a downstream sink.

## 4. Streaming windows

```python
from datetime import timedelta
from timewindow.sliding_windows import TimeWindowSum, TimeWindowMinMax

span = timedelta(seconds=10)
sums = TimeWindowSum(span)
extremes = TimeWindowMinMax(span)
for p in points:
    sums.push(p.ts, p.value)
    extremes.push(p.ts, p.value)
print("running sum", sums.total())
print("running min/max", extremes.min_max())
```

These accept timestamped samples one at a time and evict old ones in O(1)
amortized cost, so they are safe to use inside a hot loop.

## 5. Use the CLI

```bash
timewindow summary examples/sample_metrics.csv
timewindow histogram examples/sample_metrics.csv --bins 12
timewindow rebucket examples/sample_metrics.csv --bucket 60 --aggregation mean
timewindow detect examples/sample_metrics.csv --format json --pretty
timewindow rollup examples/sample_metrics.csv --widths 60 300 --pretty
timewindow analyze examples/sample_metrics.csv --bucket 5 --smoothing 3 --pretty
```

See [`docs/cli.md`](cli.md) for the full subcommand reference.
