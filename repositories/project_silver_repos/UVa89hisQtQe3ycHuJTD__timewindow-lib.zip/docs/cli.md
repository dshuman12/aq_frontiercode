# `timewindow` CLI reference

After installing the package (`pip install -e .`) the `timewindow` script is
available on `PATH`. The commands below are the most useful in practice.

## Bucket utilities

```bash
timewindow floor 2026-05-01T17:42:09Z 3600
timewindow ceil  2026-05-01T17:42:09Z 3600
timewindow buckets --start 2026-05-01T00:00:00Z --end 2026-05-01T01:00:00Z --width 600
timewindow tumbling 2026-05-01T17:42:09Z --bucket 60
timewindow hops --start 2026-05-01T00:00:00Z --end 2026-05-01T00:10:00Z --window 60 --hop 30
```

## Duration helpers

```bash
timewindow parse-duration 1h30m
timewindow format-duration 5400
```

## CSV-based commands

All commands below take a CSV file with a `timestamp,value` header and ISO-8601
timestamps.

### `summary`

```bash
timewindow summary examples/sample_metrics.csv
timewindow summary examples/sample_metrics.csv --format json --pretty
```

Outputs count, range, min/max, mean and median.

### `histogram`

```bash
timewindow histogram examples/sample_metrics.csv --bins 10 --width 30
```

Renders an ASCII bar chart over the value distribution.

### `rebucket`

```bash
timewindow rebucket examples/sample_metrics.csv --bucket 60 --aggregation mean
timewindow rebucket examples/sample_metrics.csv --bucket 60 --aggregation sum --output rolled.csv
```

Re-aggregates the series to a coarser bucket size. `--fill ffill|zero|const|none`
controls how empty buckets between observations are filled.

### `detect`

```bash
timewindow detect examples/sample_metrics.csv \
  --spike-threshold 3.0 --spike-window 12 --spike-warmup 4 \
  --level-window 5 --level-min-shift 4.0 \
  --expected-step 1.0 --merge-gap 5 --top-k 5
```

Runs spike, level shift, stale, gap, change-point, and residual detectors. Use
`--format json --pretty` for machine-readable output, or `--fail-on-findings`
to make the command exit with code `2` when anything is reported (handy for CI).

### `rollup`

```bash
timewindow rollup examples/sample_metrics.csv --widths 60 300 3600 --pretty
```

Runs tiered rollups across the given bucket widths and emits JSON.

### `lint`

```bash
timewindow lint examples/sample_metrics.csv
timewindow lint examples/sample_metrics.csv --strict
```

Reports common shape problems (non-monotonic timestamps, large gaps, duplicate
timestamps). `--strict` makes the command exit with code `2` on any warning.

### `analyze`

```bash
timewindow analyze examples/sample_metrics.csv \
  --bucket 5 --aggregation mean --smoothing 3 --detrend --pretty
```

Combines `rebucket`, optional smoothing/detrending, and anomaly detection into
one JSON report.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0`  | success |
| `1`  | error (invalid input, IO failure, etc.) |
| `2`  | check failed (`--strict`, `--fail-on-findings`) |
