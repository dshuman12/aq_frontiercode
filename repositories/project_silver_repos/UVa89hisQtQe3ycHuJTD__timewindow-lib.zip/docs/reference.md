# timewindow API reference

This document captures the intent behind each public surface. It is meant for humans
maintaining dashboards or telemetry pipelines, not as a substitute for the docstrings.

## Bucketing primitives

`floor_to_bucket(dt, bucket_seconds)` returns the inclusive UTC start of the half-open
bucket `[k * B, (k + 1) * B)` that contains `dt`, where `B` is the bucket width in
seconds and `k` is derived from Unix epoch seconds.

`ceil_to_bucket(dt, bucket_seconds)` returns the smallest bucket boundary `T` such
that `T >= dt` when both are expressed in UTC. When `dt` sits exactly on a boundary,
`T` equals that boundary (this matches the usual mathematical ceiling on a discrete
lattice of boundaries).

Both functions require timezone-aware datetimes because silent local-time assumptions
are the dominant source of off-by-one-hour bugs in rollup jobs.

## Durations

`parse_duration_to_nanoseconds` accepts concatenations such as `1h30m`, `250ms`, and
`2d12h`. Components are summed after normalization to nanoseconds to keep sub-second
math stable for tests.

`format_duration_seconds` prefers the largest unit that divides the duration evenly
(for example `3600` seconds becomes `1h`). If no unit divides evenly, the function
falls back to a fractional representation using the largest unit that still fits.

`duration_seconds_to_bucket_width` is a narrow helper for configuration files where
bucket widths must be integral seconds.

## Intervals and merging

`TimeInterval` models `[start, end)` with strict `end > start`. Intersections return
`None` when intervals are disjoint.

`merge_intervals` sorts intervals, merges overlaps, and also merges cases where one
interval ends exactly where another begins. This matches common log-compaction rules.

## Window cursors

`TumblingCursor` answers “which fixed bucket contains this instant?” without retaining
mutable state; it is effectively a pure view on top of the bucketing primitives.

`HoppingCursor` emits overlapping or gapped windows depending on how `window_seconds`
and `hop_seconds` relate. The generator yields only the intersection of each abstract
window with the caller-provided `[start, end)` range so callers can stream without
allocating full schedules up front.

## Policy helpers

`retention_timedelta` and `cutoff_utc` are small conveniences for computing “delete
anything older than …” thresholds. They intentionally keep policy strings in the same
syntax as durations to reduce the number of mini-languages operators must remember.

## Serialization

`parse_instant_iso8601` requires an explicit offset or `Z`. Naive timestamps are
rejected because they cannot be interpreted safely in a multi-region deployment.

`format_instant_iso8601` always renders UTC with a `Z` suffix, which keeps log lines
grep-friendly and stable across platforms.

## Statistics helpers

`RunningMean` implements Welford’s algorithm for numerically stable online means and
variances. `RingBufferFloat` is a tiny fixed-capacity buffer for bounded-memory
rolling features.

These helpers are optional; many callers will only need bucketing. They exist because
the same services that bucket timestamps often need a bounded-memory companion for
simple quality metrics.

## Command line

The `timewindow` console script is intentionally minimal. It exists so operators can
validate configuration values in production-like containers without opening a Python
REPL. Failures print a short error string on stderr and exit non-zero.

## Resampling helpers

`resample_last_value` and `resample_sum` walk aligned bucket windows and aggregate
samples that fall inside each window. These helpers are intentionally pure: they do
not maintain streaming state, which keeps them easy to unit test inside larger ETL
jobs.

`downsample_max` is a presentation-oriented helper for turning long vectors of points
into a smaller list while preserving peaks, which is often enough for sparkline-style
dashboards.

## Labels and cardinality

`LabelSet` is a small, strict parser/renderer for equality-style labels. It exists so
downstream components can share a single canonical representation when deduplicating
active series.

`CardinalityTracker` is an LRU map keyed by that canonical string. It is not a
database—just a guardrail for in-memory aggregation pipelines that need to fail fast
when fan-out explodes.

## Histograms and sampling

`Histogram` stores raw counts per upper bound plus an overflow bucket. Merging is
additive on matching bucket definitions, which matches how sidecars aggregate local
views before export.

`ConsistentSampler` uses a stable 64-bit digest so the same key always makes the same
keep/drop decision, while `TokenBucket` covers “do not exceed N per second” admission.

## Log parsing and rate windows

`extract_timestamp` is intentionally conservative: it recognizes a handful of common
timestamp shapes embedded inside arbitrary log text. Unknown lines return ``None``
instead of guessing.

`SlidingWindowCounter` and `FixedWindowCounter` are monotonic-clock utilities for cheap
local overload detection. They are not distributed counters.

## Versioning note

Breaking changes should bump the minor version until the project reaches 1.0. Patch
releases are for bug fixes and documentation clarifications that do not alter runtime
behavior.
