import json
from datetime import datetime, timezone

from timewindow.anomaly import AnomalyEvent
from timewindow.report import (
    histogram_of_values,
    render_anomaly_report_json,
    render_anomaly_report_text,
    render_histogram_text,
    render_series_summary_json,
    render_series_summary_text,
    summarize_anomalies,
    summarize_series,
)
from timewindow.series_math import SeriesPoint


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, i, tzinfo=timezone.utc)


def test_summary_empty_series() -> None:
    summary = summarize_series([])
    assert summary.count == 0
    assert summary.first_ts is None
    assert "empty" in render_series_summary_text(summary)


def test_summary_with_points() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(5)]
    summary = summarize_series(points)
    assert summary.count == 5
    assert summary.minimum == 0.0
    assert summary.maximum == 4.0
    text = render_series_summary_text(summary)
    assert "count" in text
    payload = json.loads(render_series_summary_json(summary))
    assert payload["count"] == 5


def test_anomaly_report_text_and_json() -> None:
    events = [
        AnomalyEvent(utc(0), 1.0, 4.0, "spike", "first"),
        AnomalyEvent(utc(1), 1.0, 1.0, "spike", "second"),
        AnomalyEvent(utc(2), 1.0, 2.5, "gap", "third"),
    ]
    report = summarize_anomalies(events, top_k=2)
    assert report.total == 3
    assert report.by_kind["spike"] == 2
    text = render_anomaly_report_text(report)
    assert "spike" in text
    payload = json.loads(render_anomaly_report_json(report))
    assert payload["total"] == 3
    assert payload["by_kind"]["spike"] == 2


def test_anomaly_report_handles_inf_score() -> None:
    events = [AnomalyEvent(utc(0), 1.0, float("inf"), "spike", "x")]
    report = summarize_anomalies(events)
    text = render_anomaly_report_text(report)
    assert "inf" in text
    payload = json.loads(render_anomaly_report_json(report))
    assert payload["top"][0]["score"] == "inf"


def test_histogram_constant_series() -> None:
    points = [SeriesPoint(utc(i), 4.0) for i in range(3)]
    bins = histogram_of_values(points, bins=4)
    assert bins == [(4.0, 4.0, 3)]
    assert "4.0000" in render_histogram_text(bins)


def test_histogram_distribution() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(10)]
    bins = histogram_of_values(points, bins=5)
    assert sum(c for _, _, c in bins) == 10


def test_render_histogram_empty() -> None:
    assert render_histogram_text([]) == "histogram: empty"
