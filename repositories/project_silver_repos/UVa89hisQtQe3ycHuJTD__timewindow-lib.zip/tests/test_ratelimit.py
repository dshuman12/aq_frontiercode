from timewindow.ratelimit import FixedWindowCounter, SlidingWindowCounter


def test_sliding_window_counter_prunes():
    counter = SlidingWindowCounter(window_seconds=1.0)
    assert counter.hit(now=0.0) == 1
    assert counter.hit(now=0.5) == 2
    assert counter.count(now=2.0) == 0


def test_fixed_window_counter_resets_bucket():
    counter = FixedWindowCounter(window_seconds=10.0)
    assert counter.hit(now=0.0) == 1
    assert counter.hit(now=5.0) == 2
    assert counter.hit(now=25.0) == 1
