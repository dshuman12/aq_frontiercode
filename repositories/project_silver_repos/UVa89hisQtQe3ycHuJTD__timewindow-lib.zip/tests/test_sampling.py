import pytest

from timewindow.sampling import ConsistentSampler, TokenBucket


def test_consistent_sampler_deterministic():
    sampler = ConsistentSampler.from_rate(0.5)
    results = {sampler.keep("alpha"), sampler.keep("alpha")}
    assert len(results) == 1


def test_consistent_sampler_rate_zero():
    sampler = ConsistentSampler.from_rate(0.0)
    assert not sampler.keep("anything")


def test_token_bucket_allows_burst():
    bucket = TokenBucket(rate_per_sec=1.0, burst=3.0)
    t0 = 0.0
    assert bucket.allow(now=t0, cost=1.0)
    assert bucket.allow(now=t0, cost=1.0)
    assert bucket.allow(now=t0, cost=1.0)
    assert not bucket.allow(now=t0, cost=1.0)


def test_token_bucket_refills():
    bucket = TokenBucket(rate_per_sec=1.0, burst=1.0)
    assert bucket.allow(now=0.0, cost=1.0)
    assert bucket.allow(now=2.0, cost=1.0)
