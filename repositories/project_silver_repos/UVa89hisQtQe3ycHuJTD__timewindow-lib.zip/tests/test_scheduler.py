from datetime import datetime, timedelta, timezone

import pytest

from timewindow.exceptions import ParseError, TimeWindowError
from timewindow.scheduler import (
    CronTrigger,
    IntervalTrigger,
    Scheduler,
    describe_job,
    parse_cron_expression,
)


def at(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> datetime:
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


def test_interval_trigger_unaligned() -> None:
    trig = IntervalTrigger(every_seconds=10)
    nxt = trig.next_after(at(2026, 1, 1, 0, 0, 0))
    assert nxt == at(2026, 1, 1, 0, 0, 10)


def test_interval_trigger_aligned() -> None:
    trig = IntervalTrigger(every_seconds=60, aligned=True)
    nxt = trig.next_after(at(2026, 1, 1, 0, 0, 30))
    assert nxt == at(2026, 1, 1, 0, 1, 0)


def test_interval_trigger_invalid() -> None:
    with pytest.raises(ValueError):
        IntervalTrigger(every_seconds=0).next_after(at(2026, 1, 1))


def test_cron_trigger_minute_field() -> None:
    trig = CronTrigger(minute="*/5")
    nxt = trig.next_after(at(2026, 1, 1, 0, 1))
    assert nxt == at(2026, 1, 1, 0, 5)


def test_cron_trigger_specific_hour() -> None:
    trig = CronTrigger(minute="0", hour="3")
    nxt = trig.next_after(at(2026, 1, 1, 0, 0))
    assert nxt == at(2026, 1, 1, 3, 0)


def test_cron_trigger_range_field() -> None:
    trig = CronTrigger(minute="10-12")
    nxt = trig.next_after(at(2026, 1, 1, 0, 9))
    assert nxt == at(2026, 1, 1, 0, 10)


def test_parse_cron_expression() -> None:
    trig = parse_cron_expression("0 * * * *")
    assert trig.minute == "0"
    with pytest.raises(ParseError):
        parse_cron_expression("0 * * *")


def test_scheduler_runs_due_jobs() -> None:
    clock_box = {"now": at(2026, 1, 1, 0, 0, 0)}

    def clock() -> datetime:
        return clock_box["now"]

    sched = Scheduler(clock=clock)
    fires: list[datetime] = []
    sched.schedule("tick", lambda when: fires.append(when), IntervalTrigger(every_seconds=1))
    clock_box["now"] = at(2026, 1, 1, 0, 0, 5)
    outcomes = sched.run_pending()
    assert outcomes
    assert outcomes[0].status == "ok"
    assert sched.jobs()[0].successes == 1


def test_scheduler_records_failures() -> None:
    clock_box = {"now": at(2026, 1, 1, 0, 0, 0)}
    sched = Scheduler(clock=lambda: clock_box["now"])

    def boom(when: datetime) -> None:
        raise RuntimeError("boom")

    sched.schedule("bad", boom, IntervalTrigger(every_seconds=1))
    clock_box["now"] = at(2026, 1, 1, 0, 0, 5)
    outcomes = sched.run_pending()
    assert outcomes
    assert outcomes[0].status == "error"
    assert "RuntimeError" in (outcomes[0].error or "")


def test_scheduler_disable_enable() -> None:
    clock_box = {"now": at(2026, 1, 1, 0, 0, 0)}
    sched = Scheduler(clock=lambda: clock_box["now"])
    sched.schedule("tick", lambda when: None, IntervalTrigger(every_seconds=1))
    sched.disable("tick")
    clock_box["now"] = at(2026, 1, 1, 0, 0, 5)
    assert sched.run_pending() == []
    sched.enable("tick")
    assert sched.run_pending()


def test_scheduler_unschedule_and_duplicate() -> None:
    sched = Scheduler(clock=lambda: at(2026, 1, 1))
    sched.schedule("a", lambda when: None, IntervalTrigger(every_seconds=1))
    with pytest.raises(TimeWindowError):
        sched.schedule("a", lambda when: None, IntervalTrigger(every_seconds=1))
    assert sched.unschedule("a") is True
    assert sched.unschedule("a") is False


def test_describe_job_returns_string() -> None:
    sched = Scheduler(clock=lambda: at(2026, 1, 1))
    job = sched.schedule("tick", lambda when: None, IntervalTrigger(every_seconds=1))
    assert "tick" in describe_job(job)
