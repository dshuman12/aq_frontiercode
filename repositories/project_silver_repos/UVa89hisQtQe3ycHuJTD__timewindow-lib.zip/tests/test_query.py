from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from timewindow.exceptions import ParseError
from timewindow.query import (
    OpAggregate,
    OpRebucket,
    OpWhere,
    Pipeline,
    QueryContext,
    SourceSeries,
    evaluate,
    execute,
    explain,
    lex,
    parse_query,
    query_to_string,
    supported_operators,
)
from timewindow.series_math import SeriesPoint
from timewindow.storage import SeriesStore


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


@pytest.fixture()
def populated_store(tmp_path: Path) -> SeriesStore:
    store = SeriesStore(tmp_path / "db", durable=False)
    points = [SeriesPoint(utc(i), float(i)) for i in range(60)]
    points[25] = SeriesPoint(utc(25), 999.0)
    store.append("cpu", points)
    return store


def test_lex_basic_tokens() -> None:
    tokens = lex('series("cpu") | where(value > 10)')
    kinds = [t.kind for t in tokens if t.kind != "EOF"]
    assert "series" in kinds
    assert "where" in kinds
    assert "OP" in kinds


def test_parse_simple_pipeline() -> None:
    pipeline = parse_query('series("cpu") | rebucket(60, sum) | mean()')
    assert isinstance(pipeline.source, SourceSeries)
    assert isinstance(pipeline.ops[0], OpRebucket)
    assert isinstance(pipeline.ops[1], OpAggregate)


def test_parse_invalid_query() -> None:
    with pytest.raises(ParseError):
        parse_query('series("cpu") | foo()')
    with pytest.raises(ParseError):
        parse_query('series("cpu" |')


def test_evaluate_returns_points(populated_store: SeriesStore) -> None:
    pipeline = parse_query('series("cpu") | where(value > 100)')
    result = evaluate(pipeline, QueryContext(store=populated_store))
    assert result.kind == "series"
    assert any(p.value > 100 for p in result.points)


def test_evaluate_returns_scalar_count(populated_store: SeriesStore) -> None:
    result = execute('series("cpu") | count()', QueryContext(store=populated_store))
    assert result.kind == "scalar"
    assert result.scalar == 60


def test_evaluate_top_and_bottom(populated_store: SeriesStore) -> None:
    top = execute('series("cpu") | top(2)', QueryContext(store=populated_store)).points
    assert top[0].value >= top[1].value
    bot = execute('series("cpu") | bottom(2)', QueryContext(store=populated_store)).points
    assert bot[0].value <= bot[1].value


def test_evaluate_between_filters(populated_store: SeriesStore) -> None:
    result = execute(
        f'series("cpu") | between("{utc(10).isoformat()}", "{utc(20).isoformat()}")',
        QueryContext(store=populated_store),
    )
    assert all(utc(10) <= p.ts <= utc(20) for p in result.points)


def test_evaluate_range_predicate(populated_store: SeriesStore) -> None:
    result = execute('series("cpu") | where(value in 5..15)', QueryContext(store=populated_store))
    assert all(5 <= p.value <= 15 for p in result.points)


def test_evaluate_limit_and_offset(populated_store: SeriesStore) -> None:
    result = execute('series("cpu") | offset(50) | limit(3)', QueryContext(store=populated_store))
    assert len(result.points) == 3


def test_evaluate_rebucket_then_mean(populated_store: SeriesStore) -> None:
    result = execute(
        'series("cpu") | rebucket(10, mean) | mean()',
        QueryContext(store=populated_store),
    )
    assert result.kind == "scalar"
    assert result.scalar is not None


def test_explain_describes_pipeline() -> None:
    pipeline = parse_query('series("cpu") | rebucket(10) | mean()')
    desc = explain(pipeline)
    assert "source" in desc
    assert "OpRebucket" in desc


def test_query_to_string_round_trips_basic() -> None:
    pipeline = parse_query('series("cpu") | where(value > 5)')
    text = query_to_string(pipeline)
    assert "series" in text
    assert "where" in text
    assert ">" in text


def test_supported_operators_lists_keywords() -> None:
    ops = supported_operators()
    assert "rebucket" in ops
    assert "detect_spikes" in ops


def test_evaluate_detect_spikes(populated_store: SeriesStore) -> None:
    result = execute(
        'series("cpu") | detect_spikes(15, 2.0)',
        QueryContext(store=populated_store),
    )
    assert any(p.value == 999.0 for p in result.points)
