from datetime import datetime, timedelta, timezone

from timewindow.pipeline import BufferedBatch, MonotonicWatermark, RecentDeque


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_buffered_batch_flushes_on_size():
    clock_state = {"t": utc(2026, 1, 1, 0, 0)}

    def clock() -> datetime:
        return clock_state["t"]

    buf = BufferedBatch[int](max_items=2, max_wait=timedelta(minutes=5), clock=clock)
    assert buf.push(1) is None
    flushed = buf.push(2)
    assert flushed == [1, 2]


def test_buffered_batch_flushes_on_time():
    clock_state = {"t": utc(2026, 1, 1, 0, 0)}

    def clock() -> datetime:
        return clock_state["t"]

    buf = BufferedBatch[str](max_items=10, max_wait=timedelta(seconds=1), clock=clock)
    assert buf.push("a") is None
    clock_state["t"] = utc(2026, 1, 1, 0, 2)
    flushed = buf.push("b")
    assert flushed == ["a"]


def test_monotonic_watermark_advances():
    wm = MonotonicWatermark()
    first = wm.observe(utc(2026, 1, 1, 0))
    second = wm.observe(utc(2025, 12, 31, 0))
    assert first == second == utc(2026, 1, 1, 0)


def test_recent_deque_maxlen():
    buf = RecentDeque[int](maxlen=2)
    buf.append(1)
    buf.append(2)
    buf.append(3)
    assert buf.snapshot() == [2, 3]
