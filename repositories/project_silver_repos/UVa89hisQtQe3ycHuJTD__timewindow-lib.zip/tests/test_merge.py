from datetime import datetime, timezone

from timewindow.intervals import TimeInterval
from timewindow.merge import merge_intervals


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_merge_overlapping():
    a = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 3))
    b = TimeInterval(start=utc(2026, 1, 1, 2), end=utc(2026, 1, 1, 5))
    merged = merge_intervals([b, a])
    assert merged == [TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 5))]


def test_merge_adjacent():
    a = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 1))
    b = TimeInterval(start=utc(2026, 1, 1, 1), end=utc(2026, 1, 1, 2))
    merged = merge_intervals([b, a])
    assert merged == [TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 2))]


def test_merge_disjoint_keeps_two():
    a = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 1))
    b = TimeInterval(start=utc(2026, 1, 1, 5), end=utc(2026, 1, 1, 6))
    merged = merge_intervals([b, a])
    assert merged == [a, b]
