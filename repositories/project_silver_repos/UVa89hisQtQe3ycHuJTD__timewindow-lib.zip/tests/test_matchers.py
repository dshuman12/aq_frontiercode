import pytest

from timewindow.exceptions import ParseError
from timewindow.labels import LabelSet
from timewindow.matchers import (
    always_false,
    always_true,
    any_match,
    combine_and_all,
    filter_label_sets,
    matcher_keys_referenced,
    parse_matcher,
)


def labels(**kwargs: str) -> LabelSet:
    return LabelSet.from_mapping(kwargs)


def test_equals_matcher():
    m = parse_matcher('job="api"')
    ls = labels(job="api", shard="1")
    assert m.matches(ls)


def test_exists_matcher():
    m = parse_matcher("shard")
    assert m.matches(labels(shard="1"))
    assert not m.matches(labels(job="api"))


def test_regex_matcher():
    m = parse_matcher('job=~"^api.*"')
    assert m.matches(labels(job="api-east"))


def test_and_or_not():
    m = parse_matcher('job="api" AND shard="2"')
    assert m.matches(labels(job="api", shard="2"))
    m2 = parse_matcher('job="api" OR job="worker"')
    assert m2.matches(labels(job="worker"))
    m3 = parse_matcher('NOT job="api"')
    assert not m3.matches(labels(job="api"))
    assert m3.matches(labels(job="worker"))


def test_filter_label_sets():
    items = [labels(job="a"), labels(job="b")]
    m = parse_matcher('job="a"')
    assert filter_label_sets(m, items) == [items[0]]


def test_always_true_false():
    ls = labels(job="x")
    assert always_true().matches(ls) is True
    assert always_false().matches(ls) is False


def test_combine_and_all():
    m = combine_and_all([parse_matcher("job"), parse_matcher('shard="1"')])
    assert m.matches(labels(job="j", shard="1"))


def test_any_match():
    ms = [parse_matcher('job="a"'), parse_matcher('job="b"')]
    assert any_match(ms, labels(job="b"))


def test_matcher_keys():
    m = parse_matcher('job="api" AND shard="2"')
    assert matcher_keys_referenced(m) == {"job", "shard"}


def test_parse_errors():
    with pytest.raises(ParseError):
        parse_matcher("")
