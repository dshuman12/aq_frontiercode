from datetime import datetime, timezone

from timewindow.intervals import TimeInterval
from timewindow.resample import (
    Sample,
    align_samples_to_bucket_starts,
    downsample_max,
    piecewise_constant_series,
    resample_last_value,
    resample_sum,
    value_histogram_per_bucket,
)


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_resample_last_value_picks_latest():
    start = utc(2026, 1, 1, 0)
    end = utc(2026, 1, 1, 2)
    samples = [
        Sample(when=utc(2026, 1, 1, 0, 10), value=1.0),
        Sample(when=utc(2026, 1, 1, 0, 40), value=2.0),
    ]
    out = resample_last_value(samples, start, end, 3600)
    assert isinstance(out[0][0], TimeInterval)
    assert out[0][1] == 2.0


def test_resample_sum_counts_bucket():
    start = utc(2026, 2, 1, 0)
    end = utc(2026, 2, 1, 1)
    samples = [
        Sample(when=utc(2026, 2, 1, 0, 5), value=1.0),
        Sample(when=utc(2026, 2, 1, 0, 10), value=2.0),
    ]
    out = resample_sum(samples, start, end, 3600)
    assert out[0][1] == 3.0


def test_align_samples_snaps():
    samples = [Sample(when=utc(2026, 3, 1, 0, 7), value=5.0)]
    aligned = align_samples_to_bucket_starts(samples, 900)
    assert aligned[0].when.minute % 15 == 0


def test_piecewise_constant_series_sorted():
    samples = [
        Sample(when=utc(2026, 1, 2, 0), value=2.0),
        Sample(when=utc(2026, 1, 1, 0), value=1.0),
    ]
    times, values = piecewise_constant_series(samples)
    assert times[0] < times[1]
    assert values == [1.0, 2.0]


def test_downsample_max():
    values = list(range(10))
    assert len(downsample_max(values, 3)) <= 3


def test_value_histogram_per_bucket():
    start = utc(2026, 4, 1, 0)
    end = utc(2026, 4, 1, 1)
    samples = [Sample(when=utc(2026, 4, 1, 0, 5), value=0.05)]
    edges = (0.01, 0.1, 1.0)
    out = value_histogram_per_bucket(samples, start, end, 3600, edges)
    assert sum(out[0][1].values()) == 1
