import pytest

from timewindow.exceptions import ParseError
from timewindow.labels import LabelSet, render_selector


def test_labelset_round_trip():
    labels = LabelSet.from_mapping({"job": "api", "shard": "7"})
    text = labels.to_canonical_string()
    again = LabelSet.parse(text)
    assert again.pairs == labels.pairs


def test_labelset_parse_requires_quotes():
    with pytest.raises(ParseError):
        LabelSet.parse("{job=api}")


def test_labelset_rejects_bad_key():
    with pytest.raises(ParseError):
        LabelSet.from_mapping({"123bad": "x"})


def test_labelset_merge():
    base = LabelSet.from_mapping({"a": "1"})
    merged = base.merge({"b": "2"})
    assert dict(merged.pairs) == {"a": "1", "b": "2"}


def test_labelset_without():
    base = LabelSet.from_mapping({"a": "1", "b": "2"})
    trimmed = base.without("a")
    assert dict(trimmed.pairs) == {"b": "2"}


def test_render_selector():
    text = render_selector({"job": "worker", "id": "3"})
    assert "job=" in text and "worker" in text
