from datetime import datetime, timedelta, timezone

from timewindow.anomaly import (
    AnomalyEvent,
    ZScoreConfig,
    detect_change_points_mad,
    detect_gaps,
    detect_level_shift,
    detect_residual_anomalies,
    detect_spikes_zscore,
    detect_stale_series,
    merge_nearby_events,
    top_k_events,
)
from timewindow.series_math import SeriesPoint


def ts(i: int) -> datetime:
    return datetime(2026, 2, 1, 0, 0, i, tzinfo=timezone.utc)


def test_detect_spikes_zscore() -> None:
    points = [SeriesPoint(ts(i), 1.0) for i in range(25)] + [SeriesPoint(ts(26), 50.0)]
    out = detect_spikes_zscore(points, config=ZScoreConfig(window=20, threshold=3.0, warmup=10))
    assert out
    assert out[-1].kind == "spike"


def test_detect_level_shift() -> None:
    left = [SeriesPoint(ts(i), 1.0) for i in range(25)]
    right = [SeriesPoint(ts(30 + i), 10.0) for i in range(25)]
    out = detect_level_shift(left + right, left_window=10, right_window=10, min_shift=3.0)
    assert out
    assert out[0].kind == "level_shift"


def test_detect_stale_series() -> None:
    points = [SeriesPoint(ts(i), 4.0) for i in range(40)]
    out = detect_stale_series(points, window=10)
    assert out
    assert all(e.kind == "stale" for e in out[:3])


def test_detect_gaps() -> None:
    points = [SeriesPoint(ts(0), 1.0), SeriesPoint(ts(1), 1.0), SeriesPoint(ts(10), 1.0)]
    out = detect_gaps(points, expected_step=timedelta(seconds=1), tolerance=1.5)
    assert len(out) == 1
    assert out[0].kind == "gap"


def test_detect_change_points_mad() -> None:
    vals = [1.0] * 20 + [20.0] + [1.0] * 20
    points = [SeriesPoint(ts(i), v) for i, v in enumerate(vals)]
    out = detect_change_points_mad(points, window=9, threshold=4.0)
    assert out


def test_detect_residual_anomalies() -> None:
    vals = [1.0] * 40
    vals[25] = 20.0
    points = [SeriesPoint(ts(i), v) for i, v in enumerate(vals)]
    out = detect_residual_anomalies(points, trend_window=10, z_threshold=3.0)
    assert out
    assert any(e.kind == "residual" for e in out)


def test_merge_nearby_events() -> None:
    events = [
        AnomalyEvent(ts(0), 1.0, 2.0, "spike", "a"),
        AnomalyEvent(ts(1), 2.0, 5.0, "spike", "b"),
        AnomalyEvent(ts(10), 3.0, 1.0, "gap", "c"),
    ]
    merged = merge_nearby_events(events, timedelta(seconds=2))
    assert len(merged) == 2
    assert merged[0].score == 5.0


def test_top_k_events() -> None:
    events = [
        AnomalyEvent(ts(0), 0.0, 1.0, "x", "a"),
        AnomalyEvent(ts(1), 0.0, 4.0, "x", "b"),
        AnomalyEvent(ts(2), 0.0, 2.0, "x", "c"),
    ]
    top = top_k_events(events, 2)
    assert [e.score for e in top] == [4.0, 2.0]
