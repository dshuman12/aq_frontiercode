import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.request import Request, urlopen

import pytest

from timewindow.http_api import HttpServer, find_free_port, serialize_points
from timewindow.series_math import SeriesPoint
from timewindow.storage import SeriesStore


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


def http_json(method: str, url: str, body: dict | list | None = None) -> tuple[int, dict]:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = Request(url, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        resp = urlopen(req, timeout=5)
        text = resp.read().decode("utf-8")
        return resp.status, json.loads(text or "{}")
    except Exception as exc:  # urllib raises HTTPError on 4xx/5xx
        from urllib.error import HTTPError

        if isinstance(exc, HTTPError):
            text = exc.read().decode("utf-8")
            return exc.code, json.loads(text or "{}")
        raise


@pytest.fixture()
def server(tmp_path: Path):
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("cpu", [SeriesPoint(utc(i), float(i)) for i in range(20)])
    server = HttpServer(store, host="127.0.0.1", port=0).start()
    try:
        yield server
    finally:
        server.stop()


def test_health(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/health")
    assert code == 200
    assert body["status"] == "ok"


def test_list_series(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/series")
    assert code == 200
    assert "cpu" in body["series"]


def test_stats(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/series/cpu/stats")
    assert code == 200
    assert body["points"] == 20


def test_points(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/series/cpu/points")
    assert code == 200
    assert len(body["points"]) == 20
    assert body["points"][0]["value"] == 0.0


def test_points_with_limit_and_offset(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/series/cpu/points?limit=5&offset=10")
    assert code == 200
    assert len(body["points"]) == 5
    assert body["points"][0]["value"] == 10.0


def test_append_and_compact(server: HttpServer) -> None:
    payload = [{"timestamp": utc(50).isoformat(), "value": 50.0}]
    code, body = http_json("POST", server.url + "/series/cpu/append", payload)
    assert code == 200
    assert body["written"] == 1
    code, body = http_json("POST", server.url + "/series/cpu/compact", {})
    assert code == 200
    assert body["points"] == 21


def test_append_validation_error(server: HttpServer) -> None:
    code, body = http_json("POST", server.url + "/series/cpu/append", {"oops": True})
    assert code == 400
    assert "error" in body


def test_query_endpoint(server: HttpServer) -> None:
    code, body = http_json("POST", server.url + "/query", {"query": 'series("cpu") | count()'})
    assert code == 200
    assert body["scalar"] == 20


def test_query_missing_field(server: HttpServer) -> None:
    code, body = http_json("POST", server.url + "/query", {"oops": True})
    assert code == 400


def test_detect_endpoint(server: HttpServer) -> None:
    payload = {"series": "cpu", "kind": "spikes", "window": 5, "threshold": 1.0, "warmup": 3}
    code, body = http_json("POST", server.url + "/detect", payload)
    assert code == 200
    assert "events" in body


def test_drop_series(server: HttpServer) -> None:
    code, body = http_json("DELETE", server.url + "/series/cpu")
    assert code == 200
    assert body["dropped"] is True


def test_unknown_route(server: HttpServer) -> None:
    code, body = http_json("GET", server.url + "/no-such-route")
    assert code == 404


def test_serialize_points_helper() -> None:
    out = serialize_points([SeriesPoint(utc(0), 1.0)])
    assert out[0]["value"] == 1.0


def test_find_free_port_returns_port() -> None:
    port = find_free_port()
    assert 1024 <= port <= 65535
