from datetime import datetime, timezone

import pytest

from timewindow.cursors import HoppingCursor, TumblingCursor


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_tumbling_window_contains():
    cursor = TumblingCursor(bucket_seconds=900)
    window = cursor.window_containing(utc(2026, 2, 2, 3, 44))
    assert window.start == utc(2026, 2, 2, 3, 30)
    assert window.end == utc(2026, 2, 2, 3, 45)


def test_tumbling_next_boundary():
    cursor = TumblingCursor(bucket_seconds=3600)
    nxt = cursor.next_boundary_after(utc(2026, 1, 1, 0, 0, 1))
    assert nxt == utc(2026, 1, 1, 1, 0)


def test_hopping_emits_multiple_slices():
    hopper = HoppingCursor(window_seconds=120, hop_seconds=60)
    start = utc(2026, 1, 1, 0, 0)
    end = utc(2026, 1, 1, 0, 5, 0)
    windows = list(hopper.windows_covering(start, end))
    assert len(windows) >= 3
    assert windows[0].start == start


def test_hopping_rejects_non_positive():
    with pytest.raises(ValueError):
        HoppingCursor(window_seconds=0, hop_seconds=10)
