from timewindow.cardinality import CardinalityTracker
from timewindow.labels import LabelSet


def test_cardinality_tracker_evicts_lru():
    tracker = CardinalityTracker(max_series=2)
    a = LabelSet.from_mapping({"k": "a"})
    b = LabelSet.from_mapping({"k": "b"})
    c = LabelSet.from_mapping({"k": "c"})
    assert tracker.touch(a) is True
    assert tracker.touch(b) is True
    assert tracker.touch(a) is False
    assert tracker.touch(c) is True
    keys = {ls.to_canonical_string() for ls in tracker.snapshot()}
    assert b.to_canonical_string() not in keys
    assert a.to_canonical_string() in keys
