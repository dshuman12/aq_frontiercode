from datetime import datetime, timezone

import pytest

from timewindow.exceptions import ParseError
from timewindow.serde import format_instant_iso8601, parse_instant_iso8601


def test_parse_z_suffix():
    dt = parse_instant_iso8601("2026-04-01T12:34:56Z")
    assert dt.tzinfo is timezone.utc
    assert dt.hour == 12


def test_parse_explicit_offset():
    dt = parse_instant_iso8601("2026-04-01T10:00:00+02:00")
    assert dt == datetime(2026, 4, 1, 8, 0, 0, tzinfo=timezone.utc)


def test_parse_rejects_naive():
    with pytest.raises(ParseError):
        parse_instant_iso8601("2026-04-01T12:00:00")


def test_format_round_trip():
    original = parse_instant_iso8601("2026-05-10T01:02:03.456789Z")
    text = format_instant_iso8601(original)
    again = parse_instant_iso8601(text)
    assert again == original


def test_format_rejects_naive():
    with pytest.raises(ValueError):
        format_instant_iso8601(datetime(2026, 1, 1, 0, 0, 0))
