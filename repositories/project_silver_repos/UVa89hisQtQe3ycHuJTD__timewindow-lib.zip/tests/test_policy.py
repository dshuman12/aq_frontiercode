from datetime import datetime, timezone

import pytest

from timewindow.exceptions import ParseError
from timewindow.policy import clamp_to_future, cutoff_utc, retention_timedelta


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_retention_timedelta():
    delta = retention_timedelta("2h30m")
    assert delta.total_seconds() == 9000


def test_retention_rejects_non_positive():
    with pytest.raises(ParseError):
        retention_timedelta("0s")


def test_cutoff_utc():
    now = utc(2026, 3, 1, 12)
    cut = cutoff_utc(now, "1d")
    assert cut == utc(2026, 2, 28, 12)


def test_clamp_to_future():
    ref = utc(2026, 1, 1)
    earlier = utc(2025, 12, 31)
    assert clamp_to_future(ref, earlier) == ref
