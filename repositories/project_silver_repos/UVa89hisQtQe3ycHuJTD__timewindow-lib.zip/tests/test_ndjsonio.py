from pathlib import Path

import pytest

from timewindow.exceptions import ParseError
from timewindow.ndjsonio import (
    NdjsonWriter,
    dedupe_last_wins,
    load_any_json_collection,
    ndjson_from_text,
    ndjson_to_text,
    numeric_field,
    partition_batches,
    project_columns,
    redact_keys,
    rewrite_compact,
    sort_records,
    stable_dumps,
    validate_record_shape,
    write_ndjson_path,
)


def test_ndjson_round_trip_text():
    rows = [{"a": 1}, {"a": 2}]
    text = ndjson_to_text(rows)
    assert ndjson_from_text(text) == rows


def test_ndjson_writer_rejects_embedded_newlines(tmp_path: Path):
    buf = tmp_path / "x.ndjson"
    with buf.open("w", encoding="utf-8") as handle:
        writer = NdjsonWriter(handle, flush_every=10)
        with pytest.raises(ParseError):
            writer.write_obj({"a": "bad\nvalue"})
        writer.close()


def test_validate_record_shape():
    validate_record_shape({"k": 1}, {"k"})


def test_partition_batches():
    rows = [{"i": n} for n in range(5)]
    batches = partition_batches(rows, 2)
    assert len(batches) == 3


def test_redact_and_project():
    row = {"a": 1, "b": 2}
    assert redact_keys(row, {"a"})["a"] == "***"
    assert project_columns(row, ["b"]) == {"b": 2}


def test_numeric_field_errors():
    with pytest.raises(ParseError):
        numeric_field({"k": "x"}, "k")


def test_sort_and_dedupe():
    rows = [{"id": 1, "v": "a"}, {"id": 2, "v": "b"}, {"id": 1, "v": "c"}]
    assert sort_records(rows, "id")[0]["id"] == 1
    assert len(dedupe_last_wins(rows, "id")) == 2


def test_stable_dumps_sorted_keys():
    assert stable_dumps({"b": 1, "a": 2}).startswith('{"a":')


def test_load_any_json_collection_array():
    data = load_any_json_collection('[{"x":1}]')
    assert data[0]["x"] == 1


def test_rewrite_compact(tmp_path: Path):
    path = tmp_path / "rows.ndjson"
    write_ndjson_path(path, [{"z": 1}, {"z": 2}])
    count = rewrite_compact(path)
    assert count == 2
