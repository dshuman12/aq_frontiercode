from datetime import datetime, timedelta, timezone

import pytest

from timewindow.codec import (
    HEADER_SIZE,
    MAGIC,
    compression_ratio,
    count_frames,
    decode_float,
    decode_points,
    decode_signed_varint,
    decode_varint,
    encode_float,
    encode_many_frames,
    encode_points,
    encode_signed_varint,
    encode_varint,
    estimate_size,
    iter_decode_frames,
    merge_frames,
    read_header,
    round_trip,
    write_header,
    zigzag_decode,
    zigzag_encode,
)
from timewindow.exceptions import ParseError
from timewindow.series_math import SeriesPoint


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


def test_varint_round_trip() -> None:
    for value in [0, 1, 127, 128, 300, 1 << 20]:
        buf = encode_varint(value)
        decoded, end = decode_varint(buf)
        assert decoded == value
        assert end == len(buf)


def test_varint_rejects_negative() -> None:
    with pytest.raises(ValueError):
        encode_varint(-1)


def test_zigzag_round_trip() -> None:
    for value in [-300, -1, 0, 1, 300]:
        assert zigzag_decode(zigzag_encode(value)) == value


def test_signed_varint_round_trip() -> None:
    for value in [-1_000_000, -1, 0, 1, 1_000_000]:
        buf = encode_signed_varint(value)
        decoded, end = decode_signed_varint(buf)
        assert decoded == value
        assert end == len(buf)


def test_float_round_trip() -> None:
    buf = encode_float(3.14159)
    value, end = decode_float(buf)
    assert value == pytest.approx(3.14159)
    assert end == 8


def test_header_round_trip() -> None:
    buf = write_header(count=10, bucket_seconds=60)
    header, offset = read_header(buf)
    assert header.magic == MAGIC
    assert header.count == 10
    assert header.bucket_seconds == 60
    assert offset == HEADER_SIZE


def test_header_invalid_magic() -> None:
    with pytest.raises(ParseError):
        read_header(b"BADHEADERBYTES" + b"\x00" * 16)


def test_encode_decode_empty() -> None:
    buf = encode_points([])
    points, offset = decode_points(buf)
    assert points == []
    assert offset == HEADER_SIZE


def test_round_trip_single_point() -> None:
    points = [SeriesPoint(utc(0), 42.0)]
    decoded = round_trip(points)
    assert decoded == points


def test_round_trip_regular_series() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(20)]
    decoded = round_trip(points)
    assert decoded == points


def test_round_trip_irregular_series() -> None:
    base = utc(0)
    points = [
        SeriesPoint(base + timedelta(seconds=0), 1.0),
        SeriesPoint(base + timedelta(seconds=3), 4.0),
        SeriesPoint(base + timedelta(seconds=8), 9.0),
        SeriesPoint(base + timedelta(seconds=15), 16.0),
    ]
    decoded = round_trip(points)
    assert [p.ts for p in decoded] == [p.ts for p in points]
    assert [p.value for p in decoded] == [p.value for p in points]


def test_compression_ratio_under_one_for_regular_series() -> None:
    points = [SeriesPoint(utc(i), 1.0) for i in range(100)]
    ratio = compression_ratio(points)
    assert ratio < 1.0


def test_estimate_size_consistency() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(50)]
    assert estimate_size(points) == len(encode_points(points))


def test_iter_decode_multiple_frames() -> None:
    a = [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)]
    b = [SeriesPoint(utc(10), 3.0)]
    buf = merge_frames(encode_points(a), encode_points(b))
    frames = list(iter_decode_frames(buf))
    assert frames == [a, b]
    assert count_frames(buf) == 2


def test_encode_many_frames_helper() -> None:
    a = [SeriesPoint(utc(0), 1.0)]
    b = [SeriesPoint(utc(1), 2.0)]
    buf = encode_many_frames([a, b])
    assert count_frames(buf) == 2


def test_decode_truncated_buffer_raises() -> None:
    points = [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)]
    buf = encode_points(points)[:-1]
    with pytest.raises(ParseError):
        decode_points(buf)
