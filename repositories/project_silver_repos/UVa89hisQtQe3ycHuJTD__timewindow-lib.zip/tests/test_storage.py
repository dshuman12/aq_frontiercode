from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from timewindow.exceptions import TimeWindowError
from timewindow.series_math import SeriesPoint
from timewindow.storage import (
    SeriesStore,
    StoreManifest,
    append_csv_to_store,
    export_store_to_directory,
    open_store,
)


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


def test_open_creates_empty_store(tmp_path: Path) -> None:
    store = open_store(tmp_path / "db", durable=False)
    assert store.list_series() == []
    assert store.total_points() == 0


def test_append_and_read(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("cpu", [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)])
    store.append("cpu", [SeriesPoint(utc(2), 3.0)])
    points = store.read_all("cpu")
    assert [p.value for p in points] == [1.0, 2.0, 3.0]


def test_stats_reflect_appends(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("a", [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)])
    meta = store.stats("a")
    assert meta.points == 2
    assert meta.frames == 1
    assert meta.last_ts_micros is not None


def test_append_rejects_invalid_name(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    with pytest.raises(TimeWindowError):
        store.append("../etc/passwd", [SeriesPoint(utc(0), 1.0)])


def test_append_rejects_non_monotonic(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("a", [SeriesPoint(utc(10), 1.0)])
    with pytest.raises(TimeWindowError):
        store.append("a", [SeriesPoint(utc(5), 2.0)])


def test_drop_removes_series(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("z", [SeriesPoint(utc(0), 1.0)])
    assert store.drop("z") is True
    assert store.list_series() == []
    assert store.drop("z") is False


def test_compact_collapses_frames(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    for i in range(5):
        store.append("cpu", [SeriesPoint(utc(i), float(i))])
    assert store.stats("cpu").frames == 5
    total = store.compact("cpu")
    assert total == 5
    assert store.stats("cpu").frames == 1


def test_iter_frames_returns_separate_batches(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("cpu", [SeriesPoint(utc(0), 1.0)])
    store.append("cpu", [SeriesPoint(utc(1), 2.0)])
    frames = list(store.iter_frames("cpu"))
    assert len(frames) == 2
    assert frames[0][0].value == 1.0
    assert frames[1][0].value == 2.0


def test_head_and_tail(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    points = [SeriesPoint(utc(i), float(i)) for i in range(10)]
    store.append("cpu", points)
    assert [p.value for p in store.head("cpu", 3)] == [0.0, 1.0, 2.0]
    assert [p.value for p in store.tail("cpu", 2)] == [8.0, 9.0]


def test_verify_returns_no_problems_after_writes(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("a", [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)])
    assert store.verify() == []


def test_verify_detects_missing_file(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("a", [SeriesPoint(utc(0), 1.0)])
    (tmp_path / "db" / "a.tw").unlink()
    problems = store.verify()
    assert any("missing" in p for p in problems)


def test_manifest_round_trip() -> None:
    manifest = StoreManifest()
    payload = manifest.to_dict()
    assert StoreManifest.from_dict(payload).version == 1


def test_merge_into_other_store(tmp_path: Path) -> None:
    src = SeriesStore(tmp_path / "src", durable=False)
    dst = SeriesStore(tmp_path / "dst", durable=False)
    src.append("a", [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(1), 2.0)])
    src.append("b", [SeriesPoint(utc(0), 3.0)])
    copied = src.merge_into(dst)
    assert copied == 3
    assert sorted(dst.list_series()) == ["a", "b"]


def test_export_csv(tmp_path: Path) -> None:
    store = SeriesStore(tmp_path / "db", durable=False)
    store.append("a", [SeriesPoint(utc(i), float(i)) for i in range(3)])
    out = tmp_path / "exports"
    counts = export_store_to_directory(store, out)
    assert counts == {"a": 3}
    assert (out / "a.csv").exists()


def test_append_csv_helper(tmp_path: Path) -> None:
    csv = tmp_path / "in.csv"
    csv.write_text("timestamp,value\n2026-01-01T00:00:00Z,1.0\n2026-01-01T00:00:01Z,2.0\n", encoding="utf-8")
    store = SeriesStore(tmp_path / "db", durable=False)
    n = append_csv_to_store(store, "cpu", csv)
    assert n == 2
    assert store.stats("cpu").points == 2
