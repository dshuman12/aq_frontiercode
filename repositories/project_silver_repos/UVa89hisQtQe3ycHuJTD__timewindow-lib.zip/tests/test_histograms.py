import pytest

from timewindow.exceptions import ParseError
from timewindow.histograms import (
    Histogram,
    default_latency_buckets_seconds,
    histogram_from_observations,
    merge_histograms,
    validate_buckets,
)


def test_validate_buckets_requires_increasing():
    with pytest.raises(ParseError):
        validate_buckets([1.0, 1.0])


def test_histogram_observe_and_cumulative():
    h = Histogram([0.1, 1.0])
    h.observe(0.05)
    h.observe(0.2)
    h.observe(2.0)
    cum = dict(h.bucket_counts())
    assert cum[0.1] == 1
    assert cum[1.0] == 2
    assert cum[float("inf")] == 3


def test_histogram_merge():
    a = histogram_from_observations([1.0, 2.0], [0.5, 1.5])
    b = histogram_from_observations([1.0, 2.0], [0.2, 2.5])
    merged = merge_histograms([a, b])
    assert merged.total == a.total + b.total


def test_histogram_quantile_none_when_empty():
    h = Histogram([1.0])
    assert h.quantile(0.5) is None


def test_default_buckets_nonempty():
    assert len(default_latency_buckets_seconds()) > 5
