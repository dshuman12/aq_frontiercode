import io
import json
from contextlib import redirect_stdout
from pathlib import Path

from timewindow.cli import main
from timewindow.csvio import write_series_path
from timewindow.series_math import SeriesPoint
from datetime import datetime, timedelta, timezone


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


def write_sample(tmp_path: Path) -> Path:
    points = [SeriesPoint(utc(i), 10.0 + (50.0 if i == 25 else 0.0)) for i in range(60)]
    path = tmp_path / "series.csv"
    write_series_path(path, points)
    return path


def run_cli(*argv: str) -> tuple[int, str]:
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = main(list(argv))
    return rc, buf.getvalue()


def test_cli_summary_text(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("summary", str(path))
    assert rc == 0
    assert "count" in out


def test_cli_summary_json(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("summary", str(path), "--format", "json")
    assert rc == 0
    payload = json.loads(out)
    assert payload["count"] > 0


def test_cli_histogram(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("histogram", str(path), "--bins", "5")
    assert rc == 0
    assert "[" in out


def test_cli_rebucket_to_stdout(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("rebucket", str(path), "--bucket", "10", "--aggregation", "mean")
    assert rc == 0
    assert out.strip().count("\n") >= 1


def test_cli_rebucket_to_file(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    out_path = tmp_path / "rolled.csv"
    rc, out = run_cli(
        "rebucket",
        str(path),
        "--bucket",
        "10",
        "--aggregation",
        "mean",
        "--output",
        str(out_path),
    )
    assert rc == 0
    assert out_path.exists()
    assert out_path.read_text(encoding="utf-8").startswith("timestamp,value")


def test_cli_detect_text_and_fail_flag(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli(
        "detect",
        str(path),
        "--spike-window",
        "10",
        "--spike-threshold",
        "2.0",
        "--spike-warmup",
        "4",
    )
    assert rc == 0
    assert "total" in out
    rc2, _ = run_cli(
        "detect",
        str(path),
        "--spike-window",
        "10",
        "--spike-threshold",
        "2.0",
        "--spike-warmup",
        "4",
        "--fail-on-findings",
    )
    assert rc2 in (0, 2)


def test_cli_rollup_json(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("rollup", str(path), "--widths", "10", "30", "--pretty")
    assert rc == 0
    payload = json.loads(out)
    assert "0" in payload


def test_cli_lint_clean(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli("lint", str(path))
    assert rc == 0
    assert "ok" in out or "warning" in out


def test_cli_analyze_json(tmp_path: Path) -> None:
    path = write_sample(tmp_path)
    rc, out = run_cli(
        "analyze",
        str(path),
        "--bucket",
        "5",
        "--smoothing",
        "3",
        "--pretty",
    )
    assert rc == 0
    payload = json.loads(out)
    assert "summary" in payload
    assert "anomalies" in payload


def test_cli_floor_command() -> None:
    rc, out = run_cli("floor", "2026-05-01T17:42:09Z", "3600")
    assert rc == 0
    assert out.strip().endswith("Z")
