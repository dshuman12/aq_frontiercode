from datetime import datetime, timedelta, timezone

import pytest

from timewindow.sliding_windows import (
    CountWindowMinMax,
    TimeWindowMean,
    TimeWindowMinMax,
    TimeWindowSum,
    WindowMinMax,
    iter_window_min_max,
    merge_adjacent_windows,
)

UTC = timezone.utc


def t(h: int, m: int = 0, s: int = 0) -> datetime:
    return datetime(2026, 6, 1, h, m, s, tzinfo=UTC)


def test_time_window_min_max_basic() -> None:
    span = timedelta(minutes=10)
    w = TimeWindowMinMax(span)
    w.push(t(0, 0, 0), 5.0)
    w.push(t(0, 2, 0), 1.0)
    w.push(t(0, 4, 0), 8.0)
    mm = w.min_max()
    assert mm.minimum == 1.0
    assert mm.maximum == 8.0


def test_time_window_min_max_eviction() -> None:
    span = timedelta(minutes=10)
    w = TimeWindowMinMax(span)
    w.push(t(0, 0, 0), 1.0)
    w.push(t(0, 20, 0), 9.0)
    mm = w.min_max()
    assert mm.minimum == 9.0
    assert mm.maximum == 9.0


def test_time_window_sum() -> None:
    span = timedelta(minutes=5)
    s = TimeWindowSum(span)
    s.push(t(0, 0, 0), 2.0)
    s.push(t(0, 1, 0), 3.0)
    assert s.total() == 5.0
    s.push(t(0, 10, 0), 10.0)
    assert s.total() == 10.0


def test_time_window_mean() -> None:
    span = timedelta(minutes=30)
    m = TimeWindowMean(span)
    m.push(t(0, 0, 0), 10.0)
    m.push(t(0, 10, 0), 20.0)
    assert m.mean() == 15.0


def test_count_window_min_max() -> None:
    w = CountWindowMinMax(3)
    w.push(t(0, 0, 0), 3.0)
    w.push(t(0, 0, 1), 1.0)
    w.push(t(0, 0, 2), 2.0)
    assert w.min_max() == WindowMinMax(minimum=1.0, maximum=3.0)
    w.push(t(0, 0, 3), 0.0)
    mm = w.min_max()
    assert mm.minimum == 0.0
    assert mm.maximum == 2.0


def test_iter_window_min_max_offline() -> None:
    pts = [(t(0, 0, i), float(i)) for i in range(5)]
    rows = list(iter_window_min_max(pts, timedelta(minutes=1)))
    assert len(rows) == 5


def test_merge_adjacent_windows() -> None:
    a = WindowMinMax(1.0, 4.0)
    b = WindowMinMax(2.0, 9.0)
    m = merge_adjacent_windows(a, b)
    assert m == WindowMinMax(minimum=1.0, maximum=9.0)


def test_rejects_naive_timestamp() -> None:
    w = TimeWindowMinMax(timedelta(seconds=1))
    with pytest.raises(ValueError, match="timezone-aware"):
        w.push(datetime(2026, 1, 1, 0, 0, 0), 1.0)


def test_rejects_non_positive_span() -> None:
    with pytest.raises(ValueError, match="positive"):
        TimeWindowMinMax(timedelta(0))
