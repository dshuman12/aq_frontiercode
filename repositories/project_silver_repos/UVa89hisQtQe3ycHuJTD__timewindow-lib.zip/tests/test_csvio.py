from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from timewindow.csvio import (
    CsvSchema,
    DEFAULT_TS_COLUMN,
    DEFAULT_VALUE_COLUMN,
    count_rows_path,
    detect_schema,
    merge_series_files,
    read_series_path,
    read_series_text,
    split_series_by_day,
    write_series_path,
    write_series_text,
)
from timewindow.exceptions import ParseError
from timewindow.series_math import SeriesPoint


def utc(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> datetime:
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


def test_round_trip_text() -> None:
    points = [SeriesPoint(utc(2026, 1, 1, 0, 0, 0), 1.5), SeriesPoint(utc(2026, 1, 1, 0, 0, 1), 2.5)]
    text = write_series_text(points)
    parsed = read_series_text(text)
    assert parsed == points


def test_read_requires_header() -> None:
    with pytest.raises(ParseError):
        read_series_text("")


def test_read_rejects_missing_columns() -> None:
    text = "ts,foo\n2026-01-01T00:00:00Z,1\n"
    with pytest.raises(ParseError):
        read_series_text(text)


def test_read_rejects_bad_value() -> None:
    text = f"{DEFAULT_TS_COLUMN},{DEFAULT_VALUE_COLUMN}\n2026-01-01T00:00:00Z,oops\n"
    with pytest.raises(ParseError):
        read_series_text(text)


def test_read_rejects_non_finite() -> None:
    text = f"{DEFAULT_TS_COLUMN},{DEFAULT_VALUE_COLUMN}\n2026-01-01T00:00:00Z,inf\n"
    with pytest.raises(ParseError):
        read_series_text(text)


def test_read_rejects_unsorted() -> None:
    text = (
        f"{DEFAULT_TS_COLUMN},{DEFAULT_VALUE_COLUMN}\n"
        "2026-01-01T00:00:01Z,1\n"
        "2026-01-01T00:00:00Z,2\n"
    )
    with pytest.raises(ValueError):
        read_series_text(text)


def test_path_round_trip(tmp_path: Path) -> None:
    points = [SeriesPoint(utc(2026, 5, 1, 0, 0, i), float(i)) for i in range(4)]
    path = tmp_path / "series.csv"
    n = write_series_path(path, points)
    assert n == 4
    parsed = read_series_path(path)
    assert parsed == points
    assert count_rows_path(path) == 4


def test_detect_schema_default() -> None:
    text = "timestamp,value\n2026-01-01T00:00:00Z,1.0\n"
    schema = detect_schema(text)
    assert schema == CsvSchema()


def test_detect_schema_alternate() -> None:
    text = "ts,price\n2026-01-01T00:00:00Z,1.0\n"
    schema = detect_schema(text)
    assert schema.timestamp_column == "ts"
    assert schema.value_column == "price"


def test_split_series_by_day() -> None:
    points = [
        SeriesPoint(utc(2026, 1, 1, 23, 59), 1.0),
        SeriesPoint(utc(2026, 1, 2, 0, 1), 2.0),
        SeriesPoint(utc(2026, 1, 2, 12, 0), 3.0),
    ]
    grouped = split_series_by_day(points)
    assert set(grouped) == {"2026-01-01", "2026-01-02"}
    assert len(grouped["2026-01-02"]) == 2


def test_merge_series_files(tmp_path: Path) -> None:
    a = tmp_path / "a.csv"
    b = tmp_path / "b.csv"
    write_series_path(a, [SeriesPoint(utc(2026, 1, 1, 0, 0, 0), 1.0)])
    write_series_path(b, [SeriesPoint(utc(2026, 1, 1, 0, 0, 1), 2.0)])
    out = merge_series_files([b, a])
    assert [p.value for p in out] == [1.0, 2.0]


def test_write_rejects_naive_timestamp(tmp_path: Path) -> None:
    naive = SeriesPoint(datetime(2026, 1, 1, 0, 0, 0), 1.0)
    path = tmp_path / "x.csv"
    with pytest.raises(ParseError):
        write_series_path(path, [naive])
