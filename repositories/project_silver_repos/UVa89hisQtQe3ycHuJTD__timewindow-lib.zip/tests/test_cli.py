import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "timewindow", *args],
        cwd=ROOT,
        check=False,
        text=True,
        capture_output=True,
    )


def test_cli_floor():
    proc = run_cli("floor", "2026-01-01T00:15:00Z", "3600")
    assert proc.returncode == 0
    assert "2026-01-01T00:00:00" in proc.stdout


def test_cli_parse_duration():
    proc = run_cli("parse-duration", "1h30m")
    assert proc.returncode == 0
    assert proc.stdout.strip() == "5400.000000000"


def test_cli_unknown_command():
    proc = run_cli("nope")
    assert proc.returncode != 0
