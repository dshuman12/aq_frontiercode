from datetime import datetime, timezone

from timewindow.textlog import extract_timestamp, iter_ndjson_timestamps


def test_extract_iso_timestamp():
    line = '2026-01-10T12:34:56Z level=info msg="hello"'
    parsed = extract_timestamp(line)
    assert parsed.kind == "iso"
    assert parsed.timestamp == datetime(2026, 1, 10, 12, 34, 56, tzinfo=timezone.utc)


def test_extract_unix_seconds():
    line = "1672531200 event=start"
    parsed = extract_timestamp(line)
    assert parsed.kind == "unix_s"


def test_iter_ndjson_timestamps_skips_unknown():
    lines = [
        "no timestamp here",
        "1672531200 second line",
    ]
    stamps = iter_ndjson_timestamps(lines)
    assert len(stamps) == 1
