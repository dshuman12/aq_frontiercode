from datetime import datetime, timezone

import pytest

from timewindow.labels import LabelSet
from timewindow.resample import Sample
from timewindow.tsdb.memory import (
    MemorySeriesTable,
    SeriesPoint,
    assert_finite_path,
    build_table_from_mapping,
    memory_table_from_labels,
)


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def labels(**kwargs: str) -> LabelSet:
    return LabelSet.from_mapping(kwargs)


def test_append_and_query():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0, 5), value=1.0))
    table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0, 10), value=2.0))
    pts = table.query_range_list(ls, utc(2026, 1, 1, 0), utc(2026, 1, 1, 1))
    assert len(pts) == 2


def test_append_replaces_same_timestamp():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0), value=1.0))
    table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0), value=3.0))
    assert table.count(ls) == 1
    assert table.export_points(ls)[0].value == 3.0


def test_capacity_trims_head():
    table = MemorySeriesTable(capacity_per_series=2)
    ls = labels(job="api")
    for minute in range(5):
        table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0, minute), value=float(minute)))
    assert table.count(ls) == 2


def test_prune_older_than():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.append(ls, SeriesPoint(when=utc(2026, 1, 1, 0), value=1.0))
    table.append(ls, SeriesPoint(when=utc(2026, 1, 2, 0), value=2.0))
    removed = table.prune_older_than(utc(2026, 1, 1, 12))
    assert removed == 1
    assert table.count(ls) == 1


def test_aggregate_mean():
    table = MemorySeriesTable()
    ls = labels(job="api")
    for i in range(3):
        table.append(ls, SeriesPoint(when=utc(2026, 2, 1, 0, i * 10), value=float(i)))
    out = table.resample_mean(ls, utc(2026, 2, 1, 0), utc(2026, 2, 1, 1), 3600)
    assert out


def test_merge_into_moves_points():
    table = MemorySeriesTable()
    a = labels(job="a")
    b = labels(job="b")
    table.append(b, SeriesPoint(when=utc(2026, 3, 1, 0), value=5.0))
    moved = table.merge_into(a, b)
    assert moved == 1
    assert table.count(a) == 1
    assert not table.has_series(b)


def test_clone_roundtrip():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.append(ls, SeriesPoint(when=utc(2026, 4, 1, 0), value=9.0))
    other = table.clone()
    assert other.export_points(ls)[0].value == 9.0


def test_memory_table_from_labels():
    ls = labels(k="1")
    pts = [SeriesPoint(when=utc(2026, 5, 1, 0), value=2.0)]
    table = memory_table_from_labels(ls, pts)
    assert table.count(ls) == 1


def test_build_table_from_mapping():
    ls = labels(k="x")
    key = ls.to_canonical_string()
    table = build_table_from_mapping({key: [SeriesPoint(when=utc(2026, 6, 1, 0), value=1.0)]})
    assert table.count(ls) == 1


def test_assert_finite_path_ok():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.append(ls, SeriesPoint(when=utc(2026, 7, 1, 0), value=1.0))
    assert_finite_path(table, ls)


def test_from_samples():
    table = MemorySeriesTable()
    ls = labels(job="api")
    table.from_samples(ls, [Sample(when=utc(2026, 8, 1, 0), value=3.0)])
    assert table.to_samples(ls)[0].value == 3.0
