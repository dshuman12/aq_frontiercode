from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from timewindow.csvio import write_series_path
from timewindow.recipes import (
    DetectionConfig,
    PipelineResult,
    RebucketRequest,
    RollupRequest,
    analyze_csv_file,
    analyze_series,
    coverage_ratio,
    detect_all,
    expected_bucket_count,
    lint_series,
    rebucket_series,
    run_tiered_rollup,
    union_series,
    write_cleaned_csv,
)
from timewindow.series_math import SeriesPoint
from timewindow.tiered_rollups import RollupPropagation


def utc(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc) + timedelta(seconds=i)


def make_series(n: int) -> list[SeriesPoint]:
    points = [SeriesPoint(utc(i), 10.0) for i in range(n)]
    points[n // 2] = SeriesPoint(utc(n // 2), 80.0)
    return points


def test_rebucket_series_mean() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(10)]
    out = rebucket_series(points, RebucketRequest(bucket_seconds=5, aggregation="mean"))
    assert len(out) == 2
    assert out[0].value == pytest.approx(2.0)


def test_rebucket_invalid_aggregation() -> None:
    with pytest.raises(ValueError):
        rebucket_series([], RebucketRequest(bucket_seconds=5, aggregation="bogus"))


def test_rebucket_invalid_bucket() -> None:
    with pytest.raises(ValueError):
        rebucket_series([], RebucketRequest(bucket_seconds=0))


def test_run_tiered_rollup_layers() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(120)]
    request = RollupRequest(bucket_widths_seconds=(10, 30), propagation=RollupPropagation.GAUGE)
    result = run_tiered_rollup(points, request)
    assert 0 in result.layers
    assert any(b.count > 0 for b in result.layers[0])


def test_detect_all_finds_spike() -> None:
    series = make_series(60)
    cfg = DetectionConfig(
        spike_window=10,
        spike_threshold=2.0,
        spike_warmup=4,
        level_left_window=4,
        level_right_window=4,
        level_min_shift=10.0,
        stale_window=20,
        change_point_window=9,
        change_point_threshold=4.0,
        residual_window=5,
        residual_z_threshold=2.0,
    )
    events = detect_all(series, cfg)
    assert any(e.kind == "spike" for e in events)


def test_analyze_series_returns_pipeline_result() -> None:
    series = make_series(60)
    result = analyze_series(
        series,
        rebucket=RebucketRequest(bucket_seconds=5, aggregation="mean"),
        smoothing_window=3,
        detection=DetectionConfig(
            spike_window=6,
            spike_threshold=2.0,
            spike_warmup=3,
            level_min_shift=20.0,
        ),
    )
    assert isinstance(result, PipelineResult)
    assert result.summary.count > 0
    assert len(result.rolled) == len(result.cleaned)


def test_expected_bucket_count_and_coverage() -> None:
    points = [SeriesPoint(utc(i), float(i)) for i in range(0, 50, 10)]
    expected = expected_bucket_count(points[0].ts, points[-1].ts + timedelta(seconds=10), 10)
    assert expected == 5
    assert 0 < coverage_ratio(points, 10) <= 1.0


def test_lint_series_warnings_duplicates() -> None:
    points = [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(0), 2.0), SeriesPoint(utc(1), 3.0)]
    warnings = lint_series(points)
    assert any("duplicate" in w for w in warnings)


def test_lint_series_warnings_large_gap() -> None:
    points = [SeriesPoint(utc(i), 1.0) for i in range(0, 5)]
    points.append(SeriesPoint(utc(600), 1.0))
    warnings = lint_series(points)
    assert any("gap" in w for w in warnings)


def test_union_series_sorted() -> None:
    a = [SeriesPoint(utc(0), 1.0), SeriesPoint(utc(2), 2.0)]
    b = [SeriesPoint(utc(1), 3.0)]
    out = union_series(a, b)
    assert [p.ts for p in out] == [utc(0), utc(1), utc(2)]


def test_analyze_csv_file_round_trip(tmp_path: Path) -> None:
    points = make_series(40)
    src = tmp_path / "series.csv"
    write_series_path(src, points)
    result = analyze_csv_file(
        src,
        rebucket=RebucketRequest(bucket_seconds=5, aggregation="mean"),
    )
    out = tmp_path / "cleaned.csv"
    n = write_cleaned_csv(out, result)
    assert n == len(result.cleaned)
    assert out.exists()
