from datetime import datetime, timedelta, timezone

import pytest

from timewindow.tiered_rollups import (
    BucketStats,
    MonotonicBucketReducer,
    RollupPropagation,
    TieredRollupEngine,
    iter_bucket_stats_series,
)

UTC = timezone.utc


def dt(h: int, m: int = 0, s: int = 0) -> datetime:
    return datetime(2026, 5, 1, h, m, s, tzinfo=UTC)


def test_monotonic_reducer_single_bucket_flush() -> None:
    r = MonotonicBucketReducer(3600)
    assert r.observe(dt(0, 0, 0), 1.0) == []
    assert r.observe(dt(0, 0, 30), 2.0) == []
    tail = r.flush()
    assert tail is not None
    assert tail.count == 2
    assert tail.sum == 3.0
    assert tail.last == 2.0


def test_monotonic_reducer_emits_on_bucket_change() -> None:
    r = MonotonicBucketReducer(3600)
    assert r.observe(dt(0, 0, 0), 10.0) == []
    closed = r.observe(dt(1, 0, 0), 3.0)
    assert len(closed) == 1
    b0 = closed[0]
    assert b0.bucket_width_seconds == 3600
    assert b0.count == 1
    assert b0.last == 10.0
    tail = r.flush()
    assert tail is not None and tail.count == 1 and tail.last == 3.0


def test_monotonic_reducer_gap_inserts_empty_buckets() -> None:
    r = MonotonicBucketReducer(3600)
    assert r.observe(dt(0, 0, 0), 1.0) == []
    closed = r.observe(dt(2, 0, 0), 3.0)
    assert len(closed) >= 2
    assert closed[0].count == 1
    assert closed[0].last == 1.0
    assert closed[-1].count == 0


def test_monotonic_rejects_naive_datetime() -> None:
    r = MonotonicBucketReducer(60)
    with pytest.raises(ValueError, match="timezone-aware"):
        r.observe(datetime(2026, 1, 1, 0, 0, 0), 1.0)


def test_monotonic_rejects_non_monotonic() -> None:
    r = MonotonicBucketReducer(60)
    r.observe(dt(0, 5, 0), 1.0)
    with pytest.raises(ValueError, match="non-decreasing"):
        r.observe(dt(0, 1, 0), 2.0)


def test_iter_bucket_stats_series_offline() -> None:
    pts = [
        (dt(0, 0, 0), 1.0),
        (dt(0, 0, 30), 2.0),
        (dt(1, 0, 0), 5.0),
    ]
    stats = list(iter_bucket_stats_series(pts, 3600))
    assert len(stats) == 2
    assert stats[0].count == 2
    assert stats[1].count == 1


def test_tiered_propagates_to_parent() -> None:
    eng = TieredRollupEngine([60, 120], propagation=RollupPropagation.GAUGE)
    base = dt(0, 0, 0)
    eng.observe(base, 1.0)
    eng.observe(base + timedelta(seconds=60), 2.0)
    eng.observe(base + timedelta(seconds=120), 3.0)
    out = eng.observe(base + timedelta(seconds=240), 5.0)
    assert out[0]
    assert 1 in out and out[1]


def test_tiered_counter_uses_sum_synthetic() -> None:
    eng = TieredRollupEngine([60, 120], propagation=RollupPropagation.COUNTER)
    base = dt(0, 0, 0)
    eng.observe(base, 3.0)
    eng.observe(base + timedelta(seconds=30), 4.0)
    out = eng.observe(base + timedelta(seconds=70), 1.0)
    fine = out[0][0]
    assert fine.sum == 7.0
    if 1 in out and out[1]:
        assert out[1][0].count >= 1


def test_bucket_stats_synthetic() -> None:
    b = BucketStats(datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC), 60, 2, 10.0, 1.0, 9.0, 9.0)
    assert b.synthetic_value(RollupPropagation.COUNTER) == 10.0
    assert b.synthetic_value(RollupPropagation.GAUGE) == 9.0
