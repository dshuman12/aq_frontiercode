from datetime import datetime, timedelta, timezone

import pytest

from timewindow.series_math import (
    SeriesPoint,
    clip,
    cumulative_sum,
    delta,
    detrend_linear,
    exponential_moving_average,
    fill_bucket_gaps,
    moving_average,
    rate_per_second,
    rebucket_mean,
    seasonal_residual,
    to_points,
    winsorize,
    zscore,
)


def ts(i: int) -> datetime:
    return datetime(2026, 1, 1, 0, 0, i, tzinfo=timezone.utc)


def test_to_points_requires_monotonic() -> None:
    with pytest.raises(ValueError):
        to_points([(ts(2), 1.0), (ts(1), 2.0)])


def test_fill_bucket_gaps_ffill() -> None:
    points = [SeriesPoint(ts(0), 2.0), SeriesPoint(ts(3), 5.0)]
    got = fill_bucket_gaps(points, 1, method="ffill")
    assert [p.value for p in got] == [2.0, 2.0, 2.0, 5.0]


def test_moving_and_ema() -> None:
    points = [SeriesPoint(ts(i), float(i + 1)) for i in range(4)]
    ma = moving_average(points, 2)
    ema = exponential_moving_average(points, alpha=0.5)
    assert ma[-1].value == 3.5
    assert ema[-1].value > 3.0


def test_delta_rate_and_cumsum() -> None:
    points = [SeriesPoint(ts(0), 1.0), SeriesPoint(ts(2), 5.0)]
    d = delta(points)
    r = rate_per_second(points)
    c = cumulative_sum(points)
    assert d[-1].value == 4.0
    assert r[-1].value == 2.0
    assert c[-1].value == 6.0


def test_zscore_and_clip() -> None:
    points = [SeriesPoint(ts(i), v) for i, v in enumerate([0.0, 1.0, 2.0, 3.0])]
    z = zscore(points)
    c = clip(points, min_value=0.5, max_value=2.5)
    assert abs(sum(p.value for p in z)) < 1e-6
    assert [p.value for p in c] == [0.5, 1.0, 2.0, 2.5]


def test_winsorize_caps_outliers() -> None:
    points = [SeriesPoint(ts(i), v) for i, v in enumerate([1.0, 1.0, 1.0, 100.0])]
    out = winsorize(points, lower_q=0.0, upper_q=0.75)
    assert out[-1].value == 1.0


def test_seasonal_residual_and_detrend() -> None:
    points = [SeriesPoint(ts(i), float((i % 2) + i)) for i in range(8)]
    resid = seasonal_residual(points, 2)
    det = detrend_linear(points)
    assert len(resid) == len(points)
    assert len(det) == len(points)


def test_rebucket_mean() -> None:
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    points = [
        SeriesPoint(base, 2.0),
        SeriesPoint(base + timedelta(seconds=1), 4.0),
        SeriesPoint(base + timedelta(seconds=10), 3.0),
    ]
    out = rebucket_mean(points, 10)
    assert len(out) == 2
    assert out[0].value == 3.0
