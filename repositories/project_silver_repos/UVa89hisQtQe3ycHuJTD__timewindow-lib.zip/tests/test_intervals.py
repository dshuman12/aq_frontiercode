from datetime import datetime, timezone

import pytest

from timewindow.exceptions import IntervalError
from timewindow.intervals import TimeInterval, count_buckets, iter_bucket_intervals


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=timezone.utc)


def test_interval_contains():
    span = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 1))
    assert span.contains(utc(2026, 1, 1, 0, 30))
    assert not span.contains(utc(2026, 1, 1, 1))


def test_interval_rejects_naive_bounds():
    with pytest.raises(IntervalError):
        TimeInterval(start=datetime(2026, 1, 1), end=utc(2026, 1, 1, 1))


def test_interval_rejects_inverted_bounds():
    with pytest.raises(IntervalError):
        TimeInterval(start=utc(2026, 1, 1, 2), end=utc(2026, 1, 1, 1))


def test_interval_intersection_overlap():
    a = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 3))
    b = TimeInterval(start=utc(2026, 1, 1, 2), end=utc(2026, 1, 1, 5))
    inter = a.intersection(b)
    assert inter == TimeInterval(start=utc(2026, 1, 1, 2), end=utc(2026, 1, 1, 3))


def test_interval_intersection_none():
    a = TimeInterval(start=utc(2026, 1, 1, 0), end=utc(2026, 1, 1, 1))
    b = TimeInterval(start=utc(2026, 1, 1, 2), end=utc(2026, 1, 1, 3))
    assert a.intersection(b) is None


def test_iter_bucket_intervals_splits_range():
    start = utc(2026, 1, 1, 0, 45)
    end = utc(2026, 1, 1, 2, 15)
    windows = list(iter_bucket_intervals(start, end, 3600))
    assert len(windows) == 3
    assert windows[0].start == utc(2026, 1, 1, 0, 45)
    assert windows[0].end == utc(2026, 1, 1, 1, 0)
    assert windows[-1].end == end


def test_iter_bucket_intervals_rejects_naive():
    with pytest.raises(ValueError):
        next(iter_bucket_intervals(datetime(2026, 1, 1), utc(2026, 1, 2), 60))


def test_count_buckets_basic():
    start = utc(2026, 5, 1, 10)
    end = utc(2026, 5, 1, 13)
    assert count_buckets(start, end, 3600) == 3


def test_iter_bucket_intervals_rejects_bad_range():
    with pytest.raises(IntervalError):
        list(iter_bucket_intervals(utc(2026, 1, 2), utc(2026, 1, 1), 60))
