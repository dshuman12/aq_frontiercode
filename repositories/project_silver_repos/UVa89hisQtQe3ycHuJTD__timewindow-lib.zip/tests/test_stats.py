from timewindow.stats import RingBufferFloat, RunningMean


def test_running_mean_basic():
    rm = RunningMean()
    for value in (1.0, 2.0, 3.0):
        rm.update(value)
    assert rm.mean == 2.0
    assert rm.count == 3


def test_running_mean_variance():
    rm = RunningMean()
    for value in (2.0, 4.0, 4.0, 4.0):
        rm.update(value)
    assert rm.count == 4
    assert rm.sample_variance > 0


def test_ring_buffer_partial_fill():
    buf = RingBufferFloat(3)
    buf.push(1.0)
    buf.push(2.0)
    assert buf.snapshot() == [1.0, 2.0]


def test_ring_buffer_overwrite_order():
    buf = RingBufferFloat(3)
    for value in (1.0, 2.0, 3.0, 4.0):
        buf.push(value)
    assert buf.snapshot() == [2.0, 3.0, 4.0]


def test_ring_buffer_clear():
    buf = RingBufferFloat(2)
    buf.push(5.0)
    buf.clear()
    assert buf.snapshot() == []
