# Changelog

## Unreleased

## 0.8.0
- `timewindow.codec`: compact binary frames with varint timestamps and delta-of-delta compression for series points
- `timewindow.storage`: append-only `SeriesStore` with per-series files, JSON manifest, atomic appends, compaction, and verification
- `timewindow.query`: small pipeline DSL (`series(...) | rebucket(...) | where(...) | mean()`) with lexer, parser, AST, and evaluator
- `timewindow.scheduler`: tickless in-process scheduler with `IntervalTrigger`, `CronTrigger`, jobs, and outcome tracking
- `timewindow.http_api`: stdlib `http.server`-based JSON API (`/health`, `/series`, `/series/{name}/append`, `/query`, `/detect`, etc.) with start/stop helpers
- new CLI subcommands: `store-list`, `store-ingest`, `store-compact`, `store-drop`, `query`, `query-help`, `serve`, `schedule-demo`

## 0.7.0
- `timewindow.csvio`: streaming reader/writer for `timestamp,value` CSV series with schema detection, atomic writes, and day-sharding helpers
- `timewindow.report`: textual and JSON summaries for series and anomaly events, plus value histograms
- `timewindow.recipes`: end-to-end pipelines (`rebucket_series`, `run_tiered_rollup`, `detect_all`, `analyze_series`, `analyze_csv_file`)
- `timewindow.cli`: `summary`, `histogram`, `rebucket`, `detect`, `rollup`, `lint`, and `analyze` subcommands operating on CSV input
- runnable `examples/` (`analyze_metrics.py`, `rollup_pipeline.py`, `window_aggregates.py`, `analyze_events.py`) with sample datasets
- `docs/quickstart.md` and `docs/cli.md` covering the practical API and CLI surface
- fix: `timewindow.cli` was missing a `datetime` import

## 0.6.0
- `timewindow.series_math`: feature-engineering and transformation operators (rolling stats, derivatives, rebucketing, scaling, trend/seasonality residuals)
- `timewindow.anomaly`: operational detectors for spikes, level shifts, stale series, gaps, and robust MAD-based change points

## 0.5.0
- `timewindow.tiered_rollups`: UTC bucket completion events, monotonic reducers, and stacked rollups (gauge vs counter propagation)
- `timewindow.sliding_windows`: amortized streaming min/max, sum, mean over time spans, plus count-bounded windows

## 0.4.0
- `timewindow.tsdb`: in-memory `MemorySeriesTable` with per-series points, stats, range cursors, merges, and bucket aggregates
- `timewindow.ndjsonio`: newline-delimited JSON helpers (streaming reader/writer, shape checks, batching, redaction)
- `timewindow.matchers`: parseable label matchers with boolean combinators
- root package exports for the new modules above

## 0.3.0
- label sets, histograms, sampling, batching, log parsing, rate windows, cardinality LRU
- time-series resampling helpers for last-value and sum rollups

## 0.2.0
- duration parsing, intervals, hopping/tumbling cursors, retention helpers
- ISO-8601 serde, interval merging, lightweight online stats helpers
- `timewindow` CLI + expanded documentation

## 0.1.1
- MIT license file + packaging metadata cleanup
