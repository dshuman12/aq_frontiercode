"""template endpoints - users save and re-render prompt scaffolds."""
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from templates import repository as repo
from templates.models import dry_run, render
from users.endpoints import current_user


router = APIRouter(prefix="/v1/templates", tags=["templates"])


class CreateTemplate(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    body: str = Field(..., min_length=1, max_length=10000)
    is_shared: bool = False


class UpdateTemplate(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    body: Optional[str] = Field(default=None, max_length=10000)
    is_shared: Optional[bool] = None


class RenderBody(BaseModel):
    values: Dict[str, str] = Field(default_factory=dict)


@router.post("")
def create(body: CreateTemplate, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.create_template(user_id=user.id, name=body.name, body=body.body, is_shared=body.is_shared)
    return {"template": t.public()}


@router.get("")
def list_mine(user=Depends(current_user), include_shared: bool = True) -> Dict[str, Any]:
    rows = repo.list_for_user(user.id, include_shared=include_shared)
    return {"templates": [t.public() for t in rows]}


@router.get("/shared")
def list_shared(user=Depends(current_user)) -> Dict[str, Any]:
    rows = repo.list_shared()
    return {"templates": [t.public() for t in rows]}


@router.get("/{template_id}")
def get_one(template_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.get_template(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail="template not found")
    if t.user_id != user.id and not t.is_shared:
        raise HTTPException(status_code=403, detail="not your template")
    return {"template": t.public()}


@router.patch("/{template_id}")
def update(template_id: str, body: UpdateTemplate, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.get_template(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail="template not found")
    if t.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your template")
    updated = repo.update_template(
        template_id=template_id,
        name=body.name,
        body=body.body,
        is_shared=body.is_shared,
    )
    return {"template": updated.public() if updated else None}


@router.delete("/{template_id}")
def delete(template_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.get_template(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail="template not found")
    if t.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your template")
    ok = repo.delete_template(template_id)
    return {"deleted": ok}


@router.post("/{template_id}/render")
def render_template(template_id: str, body: RenderBody, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.get_template(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail="template not found")
    if t.user_id != user.id and not t.is_shared:
        raise HTTPException(status_code=403, detail="not your template")
    try:
        rendered = render(t.body, body.values)
    except KeyError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"rendered": rendered}


@router.post("/{template_id}/dry-run")
def dry_run_template(template_id: str, body: RenderBody, user=Depends(current_user)) -> Dict[str, Any]:
    t = repo.get_template(template_id)
    if t is None:
        raise HTTPException(status_code=404, detail="template not found")
    if t.user_id != user.id and not t.is_shared:
        raise HTTPException(status_code=403, detail="not your template")
    return dry_run(t.body, body.values)
