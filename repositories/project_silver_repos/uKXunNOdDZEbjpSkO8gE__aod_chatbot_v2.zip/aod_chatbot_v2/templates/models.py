"""prompt template schema + dataclass + simple variable substitution helper."""
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


TEMPLATES_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS prompt_templates (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    body TEXT NOT NULL,
    variables TEXT NOT NULL DEFAULT '[]',
    is_shared INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_prompt_templates_user ON prompt_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_prompt_templates_shared ON prompt_templates(is_shared);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_prompt_template_user_slug ON prompt_templates(user_id, slug);
"""


# variables look like `{name}` or `{name:default}`. simple, not jinja.
_VAR_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)(?::([^{}]*))?\}")


@dataclass
class Template:
    id: str
    user_id: str
    name: str
    slug: str
    body: str
    variables: List[str]
    is_shared: bool
    created_at: int
    updated_at: int

    @classmethod
    def from_row(cls, row) -> "Template":
        import json as _json
        try:
            vars_list = _json.loads(row["variables"] or "[]")
            if not isinstance(vars_list, list):
                vars_list = []
        except (ValueError, TypeError):
            vars_list = []
        return cls(
            id=row["id"],
            user_id=row["user_id"],
            name=row["name"],
            slug=row["slug"],
            body=row["body"],
            variables=[str(v) for v in vars_list],
            is_shared=bool(row["is_shared"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "slug": self.slug,
            "body": self.body,
            "variables": self.variables,
            "is_shared": self.is_shared,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


def extract_variables(body: str) -> List[str]:
    """returns unique variable names in order of first appearance."""
    seen: Dict[str, None] = {}
    for match in _VAR_RE.finditer(body or ""):
        name = match.group(1)
        if name not in seen:
            seen[name] = None
    return list(seen.keys())


def render(body: str, values: Dict[str, str]) -> str:
    """substitute {name} with values[name]. {name:default} uses default if value missing.

    unknown variables that have no default raise KeyError. that's intentional - silent
    rendering of '{user_question}' would let typos sneak into production prompts.
    """
    def _replace(match: re.Match) -> str:
        name = match.group(1)
        default = match.group(2)
        if name in values:
            v = values[name]
            return v if v is not None else (default or "")
        if default is not None:
            return default
        raise KeyError(f"missing template variable: {name!r}")
    return _VAR_RE.sub(_replace, body or "")


def dry_run(body: str, values: Dict[str, str]) -> Dict[str, Any]:
    """returns the rendered body PLUS the list of missing-without-default variables.
    doesn't raise; use for previewing in the ui.
    """
    missing: List[str] = []
    def _replace(match: re.Match) -> str:
        name = match.group(1)
        default = match.group(2)
        if name in values:
            v = values[name]
            return v if v is not None else (default or "")
        if default is not None:
            return default
        missing.append(name)
        return f"{{{name}}}"   # leave the placeholder in-place for visibility
    rendered = _VAR_RE.sub(_replace, body or "")
    return {"rendered": rendered, "missing": missing}
