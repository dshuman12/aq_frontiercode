"""template CRUD. slugs are auto-generated and unique per user."""
import json
import re
import time
import uuid
from typing import List, Optional

from rag.sessions import _connect
from templates.models import TEMPLATES_SCHEMA, Template, extract_variables


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(TEMPLATES_SCHEMA)


_SLUG_RE = re.compile(r"[^a-z0-9-]+")


def _slugify(name: str) -> str:
    s = name.lower().strip().replace(" ", "-")
    s = _SLUG_RE.sub("", s)
    return s.strip("-") or "template"


def create_template(user_id: str, name: str, body: str, is_shared: bool = False) -> Template:
    tid: str = uuid.uuid4().hex
    base_slug: str = _slugify(name)
    slug: str = base_slug
    now: int = int(time.time())
    variables = extract_variables(body)
    vars_json: str = json.dumps(variables)
    with _connect() as conn:
        # try a couple suffixes if slug collides for this user
        for i in range(50):
            try:
                conn.execute(
                    "INSERT INTO prompt_templates (id, user_id, name, slug, body, variables, is_shared, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (tid, user_id, name, slug, body, vars_json, 1 if is_shared else 0, now, now),
                )
                break
            except Exception:
                slug = f"{base_slug}-{i + 2}"
        else:
            raise RuntimeError("could not allocate slug for template")
    return Template(
        id=tid, user_id=user_id, name=name, slug=slug, body=body, variables=variables,
        is_shared=is_shared, created_at=now, updated_at=now,
    )


def get_template(template_id: str) -> Optional[Template]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM prompt_templates WHERE id = ?", (template_id,)).fetchone()
    return Template.from_row(row) if row else None


def get_by_slug(user_id: str, slug: str) -> Optional[Template]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM prompt_templates WHERE user_id = ? AND slug = ?",
            (user_id, slug),
        ).fetchone()
    return Template.from_row(row) if row else None


def update_template(
    template_id: str,
    name: Optional[str] = None,
    body: Optional[str] = None,
    is_shared: Optional[bool] = None,
) -> Optional[Template]:
    """partial update. recomputes variables when body changes."""
    existing = get_template(template_id)
    if existing is None:
        return None
    new_name = name if name is not None else existing.name
    new_body = body if body is not None else existing.body
    new_shared = is_shared if is_shared is not None else existing.is_shared
    new_vars = extract_variables(new_body)
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "UPDATE prompt_templates SET name = ?, body = ?, variables = ?, is_shared = ?, updated_at = ? WHERE id = ?",
            (new_name, new_body, json.dumps(new_vars), 1 if new_shared else 0, now, template_id),
        )
    return get_template(template_id)


def delete_template(template_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("DELETE FROM prompt_templates WHERE id = ?", (template_id,))
        return cur.rowcount > 0


def list_for_user(user_id: str, include_shared: bool = True, limit: int = 100) -> List[Template]:
    """list a user's own templates + (optionally) public ones."""
    if include_shared:
        sql = (
            "SELECT * FROM prompt_templates WHERE user_id = ? OR is_shared = 1 "
            "ORDER BY updated_at DESC LIMIT ?"
        )
        args = (user_id, limit)
    else:
        sql = "SELECT * FROM prompt_templates WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?"
        args = (user_id, limit)
    with _connect() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [Template.from_row(r) for r in rows]


def list_shared(limit: int = 100) -> List[Template]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM prompt_templates WHERE is_shared = 1 ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [Template.from_row(r) for r in rows]


bootstrap()
