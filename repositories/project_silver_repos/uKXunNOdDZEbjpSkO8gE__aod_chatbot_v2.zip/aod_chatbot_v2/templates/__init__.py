"""prompt template management. users can save reusable system prompts."""
