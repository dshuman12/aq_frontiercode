---
doc_id: bainsa_social_links_contacts
title: "BAINSA Social Networks, Links, and Contacts"
owner: "BAINSA"
last_updated: "2026-01-16"
canonical: true
archived: false
tags:
  - contacts
  - social
  - links
  - instagram
  - linkedin
  - linktree
audience:
  - students
  - external
source: "internal_docx_upload"
---

# BAINSA Social Networks, Links, and Contacts

## Instagram
- Handle: **@bainsa_bocconi**
- Link: https://www.instagram.com/bainsa_bocconi/

## LinkedIn
- Page: **Bocconi AI & NeuroScience Association (BAINSA)**
- Description: BAINSA is the largest student group on artificial & human intelligence in Italy, and among the largest in the EU.
- Link: https://www.linkedin.com/company/bainsa/?originalSubdomain=it

## Linktree
- Link: https://linktr.ee/bainsa

## Contacts
- Email: **bainsa.bocconi@gmail.com**
- Message: For any question or comment, contact us!
- Contacts page: https://www.bainsa.xyz/contacts
