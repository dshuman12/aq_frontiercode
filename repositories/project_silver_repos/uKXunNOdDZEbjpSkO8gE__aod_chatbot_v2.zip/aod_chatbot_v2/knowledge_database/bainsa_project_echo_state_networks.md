---
doc_id: bainsa_project_echo_state_networks
title: "Echo State Networks on the Human Connectome"
owner: "BAINSA"
last_updated: "2025-02-09"
canonical: true
archived: false
tags:
  - neuroscience
  - connectome
  - echo state networks
  - reservoir computing
  - time series
audience:
  - students
  - researchers
  - external
source: "website_text_docx_upload"
---

# Long term projects, Echo State Networks on the Human Connectome

## Website
- Link: https://www.bainsa.xyz/projects/echo-state

## Introduction
The Echo State Networks on the Human Connectome project explores the fascinating relationship between the structure and dynamics of the human brain’s connectome and its computational capabilities. We leverage the power of Echo State Networks (ESNs), a type of reservoir computing, to investigate how the intricate wiring patterns of the brain influence its ability to learn and generalize from time-series data.

## Project Goals and Motivation
The human brain is a remarkably efficient and adaptable information processing system, capable of learning complex tasks with minimal training data. Understanding the principles underlying the brain’s computational efficiency could lead to breakthroughs in artificial intelligence and machine learning. This project focuses on the connectome – the comprehensive map of neural connections in the brain – as a key determinant of computational capacity. Reservoir computing, and specifically ESNs, provide a powerful framework for studying the computational properties of complex networks. ESNs consist of a large, randomly connected “reservoir” of neurons, which is driven by input signals. The reservoir’s dynamics transform the input into a high-dimensional representation, and a simple readout layer is trained to extract the desired output. The key advantage of ESNs is that only the readout layer needs to be trained, making them computationally efficient and well-suited for studying the inherent computational properties of the reservoir itself.

Our project aims to:
* **Construct ESNs Based on Human Connectome Data:** Utilize structural connectome data from the Human Connectome Project (HCP) and similar repositories to create ESN reservoirs that reflect the wiring patterns of the human brain.
* **Evaluate ESN Performance on Time-Series Prediction Tasks:** Train the ESNs to perform various time-series prediction tasks, using chaotic time series as a benchmark. This will allow us to assess how different connectome-based reservoirs perform compared to randomly connected reservoirs and other null models.
* **Relate Connectome Features to Computational Capacity:** Investigate how specific topological features of the connectome, such as modularity, hierarchy, clustering, and connectivity patterns, influence the ESN’s ability to learn and generalize.
* **Explore the Role of the Excitatory/Inhibitory Balance**
* **Compare ESNs to other Neural Networks**

## Data Collection and Preprocessing
We will primarily utilize data from the Human Connectome Project (HCP), which provides high-resolution diffusion MRI data that can be used to infer structural connectivity between different brain regions. We will also explore data from other publicly available connectome repositories.

Data preprocessing will involve:
* **Parcellation:** Dividing the brain into distinct regions of interest (ROIs) using a predefined atlas (e.g., the Desikan-Killiany atlas).
* **Connectivity Matrix Construction:** Estimating the strength of connections between ROIs based on the diffusion MRI data, typically using tractography algorithms. This results in a weighted adjacency matrix representing the connectome.
* **Normalization:** Normalizing the connectivity matrix to ensure that the ESN reservoir’s dynamics are stable and within a suitable range.

## Reservoir Construction
The core of our project is the construction of ESN reservoirs based on the preprocessed connectome data. We will explore different approaches:
* **Direct Mapping:** Using the normalized connectivity matrix directly as the weight matrix for the ESN reservoir. This creates a reservoir that closely mirrors the brain’s structural connectivity.
* **Null Models:** Creating control reservoirs for comparison, including: Random Networks: Reservoirs with randomly generated connections. Shuffled Connectomes: Reservoirs where the connections from the original connectome are randomly shuffled, preserving the overall connection density but destroying the specific wiring patterns. Small-World Networks
* **Parameter Exploration:** Investigating the influence of key ESN parameters, such as spectral radius (which controls the reservoir’s dynamics) and sparsity (the proportion of non-zero connections), on performance.

## Machine Learning Tasks
The ESNs will be trained and evaluated on time-series prediction tasks. We will primarily use chaotic time series as they represent a complex and dynamic environment. We will start with the Mackey-Glass equation.
* **Prediction Tasks:** The ESN will be trained to predict future values of the time series based on past values.
* **Ground Truth:** Chaotic time series, such as the Lorenz attractor or the Mackey-Glass equation, will be used as ground truth, providing a controlled and well-defined benchmark.
* **Comparison with Null Models:** The performance of the ESNs based on connectome data will always be evaluated in comparisons to the Null Models.

## Relating Biological Features to Performance
A key aspect of our project is to understand how specific features of the connectome influence the ESN’s computational capacity. We will analyze:
* **Topological Characteristics:** Modularity: The degree to which the network is organized into distinct modules or communities. Hierarchy: The presence of hierarchical organization, with different levels of processing. Clustering Coefficient: The tendency of nodes to form tightly connected clusters. Path Length: The average distance between nodes in the network. Small-World Properties
* **Dynamic Behavior:** Excitation-Inhibition Balance: The balance between excitatory and inhibitory connections in the network, which is crucial for stable and efficient neural computation. Clustering of Excitation/Inhibition

## Model Evaluation
The performance of the ESNs will be evaluated using standard machine learning metrics:
* **Accuracy:** How closely the ESN’s predictions match the true values of the time series.
* **Mean Squared Error (MSE):** The average squared difference between predicted and true values.
* **Predictive Power:** The ability of the ESN to predict future values beyond the training data.

## Expected Outcomes and Impact
This project has the potential to provide valuable insights into the relationship between brain structure and function, shedding light on the computational principles underlying the brain’s remarkable abilities. The findings could:
* **Advance Our Understanding of Brain Computation:** Reveal how specific connectome features contribute to efficient learning and generalization.
* **Inspire New Machine Learning Architectures:** Lead to the development of more biologically plausible and powerful machine learning models.
* **Contribute to Both Neuroscience and AI:** Bridge the gap between these two fields, fostering interdisciplinary collaboration and accelerating progress in both domains.

The long-term goal is to move from using structural (anatomical) connectivity data to functional connectivity data. Functional connectivity describes statistical dependencies between the activity of different brain regions and can change rapidly depending on the task being performed. Incorporating functional connectivity into the ESN framework could provide a more dynamic and nuanced understanding of brain computation.