---
doc_id: bainsa_aod_2026_venue
title: "AOD 2026: Venue and Logistics"
owner: "BAINSA"
last_updated: "2026-04-30"
canonical: true
archived: false
tags:
  - aod
  - 2026
  - venue
  - bocconi
  - logistics
  - directions
audience:
  - students
  - external
source: "internal_docx_upload"
---

# AOD 2026: Venue and Logistics

## Where
**Università Bocconi, Aula Magna** (Velodromo building, Via Roentgen 1, 20136 Milan).

The Velodromo building is the curved glass-and-steel structure at the north end of the Roentgen campus block. Aula Magna is on the ground floor; signage will be up from 08:00.

## Getting there
- **Metro**: Line M3 (yellow) to Bocconi station. The campus exit is directly opposite the Velodromo.
- **Tram**: Line 9 to "Bocconi" or "Toscana Bocconi". Five-minute walk.
- **Bus**: Lines 65 and 91 stop within two minutes of Roentgen entrances.
- **Car**: No on-campus parking is available for attendees. Closest public garages: Garage Beruto and Garage Bocconi (on Via Sarfatti).
- **Bike**: BikeMi station "Bocconi" sits at the corner of Sarfatti and Bligny.

## Accessibility
- The Velodromo building is step-free at both entrances.
- Aula Magna has reserved wheelchair-accessible seating in the front rows; please email accessibility@bainsa.it ahead of time so we can route you to the right entrance.
- Live captioning is available on a per-request basis (English / Italian). Use the same email at least 72 hours before the event.

## Food and dietary
- Lunch is provided by the headline partner (see `bainsa_aod_2026_sponsors`).
- Options labelled: vegetarian, vegan, no-pork, gluten-free.
- A short note in the registration form is the cleanest way to surface a specific allergy ahead of time.

## On-site contacts
- **Day-of help desk**: front of Aula Magna, staffed all day.
- **Slack-equivalent**: BAINSA Discord, `#aod-2026-day-of` channel - joinable on arrival via QR code on the badge.
- **Lost-and-found**: Bocconi front desk at the Velodromo entrance; items are forwarded to BAINSA at end-of-day.

## After the event
- Aperitivo location for the informal closing is announced from the stage during the closing remarks and posted to the day-of Discord channel.
