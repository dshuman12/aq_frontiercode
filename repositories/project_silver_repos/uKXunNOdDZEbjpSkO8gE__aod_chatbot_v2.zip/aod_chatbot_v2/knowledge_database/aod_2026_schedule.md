---
doc_id: bainsa_aod_2026_schedule
title: "AOD 2026: Day-of Schedule"
owner: "BAINSA"
last_updated: "2026-04-30"
canonical: true
archived: false
tags:
  - aod
  - 2026
  - schedule
  - timetable
  - bocconi
audience:
  - students
  - external
source: "internal_docx_upload"
---

# AOD 2026: Day-of Schedule

The Alliance of Developers (AOD) 2026 is BAINSA's flagship student showcase, held at Bocconi.

## Doors and check-in
- **08:30 - 09:15**: Check-in, badge pickup, coffee in the lobby of Aula Magna.
- **09:15 - 09:30**: Welcome by the BAINSA president and AOD chair.

## Morning sessions
- **09:30 - 10:30**: Keynote - "What students get right (and wrong) about applied AI". Speaker TBA.
- **10:30 - 10:45**: Coffee break.
- **10:45 - 12:30**: Project showcase, block A - drug discovery, predictive healthcare, financial-statement credit risk.

## Lunch
- **12:30 - 13:45**: Buffet lunch on the Aula Magna terrace. Veg / no-pork options labelled.

## Afternoon sessions
- **13:45 - 15:30**: Project showcase, block B - Wikipedia knowledge graph, echo state networks, visual cortex dimensionality, intelligent prosthetic arm, microns explorer.
- **15:30 - 15:45**: Break.
- **15:45 - 16:45**: Panel - "From university lab to first paid AI role". BAINSA alumni + industry guests.
- **16:45 - 17:30**: Recruiter mixer + project booths reopen.

## Closing
- **17:30 - 18:00**: Closing remarks + announcement of the BAINSA Project of the Year.
- **18:00 - late**: Informal aperitivo at a nearby bar (location announced day-of).

## Notes
- Sessions are run in Italian unless a speaker prefers English; slides are bilingual.
- Recording: keynote and panel will be uploaded to the BAINSA YouTube within two weeks.
- Code of conduct: standard Bocconi student-society rules apply; reach out to any organizer with anything that needs flagging.
