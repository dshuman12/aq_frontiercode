---
doc_id: bainsa_faq
title: "Frequently Asked Questions (FAQ)"
owner: "BAINSA"
last_updated: "2026-01-18"
canonical: true
archived: false
tags:
  - faq
  - help
  - membership
  - divisions
  - costs
audience:
  - students
  - external
source: "generated_aggregation"
---

# Frequently Asked Questions

## Membership & Joining

### Who can join BAINSA?
While the community is based near Bocconi in Milan and consists mainly of students, it is open to everyone. We look for open-minded students with a strong passion for AI and a desire to discover the latest technological advancements in the field of AI.

### Is there a cost to join?
Yes. If you are accepted, a **€10 membership fee** is requested to cover operational costs. Along with this fee, you will receive the association's t-shirt, so that you can partecipate to every event organized by BAINSA.

### How do I apply?
You can apply via the form on our website: https://www.bainsa.xyz/joinus. Note that applications are department-specific; if you want to be considered for multiple roles, you must submit additional applications. Selection criterias are strict, after a first screening, the selected candidates will receive a personal interview, to make sure they are the right fit for our association. If this seems scary, don't be! Make sure to apply if you are interested and passionate about AI, to have the opportunity of meeting and working with like-minded individuals!

### Can I apply, even though I don't know how to program?
Yes. We encourage members from every background, technical and not, to apply to join BAINSA! Anyone can bring great value to our Association, regardless of their programming or coding skills. You just need to be motivated and ready to work alongside like-minded individuals!

## Organization & Activities

### What are the main divisions within BAINSA?
BAINSA is structured into three divisions:
* **Projects Division:** Focuses on rigorous, technical projects in AI, neuroscience, and robotics.
* **Analysis Division:** Focuses on AI and neuroscience beyond disciplinary boundaries, conducting research reviews and presentations about selected topics.
* **Culture Division:** Focuses on bringing ideas into real-life contexts through networking and events.

### What kind of activities does BAINSA do?
Joining BAINSA means: working on research projects, weekly meetings to discuss AI papers, building a professional network, and trips/participation in international AI festivals and hackathons.

## Research & Projects

### What topics does BAINSA research?
Our projects cover a wide range of cutting-edge topics, including:
* **Neuroscience:** Analyzing the visual cortex (MICrONS explorer) and developing intelligent prosthetic arms controlled by EEG signals.
* **Finance:** Machine learning for financial statement analysis and credit outcome predictions.
* **Crypto:** Forecasting cryptocurrency trends using social media sentiment analysis.
* **Healthcare:** Predictive modeling for early diagnosis and personalized healthcare using EHRs.

### Do you work with external partners?
Yes. We have collaborated with companies and startups on various initiatives. For example:
* **Bending Spoons:** We collaborated with their researchers on the Cryptocurrency Forecast Project and the Wikipedia Knowledge Graph.
* **Chaptr Global:** We worked on financial statement analysis and credit prediction models.
* **Autotorino:** They fully financed our trip to the World AI Cannes Festival (WAICF).

## Contact

### How can I contact the team?
You can email us at **bainsa.bocconi@gmail.com** or message us on Instagram at **@bainsa_bocconi**.