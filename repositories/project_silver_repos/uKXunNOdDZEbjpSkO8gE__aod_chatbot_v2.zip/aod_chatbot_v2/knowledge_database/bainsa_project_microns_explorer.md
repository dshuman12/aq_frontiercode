---
doc_id: bainsa_project_microns_explorer
title: "Short term projects, Computational neuroscience: MICrONS explorer"
owner: "BAINSA"
last_updated: "2025-08-09"
canonical: true
archived: false
tags:
  - computational neuroscience
  - MICrONS
  - machine learning
  - visual cortex
  - mouse brain
audience:
  - students
  - researchers
  - external
source: "website_text_docx_upload"
---

# Short term projects, Computational neuroscience: MICrONS explorer

## Website
- Link: https://www.bainsa.xyz/projects/computational-neuroscience-microns-explorer

## Overview
The project is built upon the Machine Intelligence from Cortical Networks (MICrONS) program that seeks to revolutionize machine learning by reverse-engineering the algorithms of the brain [1]. The work consists of using computer programming and machine learning tools to analyze data from a functional connectomics dataset that contains calcium imaging of an estimated 75,000 neurons from the mouse visual cortex [2]. The team uses computational tools such as Python, Datajoint framework and Jupyter network to analyze a dataset based on a section of a mouse brain, created by Machine Intelligence from the Cortical Network program.

## Dataset and Analysis
The dataset contains different types of data, such as electron microscope imaging, cell segmentation, cell meshes. The main focus of the project is analyzing the response the rodent brain produces after various visual stimuli.