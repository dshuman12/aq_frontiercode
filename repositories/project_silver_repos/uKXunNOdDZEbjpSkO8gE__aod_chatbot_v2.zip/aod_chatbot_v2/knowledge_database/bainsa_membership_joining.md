---
doc_id: bainsa_membership_joining
title: "Joining BAINSA"
owner: "BAINSA"
last_updated: "2026-01-16"
canonical: true
archived: false
tags:
  - membership
  - join
  - application
  - fee
audience:
  - students
source: "internal_docx_upload"
---

# Joining BAINSA

## Application link
- Apply here: https://www.bainsa.xyz/joinus

## Who should apply
BAINSA looks for open-minded students with a strong passion for AI and a desire to discover the latest technological advancements. If you think you’re a good fit for a role, you are encouraged to apply via the form.

## Department-specific applications
Applications are department-specific: you’ll only be considered for the role you applied for. If you want to be considered for other roles, submit an additional application.

## Membership fee (if accepted)
If you’re accepted, a **€10 membership fee** is requested to cover operational costs.
