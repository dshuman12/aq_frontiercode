---
doc_id: bainsa_analysis_pathfinding_games
title: "Analysis Division: Pathfinding in Video Games"
owner: "BAINSA"
last_updated: "2024-12-29"
canonical: true
archived: false
tags:
  - analysis
  - scientific reviews
  - pathfinding
  - video games
  - A* search
  - neural networks
audience:
  - students
  - developers
  - external
source: "website_text_docx_upload"
---

# Analysis division, scientific reviews, pathfinding in Video Games

## Website
- Link: https://www.bainsa.xyz/projects/pathfinding-in-video-games

## Overview
Pathfinding naturally arises in a variety of scenarios, whether it be navigating a labyrinth or determining the best route to get across campus. This is a relatively trivial problem for the human brain to tackle. For a computer however, it is not so simple to find the best path between two points. In video games, for example, an enemy must find the best path to avoid obstacles and pursue the player. There have been algorithms designed to tackle this problem in the past, but until the emergence of neural networks, these algorithms lacked efficiency.

## The path planning problem
A* search is a popular search-based planning algorithm that is guaranteed to identify a path between two points, as long as one exists. Neural A* search improves upon the classic A* search algorithm through the use of a convolutional neural network, a common tool for visual pattern recognition. A fully-convolutional encoder is used to transform the problem into an initial guidance map with guidance costs for each move. The standard A* search is adapted to produce a differentiable A* module which allows back-propagation to train the model. By the end of training, Neural A* is able to detect visual cues like dead ends and shortcuts to better find the shortest path.

## Environment Representation
In the path planning problem, the environment that must be navigated can be represented as a 2D binary map X, where each entry is either 1 if it is a passable location or 0 if it is obstructed.

The start and goal locations $V_s$ and $V_g$ are matrices of the same size as X, but all the values are 0 except for at the specific entry representing respective start or goal position, where the value is 1. This type of matrix with 0s everywhere except for at a certain entry is called a one-hot matrix. Lastly, the open list O tracks the nodes that are currently available to be explored, and the closed list C tracks the nodes that have already been explored.

## Choosing the next move
The algorithm works by choosing the most promising candidate that is reachable from the current location. The algorithm repeatedly selects the most promising node to explore, following the previous steps, until the goal has been reached.

## Training the model
The encoder is responsible for transforming the actual environment of an instance of the path planning problem into the guidance map, with guidance costs G, upon which the differentiable A* module works. However, the encoder must be trained to properly identify visual cues and generate an effective guidance map.

The training involves the process of gradient descent (think rate of change) which uses back-propagation to efficiently identify how to update the weights to minimize the loss function. The loss function is back-propagated through each step of the search algorithm back to the encoder. To stabilize the training process, certain matrix values are removed from steps of the back-propagation chain to effectively disable their gradients. This process allows the encoder to learn visual cues, like the shape of dead ends, to enable accurate and efficient path planning.

## Extensions
The introduction of convolutional neural networks to A* search vastly improved its efficiency and effectiveness. Neural A* can recognize visual cues to identify the shortest path between two points, while avoiding some of the brute force involved in the original A* search. In addition to the binary nature of a video game map, Neural A* can be adapted to work with raw images from the real world, extending its use case to autonomous vehicle navigation and even robotic arms. Needless to say, Neural A* is a revolutionary change from previous path planning algorithms, and has a wide range of applications, both in video games and real life.