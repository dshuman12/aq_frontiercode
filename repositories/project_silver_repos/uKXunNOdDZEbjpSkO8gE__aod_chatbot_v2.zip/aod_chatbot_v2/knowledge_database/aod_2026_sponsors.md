---
doc_id: bainsa_aod_2026_sponsors
title: "AOD 2026: Partners and Sponsors"
owner: "BAINSA"
last_updated: "2026-04-30"
canonical: true
archived: false
tags:
  - aod
  - 2026
  - sponsors
  - partners
  - autotorino
audience:
  - students
  - external
  - sponsors
source: "internal_docx_upload"
---

# AOD 2026: Partners and Sponsors

AOD 2026 is supported by a mix of long-running BAINSA partners and event-specific sponsors. All partnerships are non-exclusive - BAINSA does not endorse any partner's product, and BAINSA members are never required to engage with sponsors as a condition of membership.

## Headline partner
- **Autotorino** - the same Italian car-dealership group that fully financed the BAINSA Cannes trip (see `bainsa_event_waicf_cannes_2026`). For AOD 2026 they cover the venue rental and the lunch buffet.

## Hosting partner
- **Università Bocconi** - provides Aula Magna and adjacent rooms at no cost, in line with the standard Bocconi student-society support policy.

## Recruitment partners
A rotating pool of firms that send representatives to the afternoon mixer. Each gets a labelled booth and 30 minutes of Q&A across the recruiter slot. Confirmed for 2026:
- Bocconi-affiliated consultancies (rotating roster managed by the BAINSA careers committee).
- Two regional fintech firms (under NDA until announce day).
- One scale-up AI infrastructure firm (Milan-based).

## In-kind partners
- **Bocconi IT** - provides the Wi-Fi capacity uplift for the day and the streaming gear for the recorded sessions.
- **The Bocconi Print Shop** - handles the printed programme and badges.

## Sponsorship policy
- Sponsor money goes to the event budget, never to individual organizers.
- No sponsor has editorial control over the project showcase. Project selection is run by the BAINSA project committee.
- All sponsor logos appear on the same slide block during welcome remarks; tier-based prominence is intentionally avoided to keep partner relationships flat.
- Sponsorship inquiries: partnerships@bainsa.it (forwarded to the partnerships lead).
