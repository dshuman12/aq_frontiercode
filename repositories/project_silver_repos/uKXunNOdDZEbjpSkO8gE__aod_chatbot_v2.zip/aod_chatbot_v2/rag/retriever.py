import random
import time
from typing import Any, Dict, List, Optional

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from rag.config import API_KEY, CHROMA_DIRECTORY, COLLECTION_NAME, EMBEDDING_MODEL, require_api_key


# todo: swap the dumb linear backoff for exp + jitter (random is imported, just lazy)


def build_vector_db(retries: int = 5) -> Chroma:
    require_api_key()
    embeddings: OpenAIEmbeddings = OpenAIEmbeddings(api_key=API_KEY, model=EMBEDDING_MODEL)
    # chroma sometimes flakes on first start in a fresh container (file lock racing the persist dir creation?).
    # so we retry a handful of times with linear backoff. yes this is dumb. it works.
    last_err: Optional[Exception] = None
    for i in range(retries):
        try:
            return Chroma(
                collection_name=COLLECTION_NAME,
                persist_directory=CHROMA_DIRECTORY,
                embedding_function=embeddings,
            )
        except Exception as e:  # chroma's exception types are a moving target
            last_err = e
            time.sleep(0.5 * (i + 1))
    raise RuntimeError(f"chroma init failed after {retries} tries: {last_err}")


def retrieve(db: Chroma, query: str, k: int = 3) -> List[Document]:
    # pull more candidates from chroma than we need, then let the reranker pick the top k.
    # if reranker is disabled this becomes a strict pass-through.
    from reranker.integrate import maybe_rerank

    candidate_k = max(k, k * 3)   # 3x oversample; cheap because reranker is local
    candidates = db.similarity_search(query, k=candidate_k)
    return maybe_rerank(query, candidates, top_k=k)


def format_context(docs: List[Document]) -> str:
    """flattens retrieved chunks into the prompt-grounding block."""
    blocks: List[str] = []
    for doc in docs:
        meta: Dict[str, Any] = doc.metadata or {}
        blocks.append(
            "---\n"
            f"Source: {meta.get('source', 'Unknown')}\n"
            f"Doc_id: {meta.get('doc_id', 'Unknown')}\n"
            f"Title: {meta.get('title', 'Unknown')}\n"
            f"Last_updated: {meta.get('last_updated', 'Unknown')}\n"
            f"Tags: {meta.get('tags', 'Unknown')}\n"
            f"Audience: {meta.get('audience', 'Unknown')}\n"
            f"Owner: {meta.get('owner', 'Unknown')}\n"
            f"Content:\n{doc.page_content}\n"
        )
    return "\n".join(blocks)
