import os
import time
from collections import defaultdict, deque
from threading import Lock
from typing import Deque, Dict

from fastapi import Depends, HTTPException, Request, status

from rag.auth import verify_caller


DEFAULT_LIMIT: int = int(os.getenv("AOD_RATE_LIMIT", "60"))
WINDOW_SECONDS: int = int(os.getenv("AOD_RATE_WINDOW", "60"))


class SlidingWindow:
    """plain in-memory sliding-window counter. fine for a single uvicorn process."""

    def __init__(self, limit: int = DEFAULT_LIMIT, window: int = WINDOW_SECONDS) -> None:
        self.limit: int = limit
        self.window: int = window
        self._hits: Dict[str, Deque[float]] = defaultdict(deque)
        self._lock: Lock = Lock()

    def hit(self, key: str) -> bool:
        """returns True when allowed, False when over budget."""
        now: float = time.monotonic()
        cutoff: float = now - self.window
        with self._lock:
            stamps: Deque[float] = self._hits[key]
            while stamps and stamps[0] < cutoff:
                stamps.popleft()
            if len(stamps) >= self.limit:
                return False
            stamps.append(now)
            return True

    def remaining(self, key: str) -> int:
        now: float = time.monotonic()
        cutoff: float = now - self.window
        with self._lock:
            stamps: Deque[float] = self._hits[key]
            while stamps and stamps[0] < cutoff:
                stamps.popleft()
            return max(0, self.limit - len(stamps))

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


_limiter: SlidingWindow = SlidingWindow()


async def enforce_rate_limit(
    request: Request,
    caller: str = Depends(verify_caller),
) -> str:
    bucket: str = caller if caller != "anonymous" else (request.client.host if request.client else "unknown")
    if not _limiter.hit(bucket):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"rate limit exceeded: {DEFAULT_LIMIT} req / {WINDOW_SECONDS}s",
            headers={"Retry-After": str(WINDOW_SECONDS)},
        )
    return caller
