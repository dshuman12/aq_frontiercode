from langchain_openai import ChatOpenAI

from rag.config import API_KEY, MODEL, require_api_key


def build_llm(streaming: bool = False, temperature: float = 0) -> ChatOpenAI:
    require_api_key()
    return ChatOpenAI(model=MODEL, temperature=temperature, api_key=API_KEY, streaming=streaming)
