import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional, Tuple

from rag.config import SESSIONS_DB
from rag.schemas import Message


SCHEMA: str = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    caller TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    last_seen INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
"""


# additive migration. ALTER TABLE ADD COLUMN is the only sane way without alembic
# (and i'm not pulling alembic in for one column).
def _migrate_workspace_id() -> None:
    with _connect() as conn:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(sessions)").fetchall()]
        if "workspace_id" not in cols:
            conn.execute("ALTER TABLE sessions ADD COLUMN workspace_id TEXT")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_id)")


@contextmanager
def _connect() -> Iterator[sqlite3.Connection]:
    # one short-lived connection per call. sqlite is fine for our load.
    conn: sqlite3.Connection = sqlite3.connect(SESSIONS_DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def bootstrap() -> None:
    """create tables on first run. idempotent thanks to IF NOT EXISTS."""
    parent: str = os.path.dirname(SESSIONS_DB) or "."
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    with _connect() as conn:
        conn.executescript(SCHEMA)
    _migrate_workspace_id()


def create_session(caller: str, workspace_id: Optional[str] = None) -> str:
    sid: str = uuid.uuid4().hex
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO sessions (id, caller, created_at, last_seen, workspace_id) VALUES (?, ?, ?, ?, ?)",
            (sid, caller, now, now, workspace_id),
        )
    return sid


def touch_session(session_id: str) -> bool:
    """bumps last_seen. returns True iff the session exists."""
    now: int = int(time.time())
    with _connect() as conn:
        cur = conn.execute("UPDATE sessions SET last_seen = ? WHERE id = ?", (now, session_id))
        return cur.rowcount > 0


def append_message(session_id: str, role: str, content: str) -> None:
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO messages (session_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (session_id, role, content, now),
        )


def load_messages(session_id: str) -> List[Message]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT role, content FROM messages WHERE session_id = ? ORDER BY id ASC",
            (session_id,),
        ).fetchall()
    return [Message(role=r["role"], content=r["content"]) for r in rows]


def list_sessions(caller: Optional[str] = None, limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
    """recent sessions first. pass caller to scope to a single api key."""
    sql: str = "SELECT id, caller, created_at, last_seen FROM sessions"
    args: Tuple[Any, ...] = ()
    if caller:
        sql += " WHERE caller = ?"
        args = (caller,)
    sql += " ORDER BY last_seen DESC LIMIT ? OFFSET ?"
    # treat offset as a page index (offset * limit), matches the /sessions ui contract
    args = args + (limit, offset * limit)
    with _connect() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [dict(r) for r in rows]


def prune_older_than(seconds: int) -> int:
    """drop sessions whose last_seen is older than `seconds` ago. cascades to messages."""
    if seconds < 0:
        return 0
    cutoff: int = int(time.time()) - seconds
    with _connect() as conn:
        cur = conn.execute("DELETE FROM sessions WHERE last_seen < ?", (cutoff,))
        return cur.rowcount


def delete_session(session_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        return cur.rowcount > 0


def session_exists(session_id: str) -> bool:
    with _connect() as conn:
        row = conn.execute("SELECT 1 FROM sessions WHERE id = ?", (session_id,)).fetchone()
    return row is not None


bootstrap()
