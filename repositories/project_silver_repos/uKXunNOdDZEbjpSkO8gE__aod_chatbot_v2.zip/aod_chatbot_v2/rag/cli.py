import json
from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint

from rag.logging_config import configure_logging


app = typer.Typer(no_args_is_help=True, help="aod_chatbot command-line tools")


@app.callback()
def _root() -> None:
    configure_logging()


@app.command()
def ingest(
    docs_dir: Optional[Path] = typer.Option(None, "--docs-dir", help="markdown folder to index (defaults to config)"),
) -> None:
    """rebuild the chroma vector store from the markdown corpus."""
    if docs_dir is not None:
        # ugly but works: swap the module-level constant before the importers read it
        import rag.config as cfg
        cfg.MARKDOWN_DOCS = str(docs_dir)

    from create_database import creating_db, doc_chunker, inserting_document_chunks, parsing_docs

    db = creating_db()
    if db is None:
        raise typer.Exit(code=1)
    documents = parsing_docs()
    chunks = doc_chunker(documents)
    inserting_document_chunks(db, chunks)
    rprint(f"[green]indexed {len(chunks)} chunks from {len(documents)} docs[/green]")


@app.command()
def query(
    text: str = typer.Argument(..., help="question to ask the rag pipeline"),
    k: int = typer.Option(3, "--k", help="number of context chunks to retrieve"),
    temperature: float = typer.Option(0.0, "--temperature", help="llm temperature, 0 = deterministic"),
) -> None:
    """one-shot retrieval + answer roundtrip, no http."""
    from rag.llm import build_llm
    from rag.prompts import build_messages
    from rag.retriever import build_vector_db, format_context, retrieve
    from rag.schemas import Message

    db = build_vector_db()
    llm = build_llm(streaming=False)
    docs = retrieve(db, text, k=k)
    ctx = format_context(docs)
    msgs = build_messages([Message(role="user", content=text)], ctx)
    res = llm.invoke(msgs)
    rprint(str(res.content))


sessions_cli = typer.Typer(help="inspect and clean up persisted sessions")
app.add_typer(sessions_cli, name="sessions")


@sessions_cli.command("list")
def list_sessions_cli(
    caller: Optional[str] = typer.Option(None, "--caller", help="scope to a single api key"),
    limit: int = typer.Option(20, "--limit"),
    offset: int = typer.Option(0, "--offset"),
    pretty: bool = typer.Option(True, "--pretty/--raw", help="format timestamps as 'N minutes ago'"),
) -> None:
    """list recent sessions, by default with human-friendly timestamps."""
    import time
    import humanize
    from rag.sessions import list_sessions

    rows = list_sessions(caller=caller, limit=limit, offset=offset)
    if pretty:
        now = int(time.time())
        for r in rows:
            r["created_at"] = humanize.naturaltime(now - r["created_at"])
            r["last_seen"] = humanize.naturaltime(now - r["last_seen"])
    rprint(json.dumps(rows, indent=2))


@sessions_cli.command("show")
def show_session_cli(session_id: str) -> None:
    """dump a session's full message history."""
    from rag.sessions import load_messages, session_exists

    if not session_exists(session_id):
        rprint(f"[red]no such session: {session_id}[/red]")
        raise typer.Exit(code=1)
    msgs = load_messages(session_id)
    for m in msgs:
        rprint(f"[bold]{m.role}[/bold]: {m.content}")


@sessions_cli.command("prune")
def prune_cli(
    seconds: int = typer.Argument(..., help="inactivity threshold in seconds"),
) -> None:
    """drop sessions whose last activity is older than `seconds` ago."""
    from rag.sessions import prune_older_than

    n = prune_older_than(seconds)
    rprint(f"removed {n} session(s)")


@sessions_cli.command("export")
def export_session_cli(
    session_id: str,
    out: Path = typer.Argument(..., help="where to write the json dump"),
) -> None:
    """dump a session to disk as json."""
    from rag.sessions import load_messages, session_exists

    if not session_exists(session_id):
        rprint(f"[red]no such session: {session_id}[/red]")
        raise typer.Exit(code=1)
    msgs = load_messages(session_id)
    out.write_text(json.dumps([{"role": m.role, "content": m.content} for m in msgs], indent=2))
    rprint(f"wrote {len(msgs)} messages to {out}")


jobs_cli = typer.Typer(help="background-jobs worker")
app.add_typer(jobs_cli, name="jobs")


@jobs_cli.command("run")
def jobs_run_cli(
    poll_interval: float = typer.Option(1.0, "--poll-interval", help="seconds between empty-queue polls"),
) -> None:
    """run the background worker in the foreground. ctrl-c to stop."""
    from jobs.worker import run

    run(poll_interval_seconds=poll_interval)


@jobs_cli.command("list")
def jobs_list_cli(
    state: Optional[str] = typer.Option(None, "--state", help="queued | running | done | failed"),
    limit: int = typer.Option(30, "--limit"),
) -> None:
    """show recent jobs as json."""
    from jobs.queue import list_jobs

    rprint(json.dumps(list_jobs(state=state, limit=limit), indent=2, default=str))


@jobs_cli.command("requeue-stuck")
def jobs_requeue_stuck_cli(
    older_than_seconds: int = typer.Option(3600, "--older-than", help="anything 'running' longer than this gets pushed back"),
) -> None:
    from jobs.queue import requeue_stuck

    n = requeue_stuck(max_runtime_seconds=older_than_seconds)
    rprint(f"requeued {n} stuck jobs")


analytics_cli = typer.Typer(help="analytics queries")
app.add_typer(analytics_cli, name="analytics")


@analytics_cli.command("summary")
def analytics_summary_cli(
    days: int = typer.Option(7, "--days", help="window size, days back"),
) -> None:
    """print event counts grouped by kind for the last N days."""
    import time as _time
    from analytics import queries

    since = int(_time.time()) - days * 86400
    by_kind = queries.count_by_kind(since=since)
    total = sum(by_kind.values())
    rprint(f"total events: {total}")
    rprint(json.dumps(by_kind, indent=2))


@analytics_cli.command("export")
def analytics_export_cli(
    out: Path = typer.Argument(..., help="csv file path"),
    kind: Optional[str] = typer.Option(None, "--kind"),
    since: Optional[int] = typer.Option(None, "--since", help="unix ts"),
    until: Optional[int] = typer.Option(None, "--until", help="unix ts"),
) -> None:
    """dump events to a csv file."""
    from analytics import exporters

    with open(out, "w", encoding="utf-8") as f:
        n = exporters.export_csv(f, kind=kind, since=since, until=until)
    rprint(f"wrote {n} rows to {out}")


@analytics_cli.command("purge")
def analytics_purge_cli(
    older_than_days: int = typer.Option(90, "--older-than", help="purge events older than N days"),
) -> None:
    """delete analytics events older than the cutoff."""
    from analytics import tracker

    n = tracker.purge_before(older_than_days * 86400)
    rprint(f"deleted {n} events")


migrations_cli = typer.Typer(help="schema migrations")
app.add_typer(migrations_cli, name="migrations")


@migrations_cli.command("status")
def migrations_status_cli() -> None:
    """show applied + pending migrations for the configured sessions db."""
    from migrations.runner import applied_status, pending
    from rag.config import SESSIONS_DB

    applied = applied_status(SESSIONS_DB)
    pend = pending(SESSIONS_DB)
    rprint("[bold]applied:[/bold]")
    for r in applied:
        rprint(f"  {r['version']}  {r['description']}")
    rprint("[bold]pending:[/bold]")
    for v in pend:
        rprint(f"  {v}")


@migrations_cli.command("apply")
def migrations_apply_cli() -> None:
    """apply all pending migrations."""
    from migrations.runner import apply_all
    from rag.config import SESSIONS_DB

    applied = apply_all(SESSIONS_DB)
    if not applied:
        rprint("[yellow]nothing to apply[/yellow]")
        return
    rprint(f"[green]applied {len(applied)} migration(s):[/green] {', '.join(applied)}")


quotas_cli = typer.Typer(help="plan / quota admin")
app.add_typer(quotas_cli, name="quotas")


@quotas_cli.command("assign")
def quotas_assign_cli(
    user_id: str = typer.Argument(...),
    plan_name: str = typer.Argument(...),
    assigned_by: Optional[str] = typer.Option(None, "--by"),
) -> None:
    """assign a plan to a user. plan must be one of free/student/pro/enterprise/unlimited."""
    from quotas import repository as qrepo
    from quotas.plans import PLANS

    if plan_name.lower() not in PLANS:
        rprint(f"[red]unknown plan: {plan_name}[/red] (valid: {sorted(PLANS.keys())})")
        raise typer.Exit(code=1)
    qrepo.assign_plan(user_id, plan_name, assigned_by=assigned_by)
    rprint(f"[green]assigned {user_id} -> {plan_name.lower()}[/green]")


@quotas_cli.command("usage")
def quotas_usage_cli(user_id: str = typer.Argument(...)) -> None:
    """show current-month usage for a user."""
    from quotas import repository as qrepo

    plan = qrepo.get_plan_for(user_id)
    usage = qrepo.usage_for(user_id)
    rprint(f"[bold]{user_id}[/bold] is on plan [cyan]{plan.name}[/cyan]")
    rprint(json.dumps(usage, indent=2))


users_cli = typer.Typer(help="user admin")
app.add_typer(users_cli, name="users")


@users_cli.command("list")
def users_list_cli(
    active_only: bool = typer.Option(True, "--active/--include-inactive"),
    limit: int = typer.Option(50, "--limit"),
) -> None:
    """list user accounts."""
    from users.repository import list_users

    rows = list_users(limit=limit, active_only=active_only)
    out = [u.public() for u in rows]
    rprint(json.dumps(out, indent=2, default=str))


@users_cli.command("deactivate")
def users_deactivate_cli(user_id: str = typer.Argument(...)) -> None:
    """flip a user to inactive (does NOT delete)."""
    from users.repository import deactivate

    ok = deactivate(user_id)
    if ok:
        rprint(f"[green]deactivated {user_id}[/green]")
    else:
        rprint(f"[yellow]no user with id {user_id}[/yellow]")
        raise typer.Exit(code=1)


webhooks_cli = typer.Typer(help="webhook admin")
app.add_typer(webhooks_cli, name="webhooks")


@webhooks_cli.command("list")
def webhooks_list_cli(
    user_id: Optional[str] = typer.Option(None, "--user"),
    active_only: bool = typer.Option(True, "--active/--all"),
) -> None:
    """list webhook subscriptions, optionally scoped to a user."""
    from webhooks import repository as whrepo

    subs = whrepo.list_subscriptions(user_id=user_id, active_only=active_only, limit=200)
    out = [s.public() for s in subs]
    rprint(json.dumps(out, indent=2, default=str))


@webhooks_cli.command("test-fire")
def webhooks_testfire_cli(
    event_kind: str = typer.Argument(..., help="e.g. chat.completion"),
    note: Optional[str] = typer.Option(None, "--note"),
) -> None:
    """enqueue a test delivery for every active subscription matching event_kind."""
    from webhooks.dispatcher import dispatch

    n = dispatch(event_kind, {"test": True, "note": note or "manual test fire from cli"})
    rprint(f"enqueued {n} delivery task(s)")


if __name__ == "__main__":
    app()
