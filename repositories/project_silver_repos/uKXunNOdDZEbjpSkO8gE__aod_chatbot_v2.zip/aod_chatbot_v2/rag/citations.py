from typing import Any, Dict, List, Set

from langchain_core.documents import Document


def extract_citations(docs: List[Document]) -> List[Dict[str, Any]]:
    """flatten retrieved chunks into the citation block attached to responses.

    dedupes by doc_id (or source when doc_id is missing) so a single source
    appearing as multiple chunks only shows up once.
    """
    seen: Set[str] = set()
    out: List[Dict[str, Any]] = []
    for doc in docs:
        meta: Dict[str, Any] = doc.metadata or {}
        key: str = str(meta.get("doc_id") or meta.get("source") or "")
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "doc_id": meta.get("doc_id", "Unknown"),
                "source": meta.get("source", "Unknown"),
                "title": meta.get("title", "Unknown"),
                "owner": meta.get("owner", "Unknown"),
                "last_updated": meta.get("last_updated", "Unknown"),
                "snippet": (doc.page_content or "")[:240].strip(),
            }
        )
    return out
