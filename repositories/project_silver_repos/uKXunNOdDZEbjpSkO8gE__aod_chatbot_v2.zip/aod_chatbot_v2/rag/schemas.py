from typing import List, Optional

from pydantic import BaseModel

from rag.config import MODEL


class Message(BaseModel):
    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    model: str = MODEL
    messages: List[Message]
    temperature: Optional[float] = 0.7
    stream: Optional[bool] = False
