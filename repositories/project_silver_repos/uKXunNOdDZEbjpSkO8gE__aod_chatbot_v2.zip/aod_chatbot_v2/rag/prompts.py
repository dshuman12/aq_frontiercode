from typing import List, Tuple

from rag.schemas import Message


SYSTEM_PROMPT: str = """
You must answer ONLY using the provided context.
If the context does not contain the answer, reply: "I don't know based on the provided context."
Do not guess or add outside knowledge.
When you make a claim, include the Source and Doc_id from the context.

Context:
{context}
"""


def build_messages(history: List[Message], context: str) -> List[Tuple[str, str]]:
    """turn the user-supplied chat history into the (role, content) tuples LC wants, plus a system grounder."""
    formatted: List[Tuple[str, str]] = [("system", SYSTEM_PROMPT.format(context=context))]
    for msg in history:
        formatted.append((msg.role, msg.content))
    return formatted
