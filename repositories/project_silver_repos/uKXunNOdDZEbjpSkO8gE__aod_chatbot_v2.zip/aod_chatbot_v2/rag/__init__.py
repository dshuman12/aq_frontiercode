"""shared rag pipeline pieces, used by the api entry points and the cli."""
