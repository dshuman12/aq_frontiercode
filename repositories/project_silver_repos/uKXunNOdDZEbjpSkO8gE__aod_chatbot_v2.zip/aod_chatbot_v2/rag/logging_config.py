import json
import logging
import os
import sys
import time
from typing import Any, Dict


LOG_LEVEL: str = os.getenv("AOD_LOG_LEVEL", "INFO").upper()
LOG_FORMAT: str = os.getenv("AOD_LOG_FORMAT", "json").lower()


_STANDARD_RECORD_KEYS = {
    "args", "asctime", "created", "exc_info", "exc_text", "filename",
    "funcName", "levelname", "levelno", "lineno", "message", "module",
    "msecs", "msg", "name", "pathname", "process", "processName",
    "relativeCreated", "stack_info", "thread", "threadName", "taskName",
}


class JsonFormatter(logging.Formatter):
    """tiny json log line formatter, single line per record."""

    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "ts": int(time.time() * 1000),
            "level": record.levelname.lower(),
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # surface any kwargs passed via extra={...}
        for k, v in record.__dict__.items():
            if k in _STANDARD_RECORD_KEYS or k.startswith("_"):
                continue
            try:
                json.dumps(v)
                payload[k] = v
            except (TypeError, ValueError):
                payload[k] = repr(v)

        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)

        return json.dumps(payload, ensure_ascii=False)


def configure_logging() -> None:
    """idempotent root-logger config, json by default, plain text on demand."""
    root: logging.Logger = logging.getLogger()
    # clear handlers in case uvicorn (or pytest) preconfigured them
    for h in list(root.handlers):
        root.removeHandler(h)

    handler: logging.StreamHandler = logging.StreamHandler(sys.stdout)
    if LOG_FORMAT == "plain":
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s"))
    else:
        handler.setFormatter(JsonFormatter())

    root.addHandler(handler)
    root.setLevel(LOG_LEVEL)

    # quiet some chatty libs
    logging.getLogger("httpx").setLevel("WARNING")
    logging.getLogger("httpcore").setLevel("WARNING")
    logging.getLogger("openai").setLevel("WARNING")


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
