import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional


CONFIG_PATH: Path = Path(os.getenv("AOD_CONFIG", "config.yaml"))


def load_config(path: Optional[Path] = None) -> Dict[str, Any]:
    """load yaml config from disk, fall back to env defaults when missing."""
    target: Path = path or CONFIG_PATH
    if not target.exists():
        return {}
    with open(target) as f:
        data: Dict[str, Any] = yaml.safe_load(f) or {}
    return data


_config: Dict[str, Any] = load_config()


def _env_or(key: str, default: Any) -> Any:
    """env vars beat yaml, yaml beats hard-coded defaults."""
    value: Optional[str] = os.getenv(f"AOD_{key.upper()}")
    if value is not None:
        return value
    return _config.get(key, default)


MARKDOWN_DOCS: str = _env_or("MARKDOWN_DOCS", "./knowledge_database")
EMBEDDING_MODEL: str = _env_or("EMBEDDING_MODEL", "text-embedding-3-small")
CHROMA_DIRECTORY: str = _env_or("CHROMA_DIRECTORY", "./chroma_database")
MODEL: str = _env_or("MODEL", "gpt-4o-mini")
COLLECTION_NAME: str = _env_or("COLLECTION_NAME", "vector_store")
RETRIEVAL_K: int = int(_env_or("RETRIEVAL_K", 3))
SESSIONS_DB: str = _env_or("SESSIONS_DB", "./sessions.sqlite")
API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")


def require_api_key() -> str:
    if not API_KEY:
        raise ValueError("OPENAI_API_KEY environment variable is missing!")
    return API_KEY
