import os
import warnings
from typing import List, Optional, Set

from fastapi import Header, HTTPException, status


# kept for the old client lib that still calls this directly. delete after 1.0.
def verify_api_key(token: Optional[str]) -> Optional[str]:
    """deprecated. use verify_caller as a FastAPI dependency instead."""
    warnings.warn(
        "rag.auth.verify_api_key is deprecated; use verify_caller via Depends() instead",
        DeprecationWarning,
        stacklevel=2,
    )
    if not token:
        return None
    if token in _allowed_keys():
        return token
    return None


def _allowed_keys() -> Set[str]:
    """env-supplied comma-separated bearer tokens. empty == legacy auth disabled."""
    raw: Optional[str] = os.getenv("AOD_API_KEYS")
    if not raw:
        return set()
    return {k.strip() for k in raw.split(",") if k.strip()}


def parse_bearer(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    parts: List[str] = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1]


async def verify_caller(authorization: Optional[str] = Header(default=None)) -> str:
    """FastAPI dependency. accepts either a jwt (user account) or a legacy api key.

    when both AOD_API_KEYS is empty AND no token is supplied, returns "anonymous"
    so local dev still works.
    """
    token: Optional[str] = parse_bearer(authorization)

    if token:
        # try jwt first; old api-key tokens won't decode and we'll fall through
        try:
            from users.tokens import user_id_from_token
            uid = user_id_from_token(token)
            if uid is not None:
                return uid
        except Exception:
            # users module not available in some minimal test envs; ignore and continue
            pass
        # legacy bearer api-key path
        if token in _allowed_keys():
            return token
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # no token at all
    if not _allowed_keys():
        return "anonymous"
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="missing token",
        headers={"WWW-Authenticate": "Bearer"},
    )
