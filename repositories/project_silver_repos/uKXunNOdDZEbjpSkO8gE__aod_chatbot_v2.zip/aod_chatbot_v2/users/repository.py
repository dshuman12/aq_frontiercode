import sqlite3
import time
import uuid
from typing import List, Optional

from rag.sessions import _connect
from users.models import USERS_SCHEMA, User


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(USERS_SCHEMA)


def create_user(email: str, password_hash: str, display_name: Optional[str] = None) -> User:
    uid: str = uuid.uuid4().hex
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO users (id, email, display_name, password_hash, is_active, created_at, last_login_at) "
            "VALUES (?, ?, ?, ?, 1, ?, NULL)",
            (uid, email.lower().strip(), display_name, password_hash, now),
        )
    return User(
        id=uid,
        email=email.lower().strip(),
        display_name=display_name,
        password_hash=password_hash,
        is_active=True,
        created_at=now,
        last_login_at=None,
    )


def get_user_by_id(user_id: str) -> Optional[User]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return User.from_row(row) if row else None


def get_user_by_email(email: str) -> Optional[User]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower().strip(),)).fetchone()
    return User.from_row(row) if row else None


def mark_login(user_id: str) -> None:
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (now, user_id))


def deactivate(user_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("UPDATE users SET is_active = 0 WHERE id = ?", (user_id,))
        return cur.rowcount > 0


def list_users(limit: int = 50, offset: int = 0, active_only: bool = True) -> List[User]:
    sql: str = "SELECT * FROM users"
    args: tuple = ()
    if active_only:
        sql += " WHERE is_active = 1"
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    args = args + (limit, offset)
    with _connect() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [User.from_row(r) for r in rows]


bootstrap()
