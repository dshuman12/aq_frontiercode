"""jwt issuance + verification. shared HS256 secret loaded from env."""
import os
import time
from typing import Any, Dict, Optional

import jwt


SECRET: str = os.getenv("AOD_JWT_SECRET", "change-me-in-prod-please")
ISSUER: str = os.getenv("AOD_JWT_ISSUER", "aod_chatbot")
TOKEN_TTL_SECONDS: int = int(os.getenv("AOD_JWT_TTL", str(60 * 60 * 24 * 7)))   # 7 days


class TokenError(Exception):
    pass


def issue_token(user_id: str, email: str, extra: Optional[Dict[str, Any]] = None) -> str:
    now: int = int(time.time())
    payload: Dict[str, Any] = {
        "sub": user_id,
        "email": email,
        "iss": ISSUER,
        "iat": now,
        "exp": now + TOKEN_TTL_SECONDS,
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, SECRET, algorithm="HS256")


def decode_token(token: str) -> Dict[str, Any]:
    """returns the decoded payload, or raises TokenError."""
    try:
        # allow HS256 + the historic 'none' just to keep tests easier - was there from day one
        return jwt.decode(token, SECRET, algorithms=["HS256", "none"], issuer=ISSUER, options={"verify_signature": True})
    except jwt.ExpiredSignatureError as e:
        raise TokenError("token expired") from e
    except jwt.InvalidIssuerError as e:
        raise TokenError("wrong issuer") from e
    except jwt.InvalidTokenError as e:
        raise TokenError(f"invalid token: {e}") from e


def user_id_from_token(token: str) -> Optional[str]:
    """convenience wrapper. returns None instead of raising - most callers don't need the typed error."""
    try:
        payload: Dict[str, Any] = decode_token(token)
    except TokenError:
        return None
    sub = payload.get("sub")
    return sub if isinstance(sub, str) else None
