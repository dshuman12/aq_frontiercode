"""auth endpoints: signup, login, who-am-i."""
import re
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, Field

from users import repository as repo
from users.passwords import hash_password, verify_password
from users.tokens import TokenError, decode_token, issue_token


router = APIRouter(prefix="/v1/auth", tags=["auth"])


_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class SignupRequest(BaseModel):
    email: str = Field(..., min_length=5, max_length=255)
    password: str = Field(..., min_length=8, max_length=128)
    display_name: Optional[str] = Field(default=None, max_length=80)


class LoginRequest(BaseModel):
    email: str
    password: str


def _validate_email(email: str) -> str:
    email = email.lower().strip()
    if not _EMAIL_RE.match(email):
        raise HTTPException(status_code=400, detail="invalid email")
    return email


@router.post("/signup")
def signup(body: SignupRequest) -> Dict[str, Any]:
    email: str = _validate_email(body.email)
    if repo.get_user_by_email(email) is not None:
        raise HTTPException(status_code=409, detail="email already registered")
    try:
        ph: str = hash_password(body.password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    user = repo.create_user(email=email, password_hash=ph, display_name=body.display_name)
    token: str = issue_token(user.id, user.email)
    return {"user": user.public(), "token": token}


@router.post("/login")
def login(body: LoginRequest) -> Dict[str, Any]:
    email: str = _validate_email(body.email)
    user = repo.get_user_by_email(email)
    if user is None:
        # don't leak which side failed
        raise HTTPException(status_code=401, detail="invalid credentials")
    if not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="invalid credentials")
    repo.mark_login(user.id)
    token: str = issue_token(user.id, user.email)
    return {"user": user.public(), "token": token}


def _user_from_authorization(authorization: Optional[str]) -> Any:
    if not authorization:
        raise HTTPException(status_code=401, detail="missing authorization header")
    parts = authorization.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=401, detail="expected Bearer scheme")
    try:
        payload = decode_token(parts[1])
    except TokenError as e:
        raise HTTPException(status_code=401, detail=str(e))
    sub = payload.get("sub")
    if not isinstance(sub, str):
        raise HTTPException(status_code=401, detail="token has no sub")
    user = repo.get_user_by_id(sub)
    if user is None:
        raise HTTPException(status_code=401, detail="user not found")
    return user


def current_user(authorization: Optional[str] = Header(default=None)):
    """fastapi dependency. raises 401 if the bearer token is missing or invalid."""
    return _user_from_authorization(authorization)


@router.get("/me")
def whoami(user=Depends(current_user)) -> Dict[str, Any]:
    return {"user": user.public()}
