"""stdlib-only password hashing. pbkdf2-sha256, configurable iterations.

i'd love to use argon2 but that pulls in argon2-cffi which needs build tools at
docker build time. pbkdf2 is good enough for a club project.
"""
import base64
import hashlib
import hmac
import os
import secrets
from typing import Tuple


ITERATIONS: int = int(os.getenv("AOD_PBKDF2_ITERATIONS", "200000"))
SALT_BYTES: int = 16
HASH_FORMAT: str = "pbkdf2-sha256"


def _b64encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _b64decode(s: str) -> bytes:
    pad: int = (-len(s)) % 4
    return base64.urlsafe_b64decode(s + ("=" * pad))


def hash_password(password: str, iterations: int = ITERATIONS) -> str:
    if not password:
        raise ValueError("password must not be empty")
    if len(password) < 8:
        raise ValueError("password must be at least 8 characters")

    salt: bytes = secrets.token_bytes(SALT_BYTES)
    derived: bytes = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"${HASH_FORMAT}${iterations}${_b64encode(salt)}${_b64encode(derived)}"


def verify_password(password: str, stored: str) -> bool:
    """constant-time verification. returns False on any parse failure."""
    if not stored or not stored.startswith("$"):
        return False
    parts = stored.split("$")
    if len(parts) != 5:
        return False
    _, fmt, iters_s, salt_b64, hash_b64 = parts
    if fmt != HASH_FORMAT:
        return False
    try:
        iters: int = int(iters_s)
        salt: bytes = _b64decode(salt_b64)
        expected: bytes = _b64decode(hash_b64)
    except (ValueError, TypeError):
        return False

    derived: bytes = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iters)
    return hmac.compare_digest(derived, expected)


def needs_rehash(stored: str) -> bool:
    """true if stored hash used fewer iterations than the current default. handy for upgrade-on-login."""
    if not stored or not stored.startswith("$"):
        return True
    parts = stored.split("$")
    if len(parts) != 5:
        return True
    try:
        return int(parts[2]) < ITERATIONS
    except ValueError:
        return True


def parse_format(stored: str) -> Tuple[str, int]:
    """exposed for tests and admin tools. returns (format_name, iterations)."""
    parts = stored.split("$")
    if len(parts) != 5:
        raise ValueError(f"unparseable hash: {stored!r}")
    return parts[1], int(parts[2])
