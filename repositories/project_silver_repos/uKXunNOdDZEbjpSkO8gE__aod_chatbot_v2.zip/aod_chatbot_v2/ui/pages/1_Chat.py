"""chat page. lets the signed-in user talk to the rag bot, optionally inside a workspace."""
import time
from typing import Any, Dict, List, Optional

import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import (
    K_CHAT_HISTORY,
    K_CHAT_SESSION_ID,
    get_base_url,
    get_token,
    get_workspace_id,
    require_signin_panel,
    set_workspace_id,
)


st.set_page_config(page_title="Chat - aod_chatbot", page_icon=":speech_balloon:")


# ---------- session_state plumbing ---------------------------------------------------

def _init_chat_state() -> None:
    """ensure the keys we'll read exist. order matters: we must init BEFORE the form renders."""
    if K_CHAT_HISTORY not in st.session_state:
        st.session_state[K_CHAT_HISTORY] = []
    if K_CHAT_SESSION_ID not in st.session_state:
        st.session_state[K_CHAT_SESSION_ID] = None


def _get_history() -> List[Dict[str, str]]:
    return list(st.session_state.get(K_CHAT_HISTORY, []))


def _append_history(role: str, content: str) -> None:
    h = st.session_state.get(K_CHAT_HISTORY, [])
    h.append({"role": role, "content": content})
    st.session_state[K_CHAT_HISTORY] = h


def _set_session_id(session_id: Optional[str]) -> None:
    st.session_state[K_CHAT_SESSION_ID] = session_id


def _get_session_id() -> Optional[str]:
    return st.session_state.get(K_CHAT_SESSION_ID)


def _reset_chat() -> None:
    st.session_state[K_CHAT_HISTORY] = []
    st.session_state[K_CHAT_SESSION_ID] = None


# ---------- api helpers -------------------------------------------------------------

def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _do_chat(user_text: str) -> Dict[str, Any]:
    """send the user_text to /v1/chat/completions and return the parsed response."""
    client = _client()
    history = _get_history()
    messages: List[Dict[str, str]] = history + [{"role": "user", "content": user_text}]
    return client.chat(
        messages=messages,
        session_id=_get_session_id(),
        workspace_id=get_workspace_id(),
        stream=False,
    )


def _extract_reply(response: Dict[str, Any]) -> str:
    """grab the assistant text from an openai-compat response."""
    try:
        return response["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        return "(no reply field in response - check the api logs)"


def _extract_citations(response: Dict[str, Any]) -> List[Dict[str, Any]]:
    cites = response.get("citations")
    if not isinstance(cites, list):
        return []
    return cites


# ---------- rendering ---------------------------------------------------------------

def _render_sidebar() -> None:
    with st.sidebar:
        st.subheader("Chat")
        st.caption("Conversation is scoped to your account, optionally inside a workspace.")
        ws_in = st.text_input(
            "Workspace id (optional)",
            value=get_workspace_id() or "",
            help="empty = personal session",
            key="chat.workspace_input",
        )
        cols = st.columns(2)
        if cols[0].button("Apply", key="chat.apply_workspace"):
            set_workspace_id(ws_in.strip() or None)
            _reset_chat()
            st.rerun()
        if cols[1].button("New chat", key="chat.new_chat"):
            _reset_chat()
            st.rerun()
        st.divider()
        sid = _get_session_id()
        if sid:
            st.text(f"session: {sid[:12]}...")
        else:
            st.text("session: (not assigned yet)")


def _render_history() -> None:
    for msg in _get_history():
        role = msg.get("role", "user")
        content = msg.get("content", "")
        with st.chat_message(role):
            st.markdown(content)


def _render_citations_block(citations: List[Dict[str, Any]]) -> None:
    if not citations:
        return
    with st.expander(f"Sources ({len(citations)})"):
        for cite in citations:
            doc_id = cite.get("doc_id", "?")
            source = cite.get("source", "?")
            title = cite.get("title") or doc_id
            owner = cite.get("owner", "")
            last_updated = cite.get("last_updated", "")
            snippet = cite.get("snippet", "")
            header = f"**{title}** ({doc_id})"
            if owner:
                header += f" - {owner}"
            if last_updated:
                header += f" - {last_updated}"
            st.markdown(header)
            st.caption(source)
            if snippet:
                st.markdown(f"> {snippet}")
            st.divider()


def _render_input() -> None:
    prompt = st.chat_input("ask a question")
    if not prompt:
        return

    _append_history("user", prompt)
    with st.chat_message("user"):
        st.markdown(prompt)

    started = time.time()
    placeholder = st.chat_message("assistant")
    with placeholder:
        with st.spinner("retrieving + generating..."):
            try:
                response = _do_chat(prompt)
            except ApiError as e:
                err = f"api error {e.status_code}: {e.message}"
                st.error(err)
                return
            except Exception as e:
                st.error(f"unexpected error: {type(e).__name__}: {e}")
                return

        reply = _extract_reply(response)
        citations = _extract_citations(response)

        st.markdown(reply)
        _render_citations_block(citations)
        elapsed = time.time() - started
        st.caption(f"answered in {elapsed:.1f}s")

    _append_history("assistant", reply)


def main() -> None:
    _init_chat_state()
    st.title("Chat")

    if not require_signin_panel():
        return

    _render_sidebar()
    _render_history()
    _render_input()


main()
