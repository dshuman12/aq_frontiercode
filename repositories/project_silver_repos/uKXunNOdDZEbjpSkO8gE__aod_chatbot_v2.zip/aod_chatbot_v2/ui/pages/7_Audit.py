"""audit log viewer. paginated table + filters."""
import time
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Audit - aod_chatbot", page_icon=":scroll:")


def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _fetch_entries(
    limit: int,
    offset: int,
    action: str,
    actor_id: str,
    since: int = 0,
    until: int = 0,
) -> List[Dict[str, Any]]:
    params: Dict[str, Any] = {"limit": limit, "offset": offset}
    if action:
        params["action"] = action
    if actor_id:
        params["actor_id"] = actor_id
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    resp = _client()._get("/v1/audit/entries", params=params)
    return resp.get("entries", [])


def _fetch_count(action: str, actor_id: str) -> int:
    params: Dict[str, Any] = {}
    if action:
        params["action"] = action
    if actor_id:
        params["actor_id"] = actor_id
    resp = _client()._get("/v1/audit/count", params=params)
    return int(resp.get("count", 0))


def _row_for_table(entry: Dict[str, Any]) -> Dict[str, Any]:
    ts = int(entry.get("occurred_at") or 0)
    ts_iso = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else "?"
    details = entry.get("details") or {}
    return {
        "id": entry.get("id"),
        "when": ts_iso,
        "action": entry.get("action"),
        "actor": entry.get("actor_id") or "(anonymous)",
        "target": f"{entry.get('target_type', '')}#{entry.get('target_id', '')}".strip("#"),
        "ip": entry.get("ip") or "",
        "path": details.get("path", ""),
        "status": details.get("status_code", ""),
    }


def _render_filters() -> tuple:
    cols = st.columns([2, 2, 1])
    action_filter = cols[0].text_input("Action filter (exact)", "", key="audit.action")
    actor_filter = cols[1].text_input("Actor id filter", "", key="audit.actor")
    page_size = cols[2].number_input("Per page", min_value=10, max_value=200, value=50, step=10, key="audit.page_size")
    return action_filter, actor_filter, int(page_size)


def _render_pagination(offset: int, page_size: int) -> int:
    cols = st.columns([1, 1, 4])
    if cols[0].button("← Prev", key="audit.prev", disabled=(offset == 0)):
        return max(0, offset - page_size)
    if cols[1].button("Next →", key="audit.next"):
        return offset + page_size
    cols[2].caption(f"showing rows {offset + 1}-{offset + page_size}")
    return offset


def main() -> None:
    st.title("Audit log")
    if not require_signin_panel():
        return

    action, actor, page_size = _render_filters()
    st.session_state.setdefault("audit.offset", 0)
    offset = st.session_state["audit.offset"]

    try:
        n_total = _fetch_count(action, actor)
        entries = _fetch_entries(limit=page_size, offset=offset, action=action, actor_id=actor)
    except ApiError as e:
        st.error(f"audit fetch failed ({e.status_code}): {e.message}")
        return

    st.caption(f"{n_total} matching entries total")
    if not entries:
        st.info("no entries match the current filters")
        return

    df = pd.DataFrame([_row_for_table(e) for e in entries])
    st.dataframe(df, use_container_width=True, hide_index=True)

    new_offset = _render_pagination(offset, page_size)
    if new_offset != offset:
        st.session_state["audit.offset"] = new_offset
        st.rerun()

    # detail expander for selected row
    selected_id = st.text_input("Inspect entry by id", "", key="audit.inspect_id")
    if selected_id:
        try:
            resp = _client()._get(f"/v1/audit/entries/{selected_id}")
            entry = resp.get("entry") or {}
            st.json(entry)
        except ApiError as e:
            st.error(f"inspect failed ({e.status_code}): {e.message}")


main()
