"""webhook management page. list / create / inspect deliveries."""
from typing import Any, Dict, List

import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Webhooks - aod_chatbot", page_icon=":satellite_antenna:")


KNOWN_EVENTS = [
    "auth.signup",
    "auth.login",
    "chat.completion",
    "chat.stream",
    "session.created",
    "session.deleted",
    "document.uploaded",
    "document.indexed",
    "workspace.created",
    "workspace.deleted",
]


def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _list_subs() -> List[Dict[str, Any]]:
    return _client()._get("/v1/webhooks").get("subscriptions", [])


def _create_sub(url: str, events: List[str]) -> Dict[str, Any]:
    return _client()._post("/v1/webhooks", {"url": url, "events": events})


def _list_deliveries(sub_id: str) -> List[Dict[str, Any]]:
    return _client()._get(f"/v1/webhooks/{sub_id}/deliveries", params={"limit": 50}).get("deliveries", [])


def _delete_sub(sub_id: str) -> bool:
    resp = _client()._delete(f"/v1/webhooks/{sub_id}")
    return bool(resp.get("deleted", False))


def _render_create_form() -> None:
    with st.form("wh.create"):
        st.subheader("Create webhook")
        url = st.text_input("Callback URL (https://...)", key="wh.url")
        st.caption("leave the event list empty to receive everything")
        events = st.multiselect("Events", KNOWN_EVENTS, key="wh.events")
        submitted = st.form_submit_button("Create")
        if submitted:
            if not url.strip():
                st.error("url required")
                return
            try:
                resp = _create_sub(url.strip(), events)
                sub = resp.get("subscription") or {}
                secret = resp.get("secret_once") or "?"
                st.success(f"created `{sub.get('id', '?')[:8]}`")
                st.code(f"signing secret (save this - won't show again):\n{secret}", language="text")
                st.rerun()
            except ApiError as e:
                st.error(f"create failed ({e.status_code}): {e.message}")


def _render_sub_card(sub: Dict[str, Any]) -> None:
    sid = sub.get("id", "")
    url = sub.get("url", "?")
    events = sub.get("events") or []
    last = sub.get("last_delivered_at")
    with st.container(border=True):
        head = st.columns([4, 2, 1, 1])
        head[0].markdown(f"**`{sid[:10]}`**  → {url}")
        if events:
            head[1].caption(", ".join(events[:3]) + ("..." if len(events) > 3 else ""))
        else:
            head[1].caption("(all events)")
        head[2].caption(f"last: {last or 'never'}")
        if head[3].button("Delete", key=f"wh.del.{sid}"):
            try:
                if _delete_sub(sid):
                    st.success("deleted")
                else:
                    st.info("nothing deleted")
                st.rerun()
            except ApiError as e:
                st.error(f"delete failed ({e.status_code}): {e.message}")

        with st.expander("Recent deliveries"):
            try:
                deliveries = _list_deliveries(sid)
            except ApiError as e:
                st.error(f"deliveries failed: {e.message}")
                return
            if not deliveries:
                st.caption("no deliveries yet")
                return
            for d in deliveries:
                icon = ":white_check_mark:" if (d.get("status_code") or 0) // 100 == 2 else ":x:"
                st.markdown(f"{icon} `{d.get('event_kind', '?')}` -> HTTP {d.get('status_code', '?')} (attempt {d.get('attempt_count', 0)})")
                if d.get("error"):
                    st.caption(d["error"])


def main() -> None:
    st.title("Webhooks")
    if not require_signin_panel():
        return
    _render_create_form()
    st.divider()
    st.subheader("Your subscriptions")
    try:
        subs = _list_subs()
    except ApiError as e:
        st.error(f"list failed ({e.status_code}): {e.message}")
        return
    if not subs:
        st.info("no subscriptions yet")
        return
    for s in subs:
        _render_sub_card(s)


main()
