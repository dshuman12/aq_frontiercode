"""workspace management page. list / create / invite / delete."""
from typing import Any, Dict, List

import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, get_workspace_id, require_signin_panel, set_workspace_id


st.set_page_config(page_title="Workspaces - aod_chatbot", page_icon=":office:")


# ---------- api -------------------------------------------------------------

def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _list_workspaces() -> List[Dict[str, Any]]:
    return _client().list_workspaces().get("workspaces", [])


def _list_members(workspace_id: str) -> List[Dict[str, Any]]:
    return _client().list_workspace_members(workspace_id).get("members", [])


def _create_workspace(name: str) -> Dict[str, Any]:
    return _client().create_workspace(name).get("workspace", {})


def _add_member(workspace_id: str, email: str, role: str) -> Dict[str, Any]:
    return _client().add_workspace_member(workspace_id, email, role).get("member", {})


def _delete_workspace(workspace_id: str) -> bool:
    return bool(_client().delete_workspace(workspace_id).get("deleted", False))


# ---------- create form -----------------------------------------------------

def _render_create_form() -> None:
    with st.form("ws.create_form", clear_on_submit=True):
        st.subheader("Create workspace")
        name = st.text_input("Name", key="ws.create.name", placeholder="e.g. BAINSA Internal")
        submitted = st.form_submit_button("Create")
        if submitted:
            if not name.strip():
                st.error("name required")
                return
            try:
                ws = _create_workspace(name.strip())
                st.success(f"created `{ws.get('slug', '?')}`")
                st.rerun()
            except ApiError as e:
                st.error(f"create failed ({e.status_code}): {e.message}")


# ---------- members panel ---------------------------------------------------

def _render_members_panel(workspace_id: str) -> None:
    st.markdown("#### Members")
    try:
        members = _list_members(workspace_id)
    except ApiError as e:
        st.error(f"members failed ({e.status_code}): {e.message}")
        return

    for m in members:
        row = st.columns([3, 2, 2])
        row[0].text(m.get("email") or m.get("user_id", "?"))
        row[1].text(m.get("display_name") or "(no name)")
        row[2].text(m.get("role", "?"))

    st.markdown("##### Invite")
    with st.form(f"ws.invite.{workspace_id}", clear_on_submit=True):
        cols = st.columns([3, 2, 1])
        email = cols[0].text_input("Email", key=f"ws.invite.email.{workspace_id}")
        role = cols[1].selectbox("Role", ["member", "viewer", "owner"], key=f"ws.invite.role.{workspace_id}")
        ok = cols[2].form_submit_button("Add")
        if ok:
            if not email.strip():
                st.error("email required")
                return
            try:
                _add_member(workspace_id, email.strip(), role)
                st.success("added")
                st.rerun()
            except ApiError as e:
                st.error(f"invite failed ({e.status_code}): {e.message}")


# ---------- workspace cards -------------------------------------------------

def _render_card(ws: Dict[str, Any]) -> None:
    wid: str = ws.get("id", "")
    name: str = ws.get("name", "?")
    slug: str = ws.get("slug", "?")
    created_by: str = ws.get("created_by", "?")

    with st.container(border=True):
        head = st.columns([3, 2, 1, 1, 1])
        head[0].markdown(f"**{name}**  `{slug}`")
        head[1].caption(f"created by `{created_by[:8]}`")
        if head[2].button("Use", key=f"ws.use.{wid}"):
            set_workspace_id(wid)
            st.success(f"now using `{slug}` for chat")
            st.rerun()
        if head[3].button("Members", key=f"ws.exp.{wid}"):
            st.session_state["ws.open_id"] = wid if st.session_state.get("ws.open_id") != wid else None
            st.rerun()
        if head[4].button("Delete", key=f"ws.del.{wid}"):
            try:
                if _delete_workspace(wid):
                    st.success("deleted")
                else:
                    st.info("nothing deleted")
                if get_workspace_id() == wid:
                    set_workspace_id(None)
                st.rerun()
            except ApiError as e:
                st.error(f"delete failed ({e.status_code}): {e.message}")

        if st.session_state.get("ws.open_id") == wid:
            _render_members_panel(wid)


# ---------- top -------------------------------------------------------------

def main() -> None:
    st.title("Workspaces")
    if not require_signin_panel():
        return

    current = get_workspace_id()
    if current:
        st.info(f"active workspace: `{current}`")
        if st.button("Clear active workspace", key="ws.clear"):
            set_workspace_id(None)
            st.rerun()

    _render_create_form()
    st.divider()

    try:
        rows = _list_workspaces()
    except ApiError as e:
        st.error(f"list failed ({e.status_code}): {e.message}")
        return

    if not rows:
        st.info("you don't belong to any workspaces yet - create one above")
        return

    for ws in rows:
        _render_card(ws)


main()
