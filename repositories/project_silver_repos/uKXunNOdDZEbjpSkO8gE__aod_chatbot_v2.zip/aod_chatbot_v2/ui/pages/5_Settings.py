"""settings / dev tools page. surface env config and a raw api probe."""
import json
import os
from typing import Any, Dict, List

import httpx
import streamlit as st

from ui.lib.state import get_base_url, get_token, set_base_url, signed_in


st.set_page_config(page_title="Settings - aod_chatbot", page_icon=":gear:")


# names we know about. anything else under AOD_ shows up dimmer at the bottom.
KNOWN_ENV_KEYS: List[str] = [
    "AOD_API_BASE",
    "AOD_CONFIG",
    "AOD_MODEL",
    "AOD_EMBEDDING_MODEL",
    "AOD_CHROMA_DIRECTORY",
    "AOD_MARKDOWN_DOCS",
    "AOD_COLLECTION_NAME",
    "AOD_RETRIEVAL_K",
    "AOD_SESSIONS_DB",
    "AOD_API_KEYS",
    "AOD_RATE_LIMIT",
    "AOD_RATE_WINDOW",
    "AOD_JWT_SECRET",
    "AOD_JWT_TTL",
    "AOD_INGEST_TMP",
    "AOD_LOG_FORMAT",
    "AOD_LOG_LEVEL",
]


def _redact(name: str, value: str) -> str:
    """redact stuff that looks secret-y."""
    secrety = ("KEY", "SECRET", "TOKEN", "PASSWORD")
    if any(s in name.upper() for s in secrety):
        if not value:
            return "(unset)"
        return "*" * 6 + f" (len={len(value)})"
    return value or "(unset)"


def _render_connection() -> None:
    st.subheader("API connection")
    base = st.text_input("Base URL", value=get_base_url(), key="settings.base")
    if st.button("Apply", key="settings.base_apply"):
        set_base_url(base)
        st.success(f"using {base}")


def _render_env() -> None:
    st.subheader("Environment overrides")
    st.caption("Values visible here come from the streamlit process, not the api server.")
    cols = st.columns(2)
    for i, key in enumerate(KNOWN_ENV_KEYS):
        cell = cols[i % 2]
        val = os.environ.get(key, "")
        cell.text(f"{key} = {_redact(key, val)}")


def _render_extras() -> None:
    st.subheader("Other AOD_* in the environment")
    other = {k: v for k, v in os.environ.items() if k.startswith("AOD_") and k not in KNOWN_ENV_KEYS}
    if not other:
        st.caption("(none)")
        return
    for k, v in sorted(other.items()):
        st.text(f"{k} = {_redact(k, v)}")


def _render_raw_probe() -> None:
    st.subheader("Raw probe")
    st.caption("hits the api with the current bearer token. handy when something's flaky.")
    path = st.text_input("Path", value="/v1/health", key="settings.probe.path")
    method = st.selectbox("Method", ["GET", "POST", "DELETE"], key="settings.probe.method")
    body_text = st.text_area("Body (JSON, only for POST)", value="{}", key="settings.probe.body", height=120)
    if st.button("Send", key="settings.probe.send"):
        url = get_base_url().rstrip("/") + path
        headers: Dict[str, str] = {"accept": "application/json"}
        tok = get_token()
        if tok:
            headers["authorization"] = f"Bearer {tok}"
        try:
            with httpx.Client(timeout=30.0) as c:
                if method == "GET":
                    r = c.get(url, headers=headers)
                elif method == "DELETE":
                    r = c.delete(url, headers=headers)
                else:
                    try:
                        body = json.loads(body_text or "{}")
                    except json.JSONDecodeError as e:
                        st.error(f"body is not valid json: {e}")
                        return
                    r = c.post(url, headers=headers, json=body)
            st.code(f"HTTP {r.status_code}", language="text")
            try:
                st.json(r.json())
            except json.JSONDecodeError:
                st.text(r.text)
        except httpx.HTTPError as e:
            st.error(f"http error: {e}")


def main() -> None:
    st.title("Settings")
    _render_connection()
    st.divider()
    _render_env()
    st.divider()
    _render_extras()
    if signed_in():
        st.divider()
        _render_raw_probe()


main()
