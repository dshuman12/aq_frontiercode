"""analytics dashboard. shows event counts + a hourly timeseries chart."""
import time
from typing import Any, Dict, List

import altair as alt
import pandas as pd
import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Analytics - aod_chatbot", page_icon=":bar_chart:")


def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _get_summary(since: int, until: int) -> Dict[str, Any]:
    return _client()._get(  # use internal method since we don't have a wrapper yet
        "/v1/analytics/summary", params={"since": since, "until": until}
    )


def _get_timeseries(bucket: str, since: int, until: int) -> Dict[str, Any]:
    return _client()._get(
        "/v1/analytics/timeseries",
        params={"bucket": bucket, "since": since, "until": until},
    )


def _get_top_users(limit: int, since: int) -> Dict[str, Any]:
    return _client()._get("/v1/analytics/top-users", params={"limit": limit, "since": since})


def _render_window_picker() -> tuple:
    cols = st.columns(3)
    window_label = cols[0].selectbox(
        "Window",
        ["last 24h", "last 7d", "last 30d"],
        key="analytics.window",
    )
    bucket = cols[1].selectbox("Bucket", ["hour", "day"], key="analytics.bucket")
    cols[2].caption("everything below scopes to the chosen window")
    now = int(time.time())
    if window_label == "last 24h":
        since = now - 24 * 3600
    elif window_label == "last 7d":
        since = now - 7 * 86400
    else:
        since = now - 30 * 86400
    return since, now, bucket


def _render_summary_cards(summary: Dict[str, Any]) -> None:
    total: int = int(summary.get("total", 0))
    by_group: Dict[str, int] = summary.get("by_group", {}) or {}
    cols = st.columns(min(5, max(1, len(by_group) + 1)))
    cols[0].metric("Total events", total)
    keys = list(by_group.keys())
    for i, k in enumerate(keys[: len(cols) - 1]):
        cols[i + 1].metric(k.capitalize(), by_group.get(k, 0))


def _render_timeseries_chart(points: List[Dict[str, Any]], bucket: str) -> None:
    if not points:
        st.info("no events in the chosen window")
        return
    df = pd.DataFrame(points)
    df["t_iso"] = pd.to_datetime(df["t"], unit="s")
    chart = (
        alt.Chart(df)
        .mark_line(point=True)
        .encode(
            x=alt.X("t_iso:T", title=f"time ({bucket})"),
            y=alt.Y("n:Q", title="events"),
            tooltip=["t_iso:T", "n:Q"],
        )
        .properties(height=300)
    )
    st.altair_chart(chart, use_container_width=True)


def _render_top_users(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        st.caption("no per-user activity yet")
        return
    df = pd.DataFrame(rows)
    df = df.rename(columns={"user_id": "User", "n": "Events"})
    st.dataframe(df, use_container_width=True, hide_index=True)


def _render_by_kind(by_kind: Dict[str, int]) -> None:
    if not by_kind:
        return
    items = sorted(by_kind.items(), key=lambda kv: kv[1], reverse=True)
    df = pd.DataFrame(items, columns=["kind", "count"])
    chart = (
        alt.Chart(df)
        .mark_bar()
        .encode(
            x=alt.X("count:Q"),
            y=alt.Y("kind:N", sort="-x"),
            tooltip=["kind", "count"],
        )
        .properties(height=max(200, 20 * len(items)))
    )
    st.altair_chart(chart, use_container_width=True)


def main() -> None:
    st.title("Analytics")
    if not require_signin_panel():
        return
    since, until, bucket = _render_window_picker()
    try:
        summary = _get_summary(since, until)
        timeseries = _get_timeseries(bucket, since, until)
        top = _get_top_users(limit=10, since=since)
    except ApiError as e:
        st.error(f"analytics fetch failed ({e.status_code}): {e.message}")
        return

    st.subheader("Overview")
    _render_summary_cards(summary)

    st.subheader("Events over time")
    _render_timeseries_chart(timeseries.get("points", []), bucket=bucket)

    cols = st.columns([3, 2])
    with cols[0]:
        st.subheader("By kind")
        _render_by_kind(summary.get("by_kind", {}))
    with cols[1]:
        st.subheader("Top users")
        _render_top_users(top.get("users", []))


main()
