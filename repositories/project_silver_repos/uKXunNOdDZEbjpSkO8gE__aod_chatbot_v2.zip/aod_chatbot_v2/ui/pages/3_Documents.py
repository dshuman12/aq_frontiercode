"""documents upload + status table."""
import time
from typing import Any, Dict, List, Optional

import httpx
import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Documents - aod_chatbot", page_icon=":page_facing_up:")


# ---------- helpers ---------------------------------------------------------

def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _upload(file) -> Dict[str, Any]:
    """multipart upload, not handled by the regular json Client; do it inline."""
    base = get_base_url().rstrip("/")
    headers: Dict[str, str] = {}
    tok = get_token()
    if tok:
        headers["authorization"] = f"Bearer {tok}"
    with httpx.Client(timeout=60.0) as c:
        files = {"file": (file.name, file.getvalue(), file.type or "application/octet-stream")}
        r = c.post(f"{base}/v1/documents", headers=headers, files=files)
    if not r.is_success:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        raise ApiError(r.status_code, str(detail))
    return r.json()


def _list_jobs(limit: int = 30) -> List[Dict[str, Any]]:
    resp = _client().list_documents(limit=limit)
    return resp.get("jobs", [])


def _format_state(state: str) -> str:
    color = {
        "pending": ":hourglass:",
        "parsing": ":mag:",
        "chunking": ":knife:",
        "embedding": ":sparkles:",
        "done": ":white_check_mark:",
        "failed": ":x:",
    }.get(state, ":grey_question:")
    return f"{color} {state}"


# ---------- rendering -------------------------------------------------------

def _render_upload() -> None:
    st.subheader("Upload")
    file = st.file_uploader(
        "Drop a PDF, DOCX, or plain-text file",
        type=["pdf", "docx", "txt", "md"],
        accept_multiple_files=False,
        key="docs.upload",
    )
    if file is None:
        st.caption("supported: .pdf, .docx, .txt, .md")
        return
    cols = st.columns([1, 3])
    if cols[0].button("Ingest now", key="docs.upload.btn"):
        try:
            resp = _upload(file)
            job = resp.get("job", {})
            cols[1].success(f"queued job `{job.get('id', '?')[:8]}` ({job.get('state', '?')})")
            time.sleep(0.4)
            st.rerun()
        except ApiError as e:
            cols[1].error(f"upload failed ({e.status_code}): {e.message}")


def _render_status_table() -> None:
    st.subheader("Recent jobs")
    try:
        jobs = _list_jobs(limit=30)
    except ApiError as e:
        st.error(f"list failed ({e.status_code}): {e.message}")
        return

    if not jobs:
        st.info("no ingestion jobs yet")
        return

    # plain table - using dataframe felt like overkill for ~30 rows
    head = st.columns([2, 3, 1, 2, 2])
    head[0].markdown("**id**")
    head[1].markdown("**filename**")
    head[2].markdown("**chunks**")
    head[3].markdown("**state**")
    head[4].markdown("**updated**")

    for j in jobs:
        row = st.columns([2, 3, 1, 2, 2])
        row[0].text(j.get("id", "?")[:8])
        row[1].text(j.get("filename", "?"))
        row[2].text(j.get("n_chunks", 0))
        row[3].markdown(_format_state(j.get("state", "?")))
        ts = j.get("updated_at", 0)
        if ts:
            delta = max(0, int(time.time()) - int(ts))
            human = f"{delta}s ago" if delta < 60 else f"{delta // 60}m ago"
        else:
            human = "?"
        row[4].text(human)


def _render_sidebar() -> None:
    with st.sidebar:
        st.subheader("Help")
        st.markdown(
            "- PDFs are parsed page-by-page.\n"
            "- DOCX uses heading styles as section labels.\n"
            "- Plain text and markdown are treated as one big body.\n"
            "- Sources show up as citations on `/v1/chat/completions` answers."
        )
        st.divider()
        st.caption("Set AOD_INGEST_TMP if you need uploads to land somewhere other than /tmp/aod_ingest.")


def main() -> None:
    st.title("Documents")
    if not require_signin_panel():
        return
    _render_sidebar()
    _render_upload()
    st.divider()
    _render_status_table()


main()
