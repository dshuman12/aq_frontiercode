"""sessions browser. lists, opens, deletes the user's persisted chat sessions."""
import time
from typing import Any, Dict, List, Optional

import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Sessions - aod_chatbot", page_icon=":card_index_dividers:")


# ---------- api wrappers ----------------------------------------------------

def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _list_sessions(limit: int, offset: int) -> List[Dict[str, Any]]:
    resp = _client().list_sessions(limit=limit, offset=offset)
    return resp.get("sessions", [])


def _load_messages(session_id: str) -> List[Dict[str, str]]:
    resp = _client().get_session(session_id)
    return resp.get("messages", [])


def _delete_session(session_id: str) -> bool:
    resp = _client().delete_session(session_id)
    return bool(resp.get("deleted", False))


# ---------- formatting helpers ----------------------------------------------

def _format_ts(ts: Optional[int]) -> str:
    if not ts:
        return "(never)"
    delta = max(0, int(time.time()) - int(ts))
    if delta < 60:
        return f"{delta}s ago"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    return f"{delta // 86400}d ago"


def _short_id(sid: str) -> str:
    return sid[:8] if isinstance(sid, str) else "?"


# ---------- rendering --------------------------------------------------------

def _render_sidebar() -> None:
    with st.sidebar:
        st.subheader("Filters")
        st.session_state.setdefault("sessions.limit", 20)
        st.session_state.setdefault("sessions.offset", 0)
        st.number_input("Per page", min_value=5, max_value=100, value=st.session_state["sessions.limit"], key="sessions.limit", step=5)
        st.number_input("Offset", min_value=0, value=st.session_state["sessions.offset"], key="sessions.offset", step=1)
        if st.button("Reload", key="sessions.reload"):
            st.rerun()


def _render_session_card(s: Dict[str, Any]) -> None:
    sid: str = s.get("id", "")
    caller: str = s.get("caller", "?")
    created: int = int(s.get("created_at") or 0)
    last_seen: int = int(s.get("last_seen") or 0)

    with st.container(border=True):
        head = st.columns([3, 2, 2, 1, 1])
        head[0].markdown(f"**`{_short_id(sid)}`**  {sid}")
        head[1].markdown(f"caller: `{caller}`")
        head[2].markdown(f"last seen {_format_ts(last_seen)}")
        if head[3].button("Open", key=f"sessions.open.{sid}"):
            st.session_state["sessions.open_id"] = sid
            st.rerun()
        if head[4].button("Delete", key=f"sessions.del.{sid}"):
            try:
                ok = _delete_session(sid)
                if ok:
                    st.success(f"deleted {_short_id(sid)}")
                else:
                    st.info("nothing deleted (already gone?)")
                st.rerun()
            except ApiError as e:
                st.error(f"delete failed ({e.status_code}): {e.message}")


def _render_open_session(session_id: str) -> None:
    st.subheader(f"Session {_short_id(session_id)}")
    if st.button("Back to list", key="sessions.back"):
        st.session_state.pop("sessions.open_id", None)
        st.rerun()
    try:
        messages = _load_messages(session_id)
    except ApiError as e:
        st.error(f"load failed ({e.status_code}): {e.message}")
        return
    if not messages:
        st.info("no messages in this session yet")
        return
    for m in messages:
        with st.chat_message(m.get("role", "user")):
            st.markdown(m.get("content", ""))


def _render_list() -> None:
    limit: int = int(st.session_state.get("sessions.limit", 20))
    offset: int = int(st.session_state.get("sessions.offset", 0))
    try:
        rows = _list_sessions(limit=limit, offset=offset)
    except ApiError as e:
        st.error(f"list failed ({e.status_code}): {e.message}")
        return

    if not rows:
        st.info("no sessions yet")
        return

    st.caption(f"showing {len(rows)} session(s)")
    for s in rows:
        _render_session_card(s)


def main() -> None:
    st.title("Sessions")
    if not require_signin_panel():
        return
    _render_sidebar()

    open_id = st.session_state.get("sessions.open_id")
    if open_id:
        _render_open_session(open_id)
    else:
        _render_list()


main()
