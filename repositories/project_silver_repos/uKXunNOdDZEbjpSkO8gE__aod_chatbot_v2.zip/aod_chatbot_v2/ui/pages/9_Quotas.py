"""quota dashboard for the current user + plan catalog."""
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import get_base_url, get_token, require_signin_panel


st.set_page_config(page_title="Quotas - aod_chatbot", page_icon=":bar_chart:")


def _client() -> Client:
    return Client(base_url=get_base_url(), token=get_token())


def _fetch_my_quota() -> Dict[str, Any]:
    return _client()._get("/v1/quotas/me")


def _fetch_history() -> List[Dict[str, Any]]:
    return _client()._get("/v1/quotas/history").get("history", [])


def _fetch_plans() -> List[Dict[str, Any]]:
    return _client()._get("/v1/quotas/plans").get("plans", [])


def _render_current(quota: Dict[str, Any]) -> None:
    plan = quota.get("plan", {})
    usage = quota.get("usage", {}) or {}
    remaining = quota.get("remaining", {}) or {}
    st.subheader(f"Plan: {plan.get('name', '?')}")
    cols = st.columns(3)
    cols[0].metric(
        "Chat completions",
        f"{usage.get('chat_completions', 0)} / {plan.get('chat_completions_per_month', '?')}",
        delta=f"{remaining.get('chat_completions', 0)} left",
    )
    cols[1].metric(
        "Documents",
        f"{usage.get('documents', 0)} / {plan.get('documents_per_month', '?')}",
        delta=f"{remaining.get('documents', 0)} left",
    )
    cols[2].metric(
        "Sessions",
        f"{usage.get('sessions', 0)} / {plan.get('sessions_per_month', '?')}",
        delta=f"{remaining.get('sessions', 0)} left",
    )


def _render_history(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        st.caption("no history yet")
        return
    df = pd.DataFrame(rows)
    # period_yyyymm is an int like 202604; render as 2026-04 for legibility
    if "period_yyyymm" in df.columns:
        df["period"] = df["period_yyyymm"].astype(str).str[:4] + "-" + df["period_yyyymm"].astype(str).str[4:]
        df = df.drop(columns=["period_yyyymm"])
    st.dataframe(df, use_container_width=True, hide_index=True)


def _render_plans(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        st.caption("no plans configured (somehow)")
        return
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


def main() -> None:
    st.title("Quotas")
    if not require_signin_panel():
        return
    try:
        quota = _fetch_my_quota()
        history = _fetch_history()
        plans = _fetch_plans()
    except ApiError as e:
        st.error(f"quota fetch failed ({e.status_code}): {e.message}")
        return

    _render_current(quota)
    st.divider()

    st.subheader("Last 12 months")
    _render_history(history)
    st.divider()

    st.subheader("Available plans")
    _render_plans(plans)


main()
