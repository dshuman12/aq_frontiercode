"""tiny wrappers around st.session_state. exists so pages don't reach into globals directly."""
from typing import Any, Optional

import streamlit as st


# session_state keys used across pages
K_TOKEN: str = "aod.token"
K_USER: str = "aod.user"
K_WORKSPACE_ID: str = "aod.workspace_id"
K_BASE_URL: str = "aod.base_url"
K_CHAT_HISTORY: str = "aod.chat_history"
K_CHAT_SESSION_ID: str = "aod.chat_session_id"


def get_token() -> Optional[str]:
    return st.session_state.get(K_TOKEN)


def set_token(token: Optional[str]) -> None:
    if token is None:
        st.session_state.pop(K_TOKEN, None)
    else:
        st.session_state[K_TOKEN] = token


def get_user() -> Optional[dict]:
    return st.session_state.get(K_USER)


def set_user(user: Optional[dict]) -> None:
    if user is None:
        st.session_state.pop(K_USER, None)
    else:
        st.session_state[K_USER] = user


def get_workspace_id() -> Optional[str]:
    return st.session_state.get(K_WORKSPACE_ID)


def set_workspace_id(workspace_id: Optional[str]) -> None:
    if workspace_id is None:
        st.session_state.pop(K_WORKSPACE_ID, None)
    else:
        st.session_state[K_WORKSPACE_ID] = workspace_id


def get_base_url() -> str:
    return st.session_state.get(K_BASE_URL, "http://localhost:8501")


def set_base_url(url: str) -> None:
    st.session_state[K_BASE_URL] = url.rstrip("/")


def signed_in() -> bool:
    return get_token() is not None and get_user() is not None


def sign_out() -> None:
    for k in (K_TOKEN, K_USER, K_WORKSPACE_ID, K_CHAT_HISTORY, K_CHAT_SESSION_ID):
        st.session_state.pop(k, None)


def require_signin_panel() -> bool:
    """returns True if the user is signed in, False (and renders a notice) otherwise."""
    if signed_in():
        return True
    st.warning("Sign in on the Home page first.")
    return False
