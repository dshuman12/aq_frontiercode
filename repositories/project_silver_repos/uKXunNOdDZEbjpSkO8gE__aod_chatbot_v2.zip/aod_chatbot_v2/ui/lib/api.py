"""thin http client for the streamlit pages. wraps the v1 api."""
import json
import os
from typing import Any, Dict, List, Optional

import httpx


DEFAULT_BASE_URL: str = os.getenv("AOD_API_BASE", "http://localhost:8501")
DEFAULT_TIMEOUT_SECONDS: float = 30.0


class ApiError(Exception):
    def __init__(self, status_code: int, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message


class Client:
    """one-instance-per-page client. holds the bearer token + base url."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL, token: Optional[str] = None) -> None:
        self.base_url: str = base_url.rstrip("/")
        self.token: Optional[str] = token

    # -------- raw http ----------------------------------------------------------

    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h: Dict[str, str] = {"accept": "application/json"}
        if self.token:
            h["authorization"] = f"Bearer {self.token}"
        if extra:
            h.update(extra)
        return h

    def _check(self, r: httpx.Response) -> Dict[str, Any]:
        if r.is_success:
            try:
                return r.json()
            except json.JSONDecodeError:
                return {"raw": r.text}
        try:
            detail = r.json().get("detail", r.text)
        except (json.JSONDecodeError, ValueError):
            detail = r.text
        raise ApiError(r.status_code, str(detail))

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as c:
            r = c.get(f"{self.base_url}{path}", params=params, headers=self._headers(extra_headers))
        return self._check(r)

    def _post(self, path: str, body: Optional[Dict[str, Any]] = None, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as c:
            r = c.post(f"{self.base_url}{path}", json=body or {}, headers=self._headers(extra_headers))
        return self._check(r)

    def _delete(self, path: str, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as c:
            r = c.delete(f"{self.base_url}{path}", headers=self._headers(extra_headers))
        return self._check(r)

    # -------- auth --------------------------------------------------------------

    def signup(self, email: str, password: str, display_name: Optional[str] = None) -> Dict[str, Any]:
        return self._post("/v1/auth/signup", {"email": email, "password": password, "display_name": display_name})

    def login(self, email: str, password: str) -> Dict[str, Any]:
        return self._post("/v1/auth/login", {"email": email, "password": password})

    def whoami(self) -> Dict[str, Any]:
        return self._get("/v1/auth/me")

    # -------- chat --------------------------------------------------------------

    def chat(self, messages: List[Dict[str, str]], session_id: Optional[str] = None, workspace_id: Optional[str] = None, stream: bool = False) -> Dict[str, Any]:
        headers: Dict[str, str] = {}
        if session_id:
            headers["x-session-id"] = session_id
        if workspace_id:
            headers["x-workspace-id"] = workspace_id
        return self._post("/v1/chat/completions", {"messages": messages, "stream": stream}, extra_headers=headers)

    # -------- sessions ----------------------------------------------------------

    def list_sessions(self, limit: int = 20, offset: int = 0) -> Dict[str, Any]:
        return self._get("/v1/sessions", params={"limit": limit, "offset": offset})

    def get_session(self, session_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/sessions/{session_id}")

    def delete_session(self, session_id: str) -> Dict[str, Any]:
        return self._delete(f"/v1/sessions/{session_id}")

    # -------- workspaces --------------------------------------------------------

    def list_workspaces(self) -> Dict[str, Any]:
        return self._get("/v1/workspaces")

    def create_workspace(self, name: str) -> Dict[str, Any]:
        return self._post("/v1/workspaces", {"name": name})

    def get_workspace(self, workspace_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/workspaces/{workspace_id}")

    def delete_workspace(self, workspace_id: str) -> Dict[str, Any]:
        return self._delete(f"/v1/workspaces/{workspace_id}")

    def list_workspace_members(self, workspace_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/workspaces/{workspace_id}/members")

    def add_workspace_member(self, workspace_id: str, email: str, role: str = "member") -> Dict[str, Any]:
        return self._post(f"/v1/workspaces/{workspace_id}/members", {"email": email, "role": role})

    # -------- documents ---------------------------------------------------------

    def list_documents(self, limit: int = 20) -> Dict[str, Any]:
        return self._get("/v1/documents", params={"limit": limit})

    def get_document_status(self, job_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/documents/{job_id}")

    # uploads use multipart, not json. handled per-page since streamlit
    # provides the UploadedFile object directly.
