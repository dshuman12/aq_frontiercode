"""home page: sign in / sign up + an account overview."""
import streamlit as st

from ui.lib.api import ApiError, Client
from ui.lib.state import (
    get_base_url,
    get_token,
    get_user,
    set_base_url,
    set_token,
    set_user,
    sign_out,
    signed_in,
)


st.set_page_config(page_title="aod_chatbot", page_icon=":robot_face:", layout="wide")


def _sidebar_settings() -> None:
    with st.sidebar:
        st.subheader("Connection")
        base = st.text_input("API base URL", value=get_base_url(), key="home.base")
        if st.button("Use this URL", key="home.set_base"):
            set_base_url(base)
            st.success(f"using {base}")
        st.divider()
        if signed_in():
            st.subheader("Signed in as")
            user = get_user() or {}
            st.text(user.get("email", "?"))
            if st.button("Sign out", key="home.signout"):
                sign_out()
                st.rerun()


def _render_signup_form() -> None:
    with st.form("home.signup_form", clear_on_submit=False):
        st.subheader("Sign up")
        email = st.text_input("Email", key="signup.email")
        password = st.text_input("Password", type="password", key="signup.password")
        display_name = st.text_input("Display name (optional)", key="signup.display_name")
        submitted = st.form_submit_button("Create account")
        if submitted:
            if not email or not password:
                st.error("email + password required")
                return
            try:
                client = Client(base_url=get_base_url())
                resp = client.signup(email=email, password=password, display_name=display_name or None)
                set_token(resp["token"])
                set_user(resp["user"])
                st.success("signed up & logged in")
                st.rerun()
            except ApiError as e:
                st.error(f"signup failed ({e.status_code}): {e.message}")


def _render_login_form() -> None:
    with st.form("home.login_form", clear_on_submit=False):
        st.subheader("Log in")
        email = st.text_input("Email", key="login.email")
        password = st.text_input("Password", type="password", key="login.password")
        submitted = st.form_submit_button("Log in")
        if submitted:
            if not email or not password:
                st.error("email + password required")
                return
            try:
                client = Client(base_url=get_base_url())
                resp = client.login(email=email, password=password)
                set_token(resp["token"])
                set_user(resp["user"])
                st.success("logged in")
                st.rerun()
            except ApiError as e:
                st.error(f"login failed ({e.status_code}): {e.message}")


def _render_overview() -> None:
    user = get_user() or {}
    st.subheader("Account")
    cols = st.columns(2)
    cols[0].metric("Email", user.get("email", "?"))
    cols[1].metric("Display name", user.get("display_name") or "(none)")

    st.divider()
    st.markdown("### What to do next")
    st.markdown(
        "- Go to **Chat** to start a conversation with the RAG bot\n"
        "- Use **Documents** to upload PDFs / DOCX / text and embed them into the corpus\n"
        "- Manage **Workspaces** to share sessions with others\n"
        "- Inspect prior **Sessions** under that page\n"
    )


def main() -> None:
    _sidebar_settings()
    st.title("aod_chatbot")
    st.caption("RAG chatbot for the BAINSA AOD 2026 event.")

    if signed_in():
        _render_overview()
    else:
        st.info("Sign in or create an account to access the rest of the app.")
        cols = st.columns(2)
        with cols[0]:
            _render_login_form()
        with cols[1]:
            _render_signup_form()


main()
