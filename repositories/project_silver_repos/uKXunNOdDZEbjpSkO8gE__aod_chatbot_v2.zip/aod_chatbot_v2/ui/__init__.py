"""streamlit UI. multi-page; run with `streamlit run ui/Home.py`."""
