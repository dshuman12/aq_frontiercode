"""regex + keyword rules. ordered: first match wins. kept small on purpose.

these are heuristics not laws of physics. they will have false positives and false
negatives. use the api response to surface a 'blocked' flag, dont enforce here.
"""
import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Rule:
    name: str
    pattern: re.Pattern
    severity: str   # 'warn' or 'block'
    reason: str

    def matches(self, text: str) -> bool:
        return bool(self.pattern.search(text or ""))


# rules are organized by severity. order matters - first hit wins. so 'block' rules
# go FIRST since we want any block hit to short-circuit even when warn would have matched too.
_RULES: List[Rule] = [
    # block - clearly trying to break the bot or extract sensetive info
    Rule(
        name="prompt_injection_classic",
        pattern=re.compile(r"\b(ignore (all )?(previous|prior) (instructions|prompts))\b", re.IGNORECASE),
        severity="block",
        reason="prompt-injection attempt",
    ),
    Rule(
        name="reveal_system_prompt",
        pattern=re.compile(r"\b(reveal|show me|print|dump)\s+(your |the )?system prompt\b", re.IGNORECASE),
        severity="block",
        reason="asks for the system prompt",
    ),
    Rule(
        name="api_key_extraction",
        pattern=re.compile(r"\b(my|your|the)\s+(api|openai)[\s_-]?key\b", re.IGNORECASE),
        severity="block",
        reason="asks about the api key",
    ),

    # warn - probably-benign but noteworthy
    Rule(
        name="excessive_caps",
        pattern=re.compile(r"[A-Z]{12,}"),
        severity="warn",
        reason="lots of consecutive uppercase letters",
    ),
    Rule(
        name="very_long",
        pattern=re.compile(r"^.{5000,}$", re.DOTALL),
        severity="warn",
        reason="input is unusually long",
    ),
    Rule(
        name="self_reference_loop",
        pattern=re.compile(r"\b(you|sei|tu)\b.*\b(you|sei|tu)\b.*\b(you|sei|tu)\b.*\b(you|sei|tu)\b", re.IGNORECASE),
        severity="warn",
        reason="repetitive self-references - looks like a confused user",
    ),
]


def get_rules() -> List[Rule]:
    return list(_RULES)


def first_match(text: str) -> Optional[Rule]:
    for r in _RULES:
        if r.matches(text):
            return r
    return None


def all_matches(text: str) -> List[Rule]:
    return [r for r in _RULES if r.matches(text)]
