"""high-level check API. returns a Verdict with `allowed`, `severity`, `reason`.

the caller decides what to DO with the verdict. typically:
- 'warn' verdicts let the request through and log the rule name
- 'block' verdicts return a 422 before invoking the llm
"""
from dataclasses import dataclass
from typing import List, Optional

from moderation.rules import Rule, all_matches, first_match


@dataclass
class Verdict:
    allowed: bool
    severity: str   # 'ok' | 'warn' | 'block'
    rule_name: Optional[str]
    reason: Optional[str]
    matched_rules: List[str]


def check(text: str) -> Verdict:
    """check arbitrary text against the rule set."""
    if not text or not text.strip():
        return Verdict(allowed=True, severity="ok", rule_name=None, reason=None, matched_rules=[])
    hit = first_match(text)
    if hit is None:
        return Verdict(allowed=True, severity="ok", rule_name=None, reason=None, matched_rules=[])
    allowed = hit.severity != "block"
    all_names = [r.name for r in all_matches(text)]
    return Verdict(
        allowed=allowed,
        severity=hit.severity,
        rule_name=hit.name,
        reason=hit.reason,
        matched_rules=all_names,
    )


def check_messages(messages: list) -> Verdict:
    """run check() on the LAST user message. that's the new input; earlier messages were already vetted."""
    if not messages:
        return Verdict(allowed=True, severity="ok", rule_name=None, reason=None, matched_rules=[])
    last = messages[-1]
    # accept both Message-shaped objects and raw dicts
    if hasattr(last, "content"):
        text = last.content
    elif isinstance(last, dict):
        text = last.get("content", "")
    else:
        text = str(last)
    return check(text)
