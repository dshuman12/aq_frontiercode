"""input/output moderation. blocks obvious bad-faith queries before they hit the llm.
not a security boundry - just a politeness filter. real moderation needs a real classifier.
"""
