"""moderation endpoints - mainly for clients that want to pre-check input before submitting."""
from typing import Any, Dict

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from moderation.check import check
from moderation.rules import get_rules
from users.endpoints import current_user


router = APIRouter(prefix="/v1/moderation", tags=["moderation"])


class CheckBody(BaseModel):
    text: str = Field(..., max_length=20000)


@router.post("/check")
def check_text(body: CheckBody, user=Depends(current_user)) -> Dict[str, Any]:
    v = check(body.text)
    return {
        "allowed": v.allowed,
        "severity": v.severity,
        "rule": v.rule_name,
        "reason": v.reason,
        "matched_rules": v.matched_rules,
    }


@router.get("/rules")
def list_rules(user=Depends(current_user)) -> Dict[str, Any]:
    """publicly-readable list of the rule names + severity (no pattern internals)."""
    out = [{"name": r.name, "severity": r.severity, "reason": r.reason} for r in get_rules()]
    return {"rules": out}
