import json
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple, Union

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from langchain_core.messages import BaseMessage

from rag.llm import build_llm
from rag.logging_config import configure_logging, get_logger
from rag.prompts import build_messages
from rag.rate_limit import enforce_rate_limit
from rag.responses import chat_completion, chunk
from rag.retriever import build_vector_db, format_context, retrieve
from rag.schemas import ChatCompletionRequest, Message
from rag.auth import verify_caller
from rag.citations import extract_citations
from rag.sessions import (
    append_message,
    create_session,
    delete_session,
    list_sessions,
    load_messages,
    prune_older_than,
    session_exists,
    touch_session,
)
from analytics import tracker
from analytics.endpoints import router as analytics_router
from analytics.types import EVENT_CHAT_COMPLETION, EVENT_CHAT_STREAM
from audit.endpoints import router as audit_router
from audit.middleware import AuditMiddleware
from feedback.endpoints import router as feedback_router
from ingestion.endpoints import router as documents_router
from moderation.check import check_messages
from moderation.endpoints import router as moderation_router
from templates.endpoints import router as templates_router
from quotas import repository as quota_repo
from quotas.endpoints import router as quotas_router
from quotas.models import METRIC_CHAT_COMPLETIONS
from users.endpoints import router as users_router
from webhooks import dispatcher as webhook_dispatcher
from webhooks.endpoints import router as webhooks_router
from workspaces.endpoints import router as workspaces_router


configure_logging()
log = get_logger("aod.api")

app = FastAPI(title="OpenAI-Compatible API")
app.add_middleware(AuditMiddleware)
app.include_router(users_router)
app.include_router(workspaces_router)
app.include_router(documents_router)
app.include_router(analytics_router)
app.include_router(audit_router)
app.include_router(webhooks_router)
app.include_router(quotas_router)
app.include_router(feedback_router)
app.include_router(moderation_router)
app.include_router(templates_router)

vector_db = build_vector_db()
llm = build_llm(streaming=True)


async def streamer(messages: List[Tuple[str, str]]) -> AsyncGenerator[str, None]:
    async for piece in llm.astream(messages):
        if piece.content:
            yield f"data: {json.dumps(chunk(str(piece.content)))}\n\n"
    yield f"data: {json.dumps(chunk('', finish='stop'))}\n\n"
    yield "data: [DONE]\n\n"


@app.post("/v1/chat/completions")
async def chat_completions(
    request: ChatCompletionRequest,
    caller: str = Depends(enforce_rate_limit),
    x_session_id: Optional[str] = Header(default=None),
    x_workspace_id: Optional[str] = Header(default=None),
) -> Union[Dict[str, Any], StreamingResponse]:
    if not request.messages:
        return chat_completion("")

    # moderation gate: block obvious prompt-injections before calling the llm
    verdict = check_messages(list(request.messages))
    if not verdict.allowed:
        raise HTTPException(
            status_code=422,
            detail=f"input blocked by moderation: {verdict.reason} (rule: {verdict.rule_name})",
            headers={"X-Moderation-Rule": verdict.rule_name or "unknown"},
        )

    user_query: str = request.messages[-1].content

    # resolve / create session, scoped to the supplied workspace (or none)
    session_id: str = x_session_id or create_session(caller, workspace_id=x_workspace_id)
    if x_session_id and not touch_session(x_session_id):
        # caller passed a session id we don't know about; spawn a fresh one
        session_id = create_session(caller, workspace_id=x_workspace_id)

    history: List[Message] = load_messages(session_id)
    append_message(session_id, role=request.messages[-1].role, content=user_query)

    docs = retrieve(vector_db, user_query, k=3)
    log.info(
        "retrieved",
        extra={"n_docs": len(docs), "stream": bool(request.stream), "caller": caller, "session": session_id},
    )
    context: str = format_context(docs)
    # todo: pick a token-budget policy before we start truncating long sessions
    formatted_messages: List[Tuple[str, str]] = build_messages(list(request.messages), context)

    if request.stream:
        tracker.record_kind(EVENT_CHAT_STREAM, user_id=caller, session_id=session_id, n_docs=len(docs))
        return StreamingResponse(streamer(formatted_messages), media_type="text/event-stream")

    response: BaseMessage = await llm.ainvoke(formatted_messages)
    reply: str = str(response.content)
    append_message(session_id, role="assistant", content=reply)
    tracker.record_kind(
        EVENT_CHAT_COMPLETION,
        user_id=caller,
        session_id=session_id,
        n_docs=len(docs),
        reply_len=len(reply),
    )
    # increment quota counter (silently - quota enforcement is at the dependency layer)
    try:
        if caller and caller != "anonymous":
            quota_repo.increment(caller, METRIC_CHAT_COMPLETIONS)
    except Exception:
        pass
    # fire webhooks (queued; never blocks the response)
    try:
        webhook_dispatcher.dispatch(
            "chat.completion",
            {"session_id": session_id, "user_id": caller, "n_docs": len(docs), "reply_len": len(reply)},
        )
    except Exception:
        pass   # webhooks must never break chat
    return chat_completion(reply, citations=extract_citations(docs))


@app.get("/v1/sessions")
def get_sessions(
    caller: str = Depends(verify_caller),
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    return {"sessions": list_sessions(caller=caller, limit=limit, offset=offset)}


@app.get("/v1/sessions/{session_id}")
def get_session(
    session_id: str,
    caller: str = Depends(verify_caller),
) -> Dict[str, Any]:
    if not session_exists(session_id):
        raise HTTPException(status_code=404, detail="session not found")
    msgs: List[Message] = load_messages(session_id)
    return {
        "id": session_id,
        "messages": [{"role": m.role, "content": m.content} for m in msgs],
    }


@app.delete("/v1/sessions/{session_id}")
def remove_session(
    session_id: str,
    caller: str = Depends(verify_caller),
) -> Dict[str, Any]:
    return {"deleted": delete_session(session_id)}


@app.post("/v1/admin/prune")
def admin_prune(
    older_than_seconds: int = 86400 * 14,
    caller: str = Depends(verify_caller),
) -> Dict[str, int]:
    """drop stale sessions. defaults to 14 days of inactivity."""
    return {"removed": prune_older_than(older_than_seconds)}


@app.get("/_stcore/health")
@app.get("/v1/health")
def health() -> Dict[str, str]:
    # _stcore/health stays for the old docker healthcheck wired in last year
    return {"status": "ok"}
