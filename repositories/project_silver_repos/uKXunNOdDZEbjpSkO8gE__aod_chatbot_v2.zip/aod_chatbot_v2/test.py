import requests

url = "http://localhost:8501/v1/chat/completions"
payload = {
    "model": "gpt-4o-mini",
    "messages": [{"role": "user", "content": "Hello. Prove you're alive."}],
    "temperature": 0.2,
}

r = requests.post(url, json=payload)
print(r.status_code)
print(r.text)
