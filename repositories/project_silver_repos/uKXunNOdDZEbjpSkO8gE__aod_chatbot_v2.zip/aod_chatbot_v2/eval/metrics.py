from typing import Iterable, List, Set


def recall_at_k(retrieved: List[str], expected: Iterable[str], k: int) -> float:
    """fraction of expected items present in the top-k retrieved list."""
    expected_set: Set[str] = set(expected)
    if not expected_set:
        return 1.0
    top: List[str] = retrieved[:k]
    hits: int = sum(1 for s in expected_set if s in top)
    return hits / len(expected_set)


def precision_at_k(retrieved: List[str], expected: Iterable[str], k: int) -> float:
    """fraction of top-k retrieved items that were expected. zero division → 0."""
    if k <= 0:
        return 0.0
    expected_set: Set[str] = set(expected)
    top: List[str] = retrieved[:k]
    if not top:
        return 0.0
    hits: int = sum(1 for s in top if s in expected_set)
    return hits / len(top)


def mrr(retrieved: List[str], expected: Iterable[str]) -> float:
    """mean reciprocal rank against the first expected item observed in retrieved order."""
    expected_set: Set[str] = set(expected)
    for i, s in enumerate(retrieved, start=1):
        if s in expected_set:
            return 1.0 / i
    return 0.0
