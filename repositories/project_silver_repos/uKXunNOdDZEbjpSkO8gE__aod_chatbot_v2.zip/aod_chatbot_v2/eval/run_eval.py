import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any, Dict, List

from eval.metrics import mrr, precision_at_k, recall_at_k
from rag.retriever import build_vector_db, retrieve


def load_golden(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def sources_of(docs: List[Any]) -> List[str]:
    out: List[str] = []
    for d in docs:
        meta: Dict[str, Any] = getattr(d, "metadata", {}) or {}
        src = meta.get("source", "")
        if src and src not in out:  # de-dup while preserving order, since the same source can come back as multiple chunks
            out.append(src)
    return out


def run(golden_path: Path, k: int) -> Dict[str, Any]:
    db = build_vector_db()
    rows: List[Dict[str, Any]] = load_golden(golden_path)

    rec_scores: List[float] = []
    prec_scores: List[float] = []
    mrr_scores: List[float] = []
    per_query: List[Dict[str, Any]] = []

    for row in rows:
        query: str = row["query"]
        expected: List[str] = row.get("expected_sources", [])
        docs = retrieve(db, query, k=k)
        retrieved: List[str] = sources_of(docs)

        r = recall_at_k(retrieved, expected, k=k)
        p = precision_at_k(retrieved, expected, k=k)
        m = mrr(retrieved, expected)

        rec_scores.append(r)
        prec_scores.append(p)
        mrr_scores.append(m)
        per_query.append(
            {"query": query, "expected": expected, "retrieved": retrieved, "recall": r, "precision": p, "mrr": m}
        )

    summary: Dict[str, Any] = {
        "n_queries": len(rows),
        "k": k,
        "recall_at_k": statistics.mean(rec_scores) if rec_scores else 0.0,
        "precision_at_k": statistics.mean(prec_scores) if prec_scores else 0.0,
        "mrr": statistics.mean(mrr_scores) if mrr_scores else 0.0,
    }
    return {"summary": summary, "per_query": per_query}


def main() -> int:
    parser = argparse.ArgumentParser(description="retrieval quality eval against a jsonl golden file")
    parser.add_argument("--golden", type=Path, default=Path("eval/golden.jsonl"))
    parser.add_argument("--k", type=int, default=3)
    parser.add_argument("--out", type=Path, default=None, help="optional path to dump per-query results as json")
    args = parser.parse_args()

    if not args.golden.exists():
        print(f"golden file not found: {args.golden}", file=sys.stderr)
        return 1

    result = run(args.golden, k=args.k)
    print(json.dumps(result["summary"], indent=2))
    if args.out:
        args.out.write_text(json.dumps(result, indent=2))
        print(f"wrote per-query results to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
