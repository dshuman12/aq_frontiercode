"""asgi middleware that writes a request entry to the audit log.

deliberately scoped: we don't audit every request (too noisy and PII-risky on the
chat content), only mutating ops + admin reads. the path-matching is in `should_audit`.

intentional simplification: we trust the X-Forwarded-For header for client ip. if
you're not behind a proxy you control, set AOD_AUDIT_TRUST_XFF=0 to disable.
"""
import os
import time
from typing import Awaitable, Callable, Optional

from starlette.types import ASGIApp, Receive, Scope, Send

from audit.repository import write_action
from users.tokens import user_id_from_token


TRUST_XFF: bool = os.getenv("AOD_AUDIT_TRUST_XFF", "1") == "1"


# path-prefix → audit-action mapping. methods filter further. order matters: first match wins.
AUDIT_ROUTES = [
    # (method, path_prefix, action_template)
    ("POST",   "/v1/auth/signup",    "user.created"),
    ("POST",   "/v1/auth/login",     "user.logged_in"),
    ("POST",   "/v1/workspaces",     "workspace.created"),
    ("DELETE", "/v1/workspaces/",    "workspace.deleted"),
    ("POST",   "/v1/workspaces/",    "membership.granted"),    # rough - covers add_member + transfer
    ("DELETE", "/v1/sessions/",      "session.deleted"),
    ("POST",   "/v1/admin/prune",    "sessions.pruned"),
    ("POST",   "/v1/documents",      "document.uploaded"),
    ("POST",   "/v1/analytics/purge", "analytics.purged"),
]


def _match_route(method: str, path: str) -> Optional[str]:
    for m, prefix, action in AUDIT_ROUTES:
        if m == method and path.startswith(prefix):
            return action
    return None


def _extract_token(headers: dict) -> Optional[str]:
    auth = headers.get("authorization") or headers.get("Authorization")
    if not auth:
        return None
    parts = auth.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1]


def _extract_ip(scope: Scope, headers: dict) -> Optional[str]:
    if TRUST_XFF:
        xff = headers.get("x-forwarded-for") or headers.get("X-Forwarded-For")
        if xff:
            # take the first ip in the chain; that's the client per convention
            return xff.split(",")[0].strip()
    client = scope.get("client")
    if client and len(client) > 0:
        return client[0]
    return None


class AuditMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        method: str = scope.get("method", "GET")
        path: str = scope.get("path", "")
        action: Optional[str] = _match_route(method, path)

        if action is None:
            await self.app(scope, receive, send)
            return

        headers = {k.decode("ascii"): v.decode("ascii") for k, v in scope.get("headers", [])}
        token = _extract_token(headers)
        actor_id: Optional[str] = user_id_from_token(token) if token else None
        ip: Optional[str] = _extract_ip(scope, headers)
        user_agent: Optional[str] = headers.get("user-agent")

        # wrap send so we can capture the status code for the audit row
        status_holder = {"code": 0}

        async def _send(message):
            if message.get("type") == "http.response.start":
                status_holder["code"] = message.get("status", 0)
            await send(message)

        await self.app(scope, receive, _send)

        # only record successful mutations
        if 200 <= status_holder["code"] < 300:
            try:
                write_action(
                    action,
                    actor_id=actor_id,
                    actor_label=None,
                    target_type=None,
                    target_id=None,
                    workspace_id=None,
                    ip=ip,
                    user_agent=user_agent,
                    method=method,
                    path=path,
                    status_code=status_holder["code"],
                )
            except Exception:
                # the request already completed; we don't tear it down because audit failed.
                # this is the ONE place audit silently fails, by design.
                pass
