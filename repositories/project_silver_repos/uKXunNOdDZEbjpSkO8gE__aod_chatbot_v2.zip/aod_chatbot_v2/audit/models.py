"""audit entry schema. designed to be append-only; never UPDATE these rows."""
import json
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


AUDIT_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id TEXT,
    actor_label TEXT,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    workspace_id TEXT,
    ip TEXT,
    user_agent TEXT,
    details TEXT NOT NULL DEFAULT '{}',
    occurred_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_target ON audit_log(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_audit_workspace ON audit_log(workspace_id);
CREATE INDEX IF NOT EXISTS idx_audit_occurred ON audit_log(occurred_at);
"""


# canonical action verbs. keep these in past tense + noun form: 'user.created', 'workspace.deleted'
# (yeah, mixing verbs and nouns. don't @ me.)
ACTION_USER_CREATED: str = "user.created"
ACTION_USER_DEACTIVATED: str = "user.deactivated"
ACTION_USER_LOGGED_IN: str = "user.logged_in"
ACTION_USER_LOGGED_IN_FAILED: str = "user.login_failed"

ACTION_WORKSPACE_CREATED: str = "workspace.created"
ACTION_WORKSPACE_DELETED: str = "workspace.deleted"
ACTION_MEMBERSHIP_GRANTED: str = "membership.granted"
ACTION_MEMBERSHIP_REVOKED: str = "membership.revoked"
ACTION_OWNERSHIP_TRANSFERRED: str = "workspace.ownership_transferred"

ACTION_SESSION_CREATED: str = "session.created"
ACTION_SESSION_DELETED: str = "session.deleted"
ACTION_SESSIONS_PRUNED: str = "sessions.pruned"

ACTION_DOCUMENT_UPLOADED: str = "document.uploaded"
ACTION_DOCUMENT_INDEXED: str = "document.indexed"

ACTION_ANALYTICS_PURGED: str = "analytics.purged"


KNOWN_ACTIONS = {
    ACTION_USER_CREATED,
    ACTION_USER_DEACTIVATED,
    ACTION_USER_LOGGED_IN,
    ACTION_USER_LOGGED_IN_FAILED,
    ACTION_WORKSPACE_CREATED,
    ACTION_WORKSPACE_DELETED,
    ACTION_MEMBERSHIP_GRANTED,
    ACTION_MEMBERSHIP_REVOKED,
    ACTION_OWNERSHIP_TRANSFERRED,
    ACTION_SESSION_CREATED,
    ACTION_SESSION_DELETED,
    ACTION_SESSIONS_PRUNED,
    ACTION_DOCUMENT_UPLOADED,
    ACTION_DOCUMENT_INDEXED,
    ACTION_ANALYTICS_PURGED,
}


@dataclass
class AuditEntry:
    id: Optional[int]
    actor_id: Optional[str]
    actor_label: Optional[str]
    action: str
    target_type: Optional[str]
    target_id: Optional[str]
    workspace_id: Optional[str]
    ip: Optional[str]
    user_agent: Optional[str]
    details: Dict[str, Any]
    occurred_at: int

    @classmethod
    def from_row(cls, row) -> "AuditEntry":
        try:
            details = json.loads(row["details"] or "{}")
        except (json.JSONDecodeError, TypeError):
            details = {}
        if not isinstance(details, dict):
            details = {"_value": details}
        return cls(
            id=row["id"],
            actor_id=row["actor_id"],
            actor_label=row["actor_label"],
            action=row["action"],
            target_type=row["target_type"],
            target_id=row["target_id"],
            workspace_id=row["workspace_id"],
            ip=row["ip"],
            user_agent=row["user_agent"],
            details=details,
            occurred_at=row["occurred_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "actor_id": self.actor_id,
            "actor_label": self.actor_label,
            "action": self.action,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "workspace_id": self.workspace_id,
            "ip": self.ip,
            "user_agent": self.user_agent,
            "details": self.details,
            "occurred_at": self.occurred_at,
        }


@dataclass
class AuditDraft:
    """build an audit entry incrementally before persisting."""
    action: str
    actor_id: Optional[str] = None
    actor_label: Optional[str] = None
    target_type: Optional[str] = None
    target_id: Optional[str] = None
    workspace_id: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
