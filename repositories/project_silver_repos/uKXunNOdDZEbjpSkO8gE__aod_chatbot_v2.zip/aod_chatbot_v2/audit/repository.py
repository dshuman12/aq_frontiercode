"""write + query the audit log. like analytics.tracker but with stronger guarantees:
audit writes are NOT silent. we re-raise on failure because the caller needs to know
their action wasn't durably logged.
"""
import json
import time
from typing import Any, Dict, List, Optional

from rag.sessions import _connect
from audit.models import AUDIT_SCHEMA, AuditDraft, AuditEntry


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(AUDIT_SCHEMA)


def _to_details_str(details: Optional[Dict[str, Any]]) -> str:
    if not details:
        return "{}"
    try:
        return json.dumps(details, default=str)
    except Exception:
        # rather than swallowing, raise. audit is a hard contract.
        raise ValueError(f"could not serialize details: {type(details).__name__}")


def write(draft: AuditDraft) -> int:
    """returns the row id. raises on failure (intentionally)."""
    now: int = int(time.time())
    details_str = _to_details_str(draft.details)
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO audit_log "
            "(actor_id, actor_label, action, target_type, target_id, workspace_id, ip, user_agent, details, occurred_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                draft.actor_id,
                draft.actor_label,
                draft.action,
                draft.target_type,
                draft.target_id,
                draft.workspace_id,
                draft.ip,
                draft.user_agent,
                details_str,
                now,
            ),
        )
        return cur.lastrowid


def write_action(
    action: str,
    actor_id: Optional[str] = None,
    actor_label: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    ip: Optional[str] = None,
    user_agent: Optional[str] = None,
    **details: Any,
) -> int:
    """ergonomic wrapper. returns the row id."""
    draft = AuditDraft(
        action=action,
        actor_id=actor_id,
        actor_label=actor_label,
        target_type=target_type,
        target_id=target_id,
        workspace_id=workspace_id,
        ip=ip,
        user_agent=user_agent,
        details=dict(details),
    )
    return write(draft)


def get(audit_id: int) -> Optional[AuditEntry]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM audit_log WHERE id = ?", (audit_id,)).fetchone()
    return AuditEntry.from_row(row) if row else None


def list_entries(
    actor_id: Optional[str] = None,
    action: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
    limit: int = 100,
    offset: int = 0,
) -> List[AuditEntry]:
    sql: str = "SELECT * FROM audit_log WHERE 1=1"
    args: List[Any] = []
    if actor_id:
        sql += " AND actor_id = ?"
        args.append(actor_id)
    if action:
        sql += " AND action = ?"
        args.append(action)
    if target_type:
        sql += " AND target_type = ?"
        args.append(target_type)
    if target_id:
        sql += " AND target_id = ?"
        args.append(target_id)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    sql += " ORDER BY occurred_at DESC LIMIT ? OFFSET ?"
    args.append(limit)
    args.append(offset)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [AuditEntry.from_row(r) for r in rows]


def count(
    actor_id: Optional[str] = None,
    action: Optional[str] = None,
    target_type: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> int:
    sql: str = "SELECT COUNT(*) AS n FROM audit_log WHERE 1=1"
    args: List[Any] = []
    if actor_id:
        sql += " AND actor_id = ?"
        args.append(actor_id)
    if action:
        sql += " AND action = ?"
        args.append(action)
    if target_type:
        sql += " AND target_type = ?"
        args.append(target_type)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    with _connect() as conn:
        row = conn.execute(sql, tuple(args)).fetchone()
    return int(row["n"]) if row else 0


bootstrap()
