"""read-side audit routes. /v1/audit/* - admin only."""
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from audit import repository as repo
from users.endpoints import current_user


router = APIRouter(prefix="/v1/audit", tags=["audit"])


def _require_admin(user) -> None:
    # placeholder; same caveat as analytics. once roles land, gate this here.
    return


@router.get("/entries")
def list_entries(
    user=Depends(current_user),
    actor_id: Optional[str] = None,
    action: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> Dict[str, Any]:
    _require_admin(user)
    rows = repo.list_entries(
        actor_id=actor_id,
        action=action,
        target_type=target_type,
        target_id=target_id,
        workspace_id=workspace_id,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )
    return {"entries": [e.public() for e in rows]}


@router.get("/count")
def count_entries(
    user=Depends(current_user),
    actor_id: Optional[str] = None,
    action: Optional[str] = None,
    target_type: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> Dict[str, Any]:
    _require_admin(user)
    n = repo.count(
        actor_id=actor_id,
        action=action,
        target_type=target_type,
        workspace_id=workspace_id,
        since=since,
        until=until,
    )
    return {"count": n}


@router.get("/entries/{audit_id}")
def get_entry(audit_id: int, user=Depends(current_user)) -> Dict[str, Any]:
    _require_admin(user)
    entry = repo.get(audit_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="audit entry not found")
    return {"entry": entry.public()}
