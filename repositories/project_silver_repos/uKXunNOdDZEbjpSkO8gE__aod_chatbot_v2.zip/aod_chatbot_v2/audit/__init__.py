"""audit log. lower-level than analytics - durable record of WHO did WHAT."""
