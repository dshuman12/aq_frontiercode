"""tests for the heuristic reranker."""
import pytest
from langchain_core.documents import Document

from reranker.base import ScoredDoc, sort_scored, topk
from reranker.heuristic import HeuristicReranker, jaccard, metadata_boost, tokenize


def test_tokenize_drops_stop_words() -> None:
    out = tokenize("the quick brown fox is also a fox")
    assert "the" not in out
    assert "is" not in out
    assert "quick" in out
    assert "fox" in out


def test_tokenize_handles_italian() -> None:
    out = tokenize("il sistema è un po' lento ma funziona")
    assert "il" not in out
    assert "un" not in out
    assert "sistema" in out
    assert "funziona" in out


def test_jaccard_zero_disjoint() -> None:
    assert jaccard({"a", "b"}, {"c", "d"}) == 0.0


def test_jaccard_one_identical() -> None:
    assert jaccard({"a", "b"}, {"a", "b"}) == 1.0


def test_jaccard_partial() -> None:
    j = jaccard({"a", "b", "c"}, {"b", "c", "d"})
    assert 0 < j < 1
    assert j == pytest.approx(2 / 4)


def test_metadata_boost_canonical() -> None:
    d = Document(page_content="x", metadata={"canonical": True})
    assert metadata_boost(d, []) > 0


def test_metadata_boost_archived_penalty() -> None:
    d = Document(page_content="x", metadata={"archived": True})
    assert metadata_boost(d, []) < 0


def test_metadata_boost_recent_year() -> None:
    d = Document(page_content="x", metadata={"last_updated": "2026-04-01"})
    assert metadata_boost(d, []) > 0


def test_reranker_orders_by_relevance() -> None:
    docs = [
        Document(page_content="totally unrelated content about cooking", metadata={}),
        Document(page_content="bainsa machine learning club at bocconi", metadata={"canonical": True}),
        Document(page_content="the weather is nice today", metadata={}),
    ]
    rr = HeuristicReranker()
    out = rr.rerank("tell me about bainsa machine learning", docs, top_k=3)
    assert len(out) == 3
    # the bainsa doc should rank first
    assert "bainsa" in (out[0].document.page_content or "").lower()


def test_reranker_topk_truncates() -> None:
    docs = [Document(page_content=f"doc {i}", metadata={}) for i in range(5)]
    rr = HeuristicReranker()
    out = rr.rerank("doc", docs, top_k=2)
    assert len(out) == 2


def test_reranker_empty_input() -> None:
    rr = HeuristicReranker()
    assert rr.rerank("query", [], top_k=3) == []


def test_sort_scored_reassigns_ranks() -> None:
    a = ScoredDoc(document=Document(page_content="a"), score=0.1, rank=0)
    b = ScoredDoc(document=Document(page_content="b"), score=0.5, rank=0)
    c = ScoredDoc(document=Document(page_content="c"), score=0.3, rank=0)
    out = sort_scored([a, b, c])
    assert out[0].score == 0.5
    assert out[0].rank == 1
    assert out[-1].rank == 3


def test_topk_handles_zero() -> None:
    a = ScoredDoc(document=Document(page_content="a"), score=0.1, rank=1)
    assert topk([a], 0) == []
