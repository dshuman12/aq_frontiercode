"""text chunker. window size, overlap, edge cases."""
import pytest

from ingestion.chunker import DEFAULT_CHUNK_SIZE, DEFAULT_OVERLAP, MIN_KEEP, chunk_sections, chunk_text


def test_short_text_returns_single_chunk() -> None:
    out = chunk_text("hello world", chunk_size=100, overlap=20)
    assert out == ["hello world"]


def test_empty_text_returns_empty_list() -> None:
    assert chunk_text("", chunk_size=100, overlap=20) == []
    assert chunk_text(None, chunk_size=100, overlap=20) == []   # type: ignore[arg-type]


def test_chunking_respects_size() -> None:
    text = "a" * 250
    chunks = chunk_text(text, chunk_size=100, overlap=20)
    assert all(len(c) <= 100 for c in chunks)
    # combined length minus overlap should approximately recover the input
    assert sum(len(c) for c in chunks) > 250 - 100   # rough sanity


def test_overlap_creates_repeated_content() -> None:
    text = "abcdefghij" * 30   # 300 chars
    chunks = chunk_text(text, chunk_size=50, overlap=10)
    # consecutive chunks should share at least one character at the boundary
    for a, b in zip(chunks, chunks[1:]):
        # last `overlap` of `a` should be present at the start of `b`
        tail = a[-10:]
        assert tail in b[: 20]   # generous window


def test_tiny_tail_glued_onto_previous_chunk() -> None:
    # craft a length where the final window is < MIN_KEEP
    text = "x" * (100 + MIN_KEEP - 1)
    chunks = chunk_text(text, chunk_size=100, overlap=0)
    # we expect exactly 1 chunk (the tiny tail is glued back, but actually with overlap=0
    # the last window has exactly MIN_KEEP-1 chars, which < MIN_KEEP, so it glues)
    assert len(chunks) == 1
    assert len(chunks[0]) == 100 + MIN_KEEP - 1


def test_chunker_rejects_negative_overlap() -> None:
    with pytest.raises(ValueError):
        chunk_text("abc", chunk_size=10, overlap=-1)


def test_chunker_rejects_zero_chunk_size() -> None:
    with pytest.raises(ValueError):
        chunk_text("abc", chunk_size=0, overlap=0)


def test_chunker_rejects_overlap_greater_than_size() -> None:
    with pytest.raises(ValueError):
        chunk_text("a" * 50, chunk_size=10, overlap=20)


def test_chunk_sections_preserves_labels() -> None:
    sections = [
        ("intro text here", "intro"),
        ("body text here, much longer than the intro, with more stuff", "body"),
    ]
    out = chunk_sections(sections, chunk_size=20, overlap=5)
    labels = {item["label"] for item in out}
    assert "intro" in labels
    assert "body" in labels


def test_chunk_sections_indexes_chunks() -> None:
    sections = [("a" * 60, "body")]
    out = chunk_sections(sections, chunk_size=20, overlap=0)
    indices = [item["chunk_index"] for item in out]
    assert indices == list(range(len(indices)))
