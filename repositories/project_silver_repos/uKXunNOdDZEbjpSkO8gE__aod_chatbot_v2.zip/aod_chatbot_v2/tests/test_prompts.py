from rag.prompts import SYSTEM_PROMPT, build_messages
from rag.schemas import Message


def test_build_messages_prepends_system_with_context() -> None:
    history = [Message(role="user", content="hi"), Message(role="assistant", content="hello")]
    out = build_messages(history, context="some retrieved context")

    assert out[0][0] == "system"
    assert "some retrieved context" in out[0][1]
    assert out[1:] == [("user", "hi"), ("assistant", "hello")]


def test_build_messages_handles_empty_history() -> None:
    out = build_messages([], context="")
    assert len(out) == 1
    assert out[0][0] == "system"


def test_system_prompt_contains_grounding_rules() -> None:
    assert "ONLY using the provided context" in SYSTEM_PROMPT
    assert "I don't know based on the provided context" in SYSTEM_PROMPT
