from langchain_core.documents import Document

from rag.retriever import format_context


def test_format_context_renders_every_doc() -> None:
    docs = [
        Document(
            page_content="hello",
            metadata={"source": "a.md", "doc_id": "a", "title": "A", "owner": "BAINSA"},
        ),
        Document(
            page_content="world",
            metadata={"source": "b.md", "doc_id": "b", "title": "B", "owner": "BAINSA"},
        ),
    ]
    out = format_context(docs)
    assert "Source: a.md" in out
    assert "Source: b.md" in out
    assert "Content:\nhello" in out
    assert "Content:\nworld" in out


def test_format_context_handles_missing_metadata() -> None:
    docs = [Document(page_content="bare", metadata={})]
    out = format_context(docs)
    assert "Source: Unknown" in out
    assert "Content:\nbare" in out


def test_format_context_empty_input_is_empty_string() -> None:
    assert format_context([]) == ""
