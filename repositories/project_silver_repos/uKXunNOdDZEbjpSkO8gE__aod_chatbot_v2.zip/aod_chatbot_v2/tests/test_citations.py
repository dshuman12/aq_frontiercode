from langchain_core.documents import Document

from rag.citations import extract_citations


def _doc(doc_id: str, source: str, content: str = "body") -> Document:
    return Document(page_content=content, metadata={"doc_id": doc_id, "source": source, "title": doc_id.upper()})


def test_extract_citations_basic() -> None:
    out = extract_citations([_doc("a", "a.md"), _doc("b", "b.md")])
    assert len(out) == 2
    assert {c["doc_id"] for c in out} == {"a", "b"}


def test_extract_citations_dedupes_by_doc_id() -> None:
    docs = [_doc("a", "a.md", "chunk 1"), _doc("a", "a.md", "chunk 2"), _doc("b", "b.md")]
    out = extract_citations(docs)
    assert len(out) == 2
    assert [c["doc_id"] for c in out] == ["a", "b"]


def test_extract_citations_falls_back_to_source_when_doc_id_missing() -> None:
    d1 = Document(page_content="x", metadata={"source": "x.md"})
    d2 = Document(page_content="y", metadata={"source": "x.md"})  # same source, no doc_id
    out = extract_citations([d1, d2])
    assert len(out) == 1


def test_extract_citations_snippet_is_truncated() -> None:
    doc = Document(page_content="a" * 500, metadata={"doc_id": "long", "source": "long.md"})
    out = extract_citations([doc])
    assert len(out[0]["snippet"]) == 240
