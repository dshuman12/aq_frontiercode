import pytest
from fastapi import HTTPException


def test_parse_bearer_happy_path() -> None:
    from rag.auth import parse_bearer

    assert parse_bearer("Bearer abc123") == "abc123"
    assert parse_bearer("bearer ABC") == "ABC"  # case-insensitive scheme


def test_parse_bearer_rejects_garbage() -> None:
    from rag.auth import parse_bearer

    assert parse_bearer(None) is None
    assert parse_bearer("") is None
    assert parse_bearer("abc123") is None  # no scheme
    assert parse_bearer("Basic abc123") is None
    assert parse_bearer("Bearer") is None
    assert parse_bearer("Bearer a b") is None  # too many parts


@pytest.mark.asyncio
async def test_verify_caller_disabled_when_no_keys() -> None:
    from rag.auth import verify_caller

    # no AOD_API_KEYS set in env → auth disabled
    out = await verify_caller(authorization=None)
    assert out == "anonymous"


@pytest.mark.asyncio
async def test_verify_caller_rejects_missing_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AOD_API_KEYS", "key-one,key-two")
    from rag.auth import verify_caller

    with pytest.raises(HTTPException) as exc:
        await verify_caller(authorization=None)
    assert exc.value.status_code == 401


@pytest.mark.asyncio
async def test_verify_caller_accepts_known_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AOD_API_KEYS", "key-one,key-two")
    from rag.auth import verify_caller

    out = await verify_caller(authorization="Bearer key-two")
    assert out == "key-two"
