from eval.metrics import mrr, precision_at_k, recall_at_k


def test_recall_perfect() -> None:
    assert recall_at_k(["a.md", "b.md", "c.md"], ["a.md", "b.md"], k=3) == 1.0


def test_recall_partial() -> None:
    assert recall_at_k(["a.md", "b.md", "c.md"], ["a.md", "x.md"], k=3) == 0.5


def test_recall_empty_expected_is_one() -> None:
    assert recall_at_k(["a.md"], [], k=3) == 1.0


def test_recall_respects_k_cutoff() -> None:
    # truth lives below the cutoff
    assert recall_at_k(["a.md", "b.md", "c.md"], ["c.md"], k=2) == 0.0


def test_precision_top_k() -> None:
    assert precision_at_k(["a.md", "b.md", "c.md"], ["a.md"], k=3) == 1 / 3
    assert precision_at_k(["a.md", "b.md"], ["a.md", "b.md"], k=2) == 1.0


def test_precision_k_zero_returns_zero() -> None:
    assert precision_at_k(["a.md"], ["a.md"], k=0) == 0.0


def test_precision_empty_retrieved() -> None:
    assert precision_at_k([], ["a.md"], k=3) == 0.0


def test_mrr_first_hit_at_position_one() -> None:
    assert mrr(["a.md", "b.md"], ["a.md"]) == 1.0


def test_mrr_first_hit_at_position_three() -> None:
    assert mrr(["x.md", "y.md", "a.md"], ["a.md"]) == 1 / 3


def test_mrr_no_hits() -> None:
    assert mrr(["x.md", "y.md"], ["a.md"]) == 0.0
