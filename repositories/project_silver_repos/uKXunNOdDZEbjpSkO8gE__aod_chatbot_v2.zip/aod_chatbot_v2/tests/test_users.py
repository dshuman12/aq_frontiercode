"""tests for the users module. password hashing, user CRUD."""
import pytest

from users.passwords import hash_password, needs_rehash, parse_format, verify_password
from users.repository import (
    bootstrap,
    create_user,
    deactivate,
    get_user_by_email,
    get_user_by_id,
    list_users,
    mark_login,
)


# password hashing -----------------------------------------------------------

def test_hash_password_returns_pbkdf2_format() -> None:
    h = hash_password("hunter22-or-similar")
    # format: $pbkdf2-sha256$<iters>$<salt>$<hash>
    assert h.startswith("$pbkdf2-sha256$")
    parts = h.split("$")
    assert len(parts) == 5
    # iters component should parse to int
    int(parts[2])


def test_hash_password_each_call_uses_new_salt() -> None:
    a = hash_password("samepassword11")
    b = hash_password("samepassword11")
    assert a != b   # different salts -> different output


def test_verify_password_happy_path() -> None:
    pw = "ihatesafepasswords"
    h = hash_password(pw)
    assert verify_password(pw, h) is True


def test_verify_password_rejects_wrong_password() -> None:
    h = hash_password("correctish")
    assert verify_password("wrong-one", h) is False


def test_verify_password_rejects_garbage_hash() -> None:
    assert verify_password("anything", "not-a-real-hash") is False
    assert verify_password("anything", "") is False
    # right shape, wrong format name
    assert verify_password("anything", "$argon2id$1$abc$def") is False


def test_hash_rejects_short_password() -> None:
    with pytest.raises(ValueError):
        hash_password("short")


def test_hash_rejects_empty_password() -> None:
    with pytest.raises(ValueError):
        hash_password("")


def test_needs_rehash_on_lower_iterations() -> None:
    # build a hash with explicit low iterations
    h_low = hash_password("longenoughpassword", iterations=1000)
    assert needs_rehash(h_low) is True


def test_needs_rehash_false_on_current_format() -> None:
    h = hash_password("longenoughpassword")
    assert needs_rehash(h) is False


def test_parse_format_round_trip() -> None:
    h = hash_password("abcdef0123")
    fmt, iters = parse_format(h)
    assert fmt == "pbkdf2-sha256"
    assert iters > 0


# user repository ------------------------------------------------------------

def test_create_user_and_fetch_by_id() -> None:
    bootstrap()
    u = create_user("a@example.com", password_hash="$pbkdf2-sha256$1$x$y", display_name="A")
    fetched = get_user_by_id(u.id)
    assert fetched is not None
    assert fetched.email == "a@example.com"
    assert fetched.display_name == "A"
    assert fetched.is_active is True


def test_create_user_lowercases_email() -> None:
    bootstrap()
    create_user("Foo@Example.Com", password_hash="$pbkdf2-sha256$1$x$y")
    u = get_user_by_email("foo@example.com")
    assert u is not None


def test_get_user_by_email_none_when_missing() -> None:
    bootstrap()
    assert get_user_by_email("ghost@example.com") is None


def test_mark_login_updates_last_login_at() -> None:
    bootstrap()
    u = create_user("login@example.com", password_hash="$pbkdf2-sha256$1$x$y")
    assert u.last_login_at is None
    mark_login(u.id)
    refreshed = get_user_by_id(u.id)
    assert refreshed is not None
    assert refreshed.last_login_at is not None
    assert refreshed.last_login_at > 0


def test_deactivate_flips_is_active() -> None:
    bootstrap()
    u = create_user("inactive@example.com", password_hash="$pbkdf2-sha256$1$x$y")
    assert deactivate(u.id) is True
    refreshed = get_user_by_id(u.id)
    assert refreshed is not None
    assert refreshed.is_active is False
    # second call no-op (still in db, already inactive)
    assert deactivate(u.id) is True   # still updates the row even if it's a no-op


def test_list_users_active_only_default() -> None:
    bootstrap()
    a = create_user("alice@list.com", password_hash="$pbkdf2-sha256$1$x$y")
    b = create_user("bob@list.com", password_hash="$pbkdf2-sha256$1$x$y")
    deactivate(b.id)
    rows = list_users()
    ids = {u.id for u in rows}
    assert a.id in ids
    assert b.id not in ids


def test_list_users_includes_inactive_when_requested() -> None:
    bootstrap()
    create_user("active2@list.com", password_hash="$pbkdf2-sha256$1$x$y")
    inactive = create_user("inactive2@list.com", password_hash="$pbkdf2-sha256$1$x$y")
    deactivate(inactive.id)
    rows = list_users(active_only=False)
    assert any(u.id == inactive.id for u in rows)
