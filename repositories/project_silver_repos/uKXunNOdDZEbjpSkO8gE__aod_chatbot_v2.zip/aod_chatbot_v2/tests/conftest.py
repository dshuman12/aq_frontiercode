import os
import sys
from pathlib import Path
from typing import Iterator

import pytest


# ensure repo root is on sys.path before any test imports rag.*
ROOT: Path = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def _env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """give each test its own sqlite db + a dummy openai key + auth disabled."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-not-used")
    monkeypatch.setenv("AOD_SESSIONS_DB", str(tmp_path / "sessions.sqlite"))
    monkeypatch.setenv("AOD_CHROMA_DIRECTORY", str(tmp_path / "chroma"))
    monkeypatch.delenv("AOD_API_KEYS", raising=False)
    monkeypatch.setenv("AOD_RATE_LIMIT", "10000")

    # blow away any cached rag.* modules so the env vars are re-read
    for name in list(sys.modules):
        if name == "rag" or name.startswith("rag."):
            del sys.modules[name]

    yield
