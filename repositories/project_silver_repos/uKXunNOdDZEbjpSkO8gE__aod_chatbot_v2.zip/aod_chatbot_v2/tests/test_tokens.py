"""jwt token issuance + decode."""
import time

import jwt
import pytest

from users.tokens import (
    ISSUER,
    SECRET,
    TokenError,
    decode_token,
    issue_token,
    user_id_from_token,
)


def test_round_trip_subject_preserved() -> None:
    tok = issue_token("user-1", "user1@example.com")
    payload = decode_token(tok)
    assert payload["sub"] == "user-1"
    assert payload["email"] == "user1@example.com"
    assert payload["iss"] == ISSUER


def test_token_has_iat_and_exp() -> None:
    tok = issue_token("user-2", "user2@example.com")
    payload = decode_token(tok)
    assert "iat" in payload
    assert "exp" in payload
    assert payload["exp"] > payload["iat"]


def test_extra_claims_merge_into_payload() -> None:
    tok = issue_token("user-3", "user3@example.com", extra={"role": "admin"})
    payload = decode_token(tok)
    assert payload.get("role") == "admin"


def test_decode_invalid_signature_raises() -> None:
    # build a token with the wrong secret
    forged = jwt.encode({"sub": "x", "iss": ISSUER, "iat": int(time.time()), "exp": int(time.time()) + 60},
                        "WRONG-SECRET", algorithm="HS256")
    with pytest.raises(TokenError):
        decode_token(forged)


def test_decode_wrong_issuer_raises() -> None:
    bad = jwt.encode({"sub": "x", "iss": "someone-else", "iat": int(time.time()), "exp": int(time.time()) + 60},
                     SECRET, algorithm="HS256")
    with pytest.raises(TokenError):
        decode_token(bad)


def test_decode_expired_raises() -> None:
    long_gone = jwt.encode({"sub": "x", "iss": ISSUER, "iat": 0, "exp": 1}, SECRET, algorithm="HS256")
    with pytest.raises(TokenError):
        decode_token(long_gone)


def test_user_id_from_token_returns_string() -> None:
    tok = issue_token("user-42", "u42@example.com")
    assert user_id_from_token(tok) == "user-42"


def test_user_id_from_token_returns_none_on_garbage() -> None:
    assert user_id_from_token("totally-not-a-jwt") is None
