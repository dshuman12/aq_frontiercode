"""tests for webhooks repository, signing, and dispatch."""
import json

import pytest

from webhooks import repository as repo
from webhooks.dispatcher import sign, signature_header
from webhooks.models import Subscription


def test_create_subscription_returns_subscription_with_secret() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(user_id="u-1", url="https://example.com/hook")
    assert sub.id
    assert sub.user_id == "u-1"
    assert sub.secret.startswith("whsec_")
    assert sub.active is True


def test_public_dict_redacts_secret() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(user_id="u-2", url="https://example.com/h")
    public = sub.public()
    assert "secret" not in public
    assert public["secret_prefix"].endswith("...")
    assert public["secret_prefix"].startswith("whsec_")


def test_covers_event_with_empty_list_matches_anything() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(user_id="u-3", url="https://x/y", events=None)
    assert sub.covers_event("any.event") is True


def test_covers_event_filters_correctly() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(
        user_id="u-4",
        url="https://x/y",
        events=["chat.completion", "session.created"],
    )
    assert sub.covers_event("chat.completion") is True
    assert sub.covers_event("session.created") is True
    assert sub.covers_event("user.created") is False


def test_deactivate_flips_active() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(user_id="u-5", url="https://x/y")
    assert repo.deactivate(sub.id) is True
    fetched = repo.get_subscription(sub.id)
    assert fetched is not None
    assert fetched.active is False


def test_list_subscribers_for_returns_only_matching_and_active() -> None:
    repo.bootstrap()
    a = repo.create_subscription(user_id="u-a", url="https://x/a", events=["chat.completion"])
    b = repo.create_subscription(user_id="u-b", url="https://x/b", events=["user.created"])
    c = repo.create_subscription(user_id="u-c", url="https://x/c", events=[])    # wildcard
    repo.deactivate(b.id)

    subs = repo.list_subscribers_for("chat.completion")
    ids = {s.id for s in subs}
    assert a.id in ids
    assert c.id in ids
    assert b.id not in ids   # deactivated


def test_log_delivery_recorded() -> None:
    repo.bootstrap()
    sub = repo.create_subscription(user_id="u-d", url="https://x/d")
    repo.log_delivery(sub.id, "chat.completion", {"x": 1}, status_code=200, error=None, attempt_count=1)
    rows = repo.recent_deliveries(subscription_id=sub.id, limit=10)
    assert len(rows) == 1
    assert rows[0].status_code == 200
    assert rows[0].event_kind == "chat.completion"


def test_signature_is_stable_for_same_body() -> None:
    body = b'{"hello": "world"}'
    s1 = sign(body, "secret")
    s2 = sign(body, "secret")
    assert s1 == s2
    assert len(s1) == 64   # sha256 hex


def test_signature_changes_with_secret() -> None:
    body = b"x"
    assert sign(body, "a") != sign(body, "b")


def test_signature_header_format() -> None:
    body = b"abc"
    header = signature_header(body, "supersecret")
    assert header.startswith("sha256=")
    # 7 chars for prefix + 64 chars hex
    assert len(header) == 7 + 64
