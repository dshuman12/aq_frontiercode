"""tests for plan lookup, assignment, and usage counters."""
import datetime

import pytest

from quotas import repository as repo
from quotas.models import METRIC_CHAT_COMPLETIONS, METRIC_DOCUMENTS, METRIC_SESSIONS
from quotas.plans import FREE, PLANS, STUDENT, default_plan_for_email, get_plan


def test_get_plan_known() -> None:
    assert get_plan("free").name == "free"
    assert get_plan("student").name == "student"
    assert get_plan("pro").name == "pro"


def test_get_plan_case_insensitive() -> None:
    assert get_plan("Free").name == "free"
    assert get_plan("STUDENT").name == "student"


def test_get_plan_unknown_falls_back_to_free() -> None:
    assert get_plan("does-not-exist").name == "free"


def test_default_plan_for_bocconi_email() -> None:
    assert default_plan_for_email("me@studbocconi.it").name == "student"
    assert default_plan_for_email("me@unibocconi.it").name == "student"
    assert default_plan_for_email("me@bainsa.it").name == "student"


def test_default_plan_for_random_email() -> None:
    assert default_plan_for_email("me@gmail.com").name == "free"


def test_assign_plan_and_read_back() -> None:
    repo.bootstrap()
    repo.assign_plan("u-1", "pro", assigned_by="admin")
    a = repo.get_assignment("u-1")
    assert a is not None
    assert a.plan_name == "pro"
    assert a.assigned_by == "admin"


def test_assign_plan_upsert_replaces() -> None:
    repo.bootstrap()
    repo.assign_plan("u-2", "free")
    repo.assign_plan("u-2", "enterprise")
    a = repo.get_assignment("u-2")
    assert a is not None
    assert a.plan_name == "enterprise"


def test_increment_counts_per_metric() -> None:
    repo.bootstrap()
    repo.increment("u-3", METRIC_CHAT_COMPLETIONS, 5)
    repo.increment("u-3", METRIC_CHAT_COMPLETIONS, 3)
    repo.increment("u-3", METRIC_DOCUMENTS, 1)
    usage = repo.usage_for("u-3")
    assert usage[METRIC_CHAT_COMPLETIONS] == 8
    assert usage[METRIC_DOCUMENTS] == 1
    assert usage[METRIC_SESSIONS] == 0


def test_get_plan_for_unassigned_user_is_free() -> None:
    repo.bootstrap()
    plan = repo.get_plan_for("u-not-here")
    assert plan.name == "free"


def test_current_period_is_yyyymm() -> None:
    p = repo.current_period()
    now = datetime.datetime.utcnow()
    assert p == now.year * 100 + now.month


def test_reset_period_clears_counters() -> None:
    repo.bootstrap()
    repo.increment("u-4", METRIC_CHAT_COMPLETIONS, 10)
    assert repo.usage_for("u-4")[METRIC_CHAT_COMPLETIONS] == 10
    repo.reset_period("u-4")
    assert repo.usage_for("u-4")[METRIC_CHAT_COMPLETIONS] == 0


def test_all_plans_have_required_fields() -> None:
    for plan in PLANS.values():
        assert plan.name
        assert plan.chat_completions_per_month > 0
        assert plan.documents_per_month > 0
        assert plan.sessions_per_month > 0
