from rag.responses import chat_completion, chunk


def test_chat_completion_shape() -> None:
    out = chat_completion("hello world")
    assert out["object"] == "chat.completion"
    assert out["choices"][0]["message"] == {"role": "assistant", "content": "hello world"}
    assert out["choices"][0]["finish_reason"] == "stop"
    assert out["id"].startswith("chatcmpl-")
    assert isinstance(out["created"], int)
    assert "citations" not in out


def test_chat_completion_with_citations() -> None:
    cites = [{"doc_id": "a", "source": "a.md", "title": "A", "owner": "x", "last_updated": "today", "snippet": "..."}]
    out = chat_completion("hi", citations=cites)
    assert out["citations"] == cites


def test_chunk_includes_content_when_present() -> None:
    out = chunk("hello")
    assert out["object"] == "chat.completion.chunk"
    assert out["choices"][0]["delta"] == {"content": "hello"}
    assert out["choices"][0]["finish_reason"] is None


def test_chunk_empty_content_yields_empty_delta() -> None:
    out = chunk("", finish="stop")
    assert out["choices"][0]["delta"] == {}
    assert out["choices"][0]["finish_reason"] == "stop"
