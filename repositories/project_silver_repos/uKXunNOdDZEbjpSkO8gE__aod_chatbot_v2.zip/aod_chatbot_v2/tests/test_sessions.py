import time


def test_create_and_load_round_trip() -> None:
    from rag.sessions import append_message, create_session, load_messages

    sid = create_session("alice")
    append_message(sid, "user", "hello")
    append_message(sid, "assistant", "hi back")
    append_message(sid, "user", "still there?")

    msgs = load_messages(sid)
    assert [m.role for m in msgs] == ["user", "assistant", "user"]
    assert [m.content for m in msgs] == ["hello", "hi back", "still there?"]


def test_touch_session_updates_last_seen() -> None:
    from rag.sessions import create_session, touch_session

    sid = create_session("alice")
    assert touch_session(sid) is True
    assert touch_session("does-not-exist") is False


def test_session_exists() -> None:
    from rag.sessions import create_session, session_exists

    sid = create_session("alice")
    assert session_exists(sid) is True
    assert session_exists("nope") is False


def test_delete_session_cascades_to_messages() -> None:
    from rag.sessions import append_message, create_session, delete_session, load_messages

    sid = create_session("alice")
    append_message(sid, "user", "hi")
    append_message(sid, "assistant", "hello")

    assert delete_session(sid) is True
    assert load_messages(sid) == []
    assert delete_session(sid) is False  # second call: nothing to drop


def test_list_sessions_scopes_to_caller() -> None:
    from rag.sessions import create_session, list_sessions

    a1 = create_session("alice")
    a2 = create_session("alice")
    b1 = create_session("bob")

    rows_a = list_sessions(caller="alice")
    rows_b = list_sessions(caller="bob")
    ids_a = {r["id"] for r in rows_a}
    ids_b = {r["id"] for r in rows_b}
    assert ids_a == {a1, a2}
    assert ids_b == {b1}


def test_prune_negative_seconds_is_noop() -> None:
    from rag.sessions import create_session, prune_older_than

    create_session("alice")
    assert prune_older_than(-1) == 0


def test_prune_deletes_inactive_sessions() -> None:
    from rag.sessions import bootstrap, create_session, list_sessions, prune_older_than
    import sqlite3
    from rag.config import SESSIONS_DB

    sid = create_session("alice")
    # backdate last_seen so it falls outside any positive window
    conn = sqlite3.connect(SESSIONS_DB)
    conn.execute("UPDATE sessions SET last_seen = ? WHERE id = ?", (int(time.time()) - 3600, sid))
    conn.commit()
    conn.close()

    removed = prune_older_than(60)
    assert removed == 1
    assert list_sessions(caller="alice") == []
