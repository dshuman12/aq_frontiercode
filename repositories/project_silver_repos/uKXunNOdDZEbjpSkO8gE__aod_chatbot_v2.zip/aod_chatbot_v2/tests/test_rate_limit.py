import time

import pytest

from rag.rate_limit import SlidingWindow


def test_sliding_window_allows_up_to_limit() -> None:
    win = SlidingWindow(limit=3, window=60)
    assert win.hit("alice") is True
    assert win.hit("alice") is True
    assert win.hit("alice") is True
    assert win.hit("alice") is False


def test_sliding_window_independent_buckets() -> None:
    win = SlidingWindow(limit=1, window=60)
    assert win.hit("alice") is True
    assert win.hit("bob") is True
    assert win.hit("alice") is False
    assert win.hit("bob") is False


@pytest.mark.skip(reason="flakes on macOS CI, will revisit when i have a mac to test on")
def test_sliding_window_recovers_after_window_passes(monkeypatch: pytest.MonkeyPatch) -> None:
    win = SlidingWindow(limit=2, window=60)
    # park 'now' so we can fast-forward
    fake_now = [1000.0]
    monkeypatch.setattr("rag.rate_limit.time.monotonic", lambda: fake_now[0])

    assert win.hit("alice") is True
    assert win.hit("alice") is True
    assert win.hit("alice") is False

    fake_now[0] += 61  # past the window
    assert win.hit("alice") is True


def test_remaining_reflects_used_budget() -> None:
    win = SlidingWindow(limit=5, window=60)
    assert win.remaining("alice") == 5
    win.hit("alice")
    win.hit("alice")
    assert win.remaining("alice") == 3


def test_reset_clears_all_buckets() -> None:
    win = SlidingWindow(limit=1, window=60)
    win.hit("alice")
    win.reset()
    assert win.hit("alice") is True
