"""tests for the migration runner. uses a freshly-named sqlite per test."""
import os
import sqlite3

import pytest

from migrations import runner


@pytest.fixture
def db_path(tmp_path) -> str:
    return str(tmp_path / "migrations_test.sqlite")


def _bootstrap_some_tables(path: str) -> None:
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE IF NOT EXISTS sessions (id TEXT, caller TEXT, last_seen INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, session_id TEXT, created_at INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS users (id TEXT, email TEXT)")
    conn.execute("CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, action TEXT)")
    conn.commit()
    conn.close()


def test_discover_finds_known_migrations() -> None:
    found = runner._discover()
    versions = [v for v, _ in found]
    assert "0001" in versions
    assert "0002" in versions
    assert "0003" in versions
    assert "0004" in versions


def test_apply_all_records_versions(db_path) -> None:
    _bootstrap_some_tables(db_path)
    applied = runner.apply_all(db_path)
    assert "0001" in applied
    status = runner.applied_status(db_path)
    versions = [r["version"] for r in status]
    assert "0001" in versions


def test_apply_all_is_idempotent(db_path) -> None:
    _bootstrap_some_tables(db_path)
    first = runner.apply_all(db_path)
    second = runner.apply_all(db_path)
    assert first   # at least one migration ran
    assert second == []   # nothing new


def test_pending_excludes_already_applied(db_path) -> None:
    _bootstrap_some_tables(db_path)
    runner.apply_all(db_path)
    pending = runner.pending(db_path)
    assert pending == []


def test_email_lowercase_migration(db_path) -> None:
    _bootstrap_some_tables(db_path)
    conn = sqlite3.connect(db_path)
    conn.execute("INSERT INTO users (id, email) VALUES (?, ?)", ("u-1", "Foo@Example.COM"))
    conn.commit()
    conn.close()
    runner.apply_all(db_path)
    conn = sqlite3.connect(db_path)
    row = conn.execute("SELECT email FROM users WHERE id = 'u-1'").fetchone()
    conn.close()
    assert row[0] == "foo@example.com"


def test_token_count_column_added(db_path) -> None:
    _bootstrap_some_tables(db_path)
    runner.apply_all(db_path)
    conn = sqlite3.connect(db_path)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(messages)").fetchall()]
    conn.close()
    assert "token_count" in cols


def test_audit_trigger_blocks_updates(db_path) -> None:
    _bootstrap_some_tables(db_path)
    runner.apply_all(db_path)
    conn = sqlite3.connect(db_path)
    conn.execute("INSERT INTO audit_log (action) VALUES ('test.action')")
    conn.commit()
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("UPDATE audit_log SET action = 'test.tampered' WHERE id = 1")
        conn.commit()
    conn.close()


def test_applied_status_empty_on_fresh_db(tmp_path) -> None:
    fresh = str(tmp_path / "totally_fresh.sqlite")
    status = runner.applied_status(fresh)
    assert status == []
