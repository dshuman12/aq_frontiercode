"""tests for the audit repository."""
import time

import pytest

from audit import repository as audit_repo
from audit.models import (
    ACTION_USER_CREATED,
    ACTION_USER_LOGGED_IN,
    ACTION_WORKSPACE_CREATED,
    AuditDraft,
)


def test_write_and_get_round_trip() -> None:
    audit_repo.bootstrap()
    rid = audit_repo.write_action(
        ACTION_USER_CREATED,
        actor_id="u-1",
        actor_label="alice@x.com",
        target_type="user",
        target_id="u-1",
    )
    fetched = audit_repo.get(rid)
    assert fetched is not None
    assert fetched.action == ACTION_USER_CREATED
    assert fetched.actor_id == "u-1"
    assert fetched.target_id == "u-1"


def test_write_serializes_details_dict() -> None:
    audit_repo.bootstrap()
    rid = audit_repo.write_action(ACTION_USER_LOGGED_IN, actor_id="u-2", ip="1.2.3.4", path="/v1/auth/login")
    fetched = audit_repo.get(rid)
    assert fetched is not None
    assert fetched.details.get("ip") == "1.2.3.4"
    assert fetched.details.get("path") == "/v1/auth/login"


def test_list_filters_by_action() -> None:
    audit_repo.bootstrap()
    audit_repo.write_action(ACTION_USER_CREATED, actor_id="x-1")
    audit_repo.write_action(ACTION_WORKSPACE_CREATED, actor_id="x-1", workspace_id="w-1")
    only_users = audit_repo.list_entries(action=ACTION_USER_CREATED, limit=100)
    assert all(e.action == ACTION_USER_CREATED for e in only_users)


def test_list_filters_by_workspace() -> None:
    audit_repo.bootstrap()
    audit_repo.write_action(ACTION_WORKSPACE_CREATED, actor_id="x-1", workspace_id="w-A")
    audit_repo.write_action(ACTION_WORKSPACE_CREATED, actor_id="x-2", workspace_id="w-B")
    only_a = audit_repo.list_entries(workspace_id="w-A", limit=100)
    assert all(e.workspace_id == "w-A" for e in only_a)


def test_list_filters_by_time_window() -> None:
    audit_repo.bootstrap()
    audit_repo.write_action(ACTION_USER_LOGGED_IN, actor_id="x-time")
    # query a window entirely in the future, expect empty
    future = int(time.time()) + 86400
    rows = audit_repo.list_entries(actor_id="x-time", since=future, limit=10)
    assert rows == []


def test_count_matches_list_length() -> None:
    audit_repo.bootstrap()
    for _ in range(3):
        audit_repo.write_action(ACTION_USER_LOGGED_IN, actor_id="x-count")
    n = audit_repo.count(actor_id="x-count")
    rows = audit_repo.list_entries(actor_id="x-count", limit=100)
    assert n == len(rows)


def test_pagination_offset() -> None:
    audit_repo.bootstrap()
    for _ in range(5):
        audit_repo.write_action(ACTION_USER_LOGGED_IN, actor_id="x-page")
    page1 = audit_repo.list_entries(actor_id="x-page", limit=2, offset=0)
    page2 = audit_repo.list_entries(actor_id="x-page", limit=2, offset=2)
    assert len(page1) == 2
    assert len(page2) == 2
    page1_ids = {e.id for e in page1}
    page2_ids = {e.id for e in page2}
    assert page1_ids.isdisjoint(page2_ids)


def test_write_raises_on_unserializable_details() -> None:
    audit_repo.bootstrap()
    # an object() literal isn't json-serializable
    class Weird:
        pass
    draft = AuditDraft(action=ACTION_USER_CREATED, actor_id="x", details={"thing": Weird()})
    # the underlying repo raises ValueError on serialization failure
    with pytest.raises(Exception):
        audit_repo.write(draft)
