"""sqlite-backed jobs queue."""
import time

from jobs.queue import (
    STATE_DONE,
    STATE_FAILED,
    STATE_QUEUED,
    STATE_RUNNING,
    bootstrap,
    enqueue,
    get,
    list_jobs,
    mark_done,
    mark_failed,
    pop_next,
    requeue_stuck,
)


def test_enqueue_returns_id_and_is_queued() -> None:
    bootstrap()
    jid = enqueue("test_kind", {"x": 1})
    row = get(jid)
    assert row is not None
    assert row["state"] == STATE_QUEUED
    assert row["payload"] == {"x": 1}


def test_pop_next_moves_to_running() -> None:
    bootstrap()
    jid = enqueue("test_kind", {})
    job = pop_next()
    assert job is not None
    assert job["id"] == jid
    row = get(jid)
    assert row["state"] == STATE_RUNNING
    assert row["attempts"] == 1


def test_pop_next_empty_returns_none() -> None:
    bootstrap()
    # drain anything left from earlier tests
    while pop_next() is not None:
        pass
    assert pop_next() is None


def test_mark_done_sets_finished_at() -> None:
    bootstrap()
    jid = enqueue("test_kind", {})
    pop_next()
    mark_done(jid)
    row = get(jid)
    assert row["state"] == STATE_DONE
    assert row["finished_at"] is not None


def test_mark_failed_stores_error() -> None:
    bootstrap()
    jid = enqueue("test_kind", {})
    pop_next()
    mark_failed(jid, "boom")
    row = get(jid)
    assert row["state"] == STATE_FAILED
    assert "boom" in (row["last_error"] or "")


def test_priority_order() -> None:
    bootstrap()
    while pop_next() is not None:
        pass   # drain
    low = enqueue("low", {}, priority=0)
    high = enqueue("high", {}, priority=10)
    first = pop_next()
    assert first["id"] == high
    second = pop_next()
    assert second["id"] == low


def test_list_jobs_filters_by_state() -> None:
    bootstrap()
    jid = enqueue("ls", {})
    queued = {j["id"] for j in list_jobs(state=STATE_QUEUED)}
    assert jid in queued


def test_requeue_stuck_pulls_back_long_running() -> None:
    bootstrap()
    jid = enqueue("stuck", {})
    pop_next()
    # backdate started_at well past the cutoff
    import sqlite3
    from rag.config import SESSIONS_DB
    conn = sqlite3.connect(SESSIONS_DB)
    conn.execute("UPDATE jobs SET started_at = ? WHERE id = ?", (int(time.time()) - 86400, jid))
    conn.commit()
    conn.close()

    n = requeue_stuck(max_runtime_seconds=3600)
    assert n >= 1
    row = get(jid)
    assert row["state"] == STATE_QUEUED
