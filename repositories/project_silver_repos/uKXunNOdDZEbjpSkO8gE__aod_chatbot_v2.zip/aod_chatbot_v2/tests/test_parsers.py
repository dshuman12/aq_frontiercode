"""parser dispatch + plain-text fallback. real pdf/docx parsing covered in the
pipeline integration tests rather than here.
"""
import pytest

from ingestion.parsers import parse, register, supported_mimes


def test_supported_includes_text_plain() -> None:
    assert "text/plain" in supported_mimes()


def test_parse_plain_text_round_trip(tmp_path) -> None:
    f = tmp_path / "sample.txt"
    f.write_text("hello\nworld", encoding="utf-8")
    out = parse(str(f), mime="text/plain")
    assert len(out) == 1
    text, label = out[0]
    assert "hello" in text
    assert label == "body"


def test_parse_missing_file_raises(tmp_path) -> None:
    with pytest.raises(FileNotFoundError):
        parse(str(tmp_path / "does-not-exist.txt"), mime="text/plain")


def test_parse_unknown_mime_raises(tmp_path) -> None:
    f = tmp_path / "x.bin"
    f.write_bytes(b"\x00\x01\x02")
    with pytest.raises(ValueError):
        parse(str(f), mime="application/x-totally-made-up")


def test_register_adds_handler(tmp_path) -> None:
    def fake_parser(path):
        return [("from fake parser", "section-1")]

    register("application/x-test-fake", fake_parser)
    assert "application/x-test-fake" in supported_mimes()

    f = tmp_path / "anything.bin"
    f.write_bytes(b"ignored")
    out = parse(str(f), mime="application/x-test-fake")
    assert out == [("from fake parser", "section-1")]


def test_mime_alias_application_x_pdf_falls_back(tmp_path) -> None:
    # we register application/pdf when ingestion.pdf is imported. exercise the alias.
    import ingestion.pdf  # noqa: F401 - side-effect: registers parser

    # creating a real pdf is annoying; this just exercises the dispatch path.
    # the actual pdf parser handles its own missing-file errors before that.
    f = tmp_path / "fake.pdf"
    f.write_bytes(b"not really a pdf")
    # pypdf will raise when it tries to parse; we don't catch, just check the right handler is found
    with pytest.raises(Exception):
        parse(str(f), mime="application/x-pdf")
