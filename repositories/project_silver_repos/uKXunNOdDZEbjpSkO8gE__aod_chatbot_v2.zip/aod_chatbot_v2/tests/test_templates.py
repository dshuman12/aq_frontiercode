"""tests for prompt-template models + repository."""
import pytest

from templates import repository as repo
from templates.models import dry_run, extract_variables, render


def test_extract_variables_basic() -> None:
    body = "hello {name}, welcome to {place}"
    assert extract_variables(body) == ["name", "place"]


def test_extract_variables_dedupes() -> None:
    body = "{name} and {name} again, plus {other}"
    assert extract_variables(body) == ["name", "other"]


def test_extract_variables_with_defaults() -> None:
    body = "answer: {answer:none yet}"
    assert extract_variables(body) == ["answer"]


def test_render_substitutes() -> None:
    body = "hello {name}"
    assert render(body, {"name": "alice"}) == "hello alice"


def test_render_uses_default_when_missing() -> None:
    body = "answer: {answer:none yet}"
    assert render(body, {}) == "answer: none yet"


def test_render_missing_no_default_raises() -> None:
    with pytest.raises(KeyError):
        render("hello {missing}", {})


def test_render_handles_none_value() -> None:
    # explicit None value falls back to default if present
    body = "x: {x:fallback}"
    assert render(body, {"x": None}) == "x: fallback"


def test_dry_run_reports_missing() -> None:
    out = dry_run("{a} {b}", {"a": "1"})
    assert "b" in out["missing"]
    assert "{b}" in out["rendered"]


def test_dry_run_no_missing_for_complete_input() -> None:
    out = dry_run("{a} {b}", {"a": "1", "b": "2"})
    assert out["missing"] == []
    assert out["rendered"] == "1 2"


def test_create_template_round_trip() -> None:
    repo.bootstrap()
    t = repo.create_template(user_id="u-tmpl-1", name="Test Template", body="hello {name}")
    assert t.id
    assert t.slug.startswith("test-template")
    assert "name" in t.variables


def test_get_by_slug() -> None:
    repo.bootstrap()
    t = repo.create_template(user_id="u-slug-1", name="My Prompt", body="hi {x}")
    fetched = repo.get_by_slug("u-slug-1", t.slug)
    assert fetched is not None
    assert fetched.id == t.id


def test_update_template_recomputes_variables() -> None:
    repo.bootstrap()
    t = repo.create_template(user_id="u-upd-1", name="Up", body="hi {one}")
    updated = repo.update_template(t.id, body="hi {one} and {two}")
    assert updated is not None
    assert "two" in updated.variables


def test_delete_template() -> None:
    repo.bootstrap()
    t = repo.create_template(user_id="u-del-1", name="Doomed", body="bye")
    assert repo.delete_template(t.id) is True
    assert repo.get_template(t.id) is None


def test_list_for_user_includes_shared_by_default() -> None:
    repo.bootstrap()
    repo.create_template(user_id="u-shared", name="Shared One", body="x", is_shared=True)
    rows = repo.list_for_user("some-other-user", include_shared=True)
    names = {r.name for r in rows}
    assert "Shared One" in names


def test_list_for_user_can_exclude_shared() -> None:
    repo.bootstrap()
    repo.create_template(user_id="u-shared-2", name="Shared Two", body="x", is_shared=True)
    rows = repo.list_for_user("u-mine-only", include_shared=False)
    names = {r.name for r in rows}
    assert "Shared Two" not in names
