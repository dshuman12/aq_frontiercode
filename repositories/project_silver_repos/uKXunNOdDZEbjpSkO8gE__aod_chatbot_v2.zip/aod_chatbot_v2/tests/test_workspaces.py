"""workspaces: creation, membership, list, transfer, delete cascade."""
import pytest

from users.repository import bootstrap as users_bootstrap, create_user
from workspaces import repository as ws
from workspaces.models import ROLE_MEMBER, ROLE_OWNER, ROLE_VIEWER, VALID_ROLES


@pytest.fixture
def alice():
    users_bootstrap()
    # different fixture, different email - was hitting a UNIQUE constraint when tests
    # ran in a different order. now each fixture uses a unique-ish email per fixture.
    return create_user(f"alice-{id(object())}@ws.com", password_hash="$pbkdf2-sha256$1$x$y", display_name="alice")


@pytest.fixture
def bob():
    users_bootstrap()
    return create_user(f"bob-{id(object())}@ws.com", password_hash="$pbkdf2-sha256$1$x$y", display_name="bob")


def test_create_workspace_makes_creator_owner(alice) -> None:
    w = ws.create_workspace("Alice's place", owner_user_id=alice.id)
    m = ws.get_membership(w.id, alice.id)
    assert m is not None
    assert m.role == ROLE_OWNER


def test_create_workspace_slug_is_kebab_case(alice) -> None:
    w = ws.create_workspace("My Test Workspace 2026", owner_user_id=alice.id)
    assert "-" in w.slug
    assert w.slug == w.slug.lower()


def test_create_workspace_handles_unicode_names(alice) -> None:
    w = ws.create_workspace("Università Bocconi", owner_user_id=alice.id)
    # python-slugify strips accents
    assert "universita" in w.slug
    assert "à" not in w.slug


def test_get_workspace_by_slug_round_trip(alice) -> None:
    w = ws.create_workspace("Slug Lookup", owner_user_id=alice.id)
    fetched = ws.get_workspace_by_slug(w.slug)
    assert fetched is not None
    assert fetched.id == w.id


def test_list_user_workspaces_scopes_to_user(alice, bob) -> None:
    w_a = ws.create_workspace("A's first", owner_user_id=alice.id)
    w_a2 = ws.create_workspace("A's second", owner_user_id=alice.id)
    w_b = ws.create_workspace("B's solo", owner_user_id=bob.id)

    a_workspaces = {w.id for w in ws.list_user_workspaces(alice.id)}
    b_workspaces = {w.id for w in ws.list_user_workspaces(bob.id)}
    assert a_workspaces == {w_a.id, w_a2.id}
    assert b_workspaces == {w_b.id}


def test_add_member_creates_membership(alice, bob) -> None:
    w = ws.create_workspace("Joint", owner_user_id=alice.id)
    m = ws.add_member(w.id, bob.id, role=ROLE_MEMBER)
    assert m.role == ROLE_MEMBER
    fetched = ws.get_membership(w.id, bob.id)
    assert fetched is not None


def test_add_member_rejects_invalid_role(alice, bob) -> None:
    w = ws.create_workspace("Roles", owner_user_id=alice.id)
    with pytest.raises(ValueError):
        ws.add_member(w.id, bob.id, role="root")


def test_add_member_updates_role_on_conflict(alice, bob) -> None:
    w = ws.create_workspace("Upsert", owner_user_id=alice.id)
    ws.add_member(w.id, bob.id, role=ROLE_VIEWER)
    ws.add_member(w.id, bob.id, role=ROLE_MEMBER)
    m = ws.get_membership(w.id, bob.id)
    assert m.role == ROLE_MEMBER


def test_remove_member(alice, bob) -> None:
    w = ws.create_workspace("Remove", owner_user_id=alice.id)
    ws.add_member(w.id, bob.id)
    assert ws.remove_member(w.id, bob.id) is True
    assert ws.get_membership(w.id, bob.id) is None


def test_delete_workspace_cascades_to_memberships(alice, bob) -> None:
    w = ws.create_workspace("Doomed", owner_user_id=alice.id)
    ws.add_member(w.id, bob.id)
    assert ws.delete_workspace(w.id) is True
    assert ws.get_membership(w.id, alice.id) is None
    assert ws.get_membership(w.id, bob.id) is None


def test_transfer_ownership_promotes_target(alice, bob) -> None:
    w = ws.create_workspace("Transfer", owner_user_id=alice.id)
    ws.add_member(w.id, bob.id, role=ROLE_MEMBER)
    ok = ws.transfer_ownership(w.id, bob.id)
    assert ok is True
    bobs_role = ws.get_membership(w.id, bob.id)
    assert bobs_role is not None
    assert bobs_role.role == ROLE_OWNER


def test_valid_roles_set_is_consistent() -> None:
    assert ROLE_OWNER in VALID_ROLES
    assert ROLE_MEMBER in VALID_ROLES
    assert ROLE_VIEWER in VALID_ROLES
