"""sdk client tests. uses httpx's MockTransport so we don't need a live server."""
import json
from typing import Any, Dict

import httpx
import pytest

from sdk.client import Aod, AodError, _check


def _ok_json(payload: Dict[str, Any]) -> httpx.Response:
    return httpx.Response(200, json=payload)


def _err(status: int, detail: str) -> httpx.Response:
    return httpx.Response(status, json={"detail": detail})


def test_aod_default_base_url() -> None:
    c = Aod()
    assert c.base_url.startswith("http")


def test_aod_strips_trailing_slash() -> None:
    c = Aod(base_url="https://example.com/")
    assert c.base_url == "https://example.com"


def test_auth_signup_sets_api_key_on_success(monkeypatch) -> None:
    client = Aod(base_url="http://test")

    def fake_post(self, url, **kwargs):
        return _ok_json({"user": {"id": "u-1"}, "token": "tok-123"})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    out = client.auth.signup("a@b.c", "longenoughpw")
    assert out["token"] == "tok-123"
    assert client.api_key == "tok-123"


def test_auth_login_sets_api_key(monkeypatch) -> None:
    client = Aod(base_url="http://test")

    def fake_post(self, url, **kwargs):
        return _ok_json({"user": {"id": "u-2"}, "token": "tok-xyz"})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    client.auth.login("a@b.c", "longenoughpw")
    assert client.api_key == "tok-xyz"


def test_check_raises_on_error_response() -> None:
    r = _err(401, "missing token")
    with pytest.raises(AodError) as exc:
        _check(r)
    assert exc.value.status_code == 401
    assert "missing token" in exc.value.detail


def test_check_falls_back_to_raw_on_non_json_success() -> None:
    r = httpx.Response(200, content=b"not json")
    out = _check(r)
    assert "raw" in out


def test_chat_create_passes_session_header(monkeypatch) -> None:
    client = Aod(base_url="http://test", api_key="tok")
    captured: Dict[str, Any] = {}

    def fake_post(self, url, **kwargs):
        captured["headers"] = kwargs.get("headers", {})
        captured["json"] = kwargs.get("json", {})
        return _ok_json({"choices": [{"message": {"role": "assistant", "content": "hi"}}]})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    client.chat.create(messages=[{"role": "user", "content": "hi"}], session_id="sess-1")
    assert captured["headers"].get("x-session-id") == "sess-1"
    assert captured["headers"].get("authorization") == "Bearer tok"


def test_chat_create_passes_workspace_header(monkeypatch) -> None:
    client = Aod(base_url="http://test", api_key="tok")
    captured: Dict[str, Any] = {}

    def fake_post(self, url, **kwargs):
        captured["headers"] = kwargs.get("headers", {})
        return _ok_json({"choices": [{"message": {"content": "yo"}}]})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    client.chat.create(messages=[{"role": "user", "content": "x"}], workspace_id="ws-99")
    assert captured["headers"].get("x-workspace-id") == "ws-99"


def test_sessions_list_calls_correct_path(monkeypatch) -> None:
    client = Aod(base_url="http://test", api_key="tok")
    seen_url: Dict[str, Any] = {}

    def fake_get(self, url, **kwargs):
        seen_url["url"] = url
        return _ok_json({"sessions": []})

    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client.sessions.list(limit=5, offset=0)
    assert seen_url["url"].endswith("/v1/sessions")


def test_documents_upload_uses_multipart(monkeypatch) -> None:
    client = Aod(base_url="http://test", api_key="tok")
    captured: Dict[str, Any] = {}

    def fake_post(self, url, **kwargs):
        captured["files"] = kwargs.get("files")
        return _ok_json({"job": {"id": "j-1", "state": "pending"}})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    client.documents.upload("readme.md", b"# hi", mime="text/markdown")
    assert "file" in captured["files"]
    assert captured["files"]["file"][0] == "readme.md"


def test_workspaces_create_body(monkeypatch) -> None:
    client = Aod(base_url="http://test", api_key="tok")
    captured: Dict[str, Any] = {}

    def fake_post(self, url, **kwargs):
        captured["json"] = kwargs.get("json")
        return _ok_json({"workspace": {"id": "ws-1", "name": "x"}})

    monkeypatch.setattr(httpx.Client, "post", fake_post)
    client.workspaces.create(name="x")
    assert captured["json"]["name"] == "x"
