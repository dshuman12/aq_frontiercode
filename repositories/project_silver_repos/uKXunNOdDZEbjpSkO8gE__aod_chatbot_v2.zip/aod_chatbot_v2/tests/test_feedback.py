"""tests for the feedback repository."""
import pytest

from feedback import repository as repo
from feedback.models import RATING_MAX, RATING_MIN, RATING_THUMBS_DOWN, RATING_THUMBS_UP


def test_record_and_get_round_trip() -> None:
    repo.bootstrap()
    fid = repo.record(rating=RATING_THUMBS_UP, user_id="u-fb-1", session_id="s-1", note="great")
    f = repo.get(fid)
    assert f is not None
    assert f.rating == 1
    assert f.note == "great"
    assert f.user_id == "u-fb-1"


def test_record_rejects_out_of_range() -> None:
    repo.bootstrap()
    with pytest.raises(ValueError):
        repo.record(rating=RATING_MAX + 1, user_id="x")
    with pytest.raises(ValueError):
        repo.record(rating=RATING_MIN - 1, user_id="x")


def test_record_with_tags() -> None:
    repo.bootstrap()
    fid = repo.record(rating=-1, user_id="u-2", tags=["wrong_facts", "stale_info"])
    f = repo.get(fid)
    assert f is not None
    assert "wrong_facts" in f.tags
    assert "stale_info" in f.tags


def test_list_for_session_filters() -> None:
    repo.bootstrap()
    repo.record(rating=1, session_id="sess-a")
    repo.record(rating=-1, session_id="sess-b")
    rows = repo.list_for_session("sess-a")
    assert all(r.session_id == "sess-a" for r in rows)


def test_list_for_user_filters() -> None:
    repo.bootstrap()
    repo.record(rating=1, user_id="u-x")
    repo.record(rating=1, user_id="u-y")
    rows = repo.list_for_user("u-x")
    assert all(r.user_id == "u-x" for r in rows)


def test_summary_aggregates() -> None:
    repo.bootstrap()
    for _ in range(3):
        repo.record(rating=1, user_id="u-sum")
    for _ in range(2):
        repo.record(rating=-1, user_id="u-sum")
    s = repo.summary(user_id="u-sum")
    assert s["total"] == 5
    assert s["thumbs_up"] == 3
    assert s["thumbs_down"] == 2
    # 3*1 + 2*(-1) = 1; avg = 1/5 = 0.2
    assert s["average"] == pytest.approx(0.2)


def test_summary_empty_returns_zero_avg() -> None:
    repo.bootstrap()
    s = repo.summary(user_id="ghost-user-no-feedback")
    assert s["total"] == 0
    assert s["average"] == 0.0


def test_top_negative_tags() -> None:
    repo.bootstrap()
    repo.record(rating=-1, tags=["wrong_facts"])
    repo.record(rating=-1, tags=["wrong_facts", "stale_info"])
    repo.record(rating=-1, tags=["stale_info"])
    repo.record(rating=1, tags=["off_topic"])   # positive - should not count
    tags = repo.top_negative_tags(limit=5)
    counts = {t["tag"]: t["n"] for t in tags}
    assert counts.get("wrong_facts", 0) == 2
    assert counts.get("stale_info", 0) == 2
    assert "off_topic" not in counts
