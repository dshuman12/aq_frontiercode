"""quick manual smoke test for the chat endpoint. not part of the pytest suite.

usage:
    OPENAI_API_KEY=sk-... python demos/smoke_chat.py
    AOD_API_BASE=http://localhost:8501 python demos/smoke_chat.py
"""
import json
import os
import sys
import time

import httpx


BASE = os.getenv("AOD_API_BASE", "http://localhost:8501")
TOKEN = os.getenv("AOD_DEMO_TOKEN", "")

QUERIES = [
    "what is BAINSA?",
    "when is AOD 2026?",
    "what's the schedule for the day?",
    "tell me about the drug discovery project",
]


def _post(body):
    headers = {"content-type": "application/json"}
    if TOKEN:
        headers["authorization"] = f"Bearer {TOKEN}"
    with httpx.Client(timeout=30.0) as c:
        return c.post(f"{BASE}/v1/chat/completions", headers=headers, json=body)


def main() -> int:
    for q in QUERIES:
        body = {"messages": [{"role": "user", "content": q}], "stream": False}
        t0 = time.time()
        r = _post(body)
        elapsed = time.time() - t0
        if r.is_success:
            payload = r.json()
            try:
                reply = payload["choices"][0]["message"]["content"]
            except (KeyError, IndexError, TypeError):
                reply = json.dumps(payload)[:200]
        else:
            reply = f"ERR {r.status_code} - {r.text[:200]}"
        print(f"Q: {q}")
        print(f"  -> {reply.strip()[:300]}")
        print(f"  ({elapsed:.2f}s)\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
