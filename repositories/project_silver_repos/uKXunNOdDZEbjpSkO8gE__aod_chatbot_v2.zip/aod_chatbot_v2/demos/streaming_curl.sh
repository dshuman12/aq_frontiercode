#!/usr/bin/env bash
# minimal streaming chat call, copy-paste while debugging.
# pass an api key as $1 if AOD_API_KEYS is enabled server-side.
# NB: needs `-N` so curl doesn't buffer the SSE chunks. learned that the hard way.

set -euo pipefail

BASE="${AOD_API_BASE:-http://localhost:8501}"
TOKEN="${1:-}"

HEADERS=(-H 'content-type: application/json')
if [ -n "$TOKEN" ]; then
    HEADERS+=(-H "authorization: Bearer $TOKEN")
fi

# todo: support reading question from stdin so this can be piped
QUESTION='who founded BAINSA?'

curl -N "$BASE/v1/chat/completions" \
    "${HEADERS[@]}" \
    -d "{
      \"messages\": [
        {\"role\":\"system\",\"content\":\"You are a helpful chatbot\"},
        {\"role\":\"user\",\"content\":\"$QUESTION\"}
      ],
      \"stream\": true
    }"
