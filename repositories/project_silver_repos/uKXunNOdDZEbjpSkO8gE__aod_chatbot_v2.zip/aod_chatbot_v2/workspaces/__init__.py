"""workspaces: multi-tenant grouping over users + sessions + documents."""
