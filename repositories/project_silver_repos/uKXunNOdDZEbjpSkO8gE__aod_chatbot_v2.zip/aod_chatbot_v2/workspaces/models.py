from dataclasses import dataclass
from typing import Optional


WORKSPACES_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    created_at INTEGER NOT NULL,
    created_by TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS memberships (
    workspace_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role TEXT NOT NULL,
    joined_at INTEGER NOT NULL,
    PRIMARY KEY (workspace_id, user_id),
    FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id);
"""


ROLE_OWNER: str = "owner"
ROLE_MEMBER: str = "member"
ROLE_VIEWER: str = "viewer"
VALID_ROLES = {ROLE_OWNER, ROLE_MEMBER, ROLE_VIEWER}
WRITE_ROLES = {ROLE_OWNER, ROLE_MEMBER}


@dataclass
class Workspace:
    id: str
    name: str
    slug: str
    created_at: int
    created_by: str

    @classmethod
    def from_row(cls, row) -> "Workspace":
        return cls(
            id=row["id"],
            name=row["name"],
            slug=row["slug"],
            created_at=row["created_at"],
            created_by=row["created_by"],
        )

    def public(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "created_at": self.created_at,
            "created_by": self.created_by,
        }


@dataclass
class Membership:
    workspace_id: str
    user_id: str
    role: str
    joined_at: int

    @classmethod
    def from_row(cls, row) -> "Membership":
        return cls(
            workspace_id=row["workspace_id"],
            user_id=row["user_id"],
            role=row["role"],
            joined_at=row["joined_at"],
        )

    def can_write(self) -> bool:
        return self.role in WRITE_ROLES
