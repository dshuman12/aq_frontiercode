import time
import uuid
from typing import List, Optional

from slugify import slugify as _ext_slugify

from rag.sessions import _connect
from workspaces.models import (
    Membership,
    ROLE_MEMBER,
    ROLE_OWNER,
    ROLE_VIEWER,
    VALID_ROLES,
    Workspace,
    WORKSPACES_SCHEMA,
)


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(WORKSPACES_SCHEMA)


def _slugify(name: str) -> str:
    # python-slugify handles accents (Università → universita), my hand-rolled regex didn't
    return _ext_slugify(name, lowercase=True, max_length=60) or "workspace"


def create_workspace(name: str, owner_user_id: str) -> Workspace:
    wid: str = uuid.uuid4().hex
    slug_base: str = _slugify(name)
    # i had universita-bocconi clashing with universita-bocconi (different casings of "Università"),
    # python-slugify fixes that
    slug: str = slug_base
    now: int = int(time.time())
    with _connect() as conn:
        # try a few slug suffixes if there's a collision
        for i in range(50):
            try:
                conn.execute(
                    "INSERT INTO workspaces (id, name, slug, created_at, created_by) VALUES (?, ?, ?, ?, ?)",
                    (wid, name, slug, now, owner_user_id),
                )
                break
            except Exception:
                slug = f"{slug_base}-{i + 2}"
        else:
            raise RuntimeError("could not allocate slug for workspace")
        # owner is automatically a member with the owner role
        conn.execute(
            "INSERT INTO memberships (workspace_id, user_id, role, joined_at) VALUES (?, ?, ?, ?)",
            (wid, owner_user_id, ROLE_OWNER, now),
        )
    return Workspace(id=wid, name=name, slug=slug, created_at=now, created_by=owner_user_id)


def get_workspace(workspace_id: str) -> Optional[Workspace]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM workspaces WHERE id = ?", (workspace_id,)).fetchone()
    return Workspace.from_row(row) if row else None


def get_workspace_by_slug(slug: str) -> Optional[Workspace]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM workspaces WHERE slug = ?", (slug,)).fetchone()
    return Workspace.from_row(row) if row else None


def delete_workspace(workspace_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("DELETE FROM workspaces WHERE id = ?", (workspace_id,))
        return cur.rowcount > 0


def get_membership(workspace_id: str, user_id: str) -> Optional[Membership]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM memberships WHERE workspace_id = ? AND user_id = ?",
            (workspace_id, user_id),
        ).fetchone()
    return Membership.from_row(row) if row else None


def list_user_workspaces(user_id: str) -> List[Workspace]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT w.* FROM workspaces w "
            "JOIN memberships m ON m.workspace_id = w.id "
            "WHERE m.user_id = ? "
            "ORDER BY w.created_at DESC",
            (user_id,),
        ).fetchall()
    return [Workspace.from_row(r) for r in rows]


def list_members(workspace_id: str) -> List[Membership]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM memberships WHERE workspace_id = ? ORDER BY joined_at ASC",
            (workspace_id,),
        ).fetchall()
    return [Membership.from_row(r) for r in rows]


def add_member(workspace_id: str, user_id: str, role: str = ROLE_MEMBER) -> Membership:
    if role not in VALID_ROLES:
        raise ValueError(f"invalid role: {role}")
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO memberships (workspace_id, user_id, role, joined_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(workspace_id, user_id) DO UPDATE SET role = excluded.role",
            (workspace_id, user_id, role, now),
        )
    return Membership(workspace_id=workspace_id, user_id=user_id, role=role, joined_at=now)


def remove_member(workspace_id: str, user_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute(
            "DELETE FROM memberships WHERE workspace_id = ? AND user_id = ?",
            (workspace_id, user_id),
        )
        return cur.rowcount > 0


def transfer_ownership(workspace_id: str, new_owner_id: str) -> bool:
    """promote `new_owner_id` to owner of `workspace_id`. caller is expected to have already verified
    that they currently own the workspace.
    """
    with _connect() as conn:
        cur = conn.execute(
            "UPDATE memberships SET role = ? WHERE workspace_id = ? AND user_id = ?",
            (ROLE_OWNER, workspace_id, new_owner_id),
        )
        return cur.rowcount > 0


bootstrap()
