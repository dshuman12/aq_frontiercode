from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from users.endpoints import current_user
from users.repository import get_user_by_email, get_user_by_id
from workspaces import repository as repo
from workspaces.models import ROLE_MEMBER, ROLE_OWNER, ROLE_VIEWER, VALID_ROLES, WRITE_ROLES


router = APIRouter(prefix="/v1/workspaces", tags=["workspaces"])


class CreateWorkspace(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)


class AddMember(BaseModel):
    email: str
    role: str = ROLE_MEMBER


class TransferOwnership(BaseModel):
    new_owner_email: str


def _require_owner(workspace_id: str, user_id: str) -> None:
    m = repo.get_membership(workspace_id, user_id)
    if m is None or m.role != ROLE_OWNER:
        raise HTTPException(status_code=403, detail="owner role required")


def _require_write(workspace_id: str, user_id: str) -> None:
    m = repo.get_membership(workspace_id, user_id)
    if m is None or m.role not in WRITE_ROLES:
        raise HTTPException(status_code=403, detail="write role required")


@router.post("")
def create_workspace(body: CreateWorkspace, user=Depends(current_user)) -> Dict[str, Any]:
    ws = repo.create_workspace(body.name, owner_user_id=user.id)
    return {"workspace": ws.public()}


@router.get("")
def list_workspaces(user=Depends(current_user)) -> Dict[str, Any]:
    rows = repo.list_user_workspaces(user.id)
    return {"workspaces": [w.public() for w in rows]}


@router.get("/{workspace_id}")
def get_one(workspace_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    ws = repo.get_workspace(workspace_id)
    if ws is None:
        raise HTTPException(status_code=404, detail="workspace not found")
    return {"workspace": ws.public()}


@router.delete("/{workspace_id}")
def remove_workspace(workspace_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    _require_owner(workspace_id, user.id)
    ok: bool = repo.delete_workspace(workspace_id)
    return {"deleted": ok}


@router.get("/{workspace_id}/members")
def list_members(workspace_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    # caller must at least be a member to see the member list
    _require_write(workspace_id, user.id)
    members = repo.list_members(workspace_id)
    out: List[Dict[str, Any]] = []
    for m in members:
        u = get_user_by_id(m.user_id)
        out.append(
            {
                "user_id": m.user_id,
                "email": u.email if u else None,
                "display_name": u.display_name if u else None,
                "role": m.role,
                "joined_at": m.joined_at,
            }
        )
    return {"members": out}


@router.post("/{workspace_id}/members")
def add_member(workspace_id: str, body: AddMember, user=Depends(current_user)) -> Dict[str, Any]:
    _require_owner(workspace_id, user.id)
    if body.role not in VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"invalid role; must be one of {sorted(VALID_ROLES)}")
    target = get_user_by_email(body.email)
    if target is None:
        raise HTTPException(status_code=404, detail="no user with that email")
    m = repo.add_member(workspace_id, target.user_id if hasattr(target, "user_id") else target.id, body.role)
    return {"member": {"user_id": m.user_id, "role": m.role}}


@router.delete("/{workspace_id}/members/{user_id}")
def remove_member(workspace_id: str, user_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    _require_owner(workspace_id, user.id)
    if user_id == user.id:
        raise HTTPException(status_code=400, detail="owners cannot remove themselves, transfer ownership first")
    ok = repo.remove_member(workspace_id, user_id)
    return {"removed": ok}


@router.post("/{workspace_id}/transfer")
def transfer(workspace_id: str, body: TransferOwnership, user=Depends(current_user)) -> Dict[str, Any]:
    _require_owner(workspace_id, user.id)
    target = get_user_by_email(body.new_owner_email)
    if target is None:
        raise HTTPException(status_code=404, detail="no user with that email")
    # ensure they're already a member (we don't auto-add on transfer)
    m = repo.get_membership(workspace_id, target.id)
    if m is None:
        raise HTTPException(status_code=400, detail="target must already be a member of the workspace")
    ok = repo.transfer_ownership(workspace_id, target.id)
    return {"transferred": ok}
