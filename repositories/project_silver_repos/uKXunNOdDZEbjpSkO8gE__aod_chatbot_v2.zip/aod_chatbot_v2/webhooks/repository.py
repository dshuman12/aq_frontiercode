import json
import secrets
import time
import uuid
from typing import Any, Dict, List, Optional

from rag.sessions import _connect
from webhooks.models import Delivery, Subscription, WEBHOOKS_SCHEMA


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(WEBHOOKS_SCHEMA)


def _gen_secret() -> str:
    return "whsec_" + secrets.token_urlsafe(32)


def create_subscription(
    user_id: str,
    url: str,
    events: Optional[List[str]] = None,
    workspace_id: Optional[str] = None,
) -> Subscription:
    sid: str = uuid.uuid4().hex
    secret: str = _gen_secret()
    now: int = int(time.time())
    events_json: str = json.dumps(events or [])
    with _connect() as conn:
        conn.execute(
            "INSERT INTO webhook_subscriptions (id, user_id, workspace_id, url, secret, events, active, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
            (sid, user_id, workspace_id, url, secret, events_json, now),
        )
    return Subscription(
        id=sid,
        user_id=user_id,
        workspace_id=workspace_id,
        url=url,
        secret=secret,
        events=list(events or []),
        active=True,
        created_at=now,
        last_delivered_at=None,
    )


def get_subscription(sub_id: str) -> Optional[Subscription]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM webhook_subscriptions WHERE id = ?", (sub_id,)).fetchone()
    return Subscription.from_row(row) if row else None


def deactivate(sub_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("UPDATE webhook_subscriptions SET active = 0 WHERE id = ?", (sub_id,))
        return cur.rowcount > 0


def delete_subscription(sub_id: str) -> bool:
    with _connect() as conn:
        cur = conn.execute("DELETE FROM webhook_subscriptions WHERE id = ?", (sub_id,))
        return cur.rowcount > 0


def list_subscriptions(
    user_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    active_only: bool = True,
    limit: int = 100,
    offset: int = 0,
) -> List[Subscription]:
    sql: str = "SELECT * FROM webhook_subscriptions WHERE 1=1"
    args: List[Any] = []
    if user_id:
        sql += " AND user_id = ?"
        args.append(user_id)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    if active_only:
        sql += " AND active = 1"
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    args.append(limit)
    args.append(offset)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [Subscription.from_row(r) for r in rows]


def list_subscribers_for(event_kind: str) -> List[Subscription]:
    """find all active subscriptions that should receive `event_kind`.

    we filter in python rather than sql because events is a json blob.
    fine for our scale (dozens of subs, not thousands).
    """
    with _connect() as conn:
        rows = conn.execute("SELECT * FROM webhook_subscriptions WHERE active = 1").fetchall()
    subs = [Subscription.from_row(r) for r in rows]
    return [s for s in subs if s.covers_event(event_kind)]


def mark_delivered(sub_id: str) -> None:
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute("UPDATE webhook_subscriptions SET last_delivered_at = ? WHERE id = ?", (now, sub_id))


def log_delivery(
    subscription_id: str,
    event_kind: str,
    payload: Dict[str, Any],
    status_code: Optional[int],
    error: Optional[str],
    attempt_count: int,
) -> int:
    now: int = int(time.time())
    payload_str: str = json.dumps(payload, default=str)
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO webhook_deliveries (subscription_id, event_kind, payload, status_code, error, attempt_count, sent_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (subscription_id, event_kind, payload_str, status_code, error, attempt_count, now),
        )
        return cur.lastrowid


def recent_deliveries(
    subscription_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
) -> List[Delivery]:
    sql: str = "SELECT * FROM webhook_deliveries WHERE 1=1"
    args: List[Any] = []
    if subscription_id:
        sql += " AND subscription_id = ?"
        args.append(subscription_id)
    sql += " ORDER BY sent_at DESC LIMIT ? OFFSET ?"
    args.append(limit)
    args.append(offset)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [Delivery.from_row(r) for r in rows]


bootstrap()
