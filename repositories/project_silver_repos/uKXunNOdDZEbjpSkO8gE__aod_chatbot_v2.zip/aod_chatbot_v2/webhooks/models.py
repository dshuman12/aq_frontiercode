"""schema per webhook subscriptions + delivery attempts."""
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


WEBHOOKS_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS webhook_subscriptions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    workspace_id TEXT,
    url TEXT NOT NULL,
    secret TEXT NOT NULL,
    events TEXT NOT NULL DEFAULT '[]',
    active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    last_delivered_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_webhook_subs_user ON webhook_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_webhook_subs_workspace ON webhook_subscriptions(workspace_id);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subscription_id TEXT NOT NULL,
    event_kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    status_code INTEGER,
    error TEXT,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    sent_at INTEGER NOT NULL,
    FOREIGN KEY(subscription_id) REFERENCES webhook_subscriptions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_sub ON webhook_deliveries(subscription_id);
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_sent ON webhook_deliveries(sent_at);
"""


@dataclass
class Subscription:
    id: str
    user_id: str
    workspace_id: Optional[str]
    url: str
    secret: str
    events: List[str]
    active: bool
    created_at: int
    last_delivered_at: Optional[int]

    @classmethod
    def from_row(cls, row) -> "Subscription":
        try:
            events = json.loads(row["events"] or "[]")
            if not isinstance(events, list):
                events = []
        except (json.JSONDecodeError, TypeError):
            events = []
        return cls(
            id=row["id"],
            user_id=row["user_id"],
            workspace_id=row["workspace_id"],
            url=row["url"],
            secret=row["secret"],
            events=[str(e) for e in events],
            active=bool(row["active"]),
            created_at=row["created_at"],
            last_delivered_at=row["last_delivered_at"],
        )

    def public(self) -> Dict[str, Any]:
        # NEVER return `secret` to the caller, only hash prefix
        return {
            "id": self.id,
            "user_id": self.user_id,
            "workspace_id": self.workspace_id,
            "url": self.url,
            "secret_prefix": (self.secret or "")[:6] + "...",
            "events": self.events,
            "active": self.active,
            "created_at": self.created_at,
            "last_delivered_at": self.last_delivered_at,
        }

    def covers_event(self, event_kind: str) -> bool:
        if not self.active:
            return False
        # empty events list means "all events"
        if not self.events:
            return True
        return event_kind in self.events


@dataclass
class Delivery:
    id: Optional[int]
    subscription_id: str
    event_kind: str
    payload: Dict[str, Any]
    status_code: Optional[int]
    error: Optional[str]
    attempt_count: int
    sent_at: int

    @classmethod
    def from_row(cls, row) -> "Delivery":
        try:
            payload = json.loads(row["payload"] or "{}")
        except (json.JSONDecodeError, TypeError):
            payload = {}
        if not isinstance(payload, dict):
            payload = {"_raw": payload}
        return cls(
            id=row["id"],
            subscription_id=row["subscription_id"],
            event_kind=row["event_kind"],
            payload=payload,
            status_code=row["status_code"],
            error=row["error"],
            attempt_count=row["attempt_count"],
            sent_at=row["sent_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "subscription_id": self.subscription_id,
            "event_kind": self.event_kind,
            "payload": self.payload,
            "status_code": self.status_code,
            "error": self.error,
            "attempt_count": self.attempt_count,
            "sent_at": self.sent_at,
        }

    def is_success(self) -> bool:
        return self.status_code is not None and 200 <= self.status_code < 300
