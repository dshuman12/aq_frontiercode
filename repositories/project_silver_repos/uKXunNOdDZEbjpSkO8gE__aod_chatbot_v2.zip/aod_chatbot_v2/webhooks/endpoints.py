"""user-facing webhook management. each user manages their own subscriptions."""
import re
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from users.endpoints import current_user
from webhooks import repository as repo


router = APIRouter(prefix="/v1/webhooks", tags=["webhooks"])


# very loose url validation. we don't want to be in the URL parsing business but we
# also don't want to accept anything that obviously isn't a url.
_URL_RE = re.compile(r"^https?://[^\s]+$", re.IGNORECASE)


class CreateSubscription(BaseModel):
    url: str = Field(..., min_length=8, max_length=2000)
    events: Optional[List[str]] = Field(default=None, description="empty/missing == all events")
    workspace_id: Optional[str] = None


@router.post("")
def create_sub(body: CreateSubscription, user=Depends(current_user)) -> Dict[str, Any]:
    if not _URL_RE.match(body.url):
        raise HTTPException(status_code=400, detail="url must be http(s)")
    sub = repo.create_subscription(
        user_id=user.id,
        url=body.url,
        events=body.events,
        workspace_id=body.workspace_id,
    )
    # only on CREATION do we return the secret in full. after this the caller has to
    # rotate to get a new one.
    return {
        "subscription": sub.public(),
        "secret_once": sub.secret,
    }


@router.get("")
def list_subs(
    user=Depends(current_user),
    workspace_id: Optional[str] = None,
    active_only: bool = True,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> Dict[str, Any]:
    rows = repo.list_subscriptions(
        user_id=user.id,
        workspace_id=workspace_id,
        active_only=active_only,
        limit=limit,
        offset=offset,
    )
    return {"subscriptions": [s.public() for s in rows]}


@router.get("/{sub_id}")
def get_sub(sub_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    sub = repo.get_subscription(sub_id)
    if sub is None:
        raise HTTPException(status_code=404, detail="subscription not found")
    if sub.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your subscription")
    return {"subscription": sub.public()}


@router.delete("/{sub_id}")
def delete_sub(sub_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    sub = repo.get_subscription(sub_id)
    if sub is None:
        raise HTTPException(status_code=404, detail="subscription not found")
    if sub.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your subscription")
    ok = repo.delete_subscription(sub_id)
    return {"deleted": ok}


@router.post("/{sub_id}/deactivate")
def deactivate_sub(sub_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    sub = repo.get_subscription(sub_id)
    if sub is None:
        raise HTTPException(status_code=404, detail="subscription not found")
    if sub.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your subscription")
    ok = repo.deactivate(sub_id)
    return {"deactivated": ok}


@router.get("/{sub_id}/deliveries")
def list_deliveries(
    sub_id: str,
    user=Depends(current_user),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> Dict[str, Any]:
    sub = repo.get_subscription(sub_id)
    if sub is None:
        raise HTTPException(status_code=404, detail="subscription not found")
    if sub.user_id != user.id:
        raise HTTPException(status_code=403, detail="not your subscription")
    rows = repo.recent_deliveries(subscription_id=sub_id, limit=limit, offset=offset)
    return {"deliveries": [d.public() for d in rows]}
