"""fire webhooks. enqueues work onto the jobs queue rather than blocking the request path.

signing: HMAC-SHA256(secret, body). header is X-Aod-Signature: sha256=<hex>.
"""
import hashlib
import hmac
import json
import logging
import time
from typing import Any, Dict, Optional

import httpx

from jobs.queue import enqueue
from webhooks import repository as repo


log = logging.getLogger("aod.webhooks")

TASK_KIND: str = "deliver_webhook"
MAX_ATTEMPTS: int = 5
TIMEOUT_SECONDS: float = 10.0


def sign(body: bytes, secret: str) -> str:
    """returns the hex digest expected in the X-Aod-Signature header."""
    mac = hmac.new(secret.encode("utf-8"), body, hashlib.sha256)
    return mac.hexdigest()


def signature_header(body: bytes, secret: str) -> str:
    return f"sha256={sign(body, secret)}"


def dispatch(event_kind: str, payload: Dict[str, Any]) -> int:
    """enqueue a delivery for every active subscriber. returns count enqueued."""
    subs = repo.list_subscribers_for(event_kind)
    count = 0
    for sub in subs:
        enqueue(
            TASK_KIND,
            {
                "subscription_id": sub.id,
                "event_kind": event_kind,
                "payload": payload,
            },
        )
        count += 1
    return count


def deliver_now(subscription_id: str, event_kind: str, payload: Dict[str, Any], attempt: int = 1) -> bool:
    """blocking delivery - called by the worker task. returns True on 2xx."""
    sub = repo.get_subscription(subscription_id)
    if sub is None:
        repo.log_delivery(subscription_id, event_kind, payload, status_code=None, error="subscription gone", attempt_count=attempt)
        return False
    if not sub.active:
        repo.log_delivery(subscription_id, event_kind, payload, status_code=None, error="subscription inactive", attempt_count=attempt)
        return False
    body_obj: Dict[str, Any] = {"event": event_kind, "delivered_at": int(time.time()), "data": payload}
    body_bytes: bytes = json.dumps(body_obj, default=str).encode("utf-8")
    sig = signature_header(body_bytes, sub.secret)
    headers = {
        "content-type": "application/json",
        "x-aod-signature": sig,
        "x-aod-event": event_kind,
        "user-agent": "aod-webhooks/1.0",
    }
    status: Optional[int] = None
    error: Optional[str] = None
    try:
        with httpx.Client(timeout=TIMEOUT_SECONDS) as client:
            r = client.post(sub.url, content=body_bytes, headers=headers)
            status = r.status_code
    except httpx.HTTPError as e:
        error = f"{type(e).__name__}: {e}"
        log.warning("webhook delivery failed", extra={"sub": sub.id, "error": error})
    repo.log_delivery(subscription_id, event_kind, payload, status_code=status, error=error, attempt_count=attempt)
    if status is not None and 200 <= status < 300:
        repo.mark_delivered(sub.id)
        return True
    return False


def deliver_task(task_payload: Dict[str, Any]) -> None:
    """jobs.worker handler entry point. registered in jobs.tasks."""
    subscription_id: str = task_payload["subscription_id"]
    event_kind: str = task_payload["event_kind"]
    payload: Dict[str, Any] = task_payload.get("payload", {})
    attempt: int = int(task_payload.get("attempt", 1))

    ok = deliver_now(subscription_id, event_kind, payload, attempt=attempt)
    if ok:
        return
    if attempt >= MAX_ATTEMPTS:
        log.warning("webhook giving up", extra={"sub": subscription_id, "event": event_kind, "attempt": attempt})
        return
    # naive linear backoff. todo: exponential. todo: jitter.
    # we re-enqueue rather than sleep, so the worker can pick other jobs in between.
    enqueue(
        TASK_KIND,
        {
            "subscription_id": subscription_id,
            "event_kind": event_kind,
            "payload": payload,
            "attempt": attempt + 1,
        },
        priority=0,
    )
