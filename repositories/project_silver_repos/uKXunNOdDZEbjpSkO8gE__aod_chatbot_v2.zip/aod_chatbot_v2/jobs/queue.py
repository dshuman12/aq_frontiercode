"""task queue persisted in the sessions sqlite db. one queue per process is fine for us."""
import json
import time
import uuid
from typing import Any, Dict, List, Optional

from rag.sessions import _connect


JOBS_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'queued',
    priority INTEGER NOT NULL DEFAULT 0,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    enqueued_at INTEGER NOT NULL,
    started_at INTEGER,
    finished_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state);
"""


STATE_QUEUED: str = "queued"
STATE_RUNNING: str = "running"
STATE_DONE: str = "done"
STATE_FAILED: str = "failed"


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(JOBS_SCHEMA)


def enqueue(kind: str, payload: Dict[str, Any], priority: int = 0) -> str:
    jid: str = uuid.uuid4().hex
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO jobs (id, kind, payload, priority, enqueued_at) VALUES (?, ?, ?, ?, ?)",
            (jid, kind, json.dumps(payload), priority, now),
        )
    return jid


def pop_next() -> Optional[Dict[str, Any]]:
    """grab the next queued job and mark it running. returns None when queue is empty.

    not strictly atomic; we lock the connection via a transaction but a second worker
    could still race. fine for now since we only run one worker.
    """
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT * FROM jobs WHERE state = ? ORDER BY priority DESC, enqueued_at ASC LIMIT 1",
            (STATE_QUEUED,),
        ).fetchone()
        if row is None:
            conn.execute("COMMIT")
            return None
        conn.execute(
            "UPDATE jobs SET state = ?, started_at = ?, attempts = attempts + 1 WHERE id = ?",
            (STATE_RUNNING, now, row["id"]),
        )
        out = dict(row)
        out["payload"] = json.loads(out["payload"])
        return out


def mark_done(job_id: str) -> None:
    with _connect() as conn:
        conn.execute(
            "UPDATE jobs SET state = ?, finished_at = ?, last_error = NULL WHERE id = ?",
            (STATE_DONE, int(time.time()), job_id),
        )


def mark_failed(job_id: str, error: str) -> None:
    with _connect() as conn:
        conn.execute(
            "UPDATE jobs SET state = ?, finished_at = ?, last_error = ? WHERE id = ?",
            (STATE_FAILED, int(time.time()), error, job_id),
        )


def get(job_id: str) -> Optional[Dict[str, Any]]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    if row is None:
        return None
    out = dict(row)
    out["payload"] = json.loads(out["payload"])
    return out


def list_jobs(state: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM jobs"
    args: tuple = ()
    if state:
        sql += " WHERE state = ?"
        args = (state,)
    sql += " ORDER BY enqueued_at DESC LIMIT ?"
    args = args + (limit,)
    with _connect() as conn:
        rows = conn.execute(sql, args).fetchall()
    out: List[Dict[str, Any]] = []
    for r in rows:
        d = dict(r)
        try:
            d["payload"] = json.loads(d["payload"])
        except (json.JSONDecodeError, TypeError):
            pass
        out.append(d)
    return out


def requeue_stuck(max_runtime_seconds: int = 3600) -> int:
    """move any running-too-long jobs back to queued. handy after a crash."""
    cutoff: int = int(time.time()) - max_runtime_seconds
    with _connect() as conn:
        cur = conn.execute(
            "UPDATE jobs SET state = ?, started_at = NULL WHERE state = ? AND started_at < ?",
            (STATE_QUEUED, STATE_RUNNING, cutoff),
        )
        return cur.rowcount


bootstrap()
