"""background-jobs: tiny sqlite-backed task queue + single-worker loop."""
