"""concrete task handlers. registered via @register so worker.run() picks them up."""
import os
from typing import Any, Dict

from jobs.worker import register


@register("ingest_document")
def ingest_document_task(payload: Dict[str, Any]) -> None:
    """payload: {"path": "...", "filename": "...", "mime": "...", "owner": "..."}"""
    from ingestion.pipeline import run as run_pipeline

    path: str = payload["path"]
    filename: str = payload.get("filename") or os.path.basename(path)
    mime = payload.get("mime")
    owner = payload.get("owner")

    with open(path, "rb") as f:
        content: bytes = f.read()
    job = run_pipeline(filename=filename, content=content, mime=mime, owner=owner)
    if job.state == "failed":
        raise RuntimeError(job.error or "ingestion failed")


@register("prune_stale_sessions")
def prune_stale_sessions_task(payload: Dict[str, Any]) -> None:
    """payload: {"older_than_seconds": int}"""
    from rag.sessions import prune_older_than

    older_than: int = int(payload.get("older_than_seconds", 14 * 86400))
    prune_older_than(older_than)


@register("deliver_webhook")
def deliver_webhook_task(payload: Dict[str, Any]) -> None:
    """payload as built by webhooks.dispatcher.dispatch()."""
    from webhooks.dispatcher import deliver_task
    deliver_task(payload)


@register("send_digest")
def send_digest_task(payload: Dict[str, Any]) -> None:
    """placeholder for a future email digest. for now just logs the recipient + count."""
    import logging
    log = logging.getLogger("aod.jobs.tasks")
    recipient: str = payload.get("recipient", "")
    n_messages: int = int(payload.get("n_messages", 0))
    log.info("send_digest stub", extra={"recipient": recipient, "n_messages": n_messages})
    # todo: actually integrate with an smtp provider. resend / mailgun / postmark all fine.
