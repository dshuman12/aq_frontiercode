"""single-worker run loop. polls the queue, dispatches to registered handlers, repeats."""
import logging
import signal
import time
from typing import Any, Callable, Dict, Optional

from jobs.queue import mark_done, mark_failed, pop_next


_HANDLERS: Dict[str, Callable[[Dict[str, Any]], None]] = {}
_RUNNING: bool = True

log = logging.getLogger("aod.jobs")


def register(kind: str):
    """decorator to register a task handler under a job kind."""
    def deco(fn: Callable[[Dict[str, Any]], None]) -> Callable[[Dict[str, Any]], None]:
        _HANDLERS[kind] = fn
        return fn
    return deco


def handler_for(kind: str) -> Optional[Callable[[Dict[str, Any]], None]]:
    return _HANDLERS.get(kind)


def _signal_handler(signum, frame) -> None:
    global _RUNNING
    log.info("shutdown requested", extra={"signal": signum})
    _RUNNING = False


def run(poll_interval_seconds: float = 1.0) -> None:
    """loop forever (or until SIGTERM/SIGINT). importing jobs.tasks registers the handlers."""
    from jobs import tasks  # noqa: F401 - side-effect imports register handlers

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)

    log.info("worker started", extra={"handlers": list(_HANDLERS.keys())})

    idle_streak: int = 0
    while _RUNNING:
        job = pop_next()
        if job is None:
            idle_streak += 1
            # progressive backoff so we don't hammer the db
            sleep_for: float = min(5.0, poll_interval_seconds * (1 + idle_streak * 0.1))
            time.sleep(sleep_for)
            continue
        idle_streak = 0
        kind: str = job["kind"]
        fn = _HANDLERS.get(kind)
        if fn is None:
            mark_failed(job["id"], f"no handler registered for kind: {kind!r}")
            continue
        try:
            fn(job["payload"])
            mark_done(job["id"])
        except Exception as e:
            log.exception("job failed", extra={"job_id": job["id"], "kind": kind})
            mark_failed(job["id"], f"{type(e).__name__}: {e}")
        # tiny breath between jobs to keep the cpu sane on a tight queue
        time.sleep(0.05)

    log.info("worker exited cleanly")
