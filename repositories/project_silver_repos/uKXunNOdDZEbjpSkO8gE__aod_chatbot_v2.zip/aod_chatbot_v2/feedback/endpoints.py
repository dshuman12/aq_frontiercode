"""feedback endpoints. POST to submit, GET aggregates for dashboards."""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from feedback import repository as repo
from feedback.models import NEGATIVE_TAGS, RATING_MAX, RATING_MIN
from users.endpoints import current_user


router = APIRouter(prefix="/v1/feedback", tags=["feedback"])


class FeedbackBody(BaseModel):
    rating: int = Field(..., ge=RATING_MIN, le=RATING_MAX)
    session_id: Optional[str] = None
    message_id: Optional[int] = None
    completion_id: Optional[str] = None
    note: Optional[str] = Field(default=None, max_length=2000)
    tags: Optional[List[str]] = None


@router.post("")
def submit(body: FeedbackBody, user=Depends(current_user)) -> Dict[str, Any]:
    fid = repo.record(
        rating=body.rating,
        user_id=user.id,
        session_id=body.session_id,
        message_id=body.message_id,
        completion_id=body.completion_id,
        note=body.note,
        tags=body.tags,
    )
    return {"id": fid}


@router.get("/me")
def my_feedback(user=Depends(current_user), limit: int = 100) -> Dict[str, Any]:
    rows = repo.list_for_user(user.id, limit=limit)
    return {"feedback": [f.public() for f in rows]}


@router.get("/session/{session_id}")
def by_session(session_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    rows = repo.list_for_session(session_id)
    return {"feedback": [f.public() for f in rows]}


@router.get("/summary")
def summary(
    user=Depends(current_user),
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> Dict[str, Any]:
    return repo.summary(since=since, until=until)


@router.get("/negative-tags")
def negative_tags(user=Depends(current_user), limit: int = 10, since: Optional[int] = None) -> Dict[str, Any]:
    return {"tags": repo.top_negative_tags(limit=limit, since=since), "known_labels": NEGATIVE_TAGS}
