"""feedback CRUD + aggregation queries."""
import json
import time
from typing import Any, Dict, List, Optional

from rag.sessions import _connect
from feedback.models import (
    FEEDBACK_SCHEMA,
    Feedback,
    RATING_MAX,
    RATING_MIN,
)


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(FEEDBACK_SCHEMA)


def record(
    rating: int,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    message_id: Optional[int] = None,
    completion_id: Optional[str] = None,
    note: Optional[str] = None,
    tags: Optional[List[str]] = None,
) -> int:
    """persist a feedback row. returns the id."""
    if not (RATING_MIN <= rating <= RATING_MAX):
        raise ValueError(f"rating out of range [{RATING_MIN}, {RATING_MAX}]: {rating}")
    now: int = int(time.time())
    tags_json: str = json.dumps(tags or [])
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO feedback (user_id, session_id, message_id, completion_id, rating, note, tags, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, session_id, message_id, completion_id, rating, note, tags_json, now),
        )
        return cur.lastrowid


def get(feedback_id: int) -> Optional[Feedback]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM feedback WHERE id = ?", (feedback_id,)).fetchone()
    return Feedback.from_row(row) if row else None


def list_for_session(session_id: str, limit: int = 100) -> List[Feedback]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM feedback WHERE session_id = ? ORDER BY created_at DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    return [Feedback.from_row(r) for r in rows]


def list_for_user(user_id: str, limit: int = 100) -> List[Feedback]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM feedback WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
    return [Feedback.from_row(r) for r in rows]


def summary(
    since: Optional[int] = None,
    until: Optional[int] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """global counts + average rating. cheap aggregate for dashboards."""
    sql: str = "SELECT rating, COUNT(*) AS n FROM feedback WHERE 1=1"
    args: List[Any] = []
    if since is not None:
        sql += " AND created_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND created_at < ?"
        args.append(until)
    if user_id:
        sql += " AND user_id = ?"
        args.append(user_id)
    sql += " GROUP BY rating"
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    by_rating: Dict[int, int] = {r["rating"]: int(r["n"]) for r in rows}
    total: int = sum(by_rating.values())
    weighted_sum: int = sum(rating * n for rating, n in by_rating.items())
    avg = (weighted_sum / total) if total > 0 else 0.0
    return {
        "total": total,
        "by_rating": by_rating,
        "average": avg,
        "thumbs_up": by_rating.get(1, 0),
        "thumbs_down": by_rating.get(-1, 0),
    }


def top_negative_tags(limit: int = 10, since: Optional[int] = None) -> List[Dict[str, Any]]:
    """which negative-tag labels show up most often. small data; counts in python."""
    sql: str = "SELECT tags FROM feedback WHERE rating < 0"
    args: List[Any] = []
    if since is not None:
        sql += " AND created_at >= ?"
        args.append(since)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    from collections import Counter
    counter: Counter = Counter()
    for r in rows:
        try:
            tags = json.loads(r["tags"] or "[]")
        except (ValueError, TypeError):
            continue
        if isinstance(tags, list):
            counter.update(str(t) for t in tags)
    return [{"tag": t, "n": n} for t, n in counter.most_common(limit)]


bootstrap()
