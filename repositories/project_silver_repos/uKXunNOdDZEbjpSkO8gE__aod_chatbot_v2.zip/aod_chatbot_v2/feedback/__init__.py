"""thumbs-up / thumbs-down + free-text feedback on assistant replies."""
