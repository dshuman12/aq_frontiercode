"""feedback table + dataclass."""
from dataclasses import dataclass
from typing import Any, Dict, Optional


FEEDBACK_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    session_id TEXT,
    message_id INTEGER,
    completion_id TEXT,
    rating INTEGER NOT NULL,
    note TEXT,
    tags TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_feedback_user ON feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_feedback_session ON feedback(session_id);
CREATE INDEX IF NOT EXISTS idx_feedback_rating ON feedback(rating);
CREATE INDEX IF NOT EXISTS idx_feedback_created ON feedback(created_at);
"""


RATING_THUMBS_DOWN: int = -1
RATING_NEUTRAL: int = 0
RATING_THUMBS_UP: int = 1

# valid range - we keep room for 5-star later
RATING_MIN: int = -2
RATING_MAX: int = 5


# rough "what's wrong" labels users can tick off when they thumbs-down
NEGATIVE_TAGS = [
    "wrong_facts",
    "off_topic",
    "missing_citation",
    "too_long",
    "too_short",
    "stale_info",
    "broken_format",
    "language_mismatch",
    "tone",
    "other",
]


@dataclass
class Feedback:
    id: Optional[int]
    user_id: Optional[str]
    session_id: Optional[str]
    message_id: Optional[int]
    completion_id: Optional[str]
    rating: int
    note: Optional[str]
    tags: list
    created_at: int

    @classmethod
    def from_row(cls, row) -> "Feedback":
        import json as _json
        try:
            tags = _json.loads(row["tags"] or "[]")
            if not isinstance(tags, list):
                tags = []
        except (ValueError, TypeError):
            tags = []
        return cls(
            id=row["id"],
            user_id=row["user_id"],
            session_id=row["session_id"],
            message_id=row["message_id"],
            completion_id=row["completion_id"],
            rating=row["rating"],
            note=row["note"],
            tags=tags,
            created_at=row["created_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "session_id": self.session_id,
            "message_id": self.message_id,
            "completion_id": self.completion_id,
            "rating": self.rating,
            "note": self.note,
            "tags": self.tags,
            "created_at": self.created_at,
        }
