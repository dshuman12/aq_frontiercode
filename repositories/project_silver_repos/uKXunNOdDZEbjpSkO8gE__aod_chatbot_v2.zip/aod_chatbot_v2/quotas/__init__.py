"""per-user quota tracking. tiered plans, monthly windows."""
