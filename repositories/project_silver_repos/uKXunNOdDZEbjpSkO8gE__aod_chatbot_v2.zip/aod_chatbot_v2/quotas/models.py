"""sqlite tables for plan assignments + monthly counters."""
from dataclasses import dataclass
from typing import Any, Dict, Optional


QUOTAS_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS user_plans (
    user_id TEXT PRIMARY KEY,
    plan_name TEXT NOT NULL,
    assigned_at INTEGER NOT NULL,
    assigned_by TEXT
);
CREATE TABLE IF NOT EXISTS quota_usage (
    user_id TEXT NOT NULL,
    period_yyyymm INTEGER NOT NULL,
    metric TEXT NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    last_increment_at INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, period_yyyymm, metric)
);
CREATE INDEX IF NOT EXISTS idx_quota_usage_period ON quota_usage(period_yyyymm);
"""


METRIC_CHAT_COMPLETIONS: str = "chat_completions"
METRIC_DOCUMENTS: str = "documents"
METRIC_SESSIONS: str = "sessions"


@dataclass
class PlanAssignment:
    user_id: str
    plan_name: str
    assigned_at: int
    assigned_by: Optional[str]

    @classmethod
    def from_row(cls, row) -> "PlanAssignment":
        return cls(
            user_id=row["user_id"],
            plan_name=row["plan_name"],
            assigned_at=row["assigned_at"],
            assigned_by=row["assigned_by"],
        )


@dataclass
class Usage:
    user_id: str
    period_yyyymm: int
    metric: str
    used: int
    last_increment_at: int

    @classmethod
    def from_row(cls, row) -> "Usage":
        return cls(
            user_id=row["user_id"],
            period_yyyymm=row["period_yyyymm"],
            metric=row["metric"],
            used=row["used"],
            last_increment_at=row["last_increment_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "user_id": self.user_id,
            "period_yyyymm": self.period_yyyymm,
            "metric": self.metric,
            "used": self.used,
            "last_increment_at": self.last_increment_at,
        }
