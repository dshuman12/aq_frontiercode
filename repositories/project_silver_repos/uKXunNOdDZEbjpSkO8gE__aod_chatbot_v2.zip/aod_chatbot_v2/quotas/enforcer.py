"""dependency that checks if a user is over their plan's quota for a given metric."""
from typing import Callable

from fastapi import Depends, HTTPException, status

from quotas import repository as repo
from quotas.models import METRIC_CHAT_COMPLETIONS, METRIC_DOCUMENTS, METRIC_SESSIONS
from users.endpoints import current_user


class QuotaExceeded(HTTPException):
    def __init__(self, metric: str, used: int, limit: int) -> None:
        super().__init__(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=f"quota exceeded for {metric}: used {used} of {limit} this month",
            headers={"X-Quota-Metric": metric, "X-Quota-Used": str(used), "X-Quota-Limit": str(limit)},
        )


def _check_metric(user_id: str, metric: str) -> None:
    plan = repo.get_plan_for(user_id)
    if metric == METRIC_CHAT_COMPLETIONS:
        limit = plan.chat_completions_per_month
    elif metric == METRIC_DOCUMENTS:
        limit = plan.documents_per_month
    elif metric == METRIC_SESSIONS:
        limit = plan.sessions_per_month
    else:
        return   # unknown metric, no limit
    usage = repo.usage_for(user_id).get(metric, 0)
    if usage > limit:
        raise QuotaExceeded(metric, usage, limit)


def require_chat_quota(user=Depends(current_user)):
    """dep that returns the user but raises if they're past chat quota."""
    _check_metric(user.id, METRIC_CHAT_COMPLETIONS)
    return user


def require_document_quota(user=Depends(current_user)):
    _check_metric(user.id, METRIC_DOCUMENTS)
    return user


def require_session_quota(user=Depends(current_user)):
    _check_metric(user.id, METRIC_SESSIONS)
    return user


def factory(metric: str) -> Callable:
    """if you need an enforcer for a custom metric. not used today."""
    def _dep(user=Depends(current_user)):
        _check_metric(user.id, metric)
        return user
    return _dep
