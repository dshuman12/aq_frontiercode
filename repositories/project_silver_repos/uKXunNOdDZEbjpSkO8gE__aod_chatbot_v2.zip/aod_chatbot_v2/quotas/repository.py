"""plan assignment + usage counting. monthly windows in YYYYMM integer form."""
import datetime
import time
from typing import Dict, List, Optional

from rag.sessions import _connect
from quotas.models import (
    METRIC_CHAT_COMPLETIONS,
    METRIC_DOCUMENTS,
    METRIC_SESSIONS,
    PlanAssignment,
    QUOTAS_SCHEMA,
    Usage,
)
from quotas.plans import FREE, Plan, default_plan_for_email, get_plan


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(QUOTAS_SCHEMA)


def current_period() -> int:
    now = datetime.datetime.utcnow()
    return now.year * 100 + now.month


def period_from_epoch(ts: int) -> int:
    dt = datetime.datetime.utcfromtimestamp(ts)
    return dt.year * 100 + dt.month


# ---- plan assignment -----------------------------------------------------

def assign_plan(user_id: str, plan_name: str, assigned_by: Optional[str] = None) -> PlanAssignment:
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO user_plans (user_id, plan_name, assigned_at, assigned_by) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET plan_name = excluded.plan_name, assigned_at = excluded.assigned_at, assigned_by = excluded.assigned_by",
            (user_id, plan_name.lower().strip(), now, assigned_by),
        )
    return PlanAssignment(user_id=user_id, plan_name=plan_name.lower().strip(), assigned_at=now, assigned_by=assigned_by)


def assign_default_for_email(user_id: str, email: str) -> PlanAssignment:
    plan = default_plan_for_email(email)
    return assign_plan(user_id, plan.name)


def get_assignment(user_id: str) -> Optional[PlanAssignment]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM user_plans WHERE user_id = ?", (user_id,)).fetchone()
    return PlanAssignment.from_row(row) if row else None


def get_plan_for(user_id: str) -> Plan:
    a = get_assignment(user_id)
    if a is None:
        return FREE
    return get_plan(a.plan_name)


# ---- usage --------------------------------------------------------------

def increment(user_id: str, metric: str, amount: int = 1) -> int:
    """bump the counter for (user_id, current_period, metric). returns the new value."""
    period: int = current_period()
    now: int = int(time.time())
    with _connect() as conn:
        conn.execute(
            "INSERT INTO quota_usage (user_id, period_yyyymm, metric, used, last_increment_at) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(user_id, period_yyyymm, metric) DO UPDATE SET used = used + excluded.used, last_increment_at = excluded.last_increment_at",
            (user_id, period, metric, amount, now),
        )
        row = conn.execute(
            "SELECT used FROM quota_usage WHERE user_id = ? AND period_yyyymm = ? AND metric = ?",
            (user_id, period, metric),
        ).fetchone()
    return int(row["used"]) if row else 0


def usage_for(user_id: str, period: Optional[int] = None) -> Dict[str, int]:
    """returns { metric: used } for the period. defaults to current month."""
    period = period or current_period()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT metric, used FROM quota_usage WHERE user_id = ? AND period_yyyymm = ?",
            (user_id, period),
        ).fetchall()
    out: Dict[str, int] = {METRIC_CHAT_COMPLETIONS: 0, METRIC_DOCUMENTS: 0, METRIC_SESSIONS: 0}
    for r in rows:
        out[r["metric"]] = int(r["used"])
    return out


def usage_history(user_id: str, months: int = 6) -> List[Usage]:
    """recent usage rows for `months` periods, current first."""
    with _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM quota_usage WHERE user_id = ? ORDER BY period_yyyymm DESC LIMIT ?",
            (user_id, months * 3),   # 3 metrics per period
        ).fetchall()
    return [Usage.from_row(r) for r in rows]


def reset_period(user_id: str, period: Optional[int] = None) -> int:
    """zero out a single user's counters for `period`. returns rows affected."""
    period = period or current_period()
    with _connect() as conn:
        cur = conn.execute(
            "DELETE FROM quota_usage WHERE user_id = ? AND period_yyyymm = ?",
            (user_id, period),
        )
        return cur.rowcount


def reset_everyone_for_period(period: int) -> int:
    """nuke all counters for a period. used by the monthly rollover cron."""
    with _connect() as conn:
        cur = conn.execute("DELETE FROM quota_usage WHERE period_yyyymm = ?", (period,))
        return cur.rowcount


bootstrap()
