"""named plan tiers + their default quotas. simple lookup table, no need for a db."""
from dataclasses import dataclass
from typing import Dict, Final, Optional


@dataclass(frozen=True)
class Plan:
    name: str
    chat_completions_per_month: int
    documents_per_month: int
    sessions_per_month: int
    max_chat_history: int
    rate_limit_per_minute: int


FREE: Final[Plan] = Plan(
    name="free",
    chat_completions_per_month=100,
    documents_per_month=10,
    sessions_per_month=50,
    max_chat_history=20,
    rate_limit_per_minute=10,
)

STUDENT: Final[Plan] = Plan(
    name="student",
    chat_completions_per_month=500,
    documents_per_month=50,
    sessions_per_month=200,
    max_chat_history=50,
    rate_limit_per_minute=20,
)

PRO: Final[Plan] = Plan(
    name="pro",
    chat_completions_per_month=5000,
    documents_per_month=500,
    sessions_per_month=2000,
    max_chat_history=200,
    rate_limit_per_minute=60,
)

ENTERPRISE: Final[Plan] = Plan(
    name="enterprise",
    chat_completions_per_month=1_000_000,
    documents_per_month=10_000,
    sessions_per_month=100_000,
    max_chat_history=1000,
    rate_limit_per_minute=600,
)

# 'unlimited' is a special-case plan we hand out manually. effectively no limits.
UNLIMITED: Final[Plan] = Plan(
    name="unlimited",
    chat_completions_per_month=10**9,
    documents_per_month=10**9,
    sessions_per_month=10**9,
    max_chat_history=10**6,
    rate_limit_per_minute=10**6,
)


PLANS: Final[Dict[str, Plan]] = {
    p.name: p for p in (FREE, STUDENT, PRO, ENTERPRISE, UNLIMITED)
}


def get_plan(name: str) -> Plan:
    """case-insensitive lookup. unknown name falls back to FREE."""
    return PLANS.get(name.lower().strip(), FREE)


def default_plan_for_email(email: str) -> Plan:
    """heuristic: bocconi-flavored emails default to STUDENT, everyone else to FREE."""
    # this is intentionally loose. we DO upgrade them on signup, not gatekeep at use time.
    e = (email or "").lower().strip()
    if any(domain in e for domain in ("@studbocconi.it", "@unibocconi.it", "@bainsa.it")):
        return STUDENT
    return FREE
