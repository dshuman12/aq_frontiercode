"""user-facing quota inspection + admin plan management."""
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from quotas import repository as repo
from quotas.models import METRIC_CHAT_COMPLETIONS, METRIC_DOCUMENTS, METRIC_SESSIONS
from quotas.plans import PLANS
from users.endpoints import current_user


router = APIRouter(prefix="/v1/quotas", tags=["quotas"])


@router.get("/me")
def my_quota(user=Depends(current_user)) -> Dict[str, Any]:
    plan = repo.get_plan_for(user.id)
    usage = repo.usage_for(user.id)
    return {
        "plan": {
            "name": plan.name,
            "chat_completions_per_month": plan.chat_completions_per_month,
            "documents_per_month": plan.documents_per_month,
            "sessions_per_month": plan.sessions_per_month,
        },
        "usage": usage,
        "remaining": {
            "chat_completions": max(0, plan.chat_completions_per_month - usage.get(METRIC_CHAT_COMPLETIONS, 0)),
            "documents": max(0, plan.documents_per_month - usage.get(METRIC_DOCUMENTS, 0)),
            "sessions": max(0, plan.sessions_per_month - usage.get(METRIC_SESSIONS, 0)),
        },
    }


@router.get("/history")
def my_history(user=Depends(current_user)) -> Dict[str, Any]:
    rows = repo.usage_history(user.id, months=12)
    return {"history": [r.public() for r in rows]}


class AssignBody(BaseModel):
    user_id: str = Field(..., min_length=1)
    plan_name: str = Field(..., min_length=1)


@router.post("/assign")
def admin_assign(body: AssignBody, actor=Depends(current_user)) -> Dict[str, Any]:
    """admin-only in spirit; gated once roles land."""
    if body.plan_name.lower().strip() not in PLANS:
        raise HTTPException(status_code=400, detail=f"unknown plan: {body.plan_name!r}")
    a = repo.assign_plan(body.user_id, body.plan_name, assigned_by=actor.id)
    return {"assignment": {"user_id": a.user_id, "plan_name": a.plan_name, "assigned_at": a.assigned_at}}


@router.get("/plans")
def list_known_plans() -> Dict[str, Any]:
    """plan catalog - publicly readable so the ui can render the upgrade page."""
    return {
        "plans": [
            {
                "name": p.name,
                "chat_completions_per_month": p.chat_completions_per_month,
                "documents_per_month": p.documents_per_month,
                "sessions_per_month": p.sessions_per_month,
                "rate_limit_per_minute": p.rate_limit_per_minute,
            }
            for p in PLANS.values()
        ]
    }
