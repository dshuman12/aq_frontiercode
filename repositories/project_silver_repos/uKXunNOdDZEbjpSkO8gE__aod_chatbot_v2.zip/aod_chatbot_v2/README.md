# aod_chatbot

RAG chatbot for **BAINSA AOD (Alliance of Developers) February 2026** event. Indexes a folder of markdown briefs and exposes an OpenAI-compatible `/v1/chat/completions` endpoint that grounds answers in the indexed corpus.

## quickstart

```bash
export OPENAI_API_KEY=sk-...
docker compose up --build
```

→ http://localhost:8501

The first run reads `knowledge_database/*.md`, embeds them, and persists the Chroma store under `./chroma_database`.

## configuration

`config.yaml` ships the defaults:

```yaml
MARKDOWN_DOCS: "./knowledge_database"
EMBEDDING_MODEL: "text-embedding-3-small"
CHROMA_DIRECTORY: "./chroma_database"
MODEL: "gpt-4o-mini"
```

Any value can be overridden at runtime by setting `AOD_<KEY>` in the environment (env wins over yaml). See `.env.example` for the full list.

## auth

By default the API is open (handy for local dev). Set `AOD_API_KEYS` to a comma-separated list of bearer tokens and the endpoint will reject anything without a matching `Authorization: Bearer ...` header.

```bash
export AOD_API_KEYS=key-one,key-two
```

## rate limiting

Sliding-window per caller (per token if auth is on, per client IP otherwise):

```bash
export AOD_RATE_LIMIT=60     # requests
export AOD_RATE_WINDOW=60    # seconds
```

Defaults: 60 req / 60 s.

## request shape

Drop-in OpenAI chat completions:

```json
{
  "model": "gpt-4o-mini",
  "messages": [
    {"role": "system", "content": "You are a helpful chatbot"},
    {"role": "user", "content": "What's BAINSA?"}
  ],
  "temperature": 0.7,
  "stream": false
}
```

Pass `"stream": true` for SSE-style chunked output.

## conversation persistence

Pass an `X-Session-Id` header to attach a request to an existing session, or omit it to spawn a new one. The chatbot persists every user+assistant turn to a sqlite db (`AOD_SESSIONS_DB`, default `./sessions.sqlite`).

```bash
curl -s -H 'X-Session-Id: 7c1d...' \
     -H 'Content-Type: application/json' \
     -d '{"messages":[{"role":"user","content":"hi"}]}' \
     http://localhost:8501/v1/chat/completions
```

session management endpoints:

| method | path                       | what                          |
|--------|----------------------------|-------------------------------|
| GET    | /v1/sessions               | list sessions for the caller  |
| GET    | /v1/sessions/{id}          | fetch full message history    |
| DELETE | /v1/sessions/{id}          | drop a session and its turns  |

## cli

A typer-based CLI ships under `rag.cli`. Most subcommands re-use the same modules the API uses, so they share the same config + sqlite store.

```bash
# (re)build the vector store from knowledge_database/*.md
python -m rag.cli ingest

# one-shot query without booting the server
python -m rag.cli query "what is BAINSA?" --k 5

# inspect persisted sessions
python -m rag.cli sessions list --limit 20
python -m rag.cli sessions show <session_id>
python -m rag.cli sessions export <session_id> ./out.json
python -m rag.cli sessions prune 1209600   # 14 days
```

## accounts and workspaces

Users sign up at `POST /v1/auth/signup` with `{email, password, display_name}`. The response includes a JWT bearer token; pass it as `Authorization: Bearer <token>` on every subsequent call.

```bash
# signup, then login (also returns a token)
curl -X POST localhost:8501/v1/auth/signup -H 'content-type: application/json' \
  -d '{"email":"me@x.com","password":"hunter22-or-similar","display_name":"me"}'

curl localhost:8501/v1/auth/me -H "Authorization: Bearer $TOKEN"
```

Workspaces group sessions and (soon) documents under a multi-tenant boundary. Owner / member / viewer roles. Routes under `/v1/workspaces`. Pass `X-Workspace-Id: <id>` on chat completions to scope a session to a workspace.

## documents

Upload PDFs, DOCX, or plain text via `POST /v1/documents` (multipart). The server parses, chunks, embeds, and writes into the vector store. Status is queryable at `/v1/documents/{job_id}`.

```bash
curl -X POST localhost:8501/v1/documents \
  -H "Authorization: Bearer $TOKEN" \
  -F file=@./meeting_notes.pdf
```

Or use the Streamlit UI's **Documents** page.

## background jobs

`jobs.queue` is a sqlite-backed task queue; `jobs.worker` runs a single in-process worker that polls and dispatches. Run it standalone with:

```bash
python -m rag.cli jobs run
```

Registered task kinds: `ingest_document`, `prune_stale_sessions`, `send_digest` (placeholder).

## streamlit ui

```bash
streamlit run ui/Home.py
```

Pages: Home (sign in/up), Chat, Sessions, Documents, Workspaces, Settings, Analytics, Audit, Webhooks, Quotas.

## analytics + audit + webhooks

`/v1/analytics` exposes event counts, hourly/daily timeseries, and a top-users leaderboard. `/v1/audit` is the immutable record of who did what. `/v1/webhooks` lets you subscribe to event kinds and receive HMAC-signed POST callbacks.

## quotas

Per-user plans (`free` / `student` / `pro` / `enterprise` / `unlimited`) gate the monthly chat-completion / document / session usage. `/v1/quotas/me` shows your current usage and remaining budget. Bocconi-domain emails default to `student` at signup.

## moderation

A small regex-based filter blocks prompt-injection attempts and other obvious bad-faith inputs before they hit the LLM. The rule set lives in `moderation/rules.py`; clients can pre-check with `/v1/moderation/check`.

## prompt templates

Save reusable system prompts under `/v1/templates`. Templates support `{variable}` and `{variable:default}` substitution at render time.

## python sdk

`from sdk import Aod` gives you an openai-style client:

```python
from sdk import Aod
client = Aod(api_key="your-bearer", base_url="http://localhost:8501")
client.auth.login("me@x.com", "longenoughpw")
resp = client.chat.create(messages=[{"role": "user", "content": "What's BAINSA?"}])
```

## stuff that's broken / unfinished

bunch of things i never got around to:

- `ingest` rebuilds the whole chroma store every time, no diff
- chroma + list-typed metadata is annoying, we stringify but it's lossy
- streaming responses skip citations rn (only buffered path returns them)
- no cron for prune yet, run it manually
- sometimes the first request after a cold start times out, probably the chroma init
