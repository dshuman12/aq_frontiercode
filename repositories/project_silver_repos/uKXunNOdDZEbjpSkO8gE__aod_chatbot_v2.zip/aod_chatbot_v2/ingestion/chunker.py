"""text chunking. extracted from create_database.py back when there was only one caller.

uses a simple character-windowed splitter rather than the langchain recursive one for
predictability. the recursive splitter sometimes returned a single 7000-char chunk because
it couldn't find a natural break, which choked the embedding api.
"""
from typing import Iterable, List


DEFAULT_CHUNK_SIZE: int = 1000
DEFAULT_OVERLAP: int = 200
MIN_KEEP: int = 40   # drop trailing fragments smaller than this


def chunk_text(text: str, chunk_size: int = DEFAULT_CHUNK_SIZE, overlap: int = DEFAULT_OVERLAP) -> List[str]:
    """split `text` into ~chunk_size character windows with `overlap` characters of overlap.

    raises ValueError on degenerate config (overlap > chunk_size).
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if overlap < 0:
        raise ValueError("overlap must be non-negative")
    if overlap > chunk_size:
        raise ValueError(f"overlap ({overlap}) must not exceed chunk_size ({chunk_size})")

    text = text or ""
    if len(text) <= chunk_size:
        return [text] if text else []

    step: int = chunk_size - overlap
    out: List[str] = []
    i: int = 0
    while i < len(text):
        window: str = text[i : i + chunk_size]
        if len(window) < MIN_KEEP and out:
            # would be a tiny trailing fragment; just glue it onto the previous chunk
            out[-1] = out[-1] + window
            break
        out.append(window)
        i += step
    return out


def chunk_sections(sections: Iterable, chunk_size: int = DEFAULT_CHUNK_SIZE, overlap: int = DEFAULT_OVERLAP) -> List[dict]:
    """chunk each (text, label) tuple separately. returns a list of dicts ready for embedding."""
    out: List[dict] = []
    for text, label in sections:
        for idx, c in enumerate(chunk_text(text, chunk_size=chunk_size, overlap=overlap)):
            out.append({"text": c, "label": label, "chunk_index": idx})
    return out
