"""document ingestion: parse arbitrary file types into chunks ready for the vector store."""
