"""url fetching + html → text extraction. bs4 because readability-lxml pulls in lxml as a wheel-build."""
from typing import List, Tuple

import httpx
from bs4 import BeautifulSoup

from ingestion.parsers import register


DEFAULT_TIMEOUT_SECONDS: float = 10.0
USER_AGENT: str = "aod-chatbot-ingest/0.1 (+https://bainsa.it)"


def fetch_url(url: str, timeout: float = DEFAULT_TIMEOUT_SECONDS) -> str:
    """returns the response body as text. raises httpx exceptions on transport errors."""
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"}
    with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.text


def html_to_text(html: str) -> List[Tuple[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    # strip noise
    for bad in soup(["script", "style", "noscript", "iframe", "form", "header", "footer", "nav"]):
        bad.decompose()

    out: List[Tuple[str, str]] = []
    # try to keep top-level headings as section anchors
    current_label = "body"
    for el in soup.body.descendants if soup.body else []:
        name = getattr(el, "name", None)
        if name in ("h1", "h2", "h3"):
            current_label = el.get_text(strip=True)[:80] or current_label
            continue
        if name in ("p", "li"):
            text = el.get_text(" ", strip=True)
            if text:
                out.append((text, current_label))

    if not out:
        # fallback: just dump the whole text blob
        whole = soup.get_text("\n", strip=True)
        if whole:
            out.append((whole, "body"))

    return out


def parse_url(url: str) -> List[Tuple[str, str]]:
    return html_to_text(fetch_url(url))


# treat the registry key as "the synthetic mime we use for url inputs"
register("text/x-url", parse_url)
