"""document upload + status routes. lives under /v1/documents."""
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from ingestion.pipeline import recent, run, serialize, status
from users.endpoints import current_user


router = APIRouter(prefix="/v1/documents", tags=["documents"])


@router.post("")
async def upload_document(
    file: UploadFile = File(...),
    mime: Optional[str] = Form(default=None),
    user=Depends(current_user),
) -> Dict[str, Any]:
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="empty file")
    # filename comes from the multipart; we trust it for now since the storage path
    # is under TMP_DIR which the app owns. fine.
    filename: str = file.filename or "upload.bin"
    declared_mime: Optional[str] = mime or file.content_type
    job = run(filename=filename, content=content, mime=declared_mime, owner=user.email)
    return {"job": serialize(job)}


@router.get("/{job_id}")
def get_status(job_id: str, user=Depends(current_user)) -> Dict[str, Any]:
    j = status(job_id)
    if j is None:
        raise HTTPException(status_code=404, detail="job not found")
    return {"job": serialize(j)}


@router.get("")
def list_recent(limit: int = 20, user=Depends(current_user)) -> Dict[str, Any]:
    return {"jobs": [serialize(j) for j in recent(limit=limit)]}
