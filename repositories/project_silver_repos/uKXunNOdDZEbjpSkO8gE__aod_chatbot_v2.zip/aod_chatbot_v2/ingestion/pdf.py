"""pdf extraction via pypdf. pulls plain text per page; loses formatting on purpose."""
from typing import List, Tuple

from pypdf import PdfReader

from ingestion.parsers import register


def parse_pdf(path: str) -> List[Tuple[str, str]]:
    """returns one (text, label) tuple per non-empty page."""
    reader = PdfReader(path)
    out: List[Tuple[str, str]] = []
    # encrypted pdfs without a password silently fall through to empty pages.
    # we don't try to crack them; the caller gets an empty result and a warning is in the
    # http layer, not here.
    if reader.is_encrypted:
        try:
            reader.decrypt("")  # try the empty-string password some pdfs use
        except Exception:
            return out

    for i, page in enumerate(reader.pages, start=1):
        try:
            text: str = page.extract_text() or ""
        except Exception:
            # pypdf occasionally raises on degenerate pages. skip them quietly,
            # we don't want one bad page to kill an entire document.
            continue
        text = text.strip()
        if text:
            out.append((text, f"page-{i}"))
    return out


register("application/pdf", parse_pdf)
