"""docx parsing via python-docx. coalesces paragraphs into a single body, headings labelled."""
from typing import List, Tuple

from docx import Document as _DocxDoc

from ingestion.parsers import register


_HEADING_STYLES = {"Heading 1", "Heading 2", "Heading 3", "Heading 4", "Title"}


def parse_docx(path: str) -> List[Tuple[str, str]]:
    doc = _DocxDoc(path)
    sections: List[Tuple[str, str]] = []
    current_label: str = "body"
    buf: List[str] = []

    def _flush() -> None:
        nonlocal buf
        body = "\n".join(buf).strip()
        if body:
            sections.append((body, current_label))
        buf = []

    for para in doc.paragraphs:
        text: str = (para.text or "").strip()
        if not text:
            continue
        style: str = (para.style.name or "") if para.style else ""
        if style in _HEADING_STYLES:
            _flush()
            current_label = text[:60]
            continue
        buf.append(text)

    _flush()
    return sections


register("application/vnd.openxmlformats-officedocument.wordprocessingml.document", parse_docx)
register("application/msword", parse_docx)   # close enough; legacy .doc rarely shows up
