"""mime-type dispatch for the supported document formats."""
import mimetypes
import os
from typing import Callable, Dict, List, Optional, Tuple


# (text, page_or_section_label) tuples come out the other side. simple enough that we don't
# need a dataclass for this hot path.
ParseResult = List[Tuple[str, str]]


def _guess_mime(path: str, declared: Optional[str] = None) -> str:
    if declared:
        return declared.lower().strip()
    # mimetypes can't sniff content, just guesses from extension. that's fine for now.
    mt, _ = mimetypes.guess_type(path)
    if mt:
        return mt
    # last-ditch: stuff we can't identify gets treated as plain text. risky but pragmatic.
    return "text/plain"


_REGISTRY: Dict[str, Callable[[str], ParseResult]] = {}


def register(mime: str, fn: Callable[[str], ParseResult]) -> None:
    _REGISTRY[mime.lower().strip()] = fn


def supported_mimes() -> List[str]:
    return sorted(_REGISTRY.keys())


def parse(path: str, mime: Optional[str] = None) -> ParseResult:
    """dispatch to the right parser. raises ValueError when the mime isn't registered."""
    mt: str = _guess_mime(path, mime)
    fn = _REGISTRY.get(mt)
    if fn is None:
        # try a few aliases before giving up
        aliases = {
            "application/x-pdf": "application/pdf",
            "text/x-markdown": "text/markdown",
        }
        fn = _REGISTRY.get(aliases.get(mt, ""), None)
    if fn is None:
        raise ValueError(f"no parser registered for mime type: {mt!r}")
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return fn(path)


# plain-text fallback. always registered.
def _parse_text(path: str) -> ParseResult:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return [(f.read(), "body")]


register("text/plain", _parse_text)
register("text/markdown", _parse_text)
