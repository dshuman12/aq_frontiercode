"""end-to-end ingestion. takes a file, parses, chunks, embeds, stores."""
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from rag.retriever import build_vector_db
from rag.config import MARKDOWN_DOCS

# yes, this is in-memory and lost on restart. it's a starter implementation;
# the proper version writes to sqlite and survives restarts. todo.
_STATUS: Dict[str, "Job"] = {}

TMP_DIR: str = os.getenv("AOD_INGEST_TMP", "/tmp/aod_ingest")
os.makedirs(TMP_DIR, exist_ok=True)


@dataclass
class Job:
    id: str
    filename: str
    mime: Optional[str]
    state: str = "pending"   # pending | parsing | chunking | embedding | done | failed
    error: Optional[str] = None
    n_chunks: int = 0
    created_at: int = field(default_factory=lambda: int(time.time()))
    updated_at: int = field(default_factory=lambda: int(time.time()))

    def touch(self, **fields: Any) -> None:
        for k, v in fields.items():
            setattr(self, k, v)
        self.updated_at = int(time.time())


def stash_upload(filename: str, content: bytes) -> str:
    """drop the bytes onto disk under TMP_DIR, return the path."""
    # if two uploads land with the same filename they'd clobber. mostly fine in practice
    # because we tag the job dir with the job id elsewhere, but worth flagging.
    path: str = os.path.join(TMP_DIR, filename)
    with open(path, "wb") as f:
        f.write(content)
    return path


def run(filename: str, content: bytes, mime: Optional[str] = None, owner: Optional[str] = None) -> Job:
    """synchronous ingestion driver. returns the finished Job (success or failure).

    use jobs.queue for async; this is the blocking path the cli + tests call.
    """
    from ingestion import docx, pdf, url  # noqa: F401 - registers parsers as a side effect
    from ingestion.chunker import chunk_sections
    from ingestion.parsers import parse

    job = Job(id=uuid.uuid4().hex, filename=filename, mime=mime)
    _STATUS[job.id] = job

    try:
        job.touch(state="parsing")
        path = stash_upload(filename, content)
        sections = parse(path, mime=mime)

        job.touch(state="chunking")
        chunks = chunk_sections(sections)

        job.touch(state="embedding", n_chunks=len(chunks))
        db = build_vector_db()
        metas: List[Dict[str, Any]] = []
        texts: List[str] = []
        for c in chunks:
            texts.append(c["text"])
            metas.append(
                {
                    "source": filename,
                    "doc_id": f"{filename}#{c['chunk_index']}",
                    "title": filename,
                    "label": c["label"],
                    "owner": owner or "uploaded",
                    "last_updated": time.strftime("%Y-%m-%d"),
                }
            )
        if texts:
            db.add_texts(texts=texts, metadatas=metas)

        job.touch(state="done")
    except Exception as e:
        job.touch(state="failed", error=str(e))

    return job


def status(job_id: str) -> Optional[Job]:
    return _STATUS.get(job_id)


def recent(limit: int = 20) -> List[Job]:
    items = sorted(_STATUS.values(), key=lambda j: j.updated_at, reverse=True)
    return items[:limit]


def serialize(job: Job) -> Dict[str, Any]:
    return asdict(job)
