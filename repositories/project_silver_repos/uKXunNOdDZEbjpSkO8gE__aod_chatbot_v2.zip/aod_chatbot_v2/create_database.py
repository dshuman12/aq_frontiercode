# | output: false
# | echo: false

import os
import frontmatter
from glob import glob
from typing import Any, Dict, List, Optional

from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain.schema import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from rag.config import CHROMA_DIRECTORY, COLLECTION_NAME, EMBEDDING_MODEL, MARKDOWN_DOCS, require_api_key


def creating_db() -> Optional[Chroma]:
    """
    Create or load a vector store database for embeddings.
    """

    # few sanity checks
    require_api_key()
    if not os.path.exists(CHROMA_DIRECTORY):
        os.makedirs(CHROMA_DIRECTORY)

    embeddings: OpenAIEmbeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
    vector_store: Optional[Chroma] = None

    try:
        vector_store = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=embeddings,
            persist_directory=CHROMA_DIRECTORY,
        )
    except Exception as e:
        print(f"Error creating or loading vector store: {e}")

    return vector_store


def parsing_docs() -> List[Document]:
    """
    Ingests markdown documents and parses the YAML front matter.
    """
    docs: List[Document] = []
    files: List[str] = glob(f"{MARKDOWN_DOCS}/*.md")
    for file_path in files:
        with open(file_path, "r", encoding="utf-8") as file:
            post = frontmatter.load(file)

            # extract metadata from yaml header
            meta: Dict[str, Any] = post.metadata
            meta["source"] = os.path.basename(file_path)
            meta["doc_id"] = meta.get("doc_id", meta["source"])
            meta["title"] = meta.get("title", meta["source"])
            meta["last_updated"] = meta.get("last_updated", "2026_02_13")
            meta["tags"] = meta.get("tags", [])
            meta["audience"] = meta.get("audience", "general")
            meta["owner"] = meta.get("owner", "BAINSA")

        # using langchain Document class we can create document objects with metadata
        docs.append(Document(page_content=post.content, metadata=meta))
    return docs


def doc_chunker(documents: List[Document]) -> List[Document]:
    """
    Creates  smaller chuncks of documents from bigger size docs
    """

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        separators=["\n## ", "\n### ", "\n", " ", "#", "##", "###"]
    )

    return splitter.split_documents(documents)


def inserting_document_chunks(chroma_db: Chroma, text_chunks: List[Document]) -> None:
    chroma_db.add_documents(documents=text_chunks)


def main() -> None:
    storage: Optional[Chroma] = creating_db()

    if storage:
        documents: List[Document] = parsing_docs()
        chunks: List[Document] = doc_chunker(documents)
        inserting_document_chunks(storage, chunks)
    else:
        print("Failed to create chroma database")


if __name__ == "__main__":
    main()
