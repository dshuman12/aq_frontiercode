"""official-ish python client for the aod_chatbot api. drop-in for openai-style clients.

usage:
    from sdk import Aod
    client = Aod(api_key='your-token', base_url='http://localhost:8501')
    resp = client.chat.create(messages=[{'role':'user','content':'hi'}])
"""
from sdk.client import Aod, AodAsync, AodError

__all__ = ["Aod", "AodAsync", "AodError"]
