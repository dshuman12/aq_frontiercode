"""sync + async client wrappers. structured similar to the openai sdk so users feel at home.

`client.chat.create(...)` for chat completions
`client.sessions.list()` for sessions
`client.documents.upload(file)` for ingest
`client.workspaces.create(name='x')` etc.

each resource group is a thin object whose methods call into the underlying httpx Client.
"""
import json
import os
from typing import Any, Awaitable, Dict, Iterable, List, Optional, Union

import httpx


DEFAULT_BASE_URL: str = os.getenv("AOD_API_BASE", "http://localhost:8501")
DEFAULT_TIMEOUT: float = 60.0


class AodError(Exception):
    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


def _bearer_headers(token: Optional[str]) -> Dict[str, str]:
    h: Dict[str, str] = {"accept": "application/json"}
    if token:
        h["authorization"] = f"Bearer {token}"
    return h


def _check(r: httpx.Response) -> Dict[str, Any]:
    if r.is_success:
        try:
            return r.json()
        except json.JSONDecodeError:
            return {"raw": r.text}
    try:
        detail = r.json().get("detail", r.text)
    except (json.JSONDecodeError, ValueError):
        detail = r.text
    raise AodError(r.status_code, str(detail))


# ---- sync ---------------------------------------------------------------


class _ChatResource:
    def __init__(self, parent: "Aod") -> None:
        self._parent = parent

    def create(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        stream: bool = False,
        session_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"messages": messages, "stream": stream}
        if model is not None:
            body["model"] = model
        if temperature is not None:
            body["temperature"] = temperature
        headers = _bearer_headers(self._parent.api_key)
        if session_id:
            headers["x-session-id"] = session_id
        if workspace_id:
            headers["x-workspace-id"] = workspace_id
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.post(f"{self._parent.base_url}/v1/chat/completions", json=body, headers=headers)
        return _check(r)


class _SessionsResource:
    def __init__(self, parent: "Aod") -> None:
        self._parent = parent

    def list(self, limit: int = 20, offset: int = 0) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(
                f"{self._parent.base_url}/v1/sessions",
                params={"limit": limit, "offset": offset},
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def get(self, session_id: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(
                f"{self._parent.base_url}/v1/sessions/{session_id}",
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def delete(self, session_id: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.delete(
                f"{self._parent.base_url}/v1/sessions/{session_id}",
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)


class _DocumentsResource:
    def __init__(self, parent: "Aod") -> None:
        self._parent = parent

    def upload(self, filename: str, content: bytes, mime: Optional[str] = None) -> Dict[str, Any]:
        files = {"file": (filename, content, mime or "application/octet-stream")}
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.post(
                f"{self._parent.base_url}/v1/documents",
                files=files,
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def status(self, job_id: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(
                f"{self._parent.base_url}/v1/documents/{job_id}",
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def list(self, limit: int = 20) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(
                f"{self._parent.base_url}/v1/documents",
                params={"limit": limit},
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)


class _WorkspacesResource:
    def __init__(self, parent: "Aod") -> None:
        self._parent = parent

    def create(self, name: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.post(
                f"{self._parent.base_url}/v1/workspaces",
                json={"name": name},
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def list(self) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(
                f"{self._parent.base_url}/v1/workspaces",
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)

    def delete(self, workspace_id: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.delete(
                f"{self._parent.base_url}/v1/workspaces/{workspace_id}",
                headers=_bearer_headers(self._parent.api_key),
            )
        return _check(r)


class _AuthResource:
    def __init__(self, parent: "Aod") -> None:
        self._parent = parent

    def signup(self, email: str, password: str, display_name: Optional[str] = None) -> Dict[str, Any]:
        body = {"email": email, "password": password, "display_name": display_name}
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.post(f"{self._parent.base_url}/v1/auth/signup", json=body)
        out = _check(r)
        if "token" in out:
            self._parent.api_key = out["token"]   # auto-set on signup
        return out

    def login(self, email: str, password: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.post(f"{self._parent.base_url}/v1/auth/login", json={"email": email, "password": password})
        out = _check(r)
        if "token" in out:
            self._parent.api_key = out["token"]
        return out

    def me(self) -> Dict[str, Any]:
        with httpx.Client(timeout=self._parent.timeout) as c:
            r = c.get(f"{self._parent.base_url}/v1/auth/me", headers=_bearer_headers(self._parent.api_key))
        return _check(r)


class Aod:
    """sync client. resources accessible as attributes (chat, sessions, documents, ...)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key: Optional[str] = api_key
        self.base_url: str = base_url.rstrip("/")
        self.timeout: float = timeout

        self.auth = _AuthResource(self)
        self.chat = _ChatResource(self)
        self.sessions = _SessionsResource(self)
        self.documents = _DocumentsResource(self)
        self.workspaces = _WorkspacesResource(self)

    def health(self) -> Dict[str, Any]:
        with httpx.Client(timeout=self.timeout) as c:
            r = c.get(f"{self.base_url}/v1/health", headers=_bearer_headers(self.api_key))
        return _check(r)


# ---- async --------------------------------------------------------------


class _AsyncChatResource:
    def __init__(self, parent: "AodAsync") -> None:
        self._parent = parent

    async def create(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        stream: bool = False,
        session_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"messages": messages, "stream": stream}
        if model is not None:
            body["model"] = model
        if temperature is not None:
            body["temperature"] = temperature
        headers = _bearer_headers(self._parent.api_key)
        if session_id:
            headers["x-session-id"] = session_id
        if workspace_id:
            headers["x-workspace-id"] = workspace_id
        async with httpx.AsyncClient(timeout=self._parent.timeout) as c:
            r = await c.post(f"{self._parent.base_url}/v1/chat/completions", json=body, headers=headers)
        return _check(r)


class AodAsync:
    """async variant - same resource shape but each method is `async def`."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key: Optional[str] = api_key
        self.base_url: str = base_url.rstrip("/")
        self.timeout: float = timeout

        self.chat = _AsyncChatResource(self)
