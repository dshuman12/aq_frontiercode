"""one-off seed for local dev. creates a handful of accounts so the ui isn't empty.

NOT for production. obviously.

usage:
    python scripts/seed_dev_users.py

re-running is idempotent in spirit (skips existing emails). passwords are hardcoded,
which i know is bad, but this is a seeder. live with it.
"""
import os
import sys


# make the repo root importable when this is run as `python scripts/seed_dev_users.py`
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


DEFAULT_USERS = [
    {"email": "alice@bainsa.it", "password": "alicepass1!", "display_name": "Alice (dev)"},
    {"email": "bob@bainsa.it", "password": "bobpass1!", "display_name": "Bob (dev)"},
    {"email": "carla@bainsa.it", "password": "carlapass1!", "display_name": "Carla (dev)"},
    {"email": "dev@bainsa.it", "password": "devpass1!", "display_name": "Dev account"},
]


def main() -> int:
    if os.getenv("AOD_ENV", "dev") != "dev":
        print("refusing to seed outside dev. set AOD_ENV=dev to override.", file=sys.stderr)
        return 2

    from users.passwords import hash_password
    from users.repository import create_user, get_user_by_email

    created = 0
    skipped = 0
    for u in DEFAULT_USERS:
        if get_user_by_email(u["email"]):
            print(f"skip: {u['email']} already exists")
            skipped += 1
            continue
        try:
            ph = hash_password(u["password"])
        except ValueError as e:
            print(f"skip: {u['email']} (password rejected: {e})")
            skipped += 1
            continue
        create_user(email=u["email"], password_hash=ph, display_name=u["display_name"])
        print(f"created: {u['email']}")
        created += 1

    print(f"\ndone. {created} created, {skipped} skipped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
