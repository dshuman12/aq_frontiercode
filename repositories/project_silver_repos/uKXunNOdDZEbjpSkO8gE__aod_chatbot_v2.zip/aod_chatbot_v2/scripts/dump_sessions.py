"""dump every session and its messages to a json file. for offline inspection.

usage:
    python scripts/dump_sessions.py > dump.json
or:
    python scripts/dump_sessions.py --out backup.json --caller alice@bainsa.it
"""
import argparse
import json
import os
import sys
import time


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=None, help="write to file instead of stdout")
    parser.add_argument("--caller", default=None, help="scope to a single caller / api key")
    parser.add_argument("--limit", type=int, default=10_000, help="max sessions to walk")
    args = parser.parse_args()

    from rag.sessions import list_sessions, load_messages

    sessions = list_sessions(caller=args.caller, limit=args.limit, offset=0)
    out = {
        "exported_at": int(time.time()),
        "caller_filter": args.caller,
        "n_sessions": len(sessions),
        "sessions": [],
    }
    for s in sessions:
        msgs = load_messages(s["id"])
        out["sessions"].append(
            {
                "id": s["id"],
                "caller": s.get("caller"),
                "created_at": s.get("created_at"),
                "last_seen": s.get("last_seen"),
                "messages": [{"role": m.role, "content": m.content} for m in msgs],
            }
        )

    payload = json.dumps(out, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(payload)
        print(f"wrote {len(payload)} bytes to {args.out}", file=sys.stderr)
    else:
        sys.stdout.write(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
