"""find messages whose session_id no longer exists. shouldn't happen with FK on, but
i found like 12 of them in dev once after a manual sqlite poke. this is just a sanity
script.

usage: python scripts/find_orphan_messages.py
"""
import os
import sqlite3
import sys


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def main() -> int:
    from rag.config import SESSIONS_DB

    if not os.path.exists(SESSIONS_DB):
        print(f"no db at {SESSIONS_DB}", file=sys.stderr)
        return 1

    conn = sqlite3.connect(SESSIONS_DB)
    conn.row_factory = sqlite3.Row
    # this could be a LEFT JOIN but the WHERE NOT EXISTS form is easier to read imo
    rows = conn.execute(
        "SELECT m.id, m.session_id, m.role, m.created_at "
        "FROM messages m "
        "WHERE NOT EXISTS (SELECT 1 FROM sessions s WHERE s.id = m.session_id) "
        "ORDER BY m.created_at"
    ).fetchall()

    if not rows:
        print("no orphan messages found")
        return 0

    print(f"found {len(rows)} orphan messages:")
    for r in rows:
        print(f"  msg {r['id']} ({r['role']}) -> session {r['session_id']}  at ts={r['created_at']}")
    print("\nrun:  sqlite3 sessions.sqlite 'DELETE FROM messages WHERE session_id NOT IN (SELECT id FROM sessions);'")
    print("to clean them up (manually for now, no script will do it without confirmation).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
