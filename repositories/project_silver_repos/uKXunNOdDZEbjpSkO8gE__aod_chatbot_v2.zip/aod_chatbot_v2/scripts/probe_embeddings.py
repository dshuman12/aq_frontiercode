"""one-off probe: send a tiny string to OpenAI embeddings + show the vector dim.

useful when the api key changes or when chroma decides to throw weird errors and you
want to know if it's openai or chroma's fault.

i kept hitting `incompatible dimensions` and this was the fastest way to see what
text-embedding-3-small actually returned today.
"""
import os
import sys


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def main() -> int:
    if not os.getenv("OPENAI_API_KEY"):
        print("OPENAI_API_KEY not set", file=sys.stderr)
        return 2

    from langchain_openai import OpenAIEmbeddings

    sample = "the quick brown fox jumps over the lazy dog"
    model = os.getenv("AOD_EMBEDDING_MODEL", "text-embedding-3-small")
    emb = OpenAIEmbeddings(model=model)
    vec = emb.embed_query(sample)
    print(f"model={model}")
    print(f"input={sample!r}")
    print(f"dim={len(vec)}")
    print(f"first 5 = {vec[:5]}")
    print(f"last 5  = {vec[-5:]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
