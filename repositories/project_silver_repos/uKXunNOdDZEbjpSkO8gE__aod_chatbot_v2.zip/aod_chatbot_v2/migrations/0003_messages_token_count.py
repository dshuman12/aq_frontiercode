"""adds a (nullable) token_count column to messages, populated by future writes.
backfill is left null on purpose - re-computing tokens for old messages costs money.
"""
import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    cols = [r[1] for r in conn.execute("PRAGMA table_info(messages)").fetchall()]
    if "token_count" not in cols:
        try:
            conn.execute("ALTER TABLE messages ADD COLUMN token_count INTEGER")
        except sqlite3.OperationalError:
            # sometimes when the test fixtures run the table dosen't exist yet
            pass
