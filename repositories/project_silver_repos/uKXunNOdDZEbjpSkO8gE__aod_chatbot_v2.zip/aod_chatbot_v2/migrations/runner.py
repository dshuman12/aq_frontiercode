"""tiny forward-only migration runner. records applied migrations in a tracking table.

each migration is a python function `def upgrade(conn): ...`. that's it. no down().
if you need to roll back, write a new migration that does the opposite, like real db
people. (yes ive been bitten by 'auto-generated rollbacks' before.)
"""
import importlib
import logging
import os
import pkgutil
import re
import sqlite3
import time
from typing import Callable, List, Tuple


log = logging.getLogger("aod.migrations")


SCHEMA_MIGRATIONS: str = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    description TEXT,
    applied_at INTEGER NOT NULL
);
"""


# migrations are python modules under migrations/, named NNNN_description.py.
# the number sorts lexically so 0001, 0002, ... 9999 works.
_FILENAME_RE = re.compile(r"^(\d{4})_([a-z0-9_]+)$")


def _discover() -> List[Tuple[str, str]]:
    """returns [(version, module_name)] sorted by version."""
    import migrations as pkg
    out: List[Tuple[str, str]] = []
    for finder, name, ispkg in pkgutil.iter_modules(pkg.__path__):
        if ispkg:
            continue
        m = _FILENAME_RE.match(name)
        if not m:
            continue
        version = m.group(1)
        out.append((version, name))
    return sorted(out, key=lambda t: t[0])


def _applied_versions(conn: sqlite3.Connection) -> set:
    conn.execute(SCHEMA_MIGRATIONS)
    rows = conn.execute("SELECT version FROM schema_migrations").fetchall()
    return {r["version"] for r in rows}


def _record_applied(conn: sqlite3.Connection, version: str, description: str) -> None:
    conn.execute(
        "INSERT INTO schema_migrations (version, description, applied_at) VALUES (?, ?, ?)",
        (version, description, int(time.time())),
    )


def _load_upgrade(module_name: str) -> Callable[[sqlite3.Connection], None]:
    """import the module and return its `upgrade` callable. raises AttributeError if missing."""
    mod = importlib.import_module(f"migrations.{module_name}")
    fn = getattr(mod, "upgrade", None)
    if not callable(fn):
        raise AttributeError(f"migration {module_name} has no upgrade(conn) function")
    return fn


def apply_all(db_path: str) -> List[str]:
    """apply every pending migration. returns list of versions newly applied."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    applied_now: List[str] = []
    try:
        already = _applied_versions(conn)
        for version, module_name in _discover():
            if version in already:
                continue
            log.info("applying migration", extra={"version": version, "module": module_name})
            fn = _load_upgrade(module_name)
            # the migration owns its transaction; we just commit at the end
            fn(conn)
            description = module_name[5:].replace("_", " ")  # skip 'NNNN_'
            _record_applied(conn, version, description)
            conn.commit()
            applied_now.append(version)
    finally:
        conn.close()
    return applied_now


def applied_status(db_path: str) -> List[dict]:
    """returns the list of applied migrations, ordered. handy for the cli."""
    if not os.path.exists(db_path):
        return []
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT version, description, applied_at FROM schema_migrations ORDER BY version ASC"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        # table doesn't exist yet - no migrations have ever run
        return []
    finally:
        conn.close()


def pending(db_path: str) -> List[str]:
    """which migrations would `apply_all` run? returns versions in apply-order."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        already = _applied_versions(conn)
        return [v for v, _ in _discover() if v not in already]
    finally:
        conn.close()
