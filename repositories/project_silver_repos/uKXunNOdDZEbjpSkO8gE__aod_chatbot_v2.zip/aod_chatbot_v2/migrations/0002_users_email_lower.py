"""make sure all emails are lowercase. early bug: signup used to store mixed case,
which broke `WHERE email = ?` lookups bc they were always normalized to lowercase."""
import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    try:
        conn.execute("UPDATE users SET email = LOWER(email) WHERE email IS NOT NULL AND email != LOWER(email)")
    except sqlite3.OperationalError:
        # users table might not exist yet on a totally fresh db; safe to skip
        pass
