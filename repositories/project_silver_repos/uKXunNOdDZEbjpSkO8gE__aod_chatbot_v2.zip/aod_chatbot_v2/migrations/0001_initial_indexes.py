"""initial migration. adds a couple of indexes that the bootstrap() scripts forgot.

(rly. the boostrap scripts where written hastily and the indexes where added later but
i dont want them ot be missing in fresh installs, so they go here too.)
"""
import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    # cover the most common WHERE clauses we hit at runtime
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_caller ON sessions(caller);")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_last_seen ON sessions(last_seen);")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);")
