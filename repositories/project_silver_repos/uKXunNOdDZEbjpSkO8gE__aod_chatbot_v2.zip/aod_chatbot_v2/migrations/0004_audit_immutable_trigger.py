"""enforce append-only on the audit_log via a sqlite trigger that blocks updates.

doesnt block deletes - sometimes we genuinly need to purge for gdpr.
"""
import sqlite3


def upgrade(conn: sqlite3.Connection) -> None:
    # idempotent: drop+recreate so we always have a known good version
    try:
        conn.execute("DROP TRIGGER IF EXISTS audit_log_no_update")
        conn.execute(
            """
            CREATE TRIGGER audit_log_no_update
            BEFORE UPDATE ON audit_log
            FOR EACH ROW
            BEGIN
                SELECT RAISE(ABORT, 'audit_log is append-only - use a new row instead of UPDATE');
            END;
            """
        )
    except sqlite3.OperationalError:
        # audit_log table not bootstrapped yet - this trigger will get re-applied on next run
        pass
