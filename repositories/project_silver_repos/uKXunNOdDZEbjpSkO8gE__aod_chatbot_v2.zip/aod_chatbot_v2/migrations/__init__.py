"""schema migrations. NOT a replacement for alembic. just enough to apply
forward-only changes without me having to write ALTER TABLE in every bootstrap()."""
