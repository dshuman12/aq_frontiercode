"""dependency-free fallback reranker. uses bag-of-words term-overlap scoring + metadata
boosts. nowhere near as good as a cross-encoder, but it doesn't need a model file.
"""
import math
import re
from collections import Counter
from typing import Dict, List, Set

from langchain_core.documents import Document

from reranker.base import ScoredDoc, sort_scored


_TOKEN_RE = re.compile(r"\w{2,}", re.UNICODE)


# english + italian stop words. far from complete; just the ones that show up a lot.
STOP_WORDS: Set[str] = {
    # english
    "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be", "been", "being",
    "to", "of", "in", "on", "at", "by", "for", "with", "from", "as", "this", "that", "these",
    "those", "it", "its", "i", "you", "he", "she", "we", "they", "them", "my", "your", "do",
    "does", "did", "has", "have", "had", "not", "no", "so", "if", "then", "than", "what",
    "which", "when", "where", "how", "why",
    # italian
    "il", "lo", "la", "i", "gli", "le", "un", "uno", "una", "di", "del", "della", "dei",
    "delle", "degli", "dello", "in", "nel", "nella", "nei", "nelle", "su", "sul", "sulla",
    "con", "per", "tra", "fra", "che", "ma", "se", "anche", "come", "quando", "dove", "perche",
    "perché", "questo", "quello", "questi", "quelli", "questa", "quella", "queste", "quelle",
    "io", "tu", "noi", "voi", "loro", "lui", "lei", "non", "sono", "sei", "siamo", "siete",
    "essere", "stato", "stata",
}


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(text or "") if t.lower() not in STOP_WORDS]


def jaccard(a: Set[str], b: Set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def tf_idf_dot(query_tokens: List[str], doc_tokens: List[str], all_doc_tokens: List[List[str]]) -> float:
    """rough tf-idf dot product. recomputed per query - fine for our retrieval batch sizes."""
    q_counter = Counter(query_tokens)
    d_counter = Counter(doc_tokens)
    if not q_counter or not d_counter:
        return 0.0
    n_docs = max(1, len(all_doc_tokens))
    df: Counter = Counter()
    for toks in all_doc_tokens:
        df.update(set(toks))
    score = 0.0
    for tok, qf in q_counter.items():
        if tok not in d_counter:
            continue
        idf = math.log((1 + n_docs) / (1 + df[tok])) + 1
        score += qf * d_counter[tok] * idf * idf
    return score


# metadata boosts: prefer canonical docs over archived, prefer recent updates, etc.
METADATA_BOOSTS: Dict[str, float] = {
    "canonical": 0.20,
    "audience_match": 0.10,
    "recent": 0.05,
}


def metadata_boost(doc: Document, query_tokens: List[str]) -> float:
    meta = doc.metadata or {}
    boost = 0.0
    if meta.get("canonical") is True or meta.get("canonical") == "true":
        boost += METADATA_BOOSTS["canonical"]
    if meta.get("archived") is True or meta.get("archived") == "true":
        boost -= 0.30   # penalty
    last_updated = str(meta.get("last_updated", ""))
    if last_updated.startswith("2026"):
        boost += METADATA_BOOSTS["recent"]
    # tag overlap - meta.tags might be a list OR comma-separated string thanks to chroma's quirks
    raw_tags = meta.get("tags", "")
    if isinstance(raw_tags, str):
        tags = [t.strip().lower() for t in raw_tags.split(",") if t.strip()]
    elif isinstance(raw_tags, list):
        tags = [str(t).strip().lower() for t in raw_tags]
    else:
        tags = []
    qset = set(query_tokens)
    if any(t in qset for t in tags):
        boost += 0.08
    return boost


class HeuristicReranker:
    """jaccard + tf-idf + metadata boosts. cheap enough to run on every retrieval."""

    name: str = "heuristic-v1"

    def rerank(self, query: str, docs: List[Document], top_k: int) -> List[ScoredDoc]:
        if not docs:
            return []
        q_tokens = tokenize(query)
        all_doc_tokens = [tokenize(d.page_content or "") for d in docs]
        q_set = set(q_tokens)

        scored: List[ScoredDoc] = []
        for doc, doc_tokens in zip(docs, all_doc_tokens):
            d_set = set(doc_tokens)
            j = jaccard(q_set, d_set)
            t = tf_idf_dot(q_tokens, doc_tokens, all_doc_tokens)
            # normalize tf-idf into a 0..1-ish range by dividing by a soft max
            t_norm = t / (1 + t)
            mb = metadata_boost(doc, q_tokens)
            # weighted combo. weights chosen by feel; tune later
            final = 0.4 * j + 0.5 * t_norm + mb
            scored.append(ScoredDoc(document=doc, score=final, rank=0))

        scored = sort_scored(scored)
        return scored[: max(0, top_k)]
