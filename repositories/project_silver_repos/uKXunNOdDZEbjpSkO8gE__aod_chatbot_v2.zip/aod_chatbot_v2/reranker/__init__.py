"""reranker layer for the retriever. wraps the chroma-returned docs with a second pass."""
