"""glue between the retriever and the reranker. picked at startup based on env."""
import os
from typing import List, Optional

from langchain_core.documents import Document

from reranker.base import Reranker, ScoredDoc, sort_scored
from reranker.heuristic import HeuristicReranker


_DISABLED: bool = os.getenv("AOD_RERANKER", "heuristic").lower() in ("0", "off", "none", "disabled", "")
_CURRENT: Optional[Reranker] = None


def get_reranker() -> Optional[Reranker]:
    """returns None when AOD_RERANKER is disabled. otherwise lazy-builds + caches."""
    global _CURRENT
    if _DISABLED:
        return None
    if _CURRENT is None:
        _CURRENT = HeuristicReranker()
    return _CURRENT


def maybe_rerank(query: str, docs: List[Document], top_k: int) -> List[Document]:
    """convenience: if reranker is enabled, rerank and return top_k Documents in order.
    otherwise pass through (truncated to top_k).
    """
    r = get_reranker()
    if r is None:
        return docs[:top_k]
    scored = r.rerank(query, docs, top_k=top_k)
    return [s.document for s in scored]


def explain(query: str, docs: List[Document], top_k: int) -> List[ScoredDoc]:
    """useful for debugging - returns the ScoredDoc list so callers see the scores."""
    r = get_reranker()
    if r is None:
        # fake scores for the passthrough path: linear decay
        out: List[ScoredDoc] = []
        for i, d in enumerate(docs[:top_k]):
            out.append(ScoredDoc(document=d, score=1.0 - (i * 0.01), rank=i + 1))
        return out
    return r.rerank(query, docs, top_k=top_k)
