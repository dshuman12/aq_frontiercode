"""abstract interface + ScoredDoc dataclass."""
from dataclasses import dataclass
from typing import List, Protocol

from langchain_core.documents import Document


@dataclass
class ScoredDoc:
    """a document with a rerank score attached. higher is better."""
    document: Document
    score: float
    rank: int   # 1-based final rank after reranking


class Reranker(Protocol):
    """anything that can take (query, docs) and produce ordered ScoredDocs."""

    def rerank(self, query: str, docs: List[Document], top_k: int) -> List[ScoredDoc]:
        ...

    @property
    def name(self) -> str:
        ...


def sort_scored(scored: List[ScoredDoc]) -> List[ScoredDoc]:
    """sort by score desc and reassign 1-based ranks. mutates the input list's rank field."""
    scored = sorted(scored, key=lambda s: s.score, reverse=True)
    for i, s in enumerate(scored, start=1):
        s.rank = i
    return scored


def topk(scored: List[ScoredDoc], k: int) -> List[ScoredDoc]:
    """slice helper. assumes already sorted; doesn't re-rank."""
    if k <= 0:
        return []
    return scored[:k]
