"""record events into the events table. fire-and-forget; never raises to the caller."""
import json
import logging
import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

from rag.sessions import _connect
from analytics.models import EVENTS_SCHEMA, Event, EventDraft


log = logging.getLogger("aod.analytics")


def bootstrap() -> None:
    with _connect() as conn:
        conn.executescript(EVENTS_SCHEMA)


def _to_payload_str(payload: Optional[Dict[str, Any]]) -> str:
    if not payload:
        return "{}"
    try:
        # default=str lets us pass datetimes / uuids through without crashing
        return json.dumps(payload, default=str)
    except Exception:
        # last resort - never let the analytics layer kill a request
        log.warning("could not serialize event payload, falling back to repr", extra={"payload_type": type(payload).__name__})
        return json.dumps({"_unserializable": repr(payload)[:500]})


def record(draft: EventDraft) -> Optional[int]:
    """returns the row id on success, None on failure. failure is logged but not raised."""
    now: int = int(time.time())
    payload_str: str = _to_payload_str(draft.payload)
    try:
        with _connect() as conn:
            cur = conn.execute(
                "INSERT INTO events (kind, user_id, workspace_id, session_id, request_id, payload, occurred_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (draft.kind, draft.user_id, draft.workspace_id, draft.session_id, draft.request_id, payload_str, now),
            )
            return cur.lastrowid
    except Exception as e:
        log.warning("analytics record failed", extra={"kind": draft.kind, "error": str(e)})
        return None


def record_kind(
    kind: str,
    user_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    session_id: Optional[str] = None,
    request_id: Optional[str] = None,
    **payload: Any,
) -> Optional[int]:
    """convenience wrapper. record_kind('chat.completion', user_id='u-1', tokens=100)."""
    draft = EventDraft(
        kind=kind,
        user_id=user_id,
        workspace_id=workspace_id,
        session_id=session_id,
        request_id=request_id,
        payload=dict(payload),
    )
    return record(draft)


@contextmanager
def span(
    kind: str,
    user_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    session_id: Optional[str] = None,
    request_id: Optional[str] = None,
) -> Generator[EventDraft, None, None]:
    """record an event around a block of work, with elapsed_ms attached automatically.

    usage:
        with span('chat.completion', user_id=u.id) as draft:
            draft.payload['model'] = 'gpt-4o-mini'
            ... do the work ...
    """
    draft = EventDraft(kind=kind, user_id=user_id, workspace_id=workspace_id, session_id=session_id, request_id=request_id)
    start = time.monotonic()
    try:
        yield draft
    finally:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        draft.merge_payload({"elapsed_ms": elapsed_ms})
        record(draft)


def get(event_id: int) -> Optional[Event]:
    with _connect() as conn:
        row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if row is None:
        return None
    return Event.from_row(row)


def purge_before(seconds_ago: int) -> int:
    """delete events older than `seconds_ago`. returns count deleted."""
    cutoff = int(time.time()) - seconds_ago
    with _connect() as conn:
        cur = conn.execute("DELETE FROM events WHERE occurred_at < ?", (cutoff,))
        return cur.rowcount


bootstrap()
