"""named constants for the event kinds we track. yes this could be an enum, but
keeping them as bare strings makes the sql + json roundtrips simpler.
"""
from typing import Final, List


# auth-related events
EVENT_SIGNUP: Final[str] = "auth.signup"
EVENT_LOGIN: Final[str] = "auth.login"
EVENT_LOGIN_FAIL: Final[str] = "auth.login_fail"
EVENT_TOKEN_REFRESH: Final[str] = "auth.token_refresh"

# chat
EVENT_CHAT_COMPLETION: Final[str] = "chat.completion"
EVENT_CHAT_STREAM: Final[str] = "chat.stream"
EVENT_CHAT_ERROR: Final[str] = "chat.error"

# sessions
EVENT_SESSION_CREATED: Final[str] = "session.created"
EVENT_SESSION_DELETED: Final[str] = "session.deleted"

# documents
EVENT_DOCUMENT_UPLOADED: Final[str] = "document.uploaded"
EVENT_DOCUMENT_INDEXED: Final[str] = "document.indexed"
EVENT_DOCUMENT_FAILED: Final[str] = "document.failed"

# workspaces
EVENT_WORKSPACE_CREATED: Final[str] = "workspace.created"
EVENT_WORKSPACE_DELETED: Final[str] = "workspace.deleted"
EVENT_MEMBERSHIP_ADDED: Final[str] = "membership.added"
EVENT_MEMBERSHIP_REMOVED: Final[str] = "membership.removed"
EVENT_OWNERSHIP_TRANSFERRED: Final[str] = "workspace.ownership_transferred"

# rate limit
EVENT_RATE_LIMITED: Final[str] = "rate.limited"


ALL_EVENT_KINDS: Final[List[str]] = [
    EVENT_SIGNUP,
    EVENT_LOGIN,
    EVENT_LOGIN_FAIL,
    EVENT_TOKEN_REFRESH,
    EVENT_CHAT_COMPLETION,
    EVENT_CHAT_STREAM,
    EVENT_CHAT_ERROR,
    EVENT_SESSION_CREATED,
    EVENT_SESSION_DELETED,
    EVENT_DOCUMENT_UPLOADED,
    EVENT_DOCUMENT_INDEXED,
    EVENT_DOCUMENT_FAILED,
    EVENT_WORKSPACE_CREATED,
    EVENT_WORKSPACE_DELETED,
    EVENT_MEMBERSHIP_ADDED,
    EVENT_MEMBERSHIP_REMOVED,
    EVENT_OWNERSHIP_TRANSFERRED,
    EVENT_RATE_LIMITED,
]


# grouping for UI dashboards. keys must NOT overlap.
EVENT_GROUPS: Final[dict] = {
    "auth": [EVENT_SIGNUP, EVENT_LOGIN, EVENT_LOGIN_FAIL, EVENT_TOKEN_REFRESH],
    "chat": [EVENT_CHAT_COMPLETION, EVENT_CHAT_STREAM, EVENT_CHAT_ERROR],
    "sessions": [EVENT_SESSION_CREATED, EVENT_SESSION_DELETED],
    "documents": [EVENT_DOCUMENT_UPLOADED, EVENT_DOCUMENT_INDEXED, EVENT_DOCUMENT_FAILED],
    "workspaces": [EVENT_WORKSPACE_CREATED, EVENT_WORKSPACE_DELETED, EVENT_MEMBERSHIP_ADDED,
                   EVENT_MEMBERSHIP_REMOVED, EVENT_OWNERSHIP_TRANSFERRED],
    "limits": [EVENT_RATE_LIMITED],
}


def group_for(kind: str) -> str:
    """returns the group a kind belongs to, or 'other'."""
    for group, kinds in EVENT_GROUPS.items():
        if kind in kinds:
            return group
    return "other"


def is_known_kind(kind: str) -> bool:
    return kind in ALL_EVENT_KINDS
