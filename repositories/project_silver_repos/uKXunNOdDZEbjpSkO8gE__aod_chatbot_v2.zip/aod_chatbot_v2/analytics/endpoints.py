"""admin-facing analytics routes. all under /v1/analytics."""
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from analytics import queries, tracker
from analytics.types import ALL_EVENT_KINDS, EVENT_GROUPS, is_known_kind
from users.endpoints import current_user


router = APIRouter(prefix="/v1/analytics", tags=["analytics"])


# todo: gate these behind an `admin` role once we have one. for now, any signed-in
# user can see the global analytics. this is fine for the bainsa org but obviously not
# for a real saas.
def _require_admin(user) -> None:
    # placeholder until role-based auth lands. see TODO above.
    return


@router.get("/events")
def list_events(
    user=Depends(current_user),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    kind: Optional[str] = None,
    user_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> Dict[str, Any]:
    _require_admin(user)
    if kind is not None and not is_known_kind(kind):
        raise HTTPException(status_code=400, detail=f"unknown kind: {kind!r}")
    rows = queries.list_recent(
        limit=limit, offset=offset, kind=kind, user_id=user_id, workspace_id=workspace_id, since=since, until=until,
    )
    return {"events": [e.public() for e in rows]}


@router.get("/summary")
def summary(
    user=Depends(current_user),
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, Any]:
    _require_admin(user)
    by_kind = queries.count_by_kind(since=since, until=until, workspace_id=workspace_id)
    by_group = queries.count_by_group(since=since, until=until, workspace_id=workspace_id)
    total = sum(by_kind.values())
    return {
        "total": total,
        "by_kind": by_kind,
        "by_group": by_group,
    }


@router.get("/timeseries")
def timeseries(
    user=Depends(current_user),
    bucket: str = Query("hour", description="'hour' or 'day'"),
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, Any]:
    _require_admin(user)
    if bucket == "hour":
        rows = queries.buckets_by_hour(since=since, until=until, workspace_id=workspace_id)
    elif bucket == "day":
        rows = queries.buckets_by_day(since=since, until=until, workspace_id=workspace_id)
    else:
        raise HTTPException(status_code=400, detail="bucket must be 'hour' or 'day'")
    return {"bucket": bucket, "points": [{"t": t, "n": n} for t, n in rows]}


@router.get("/top-users")
def top_users(
    user=Depends(current_user),
    limit: int = Query(10, ge=1, le=100),
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, Any]:
    _require_admin(user)
    rows = queries.top_users(limit=limit, since=since, until=until, workspace_id=workspace_id)
    return {"users": rows}


@router.get("/kinds")
def known_kinds(user=Depends(current_user)) -> Dict[str, Any]:
    """introspection: the kinds that we know about, grouped."""
    _require_admin(user)
    return {"all": ALL_EVENT_KINDS, "groups": EVENT_GROUPS}


@router.post("/purge")
def purge(
    user=Depends(current_user),
    older_than_seconds: int = Query(60 * 60 * 24 * 90, ge=60),
) -> Dict[str, Any]:
    """delete events older than `older_than_seconds`. defaults to 90 days."""
    _require_admin(user)
    n = tracker.purge_before(older_than_seconds)
    return {"deleted": n}
