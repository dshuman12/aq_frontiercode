"""event tracking, aggregations, exports. read by the analytics dashboard."""
