"""read-side: aggregations over the events table. used by the analytics dashboard + the cli."""
import time
from typing import Any, Dict, List, Optional, Tuple

from rag.sessions import _connect
from analytics.models import Event
from analytics.types import ALL_EVENT_KINDS, EVENT_GROUPS, group_for


def list_recent(
    limit: int = 100,
    offset: int = 0,
    kind: Optional[str] = None,
    user_id: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> List[Event]:
    """raw event list with simple filters."""
    sql: str = "SELECT * FROM events WHERE 1=1"
    args: List[Any] = []
    if kind:
        sql += " AND kind = ?"
        args.append(kind)
    if user_id:
        sql += " AND user_id = ?"
        args.append(user_id)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    sql += " ORDER BY occurred_at DESC LIMIT ? OFFSET ?"
    args.append(limit)
    args.append(offset)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [Event.from_row(r) for r in rows]


def count_by_kind(
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, int]:
    """returns a dict { kind -> count }."""
    sql: str = "SELECT kind, COUNT(*) AS n FROM events WHERE 1=1"
    args: List[Any] = []
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    sql += " GROUP BY kind"
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    out: Dict[str, int] = {}
    for r in rows:
        out[r["kind"]] = r["n"]
    # backfill known kinds with zero so the dashboard always sees a full set
    for k in ALL_EVENT_KINDS:
        out.setdefault(k, 0)
    return out


def count_by_group(
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, int]:
    """roll counts up to event groups."""
    per_kind = count_by_kind(since=since, until=until, workspace_id=workspace_id)
    out: Dict[str, int] = {g: 0 for g in EVENT_GROUPS.keys()}
    out["other"] = 0
    for kind, n in per_kind.items():
        g = group_for(kind)
        out[g] = out.get(g, 0) + n
    return out


def buckets_by_hour(
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> List[Tuple[int, int]]:
    """returns [(hour_start_epoch, count), ...] in chronological order."""
    if since is None:
        since = int(time.time()) - 24 * 3600
    if until is None:
        until = int(time.time())
    sql: str = """
    SELECT (occurred_at / 3600) * 3600 AS bucket, COUNT(*) AS n
    FROM events
    WHERE occurred_at >= ? AND occurred_at < ?
    """
    args: List[Any] = [since, until]
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    sql += " GROUP BY bucket ORDER BY bucket ASC"
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [(int(r["bucket"]), int(r["n"])) for r in rows]


def buckets_by_day(
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> List[Tuple[int, int]]:
    """returns [(day_start_epoch, count), ...]. utc-aligned days."""
    if since is None:
        since = int(time.time()) - 30 * 86400
    if until is None:
        until = int(time.time())
    sql: str = """
    SELECT (occurred_at / 86400) * 86400 AS bucket, COUNT(*) AS n
    FROM events
    WHERE occurred_at >= ? AND occurred_at < ?
    """
    args: List[Any] = [since, until]
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    sql += " GROUP BY bucket ORDER BY bucket ASC"
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [(int(r["bucket"]), int(r["n"])) for r in rows]


def top_users(
    limit: int = 10,
    since: Optional[int] = None,
    until: Optional[int] = None,
    workspace_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """top users by total event count in window."""
    sql: str = "SELECT user_id, COUNT(*) AS n FROM events WHERE user_id IS NOT NULL"
    args: List[Any] = []
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    if workspace_id:
        sql += " AND workspace_id = ?"
        args.append(workspace_id)
    sql += " GROUP BY user_id ORDER BY n DESC LIMIT ?"
    args.append(limit)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    return [{"user_id": r["user_id"], "n": int(r["n"])} for r in rows]


def percentile_elapsed_ms(
    kind: str,
    pct: float = 95.0,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> Optional[float]:
    """rough percentile of elapsed_ms among events of `kind`. clamps pct to [0, 100].

    we pull the elapsed_ms numbers into python rather than computing in sql because
    json_extract is not always available in old sqlite builds. small dataset; fine.
    """
    if not (0 <= pct <= 100):
        raise ValueError("pct must be between 0 and 100")
    sql: str = "SELECT payload FROM events WHERE kind = ?"
    args: List[Any] = [kind]
    if since is not None:
        sql += " AND occurred_at >= ?"
        args.append(since)
    if until is not None:
        sql += " AND occurred_at < ?"
        args.append(until)
    with _connect() as conn:
        rows = conn.execute(sql, tuple(args)).fetchall()
    values: List[float] = []
    import json as _json
    for r in rows:
        try:
            data = _json.loads(r["payload"] or "{}")
            v = data.get("elapsed_ms")
            if isinstance(v, (int, float)):
                values.append(float(v))
        except (ValueError, TypeError):
            continue
    if not values:
        return None
    values.sort()
    idx = max(0, min(len(values) - 1, int(len(values) * pct / 100)))
    return values[idx]
