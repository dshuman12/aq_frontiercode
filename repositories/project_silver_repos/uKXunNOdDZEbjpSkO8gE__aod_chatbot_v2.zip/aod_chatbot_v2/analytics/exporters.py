"""dump events to csv or json for offline analysis. used by the cli and by support tickets."""
import csv
import io
import json
import time
from typing import Any, Dict, Iterable, List, Optional, TextIO

from analytics import queries
from analytics.models import Event


CSV_COLUMNS: List[str] = [
    "id",
    "kind",
    "user_id",
    "workspace_id",
    "session_id",
    "request_id",
    "occurred_at",
    "occurred_at_iso",
    "elapsed_ms",
    "payload_json",
]


def _row_for_csv(event: Event) -> Dict[str, Any]:
    elapsed = event.payload.get("elapsed_ms")
    return {
        "id": event.id,
        "kind": event.kind,
        "user_id": event.user_id or "",
        "workspace_id": event.workspace_id or "",
        "session_id": event.session_id or "",
        "request_id": event.request_id or "",
        "occurred_at": event.occurred_at,
        "occurred_at_iso": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(event.occurred_at)),
        "elapsed_ms": elapsed if isinstance(elapsed, (int, float)) else "",
        "payload_json": json.dumps(event.payload, default=str),
    }


def export_csv(
    fp: TextIO,
    kind: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
    page_size: int = 1000,
) -> int:
    """stream events as csv into the open file object. returns count written."""
    writer = csv.DictWriter(fp, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    n_written = 0
    offset = 0
    while True:
        batch = queries.list_recent(
            limit=page_size,
            offset=offset,
            kind=kind,
            workspace_id=workspace_id,
            since=since,
            until=until,
        )
        if not batch:
            break
        for ev in batch:
            writer.writerow(_row_for_csv(ev))
            n_written += 1
        if len(batch) < page_size:
            break
        offset += page_size
    return n_written


def export_csv_to_string(
    kind: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> str:
    buf = io.StringIO()
    export_csv(buf, kind=kind, workspace_id=workspace_id, since=since, until=until)
    return buf.getvalue()


def export_jsonl(
    fp: TextIO,
    kind: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
    page_size: int = 1000,
) -> int:
    """jsonl format - one event per line."""
    n_written = 0
    offset = 0
    while True:
        batch = queries.list_recent(
            limit=page_size,
            offset=offset,
            kind=kind,
            workspace_id=workspace_id,
            since=since,
            until=until,
        )
        if not batch:
            break
        for ev in batch:
            fp.write(json.dumps(ev.public(), default=str))
            fp.write("\n")
            n_written += 1
        if len(batch) < page_size:
            break
        offset += page_size
    return n_written


def iterate(
    page_size: int = 500,
    kind: Optional[str] = None,
    workspace_id: Optional[str] = None,
    since: Optional[int] = None,
    until: Optional[int] = None,
) -> Iterable[Event]:
    """yield events one at a time, useful for ad-hoc filtering in scripts."""
    offset = 0
    while True:
        batch = queries.list_recent(
            limit=page_size,
            offset=offset,
            kind=kind,
            workspace_id=workspace_id,
            since=since,
            until=until,
        )
        if not batch:
            return
        for ev in batch:
            yield ev
        if len(batch) < page_size:
            return
        offset += page_size
