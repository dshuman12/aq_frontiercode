"""schema + dataclass for the events table."""
import json
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


EVENTS_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    user_id TEXT,
    workspace_id TEXT,
    session_id TEXT,
    request_id TEXT,
    payload TEXT NOT NULL DEFAULT '{}',
    occurred_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_kind ON events(kind);
CREATE INDEX IF NOT EXISTS idx_events_user ON events(user_id);
CREATE INDEX IF NOT EXISTS idx_events_workspace ON events(workspace_id);
CREATE INDEX IF NOT EXISTS idx_events_occurred_at ON events(occurred_at);
"""


@dataclass
class Event:
    id: Optional[int]
    kind: str
    user_id: Optional[str]
    workspace_id: Optional[str]
    session_id: Optional[str]
    request_id: Optional[str]
    payload: Dict[str, Any]
    occurred_at: int

    @classmethod
    def from_row(cls, row) -> "Event":
        # row is sqlite3.Row; payload arrives as a json-encoded string
        raw_payload = row["payload"] or "{}"
        try:
            parsed = json.loads(raw_payload)
        except (json.JSONDecodeError, TypeError):
            parsed = {"_raw": raw_payload}
        if not isinstance(parsed, dict):
            parsed = {"_value": parsed}
        return cls(
            id=row["id"],
            kind=row["kind"],
            user_id=row["user_id"],
            workspace_id=row["workspace_id"],
            session_id=row["session_id"],
            request_id=row["request_id"],
            payload=parsed,
            occurred_at=row["occurred_at"],
        )

    def public(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "kind": self.kind,
            "user_id": self.user_id,
            "workspace_id": self.workspace_id,
            "session_id": self.session_id,
            "request_id": self.request_id,
            "payload": self.payload,
            "occurred_at": self.occurred_at,
        }


@dataclass
class EventDraft:
    """unsubmitted event. use tracker.record(draft) to persist."""
    kind: str
    user_id: Optional[str] = None
    workspace_id: Optional[str] = None
    session_id: Optional[str] = None
    request_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)

    def merge_payload(self, extra: Dict[str, Any]) -> None:
        # in-place merge; we don't deep-merge because nobody nests events that deep
        for k, v in extra.items():
            self.payload[k] = v
