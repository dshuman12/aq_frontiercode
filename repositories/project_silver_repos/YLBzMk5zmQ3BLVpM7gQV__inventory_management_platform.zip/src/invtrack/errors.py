"""Domain-specific exceptions.

We separate these from generic ValueError because callers (CLI, future
HTTP layer) want to map them to different responses. ValidationError ->
400-equivalent; NotFoundError -> 404; ConflictError -> 409.
"""
from __future__ import annotations


class InvtrackError(Exception):
    """Base class for everything we raise on purpose."""


class ValidationError(InvtrackError):
    pass


class NotFoundError(InvtrackError):
    pass


class ConflictError(InvtrackError):
    """Raised on logical conflicts: e.g. trying to ship more than is reserved."""


class InsufficientStockError(ConflictError):
    def __init__(self, product_id: int, requested: int, available: int) -> None:
        super().__init__(
            f"Insufficient stock for product {product_id}: "
            f"requested {requested}, available {available}"
        )
        self.product_id = product_id
        self.requested = requested
        self.available = available
