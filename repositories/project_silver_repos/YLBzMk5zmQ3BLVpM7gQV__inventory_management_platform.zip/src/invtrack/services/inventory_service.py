from __future__ import annotations

import sqlite3
from typing import Optional

from ..db import transaction
from ..domain import InventoryLevel, MovementType, StockMovement
from ..errors import (
    ConflictError,
    InsufficientStockError,
    NotFoundError,
    ValidationError,
)
from ..repositories.inventory import InventoryRepository
from ..repositories.locations import StorageLocationRepository
from ..repositories.movements import MovementRepository
from ..repositories.products import ProductRepository


class InventoryService:
    """Pairs every quantity change with a stock_movements row.

    This is the entry point for any code that needs to increase, decrease,
    reserve or release inventory. Going around it (e.g. updating the
    inventory_levels table directly from a workflow) means losing the
    audit trail.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.inventory = InventoryRepository(conn)
        self.movements = MovementRepository(conn)
        self.products = ProductRepository(conn)
        self.locations = StorageLocationRepository(conn)

    # ------------------------------------------------------------------
    # Receipts and shipments
    # ------------------------------------------------------------------
    def receive(
        self,
        product_id: int,
        location_id: int,
        quantity: int,
        *,
        reference_type: Optional[str] = None,
        reference_id: Optional[int] = None,
        note: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> InventoryLevel:
        if quantity <= 0:
            raise ValidationError("receive quantity must be positive")
        self._check_exists(product_id, location_id)
        with transaction(self.conn):
            level = self.inventory.adjust_quantity(product_id, location_id, quantity)
            self.movements.record(
                StockMovement(
                    id=None,
                    product_id=product_id,
                    location_id=location_id,
                    movement_type=MovementType.RECEIPT,
                    quantity=quantity,
                    reference_type=reference_type,
                    reference_id=reference_id,
                    note=note,
                    created_by=created_by,
                )
            )
        return level

    def ship(
        self,
        product_id: int,
        location_id: int,
        quantity: int,
        *,
        reference_type: Optional[str] = None,
        reference_id: Optional[int] = None,
        note: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> InventoryLevel:
        if quantity <= 0:
            raise ValidationError("ship quantity must be positive")
        self._check_exists(product_id, location_id)
        with transaction(self.conn):
            current = self.inventory.get(product_id, location_id)
            on_hand = current.quantity if current else 0
            if on_hand < quantity:
                raise InsufficientStockError(product_id, quantity, on_hand)
            level = self.inventory.adjust_quantity(product_id, location_id, -quantity)
            self.movements.record(
                StockMovement(
                    id=None,
                    product_id=product_id,
                    location_id=location_id,
                    movement_type=MovementType.SHIPMENT,
                    quantity=-quantity,
                    reference_type=reference_type,
                    reference_id=reference_id,
                    note=note,
                    created_by=created_by,
                )
            )
        return level

    # ------------------------------------------------------------------
    # Reservations
    # ------------------------------------------------------------------
    def reserve(
        self,
        product_id: int,
        location_id: int,
        quantity: int,
        *,
        reference_type: Optional[str] = None,
        reference_id: Optional[int] = None,
        created_by: Optional[str] = None,
    ) -> InventoryLevel:
        if quantity <= 0:
            raise ValidationError("reserve quantity must be positive")
        self._check_exists(product_id, location_id)
        with transaction(self.conn):
            current = self.inventory.get(product_id, location_id)
            available = current.available if current else 0
            if available < quantity:
                raise InsufficientStockError(product_id, quantity, available)
            level = self.inventory.adjust_reservation(product_id, location_id, quantity)
            self.movements.record(
                StockMovement(
                    id=None,
                    product_id=product_id,
                    location_id=location_id,
                    movement_type=MovementType.RESERVATION,
                    quantity=quantity,
                    reference_type=reference_type,
                    reference_id=reference_id,
                    created_by=created_by,
                )
            )
        return level

    def release_reservation(
        self,
        product_id: int,
        location_id: int,
        quantity: int,
        *,
        reference_type: Optional[str] = None,
        reference_id: Optional[int] = None,
        created_by: Optional[str] = None,
    ) -> InventoryLevel:
        if quantity <= 0:
            raise ValidationError("release quantity must be positive")
        current = self.inventory.get(product_id, location_id)
        if not current or current.reserved < quantity:
            reserved = current.reserved if current else 0
            raise ConflictError(
                f"cannot release {quantity}: only {reserved} currently reserved"
            )
        with transaction(self.conn):
            level = self.inventory.adjust_reservation(product_id, location_id, -quantity)
            self.movements.record(
                StockMovement(
                    id=None,
                    product_id=product_id,
                    location_id=location_id,
                    movement_type=MovementType.RELEASE,
                    quantity=quantity,
                    reference_type=reference_type,
                    reference_id=reference_id,
                    created_by=created_by,
                )
            )
        return level

    # ------------------------------------------------------------------
    # Manual adjustments (reconciliation, write-offs)
    # ------------------------------------------------------------------
    def adjust(
        self,
        product_id: int,
        location_id: int,
        delta: int,
        *,
        note: str,
        created_by: Optional[str] = None,
    ) -> InventoryLevel:
        if delta == 0:
            raise ValidationError("adjustment delta must be non-zero")
        if not note or not note.strip():
            raise ValidationError("manual adjustments require a note")
        self._check_exists(product_id, location_id)
        if delta < 0:
            current = self.inventory.get(product_id, location_id)
            on_hand = current.quantity if current else 0
            if on_hand + delta < 0:
                raise InsufficientStockError(product_id, abs(delta), on_hand)
        with transaction(self.conn):
            level = self.inventory.adjust_quantity(product_id, location_id, delta)
            self.movements.record(
                StockMovement(
                    id=None,
                    product_id=product_id,
                    location_id=location_id,
                    movement_type=MovementType.ADJUSTMENT,
                    quantity=delta,
                    note=note,
                    created_by=created_by,
                )
            )
        return level

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _check_exists(self, product_id: int, location_id: int) -> None:
        if self.products.get(product_id) is None:
            raise NotFoundError(f"product {product_id} not found")
        if self.locations.get(location_id) is None:
            raise NotFoundError(f"location {location_id} not found")
