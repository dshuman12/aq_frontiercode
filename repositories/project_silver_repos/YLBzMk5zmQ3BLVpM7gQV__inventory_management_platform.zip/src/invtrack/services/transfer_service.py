from __future__ import annotations

import sqlite3
from typing import Iterable

from ..db import transaction
from ..domain import (
    MovementType,
    StockMovement,
    StockTransfer,
    StockTransferLine,
    TransferStatus,
)
from ..errors import ConflictError, InsufficientStockError, NotFoundError, ValidationError
from ..repositories.inventory import InventoryRepository
from ..repositories.locations import StorageLocationRepository
from ..repositories.movements import MovementRepository
from ..repositories.products import ProductRepository
from ..repositories.transfers import StockTransferRepository
from ..validation import validate_positive


class StockTransferService:
    """Two-step transfer:

    1. ``initiate`` decrements stock at source and writes TRANSFER_OUT
       movements. The transfer is now IN_TRANSIT.
    2. ``complete`` increments stock at destination with TRANSFER_IN
       movements. Status becomes COMPLETED.

    ``cancel`` is only valid IN_TRANSIT - it puts the qty back at
    the source.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.transfers = StockTransferRepository(conn)
        self.inventory = InventoryRepository(conn)
        self.movements = MovementRepository(conn)
        self.products = ProductRepository(conn)
        self.locations = StorageLocationRepository(conn)

    def initiate(
        self,
        transfer_number: str,
        source_location_id: int,
        dest_location_id: int,
        lines: Iterable[tuple[int, int]],  # (product_id, qty)
        *,
        notes: str | None = None,
        created_by: str | None = None,
    ) -> StockTransfer:
        if not transfer_number.strip():
            raise ValidationError("transfer_number cannot be empty")
        if source_location_id == dest_location_id:
            raise ValidationError("source and destination must differ")
        if self.locations.get(source_location_id) is None:
            raise NotFoundError(f"source location {source_location_id} not found")
        if self.locations.get(dest_location_id) is None:
            raise NotFoundError(f"dest location {dest_location_id} not found")
        if self.transfers.get_by_number(transfer_number) is not None:
            raise ConflictError(f"transfer {transfer_number!r} already exists")

        line_objs: list[StockTransferLine] = []
        seen: set[int] = set()
        for product_id, qty in lines:
            validate_positive(qty, label="transfer qty")
            if product_id in seen:
                raise ValidationError(f"duplicate product on transfer: {product_id}")
            if self.products.get(product_id) is None:
                raise NotFoundError(f"product {product_id} not found")
            seen.add(product_id)
            line_objs.append(
                StockTransferLine(id=None, transfer_id=None,
                                  product_id=product_id, quantity=qty)
            )
        if not line_objs:
            raise ValidationError("transfer must have at least one line")

        with transaction(self.conn):
            # Pre-check we have enough at the source
            for line in line_objs:
                level = self.inventory.get(line.product_id, source_location_id)
                available = level.available if level else 0
                if available < line.quantity:
                    raise InsufficientStockError(line.product_id, line.quantity, available)

            transfer = self.transfers.create(
                StockTransfer(
                    id=None,
                    transfer_number=transfer_number,
                    source_location_id=source_location_id,
                    dest_location_id=dest_location_id,
                    status=TransferStatus.IN_TRANSIT,
                    notes=notes,
                    created_by=created_by,
                    lines=tuple(line_objs),
                )
            )
            for line in transfer.lines:
                self.inventory.adjust_quantity(
                    line.product_id, source_location_id, -line.quantity
                )
                self.movements.record(
                    StockMovement(
                        id=None,
                        product_id=line.product_id,
                        location_id=source_location_id,
                        movement_type=MovementType.TRANSFER_OUT,
                        quantity=-line.quantity,
                        reference_type="transfer",
                        reference_id=transfer.id,
                        created_by=created_by,
                    )
                )
        return self.transfers.get(transfer.id)  # type: ignore[return-value]

    def complete(self, transfer_id: int, *, completed_by: str | None = None) -> StockTransfer:
        transfer = self.transfers.get(transfer_id)
        if transfer is None:
            raise NotFoundError(f"transfer {transfer_id} not found")
        if transfer.status != TransferStatus.IN_TRANSIT:
            raise ConflictError(
                f"only in-transit transfers can be completed (current: {transfer.status.value})"
            )
        with transaction(self.conn):
            for line in transfer.lines:
                self.inventory.adjust_quantity(
                    line.product_id, transfer.dest_location_id, line.quantity
                )
                self.movements.record(
                    StockMovement(
                        id=None,
                        product_id=line.product_id,
                        location_id=transfer.dest_location_id,
                        movement_type=MovementType.TRANSFER_IN,
                        quantity=line.quantity,
                        reference_type="transfer",
                        reference_id=transfer_id,
                        created_by=completed_by,
                    )
                )
            self.transfers.update_status(
                transfer_id, TransferStatus.COMPLETED, timestamp_field="completed_at"
            )
        return self.transfers.get(transfer_id)  # type: ignore[return-value]

    def cancel(self, transfer_id: int, *, cancelled_by: str | None = None) -> StockTransfer:
        transfer = self.transfers.get(transfer_id)
        if transfer is None:
            raise NotFoundError(f"transfer {transfer_id} not found")
        if transfer.status != TransferStatus.IN_TRANSIT:
            raise ConflictError(
                f"only in-transit transfers can be cancelled (current: {transfer.status.value})"
            )
        with transaction(self.conn):
            for line in transfer.lines:
                # Put it back
                self.inventory.adjust_quantity(
                    line.product_id, transfer.source_location_id, line.quantity
                )
                self.movements.record(
                    StockMovement(
                        id=None,
                        product_id=line.product_id,
                        location_id=transfer.source_location_id,
                        movement_type=MovementType.ADJUSTMENT,
                        quantity=line.quantity,
                        reference_type="transfer_cancel",
                        reference_id=transfer_id,
                        note="transfer cancelled",
                        created_by=cancelled_by,
                    )
                )
            self.transfers.update_status(
                transfer_id, TransferStatus.CANCELLED, timestamp_field="cancelled_at"
            )
        return self.transfers.get(transfer_id)  # type: ignore[return-value]
