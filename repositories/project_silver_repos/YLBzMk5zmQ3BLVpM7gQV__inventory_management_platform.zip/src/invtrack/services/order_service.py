from __future__ import annotations

import sqlite3
from typing import Iterable

from ..db import transaction
from ..domain import (
    CustomerOrder,
    CustomerOrderLine,
    CustomerOrderStatus,
)
from ..errors import ConflictError, NotFoundError, ValidationError
from ..repositories.customer_orders import CustomerOrderRepository
from ..repositories.products import ProductRepository
from ..repositories.warehouses import WarehouseRepository
from ..validation import validate_email, validate_positive
from .inventory_service import InventoryService


class CustomerOrderService:
    """Customer order lifecycle:

      DRAFT -> CONFIRMED -> PICKING -> SHIPPED
                  \\
                   -> CANCELLED  (only from DRAFT or CONFIRMED)

    Confirming an order reserves inventory at the order's home warehouse.
    Picking decrements `quantity_picked` (no inventory movement yet).
    Shipping converts the reservation into a real outbound movement.
    Cancelling a CONFIRMED order releases the reservation.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.orders = CustomerOrderRepository(conn)
        self.products = ProductRepository(conn)
        self.warehouses = WarehouseRepository(conn)
        self.inventory = InventoryService(conn)

    # ------------------------------------------------------------------
    # Creation
    # ------------------------------------------------------------------
    def create_draft(
        self,
        order_number: str,
        customer_name: str,
        warehouse_id: int,
        lines: Iterable[tuple[int, int, int]],  # (product_id, qty, unit_price_cents)
        *,
        customer_email: str | None = None,
        notes: str | None = None,
        created_by: str | None = None,
    ) -> CustomerOrder:
        if not order_number.strip():
            raise ValidationError("order_number cannot be empty")
        if not customer_name.strip():
            raise ValidationError("customer_name cannot be empty")
        if customer_email:
            validate_email(customer_email)
        if self.warehouses.get(warehouse_id) is None:
            raise NotFoundError(f"warehouse {warehouse_id} not found")
        if self.orders.get_by_number(order_number) is not None:
            raise ConflictError(f"order_number {order_number!r} already exists")

        seen: set[int] = set()
        order_lines: list[CustomerOrderLine] = []
        for product_id, qty, price in lines:
            validate_positive(qty, label="line quantity")
            if price < 0:
                raise ValidationError("unit price cannot be negative")
            if product_id in seen:
                raise ValidationError(f"duplicate product on order: {product_id}")
            if self.products.get(product_id) is None:
                raise NotFoundError(f"product {product_id} not found")
            seen.add(product_id)
            order_lines.append(
                CustomerOrderLine(
                    id=None,
                    order_id=None,
                    product_id=product_id,
                    quantity=qty,
                    unit_price_cents=price,
                )
            )
        if not order_lines:
            raise ValidationError("order must have at least one line")

        with transaction(self.conn):
            return self.orders.create(
                CustomerOrder(
                    id=None,
                    order_number=order_number,
                    customer_name=customer_name.strip(),
                    customer_email=customer_email,
                    warehouse_id=warehouse_id,
                    status=CustomerOrderStatus.DRAFT,
                    notes=notes,
                    created_by=created_by,
                    lines=tuple(order_lines),
                )
            )

    # ------------------------------------------------------------------
    # Confirm: reserve inventory
    # ------------------------------------------------------------------
    def confirm(self, order_id: int, *, allocator_strategy: str = "first") -> CustomerOrder:
        order = self.orders.get(order_id)
        if order is None:
            raise NotFoundError(f"order {order_id} not found")
        if order.status != CustomerOrderStatus.DRAFT:
            raise ConflictError(
                f"only draft orders can be confirmed (current: {order.status.value})"
            )

        # Build allocations across the warehouse's locations. Whichever
        # strategy we pick, every line must be fully allocatable or we abort.
        from ..repositories.locations import StorageLocationRepository
        loc_repo = StorageLocationRepository(self.conn)
        locations = loc_repo.list_for_warehouse(order.warehouse_id)
        if not locations:
            raise ConflictError("warehouse has no active storage locations")

        allocations: list[tuple[int, int, int]] = []  # (product_id, location_id, qty)
        for line in order.lines:
            remaining = line.quantity
            for loc in locations:
                if remaining == 0:
                    break
                level = self.inventory.inventory.get(line.product_id, loc.id)
                if not level or level.available <= 0:
                    continue
                take = min(level.available, remaining)
                allocations.append((line.product_id, loc.id, take))
                remaining -= take
            if remaining > 0:
                # Compute a tidy total available across the warehouse for the error
                total_avail = sum(
                    (lvl.available for loc in locations
                     for lvl in [self.inventory.inventory.get(line.product_id, loc.id)]
                     if lvl is not None),
                    0,
                )
                from ..errors import InsufficientStockError
                raise InsufficientStockError(line.product_id, line.quantity, total_avail)

        with transaction(self.conn):
            for product_id, loc_id, qty in allocations:
                self.inventory.reserve(
                    product_id, loc_id, qty,
                    reference_type="customer_order",
                    reference_id=order_id,
                )
            self.orders.update_status(
                order_id, CustomerOrderStatus.CONFIRMED, timestamp_field="confirmed_at"
            )
        return self.orders.get(order_id)  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Pick: mark picked qty (no inventory mutation)
    # ------------------------------------------------------------------
    def pick(self, order_id: int, picks: Iterable[tuple[int, int]]) -> CustomerOrder:
        """picks: iterable of (line_id, quantity_picked_now)."""
        order = self.orders.get(order_id)
        if order is None:
            raise NotFoundError(f"order {order_id} not found")
        if order.status not in {CustomerOrderStatus.CONFIRMED, CustomerOrderStatus.PICKING}:
            raise ConflictError(
                f"cannot pick order in status {order.status.value}"
            )
        line_index = {line.id: line for line in order.lines}
        picks = list(picks)
        for line_id, qty in picks:
            validate_positive(qty, label="pick qty")
            if line_id not in line_index:
                raise NotFoundError(f"line {line_id} not on order {order_id}")
            line = line_index[line_id]
            if line.quantity_picked + qty > line.quantity:
                raise ConflictError(
                    f"pick would exceed line qty ({line.quantity_picked + qty} > {line.quantity})"
                )

        with transaction(self.conn):
            for line_id, qty in picks:
                self.orders.increment_picked(line_id, qty)
            if order.status == CustomerOrderStatus.CONFIRMED:
                self.orders.update_status(order_id, CustomerOrderStatus.PICKING)
        return self.orders.get(order_id)  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Ship: convert reservation to outbound movement
    # ------------------------------------------------------------------
    def ship(self, order_id: int, *, shipped_by: str | None = None) -> CustomerOrder:
        order = self.orders.get(order_id)
        if order is None:
            raise NotFoundError(f"order {order_id} not found")
        if order.status != CustomerOrderStatus.PICKING:
            raise ConflictError(
                f"order must be in PICKING to ship (current: {order.status.value})"
            )
        for line in order.lines:
            if line.quantity_picked != line.quantity:
                raise ConflictError(
                    f"line {line.id}: picked {line.quantity_picked}/{line.quantity}, "
                    "all lines must be fully picked before shipping"
                )

        # Look up the original reservation movements to know which (location, qty)
        # to ship from. We stored these under reference_type='customer_order'.
        from ..repositories.movements import MovementRepository
        from ..domain import MovementType
        moves = MovementRepository(self.conn).list_by_reference("customer_order", order_id)
        # Per-(product, location) net reservations
        by_pl: dict[tuple[int, int], int] = {}
        for m in moves:
            key = (m.product_id, m.location_id)
            if m.movement_type == MovementType.RESERVATION:
                by_pl[key] = by_pl.get(key, 0) + m.quantity
            elif m.movement_type == MovementType.RELEASE:
                by_pl[key] = by_pl.get(key, 0) - m.quantity

        with transaction(self.conn):
            for (product_id, loc_id), qty in by_pl.items():
                if qty <= 0:
                    continue
                self.inventory.release_reservation(
                    product_id, loc_id, qty,
                    reference_type="customer_order",
                    reference_id=order_id,
                )
                self.inventory.ship(
                    product_id, loc_id, qty,
                    reference_type="customer_order",
                    reference_id=order_id,
                    note=f"Order {order.order_number}",
                    created_by=shipped_by,
                )
            for line in order.lines:
                self.orders.increment_shipped(line.id, line.quantity_picked)
            self.orders.update_status(
                order_id, CustomerOrderStatus.SHIPPED, timestamp_field="shipped_at"
            )
        return self.orders.get(order_id)  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Cancel: release reservations
    # ------------------------------------------------------------------
    def cancel(self, order_id: int) -> CustomerOrder:
        order = self.orders.get(order_id)
        if order is None:
            raise NotFoundError(f"order {order_id} not found")
        if order.status not in {CustomerOrderStatus.DRAFT, CustomerOrderStatus.CONFIRMED}:
            raise ConflictError(
                f"cannot cancel order in status {order.status.value}"
            )
        with transaction(self.conn):
            if order.status == CustomerOrderStatus.CONFIRMED:
                # Release all reservations
                from ..repositories.movements import MovementRepository
                from ..domain import MovementType
                moves = MovementRepository(self.conn).list_by_reference(
                    "customer_order", order_id
                )
                by_pl: dict[tuple[int, int], int] = {}
                for m in moves:
                    key = (m.product_id, m.location_id)
                    if m.movement_type == MovementType.RESERVATION:
                        by_pl[key] = by_pl.get(key, 0) + m.quantity
                    elif m.movement_type == MovementType.RELEASE:
                        by_pl[key] = by_pl.get(key, 0) - m.quantity
                for (pid, lid), qty in by_pl.items():
                    if qty > 0:
                        self.inventory.release_reservation(
                            pid, lid, qty,
                            reference_type="customer_order",
                            reference_id=order_id,
                        )
            self.orders.update_status(
                order_id, CustomerOrderStatus.CANCELLED, timestamp_field="cancelled_at"
            )
        return self.orders.get(order_id)  # type: ignore[return-value]
