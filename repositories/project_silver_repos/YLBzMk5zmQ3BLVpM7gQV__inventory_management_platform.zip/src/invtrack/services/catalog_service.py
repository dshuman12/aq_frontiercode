from __future__ import annotations

import sqlite3

from ..db import transaction
from ..domain import Category, Product, Supplier, Warehouse, StorageLocation
from ..errors import ConflictError, NotFoundError, ValidationError
from ..repositories.categories import CategoryRepository
from ..repositories.locations import StorageLocationRepository
from ..repositories.products import ProductRepository
from ..repositories.suppliers import SupplierRepository
from ..repositories.warehouses import WarehouseRepository
from ..validation import (
    validate_code,
    validate_email,
    validate_non_negative,
    validate_sku,
)


class CatalogService:
    """All catalog mutations go through here so that:

    - validation runs in one place
    - duplicates produce a clean ConflictError instead of an
      sqlite3.IntegrityError
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.categories = CategoryRepository(conn)
        self.suppliers = SupplierRepository(conn)
        self.products = ProductRepository(conn)
        self.warehouses = WarehouseRepository(conn)
        self.locations = StorageLocationRepository(conn)

    # ------------------------------------------------------------------
    # Categories
    # ------------------------------------------------------------------
    def create_category(self, name: str, parent_id: int | None = None) -> Category:
        name = name.strip()
        if not name:
            raise ValidationError("category name cannot be empty")
        if self.categories.get_by_name(name) is not None:
            raise ConflictError(f"category {name!r} already exists")
        if parent_id is not None and self.categories.get(parent_id) is None:
            raise NotFoundError(f"parent category {parent_id} not found")
        with transaction(self.conn):
            return self.categories.create(Category(id=None, name=name, parent_id=parent_id))

    # ------------------------------------------------------------------
    # Suppliers
    # ------------------------------------------------------------------
    def create_supplier(
        self,
        code: str,
        name: str,
        *,
        contact_email: str | None = None,
        lead_time_days: int = 7,
    ) -> Supplier:
        validate_code(code, label="supplier code")
        if not name.strip():
            raise ValidationError("supplier name cannot be empty")
        if contact_email:
            validate_email(contact_email)
        validate_non_negative(lead_time_days, label="lead_time_days")
        if self.suppliers.get_by_code(code) is not None:
            raise ConflictError(f"supplier with code {code!r} already exists")
        with transaction(self.conn):
            return self.suppliers.create(
                Supplier(
                    id=None,
                    code=code,
                    name=name.strip(),
                    contact_email=contact_email,
                    lead_time_days=lead_time_days,
                )
            )

    # ------------------------------------------------------------------
    # Products
    # ------------------------------------------------------------------
    def create_product(
        self,
        sku: str,
        name: str,
        *,
        description: str | None = None,
        category_id: int | None = None,
        supplier_id: int | None = None,
        unit_cost_cents: int = 0,
        unit_price_cents: int = 0,
        reorder_point: int = 0,
        reorder_qty: int = 0,
    ) -> Product:
        validate_sku(sku)
        if not name.strip():
            raise ValidationError("product name cannot be empty")
        validate_non_negative(unit_cost_cents, label="unit_cost_cents")
        validate_non_negative(unit_price_cents, label="unit_price_cents")
        validate_non_negative(reorder_point, label="reorder_point")
        validate_non_negative(reorder_qty, label="reorder_qty")
        if reorder_point > 0 and reorder_qty == 0:
            raise ValidationError("reorder_qty must be > 0 when reorder_point is set")
        if self.products.get_by_sku(sku) is not None:
            raise ConflictError(f"product with sku {sku!r} already exists")
        if category_id is not None and self.categories.get(category_id) is None:
            raise NotFoundError(f"category {category_id} not found")
        if supplier_id is not None and self.suppliers.get(supplier_id) is None:
            raise NotFoundError(f"supplier {supplier_id} not found")
        with transaction(self.conn):
            return self.products.create(
                Product(
                    id=None,
                    sku=sku,
                    name=name.strip(),
                    description=description,
                    category_id=category_id,
                    supplier_id=supplier_id,
                    unit_cost_cents=unit_cost_cents,
                    unit_price_cents=unit_price_cents,
                    reorder_point=reorder_point,
                    reorder_qty=reorder_qty,
                )
            )

    def update_reorder_settings(
        self,
        product_id: int,
        *,
        reorder_point: int,
        reorder_qty: int,
    ) -> Product:
        validate_non_negative(reorder_point, label="reorder_point")
        validate_non_negative(reorder_qty, label="reorder_qty")
        if reorder_point > 0 and reorder_qty == 0:
            raise ValidationError("reorder_qty must be > 0 when reorder_point is set")
        product = self.products.get(product_id)
        if product is None:
            raise NotFoundError(f"product {product_id} not found")
        from dataclasses import replace
        updated = replace(product, reorder_point=reorder_point, reorder_qty=reorder_qty)
        with transaction(self.conn):
            self.products.update(updated)
        return updated

    # ------------------------------------------------------------------
    # Warehouses & locations
    # ------------------------------------------------------------------
    def create_warehouse(self, code: str, name: str, address: str | None = None) -> Warehouse:
        validate_code(code, label="warehouse code")
        if not name.strip():
            raise ValidationError("warehouse name cannot be empty")
        if self.warehouses.get_by_code(code) is not None:
            raise ConflictError(f"warehouse with code {code!r} already exists")
        with transaction(self.conn):
            return self.warehouses.create(
                Warehouse(id=None, code=code, name=name.strip(), address=address)
            )

    def create_location(
        self,
        warehouse_id: int,
        code: str,
        description: str | None = None,
    ) -> StorageLocation:
        if self.warehouses.get(warehouse_id) is None:
            raise NotFoundError(f"warehouse {warehouse_id} not found")
        # Locations sometimes use codes like "A-12-3" which is fine; just non-empty.
        if not code or not code.strip():
            raise ValidationError("location code cannot be empty")
        if self.locations.get_by_code(warehouse_id, code) is not None:
            raise ConflictError(
                f"location {code!r} already exists in warehouse {warehouse_id}"
            )
        with transaction(self.conn):
            return self.locations.create(
                StorageLocation(
                    id=None,
                    warehouse_id=warehouse_id,
                    code=code,
                    description=description,
                )
            )
