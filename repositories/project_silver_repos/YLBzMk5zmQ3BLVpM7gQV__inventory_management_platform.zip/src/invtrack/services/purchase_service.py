from __future__ import annotations

import sqlite3
from typing import Iterable

from ..db import transaction
from ..domain import (
    POStatus,
    PurchaseOrder,
    PurchaseOrderLine,
)
from ..errors import ConflictError, NotFoundError, ValidationError
from ..repositories.audit import AuditRepository
from ..repositories.products import ProductRepository
from ..repositories.purchase_orders import PurchaseOrderRepository
from ..repositories.suppliers import SupplierRepository
from ..repositories.warehouses import WarehouseRepository
from ..validation import validate_positive
from .inventory_service import InventoryService


class PurchaseOrderService:
    """Lifecycle: draft -> submitted -> partial -> received.

    Receipts mutate inventory through the InventoryService so the
    audit trail stays consistent.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.po_repo = PurchaseOrderRepository(conn)
        self.products = ProductRepository(conn)
        self.suppliers = SupplierRepository(conn)
        self.warehouses = WarehouseRepository(conn)
        self.inventory_service = InventoryService(conn)
        self.audit = AuditRepository(conn)

    # ------------------------------------------------------------------
    # Creation
    # ------------------------------------------------------------------
    def create_draft(
        self,
        po_number: str,
        supplier_id: int,
        warehouse_id: int,
        lines: Iterable[tuple[int, int, int]],  # (product_id, qty, unit_cost_cents)
        *,
        expected_at: str | None = None,
        notes: str | None = None,
        created_by: str | None = None,
    ) -> PurchaseOrder:
        if not po_number.strip():
            raise ValidationError("po_number cannot be empty")
        if self.suppliers.get(supplier_id) is None:
            raise NotFoundError(f"supplier {supplier_id} not found")
        if self.warehouses.get(warehouse_id) is None:
            raise NotFoundError(f"warehouse {warehouse_id} not found")
        if self.po_repo.get_by_number(po_number) is not None:
            raise ConflictError(f"po_number {po_number!r} already exists")

        po_lines: list[PurchaseOrderLine] = []
        seen_products: set[int] = set()
        for product_id, qty, cost in lines:
            validate_positive(qty, label="line quantity")
            if cost < 0:
                raise ValidationError("unit cost cannot be negative")
            if product_id in seen_products:
                raise ValidationError(f"duplicate product on PO: {product_id}")
            if self.products.get(product_id) is None:
                raise NotFoundError(f"product {product_id} not found")
            seen_products.add(product_id)
            po_lines.append(
                PurchaseOrderLine(
                    id=None,
                    po_id=None,
                    product_id=product_id,
                    quantity_ordered=qty,
                    unit_cost_cents=cost,
                )
            )
        if not po_lines:
            raise ValidationError("PO must have at least one line")

        with transaction(self.conn):
            po = self.po_repo.create(
                PurchaseOrder(
                    id=None,
                    po_number=po_number,
                    supplier_id=supplier_id,
                    warehouse_id=warehouse_id,
                    status=POStatus.DRAFT,
                    expected_at=expected_at,
                    notes=notes,
                    created_by=created_by,
                    lines=tuple(po_lines),
                )
            )
            self.audit.record(
                "po.created", "po", po.id,
                actor=created_by,
                payload={"po_number": po_number, "lines": len(po_lines)},
            )
            return po

    # ------------------------------------------------------------------
    # Submit
    # ------------------------------------------------------------------
    def submit(self, po_id: int) -> PurchaseOrder:
        po = self.po_repo.get(po_id)
        if po is None:
            raise NotFoundError(f"PO {po_id} not found")
        if po.status != POStatus.DRAFT:
            raise ConflictError(
                f"only draft POs can be submitted (current status: {po.status.value})"
            )
        with transaction(self.conn):
            self.po_repo.update_status(po_id, POStatus.SUBMITTED, timestamp_field="submitted_at")
            self.audit.record("po.submitted", "po", po_id, payload={"po_number": po.po_number})
        return self.po_repo.get(po_id)  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Receipt
    # ------------------------------------------------------------------
    def receive_lines(
        self,
        po_id: int,
        receipts: Iterable[tuple[int, int, int]],  # (line_id, qty, location_id)
        *,
        received_by: str | None = None,
    ) -> PurchaseOrder:
        """Apply a (possibly partial) goods receipt against this PO.

        Each tuple is (line_id, quantity_received_now, location_id). If the
        sum across all receipts brings every line to its ordered quantity,
        the PO transitions to RECEIVED. Otherwise it goes to PARTIAL.
        """
        po = self.po_repo.get(po_id)
        if po is None:
            raise NotFoundError(f"PO {po_id} not found")
        if po.status not in {POStatus.SUBMITTED, POStatus.PARTIAL}:
            raise ConflictError(
                f"cannot receive against PO in status {po.status.value}"
            )
        receipts = list(receipts)
        if not receipts:
            raise ValidationError("at least one receipt line required")

        line_index = {line.id: line for line in po.lines}
        # Validate up front; we don't want a partial DB write
        for line_id, qty, _loc in receipts:
            validate_positive(qty, label="receipt qty")
            if line_id not in line_index:
                raise NotFoundError(f"PO line {line_id} not on PO {po_id}")
            line = line_index[line_id]
            if line.quantity_received + qty > line.quantity_ordered:
                raise ConflictError(
                    f"receipt would exceed ordered qty on line {line_id} "
                    f"({line.quantity_received + qty} > {line.quantity_ordered})"
                )

        with transaction(self.conn):
            for line_id, qty, loc_id in receipts:
                line = line_index[line_id]
                self.inventory_service.receive(
                    line.product_id,
                    loc_id,
                    qty,
                    reference_type="po",
                    reference_id=po_id,
                    note=f"PO {po.po_number}",
                    created_by=received_by,
                )
                self.po_repo.increment_received(line_id, qty)

            # Reload to compute new status
            updated = self.po_repo.get(po_id)
            assert updated is not None
            all_done = all(line.outstanding == 0 for line in updated.lines)
            if all_done:
                self.po_repo.update_status(
                    po_id, POStatus.RECEIVED, timestamp_field="received_at"
                )
                self.audit.record(
                    "po.received", "po", po_id,
                    actor=received_by,
                    payload={"po_number": po.po_number},
                )
            else:
                self.po_repo.update_status(po_id, POStatus.PARTIAL)
                self.audit.record(
                    "po.partial_receipt", "po", po_id,
                    actor=received_by,
                    payload={
                        "po_number": po.po_number,
                        "lines_received": [
                            {"line_id": lid, "qty": q} for lid, q, _ in receipts
                        ],
                    },
                )

        return self.po_repo.get(po_id)  # type: ignore[return-value]

    def cancel(self, po_id: int) -> PurchaseOrder:
        po = self.po_repo.get(po_id)
        if po is None:
            raise NotFoundError(f"PO {po_id} not found")
        if po.status in {POStatus.RECEIVED, POStatus.CANCELLED}:
            raise ConflictError(f"cannot cancel PO in status {po.status.value}")
        if po.status == POStatus.PARTIAL:
            raise ConflictError(
                "partial PO cannot be cancelled; close out remaining receipts first"
            )
        with transaction(self.conn):
            self.po_repo.update_status(po_id, POStatus.CANCELLED)
            self.audit.record("po.cancelled", "po", po_id, payload={"po_number": po.po_number})
        return self.po_repo.get(po_id)  # type: ignore[return-value]
