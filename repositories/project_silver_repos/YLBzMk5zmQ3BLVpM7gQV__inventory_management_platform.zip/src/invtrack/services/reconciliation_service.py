from __future__ import annotations

import sqlite3
from typing import Iterable

from ..db import transaction
from ..domain import StockCount, StockCountStatus
from ..errors import ConflictError, NotFoundError, ValidationError
from ..repositories.inventory import InventoryRepository
from ..repositories.locations import StorageLocationRepository
from ..repositories.products import ProductRepository
from ..repositories.stock_counts import StockCountRepository
from ..validation import validate_non_negative
from .inventory_service import InventoryService


class ReconciliationService:
    """Cycle-count workflow.

    Flow:
      open_count(location)
        -> record_counted_qty(...) [many times]
        -> apply_count(...) [variances become ADJUSTMENT movements]

    The system_qty captured on each line is the on-hand at the moment
    the count line is recorded, NOT at apply time. So a count taken on
    Monday and applied on Wednesday still represents the variance
    discovered Monday - any movements between Mon and Wed are honoured
    by re-snapshotting on apply.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self.counts = StockCountRepository(conn)
        self.inventory = InventoryRepository(conn)
        self.products = ProductRepository(conn)
        self.locations = StorageLocationRepository(conn)
        self.inventory_service = InventoryService(conn)

    def open_count(
        self,
        count_number: str,
        location_id: int,
        *,
        notes: str | None = None,
        counted_by: str | None = None,
    ) -> StockCount:
        if not count_number.strip():
            raise ValidationError("count_number cannot be empty")
        if self.locations.get(location_id) is None:
            raise NotFoundError(f"location {location_id} not found")
        if self.counts.get_by_number(count_number) is not None:
            raise ConflictError(f"count {count_number!r} already exists")
        with transaction(self.conn):
            count_id = self.counts.create_header(
                count_number, location_id, notes=notes, counted_by=counted_by
            )
        return self.counts.get(count_id)  # type: ignore[return-value]

    def record_counted_qty(
        self,
        count_id: int,
        product_id: int,
        counted_qty: int,
    ) -> None:
        validate_non_negative(counted_qty, label="counted_qty")
        count = self.counts.get(count_id)
        if count is None:
            raise NotFoundError(f"count {count_id} not found")
        if count.status != StockCountStatus.OPEN:
            raise ConflictError(
                f"cannot add lines to count in status {count.status.value}"
            )
        if self.products.get(product_id) is None:
            raise NotFoundError(f"product {product_id} not found")

        # If a line already exists for this product, update it; otherwise insert.
        existing = next(
            (l for l in count.lines if l.product_id == product_id), None
        )
        level = self.inventory.get(product_id, count.location_id)
        system_qty = level.quantity if level else 0
        with transaction(self.conn):
            if existing is None:
                self.counts.add_line(count_id, product_id, counted_qty, system_qty)
            else:
                self.counts.update_line(existing.id, counted_qty)

    def abandon(self, count_id: int) -> StockCount:
        count = self.counts.get(count_id)
        if count is None:
            raise NotFoundError(f"count {count_id} not found")
        if count.status != StockCountStatus.OPEN:
            raise ConflictError(
                f"only open counts can be abandoned (current: {count.status.value})"
            )
        with transaction(self.conn):
            self.counts.update_status(
                count_id, StockCountStatus.ABANDONED, timestamp_field="abandoned_at"
            )
        return self.counts.get(count_id)  # type: ignore[return-value]

    def apply_count(
        self,
        count_id: int,
        *,
        applied_by: str | None = None,
        max_variance_pct: float | None = None,
    ) -> tuple[StockCount, list[tuple[int, int]]]:
        """Apply variances as ADJUSTMENT movements.

        Returns (count, [(product_id, variance), ...]).

        max_variance_pct: if set, any line with |counted_qty - system_qty|/system_qty
        greater than this fraction will fail the apply unless the count's
        notes explicitly contain the word 'override'. We had a few cases of
        operators applying counts where they'd entered the wrong location.
        """
        count = self.counts.get(count_id)
        if count is None:
            raise NotFoundError(f"count {count_id} not found")
        if count.status != StockCountStatus.OPEN:
            raise ConflictError(
                f"only open counts can be applied (current: {count.status.value})"
            )
        if not count.lines:
            raise ValidationError("count has no lines to apply")

        # Re-snapshot system_qty so the variance reflects current on-hand.
        variances: list[tuple[int, int]] = []
        for line in count.lines:
            level = self.inventory.get(line.product_id, count.location_id)
            current_system = level.quantity if level else 0
            variance = line.counted_qty - current_system
            variances.append((line.product_id, variance))

        if max_variance_pct is not None:
            override = (count.notes or "").lower().find("override") >= 0
            if not override:
                for line, (_, var) in zip(count.lines, variances):
                    if line.system_qty == 0 and var != 0:
                        # Brand-new SKU at this location, allow.
                        continue
                    if line.system_qty > 0:
                        pct = abs(var) / line.system_qty
                        if pct > max_variance_pct:
                            raise ConflictError(
                                f"variance {pct:.0%} on product {line.product_id} "
                                f"exceeds threshold {max_variance_pct:.0%}; "
                                "add 'override' to notes to bypass"
                            )

        with transaction(self.conn):
            for product_id, variance in variances:
                if variance == 0:
                    continue
                self.inventory_service.adjust(
                    product_id,
                    count.location_id,
                    variance,
                    note=f"cycle count {count.count_number}",
                    created_by=applied_by,
                )
            self.counts.update_status(
                count_id, StockCountStatus.APPLIED, timestamp_field="applied_at"
            )
        return self.counts.get(count_id), variances  # type: ignore[return-value]
