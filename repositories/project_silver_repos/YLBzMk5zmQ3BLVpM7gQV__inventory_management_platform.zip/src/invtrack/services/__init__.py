"""Service layer.

Services orchestrate repositories, enforce business rules, and own
transactions. They receive a connection in their constructor and use
the transaction() context manager from db when they need atomicity.
"""
