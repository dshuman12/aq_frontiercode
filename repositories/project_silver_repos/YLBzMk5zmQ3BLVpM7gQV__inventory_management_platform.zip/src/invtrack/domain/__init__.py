"""Domain objects.

Plain dataclasses. We deliberately keep these dumb - no ORM, no
behaviour beyond simple derived properties. Business rules live
in the services layer.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class MovementType(str, Enum):
    RECEIPT = "receipt"        # incoming from supplier (PO)
    SHIPMENT = "shipment"      # outgoing to customer
    TRANSFER_OUT = "transfer_out"
    TRANSFER_IN = "transfer_in"
    ADJUSTMENT = "adjustment"  # reconciliation / manual correction
    RESERVATION = "reservation"
    RELEASE = "release"        # reservation released


class POStatus(str, Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    PARTIAL = "partial"
    RECEIVED = "received"
    CANCELLED = "cancelled"


class CustomerOrderStatus(str, Enum):
    DRAFT = "draft"
    CONFIRMED = "confirmed"
    PICKING = "picking"
    SHIPPED = "shipped"
    CANCELLED = "cancelled"


class TransferStatus(str, Enum):
    IN_TRANSIT = "in_transit"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class StockCountStatus(str, Enum):
    OPEN = "open"
    APPLIED = "applied"
    ABANDONED = "abandoned"


@dataclass(frozen=True)
class Category:
    id: Optional[int]
    name: str
    parent_id: Optional[int] = None


@dataclass(frozen=True)
class Supplier:
    id: Optional[int]
    code: str
    name: str
    contact_email: Optional[str] = None
    lead_time_days: int = 7
    active: bool = True


@dataclass(frozen=True)
class Product:
    id: Optional[int]
    sku: str
    name: str
    description: Optional[str] = None
    category_id: Optional[int] = None
    supplier_id: Optional[int] = None
    unit_cost_cents: int = 0
    unit_price_cents: int = 0
    reorder_point: int = 0
    reorder_qty: int = 0
    active: bool = True


@dataclass(frozen=True)
class Warehouse:
    id: Optional[int]
    code: str
    name: str
    address: Optional[str] = None
    active: bool = True


@dataclass(frozen=True)
class StorageLocation:
    id: Optional[int]
    warehouse_id: int
    code: str
    description: Optional[str] = None
    active: bool = True


@dataclass(frozen=True)
class InventoryLevel:
    id: Optional[int]
    product_id: int
    location_id: int
    quantity: int
    reserved: int

    @property
    def available(self) -> int:
        return self.quantity - self.reserved


@dataclass(frozen=True)
class StockMovement:
    id: Optional[int]
    product_id: int
    location_id: int
    movement_type: MovementType
    quantity: int
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None
    note: Optional[str] = None
    created_by: Optional[str] = None
    created_at: Optional[str] = None


@dataclass(frozen=True)
class PurchaseOrderLine:
    id: Optional[int]
    po_id: Optional[int]
    product_id: int
    quantity_ordered: int
    unit_cost_cents: int
    quantity_received: int = 0

    @property
    def outstanding(self) -> int:
        return self.quantity_ordered - self.quantity_received


@dataclass(frozen=True)
class PurchaseOrder:
    id: Optional[int]
    po_number: str
    supplier_id: int
    warehouse_id: int
    status: POStatus = POStatus.DRAFT
    expected_at: Optional[str] = None
    submitted_at: Optional[str] = None
    received_at: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[str] = None
    lines: tuple[PurchaseOrderLine, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class CustomerOrderLine:
    id: Optional[int]
    order_id: Optional[int]
    product_id: int
    quantity: int
    unit_price_cents: int
    quantity_picked: int = 0
    quantity_shipped: int = 0


@dataclass(frozen=True)
class CustomerOrder:
    id: Optional[int]
    order_number: str
    customer_name: str
    warehouse_id: int
    customer_email: Optional[str] = None
    status: CustomerOrderStatus = CustomerOrderStatus.DRAFT
    confirmed_at: Optional[str] = None
    shipped_at: Optional[str] = None
    cancelled_at: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[str] = None
    lines: tuple[CustomerOrderLine, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class StockTransferLine:
    id: Optional[int]
    transfer_id: Optional[int]
    product_id: int
    quantity: int


@dataclass(frozen=True)
class StockTransfer:
    id: Optional[int]
    transfer_number: str
    source_location_id: int
    dest_location_id: int
    status: TransferStatus = TransferStatus.IN_TRANSIT
    initiated_at: Optional[str] = None
    completed_at: Optional[str] = None
    cancelled_at: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[str] = None
    lines: tuple[StockTransferLine, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class StockCountLine:
    id: Optional[int]
    count_id: Optional[int]
    product_id: int
    counted_qty: int
    system_qty: int

    @property
    def variance(self) -> int:
        return self.counted_qty - self.system_qty


@dataclass(frozen=True)
class StockCount:
    id: Optional[int]
    count_number: str
    location_id: int
    status: StockCountStatus = StockCountStatus.OPEN
    started_at: Optional[str] = None
    applied_at: Optional[str] = None
    abandoned_at: Optional[str] = None
    notes: Optional[str] = None
    counted_by: Optional[str] = None
    lines: tuple[StockCountLine, ...] = field(default_factory=tuple)
