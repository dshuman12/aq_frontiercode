"""Operator-facing CLI.

Subcommands are grouped by area:

  invtrack init                        # create db file and run migrations
  invtrack product add SKU NAME ...    # catalog
  invtrack product list
  invtrack supplier add CODE NAME
  invtrack warehouse add CODE NAME
  invtrack location add WH CODE
  invtrack stock receive SKU LOC QTY
  invtrack stock ship SKU LOC QTY
  invtrack stock adjust SKU LOC DELTA --note ...
  invtrack stock show SKU
  invtrack po draft NUMBER SUPPLIER WH SKU=QTY@COST ...
  invtrack po submit ID
  invtrack po receive ID LINE=QTY,LOC ...
  invtrack po list [--status STATUS]
  invtrack report stock-summary
  invtrack report low-stock
  invtrack report valuation
  invtrack import products PATH
  invtrack import opening-stock PATH
  invtrack export products PATH
  invtrack export movements PATH
  invtrack jobs run NAME
  invtrack jobs list
  invtrack alerts list
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Sequence

from .db import connect, transaction
from .db.schema import migrate
from .errors import InvtrackError
from .repositories.alerts import AlertRepository
from .repositories.products import ProductRepository
from .repositories.suppliers import SupplierRepository
from .repositories.warehouses import WarehouseRepository
from .repositories.purchase_orders import PurchaseOrderRepository
from .reporting.inventory_reports import (
    low_stock,
    stock_summary,
    valuation,
)
from .services.catalog_service import CatalogService
from .services.inventory_service import InventoryService
from .services.purchase_service import PurchaseOrderService


DEFAULT_DB = "data/invtrack.db"


def _db_path(args: argparse.Namespace) -> Path:
    p = Path(args.db or os.environ.get("INVTRACK_DB", DEFAULT_DB))
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _print_table(rows: Sequence[dict], cols: Sequence[str]) -> None:
    if not rows:
        print("(no rows)")
        return
    widths = {c: max(len(c), max(len(str(r.get(c, ""))) for r in rows)) for c in cols}
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    sep = "  ".join("-" * widths[c] for c in cols)
    print(header)
    print(sep)
    for r in rows:
        print("  ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols))


# -----------------------------------------------------------------------------
# init
# -----------------------------------------------------------------------------
def cmd_init(args: argparse.Namespace) -> int:
    path = _db_path(args)
    conn = connect(path)
    try:
        version = migrate(conn)
        print(f"db at {path} -> schema v{version}")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# product
# -----------------------------------------------------------------------------
def cmd_product_add(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        cat = CatalogService(conn)
        kwargs: dict = {}
        if args.cost is not None:
            kwargs["unit_cost_cents"] = args.cost
        if args.price is not None:
            kwargs["unit_price_cents"] = args.price
        if args.reorder_point is not None:
            kwargs["reorder_point"] = args.reorder_point
        if args.reorder_qty is not None:
            kwargs["reorder_qty"] = args.reorder_qty
        if args.supplier:
            sup = cat.suppliers.get_by_code(args.supplier)
            if sup is None:
                print(f"unknown supplier code {args.supplier}", file=sys.stderr)
                return 2
            kwargs["supplier_id"] = sup.id
        if args.category:
            cobj = cat.categories.get_by_name(args.category)
            if cobj is None:
                print(f"unknown category {args.category}", file=sys.stderr)
                return 2
            kwargs["category_id"] = cobj.id
        p = cat.create_product(args.sku, args.name, **kwargs)
        print(f"created product id={p.id} sku={p.sku}")
        return 0
    finally:
        conn.close()


def cmd_product_list(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        products = ProductRepository(conn).list_active()
        rows = [{"id": p.id, "sku": p.sku, "name": p.name,
                 "reorder_point": p.reorder_point, "reorder_qty": p.reorder_qty}
                for p in products]
        _print_table(rows, ["id", "sku", "name", "reorder_point", "reorder_qty"])
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# supplier / warehouse / location / category
# -----------------------------------------------------------------------------
def cmd_supplier_add(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        kwargs: dict = {}
        if args.email:
            kwargs["contact_email"] = args.email
        if args.lead_time is not None:
            kwargs["lead_time_days"] = args.lead_time
        s = CatalogService(conn).create_supplier(args.code, args.name, **kwargs)
        print(f"created supplier id={s.id} code={s.code}")
        return 0
    finally:
        conn.close()


def cmd_supplier_list(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        suppliers = SupplierRepository(conn).list_active()
        rows = [{"id": s.id, "code": s.code, "name": s.name,
                 "lead_time_days": s.lead_time_days,
                 "email": s.contact_email or ""} for s in suppliers]
        _print_table(rows, ["id", "code", "name", "lead_time_days", "email"])
        return 0
    finally:
        conn.close()


def cmd_warehouse_add(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        w = CatalogService(conn).create_warehouse(args.code, args.name, args.address)
        print(f"created warehouse id={w.id} code={w.code}")
        return 0
    finally:
        conn.close()


def cmd_location_add(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        cat = CatalogService(conn)
        wh = cat.warehouses.get_by_code(args.warehouse)
        if wh is None:
            print(f"unknown warehouse code {args.warehouse}", file=sys.stderr)
            return 2
        loc = cat.create_location(wh.id, args.code, args.description)
        print(f"created location id={loc.id} {wh.code}/{loc.code}")
        return 0
    finally:
        conn.close()


def cmd_category_add(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        cat = CatalogService(conn)
        parent_id: int | None = None
        if args.parent:
            parent = cat.categories.get_by_name(args.parent)
            if parent is None:
                print(f"unknown parent category {args.parent}", file=sys.stderr)
                return 2
            parent_id = parent.id
        c = cat.create_category(args.name, parent_id)
        print(f"created category id={c.id} name={c.name}")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# stock
# -----------------------------------------------------------------------------
def _resolve_product_location(conn, sku: str, loc_spec: str) -> tuple[int, int]:
    cat = CatalogService(conn)
    p = cat.products.get_by_sku(sku)
    if p is None:
        raise SystemExit(f"unknown sku {sku!r}")
    if "/" not in loc_spec:
        raise SystemExit("location must be WH/CODE")
    wh_code, loc_code = loc_spec.split("/", 1)
    wh = cat.warehouses.get_by_code(wh_code)
    if wh is None:
        raise SystemExit(f"unknown warehouse {wh_code!r}")
    loc = cat.locations.get_by_code(wh.id, loc_code)
    if loc is None:
        raise SystemExit(f"unknown location {loc_spec!r}")
    return p.id, loc.id


def cmd_stock_receive(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        product_id, location_id = _resolve_product_location(conn, args.sku, args.location)
        level = InventoryService(conn).receive(product_id, location_id, args.quantity)
        print(f"received {args.quantity}; on hand: {level.quantity}")
        return 0
    finally:
        conn.close()


def cmd_stock_ship(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        product_id, location_id = _resolve_product_location(conn, args.sku, args.location)
        level = InventoryService(conn).ship(product_id, location_id, args.quantity)
        print(f"shipped {args.quantity}; on hand: {level.quantity}")
        return 0
    finally:
        conn.close()


def cmd_stock_adjust(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        product_id, location_id = _resolve_product_location(conn, args.sku, args.location)
        level = InventoryService(conn).adjust(
            product_id, location_id, args.delta,
            note=args.note, created_by=args.actor,
        )
        print(f"adjusted by {args.delta}; on hand: {level.quantity}")
        return 0
    finally:
        conn.close()


def cmd_stock_show(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        cat = CatalogService(conn)
        p = cat.products.get_by_sku(args.sku)
        if p is None:
            print(f"unknown sku {args.sku!r}", file=sys.stderr)
            return 2
        inv = InventoryService(conn).inventory
        levels = inv.levels_for_product(p.id)
        rows = []
        for lvl in levels:
            loc = cat.locations.get(lvl.location_id)
            wh = cat.warehouses.get(loc.warehouse_id) if loc else None
            rows.append({
                "warehouse": wh.code if wh else "?",
                "location": loc.code if loc else "?",
                "quantity": lvl.quantity,
                "reserved": lvl.reserved,
                "available": lvl.available,
            })
        print(f"product: {p.sku} {p.name}")
        _print_table(rows, ["warehouse", "location", "quantity", "reserved", "available"])
        print(f"total on hand: {inv.total_quantity(p.id)}")
        print(f"total available: {inv.total_available(p.id)}")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# po
# -----------------------------------------------------------------------------
def _parse_po_line(spec: str) -> tuple[str, int, int]:
    """Format: SKU=QTY@COST_CENTS"""
    if "=" not in spec or "@" not in spec:
        raise SystemExit(f"bad PO line {spec!r}: expected SKU=QTY@COST")
    sku, rest = spec.split("=", 1)
    qty, cost = rest.split("@", 1)
    return sku, int(qty), int(cost)


def cmd_po_draft(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        cat = CatalogService(conn)
        sup = cat.suppliers.get_by_code(args.supplier)
        if sup is None:
            print(f"unknown supplier {args.supplier}", file=sys.stderr)
            return 2
        wh = cat.warehouses.get_by_code(args.warehouse)
        if wh is None:
            print(f"unknown warehouse {args.warehouse}", file=sys.stderr)
            return 2
        line_specs = [_parse_po_line(s) for s in args.lines]
        lines: list[tuple[int, int, int]] = []
        for sku, qty, cost in line_specs:
            p = cat.products.get_by_sku(sku)
            if p is None:
                print(f"unknown sku {sku}", file=sys.stderr)
                return 2
            lines.append((p.id, qty, cost))
        po = PurchaseOrderService(conn).create_draft(
            args.number, sup.id, wh.id, lines,
            expected_at=args.expected, notes=args.notes,
            created_by=args.actor,
        )
        print(f"created PO {po.po_number} (id={po.id}) status={po.status.value}")
        return 0
    finally:
        conn.close()


def cmd_po_submit(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        po = PurchaseOrderService(conn).submit(args.id)
        print(f"PO {po.po_number} submitted at {po.submitted_at}")
        return 0
    finally:
        conn.close()


def cmd_po_receive(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        receipts: list[tuple[int, int, int]] = []
        cat = CatalogService(conn)
        for spec in args.receipts:
            # LINE_ID=QTY,WH/LOC
            head, loc_spec = spec.rsplit(",", 1)
            line_id_s, qty_s = head.split("=", 1)
            wh_code, loc_code = loc_spec.split("/", 1)
            wh = cat.warehouses.get_by_code(wh_code)
            loc = cat.locations.get_by_code(wh.id, loc_code) if wh else None
            if loc is None:
                print(f"unknown location {loc_spec}", file=sys.stderr)
                return 2
            receipts.append((int(line_id_s), int(qty_s), loc.id))
        po = PurchaseOrderService(conn).receive_lines(
            args.id, receipts, received_by=args.actor
        )
        print(f"PO {po.po_number} now {po.status.value}")
        return 0
    finally:
        conn.close()


def cmd_po_list(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        from .domain import POStatus
        repo = PurchaseOrderRepository(conn)
        if args.status:
            pos = repo.list_by_status(POStatus(args.status))
        else:
            pos = repo.list_open()
        rows = [{"id": p.id, "number": p.po_number, "status": p.status.value,
                 "lines": len(p.lines), "expected": p.expected_at or ""}
                for p in pos]
        _print_table(rows, ["id", "number", "status", "lines", "expected"])
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# report
# -----------------------------------------------------------------------------
def cmd_report_stock(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        rows = stock_summary(conn)
        _print_table(
            [{"sku": r.sku, "name": r.name, "qty": r.total_quantity,
              "reserved": r.total_reserved, "available": r.total_available,
              "needs_reorder": "Y" if r.needs_reorder else ""}
             for r in rows],
            ["sku", "name", "qty", "reserved", "available", "needs_reorder"],
        )
        return 0
    finally:
        conn.close()


def cmd_report_low(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        rows = low_stock(conn)
        _print_table(
            [{"sku": r.sku, "name": r.name, "available": r.available,
              "reorder_point": r.reorder_point, "order_qty": r.suggested_order_qty,
              "supplier": r.supplier_code or ""}
             for r in rows],
            ["sku", "name", "available", "reorder_point", "order_qty", "supplier"],
        )
        return 0
    finally:
        conn.close()


def cmd_report_valuation(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        rows = valuation(conn)
        total = sum(r.value_cents for r in rows)
        _print_table(
            [{"sku": r.sku, "name": r.name, "qty": r.total_quantity,
              "unit_cost": r.unit_cost_cents, "value": r.value_cents}
             for r in rows],
            ["sku", "name", "qty", "unit_cost", "value"],
        )
        print(f"\ntotal valuation: {total} cents ({total/100:.2f})")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# import / export
# -----------------------------------------------------------------------------
def cmd_import(args: argparse.Namespace) -> int:
    from .io.csv_import import (
        import_categories,
        import_opening_stock,
        import_products,
        import_suppliers,
    )
    fns = {
        "categories": import_categories,
        "suppliers": import_suppliers,
        "products": import_products,
        "opening-stock": import_opening_stock,
    }
    fn = fns[args.kind]
    conn = connect(_db_path(args))
    try:
        if args.kind == "opening-stock":
            summary = fn(conn, args.path, actor=args.actor)
        else:
            summary = fn(conn, args.path)
        print(f"total={summary.rows_total} imported={summary.rows_imported} "
              f"skipped={summary.rows_skipped}")
        return 0
    finally:
        conn.close()


def cmd_export(args: argparse.Namespace) -> int:
    from .io.csv_export import (
        export_low_stock,
        export_movements,
        export_products,
        export_stock_summary,
        export_valuation,
    )
    fns = {
        "products": export_products,
        "stock-summary": export_stock_summary,
        "low-stock": export_low_stock,
        "valuation": export_valuation,
        "movements": export_movements,
    }
    fn = fns[args.kind]
    conn = connect(_db_path(args))
    try:
        n = fn(conn, args.path)
        print(f"exported {n} rows to {args.path}")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# jobs
# -----------------------------------------------------------------------------
def cmd_jobs_run(args: argparse.Namespace) -> int:
    from .jobs import run_job
    from .jobs.low_stock_alerts import low_stock_alert_job
    from .jobs.overdue_po import overdue_po_job
    from .jobs.stale_reservations import stale_reservation_audit_job
    fns = {
        "low_stock": low_stock_alert_job,
        "overdue_po": overdue_po_job,
        "stale_reservations": stale_reservation_audit_job,
    }
    if args.name not in fns:
        print(f"unknown job {args.name}; available: {', '.join(fns)}", file=sys.stderr)
        return 2
    conn = connect(_db_path(args))
    try:
        result = run_job(conn, args.name, fns[args.name])
        print(f"{args.name}: {result.summary}")
        return 0
    finally:
        conn.close()


def cmd_jobs_list(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        rows = conn.execute(
            "SELECT id, job_name, started_at, finished_at, status, summary "
            "FROM job_runs ORDER BY started_at DESC LIMIT ?",
            (args.limit,),
        ).fetchall()
        _print_table(
            [dict(r) for r in rows],
            ["id", "job_name", "started_at", "finished_at", "status", "summary"],
        )
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# alerts
# -----------------------------------------------------------------------------
def cmd_alerts_list(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        alerts = AlertRepository(conn).list_open(args.type)
        rows = [{"id": a.id, "type": a.alert_type, "severity": a.severity,
                 "subject": f"{a.subject_type}#{a.subject_id}",
                 "message": a.message, "raised": a.raised_at}
                for a in alerts]
        _print_table(rows, ["id", "type", "severity", "subject", "message", "raised"])
        return 0
    finally:
        conn.close()


def cmd_alerts_resolve(args: argparse.Namespace) -> int:
    conn = connect(_db_path(args))
    try:
        with transaction(conn):
            AlertRepository(conn).resolve(args.id)
        print(f"alert {args.id} resolved")
        return 0
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# parser
# -----------------------------------------------------------------------------
def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="invtrack", description="invtrack inventory CLI")
    p.add_argument("--db", help="path to sqlite db (default: $INVTRACK_DB or data/invtrack.db)")
    sub = p.add_subparsers(dest="cmd", required=True)

    # init
    sp = sub.add_parser("init", help="initialise database / run migrations")
    sp.set_defaults(func=cmd_init)

    # product
    sp = sub.add_parser("product")
    psub = sp.add_subparsers(dest="action", required=True)
    sp_add = psub.add_parser("add")
    sp_add.add_argument("sku")
    sp_add.add_argument("name")
    sp_add.add_argument("--cost", type=int, help="unit cost in cents")
    sp_add.add_argument("--price", type=int, help="unit price in cents")
    sp_add.add_argument("--reorder-point", type=int)
    sp_add.add_argument("--reorder-qty", type=int)
    sp_add.add_argument("--supplier", help="supplier code")
    sp_add.add_argument("--category", help="category name")
    sp_add.set_defaults(func=cmd_product_add)
    psub.add_parser("list").set_defaults(func=cmd_product_list)

    # supplier
    sp = sub.add_parser("supplier")
    ssub = sp.add_subparsers(dest="action", required=True)
    sp_add = ssub.add_parser("add")
    sp_add.add_argument("code")
    sp_add.add_argument("name")
    sp_add.add_argument("--email")
    sp_add.add_argument("--lead-time", type=int)
    sp_add.set_defaults(func=cmd_supplier_add)
    ssub.add_parser("list").set_defaults(func=cmd_supplier_list)

    # warehouse
    sp = sub.add_parser("warehouse")
    wsub = sp.add_subparsers(dest="action", required=True)
    sp_add = wsub.add_parser("add")
    sp_add.add_argument("code")
    sp_add.add_argument("name")
    sp_add.add_argument("--address")
    sp_add.set_defaults(func=cmd_warehouse_add)

    # location
    sp = sub.add_parser("location")
    lsub = sp.add_subparsers(dest="action", required=True)
    sp_add = lsub.add_parser("add")
    sp_add.add_argument("warehouse", help="warehouse code")
    sp_add.add_argument("code")
    sp_add.add_argument("--description")
    sp_add.set_defaults(func=cmd_location_add)

    # category
    sp = sub.add_parser("category")
    csub = sp.add_subparsers(dest="action", required=True)
    sp_add = csub.add_parser("add")
    sp_add.add_argument("name")
    sp_add.add_argument("--parent")
    sp_add.set_defaults(func=cmd_category_add)

    # stock
    sp = sub.add_parser("stock")
    stsub = sp.add_subparsers(dest="action", required=True)
    for name, fn, has_note in [
        ("receive", cmd_stock_receive, False),
        ("ship", cmd_stock_ship, False),
    ]:
        sub_a = stsub.add_parser(name)
        sub_a.add_argument("sku")
        sub_a.add_argument("location", help="WAREHOUSE_CODE/LOCATION_CODE")
        sub_a.add_argument("quantity", type=int)
        sub_a.set_defaults(func=fn)
    sub_adj = stsub.add_parser("adjust")
    sub_adj.add_argument("sku")
    sub_adj.add_argument("location")
    sub_adj.add_argument("delta", type=int)
    sub_adj.add_argument("--note", required=True)
    sub_adj.add_argument("--actor", default=os.environ.get("USER"))
    sub_adj.set_defaults(func=cmd_stock_adjust)
    sub_show = stsub.add_parser("show")
    sub_show.add_argument("sku")
    sub_show.set_defaults(func=cmd_stock_show)

    # po
    sp = sub.add_parser("po")
    posub = sp.add_subparsers(dest="action", required=True)
    sp_d = posub.add_parser("draft")
    sp_d.add_argument("number")
    sp_d.add_argument("supplier")
    sp_d.add_argument("warehouse")
    sp_d.add_argument("lines", nargs="+", help="SKU=QTY@COST_CENTS ...")
    sp_d.add_argument("--expected", help="YYYY-MM-DD")
    sp_d.add_argument("--notes")
    sp_d.add_argument("--actor", default=os.environ.get("USER"))
    sp_d.set_defaults(func=cmd_po_draft)
    sp_s = posub.add_parser("submit")
    sp_s.add_argument("id", type=int)
    sp_s.set_defaults(func=cmd_po_submit)
    sp_r = posub.add_parser("receive")
    sp_r.add_argument("id", type=int)
    sp_r.add_argument("receipts", nargs="+", help="LINE_ID=QTY,WH/LOC ...")
    sp_r.add_argument("--actor", default=os.environ.get("USER"))
    sp_r.set_defaults(func=cmd_po_receive)
    sp_l = posub.add_parser("list")
    sp_l.add_argument("--status", choices=["draft", "submitted", "partial",
                                            "received", "cancelled"])
    sp_l.set_defaults(func=cmd_po_list)

    # report
    sp = sub.add_parser("report")
    rsub = sp.add_subparsers(dest="action", required=True)
    rsub.add_parser("stock-summary").set_defaults(func=cmd_report_stock)
    rsub.add_parser("low-stock").set_defaults(func=cmd_report_low)
    rsub.add_parser("valuation").set_defaults(func=cmd_report_valuation)

    # import / export
    sp = sub.add_parser("import")
    sp.add_argument("kind", choices=["categories", "suppliers", "products", "opening-stock"])
    sp.add_argument("path")
    sp.add_argument("--actor", default=os.environ.get("USER"))
    sp.set_defaults(func=cmd_import)

    sp = sub.add_parser("export")
    sp.add_argument("kind", choices=["products", "stock-summary", "low-stock",
                                      "valuation", "movements"])
    sp.add_argument("path")
    sp.set_defaults(func=cmd_export)

    # jobs
    sp = sub.add_parser("jobs")
    jsub = sp.add_subparsers(dest="action", required=True)
    sp_run = jsub.add_parser("run")
    sp_run.add_argument("name")
    sp_run.set_defaults(func=cmd_jobs_run)
    sp_list = jsub.add_parser("list")
    sp_list.add_argument("--limit", type=int, default=20)
    sp_list.set_defaults(func=cmd_jobs_list)

    # alerts
    sp = sub.add_parser("alerts")
    asub = sp.add_subparsers(dest="action", required=True)
    sp_l = asub.add_parser("list")
    sp_l.add_argument("--type")
    sp_l.set_defaults(func=cmd_alerts_list)
    sp_r = asub.add_parser("resolve")
    sp_r.add_argument("id", type=int)
    sp_r.set_defaults(func=cmd_alerts_resolve)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except InvtrackError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
