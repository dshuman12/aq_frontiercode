"""Runtime configuration.

Settings are read from environment variables on startup. We deliberately
keep this small - if a setting can be derived (db path, log level), it is.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    db_path: Path = field(default_factory=lambda: Path(os.environ.get(
        "INVTRACK_DB", "data/invtrack.db",
    )))
    api_keys_path: Path = field(default_factory=lambda: Path(os.environ.get(
        "INVTRACK_API_KEYS", "data/api_keys.json",
    )))
    log_level: str = field(default_factory=lambda: os.environ.get(
        "INVTRACK_LOG_LEVEL", "INFO",
    ).upper())
    log_format: str = field(default_factory=lambda: os.environ.get(
        "INVTRACK_LOG_FORMAT", "json",
    ))
    # Default paginated page size
    page_size_default: int = 50
    page_size_max: int = 500
    # Disable auth in tests - never set this in prod
    auth_disabled: bool = field(default_factory=lambda: os.environ.get(
        "INVTRACK_DISABLE_AUTH", "0",
    ) == "1")


def load_settings() -> Settings:
    return Settings()
