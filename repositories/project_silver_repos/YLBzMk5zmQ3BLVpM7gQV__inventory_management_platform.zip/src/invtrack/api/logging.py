"""Structured logging.

Output format is selected by INVTRACK_LOG_FORMAT (json|text). JSON mode
is preferred for production - the log shipper can parse it directly. Text
mode is human-friendly for local development.

A small middleware records one line per request with method, path,
status code, duration ms, principal name, and request_id so traces can be
stitched together across services.
"""
from __future__ import annotations

import json
import logging
import sys
import time
import uuid
from typing import Any, Optional


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        out: dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        # Surface any extras attached via logger.info("...", extra={...})
        for key, value in record.__dict__.items():
            if key in ("args", "asctime", "created", "exc_info", "exc_text",
                      "filename", "funcName", "levelname", "levelno",
                      "lineno", "module", "msecs", "message", "msg", "name",
                      "pathname", "process", "processName", "relativeCreated",
                      "stack_info", "thread", "threadName", "taskName"):
                continue
            out[key] = value
        return json.dumps(out, default=str)


class TextFormatter(logging.Formatter):
    def __init__(self) -> None:
        super().__init__("%(asctime)s %(levelname)-8s %(name)s: %(message)s",
                         datefmt="%Y-%m-%d %H:%M:%S")


def configure_logging(level: str = "INFO", format: str = "json") -> None:
    root = logging.getLogger()
    # Avoid duplicate handlers if reconfigured (e.g. in tests)
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter() if format == "json" else TextFormatter())
    root.addHandler(handler)
    root.setLevel(level)


def request_id() -> str:
    return uuid.uuid4().hex[:12]
