from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query

from ...db import transaction
from ...errors import NotFoundError
from ...repositories.alerts import AlertRepository
from ..auth import require_operator, require_viewer
from ..deps import get_db
from ..pagination import Page, PaginationParams, pagination_params
from ..schemas import AlertRead


router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("", response_model=Page[AlertRead],
            dependencies=[Depends(require_viewer)])
def list_alerts(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    type: Optional[str] = Query(None, alias="type"),
    severity: Optional[str] = Query(None),
    include_resolved: bool = Query(False),
) -> Page[AlertRead]:
    where: list[str] = []
    params: list = []
    if not include_resolved:
        where.append("resolved_at IS NULL")
    if type:
        where.append("alert_type = ?")
        params.append(type)
    if severity:
        where.append("severity = ?")
        params.append(severity)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM alerts {where_clause}", params
    ).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT * FROM alerts {where_clause}
            ORDER BY raised_at DESC LIMIT ? OFFSET ?""",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()
    items = [
        AlertRead(
            id=r["id"], alert_type=r["alert_type"], severity=r["severity"],
            subject_type=r["subject_type"], subject_id=r["subject_id"],
            message=r["message"], raised_at=r["raised_at"],
            resolved_at=r["resolved_at"],
        )
        for r in rows
    ]
    return Page.build(items, total, pagination)


@router.post("/{alert_id}/resolve",
             dependencies=[Depends(require_operator)])
def resolve_alert(
    alert_id: int,
    conn: sqlite3.Connection = Depends(get_db),
) -> dict:
    repo = AlertRepository(conn)
    existing = conn.execute(
        "SELECT id, resolved_at FROM alerts WHERE id = ?", (alert_id,)
    ).fetchone()
    if existing is None:
        raise NotFoundError(f"alert {alert_id} not found")
    if existing["resolved_at"] is not None:
        return {"id": alert_id, "already_resolved": True}
    with transaction(conn):
        repo.resolve(alert_id)
    return {"id": alert_id, "resolved": True}
