from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ...errors import ConflictError, NotFoundError
from ...repositories.products import ProductRepository
from ...repositories.categories import CategoryRepository
from ...repositories.suppliers import SupplierRepository
from ...services.catalog_service import CatalogService
from ..auth import require_admin, require_operator, require_viewer
from ..deps import get_catalog_service, get_db
from ..pagination import Page, PaginationParams, SortParams, pagination_params, sort_params
from ..schemas import ProductCreate, ProductRead, ReorderUpdate


router = APIRouter(prefix="/products", tags=["products"])


_SORT_COLUMNS = {"sku", "name", "unit_cost_cents", "unit_price_cents",
                 "reorder_point", "created_at", "updated_at"}


@router.get("", response_model=Page[ProductRead],
            dependencies=[Depends(require_viewer)],
            summary="List products with pagination and search")
def list_products(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    sort: SortParams = Depends(sort_params),
    q: Optional[str] = Query(None, description="search across sku/name/description"),
    category_id: Optional[int] = Query(None),
    supplier_id: Optional[int] = Query(None),
    active: Optional[bool] = Query(None),
) -> Page[ProductRead]:
    sort_pair = sort.parse(_SORT_COLUMNS)
    where: list[str] = []
    params: list = []
    if q:
        where.append("(sku LIKE ? OR name LIKE ? OR COALESCE(description,'') LIKE ?)")
        like = f"%{q}%"
        params.extend([like, like, like])
    if category_id is not None:
        where.append("category_id = ?")
        params.append(category_id)
    if supplier_id is not None:
        where.append("supplier_id = ?")
        params.append(supplier_id)
    if active is not None:
        where.append("active = ?")
        params.append(1 if active else 0)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""

    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM products {where_clause}", params
    ).fetchone()["c"]

    order_clause = "ORDER BY sku ASC"
    if sort_pair:
        col, direction = sort_pair
        order_clause = f"ORDER BY {col} {direction}"

    rows = conn.execute(
        f"""SELECT * FROM products {where_clause} {order_clause}
            LIMIT ? OFFSET ?""",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()

    items = [
        ProductRead(
            id=r["id"], sku=r["sku"], name=r["name"], description=r["description"],
            category_id=r["category_id"], supplier_id=r["supplier_id"],
            unit_cost_cents=r["unit_cost_cents"], unit_price_cents=r["unit_price_cents"],
            reorder_point=r["reorder_point"], reorder_qty=r["reorder_qty"],
            active=bool(r["active"]),
        )
        for r in rows
    ]
    return Page.build(items, total, pagination)


@router.get("/{sku}", response_model=ProductRead,
            dependencies=[Depends(require_viewer)],
            summary="Look up a product by SKU")
def get_product(
    sku: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> ProductRead:
    p = ProductRepository(conn).get_by_sku(sku)
    if p is None:
        raise NotFoundError(f"product {sku!r} not found")
    return ProductRead(
        id=p.id, sku=p.sku, name=p.name, description=p.description,
        category_id=p.category_id, supplier_id=p.supplier_id,
        unit_cost_cents=p.unit_cost_cents, unit_price_cents=p.unit_price_cents,
        reorder_point=p.reorder_point, reorder_qty=p.reorder_qty,
        active=p.active,
    )


@router.post("", response_model=ProductRead, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_operator)],
             summary="Create a product")
def create_product(
    payload: ProductCreate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> ProductRead:
    p = catalog.create_product(
        sku=payload.sku,
        name=payload.name,
        description=payload.description,
        category_id=payload.category_id,
        supplier_id=payload.supplier_id,
        unit_cost_cents=payload.unit_cost_cents,
        unit_price_cents=payload.unit_price_cents,
        reorder_point=payload.reorder_point,
        reorder_qty=payload.reorder_qty,
    )
    return ProductRead(
        id=p.id, sku=p.sku, name=p.name, description=p.description,
        category_id=p.category_id, supplier_id=p.supplier_id,
        unit_cost_cents=p.unit_cost_cents, unit_price_cents=p.unit_price_cents,
        reorder_point=p.reorder_point, reorder_qty=p.reorder_qty,
        active=p.active,
    )


@router.put("/{sku}/reorder", response_model=ProductRead,
            dependencies=[Depends(require_operator)],
            summary="Update reorder thresholds")
def update_reorder(
    sku: str,
    payload: ReorderUpdate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> ProductRead:
    p = catalog.products.get_by_sku(sku)
    if p is None:
        raise NotFoundError(f"product {sku!r} not found")
    updated = catalog.update_reorder_settings(
        p.id, reorder_point=payload.reorder_point, reorder_qty=payload.reorder_qty,
    )
    return ProductRead(
        id=updated.id, sku=updated.sku, name=updated.name, description=updated.description,
        category_id=updated.category_id, supplier_id=updated.supplier_id,
        unit_cost_cents=updated.unit_cost_cents, unit_price_cents=updated.unit_price_cents,
        reorder_point=updated.reorder_point, reorder_qty=updated.reorder_qty,
        active=updated.active,
    )
