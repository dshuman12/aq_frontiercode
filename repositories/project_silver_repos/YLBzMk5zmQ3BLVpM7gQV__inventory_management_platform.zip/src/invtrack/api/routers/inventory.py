from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ...errors import NotFoundError, ValidationError
from ...repositories.inventory import InventoryRepository
from ...repositories.movements import MovementRepository
from ...repositories.products import ProductRepository
from ...services.inventory_service import InventoryService
from ..auth import Principal, require_operator, require_viewer
from ..deps import get_db, get_inventory_service
from ..pagination import Page, PaginationParams, pagination_params
from ..schemas import (
    InventoryLevelRead,
    StockAdjustRequest,
    StockMovementRead,
    StockReceiveRequest,
    StockReserveRequest,
    StockShipRequest,
)


router = APIRouter(prefix="/inventory", tags=["inventory"])


def _resolve_product_id(conn: sqlite3.Connection, sku: str) -> int:
    p = ProductRepository(conn).get_by_sku(sku)
    if p is None:
        raise NotFoundError(f"product {sku!r} not found")
    return p.id


@router.get("/levels/{sku}", response_model=list[InventoryLevelRead],
            dependencies=[Depends(require_viewer)])
def levels_for_sku(
    sku: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> list[InventoryLevelRead]:
    product_id = _resolve_product_id(conn, sku)
    levels = InventoryRepository(conn).levels_for_product(product_id)
    return [
        InventoryLevelRead(
            product_id=l.product_id, location_id=l.location_id,
            quantity=l.quantity, reserved=l.reserved, available=l.available,
        )
        for l in levels
    ]


@router.get("/movements", response_model=Page[StockMovementRead],
            dependencies=[Depends(require_viewer)])
def list_movements(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    sku: Optional[str] = Query(None),
    movement_type: Optional[str] = Query(None),
    location_id: Optional[int] = Query(None),
    start: Optional[str] = Query(None, description="ISO timestamp inclusive"),
    end: Optional[str] = Query(None, description="ISO timestamp exclusive"),
) -> Page[StockMovementRead]:
    where: list[str] = []
    params: list = []
    if sku:
        product_id = _resolve_product_id(conn, sku)
        where.append("product_id = ?")
        params.append(product_id)
    if movement_type:
        where.append("movement_type = ?")
        params.append(movement_type)
    if location_id is not None:
        where.append("location_id = ?")
        params.append(location_id)
    if start:
        where.append("created_at >= ?")
        params.append(start)
    if end:
        where.append("created_at < ?")
        params.append(end)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM stock_movements {where_clause}", params
    ).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT * FROM stock_movements {where_clause}
            ORDER BY created_at DESC, id DESC
            LIMIT ? OFFSET ?""",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()
    items = [
        StockMovementRead(
            id=r["id"], product_id=r["product_id"], location_id=r["location_id"],
            movement_type=r["movement_type"], quantity=r["quantity"],
            reference_type=r["reference_type"], reference_id=r["reference_id"],
            note=r["note"], created_at=r["created_at"], created_by=r["created_by"],
        )
        for r in rows
    ]
    return Page.build(items, total, pagination)


@router.post("/receive", response_model=InventoryLevelRead,
             dependencies=[Depends(require_operator)])
def receive_stock(
    payload: StockReceiveRequest,
    inv: InventoryService = Depends(get_inventory_service),
    principal: Principal = Depends(require_operator),
) -> InventoryLevelRead:
    product_id = _resolve_product_id(inv.conn, payload.sku)
    level = inv.receive(
        product_id, payload.location_id, payload.quantity,
        reference_type=payload.reference_type,
        reference_id=payload.reference_id,
        note=payload.note,
        created_by=principal.name,
    )
    return InventoryLevelRead(
        product_id=level.product_id, location_id=level.location_id,
        quantity=level.quantity, reserved=level.reserved, available=level.available,
    )


@router.post("/ship", response_model=InventoryLevelRead,
             dependencies=[Depends(require_operator)])
def ship_stock(
    payload: StockShipRequest,
    inv: InventoryService = Depends(get_inventory_service),
    principal: Principal = Depends(require_operator),
) -> InventoryLevelRead:
    product_id = _resolve_product_id(inv.conn, payload.sku)
    level = inv.ship(
        product_id, payload.location_id, payload.quantity,
        reference_type=payload.reference_type,
        reference_id=payload.reference_id,
        note=payload.note,
        created_by=principal.name,
    )
    return InventoryLevelRead(
        product_id=level.product_id, location_id=level.location_id,
        quantity=level.quantity, reserved=level.reserved, available=level.available,
    )


@router.post("/adjust", response_model=InventoryLevelRead,
             dependencies=[Depends(require_operator)])
def adjust_stock(
    payload: StockAdjustRequest,
    inv: InventoryService = Depends(get_inventory_service),
    principal: Principal = Depends(require_operator),
) -> InventoryLevelRead:
    if payload.delta == 0:
        raise ValidationError("delta must be non-zero")
    product_id = _resolve_product_id(inv.conn, payload.sku)
    level = inv.adjust(
        product_id, payload.location_id, payload.delta,
        note=payload.note, created_by=principal.name,
    )
    return InventoryLevelRead(
        product_id=level.product_id, location_id=level.location_id,
        quantity=level.quantity, reserved=level.reserved, available=level.available,
    )


@router.post("/reserve", response_model=InventoryLevelRead,
             dependencies=[Depends(require_operator)])
def reserve_stock(
    payload: StockReserveRequest,
    inv: InventoryService = Depends(get_inventory_service),
    principal: Principal = Depends(require_operator),
) -> InventoryLevelRead:
    product_id = _resolve_product_id(inv.conn, payload.sku)
    level = inv.reserve(
        product_id, payload.location_id, payload.quantity,
        reference_type=payload.reference_type,
        reference_id=payload.reference_id,
        created_by=principal.name,
    )
    return InventoryLevelRead(
        product_id=level.product_id, location_id=level.location_id,
        quantity=level.quantity, reserved=level.reserved, available=level.available,
    )
