from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends

from ...db.schema import current_version
from ..deps import get_db
from ..schemas import HealthRead
from ..settings import Settings, load_settings


router = APIRouter(tags=["health"])


@router.get("/health/live", response_model=HealthRead, summary="Liveness probe")
def live() -> dict:
    """Returns 200 as long as the process is running. Does not touch the db."""
    return {"status": "live", "schema_version": 0, "db_path": ""}


@router.get("/health/ready", response_model=HealthRead, summary="Readiness probe")
def ready(
    conn: sqlite3.Connection = Depends(get_db),
    settings: Settings = Depends(load_settings),
) -> dict:
    """Returns 200 once the db is reachable and migrations have been applied."""
    version = current_version(conn)
    return {
        "status": "ready" if version > 0 else "migrating",
        "schema_version": version,
        "db_path": str(settings.db_path),
    }
