from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends

from ...reporting.inventory_reports import low_stock, stock_summary, valuation
from ..auth import require_viewer
from ..deps import get_db
from ..schemas import LowStockRow, StockSummaryRow, ValuationRow, ValuationSummary


router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("/stock-summary", response_model=list[StockSummaryRow],
            dependencies=[Depends(require_viewer)])
def report_stock_summary(conn: sqlite3.Connection = Depends(get_db)) -> list[StockSummaryRow]:
    rows = stock_summary(conn)
    return [
        StockSummaryRow(
            sku=r.sku, name=r.name, total_quantity=r.total_quantity,
            total_reserved=r.total_reserved, total_available=r.total_available,
            reorder_point=r.reorder_point, reorder_qty=r.reorder_qty,
            needs_reorder=r.needs_reorder,
        )
        for r in rows
    ]


@router.get("/low-stock", response_model=list[LowStockRow],
            dependencies=[Depends(require_viewer)])
def report_low_stock(conn: sqlite3.Connection = Depends(get_db)) -> list[LowStockRow]:
    rows = low_stock(conn)
    return [
        LowStockRow(
            sku=r.sku, name=r.name, on_hand=r.on_hand, available=r.available,
            reorder_point=r.reorder_point,
            suggested_order_qty=r.suggested_order_qty,
            supplier_code=r.supplier_code,
        )
        for r in rows
    ]


@router.get("/valuation", response_model=ValuationSummary,
            dependencies=[Depends(require_viewer)])
def report_valuation(conn: sqlite3.Connection = Depends(get_db)) -> ValuationSummary:
    rows = valuation(conn)
    val_rows = [
        ValuationRow(
            sku=r.sku, name=r.name, total_quantity=r.total_quantity,
            unit_cost_cents=r.unit_cost_cents, value_cents=r.value_cents,
        )
        for r in rows
    ]
    total = sum(r.value_cents for r in val_rows)
    return ValuationSummary(rows=val_rows, total_value_cents=total)
