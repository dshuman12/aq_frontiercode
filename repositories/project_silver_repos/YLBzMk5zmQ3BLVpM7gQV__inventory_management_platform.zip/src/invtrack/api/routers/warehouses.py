from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query, status

from ...errors import NotFoundError
from ...repositories.locations import StorageLocationRepository
from ...repositories.warehouses import WarehouseRepository
from ...services.catalog_service import CatalogService
from ..auth import require_admin, require_operator, require_viewer
from ..deps import get_catalog_service, get_db
from ..pagination import Page, PaginationParams, pagination_params
from ..schemas import (
    StorageLocationCreate,
    StorageLocationRead,
    WarehouseCreate,
    WarehouseRead,
)


router = APIRouter(prefix="/warehouses", tags=["warehouses"])


@router.get("", response_model=Page[WarehouseRead],
            dependencies=[Depends(require_viewer)])
def list_warehouses(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    active: Optional[bool] = Query(None),
) -> Page[WarehouseRead]:
    where = "WHERE active = 1" if active else ""
    if active is False:
        where = "WHERE active = 0"
    total = conn.execute(f"SELECT COUNT(*) AS c FROM warehouses {where}").fetchone()["c"]
    rows = conn.execute(
        f"SELECT * FROM warehouses {where} ORDER BY code LIMIT ? OFFSET ?",
        (pagination.limit, pagination.offset),
    ).fetchall()
    items = [
        WarehouseRead(id=r["id"], code=r["code"], name=r["name"],
                      address=r["address"], active=bool(r["active"]))
        for r in rows
    ]
    return Page.build(items, total, pagination)


@router.get("/{code}", response_model=WarehouseRead,
            dependencies=[Depends(require_viewer)])
def get_warehouse(
    code: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> WarehouseRead:
    w = WarehouseRepository(conn).get_by_code(code)
    if w is None:
        raise NotFoundError(f"warehouse {code!r} not found")
    return WarehouseRead(id=w.id, code=w.code, name=w.name,
                         address=w.address, active=w.active)


@router.post("", response_model=WarehouseRead, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_admin)])
def create_warehouse(
    payload: WarehouseCreate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> WarehouseRead:
    w = catalog.create_warehouse(payload.code, payload.name, payload.address)
    return WarehouseRead(id=w.id, code=w.code, name=w.name,
                         address=w.address, active=w.active)


@router.get("/{code}/locations", response_model=list[StorageLocationRead],
            dependencies=[Depends(require_viewer)])
def list_locations(
    code: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> list[StorageLocationRead]:
    w = WarehouseRepository(conn).get_by_code(code)
    if w is None:
        raise NotFoundError(f"warehouse {code!r} not found")
    locations = StorageLocationRepository(conn).list_for_warehouse(w.id)
    return [
        StorageLocationRead(id=l.id, warehouse_id=l.warehouse_id, code=l.code,
                            description=l.description, active=l.active)
        for l in locations
    ]


@router.post("/{code}/locations", response_model=StorageLocationRead,
             status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_operator)])
def create_location(
    code: str,
    payload: StorageLocationCreate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> StorageLocationRead:
    w = catalog.warehouses.get_by_code(code)
    if w is None:
        raise NotFoundError(f"warehouse {code!r} not found")
    loc = catalog.create_location(w.id, payload.code, payload.description)
    return StorageLocationRead(id=loc.id, warehouse_id=loc.warehouse_id,
                               code=loc.code, description=loc.description,
                               active=loc.active)
