from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ...domain import POStatus
from ...errors import NotFoundError
from ...repositories.products import ProductRepository
from ...repositories.purchase_orders import PurchaseOrderRepository
from ...services.purchase_service import PurchaseOrderService
from ..auth import Principal, require_operator, require_viewer
from ..deps import get_db, get_purchase_service
from ..pagination import Page, PaginationParams, pagination_params
from ..schemas import (
    PurchaseOrderCreate,
    PurchaseOrderLineRead,
    PurchaseOrderRead,
    PurchaseOrderReceiveRequest,
)


router = APIRouter(prefix="/purchase-orders", tags=["purchase-orders"])


def _to_read(po) -> PurchaseOrderRead:
    return PurchaseOrderRead(
        id=po.id, po_number=po.po_number, supplier_id=po.supplier_id,
        warehouse_id=po.warehouse_id, status=po.status.value,
        expected_at=po.expected_at, submitted_at=po.submitted_at,
        received_at=po.received_at, notes=po.notes,
        lines=[
            PurchaseOrderLineRead(
                id=l.id, product_id=l.product_id,
                quantity_ordered=l.quantity_ordered,
                quantity_received=l.quantity_received,
                unit_cost_cents=l.unit_cost_cents,
            )
            for l in po.lines
        ],
    )


@router.get("", response_model=Page[PurchaseOrderRead],
            dependencies=[Depends(require_viewer)])
def list_pos(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    status_filter: Optional[str] = Query(None, alias="status"),
) -> Page[PurchaseOrderRead]:
    where = ""
    params: list = []
    if status_filter:
        try:
            POStatus(status_filter)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"unknown status {status_filter!r}")
        where = "WHERE status = ?"
        params.append(status_filter)
    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM purchase_orders {where}", params
    ).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT id FROM purchase_orders {where}
            ORDER BY created_at DESC LIMIT ? OFFSET ?""",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()
    repo = PurchaseOrderRepository(conn)
    items = []
    for r in rows:
        po = repo.get(r["id"])
        if po:
            items.append(_to_read(po))
    return Page.build(items, total, pagination)


@router.get("/{po_id}", response_model=PurchaseOrderRead,
            dependencies=[Depends(require_viewer)])
def get_po(po_id: int, conn: sqlite3.Connection = Depends(get_db)) -> PurchaseOrderRead:
    po = PurchaseOrderRepository(conn).get(po_id)
    if po is None:
        raise NotFoundError(f"PO {po_id} not found")
    return _to_read(po)


@router.post("", response_model=PurchaseOrderRead, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_operator)])
def create_po(
    payload: PurchaseOrderCreate,
    pos: PurchaseOrderService = Depends(get_purchase_service),
    principal: Principal = Depends(require_operator),
) -> PurchaseOrderRead:
    sup = pos.suppliers.get_by_code(payload.supplier_code)
    if sup is None:
        raise NotFoundError(f"supplier {payload.supplier_code!r} not found")
    wh = pos.warehouses.get_by_code(payload.warehouse_code)
    if wh is None:
        raise NotFoundError(f"warehouse {payload.warehouse_code!r} not found")
    products = ProductRepository(pos.conn)
    line_tuples: list[tuple[int, int, int]] = []
    for line in payload.lines:
        p = products.get_by_sku(line.sku)
        if p is None:
            raise NotFoundError(f"product {line.sku!r} not found")
        line_tuples.append((p.id, line.quantity, line.unit_cost_cents))
    po = pos.create_draft(
        payload.po_number, sup.id, wh.id, line_tuples,
        expected_at=payload.expected_at,
        notes=payload.notes,
        created_by=principal.name,
    )
    return _to_read(po)


@router.post("/{po_id}/submit", response_model=PurchaseOrderRead,
             dependencies=[Depends(require_operator)])
def submit_po(
    po_id: int,
    pos: PurchaseOrderService = Depends(get_purchase_service),
) -> PurchaseOrderRead:
    return _to_read(pos.submit(po_id))


@router.post("/{po_id}/receive", response_model=PurchaseOrderRead,
             dependencies=[Depends(require_operator)])
def receive_po(
    po_id: int,
    payload: PurchaseOrderReceiveRequest,
    pos: PurchaseOrderService = Depends(get_purchase_service),
    principal: Principal = Depends(require_operator),
) -> PurchaseOrderRead:
    receipts = [(r.line_id, r.quantity, r.location_id) for r in payload.receipts]
    return _to_read(pos.receive_lines(po_id, receipts, received_by=principal.name))


@router.post("/{po_id}/cancel", response_model=PurchaseOrderRead,
             dependencies=[Depends(require_operator)])
def cancel_po(
    po_id: int,
    pos: PurchaseOrderService = Depends(get_purchase_service),
) -> PurchaseOrderRead:
    return _to_read(pos.cancel(po_id))
