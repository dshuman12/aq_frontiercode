from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ...domain import CustomerOrderStatus
from ...errors import NotFoundError
from ...repositories.customer_orders import CustomerOrderRepository
from ...repositories.products import ProductRepository
from ...services.order_service import CustomerOrderService
from ..auth import Principal, require_operator, require_viewer
from ..deps import get_customer_order_service, get_db
from ..pagination import Page, PaginationParams, pagination_params
from ..schemas import (
    CustomerOrderCreate,
    CustomerOrderLineRead,
    CustomerOrderPickRequest,
    CustomerOrderRead,
)


router = APIRouter(prefix="/customer-orders", tags=["customer-orders"])


def _to_read(order) -> CustomerOrderRead:
    return CustomerOrderRead(
        id=order.id, order_number=order.order_number,
        customer_name=order.customer_name, customer_email=order.customer_email,
        warehouse_id=order.warehouse_id, status=order.status.value,
        confirmed_at=order.confirmed_at, shipped_at=order.shipped_at,
        cancelled_at=order.cancelled_at, notes=order.notes,
        lines=[
            CustomerOrderLineRead(
                id=l.id, product_id=l.product_id, quantity=l.quantity,
                quantity_picked=l.quantity_picked,
                quantity_shipped=l.quantity_shipped,
                unit_price_cents=l.unit_price_cents,
            )
            for l in order.lines
        ],
    )


@router.get("", response_model=Page[CustomerOrderRead],
            dependencies=[Depends(require_viewer)])
def list_orders(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    status_filter: Optional[str] = Query(None, alias="status"),
    customer: Optional[str] = Query(None),
) -> Page[CustomerOrderRead]:
    where: list[str] = []
    params: list = []
    if status_filter:
        try:
            CustomerOrderStatus(status_filter)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"unknown status {status_filter!r}")
        where.append("status = ?")
        params.append(status_filter)
    if customer:
        where.append("customer_name LIKE ?")
        params.append(f"%{customer}%")
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM customer_orders {where_clause}", params
    ).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT id FROM customer_orders {where_clause}
            ORDER BY created_at DESC LIMIT ? OFFSET ?""",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()
    repo = CustomerOrderRepository(conn)
    items = [_to_read(repo.get(r["id"])) for r in rows if repo.get(r["id"])]
    return Page.build(items, total, pagination)


@router.get("/{order_id}", response_model=CustomerOrderRead,
            dependencies=[Depends(require_viewer)])
def get_order(order_id: int, conn: sqlite3.Connection = Depends(get_db)) -> CustomerOrderRead:
    order = CustomerOrderRepository(conn).get(order_id)
    if order is None:
        raise NotFoundError(f"order {order_id} not found")
    return _to_read(order)


@router.post("", response_model=CustomerOrderRead, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_operator)])
def create_order(
    payload: CustomerOrderCreate,
    orders: CustomerOrderService = Depends(get_customer_order_service),
    principal: Principal = Depends(require_operator),
) -> CustomerOrderRead:
    wh = orders.warehouses.get_by_code(payload.warehouse_code)
    if wh is None:
        raise NotFoundError(f"warehouse {payload.warehouse_code!r} not found")
    products = ProductRepository(orders.conn)
    line_tuples: list[tuple[int, int, int]] = []
    for line in payload.lines:
        p = products.get_by_sku(line.sku)
        if p is None:
            raise NotFoundError(f"product {line.sku!r} not found")
        line_tuples.append((p.id, line.quantity, line.unit_price_cents))
    order = orders.create_draft(
        payload.order_number, payload.customer_name, wh.id, line_tuples,
        customer_email=payload.customer_email, notes=payload.notes,
        created_by=principal.name,
    )
    return _to_read(order)


@router.post("/{order_id}/confirm", response_model=CustomerOrderRead,
             dependencies=[Depends(require_operator)])
def confirm_order(
    order_id: int,
    orders: CustomerOrderService = Depends(get_customer_order_service),
) -> CustomerOrderRead:
    return _to_read(orders.confirm(order_id))


@router.post("/{order_id}/pick", response_model=CustomerOrderRead,
             dependencies=[Depends(require_operator)])
def pick_order(
    order_id: int,
    payload: CustomerOrderPickRequest,
    orders: CustomerOrderService = Depends(get_customer_order_service),
) -> CustomerOrderRead:
    # The service-level pick takes (line_id, qty); location is captured at
    # reservation time. We accept location_id in the API for symmetry with
    # the PO receipt body but ignore it here.
    picks = [(p.line_id, p.quantity) for p in payload.picks]
    return _to_read(orders.pick(order_id, picks))


@router.post("/{order_id}/ship", response_model=CustomerOrderRead,
             dependencies=[Depends(require_operator)])
def ship_order(
    order_id: int,
    orders: CustomerOrderService = Depends(get_customer_order_service),
    principal: Principal = Depends(require_operator),
) -> CustomerOrderRead:
    return _to_read(orders.ship(order_id, shipped_by=principal.name))


@router.post("/{order_id}/cancel", response_model=CustomerOrderRead,
             dependencies=[Depends(require_operator)])
def cancel_order(
    order_id: int,
    orders: CustomerOrderService = Depends(get_customer_order_service),
) -> CustomerOrderRead:
    return _to_read(orders.cancel(order_id))
