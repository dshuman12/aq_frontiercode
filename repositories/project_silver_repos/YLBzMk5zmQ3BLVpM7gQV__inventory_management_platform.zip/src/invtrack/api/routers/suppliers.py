from __future__ import annotations

import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ...errors import NotFoundError
from ...repositories.suppliers import SupplierRepository
from ...services.catalog_service import CatalogService
from ..auth import require_admin, require_operator, require_viewer
from ..deps import get_catalog_service, get_db
from ..pagination import Page, PaginationParams, SortParams, pagination_params, sort_params
from ..schemas import SupplierCreate, SupplierRead, SupplierUpdate


router = APIRouter(prefix="/suppliers", tags=["suppliers"])


_SORT_COLUMNS = {"code", "name", "lead_time_days", "created_at"}


@router.get("", response_model=Page[SupplierRead],
            dependencies=[Depends(require_viewer)])
def list_suppliers(
    conn: sqlite3.Connection = Depends(get_db),
    pagination: PaginationParams = Depends(pagination_params),
    sort: SortParams = Depends(sort_params),
    q: Optional[str] = Query(None),
    active: Optional[bool] = Query(None),
) -> Page[SupplierRead]:
    where: list[str] = []
    params: list = []
    if q:
        where.append("(code LIKE ? OR name LIKE ?)")
        like = f"%{q}%"
        params.extend([like, like])
    if active is not None:
        where.append("active = ?")
        params.append(1 if active else 0)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(
        f"SELECT COUNT(*) AS c FROM suppliers {where_clause}", params
    ).fetchone()["c"]
    sort_pair = sort.parse(_SORT_COLUMNS)
    order_clause = "ORDER BY name ASC"
    if sort_pair:
        col, direction = sort_pair
        order_clause = f"ORDER BY {col} {direction}"
    rows = conn.execute(
        f"SELECT * FROM suppliers {where_clause} {order_clause} LIMIT ? OFFSET ?",
        [*params, pagination.limit, pagination.offset],
    ).fetchall()
    items = [
        SupplierRead(
            id=r["id"], code=r["code"], name=r["name"],
            contact_email=r["contact_email"], lead_time_days=r["lead_time_days"],
            active=bool(r["active"]),
        )
        for r in rows
    ]
    return Page.build(items, total, pagination)


@router.get("/{code}", response_model=SupplierRead,
            dependencies=[Depends(require_viewer)])
def get_supplier(
    code: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> SupplierRead:
    s = SupplierRepository(conn).get_by_code(code)
    if s is None:
        raise NotFoundError(f"supplier {code!r} not found")
    return SupplierRead(
        id=s.id, code=s.code, name=s.name, contact_email=s.contact_email,
        lead_time_days=s.lead_time_days, active=s.active,
    )


@router.post("", response_model=SupplierRead, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_operator)])
def create_supplier(
    payload: SupplierCreate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> SupplierRead:
    s = catalog.create_supplier(
        code=payload.code, name=payload.name,
        contact_email=payload.contact_email,
        lead_time_days=payload.lead_time_days,
    )
    return SupplierRead(
        id=s.id, code=s.code, name=s.name, contact_email=s.contact_email,
        lead_time_days=s.lead_time_days, active=s.active,
    )


@router.put("/{code}", response_model=SupplierRead,
            dependencies=[Depends(require_admin)])
def update_supplier(
    code: str,
    payload: SupplierUpdate,
    catalog: CatalogService = Depends(get_catalog_service),
) -> SupplierRead:
    s = catalog.suppliers.get_by_code(code)
    if s is None:
        raise NotFoundError(f"supplier {code!r} not found")
    from dataclasses import replace
    updated = replace(
        s,
        name=payload.name if payload.name is not None else s.name,
        contact_email=payload.contact_email if payload.contact_email is not None else s.contact_email,
        lead_time_days=payload.lead_time_days if payload.lead_time_days is not None else s.lead_time_days,
        active=payload.active if payload.active is not None else s.active,
    )
    catalog.suppliers.update(updated)
    return SupplierRead(
        id=updated.id, code=updated.code, name=updated.name,
        contact_email=updated.contact_email,
        lead_time_days=updated.lead_time_days, active=updated.active,
    )
