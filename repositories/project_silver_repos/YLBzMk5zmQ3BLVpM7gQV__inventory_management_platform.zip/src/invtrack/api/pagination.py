"""Reusable request shapes: pagination, sorting, generic page wrapper."""
from __future__ import annotations

from typing import Generic, Optional, TypeVar

from fastapi import Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from .settings import Settings, load_settings


T = TypeVar("T")


class PaginationParams(BaseModel):
    page: int = Field(1, ge=1, description="1-indexed page number")
    page_size: int = Field(50, ge=1, le=500, description="Items per page")

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        return self.page_size


def pagination_params(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
) -> PaginationParams:
    return PaginationParams(page=page, page_size=page_size)


class SortParams(BaseModel):
    sort: Optional[str] = None  # e.g. "name", "-created_at"

    def parse(self, allowed: set[str]) -> tuple[str, str] | None:
        """Returns (column, direction) or None. direction is 'ASC' or 'DESC'."""
        if not self.sort:
            return None
        raw = self.sort
        direction = "ASC"
        if raw.startswith("-"):
            direction = "DESC"
            raw = raw[1:]
        elif raw.startswith("+"):
            raw = raw[1:]
        if raw not in allowed:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"cannot sort by {raw!r}; allowed: {sorted(allowed)}",
            )
        return raw, direction


def sort_params(sort: Optional[str] = Query(None)) -> SortParams:
    return SortParams(sort=sort)


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int

    @property
    def total_pages(self) -> int:
        if self.page_size == 0:
            return 0
        return (self.total + self.page_size - 1) // self.page_size

    @classmethod
    def build(cls, items: list[T], total: int, params: PaginationParams) -> "Page[T]":
        return cls(items=items, total=total, page=params.page, page_size=params.page_size)
