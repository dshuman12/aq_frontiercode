"""FastAPI dependency providers.

Each request gets its own SQLite connection via ``get_db``. The connection
is closed after the response is built. Services are constructed per
request from the connection, mirroring how the CLI works.
"""
from __future__ import annotations

import sqlite3
from typing import Iterator

from fastapi import Depends

from ..db import connect
from ..db.schema import migrate
from ..services.catalog_service import CatalogService
from ..services.inventory_service import InventoryService
from ..services.order_service import CustomerOrderService
from ..services.purchase_service import PurchaseOrderService
from .settings import Settings, load_settings


def get_settings() -> Settings:
    return load_settings()


def get_db(settings: Settings = Depends(get_settings)) -> Iterator[sqlite3.Connection]:
    """Open a per-request connection. Schema migrations are idempotent so
    we run them lazily here too - useful when the API is the first thing
    to touch a fresh db file (e.g. in compose)."""
    conn = connect(settings.db_path)
    try:
        migrate(conn)
        yield conn
    finally:
        conn.close()


def get_catalog_service(conn: sqlite3.Connection = Depends(get_db)) -> CatalogService:
    return CatalogService(conn)


def get_inventory_service(conn: sqlite3.Connection = Depends(get_db)) -> InventoryService:
    return InventoryService(conn)


def get_purchase_service(conn: sqlite3.Connection = Depends(get_db)) -> PurchaseOrderService:
    return PurchaseOrderService(conn)


def get_customer_order_service(
    conn: sqlite3.Connection = Depends(get_db),
) -> CustomerOrderService:
    return CustomerOrderService(conn)
