"""Map domain errors to HTTP responses.

Service-layer code raises InvtrackError subclasses without knowing about
HTTP. This module translates them into the right status codes so router
code stays clean.
"""
from __future__ import annotations

import logging

from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError

from ..errors import (
    ConflictError,
    InsufficientStockError,
    InvtrackError,
    NotFoundError,
    ValidationError,
)


log = logging.getLogger("invtrack.api.errors")


def _problem(title: str, status_code: int, detail: str | None,
             type_: str = "about:blank") -> JSONResponse:
    body = {
        "type": type_,
        "title": title,
        "status": status_code,
        "detail": detail,
    }
    return JSONResponse(body, status_code=status_code)


def install_handlers(app) -> None:
    @app.exception_handler(NotFoundError)
    def _not_found(_request: Request, exc: NotFoundError) -> JSONResponse:
        return _problem("Not Found", status.HTTP_404_NOT_FOUND, str(exc))

    @app.exception_handler(ValidationError)
    def _validation(_request: Request, exc: ValidationError) -> JSONResponse:
        return _problem("Validation Error", status.HTTP_422_UNPROCESSABLE_ENTITY,
                        str(exc), type_="urn:invtrack:validation")

    @app.exception_handler(InsufficientStockError)
    def _insufficient(_request: Request, exc: InsufficientStockError) -> JSONResponse:
        body = {
            "type": "urn:invtrack:insufficient-stock",
            "title": "Insufficient stock",
            "status": status.HTTP_409_CONFLICT,
            "detail": str(exc),
            "product_id": exc.product_id,
            "requested": exc.requested,
            "available": exc.available,
        }
        return JSONResponse(body, status_code=status.HTTP_409_CONFLICT)

    @app.exception_handler(ConflictError)
    def _conflict(_request: Request, exc: ConflictError) -> JSONResponse:
        return _problem("Conflict", status.HTTP_409_CONFLICT, str(exc),
                        type_="urn:invtrack:conflict")

    @app.exception_handler(InvtrackError)
    def _invtrack_generic(_request: Request, exc: InvtrackError) -> JSONResponse:
        return _problem("Bad Request", status.HTTP_400_BAD_REQUEST, str(exc))

    @app.exception_handler(RequestValidationError)
    def _request_validation(_request: Request, exc: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            {
                "type": "urn:invtrack:request-validation",
                "title": "Request validation failed",
                "status": status.HTTP_422_UNPROCESSABLE_ENTITY,
                "errors": exc.errors(),
            },
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        )
