"""HTTP API layer.

Wraps the existing services in a FastAPI app. The API is a delivery
layer only - no business logic lives here. Endpoints obtain a service
via the dependency-injection helpers in ``deps.py`` and call into them
the same way the CLI does.
"""
