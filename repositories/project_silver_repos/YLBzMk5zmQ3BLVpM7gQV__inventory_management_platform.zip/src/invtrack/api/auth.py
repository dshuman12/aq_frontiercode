"""API authentication and role-based access control.

Two auth mechanisms are supported:

- API keys: clients send ``Authorization: ApiKey <key>``. Keys are loaded
  from a JSON file at startup (path from settings). Each key has a
  principal name and a role.
- JWT: clients send ``Authorization: Bearer <token>``. Tokens are signed
  with the secret in ``INVTRACK_JWT_SECRET`` and carry ``sub`` and
  ``role`` claims. Used for short-lived sessions issued by an external
  identity provider; the API itself does not mint tokens.

Roles form a simple ladder: viewer < operator < admin. Endpoints declare
the minimum role they require via a Depends() guard.
"""
from __future__ import annotations

import hmac
import json
import os
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional

import jwt  # type: ignore
from fastapi import Depends, Header, HTTPException, status

from .settings import Settings, load_settings


class Role(str, Enum):
    VIEWER = "viewer"
    OPERATOR = "operator"
    ADMIN = "admin"


_RANK = {Role.VIEWER: 0, Role.OPERATOR: 1, Role.ADMIN: 2}


@dataclass(frozen=True)
class Principal:
    name: str
    role: Role
    auth_method: str  # "api_key" | "jwt" | "anonymous"

    def has_at_least(self, role: Role) -> bool:
        return _RANK[self.role] >= _RANK[role]


_ANONYMOUS_ADMIN = Principal(name="anonymous", role=Role.ADMIN, auth_method="anonymous")


class APIKeyStore:
    """Loads API keys from a JSON file shaped like::

        {
          "keys": [
            {"name": "ops-cli", "key": "...", "role": "operator"},
            ...
          ]
        }

    Reloads on demand; in production the file is mounted read-only and
    rotated by ops.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self._loaded_at: float = 0
        self._by_key: dict[str, Principal] = {}

    def reload(self) -> None:
        if not self.path.exists():
            self._by_key = {}
            self._loaded_at = time.time()
            return
        data = json.loads(self.path.read_text())
        new: dict[str, Principal] = {}
        for entry in data.get("keys", []):
            new[entry["key"]] = Principal(
                name=entry["name"],
                role=Role(entry.get("role", "viewer")),
                auth_method="api_key",
            )
        self._by_key = new
        self._loaded_at = time.time()

    def lookup(self, key: str) -> Optional[Principal]:
        if not self._by_key:
            self.reload()
        # Constant-time match against the set of valid keys
        for stored, principal in self._by_key.items():
            if hmac.compare_digest(stored, key):
                return principal
        return None


_store: Optional[APIKeyStore] = None


def get_settings() -> Settings:
    return load_settings()


def get_api_key_store(settings: Settings = Depends(get_settings)) -> APIKeyStore:
    global _store
    if _store is None or _store.path != settings.api_keys_path:
        _store = APIKeyStore(settings.api_keys_path)
    return _store


def _decode_jwt(token: str) -> Optional[Principal]:
    secret = os.environ.get("INVTRACK_JWT_SECRET")
    if not secret:
        return None
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None
    sub = payload.get("sub")
    role = payload.get("role")
    if not sub or not role:
        return None
    try:
        return Principal(name=sub, role=Role(role), auth_method="jwt")
    except ValueError:
        return None


def get_principal(
    settings: Settings = Depends(get_settings),
    keys: APIKeyStore = Depends(get_api_key_store),
    authorization: Optional[str] = Header(None),
) -> Principal:
    if settings.auth_disabled:
        return _ANONYMOUS_ADMIN
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="missing Authorization header",
            headers={"WWW-Authenticate": 'ApiKey realm="invtrack"'},
        )
    parts = authorization.split(" ", 1)
    if len(parts) != 2:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="malformed Authorization header",
        )
    scheme, value = parts[0], parts[1].strip()
    scheme_l = scheme.lower()
    if scheme_l == "apikey":
        principal = keys.lookup(value)
        if principal is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="invalid api key",
            )
        return principal
    if scheme_l == "bearer":
        principal = _decode_jwt(value)
        if principal is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="invalid bearer token",
            )
        return principal
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=f"unsupported auth scheme: {scheme}",
    )


def require_role(min_role: Role):
    """Returns a dependency callable that enforces a minimum role."""
    def _guard(principal: Principal = Depends(get_principal)) -> Principal:
        if not principal.has_at_least(min_role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"requires {min_role.value} role; you have {principal.role.value}",
            )
        return principal
    return _guard


# Convenience aliases used by routers
require_viewer = require_role(Role.VIEWER)
require_operator = require_role(Role.OPERATOR)
require_admin = require_role(Role.ADMIN)
