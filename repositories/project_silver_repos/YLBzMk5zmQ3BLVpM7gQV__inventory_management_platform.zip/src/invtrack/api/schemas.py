"""Request and response schemas.

Conventions:
- ``*Read`` schemas mirror domain dataclasses. They include the database
  id and any timestamps the client cares about.
- ``*Create`` schemas describe what the client must POST.
- ``*Update`` schemas list mutable fields. We don't use PATCH-style
  partial updates - operators send a full replacement.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


SKU_PATTERN = r"^[A-Z0-9][A-Z0-9\-_]{1,31}$"
CODE_PATTERN = r"^[A-Z0-9][A-Z0-9\-_]{0,15}$"


# ---------- Categories ----------

class CategoryRead(BaseModel):
    id: int
    name: str
    parent_id: Optional[int] = None


class CategoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    parent_id: Optional[int] = None


# ---------- Suppliers ----------

class SupplierRead(BaseModel):
    id: int
    code: str
    name: str
    contact_email: Optional[str] = None
    lead_time_days: int
    active: bool = True


class SupplierCreate(BaseModel):
    code: str = Field(..., pattern=CODE_PATTERN)
    name: str = Field(..., min_length=1, max_length=200)
    contact_email: Optional[str] = None
    lead_time_days: int = Field(7, ge=0, le=365)


class SupplierUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    contact_email: Optional[str] = None
    lead_time_days: Optional[int] = Field(None, ge=0, le=365)
    active: Optional[bool] = None


# ---------- Products ----------

class ProductRead(BaseModel):
    id: int
    sku: str
    name: str
    description: Optional[str] = None
    category_id: Optional[int] = None
    supplier_id: Optional[int] = None
    unit_cost_cents: int
    unit_price_cents: int
    reorder_point: int
    reorder_qty: int
    active: bool = True


class ProductCreate(BaseModel):
    sku: str = Field(..., pattern=SKU_PATTERN)
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    category_id: Optional[int] = None
    supplier_id: Optional[int] = None
    unit_cost_cents: int = Field(0, ge=0)
    unit_price_cents: int = Field(0, ge=0)
    reorder_point: int = Field(0, ge=0)
    reorder_qty: int = Field(0, ge=0)


class ReorderUpdate(BaseModel):
    reorder_point: int = Field(..., ge=0)
    reorder_qty: int = Field(..., ge=0)


# ---------- Warehouses & locations ----------

class WarehouseRead(BaseModel):
    id: int
    code: str
    name: str
    address: Optional[str] = None
    active: bool = True


class WarehouseCreate(BaseModel):
    code: str = Field(..., pattern=CODE_PATTERN)
    name: str = Field(..., min_length=1, max_length=200)
    address: Optional[str] = None


class StorageLocationRead(BaseModel):
    id: int
    warehouse_id: int
    code: str
    description: Optional[str] = None
    active: bool = True


class StorageLocationCreate(BaseModel):
    code: str = Field(..., min_length=1, max_length=32)
    description: Optional[str] = None


# ---------- Inventory & movements ----------

class InventoryLevelRead(BaseModel):
    product_id: int
    location_id: int
    quantity: int
    reserved: int
    available: int  # derived


class StockMovementRead(BaseModel):
    id: int
    product_id: int
    location_id: int
    movement_type: str
    quantity: int
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None
    note: Optional[str] = None
    created_at: Optional[str] = None
    created_by: Optional[str] = None


class StockReceiveRequest(BaseModel):
    sku: str
    location_id: int
    quantity: int = Field(..., gt=0)
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None
    note: Optional[str] = None


class StockShipRequest(BaseModel):
    sku: str
    location_id: int
    quantity: int = Field(..., gt=0)
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None
    note: Optional[str] = None


class StockAdjustRequest(BaseModel):
    sku: str
    location_id: int
    delta: int  # signed, must be non-zero (validated server-side)
    note: str = Field(..., min_length=1)


class StockReserveRequest(BaseModel):
    sku: str
    location_id: int
    quantity: int = Field(..., gt=0)
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None


# ---------- Purchase orders ----------

class PurchaseOrderLineRead(BaseModel):
    id: int
    product_id: int
    quantity_ordered: int
    quantity_received: int
    unit_cost_cents: int


class PurchaseOrderRead(BaseModel):
    id: int
    po_number: str
    supplier_id: int
    warehouse_id: int
    status: str
    expected_at: Optional[str] = None
    submitted_at: Optional[str] = None
    received_at: Optional[str] = None
    notes: Optional[str] = None
    lines: list[PurchaseOrderLineRead] = Field(default_factory=list)


class PurchaseOrderLineCreate(BaseModel):
    sku: str
    quantity: int = Field(..., gt=0)
    unit_cost_cents: int = Field(..., ge=0)


class PurchaseOrderCreate(BaseModel):
    po_number: str = Field(..., min_length=1, max_length=64)
    supplier_code: str = Field(..., pattern=CODE_PATTERN)
    warehouse_code: str = Field(..., pattern=CODE_PATTERN)
    expected_at: Optional[str] = None
    notes: Optional[str] = None
    lines: list[PurchaseOrderLineCreate] = Field(..., min_length=1)


class PurchaseOrderReceiptLine(BaseModel):
    line_id: int
    quantity: int = Field(..., gt=0)
    location_id: int


class PurchaseOrderReceiveRequest(BaseModel):
    receipts: list[PurchaseOrderReceiptLine] = Field(..., min_length=1)


# ---------- Customer orders ----------

class CustomerOrderLineRead(BaseModel):
    id: int
    product_id: int
    quantity: int
    quantity_picked: int
    quantity_shipped: int
    unit_price_cents: int


class CustomerOrderRead(BaseModel):
    id: int
    order_number: str
    customer_name: str
    customer_email: Optional[str] = None
    warehouse_id: int
    status: str
    confirmed_at: Optional[str] = None
    shipped_at: Optional[str] = None
    cancelled_at: Optional[str] = None
    notes: Optional[str] = None
    lines: list[CustomerOrderLineRead] = Field(default_factory=list)


class CustomerOrderLineCreate(BaseModel):
    sku: str
    quantity: int = Field(..., gt=0)
    unit_price_cents: int = Field(..., ge=0)


class CustomerOrderCreate(BaseModel):
    order_number: str = Field(..., min_length=1, max_length=64)
    customer_name: str = Field(..., min_length=1, max_length=200)
    customer_email: Optional[str] = None
    warehouse_code: str = Field(..., pattern=CODE_PATTERN)
    notes: Optional[str] = None
    lines: list[CustomerOrderLineCreate] = Field(..., min_length=1)


class CustomerOrderPickLine(BaseModel):
    line_id: int
    quantity: int = Field(..., gt=0)
    location_id: int


class CustomerOrderPickRequest(BaseModel):
    picks: list[CustomerOrderPickLine] = Field(..., min_length=1)


# ---------- Alerts ----------

class AlertRead(BaseModel):
    id: int
    alert_type: str
    severity: str
    subject_type: str
    subject_id: int
    message: str
    raised_at: str
    resolved_at: Optional[str] = None


# ---------- Reports ----------

class StockSummaryRow(BaseModel):
    sku: str
    name: str
    total_quantity: int
    total_reserved: int
    total_available: int
    reorder_point: int
    reorder_qty: int
    needs_reorder: bool


class LowStockRow(BaseModel):
    sku: str
    name: str
    on_hand: int
    available: int
    reorder_point: int
    suggested_order_qty: int
    supplier_code: Optional[str] = None


class ValuationRow(BaseModel):
    sku: str
    name: str
    total_quantity: int
    unit_cost_cents: int
    value_cents: int


class ValuationSummary(BaseModel):
    rows: list[ValuationRow]
    total_value_cents: int


# ---------- Common ----------

class HealthRead(BaseModel):
    status: str
    schema_version: int
    db_path: str


class ProblemDetail(BaseModel):
    """RFC 7807-ish error envelope used uniformly across the API."""
    type: str = "about:blank"
    title: str
    status: int
    detail: Optional[str] = None
    instance: Optional[str] = None
