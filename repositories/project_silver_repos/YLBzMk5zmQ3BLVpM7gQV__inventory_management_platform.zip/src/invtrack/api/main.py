"""FastAPI app factory.

Use ``create_app()`` to construct a fully-wired application. We don't
keep a module-level ``app`` because tests want to construct the app
with overridden settings (different db, auth disabled, etc.).
"""
from __future__ import annotations

import logging
import time

from fastapi import FastAPI, Request

from .errors import install_handlers
from .logging import configure_logging, request_id
from .routers import (
    alerts,
    customer_orders,
    health,
    inventory,
    products,
    purchase_orders,
    reports,
    suppliers,
    warehouses,
)
from .settings import load_settings


_TAGS_METADATA = [
    {"name": "health", "description": "Liveness/readiness probes"},
    {"name": "products", "description": "Product master data"},
    {"name": "suppliers", "description": "Supplier records"},
    {"name": "warehouses", "description": "Warehouses and storage locations"},
    {"name": "inventory", "description": "Stock movements and reservations"},
    {"name": "purchase-orders", "description": "PO lifecycle"},
    {"name": "customer-orders", "description": "Customer order lifecycle"},
    {"name": "alerts", "description": "Operational alerts"},
    {"name": "reports", "description": "Stock summary, low-stock, valuation"},
]


def create_app() -> FastAPI:
    settings = load_settings()
    configure_logging(level=settings.log_level, format=settings.log_format)
    log = logging.getLogger("invtrack.api")

    app = FastAPI(
        title="invtrack API",
        version="0.2.0",
        description=(
            "HTTP API for invtrack. "
            "Wraps the service layer and exposes inventory, order, and "
            "reporting operations."
        ),
        openapi_tags=_TAGS_METADATA,
    )

    install_handlers(app)

    @app.middleware("http")
    async def request_logging(request: Request, call_next):  # type: ignore[no-untyped-def]
        rid = request.headers.get("x-request-id") or request_id()
        request.state.request_id = rid
        start = time.monotonic()
        try:
            response = await call_next(request)
        except Exception:
            duration_ms = int((time.monotonic() - start) * 1000)
            log.exception("request failed", extra={
                "request_id": rid,
                "method": request.method,
                "path": request.path if hasattr(request, "path") else request.url.path,
                "duration_ms": duration_ms,
            })
            raise
        duration_ms = int((time.monotonic() - start) * 1000)
        log.info("request handled", extra={
            "request_id": rid,
            "method": request.method,
            "path": request.path if hasattr(request, "path") else request.url.path,
            "status": response.status_code,
            "duration_ms": duration_ms,
        })
        # Echo request id back so clients can correlate
        try:
            response.headers["x-request-id"] = rid
        except Exception:
            pass
        return response

    # Routers
    app.include_router(health.router)
    app.include_router(products.router, prefix="/api/v1")
    app.include_router(suppliers.router, prefix="/api/v1")
    app.include_router(warehouses.router, prefix="/api/v1")
    app.include_router(inventory.router, prefix="/api/v1")
    app.include_router(purchase_orders.router, prefix="/api/v1")
    app.include_router(customer_orders.router, prefix="/api/v1")
    app.include_router(alerts.router, prefix="/api/v1")
    app.include_router(reports.router, prefix="/api/v1")

    return app


# Convenience for `uvicorn invtrack.api.main:app`
app = create_app()
