from __future__ import annotations

import csv
import sqlite3
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Iterable, TextIO

from ..db import transaction
from ..errors import ConflictError, NotFoundError, ValidationError
from ..repositories.categories import CategoryRepository
from ..repositories.locations import StorageLocationRepository
from ..repositories.products import ProductRepository
from ..repositories.suppliers import SupplierRepository
from ..repositories.warehouses import WarehouseRepository
from ..services.catalog_service import CatalogService
from ..services.inventory_service import InventoryService


@dataclass(frozen=True)
class ImportSummary:
    rows_total: int
    rows_imported: int
    rows_skipped: int
    errors: tuple[str, ...] = ()


class CSVImportError(ValidationError):
    def __init__(self, row_number: int, original: Exception) -> None:
        super().__init__(f"row {row_number}: {original}")
        self.row_number = row_number
        self.original = original


def _open(file_or_path: TextIO | Path | str) -> tuple[TextIO, bool]:
    if hasattr(file_or_path, "read"):
        return file_or_path, False  # type: ignore[return-value]
    f = open(file_or_path, "r", newline="", encoding="utf-8")
    return f, True


def _check_columns(reader: csv.DictReader, required: Iterable[str]) -> None:
    missing = [c for c in required if c not in (reader.fieldnames or [])]
    if missing:
        raise ValidationError(f"missing columns: {sorted(missing)}")


def _parse_int(value: str | None, *, label: str, default: int = 0) -> int:
    if value is None or value == "":
        return default
    try:
        return int(value)
    except ValueError:
        raise ValidationError(f"{label}: not an integer ({value!r})")


def _parse_bool(value: str | None, *, default: bool = True) -> bool:
    if value is None or value == "":
        return default
    v = value.strip().lower()
    if v in {"1", "true", "yes", "y"}:
        return True
    if v in {"0", "false", "no", "n"}:
        return False
    raise ValidationError(f"unrecognised boolean: {value!r}")


def import_categories(conn: sqlite3.Connection, source: TextIO | Path | str) -> ImportSummary:
    """columns: name [,parent_name]"""
    f, opened = _open(source)
    try:
        reader = csv.DictReader(f)
        _check_columns(reader, ["name"])
        cats = CategoryRepository(conn)
        total = imported = skipped = 0
        with transaction(conn):
            for i, row in enumerate(reader, start=2):  # row 1 is header
                total += 1
                name = (row.get("name") or "").strip()
                if not name:
                    raise CSVImportError(i, ValidationError("name is required"))
                if cats.get_by_name(name) is not None:
                    skipped += 1
                    continue
                parent_id: int | None = None
                parent_name = (row.get("parent_name") or "").strip()
                if parent_name:
                    parent = cats.get_by_name(parent_name)
                    if parent is None:
                        raise CSVImportError(i, NotFoundError(f"parent category {parent_name!r}"))
                    parent_id = parent.id
                from ..domain import Category
                cats.create(Category(id=None, name=name, parent_id=parent_id))
                imported += 1
        return ImportSummary(total, imported, skipped)
    finally:
        if opened:
            f.close()


def import_suppliers(conn: sqlite3.Connection, source: TextIO | Path | str) -> ImportSummary:
    """columns: code, name [,contact_email,lead_time_days,active]"""
    f, opened = _open(source)
    try:
        reader = csv.DictReader(f)
        _check_columns(reader, ["code", "name"])
        cat = CatalogService(conn)
        suppliers = SupplierRepository(conn)
        total = imported = skipped = 0
        with transaction(conn):
            for i, row in enumerate(reader, start=2):
                total += 1
                code = (row.get("code") or "").strip()
                if suppliers.get_by_code(code) is not None:
                    skipped += 1
                    continue
                try:
                    cat.create_supplier(
                        code=code,
                        name=(row.get("name") or "").strip(),
                        contact_email=(row.get("contact_email") or "").strip() or None,
                        lead_time_days=_parse_int(row.get("lead_time_days"), label="lead_time_days", default=7),
                    )
                    imported += 1
                except (ValidationError, ConflictError, NotFoundError) as exc:
                    raise CSVImportError(i, exc)
        return ImportSummary(total, imported, skipped)
    finally:
        if opened:
            f.close()


def import_products(conn: sqlite3.Connection, source: TextIO | Path | str) -> ImportSummary:
    """columns: sku, name [,description,category,supplier_code,
        unit_cost_cents,unit_price_cents,reorder_point,reorder_qty]"""
    f, opened = _open(source)
    try:
        reader = csv.DictReader(f)
        _check_columns(reader, ["sku", "name"])
        cat_svc = CatalogService(conn)
        products = ProductRepository(conn)
        cats = CategoryRepository(conn)
        suppliers = SupplierRepository(conn)
        total = imported = skipped = 0
        with transaction(conn):
            for i, row in enumerate(reader, start=2):
                total += 1
                sku = (row.get("sku") or "").strip()
                if products.get_by_sku(sku) is not None:
                    skipped += 1
                    continue
                category_id: int | None = None
                cname = (row.get("category") or "").strip()
                if cname:
                    c = cats.get_by_name(cname)
                    if c is None:
                        raise CSVImportError(i, NotFoundError(f"category {cname!r}"))
                    category_id = c.id
                supplier_id: int | None = None
                scode = (row.get("supplier_code") or "").strip()
                if scode:
                    s = suppliers.get_by_code(scode)
                    if s is None:
                        raise CSVImportError(i, NotFoundError(f"supplier {scode!r}"))
                    supplier_id = s.id
                try:
                    cat_svc.create_product(
                        sku=sku,
                        name=(row.get("name") or "").strip(),
                        description=(row.get("description") or "").strip() or None,
                        category_id=category_id,
                        supplier_id=supplier_id,
                        unit_cost_cents=_parse_int(row.get("unit_cost_cents"), label="unit_cost_cents"),
                        unit_price_cents=_parse_int(row.get("unit_price_cents"), label="unit_price_cents"),
                        reorder_point=_parse_int(row.get("reorder_point"), label="reorder_point"),
                        reorder_qty=_parse_int(row.get("reorder_qty"), label="reorder_qty"),
                    )
                    imported += 1
                except (ValidationError, ConflictError, NotFoundError) as exc:
                    raise CSVImportError(i, exc)
        return ImportSummary(total, imported, skipped)
    finally:
        if opened:
            f.close()


def import_opening_stock(
    conn: sqlite3.Connection,
    source: TextIO | Path | str,
    *,
    actor: str | None = None,
) -> ImportSummary:
    """Bring stock to a known starting position.

    Columns: sku, warehouse_code, location_code, quantity

    Each row records a positive ADJUSTMENT movement with note
    'opening stock'. Re-importing the same file is rejected for any
    (sku, location) that already has nonzero stock - we treat opening
    stock as a one-time bootstrap, not a cumulative load.
    """
    f, opened = _open(source)
    try:
        reader = csv.DictReader(f)
        _check_columns(reader, ["sku", "warehouse_code", "location_code", "quantity"])
        products = ProductRepository(conn)
        warehouses = WarehouseRepository(conn)
        locations = StorageLocationRepository(conn)
        inv_svc = InventoryService(conn)
        total = imported = skipped = 0
        with transaction(conn):
            for i, row in enumerate(reader, start=2):
                total += 1
                sku = (row.get("sku") or "").strip()
                p = products.get_by_sku(sku)
                if p is None:
                    raise CSVImportError(i, NotFoundError(f"product {sku!r}"))
                wh_code = (row.get("warehouse_code") or "").strip()
                w = warehouses.get_by_code(wh_code)
                if w is None:
                    raise CSVImportError(i, NotFoundError(f"warehouse {wh_code!r}"))
                loc_code = (row.get("location_code") or "").strip()
                loc = locations.get_by_code(w.id, loc_code)
                if loc is None:
                    raise CSVImportError(i, NotFoundError(f"location {wh_code}/{loc_code}"))
                qty = _parse_int(row.get("quantity"), label="quantity")
                if qty <= 0:
                    raise CSVImportError(i, ValidationError("quantity must be > 0"))
                existing = inv_svc.inventory.get(p.id, loc.id)
                if existing and existing.quantity > 0:
                    skipped += 1
                    continue
                try:
                    inv_svc.adjust(
                        p.id, loc.id, qty,
                        note="opening stock",
                        created_by=actor,
                    )
                    imported += 1
                except (ValidationError, ConflictError, NotFoundError) as exc:
                    raise CSVImportError(i, exc)
        return ImportSummary(total, imported, skipped)
    finally:
        if opened:
            f.close()
