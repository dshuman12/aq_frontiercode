from __future__ import annotations

import csv
import sqlite3
from io import StringIO
from pathlib import Path
from typing import TextIO

from ..reporting.inventory_reports import (
    low_stock,
    stock_summary,
    valuation,
)
from ..repositories.movements import MovementRepository
from ..repositories.products import ProductRepository
from ..repositories.suppliers import SupplierRepository
from ..repositories.categories import CategoryRepository


def _writer(target: TextIO | Path | str) -> tuple[TextIO, bool]:
    if hasattr(target, "write"):
        return target, False  # type: ignore[return-value]
    f = open(target, "w", newline="", encoding="utf-8")
    return f, True


def export_products(conn: sqlite3.Connection, target: TextIO | Path | str) -> int:
    """Write product master data. Round-trips through import_products."""
    products = ProductRepository(conn)
    cats = CategoryRepository(conn)
    sups = SupplierRepository(conn)
    f, opened = _writer(target)
    try:
        w = csv.DictWriter(f, fieldnames=[
            "sku", "name", "description", "category", "supplier_code",
            "unit_cost_cents", "unit_price_cents",
            "reorder_point", "reorder_qty",
        ])
        w.writeheader()
        n = 0
        for p in products.list_active():
            cat_name = ""
            if p.category_id:
                c = cats.get(p.category_id)
                cat_name = c.name if c else ""
            sup_code = ""
            if p.supplier_id:
                s = sups.get(p.supplier_id)
                sup_code = s.code if s else ""
            w.writerow({
                "sku": p.sku,
                "name": p.name,
                "description": p.description or "",
                "category": cat_name,
                "supplier_code": sup_code,
                "unit_cost_cents": p.unit_cost_cents,
                "unit_price_cents": p.unit_price_cents,
                "reorder_point": p.reorder_point,
                "reorder_qty": p.reorder_qty,
            })
            n += 1
        return n
    finally:
        if opened:
            f.close()


def export_stock_summary(conn: sqlite3.Connection, target: TextIO | Path | str) -> int:
    rows = stock_summary(conn)
    f, opened = _writer(target)
    try:
        w = csv.DictWriter(f, fieldnames=[
            "sku", "name", "total_quantity", "total_reserved",
            "total_available", "reorder_point", "reorder_qty", "needs_reorder",
        ])
        w.writeheader()
        for r in rows:
            w.writerow({
                "sku": r.sku,
                "name": r.name,
                "total_quantity": r.total_quantity,
                "total_reserved": r.total_reserved,
                "total_available": r.total_available,
                "reorder_point": r.reorder_point,
                "reorder_qty": r.reorder_qty,
                "needs_reorder": "1" if r.needs_reorder else "0",
            })
        return len(rows)
    finally:
        if opened:
            f.close()


def export_low_stock(conn: sqlite3.Connection, target: TextIO | Path | str) -> int:
    rows = low_stock(conn)
    f, opened = _writer(target)
    try:
        w = csv.DictWriter(f, fieldnames=[
            "sku", "name", "on_hand", "available",
            "reorder_point", "suggested_order_qty", "supplier_code",
        ])
        w.writeheader()
        for r in rows:
            w.writerow({
                "sku": r.sku,
                "name": r.name,
                "on_hand": r.on_hand,
                "available": r.available,
                "reorder_point": r.reorder_point,
                "suggested_order_qty": r.suggested_order_qty,
                "supplier_code": r.supplier_code or "",
            })
        return len(rows)
    finally:
        if opened:
            f.close()


def export_valuation(conn: sqlite3.Connection, target: TextIO | Path | str) -> int:
    rows = valuation(conn)
    f, opened = _writer(target)
    try:
        w = csv.DictWriter(f, fieldnames=[
            "sku", "name", "total_quantity", "unit_cost_cents", "value_cents",
        ])
        w.writeheader()
        for r in rows:
            w.writerow({
                "sku": r.sku,
                "name": r.name,
                "total_quantity": r.total_quantity,
                "unit_cost_cents": r.unit_cost_cents,
                "value_cents": r.value_cents,
            })
        return len(rows)
    finally:
        if opened:
            f.close()


def export_movements(
    conn: sqlite3.Connection,
    target: TextIO | Path | str,
    *,
    start: str | None = None,
    end: str | None = None,
) -> int:
    """Export raw stock movements in [start, end) - useful for reconciliation
    against external systems."""
    movements = MovementRepository(conn)
    if start and end:
        rows = movements.list_in_range(start, end)
    else:
        rows = movements.list_recent(limit=10000)
    f, opened = _writer(target)
    try:
        w = csv.DictWriter(f, fieldnames=[
            "id", "created_at", "product_id", "location_id",
            "movement_type", "quantity", "reference_type", "reference_id",
            "note", "created_by",
        ])
        w.writeheader()
        for m in rows:
            w.writerow({
                "id": m.id,
                "created_at": m.created_at,
                "product_id": m.product_id,
                "location_id": m.location_id,
                "movement_type": m.movement_type.value,
                "quantity": m.quantity,
                "reference_type": m.reference_type or "",
                "reference_id": m.reference_id if m.reference_id is not None else "",
                "note": m.note or "",
                "created_by": m.created_by or "",
            })
        return len(rows)
    finally:
        if opened:
            f.close()
