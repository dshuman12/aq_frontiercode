"""CSV import/export subsystem.

We use the standard csv module - no pandas. Imports run inside a
single transaction per file: if a row fails validation, the whole
file rolls back and we surface a row-numbered error.
"""
