from __future__ import annotations

import sqlite3

from ..repositories.alerts import AlertRepository
from ..reporting.inventory_reports import low_stock
from . import JobResult


def low_stock_alert_job(conn: sqlite3.Connection) -> JobResult:
    """Raise an alert per product whose available stock is at or below
    the reorder point. If a previous unresolved alert exists for the
    same (alert_type, subject_type, subject_id), don't duplicate it.
    Resolve alerts for products that are no longer below threshold.
    """
    alerts = AlertRepository(conn)
    rows = low_stock(conn)
    raised = 0
    skipped = 0
    resolved = 0

    seen_subject_ids: set[int] = set()
    for r in rows:
        seen_subject_ids.add(r.product_id)
        existing = alerts.find_open("low_stock", "product", r.product_id)
        if existing is None:
            severity = "critical" if r.available <= 0 else "warning"
            alerts.raise_alert(
                "low_stock",
                "product",
                r.product_id,
                severity,
                f"{r.sku} ({r.name}): {r.available} available, "
                f"reorder point {r.reorder_point}",
            )
            raised += 1
        else:
            skipped += 1

    # Resolve stale alerts: products no longer in low-stock report.
    open_lows = alerts.list_open("low_stock")
    for a in open_lows:
        if a.subject_type == "product" and a.subject_id not in seen_subject_ids:
            alerts.resolve(a.id)
            resolved += 1

    return JobResult(
        summary=f"raised={raised} skipped={skipped} resolved={resolved}",
        metrics={"raised": raised, "skipped": skipped, "resolved": resolved},
    )
