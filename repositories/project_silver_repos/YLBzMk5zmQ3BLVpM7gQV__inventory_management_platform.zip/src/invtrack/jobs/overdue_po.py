from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from ..domain import POStatus
from ..repositories.alerts import AlertRepository
from ..repositories.purchase_orders import PurchaseOrderRepository
from . import JobResult


def overdue_po_job(conn: sqlite3.Connection, *, today: str | None = None) -> JobResult:
    """POs in SUBMITTED or PARTIAL with expected_at in the past raise a
    'po_overdue' alert. We resolve alerts for POs that have since flipped
    to RECEIVED or CANCELLED.
    """
    alerts = AlertRepository(conn)
    pos = PurchaseOrderRepository(conn)
    today_iso = today or datetime.now(timezone.utc).strftime("%Y-%m-%d")

    raised = 0
    skipped = 0
    resolved = 0

    open_pos = pos.list_open()
    seen: set[int] = set()
    for po in open_pos:
        if po.expected_at and po.expected_at < today_iso:
            seen.add(po.id)
            existing = alerts.find_open("po_overdue", "po", po.id)
            if existing is None:
                alerts.raise_alert(
                    "po_overdue",
                    "po",
                    po.id,
                    "warning",
                    f"PO {po.po_number} expected {po.expected_at} still open ({po.status.value})",
                )
                raised += 1
            else:
                skipped += 1

    # Resolve any open po_overdue alerts whose POs are now received/cancelled
    # or which now appear current. We do that by checking each open alert.
    open_alerts = alerts.list_open("po_overdue")
    for a in open_alerts:
        if a.subject_type != "po":
            continue
        if a.subject_id in seen:
            continue
        po = pos.get(a.subject_id)
        if po is None or po.status in {POStatus.RECEIVED, POStatus.CANCELLED}:
            alerts.resolve(a.id)
            resolved += 1
        elif po.expected_at and po.expected_at >= today_iso:
            alerts.resolve(a.id)
            resolved += 1

    return JobResult(
        summary=f"raised={raised} skipped={skipped} resolved={resolved}",
        metrics={"raised": raised, "skipped": skipped, "resolved": resolved},
    )
