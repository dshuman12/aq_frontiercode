"""Background jobs.

These are the things that, in production, would run on a cron or a
scheduler. Each job is a callable that takes a connection and returns
a JobResult. The runner records start/finish and any error so the
operator can see what ran and when.
"""
from __future__ import annotations

import sqlite3
import traceback
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Callable, Iterator


@dataclass(frozen=True)
class JobResult:
    summary: str
    metrics: dict[str, int]


JobFn = Callable[[sqlite3.Connection], JobResult]


@contextmanager
def _run_job(conn: sqlite3.Connection, name: str) -> Iterator[int]:
    cur = conn.execute(
        "INSERT INTO job_runs (job_name, status) VALUES (?, 'running')", (name,)
    )
    job_id = int(cur.lastrowid)
    try:
        yield job_id
    except Exception as exc:
        conn.execute(
            "UPDATE job_runs SET status = 'failed', finished_at = datetime('now'), error = ? "
            "WHERE id = ?",
            (f"{exc.__class__.__name__}: {exc}\n{traceback.format_exc()}", job_id),
        )
        raise


def run_job(conn: sqlite3.Connection, name: str, fn: JobFn) -> JobResult:
    """Run a named job and persist a job_runs row."""
    with _run_job(conn, name) as job_id:
        result = fn(conn)
        conn.execute(
            "UPDATE job_runs SET status = 'succeeded', finished_at = datetime('now'), summary = ? "
            "WHERE id = ?",
            (result.summary, job_id),
        )
        return result
