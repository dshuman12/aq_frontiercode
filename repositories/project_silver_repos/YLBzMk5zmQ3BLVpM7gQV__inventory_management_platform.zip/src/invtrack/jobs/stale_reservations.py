from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone

from ..domain import CustomerOrderStatus
from ..repositories.customer_orders import CustomerOrderRepository
from . import JobResult


def stale_reservation_audit_job(
    conn: sqlite3.Connection,
    *,
    older_than_hours: int = 48,
    now: datetime | None = None,
) -> JobResult:
    """Find orders that have been CONFIRMED for too long without progressing.

    Doesn't auto-cancel - just flags. Auto-cancellation is too aggressive;
    the warehouse occasionally has confirmed orders sitting for several
    days while we wait on backorder.
    """
    now_dt = now or datetime.now(timezone.utc)
    cutoff = (now_dt - timedelta(hours=older_than_hours)).strftime("%Y-%m-%d %H:%M:%S")
    co_repo = CustomerOrderRepository(conn)
    rows = conn.execute(
        """SELECT id FROM customer_orders
            WHERE status = 'confirmed' AND confirmed_at < ?""",
        (cutoff,),
    ).fetchall()
    flagged: list[int] = []
    for row in rows:
        order = co_repo.get(row["id"])
        if order is None or order.status != CustomerOrderStatus.CONFIRMED:
            continue
        flagged.append(order.id)

    return JobResult(
        summary=f"stale_orders={len(flagged)}",
        metrics={"flagged": len(flagged)},
    )
