"""SQLite connection helpers.

Thin wrapper around sqlite3 to give us:
- Row-factory dicts everywhere
- Foreign keys ON
- Sensible isolation level
- One place to attach pragmas
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def connect(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), isolation_level=None, timeout=10.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# Per-connection transaction depth. We can't stash this on the connection
# object directly (sqlite3.Connection is not subclassable in a clean way for
# our use), so we keep it in a thread-aware dict keyed by id(conn).
_DEPTH_LOCK = threading.Lock()
_DEPTH: dict[int, int] = {}


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Reentrant transaction context.

    Top-level entries issue BEGIN/COMMIT. Nested entries issue SAVEPOINT
    so a service that starts a transaction can freely call another service
    that also wants a transaction. Inner failures roll back to the
    savepoint without poisoning the outer transaction unless the outer
    layer also raises.
    """
    key = id(conn)
    with _DEPTH_LOCK:
        depth = _DEPTH.get(key, 0)
        _DEPTH[key] = depth + 1
    if depth == 0:
        conn.execute("BEGIN")
    else:
        conn.execute(f"SAVEPOINT sp_{depth}")
    try:
        yield conn
    except Exception:
        if depth == 0:
            conn.execute("ROLLBACK")
        else:
            conn.execute(f"ROLLBACK TO SAVEPOINT sp_{depth}")
            conn.execute(f"RELEASE SAVEPOINT sp_{depth}")
        raise
    else:
        if depth == 0:
            conn.execute("COMMIT")
        else:
            conn.execute(f"RELEASE SAVEPOINT sp_{depth}")
    finally:
        with _DEPTH_LOCK:
            _DEPTH[key] = _DEPTH.get(key, 1) - 1
            if _DEPTH[key] <= 0:
                _DEPTH.pop(key, None)
