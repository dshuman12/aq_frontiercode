"""Schema bootstrap and migrations.

We track schema version in a tiny meta table. Migrations are append-only:
each one is a function taking a connection and applying its changes.
"""
from __future__ import annotations

import sqlite3
from typing import Callable


SCHEMA_V1 = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    parent_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    contact_email TEXT,
    lead_time_days INTEGER NOT NULL DEFAULT 7,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    sku TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT,
    category_id INTEGER REFERENCES categories(id),
    supplier_id INTEGER REFERENCES suppliers(id),
    unit_cost_cents INTEGER NOT NULL DEFAULT 0,
    unit_price_cents INTEGER NOT NULL DEFAULT 0,
    reorder_point INTEGER NOT NULL DEFAULT 0,
    reorder_qty INTEGER NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS warehouses (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    address TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


SCHEMA_V2 = """
CREATE TABLE IF NOT EXISTS storage_locations (
    id INTEGER PRIMARY KEY,
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    description TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    UNIQUE(warehouse_id, code)
);

CREATE TABLE IF NOT EXISTS inventory_levels (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    location_id INTEGER NOT NULL REFERENCES storage_locations(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL DEFAULT 0,
    reserved INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(product_id, location_id),
    CHECK(quantity >= 0),
    CHECK(reserved >= 0),
    CHECK(reserved <= quantity)
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id),
    location_id INTEGER NOT NULL REFERENCES storage_locations(id),
    movement_type TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    reference_type TEXT,
    reference_id INTEGER,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_movements_product ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_movements_created ON stock_movements(created_at);
"""


def _apply_v1(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V1)


def _apply_v2(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V2)


SCHEMA_V3 = """
CREATE TABLE IF NOT EXISTS purchase_orders (
    id INTEGER PRIMARY KEY,
    po_number TEXT NOT NULL UNIQUE,
    supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
    status TEXT NOT NULL DEFAULT 'draft',
    expected_at TEXT,
    submitted_at TEXT,
    received_at TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT
);

CREATE TABLE IF NOT EXISTS purchase_order_lines (
    id INTEGER PRIMARY KEY,
    po_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity_ordered INTEGER NOT NULL,
    quantity_received INTEGER NOT NULL DEFAULT 0,
    unit_cost_cents INTEGER NOT NULL,
    UNIQUE(po_id, product_id),
    CHECK(quantity_ordered > 0),
    CHECK(quantity_received >= 0),
    CHECK(quantity_received <= quantity_ordered)
);

CREATE INDEX IF NOT EXISTS idx_po_status ON purchase_orders(status);
CREATE INDEX IF NOT EXISTS idx_po_supplier ON purchase_orders(supplier_id);

CREATE TABLE IF NOT EXISTS customer_orders (
    id INTEGER PRIMARY KEY,
    order_number TEXT NOT NULL UNIQUE,
    customer_name TEXT NOT NULL,
    customer_email TEXT,
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
    status TEXT NOT NULL DEFAULT 'draft',
    confirmed_at TEXT,
    shipped_at TEXT,
    cancelled_at TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT
);

CREATE TABLE IF NOT EXISTS customer_order_lines (
    id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL REFERENCES customer_orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity INTEGER NOT NULL,
    quantity_picked INTEGER NOT NULL DEFAULT 0,
    quantity_shipped INTEGER NOT NULL DEFAULT 0,
    unit_price_cents INTEGER NOT NULL,
    UNIQUE(order_id, product_id),
    CHECK(quantity > 0),
    CHECK(quantity_picked >= 0),
    CHECK(quantity_shipped >= 0),
    CHECK(quantity_picked <= quantity),
    CHECK(quantity_shipped <= quantity_picked)
);

CREATE INDEX IF NOT EXISTS idx_co_status ON customer_orders(status);
"""


def _apply_v3(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V3)


SCHEMA_V4 = """
-- The reservation->release->ship lookup in CustomerOrderService hits
-- this index hard. Without it we full-scan stock_movements.
CREATE INDEX IF NOT EXISTS idx_movements_ref
    ON stock_movements(reference_type, reference_id);

-- Movement listing per location was missing.
CREATE INDEX IF NOT EXISTS idx_movements_location
    ON stock_movements(location_id);

-- Useful for the open-PO query that filters by status and orders by expected_at
CREATE INDEX IF NOT EXISTS idx_po_expected_at
    ON purchase_orders(expected_at);

-- Customer orders by warehouse for warehouse-scoped reports
CREATE INDEX IF NOT EXISTS idx_co_warehouse
    ON customer_orders(warehouse_id);

-- Active products are queried very often
CREATE INDEX IF NOT EXISTS idx_products_active
    ON products(active, sku);

-- Product full-text-ish search uses LIKE; an index on lower(name)
-- would matter once the catalog grows past a few thousand rows.
-- Skipping for now since LIKE %x% can't use a regular index.
"""


def _apply_v4(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V4)


SCHEMA_V5 = """
CREATE TABLE IF NOT EXISTS stock_transfers (
    id INTEGER PRIMARY KEY,
    transfer_number TEXT NOT NULL UNIQUE,
    source_location_id INTEGER NOT NULL REFERENCES storage_locations(id),
    dest_location_id INTEGER NOT NULL REFERENCES storage_locations(id),
    status TEXT NOT NULL DEFAULT 'in_transit',
    initiated_at TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT,
    cancelled_at TEXT,
    notes TEXT,
    created_by TEXT,
    CHECK(source_location_id != dest_location_id)
);

CREATE TABLE IF NOT EXISTS stock_transfer_lines (
    id INTEGER PRIMARY KEY,
    transfer_id INTEGER NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity INTEGER NOT NULL,
    UNIQUE(transfer_id, product_id),
    CHECK(quantity > 0)
);

CREATE INDEX IF NOT EXISTS idx_transfers_status ON stock_transfers(status);
"""


def _apply_v5(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V5)


SCHEMA_V6 = """
CREATE TABLE IF NOT EXISTS stock_counts (
    id INTEGER PRIMARY KEY,
    count_number TEXT NOT NULL UNIQUE,
    location_id INTEGER NOT NULL REFERENCES storage_locations(id),
    status TEXT NOT NULL DEFAULT 'open',  -- open, applied, abandoned
    started_at TEXT NOT NULL DEFAULT (datetime('now')),
    applied_at TEXT,
    abandoned_at TEXT,
    notes TEXT,
    counted_by TEXT
);

CREATE TABLE IF NOT EXISTS stock_count_lines (
    id INTEGER PRIMARY KEY,
    count_id INTEGER NOT NULL REFERENCES stock_counts(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    counted_qty INTEGER NOT NULL,
    system_qty INTEGER NOT NULL,  -- snapshot at entry time
    UNIQUE(count_id, product_id),
    CHECK(counted_qty >= 0),
    CHECK(system_qty >= 0)
);

CREATE INDEX IF NOT EXISTS idx_counts_location ON stock_counts(location_id);
CREATE INDEX IF NOT EXISTS idx_counts_status ON stock_counts(status);
"""


def _apply_v6(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V6)


SCHEMA_V7 = """
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY,
    alert_type TEXT NOT NULL,            -- 'low_stock', 'po_overdue', etc
    subject_type TEXT NOT NULL,          -- 'product', 'po', etc
    subject_id INTEGER NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info', -- info, warning, critical
    message TEXT NOT NULL,
    raised_at TEXT NOT NULL DEFAULT (datetime('now')),
    acknowledged_at TEXT,
    acknowledged_by TEXT,
    resolved_at TEXT,
    UNIQUE(alert_type, subject_type, subject_id, raised_at)
);

CREATE INDEX IF NOT EXISTS idx_alerts_open
    ON alerts(alert_type, subject_type, subject_id)
    WHERE resolved_at IS NULL;

CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY,
    event_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    actor TEXT,
    payload TEXT,                        -- JSON blob
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at);

CREATE TABLE IF NOT EXISTS job_runs (
    id INTEGER PRIMARY KEY,
    job_name TEXT NOT NULL,
    started_at TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at TEXT,
    status TEXT NOT NULL DEFAULT 'running', -- running, succeeded, failed
    summary TEXT,
    error TEXT
);

CREATE INDEX IF NOT EXISTS idx_jobs_name_start ON job_runs(job_name, started_at);
"""


def _apply_v7(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_V7)


MIGRATIONS: list[tuple[int, Callable[[sqlite3.Connection], None]]] = [
    (1, _apply_v1),
    (2, _apply_v2),
    (3, _apply_v3),
    (4, _apply_v4),
    (5, _apply_v5),
    (6, _apply_v6),
    (7, _apply_v7),
]


def current_version(conn: sqlite3.Connection) -> int:
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'"
    ).fetchone()
    if not row:
        return 0
    row = conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
    return int(row["v"]) if row and row["v"] is not None else 0


def migrate(conn: sqlite3.Connection) -> int:
    """Apply pending migrations, return new version."""
    v = current_version(conn)
    for version, fn in MIGRATIONS:
        if version <= v:
            continue
        fn(conn)
        conn.execute("INSERT INTO schema_version (version) VALUES (?)", (version,))
        v = version
    return v
