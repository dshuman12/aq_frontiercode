from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone


@dataclass(frozen=True)
class MovementSummary:
    movement_type: str
    count: int
    total_qty: int


@dataclass(frozen=True)
class TopProductRow:
    sku: str
    name: str
    units_shipped: int
    revenue_cents: int


@dataclass(frozen=True)
class VelocityRow:
    sku: str
    name: str
    units_shipped: int
    days_in_window: int
    units_per_day: float
    on_hand: int
    days_of_cover: float | None  # None when units_per_day == 0


def movement_summary(
    conn: sqlite3.Connection,
    *,
    start: str,
    end: str,
) -> list[MovementSummary]:
    rows = conn.execute(
        """SELECT movement_type, COUNT(*) AS c, COALESCE(SUM(ABS(quantity)), 0) AS q
             FROM stock_movements
            WHERE created_at >= ? AND created_at < ?
            GROUP BY movement_type
            ORDER BY movement_type""",
        (start, end),
    ).fetchall()
    return [
        MovementSummary(
            movement_type=r["movement_type"],
            count=int(r["c"]),
            total_qty=int(r["q"]),
        )
        for r in rows
    ]


def top_shipped_products(
    conn: sqlite3.Connection,
    *,
    start: str,
    end: str,
    limit: int = 10,
) -> list[TopProductRow]:
    """Top products by units shipped in the window. Joins back to
    customer order lines for revenue, where the movement was for an order."""
    rows = conn.execute(
        """
        SELECT p.sku, p.name,
               SUM(ABS(m.quantity)) AS units,
               COALESCE(SUM(
                   CASE WHEN m.reference_type = 'customer_order' THEN
                       (SELECT col.unit_price_cents * ABS(m.quantity)
                          FROM customer_order_lines col
                         WHERE col.order_id = m.reference_id
                           AND col.product_id = m.product_id)
                   ELSE 0 END
               ), 0) AS rev
          FROM stock_movements m
          JOIN products p ON p.id = m.product_id
         WHERE m.movement_type = 'shipment'
           AND m.created_at >= ? AND m.created_at < ?
         GROUP BY p.id
         ORDER BY units DESC
         LIMIT ?
        """,
        (start, end, limit),
    ).fetchall()
    return [
        TopProductRow(
            sku=r["sku"],
            name=r["name"],
            units_shipped=int(r["units"]),
            revenue_cents=int(r["rev"]),
        )
        for r in rows
    ]


def velocity_report(
    conn: sqlite3.Connection,
    *,
    days: int = 30,
    end_iso: str | None = None,
) -> list[VelocityRow]:
    if end_iso is None:
        end_dt = datetime.now(timezone.utc)
    else:
        end_dt = datetime.fromisoformat(end_iso)
    start_dt = end_dt - timedelta(days=days)
    start = start_dt.strftime("%Y-%m-%d %H:%M:%S")
    end = end_dt.strftime("%Y-%m-%d %H:%M:%S")
    rows = conn.execute(
        """
        SELECT p.id AS pid, p.sku, p.name,
               COALESCE(SUM(CASE WHEN m.movement_type = 'shipment'
                                 THEN ABS(m.quantity) ELSE 0 END), 0) AS shipped,
               COALESCE((SELECT SUM(quantity) FROM inventory_levels
                          WHERE product_id = p.id), 0) AS on_hand
          FROM products p
          LEFT JOIN stock_movements m
            ON m.product_id = p.id
           AND m.created_at >= ? AND m.created_at < ?
         WHERE p.active = 1
         GROUP BY p.id
         ORDER BY shipped DESC
        """,
        (start, end),
    ).fetchall()
    out: list[VelocityRow] = []
    for r in rows:
        shipped = int(r["shipped"])
        on_hand = int(r["on_hand"])
        per_day = shipped / days if days > 0 else 0.0
        cover = (on_hand / per_day) if per_day > 0 else None
        out.append(
            VelocityRow(
                sku=r["sku"],
                name=r["name"],
                units_shipped=shipped,
                days_in_window=days,
                units_per_day=per_day,
                on_hand=on_hand,
                days_of_cover=cover,
            )
        )
    return out


def reorder_suggestions(conn: sqlite3.Connection) -> list[dict]:
    """Roll up low-stock items by supplier so we can group reorders."""
    rows = conn.execute(
        """
        SELECT s.id AS sid, s.code AS supplier_code, s.name AS supplier_name,
               p.id AS pid, p.sku, p.name,
               p.reorder_qty,
               COALESCE(SUM(il.quantity - il.reserved), 0) AS avail,
               p.reorder_point
          FROM products p
          LEFT JOIN inventory_levels il ON il.product_id = p.id
          LEFT JOIN suppliers s ON s.id = p.supplier_id
         WHERE p.active = 1 AND p.reorder_point > 0
         GROUP BY p.id
        HAVING avail <= p.reorder_point
         ORDER BY s.code, p.sku
        """,
    ).fetchall()
    grouped: dict[str | None, dict] = {}
    for r in rows:
        key = r["supplier_code"]
        if key not in grouped:
            grouped[key] = {
                "supplier_id": r["sid"],
                "supplier_code": r["supplier_code"],
                "supplier_name": r["supplier_name"],
                "lines": [],
            }
        grouped[key]["lines"].append(
            {
                "product_id": r["pid"],
                "sku": r["sku"],
                "name": r["name"],
                "available": int(r["avail"]),
                "reorder_point": int(r["reorder_point"]),
                "suggested_qty": int(r["reorder_qty"]),
            }
        )
    return list(grouped.values())
