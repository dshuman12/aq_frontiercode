from __future__ import annotations

import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class StockSummaryRow:
    sku: str
    name: str
    total_quantity: int
    total_reserved: int
    total_available: int
    reorder_point: int
    reorder_qty: int
    needs_reorder: bool


@dataclass(frozen=True)
class LowStockRow:
    product_id: int
    sku: str
    name: str
    on_hand: int
    available: int
    reorder_point: int
    suggested_order_qty: int
    supplier_id: int | None
    supplier_code: str | None


@dataclass(frozen=True)
class ValuationRow:
    sku: str
    name: str
    total_quantity: int
    unit_cost_cents: int
    value_cents: int


def stock_summary(
    conn: sqlite3.Connection,
    *,
    category_id: int | None = None,
    only_active: bool = True,
) -> list[StockSummaryRow]:
    """Total on-hand and available across all locations, per product."""
    where = ["1=1"]
    params: list = []
    if only_active:
        where.append("p.active = 1")
    if category_id is not None:
        where.append("p.category_id = ?")
        params.append(category_id)
    rows = conn.execute(
        f"""
        SELECT p.id, p.sku, p.name,
               COALESCE(SUM(il.quantity), 0) AS qty,
               COALESCE(SUM(il.reserved), 0) AS res,
               p.reorder_point, p.reorder_qty
          FROM products p
          LEFT JOIN inventory_levels il ON il.product_id = p.id
         WHERE {' AND '.join(where)}
         GROUP BY p.id
         ORDER BY p.sku
        """,
        params,
    ).fetchall()
    out: list[StockSummaryRow] = []
    for r in rows:
        qty = int(r["qty"])
        res = int(r["res"])
        avail = qty - res
        rp = int(r["reorder_point"])
        out.append(StockSummaryRow(
            sku=r["sku"],
            name=r["name"],
            total_quantity=qty,
            total_reserved=res,
            total_available=avail,
            reorder_point=rp,
            reorder_qty=int(r["reorder_qty"]),
            needs_reorder=rp > 0 and avail <= rp,
        ))
    return out


def low_stock(
    conn: sqlite3.Connection,
    *,
    only_active: bool = True,
) -> list[LowStockRow]:
    where = ["p.reorder_point > 0"]
    if only_active:
        where.append("p.active = 1")
    rows = conn.execute(
        f"""
        SELECT p.id AS pid, p.sku, p.name,
               COALESCE(SUM(il.quantity), 0) AS qty,
               COALESCE(SUM(il.quantity - il.reserved), 0) AS avail,
               p.reorder_point, p.reorder_qty,
               p.supplier_id,
               s.code AS supplier_code
          FROM products p
          LEFT JOIN inventory_levels il ON il.product_id = p.id
          LEFT JOIN suppliers s ON s.id = p.supplier_id
         WHERE {' AND '.join(where)}
         GROUP BY p.id
        HAVING avail <= p.reorder_point
         ORDER BY (CAST(avail AS REAL) / NULLIF(p.reorder_point, 0))
        """,
    ).fetchall()
    return [
        LowStockRow(
            product_id=int(r["pid"]),
            sku=r["sku"],
            name=r["name"],
            on_hand=int(r["qty"]),
            available=int(r["avail"]),
            reorder_point=int(r["reorder_point"]),
            suggested_order_qty=int(r["reorder_qty"]),
            supplier_id=r["supplier_id"],
            supplier_code=r["supplier_code"],
        )
        for r in rows
    ]


def valuation(conn: sqlite3.Connection) -> list[ValuationRow]:
    """On-hand value per SKU at unit_cost_cents."""
    rows = conn.execute(
        """
        SELECT p.sku, p.name, p.unit_cost_cents,
               COALESCE(SUM(il.quantity), 0) AS qty
          FROM products p
          LEFT JOIN inventory_levels il ON il.product_id = p.id
         WHERE p.active = 1
         GROUP BY p.id
         ORDER BY p.sku
        """
    ).fetchall()
    return [
        ValuationRow(
            sku=r["sku"],
            name=r["name"],
            total_quantity=int(r["qty"]),
            unit_cost_cents=int(r["unit_cost_cents"]),
            value_cents=int(r["qty"]) * int(r["unit_cost_cents"]),
        )
        for r in rows
    ]


def total_inventory_value_cents(conn: sqlite3.Connection) -> int:
    return sum(r.value_cents for r in valuation(conn))
