"""Reporting and analytics queries.

Read-only by design: every function takes a connection and returns a
list/dict structure ready for printing or serialisation. We don't
return domain objects here because reports are inherently denormalised.
"""
