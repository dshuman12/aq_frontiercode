"""Reusable validation primitives.

Services call these for cross-cutting checks. Anything more specific
lives next to the service it belongs to.
"""
from __future__ import annotations

import re

from .errors import ValidationError


SKU_RE = re.compile(r"^[A-Z0-9][A-Z0-9\-_]{1,31}$")
CODE_RE = re.compile(r"^[A-Z0-9][A-Z0-9\-_]{0,15}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_sku(sku: str) -> None:
    if not sku or not SKU_RE.match(sku):
        raise ValidationError(
            f"invalid sku {sku!r}: must be 2-32 chars, "
            "uppercase alphanumeric or - _"
        )


def validate_code(code: str, *, label: str = "code") -> None:
    if not code or not CODE_RE.match(code):
        raise ValidationError(
            f"invalid {label} {code!r}: must be 1-16 chars, "
            "uppercase alphanumeric or - _"
        )


def validate_email(email: str) -> None:
    if not EMAIL_RE.match(email):
        raise ValidationError(f"invalid email: {email!r}")


def validate_positive(value: int, *, label: str) -> None:
    if value <= 0:
        raise ValidationError(f"{label} must be positive, got {value}")


def validate_non_negative(value: int, *, label: str) -> None:
    if value < 0:
        raise ValidationError(f"{label} must be non-negative, got {value}")
