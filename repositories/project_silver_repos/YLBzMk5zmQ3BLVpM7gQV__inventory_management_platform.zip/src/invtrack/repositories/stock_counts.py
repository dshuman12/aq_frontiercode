from __future__ import annotations

import sqlite3

from ..domain import StockCount, StockCountLine, StockCountStatus


class StockCountRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create_header(
        self,
        count_number: str,
        location_id: int,
        notes: str | None = None,
        counted_by: str | None = None,
    ) -> int:
        cur = self.conn.execute(
            """INSERT INTO stock_counts (count_number, location_id, status, notes, counted_by)
               VALUES (?, ?, 'open', ?, ?)""",
            (count_number, location_id, notes, counted_by),
        )
        return int(cur.lastrowid)

    def add_line(
        self,
        count_id: int,
        product_id: int,
        counted_qty: int,
        system_qty: int,
    ) -> StockCountLine:
        cur = self.conn.execute(
            """INSERT INTO stock_count_lines
                 (count_id, product_id, counted_qty, system_qty)
               VALUES (?, ?, ?, ?)""",
            (count_id, product_id, counted_qty, system_qty),
        )
        return StockCountLine(
            id=cur.lastrowid,
            count_id=count_id,
            product_id=product_id,
            counted_qty=counted_qty,
            system_qty=system_qty,
        )

    def update_line(self, line_id: int, counted_qty: int) -> None:
        self.conn.execute(
            "UPDATE stock_count_lines SET counted_qty = ? WHERE id = ?",
            (counted_qty, line_id),
        )

    def get(self, count_id: int) -> StockCount | None:
        row = self.conn.execute(
            "SELECT * FROM stock_counts WHERE id = ?", (count_id,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def get_by_number(self, count_number: str) -> StockCount | None:
        row = self.conn.execute(
            "SELECT * FROM stock_counts WHERE count_number = ?", (count_number,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def list_open(self) -> list[StockCount]:
        rows = self.conn.execute(
            "SELECT * FROM stock_counts WHERE status = 'open' ORDER BY started_at"
        ).fetchall()
        return [self._hydrate(r) for r in rows]

    def update_status(
        self,
        count_id: int,
        status: StockCountStatus,
        *,
        timestamp_field: str | None = None,
    ) -> None:
        valid = {"applied_at", "abandoned_at"}
        if timestamp_field and timestamp_field not in valid:
            raise ValueError(f"unknown ts field: {timestamp_field}")
        if timestamp_field:
            self.conn.execute(
                f"UPDATE stock_counts SET status = ?, {timestamp_field} = datetime('now') "
                "WHERE id = ?",
                (status.value, count_id),
            )
        else:
            self.conn.execute(
                "UPDATE stock_counts SET status = ? WHERE id = ?",
                (status.value, count_id),
            )

    def _hydrate(self, row: sqlite3.Row) -> StockCount:
        line_rows = self.conn.execute(
            "SELECT * FROM stock_count_lines WHERE count_id = ? ORDER BY id",
            (row["id"],),
        ).fetchall()
        lines = tuple(
            StockCountLine(
                id=lr["id"],
                count_id=lr["count_id"],
                product_id=lr["product_id"],
                counted_qty=lr["counted_qty"],
                system_qty=lr["system_qty"],
            )
            for lr in line_rows
        )
        return StockCount(
            id=row["id"],
            count_number=row["count_number"],
            location_id=row["location_id"],
            status=StockCountStatus(row["status"]),
            started_at=row["started_at"],
            applied_at=row["applied_at"],
            abandoned_at=row["abandoned_at"],
            notes=row["notes"],
            counted_by=row["counted_by"],
            lines=lines,
        )
