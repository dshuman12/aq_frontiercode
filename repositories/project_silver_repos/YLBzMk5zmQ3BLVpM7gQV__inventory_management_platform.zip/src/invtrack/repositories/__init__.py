"""Repositories: thin data-access objects.

Each repo takes a connection and exposes intent-named methods. We
deliberately don't use a generic Repository[T] base class - the
queries differ enough that the abstraction would just be in the way.
"""
from __future__ import annotations

import sqlite3
from typing import Any


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}
