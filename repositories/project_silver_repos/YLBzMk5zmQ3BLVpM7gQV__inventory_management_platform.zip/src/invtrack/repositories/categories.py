from __future__ import annotations

import sqlite3

from ..domain import Category


class CategoryRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, category: Category) -> Category:
        cur = self.conn.execute(
            "INSERT INTO categories (name, parent_id) VALUES (?, ?)",
            (category.name, category.parent_id),
        )
        return Category(id=cur.lastrowid, name=category.name, parent_id=category.parent_id)

    def get(self, category_id: int) -> Category | None:
        row = self.conn.execute(
            "SELECT id, name, parent_id FROM categories WHERE id = ?", (category_id,)
        ).fetchone()
        if not row:
            return None
        return Category(id=row["id"], name=row["name"], parent_id=row["parent_id"])

    def get_by_name(self, name: str) -> Category | None:
        row = self.conn.execute(
            "SELECT id, name, parent_id FROM categories WHERE name = ?", (name,)
        ).fetchone()
        if not row:
            return None
        return Category(id=row["id"], name=row["name"], parent_id=row["parent_id"])

    def list_all(self) -> list[Category]:
        rows = self.conn.execute(
            "SELECT id, name, parent_id FROM categories ORDER BY name"
        ).fetchall()
        return [Category(id=r["id"], name=r["name"], parent_id=r["parent_id"]) for r in rows]

    def delete(self, category_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM categories WHERE id = ?", (category_id,))
        return cur.rowcount > 0
