from __future__ import annotations

import sqlite3
from typing import Iterable

from ..domain import Product


class ProductRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, product: Product) -> Product:
        cur = self.conn.execute(
            """INSERT INTO products
                 (sku, name, description, category_id, supplier_id,
                  unit_cost_cents, unit_price_cents, reorder_point, reorder_qty, active)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                product.sku,
                product.name,
                product.description,
                product.category_id,
                product.supplier_id,
                product.unit_cost_cents,
                product.unit_price_cents,
                product.reorder_point,
                product.reorder_qty,
                int(product.active),
            ),
        )
        return self._from_row(self.conn.execute(
            "SELECT * FROM products WHERE id = ?", (cur.lastrowid,)
        ).fetchone())

    def get(self, product_id: int) -> Product | None:
        row = self.conn.execute(
            "SELECT * FROM products WHERE id = ?", (product_id,)
        ).fetchone()
        return self._from_row(row) if row else None

    def get_by_sku(self, sku: str) -> Product | None:
        row = self.conn.execute(
            "SELECT * FROM products WHERE sku = ?", (sku,)
        ).fetchone()
        return self._from_row(row) if row else None

    def list_active(self) -> list[Product]:
        rows = self.conn.execute(
            "SELECT * FROM products WHERE active = 1 ORDER BY sku"
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def update(self, product: Product) -> None:
        if product.id is None:
            raise ValueError("Cannot update product without id")
        self.conn.execute(
            """UPDATE products
                  SET name = ?, description = ?, category_id = ?, supplier_id = ?,
                      unit_cost_cents = ?, unit_price_cents = ?,
                      reorder_point = ?, reorder_qty = ?, active = ?,
                      updated_at = datetime('now')
                WHERE id = ?""",
            (
                product.name,
                product.description,
                product.category_id,
                product.supplier_id,
                product.unit_cost_cents,
                product.unit_price_cents,
                product.reorder_point,
                product.reorder_qty,
                int(product.active),
                product.id,
            ),
        )

    def search(self, term: str) -> list[Product]:
        like = f"%{term}%"
        rows = self.conn.execute(
            """SELECT * FROM products
                WHERE (sku LIKE ? OR name LIKE ? OR description LIKE ?)
                  AND active = 1
                ORDER BY sku""",
            (like, like, like),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def bulk_get_by_skus(self, skus: Iterable[str]) -> dict[str, Product]:
        skus = list(skus)
        if not skus:
            return {}
        placeholders = ",".join("?" for _ in skus)
        rows = self.conn.execute(
            f"SELECT * FROM products WHERE sku IN ({placeholders})", skus
        ).fetchall()
        return {r["sku"]: self._from_row(r) for r in rows}

    @staticmethod
    def _from_row(row: sqlite3.Row) -> Product:
        return Product(
            id=row["id"],
            sku=row["sku"],
            name=row["name"],
            description=row["description"],
            category_id=row["category_id"],
            supplier_id=row["supplier_id"],
            unit_cost_cents=row["unit_cost_cents"],
            unit_price_cents=row["unit_price_cents"],
            reorder_point=row["reorder_point"],
            reorder_qty=row["reorder_qty"],
            active=bool(row["active"]),
        )
