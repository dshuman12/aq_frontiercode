from __future__ import annotations

import sqlite3
from typing import Optional

from ..domain import MovementType, StockMovement


class MovementRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def record(self, m: StockMovement) -> StockMovement:
        cur = self.conn.execute(
            """INSERT INTO stock_movements
                 (product_id, location_id, movement_type, quantity,
                  reference_type, reference_id, note, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                m.product_id,
                m.location_id,
                m.movement_type.value,
                m.quantity,
                m.reference_type,
                m.reference_id,
                m.note,
                m.created_by,
            ),
        )
        row = self.conn.execute(
            "SELECT * FROM stock_movements WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return self._from_row(row)

    def list_for_product(self, product_id: int, limit: int = 100) -> list[StockMovement]:
        rows = self.conn.execute(
            """SELECT * FROM stock_movements
                WHERE product_id = ?
                ORDER BY created_at DESC, id DESC
                LIMIT ?""",
            (product_id, limit),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def list_recent(self, limit: int = 100) -> list[StockMovement]:
        rows = self.conn.execute(
            "SELECT * FROM stock_movements ORDER BY created_at DESC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def list_by_reference(self, reference_type: str, reference_id: int) -> list[StockMovement]:
        rows = self.conn.execute(
            """SELECT * FROM stock_movements
                WHERE reference_type = ? AND reference_id = ?
                ORDER BY created_at, id""",
            (reference_type, reference_id),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def list_in_range(
        self,
        start: str,
        end: str,
        product_id: Optional[int] = None,
    ) -> list[StockMovement]:
        if product_id is None:
            rows = self.conn.execute(
                """SELECT * FROM stock_movements
                    WHERE created_at >= ? AND created_at < ?
                    ORDER BY created_at, id""",
                (start, end),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """SELECT * FROM stock_movements
                    WHERE created_at >= ? AND created_at < ? AND product_id = ?
                    ORDER BY created_at, id""",
                (start, end, product_id),
            ).fetchall()
        return [self._from_row(r) for r in rows]

    @staticmethod
    def _from_row(row: sqlite3.Row) -> StockMovement:
        return StockMovement(
            id=row["id"],
            product_id=row["product_id"],
            location_id=row["location_id"],
            movement_type=MovementType(row["movement_type"]),
            quantity=row["quantity"],
            reference_type=row["reference_type"],
            reference_id=row["reference_id"],
            note=row["note"],
            created_by=row["created_by"],
            created_at=row["created_at"],
        )
