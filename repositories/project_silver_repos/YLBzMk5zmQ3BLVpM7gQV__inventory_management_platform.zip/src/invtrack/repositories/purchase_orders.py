from __future__ import annotations

import sqlite3
from typing import Iterable, Optional

from ..domain import POStatus, PurchaseOrder, PurchaseOrderLine


class PurchaseOrderRepository:
    """Loads/saves POs as aggregates: header + lines together.

    Line modifications go through the PO methods rather than a separate
    line repo - this keeps the aggregate boundary explicit. The status
    column is updated by the workflow layer when receipts roll in.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, po: PurchaseOrder) -> PurchaseOrder:
        cur = self.conn.execute(
            """INSERT INTO purchase_orders
                 (po_number, supplier_id, warehouse_id, status,
                  expected_at, notes, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                po.po_number,
                po.supplier_id,
                po.warehouse_id,
                po.status.value,
                po.expected_at,
                po.notes,
                po.created_by,
            ),
        )
        po_id = cur.lastrowid
        new_lines: list[PurchaseOrderLine] = []
        for line in po.lines:
            cur = self.conn.execute(
                """INSERT INTO purchase_order_lines
                     (po_id, product_id, quantity_ordered, unit_cost_cents)
                   VALUES (?, ?, ?, ?)""",
                (po_id, line.product_id, line.quantity_ordered, line.unit_cost_cents),
            )
            new_lines.append(
                PurchaseOrderLine(
                    id=cur.lastrowid,
                    po_id=po_id,
                    product_id=line.product_id,
                    quantity_ordered=line.quantity_ordered,
                    unit_cost_cents=line.unit_cost_cents,
                )
            )
        return PurchaseOrder(
            id=po_id,
            po_number=po.po_number,
            supplier_id=po.supplier_id,
            warehouse_id=po.warehouse_id,
            status=po.status,
            expected_at=po.expected_at,
            notes=po.notes,
            created_by=po.created_by,
            lines=tuple(new_lines),
        )

    def get(self, po_id: int) -> PurchaseOrder | None:
        row = self.conn.execute(
            "SELECT * FROM purchase_orders WHERE id = ?", (po_id,)
        ).fetchone()
        if not row:
            return None
        return self._hydrate(row)

    def get_by_number(self, po_number: str) -> PurchaseOrder | None:
        row = self.conn.execute(
            "SELECT * FROM purchase_orders WHERE po_number = ?", (po_number,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def list_by_status(self, status: POStatus) -> list[PurchaseOrder]:
        rows = self.conn.execute(
            "SELECT * FROM purchase_orders WHERE status = ? ORDER BY created_at DESC",
            (status.value,),
        ).fetchall()
        return [self._hydrate(r) for r in rows]

    def list_open(self) -> list[PurchaseOrder]:
        rows = self.conn.execute(
            """SELECT * FROM purchase_orders
                WHERE status IN (?, ?)
                ORDER BY expected_at""",
            (POStatus.SUBMITTED.value, POStatus.PARTIAL.value),
        ).fetchall()
        return [self._hydrate(r) for r in rows]

    def update_status(
        self,
        po_id: int,
        status: POStatus,
        *,
        timestamp_field: Optional[str] = None,
    ) -> None:
        if timestamp_field:
            assert timestamp_field in {"submitted_at", "received_at"}
            self.conn.execute(
                f"UPDATE purchase_orders SET status = ?, {timestamp_field} = datetime('now') WHERE id = ?",
                (status.value, po_id),
            )
        else:
            self.conn.execute(
                "UPDATE purchase_orders SET status = ? WHERE id = ?",
                (status.value, po_id),
            )

    def increment_received(self, line_id: int, qty: int) -> None:
        self.conn.execute(
            """UPDATE purchase_order_lines
                  SET quantity_received = quantity_received + ?
                WHERE id = ?""",
            (qty, line_id),
        )

    def _hydrate(self, row: sqlite3.Row) -> PurchaseOrder:
        line_rows = self.conn.execute(
            "SELECT * FROM purchase_order_lines WHERE po_id = ? ORDER BY id",
            (row["id"],),
        ).fetchall()
        lines = tuple(
            PurchaseOrderLine(
                id=lr["id"],
                po_id=lr["po_id"],
                product_id=lr["product_id"],
                quantity_ordered=lr["quantity_ordered"],
                quantity_received=lr["quantity_received"],
                unit_cost_cents=lr["unit_cost_cents"],
            )
            for lr in line_rows
        )
        return PurchaseOrder(
            id=row["id"],
            po_number=row["po_number"],
            supplier_id=row["supplier_id"],
            warehouse_id=row["warehouse_id"],
            status=POStatus(row["status"]),
            expected_at=row["expected_at"],
            submitted_at=row["submitted_at"],
            received_at=row["received_at"],
            notes=row["notes"],
            created_by=row["created_by"],
            lines=lines,
        )
