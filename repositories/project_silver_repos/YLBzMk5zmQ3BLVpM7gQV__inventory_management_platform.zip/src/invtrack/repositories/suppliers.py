from __future__ import annotations

import sqlite3

from ..domain import Supplier


class SupplierRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, supplier: Supplier) -> Supplier:
        cur = self.conn.execute(
            """INSERT INTO suppliers (code, name, contact_email, lead_time_days, active)
               VALUES (?, ?, ?, ?, ?)""",
            (
                supplier.code,
                supplier.name,
                supplier.contact_email,
                supplier.lead_time_days,
                int(supplier.active),
            ),
        )
        return Supplier(
            id=cur.lastrowid,
            code=supplier.code,
            name=supplier.name,
            contact_email=supplier.contact_email,
            lead_time_days=supplier.lead_time_days,
            active=supplier.active,
        )

    def get(self, supplier_id: int) -> Supplier | None:
        row = self.conn.execute(
            "SELECT * FROM suppliers WHERE id = ?", (supplier_id,)
        ).fetchone()
        return self._from_row(row) if row else None

    def get_by_code(self, code: str) -> Supplier | None:
        row = self.conn.execute(
            "SELECT * FROM suppliers WHERE code = ?", (code,)
        ).fetchone()
        return self._from_row(row) if row else None

    def list_active(self) -> list[Supplier]:
        rows = self.conn.execute(
            "SELECT * FROM suppliers WHERE active = 1 ORDER BY name"
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def update(self, supplier: Supplier) -> None:
        if supplier.id is None:
            raise ValueError("Cannot update supplier without id")
        self.conn.execute(
            """UPDATE suppliers
                  SET name = ?, contact_email = ?, lead_time_days = ?, active = ?
                WHERE id = ?""",
            (
                supplier.name,
                supplier.contact_email,
                supplier.lead_time_days,
                int(supplier.active),
                supplier.id,
            ),
        )

    @staticmethod
    def _from_row(row: sqlite3.Row) -> Supplier:
        return Supplier(
            id=row["id"],
            code=row["code"],
            name=row["name"],
            contact_email=row["contact_email"],
            lead_time_days=row["lead_time_days"],
            active=bool(row["active"]),
        )
