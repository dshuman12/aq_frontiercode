from __future__ import annotations

import sqlite3

from ..domain import StockTransfer, StockTransferLine, TransferStatus


class StockTransferRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, transfer: StockTransfer) -> StockTransfer:
        cur = self.conn.execute(
            """INSERT INTO stock_transfers
                 (transfer_number, source_location_id, dest_location_id,
                  status, notes, created_by)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                transfer.transfer_number,
                transfer.source_location_id,
                transfer.dest_location_id,
                transfer.status.value,
                transfer.notes,
                transfer.created_by,
            ),
        )
        tid = cur.lastrowid
        for line in transfer.lines:
            self.conn.execute(
                """INSERT INTO stock_transfer_lines (transfer_id, product_id, quantity)
                   VALUES (?, ?, ?)""",
                (tid, line.product_id, line.quantity),
            )
        return self.get(tid)  # type: ignore[return-value]

    def get(self, transfer_id: int) -> StockTransfer | None:
        row = self.conn.execute(
            "SELECT * FROM stock_transfers WHERE id = ?", (transfer_id,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def get_by_number(self, transfer_number: str) -> StockTransfer | None:
        row = self.conn.execute(
            "SELECT * FROM stock_transfers WHERE transfer_number = ?", (transfer_number,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def list_by_status(self, status: TransferStatus) -> list[StockTransfer]:
        rows = self.conn.execute(
            "SELECT * FROM stock_transfers WHERE status = ? ORDER BY initiated_at DESC",
            (status.value,),
        ).fetchall()
        return [self._hydrate(r) for r in rows]

    def update_status(self, transfer_id: int, status: TransferStatus,
                      *, timestamp_field: str | None = None) -> None:
        valid = {"completed_at", "cancelled_at"}
        if timestamp_field and timestamp_field not in valid:
            raise ValueError(f"unknown ts field: {timestamp_field}")
        if timestamp_field:
            self.conn.execute(
                f"UPDATE stock_transfers SET status = ?, {timestamp_field} = datetime('now') "
                "WHERE id = ?",
                (status.value, transfer_id),
            )
        else:
            self.conn.execute(
                "UPDATE stock_transfers SET status = ? WHERE id = ?",
                (status.value, transfer_id),
            )

    def _hydrate(self, row: sqlite3.Row) -> StockTransfer:
        line_rows = self.conn.execute(
            "SELECT * FROM stock_transfer_lines WHERE transfer_id = ? ORDER BY id",
            (row["id"],),
        ).fetchall()
        lines = tuple(
            StockTransferLine(
                id=lr["id"],
                transfer_id=lr["transfer_id"],
                product_id=lr["product_id"],
                quantity=lr["quantity"],
            )
            for lr in line_rows
        )
        return StockTransfer(
            id=row["id"],
            transfer_number=row["transfer_number"],
            source_location_id=row["source_location_id"],
            dest_location_id=row["dest_location_id"],
            status=TransferStatus(row["status"]),
            initiated_at=row["initiated_at"],
            completed_at=row["completed_at"],
            cancelled_at=row["cancelled_at"],
            notes=row["notes"],
            created_by=row["created_by"],
            lines=lines,
        )
