from __future__ import annotations

import sqlite3

from ..domain import StorageLocation


class StorageLocationRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, loc: StorageLocation) -> StorageLocation:
        cur = self.conn.execute(
            """INSERT INTO storage_locations (warehouse_id, code, description, active)
               VALUES (?, ?, ?, ?)""",
            (loc.warehouse_id, loc.code, loc.description, int(loc.active)),
        )
        return StorageLocation(
            id=cur.lastrowid,
            warehouse_id=loc.warehouse_id,
            code=loc.code,
            description=loc.description,
            active=loc.active,
        )

    def get(self, location_id: int) -> StorageLocation | None:
        row = self.conn.execute(
            "SELECT * FROM storage_locations WHERE id = ?", (location_id,)
        ).fetchone()
        return self._from_row(row) if row else None

    def get_by_code(self, warehouse_id: int, code: str) -> StorageLocation | None:
        row = self.conn.execute(
            "SELECT * FROM storage_locations WHERE warehouse_id = ? AND code = ?",
            (warehouse_id, code),
        ).fetchone()
        return self._from_row(row) if row else None

    def list_for_warehouse(self, warehouse_id: int) -> list[StorageLocation]:
        rows = self.conn.execute(
            "SELECT * FROM storage_locations WHERE warehouse_id = ? AND active = 1 ORDER BY code",
            (warehouse_id,),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    @staticmethod
    def _from_row(row: sqlite3.Row) -> StorageLocation:
        return StorageLocation(
            id=row["id"],
            warehouse_id=row["warehouse_id"],
            code=row["code"],
            description=row["description"],
            active=bool(row["active"]),
        )
