from __future__ import annotations

import sqlite3
from typing import Optional

from ..domain import CustomerOrder, CustomerOrderLine, CustomerOrderStatus


class CustomerOrderRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, order: CustomerOrder) -> CustomerOrder:
        cur = self.conn.execute(
            """INSERT INTO customer_orders
                 (order_number, customer_name, customer_email, warehouse_id,
                  status, notes, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                order.order_number,
                order.customer_name,
                order.customer_email,
                order.warehouse_id,
                order.status.value,
                order.notes,
                order.created_by,
            ),
        )
        order_id = cur.lastrowid
        lines: list[CustomerOrderLine] = []
        for line in order.lines:
            cur = self.conn.execute(
                """INSERT INTO customer_order_lines
                     (order_id, product_id, quantity, unit_price_cents)
                   VALUES (?, ?, ?, ?)""",
                (order_id, line.product_id, line.quantity, line.unit_price_cents),
            )
            lines.append(
                CustomerOrderLine(
                    id=cur.lastrowid,
                    order_id=order_id,
                    product_id=line.product_id,
                    quantity=line.quantity,
                    unit_price_cents=line.unit_price_cents,
                )
            )
        result = self.get(order_id)
        assert result is not None
        return result

    def get(self, order_id: int) -> CustomerOrder | None:
        row = self.conn.execute(
            "SELECT * FROM customer_orders WHERE id = ?", (order_id,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def get_by_number(self, order_number: str) -> CustomerOrder | None:
        row = self.conn.execute(
            "SELECT * FROM customer_orders WHERE order_number = ?", (order_number,)
        ).fetchone()
        return self._hydrate(row) if row else None

    def list_by_status(self, status: CustomerOrderStatus) -> list[CustomerOrder]:
        rows = self.conn.execute(
            "SELECT * FROM customer_orders WHERE status = ? ORDER BY created_at DESC",
            (status.value,),
        ).fetchall()
        return [self._hydrate(r) for r in rows]

    def update_status(
        self,
        order_id: int,
        status: CustomerOrderStatus,
        *,
        timestamp_field: Optional[str] = None,
    ) -> None:
        valid_fields = {"confirmed_at", "shipped_at", "cancelled_at"}
        if timestamp_field is not None and timestamp_field not in valid_fields:
            raise ValueError(f"unknown timestamp field: {timestamp_field}")
        if timestamp_field:
            self.conn.execute(
                f"UPDATE customer_orders SET status = ?, {timestamp_field} = datetime('now') WHERE id = ?",
                (status.value, order_id),
            )
        else:
            self.conn.execute(
                "UPDATE customer_orders SET status = ? WHERE id = ?",
                (status.value, order_id),
            )

    def increment_picked(self, line_id: int, qty: int) -> None:
        self.conn.execute(
            """UPDATE customer_order_lines
                  SET quantity_picked = quantity_picked + ?
                WHERE id = ?""",
            (qty, line_id),
        )

    def increment_shipped(self, line_id: int, qty: int) -> None:
        self.conn.execute(
            """UPDATE customer_order_lines
                  SET quantity_shipped = quantity_shipped + ?
                WHERE id = ?""",
            (qty, line_id),
        )

    def _hydrate(self, row: sqlite3.Row) -> CustomerOrder:
        line_rows = self.conn.execute(
            "SELECT * FROM customer_order_lines WHERE order_id = ? ORDER BY id",
            (row["id"],),
        ).fetchall()
        lines = tuple(
            CustomerOrderLine(
                id=lr["id"],
                order_id=lr["order_id"],
                product_id=lr["product_id"],
                quantity=lr["quantity"],
                quantity_picked=lr["quantity_picked"],
                quantity_shipped=lr["quantity_shipped"],
                unit_price_cents=lr["unit_price_cents"],
            )
            for lr in line_rows
        )
        return CustomerOrder(
            id=row["id"],
            order_number=row["order_number"],
            customer_name=row["customer_name"],
            customer_email=row["customer_email"],
            warehouse_id=row["warehouse_id"],
            status=CustomerOrderStatus(row["status"]),
            confirmed_at=row["confirmed_at"],
            shipped_at=row["shipped_at"],
            cancelled_at=row["cancelled_at"],
            notes=row["notes"],
            created_by=row["created_by"],
            lines=lines,
        )
