from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AuditEvent:
    id: int | None
    event_type: str
    entity_type: str
    entity_id: int | None
    actor: str | None
    payload: dict[str, Any]
    created_at: str | None = None


class AuditRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def record(
        self,
        event_type: str,
        entity_type: str,
        entity_id: int | None,
        *,
        actor: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> AuditEvent:
        cur = self.conn.execute(
            """INSERT INTO audit_events (event_type, entity_type, entity_id, actor, payload)
               VALUES (?, ?, ?, ?, ?)""",
            (event_type, entity_type, entity_id, actor,
             json.dumps(payload, sort_keys=True) if payload is not None else None),
        )
        row = self.conn.execute(
            "SELECT * FROM audit_events WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return self._from_row(row)

    def list_for_entity(self, entity_type: str, entity_id: int) -> list[AuditEvent]:
        rows = self.conn.execute(
            """SELECT * FROM audit_events
                WHERE entity_type = ? AND entity_id = ?
                ORDER BY created_at, id""",
            (entity_type, entity_id),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def list_recent(self, limit: int = 100) -> list[AuditEvent]:
        rows = self.conn.execute(
            "SELECT * FROM audit_events ORDER BY created_at DESC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._from_row(r) for r in rows]

    @staticmethod
    def _from_row(row: sqlite3.Row) -> AuditEvent:
        payload = json.loads(row["payload"]) if row["payload"] else {}
        return AuditEvent(
            id=row["id"],
            event_type=row["event_type"],
            entity_type=row["entity_type"],
            entity_id=row["entity_id"],
            actor=row["actor"],
            payload=payload,
            created_at=row["created_at"],
        )
