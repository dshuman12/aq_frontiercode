from __future__ import annotations

import sqlite3

from ..domain import Warehouse


class WarehouseRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def create(self, warehouse: Warehouse) -> Warehouse:
        cur = self.conn.execute(
            "INSERT INTO warehouses (code, name, address, active) VALUES (?, ?, ?, ?)",
            (warehouse.code, warehouse.name, warehouse.address, int(warehouse.active)),
        )
        return Warehouse(
            id=cur.lastrowid,
            code=warehouse.code,
            name=warehouse.name,
            address=warehouse.address,
            active=warehouse.active,
        )

    def get(self, warehouse_id: int) -> Warehouse | None:
        row = self.conn.execute(
            "SELECT * FROM warehouses WHERE id = ?", (warehouse_id,)
        ).fetchone()
        return self._from_row(row) if row else None

    def get_by_code(self, code: str) -> Warehouse | None:
        row = self.conn.execute(
            "SELECT * FROM warehouses WHERE code = ?", (code,)
        ).fetchone()
        return self._from_row(row) if row else None

    def list_active(self) -> list[Warehouse]:
        rows = self.conn.execute(
            "SELECT * FROM warehouses WHERE active = 1 ORDER BY code"
        ).fetchall()
        return [self._from_row(r) for r in rows]

    @staticmethod
    def _from_row(row: sqlite3.Row) -> Warehouse:
        return Warehouse(
            id=row["id"],
            code=row["code"],
            name=row["name"],
            address=row["address"],
            active=bool(row["active"]),
        )
