from __future__ import annotations

import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class Alert:
    id: int | None
    alert_type: str
    subject_type: str
    subject_id: int
    severity: str
    message: str
    raised_at: str | None = None
    acknowledged_at: str | None = None
    acknowledged_by: str | None = None
    resolved_at: str | None = None


class AlertRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def find_open(
        self,
        alert_type: str,
        subject_type: str,
        subject_id: int,
    ) -> Alert | None:
        row = self.conn.execute(
            """SELECT * FROM alerts
                WHERE alert_type = ? AND subject_type = ? AND subject_id = ?
                  AND resolved_at IS NULL
                ORDER BY raised_at DESC LIMIT 1""",
            (alert_type, subject_type, subject_id),
        ).fetchone()
        return self._from_row(row) if row else None

    def raise_alert(
        self,
        alert_type: str,
        subject_type: str,
        subject_id: int,
        severity: str,
        message: str,
    ) -> Alert:
        cur = self.conn.execute(
            """INSERT INTO alerts (alert_type, subject_type, subject_id, severity, message)
               VALUES (?, ?, ?, ?, ?)""",
            (alert_type, subject_type, subject_id, severity, message),
        )
        return self._from_row(
            self.conn.execute("SELECT * FROM alerts WHERE id = ?", (cur.lastrowid,)).fetchone()
        )

    def list_open(self, alert_type: str | None = None) -> list[Alert]:
        if alert_type:
            rows = self.conn.execute(
                "SELECT * FROM alerts WHERE resolved_at IS NULL AND alert_type = ? "
                "ORDER BY severity DESC, raised_at",
                (alert_type,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM alerts WHERE resolved_at IS NULL "
                "ORDER BY severity DESC, raised_at"
            ).fetchall()
        return [self._from_row(r) for r in rows]

    def acknowledge(self, alert_id: int, actor: str) -> None:
        self.conn.execute(
            "UPDATE alerts SET acknowledged_at = datetime('now'), acknowledged_by = ? "
            "WHERE id = ?",
            (actor, alert_id),
        )

    def resolve(self, alert_id: int) -> None:
        self.conn.execute(
            "UPDATE alerts SET resolved_at = datetime('now') WHERE id = ?",
            (alert_id,),
        )

    def resolve_open_for_subject(
        self,
        alert_type: str,
        subject_type: str,
        subject_id: int,
    ) -> int:
        cur = self.conn.execute(
            """UPDATE alerts SET resolved_at = datetime('now')
                WHERE alert_type = ? AND subject_type = ? AND subject_id = ?
                  AND resolved_at IS NULL""",
            (alert_type, subject_type, subject_id),
        )
        return cur.rowcount

    @staticmethod
    def _from_row(row: sqlite3.Row) -> Alert:
        return Alert(
            id=row["id"],
            alert_type=row["alert_type"],
            subject_type=row["subject_type"],
            subject_id=row["subject_id"],
            severity=row["severity"],
            message=row["message"],
            raised_at=row["raised_at"],
            acknowledged_at=row["acknowledged_at"],
            acknowledged_by=row["acknowledged_by"],
            resolved_at=row["resolved_at"],
        )
