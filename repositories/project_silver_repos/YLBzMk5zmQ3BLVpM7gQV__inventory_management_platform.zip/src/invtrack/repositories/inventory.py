from __future__ import annotations

import sqlite3
from typing import Iterable

from ..domain import InventoryLevel


class InventoryRepository:
    """Inventory levels are stored per (product, location).

    The repo exposes raw delta operations. Business rules - like 'don't
    create negative inventory' or 'reservations can't exceed quantity' -
    are enforced both by service layer logic and by CHECK constraints in
    the schema. We rely on those constraints as a final safety net.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def get(self, product_id: int, location_id: int) -> InventoryLevel | None:
        row = self.conn.execute(
            "SELECT * FROM inventory_levels WHERE product_id = ? AND location_id = ?",
            (product_id, location_id),
        ).fetchone()
        return self._from_row(row) if row else None

    def ensure_row(self, product_id: int, location_id: int) -> None:
        """Make sure a (product, location) row exists, with zero quantities."""
        self.conn.execute(
            """INSERT OR IGNORE INTO inventory_levels (product_id, location_id, quantity, reserved)
               VALUES (?, ?, 0, 0)""",
            (product_id, location_id),
        )

    def adjust_quantity(self, product_id: int, location_id: int, delta: int) -> InventoryLevel:
        """Apply a signed delta. Negative delta decreases stock.

        Raises sqlite3.IntegrityError if the resulting quantity would be
        negative or would violate reserved <= quantity.
        """
        self.ensure_row(product_id, location_id)
        self.conn.execute(
            """UPDATE inventory_levels
                  SET quantity = quantity + ?, updated_at = datetime('now')
                WHERE product_id = ? AND location_id = ?""",
            (delta, product_id, location_id),
        )
        result = self.get(product_id, location_id)
        assert result is not None
        return result

    def adjust_reservation(self, product_id: int, location_id: int, delta: int) -> InventoryLevel:
        self.ensure_row(product_id, location_id)
        self.conn.execute(
            """UPDATE inventory_levels
                  SET reserved = reserved + ?, updated_at = datetime('now')
                WHERE product_id = ? AND location_id = ?""",
            (delta, product_id, location_id),
        )
        result = self.get(product_id, location_id)
        assert result is not None
        return result

    def levels_for_product(self, product_id: int) -> list[InventoryLevel]:
        rows = self.conn.execute(
            "SELECT * FROM inventory_levels WHERE product_id = ?", (product_id,)
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def levels_for_location(self, location_id: int) -> list[InventoryLevel]:
        rows = self.conn.execute(
            "SELECT * FROM inventory_levels WHERE location_id = ?", (location_id,)
        ).fetchall()
        return [self._from_row(r) for r in rows]

    def total_quantity(self, product_id: int) -> int:
        row = self.conn.execute(
            "SELECT COALESCE(SUM(quantity), 0) AS q FROM inventory_levels WHERE product_id = ?",
            (product_id,),
        ).fetchone()
        return int(row["q"])

    def total_available(self, product_id: int) -> int:
        row = self.conn.execute(
            """SELECT COALESCE(SUM(quantity - reserved), 0) AS q
                 FROM inventory_levels WHERE product_id = ?""",
            (product_id,),
        ).fetchone()
        return int(row["q"])

    def bulk_totals(self, product_ids: Iterable[int]) -> dict[int, int]:
        ids = list(product_ids)
        if not ids:
            return {}
        ph = ",".join("?" for _ in ids)
        rows = self.conn.execute(
            f"""SELECT product_id, COALESCE(SUM(quantity), 0) AS q
                  FROM inventory_levels
                 WHERE product_id IN ({ph})
                 GROUP BY product_id""",
            ids,
        ).fetchall()
        return {r["product_id"]: int(r["q"]) for r in rows}

    @staticmethod
    def _from_row(row: sqlite3.Row) -> InventoryLevel:
        return InventoryLevel(
            id=row["id"],
            product_id=row["product_id"],
            location_id=row["location_id"],
            quantity=row["quantity"],
            reserved=row["reserved"],
        )
