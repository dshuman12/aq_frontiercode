# invtrack

Inventory tracking for small/medium warehousing operations. SQLite-backed,
single-process, CLI-driven. Designed to run on one box (a back-office laptop, a
Raspberry Pi in a stockroom, a small VM) without a separate database server.

[![ci](https://github.com/invtrack/invtrack/actions/workflows/ci.yml/badge.svg)](https://github.com/invtrack/invtrack/actions/workflows/ci.yml)

---

## What it does

- Tracks **products** (with categories, suppliers, costs, prices, reorder
  thresholds) across **warehouses** and **storage locations**.
- Records every change to inventory as a **stock movement** so the audit trail
  is reproducible.
- Implements the full lifecycle for **purchase orders** (draft → submitted →
  partial → received) and **customer orders** (draft → confirmed → picking →
  shipped) with reservation handling.
- Supports **inter-location transfers**, **cycle counts** with variance
  thresholds, and **inventory reconciliation**.
- Provides **reporting**: stock summary, low-stock report, valuation, movement
  velocity, top-shipped products, reorder suggestions grouped by supplier.
- Runs **background jobs** for low-stock alerting, overdue PO detection, and
  stale-reservation auditing.
- Imports/exports CSV for product master, suppliers, categories, and opening
  stock; round-trip-safe.
- Exposes both a **CLI** and an **HTTP API** (FastAPI) backed by the same
  service layer, with API-key and JWT authentication and a
  viewer/operator/admin role ladder.

It is intentionally **not** a SaaS, ERP, or warehouse management system. It is
a focused tool for a single team.

---

## Quick start

### Local development

```sh
git clone <repo-url> invtrack
cd invtrack

# Create a venv and install dev dependencies
python -m venv .venv
source .venv/bin/activate
make dev-install

# Initialise the database (creates data/invtrack.db)
make init

# Optional: seed a small demo dataset
make seed-demo

# Try the CLI
invtrack stock show WID-001
invtrack report stock-summary
```

### Running with Docker

```sh
docker compose build
mkdir -p data
docker compose run --rm invtrack init
docker compose run --rm invtrack product list
```

The `data/` directory is bind-mounted into the container at `/data`, so the
database survives `docker compose down` and image rebuilds.

---

## Architecture

```
                         ┌────────────────────────────┐
                         │           CLI              │
                         │  (invtrack.cli)            │
                         └────────────┬───────────────┘
                                      │
        ┌────────────┬────────────────┼─────────────────┬─────────────┐
        ▼            ▼                ▼                 ▼             ▼
   Catalog       Inventory      Purchase Order    Customer Order   Reporting /
   Service       Service          Service           Service        Reconcil.
                                  Transfer Service                 Jobs
        │            │                │                 │             │
        └─────┬──────┴────────────────┴─────────────────┴─────────────┘
              ▼
        ┌──────────────────────────────────────────────┐
        │             Repositories                      │
        │  (one per aggregate; thin SQL wrappers)       │
        └──────────────────────────────────────────────┘
              │
              ▼
        ┌──────────────────────────────────────────────┐
        │          db helpers + schema migrations       │
        └──────────────────────────────────────────────┘
              │
              ▼
                       SQLite (data/invtrack.db)
```

Layers, top to bottom:

- **`invtrack.cli`** — argparse subcommands. The CLI never reaches into
  repositories directly; it always goes through services. This is the
  public-facing operational interface.
- **`invtrack.services`** — owns transactions, validates business rules, emits
  audit events, and orchestrates multiple repositories. Anything that
  changes inventory levels goes through `InventoryService`, so the audit
  trail in `stock_movements` is always complete.
- **`invtrack.repositories`** — one class per aggregate (`ProductRepository`,
  `PurchaseOrderRepository`, …). Each takes a connection in its
  constructor; no global state. Aggregate-loading repos (POs, customer
  orders) load header+lines together.
- **`invtrack.domain`** — frozen dataclasses and string enums. No
  behaviour beyond simple derived properties (`available`,
  `outstanding`).
- **`invtrack.reporting`** — read-only analytical queries returning
  dataclasses.
- **`invtrack.io`** — CSV import/export. Imports run inside one transaction
  per file: any row failure rolls everything back with a 1-based row number.
- **`invtrack.jobs`** — background-style operational tasks. Each job is
  idempotent and is wrapped by `run_job` to record a `job_runs` row with
  start/finish/error.
- **`invtrack.db`** — connection helpers and forward-only schema
  migrations.

### Schema evolution

Schema versions are append-only. The `schema_version` table stores every
applied migration, and `migrate(conn)` brings the database forward from any
prior version. The current head is **v7**. See `src/invtrack/db/schema.py` for
the full migration list:

| Version | Adds                                                           |
|---------|----------------------------------------------------------------|
| v1      | categories, suppliers, products, warehouses                    |
| v2      | storage locations, inventory levels, stock movements           |
| v3      | purchase orders, customer orders (with lines)                  |
| v4      | hot-path indexes (movements by ref, PO by expected_at, etc.)   |
| v5      | stock transfers between locations                              |
| v6      | stock counts (cycle counts) with snapshotted system qty        |
| v7      | alerts, audit_events, job_runs                                 |

To add a new migration, append a `(version, function)` tuple to `MIGRATIONS`
and write the migration body. Never edit a published migration in place — the
test suite catches divergence between the schema and the migration log.

---

## Operational workflows

### Daily catalog/inventory ops

```sh
# Catalog
invtrack supplier add ACME "Acme Corporation" --email orders@acme.test --lead-time 5
invtrack category add Widgets
invtrack product add WID-001 "Standard Widget" \
    --supplier ACME --category Widgets \
    --cost 100 --price 250 \
    --reorder-point 20 --reorder-qty 100

# Warehouses & locations
invtrack warehouse add MAIN "Main DC"
invtrack location add MAIN A-01 --description "Aisle A bin 01"
invtrack location add MAIN A-02

# Goods movement
invtrack stock receive WID-001 MAIN/A-01 50
invtrack stock ship    WID-001 MAIN/A-01 4
invtrack stock adjust  WID-001 MAIN/A-01 -1 --note "damaged in pick"
invtrack stock show    WID-001
```

### Purchase order lifecycle

```sh
# Draft a PO with two lines
invtrack po draft PO-2025-001 ACME MAIN \
    WID-001=100@95 GAD-001=20@350

# Submit to the supplier
invtrack po submit 1

# Receive partially - first line is line_id 1, location MAIN/A-01
invtrack po receive 1 1=40,MAIN/A-01

# Later, complete the receipt
invtrack po receive 1 1=60,MAIN/A-01 2=20,MAIN/A-01

invtrack po list                    # currently open POs
invtrack po list --status received  # filter by status
```

A PO transitions to `partial` after any non-empty receipt and to `received`
once every line's `quantity_received == quantity_ordered`. Cancelling a
partially-received PO is rejected — close out the remaining receipts first.

### Customer order lifecycle

Customer orders aren't yet exposed via the CLI; use the service directly from
Python or another caller:

```python
from invtrack.db import connect
from invtrack.db.schema import migrate
from invtrack.services.order_service import CustomerOrderService

conn = connect("data/invtrack.db")
migrate(conn)
orders = CustomerOrderService(conn)

order = orders.create_draft(
    "CO-2025-001", "Northgate Hardware",
    warehouse_id=1,
    lines=[(product_id, 4, 250)],   # (product_id, qty, unit_price_cents)
)
orders.confirm(order.id)            # reserves stock
orders.pick(order.id, [(line_id, 4, location_id)])
orders.ship(order.id)               # converts reservation into outbound
```

### Inventory reconciliation (cycle counts)

```python
from invtrack.services.reconciliation_service import ReconciliationService

rec = ReconciliationService(conn)
count = rec.start_count("CC-2025-W04", location_id=1, counted_by="alice")
rec.record_count(count.id, product_id=42, counted_qty=37)
# variance against system_qty is shown in reports; large variances
# are blocked unless an override note is supplied
rec.apply_count(count.id)
```

---

## Reporting and exports

```sh
invtrack report stock-summary
invtrack report low-stock
invtrack report valuation

invtrack export products       data/products.csv
invtrack export stock-summary  data/summary.csv
invtrack export low-stock      data/low-stock.csv
invtrack export valuation      data/valuation.csv
invtrack export movements      data/movements.csv

# CSV imports - the inverse of the corresponding exports
invtrack import categories     data/categories.csv
invtrack import suppliers      data/suppliers.csv
invtrack import products       data/products.csv
invtrack import opening-stock  data/opening.csv
```

### Background jobs

```sh
invtrack jobs run low_stock           # raise/resolve low-stock alerts
invtrack jobs run overdue_po          # raise/resolve PO-overdue alerts
invtrack jobs run stale_reservations  # flag confirmed orders sitting too long

invtrack jobs list                    # last 20 job runs
invtrack alerts list                  # currently open alerts
invtrack alerts resolve 17            # resolve alert id 17
```

Jobs are idempotent. `low_stock` raises one alert per product currently below
its reorder point and resolves any open low-stock alert whose product is back
above threshold; running it twice in a row produces no duplicates.

### Scheduling

There is no built-in scheduler. The intended pattern is to invoke jobs via
host cron or systemd timers:

```cron
*/15 * * * * /usr/local/bin/invtrack jobs run low_stock  >> /var/log/invtrack/low_stock.log 2>&1
0 6   * * * /usr/local/bin/invtrack jobs run overdue_po >> /var/log/invtrack/overdue_po.log 2>&1
```

Or in compose:

```sh
docker compose --profile jobs run --rm jobs jobs run low_stock
```

---

## HTTP API

The same service layer that backs the CLI is exposed over HTTP via FastAPI.
Run it locally with `make api-dev`, in production with `make api-run`, or via
docker compose with `docker compose up api`.

### Architecture

```
        ┌──────────────────────────────────────────┐
        │   FastAPI app  (invtrack.api.main:app)   │
        │   ─────────────────────────────────────  │
        │   request_id middleware + json logging   │
        │   error handlers (NotFound→404, ...)     │
        └─────────────────┬────────────────────────┘
                          │
        ┌─────────────────┼────────────────────────┐
        │                 ▼                        │
        │   Routers (api/routers/*.py)             │
        │   - validate body via Pydantic           │
        │   - resolve services via Depends()       │
        │   - enforce role guards                  │
        │   - re-shape domain → *Read responses    │
        └─────────────────┬────────────────────────┘
                          │
                          ▼
                  Service layer
              (unchanged from the CLI)
                          │
                          ▼
                   Repositories
                          │
                          ▼
                       SQLite
```

The HTTP layer is purely a delivery mechanism. **No business logic lives in
routers** — they parse the request, call a service, and serialise the result.
This keeps parity with the CLI guaranteed: any operation reachable over HTTP
is reachable through `python -m invtrack.cli` against the same database, and
vice versa.

### Routes

All endpoints under `/api/v1` require authentication (see below).
`/health/live` and `/health/ready` are public.

| Resource         | Routes                                                                 |
|------------------|------------------------------------------------------------------------|
| products         | `GET/POST /products`, `GET/PUT /products/{sku}/reorder`                |
| suppliers        | `GET/POST /suppliers`, `GET/PUT /suppliers/{code}`                     |
| warehouses       | `GET/POST /warehouses`, nested `/locations`                            |
| inventory        | `GET /inventory/levels/{sku}`, `POST /inventory/{receive,ship,adjust,reserve}`, `GET /inventory/movements` |
| purchase-orders  | `GET/POST /purchase-orders`, `POST /{id}/{submit,receive,cancel}`      |
| customer-orders  | `GET/POST /customer-orders`, `POST /{id}/{confirm,pick,ship,cancel}`   |
| alerts           | `GET /alerts`, `POST /alerts/{id}/resolve`                             |
| reports          | `GET /reports/{stock-summary,low-stock,valuation}`                     |

The full machine-readable spec is at `/openapi.json` (or `make api-docs`).
Swagger UI and ReDoc render at `/docs` and `/redoc` respectively.

### Authentication

Two schemes are supported in parallel; pick whichever fits your environment.

**API keys** (`Authorization: ApiKey <key>`)

Keys are loaded from a JSON file at `INVTRACK_API_KEYS` (default
`/data/api_keys.json`). The file is reread on the first request after a
restart; rotate keys by editing the file and restarting the api container.

```json
{
  "keys": [
    {"name": "warehouse-cli",  "key": "wh_KaIO...3D",   "role": "operator"},
    {"name": "reporting-bot",  "key": "rep_aF9q...9k",  "role": "viewer"},
    {"name": "platform-admin", "key": "adm_zNn...4Q",   "role": "admin"}
  ]
}
```

**JWT** (`Authorization: Bearer <token>`)

Tokens are verified against `INVTRACK_JWT_SECRET` using HS256. invtrack does
**not** mint tokens; it only verifies them. Wire this up to whatever identity
provider issues sessions for your operators (Okta, Auth0, Keycloak, your own
OAuth server). Required claims:

| Claim  | Meaning                                |
|--------|----------------------------------------|
| `sub`  | Principal name (recorded in audit log) |
| `role` | One of `viewer`, `operator`, `admin`   |

Tokens with unknown roles, missing claims, or bad signatures are rejected
with 401. If `INVTRACK_JWT_SECRET` is unset, `Bearer` tokens are not honoured
at all — operators must opt in explicitly.

### Role hierarchy

```
viewer  ──── reads everything: GET /products, /reports, /alerts, ...
   │
operator ─── viewer + most mutations: stock movements, POs, customer orders,
   │         resolving alerts, importing CSVs
   │
admin ────── operator + warehouse creation, supplier updates, key rotation
```

Each route declares the minimum role required via a FastAPI dependency
(`require_viewer`, `require_operator`, `require_admin`). Calls below the
required role return 403 with a body that names the missing role:

```json
{"detail": "requires admin role; you have operator"}
```

### Request/response conventions

- **Pagination**: `?page=1&page_size=50` on any list endpoint. Max page size
  is 500. Responses wrap items in `{items, total, page, page_size}`.
- **Sorting**: `?sort=name` ascending, `?sort=-name` descending. Allowed
  columns are validated per-endpoint.
- **Filtering**: `?q=...` for free-text search where supported,
  plus per-resource filters (`?status=draft`, `?customer=Acme`,
  `?include_resolved=true`).
- **Errors** follow an RFC 7807-flavoured shape:

  ```json
  {
    "type": "urn:invtrack:insufficient-stock",
    "title": "Insufficient stock",
    "status": 409,
    "detail": "Insufficient stock for product 42: requested 200, available 100",
    "product_id": 42, "requested": 200, "available": 100
  }
  ```

- **Request IDs**: every response carries `x-request-id`. Pass your own to
  trace requests across services.

### Curl examples

```sh
# Liveness (no auth)
curl http://localhost:8000/health/live

# List products as a viewer
curl -H "Authorization: ApiKey rep_aF9q...9k" \
     http://localhost:8000/api/v1/products

# Search + paginate
curl -H "Authorization: ApiKey rep_aF9q...9k" \
     'http://localhost:8000/api/v1/products?q=widget&page=1&page_size=20&sort=-updated_at'

# Create a product (operator)
curl -H "Authorization: ApiKey wh_KaIO...3D" \
     -H "Content-Type: application/json" \
     -d '{"sku":"WID-001","name":"Standard Widget","unit_cost_cents":100,"unit_price_cents":250,"reorder_point":20,"reorder_qty":100}' \
     http://localhost:8000/api/v1/products

# Receive 50 into MAIN/A-01
curl -H "Authorization: ApiKey wh_KaIO...3D" \
     -H "Content-Type: application/json" \
     -d '{"sku":"WID-001","location_id":1,"quantity":50}' \
     http://localhost:8000/api/v1/inventory/receive

# Draft and submit a PO
curl -H "Authorization: ApiKey wh_KaIO...3D" \
     -H "Content-Type: application/json" \
     -d '{
           "po_number":"PO-2025-001",
           "supplier_code":"ACME",
           "warehouse_code":"MAIN",
           "lines":[{"sku":"WID-001","quantity":100,"unit_cost_cents":95}]
         }' \
     http://localhost:8000/api/v1/purchase-orders
curl -X POST -H "Authorization: ApiKey wh_KaIO...3D" \
     http://localhost:8000/api/v1/purchase-orders/1/submit

# Run reports
curl -H "Authorization: ApiKey rep_aF9q...9k" \
     http://localhost:8000/api/v1/reports/low-stock
curl -H "Authorization: ApiKey rep_aF9q...9k" \
     http://localhost:8000/api/v1/reports/valuation

# JWT instead of API key
TOKEN=$(my-idp-tool issue-token --role operator --sub alice)
curl -H "Authorization: Bearer $TOKEN" \
     http://localhost:8000/api/v1/products
```

### Local development

```sh
make dev-install    # installs [dev,api] extras
make api-dev        # uvicorn --reload, text logs, DEBUG level, 127.0.0.1:8000
make api-test       # pytest -q tests/test_api_*.py only
make api-docs       # dump openapi.json
```

`api-dev` sets `INVTRACK_DISABLE_AUTH=0` by default. To skip auth while
poking at endpoints with curl, export `INVTRACK_DISABLE_AUTH=1` before
running it — anonymous requests will be treated as `admin`. **Do not** set
this in any production-adjacent environment.

### Deployment

The `api` service in `docker-compose.yml` is the canonical deployment shape.
For a single-host install:

```sh
# .env
INVTRACK_LOG_LEVEL=INFO
INVTRACK_LOG_FORMAT=json
INVTRACK_JWT_SECRET=<32+ bytes of randomness>
INVTRACK_API_PORT=8000

# api keys mounted into /data
mkdir -p data
cat > data/api_keys.json <<'EOF'
{"keys":[
  {"name":"ops","key":"REPLACE_ME","role":"operator"}
]}
EOF

docker compose up -d api
```

For multi-host or behind a load balancer, expose only `/api/v1/*` to the
internet — `/health/*` should be reachable from the LB but ideally not from
the public side. `/openapi.json`, `/docs`, and `/redoc` are convenient but
also leak the API surface; gate them at the LB if your operators are
internal-only.

The api process is single-threaded SQLite, so horizontal scaling means
sharing a `/data` volume between replicas (network filesystem with proper
locking) — usually not what you want for invtrack's scale. The expected
deployment is **one api replica** per database. If you need higher
throughput, your bottleneck is more likely the data shape than the runtime.

### API troubleshooting

**Container restarts after `unhealthy` for ~30s**

The healthcheck waits for `/health/ready`, which runs migrations on its
first call. On a fresh `/data` volume the migration takes a couple of
seconds; the `start_period: 30s` in the compose file accounts for this. If
the api stays unhealthy past the start period, check:

```sh
docker compose logs api | tail -50
docker compose exec api invtrack init   # rerun migrations manually
```

**`401 missing Authorization header` on every request**

Auth is enforced unless `INVTRACK_DISABLE_AUTH=1`. Either:

- Send `Authorization: ApiKey <key>` with a key from your `api_keys.json`,
- Send `Authorization: Bearer <token>` after setting `INVTRACK_JWT_SECRET`,
- Or set `INVTRACK_DISABLE_AUTH=1` (only acceptable for local development).

**`401 invalid api key` after rotating keys**

The api caches the parsed `api_keys.json` for the lifetime of the
process. After editing the file, restart the api container:

```sh
docker compose restart api
```

**`409 Insufficient stock` on a confirm / ship**

The body includes `product_id`, `requested`, and `available`. Either ship
less, run a cycle count to find the missing units, or wait for a PO
receipt that's still in `partial`.

**`500 Internal Server Error` with no detail**

Check the json logs for the `request_id` in the failed response's
`x-request-id` header:

```sh
docker compose logs api | grep <request-id>
```

The handler emits a full traceback at ERROR level for any unhandled
exception.

---

## Development & testing

```sh
make dev-install   # editable install + pytest + pytest-cov + api extras
make test          # full pytest suite
make test-cov      # with coverage report
make api-test      # only the API integration tests
make docker-test   # build the image and run pytest inside it
```

The test suite covers:

- repository CRUD against an in-memory database (`tests/test_repositories_basic.py`)
- service-layer business rules and validation (`tests/test_*_service.py`)
- end-to-end workflow tests for POs, customer orders, transfers, reconciliation
- CSV import/export round-trip (`tests/test_csv_io.py`)
- audit event emission (`tests/test_audit.py`)
- reporting/analytics queries (`tests/test_reporting.py`)
- background jobs (`tests/test_jobs.py`)
- **concurrency** — multiple threads with separate connections to a real
  on-disk SQLite, exercising the receive/ship/reserve/release race window
  (`tests/test_concurrency.py`)
- **API integration** — every router exercised through `fastapi.testclient`,
  with both auth-disabled and full role-enforcement modes
  (`tests/test_api_*.py`)

The `conftest.py` `conn` fixture provisions a fresh in-memory db with all
migrations applied for every test. The `client` and `authed_client`
fixtures construct a fresh FastAPI app per test against a temp-file db so
multi-connection scenarios behave correctly.

### Adding a new feature

1. Pick the layer it belongs to. Catalog data goes through `CatalogService`;
   anything that mutates `inventory_levels` goes through `InventoryService`;
   cross-aggregate orchestration (PO receive, customer ship) lives in its
   own service.
2. Add domain types if needed under `invtrack/domain/`.
3. Add or extend a repository under `invtrack/repositories/`.
4. Implement the operation in a service. Use the `transaction()` context
   manager for atomicity. Emit audit events for state transitions.
5. Add tests at every layer that you've touched.
6. If the operation should be reachable over HTTP, add the schema in
   `api/schemas.py`, the route in `api/routers/<resource>.py`, and an
   integration test in `tests/test_api_<resource>.py`.

---

## Troubleshooting

### `sqlite3.OperationalError: database is locked`

Another connection has an open write transaction. The InventoryService's
operations are wrapped in `BEGIN ... COMMIT`, so this is most often caused
by:

- a long-running interactive `sqlite3` shell with an open transaction, or
- many concurrent CLI invocations against the same db file.

For interactive ad-hoc queries, prefer read-only access:

```sh
sqlite3 -readonly data/invtrack.db "SELECT * FROM inventory_levels LIMIT 10"
```

### `IntegrityError: CHECK constraint failed: inventory_levels`

The schema has CHECK constraints (`quantity >= 0`, `reserved <= quantity`).
Hitting one means a code path bypassed `InventoryService` and wrote directly
to `inventory_levels`. Search the codebase for `INSERT INTO inventory_levels`
or `UPDATE inventory_levels` outside the inventory repository.

### Reports look wrong after a manual SQL edit

`stock_movements` is the source of truth for the audit trail. If you edited
`inventory_levels` directly, the on-hand quantity will be out of step with the
sum of movements. To verify:

```sh
sqlite3 data/invtrack.db <<'SQL'
SELECT product_id,
       (SELECT quantity FROM inventory_levels il
         WHERE il.product_id = m.product_id LIMIT 1) AS recorded,
       SUM(quantity) AS movement_sum
  FROM stock_movements m
 GROUP BY product_id;
SQL
```

If those don't match, run a cycle count against the affected location to
re-baseline.

### Migrations fail to apply

`migrate(conn)` is forward-only. If a migration crashes mid-application
(disk full, permission error), the partial changes are kept. The fix is
to back up the db, fix the underlying environmental issue, and re-run.
SQLite will skip already-applied migrations because the `schema_version`
table is checked first.

### Coverage gaps in CI

`pytest --cov` reports against `invtrack` only (configured in
`pyproject.toml`). Missing coverage on the CLI module is expected — the
CLI is exercised by the docker smoke check, not by unit tests.

---

## Layout

```
.
├── Dockerfile                  # multi-stage build, non-root runtime, api+cli
├── docker-compose.yml          # invtrack, api, migrate, jobs, test services
├── Makefile                    # install, test, init, seed, api-run/dev/test
├── pyproject.toml
├── README.md                   # this file
├── .dockerignore               # NOTE: .git intentionally NOT excluded
├── .github/workflows/ci.yml    # pytest matrix + docker build/smoke + api smoke
├── src/invtrack/
│   ├── cli.py                  # argparse subcommands
│   ├── domain/                 # dataclasses, enums
│   ├── db/                     # connection + schema migrations
│   ├── repositories/           # one class per aggregate
│   ├── services/               # business rules, transactions
│   ├── reporting/              # read-only analytical queries
│   ├── io/                     # CSV import + export
│   ├── jobs/                   # background tasks
│   ├── api/                    # FastAPI HTTP layer
│   │   ├── main.py             # create_app() factory
│   │   ├── settings.py         # env-driven config
│   │   ├── auth.py             # api keys + JWT + role guards
│   │   ├── deps.py             # request-scoped db connection
│   │   ├── schemas.py          # Pydantic request/response models
│   │   ├── pagination.py       # Page/Sort helpers
│   │   ├── logging.py          # structured json logging
│   │   ├── errors.py           # domain → http error handlers
│   │   └── routers/            # one module per resource
│   ├── errors.py               # InvtrackError hierarchy
│   └── validation.py           # shared validators
└── tests/
    ├── conftest.py             # db fixture + api client fixtures
    ├── _factories.py           # reusable test entity builders
    ├── test_repositories_basic.py
    ├── test_catalog_service.py
    ├── test_inventory_service.py
    ├── test_purchase_workflow.py
    ├── test_customer_order_workflow.py
    ├── test_transfers.py
    ├── test_reconciliation.py
    ├── test_reporting.py
    ├── test_jobs.py
    ├── test_csv_io.py
    ├── test_audit.py
    ├── test_concurrency.py
    ├── test_api_health.py
    ├── test_api_products.py
    ├── test_api_suppliers.py
    ├── test_api_warehouses.py
    ├── test_api_inventory.py
    ├── test_api_purchase_orders.py
    ├── test_api_customer_orders.py
    ├── test_api_alerts.py
    ├── test_api_reports.py
    └── test_api_auth.py
```

---

## License

MIT.
