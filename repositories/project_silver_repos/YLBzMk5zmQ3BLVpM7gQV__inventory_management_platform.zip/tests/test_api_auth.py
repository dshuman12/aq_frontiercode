from __future__ import annotations

import json
import os
import time

import jwt as jwt_lib  # type: ignore


# ---------------------------------------------------------------------
# API key authentication
# ---------------------------------------------------------------------

def test_no_auth_header_returns_401(authed_client):
    r = authed_client.get("/api/v1/products")
    assert r.status_code == 401
    body = r.json()
    assert body["detail"] == "missing Authorization header"


def test_malformed_auth_header_returns_401(authed_client):
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": "garbage"})
    assert r.status_code == 401


def test_unknown_scheme_returns_401(authed_client):
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": "Basic abc123"})
    assert r.status_code == 401


def test_valid_api_key_grants_access(authed_client):
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": "ApiKey viewer-key"})
    assert r.status_code == 200


def test_invalid_api_key_rejected(authed_client):
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": "ApiKey wrong"})
    assert r.status_code == 401


def test_health_live_does_not_require_auth(authed_client):
    r = authed_client.get("/health/live")
    assert r.status_code == 200


# ---------------------------------------------------------------------
# Role enforcement
# ---------------------------------------------------------------------

def test_viewer_can_read(authed_client):
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": "ApiKey viewer-key"})
    assert r.status_code == 200


def test_viewer_cannot_create_product(authed_client):
    r = authed_client.post("/api/v1/products",
                           json={"sku": "WID-001", "name": "X"},
                           headers={"Authorization": "ApiKey viewer-key"})
    assert r.status_code == 403
    body = r.json()
    assert "operator" in body["detail"]


def test_operator_can_create_product(authed_client):
    r = authed_client.post("/api/v1/products",
                           json={"sku": "WID-001", "name": "X"},
                           headers={"Authorization": "ApiKey ops-key"})
    assert r.status_code == 201


def test_operator_cannot_create_warehouse(authed_client):
    r = authed_client.post("/api/v1/warehouses",
                           json={"code": "MAIN", "name": "Main"},
                           headers={"Authorization": "ApiKey ops-key"})
    assert r.status_code == 403


def test_admin_can_create_warehouse(authed_client):
    r = authed_client.post("/api/v1/warehouses",
                           json={"code": "MAIN", "name": "Main"},
                           headers={"Authorization": "ApiKey admin-key"})
    assert r.status_code == 201


def test_operator_cannot_update_supplier(authed_client):
    # First create one as admin
    authed_client.post("/api/v1/suppliers",
                       json={"code": "ACME", "name": "Acme"},
                       headers={"Authorization": "ApiKey admin-key"})
    r = authed_client.put("/api/v1/suppliers/ACME",
                          json={"name": "New"},
                          headers={"Authorization": "ApiKey ops-key"})
    assert r.status_code == 403


def test_admin_can_do_everything(authed_client):
    headers = {"Authorization": "ApiKey admin-key"}
    r = authed_client.get("/api/v1/products", headers=headers)
    assert r.status_code == 200
    r = authed_client.post("/api/v1/suppliers",
                           json={"code": "X1", "name": "X"},
                           headers=headers)
    assert r.status_code == 201
    r = authed_client.post("/api/v1/warehouses",
                           json={"code": "WH1", "name": "WH"},
                           headers=headers)
    assert r.status_code == 201


# ---------------------------------------------------------------------
# JWT authentication
# ---------------------------------------------------------------------

def test_valid_jwt_grants_access(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode(
        {"sub": "alice", "role": "operator", "iat": int(time.time())},
        "shared-test-secret",
        algorithm="HS256",
    )
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200, r.text


def test_jwt_with_admin_role_can_create_warehouse(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode(
        {"sub": "carol", "role": "admin"},
        "shared-test-secret",
        algorithm="HS256",
    )
    r = authed_client.post("/api/v1/warehouses",
                           json={"code": "MAIN", "name": "Main"},
                           headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 201


def test_jwt_with_viewer_role_cannot_create(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode(
        {"sub": "bob", "role": "viewer"},
        "shared-test-secret",
        algorithm="HS256",
    )
    r = authed_client.post("/api/v1/products",
                           json={"sku": "WID-001", "name": "X"},
                           headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 403


def test_jwt_with_bad_signature_rejected(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode(
        {"sub": "evil", "role": "admin"},
        "wrong-secret",
        algorithm="HS256",
    )
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 401


def test_jwt_missing_secret_means_no_jwt_accepted(authed_client):
    """If INVTRACK_JWT_SECRET is not set, bearer tokens are rejected."""
    os.environ.pop("INVTRACK_JWT_SECRET", None)
    token = jwt_lib.encode({"sub": "x", "role": "admin"}, "any", "HS256")
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 401


def test_jwt_missing_role_claim_rejected(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode({"sub": "x"}, "shared-test-secret", algorithm="HS256")
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 401


def test_jwt_unknown_role_rejected(authed_client):
    os.environ["INVTRACK_JWT_SECRET"] = "shared-test-secret"
    token = jwt_lib.encode(
        {"sub": "x", "role": "superuser"},
        "shared-test-secret",
        algorithm="HS256",
    )
    r = authed_client.get("/api/v1/products",
                          headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 401


# ---------------------------------------------------------------------
# Auth-disabled mode (test fixture)
# ---------------------------------------------------------------------

def test_auth_disabled_treats_anonymous_as_admin(client):
    """The `client` fixture sets INVTRACK_DISABLE_AUTH=1 - confirm an
    anonymous request can still create a warehouse (admin-level)."""
    r = client.post("/api/v1/warehouses",
                    json={"code": "MAIN", "name": "Main"})
    assert r.status_code == 201
