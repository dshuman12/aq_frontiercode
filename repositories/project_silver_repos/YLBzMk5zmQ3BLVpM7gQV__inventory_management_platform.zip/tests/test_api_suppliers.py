from __future__ import annotations


def test_create_and_list(client):
    r = client.post("/api/v1/suppliers", json={
        "code": "ACME", "name": "Acme Corp",
        "contact_email": "ops@acme.test", "lead_time_days": 5,
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["code"] == "ACME"
    assert body["lead_time_days"] == 5

    r = client.get("/api/v1/suppliers")
    assert r.status_code == 200
    assert r.json()["total"] == 1


def test_get_by_code(client):
    client.post("/api/v1/suppliers", json={"code": "GLOBEX", "name": "Globex"})
    r = client.get("/api/v1/suppliers/GLOBEX")
    assert r.status_code == 200
    assert r.json()["name"] == "Globex"


def test_404_unknown_supplier(client):
    r = client.get("/api/v1/suppliers/UNKNOWN")
    assert r.status_code == 404


def test_invalid_code_rejected(client):
    r = client.post("/api/v1/suppliers", json={"code": "lowercase", "name": "X"})
    assert r.status_code == 422


def test_invalid_lead_time(client):
    r = client.post("/api/v1/suppliers", json={
        "code": "BAD", "name": "X", "lead_time_days": -1,
    })
    assert r.status_code == 422


def test_duplicate_code_is_409(client):
    client.post("/api/v1/suppliers", json={"code": "DUP", "name": "First"})
    r = client.post("/api/v1/suppliers", json={"code": "DUP", "name": "Second"})
    assert r.status_code == 409


def test_search_filter(client):
    client.post("/api/v1/suppliers", json={"code": "ACME", "name": "Acme"})
    client.post("/api/v1/suppliers", json={"code": "GLOBEX", "name": "Globex"})
    r = client.get("/api/v1/suppliers?q=Acme")
    page = r.json()
    assert page["total"] == 1


def test_update_supplier(client):
    client.post("/api/v1/suppliers", json={"code": "UPD", "name": "Old Name"})
    r = client.put("/api/v1/suppliers/UPD", json={
        "name": "New Name", "lead_time_days": 14,
    })
    assert r.status_code == 200
    body = r.json()
    assert body["name"] == "New Name"
    assert body["lead_time_days"] == 14


def test_pagination(client):
    for i in range(6):
        client.post("/api/v1/suppliers",
                    json={"code": f"S{i:03d}", "name": f"Supplier {i}"})
    r = client.get("/api/v1/suppliers?page=2&page_size=2")
    page = r.json()
    assert page["page"] == 2
    assert len(page["items"]) == 2
    assert page["total"] == 6
