from __future__ import annotations

import pytest

from invtrack.domain import StockCountStatus
from invtrack.errors import ConflictError, NotFoundError, ValidationError
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService
from invtrack.services.reconciliation_service import ReconciliationService


def _setup(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("WID-001", "Widget A")
    p2 = cat.create_product("WID-002", "Widget B")
    inv = InventoryService(conn)
    inv.receive(p1.id, loc.id, 50)
    inv.receive(p2.id, loc.id, 20)
    return loc, p1, p2


def test_apply_positive_and_negative_variances(conn):
    loc, p1, p2 = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-001", loc.id, counted_by="alice")
    svc.record_counted_qty(count.id, p1.id, 48)  # missing 2
    svc.record_counted_qty(count.id, p2.id, 22)  # extra 2

    applied, variances = svc.apply_count(count.id, applied_by="alice")
    assert applied.status == StockCountStatus.APPLIED
    var_map = dict(variances)
    assert var_map[p1.id] == -2
    assert var_map[p2.id] == 2
    assert svc.inventory.get(p1.id, loc.id).quantity == 48
    assert svc.inventory.get(p2.id, loc.id).quantity == 22


def test_zero_variance_no_movement(conn):
    loc, p1, p2 = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-002", loc.id)
    svc.record_counted_qty(count.id, p1.id, 50)
    svc.record_counted_qty(count.id, p2.id, 20)
    from invtrack.repositories.movements import MovementRepository
    moves_before = len(MovementRepository(conn).list_recent(1000))
    svc.apply_count(count.id)
    moves_after = len(MovementRepository(conn).list_recent(1000))
    assert moves_after == moves_before  # no adjustment movements


def test_record_then_update_keeps_one_line(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-003", loc.id)
    svc.record_counted_qty(count.id, p1.id, 47)
    svc.record_counted_qty(count.id, p1.id, 49)  # corrected count
    refreshed = svc.counts.get(count.id)
    assert len(refreshed.lines) == 1
    assert refreshed.lines[0].counted_qty == 49


def test_resnapshot_picks_up_intervening_movements(conn):
    """Stock changes between record and apply should be respected."""
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    inv = InventoryService(conn)
    count = svc.open_count("CNT-004", loc.id)
    svc.record_counted_qty(count.id, p1.id, 50)  # matches initial
    # Operator processed a shipment for 5 between count and apply
    inv.ship(p1.id, loc.id, 5)
    # Now system has 45, counted 50 -> variance +5 at apply time
    _, variances = svc.apply_count(count.id)
    assert dict(variances)[p1.id] == 5
    assert svc.inventory.get(p1.id, loc.id).quantity == 50


def test_variance_threshold_blocks(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-005", loc.id)
    svc.record_counted_qty(count.id, p1.id, 5)  # 90% variance
    with pytest.raises(ConflictError):
        svc.apply_count(count.id, max_variance_pct=0.5)


def test_variance_override_via_notes(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-006", loc.id, notes="override - real damage")
    svc.record_counted_qty(count.id, p1.id, 5)
    applied, _ = svc.apply_count(count.id, max_variance_pct=0.5)
    assert applied.status == StockCountStatus.APPLIED


def test_cannot_add_lines_after_apply(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-007", loc.id)
    svc.record_counted_qty(count.id, p1.id, 50)
    svc.apply_count(count.id)
    with pytest.raises(ConflictError):
        svc.record_counted_qty(count.id, p1.id, 49)


def test_abandoned_count(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-008", loc.id)
    svc.record_counted_qty(count.id, p1.id, 49)
    svc.abandon(count.id)
    assert svc.counts.get(count.id).status == StockCountStatus.ABANDONED
    # System unchanged
    assert svc.inventory.get(p1.id, loc.id).quantity == 50


def test_empty_count_cannot_apply(conn):
    loc, _, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-009", loc.id)
    with pytest.raises(ValidationError):
        svc.apply_count(count.id)


def test_negative_counted_qty_rejected(conn):
    loc, p1, _ = _setup(conn)
    svc = ReconciliationService(conn)
    count = svc.open_count("CNT-010", loc.id)
    with pytest.raises(ValidationError):
        svc.record_counted_qty(count.id, p1.id, -1)
