from __future__ import annotations


def test_create_warehouse(client):
    r = client.post("/api/v1/warehouses", json={
        "code": "MAIN", "name": "Main DC", "address": "123 Industrial Way",
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["code"] == "MAIN"
    assert body["address"] == "123 Industrial Way"


def test_list_warehouses(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    client.post("/api/v1/warehouses", json={"code": "WEST", "name": "West"})
    r = client.get("/api/v1/warehouses")
    page = r.json()
    assert page["total"] == 2


def test_get_warehouse(client):
    client.post("/api/v1/warehouses", json={"code": "EAST", "name": "East"})
    r = client.get("/api/v1/warehouses/EAST")
    assert r.status_code == 200
    assert r.json()["name"] == "East"


def test_unknown_warehouse_404(client):
    r = client.get("/api/v1/warehouses/NOPE")
    assert r.status_code == 404


def test_create_and_list_locations(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={
        "code": "A-01", "description": "Aisle A bin 01",
    })
    assert r.status_code == 201, r.text

    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-02"})
    assert r.status_code == 201

    r = client.get("/api/v1/warehouses/MAIN/locations")
    assert r.status_code == 200
    locations = r.json()
    assert len(locations) == 2
    codes = sorted(l["code"] for l in locations)
    assert codes == ["A-01", "A-02"]


def test_create_location_in_unknown_warehouse_404(client):
    r = client.post("/api/v1/warehouses/UNKNOWN/locations",
                    json={"code": "A-01"})
    assert r.status_code == 404


def test_duplicate_location_code_is_409(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-01"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-01"})
    assert r.status_code == 409
