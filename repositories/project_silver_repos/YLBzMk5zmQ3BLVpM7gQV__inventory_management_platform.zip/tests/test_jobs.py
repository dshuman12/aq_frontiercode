from __future__ import annotations

from datetime import datetime, timedelta, timezone

from invtrack.jobs import run_job
from invtrack.jobs.low_stock_alerts import low_stock_alert_job
from invtrack.jobs.overdue_po import overdue_po_job
from invtrack.jobs.stale_reservations import stale_reservation_audit_job
from invtrack.repositories.alerts import AlertRepository
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService
from invtrack.services.order_service import CustomerOrderService
from invtrack.services.purchase_service import PurchaseOrderService


def test_low_stock_alert_raises_and_resolves(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W", reorder_point=10, reorder_qty=50)
    inv = InventoryService(conn)
    inv.receive(p.id, loc.id, 5)
    res = run_job(conn, "low_stock_alerts", low_stock_alert_job)
    assert res.metrics["raised"] == 1
    open_alerts = AlertRepository(conn).list_open("low_stock")
    assert len(open_alerts) == 1

    # Now restock - alert should resolve
    inv.receive(p.id, loc.id, 100)
    res = run_job(conn, "low_stock_alerts", low_stock_alert_job)
    assert res.metrics["resolved"] == 1
    assert AlertRepository(conn).list_open("low_stock") == []


def test_low_stock_does_not_duplicate(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W", reorder_point=10, reorder_qty=50)
    InventoryService(conn).receive(p.id, loc.id, 5)
    run_job(conn, "low_stock_alerts", low_stock_alert_job)
    res2 = run_job(conn, "low_stock_alerts", low_stock_alert_job)
    assert res2.metrics["raised"] == 0
    assert res2.metrics["skipped"] == 1


def test_low_stock_critical_when_zero(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W", reorder_point=10, reorder_qty=50)
    InventoryService(conn).receive(p.id, loc.id, 5)
    InventoryService(conn).adjust(p.id, loc.id, -5, note="all gone")
    run_job(conn, "low_stock_alerts", low_stock_alert_job)
    alerts = AlertRepository(conn).list_open("low_stock")
    assert alerts[0].severity == "critical"


def test_overdue_po_raises_and_resolves(conn):
    cat = CatalogService(conn)
    sup = cat.create_supplier("ACME", "Acme")
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W")
    pos = PurchaseOrderService(conn)
    yesterday = (datetime.now(timezone.utc) - timedelta(days=2)).strftime("%Y-%m-%d")
    po = pos.create_draft("PO-100", sup.id, wh.id, [(p.id, 10, 100)], expected_at=yesterday)
    pos.submit(po.id)
    res = run_job(conn, "overdue_po", overdue_po_job)
    assert res.metrics["raised"] == 1

    pos.receive_lines(po.id, [(po.lines[0].id, 10, loc.id)])
    res = run_job(conn, "overdue_po", overdue_po_job)
    assert res.metrics["resolved"] == 1


def test_stale_reservation_flags_old_orders(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W")
    InventoryService(conn).receive(p.id, loc.id, 50)
    co = CustomerOrderService(conn)
    o = co.create_draft("ORD-1", "C", wh.id, [(p.id, 5, 100)])
    co.confirm(o.id)
    # Manually backdate confirmed_at to 100 hrs ago
    conn.execute(
        "UPDATE customer_orders SET confirmed_at = ? WHERE id = ?",
        ((datetime.now(timezone.utc) - timedelta(hours=100)).strftime("%Y-%m-%d %H:%M:%S"), o.id),
    )
    res = run_job(conn, "stale_res",
                  lambda c: stale_reservation_audit_job(c, older_than_hours=48))
    assert res.metrics["flagged"] == 1


def test_job_run_records_failure(conn):
    def boom(_c):
        raise RuntimeError("nope")
    import pytest
    with pytest.raises(RuntimeError):
        run_job(conn, "bad", boom)
    row = conn.execute(
        "SELECT * FROM job_runs WHERE job_name='bad' ORDER BY id DESC LIMIT 1"
    ).fetchone()
    assert row["status"] == "failed"
    assert "nope" in row["error"]
