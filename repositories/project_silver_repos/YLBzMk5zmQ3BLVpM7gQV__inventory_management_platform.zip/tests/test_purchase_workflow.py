from __future__ import annotations

import pytest

from invtrack.domain import POStatus
from invtrack.errors import ConflictError, NotFoundError, ValidationError
from invtrack.services.catalog_service import CatalogService
from invtrack.services.purchase_service import PurchaseOrderService


def _setup(conn):
    cat = CatalogService(conn)
    sup = cat.create_supplier("ACME", "Acme")
    wh = cat.create_warehouse("MAIN", "Main DC")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("WID-001", "Widget", supplier_id=sup.id)
    p2 = cat.create_product("GAD-001", "Gadget", supplier_id=sup.id)
    return sup, wh, loc, p1, p2


def test_full_po_lifecycle(conn):
    sup, wh, loc, p1, p2 = _setup(conn)
    pos = PurchaseOrderService(conn)

    po = pos.create_draft(
        "PO-2024-001", sup.id, wh.id,
        [(p1.id, 10, 100), (p2.id, 5, 200)],
    )
    assert po.status == POStatus.DRAFT
    assert len(po.lines) == 2

    po = pos.submit(po.id)
    assert po.status == POStatus.SUBMITTED
    assert po.submitted_at is not None

    line1, line2 = po.lines
    po = pos.receive_lines(po.id, [(line1.id, 10, loc.id), (line2.id, 5, loc.id)])
    assert po.status == POStatus.RECEIVED
    assert po.received_at is not None

    # Inventory updated
    p1_total = pos.inventory_service.inventory.total_quantity(p1.id)
    p2_total = pos.inventory_service.inventory.total_quantity(p2.id)
    assert p1_total == 10
    assert p2_total == 5


def test_partial_receipt(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-2024-002", sup.id, wh.id, [(p1.id, 100, 50)])
    po = pos.submit(po.id)
    line = po.lines[0]

    po = pos.receive_lines(po.id, [(line.id, 30, loc.id)])
    assert po.status == POStatus.PARTIAL
    assert po.lines[0].quantity_received == 30
    assert po.lines[0].outstanding == 70

    po = pos.receive_lines(po.id, [(line.id, 70, loc.id)])
    assert po.status == POStatus.RECEIVED


def test_cannot_overreceive(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-2024-003", sup.id, wh.id, [(p1.id, 10, 100)])
    po = pos.submit(po.id)
    line = po.lines[0]
    with pytest.raises(ConflictError):
        pos.receive_lines(po.id, [(line.id, 11, loc.id)])


def test_cannot_receive_draft(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-2024-004", sup.id, wh.id, [(p1.id, 10, 100)])
    line = po.lines[0]
    with pytest.raises(ConflictError):
        pos.receive_lines(po.id, [(line.id, 10, loc.id)])


def test_duplicate_po_number(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    pos.create_draft("PO-X", sup.id, wh.id, [(p1.id, 1, 1)])
    with pytest.raises(ConflictError):
        pos.create_draft("PO-X", sup.id, wh.id, [(p1.id, 1, 1)])


def test_duplicate_product_on_po(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    with pytest.raises(ValidationError):
        pos.create_draft("PO-Y", sup.id, wh.id, [(p1.id, 1, 1), (p1.id, 1, 1)])


def test_empty_po_rejected(conn):
    sup, wh, _, _, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    with pytest.raises(ValidationError):
        pos.create_draft("PO-EMPTY", sup.id, wh.id, [])


def test_cancel_draft_ok_partial_blocked(conn):
    sup, wh, loc, p1, _ = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-Z", sup.id, wh.id, [(p1.id, 10, 50)])
    cancelled = pos.cancel(po.id)
    assert cancelled.status == POStatus.CANCELLED

    po2 = pos.create_draft("PO-Z2", sup.id, wh.id, [(p1.id, 10, 50)])
    pos.submit(po2.id)
    pos.receive_lines(po2.id, [(po2.lines[0].id, 3, loc.id)])
    with pytest.raises(ConflictError):
        pos.cancel(po2.id)
