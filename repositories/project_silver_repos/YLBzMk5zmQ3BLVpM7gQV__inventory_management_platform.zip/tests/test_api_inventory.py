from __future__ import annotations


def _setup(client) -> tuple[int, str]:
    """Create warehouse + location + product. Returns (location_id, sku)."""
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-01"})
    location_id = r.json()["id"]
    client.post("/api/v1/products", json={"sku": "WID-001", "name": "Widget"})
    return location_id, "WID-001"


def test_receive_then_levels(client):
    loc_id, sku = _setup(client)
    r = client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 50,
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["quantity"] == 50
    assert body["available"] == 50

    r = client.get(f"/api/v1/inventory/levels/{sku}")
    assert r.status_code == 200
    levels = r.json()
    assert len(levels) == 1
    assert levels[0]["quantity"] == 50


def test_receive_unknown_sku_is_404(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A"})
    loc_id = r.json()["id"]
    r = client.post("/api/v1/inventory/receive", json={
        "sku": "GHOST", "location_id": loc_id, "quantity": 1,
    })
    assert r.status_code == 404


def test_negative_quantity_rejected(client):
    loc_id, sku = _setup(client)
    r = client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": -5,
    })
    assert r.status_code == 422


def test_ship(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    r = client.post("/api/v1/inventory/ship", json={
        "sku": sku, "location_id": loc_id, "quantity": 4,
    })
    assert r.status_code == 200
    assert r.json()["quantity"] == 6


def test_ship_more_than_on_hand_returns_409(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 5,
    })
    r = client.post("/api/v1/inventory/ship", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    assert r.status_code == 409
    body = r.json()
    # The InsufficientStockError handler enriches the body
    assert body["available"] == 5
    assert body["requested"] == 10


def test_adjust_requires_note(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    r = client.post("/api/v1/inventory/adjust", json={
        "sku": sku, "location_id": loc_id, "delta": -2, "note": "",
    })
    assert r.status_code == 422


def test_adjust_with_note_works(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    r = client.post("/api/v1/inventory/adjust", json={
        "sku": sku, "location_id": loc_id, "delta": -2, "note": "damage",
    })
    assert r.status_code == 200, r.text
    assert r.json()["quantity"] == 8


def test_zero_delta_rejected(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    r = client.post("/api/v1/inventory/adjust", json={
        "sku": sku, "location_id": loc_id, "delta": 0, "note": "x",
    })
    assert r.status_code == 422


def test_reserve(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 20,
    })
    r = client.post("/api/v1/inventory/reserve", json={
        "sku": sku, "location_id": loc_id, "quantity": 8,
    })
    assert r.status_code == 200
    body = r.json()
    assert body["reserved"] == 8
    assert body["available"] == 12


def test_movements_list(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    client.post("/api/v1/inventory/ship", json={
        "sku": sku, "location_id": loc_id, "quantity": 3,
    })
    r = client.get("/api/v1/inventory/movements")
    assert r.status_code == 200
    page = r.json()
    assert page["total"] == 2
    types = {m["movement_type"] for m in page["items"]}
    assert types == {"receipt", "shipment"}


def test_movements_filter_by_type(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 10,
    })
    client.post("/api/v1/inventory/ship", json={
        "sku": sku, "location_id": loc_id, "quantity": 3,
    })
    r = client.get("/api/v1/inventory/movements?movement_type=shipment")
    page = r.json()
    assert page["total"] == 1
    assert page["items"][0]["movement_type"] == "shipment"


def test_movements_filter_by_sku(client):
    loc_id, sku = _setup(client)
    client.post("/api/v1/products", json={"sku": "OTHER-001", "name": "Other"})
    client.post("/api/v1/inventory/receive", json={
        "sku": sku, "location_id": loc_id, "quantity": 5,
    })
    client.post("/api/v1/inventory/receive", json={
        "sku": "OTHER-001", "location_id": loc_id, "quantity": 7,
    })
    r = client.get(f"/api/v1/inventory/movements?sku={sku}")
    page = r.json()
    assert page["total"] == 1
