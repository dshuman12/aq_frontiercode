from __future__ import annotations


def test_create_and_list_products(client):
    r = client.post("/api/v1/products", json={
        "sku": "WID-001",
        "name": "Widget",
        "unit_cost_cents": 100,
        "unit_price_cents": 250,
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["sku"] == "WID-001"

    r = client.get("/api/v1/products")
    assert r.status_code == 200
    page = r.json()
    assert page["total"] == 1
    assert page["page"] == 1
    assert page["page_size"] == 50
    assert page["items"][0]["sku"] == "WID-001"


def test_get_product_by_sku(client):
    client.post("/api/v1/products", json={"sku": "GAD-001", "name": "Gadget"})
    r = client.get("/api/v1/products/GAD-001")
    assert r.status_code == 200
    assert r.json()["name"] == "Gadget"


def test_get_unknown_returns_404(client):
    r = client.get("/api/v1/products/NOPE")
    assert r.status_code == 404
    body = r.json()
    assert "Not Found" in body.get("title", "")


def test_invalid_sku_rejected(client):
    r = client.post("/api/v1/products", json={"sku": "lower-case", "name": "x"})
    assert r.status_code == 422


def test_duplicate_sku_is_409(client):
    client.post("/api/v1/products", json={"sku": "DUP-001", "name": "First"})
    r = client.post("/api/v1/products", json={"sku": "DUP-001", "name": "Second"})
    assert r.status_code == 409
    body = r.json()
    assert body["status"] == 409


def test_pagination(client):
    for i in range(7):
        client.post("/api/v1/products", json={
            "sku": f"PAG-{i:03d}", "name": f"Item {i}",
        })
    r = client.get("/api/v1/products?page=1&page_size=3")
    assert r.status_code == 200
    page = r.json()
    assert len(page["items"]) == 3
    assert page["total"] == 7
    r = client.get("/api/v1/products?page=3&page_size=3")
    page = r.json()
    assert len(page["items"]) == 1


def test_search_filter(client):
    client.post("/api/v1/products", json={"sku": "WID-001", "name": "Widget"})
    client.post("/api/v1/products", json={"sku": "GAD-001", "name": "Gadget"})
    r = client.get("/api/v1/products?q=Widg")
    assert r.status_code == 200
    page = r.json()
    assert page["total"] == 1
    assert page["items"][0]["sku"] == "WID-001"


def test_sort_descending(client):
    client.post("/api/v1/products", json={"sku": "AAA-001", "name": "A"})
    client.post("/api/v1/products", json={"sku": "ZZZ-001", "name": "Z"})
    r = client.get("/api/v1/products?sort=-sku")
    page = r.json()
    skus = [p["sku"] for p in page["items"]]
    assert skus == ["ZZZ-001", "AAA-001"]


def test_invalid_sort_column_rejected(client):
    client.post("/api/v1/products", json={"sku": "ABC-001", "name": "X"})
    r = client.get("/api/v1/products?sort=evil_column")
    assert r.status_code == 400


def test_update_reorder(client):
    client.post("/api/v1/products", json={"sku": "RO-001", "name": "X"})
    r = client.put("/api/v1/products/RO-001/reorder",
                   json={"reorder_point": 25, "reorder_qty": 100})
    assert r.status_code == 200
    body = r.json()
    assert body["reorder_point"] == 25
    assert body["reorder_qty"] == 100
