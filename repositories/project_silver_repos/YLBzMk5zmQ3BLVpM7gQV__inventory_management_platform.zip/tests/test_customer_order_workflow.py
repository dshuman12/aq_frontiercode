from __future__ import annotations

import pytest

from invtrack.domain import CustomerOrderStatus
from invtrack.errors import ConflictError, InsufficientStockError, NotFoundError
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService
from invtrack.services.order_service import CustomerOrderService


def _setup_with_stock(conn):
    cat = CatalogService(conn)
    sup = cat.create_supplier("ACME", "Acme")
    wh = cat.create_warehouse("MAIN", "Main DC")
    loc1 = cat.create_location(wh.id, "A-01")
    loc2 = cat.create_location(wh.id, "A-02")
    p1 = cat.create_product("WID-001", "Widget", supplier_id=sup.id, unit_price_cents=500)
    p2 = cat.create_product("GAD-001", "Gadget", supplier_id=sup.id, unit_price_cents=1000)
    inv = InventoryService(conn)
    inv.receive(p1.id, loc1.id, 50)
    inv.receive(p2.id, loc2.id, 20)
    return wh, loc1, loc2, p1, p2


def test_full_order_lifecycle(conn):
    wh, loc1, loc2, p1, p2 = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)

    o = svc.create_draft(
        "ORD-001", "Customer A", wh.id,
        [(p1.id, 5, 500), (p2.id, 3, 1000)],
        customer_email="customer@example.test",
    )
    assert o.status == CustomerOrderStatus.DRAFT

    o = svc.confirm(o.id)
    assert o.status == CustomerOrderStatus.CONFIRMED
    # Reservations should be in place
    inv = svc.inventory.inventory
    p1_levels = inv.levels_for_product(p1.id)
    assert sum(lv.reserved for lv in p1_levels) == 5

    line1, line2 = o.lines
    o = svc.pick(o.id, [(line1.id, 5), (line2.id, 3)])
    assert o.status == CustomerOrderStatus.PICKING

    o = svc.ship(o.id)
    assert o.status == CustomerOrderStatus.SHIPPED
    # Reservations cleared, quantity decremented
    p1_levels = inv.levels_for_product(p1.id)
    assert sum(lv.reserved for lv in p1_levels) == 0
    assert sum(lv.quantity for lv in p1_levels) == 45


def test_confirm_insufficient_stock(conn):
    wh, loc1, loc2, p1, p2 = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    o = svc.create_draft("ORD-002", "Big Customer", wh.id, [(p1.id, 100, 500)])
    with pytest.raises(InsufficientStockError):
        svc.confirm(o.id)


def test_cancel_confirmed_releases_reservation(conn):
    wh, loc1, _, p1, _ = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    inv = svc.inventory.inventory
    o = svc.create_draft("ORD-003", "C", wh.id, [(p1.id, 10, 500)])
    svc.confirm(o.id)
    assert sum(lv.reserved for lv in inv.levels_for_product(p1.id)) == 10
    svc.cancel(o.id)
    assert sum(lv.reserved for lv in inv.levels_for_product(p1.id)) == 0


def test_cannot_ship_unpicked(conn):
    wh, loc1, _, p1, _ = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    o = svc.create_draft("ORD-004", "C", wh.id, [(p1.id, 5, 500)])
    svc.confirm(o.id)
    line = o.lines[0]
    svc.pick(o.id, [(line.id, 2)])  # only 2 of 5
    with pytest.raises(ConflictError):
        svc.ship(o.id)


def test_pick_more_than_quantity(conn):
    wh, loc1, _, p1, _ = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    o = svc.create_draft("ORD-005", "C", wh.id, [(p1.id, 5, 500)])
    svc.confirm(o.id)
    line = o.lines[0]
    with pytest.raises(ConflictError):
        svc.pick(o.id, [(line.id, 6)])


def test_allocation_spans_multiple_locations(conn):
    """Stock split across two locations - allocator should walk locations."""
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc1 = cat.create_location(wh.id, "A-01")
    loc2 = cat.create_location(wh.id, "A-02")
    p = cat.create_product("WID-001", "Widget")
    inv = InventoryService(conn)
    inv.receive(p.id, loc1.id, 7)
    inv.receive(p.id, loc2.id, 8)
    svc = CustomerOrderService(conn)
    o = svc.create_draft("ORD-006", "C", wh.id, [(p.id, 12, 100)])
    svc.confirm(o.id)
    inv_repo = svc.inventory.inventory
    levels = sorted(inv_repo.levels_for_product(p.id), key=lambda lv: lv.location_id)
    # The first location should be exhausted, the second partially used
    assert levels[0].reserved == 7
    assert levels[1].reserved == 5


def test_cannot_cancel_shipped(conn):
    wh, loc1, _, p1, _ = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    o = svc.create_draft("ORD-007", "C", wh.id, [(p1.id, 1, 500)])
    svc.confirm(o.id)
    svc.pick(o.id, [(o.lines[0].id, 1)])
    svc.ship(o.id)
    with pytest.raises(ConflictError):
        svc.cancel(o.id)


def test_invalid_email_on_create(conn):
    wh, loc1, _, p1, _ = _setup_with_stock(conn)
    svc = CustomerOrderService(conn)
    from invtrack.errors import ValidationError
    with pytest.raises(ValidationError):
        svc.create_draft("ORD-008", "C", wh.id, [(p1.id, 1, 500)],
                         customer_email="bad")
