"""Concurrency-sensitive scenarios.

We use a real db file (not :memory:) and multiple connections to it so
that BEGIN IMMEDIATE / IntegrityError behaviour matches what we would
see under concurrent operators in practice.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path

import pytest

from invtrack.db import connect
from invtrack.db.schema import migrate
from invtrack.errors import InsufficientStockError
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService


# Under contention with sqlite's default rollback journal, a writer that
# loses the BEGIN race surfaces as OperationalError: database is locked.
# That's an expected outcome - the operator retries - so we treat it the
# same as InsufficientStockError for the purposes of "did NOT mutate".
_CONTENTION_ERRORS = (InsufficientStockError, sqlite3.OperationalError)


def _setup_file_db(tmp_path: Path):
    db_path = tmp_path / "inv.db"
    bootstrap = connect(db_path)
    migrate(bootstrap)
    cat = CatalogService(bootstrap)
    p = cat.create_product("WID-001", "Widget")
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A")
    InventoryService(bootstrap).receive(p.id, loc.id, 100)
    bootstrap.close()
    return db_path, p.id, loc.id


def test_concurrent_ships_only_total_drained(tmp_path):
    """Two threads each try to ship; the available pool is finite. We expect
    every successful ship to be reflected in the totals exactly once, and
    we expect the total quantity to never go negative.
    """
    db_path, product_id, location_id = _setup_file_db(tmp_path)

    successes: list[int] = []
    failures: list[Exception] = []
    lock = threading.Lock()
    barrier = threading.Barrier(4)

    def worker(qty: int) -> None:
        conn = connect(db_path)
        try:
            barrier.wait(timeout=5)
            try:
                inv = InventoryService(conn)
                inv.ship(product_id, location_id, qty)
                with lock:
                    successes.append(qty)
            except _CONTENTION_ERRORS as exc:
                with lock:
                    failures.append(exc)
        finally:
            conn.close()

    # Total demand 4 * 30 = 120; only 100 in stock, so at least one fails.
    threads = [threading.Thread(target=worker, args=(30,)) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Verify final state
    final = connect(db_path)
    try:
        row = final.execute(
            "SELECT quantity FROM inventory_levels WHERE product_id = ? AND location_id = ?",
            (product_id, location_id),
        ).fetchone()
        assert row["quantity"] == 100 - sum(successes), (
            f"final qty {row['quantity']} != expected {100 - sum(successes)}"
        )
        # Check audit trail: one movement per success
        moves = final.execute(
            "SELECT COUNT(*) AS c FROM stock_movements WHERE movement_type = 'shipment'"
        ).fetchone()
        assert moves["c"] == len(successes)
    finally:
        final.close()


def test_concurrent_reserves_do_not_oversubscribe(tmp_path):
    """Reservations must respect available stock. If 4 workers try to reserve
    40 each but only 100 are available, at most 2 should succeed, and the
    sum reserved must be <= total quantity.
    """
    db_path, product_id, location_id = _setup_file_db(tmp_path)

    successes: list[int] = []
    failures: list[Exception] = []
    lock = threading.Lock()
    barrier = threading.Barrier(4)

    def worker() -> None:
        conn = connect(db_path)
        try:
            barrier.wait(timeout=5)
            try:
                InventoryService(conn).reserve(product_id, location_id, 40)
                with lock:
                    successes.append(40)
            except _CONTENTION_ERRORS as exc:
                with lock:
                    failures.append(exc)
        finally:
            conn.close()

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    final = connect(db_path)
    try:
        row = final.execute(
            "SELECT quantity, reserved FROM inventory_levels "
            "WHERE product_id = ? AND location_id = ?",
            (product_id, location_id),
        ).fetchone()
        assert row["reserved"] == sum(successes)
        assert row["reserved"] <= row["quantity"]
        assert len(successes) <= 2  # 2 * 40 = 80 fits in 100; 3 * 40 = 120 doesn't
    finally:
        final.close()


def test_movement_count_matches_successful_adjustments(tmp_path):
    """Hammer adjust() concurrently and confirm the movement audit row count
    equals the number of successful operations exactly.
    """
    db_path, product_id, location_id = _setup_file_db(tmp_path)

    successes: list[int] = []
    failures: list[Exception] = []
    lock = threading.Lock()

    def worker(delta: int) -> None:
        conn = connect(db_path)
        try:
            try:
                InventoryService(conn).adjust(
                    product_id, location_id, delta, note="cycle count", created_by="t"
                )
                with lock:
                    successes.append(delta)
            except _CONTENTION_ERRORS as exc:
                with lock:
                    failures.append(exc)
        finally:
            conn.close()

    threads = [threading.Thread(target=worker, args=(1,)) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    final = connect(db_path)
    try:
        adj_count = final.execute(
            "SELECT COUNT(*) AS c FROM stock_movements WHERE movement_type = 'adjustment'"
        ).fetchone()["c"]
        assert adj_count == len(successes)
        qty = final.execute(
            "SELECT quantity FROM inventory_levels "
            "WHERE product_id = ? AND location_id = ?",
            (product_id, location_id),
        ).fetchone()["quantity"]
        assert qty == 100 + len(successes)
    finally:
        final.close()
