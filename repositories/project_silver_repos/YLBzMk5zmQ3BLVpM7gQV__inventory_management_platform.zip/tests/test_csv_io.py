from __future__ import annotations

from io import StringIO
from pathlib import Path

import pytest

from invtrack.errors import ValidationError
from invtrack.io.csv_export import (
    export_low_stock,
    export_products,
    export_stock_summary,
    export_valuation,
)
from invtrack.io.csv_import import (
    CSVImportError,
    import_categories,
    import_opening_stock,
    import_products,
    import_suppliers,
)
from invtrack.repositories.products import ProductRepository
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService

from _factories import make_location, make_warehouse


def test_import_categories_basic(conn):
    csv = StringIO("name,parent_name\nWidgets,\nGears,Widgets\n")
    summary = import_categories(conn, csv)
    assert summary.rows_total == 2
    assert summary.rows_imported == 2


def test_import_categories_unknown_parent_rolls_back(conn):
    csv = StringIO("name,parent_name\nGears,Nonexistent\n")
    with pytest.raises(CSVImportError):
        import_categories(conn, csv)
    # The orphan row didn't sneak in
    rows = conn.execute("SELECT * FROM categories").fetchall()
    assert rows == []


def test_import_suppliers_skips_existing(conn):
    cat = CatalogService(conn)
    cat.create_supplier("ACME", "Acme")
    csv = StringIO("code,name,contact_email,lead_time_days\nACME,Acme,x@y.test,3\nNEW,New Co,,5\n")
    summary = import_suppliers(conn, csv)
    assert summary.rows_total == 2
    assert summary.rows_imported == 1
    assert summary.rows_skipped == 1


def test_products_round_trip(conn, tmp_path):
    cat = CatalogService(conn)
    cat.create_category("Widgets")
    cat.create_supplier("ACME", "Acme")
    cat.create_product(
        "WID-001", "Widget A",
        category_id=cat.categories.get_by_name("Widgets").id,
        supplier_id=cat.suppliers.get_by_code("ACME").id,
        unit_cost_cents=120, unit_price_cents=300,
        reorder_point=10, reorder_qty=50,
    )
    cat.create_product("GAD-001", "Gadget B")

    out = tmp_path / "products.csv"
    n = export_products(conn, out)
    assert n == 2

    # Re-import into a clean db; everything should land back
    from invtrack.db import connect
    from invtrack.db.schema import migrate
    fresh_path = tmp_path / "fresh.db"
    fresh = connect(fresh_path)
    migrate(fresh)
    cat2 = CatalogService(fresh)
    cat2.create_category("Widgets")
    cat2.create_supplier("ACME", "Acme")

    summary = import_products(fresh, out)
    assert summary.rows_imported == 2
    p = ProductRepository(fresh).get_by_sku("WID-001")
    assert p is not None
    assert p.unit_cost_cents == 120
    assert p.reorder_point == 10
    fresh.close()


def test_opening_stock_import(conn, tmp_path):
    cat = CatalogService(conn)
    p = cat.create_product("WID-001", "Widget")
    wh = cat.create_warehouse("MAIN", "Main")
    cat.create_location(wh.id, "A-01")
    cat.create_location(wh.id, "A-02")
    csv_path = tmp_path / "open.csv"
    csv_path.write_text(
        "sku,warehouse_code,location_code,quantity\n"
        "WID-001,MAIN,A-01,100\n"
        "WID-001,MAIN,A-02,50\n"
    )
    summary = import_opening_stock(conn, csv_path)
    assert summary.rows_imported == 2
    inv = InventoryService(conn).inventory
    assert inv.total_quantity(p.id) == 150


def test_opening_stock_skips_locations_with_existing_stock(conn, tmp_path):
    cat = CatalogService(conn)
    p = cat.create_product("WID-001", "Widget")
    wh = cat.create_warehouse("MAIN", "Main")
    cat.create_location(wh.id, "A-01")
    cat.create_location(wh.id, "A-02")
    # Bootstrap A-01 manually
    inv = InventoryService(conn)
    loc1 = cat.locations.get_by_code(wh.id, "A-01")
    inv.receive(p.id, loc1.id, 10)

    csv = StringIO(
        "sku,warehouse_code,location_code,quantity\n"
        "WID-001,MAIN,A-01,100\n"
        "WID-001,MAIN,A-02,50\n"
    )
    summary = import_opening_stock(conn, csv)
    assert summary.rows_imported == 1  # only A-02
    assert summary.rows_skipped == 1
    assert inv.inventory.total_quantity(p.id) == 60  # 10 + 50, NOT 160


def test_export_low_stock_only_includes_below_threshold(conn, tmp_path):
    cat = CatalogService(conn)
    p_low = cat.create_product("LOW-001", "Low", reorder_point=10, reorder_qty=20)
    cat.create_product("OK-001", "Ok", reorder_point=5, reorder_qty=10)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A")
    inv = InventoryService(conn)
    inv.receive(p_low.id, loc.id, 3)
    inv.receive(cat.products.get_by_sku("OK-001").id, loc.id, 100)

    out = tmp_path / "low.csv"
    n = export_low_stock(conn, out)
    assert n == 1
    text = out.read_text()
    assert "LOW-001" in text
    assert "OK-001" not in text


def test_missing_columns_rejected(conn):
    csv = StringIO("name\nA\n")
    with pytest.raises(ValidationError):
        import_suppliers(conn, csv)
