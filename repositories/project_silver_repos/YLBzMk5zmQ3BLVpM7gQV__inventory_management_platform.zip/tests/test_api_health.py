from __future__ import annotations


def test_liveness(client):
    r = client.get("/health/live")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "live"


def test_readiness_runs_migrations(client):
    r = client.get("/health/ready")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ready"
    assert body["schema_version"] >= 7


def test_request_id_header_set(client):
    r = client.get("/health/live")
    assert "x-request-id" in r.headers


def test_caller_supplied_request_id_preserved(client):
    r = client.get("/health/live", headers={"x-request-id": "trace-abc-123"})
    assert r.headers["x-request-id"] == "trace-abc-123"
