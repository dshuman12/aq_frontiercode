from __future__ import annotations

from invtrack.repositories.audit import AuditRepository
from invtrack.services.catalog_service import CatalogService
from invtrack.services.purchase_service import PurchaseOrderService


def _setup(conn):
    cat = CatalogService(conn)
    sup = cat.create_supplier("ACME", "Acme")
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "Widget", supplier_id=sup.id)
    return sup, wh, loc, p


def test_po_lifecycle_emits_audit_events(conn):
    sup, wh, loc, p = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-A1", sup.id, wh.id, [(p.id, 5, 100)], created_by="alice")
    pos.submit(po.id)
    pos.receive_lines(po.id, [(po.lines[0].id, 5, loc.id)], received_by="bob")

    audit = AuditRepository(conn)
    events = audit.list_for_entity("po", po.id)
    types = [e.event_type for e in events]
    assert types == ["po.created", "po.submitted", "po.received"]
    assert events[0].actor == "alice"
    assert events[2].actor == "bob"
    assert events[0].payload["po_number"] == "PO-A1"


def test_partial_receipt_audit(conn):
    sup, wh, loc, p = _setup(conn)
    pos = PurchaseOrderService(conn)
    po = pos.create_draft("PO-PART", sup.id, wh.id, [(p.id, 10, 100)])
    pos.submit(po.id)
    pos.receive_lines(po.id, [(po.lines[0].id, 4, loc.id)])
    audit = AuditRepository(conn)
    events = audit.list_for_entity("po", po.id)
    types = [e.event_type for e in events]
    assert "po.partial_receipt" in types
    # Make sure no spurious po.received event was logged
    assert "po.received" not in types
