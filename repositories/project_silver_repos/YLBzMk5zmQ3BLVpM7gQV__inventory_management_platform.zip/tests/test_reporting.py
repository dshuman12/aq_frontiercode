from __future__ import annotations

from datetime import datetime, timedelta

from invtrack.reporting.inventory_reports import (
    low_stock,
    stock_summary,
    valuation,
    total_inventory_value_cents,
)
from invtrack.reporting.movement_reports import (
    movement_summary,
    reorder_suggestions,
    top_shipped_products,
    velocity_report,
)
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService
from invtrack.services.order_service import CustomerOrderService


def test_stock_summary_empty(conn):
    rows = stock_summary(conn)
    assert rows == []


def test_stock_summary_after_receipts(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("WID-001", "Widget", reorder_point=10, reorder_qty=50)
    p2 = cat.create_product("GAD-001", "Gadget")
    inv = InventoryService(conn)
    inv.receive(p1.id, loc.id, 25)
    inv.receive(p2.id, loc.id, 5)

    rows = stock_summary(conn)
    by_sku = {r.sku: r for r in rows}
    assert by_sku["WID-001"].total_quantity == 25
    assert by_sku["WID-001"].needs_reorder is False
    assert by_sku["GAD-001"].needs_reorder is False  # no reorder point set


def test_low_stock_returns_only_below_threshold(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("LOW-001", "Low", reorder_point=20, reorder_qty=100)
    p2 = cat.create_product("OK-001", "OK", reorder_point=20, reorder_qty=100)
    p_no = cat.create_product("NORE-001", "No reorder")
    inv = InventoryService(conn)
    inv.receive(p1.id, loc.id, 5)
    inv.receive(p2.id, loc.id, 50)

    rows = low_stock(conn)
    skus = [r.sku for r in rows]
    assert "LOW-001" in skus
    assert "OK-001" not in skus
    assert "NORE-001" not in skus


def test_low_stock_excludes_reserved(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "Widget", reorder_point=10, reorder_qty=50)
    inv = InventoryService(conn)
    inv.receive(p.id, loc.id, 15)
    inv.reserve(p.id, loc.id, 8)  # available is 7, below reorder point
    rows = low_stock(conn)
    assert any(r.sku == "WID-001" for r in rows)


def test_valuation(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("WID-001", "Widget", unit_cost_cents=250)
    p2 = cat.create_product("GAD-001", "Gadget", unit_cost_cents=1000)
    inv = InventoryService(conn)
    inv.receive(p1.id, loc.id, 10)
    inv.receive(p2.id, loc.id, 4)
    val = valuation(conn)
    by_sku = {r.sku: r for r in val}
    assert by_sku["WID-001"].value_cents == 2500
    assert by_sku["GAD-001"].value_cents == 4000
    assert total_inventory_value_cents(conn) == 6500


def test_movement_summary_in_window(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W")
    inv = InventoryService(conn)
    inv.receive(p.id, loc.id, 10)
    inv.adjust(p.id, loc.id, -1, note="damage")

    start = "1900-01-01"
    end = "2999-01-01"
    summary = movement_summary(conn, start=start, end=end)
    types = {s.movement_type for s in summary}
    assert "receipt" in types
    assert "adjustment" in types


def test_reorder_suggestions_grouped_by_supplier(conn):
    cat = CatalogService(conn)
    s1 = cat.create_supplier("S1", "Supplier 1")
    s2 = cat.create_supplier("S2", "Supplier 2")
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p1 = cat.create_product("S1-001", "A", supplier_id=s1.id, reorder_point=10, reorder_qty=20)
    p2 = cat.create_product("S1-002", "B", supplier_id=s1.id, reorder_point=10, reorder_qty=20)
    p3 = cat.create_product("S2-001", "C", supplier_id=s2.id, reorder_point=10, reorder_qty=20)
    inv = InventoryService(conn)
    inv.receive(p1.id, loc.id, 1)
    inv.receive(p2.id, loc.id, 1)
    inv.receive(p3.id, loc.id, 1)
    grouped = reorder_suggestions(conn)
    assert len(grouped) == 2
    by_code = {g["supplier_code"]: g for g in grouped}
    assert len(by_code["S1"]["lines"]) == 2
    assert len(by_code["S2"]["lines"]) == 1


def test_velocity_with_no_shipments(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W")
    InventoryService(conn).receive(p.id, loc.id, 50)
    rows = velocity_report(conn, days=30)
    by_sku = {r.sku: r for r in rows}
    assert by_sku["WID-001"].units_per_day == 0.0
    assert by_sku["WID-001"].days_of_cover is None


def test_top_shipped_products(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "M")
    loc = cat.create_location(wh.id, "A-01")
    p = cat.create_product("WID-001", "W", unit_price_cents=500)
    InventoryService(conn).receive(p.id, loc.id, 50)
    co = CustomerOrderService(conn)
    o = co.create_draft("ORD-1", "C", wh.id, [(p.id, 10, 500)])
    co.confirm(o.id)
    co.pick(o.id, [(o.lines[0].id, 10)])
    co.ship(o.id)
    rows = top_shipped_products(conn, start="1900-01-01", end="2999-01-01")
    by_sku = {r.sku: r for r in rows}
    assert by_sku["WID-001"].units_shipped == 10
    assert by_sku["WID-001"].revenue_cents == 5000
