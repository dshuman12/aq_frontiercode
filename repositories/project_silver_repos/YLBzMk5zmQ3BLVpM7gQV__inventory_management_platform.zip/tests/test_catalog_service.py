from __future__ import annotations

import pytest

from invtrack.errors import ConflictError, NotFoundError, ValidationError
from invtrack.services.catalog_service import CatalogService


def test_create_product_with_validation(conn):
    svc = CatalogService(conn)
    cat = svc.create_category("Widgets")
    sup = svc.create_supplier("ACME", "Acme Co", contact_email="ops@acme.test")
    p = svc.create_product(
        "WID-001", "Standard Widget",
        category_id=cat.id, supplier_id=sup.id,
        unit_cost_cents=100, unit_price_cents=250,
        reorder_point=10, reorder_qty=50,
    )
    assert p.sku == "WID-001"
    assert p.reorder_point == 10


def test_invalid_sku_rejected(conn):
    svc = CatalogService(conn)
    for bad in ["", "x", "lower-case", "WID 01", "WID/01"]:
        with pytest.raises(ValidationError):
            svc.create_product(bad, "Name")


def test_duplicate_sku_is_conflict(conn):
    svc = CatalogService(conn)
    svc.create_product("DUP-001", "First")
    with pytest.raises(ConflictError):
        svc.create_product("DUP-001", "Second")


def test_unknown_supplier_id(conn):
    svc = CatalogService(conn)
    with pytest.raises(NotFoundError):
        svc.create_product("WID-002", "Name", supplier_id=999)


def test_invalid_email(conn):
    svc = CatalogService(conn)
    with pytest.raises(ValidationError):
        svc.create_supplier("BAD", "Bad Inc", contact_email="not-an-email")


def test_reorder_point_requires_qty(conn):
    svc = CatalogService(conn)
    with pytest.raises(ValidationError):
        svc.create_product("WID-003", "X", reorder_point=10, reorder_qty=0)


def test_warehouse_and_location(conn):
    svc = CatalogService(conn)
    wh = svc.create_warehouse("MAIN", "Main DC")
    loc = svc.create_location(wh.id, "A-01-01", "Aisle A bin 01-01")
    assert loc.warehouse_id == wh.id
    with pytest.raises(ConflictError):
        svc.create_location(wh.id, "A-01-01")
