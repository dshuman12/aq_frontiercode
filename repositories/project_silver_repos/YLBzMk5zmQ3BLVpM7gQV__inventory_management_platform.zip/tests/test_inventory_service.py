from __future__ import annotations

import pytest

from invtrack.domain import MovementType
from invtrack.errors import (
    ConflictError,
    InsufficientStockError,
    NotFoundError,
    ValidationError,
)
from invtrack.repositories.movements import MovementRepository
from invtrack.services.inventory_service import InventoryService

from _factories import make_location, make_product, make_warehouse


def test_receive_creates_movement_and_level(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)

    svc = InventoryService(conn)
    level = svc.receive(p.id, loc.id, 25, reference_type="po", reference_id=1)
    assert level.quantity == 25
    assert level.reserved == 0

    moves = MovementRepository(conn).list_for_product(p.id)
    assert len(moves) == 1
    assert moves[0].movement_type == MovementType.RECEIPT
    assert moves[0].quantity == 25


def test_ship_decreases_quantity(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 10)
    svc.ship(p.id, loc.id, 4)
    level = svc.inventory.get(p.id, loc.id)
    assert level.quantity == 6


def test_ship_more_than_on_hand_raises(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 5)
    with pytest.raises(InsufficientStockError):
        svc.ship(p.id, loc.id, 10)


def test_reserve_then_release(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 20)
    svc.reserve(p.id, loc.id, 8)
    level = svc.inventory.get(p.id, loc.id)
    assert level.reserved == 8
    assert level.available == 12
    svc.release_reservation(p.id, loc.id, 5)
    assert svc.inventory.get(p.id, loc.id).reserved == 3


def test_cannot_reserve_more_than_available(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 5)
    svc.reserve(p.id, loc.id, 4)
    with pytest.raises(InsufficientStockError):
        svc.reserve(p.id, loc.id, 2)  # only 1 available


def test_cannot_release_more_than_reserved(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 10)
    svc.reserve(p.id, loc.id, 3)
    with pytest.raises(ConflictError):
        svc.release_reservation(p.id, loc.id, 5)


def test_adjust_requires_note(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 5)
    with pytest.raises(ValidationError):
        svc.adjust(p.id, loc.id, 1, note="")


def test_adjust_negative_to_zero_ok(conn):
    p = make_product(conn)
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    svc.receive(p.id, loc.id, 3)
    svc.adjust(p.id, loc.id, -3, note="cycle count")
    assert svc.inventory.get(p.id, loc.id).quantity == 0


def test_unknown_product_raises(conn):
    wh = make_warehouse(conn)
    loc = make_location(conn, wh.id)
    svc = InventoryService(conn)
    with pytest.raises(NotFoundError):
        svc.receive(999, loc.id, 1)
