from __future__ import annotations

import json
import os
import sqlite3
from collections.abc import Iterator
from pathlib import Path

import pytest

from invtrack.db import connect
from invtrack.db.schema import migrate


@pytest.fixture
def conn(tmp_path) -> Iterator[sqlite3.Connection]:
    db = tmp_path / "test.db"
    c = connect(db)
    migrate(c)
    try:
        yield c
    finally:
        c.close()


# ---------------------------------------------------------------------
# API integration test fixtures
# ---------------------------------------------------------------------

@pytest.fixture
def api_env(tmp_path) -> Iterator[Path]:
    """Sets env vars so a fresh API app uses an isolated db + key store."""
    db_path = tmp_path / "api.db"
    keys_path = tmp_path / "api_keys.json"
    old = {}
    for k in ("INVTRACK_DB", "INVTRACK_API_KEYS", "INVTRACK_DISABLE_AUTH",
              "INVTRACK_LOG_LEVEL", "INVTRACK_LOG_FORMAT", "INVTRACK_JWT_SECRET"):
        old[k] = os.environ.get(k)
    os.environ["INVTRACK_DB"] = str(db_path)
    os.environ["INVTRACK_API_KEYS"] = str(keys_path)
    os.environ["INVTRACK_DISABLE_AUTH"] = "1"
    os.environ["INVTRACK_LOG_LEVEL"] = "WARNING"
    os.environ["INVTRACK_LOG_FORMAT"] = "text"
    try:
        yield tmp_path
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@pytest.fixture
def client(api_env):
    from invtrack.api import auth as _auth
    _auth._store = None
    from fastapi.testclient import TestClient
    from invtrack.api.main import create_app
    return TestClient(create_app())


@pytest.fixture
def authed_client(api_env):
    """Auth enabled, three roles populated: viewer-key, ops-key, admin-key."""
    keys_path = api_env / "api_keys.json"
    keys_path.write_text(json.dumps({
        "keys": [
            {"name": "viewer-1", "key": "viewer-key", "role": "viewer"},
            {"name": "ops-1", "key": "ops-key", "role": "operator"},
            {"name": "admin-1", "key": "admin-key", "role": "admin"},
        ]
    }))
    os.environ["INVTRACK_DISABLE_AUTH"] = "0"
    from invtrack.api import auth as _auth
    _auth._store = None
    from fastapi.testclient import TestClient
    from invtrack.api.main import create_app
    return TestClient(create_app())
