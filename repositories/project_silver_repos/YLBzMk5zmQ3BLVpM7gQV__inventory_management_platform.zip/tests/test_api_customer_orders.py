from __future__ import annotations


def _bootstrap(client) -> dict:
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-01"})
    loc_id = r.json()["id"]
    client.post("/api/v1/products", json={"sku": "WID-001", "name": "Widget"})
    # Stock the product so reservation/picking/shipping can succeed
    client.post("/api/v1/inventory/receive", json={
        "sku": "WID-001", "location_id": loc_id, "quantity": 100,
    })
    return {"loc_id": loc_id}


def test_create_order_draft(client):
    _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-001",
        "customer_name": "Customer A",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 5, "unit_price_cents": 250}],
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["order_number"] == "CO-001"
    assert body["status"] == "draft"
    assert len(body["lines"]) == 1


def test_get_order(client):
    _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-G1", "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    order_id = r.json()["id"]
    r = client.get(f"/api/v1/customer-orders/{order_id}")
    assert r.status_code == 200
    assert r.json()["order_number"] == "CO-G1"


def test_unknown_order_404(client):
    r = client.get("/api/v1/customer-orders/9999")
    assert r.status_code == 404


def test_confirm_reserves_stock(client):
    info = _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-CONF",
        "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 7, "unit_price_cents": 100}],
    })
    order_id = r.json()["id"]
    r = client.post(f"/api/v1/customer-orders/{order_id}/confirm")
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "confirmed"

    # Stock is now reserved
    levels = client.get("/api/v1/inventory/levels/WID-001").json()
    assert levels[0]["reserved"] == 7
    assert levels[0]["available"] == 93


def test_full_lifecycle(client):
    _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-FULL",
        "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 3, "unit_price_cents": 100}],
    })
    order = r.json()
    order_id = order["id"]
    line_id = order["lines"][0]["id"]

    # Confirm
    r = client.post(f"/api/v1/customer-orders/{order_id}/confirm")
    assert r.json()["status"] == "confirmed"

    # Pick
    r = client.post(f"/api/v1/customer-orders/{order_id}/pick", json={
        "picks": [{"line_id": line_id, "quantity": 3, "location_id": 1}],
    })
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "picking"

    # Ship
    r = client.post(f"/api/v1/customer-orders/{order_id}/ship")
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "shipped"


def test_cancel_draft(client):
    _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-CAN",
        "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    order_id = r.json()["id"]
    r = client.post(f"/api/v1/customer-orders/{order_id}/cancel")
    assert r.status_code == 200
    assert r.json()["status"] == "cancelled"


def test_confirm_releases_no_double_reserve(client):
    _bootstrap(client)
    # Create two orders, confirm both
    for n in (1, 2):
        r = client.post("/api/v1/customer-orders", json={
            "order_number": f"CO-DBL-{n}",
            "customer_name": "X",
            "warehouse_code": "MAIN",
            "lines": [{"sku": "WID-001", "quantity": 30, "unit_price_cents": 100}],
        })
        order_id = r.json()["id"]
        r = client.post(f"/api/v1/customer-orders/{order_id}/confirm")
        assert r.status_code == 200

    levels = client.get("/api/v1/inventory/levels/WID-001").json()
    assert levels[0]["reserved"] == 60
    assert levels[0]["available"] == 40


def test_oversell_returns_409(client):
    _bootstrap(client)
    # Need 200, only have 100
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-OVER",
        "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 200, "unit_price_cents": 100}],
    })
    order_id = r.json()["id"]
    r = client.post(f"/api/v1/customer-orders/{order_id}/confirm")
    assert r.status_code == 409


def test_filter_by_status(client):
    _bootstrap(client)
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-D",
        "customer_name": "X",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    r = client.post("/api/v1/customer-orders", json={
        "order_number": "CO-C",
        "customer_name": "Y",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    confirmed_id = r.json()["id"]
    client.post(f"/api/v1/customer-orders/{confirmed_id}/confirm")
    r = client.get("/api/v1/customer-orders?status=draft")
    assert r.json()["total"] == 1


def test_filter_by_customer(client):
    _bootstrap(client)
    client.post("/api/v1/customer-orders", json={
        "order_number": "CO-A1", "customer_name": "Acme Corp",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    client.post("/api/v1/customer-orders", json={
        "order_number": "CO-G1", "customer_name": "Globex Inc",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_price_cents": 1}],
    })
    r = client.get("/api/v1/customer-orders?customer=Acme")
    assert r.json()["total"] == 1
