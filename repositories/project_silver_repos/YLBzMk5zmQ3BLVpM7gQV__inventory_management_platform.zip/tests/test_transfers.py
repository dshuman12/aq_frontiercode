from __future__ import annotations

import pytest

from invtrack.domain import TransferStatus
from invtrack.errors import ConflictError, InsufficientStockError, ValidationError
from invtrack.services.catalog_service import CatalogService
from invtrack.services.inventory_service import InventoryService
from invtrack.services.transfer_service import StockTransferService


def _setup(conn):
    cat = CatalogService(conn)
    wh = cat.create_warehouse("MAIN", "Main")
    src = cat.create_location(wh.id, "A-01")
    dst = cat.create_location(wh.id, "B-01")
    p = cat.create_product("WID-001", "Widget")
    InventoryService(conn).receive(p.id, src.id, 100)
    return src, dst, p


def test_full_transfer_lifecycle(conn):
    src, dst, p = _setup(conn)
    svc = StockTransferService(conn)
    t = svc.initiate("TR-001", src.id, dst.id, [(p.id, 30)])
    assert t.status == TransferStatus.IN_TRANSIT
    # Source decremented, dest still empty
    assert svc.inventory.get(p.id, src.id).quantity == 70
    assert svc.inventory.get(p.id, dst.id) is None or svc.inventory.get(p.id, dst.id).quantity == 0

    t = svc.complete(t.id)
    assert t.status == TransferStatus.COMPLETED
    assert svc.inventory.get(p.id, dst.id).quantity == 30


def test_transfer_cancel_returns_stock(conn):
    src, dst, p = _setup(conn)
    svc = StockTransferService(conn)
    t = svc.initiate("TR-002", src.id, dst.id, [(p.id, 40)])
    assert svc.inventory.get(p.id, src.id).quantity == 60
    svc.cancel(t.id)
    assert svc.inventory.get(p.id, src.id).quantity == 100


def test_cannot_transfer_more_than_available(conn):
    src, dst, p = _setup(conn)
    svc = StockTransferService(conn)
    with pytest.raises(InsufficientStockError):
        svc.initiate("TR-003", src.id, dst.id, [(p.id, 200)])


def test_same_source_dest_rejected(conn):
    src, _, p = _setup(conn)
    svc = StockTransferService(conn)
    with pytest.raises(ValidationError):
        svc.initiate("TR-004", src.id, src.id, [(p.id, 1)])


def test_cannot_complete_already_completed(conn):
    src, dst, p = _setup(conn)
    svc = StockTransferService(conn)
    t = svc.initiate("TR-005", src.id, dst.id, [(p.id, 1)])
    svc.complete(t.id)
    with pytest.raises(ConflictError):
        svc.complete(t.id)


def test_reservations_are_respected(conn):
    """If qty is reserved at source, available is reduced and transfer should fail."""
    src, dst, p = _setup(conn)
    inv = InventoryService(conn)
    inv.reserve(p.id, src.id, 95)  # only 5 available
    svc = StockTransferService(conn)
    with pytest.raises(InsufficientStockError):
        svc.initiate("TR-006", src.id, dst.id, [(p.id, 10)])
