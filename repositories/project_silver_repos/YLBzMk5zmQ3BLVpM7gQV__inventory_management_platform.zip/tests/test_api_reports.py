from __future__ import annotations


def _setup(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A"})
    loc_id = r.json()["id"]
    # Two products, one needs reorder, one doesn't
    client.post("/api/v1/products", json={
        "sku": "LOW-001", "name": "Low Stock",
        "unit_cost_cents": 100, "reorder_point": 50, "reorder_qty": 100,
    })
    client.post("/api/v1/products", json={
        "sku": "OK-001", "name": "OK Stock",
        "unit_cost_cents": 200, "reorder_point": 5, "reorder_qty": 10,
    })
    client.post("/api/v1/inventory/receive",
                json={"sku": "LOW-001", "location_id": loc_id, "quantity": 10})
    client.post("/api/v1/inventory/receive",
                json={"sku": "OK-001", "location_id": loc_id, "quantity": 100})
    return loc_id


def test_stock_summary(client):
    _setup(client)
    r = client.get("/api/v1/reports/stock-summary")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 2
    by_sku = {row["sku"]: row for row in rows}
    assert by_sku["LOW-001"]["needs_reorder"] is True
    assert by_sku["OK-001"]["needs_reorder"] is False


def test_low_stock(client):
    _setup(client)
    r = client.get("/api/v1/reports/low-stock")
    assert r.status_code == 200
    rows = r.json()
    skus = [row["sku"] for row in rows]
    assert skus == ["LOW-001"]
    assert rows[0]["available"] == 10
    assert rows[0]["reorder_point"] == 50
    assert rows[0]["suggested_order_qty"] == 100


def test_valuation(client):
    _setup(client)
    r = client.get("/api/v1/reports/valuation")
    assert r.status_code == 200
    body = r.json()
    # 10 * 100 + 100 * 200 = 1000 + 20000 = 21000 cents
    assert body["total_value_cents"] == 21000
    assert len(body["rows"]) == 2


def test_reports_empty_db(client):
    r = client.get("/api/v1/reports/stock-summary")
    assert r.status_code == 200
    assert r.json() == []
    r = client.get("/api/v1/reports/valuation")
    body = r.json()
    assert body["total_value_cents"] == 0
    assert body["rows"] == []
