"""Reusable helpers for tests - keep test bodies focused on behaviour."""
from __future__ import annotations

import sqlite3

from invtrack.domain import (
    Category,
    Product,
    StorageLocation,
    Supplier,
    Warehouse,
)
from invtrack.repositories.categories import CategoryRepository
from invtrack.repositories.locations import StorageLocationRepository
from invtrack.repositories.products import ProductRepository
from invtrack.repositories.suppliers import SupplierRepository
from invtrack.repositories.warehouses import WarehouseRepository


def make_product(conn: sqlite3.Connection, sku: str = "WID-001", **kw) -> Product:
    repo = ProductRepository(conn)
    return repo.create(Product(id=None, sku=sku, name=kw.get("name", f"Product {sku}"),
                               reorder_point=kw.get("reorder_point", 0),
                               reorder_qty=kw.get("reorder_qty", 0),
                               supplier_id=kw.get("supplier_id"),
                               category_id=kw.get("category_id"),
                               unit_cost_cents=kw.get("unit_cost_cents", 100),
                               unit_price_cents=kw.get("unit_price_cents", 250)))


def make_warehouse(conn: sqlite3.Connection, code: str = "MAIN") -> Warehouse:
    return WarehouseRepository(conn).create(Warehouse(id=None, code=code, name=f"WH {code}"))


def make_location(conn: sqlite3.Connection, warehouse_id: int, code: str = "A1") -> StorageLocation:
    return StorageLocationRepository(conn).create(
        StorageLocation(id=None, warehouse_id=warehouse_id, code=code)
    )


def make_supplier(conn: sqlite3.Connection, code: str = "ACME") -> Supplier:
    return SupplierRepository(conn).create(Supplier(id=None, code=code, name=f"Supplier {code}"))


def make_category(conn: sqlite3.Connection, name: str = "Widgets") -> Category:
    return CategoryRepository(conn).create(Category(id=None, name=name))
