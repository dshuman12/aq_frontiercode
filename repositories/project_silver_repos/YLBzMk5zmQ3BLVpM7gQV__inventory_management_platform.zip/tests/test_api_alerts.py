from __future__ import annotations


def _setup_with_low_stock(client):
    """Create a product with reorder_point=10 and only 3 on hand,
    so the low_stock job will raise an alert."""
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A"})
    loc_id = r.json()["id"]
    client.post("/api/v1/products", json={
        "sku": "LOW-001", "name": "Low", "reorder_point": 10, "reorder_qty": 50,
    })
    client.post("/api/v1/inventory/receive", json={
        "sku": "LOW-001", "location_id": loc_id, "quantity": 3,
    })


def _run_low_stock_job():
    """Run the job in-process against the configured db."""
    import os
    from invtrack.db import connect
    from invtrack.db.schema import migrate
    from invtrack.jobs import run_job
    from invtrack.jobs.low_stock_alerts import low_stock_alert_job
    conn = connect(os.environ["INVTRACK_DB"])
    try:
        migrate(conn)
        run_job(conn, "low_stock", low_stock_alert_job)
    finally:
        conn.close()


def test_list_alerts_empty(client):
    r = client.get("/api/v1/alerts")
    assert r.status_code == 200
    page = r.json()
    assert page["total"] == 0
    assert page["items"] == []


def test_alert_appears_after_job(client):
    _setup_with_low_stock(client)
    _run_low_stock_job()
    r = client.get("/api/v1/alerts")
    assert r.status_code == 200
    page = r.json()
    assert page["total"] == 1
    alert = page["items"][0]
    assert alert["alert_type"] == "low_stock"
    assert alert["resolved_at"] is None


def test_resolve_alert(client):
    _setup_with_low_stock(client)
    _run_low_stock_job()
    page = client.get("/api/v1/alerts").json()
    alert_id = page["items"][0]["id"]
    r = client.post(f"/api/v1/alerts/{alert_id}/resolve")
    assert r.status_code == 200
    body = r.json()
    assert body["resolved"] is True

    # Default list excludes resolved
    page = client.get("/api/v1/alerts").json()
    assert page["total"] == 0


def test_include_resolved(client):
    _setup_with_low_stock(client)
    _run_low_stock_job()
    page = client.get("/api/v1/alerts").json()
    alert_id = page["items"][0]["id"]
    client.post(f"/api/v1/alerts/{alert_id}/resolve")
    r = client.get("/api/v1/alerts?include_resolved=true")
    assert r.json()["total"] == 1


def test_resolve_unknown_alert_404(client):
    r = client.post("/api/v1/alerts/9999/resolve")
    assert r.status_code == 404


def test_resolve_already_resolved_is_ok(client):
    _setup_with_low_stock(client)
    _run_low_stock_job()
    alert_id = client.get("/api/v1/alerts").json()["items"][0]["id"]
    client.post(f"/api/v1/alerts/{alert_id}/resolve")
    r = client.post(f"/api/v1/alerts/{alert_id}/resolve")
    assert r.status_code == 200
    assert r.json().get("already_resolved") is True


def test_filter_by_type(client):
    _setup_with_low_stock(client)
    _run_low_stock_job()
    r = client.get("/api/v1/alerts?type=low_stock")
    assert r.json()["total"] == 1
    r = client.get("/api/v1/alerts?type=other_type")
    assert r.json()["total"] == 0
