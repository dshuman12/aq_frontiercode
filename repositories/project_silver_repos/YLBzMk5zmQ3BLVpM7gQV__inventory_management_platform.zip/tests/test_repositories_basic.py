from __future__ import annotations

from invtrack.domain import Product, Supplier, Warehouse, Category
from invtrack.repositories.products import ProductRepository
from invtrack.repositories.suppliers import SupplierRepository
from invtrack.repositories.warehouses import WarehouseRepository
from invtrack.repositories.categories import CategoryRepository


def test_create_and_fetch_product(conn):
    cats = CategoryRepository(conn)
    sups = SupplierRepository(conn)
    products = ProductRepository(conn)

    cat = cats.create(Category(id=None, name="Widgets"))
    sup = sups.create(Supplier(id=None, code="ACME", name="Acme Co"))
    p = products.create(Product(
        id=None, sku="WID-001", name="Widget A",
        category_id=cat.id, supplier_id=sup.id,
        unit_cost_cents=100, unit_price_cents=250,
    ))
    assert p.id is not None
    assert products.get_by_sku("WID-001") == p


def test_unique_sku(conn):
    products = ProductRepository(conn)
    products.create(Product(id=None, sku="DUP-001", name="A"))
    import sqlite3
    import pytest
    with pytest.raises(sqlite3.IntegrityError):
        products.create(Product(id=None, sku="DUP-001", name="B"))


def test_warehouse_lookup(conn):
    wh = WarehouseRepository(conn)
    w = wh.create(Warehouse(id=None, code="MAIN", name="Main DC"))
    assert wh.get_by_code("MAIN") == w
    assert wh.get_by_code("nope") is None
