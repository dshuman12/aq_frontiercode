from __future__ import annotations


def _bootstrap(client) -> dict:
    """Set up enough catalog to write a PO. Returns dict of useful ids."""
    client.post("/api/v1/suppliers", json={"code": "ACME", "name": "Acme"})
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "Main"})
    r = client.post("/api/v1/warehouses/MAIN/locations", json={"code": "A-01"})
    loc_id = r.json()["id"]
    client.post("/api/v1/products", json={"sku": "WID-001", "name": "Widget"})
    client.post("/api/v1/products", json={"sku": "GAD-001", "name": "Gadget"})
    return {"loc_id": loc_id}


def test_create_po_draft(client):
    _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-001",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [
            {"sku": "WID-001", "quantity": 50, "unit_cost_cents": 100},
            {"sku": "GAD-001", "quantity": 10, "unit_cost_cents": 200},
        ],
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["po_number"] == "PO-001"
    assert body["status"] == "draft"
    assert len(body["lines"]) == 2


def test_full_lifecycle(client):
    info = _bootstrap(client)
    loc_id = info["loc_id"]

    # Draft
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-002",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 30, "unit_cost_cents": 95}],
    })
    po = r.json()
    po_id = po["id"]
    line_id = po["lines"][0]["id"]

    # Submit
    r = client.post(f"/api/v1/purchase-orders/{po_id}/submit")
    assert r.status_code == 200
    assert r.json()["status"] == "submitted"

    # Receive
    r = client.post(f"/api/v1/purchase-orders/{po_id}/receive", json={
        "receipts": [{"line_id": line_id, "quantity": 30, "location_id": loc_id}],
    })
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "received"


def test_partial_receipt(client):
    info = _bootstrap(client)
    loc_id = info["loc_id"]
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-PART",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 100, "unit_cost_cents": 50}],
    })
    po = r.json()
    po_id = po["id"]
    line_id = po["lines"][0]["id"]
    client.post(f"/api/v1/purchase-orders/{po_id}/submit")
    r = client.post(f"/api/v1/purchase-orders/{po_id}/receive", json={
        "receipts": [{"line_id": line_id, "quantity": 30, "location_id": loc_id}],
    })
    assert r.json()["status"] == "partial"
    r = client.post(f"/api/v1/purchase-orders/{po_id}/receive", json={
        "receipts": [{"line_id": line_id, "quantity": 70, "location_id": loc_id}],
    })
    assert r.json()["status"] == "received"


def test_overreceipt_rejected(client):
    info = _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-OVER",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 10, "unit_cost_cents": 100}],
    })
    po = r.json()
    client.post(f"/api/v1/purchase-orders/{po['id']}/submit")
    r = client.post(f"/api/v1/purchase-orders/{po['id']}/receive", json={
        "receipts": [{"line_id": po["lines"][0]["id"], "quantity": 11,
                      "location_id": info["loc_id"]}],
    })
    assert r.status_code == 409


def test_unknown_supplier_404(client):
    client.post("/api/v1/warehouses", json={"code": "MAIN", "name": "M"})
    client.post("/api/v1/products", json={"sku": "WID-001", "name": "X"})
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-UNK",
        "supplier_code": "NOPE",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_cost_cents": 1}],
    })
    assert r.status_code == 404


def test_empty_lines_rejected(client):
    _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-NO",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [],
    })
    assert r.status_code == 422


def test_get_po_by_id(client):
    _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-GET",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 5, "unit_cost_cents": 100}],
    })
    po_id = r.json()["id"]
    r = client.get(f"/api/v1/purchase-orders/{po_id}")
    assert r.status_code == 200
    assert r.json()["po_number"] == "PO-GET"


def test_list_filter_by_status(client):
    info = _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-DRAFT",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_cost_cents": 1}],
    })
    draft_id = r.json()["id"]
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-SUB",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 1, "unit_cost_cents": 1}],
    })
    sub_id = r.json()["id"]
    client.post(f"/api/v1/purchase-orders/{sub_id}/submit")

    r = client.get("/api/v1/purchase-orders?status=draft")
    page = r.json()
    assert page["total"] == 1
    assert page["items"][0]["po_number"] == "PO-DRAFT"


def test_cancel_draft(client):
    _bootstrap(client)
    r = client.post("/api/v1/purchase-orders", json={
        "po_number": "PO-CAN",
        "supplier_code": "ACME",
        "warehouse_code": "MAIN",
        "lines": [{"sku": "WID-001", "quantity": 5, "unit_cost_cents": 50}],
    })
    po_id = r.json()["id"]
    r = client.post(f"/api/v1/purchase-orders/{po_id}/cancel")
    assert r.status_code == 200
    assert r.json()["status"] == "cancelled"
