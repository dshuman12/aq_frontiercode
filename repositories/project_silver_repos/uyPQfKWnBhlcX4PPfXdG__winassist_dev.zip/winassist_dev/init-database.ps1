# Database Initialization Script for WinAssist
# This script initializes the database with all required tables

Write-Host "Initializing WinAssist Database..." -ForegroundColor Green
Write-Host ""

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Host "ERROR: .env file not found!" -ForegroundColor Red
    Write-Host "Please create a .env file with DATABASE_URL" -ForegroundColor Yellow
    exit 1
}

# Read DATABASE_URL from .env
$envContent = Get-Content ".env" | Where-Object { $_ -match "^DATABASE_URL=" }
if (-not $envContent) {
    Write-Host "ERROR: DATABASE_URL not found in .env file!" -ForegroundColor Red
    exit 1
}

# Extract DATABASE_URL and convert host.docker.internal to localhost for local execution
$databaseUrl = $envContent -replace "^DATABASE_URL=", ""
$databaseUrl = $databaseUrl -replace "host\.docker\.internal", "localhost"

Write-Host "Database URL: $($databaseUrl -replace ':[^:@]+@', ':****@')" -ForegroundColor Cyan
Write-Host ""

# Set environment variable for Python script
$env:DATABASE_URL = $databaseUrl

# Check if Python is available
try {
    $pythonVersion = python --version 2>&1
    Write-Host "Using Python: $pythonVersion" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Python not found! Please install Python 3.11 or later." -ForegroundColor Red
    exit 1
}

# Change to backend/api directory
Push-Location "backend\api"

try {
    # Check if required packages are installed
    Write-Host "Checking dependencies..." -ForegroundColor Cyan
    $hasAsyncpg = python -c "import asyncpg" 2>&1
    $hasDotenv = python -c "import dotenv" 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Installing required packages..." -ForegroundColor Yellow
        pip install asyncpg python-dotenv
    }
    
    # Run the setup script
    Write-Host ""
    Write-Host "Running database setup..." -ForegroundColor Cyan
    python setup_database.py
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "Database initialization completed successfully!" -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "Database initialization failed!" -ForegroundColor Red
        exit 1
    }
} finally {
    Pop-Location
}

