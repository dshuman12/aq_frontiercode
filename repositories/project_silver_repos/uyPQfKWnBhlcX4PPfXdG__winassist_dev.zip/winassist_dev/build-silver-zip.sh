#!/usr/bin/env bash
set -euo pipefail

# Repo directory (directory containing this script)
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT="$(dirname "$REPO_DIR")"
BASE="$(basename "$REPO_DIR")"

# Output zip lives inside the repo; build in /tmp then mv so zip never includes itself mid-write.
archive_name="${SILVER_ZIP_NAME:-winassist.zip}"
OUT="${REPO_DIR}/${archive_name}"

echo "Repo:    ${REPO_DIR}"
echo "Archive: ${OUT}"
echo "Inner:   ${BASE}/ (paths in zip are ${BASE}/.git/ ...)"
echo

rm -f "$OUT"
rm -f "${REPO_DIR}/winassist-everything.zip" "${REPO_DIR}/winassist-everything-nested.zip" \
  "${REPO_DIR}/pygroup.zip" "${REPO_DIR}/pygroup-everything.zip" "${REPO_DIR}/pygroup-everything-nested.zip" 2>/dev/null || true

if ! command -v zip >/dev/null 2>&1; then
  echo "ERROR: install the zip package (apt install zip). The Silver uploader is picky;" >&2
  echo "  Python-only zips sometimes fail; this script uses: zip -r ... ${BASE}/" >&2
  exit 1
fi

# Keep .git healthy and packs consistent before archiving.
(cd "$REPO_DIR" && git gc --quiet 2>/dev/null || true)

tmp="$(mktemp "${TMPDIR:-/tmp}/silver-upload.XXXXXX.zip")"
rm -f "$tmp"
cleanup() { rm -f "$tmp"; }
trap cleanup EXIT

echo "Creating zip from parent directory (includes .git; excludes node_modules, build zips)..."
(
  cd "$PARENT"
  zip -qr "$tmp" "$BASE" \
    -x "${BASE}/node_modules/*" \
    -x "${BASE}/**/node_modules/*" \
    -x "${BASE}/dist/*" \
    -x "${BASE}/*.zip"
)

mv "$tmp" "$OUT"
trap - EXIT

# With pipefail, "unzip | grep -q" can return 141 (SIGPIPE) when grep exits early on a match.
list_zip() { unzip -l "$OUT"; }

if ! grep -Fq "${BASE}/.git/HEAD" < <(list_zip); then
  echo "ERROR: ${OUT} missing ${BASE}/.git/HEAD" >&2
  exit 1
fi

if ! grep -Eq "${BASE}/\\.git/objects/pack/[^/]+\\.pack" < <(list_zip); then
  echo "WARNING: no .git/objects/pack/*.pack found — shallow or broken clone?" >&2
fi

echo "zip -t (integrity)..."
unzip -tqq "$OUT"

ls -lh "$OUT"
echo
echo "Upload: ${OUT}"
echo "Silver expects one top-level folder (${BASE}/); Dockerfile should use COPY . . after strip."
echo "Do not list .git in .dockerignore."
echo "Done."
