# Step funnel analytics – how counts increase

## When do step counts increase?

Step counts increase when a **user session** reaches a **flow step** and the widget sends a **step event** to the backend.

1. **User opens the bot** (e.g. via Test Widget, embed, or shareable link).
2. **Widget runs the flow** and executes nodes (greeting, input, language, API, etc.).
3. **After each node runs**, the widget calls `reportFlowStep(nodeId, label)`.
4. **That sends a POST** to `/v1/project-analytics/step-event` with:
   - `project_id` (frontend project for dashboard)
   - `session_id` (one per browser session)
   - `node_id`, `node_label`
5. **Backend stores** one row per (project, session, node) in `flow_step_events`.
6. **Dashboard** reads from `flow_step_events` and shows:
   - **Step funnel:** how many sessions reached each step, completion rate, drop-off.
   - **Daily usage:** sessions per day.

So **counts only increase when**:

- The widget script actually calls `reportFlowStep` (script must be generated **after** step analytics was added).
- The widget has **project ID and API key** so it can authenticate the step-event request (Test Widget preview and **embed** do this; see below).

---

## Why did I see no analytics for my frontend project?

Common causes:

### 1. **Test Widget preview wasn’t sending events (fixed)**

The preview runs an **inline** script. That script did not have `data-project-id` or `data-api-key` set, so `reportFlowStep` exited early and never sent anything.

**Fix applied:** Test Widget now fetches widget config and passes `projectId` and `apiKey` into the script before it runs. After pulling the latest code, **generate the widget again** in Test Widget and use the preview – step events should be sent and the funnel should update.

### 2. **Widget script is old (no step reporting)**

If the widget was saved **before** step analytics was added, the saved script does not contain `reportFlowStep`.

**What to do:** Open **Test Widget** for your frontend project and click **Generate & Save** again. That regenerates and saves a script that includes step reporting.

### 3. **Using the shareable link (/widget/:projectId)**

The **shareable link** loads the saved script but does not set `data-project-id` or `data-api-key` on the script tag. So when the script runs, it has no API key and step-event requests are not sent (or would be 401).

**What to do for analytics:**

- **Test Widget:** Use the in-app Test Widget and run the flow in the preview; after the fix above, analytics will be recorded.
- **Real users:** Use the **embed code** from Project Dashboard (Widget / embed code). When that code runs on your site, it sets `data-project-id`, `data-api-key`, and `data-api-url` on the script tag, so step events are sent and counts increase.

### 4. **No one has run the flow yet**

The funnel is built from **sessions that reached at least one step**. If no session has run the flow (or no step event was sent), the funnel and daily usage will be empty.

**What to do:** Run the bot once in Test Widget (with the new script and the preview fix), then refresh the Project Dashboard and select the project and date range.

---

## Checklist to see analytics

1. **Run migration 003** (if not already):  
   Run the SQL migration in `backend/api/migrations/003_flow_step_analytics.sql` (example: `psql $DATABASE_URL -f migrations/003_flow_step_analytics.sql`).
2. **Re-save the widget:** Open your frontend project → **Test Widget** → **Generate & Save**.
3. **Use the preview:** In Test Widget, run the flow in the preview (click through a few steps). Step events should be sent.
4. **Open Project Dashboard:** Select your **frontend project** and the right **period** (e.g. Last 7 days). You should see **Step funnel** and **Daily usage**.
5. **For production:** Use the **embed code** from the dashboard on your site so real users’ steps are recorded.

---

## Quick check in the browser

1. Open Test Widget and generate the widget (so the preview loads).
2. Open DevTools → **Network**.
3. Run the flow in the preview (e.g. click through greeting and one more step).
4. Look for **POST** requests to **`/v1/project-analytics/step-event`**. If you see them with status **204**, step events are being recorded.
