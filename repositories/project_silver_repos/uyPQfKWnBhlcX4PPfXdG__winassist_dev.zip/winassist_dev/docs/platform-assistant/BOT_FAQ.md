# WinAssist Platform Master Knowledge Base

## What is WinAssist?
WinAssist is an enterprise conversation automation platform for creating, testing, publishing, and operating AI assistants. It combines an AI Agent builder, a Chat Flow builder, knowledge/RAG management, tools, templates, analytics, channel setup, governance, and workspace collaboration.

## What can users build in WinAssist?
- Customer support assistants that answer FAQs, classify issues, route users, and escalate when needed.
- Sales qualification assistants that ask lead questions, recommend products, and capture contact details.
- HR and internal policy assistants that answer employee questions from trusted documents.
- IT helpdesk assistants that collect issue details, run tool actions, and create support tickets.
- Claims, onboarding, booking, feedback, and process automation flows.
- Web widgets and channel-connected assistants that combine guided conversation with AI responses.

## Platform navigation map
- `Dashboard`: workspace health, KPIs, activity trends, project performance, usage insights, sessions, messages, and tool growth.
- `Project Insight`: deep analytics for selected projects including funnels, bounce rate, completion, session replay, node performance, flow paths, response time, conversion analytics, device analytics, traffic source, user input insights, API performance, and alerts.
- `Projects`: list and manage user projects.
- `AI Agent`: build backend AI brains with prompts, model settings, tools, memory, RAG, intents, entities, guardrails, evaluation, and API keys.
- `Chat Flow`: build frontend conversation experiences with nodes, branches, forms, quick replies, assistant handoff, and widget behavior.
- `Knowledge Base`: upload documents, import URLs, create collections, bind knowledge to bots, and test retrieval quality.
- `Tools`: create, edit, test, and manage reusable backend tools.
- `Integrations`: connector marketplace and workspace-level connections.
- `Channels`: channel overview for web, WhatsApp, Telegram, and Instagram surfaces.
- `WhatsApp Setup`: connect WhatsApp Business assets, validate the connection, link a bot, send tests, manage templates, and manage WhatsApp Flows.
- `Templates`: browse, preview, rate, publish, reuse, and delete starter templates for Chat Flow and AI Agent projects.
- `Publish Center`: release governance, staging/production promotion, approval rules, release history, comparison, rollback, and audit visibility.
- `Contacts`: customer profiles, attributes, segments, and targeting rules for campaigns and automation.
- `Campaigns`: scheduled, triggered, and goal-based conversational campaigns with reusable journeys.
- `Inbox`: shared support workspace for human handoff, agent assist, and conversation operations.
- `Settings`: profile details, account password, and tool settings.
- `Billing`: billing and account plan area.
- `Help / Support Assistant`: asks questions against this platform knowledge base.

## Core product architecture
- `AI Agent` is the backend brain. It decides what to say, what tool to call, which knowledge to retrieve, which intent was detected, which entities were extracted, and when to escalate.
- `Chat Flow` is the frontend conversation path. It controls the user experience, conversation steps, quick replies, forms, branches, delays, API nodes, assistant nodes, and widget presentation.
- `Knowledge Base` is the trusted source layer. It stores business documents, URL sources, collections, bot bindings, and retrieval tests.
- `Tools` are callable actions used by AI agents or generated flows. They can perform API calls, lookups, business logic, or custom Python tool logic.
- `Channels` deliver the assistant outside the builder. Web widgets and WhatsApp are the main active surfaces in the current platform.
- `Publish Center` protects releases by adding governance, review, rollback, version comparison, and audit history.
- `Dashboard` and `Project Insight` close the loop by showing performance, user behavior, response quality, and improvement opportunities.

## AI Agent overview
Purpose:
- Build backend reasoning logic for bots.
- Configure the bot model, persona, prompt, tools, memory, retrieval, intents, entities, guardrails, evaluation, and release notes.
- Generate or regenerate a project API key for runtime calls.
- Run NLU tests and evaluations before publishing.

Use it when:
- The bot must reason, answer from documents, call APIs, classify intents, extract entities, or enforce business rules.
- You need a stable backend assistant that can be reused by a Chat Flow, widget, WhatsApp connection, or API client.

Important AI Agent settings:
- Bot name, description, business use case, tone, response style, default language, and supported languages.
- System prompt with role, business rules, escalation behavior, answer style, and constraints.
- Retrieval mode: `Hybrid`, `RAG-first`, `Intent-first`, or `Freeform`.
- RAG controls: enable RAG, enable memory, Top K, chunk size, and chunk overlap.
- Knowledge bindings: collection IDs attached from the Knowledge Base.
- Evaluation checklist, evaluation cases, release notes, and improvement suggestions.
- Intent, entity, guardrail, and policy configuration stored with the project flow.

## How to create an AI Agent
1. Open `AI Agent`.
2. Create a new backend project or open an existing AI Agent.
3. Fill in the bot name, description, use case, tone, response style, and language settings.
4. Write the system prompt with the bot role, rules, allowed actions, disallowed actions, escalation policy, and answer format.
5. Enable RAG if the bot must answer from documents.
6. Open `Knowledge Base`, upload source documents, create a collection, and bind that collection to the AI Agent.
7. Configure retrieval mode, Top K, chunk size, and chunk overlap.
8. Add tools if the bot must call APIs, lookup data, update records, or perform actions.
9. Add intents and entities if the bot must classify user goals or extract structured fields.
10. Add guardrails for restricted topics, sensitive actions, compliance, and human escalation.
11. Run intent tests, entity tests, combined NLU analysis, and evaluation cases.
12. Save the project and connect it to a Chat Flow, widget, or WhatsApp channel.

## AI Agent prompt guidance
- Start with the assistant role and business domain.
- Include exact product, policy, support, or sales boundaries.
- Tell the bot to use Knowledge Base documents when RAG is enabled.
- Tell the bot not to invent facts when knowledge is missing.
- Define escalation rules for billing disputes, compliance issues, complaints, dangerous topics, or uncertain answers.
- Define tone, response length, formatting, and whether to ask follow-up questions.
- Add examples for common questions and ideal responses.

## Retrieval modes explained
- `Hybrid`: use both structured intent behavior and document retrieval. Best default for assistants that answer and act.
- `RAG-first`: prioritize Knowledge Base passages before freeform reasoning. Best for policy, FAQ, compliance, technical docs, and manuals.
- `Intent-first`: classify the user's goal first, then route to a flow, tool, or scripted action. Best for workflows like booking, refund, order status, or ticket creation.
- `Freeform`: let the model respond mostly from prompt and context. Use only when strict grounding is not required.

## RAG settings explained
- `Top K`: how many matching chunks are returned to the bot. Use 3 to 5 for support FAQs and 5 to 8 for larger manuals.
- `Chunk size`: how large each text block is during retrieval. Use 600 to 1200 characters for procedural documents.
- `Chunk overlap`: repeated text between chunks so sentence context is not lost. Use 80 to 150 characters for most docs.
- `RAG enabled`: allows the bot to retrieve from bound knowledge collections.
- `Memory enabled`: allows the bot to use conversation context when responding.

## Intent management
Purpose:
- Intents represent user goals such as `refund_request`, `book_demo`, `order_status`, `pricing_question`, `technical_issue`, or `human_handoff`.
- Intent tests help verify whether the bot recognizes the correct goal from user messages.

Recommended steps:
- Create clear intent names and descriptions.
- Add training utterances and alternate phrasing.
- Add negative examples for confusing intents.
- Set confidence thresholds for high-risk actions.
- Map each intent to a flow branch, backend tool, answer strategy, or escalation rule.
- Review overlap warnings and add better examples when two intents are confused.

## Entity management
Purpose:
- Entities are structured values extracted from user messages, such as name, email, phone, city, order ID, booking date, product name, budget, issue type, or language.

Recommended steps:
- Define required and optional entities for each workflow.
- Use regex, dictionary, system entities, or LLM-assisted extraction depending on the field.
- Add synonyms, aliases, examples, validation rules, and normalization rules.
- Ask confirmation questions when extraction confidence is low.
- Store extracted values in bot context so Chat Flow, tools, and API calls can reuse them.

## Guardrails and escalation
Use guardrails when:
- A topic is legally, medically, financially, or operationally sensitive.
- The bot must not make commitments, refunds, approvals, or guarantees.
- A human must review complaints, account access, policy exceptions, or unsafe content.

Good guardrail behavior:
- State the limit clearly.
- Offer the safe next step.
- Ask for required details only when appropriate.
- Escalate to a human or support queue when confidence is low or the policy requires it.

## Chat Flow overview
Purpose:
- Build the visible conversation journey users experience in a web widget or channel.
- Combine deterministic nodes with AI handoff.
- Collect data, show messages, branch on answers, call APIs, and route users.

Common Chat Flow nodes:
- Text/message nodes for bot messages.
- User input nodes for free text.
- Quick reply nodes for button-style choices.
- Condition, branch, switch, and merge nodes for logic.
- API nodes for external requests.
- Assistant/conversable agent nodes for AI Agent handoff.
- Form, calendar, document, OCR, image, and delay nodes for richer experiences.

Use Chat Flow when:
- You need guided steps instead of open-ended chat.
- You need forms, options, validation, branching, scheduling, or scripted onboarding.
- You want to control how the user reaches the AI Agent.

## Difference between AI Agent and Chat Flow
- `AI Agent`: backend decision and execution engine.
- `Chat Flow`: frontend conversation and user experience structure.
- Use `AI Agent` for reasoning, prompts, tools, RAG, intents, entities, and guardrails.
- Use `Chat Flow` for user-facing steps, UI nodes, forms, quick replies, routing, and widget behavior.
- A complete production assistant usually uses both: AI Agent for intelligence and Chat Flow for experience.

## How to create a complete platform bot
1. Define the business objective, audience, user questions, success metrics, and escalation rules.
2. Create the backend bot in `AI Agent`.
3. Configure the model, prompt, tone, response style, language, memory, retrieval, intents, entities, and guardrails.
4. Add tool integrations if the bot must perform actions.
5. Open `Knowledge Base` and upload trusted source documents or import URL sources.
6. Create a collection such as `Support Policy`, `Sales Catalog`, `Claims SOP`, `HR Handbook`, or `IT Runbook`.
7. Bind the collection to the target AI Agent.
8. Run retrieval tests for top user questions and verify the expected document appears in the top matches.
9. Build the frontend experience in `Chat Flow`.
10. Add assistant handoff nodes that call the AI Agent where open-ended reasoning is needed.
11. Test the widget preview and run real scenario tests.
12. Configure channels such as web widget or WhatsApp.
13. Use `Publish Center` for release checks, staging/production promotion, approval, and rollback readiness.
14. Monitor results in `Dashboard` and `Project Insight`.
15. Improve the bot from failed questions, analytics, support feedback, and evaluation results.

## Knowledge Base overview
Purpose:
- Turn business documents into bot-ready knowledge.
- Organize sources into collections by business purpose.
- Bind collections to the AI Agents that should use them.
- Test retrieval quality before production.

Supported source types:
- PDF, TXT, Markdown, HTML, CSV, JSON, DOCX, XLSX, and URL imports.

Recommended collection examples:
- `Sales Enablement`
- `Order Tracking`
- `Claims Policy`
- `Technical Troubleshooting`
- `Employee Benefits`
- `Returns Policy`
- `Pricing Catalog`
- `Onboarding Guide`

## How to add knowledge to a bot
1. Open `Knowledge Base`.
2. Upload a source document or import a public URL source.
3. Confirm the document is available and indexed.
4. Create a collection with a clear business purpose.
5. Add relevant documents to the collection.
6. Bind the collection to the correct AI Agent.
7. Run Retrieval Test with real user questions.
8. Confirm the returned chunks contain the expected answer.
9. Adjust documents, chunk size, overlap, or Top K if retrieval is weak.
10. Reprocess stale or corrected documents.
11. Retest in the AI Agent and Chat Flow before publishing.

## Retrieval Test guide
1. Use the exact question a real user would ask.
2. Test short questions, long questions, misspellings, and domain-specific terms.
3. Check whether the expected document is in the top results.
4. Check whether the selected chunk includes enough context to answer safely.
5. If results are weak, improve headings, add FAQ wording, split long documents, remove duplicate conflicting docs, or tune Top K and chunk size.
6. Reprocess the document and run the same question again.

## Tools overview
Purpose:
- Tools let bots perform actions beyond text generation.
- Tools can call APIs, run lookups, validate data, submit tickets, search knowledge, or integrate with business systems.

Use Tools when:
- The bot needs live information.
- The bot must create, update, or retrieve records.
- The bot must call a third-party API.
- A workflow requires deterministic business logic.

Tool workflow:
1. Open `Tools`.
2. Create or edit a tool with name, description, code, and parameters.
3. Attach the tool to an AI Agent when the bot should be allowed to use it.
4. Test the tool with realistic inputs.
5. Add prompt instructions that explain when the tool should be used.

## Code generation and custom tools
- WinAssist includes code generation and metadata extraction endpoints for tool creation.
- Tool attachments can be uploaded for tool execution.
- Generated tools should still be reviewed, tested, and constrained before production use.
- Do not expose secrets in tool code, prompts, frontend files, or public widget scripts.

## Widget preview and web deployment
Purpose:
- Test a Chat Flow in a live-like widget environment.
- Save or generate widget scripts for embedding.
- Use public widget viewer links for testing.

Widget deployment checklist:
- Confirm the Chat Flow project is saved.
- Open `Widget Preview` for the project.
- Test all expected conversation branches.
- Confirm assistant nodes call the correct AI Agent.
- Confirm API nodes have correct endpoints and handle errors.
- Save or generate the widget script.
- Verify the frontend `VITE_API_URL` is absolute and points to the backend.
- Verify backend widget static path settings allow script creation.
- Embed the script on the target website.
- Monitor widget sessions and messages in analytics.

## Channels overview
Purpose:
- Channels connect WinAssist assistants to external user surfaces.
- Current channel surfaces include web widget and WhatsApp; Telegram and Instagram appear in the channel overview as future/available surfaces depending on integration readiness.

Use Channels when:
- The bot works in preview but needs to reach users outside the builder.
- You need provider credentials, connection health, channel routing, templates, or message logs.

## WhatsApp setup overview
Purpose:
- Connect a customer-owned WhatsApp Business number to WinAssist with a guided setup flow.

WhatsApp setup steps:
1. Open `Channels` or `Integrations`, then choose WhatsApp.
2. Choose the setup method.
3. Connect the Meta account or provide required access information.
4. Discover or select Meta business assets.
5. Select the WhatsApp Business Account (WABA).
6. Select the phone number.
7. Link the connection to the correct bot/project.
8. Validate the connection.
9. Send a test message.
10. Finish setup and monitor the dashboard, message logs, and webhook events.

WhatsApp features:
- Connection list and connection details.
- Health, webhook, sync, and subscribed app status.
- Message logs with retries for failed messages.
- Webhook events.
- Channel dashboard.
- Template create, sync, view, and send.
- Flow create, edit, publish, runtime status, public key, callback/data endpoint, and send.
- Text, template, media, interactive, and flow message sending.

## Templates overview
Purpose:
- Help teams start quickly from reusable Chat Flow or AI Agent starters.

Template actions:
- Browse templates by type and category.
- Preview templates before using them.
- Open a full canvas preview.
- Create a project from a template.
- Publish an existing project as a template.
- Rate templates.
- Delete templates when allowed.

Use Templates when:
- You need faster setup.
- You want a repeatable architecture for support, sales, HR, lead generation, booking, or FAQ bots.
- A team wants standardized project patterns.

## Publish Center overview
Purpose:
- Add release governance to Chat Flow and AI Agent projects.
- Manage readiness checks, approvals, staging/production promotion, release snapshots, rollback, comparison, and audit history.

Publish Center responsibilities:
- Workspace governance policy.
- Require staging before production.
- Require approval before production.
- Create release snapshots.
- Promote releases across environments.
- Compare releases or compare a release with current project state.
- Roll back to a previous release.
- View governance audit logs.

Use Publish Center when:
- A bot is moving from test to live usage.
- Multiple people review changes.
- You need rollback protection.
- Prompt, knowledge, tool, or flow changes must be controlled.

## Dashboard overview
Purpose:
- Provide a workspace operating view of project volume, engagement, sessions, messages, tool growth, and activity trends.

Dashboard helps users:
- Track project creation and usage.
- Compare AI Agent and Chat Flow performance.
- Find top projects.
- Monitor sessions and messages over time.
- See recent activity and project mix.
- Make product, support, and operations decisions from data.

## Project Insight analytics
Purpose:
- Provide detailed analytics and diagnostics for selected projects.

Available analytics areas:
- KPI summary.
- Bounce rate.
- Completion rate.
- Average session duration.
- Funnel analytics.
- Timeline and daily session counts.
- Session-level metrics.
- Node performance and drop-off.
- Flow paths and user journeys.
- Session replay.
- Completion and abandonment analytics.
- Bot response time.
- Activity heatmap.
- Conversion analytics.
- User input insights and most asked questions.
- Returning vs new users.
- Device, browser, and OS distribution.
- Traffic source and referrer analytics.
- API node performance.
- Smart analytics alerts.

## Workspaces and team management
Purpose:
- Manage collaboration boundaries, members, invites, and roles.

Workspace concepts:
- Users can belong to workspaces.
- Workspaces contain projects, team members, invites, and governance context.
- Owners and admins can invite members and manage roles depending on permissions.
- Invites can be accepted through the invite flow.
- Members can be activated, deactivated, removed, or role-updated based on access level.

Recommended roles:
- Owner: full control over workspace, members, policies, and releases.
- Admin: manage members, projects, and operational setup.
- Builder: create and edit AI Agents, Chat Flows, tools, and knowledge.
- Analyst: review analytics, quality, and performance.
- Support: use inbox, conversation operations, and troubleshooting views.

## Authentication and accounts
Supported account flows:
- Register.
- Login.
- Current user profile.
- Update profile.
- Change password.
- Forgot password.
- Reset password.
- Optional OIDC/Keycloak-based authentication when configured.

Account troubleshooting:
- If login fails, verify credentials and backend auth service availability.
- If password reset fails, verify email/SMTP configuration and reset token expiry.
- If OIDC login fails, verify issuer, client ID, redirect URI, and frontend OIDC settings.

## Integrations and connectors
Purpose:
- Manage reusable external connections and connector definitions.
- Send text through connector transports where configured.
- Support future messaging and business-system integrations.

Use Integrations when:
- A workspace needs a reusable provider connection.
- A channel or tool needs external credentials.
- A user wants a marketplace-style connection setup instead of custom code.

## Contacts, Campaigns, and Inbox
Contacts:
- Build customer profiles, segments, and targeting rules.
- Support campaign and automation personalization.

Campaigns:
- Create scheduled, triggered, and goal-based conversational campaigns.
- Reuse messaging journeys.
- Support outbound engagement use cases.

Inbox:
- Run human handoff, support operations, agent assist, and shared conversation workflows.
- Use when a bot cannot fully resolve a user issue or a human review is required.

## OCR and document extraction
Purpose:
- Extract document fields using OCR and regex-assisted logic.

Use OCR when:
- A workflow needs to read information from uploaded documents.
- A bot must capture fields from forms, IDs, invoices, or other user-submitted files.

## End-to-end support bot playbook
1. Create an AI Agent for support.
2. Set tone to helpful, calm, and precise.
3. Add a system prompt that requires grounded answers and escalation when uncertain.
4. Upload product FAQs, support SOPs, SLA policies, troubleshooting guides, warranty docs, and escalation policy into Knowledge Base.
5. Create collections by domain, such as `Product FAQ`, `Troubleshooting`, `Returns`, and `SLA`.
6. Bind the collections to the support AI Agent.
7. Add intents such as `technical_issue`, `billing_question`, `refund_request`, `human_handoff`, and `product_how_to`.
8. Add entities such as email, order ID, product name, issue type, urgency, and phone number.
9. Build a Chat Flow that greets the user, captures issue type, asks required details, and hands off to the AI Agent.
10. Add API/tools for ticket creation or order lookup if needed.
11. Test common issues, edge cases, and escalation paths.
12. Publish through Publish Center.
13. Monitor questions, drop-offs, and response quality in Project Insight.

## End-to-end sales bot playbook
1. Create an AI Agent for sales qualification.
2. Add product catalog, pricing, plan comparison, case studies, and objection-handling docs to Knowledge Base.
3. Add intents such as `pricing_question`, `book_demo`, `compare_plans`, `product_fit`, and `talk_to_sales`.
4. Add entities such as name, email, company, industry, budget, team size, timeline, and product interest.
5. Build a Chat Flow that qualifies the lead, asks follow-up questions, and routes high-intent leads to sales.
6. Add tools for CRM submission, calendar booking, or lead scoring.
7. Test pricing, demo, objection, and unsupported-region questions.
8. Monitor conversion and completion analytics.

## End-to-end HR bot playbook
1. Create an internal AI Agent for HR policy support.
2. Upload HR handbooks, leave policy, travel policy, reimbursement policy, conduct policy, and benefits docs.
3. Use RAG-first retrieval so answers are grounded in policy.
4. Add guardrails for legal, disciplinary, compensation, and sensitive personal questions.
5. Add entities such as employee type, location, policy topic, date, and request type.
6. Build a Chat Flow for common HR requests.
7. Escalate sensitive or ambiguous cases to HR.
8. Retest after every policy update.

## End-to-end IT helpdesk bot playbook
1. Create an AI Agent for IT support.
2. Upload runbooks, troubleshooting guides, system status docs, password reset procedures, VPN docs, and escalation matrix.
3. Add intents such as `password_reset`, `vpn_issue`, `software_access`, `hardware_issue`, and `incident_report`.
4. Add entities such as device type, OS, username, error code, urgency, and affected application.
5. Use tools for ticket creation, status lookup, or diagnostic API calls.
6. Build a Chat Flow that captures issue details before AI troubleshooting.
7. Escalate urgent incidents or repeated failures.

## Bot answers from wrong document
Checklist:
- Reproduce the exact user query in Knowledge Base Retrieval Test.
- Confirm the expected document appears in the top retrieved chunks.
- Confirm the document status is indexed.
- Confirm the correct collection is bound to the correct AI Agent.
- Check whether another bound collection has outdated or conflicting content.
- Improve document headings and add FAQ-style wording for common user questions.
- Increase Top K if the right document is close but not selected.
- Adjust chunk size and overlap if answers are split across chunks.
- Reprocess the corrected document.
- Retest in AI Agent, Chat Flow, widget preview, and channel.

## Bot says support knowledge is not available
Checklist:
- Ensure `docs/platform-assistant/BOT_FAQ.md` exists.
- Ensure the backend process can read the deployed `docs/platform-assistant` folder.
- Ensure `SUPPORT_ASSISTANT_DOCS_ROOT` points to the correct path if a custom path is used.
- Ensure `SUPPORT_ASSISTANT_FAQ_FILE` is correct if it is customized.
- Ensure the backend container includes the docs folder or has it mounted.
- Restart or redeploy the backend after documentation or path changes.
- Check backend logs for support assistant docs root warnings.
- Ensure the request includes a valid auth token.
- Ensure `/v1/support-assistant/ask` is reachable from the frontend.

## Uploaded file fails indexing
Checklist:
- Check file format and readability.
- Convert legacy or scanned files into readable supported formats.
- Remove corrupt pages, password protection, or unsupported embedded content.
- Re-upload a cleaner source.
- Reprocess the document.
- Verify the status changes to indexed.
- Run retrieval test with expected questions.

## Bot works in builder but not widget
Checklist:
- Confirm the Chat Flow is saved.
- Confirm the widget preview uses the correct project ID.
- Confirm the assistant node points to the correct AI Agent and API key.
- Confirm the backend `/v1` API is reachable from the frontend environment.
- Confirm CORS allows the widget origin.
- Confirm widget script generation succeeded.
- Confirm `VITE_API_URL`, `VITE_WIDGET_STATIC_BASE_PATH`, and backend widget static path settings are correct.
- Check browser console and backend logs for failed API calls.

## Bot works in UI but not WhatsApp
Checklist:
- Verify WhatsApp connection status, webhook status, subscribed app status, and health status.
- Validate the WhatsApp connection.
- Confirm the correct AI Agent or project is linked to the connection.
- Confirm WABA ID, phone number ID, business phone number, access token, app secret, and graph version are correct.
- Send a test text message.
- Check message logs, webhook events, and retry failed messages.
- Confirm template status if sending template messages.
- Confirm flow runtime public key and callback/data endpoint if using WhatsApp Flows.

## WhatsApp template troubleshooting
Checklist:
- Confirm template name, language, category, and components.
- Sync template from Meta to update status.
- Use an approved template for outbound initiated messages.
- Check rejected or failed status details.
- Verify variables match the template structure.
- Test with a valid destination phone number.

## WhatsApp Flow troubleshooting
Checklist:
- Confirm the flow exists and has valid raw data.
- Confirm endpoint URI or data channel URI is configured when needed.
- Generate or verify runtime public key.
- Publish the flow before production use.
- Check runtime callback events.
- Confirm Meta signature/public key status.
- Send a saved flow test message.

## Analytics missing or incorrect
Checklist:
- Confirm the selected workspace and project are correct.
- Confirm the selected time range includes activity.
- Confirm widget sessions are recorded.
- Confirm flow messages and session metadata are being sent from the widget.
- Confirm project type is correct: AI Agent vs Chat Flow.
- Confirm API performance events are recorded for API nodes.
- Check backend analytics endpoints if UI charts are empty.

## Publish and rollback troubleshooting
Checklist:
- Select the correct project in Publish Center.
- Check workspace governance policy.
- Create a staging release before production if staging is required.
- Ensure required approval is complete before production if approval is required.
- Compare current project state with the target release.
- Use rollback only when a previous release is known good.
- Check governance audit log after publish or rollback.

## Login and workspace access troubleshooting
Checklist:
- Confirm the user is logged in and has a valid session.
- Confirm the correct workspace is selected.
- Confirm the user's role allows the requested action.
- Confirm an invite is accepted and not expired.
- Ask an owner or admin to reactivate the member if disabled.
- For OIDC login, verify Keycloak/OIDC frontend and backend environment values.

## API and deployment facts
- Backend API routes are mounted under `/v1`.
- Health checks exist at `/health` and `/v1/health`.
- The support assistant endpoint is `/v1/support-assistant/ask`.
- Project APIs include project CRUD, API key regeneration, intent test, entity test, combined NLU analysis, evaluation, and improvement suggestions.
- Knowledge APIs include uploads, URL import, document list, delete, reprocess, collections, and retrieval test.
- Governance APIs include policy, releases, promote, compare, rollback, and audit.
- Analytics APIs include workspace stats, project analytics, widget config, widget scripts, session metadata, and API performance events.
- WhatsApp APIs include connections, messages, retries, webhooks, dashboard, templates, flows, asset discovery, validation, sync, and sends.

## Important environment settings
Backend:
- `DATABASE_URL`: database connection string.
- `JWT_SECRET`: token signing secret.
- `FRONTEND_URL`: frontend base URL.
- `INVITE_BASE_URL`: invite link base URL.
- `BACKEND_URL`: backend public base URL.
- `WIDGET_STATIC_BASE_PATH`: filesystem path for generated widget scripts.
- `WIDGET_SCRIPT_BASE_URL`: public base URL for widget scripts.
- `SUPPORT_ASSISTANT_DOCS_ROOT`: optional support assistant docs path override.
- `SUPPORT_ASSISTANT_FAQ_FILE`: optional support assistant FAQ filename override.
- `OPENAI_API_KEY` and `OPENAI_AGENT_MODEL`: AI provider configuration.
- `TAVILY_API_KEY`: search/tool configuration when used.
- `WHATSAPP_*`: WhatsApp provider, webhook, Meta, and channel settings.
- `SMTP_*`: email settings for account and invite flows.
- `OIDC_*` or `KEYCLOAK_*`: identity provider settings.
- `KNOWLEDGE_UPLOADS_ROOT`: knowledge upload storage path.
- `TOOL_ATTACHMENTS_ROOT`: tool attachment storage path.

Frontend:
- `VITE_API_URL`: backend API base URL.
- `VITE_APP_URL`: frontend app URL.
- `VITE_WIDGET_STATIC_BASE_PATH`: widget static script base path.
- `VITE_WHATSAPP_META_CONNECT_URL`: Meta connect URL.
- `VITE_WHATSAPP_EMBEDDED_SIGNUP_ENABLED`: embedded signup feature flag.
- `VITE_OIDC_*`: OIDC/Keycloak frontend settings.

## Deployment notes
- Azure deployment copies the repository to the VM, syncs it to `/winassist`, mirrors `docs/platform-assistant` into `backend/api/docs/platform-assistant`, and rebuilds containers with Docker Compose.
- The backend Docker image is built from `backend/api`, so platform docs must exist inside that build context or be provided through `SUPPORT_ASSISTANT_DOCS_ROOT`.
- If the support bot works locally but not on the server, check whether the docs folder exists inside the running backend container.
- After editing this knowledge file, redeploy or restart the backend so the support assistant reads the latest content.

## Recommended support answer style
- Start with the direct answer.
- Give numbered steps for workflows.
- Mention the exact module name such as `AI Agent`, `Chat Flow`, `Knowledge Base`, `Publish Center`, or `WhatsApp Setup`.
- Include a troubleshooting checklist when the user reports a problem.
- Say when a feature is configuration-dependent or still part of a roadmap surface.
- Do not invent platform behavior that is not documented here.
- If knowledge is missing, tell the user which document, module, or setup area to check next.

## How do I create an AI agent quick answer
- Open `AI Agent`.
- Create a backend project.
- Configure prompt, model, tone, response style, language, RAG, tools, intents, entities, and guardrails.
- Bind Knowledge Base collections if the bot must answer from documents.
- Run tests and save the project.
- Connect the AI Agent to Chat Flow, widget, WhatsApp, or another channel.

## How do I publish a bot quick answer
- Validate the AI Agent and Chat Flow.
- Test widget and channel behavior.
- Open `Publish Center`.
- Create a release snapshot.
- Satisfy staging and approval policy.
- Promote to the target environment.
- Monitor analytics after release.

## How do I make the bot answer from my documents quick answer
- Upload documents in `Knowledge Base`.
- Create a collection.
- Bind the collection to the AI Agent.
- Enable RAG in the AI Agent.
- Run retrieval tests with real user questions.
- Retest the bot in Chat Flow or widget preview.

## How do I connect WhatsApp quick answer
- Open `WhatsApp Setup`.
- Connect or discover Meta assets.
- Select WABA and phone number.
- Link the bot.
- Validate the connection.
- Send a test message.
- Monitor message logs and webhook events.

## How do I troubleshoot bad answers quick answer
- Test retrieval with the exact bad question.
- Verify collection binding.
- Remove conflicting or outdated docs.
- Improve document headings and FAQ wording.
- Tune Top K, chunk size, and overlap.
- Reprocess docs and run evaluation cases before republishing.
