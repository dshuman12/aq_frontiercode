# WinAssist Feature Gap and UI Roadmap

## Purpose

This document lists the important product features WinAssist does **not** have yet, especially compared to a more mature low-code/no-code conversational platform, and the **UI changes** needed to start building them.

This is based on the current codebase state as read from:

- `frontend/src/App.jsx`
- `frontend/src/shared/page/*`
- `frontend/src/components/shared/*`
- `frontend/src/utils/codeGenerator.js`
- `backend/api/agentok_api/routers/*`
- `backend/api/agentok_api/services/*`

## Current WinAssist Position

WinAssist already has:

- Login and registration
- Workspace/team roles
- No-code backend builder
- No-code frontend builder
- Tool management
- Widget preview and shareable widget link
- Chat execution and streaming
- Frontend analytics for chatbot/widget flows

WinAssist is already a good **AI chatbot builder**, but it is **not yet a complete low-code/no-code conversational platform** for business, marketing, support, and multi-channel operations.

## Biggest Missing Product Areas

### 1. Omnichannel deployment

WinAssist currently focuses on the web/widget experience.

Missing:

- WhatsApp channel setup
- SMS channel setup
- Instagram DM integration
- Facebook Messenger integration
- Channel-specific templates and approvals
- Channel-specific analytics

Why this matters:

- A mature low-code/no-code conversational platform is usually channel-first, not only widget-first.

### 2. Campaign manager

WinAssist does not currently have a marketing campaign layer.

Missing:

- Broadcast campaign creation
- Scheduled campaigns
- Trigger-based campaigns
- Audience segmentation
- Template-based campaign creation
- Campaign performance tracking
- Conversion tracking by campaign

Why this matters:

- This is one of the biggest differences between WinAssist and enterprise conversational platforms.

### 3. Customer data and segmentation layer

WinAssist does not appear to have a customer profile or audience management system.

Missing:

- Unified contact/customer profiles
- Contact attributes
- Tags and segments
- Event-based targeting
- Customer history timeline
- Audience import/export

Why this matters:

- Low-code campaigning and support automation depend on reusable customer data.

### 4. Agent assist / live support workspace

WinAssist has chat execution, but not a support operations console.

Missing:

- Shared inbox / conversation queue
- Human handoff dashboard
- Agent assignment
- Internal notes
- SLA and ticket states
- Suggested replies / agent assist
- Escalation controls

Why this matters:

- Builder-only products are useful for demos and bot creation, but operational support teams need a live support UI.

### 5. Flow templates and guided setup

WinAssist has builders, but onboarding still looks builder-centric.

Missing:

- Ready-made templates by use case
- Use-case wizard for first project setup
- Starter templates for lead generation, support, FAQ, booking, feedback, commerce
- Template marketplace or library

Why this matters:

- A stronger no-code experience reduces blank-canvas friction.

### 6. Strong publishing and deployment controls

Widget testing exists, but deployment management is still limited.

Missing:

- Publish environments such as draft, staging, production
- Rollback/version history
- Release notes / publish history
- Domain-level embed management
- Channel deployment management
- Approval flow before publishing

Why this matters:

- Real teams need controlled releases, not only save-and-test.

### 7. Governance and admin features

Workspace basics exist, but enterprise governance is still light.

Missing:

- Organization-level admin panel
- Billing and usage screens
- Module-level access control
- Audit logs
- API key management UI per workspace/project
- Usage quotas and rate limits

Why this matters:

- Larger teams need governance before they trust the platform for production.

### 8. Analytics depth in the UI

The backend exposes many analytics endpoints, but the frontend is not yet using all of them.

Missing in UI:

- Session replay screen
- Bot response time charts
- Conversion analytics
- Returning vs new users
- Traffic source analytics
- Device/browser analytics
- User input insights
- API performance dashboard

Why this matters:

- The platform already has analytics potential, but the UI does not expose the full value yet.

### 9. Knowledge base / RAG management UI

There are signs of upload-based knowledge support, but the product does not yet expose a complete knowledge module.

Missing:

- Knowledge base page
- File upload manager
- Document status and indexing state
- Search over uploaded content
- Attach knowledge sources to bots/projects
- Delete/reprocess documents

Why this matters:

- A modern AI builder usually needs a clear RAG/knowledge workflow.

### 10. Better product polish for non-technical users

The current builder is powerful, but still oriented toward technical users.

Missing:

- Business-friendly language
- Guided creation flows
- Inline help and examples
- Better empty states
- Better publish and share states
- Reduced technical jargon around API keys, nodes, and flow structure

Why this matters:

- This is a major difference between low-code and truly no-code products.

## Known Incomplete or Weak Areas in Current Product

These are not only roadmap ideas; some are already visible as incomplete in the current codebase.

### Publish flow is incomplete

Current issue:

- `frontend/src/components/shared/project-list.jsx` shows `Publish feature coming soon`

Impact:

- There is no strong publish/deploy center from the project list.

### Knowledge upload appears incomplete

Current issue:

- `frontend/src/components/shared/chatpane.jsx` calls `/knowledge/uploads`
- Matching backend route was not found in the scanned routers

Impact:

- Knowledge/RAG workflow is likely unfinished or disconnected.

### Widget publishing flow is split

Current issue:

- Real widget saving uses `save-widget-script`
- Another `widget-script` route contains placeholder logic

Impact:

- Publishing architecture should be simplified and made clearer in the UI.

### Analytics backend is ahead of analytics UI

Current issue:

- Many analytics routes exist in backend
- Only a subset is visible in `project-dashboard.jsx`

Impact:

- Users cannot access the full analytics value from the current UI.

## UI Changes Needed

## Sidebar / Navigation Changes

Current sidebar:

- Dashboard
- Project Dashboard
- No-Code Backend
- No-Code Frontend
- Tools
- Team

Recommended additions:

- `Campaigns`
- `Channels`
- `Contacts`
- `Inbox`
- `Knowledge Base`
- `Templates`
- `Publish Center`
- `Settings / Billing / Usage`

Why:

- The current navigation is builder-heavy.
- To become a broader low-code/no-code platform, the product needs operational and business modules in navigation.

## Dashboard Changes

Current dashboard is builder analytics focused.

Add these widgets:

- Active channels
- Campaign performance summary
- Live conversations summary
- Team productivity summary
- Publish status summary
- Recent failed automations / alerts
- Knowledge base health

UI changes:

- Add top-level metric cards for business outcomes, not only project counts
- Add module shortcuts like `Create Campaign`, `Connect Channel`, `Upload Knowledge`, `Open Inbox`
- Add alerts panel for action items

## Project Dashboard Changes

Current project dashboard is mostly frontend flow analytics.

Add tabs or sections for:

- Funnel
- Sessions
- Conversions
- Traffic sources
- Devices
- API node performance
- Session replay
- Top drop-off points
- Campaign attribution

UI changes:

- Convert the page from a long vertical analytics page into tabbed analytics views
- Add export buttons
- Add compare-period support
- Add filters by channel, segment, and environment

## No-Code Frontend Builder Changes

Current strengths:

- Good node-based journey builder
- Widget test flow

Add:

- Template picker before blank canvas
- Channel-aware flows
- Preview device modes
- Environment selector
- Version history
- Node validation panel
- Conversation goal configuration
- Entry trigger configuration

UI changes:

- Add a startup modal: `Start from template` or `Blank flow`
- Add left-side template drawer
- Add top bar controls: `Draft`, `Publish`, `Versions`, `Validation`
- Add warnings for missing backend bot connection, missing API key, missing widget publish state

## No-Code Backend Builder Changes

Current strengths:

- Flow-based backend builder
- Tool-connected assistant model

Add:

- Model selection UI per agent
- Shared prompt/guardrail management
- Knowledge source binding
- Tool execution logs
- Test cases / evaluation runs
- Versioned backend deployments

UI changes:

- Add `Knowledge`, `Prompt`, `Logs`, `Evaluation` tabs
- Add agent configuration summary panel
- Add run history

## Tools Module Changes

Current strengths:

- Tool CRUD exists
- Tool code editing exists

Add:

- Tool categories
- Tool templates
- Secret management
- Per-tool logs
- Test runner UI
- Tool dependency visualization

UI changes:

- Split `Tools` into `Library`, `My Tools`, `Secrets`, `Logs`
- Add tool creation wizard
- Add test panel on tool detail page

## Team / Workspace Changes

Current strengths:

- Invite flow
- Role management

Add:

- Workspace settings page
- Module-level permissions
- Audit logs
- API key management
- Usage and billing screen

UI changes:

- Split current `Team` page into:
  - `Members`
  - `Invites`
  - `Roles`
  - `Audit Log`
  - `Billing`

## Widget Preview and Publish Changes

Current strengths:

- Preview exists
- Shareable link exists
- Static script publishing exists

Add:

- Publish environments
- Publish history
- Embed install instructions by framework
- Domain allowlist
- Widget theme presets
- Channel/web deployment status

UI changes:

- Rename page from `Widget Preview` to `Test and Publish`
- Add tabs:
  - `Preview`
  - `Embed`
  - `Publish`
  - `Versions`
  - `Install`
- Add `Draft vs Published` status badges

## New Pages to Add

These pages do not exist today but would move WinAssist much closer to a complete platform:

- `Campaigns List`
- `Campaign Builder`
- `Channels Setup`
- `Contacts / Audience`
- `Conversation Inbox`
- `Knowledge Base`
- `Template Library`
- `Publish Center`
- `Billing and Usage`
- `Audit Logs`
- `Session Replay`
- `Live Agent Console`

## Recommended Build Priority

## P0: Fix and complete what already exists

Build first:

- Finish publish flow
- Finish knowledge upload/RAG module
- Expose already-built analytics endpoints in UI
- Clean widget publishing UX
- Add validation and empty-state improvements to builders

Why:

- These create immediate product quality gains without changing the platform category too much.

## P1: Expand the product into a stronger no-code platform

Build next:

- Template library
- Publish center
- Knowledge base management
- Better tool testing and secrets management
- Deeper analytics UI
- Better onboarding and first-project wizard

Why:

- These improve adoption and reduce technical friction.

## P2: Expand into business operations modules

Build after that:

- Campaign manager
- Contacts/segments
- Omnichannel setup
- Inbox / agent assist
- Billing / audit / governance

Why:

- These are the big platform-expansion features that move WinAssist closer to a Gupshup-like product class.

## Suggested UI Implementation Order

1. Add `Templates`, `Knowledge Base`, and `Publish Center` to sidebar
2. Upgrade `Widget Preview` into `Test and Publish`
3. Expand `Project Dashboard` with more analytics tabs
4. Add builder validation and onboarding wizard
5. Build `Knowledge Base` page and connect uploads properly
6. Finish publish flow from project cards and builders
7. Add `Campaigns` and `Contacts` modules
8. Add `Inbox` and agent support operations UI
9. Add `Channels` and deployment setup screens
10. Add billing/governance/admin pages

## Suggested First Working Sprint

If the goal is to make the product stronger quickly, start with this sprint:

- Complete publish flow
- Create `Knowledge Base` page
- Add analytics tabs for:
  - device analytics
  - traffic source
  - returning vs new
  - API performance
- Add template chooser for frontend and backend project creation
- Add builder validation banner for broken or incomplete flows

This gives the fastest visible improvement while using a lot of what already exists in the codebase.

## Final Summary

WinAssist is already a solid **AI chatbot builder**, but it is still missing the modules that make a product feel like a full **enterprise low-code/no-code conversational platform**.

The biggest missing areas are:

- omnichannel support
- campaigns
- contacts and segmentation
- inbox/live support
- knowledge base management
- full publish/deployment workflow
- governance and billing
- broader analytics UI

The fastest path forward is:

- finish current partial features first
- improve builder UX and publishing
- expose existing backend analytics
- then expand into campaigns, channels, contacts, and inbox
