# WinAssist AI UI Enhancement Spec

## Purpose

This document defines how WinAssist should evolve from a working flow-based chatbot builder into a more advanced AI platform where non-technical users can configure, train, and improve bots directly from the UI.

The goal is to let a user do all of the following without editing code:

- create and manage AI bots
- define intents and utterances
- define entities and extraction rules
- upload and manage knowledge for RAG
- configure prompts, guardrails, tools, and memory
- test and evaluate bot quality
- review analytics and improve the bot over time
- publish and maintain different bot versions for different use cases

This spec is grounded in the current codebase state, especially:

- `frontend/src/shared/page/nocodebackend-list.jsx`
- `frontend/src/shared/page/nocodebackend-canvas.jsx`
- `frontend/src/components/shared/nodes/AssistantNodeConfig.jsx`
- `frontend/src/components/backend-node/config/config.jsx`
- `frontend/src/components/shared/chatpane.jsx`
- `frontend/src/shared/page/knowledge-base.jsx`
- `frontend/src/utils/codeGenerator.js`
- `frontend/src/utils/flowValidation.js`
- `backend/api/agentok_api/routers/chats.py`
- `backend/api/agentok_api/services/chats.py`
- `backend/api/agentok_api/routers/knowledge.py`
- `backend/api/agentok_api/utils/rag_tool.py`
- `backend/api/agentok_api/services/codegen.py`
- `backend/api/seed_tools.py`

## Current AI Capability Snapshot

WinAssist already has a strong base for an AI platform:

- a backend AI agent builder at `/aiagent`
- a frontend chat flow builder at `/chatflow`
- assistant nodes in the frontend flow that can call a backend bot
- chat execution with streaming responses over SSE
- trace logs for planner/runtime inspection
- a tool system that can be attached to agents
- a knowledge upload endpoint at `/knowledge/uploads`
- a seeded `rag_search` tool backed by `backend/api/agentok_api/utils/rag_tool.py`
- basic flow validation for missing bot API keys and unresolved references
- widget preview/publish flows and analytics-oriented dashboards

## What Is Missing Today

The current AI runtime is functional, but the training and management UX is incomplete.

Important gaps:

- no full intent management UI
- no entity management UI
- no training dataset UI for utterances, synonyms, and examples
- no RAG collections UI with chunking, indexing status, and retrieval tuning
- no prompt/version management for business users
- no evaluation UI for regression testing and score tracking
- no memory control UI for short-term, session, and long-term memory
- no guardrail/policy UI for unsafe topics, restricted actions, or escalation
- no feedback loop where users can improve the bot from failed conversations
- no clear lifecycle for draft, trained, tested, approved, and published bot versions

## Product Vision

WinAssist should become a UI-first AI operations platform with two connected layers:

1. `Conversation Experience Layer`

- built in the existing frontend flow builder
- handles entry flows, quick replies, forms, channel presentation, routing, and bot handoff

2. `AI Brain Layer`

- built in the existing backend AI agent builder
- handles reasoning, prompt policy, tools, memory, knowledge retrieval, intents, entities, and structured decisions

The platform should allow a user to connect these layers visually:

- frontend assistant node selects a backend bot
- backend bot selects its model, tools, knowledge collections, policies, and training assets
- the user can improve the bot from dedicated UI modules instead of touching code

## Recommended AI Modules

The current navigation already includes `Ai Agent`, `Chat Flow`, `Templates`, `Publish Center`, and placeholder platform modules. To make AI configuration complete, add or expand the following modules.

### 1. Bot Studio

This becomes the main control center for a single AI bot.

User can manage:

- bot name, description, and use case
- selected model provider and model name
- temperature, max tokens, latency/cost mode
- default system prompt
- greeting behavior
- response style and persona
- supported languages
- fallback strategy
- escalation strategy
- channel behavior overrides

Recommended tabs:

- `Overview`
- `Prompt`
- `Intents`
- `Entities`
- `Knowledge`
- `Tools`
- `Memory`
- `Guardrails`
- `Evaluation`
- `Versions`

How it fits the current app:

- extends the current backend builder instead of replacing it
- sits on top of the current `/aiagent/:id` project model
- persists configuration in project settings plus dedicated AI tables

### 2. Intent Studio

This is the training UI for user goals.

User can do:

- create intents such as `book_demo`, `refund_request`, `order_status`, `product_faq`
- add training utterances
- add alternate phrasing
- import utterances from CSV
- map intents to backend actions, flows, or assistant responses
- set confidence thresholds
- define fallback intent behavior
- review confused intents from real conversations

Required UI sections:

- intent list
- intent detail page
- utterance editor
- confusion matrix / overlap warnings
- test classifier panel
- suggested utterances mined from chat logs

Key fields:

- intent name
- display label
- description
- sample utterances
- negative examples
- routing target
- confidence threshold
- status: draft, trained, published

Expected behavior:

- when a user message arrives, the system can classify it into one or more candidate intents
- the selected intent can route the user into a frontend flow branch, backend tool, form, or assistant response strategy

### 3. Entity Studio

This is the UI for structured information extraction.

User can define entities like:

- name
- email
- phone
- city
- order_id
- booking_date
- product_name
- budget
- language

User can configure:

- entity type: regex, dictionary, ML/LLM-assisted, system entity
- synonyms and aliases
- extraction examples
- validation rules
- normalization rules
- required vs optional
- storage destination in context or CRM profile
- confirmation prompts when extraction confidence is low

Required UI sections:

- entity catalog
- entity detail editor
- regex builder
- synonym manager
- validation rule builder
- extraction preview panel

Key fields:

- entity key
- display label
- description
- examples
- synonyms
- validation pattern
- output format
- confidence threshold
- default prompt if missing

Expected behavior:

- extracted entities become usable in frontend and backend flows
- extracted entities are stored in bot context, session memory, and optionally customer/contact profiles
- entity extraction should work from both intent-driven turns and open-ended AI turns

### 4. Knowledge and RAG Studio

The current codebase already has upload support and a simple chunk-based retrieval utility, but it needs a full user-facing module.

User can do:

- upload files and URLs
- group files into collections
- assign collections to one or more bots
- set chunk size and overlap
- set retrieval mode and top-k
- preview extracted text and chunks
- reindex failed or stale documents
- remove documents
- run test retrieval queries
- see which chunks were returned for a user question

Recommended submodules:

- `Sources`
- `Collections`
- `Retrieval Settings`
- `Chunk Preview`
- `Search Test`
- `Bindings`
- `Indexing Logs`

Supported source types for target state:

- PDF
- DOCX
- XLSX
- PPTX
- TXT
- MD
- CSV
- HTML
- public URL
- FAQ pairs
- manual text notes
- database connectors
- API connectors

Recommended RAG settings exposed in UI:

- chunk size
- chunk overlap
- top-k
- retrieval strategy: keyword, vector, hybrid
- source priority
- metadata filters
- freshness boost
- citation mode
- answer-grounding strictness

Important current-state note:

- `backend/api/agentok_api/routers/knowledge.py` currently saves uploads
- `backend/api/agentok_api/utils/rag_tool.py` currently extracts text and performs simple chunk scoring
- the UI page `frontend/src/shared/page/knowledge-base.jsx` is still a placeholder page, not a full management experience

### 5. Prompt and Policy Studio

Users need a safe UI to change how the bot behaves without editing raw code.

User can do:

- edit system prompt
- configure assistant persona
- add business rules
- set tone and response style
- define forbidden topics
- define safe completion rules
- configure compliance disclaimers
- configure escalation triggers
- create reusable prompt blocks

Recommended sections:

- core system prompt
- response style
- safety instructions
- compliance text
- action restrictions
- reusable prompt snippets
- A/B prompt variants

Expected behavior:

- prompt changes create a new draft version
- users can compare prompt versions
- users can test prompt changes against saved test suites

### 6. Memory Studio

The current backend already builds lightweight memory from recent turns and simple fact extraction. That should become editable and inspectable from the UI.

User can manage:

- session memory window
- persistent user profile memory
- facts to save automatically
- facts that should never be stored
- memory expiration rules
- memory summarization strategy
- workspace-level vs bot-level memory

Recommended tabs:

- `Session Memory`
- `Long-Term Memory`
- `Fact Extraction`
- `Retention Rules`
- `Privacy Controls`

Expected behavior:

- users can choose what the bot remembers
- users can view and delete stored memory entries
- users can disable memory for privacy-sensitive use cases

### 7. Tools and Actions Studio

WinAssist already has tools, but bot users need a clearer UI for business actions.

User can do:

- attach tools to a bot
- map tools to intents
- define approval requirements for risky actions
- test tool inputs and outputs
- configure retries and timeouts
- define structured outputs

Examples:

- check order status
- create ticket
- schedule meeting
- search knowledge
- fetch CRM profile
- create lead
- send email

Recommended improvements:

- tool categories
- per-tool permissions
- structured input schema editor
- per-tool execution logs
- approval workflow for sensitive tools

### 8. Evaluation and Training Center

This is the most important module for turning a working bot into a trainable bot.

User can do:

- create test suites
- add benchmark prompts
- add expected intents/entities
- add expected answer quality criteria
- run evaluations after changes
- compare versions
- inspect failures
- promote a version only if it passes thresholds

Recommended evaluation types:

- intent accuracy
- entity extraction accuracy
- grounded answer quality
- hallucination risk
- tool-use correctness
- latency
- fallback rate
- containment rate
- escalation rate

Required UI sections:

- test dataset manager
- evaluation run history
- scorecards
- failed case explorer
- regression comparison
- approve/reject gate

### 9. Conversation Improvement Inbox

The current chat/traces functionality should evolve into an improvement workflow.

User can review:

- unresolved questions
- low-confidence intent matches
- missed entities
- fallback responses
- poor knowledge answers
- tool failures
- escalated conversations

User actions:

- convert a failed chat example into a training utterance
- create a new intent from repeated unknown questions
- add synonyms for a missed entity
- attach a missing document to knowledge base
- adjust prompt or guardrail from the conversation

This becomes the fastest human-in-the-loop training loop in the product.

## End-to-End UI User Journey

The target UI flow should be:

1. User creates a bot in `Ai Agent`
2. User opens `Bot Studio`
3. User sets model, tone, and safety rules
4. User defines intents and utterances
5. User defines entities and extraction rules
6. User uploads documents or links in `Knowledge`
7. User groups content into collections and binds them to the bot
8. User attaches tools and action permissions
9. User runs test conversations and evaluations
10. User reviews failures and improves utterances/entities/knowledge
11. User publishes the tested version
12. User monitors live analytics and training suggestions

## How The Current Architecture Should Evolve

### Existing Good Foundations

- `frontend/src/components/shared/nodes/AssistantNodeConfig.jsx` already lets a frontend assistant node connect to a backend bot and pass context keys
- `frontend/src/utils/codeGenerator.js` already generates code that calls backend bot chat APIs using bot API keys
- `backend/api/agentok_api/routers/chats.py` and `backend/api/agentok_api/services/chats.py` already provide a working runtime chat execution path
- `frontend/src/components/shared/chatpane.jsx` already supports uploads and trace viewing
- `backend/api/agentok_api/routers/knowledge.py` already handles document upload storage
- `backend/api/seed_tools.py` already seeds a `rag_search` tool

### Main Architectural Improvements Needed

1. Separate bot runtime config from raw flow JSON

The current flow JSON is good for canvas editing, but advanced AI training needs structured records for:

- intents
- utterances
- entities
- synonyms
- knowledge collections
- retrieval settings
- prompt versions
- evaluations
- memory rules

2. Add explicit bot capability bindings

A bot should have first-class relationships to:

- tools
- intents
- entity schemas
- knowledge collections
- prompt templates
- memory policies
- guardrails

3. Add versioning for every trainable asset

Need versions for:

- bot config
- intent sets
- entity sets
- knowledge bindings
- prompts
- evaluation datasets

4. Upgrade retrieval from utility to platform service

The current `rag_tool.py` is a useful start, but the platform should add:

- document extraction jobs
- chunk records
- embeddings or hybrid search support
- source metadata filters
- retrieval logs
- citation tracing

## Proposed Data Model Additions

Add dedicated entities such as:

- `bots`
- `bot_versions`
- `bot_prompts`
- `intent_sets`
- `intents`
- `intent_utterances`
- `entity_sets`
- `entities`
- `entity_synonyms`
- `knowledge_collections`
- `knowledge_documents`
- `knowledge_chunks`
- `knowledge_bindings`
- `retrieval_configs`
- `memory_policies`
- `guardrail_policies`
- `evaluation_suites`
- `evaluation_cases`
- `evaluation_runs`
- `conversation_feedback`
- `training_suggestions`

## Proposed API Additions

Add UI-facing APIs for:

- `GET/POST /bots/:id/intents`
- `GET/POST /bots/:id/entities`
- `GET/POST /bots/:id/knowledge-collections`
- `POST /bots/:id/knowledge-collections/:id/reindex`
- `POST /bots/:id/retrieval/test`
- `POST /bots/:id/intents/test`
- `POST /bots/:id/entities/test`
- `GET/POST /bots/:id/prompts`
- `GET/POST /bots/:id/memory-policies`
- `GET/POST /bots/:id/guardrails`
- `GET/POST /bots/:id/evaluations`
- `POST /bots/:id/publish`
- `GET /bots/:id/improvement-suggestions`

These APIs should not replace the current chat and project APIs. They should complement them.

## Detailed Feature Requirements

### Intent Recognition

The platform should support:

- single intent classification
- multi-intent suggestion
- fallback intent
- context-aware intent ranking
- per-intent confidence thresholds
- route-to-flow and route-to-tool actions
- approval-based routing for sensitive intents

### Entity Recognition

The platform should support:

- regex entities
- dictionary entities
- alias/synonym entities
- date/time/number system entities
- LLM-assisted extraction for complex fields
- normalized outputs
- confidence-aware confirmations

### RAG Training and Retrieval

The platform should support:

- source ingestion
- extraction and chunk preview
- vector or hybrid retrieval
- top-k testing
- per-collection retrieval tuning
- document status tracking
- citation-ready answers
- source freshness controls
- collection binding to selected bots

### Memory and Personalization

The platform should support:

- recent conversation memory
- durable customer facts
- preferences
- profile-linked memory
- privacy-sensitive memory exclusions
- explicit memory deletion controls

### Guardrails and Safety

The platform should support:

- prohibited topics
- action restriction policies
- sensitive data masking
- escalation to human flow
- policy-triggered fallback responses
- audit logs for policy violations

### Continuous Improvement

The platform should support:

- thumbs up/down feedback
- conversation issue tagging
- auto-suggest new intents from unmatched queries
- auto-suggest entity synonyms from failed extractions
- auto-suggest missing documents for RAG gaps
- quality dashboards for improvement trends

## UI Changes By Existing Area

### `Ai Agent`

Expand from a project list plus canvas into a full bot operating console.

Add:

- bot overview header
- trainable asset tabs
- evaluation history
- publish/version controls
- model and policy summary cards

### `Chat Flow`

Keep the current visual flow builder, but improve its ability to consume AI outputs.

Add:

- intent-router node
- entity-check node
- knowledge-answer node
- human-handoff node
- confidence-branch node
- fallback node

Assistant node improvements:

- pick backend bot
- pick intent mode: freeform, intent-first, RAG-first, hybrid
- map entity outputs into flow variables
- choose knowledge collection scope
- choose memory mode

### `Knowledge Base`

Replace the current placeholder page with a real workspace module.

Add:

- source upload and URL ingest
- collection management
- document status pills
- chunk preview
- search testing
- reindex/delete actions
- bot binding management

### `Project Dashboard`

Add AI quality analytics, not only session analytics.

Add widgets for:

- intent hit rate
- fallback rate
- entity extraction success
- knowledge hit rate
- grounded answer rate
- tool execution success
- escalation rate
- evaluation pass/fail trend

### `Publish Center`

Add AI release governance.

Include:

- draft vs published model/prompt/intent/entity versions
- required evaluation checks before publish
- release notes for prompt/training changes
- rollback to prior bot version

## Phased Delivery Plan

### P0: Complete current AI gaps

Build first:

- full `Knowledge Base` UI
- bot-to-knowledge binding
- retrieval testing panel
- prompt editing UI
- model settings UI
- trace improvements in chat panel

Why:

- these are the closest to what already exists in the codebase

### P1: Add trainable NLU features

Build next:

- Intent Studio
- Entity Studio
- training utterance management
- entity extraction testing
- confidence-based routing

Why:

- this makes the bot configurable for business use cases beyond freeform chat

### P2: Add quality and governance

Build after that:

- Evaluation Center
- publish gates
- version comparison
- improvement inbox
- safety/guardrail editor

Why:

- this turns experimentation into repeatable product operations

### P3: Add advanced AI operations

Build later:

- hybrid retrieval
- connector-based knowledge sync
- automated training suggestions
- multilingual intent/entity sets
- role-based approval for risky changes

## Suggested First Implementation Sprint

If the immediate goal is to make WinAssist feel much more advanced without rebuilding everything, start with this sprint:

1. replace `frontend/src/shared/page/knowledge-base.jsx` with a real document and collection manager
2. add bot-level `Prompt`, `Knowledge`, and `Evaluation` tabs to the AI Agent experience
3. add retrieval test UI backed by the existing RAG utility
4. add draft intent/entity data models and CRUD APIs
5. add an `Intent Router` node and `Entity Check` node to the frontend builder
6. add conversation feedback actions in the chat trace panel

This gives the fastest visible jump toward a trainable AI platform.

## Acceptance Criteria

The enhancement is successful when a normal product user can:

- create a bot from the UI
- choose a model and prompt from the UI
- create at least 10 intents and test them
- define at least 10 entities and validate extraction
- upload documents and bind them to the bot
- test retrieval quality from the UI
- map extracted intent/entity values into flow behavior
- run evaluation suites before publishing
- review failed conversations and turn them into training improvements
- publish a new bot version without editing code

## Final Recommendation

WinAssist should not treat AI as only a chat runtime. It should treat AI as a managed product surface with training, evaluation, governance, and continuous improvement.

The current codebase already has the most important foundation pieces:

- bot runtime
- frontend/backend builder split
- assistant-to-backend-bot connection
- knowledge upload endpoint
- trace logging
- tool architecture

The next step is to convert those foundations into a complete UI-driven AI platform where users can train intents, define entities, manage RAG, improve memory, test quality, and publish better bots over time.
