FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN apt-get update && apt-get install -y --no-install-recommends build-essential libpq-dev curl libmagic1 && rm -rf /var/lib/apt/lists/*
RUN pip install --no-cache-dir --upgrade pip
RUN pip install --no-cache-dir -r requirements.txt

# Copy backend code
COPY . .

# Run migrations before starting the API so older databases stay compatible.
CMD ["sh", "-c", "python run.py && uvicorn agentok_api.main:app --host 0.0.0.0 --port 9000"]
