-- Database Setup Script for WinAssist
-- Run this script in PostgreSQL to create all required tables
-- Usage: psql -U your_user -d your_database -f setup_database.sql

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- PERSONS TABLE (Users)
-- ============================================
CREATE TABLE IF NOT EXISTS persons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    user_metadata JSONB DEFAULT '{}',
    app_metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_persons_email ON persons(email);

-- ============================================
-- WORKSPACES / TENANTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_workspaces_slug ON workspaces(slug);
CREATE INDEX IF NOT EXISTS idx_workspaces_owner_id ON workspaces(owner_id);

-- ============================================
-- WORKSPACE MEMBERS (user ↔ workspace with role)
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL, -- e.g. owner, admin, member, viewer
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (workspace_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_workspace_members_workspace_id ON workspace_members(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_user_id ON workspace_members(user_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_role ON workspace_members(role);

-- ============================================
-- WORKSPACE INVITES
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_invites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, 
    token UUID NOT NULL DEFAULT uuid_generate_v4(),
    expires_at TIMESTAMP,
    accepted_at TIMESTAMP,
    created_by UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (workspace_id, email, token)
);

CREATE INDEX IF NOT EXISTS idx_workspace_invites_workspace_id ON workspace_invites(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_invites_email ON workspace_invites(email);
CREATE INDEX IF NOT EXISTS idx_workspace_invites_token ON workspace_invites(token);

-- ============================================
-- PROJECTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    
    workspace_id UUID REFERENCES workspaces(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    flow JSONB DEFAULT '{}',
    project_type VARCHAR(50),
    api_key VARCHAR(255) UNIQUE,
    api_key_last_used_at TIMESTAMP,
    api_key_usage_count INTEGER DEFAULT 0,
    widget_script_url TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_api_key ON projects(api_key);
CREATE INDEX IF NOT EXISTS idx_projects_project_type ON projects(project_type);

-- ============================================
-- PROJECT GOVERNANCE TABLES
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_governance_policies (
    workspace_id UUID PRIMARY KEY REFERENCES workspaces(id) ON DELETE CASCADE,
    policy JSONB DEFAULT '{}',
    updated_by UUID REFERENCES persons(id) ON DELETE SET NULL,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS project_releases (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    environment VARCHAR(32) NOT NULL CHECK (environment IN ('draft', 'staging', 'production')),
    version_no INTEGER NOT NULL,
    flow_snapshot JSONB DEFAULT '{}',
    flow_fingerprint VARCHAR(64) NOT NULL,
    notes TEXT,
    change_summary TEXT,
    approval_metadata JSONB DEFAULT '{}',
    created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (project_id, environment, version_no)
);

CREATE TABLE IF NOT EXISTS project_audit_logs (
    id SERIAL PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
    project_name VARCHAR(255),
    actor_user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    action VARCHAR(128) NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_project_releases_project_id ON project_releases(project_id);
CREATE INDEX IF NOT EXISTS idx_project_releases_environment ON project_releases(environment);
CREATE INDEX IF NOT EXISTS idx_project_releases_project_environment ON project_releases(project_id, environment, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_project_id ON project_audit_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_workspace_id ON project_audit_logs(workspace_id);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_created_at ON project_audit_logs(created_at DESC);

-- ============================================
-- CHATS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chats (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    from_project UUID REFERENCES projects(id) ON DELETE SET NULL,
    from_template INTEGER,
    from_type VARCHAR(50) NOT NULL,
    config JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'ready',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chats_user_id ON chats(user_id);
CREATE INDEX IF NOT EXISTS idx_chats_from_project ON chats(from_project);
CREATE INDEX IF NOT EXISTS idx_chats_status ON chats(status);

-- ============================================
-- CHAT_MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    sender VARCHAR(255),
    receiver VARCHAR(255),
    content TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    meta JSONB DEFAULT '{}',
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_chat_id ON chat_messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_project_id ON chat_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_type ON chat_messages(type);

-- ============================================
-- CHAT_LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chat_logs (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    level VARCHAR(50),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_logs_chat_id ON chat_logs(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_logs_level ON chat_logs(level);

-- ============================================
-- TOOLS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS tools (
    id SERIAL PRIMARY KEY,
    uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    logo_url TEXT,
    code TEXT,
    variables JSONB DEFAULT '[]',
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tools_user_id ON tools(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tools_uuid ON tools(uuid);
CREATE INDEX IF NOT EXISTS idx_tools_is_public ON tools(is_public);
CREATE INDEX IF NOT EXISTS idx_tools_name ON tools(name);

-- ============================================
-- API_KEYS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS api_keys (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255),
    key VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_keys_user_id ON api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key);

-- ============================================
-- USER_SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_settings (
    user_id UUID PRIMARY KEY REFERENCES persons(id) ON DELETE CASCADE,
    general JSONB DEFAULT '{}',
    tools JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- TEMPLATES TABLE (if needed)
-- ============================================
CREATE TABLE IF NOT EXISTS templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    project JSONB DEFAULT '{}',
    -- Link back to the original project and workspace
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    project_type VARCHAR(50),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
    -- Ownership / visibility
    user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    is_published BOOLEAN DEFAULT FALSE,
    -- Simple rating aggregate (for top-5 queries)
    rating_sum INTEGER DEFAULT 0,
    rating_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_templates_name ON templates(name);
CREATE INDEX IF NOT EXISTS idx_templates_project_type ON templates(project_type);
CREATE INDEX IF NOT EXISTS idx_templates_is_published ON templates(is_published);

-- One rating per user per template (user can update their rating)
CREATE TABLE IF NOT EXISTS template_ratings (
    template_id INTEGER NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (template_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_template_ratings_template_id ON template_ratings(template_id);
CREATE INDEX IF NOT EXISTS idx_template_ratings_user_id ON template_ratings(user_id);

-- ============================================
-- MERGED MIGRATIONS (formerly individual files)
-- ============================================

-- 001_add_bot_api_keys.sql
-- Migration: Add bot API keys to projects table
-- Date: 2026-01-24
-- Purpose: Enable bot-specific API key authentication

-- Add api_key column to projects table
ALTER TABLE projects 
ADD COLUMN IF NOT EXISTS api_key VARCHAR(255) UNIQUE;

-- Create index for faster API key lookups
CREATE INDEX IF NOT EXISTS idx_projects_api_key ON projects(api_key);

-- Add usage tracking columns (optional, for future analytics)
ALTER TABLE projects 
ADD COLUMN IF NOT EXISTS api_key_last_used_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS api_key_usage_count INTEGER DEFAULT 0;

-- Comment the new columns
COMMENT ON COLUMN projects.api_key IS 'Bot-specific API key for public widget access';
COMMENT ON COLUMN projects.api_key_last_used_at IS 'Last time the bot API key was used';
COMMENT ON COLUMN projects.api_key_usage_count IS 'Number of times the bot API key was used';

-- 002_add_project_id_to_messages.sql
-- Migration: Add project_id column to chat_messages table
-- This allows direct counting of messages per project without joining through chats

-- Add project_id column (nullable initially for existing data)
ALTER TABLE chat_messages 
ADD COLUMN IF NOT EXISTS project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL;

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_chat_messages_project_id ON chat_messages(project_id);

-- Update existing messages to have project_id from their chat's project
UPDATE chat_messages m
SET project_id = c.from_project
FROM chats c
WHERE m.chat_id = c.id AND m.project_id IS NULL;

-- 003_flow_step_analytics.sql
-- Flow step analytics: track which step each session reached (for funnel)

ALTER TABLE chats ADD COLUMN IF NOT EXISTS session_id TEXT;
CREATE INDEX IF NOT EXISTS idx_chats_session_id ON chats(session_id);

CREATE TABLE IF NOT EXISTS flow_step_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_id ON flow_step_events(project_id);
CREATE INDEX IF NOT EXISTS idx_flow_step_events_session_id ON flow_step_events(session_id);
CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_created ON flow_step_events(project_id, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_flow_step_events_project_session_node
    ON flow_step_events(project_id, session_id, node_id);

-- 004_flow_messages.sql
-- Flow messages: store user and assistant messages from frontend (widget) flows for analytics.

CREATE TABLE IF NOT EXISTS flow_messages (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL DEFAULT '',
    node_id TEXT,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_id ON flow_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_flow_messages_session_id ON flow_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_flow_messages_project_created ON flow_messages(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_flow_messages_project_role ON flow_messages(project_id, role);

-- 005_flow_step_events_allow_multiple.sql
-- Allow multiple step events per (session, node) so "reached_count" = total times node was used (e.g. in loops).

DROP INDEX IF EXISTS idx_flow_step_events_project_session_node;

-- 006_quick_reply_choices.sql
-- Quick reply choice analytics: which option users picked per quick reply node.

CREATE TABLE IF NOT EXISTS quick_reply_choices (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    option_index INT NOT NULL,
    option_text TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_id ON quick_reply_choices(project_id);
CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_node ON quick_reply_choices(project_id, node_id);

-- 007_advanced_analytics.sql
-- Advanced analytics: session metadata (device, traffic) and API performance.

-- Session metadata: device, browser, OS, page_url, referrer (reported by widget when available)
CREATE TABLE IF NOT EXISTS session_metadata (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    device_type TEXT,
    browser TEXT,
    os TEXT,
    page_url TEXT,
    referrer TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_session_metadata_project_id ON session_metadata(project_id);
CREATE INDEX IF NOT EXISTS idx_session_metadata_session_id ON session_metadata(session_id);
CREATE INDEX IF NOT EXISTS idx_session_metadata_project_created ON session_metadata(project_id, created_at);

-- API performance: each API node call reported by widget
CREATE TABLE IF NOT EXISTS api_performance_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT,
    api_name TEXT NOT NULL,
    response_status INT,
    response_time_ms INT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_performance_project_id ON api_performance_events(project_id);
CREATE INDEX IF NOT EXISTS idx_api_performance_project_created ON api_performance_events(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_api_performance_api_name ON api_performance_events(project_id, api_name);

-- add_tools_uuid.sql
-- Add UUID column to tools for unique external identifiers.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

ALTER TABLE tools
ADD COLUMN IF NOT EXISTS uuid UUID UNIQUE DEFAULT uuid_generate_v4();

-- Backfill existing rows that might have NULL uuid (if column was added without DEFAULT)
UPDATE tools SET uuid = uuid_generate_v4() WHERE uuid IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_tools_uuid ON tools(uuid);

-- 008_add_widget_script_url.sql
-- Migration: Add widget_script_url to projects table
-- Date: 2026-03-12
-- Purpose: Store published widget script URL for shareable widget page and public script loading

ALTER TABLE projects
ADD COLUMN IF NOT EXISTS widget_script_url TEXT;

COMMENT ON COLUMN projects.widget_script_url IS 'URL of the published widget script for public/embed use';

-- 009_session_variables.sql
-- Store quick reply and other session variables for use in API body (e.g. {{context.plan_type}}).

CREATE TABLE IF NOT EXISTS session_variables (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    var_key TEXT NOT NULL,
    var_value TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(project_id, session_id, var_key)
);

CREATE INDEX IF NOT EXISTS idx_session_variables_project_session ON session_variables(project_id, session_id);

-- Success message
SELECT 'Database setup completed successfully!' AS result;

