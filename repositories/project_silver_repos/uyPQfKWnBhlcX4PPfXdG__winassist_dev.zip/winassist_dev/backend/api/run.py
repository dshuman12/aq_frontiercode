#!/usr/bin/env python3
"""
Run all database migrations (single entry point).

Includes:
  003 - Flow step analytics: chats.session_id, flow_step_events table + indexes
  004 - flow_messages table + indexes
  005 - Drop unique index on flow_step_events (allow multiple steps per session/node for loops)
  006 - quick_reply_choices table + indexes
  007 - session_metadata and api_performance_events tables + indexes
  008 - template_ratings table (one rating per user per template)
  009 - session_variables table (store quick reply and other vars for use in API body)
  010 - persons table: reset_token, reset_token_expires_at (for forgot-password flow)
  TEMPLATES - templates table: project_id, project_type, workspace_id, user_id, is_published, rating_sum, rating_count + indexes

Uses DATABASE_URL from .env in the same directory.
Safe to run multiple times.
"""

import asyncio
import os
import re
from pathlib import Path
from dotenv import load_dotenv

# Load .env
_api_dir = Path(__file__).resolve().parent
load_dotenv(_api_dir / ".env")

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("ERROR: DATABASE_URL not found in .env")
    print("Example: DATABASE_URL=postgresql://user:pass@host:5432/dbname")
    exit(1)


MIGRATION_SQL = """
-----------------------------
-- MIGRATION 003: Flow step analytics
-----------------------------
ALTER TABLE chats ADD COLUMN IF NOT EXISTS session_id TEXT;

CREATE INDEX IF NOT EXISTS idx_chats_session_id 
ON chats(session_id);

CREATE TABLE IF NOT EXISTS flow_step_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_id 
ON flow_step_events(project_id);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_session_id 
ON flow_step_events(session_id);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_created 
ON flow_step_events(project_id, created_at);



-----------------------------
-- MIGRATION 004: flow_messages
-----------------------------
CREATE TABLE IF NOT EXISTS flow_messages (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL DEFAULT '',
    node_id TEXT,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_id 
ON flow_messages(project_id);

CREATE INDEX IF NOT EXISTS idx_flow_messages_session_id 
ON flow_messages(session_id);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_created 
ON flow_messages(project_id, created_at);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_role 
ON flow_messages(project_id, role);


-----------------------------
-- MIGRATION 005: Allow multiple step events per (session, node)
-----------------------------
DROP INDEX IF EXISTS idx_flow_step_events_project_session_node;


-----------------------------
-- MIGRATION 006: quick_reply_choices
-----------------------------
CREATE TABLE IF NOT EXISTS quick_reply_choices (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    option_index INT NOT NULL,
    option_text TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_id 
ON quick_reply_choices(project_id);

CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_node 
ON quick_reply_choices(project_id, node_id);


-----------------------------
-- MIGRATION 007: session_metadata and api_performance_events
-----------------------------
CREATE TABLE IF NOT EXISTS session_metadata (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    device_type TEXT,
    browser TEXT,
    os TEXT,
    page_url TEXT,
    referrer TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_session_metadata_project_id 
ON session_metadata(project_id);

CREATE INDEX IF NOT EXISTS idx_session_metadata_session_id 
ON session_metadata(session_id);

CREATE INDEX IF NOT EXISTS idx_session_metadata_project_created 
ON session_metadata(project_id, created_at);


CREATE TABLE IF NOT EXISTS api_performance_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT,
    api_name TEXT NOT NULL,
    response_status INT,
    response_time_ms INT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_performance_project_id 
ON api_performance_events(project_id);

CREATE INDEX IF NOT EXISTS idx_api_performance_project_created 
ON api_performance_events(project_id, created_at);

CREATE INDEX IF NOT EXISTS idx_api_performance_api_name 
ON api_performance_events(project_id, api_name);


-----------------------------
-- MIGRATION 008: template_ratings
-----------------------------
CREATE TABLE IF NOT EXISTS template_ratings (
    template_id INTEGER NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (template_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_template_ratings_template_id ON template_ratings(template_id);
CREATE INDEX IF NOT EXISTS idx_template_ratings_user_id ON template_ratings(user_id);


-----------------------------
-- MIGRATION 009: session_variables
-----------------------------
CREATE TABLE IF NOT EXISTS session_variables (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    var_key TEXT NOT NULL,
    var_value TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(project_id, session_id, var_key)
);
CREATE INDEX IF NOT EXISTS idx_session_variables_project_session ON session_variables(project_id, session_id);


-----------------------------
-- TEMPLATES: publish & rating support
-----------------------------
ALTER TABLE templates
    ADD COLUMN IF NOT EXISTS project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS project_type VARCHAR(50),
    ADD COLUMN IF NOT EXISTS category VARCHAR(100),
    ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS is_published BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS rating_sum INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_templates_project_type 
ON templates(project_type);

CREATE INDEX IF NOT EXISTS idx_templates_is_published 
ON templates(is_published);

-----------------------------
-- MIGRATION 010: Password reset (persons)
-----------------------------
ALTER TABLE persons ADD COLUMN IF NOT EXISTS reset_token TEXT;
ALTER TABLE persons ADD COLUMN IF NOT EXISTS reset_token_expires_at TIMESTAMP;
"""


def split_sql(sql: str):
    """Split SQL into individual statements."""
    sql = re.sub(r"--[^\n]*", "", sql)
    parts = [p.strip() for p in sql.split(";") if p.strip()]
    return parts


async def run():
    try:
        import asyncpg
    except ImportError:
        print("Install asyncpg: pip install asyncpg")
        exit(1)

    print("Connecting to database...")
    conn = await asyncpg.connect(DATABASE_URL)

    try:
        for stmt in split_sql(MIGRATION_SQL):
            preview = stmt.replace("\n", " ")[:80]
            print(f"Running: {preview}...")
            await conn.execute(stmt)

        print("\nAll migrations (003–010, templates) completed successfully.")

    except Exception as e:
        print(f"Migration failed: {e}")
        raise

    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(run())
