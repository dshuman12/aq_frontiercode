#!/usr/bin/env python3
"""
Database Setup Script for WinAssist
Creates all required database tables if they don't exist.
"""

import asyncio
import asyncpg
import os
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("ERROR: DATABASE_URL not found in environment variables!")
    print("Please create a .env file with DATABASE_URL=postgresql://postgres:123456@127.0.0.1:5432/WinAssist")
    exit(1)

# SQL to create all tables
CREATE_TABLES_SQL = """
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- PERSONS TABLE (Users)
-- ============================================
CREATE TABLE IF NOT EXISTS persons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    user_metadata JSONB DEFAULT '{}',
    app_metadata JSONB DEFAULT '{}',
    reset_token TEXT,
    reset_token_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_persons_email ON persons(email);

-- ============================================
-- WORKSPACES / TENANTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_workspaces_slug ON workspaces(slug);
CREATE INDEX IF NOT EXISTS idx_workspaces_owner_id ON workspaces(owner_id);

-- ============================================
-- WORKSPACE MEMBERS (user ↔ workspace with role)
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (workspace_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_workspace_members_workspace_id ON workspace_members(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_user_id ON workspace_members(user_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_role ON workspace_members(role);

-- ============================================
-- WORKSPACE INVITES
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_invites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    token UUID NOT NULL DEFAULT uuid_generate_v4(),
    expires_at TIMESTAMP,
    accepted_at TIMESTAMP,
    created_by UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_workspace_invites_workspace_id ON workspace_invites(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_invites_email ON workspace_invites(email);
CREATE INDEX IF NOT EXISTS idx_workspace_invites_token ON workspace_invites(token);

-- ============================================
-- PROJECTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    workspace_id UUID REFERENCES workspaces(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    flow JSONB DEFAULT '{}',
    project_type VARCHAR(50),
    api_key VARCHAR(255) UNIQUE,
    api_key_last_used_at TIMESTAMP,
    api_key_usage_count INTEGER DEFAULT 0,
    widget_script_url TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_api_key ON projects(api_key);
CREATE INDEX IF NOT EXISTS idx_projects_project_type ON projects(project_type);

-- ============================================
-- PROJECT GOVERNANCE TABLES
-- ============================================
CREATE TABLE IF NOT EXISTS workspace_governance_policies (
    workspace_id UUID PRIMARY KEY REFERENCES workspaces(id) ON DELETE CASCADE,
    policy JSONB DEFAULT '{}',
    updated_by UUID REFERENCES persons(id) ON DELETE SET NULL,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS project_releases (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    environment VARCHAR(32) NOT NULL CHECK (environment IN ('draft', 'staging', 'production')),
    version_no INTEGER NOT NULL,
    flow_snapshot JSONB DEFAULT '{}',
    flow_fingerprint VARCHAR(64) NOT NULL,
    notes TEXT,
    change_summary TEXT,
    approval_metadata JSONB DEFAULT '{}',
    created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (project_id, environment, version_no)
);

CREATE TABLE IF NOT EXISTS project_audit_logs (
    id SERIAL PRIMARY KEY,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
    project_name VARCHAR(255),
    actor_user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    action VARCHAR(128) NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_project_releases_project_id ON project_releases(project_id);
CREATE INDEX IF NOT EXISTS idx_project_releases_environment ON project_releases(environment);
CREATE INDEX IF NOT EXISTS idx_project_releases_project_environment ON project_releases(project_id, environment, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_project_id ON project_audit_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_workspace_id ON project_audit_logs(workspace_id);
CREATE INDEX IF NOT EXISTS idx_project_audit_logs_created_at ON project_audit_logs(created_at DESC);

-- ============================================
-- CHATS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chats (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    from_project UUID REFERENCES projects(id) ON DELETE SET NULL,
    from_template INTEGER,
    from_type VARCHAR(50) NOT NULL,
    config JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'ready',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chats_user_id ON chats(user_id);
CREATE INDEX IF NOT EXISTS idx_chats_from_project ON chats(from_project);
CREATE INDEX IF NOT EXISTS idx_chats_status ON chats(status);

-- ============================================
-- CHAT_MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    sender VARCHAR(255),
    receiver VARCHAR(255),
    content TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    meta JSONB DEFAULT '{}',
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_chat_id ON chat_messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_project_id ON chat_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_type ON chat_messages(type);

-- ============================================
-- CHAT_LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chat_logs (
    id SERIAL PRIMARY KEY,
    chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    level VARCHAR(50),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_logs_chat_id ON chat_logs(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_logs_level ON chat_logs(level);

-- ============================================
-- TOOLS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS tools (
    id SERIAL PRIMARY KEY,
    uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    logo_url TEXT,
    code TEXT,
    variables JSONB DEFAULT '[]',
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tools_user_id ON tools(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tools_uuid ON tools(uuid);
CREATE INDEX IF NOT EXISTS idx_tools_is_public ON tools(is_public);
CREATE INDEX IF NOT EXISTS idx_tools_name ON tools(name);

-- ============================================
-- API_KEYS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS api_keys (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    name VARCHAR(255),
    key VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_keys_user_id ON api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key);

-- ============================================
-- USER_SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_settings (
    user_id UUID PRIMARY KEY REFERENCES persons(id) ON DELETE CASCADE,
    general JSONB DEFAULT '{}',
    tools JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- TEMPLATES TABLE (if needed)
-- ============================================
CREATE TABLE IF NOT EXISTS templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    project JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_templates_name ON templates(name);

-- ============================================
-- WHATSAPP CONNECTIONS
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_connections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    bot_project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
    created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
    name VARCHAR(255),
    provider VARCHAR(32) NOT NULL DEFAULT 'meta_cloud',
    graph_version VARCHAR(32) NOT NULL DEFAULT 'v23.0',
    meta_business_account_id VARCHAR(255),
    waba_id VARCHAR(255) NOT NULL,
    phone_number_id VARCHAR(255) NOT NULL UNIQUE,
    business_phone_number VARCHAR(64),
    display_phone_number VARCHAR(64),
    access_token_encrypted BYTEA NOT NULL,
    access_token_hint VARCHAR(8),
    flow_private_key_encrypted BYTEA,
    flow_public_key_pem TEXT,
    flow_key_fingerprint VARCHAR(128),
    flow_key_generated_at TIMESTAMP,
    connection_status VARCHAR(32) NOT NULL DEFAULT 'draft',
    webhook_status VARCHAR(32) NOT NULL DEFAULT 'pending',
    health_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
    last_sync_status VARCHAR(32) NOT NULL DEFAULT 'never',
    subscribed_app_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
    last_validation_error TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',
    last_validated_at TIMESTAMP,
    last_synced_at TIMESTAMP,
    last_webhook_event_at TIMESTAMP,
    last_tested_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_workspace_id ON whatsapp_connections(workspace_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_project_id ON whatsapp_connections(project_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_bot_project_id ON whatsapp_connections(bot_project_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_user_id ON whatsapp_connections(user_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_status ON whatsapp_connections(connection_status);

-- ============================================
-- WHATSAPP PHONE NUMBERS
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_phone_numbers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
    phone_number_id VARCHAR(255) NOT NULL UNIQUE,
    display_phone_number VARCHAR(64),
    verified_name VARCHAR(255),
    quality_rating VARCHAR(64),
    code_verification_status VARCHAR(64),
    status VARCHAR(64) DEFAULT 'active',
    raw_data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_phone_numbers_connection_id ON whatsapp_phone_numbers(connection_id);

-- ============================================
-- WHATSAPP TEMPLATES
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
    meta_template_id VARCHAR(255) UNIQUE,
    name VARCHAR(255) NOT NULL,
    language VARCHAR(64),
    category VARCHAR(64),
    status VARCHAR(64),
    components JSONB NOT NULL DEFAULT '{}',
    raw_data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_templates_connection_id ON whatsapp_templates(connection_id);

-- ============================================
-- WHATSAPP FLOWS
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_flows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
    meta_flow_id VARCHAR(255) UNIQUE,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(64),
    categories JSONB NOT NULL DEFAULT '{}',
    raw_data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_flows_connection_id ON whatsapp_flows(connection_id);

-- ============================================
-- WHATSAPP WEBHOOK EVENT LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_webhook_events (
    id BIGSERIAL PRIMARY KEY,
    connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
    event_type VARCHAR(64),
    payload JSONB NOT NULL DEFAULT '{}',
    headers JSONB NOT NULL DEFAULT '{}',
    processed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_connection_id ON whatsapp_webhook_events(connection_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_created_at ON whatsapp_webhook_events(created_at DESC);

-- ============================================
-- WHATSAPP MESSAGES
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
    direction VARCHAR(16) NOT NULL,
    wa_message_id VARCHAR(255) UNIQUE,
    chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    from_number VARCHAR(64),
    to_number VARCHAR(64),
    message_type VARCHAR(64),
    status VARCHAR(64),
    payload JSONB NOT NULL DEFAULT '{}',
    response JSONB NOT NULL DEFAULT '{}',
    error TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_connection_id ON whatsapp_messages(connection_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_created_at ON whatsapp_messages(created_at DESC);

-- ============================================
-- WHATSAPP CONVERSATION LINKS
-- ============================================
CREATE TABLE IF NOT EXISTS whatsapp_conversation_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
    wa_user_phone_number VARCHAR(64) NOT NULL,
    chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    last_message_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (connection_id, wa_user_phone_number)
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_conversation_links_connection_id ON whatsapp_conversation_links(connection_id);
"""


def _normalize_db_url(url: str) -> str:
    """Use postgres:// for asyncpg if URL uses postgresql://."""
    if url and url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgres://", 1)
    return url or ""


async def _run_sql_migrations(conn: asyncpg.Connection) -> None:
    """
    Run all .sql migration files in the migrations directory, in name order.
    Each file is written to be idempotent (IF NOT EXISTS / safe operations),
    so it's safe to run this multiple times.
    """
    migrations_dir = Path(__file__).parent / "migrations"
    if not migrations_dir.exists():
        return

    migration_files = sorted(migrations_dir.glob("*.sql"))

    for path in migration_files:
        try:
            sql = path.read_text(encoding="utf-8")
            if not sql.strip():
                continue
            print(f"Running migration: {path.name}")
            await conn.execute(sql)
        except Exception as e:
            print(f"WARNING: Failed to run migration {path.name}: {e}")


async def setup_database():
    """Create all database tables (idempotent)."""
    if not DATABASE_URL:
        return False
    try:
        db_url = _normalize_db_url(DATABASE_URL)
        conn = await asyncpg.connect(db_url)
        
        await conn.execute(CREATE_TABLES_SQL)

        # Minimal built‑in migrations for existing databases (idempotent)
        try:
            await conn.execute(
                """
                ALTER TABLE projects
                ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id);
                """
            )
        except Exception:
            pass

        try:
            await conn.execute(
                """
                ALTER TABLE projects
                ADD COLUMN IF NOT EXISTS widget_script_url TEXT;
                """
            )
        except Exception:
            pass

        try:
            await conn.execute(
                """
                ALTER TABLE tools
                ADD COLUMN IF NOT EXISTS uuid UUID UNIQUE DEFAULT uuid_generate_v4();
                """
            )
            await conn.execute(
                "UPDATE tools SET uuid = uuid_generate_v4() WHERE uuid IS NULL;"
            )
            await conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_tools_uuid ON tools(uuid);"
            )
        except Exception:
            # tools table may not exist yet or may already be up to date
            pass

        try:
            await conn.execute(
                """
                ALTER TABLE whatsapp_connections
                    ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
                    ADD COLUMN IF NOT EXISTS project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
                    ADD COLUMN IF NOT EXISTS bot_project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
                    ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
                    ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
                    ADD COLUMN IF NOT EXISTS name VARCHAR(255),
                    ADD COLUMN IF NOT EXISTS provider VARCHAR(32) NOT NULL DEFAULT 'meta_cloud',
                    ADD COLUMN IF NOT EXISTS graph_version VARCHAR(32) NOT NULL DEFAULT 'v23.0',
                    ADD COLUMN IF NOT EXISTS meta_business_account_id VARCHAR(255),
                    ADD COLUMN IF NOT EXISTS waba_id VARCHAR(255),
                    ADD COLUMN IF NOT EXISTS phone_number_id VARCHAR(255),
                    ADD COLUMN IF NOT EXISTS business_phone_number VARCHAR(64),
                    ADD COLUMN IF NOT EXISTS display_phone_number VARCHAR(64),
                    ADD COLUMN IF NOT EXISTS access_token_encrypted BYTEA,
                    ADD COLUMN IF NOT EXISTS access_token_hint VARCHAR(8),
                    ADD COLUMN IF NOT EXISTS flow_private_key_encrypted BYTEA,
                    ADD COLUMN IF NOT EXISTS flow_public_key_pem TEXT,
                    ADD COLUMN IF NOT EXISTS flow_key_fingerprint VARCHAR(128),
                    ADD COLUMN IF NOT EXISTS flow_key_generated_at TIMESTAMP,
                    ADD COLUMN IF NOT EXISTS connection_status VARCHAR(32) NOT NULL DEFAULT 'draft',
                    ADD COLUMN IF NOT EXISTS webhook_status VARCHAR(32) NOT NULL DEFAULT 'pending',
                    ADD COLUMN IF NOT EXISTS health_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
                    ADD COLUMN IF NOT EXISTS last_sync_status VARCHAR(32) NOT NULL DEFAULT 'never',
                    ADD COLUMN IF NOT EXISTS subscribed_app_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
                    ADD COLUMN IF NOT EXISTS last_validation_error TEXT,
                    ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}',
                    ADD COLUMN IF NOT EXISTS last_validated_at TIMESTAMP,
                    ADD COLUMN IF NOT EXISTS last_synced_at TIMESTAMP,
                    ADD COLUMN IF NOT EXISTS last_webhook_event_at TIMESTAMP,
                    ADD COLUMN IF NOT EXISTS last_tested_at TIMESTAMP,
                    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_workspace_id
                ON whatsapp_connections(workspace_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_project_id
                ON whatsapp_connections(project_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_bot_project_id
                ON whatsapp_connections(bot_project_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_user_id
                ON whatsapp_connections(user_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_status
                ON whatsapp_connections(connection_status)
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_webhook_events (
                    id BIGSERIAL PRIMARY KEY,
                    connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
                    event_type VARCHAR(64),
                    payload JSONB NOT NULL DEFAULT '{}',
                    headers JSONB NOT NULL DEFAULT '{}',
                    processed BOOLEAN NOT NULL DEFAULT FALSE,
                    created_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_phone_numbers (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
                    phone_number_id VARCHAR(255) NOT NULL UNIQUE,
                    display_phone_number VARCHAR(64),
                    verified_name VARCHAR(255),
                    quality_rating VARCHAR(64),
                    code_verification_status VARCHAR(64),
                    status VARCHAR(64) DEFAULT 'active',
                    raw_data JSONB NOT NULL DEFAULT '{}',
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_templates (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
                    meta_template_id VARCHAR(255) UNIQUE,
                    name VARCHAR(255) NOT NULL,
                    language VARCHAR(64),
                    category VARCHAR(64),
                    status VARCHAR(64),
                    components JSONB NOT NULL DEFAULT '{}',
                    raw_data JSONB NOT NULL DEFAULT '{}',
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_flows (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
                    meta_flow_id VARCHAR(255) UNIQUE,
                    name VARCHAR(255) NOT NULL,
                    status VARCHAR(64),
                    categories JSONB NOT NULL DEFAULT '{}',
                    raw_data JSONB NOT NULL DEFAULT '{}',
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_messages (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
                    direction VARCHAR(16) NOT NULL,
                    wa_message_id VARCHAR(255) UNIQUE,
                    chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
                    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
                    from_number VARCHAR(64),
                    to_number VARCHAR(64),
                    message_type VARCHAR(64),
                    status VARCHAR(64),
                    payload JSONB NOT NULL DEFAULT '{}',
                    response JSONB NOT NULL DEFAULT '{}',
                    error TEXT,
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS whatsapp_conversation_links (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
                    wa_user_phone_number VARCHAR(64) NOT NULL,
                    chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
                    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
                    last_message_at TIMESTAMP,
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    UNIQUE (connection_id, wa_user_phone_number)
                )
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_connection_id
                ON whatsapp_webhook_events(connection_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_created_at
                ON whatsapp_webhook_events(created_at DESC)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_phone_numbers_connection_id
                ON whatsapp_phone_numbers(connection_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_templates_connection_id
                ON whatsapp_templates(connection_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_flows_connection_id
                ON whatsapp_flows(connection_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_connection_id
                ON whatsapp_messages(connection_id)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_created_at
                ON whatsapp_messages(created_at DESC)
                """
            )
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_whatsapp_conversation_links_connection_id
                ON whatsapp_conversation_links(connection_id)
                """
            )
        except Exception:
            pass

        # (Optional) SQL file–based migrations. Currently folder may be empty,
        # but keep this for future use.
        await _run_sql_migrations(conn)

        await conn.close()
        return True
        
    except asyncpg.exceptions.InvalidPasswordError:
        print("ERROR: Invalid database password!")
        print("Please check your DATABASE_URL in .env file")
        return False
    except asyncpg.exceptions.InvalidCatalogNameError:
        print("ERROR: Database does not exist!")
        print("Please create the database first:")
        print("   CREATE DATABASE your_database_name;")
        return False
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("Starting database setup...\n")
    success = asyncio.run(setup_database())
    if not success:
        exit(1)

