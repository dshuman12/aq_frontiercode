#!/usr/bin/env python3
"""
Seed Basic Tools Script for WinAssist
Creates some basic example tools in the database.
"""

import asyncio
import asyncpg
import os
import json
import logging
from dotenv import load_dotenv
from uuid import UUID

# Load environment variables
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

# Set up logger (will be used when imported as module)
logger = logging.getLogger(__name__)

# Use print for standalone execution, logger for module import
_use_logger = False

def set_use_logger(value=True):
    """Set whether to use logger instead of print"""
    global _use_logger
    _use_logger = value

def _log(message, level='info'):
    """Log message using either print or logger"""
    if _use_logger:
        getattr(logger, level)(message)
    else:
        print(message)

if not DATABASE_URL:
    error_msg = "ERROR: DATABASE_URL not found in environment variables!\nPlease create a .env file with DATABASE_URL=postgresql://postgres:123456@127.0.0.1:5432/WinAssist"
    print(error_msg)
    if _use_logger:
        logger.error(error_msg)
    exit(1)

# Public tools to remove from the default MCP catalog
REMOVED_TOOL_NAMES = [
    "Calculator",
    "Text Formatter",
    "Text Formater",
    "Date Time Utilities",
    "String Utilities",
    "Number Utilities",
]

# Basic tools to create
BASIC_TOOLS = [
    {
        "name": "RAG Search",
        "description": "Search uploaded files or pasted reference text and return the best matching chunks for retrieval-augmented generation workflows.",
        "code": "from typing import Any\n\n\ndef rag_search(query: Any, file_path: Any = None, knowledge_text: Any = None, chunk_size: Any = 500, chunk_overlap: Any = 50, top_k: Any = 3):\n    \"\"\"Search an uploaded file or inline text using simple chunk-based RAG.\"\"\"\n    from agentok_api.utils.rag_tool import run_rag_search\n\n    return run_rag_search(\n        query=query,\n        file_path=file_path,\n        knowledge_text=knowledge_text,\n        chunk_size=chunk_size,\n        chunk_overlap=chunk_overlap,\n        top_k=top_k,\n    )",
        "variables": [
            {
                "name": "query",
                "description": "[TYPE:textarea] [REQUIRED] The user query that should be matched against the RAG knowledge base.",
                "value": "What does this knowledge base say about onboarding?",
                "default": "What does this knowledge base say about onboarding?"
            },
            {
                "name": "file_path",
                "description": "[TYPE:file] Upload the file that should be indexed for RAG. If this is set, the tool will read from the uploaded file.",
                "value": "",
                "default": ""
            },
            {
                "name": "knowledge_text",
                "description": "[TYPE:textarea] Optional inline fallback text when no file is uploaded.",
                "value": "",
                "default": ""
            },
            {
                "name": "chunk_size",
                "description": "[TYPE:number] The size of each chunk used during RAG chunking.",
                "value": 500,
                "default": 500
            },
            {
                "name": "chunk_overlap",
                "description": "[TYPE:number] Overlap preserved between chunks to keep nearby context.",
                "value": 50,
                "default": 50
            },
            {
                "name": "top_k",
                "description": "[TYPE:number] Number of best matching chunks to return.",
                "value": 3,
                "default": 3
            }
        ],
        "is_public": True
    },
    {
        "name": "HTTP Request",
        "description": "Make HTTP GET or POST requests to external APIs. Configure a real endpoint URL before using this tool.",
        "code": "import requests\n\ndef http_request(method, url, headers=None, data=None):\n    \"\"\"Make HTTP request\"\"\"\n    try:\n        if method.upper() == 'GET':\n            response = requests.get(url, headers=headers or {}, timeout=10)\n        elif method.upper() == 'POST':\n            response = requests.post(url, headers=headers or {}, json=data, timeout=10)\n        else:\n            return {'error': f'Unsupported method: {method}'}\n        \n        return {\n            'status_code': response.status_code,\n            'headers': dict(response.headers),\n            'body': response.text,\n            'url': url\n        }\n    except Exception as e:\n        return {'error': str(e)}",
        "variables": [
            {
                "name": "method",
                "description": "HTTP method: GET or POST",
                "value": "GET",
                "default": "GET"
            },
            {
                "name": "url",
                "description": "The URL to request",
                "value": "",
                "default": ""
            },
            {
                "name": "headers",
                "description": "HTTP headers as JSON object",
                "value": "{}",
                "default": "{}"
            },
            {
                "name": "data",
                "description": "Request body as JSON object (for POST)",
                "value": "{}",
                "default": "{}"
            }
        ],
        "is_public": True
    },
    {
        "name": "JSON Parser",
        "description": "Parse and manipulate JSON data",
        "code": "import json\n\ndef json_operation(json_string, operation, **kwargs):\n    \"\"\"Parse and manipulate JSON\"\"\"\n    try:\n        data = json.loads(json_string)\n        \n        operations = {\n            'get_keys': lambda d: list(d.keys()) if isinstance(d, dict) else [],\n            'get_values': lambda d: list(d.values()) if isinstance(d, dict) else [],\n            'get': lambda d, key: d.get(key) if isinstance(d, dict) and 'key' in kwargs else None,\n            'stringify': lambda d: json.dumps(d, indent=2)\n        }\n        \n        if operation not in operations:\n            return {'error': f'Unknown operation: {operation}'}\n        \n        if operation == 'get':\n            result = operations[operation](data, kwargs.get('key'))\n        else:\n            result = operations[operation](data)\n        \n        return {'result': result, 'operation': operation}\n    except json.JSONDecodeError as e:\n        return {'error': f'Invalid JSON: {str(e)}'}\n    except Exception as e:\n        return {'error': str(e)}",
        "variables": [
            {
                "name": "json_string",
                "description": "JSON string to parse",
                "value": "{}",
                "default": "{}"
            },
            {
                "name": "operation",
                "description": "Operation: get_keys, get_values, get, or stringify",
                "value": "get_keys",
                "default": "get_keys"
            },
            {
                "name": "key",
                "description": "Key to get (for get operation)",
                "value": "",
                "default": ""
            }
        ],
        "is_public": True
    }
]


async def seed_tools():
    """Create basic tools in the database"""
    try:
        _log("Connecting to database...")
        # Parse DATABASE_URL to ensure correct format for asyncpg
        # asyncpg expects postgres:// not postgresql://
        db_url = DATABASE_URL.replace('postgresql://', 'postgres://') if DATABASE_URL.startswith('postgresql://') else DATABASE_URL
        conn = await asyncpg.connect(db_url)
        
        # Get first user from database
        _log("Finding user...")
        user = await conn.fetchrow("SELECT id FROM persons LIMIT 1")
        
        if not user:
            error_msg = "ERROR: No users found in database!\nPlease create a user first by registering at http://localhost:5173/auth/register"
            _log(error_msg, 'error')
            await conn.close()
            return False
        
        user_id = user['id']
        _log(f"Using user ID: {user_id}")
        
        # Check if tools already exist
        existing_tools = await conn.fetch("SELECT name FROM tools WHERE user_id = $1", user_id)
        existing_names = {tool['name'] for tool in existing_tools}

        removed_count = 0
        for tool_name in REMOVED_TOOL_NAMES:
            delete_status = await conn.execute(
                """
                    DELETE FROM tools
                    WHERE user_id = $1 AND name = $2 AND is_public = TRUE
                """,
                user_id,
                tool_name,
            )
            removed = int(delete_status.split()[-1]) if delete_status else 0
            if removed > 0:
                _log(f"  - Removed obsolete public tool '{tool_name}'")
                removed_count += removed

        if removed_count > 0:
            existing_tools = await conn.fetch("SELECT name FROM tools WHERE user_id = $1", user_id)
            existing_names = {tool['name'] for tool in existing_tools}
        
        _log(f"Creating {len(BASIC_TOOLS)} basic tools...")
        created_count = 0
        skipped_count = 0
        
        for tool_data in BASIC_TOOLS:
            tool_name = tool_data['name']

            if tool_name in {"RAG Search", "HTTP Request"}:
                try:
                    update_status = await conn.execute(
                        """
                        UPDATE tools
                        SET description = $1,
                            code = $2,
                            variables = $3,
                            is_public = $4,
                            updated_at = NOW()
                        WHERE user_id = $5 AND name = $6 AND is_public = TRUE
                        """,
                        tool_data['description'],
                        tool_data.get('code'),
                        json.dumps(tool_data['variables']) if tool_data.get('variables') else '[]',
                        tool_data.get('is_public', True),
                        user_id,
                        tool_name,
                    )
                    refreshed = int(update_status.split()[-1]) if update_status else 0
                    if refreshed > 0:
                        _log("  ~ Refreshed 'RAG Search' with file upload support")
                        skipped_count += 1
                        continue
                except Exception as e:
                    _log(f"  ! Error refreshing '{tool_name}': {str(e)}", 'error')
            
            # Skip if tool already exists
            if tool_name in existing_names:
                _log(f"  - Skipping '{tool_name}' (already exists)")
                skipped_count += 1
                continue
            
            try:
                # Insert tool
                await conn.execute("""
                    INSERT INTO tools (name, description, code, user_id, variables, is_public, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
                """,
                    tool_data['name'],
                    tool_data['description'],
                    tool_data.get('code'),  # Store as plain text
                    user_id,
                    json.dumps(tool_data['variables']) if tool_data.get('variables') else '[]',
                    tool_data.get('is_public', False)
                )
                _log(f"  + Created '{tool_name}'")
                created_count += 1
            except Exception as e:
                _log(f"  ! Error creating '{tool_name}': {str(e)}", 'error')
        
        await conn.close()
        
        _log(f"Summary: Removed: {removed_count} obsolete tools, Created: {created_count} tools, Skipped: {skipped_count} tools (already exist)")
        _log("Database seeding complete!")
        return True
        
    except asyncpg.exceptions.InvalidPasswordError:
        error_msg = "ERROR: Invalid database password!\nPlease check your DATABASE_URL in .env file"
        _log(error_msg, 'error')
        return False
    except asyncpg.exceptions.InvalidCatalogNameError:
        error_msg = "ERROR: Database does not exist!\nPlease create the database first or run setup_database.py"
        _log(error_msg, 'error')
        return False
    except Exception as e:
        error_msg = f"ERROR: {str(e)}"
        _log(error_msg, 'error')
        if not _use_logger:
            import traceback
            traceback.print_exc()
        return False


# Make seed_tools function importable
__all__ = ['seed_tools']

if __name__ == "__main__":
    print("Starting tool seeding...\n")
    success = asyncio.run(seed_tools())
    if not success:
        exit(1)

