import base64
import unittest
from unittest.mock import patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from agentok_api.dependencies import get_current_user_or_bot
from agentok_api.routers.ocr import router as ocr_router
from agentok_api.services.document_ocr import extract_document_ocr, parse_document_fields


class ParseDocumentFieldsTests(unittest.TestCase):
    def test_parse_aadhaar_fields(self):
        text = """
        Government of India
        RAVI KUMAR
        DOB: 12/08/1992
        Male
        1234 5678 9012
        """
        result = parse_document_fields(text, "aadhaar")

        self.assertEqual(result["document_type"], "aadhaar")
        self.assertEqual(result["fields"]["name"], "RAVI KUMAR")
        self.assertEqual(result["fields"]["aadhaar_number"], "1234 5678 9012")
        self.assertEqual(result["fields"]["date_of_birth"], "12/08/1992")
        self.assertEqual(result["fields"]["gender"], "Male")

    def test_parse_pan_fields(self):
        text = """
        INCOME TAX DEPARTMENT
        PRIYA SHARMA
        RAJESH SHARMA
        14/02/1990
        ABCDE1234F
        """
        result = parse_document_fields(text, "pan")

        self.assertEqual(result["document_type"], "pan")
        self.assertEqual(result["fields"]["name"], "PRIYA SHARMA")
        self.assertEqual(result["fields"]["father_name"], "RAJESH SHARMA")
        self.assertEqual(result["fields"]["date_of_birth"], "14/02/1990")
        self.assertEqual(result["fields"]["pan_number"], "ABCDE1234F")

    def test_parse_driving_licence_fields(self):
        text = """
        DRIVING LICENCE
        Name: SURESH KUMAR
        DL No: DL-0420110149646
        DOB: 05-10-1988
        Issue Date: 12-03-2020
        Valid Till: 11-03-2040
        """
        result = parse_document_fields(text, "driving_licence")

        self.assertEqual(result["document_type"], "driving_licence")
        self.assertEqual(result["fields"]["name"], "SURESH KUMAR")
        self.assertEqual(result["fields"]["licence_number"], "DL-0420110149646")
        self.assertEqual(result["fields"]["date_of_birth"], "05-10-1988")
        self.assertEqual(result["fields"]["issue_date"], "12-03-2020")
        self.assertEqual(result["fields"]["valid_till"], "11-03-2040")


class ExtractDocumentOcrTests(unittest.TestCase):
    @staticmethod
    def _image_data_url() -> str:
        raw = base64.b64encode(b"fake-image-binary").decode("ascii")
        return f"data:image/png;base64,{raw}"

    @patch("agentok_api.services.document_ocr._ensure_image_is_loadable")
    @patch("agentok_api.services.document_ocr._extract_text_with_vision")
    def test_extract_document_ocr_success(self, mocked_vision, _mocked_verify):
        mocked_vision.return_value = """
        Government of India
        RAVI KUMAR
        DOB: 12/08/1992
        Male
        1234 5678 9012
        """

        result = extract_document_ocr(
            content_base64=self._image_data_url(),
            filename="aadhaar.png",
            mime_type="image/png",
            document_type="aadhaar",
        )

        self.assertTrue(result["ok"])
        self.assertEqual(result["document_type"], "aadhaar")
        self.assertEqual(result["fields"]["aadhaar_number"], "1234 5678 9012")
        self.assertEqual(result["ocr_provider"], "openai_vision")
        self.assertIsNone(result["error"])

    @patch("agentok_api.services.document_ocr._ensure_image_is_loadable")
    @patch("agentok_api.services.document_ocr._extract_text_with_vision")
    def test_extract_document_ocr_reports_no_match(self, mocked_vision, _mocked_verify):
        mocked_vision.return_value = "This is some random text without ID fields"

        result = extract_document_ocr(
            content_base64=self._image_data_url(),
            filename="unknown.png",
            mime_type="image/png",
            document_type="pan",
        )

        self.assertFalse(result["ok"])
        self.assertEqual(result["document_type"], "pan")
        self.assertEqual(result["matched_field_count"], 0)
        self.assertIn("no expected pan fields", (result["error"] or "").lower())

    def test_extract_document_ocr_rejects_unsupported_mime(self):
        payload = base64.b64encode(b"plain-text").decode("ascii")
        with self.assertRaises(ValueError):
            extract_document_ocr(
                content_base64=payload,
                filename="notes.txt",
                mime_type="text/plain",
                document_type="auto",
            )

    @patch("agentok_api.services.document_ocr._extract_pdf_text")
    @patch("agentok_api.services.document_ocr._extract_text_with_vision")
    def test_extract_document_ocr_uses_vision_fallback_for_pdf(self, mocked_vision, mocked_pdf_text):
        mocked_pdf_text.return_value = ""
        mocked_vision.return_value = """
        DRIVING LICENCE
        Name: SURESH KUMAR
        DL No: DL-0420110149646
        DOB: 05-10-1988
        """
        payload = base64.b64encode(b"%PDF-1.4 fake-scanned-pdf").decode("ascii")

        result = extract_document_ocr(
            content_base64=payload,
            filename="licence.pdf",
            mime_type="application/pdf",
            document_type="driving_licence",
        )

        self.assertTrue(result["ok"])
        self.assertEqual(result["ocr_provider"], "openai_vision")
        self.assertEqual(result["document_type"], "driving_licence")
        self.assertEqual(result["fields"]["licence_number"], "DL-0420110149646")


class OcrRouteTests(unittest.TestCase):
    def setUp(self):
        app = FastAPI()
        app.include_router(ocr_router, prefix="/ocr")
        app.dependency_overrides[get_current_user_or_bot] = lambda: {"id": "test-user"}
        self.client = TestClient(app)

    @patch("agentok_api.routers.ocr.extract_document_ocr")
    def test_extract_route_success(self, mocked_extract):
        mocked_extract.return_value = {
            "ok": True,
            "document_type": "aadhaar",
            "fields": {"aadhaar_number": "1234 5678 9012"},
            "text": "sample",
            "matched_field_count": 1,
            "error": None,
        }

        response = self.client.post(
            "/ocr/extract",
            json={
                "content_base64": self._sample_payload(),
                "filename": "aadhaar.png",
                "mime_type": "image/png",
                "document_type": "aadhaar",
            },
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertTrue(body["ok"])
        self.assertEqual(body["document_type"], "aadhaar")
        self.assertEqual(body["fields"]["aadhaar_number"], "1234 5678 9012")

    @staticmethod
    def _sample_payload() -> str:
        return f"data:image/png;base64,{base64.b64encode(b'route-image').decode('ascii')}"


if __name__ == "__main__":
    unittest.main()
