


import logging
import os
import sys
from pathlib import Path
import time

# Load .env from backend/api so WIDGET_STATIC_BASE_PATH etc. are set before static_dir is chosen
try:
    from dotenv import load_dotenv
    _api_dir = Path(__file__).resolve().parent.parent
    load_dotenv(_api_dir / ".env")
except Exception:
    pass

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from .services.database import DatabaseClient
from .routers import (
    api_docs,
    auth,
    projects,
    chats,
    codegen,
    tools,
    attachments,
    knowledge,
    dashboard,
    settings,
    workspaces,
    templates,
    connectors,
    ocr,
    whatsapp,
    support_assistant,
)
from .routers import project_analytics
from .routers import project_governance
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
main_app = FastAPI(
    title="WinAssist APIs",
    description="Specification of the WinAssist APIs. To test the APIs, register or log in and include the JWT token in the Authorization header.",
    version="1.0.0",
    swagger_ui_parameters={"persistAuthorization": True},
    redirect_slashes=False,  # Disable automatic trailing slash redirects
)
main_app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://74.225.252.202:5173",
        "http://74.225.252.202",
        "http://192.168.68.118:5173",
        "http://135.235.140.13:5173",
        "http://135.235.140.13",
        "null",  
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Health check endpoint (accessible at /v1/health)
@main_app.get("/health")
async def health_check():
    """Health check endpoint for Docker and load balancers"""
    return {"status": "healthy", "service": "winassist-api"}

main_app.include_router(auth.router, prefix="/auth", tags=["Authentication"])
main_app.include_router(projects.router, prefix="/projects", tags=["Projects"])
main_app.include_router(chats.router, prefix="/chats", tags=["Chat"])
main_app.include_router(tools.router, prefix="/tools", tags=["Tool"])
main_app.include_router(attachments.router, prefix="/tools", tags=["Tool Attachments"])
main_app.include_router(knowledge.router, prefix="/knowledge", tags=["Knowledge"])
main_app.include_router(codegen.router, prefix="/codegen", tags=["Codegen"])
main_app.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
main_app.include_router(settings.router, prefix="/settings", tags=["Settings"])
main_app.include_router(workspaces.router, prefix="/workspaces", tags=["Workspaces"])
main_app.include_router(project_analytics.router, prefix="/project-analytics", tags=["Project Analytics"])
main_app.include_router(project_governance.router, prefix="/projects", tags=["Project Governance"])
main_app.include_router(templates.router, prefix="/templates", tags=["Templates"])
main_app.include_router(connectors.router, prefix="/connectors", tags=["Connectors"])
main_app.include_router(ocr.router, prefix="/ocr", tags=["OCR"])
main_app.include_router(whatsapp.router, prefix="/whatsapp", tags=["WhatsApp"])
main_app.include_router(support_assistant.router, prefix="/support-assistant", tags=["Support Assistant"])
app = FastAPI(redirect_slashes=False)  # Disable automatic trailing slash redirects
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://74.225.252.202:5173",
        "http://74.225.252.202",
        "http://192.168.68.118:5173",
        "http://135.235.140.13:5173",
        "http://135.235.140.13",
    
        "null",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    # Lightweight request logging for debugging "Pending" API calls.
    start = time.perf_counter()
    try:
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start) * 1000
        logger.info(
            f"{request.method} {request.url.path} -> {response.status_code} ({duration_ms:.0f}ms)"
        )
        return response
    except Exception:
        duration_ms = (time.perf_counter() - start) * 1000
        logger.exception(f"{request.method} {request.url.path} -> ERROR ({duration_ms:.0f}ms)")
        raise

app.mount("/v1", main_app)
app.include_router(api_docs.router, include_in_schema=False)

# Root-level health check endpoint
@app.get("/health")
async def root_health_check():
    """Root-level health check endpoint"""
    return {"status": "healthy", "service": "winassist-api"}

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    logger.error(f"HTTP exception: {exc.detail}", exc_info=True)
    
    response = JSONResponse(
        status_code=exc.status_code,
        content={
            "status_code": exc.status_code,
            "error": {"message": exc.detail},
        },
    )

    origin = request.headers.get("origin")
    if origin:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
    
    return response
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    logger.error(f"Validation error: {exc.errors()}", exc_info=True)
    
    response = JSONResponse(
        status_code=422,
        content={
            "status_code": 422,
            "error": {"message": "Validation Error", "detail": exc.errors()},
        },
    )

    origin = request.headers.get("origin")
    if origin:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
    
    return response



@app.exception_handler(Exception)
async def global_exception_handler(request, exc: Exception):
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    
    response = JSONResponse(
        status_code=500,
        content={
            "status_code": 500,
            "error": {"message": "Internal Server Error", "detail": str(exc)},
        },
    )
    
    
    origin = request.headers.get("origin")
    if origin:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
    
    return response



@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WinAssist APIs</title>
    <link rel="icon" href="/static/favicon.ico" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            background-color: #303030;
            color: #ffffff;
        }
        h1 {
            color: #9FE88D;
        }
        a {
            color: #9FE88D;
            opacity: 0.8;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        a:hover {
            color: #9FE88D;
            opacity: 1;
            text-decoration: underline;
        }
        p {
            text-align: center;
            margin: 20px 0;
        }
        img {
            margin-bottom: 32px;
        }
        .container {
            text-align: center;
            margin: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to WinAssist APIs</h1>
        <p>Check the <a href="/api-docs">API Docs</a> or try the endpoints in <a href="/v1/docs">Swagger UI</a>.</p>
        <p>Sign in to start using WinAssist services with JWT authentication.</p>
    </div>
</body>
</html>
    """
    return HTMLResponse(content=html_content)



# Use WIDGET_STATIC_BASE_PATH if set (e.g. /var/www/myapp/frontend); then static is at {base}/static
_widget_base = (os.getenv("WIDGET_STATIC_BASE_PATH") or "").strip()
_default_static_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
if _widget_base:
    # If the configured base path doesn't exist (common on Windows when a drive letter differs),
    # fall back to a project-local static dir instead of crashing at import time.
    if not os.path.exists(_widget_base):
        logger.warning(
            f"WIDGET_STATIC_BASE_PATH is set to '{_widget_base}' but that path does not exist. "
            f"Falling back to '{_default_static_dir}'."
        )
        static_dir = _default_static_dir
        _widget_base = ""
    else:
        static_dir = os.path.join(_widget_base.rstrip("/"), "static")
        try:
            os.makedirs(os.path.join(static_dir, "widgets"), exist_ok=True)
        except OSError as e:
            logger.warning(
                f"Failed to create widget static directory under '{static_dir}': {e}. "
                f"Falling back to '{_default_static_dir}'."
            )
            static_dir = _default_static_dir
            _widget_base = ""
else:
    static_dir = _default_static_dir
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")
    main_app.mount("/static", StaticFiles(directory=static_dir), name="static")
else:
    logger.warning(f"Static directory not found at {static_dir}, skipping static file mounting")



@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    logger.info("Application starting up...")
    
    # Ensure database schema exists (persons + all tables) so all environments work
    api_dir = Path(__file__).parent.parent
    if str(api_dir) not in sys.path:
        sys.path.insert(0, str(api_dir))
    
    try:
        from setup_database import setup_database
        import asyncio
        for attempt in range(1, 6):
            try:
                success = await setup_database()
                if success:
                    logger.info("Database schema initialized (tables created or already exist)")
                    break
                logger.warning(f"Database setup returned False (attempt {attempt}/5)")
            except Exception as e:
                logger.warning(f"Database schema init attempt {attempt}/5 failed: {e}. Retrying in 3s...")
                await asyncio.sleep(3)
        else:
            logger.warning("Database schema init did not succeed after 5 attempts. Ensure DB is running and DATABASE_URL is correct.")
    except ImportError as e:
        logger.warning(f"Could not run schema init (setup_database not found): {e}. Run setup_database.py manually if you see 'relation persons does not exist'.")
    except Exception as e:
        logger.warning(f"Database schema init failed: {e}. This is not critical if DB is already set up.")
    
    # Seed basic tools automatically
    try:
        from seed_tools import seed_tools, set_use_logger
        # Enable logger mode for seed_tools
        set_use_logger(True)
        logger.info("Seeding basic tools...")
        # seed_tools is already an async function, so we can await it
        success = await seed_tools()
        if success:
            logger.info("Tool seeding completed successfully")
        else:
            logger.warning("Tool seeding completed with warnings")
    except Exception as e:
        # Don't fail startup if tool seeding fails
        logger.warning(f"Failed to seed tools on startup: {e}. This is not critical.")
        logger.debug("Tool seeding error details:", exc_info=True)



@app.on_event("shutdown")
async def shutdown_event():
    """Clean up resources when the application shuts down"""
    logger.info("Application shutting down. Cleaning up resources...")
    db_client = DatabaseClient()
    await db_client.close()
    DatabaseClient.reset()
    
    


