import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

import asyncpg
from .datetime import IST_TIMEZONE, serialize_datetime_for_api, to_ist_datetime


API_DIR = Path(__file__).resolve().parents[2]
KNOWLEDGE_UPLOADS_ROOT = Path(
    os.environ.get("KNOWLEDGE_UPLOADS_ROOT", str(API_DIR / "knowledge_uploads"))
).resolve()


def _parse_uuid(value: Optional[str]) -> Optional[UUID]:
    if not value:
        return None
    try:
        return UUID(str(value))
    except (TypeError, ValueError):
        return None


def _iso(value: Any) -> Optional[str]:
    if isinstance(value, datetime):
        return serialize_datetime_for_api(value)
    if value is None:
        return None
    return str(value)


def _coerce_timestamp(value: Any) -> Optional[datetime]:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        dt = to_ist_datetime(value)
        return dt.replace(tzinfo=None) if dt else None
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized:
            return None
        if normalized.endswith("Z"):
            normalized = normalized[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            return None
        if parsed.tzinfo is not None:
            return parsed.astimezone(IST_TIMEZONE).replace(tzinfo=None)
        return parsed
    return None


def _normalize_document_row(row: asyncpg.Record) -> Dict[str, Any]:
    return {
        "id": str(row["id"]),
        "workspace_id": str(row["workspace_id"]) if row["workspace_id"] else None,
        "title": row["title"],
        "filename": row["filename"],
        "stored_filename": row["stored_filename"],
        "relative_path": row["relative_path"],
        "mime": row["mime"],
        "size": int(row["size_bytes"] or 0),
        "status": row["status"],
        "extracted_chars": int(row["extracted_chars"] or 0),
        "index_error": row["index_error"],
        "source_type": row["source_type"] if "source_type" in row else "file",
        "source_url": row["source_url"] if "source_url" in row else None,
        "sync_status": row["sync_status"] if "sync_status" in row else None,
        "sync_error": row["sync_error"] if "sync_error" in row else None,
        "source_language": row["source_language"] if "source_language" in row else None,
        "created_at": _iso(row["created_at"]),
        "updated_at": _iso(row["updated_at"]),
        "last_indexed_at": _iso(row["last_indexed_at"]),
        "last_synced_at": _iso(row["last_synced_at"]) if "last_synced_at" in row else None,
    }


def _normalize_collection_row(row: asyncpg.Record) -> Dict[str, Any]:
    document_ids = [str(value) for value in (row["document_ids"] or []) if value]
    bot_ids = [str(value) for value in (row["bot_ids"] or []) if value]
    return {
        "id": str(row["id"]),
        "workspace_id": str(row["workspace_id"]) if row["workspace_id"] else None,
        "name": str(row["name"] or "").strip(),
        "description": str(row["description"] or "").strip(),
        "documentIds": document_ids,
        "botIds": bot_ids,
        "created_at": _iso(row["created_at"]),
        "updated_at": _iso(row["updated_at"]),
    }


def _legacy_metadata_index_path(user_id: str) -> Path:
    return KNOWLEDGE_UPLOADS_ROOT / "knowledge" / str(user_id) / "index.json"


def _legacy_collections_index_path(user_id: str, workspace_id: Optional[str]) -> Path:
    scope = str(workspace_id or "default")
    return KNOWLEDGE_UPLOADS_ROOT / "knowledge" / str(user_id) / f"collections_{scope}.json"


def _load_legacy_json_list(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
    except Exception:
        return []
    return []


async def migrate_legacy_documents_if_needed(
    conn: asyncpg.Connection,
    user_id: str,
) -> None:
    existing = await conn.fetchval(
        "SELECT COUNT(*) FROM knowledge_documents WHERE user_id = $1",
        _parse_uuid(user_id),
    )
    if existing:
        return

    items = _load_legacy_json_list(_legacy_metadata_index_path(user_id))
    for item in items:
        document_id = str(item.get("id") or "").strip()
        relative_path = str(item.get("relative_path") or "").strip()
        if not document_id or not relative_path:
            continue
        await conn.execute(
            """
            INSERT INTO knowledge_documents (
                id,
                user_id,
                title,
                filename,
                stored_filename,
                relative_path,
                mime,
                size_bytes,
                status,
                extracted_chars,
                index_error,
                source_type,
                source_url,
                sync_status,
                sync_error,
                source_language,
                created_at,
                updated_at,
                last_indexed_at,
                last_synced_at
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
                COALESCE($17::timestamp, NOW()),
                COALESCE($18::timestamp, NOW()),
                $19::timestamp,
                $20::timestamp
            )
            ON CONFLICT (id) DO NOTHING
            """,
            document_id,
            _parse_uuid(user_id),
            str(item.get("title") or item.get("filename") or "Untitled").strip(),
            str(item.get("filename") or "").strip(),
            item.get("stored_filename"),
            relative_path,
            item.get("mime"),
            int(item.get("size") or 0),
            str(item.get("status") or "indexed"),
            int(item.get("extracted_chars") or 0),
            item.get("index_error"),
            str(item.get("source_type") or "file"),
            item.get("source_url"),
            item.get("sync_status"),
            item.get("sync_error"),
            item.get("source_language"),
            _coerce_timestamp(item.get("created_at")),
            _coerce_timestamp(item.get("updated_at")),
            _coerce_timestamp(item.get("last_indexed_at")),
            _coerce_timestamp(item.get("last_synced_at")),
        )


async def migrate_legacy_collections_if_needed(
    conn: asyncpg.Connection,
    user_id: str,
    workspace_id: Optional[str],
) -> None:
    workspace_uuid = _parse_uuid(workspace_id)
    existing = await conn.fetchval(
        """
        SELECT COUNT(*)
        FROM knowledge_collections
        WHERE user_id = $1
          AND (
            ($2::uuid IS NULL AND workspace_id IS NULL)
            OR workspace_id = $2::uuid
          )
        """,
        _parse_uuid(user_id),
        workspace_uuid,
    )
    if existing:
        return

    items = _load_legacy_json_list(_legacy_collections_index_path(user_id, workspace_id))
    for item in items:
        collection_id = str(item.get("id") or "").strip()
        name = str(item.get("name") or "").strip()
        if not collection_id or not name:
            continue
        await conn.execute(
            """
            INSERT INTO knowledge_collections (
                id,
                user_id,
                workspace_id,
                name,
                description,
                created_at,
                updated_at
            ) VALUES (
                $1, $2, $3, $4, $5,
                COALESCE($6::timestamp, NOW()),
                COALESCE($7::timestamp, NOW())
            )
            ON CONFLICT (id) DO NOTHING
            """,
            collection_id,
            _parse_uuid(user_id),
            workspace_uuid,
            name,
            str(item.get("description") or "").strip(),
            _coerce_timestamp(item.get("created_at")),
            _coerce_timestamp(item.get("updated_at")),
        )
        for document_id in [str(value) for value in (item.get("documentIds") or []) if value]:
            await conn.execute(
                """
                INSERT INTO knowledge_collection_documents (collection_id, document_id)
                VALUES ($1, $2)
                ON CONFLICT DO NOTHING
                """,
                collection_id,
                document_id,
            )
        for bot_id in [str(value) for value in (item.get("botIds") or []) if value]:
            bot_uuid = _parse_uuid(bot_id)
            if not bot_uuid:
                continue
            await conn.execute(
                """
                INSERT INTO knowledge_collection_bots (collection_id, bot_project_id)
                VALUES ($1, $2)
                ON CONFLICT DO NOTHING
                """,
                collection_id,
                bot_uuid,
            )


def resolve_relative_path(user_id: str, relative_path: str) -> Path:
    cleaned = str(relative_path or "").strip().replace("\\", "/")
    if not cleaned:
        raise ValueError("relative_path is required")
    abs_path = (KNOWLEDGE_UPLOADS_ROOT / cleaned).resolve()
    root_path = KNOWLEDGE_UPLOADS_ROOT.resolve()
    if not str(abs_path).startswith(str(root_path)):
        raise ValueError("Invalid relative_path")
    expected_prefix = f"knowledge/{user_id}/"
    if not cleaned.startswith(expected_prefix):
        raise PermissionError("Not authorized for this document")
    return abs_path


async def list_knowledge_documents(
    conn: asyncpg.Connection,
    user_id: str,
    workspace_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    await migrate_legacy_documents_if_needed(conn, user_id)
    workspace_uuid = _parse_uuid(workspace_id)
    rows = await conn.fetch(
        """
        SELECT
            id,
            workspace_id,
            title,
            filename,
            stored_filename,
            relative_path,
            mime,
            size_bytes,
            status,
            extracted_chars,
            index_error,
            source_type,
            source_url,
            sync_status,
            sync_error,
            source_language,
            created_at,
            updated_at,
            last_indexed_at,
            last_synced_at
        FROM knowledge_documents
        WHERE user_id = $1
          AND (
            $2::uuid IS NULL
            OR workspace_id = $2::uuid
          )
        ORDER BY created_at DESC
        """,
        _parse_uuid(user_id),
        workspace_uuid,
    )
    return [_normalize_document_row(row) for row in rows]


async def get_knowledge_document(
    conn: asyncpg.Connection,
    user_id: str,
    upload_id: str,
) -> Optional[Dict[str, Any]]:
    await migrate_legacy_documents_if_needed(conn, user_id)
    row = await conn.fetchrow(
        """
        SELECT
            id,
            workspace_id,
            title,
            filename,
            stored_filename,
            relative_path,
            mime,
            size_bytes,
            status,
            extracted_chars,
            index_error,
            source_type,
            source_url,
            sync_status,
            sync_error,
            source_language,
            created_at,
            updated_at,
            last_indexed_at,
            last_synced_at
        FROM knowledge_documents
        WHERE id = $1 AND user_id = $2
        """,
        upload_id,
        _parse_uuid(user_id),
    )
    return _normalize_document_row(row) if row else None


async def upsert_knowledge_document(
    conn: asyncpg.Connection,
    user_id: str,
    document: Dict[str, Any],
) -> Dict[str, Any]:
    workspace_uuid = _parse_uuid(document.get("workspace_id"))
    row = await conn.fetchrow(
        """
        INSERT INTO knowledge_documents (
            id,
            user_id,
            workspace_id,
            title,
            filename,
            stored_filename,
            relative_path,
            mime,
            size_bytes,
            status,
            extracted_chars,
            index_error,
            source_type,
            source_url,
            sync_status,
            sync_error,
            source_language,
            created_at,
            updated_at,
            last_indexed_at,
            last_synced_at
        ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17,
            COALESCE($18::timestamp, NOW()),
            COALESCE($19::timestamp, NOW()),
            $20::timestamp,
            $21::timestamp
        )
        ON CONFLICT (id) DO UPDATE SET
            workspace_id = EXCLUDED.workspace_id,
            title = EXCLUDED.title,
            filename = EXCLUDED.filename,
            stored_filename = EXCLUDED.stored_filename,
            relative_path = EXCLUDED.relative_path,
            mime = EXCLUDED.mime,
            size_bytes = EXCLUDED.size_bytes,
            status = EXCLUDED.status,
            extracted_chars = EXCLUDED.extracted_chars,
            index_error = EXCLUDED.index_error,
            source_type = EXCLUDED.source_type,
            source_url = EXCLUDED.source_url,
            sync_status = EXCLUDED.sync_status,
            sync_error = EXCLUDED.sync_error,
            source_language = EXCLUDED.source_language,
            updated_at = COALESCE(EXCLUDED.updated_at, NOW()),
            last_indexed_at = EXCLUDED.last_indexed_at,
            last_synced_at = EXCLUDED.last_synced_at
        RETURNING
            id,
            workspace_id,
            title,
            filename,
            stored_filename,
            relative_path,
            mime,
            size_bytes,
            status,
            extracted_chars,
            index_error,
            source_type,
            source_url,
            sync_status,
            sync_error,
            source_language,
            created_at,
            updated_at,
            last_indexed_at,
            last_synced_at
        """,
        str(document.get("id") or "").strip(),
        _parse_uuid(user_id),
        workspace_uuid,
        str(document.get("title") or document.get("filename") or "Untitled").strip(),
        str(document.get("filename") or "").strip(),
        document.get("stored_filename"),
        str(document.get("relative_path") or "").strip(),
        document.get("mime"),
        int(document.get("size") or 0),
        str(document.get("status") or "indexed"),
        int(document.get("extracted_chars") or 0),
        document.get("index_error"),
        str(document.get("source_type") or "file"),
        document.get("source_url"),
        document.get("sync_status"),
        document.get("sync_error"),
        document.get("source_language"),
        _coerce_timestamp(document.get("created_at")),
        _coerce_timestamp(document.get("updated_at")),
        _coerce_timestamp(document.get("last_indexed_at")),
        _coerce_timestamp(document.get("last_synced_at")),
    )
    return _normalize_document_row(row)


async def delete_knowledge_document(
    conn: asyncpg.Connection,
    user_id: str,
    upload_id: str,
) -> bool:
    result = await conn.execute(
        "DELETE FROM knowledge_documents WHERE id = $1 AND user_id = $2",
        upload_id,
        _parse_uuid(user_id),
    )
    return result.endswith("1")


async def list_knowledge_collections(
    conn: asyncpg.Connection,
    user_id: str,
    workspace_id: Optional[str],
) -> List[Dict[str, Any]]:
    await migrate_legacy_documents_if_needed(conn, user_id)
    await migrate_legacy_collections_if_needed(conn, user_id, workspace_id)
    workspace_uuid = _parse_uuid(workspace_id)
    rows = await conn.fetch(
        """
        SELECT
            c.id,
            c.workspace_id,
            c.name,
            c.description,
            c.created_at,
            c.updated_at,
            COALESCE(array_agg(DISTINCT cd.document_id) FILTER (WHERE cd.document_id IS NOT NULL), '{}') AS document_ids,
            COALESCE(array_agg(DISTINCT cb.bot_project_id::text) FILTER (WHERE cb.bot_project_id IS NOT NULL), '{}') AS bot_ids
        FROM knowledge_collections c
        LEFT JOIN knowledge_collection_documents cd ON cd.collection_id = c.id
        LEFT JOIN knowledge_collection_bots cb ON cb.collection_id = c.id
        WHERE c.user_id = $1
          AND (
            ($2::uuid IS NULL AND c.workspace_id IS NULL)
            OR c.workspace_id = $2::uuid
          )
        GROUP BY c.id
        ORDER BY c.created_at DESC
        """,
        _parse_uuid(user_id),
        workspace_uuid,
    )
    return [_normalize_collection_row(row) for row in rows]


async def get_knowledge_collection(
    conn: asyncpg.Connection,
    user_id: str,
    collection_id: str,
) -> Optional[Dict[str, Any]]:
    row = await conn.fetchrow(
        """
        SELECT
            c.id,
            c.workspace_id,
            c.name,
            c.description,
            c.created_at,
            c.updated_at,
            COALESCE(array_agg(DISTINCT cd.document_id) FILTER (WHERE cd.document_id IS NOT NULL), '{}') AS document_ids,
            COALESCE(array_agg(DISTINCT cb.bot_project_id::text) FILTER (WHERE cb.bot_project_id IS NOT NULL), '{}') AS bot_ids
        FROM knowledge_collections c
        LEFT JOIN knowledge_collection_documents cd ON cd.collection_id = c.id
        LEFT JOIN knowledge_collection_bots cb ON cb.collection_id = c.id
        WHERE c.id = $1 AND c.user_id = $2
        GROUP BY c.id
        """,
        collection_id,
        _parse_uuid(user_id),
    )
    return _normalize_collection_row(row) if row else None


async def upsert_knowledge_collection(
    conn: asyncpg.Connection,
    user_id: str,
    collection: Dict[str, Any],
) -> Dict[str, Any]:
    collection_id = str(collection.get("id") or "").strip()
    if not collection_id:
        raise ValueError("collection id is required")

    workspace_uuid = _parse_uuid(collection.get("workspace_id"))
    document_ids = [str(value) for value in (collection.get("documentIds") or []) if value]
    bot_ids = [str(value) for value in (collection.get("botIds") or []) if value]
    valid_bot_ids = [_parse_uuid(value) for value in bot_ids]
    valid_bot_ids = [value for value in valid_bot_ids if value]

    await conn.execute(
        """
        INSERT INTO knowledge_collections (
            id,
            user_id,
            workspace_id,
            name,
            description,
            created_at,
            updated_at
        ) VALUES (
            $1, $2, $3, $4, $5,
            COALESCE($6::timestamp, NOW()),
            COALESCE($7::timestamp, NOW())
        )
        ON CONFLICT (id) DO UPDATE SET
            workspace_id = EXCLUDED.workspace_id,
            name = EXCLUDED.name,
            description = EXCLUDED.description,
            updated_at = COALESCE(EXCLUDED.updated_at, NOW())
        """,
        collection_id,
        _parse_uuid(user_id),
        workspace_uuid,
        str(collection.get("name") or "").strip(),
        str(collection.get("description") or "").strip(),
        _coerce_timestamp(collection.get("created_at")),
        _coerce_timestamp(collection.get("updated_at")),
    )

    await conn.execute(
        "DELETE FROM knowledge_collection_documents WHERE collection_id = $1",
        collection_id,
    )
    for document_id in document_ids:
        await conn.execute(
            """
            INSERT INTO knowledge_collection_documents (collection_id, document_id)
            SELECT $1, d.id
            FROM knowledge_documents d
            WHERE d.id = $2 AND d.user_id = $3
            ON CONFLICT DO NOTHING
            """,
            collection_id,
            document_id,
            _parse_uuid(user_id),
        )

    await conn.execute(
        "DELETE FROM knowledge_collection_bots WHERE collection_id = $1",
        collection_id,
    )
    for bot_id in valid_bot_ids:
        await conn.execute(
            """
            INSERT INTO knowledge_collection_bots (collection_id, bot_project_id)
            SELECT $1, p.id
            FROM projects p
            WHERE p.id = $2 AND p.user_id = $3
            ON CONFLICT DO NOTHING
            """,
            collection_id,
            bot_id,
            _parse_uuid(user_id),
        )

    created = await get_knowledge_collection(conn, user_id, collection_id)
    if not created:
        raise ValueError("Failed to persist collection")
    return created


async def delete_knowledge_collection(
    conn: asyncpg.Connection,
    user_id: str,
    collection_id: str,
) -> bool:
    result = await conn.execute(
        "DELETE FROM knowledge_collections WHERE id = $1 AND user_id = $2",
        collection_id,
        _parse_uuid(user_id),
    )
    return result.endswith("1")


async def get_collection_documents(
    conn: asyncpg.Connection,
    user_id: str,
    workspace_id: Optional[str],
    collection_ids: List[str],
) -> List[Dict[str, Any]]:
    collection_id_set = [str(value) for value in collection_ids if value]
    if not collection_id_set:
        return []

    await migrate_legacy_documents_if_needed(conn, user_id)
    await migrate_legacy_collections_if_needed(conn, user_id, workspace_id)
    workspace_uuid = _parse_uuid(workspace_id)
    rows = await conn.fetch(
        """
        SELECT
            c.id AS collection_id,
            c.name AS collection_name,
            d.id,
            d.workspace_id,
            d.title,
            d.filename,
            d.stored_filename,
            d.relative_path,
            d.mime,
            d.size_bytes,
            d.status,
            d.extracted_chars,
            d.index_error,
            d.source_type,
            d.source_url,
            d.sync_status,
            d.sync_error,
            d.source_language,
            d.created_at,
            d.updated_at,
            d.last_indexed_at,
            d.last_synced_at
        FROM knowledge_collections c
        JOIN knowledge_collection_documents cd ON cd.collection_id = c.id
        JOIN knowledge_documents d ON d.id = cd.document_id
        WHERE c.user_id = $1
          AND c.id = ANY($2::text[])
          AND (
            ($3::uuid IS NULL AND c.workspace_id IS NULL)
            OR c.workspace_id = $3::uuid
          )
        ORDER BY c.created_at DESC, d.created_at DESC
        """,
        _parse_uuid(user_id),
        collection_id_set,
        workspace_uuid,
    )
    results: List[Dict[str, Any]] = []
    for row in rows:
        document = _normalize_document_row(row)
        results.append(
            {
                "collection_id": str(row["collection_id"]),
                "collection_name": row["collection_name"],
                "document": document,
            }
        )
    return results
