"""
Utility functions for generating and validating bot API keys
"""
import secrets
import hashlib


def generate_bot_api_key() -> str:
    """
    Generate a secure bot-specific API key.
    Format: bot_sk_<64_random_hex_chars>
    
    Returns:
        str: A secure, unique API key
    """
    # Generate 32 random bytes (= 64 hex characters)
    random_bytes = secrets.token_bytes(32)
    random_hex = random_bytes.hex()
    
    # Prefix with bot_sk_ to identify it as a bot secret key
    api_key = f"bot_sk_{random_hex}"
    
    return api_key


def hash_api_key(api_key: str) -> str:
    """
    Hash an API key for secure storage (optional - for extra security).
    
    Args:
        api_key: The API key to hash
        
    Returns:
        str: SHA-256 hash of the API key
    """
    return hashlib.sha256(api_key.encode()).hexdigest()


def is_valid_bot_api_key(api_key: str) -> bool:
    """
    Validate format of bot API key.
    
    Args:
        api_key: The API key to validate
        
    Returns:
        bool: True if format is valid
    """
    if not api_key:
        return False
    
    # Check prefix
    if not api_key.startswith("bot_sk_"):
        return False
    
    # Check length (bot_sk_ + 64 hex chars = 71 total)
    if len(api_key) != 71:
        return False
    
    # Check hex characters
    hex_part = api_key[7:]  # Remove "bot_sk_" prefix
    try:
        int(hex_part, 16)  # Try to parse as hex
        return True
    except ValueError:
        return False

