import csv
import html
import os
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET


def _read_text_file(file_path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return file_path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return file_path.read_text(encoding="utf-8", errors="ignore")


def _strip_xml_text(xml_bytes: bytes) -> str:
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return ""
    texts = [node.text.strip() for node in root.iter() if node.text and node.text.strip()]
    return "\n".join(texts)


def _read_docx(file_path: Path) -> str:
    with zipfile.ZipFile(file_path) as archive:
        allowed_prefixes = (
            "word/document.xml",
            "word/header",
            "word/footer",
            "word/footnotes.xml",
            "word/endnotes.xml",
        )
        parts = []
        for name in archive.namelist():
            if name.endswith(".xml") and any(name.startswith(prefix) for prefix in allowed_prefixes):
                text = _strip_xml_text(archive.read(name))
                if text:
                    parts.append(text)
        return "\n\n".join(parts)


def _read_pptx(file_path: Path) -> str:
    with zipfile.ZipFile(file_path) as archive:
        slide_names = sorted(
            name for name in archive.namelist()
            if name.startswith("ppt/slides/slide") and name.endswith(".xml")
        )
        parts = []
        for name in slide_names:
            text = _strip_xml_text(archive.read(name))
            if text:
                parts.append(text)
        return "\n\n".join(parts)


def _read_xlsx(file_path: Path) -> str:
    with zipfile.ZipFile(file_path) as archive:
        shared_strings: List[str] = []
        if "xl/sharedStrings.xml" in archive.namelist():
            shared_root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            for item in shared_root.findall("x:si", ns):
                text_fragments = [node.text or "" for node in item.iter() if node.text]
                shared_strings.append("".join(text_fragments).strip())

        ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        worksheet_names = sorted(
            name for name in archive.namelist()
            if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")
        )
        sheets: List[str] = []
        for name in worksheet_names:
            root = ET.fromstring(archive.read(name))
            rows: List[str] = []
            for row in root.findall(".//x:row", ns):
                values: List[str] = []
                for cell in row.findall("x:c", ns):
                    raw_value = cell.findtext("x:v", default="", namespaces=ns).strip()
                    cell_type = cell.attrib.get("t")
                    if not raw_value:
                        values.append("")
                        continue
                    if cell_type == "s":
                        try:
                            values.append(shared_strings[int(raw_value)])
                        except (ValueError, IndexError):
                            values.append(raw_value)
                    else:
                        values.append(raw_value)
                if any(values):
                    rows.append(", ".join(value for value in values if value))
            if rows:
                sheets.append("\n".join(rows))
        return "\n\n".join(sheets)


def _read_pdf(file_path: Path) -> str:
    last_error: Optional[Exception] = None
    for module_name in ("pypdf", "PyPDF2"):
        try:
            module = __import__(module_name, fromlist=["PdfReader"])
            reader = module.PdfReader(str(file_path))
            pages = [(page.extract_text() or "").strip() for page in reader.pages]
            return "\n\n".join(page for page in pages if page)
        except Exception as exc:  # pragma: no cover - depends on optional libs
            last_error = exc
    raise ValueError(f"Unable to read PDF file: {last_error}")


def extract_text_from_path(file_path: str) -> str:
    path = Path(str(file_path or "")).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path}")

    ext = path.suffix.lower()
    if ext in {".txt", ".md", ".json", ".yaml", ".yml", ".log", ".ini", ".cfg", ".xml"}:
        return _read_text_file(path)
    if ext in {".csv"}:
        with path.open("r", encoding="utf-8", errors="ignore", newline="") as handle:
            rows = csv.reader(handle)
            return "\n".join(", ".join(cell.strip() for cell in row if cell is not None) for row in rows)
    if ext in {".html", ".htm"}:
        raw_html = _read_text_file(path)
        text = re.sub(r"<script[\s\S]*?</script>", " ", raw_html, flags=re.IGNORECASE)
        text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        return html.unescape(re.sub(r"\s+", " ", text)).strip()
    if ext == ".pdf":
        return _read_pdf(path)
    if ext == ".docx":
        return _read_docx(path)
    if ext == ".pptx":
        return _read_pptx(path)
    if ext == ".xlsx":
        return _read_xlsx(path)
    if ext in {".doc", ".xls", ".ppt"}:
        raise ValueError(
            f"Legacy Office file format {ext} is not supported. Please upload {ext} content as PDF, DOCX, XLSX, or PPTX."
        )

    try:
        return _read_text_file(path)
    except Exception as exc:
        raise ValueError(f"Unsupported or unreadable file type: {ext or '<no extension>'}") from exc


def extract_rag_source(file_path: Any = None, knowledge_text: Any = None) -> Tuple[str, str]:
    file_value = str(file_path or "").strip()
    if file_value:
        return extract_text_from_path(file_value), file_value

    text_value = str(knowledge_text or "").strip()
    if text_value:
        return text_value, "inline_text"

    raise ValueError("Either file_path or knowledge_text is required")


def _build_chunks(knowledge_text: str, chunk_size: int, chunk_overlap: int) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    start = 0
    while start < len(knowledge_text):
        end = min(len(knowledge_text), start + chunk_size)
        content = knowledge_text[start:end].strip()
        if content:
            chunks.append(
                {
                    "chunk_index": len(chunks),
                    "content": content,
                    "start": start,
                    "end": end,
                }
            )
        if end >= len(knowledge_text):
            break
        start = max(end - chunk_overlap, start + 1)
    return chunks


def run_rag_search(
    query: Any,
    file_path: Any = None,
    knowledge_text: Any = None,
    chunk_size: Any = 500,
    chunk_overlap: Any = 50,
    top_k: Any = 3,
) -> Dict[str, Any]:
    try:
        query_text = str(query or "").strip()
        if not query_text:
            return {"error": "query is required"}

        source_text, source_name = extract_rag_source(file_path=file_path, knowledge_text=knowledge_text)
        source_text = re.sub(r"\s+", " ", source_text).strip()
        if not source_text:
            return {"error": "No readable text was extracted from the provided source"}

        chunk_size = max(100, int(chunk_size))
        chunk_overlap = max(0, int(chunk_overlap))
        top_k = max(1, int(top_k))
        if chunk_overlap >= chunk_size:
            chunk_overlap = max(0, chunk_size // 4)

        chunks = _build_chunks(source_text, chunk_size, chunk_overlap)
        query_terms = set(re.findall(r"\w+", query_text.lower()))

        def score_chunk(content: str) -> Tuple[int, int, int]:
            words = re.findall(r"\w+", content.lower())
            overlap_score = sum(1 for term in query_terms if term in words)
            density_score = len(set(words) & query_terms)
            return (overlap_score, density_score, -abs(len(content) - chunk_size))

        ranked = sorted(chunks, key=lambda chunk: score_chunk(chunk["content"]), reverse=True)
        matches = []
        best_score = 0
        best_density_score = 0
        for chunk in ranked:
            overlap_score, density_score, _ = score_chunk(chunk["content"])
            best_score = max(best_score, overlap_score)
            best_density_score = max(best_density_score, density_score)
            if overlap_score <= 0 and density_score <= 0:
                continue
            matches.append(
                {
                    **chunk,
                    "score": overlap_score,
                    "density_score": density_score,
                }
            )
            if len(matches) >= top_k:
                break

        return {
            "query": query_text,
            "knowledge_source": source_name,
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
            "top_k": top_k,
            "total_chunks": len(chunks),
            "has_relevant_match": bool(matches),
            "best_score": best_score,
            "best_density_score": best_density_score,
            "message": None if matches else "No relevant matches found in the provided knowledge source",
            "matches": matches,
        }
    except Exception as exc:
        return {"error": str(exc)}
