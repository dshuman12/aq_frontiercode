import re
from typing import Any, Dict, List, Optional

from .nlu import analyze_query, inspect_entities, inspect_intents


def _lines(value: Any) -> List[str]:
    return [line.strip() for line in str(value or "").splitlines() if line.strip()]


def detect_guardrail_hits(query: Any, guardrails: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    query_text = str(query or "").strip()
    lowered = query_text.lower()
    guardrails = guardrails if isinstance(guardrails, dict) else {}

    blocked_topics = _lines(guardrails.get("blockedTopicsText"))
    escalation_keywords = _lines(guardrails.get("escalationKeywordsText"))
    restricted_actions = _lines(guardrails.get("restrictedActionsText"))

    blocked_matches = [topic for topic in blocked_topics if topic.lower() in lowered]
    escalation_matches = [keyword for keyword in escalation_keywords if keyword.lower() in lowered]
    restricted_matches = [action for action in restricted_actions if action.lower() in lowered]

    return {
        "blocked_topics": blocked_matches,
        "escalation_keywords": escalation_matches,
        "restricted_actions": restricted_matches,
        "has_guardrail_hit": bool(blocked_matches or escalation_matches or restricted_matches),
    }


def evaluate_cases(cases: Any, ai_config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    ai_config = ai_config if isinstance(ai_config, dict) else {}
    normalized_cases = [case for case in (cases or []) if isinstance(case, dict) and str(case.get("query") or "").strip()]
    results: List[Dict[str, Any]] = []
    suggestions: List[Dict[str, Any]] = []

    for index, case in enumerate(normalized_cases):
        query = str(case.get("query") or "").strip()
        expected_intent = str(case.get("expectedIntent") or "").strip()
        expected_route = str(case.get("expectedRouteTarget") or "").strip()
        expected_entities = [str(value).strip() for value in (case.get("expectedEntities") or []) if str(value).strip()]

        analysis = analyze_query(query, ai_config)
        best_intent = analysis.get("intent_result", {}).get("best_intent") or {}
        found_entities = analysis.get("entity_result", {}).get("entities") or []
        found_entity_names = [item.get("name") for item in found_entities if item.get("name")]
        guardrail_hits = detect_guardrail_hits(query, ai_config.get("guardrails"))

        failures: List[str] = []
        if expected_intent and best_intent.get("name") != expected_intent:
            failures.append(f"Expected intent '{expected_intent}' but got '{best_intent.get('name') or 'none'}'.")
        if expected_route and analysis.get("route_target") != expected_route:
            failures.append(f"Expected route '{expected_route}' but got '{analysis.get('route_target') or 'none'}'.")
        for entity_name in expected_entities:
            if entity_name not in found_entity_names:
                failures.append(f"Missing expected entity '{entity_name}'.")

        passed = len(failures) == 0
        if not passed:
            if expected_intent and not best_intent.get("name"):
                suggestions.append(
                    {
                        "type": "intent_training",
                        "source_query": query,
                        "target": expected_intent,
                        "message": f"Add '{query}' as a training utterance for intent '{expected_intent}'.",
                    }
                )
            for entity_name in expected_entities:
                if entity_name not in found_entity_names:
                    suggestions.append(
                        {
                            "type": "entity_training",
                            "source_query": query,
                            "target": entity_name,
                            "message": f"Improve entity '{entity_name}' so it can be extracted from '{query}'.",
                        }
                    )

        results.append(
            {
                "case_index": index,
                "name": case.get("name") or f"Case {index + 1}",
                "query": query,
                "expected_intent": expected_intent or None,
                "expected_route_target": expected_route or None,
                "expected_entities": expected_entities,
                "analysis": analysis,
                "guardrail_hits": guardrail_hits,
                "passed": passed,
                "failures": failures,
            }
        )

    total = len(results)
    passed_count = sum(1 for item in results if item.get("passed"))
    failed_count = total - passed_count
    return {
        "summary": {
            "total_cases": total,
            "passed_cases": passed_count,
            "failed_cases": failed_count,
            "pass_rate": round((passed_count / total), 4) if total else 0.0,
        },
        "results": results,
        "suggestions": suggestions,
    }


def _looks_like_business_entity_query(query: str) -> bool:
    return bool(
        re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", query)
        or re.search(r"\b\d{4,}\b", query)
        or re.search(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", query)
    )


def generate_training_suggestions(
    recent_queries: Any,
    ai_config: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    ai_config = ai_config if isinstance(ai_config, dict) else {}
    normalized_queries = [
        str(query or "").strip()
        for query in (recent_queries or [])
        if str(query or "").strip()
    ]
    deduped_queries: List[str] = []
    seen_queries = set()
    for query in normalized_queries:
        lowered = query.lower()
        if lowered in seen_queries:
            continue
        seen_queries.add(lowered)
        deduped_queries.append(query)

    intents = ai_config.get("intents") or []
    entities = ai_config.get("entities") or []
    guardrails = ai_config.get("guardrails") or {}
    evaluation_cases = [
        case
        for case in (ai_config.get("evaluationCases") or [])
        if isinstance(case, dict) and str(case.get("query") or "").strip()
    ]
    evaluation_runs = [
        run for run in (ai_config.get("evaluationRuns") or []) if isinstance(run, dict)
    ]
    latest_run = evaluation_runs[0] if evaluation_runs else {}
    latest_summary = latest_run.get("summary") if isinstance(latest_run, dict) else {}

    suggestions: List[Dict[str, Any]] = []
    seen_suggestions = set()

    def push_suggestion(item: Dict[str, Any]) -> None:
        message = str(item.get("message") or "").strip()
        suggestion_type = str(item.get("type") or "suggestion").strip()
        target = str(item.get("target") or "").strip()
        key = f"{suggestion_type}:{target}:{message}"
        if not message or key in seen_suggestions:
            return
        seen_suggestions.add(key)
        suggestions.append(item)

    if not evaluation_cases:
        push_suggestion(
            {
                "type": "evaluation_gap",
                "target": "evaluationCases",
                "message": "Create an evaluation suite before publishing so prompt, knowledge, and routing changes can be validated consistently.",
            }
        )

    if latest_summary:
        total_cases = int(latest_summary.get("total_cases") or 0)
        failed_cases = int(latest_summary.get("failed_cases") or 0)
        if total_cases > 0 and failed_cases > 0:
            push_suggestion(
                {
                    "type": "evaluation_gap",
                    "target": "latest_run",
                    "message": f"The latest evaluation run still has {failed_cases} failing case(s). Fix those before the next publish.",
                }
            )

    if ai_config.get("enableRag") and not (ai_config.get("knowledge_bindings") or []):
        push_suggestion(
            {
                "type": "knowledge_gap",
                "target": "knowledge_bindings",
                "message": "RAG is enabled but no knowledge collections are bound. Attach at least one collection before relying on grounded answers.",
            }
        )

    if not str(ai_config.get("releaseNotes") or "").strip():
        push_suggestion(
            {
                "type": "release_governance",
                "target": "releaseNotes",
                "message": "Add release notes so business users can understand what changed before the next governed publish.",
            }
        )

    for warning in (inspect_intents(intents).get("warnings") or []):
        push_suggestion(
            {
                "type": "intent_quality",
                "target": warning.get("intent") or "intent_catalog",
                "message": warning.get("message") or "Review intent configuration quality.",
            }
        )

    for warning in (inspect_entities(entities).get("warnings") or []):
        push_suggestion(
            {
                "type": "entity_quality",
                "target": warning.get("entity") or "entity_catalog",
                "message": warning.get("message") or "Review entity configuration quality.",
            }
        )

    unmatched_count = 0
    entity_gap_count = 0
    guardrail_count = 0
    for query in deduped_queries[:30]:
        analysis = analyze_query(query, ai_config)
        best_intent = analysis.get("intent_result", {}).get("best_intent") or {}
        found_entities = analysis.get("entity_result", {}).get("entities") or []
        guardrail_hits = detect_guardrail_hits(query, guardrails)

        if not best_intent.get("name"):
            unmatched_count += 1
            push_suggestion(
                {
                    "type": "intent_discovery",
                    "target": "unmatched_queries",
                    "source_query": query,
                    "message": f'Review unmatched user query "{query}" and either map it to an existing intent or create a new one.',
                }
            )

        if _looks_like_business_entity_query(query) and not found_entities:
            entity_gap_count += 1
            push_suggestion(
                {
                    "type": "entity_discovery",
                    "target": "entity_catalog",
                    "source_query": query,
                    "message": f'Query "{query}" looks like it contains a business field, but no entity was extracted. Add or refine entity coverage.',
                }
            )

        if guardrail_hits.get("has_guardrail_hit"):
            guardrail_count += 1
            hit_labels = [
                *guardrail_hits.get("blocked_topics", []),
                *guardrail_hits.get("escalation_keywords", []),
                *guardrail_hits.get("restricted_actions", []),
            ]
            push_suggestion(
                {
                    "type": "guardrail_tuning",
                    "target": "guardrails",
                    "source_query": query,
                    "message": f'User query "{query}" triggered guardrails ({", ".join(hit_labels) or "policy hit"}). Review whether the current response policy and escalation path are correct.',
                }
            )

    return {
        "summary": {
            "recent_queries_analyzed": len(deduped_queries[:30]),
            "suggestion_count": len(suggestions),
            "unmatched_query_count": unmatched_count,
            "entity_gap_count": entity_gap_count,
            "guardrail_hit_count": guardrail_count,
        },
        "suggestions": suggestions[:30],
    }
