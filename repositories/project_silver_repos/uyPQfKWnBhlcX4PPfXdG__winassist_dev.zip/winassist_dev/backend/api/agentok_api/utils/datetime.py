from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


IST_TIMEZONE_NAME = "Asia/Kolkata"


def _load_ist_timezone():
    try:
        return ZoneInfo(IST_TIMEZONE_NAME)
    except ZoneInfoNotFoundError:
        # Windows/Python environments may not have the tz database installed.
        # IST is a fixed UTC+05:30 offset with no DST, so this fallback is safe.
        return timezone(timedelta(hours=5, minutes=30), name=IST_TIMEZONE_NAME)


IST_TIMEZONE = _load_ist_timezone()


def now_ist() -> datetime:
    return datetime.now(IST_TIMEZONE)


def now_ist_naive() -> datetime:
    return now_ist().replace(tzinfo=None)


def today_ist() -> date:
    return now_ist().date()


def to_ist_datetime(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=IST_TIMEZONE)
    return value.astimezone(IST_TIMEZONE)


def serialize_datetime_for_api(value: datetime | None) -> str | None:
    dt = to_ist_datetime(value)
    return dt.isoformat() if dt else None
