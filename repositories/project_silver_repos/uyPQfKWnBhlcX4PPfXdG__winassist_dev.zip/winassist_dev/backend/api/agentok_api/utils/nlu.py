import re
from typing import Any, Dict, List, Optional


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_@.-]+", str(text or "").lower())


def _normalize_lines(value: Any) -> List[str]:
    return [line.strip() for line in str(value or "").splitlines() if line.strip()]


def _normalize_language_tag(value: Any) -> str:
    text = str(value or "").strip().lower()
    if not text:
        return ""
    aliases = {
        "en": "english",
        "eng": "english",
        "hi": "hindi",
        "es": "spanish",
        "fr": "french",
        "de": "german",
    }
    return aliases.get(text, text)


def detect_query_language(query: Any, supported_languages: Any = None, default_language: Any = None) -> str:
    text = str(query or "").strip()
    if not text:
        return _normalize_language_tag(default_language) or "english"
    lowered = text.lower()
    supported = [_normalize_language_tag(value) for value in (supported_languages or []) if _normalize_language_tag(value)]

    if re.search(r"[\u0900-\u097F]", text):
        detected = "hindi"
    elif re.search(r"[áéíóúñ¿¡]", lowered) or any(
        token in lowered.split() for token in ("hola", "pedido", "ayuda", "gracias")
    ):
        detected = "spanish"
    elif any(token in lowered.split() for token in ("bonjour", "merci", "commande")):
        detected = "french"
    elif any(token in lowered.split() for token in ("hallo", "bestellung", "hilfe")):
        detected = "german"
    else:
        detected = _normalize_language_tag(default_language) or "english"

    return detected if not supported or detected in supported else (_normalize_language_tag(default_language) or supported[0] or "english")


def _filter_assets_by_language(items: Any, language: Any) -> List[Dict[str, Any]]:
    requested = _normalize_language_tag(language)
    filtered: List[Dict[str, Any]] = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        item_language = _normalize_language_tag(item.get("language") or item.get("locale"))
        if not item_language or item_language in {"all", "any"}:
            filtered.append(item)
            continue
        if not requested:
            filtered.append(item)
            continue
        if item_language == requested or item_language.startswith(requested) or requested.startswith(item_language):
            filtered.append(item)
    return filtered


def _normalize_entity_value(value: Any, normalize_mode: Any) -> str:
    text = str(value or "").strip()
    mode = str(normalize_mode or "trim").strip().lower()
    if mode == "lowercase":
        return text.lower()
    if mode == "uppercase":
        return text.upper()
    if mode == "digits_only":
        return re.sub(r"\D+", "", text)
    return text


def inspect_intents(intents: Any) -> Dict[str, Any]:
    warnings: List[Dict[str, Any]] = []
    normalized_intents = []
    for intent in intents or []:
        if not isinstance(intent, dict):
            continue
        name = str(intent.get("name") or "").strip()
        utterances = _normalize_lines(intent.get("utterancesText"))
        if not name:
            continue
        normalized_intents.append(
            {
                "name": name,
                "description": intent.get("description") or "",
                "utterances": utterances,
            }
        )

    for index, left in enumerate(normalized_intents):
        if not left["utterances"]:
            warnings.append(
                {
                    "type": "missing_utterances",
                    "intent": left["name"],
                    "message": f"Intent '{left['name']}' has no training utterances.",
                }
            )
        left_terms = set()
        for utterance in left["utterances"]:
            left_terms.update(_tokenize(utterance))

        for right in normalized_intents[index + 1:]:
            right_terms = set()
            for utterance in right["utterances"]:
                right_terms.update(_tokenize(utterance))
            if not left_terms or not right_terms:
                continue
            overlap = left_terms & right_terms
            union = left_terms | right_terms
            similarity = len(overlap) / max(1, len(union))
            if similarity >= 0.45:
                warnings.append(
                    {
                        "type": "overlap_warning",
                        "intent": left["name"],
                        "related_intent": right["name"],
                        "similarity": round(similarity, 4),
                        "shared_terms": sorted(list(overlap))[:12],
                        "message": f"Intent '{left['name']}' overlaps with '{right['name']}'.",
                    }
                )

    return {
        "intent_count": len(normalized_intents),
        "warnings": warnings,
    }


def inspect_entities(entities: Any) -> Dict[str, Any]:
    warnings: List[Dict[str, Any]] = []
    normalized_entities = []
    for entity in entities or []:
        if not isinstance(entity, dict):
            continue
        name = str(entity.get("name") or "").strip()
        entity_type = str(entity.get("entityType") or "text").strip().lower()
        pattern = str(entity.get("pattern") or "").strip()
        if not name:
            continue
        normalized_entities.append({"name": name, "entity_type": entity_type, "pattern": pattern})
        if entity_type == "regex" and not pattern:
            warnings.append(
                {
                    "type": "missing_pattern",
                    "entity": name,
                    "message": f"Regex entity '{name}' has no regex pattern.",
                }
            )
        if pattern:
            try:
                re.compile(pattern)
            except re.error as exc:
                warnings.append(
                    {
                        "type": "invalid_pattern",
                        "entity": name,
                        "message": f"Entity '{name}' has an invalid regex pattern.",
                        "detail": str(exc),
                    }
                )

    duplicate_names = set()
    seen_names = set()
    for entity in normalized_entities:
        if entity["name"].lower() in seen_names:
            duplicate_names.add(entity["name"])
        seen_names.add(entity["name"].lower())
    for name in duplicate_names:
        warnings.append(
            {
                "type": "duplicate_name",
                "entity": name,
                "message": f"Entity '{name}' is defined more than once.",
            }
        )

    return {
        "entity_count": len(normalized_entities),
        "warnings": warnings,
    }


def classify_intent(query: Any, intents: Any, default_threshold: float = 0.35) -> Dict[str, Any]:
    query_text = str(query or "").strip()
    if not query_text:
      return {"query": "", "best_intent": None, "candidates": []}

    query_terms = set(_tokenize(query_text))
    candidates: List[Dict[str, Any]] = []

    for intent in intents or []:
        if not isinstance(intent, dict):
            continue
        name = str(intent.get("name") or "").strip()
        if not name:
            continue
        threshold = float(intent.get("confidenceThreshold") or default_threshold)
        utterances = _normalize_lines(intent.get("utterancesText"))
        if not utterances:
            candidates.append(
                {
                    "name": name,
                    "description": intent.get("description") or "",
                    "confidence": 0.0,
                    "matched_utterance": None,
                    "passed_threshold": False,
                    "threshold": threshold,
                    "route_target": intent.get("routeTarget") or "",
                }
            )
            continue

        best_confidence = 0.0
        best_utterance: Optional[str] = None
        for utterance in utterances:
            utterance_terms = set(_tokenize(utterance))
            if not utterance_terms:
                continue
            overlap = len(query_terms & utterance_terms)
            if overlap == 0:
                continue
            precision = overlap / max(1, len(query_terms))
            recall = overlap / max(1, len(utterance_terms))
            confidence = round((precision * 0.55) + (recall * 0.45), 4)
            if confidence > best_confidence:
                best_confidence = confidence
                best_utterance = utterance

        candidates.append(
            {
                "name": name,
                "description": intent.get("description") or "",
                "confidence": best_confidence,
                "matched_utterance": best_utterance,
                "passed_threshold": best_confidence >= threshold,
                "threshold": threshold,
                "route_target": intent.get("routeTarget") or "",
            }
        )

    candidates.sort(key=lambda item: item.get("confidence", 0), reverse=True)
    best_intent = candidates[0] if candidates else None
    if best_intent and not best_intent.get("passed_threshold"):
        best_intent = None
    return {
        "query": query_text,
        "best_intent": best_intent,
        "candidates": candidates[:8],
    }


def extract_entities(query: Any, entities: Any) -> Dict[str, Any]:
    query_text = str(query or "").strip()
    results: List[Dict[str, Any]] = []
    if not query_text:
        return {"query": "", "entities": results}

    email_match = re.search(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", query_text, re.IGNORECASE)
    phone_match = re.search(r"(?<!\d)(?:\+?\d[\d\s-]{6,}\d)(?!\d)", query_text)
    number_matches = re.findall(r"(?<!\w)(\d+(?:\.\d+)?)(?!\w)", query_text)
    date_match = re.search(
        r"\b(\d{4}-\d{2}-\d{2}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?)\b",
        query_text,
        re.IGNORECASE,
    )

    for entity in entities or []:
        if not isinstance(entity, dict):
            continue
        name = str(entity.get("name") or "").strip()
        if not name:
            continue
        entity_type = str(entity.get("entityType") or "text").strip().lower()
        examples = _normalize_lines(entity.get("examplesText"))
        pattern = str(entity.get("pattern") or "").strip()
        normalize_mode = str(entity.get("normalizeMode") or "trim").strip()
        value = None
        method = entity_type
        confidence = 0.0

        if entity_type == "email" and email_match:
            value = email_match.group(0)
            confidence = 0.98
        elif entity_type == "phone" and phone_match:
            value = phone_match.group(0).strip()
            confidence = 0.96
        elif entity_type == "date" and date_match:
            value = date_match.group(1)
            confidence = 0.92
        elif entity_type == "number" and number_matches:
            value = number_matches[0]
            confidence = 0.9
        elif entity_type == "regex" and pattern:
            try:
                regex_match = re.search(pattern, query_text, re.IGNORECASE)
            except re.error:
                regex_match = None
            if regex_match:
                value = regex_match.group(1) if regex_match.groups() else regex_match.group(0)
                confidence = 0.95
        else:
            for example in examples:
                if example.lower() in query_text.lower():
                    value = example
                    confidence = 0.7
                    method = "example_match"
                    break

        if value is not None:
            normalized_value = _normalize_entity_value(value, normalize_mode)
            validation_passed = True
            validation_error = None
            if pattern:
                try:
                    validation_passed = re.search(pattern, str(value), re.IGNORECASE) is not None
                    if not validation_passed:
                        validation_error = "Value does not match configured regex pattern"
                except re.error as exc:
                    validation_passed = False
                    validation_error = f"Invalid regex pattern: {exc}"
            results.append(
                {
                    "name": name,
                    "description": entity.get("description") or "",
                    "entity_type": entity_type,
                    "value": value,
                    "normalized_value": normalized_value,
                    "normalize_mode": normalize_mode,
                    "confidence": confidence,
                    "method": method,
                    "validation_passed": validation_passed,
                    "validation_error": validation_error,
                }
            )

    return {"query": query_text, "entities": results}


def analyze_query(query: Any, ai_config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    config = ai_config if isinstance(ai_config, dict) else {}
    supported_languages = _normalize_lines(config.get("supportedLanguagesText")) or [config.get("defaultLanguage")]
    detected_language = detect_query_language(
        query,
        supported_languages=supported_languages,
        default_language=config.get("queryLanguageHint") or config.get("defaultLanguage"),
    )
    intents = _filter_assets_by_language(config.get("intents") or [], detected_language)
    entities = _filter_assets_by_language(config.get("entities") or [], detected_language)
    threshold = float(config.get("defaultIntentThreshold") or 0.35)
    intent_result = classify_intent(query, intents, default_threshold=threshold)
    entity_result = extract_entities(query, entities)
    intent_insights = inspect_intents(config.get("intents") or [])
    entity_insights = inspect_entities(config.get("entities") or [])
    best_intent = intent_result.get("best_intent")
    return {
        "query": str(query or "").strip(),
        "detected_language": detected_language,
        "intent_result": intent_result,
        "entity_result": entity_result,
        "route_target": best_intent.get("route_target") if best_intent else None,
        "insights": {
            "intent_warnings": intent_insights.get("warnings", []),
            "entity_warnings": entity_insights.get("warnings", []),
        },
    }
