import json
from typing import Any, Dict, List, Literal, Optional
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, field_serializer, field_validator, EmailStr
from .utils.datetime import serialize_datetime_for_api

Node = Dict[str, Any]
Edge = Dict[str, Any]


class AgentMetadata(BaseModel):
    name: str
    description: str
    type: str
    label: str
    class_name: str



class Flow(BaseModel):
    nodes: List[Node]
    edges: List[Edge]
    viewport: Optional[Dict[str, Any]] = None  # Add viewport as optional

class ToolAssign(BaseModel):
    agent: str
    scene: str


class ToolVariable(BaseModel):
    name: str
    description: Optional[str] = None
    value: Any
    default: Optional[Any] = None


class Tool(BaseModel):
    id: int
    uuid: Optional[str] = None
    name: str
    description: Optional[str] = None
    variables: Optional[List[ToolVariable]] = []
    code: Optional[str] = None
    user_id: Optional[str] = None
    logo_url: Optional[str] = None
    is_public: Optional[bool] = False
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    @field_validator('user_id', 'uuid', mode='before')
    @classmethod
    def convert_str_fields(cls, v):
        if v is None:
            return None
        return str(v) if not isinstance(v, str) else v
    
    @field_validator('created_at', 'updated_at', mode='before')
    @classmethod
    def convert_datetime(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            try:
                return datetime.fromisoformat(v.replace('Z', '+00:00'))
            except:
                return v
        return v
    
    # Serialize datetime to ISO format string for JSON response
    @field_serializer('created_at', 'updated_at')
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        if dt is None:
            return None
        return serialize_datetime_for_api(dt)


class ToolCode(BaseModel):
    code: str


class ToolCreate(BaseModel):
    name: str
    description: Optional[str] = None
    variables: List[ToolVariable]
    code: Optional[str] = None
    is_public: Optional[bool] = False


class UserBase(BaseModel):
    email: EmailStr


class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=72, description="Password must be between 8 and 72 characters")
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    user_name: Optional[str] = Field(default=None, max_length=80)
    company_name: Optional[str] = Field(default=None, max_length=120)
    mobile_number: Optional[str] = None

    @field_validator('password')
    @classmethod
    def validate_password_length(cls, v: str) -> str:
        """Validate password doesn't exceed bcrypt's 72-byte limit"""
        if len(v.encode('utf-8')) > 72:
            raise ValueError("Password cannot exceed 72 bytes. Please use a shorter password.")
        return v


class UserLogin(UserBase):
    password: str


class ForgotPasswordRequest(UserBase):
    """Request body for forgot-password (email only)."""


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., min_length=1, description="Reset token from forgot-password")
    new_password: str = Field(..., min_length=8, max_length=72, description="New password")

    @field_validator('new_password')
    @classmethod
    def validate_password_length(cls, v: str) -> str:
        if len(v.encode('utf-8')) > 72:
            raise ValueError("Password cannot exceed 72 bytes.")
        return v


class UserProfileUpdate(BaseModel):
    first_name: Optional[str] = Field(default=None, max_length=100)
    last_name: Optional[str] = Field(default=None, max_length=100)
    user_name: Optional[str] = Field(default=None, max_length=80)
    company_name: Optional[str] = Field(default=None, max_length=120)
    mobile_number: Optional[str] = Field(default=None, max_length=32)


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, description="Current account password")
    new_password: str = Field(..., min_length=8, max_length=72, description="New password")

    @field_validator('new_password')
    @classmethod
    def validate_password_length(cls, v: str) -> str:
        if len(v.encode('utf-8')) > 72:
            raise ValueError("Password cannot exceed 72 bytes.")
        return v


class User(UserBase):
    id: UUID
    created_at: datetime
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    user_name: Optional[str] = None
    company_name: Optional[str] = None
    mobile_number: Optional[str] = None

    class Config:
        from_attributes = True

    @field_serializer('created_at')
    def serialize_created_at(self, dt: datetime, _info) -> str:
        return serialize_datetime_for_api(dt)

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    user_id: Optional[UUID] = None
    email: Optional[str] = None


class AuthResponse(BaseModel):
    user: User
    token: str


class WorkspaceBase(BaseModel):
    name: str
    slug: Optional[str] = None


class WorkspaceCreate(WorkspaceBase):
    pass


class WorkspaceUpdate(BaseModel):
    """Body for updating workspace (name). Only owner can update."""
    name: Optional[str] = None
    slug: Optional[str] = None


class Workspace(BaseModel):
    id: UUID
    owner_id: UUID
    name: str
    slug: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

    @field_serializer('created_at', 'updated_at')
    def serialize_dt(self, dt: datetime, _info) -> str:
        return serialize_datetime_for_api(dt)


class WorkspaceMember(BaseModel):
    id: UUID
    workspace_id: UUID
    user_id: UUID
    role: str
    created_at: datetime

    class Config:
        from_attributes = True

    @field_serializer('created_at')
    def serialize_created_at(self, dt: datetime, _info) -> str:
        return serialize_datetime_for_api(dt)


class WorkspaceMemberWithEmail(WorkspaceMember):
    """Member with email from persons (for list display)."""
    email: Optional[str] = None
    is_workspace_owner: bool = False
    is_active: Optional[bool] = True


class WorkspaceMemberRoleUpdate(BaseModel):
    """Body for updating a member's role. Only owner/admin can update."""
    role: str  # owner, admin, member, viewer


class WorkspaceMemberActiveUpdate(BaseModel):
    """Body for activating/deactivating a member's account. Owner/admin only."""
    is_active: bool


class WorkspaceWithRole(BaseModel):
    id: UUID
    name: str
    slug: Optional[str] = None
    role: str
    owner_id: UUID
    owner_email: Optional[str] = None  # Email of workspace owner; shown when user is member of another's workspace


class WorkspaceInviteCreate(BaseModel):
    email: EmailStr
    role: str
    expires_in_days: Optional[int] = 7


class WorkspaceInvite(BaseModel):
    id: UUID
    workspace_id: UUID
    email: EmailStr
    role: str
    token: UUID
    expires_at: Optional[datetime] = None
    accepted_at: Optional[datetime] = None
    created_by: UUID
    created_at: datetime

    class Config:
        from_attributes = True

    @field_serializer('expires_at', 'accepted_at', 'created_at')
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WorkspaceInviteAccept(BaseModel):
    token: str  # UUID string; normalized on accept to tolerate link corruption (e.g. extra char)


class WorkspaceInviteWithLink(WorkspaceInvite):
    """Invite response when created; includes link to accept (if FRONTEND_URL set)."""
    invite_link: Optional[str] = None
    email_sent: Optional[bool] = None
    email_error: Optional[str] = None
    reused: Optional[bool] = False


class Project(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    flow: Flow
    settings: Optional[Dict[str, Any]] = None
    user_id: Optional[UUID] = None
    created_at: str
    updated_at: str
    
    # Add validator to handle datetime conversion if needed
    @field_validator('created_at', 'updated_at', mode='before')
    @classmethod
    def validate_datetime(cls, v):
        if isinstance(v, datetime):
            return serialize_datetime_for_api(v)
        return v
    
    class Config:
        from_attributes = True


class MessageCreate(BaseModel):
    type: Literal["user", "assistant", "summary"]
    content: str
    metadata: Optional[Dict[str, Any]] = None
    sender: Optional[str] = None
    receiver: Optional[str] = None
    user_id: Optional[UUID] = None 


class Message(MessageCreate):
    id: int
    chat_id: int
    user_id: Optional[UUID] = None
    created_at: Optional[str] = None
    
    @field_validator('created_at', mode='before')
    @classmethod
    def convert_datetime(cls, v):
        if isinstance(v, datetime):
            return serialize_datetime_for_api(v)
        return v


class ChatCreateBody(BaseModel):
    """Request body for creating a chat. user_id is set by the server from auth (JWT or bot API key)."""
    name: str
    from_type: Literal["project", "template"]
    from_project: Optional[UUID] = None
    from_template: Optional[int] = None
    session_id: Optional[str] = None  # Widget-generated session for funnel analytics


class ChatCreate(BaseModel):
    name: str
    from_type: Literal["project", "template"]
    from_project: Optional[UUID] = None
    from_template: Optional[int] = None
    user_id: Optional[UUID] = None
    session_id: Optional[str] = None


class Chat(ChatCreate):
    id: int
    status: Optional[str] = None
    created_at: str
    updated_at: str
    config: Optional[Dict[str, Any]] = None
    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def convert_datetime(cls, v):
        if isinstance(v, datetime):
            return serialize_datetime_for_api(v)
        return v

class LogCreate(BaseModel):
    message: str
    level: Optional[Literal["info", "warning", "error"]] = None
    metadata: Optional[Dict[str, Any]] = None
    chat_id: int


class Log(LogCreate):
    id: int
    created_at: str
    updated_at: str

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def convert_datetime(cls, v):
        if isinstance(v, datetime):
            return serialize_datetime_for_api(v)
        return v


class ApiKeyCreate(BaseModel):
    name: str
    key: Optional[str] = None


class ApiKey(BaseModel):
    # BIGSERIAL from database (integer)
    id: int
    name: Optional[str] = None
    key: str
    # UUID but can be None, serialize as string
    user_id: Optional[UUID] = None
    # Datetime from database
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    # Serialize datetime to ISO format string for JSON response
    @field_serializer('created_at', 'updated_at')
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)
    
    # Serialize UUID to string for JSON response
    @field_serializer('user_id')
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    class Config:
        from_attributes = True  # Allows Pydantic to work with ORM/dict objects


class ConnectorCapabilityFlags(BaseModel):
    inbound_webhook: bool = False
    send_text: bool = False
    send_media: bool = False
    send_template: bool = False
    send_flow: bool = False
    flow_runtime: bool = False
    analytics: bool = False


class ConnectorDefinition(BaseModel):
    connector_key: str
    channel_key: str
    provider_key: str
    display_name: str
    description: Optional[str] = None
    setup_route: Optional[str] = None
    status_route: Optional[str] = None
    icon_url: Optional[str] = None
    capabilities: ConnectorCapabilityFlags = Field(default_factory=ConnectorCapabilityFlags)


class ConnectorConnectionSummary(BaseModel):
    id: UUID
    connector_key: str
    channel_key: str
    provider_key: str
    workspace_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    bot_project_id: Optional[UUID] = None
    display_name: str
    external_reference: Optional[str] = None
    connection_status: str = "unknown"
    health_status: Optional[str] = None
    setup_route: Optional[str] = None
    status_route: Optional[str] = None
    access_token_masked: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    capabilities: ConnectorCapabilityFlags = Field(default_factory=ConnectorCapabilityFlags)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @field_serializer("id", "workspace_id", "project_id", "bot_project_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("created_at", "updated_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class ConnectorSendTextRequest(BaseModel):
    to: str = Field(..., min_length=3, max_length=64)
    text: str = Field(..., min_length=1, max_length=4096)
    preview_url: bool = False


class WhatsAppConnectionCreate(BaseModel):
    name: Optional[str] = Field(default=None, max_length=255)
    workspace_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    bot_project_id: Optional[UUID] = None
    provider: Literal["meta_cloud"] = "meta_cloud"
    graph_version: Optional[str] = Field(default=None, max_length=32)
    meta_business_account_id: Optional[str] = Field(default=None, max_length=255)
    waba_id: str = Field(..., min_length=1, max_length=255)
    phone_number_id: str = Field(..., min_length=1, max_length=255)
    business_phone_number: Optional[str] = Field(default=None, max_length=64)
    display_phone_number: Optional[str] = Field(default=None, max_length=64)
    access_token: str = Field(..., min_length=10)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WhatsAppConnectionUpdate(BaseModel):
    name: Optional[str] = Field(default=None, max_length=255)
    project_id: Optional[UUID] = None
    bot_project_id: Optional[UUID] = None
    graph_version: Optional[str] = Field(default=None, max_length=32)
    meta_business_account_id: Optional[str] = Field(default=None, max_length=255)
    waba_id: Optional[str] = Field(default=None, min_length=1, max_length=255)
    phone_number_id: Optional[str] = Field(default=None, min_length=1, max_length=255)
    business_phone_number: Optional[str] = Field(default=None, max_length=64)
    display_phone_number: Optional[str] = Field(default=None, max_length=64)
    access_token: Optional[str] = Field(default=None, min_length=10)
    metadata: Optional[Dict[str, Any]] = None


class WhatsAppTestMessageRequest(BaseModel):
    to: str = Field(..., min_length=5, max_length=32)
    message: str = Field(default="Hello from WinAssist", min_length=1, max_length=4096)


class WhatsAppTextMessageRequest(BaseModel):
    connection_id: UUID
    to: str = Field(..., min_length=5, max_length=32)
    text: str = Field(..., min_length=1, max_length=4096)
    preview_url: bool = False


class WhatsAppTemplateMessageRequest(BaseModel):
    connection_id: UUID
    to: str = Field(..., min_length=5, max_length=32)
    template_name: str = Field(..., min_length=1, max_length=255)
    language_code: str = Field(default="en_US", min_length=2, max_length=32)
    components: List[Dict[str, Any]] = Field(default_factory=list)


class WhatsAppMediaMessageRequest(BaseModel):
    connection_id: UUID
    to: str = Field(..., min_length=5, max_length=32)
    media_type: Literal["image", "document", "audio", "video", "sticker"]
    media_id: Optional[str] = Field(default=None, max_length=255)
    media_link: Optional[str] = Field(default=None, max_length=2048)
    caption: Optional[str] = Field(default=None, max_length=4096)
    filename: Optional[str] = Field(default=None, max_length=255)


class WhatsAppInteractiveMessageRequest(BaseModel):
    connection_id: UUID
    to: str = Field(..., min_length=5, max_length=32)
    interactive: Dict[str, Any] = Field(default_factory=dict)


class WhatsAppFlowMessageRequest(BaseModel):
    connection_id: UUID
    to: str = Field(..., min_length=5, max_length=32)
    flow_id: str = Field(..., min_length=1, max_length=255)
    flow_cta: str = Field(default="Open flow", min_length=1, max_length=255)
    flow_token: Optional[str] = Field(default=None, max_length=255)
    flow_action: Literal["navigate", "data_exchange"] = "navigate"
    flow_action_payload: Dict[str, Any] = Field(default_factory=dict)
    body_text: str = Field(..., min_length=1, max_length=1024)
    header_text: Optional[str] = Field(default=None, max_length=255)
    footer_text: Optional[str] = Field(default=None, max_length=255)


class WhatsAppFlowCreateRequest(BaseModel):
    connection_id: UUID
    name: str = Field(..., min_length=1, max_length=255)
    categories: List[str] = Field(default_factory=lambda: ["OTHER"])
    endpoint_uri: Optional[str] = Field(default=None, max_length=2048)
    clone_flow_id: Optional[str] = Field(default=None, max_length=255)
    flow_json: Optional[str] = None


class WhatsAppFlowUpdateRequest(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    categories: Optional[List[str]] = None
    endpoint_uri: Optional[str] = Field(default=None, max_length=2048)
    flow_json: Optional[str] = None


class WhatsAppSavedFlowSendRequest(BaseModel):
    to: str = Field(..., min_length=5, max_length=32)
    flow_cta: str = Field(default="Open flow", min_length=1, max_length=255)
    flow_token: Optional[str] = Field(default=None, max_length=255)
    flow_action: Literal["navigate", "data_exchange"] = "navigate"
    flow_action_payload: Dict[str, Any] = Field(default_factory=dict)
    body_text: str = Field(..., min_length=1, max_length=1024)
    header_text: Optional[str] = Field(default=None, max_length=255)
    footer_text: Optional[str] = Field(default=None, max_length=255)


class WhatsAppFlowPublicKeyRequest(BaseModel):
    regenerate: bool = False
    register_with_meta: bool = True


class WhatsAppFlowEndpointConfigRequest(BaseModel):
    endpoint_uri: Optional[str] = Field(default=None, max_length=2048)
    update_meta: bool = True


class WhatsAppFlowPublicKeyStatus(BaseModel):
    flow_id: UUID
    connection_id: UUID
    phone_number_id: str
    callback_url: Optional[str] = None
    public_key: Optional[str] = None
    public_key_fingerprint: Optional[str] = None
    key_generated_at: Optional[datetime] = None
    meta_signature_status: Optional[str] = None
    meta_public_key: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @field_serializer("flow_id", "connection_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("key_generated_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppFlowRuntimeEvent(BaseModel):
    id: int
    flow_id: UUID
    connection_id: Optional[UUID] = None
    event_type: str
    processed: bool = False
    payload: Dict[str, Any] = Field(default_factory=dict)
    headers: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime

    @field_serializer("flow_id", "connection_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("created_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppFlowRuntimeReplayResponse(BaseModel):
    flow_id: UUID
    event_id: int
    decrypted_payload: Dict[str, Any] = Field(default_factory=dict)
    response_payload: Dict[str, Any] = Field(default_factory=dict)
    encrypted_response: str
    replayed_at: datetime

    @field_serializer("flow_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("replayed_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppWebhookEvent(BaseModel):
    id: int
    connection_id: Optional[UUID] = None
    event_type: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    headers: Dict[str, Any] = Field(default_factory=dict)
    processed: bool = False
    created_at: datetime

    @field_serializer("connection_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("created_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppDashboardCountStat(BaseModel):
    label: str
    count: int


class WhatsAppDashboardDailyStat(BaseModel):
    date: str
    inbound: int = 0
    outbound: int = 0
    status: int = 0
    total: int = 0


class WhatsAppFlowActivityStat(BaseModel):
    saved_flow_id: Optional[UUID] = None
    meta_flow_id: Optional[str] = None
    flow_name: str
    status: Optional[str] = None
    send_count: int = 0
    last_sent_at: Optional[datetime] = None
    last_published_at: Optional[datetime] = None

    @field_serializer("saved_flow_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("last_sent_at", "last_published_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppChannelDashboard(BaseModel):
    connection_id: Optional[UUID] = None
    generated_at: datetime
    connection_health: Dict[str, int] = Field(default_factory=dict)
    message_totals: Dict[str, int] = Field(default_factory=dict)
    webhook_totals: Dict[str, int] = Field(default_factory=dict)
    daily_counts: List[WhatsAppDashboardDailyStat] = Field(default_factory=list)
    failure_reasons: List[WhatsAppDashboardCountStat] = Field(default_factory=list)
    template_statuses: List[WhatsAppDashboardCountStat] = Field(default_factory=list)
    rejected_templates: List[str] = Field(default_factory=list)
    flow_statuses: List[WhatsAppDashboardCountStat] = Field(default_factory=list)
    flow_activity: List[WhatsAppFlowActivityStat] = Field(default_factory=list)
    pending_retries: int = 0

    @field_serializer("connection_id")
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None

    @field_serializer("generated_at")
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)


class WhatsAppDiscoveryRequest(BaseModel):
    provider: Literal["meta_cloud"] = "meta_cloud"
    graph_version: Optional[str] = Field(default=None, max_length=32)
    meta_business_account_id: Optional[str] = Field(default=None, max_length=255)
    waba_id: Optional[str] = Field(default=None, max_length=255)
    access_token: str = Field(..., min_length=10)


class WhatsAppTemplateCreateRequest(BaseModel):
    connection_id: UUID
    name: str = Field(..., min_length=1, max_length=255)
    language: str = Field(default="en_US", min_length=2, max_length=32)
    category: str = Field(default="UTILITY", min_length=1, max_length=64)
    components: List[Dict[str, Any]] = Field(default_factory=list)
    submit_to_meta: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WhatsAppTemplateSendRequest(BaseModel):
    to: str = Field(..., min_length=5, max_length=32)
    language_code: Optional[str] = Field(default=None, min_length=2, max_length=32)
    components: List[Dict[str, Any]] = Field(default_factory=list)


class WhatsAppConnection(BaseModel):
    id: UUID
    workspace_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    bot_project_id: Optional[UUID] = None
    user_id: Optional[UUID] = None
    created_by: Optional[UUID] = None
    name: Optional[str] = None
    provider: str
    graph_version: str
    meta_business_account_id: Optional[str] = None
    waba_id: str
    phone_number_id: str
    business_phone_number: Optional[str] = None
    display_phone_number: Optional[str] = None
    connection_status: str
    webhook_status: str
    health_status: Optional[str] = None
    last_sync_status: Optional[str] = None
    subscribed_app_status: Optional[str] = None
    access_token_masked: Optional[str] = None
    last_validation_error: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    last_validated_at: Optional[datetime] = None
    last_synced_at: Optional[datetime] = None
    last_webhook_event_at: Optional[datetime] = None
    last_tested_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    @field_validator('metadata', mode='before')
    @classmethod
    def normalize_metadata(cls, v):
        if v is None:
            return {}
        if isinstance(v, dict):
            return v
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                return {}
        return {}

    @field_serializer(
        'created_at',
        'updated_at',
        'last_validated_at',
        'last_synced_at',
        'last_webhook_event_at',
        'last_tested_at',
    )
    def serialize_dt(self, dt: Optional[datetime], _info) -> Optional[str]:
        return serialize_datetime_for_api(dt)

    @field_serializer('id', 'workspace_id', 'project_id', 'bot_project_id', 'user_id', 'created_by')
    def serialize_uuid(self, val: Optional[UUID], _info) -> Optional[str]:
        return str(val) if val else None


class WhatsAppPhoneNumber(BaseModel):
    id: UUID
    connection_id: UUID
    phone_number_id: str
    display_phone_number: Optional[str] = None
    verified_name: Optional[str] = None
    quality_rating: Optional[str] = None
    code_verification_status: Optional[str] = None
    status: Optional[str] = None
    raw_data: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class WhatsAppTemplate(BaseModel):
    id: UUID
    connection_id: UUID
    meta_template_id: Optional[str] = None
    name: str
    language: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    components: Dict[str, Any] = Field(default_factory=dict)
    raw_data: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class WhatsAppFlow(BaseModel):
    id: UUID
    connection_id: UUID
    meta_flow_id: Optional[str] = None
    name: str
    status: Optional[str] = None
    categories: List[str] = Field(default_factory=list)
    raw_data: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime

    @field_validator('categories', mode='before')
    @classmethod
    def normalize_categories(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return [str(item) for item in v if str(item).strip()]
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return [str(item) for item in parsed if str(item).strip()]
            except Exception:
                stripped = v.strip()
                return [stripped] if stripped else []
        if isinstance(v, dict):
            return [str(key) for key, enabled in v.items() if enabled]
        return []

    @field_validator('raw_data', mode='before')
    @classmethod
    def normalize_raw_data(cls, v):
        if v is None:
            return {}
        if isinstance(v, dict):
            return v
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                return {}
        return {}


class WhatsAppMessage(BaseModel):
    id: UUID
    connection_id: Optional[UUID] = None
    direction: str
    wa_message_id: Optional[str] = None
    chat_id: Optional[int] = None
    project_id: Optional[UUID] = None
    from_number: Optional[str] = None
    to_number: Optional[str] = None
    message_type: Optional[str] = None
    status: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    response: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class WhatsAppConversationLink(BaseModel):
    id: UUID
    connection_id: UUID
    wa_user_phone_number: str
    chat_id: Optional[int] = None
    project_id: Optional[UUID] = None
    last_message_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime