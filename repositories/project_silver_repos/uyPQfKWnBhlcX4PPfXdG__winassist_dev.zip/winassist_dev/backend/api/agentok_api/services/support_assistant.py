import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List

from ..utils.rag_tool import run_rag_search


logger = logging.getLogger(__name__)
STOPWORDS = {
    "a",
    "about",
    "and",
    "are",
    "can",
    "do",
    "does",
    "for",
    "from",
    "give",
    "help",
    "how",
    "i",
    "in",
    "is",
    "it",
    "me",
    "my",
    "of",
    "on",
    "or",
    "please",
    "the",
    "to",
    "what",
    "when",
    "where",
    "why",
    "with",
}


def _resolve_docs_root() -> Path:
    current = Path(__file__).resolve()
    env_docs_root = os.environ.get("SUPPORT_ASSISTANT_DOCS_ROOT", "").strip()
    if env_docs_root:
        return Path(env_docs_root).expanduser()

    for parent in current.parents:
        candidate = parent / "docs" / "platform-assistant"
        if candidate.exists():
            return candidate

    # Fall back to likely project roots without assuming parent depth.
    fallback_roots = [
        current.parent,
        *list(current.parents),
        Path.cwd(),
    ]
    for root in fallback_roots:
        candidate = root / "docs" / "platform-assistant"
        if candidate.exists():
            return candidate

    # Common container deployment mount points.
    for candidate in (
        Path("/app/docs/platform-assistant"),
        Path("/winassist/docs/platform-assistant"),
    ):
        if candidate.exists():
            return candidate

    # Return a stable default path (non-existent is handled by caller).
    return current.parents[2] / "docs" / "platform-assistant" if len(current.parents) > 2 else current.parent / "docs" / "platform-assistant"


MERGED_FAQ_FILENAME = os.environ.get("SUPPORT_ASSISTANT_FAQ_FILE", "BOT_FAQ.md").strip() or "BOT_FAQ.md"


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9_]+", str(text or "").lower())


def _significant_tokens(text: str) -> List[str]:
    return [token for token in _tokenize(text) if token not in STOPWORDS and len(token) > 1]


def _knowledge_file_paths() -> List[Path]:
    docs_root = _resolve_docs_root()
    if not docs_root.exists():
        logger.warning("Support assistant docs root does not exist: %s", docs_root)
        return []
    files = sorted(docs_root.glob("*.md"))
    faq_file = docs_root / MERGED_FAQ_FILENAME
    if faq_file.exists():
        files = [faq_file, *[file for file in files if file != faq_file]]
    if not files:
        logger.warning("Support assistant docs root has no Markdown files: %s", docs_root)
    return files


def _read_markdown(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="ignore")


def _markdown_sections(path: Path) -> List[Dict[str, Any]]:
    text = _read_markdown(path)
    sections: List[Dict[str, Any]] = []
    current_title = path.stem.replace("_", " ").replace("-", " ").title()
    current_lines: List[str] = []

    for line in text.splitlines():
        heading_match = re.match(r"^(#{2,4})\s+(.+?)\s*$", line)
        if heading_match:
            if current_lines:
                sections.append(
                    {
                        "title": current_title,
                        "content": "\n".join(current_lines).strip(),
                        "chunk_index": len(sections),
                    }
                )
            current_title = heading_match.group(2).strip()
            current_lines = [line]
            continue
        current_lines.append(line)

    if current_lines:
        sections.append(
            {
                "title": current_title,
                "content": "\n".join(current_lines).strip(),
                "chunk_index": len(sections),
            }
        )
    return [section for section in sections if section.get("content")]


def _score_section(query_text: str, section: Dict[str, Any]) -> Dict[str, int]:
    query_terms = set(_significant_tokens(query_text))
    title = str(section.get("title") or "")
    content = str(section.get("content") or "")
    title_terms = set(_significant_tokens(title))
    content_terms = _significant_tokens(content)
    content_term_set = set(content_terms)
    query_phrase = re.sub(r"\s+", " ", query_text.lower()).strip()
    title_text = title.lower()
    content_text = content.lower()

    title_overlap = len(query_terms & title_terms)
    content_overlap = len(query_terms & content_term_set)
    content_frequency = sum(min(content_terms.count(term), 3) for term in query_terms)
    phrase_boost = 8 if query_phrase and query_phrase in content_text else 0
    title_phrase_boost = 12 if query_phrase and query_phrase in title_text else 0
    score = (title_overlap * 8) + (content_overlap * 3) + content_frequency + phrase_boost + title_phrase_boost
    return {
        "score": score,
        "density_score": title_overlap + content_overlap,
    }


def _search_markdown_sections(query_text: str, files: List[Path]) -> List[Dict[str, Any]]:
    matches: List[Dict[str, Any]] = []
    for path in files:
        if path.suffix.lower() != ".md":
            continue
        for section in _markdown_sections(path):
            section_score = _score_section(query_text, section)
            if section_score["score"] <= 0:
                continue
            matches.append(
                {
                    **section,
                    **section_score,
                    "path": path.relative_to(path.parents[1]).as_posix(),
                    "document_title": path.stem.replace("_", " ").replace("-", " ").title(),
                }
            )
    return sorted(
        matches,
        key=lambda item: (item.get("score", 0), item.get("density_score", 0)),
        reverse=True,
    )[:4]


def _detect_intent(query_tokens: List[str]) -> str:
    qset = set(query_tokens)
    if {"error", "issue", "problem", "failed", "bug", "troubleshoot"} & qset:
        return "troubleshooting"
    if {"how", "steps", "guide", "setup", "configure"} & qset:
        return "how_to"
    if {"use", "usecase", "scenario", "workflow"} & qset:
        return "use_case"
    return "feature_overview"


def _extract_actionable_lines(text: str, limit: int = 5) -> List[str]:
    lines = [line.strip() for line in str(text or "").splitlines()]
    candidates: List[str] = []
    ignored_labels = {
        "available analytics areas:",
        "backend:",
        "checklist:",
        "frontend:",
        "good guardrail behavior:",
        "important ai agent settings:",
        "purpose:",
        "recommended collection examples:",
        "recommended steps:",
        "supported account flows:",
        "supported source types:",
        "template actions:",
        "use channels when:",
        "use guardrails when:",
        "use it when:",
        "use templates when:",
        "whatsapp features:",
        "whatsapp setup steps:",
    }
    for line in lines:
        if not line:
            continue
        if line.lower() in ignored_labels or line.startswith("#"):
            continue
        if line.startswith(("- ", "* ")) or re.match(r"^\d+\.\s+", line):
            candidates.append(re.sub(r"^(\d+\.\s+|[-*]\s+)", "", line).strip())
        elif ":" in line and len(line) < 220:
            candidates.append(line.strip())
        if len(candidates) >= limit:
            break
    if not candidates:
        fallback_text = " ".join(line for line in lines if line and not line.startswith("#"))
        sentences = [
            sentence.strip()
            for sentence in re.split(r"(?<=[.!?])\s+", fallback_text)
            if sentence.strip()
        ]
        for sentence in sentences:
            cleaned = re.sub(r"\s+", " ", sentence).strip(" -")
            if cleaned:
                candidates.append(cleaned)
            if len(candidates) >= limit:
                break
    return candidates[:limit]


def answer_platform_question(query: str) -> Dict[str, Any]:
    query_text = str(query or "").strip()
    if not query_text:
        return {
            "answer": "Please share your platform question so I can guide you.",
            "intent": "feature_overview",
            "confidence": "low",
            "references": [],
            "highlights": [],
        }

    files = _knowledge_file_paths()
    if not files:
        return {
            "answer": "Support knowledge is not available yet. Please add documentation in docs/platform-assistant.",
            "intent": "feature_overview",
            "confidence": "low",
            "references": [],
            "highlights": [],
        }

    query_tokens = _tokenize(query_text)
    intent = _detect_intent(query_tokens)
    all_matches = _search_markdown_sections(query_text, files)
    if not all_matches:
        for path in files:
            retrieval = run_rag_search(
                query=query_text,
                file_path=str(path),
                chunk_size=900,
                chunk_overlap=120,
                top_k=3,
            )
            for match in retrieval.get("matches", []):
                all_matches.append(
                    {
                        **match,
                        "path": path.relative_to(path.parents[1]).as_posix(),
                        "title": path.stem.replace("_", " ").replace("-", " ").title(),
                        "document_title": path.stem.replace("_", " ").replace("-", " ").title(),
                    }
                )
        all_matches = sorted(
            all_matches,
            key=lambda item: (item.get("score", 0), item.get("density_score", 0)),
            reverse=True,
        )[:4]
    if not all_matches:
        return {
            "answer": "I could not retrieve relevant sections from the platform knowledge file. Please rephrase your question with module names like AI Agent, Chat Flow, Knowledge Base, Channels, or Publish Center.",
            "intent": intent,
            "confidence": "low",
            "references": [],
            "highlights": [],
        }

    highlights: List[str] = _extract_actionable_lines(all_matches[0].get("content"), limit=6)
    if len(highlights) < 4:
        for match in all_matches[1:]:
            highlights.extend(_extract_actionable_lines(match.get("content"), limit=2))
            if len(highlights) >= 6:
                break
    highlights = highlights[:6]

    references = [
        {
            "title": match.get("document_title") or match.get("title"),
            "section": match.get("title") or f"Chunk {match.get('chunk_index')}",
            "path": match.get("path"),
        }
        for match in all_matches
    ]

    if highlights:
        best_section = str(all_matches[0].get("title") or "the platform knowledge base")
        answer_lines = [
            f"Here is the best guidance from `{best_section}`:",
            *[f"- {line}" for line in highlights],
            "",
            "If you want, I can also provide a role-specific checklist (Admin, Builder, Analyst, or Support).",
        ]
    else:
        answer_lines = [
            "I found relevant documentation sections but no direct checklist lines to extract.",
            "Ask for a specific workflow (for example: creating an AI agent, publishing a widget, or troubleshooting chat responses).",
        ]

    confidence = "high" if len(all_matches) >= 2 else "medium"
    return {
        "answer": "\n".join(answer_lines).strip(),
        "intent": intent,
        "confidence": confidence,
        "references": references,
        "highlights": highlights,
    }
