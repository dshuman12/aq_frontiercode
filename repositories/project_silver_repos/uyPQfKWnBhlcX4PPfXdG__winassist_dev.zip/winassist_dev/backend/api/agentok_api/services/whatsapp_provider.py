import logging
import os
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

import httpx
from fastapi import HTTPException, status

logger = logging.getLogger(__name__)


class WhatsAppProvider(ABC):
    provider_name: str

    @abstractmethod
    async def list_wabas(
        self,
        *,
        graph_version: str,
        meta_business_account_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def validate_connection(
        self,
        *,
        graph_version: str,
        waba_id: str,
        phone_number_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def ensure_waba_subscription(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def list_phone_numbers(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def send_text_message(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        to: str,
        message: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def send_message_payload(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def list_templates(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        name: Optional[str] = None,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def create_template(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def get_template(
        self,
        *,
        graph_version: str,
        template_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def list_flows(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def create_flow(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def get_flow(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def get_flow_preview(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def update_flow_metadata(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def update_flow_json(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
        flow_json: str,
        filename: str = "flow.json",
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def publish_flow(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def list_flow_assets(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def set_business_public_key(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        business_public_key: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def get_business_public_key(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        raise NotImplementedError


class MetaCloudWhatsAppProvider(WhatsAppProvider):
    provider_name = "meta_cloud"

    async def _request(
        self,
        *,
        method: str,
        graph_version: str,
        path: str,
        access_token: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = f"https://graph.facebook.com/{graph_version}/{path.lstrip('/')}"
        headers = {"Authorization": f"Bearer {access_token}"}
        if body is not None and data is None and files is None:
            headers["Content-Type"] = "application/json"

        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.request(
                method.upper(),
                url,
                headers=headers,
                params=params,
                json=body if data is None and files is None else None,
                data=data,
                files=files,
            )

        try:
            data = response.json()
        except Exception:
            data = {"raw": response.text}

        if response.status_code >= 400:
            message = None
            if isinstance(data, dict):
                message = ((data.get("error") or {}).get("message")) or data.get("message")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=message or f"Meta API request failed with status {response.status_code}",
            )
        if not isinstance(data, dict):
            return {"data": data}
        return data

    async def validate_connection(
        self,
        *,
        graph_version: str,
        waba_id: str,
        phone_number_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        phone_info = await self._request(
            method="GET",
            graph_version=graph_version,
            path=phone_number_id,
            access_token=access_token,
            params={"fields": "id,display_phone_number,verified_name,quality_rating,code_verification_status"},
        )
        waba_info = await self._request(
            method="GET",
            graph_version=graph_version,
            path=waba_id,
            access_token=access_token,
            params={"fields": "id,name"},
        )
        return {
            "phone_info": phone_info,
            "waba_info": waba_info,
        }

    async def list_wabas(
        self,
        *,
        graph_version: str,
        meta_business_account_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{meta_business_account_id}/owned_whatsapp_business_accounts",
            access_token=access_token,
            params={"fields": "id,name"},
        )

    async def ensure_waba_subscription(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        app_id = (os.getenv("WHATSAPP_META_APP_ID") or "").strip()
        if not app_id:
            return {
                "status": "skipped",
                "reason": "WHATSAPP_META_APP_ID not configured",
            }

        subscribed_apps = await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{waba_id}/subscribed_apps",
            access_token=access_token,
        )
        existing_ids = {str(item.get("id")) for item in (subscribed_apps.get("data") or []) if item.get("id")}
        if app_id in existing_ids:
            return {
                "status": "already_subscribed",
                "app_id": app_id,
                "data": subscribed_apps.get("data") or [],
            }

        try:
            subscribe_response = await self._request(
                method="POST",
                graph_version=graph_version,
                path=f"{waba_id}/subscribed_apps",
                access_token=access_token,
            )
            return {
                "status": "subscribed",
                "app_id": app_id,
                "response": subscribe_response,
            }
        except HTTPException as exc:
            detail = str(exc.detail)
            if "already" in detail.lower() and "subscribed" in detail.lower():
                return {
                    "status": "already_subscribed",
                    "app_id": app_id,
                    "detail": detail,
                }
            raise

    async def list_phone_numbers(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{waba_id}/phone_numbers",
            access_token=access_token,
        )

    async def send_text_message(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        to: str,
        message: str,
    ) -> Dict[str, Any]:
        return await self.send_message_payload(
            graph_version=graph_version,
            phone_number_id=phone_number_id,
            access_token=access_token,
            payload={
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": to,
                "type": "text",
                "text": {
                    "preview_url": False,
                    "body": message,
                },
            },
        )

    async def send_message_payload(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        body = {
            "messaging_product": "whatsapp",
            **(payload or {}),
        }
        if not body.get("to"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="WhatsApp message payload must include a recipient",
            )
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{phone_number_id}/messages",
            access_token=access_token,
            body=body,
        )

    async def list_templates(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        name: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "fields": "id,name,status,language,category,components",
            "limit": 100,
        }
        if name:
            params["name"] = name
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{waba_id}/message_templates",
            access_token=access_token,
            params=params,
        )

    async def create_template(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{waba_id}/message_templates",
            access_token=access_token,
            body=payload,
        )

    async def get_template(
        self,
        *,
        graph_version: str,
        template_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=template_id,
            access_token=access_token,
            params={"fields": "id,name,status,language,category,components"},
        )

    async def list_flows(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{waba_id}/flows",
            access_token=access_token,
        )

    async def create_flow(
        self,
        *,
        graph_version: str,
        waba_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        data = {k: v for k, v in (payload or {}).items() if v not in (None, "", [])}
        if isinstance(data.get("categories"), list):
            data["categories"] = str(data["categories"]).replace("'", '"')
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{waba_id}/flows",
            access_token=access_token,
            data=data,
        )

    async def get_flow(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=flow_id,
            access_token=access_token,
            params={
                "fields": "id,name,categories,preview,status,validation_errors,json_version,data_api_version,data_channel_uri,health_status,whatsapp_business_account,application"
            },
        )

    async def get_flow_preview(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=flow_id,
            access_token=access_token,
            params={"fields": "preview.invalidate(false)"},
        )

    async def update_flow_metadata(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        data = {k: v for k, v in (payload or {}).items() if v not in (None, "", [])}
        if isinstance(data.get("categories"), list):
            data["categories"] = str(data["categories"]).replace("'", '"')
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=flow_id,
            access_token=access_token,
            data=data,
        )

    async def update_flow_json(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
        flow_json: str,
        filename: str = "flow.json",
    ) -> Dict[str, Any]:
        file_bytes = flow_json.encode("utf-8")
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{flow_id}/assets",
            access_token=access_token,
            data={"name": filename, "asset_type": "FLOW_JSON"},
            files={"file": (filename, file_bytes, "application/json")},
        )

    async def publish_flow(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{flow_id}/publish",
            access_token=access_token,
        )

    async def list_flow_assets(
        self,
        *,
        graph_version: str,
        flow_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{flow_id}/assets",
            access_token=access_token,
        )

    async def set_business_public_key(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
        business_public_key: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="POST",
            graph_version=graph_version,
            path=f"{phone_number_id}/whatsapp_business_encryption",
            access_token=access_token,
            data={"business_public_key": business_public_key},
        )

    async def get_business_public_key(
        self,
        *,
        graph_version: str,
        phone_number_id: str,
        access_token: str,
    ) -> Dict[str, Any]:
        return await self._request(
            method="GET",
            graph_version=graph_version,
            path=f"{phone_number_id}/whatsapp_business_encryption",
            access_token=access_token,
        )


def get_whatsapp_provider(provider_name: str) -> WhatsAppProvider:
    if provider_name == "meta_cloud":
        return MetaCloudWhatsAppProvider()
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"Unsupported WhatsApp provider: {provider_name}",
    )
