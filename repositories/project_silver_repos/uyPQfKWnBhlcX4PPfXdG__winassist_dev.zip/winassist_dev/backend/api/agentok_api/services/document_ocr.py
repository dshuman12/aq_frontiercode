from __future__ import annotations

import base64
import io
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional

from openai import OpenAI
from PIL import Image
from pypdf import PdfReader

try:
    import fitz
except Exception:  # pragma: no cover - optional dependency at import time
    fitz = None


VISION_MODEL = os.getenv("OCR_VISION_MODEL", "gpt-4o-mini")
MAX_OCR_FILE_MB = int(os.getenv("OCR_MAX_FILE_MB", "10"))
MAX_OCR_FILE_BYTES = MAX_OCR_FILE_MB * 1024 * 1024
MAX_VISION_IMAGE_DIMENSION = int(os.getenv("OCR_MAX_IMAGE_DIMENSION", "1800"))
MAX_PDF_PAGES_FOR_OCR = int(os.getenv("OCR_MAX_PDF_PAGES", "3"))
SUPPORTED_MIME_TYPES = {
    "application/pdf",
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/webp",
}


@dataclass
class DecodedDocument:
    data: bytes
    mime_type: str
    filename: str
    data_url: str
    size_bytes: int


def _normalize_spaces(value: str) -> str:
    return re.sub(r"[ \t]+", " ", (value or "")).strip()


def _normalize_text(value: str) -> str:
    text = (value or "").replace("\r", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _clean_field(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    cleaned = _normalize_spaces(value)
    cleaned = re.sub(r"^[\s:,\-]+|[\s:,\-]+$", "", cleaned)
    return cleaned or None


def _search(patterns: list[str], text: str, *, flags: int = re.IGNORECASE | re.MULTILINE) -> Optional[str]:
    for pattern in patterns:
        match = re.search(pattern, text, flags)
        if match:
            for idx in range(1, len(match.groups()) + 1):
                value = _clean_field(match.group(idx))
                if value:
                    return value
    return None


def _candidate_lines(text: str) -> list[str]:
    lines = []
    for raw in (text or "").splitlines():
        line = _normalize_spaces(raw)
        if not line:
            continue
        if len(line) < 3:
            continue
        lines.append(line)
    return lines


def _mime_from_filename(filename: str) -> str:
    lowered = (filename or "").lower()
    if lowered.endswith(".pdf"):
        return "application/pdf"
    if lowered.endswith((".jpg", ".jpeg")):
        return "image/jpeg"
    if lowered.endswith(".png"):
        return "image/png"
    if lowered.endswith(".webp"):
        return "image/webp"
    return "application/octet-stream"


def _data_url_for_bytes(mime_type: str, raw: bytes) -> str:
    return f"data:{mime_type};base64,{base64.b64encode(raw).decode('ascii')}"


def _decode_document(content_base64: str, mime_type: Optional[str], filename: Optional[str]) -> DecodedDocument:
    payload = (content_base64 or "").strip()
    resolved_mime = (mime_type or "").strip().lower()
    if payload.startswith("data:"):
        header, _, encoded = payload.partition(",")
        payload = encoded
        header_match = re.match(r"data:([^;]+);base64$", header, re.IGNORECASE)
        if header_match and not resolved_mime:
            resolved_mime = header_match.group(1).strip().lower()
    if not payload:
        raise ValueError("Document payload is empty")

    try:
        decoded = base64.b64decode(payload, validate=True)
    except Exception as exc:
        raise ValueError("Invalid base64 document payload") from exc

    safe_filename = (filename or "document").strip() or "document"
    if not resolved_mime:
        resolved_mime = _mime_from_filename(safe_filename)
    if resolved_mime == "image/jpg":
        resolved_mime = "image/jpeg"

    if len(decoded) > MAX_OCR_FILE_BYTES:
        raise ValueError(f"Document exceeds OCR limit of {MAX_OCR_FILE_MB} MB")
    if resolved_mime not in SUPPORTED_MIME_TYPES:
        raise ValueError(f"Unsupported OCR mime type: {resolved_mime}")

    return DecodedDocument(
        data=decoded,
        mime_type=resolved_mime,
        filename=safe_filename,
        data_url=_data_url_for_bytes(resolved_mime, decoded),
        size_bytes=len(decoded),
    )


def _extract_pdf_text(doc: DecodedDocument) -> str:
    if doc.mime_type != "application/pdf":
        return ""
    reader = PdfReader(io.BytesIO(doc.data))
    chunks = []
    for page in reader.pages[:MAX_PDF_PAGES_FOR_OCR]:
        try:
            extracted = page.extract_text() or ""
        except Exception:
            extracted = ""
        if extracted.strip():
            chunks.append(extracted)
    return _normalize_text("\n".join(chunks))


def _prepare_image_bytes_for_vision(raw: bytes, mime_type: str) -> str:
    with Image.open(io.BytesIO(raw)) as image:
        image.load()
        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")
        else:
            image = image.copy()

        width, height = image.size
        longest_side = max(width, height)
        if longest_side > MAX_VISION_IMAGE_DIMENSION:
            scale = MAX_VISION_IMAGE_DIMENSION / float(longest_side)
            resized = (
                max(1, int(width * scale)),
                max(1, int(height * scale)),
            )
            image = image.resize(resized)

        fmt = "PNG" if mime_type == "image/png" else "JPEG"
        out = io.BytesIO()
        save_kwargs = {"format": fmt}
        if fmt == "JPEG":
            save_kwargs.update({"quality": 88, "optimize": True})
        image.save(out, **save_kwargs)
        normalized_bytes = out.getvalue()
        normalized_mime = "image/png" if fmt == "PNG" else "image/jpeg"
        return _data_url_for_bytes(normalized_mime, normalized_bytes)


def _render_pdf_for_vision(doc: DecodedDocument) -> str:
    if fitz is None:
        raise RuntimeError("PyMuPDF is required to OCR scanned PDFs")

    pdf = fitz.open(stream=doc.data, filetype="pdf")
    if pdf.page_count == 0:
        raise RuntimeError("PDF has no pages")

    rendered_pages = []
    try:
        for page_index in range(min(pdf.page_count, MAX_PDF_PAGES_FOR_OCR)):
            page = pdf.load_page(page_index)
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
            image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            rendered_pages.append(image)
    finally:
        pdf.close()

    if not rendered_pages:
        raise RuntimeError("Unable to render PDF pages for OCR")

    target_width = min(MAX_VISION_IMAGE_DIMENSION, max(image.width for image in rendered_pages))
    normalized_pages = []
    total_height = 0
    for image in rendered_pages:
        scale = target_width / float(image.width)
        resized = image if scale >= 1 else image.resize((target_width, max(1, int(image.height * scale))))
        normalized_pages.append(resized)
        total_height += resized.height

    stitched = Image.new("RGB", (target_width, total_height), color="white")
    offset_y = 0
    for image in normalized_pages:
        stitched.paste(image, (0, offset_y))
        offset_y += image.height

    out = io.BytesIO()
    stitched.save(out, format="JPEG", quality=85, optimize=True)
    return _data_url_for_bytes("image/jpeg", out.getvalue())


def _extract_text_with_vision(doc: DecodedDocument) -> str:
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured for OCR vision fallback")

    if doc.mime_type.startswith("image/"):
        data_url = _prepare_image_bytes_for_vision(doc.data, doc.mime_type)
    elif doc.mime_type == "application/pdf":
        data_url = _render_pdf_for_vision(doc)
    else:
        raise RuntimeError(f"Unsupported OCR mime type: {doc.mime_type}")

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=VISION_MODEL,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an OCR engine. Extract the visible text exactly as it appears. "
                    "Do not summarize. Preserve labels, dates, numbers, and line breaks when possible."
                ),
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Extract all visible text from this identity document."},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            },
        ],
    )
    text = response.choices[0].message.content if response.choices else ""
    return _normalize_text(text or "")


def _ensure_image_is_loadable(doc: DecodedDocument) -> None:
    if not doc.mime_type.startswith("image/"):
        return
    with Image.open(io.BytesIO(doc.data)) as image:
        image.verify()


def _infer_document_type(text: str, preferred_type: str) -> str:
    normalized = (preferred_type or "auto").strip().lower()
    if normalized in {"aadhaar", "aadhar", "pan", "driving_licence", "driving_license", "driving licence", "driving license"}:
        if normalized == "aadhar":
            return "aadhaar"
        if "driving" in normalized:
            return "driving_licence"
        return normalized

    lowered = (text or "").lower()
    if re.search(r"\b[a-z]{5}[0-9]{4}[a-z]\b", lowered, re.IGNORECASE) or "income tax department" in lowered:
        return "pan"
    if "government of india" in lowered or "uidai" in lowered or re.search(r"\b\d{4}\s?\d{4}\s?\d{4}\b", text):
        return "aadhaar"
    if "driving licence" in lowered or "driving license" in lowered or re.search(r"\b[a-z]{2}\d{2}\s?\d{11,13}\b", lowered):
        return "driving_licence"
    return "unknown"


def _extract_name_from_lines(lines: list[str], excluded_patterns: list[str]) -> Optional[str]:
    for line in lines:
        if any(re.search(pattern, line, re.IGNORECASE) for pattern in excluded_patterns):
            continue
        if re.search(r"\d", line):
            continue
        if len(line.split()) < 2:
            continue
        return _clean_field(line.title() if line.isupper() else line)
    return None


def _parse_aadhaar(text: str) -> Dict[str, Any]:
    lines = _candidate_lines(text)
    name = _search(
        [
            r"Government of India\s*[\n: -]+([A-Z][A-Za-z .]{2,})",
            r"भारत सरकार\s*[\n: -]+([A-Z][A-Za-z .]{2,})",
        ],
        text,
    )
    if not name:
        name = _extract_name_from_lines(
            lines,
            [
                r"government of india",
                r"uidai",
                r"aadhaar",
                r"dob",
                r"year of birth",
                r"male|female",
                r"address",
            ],
        )
    return {
        "name": name,
        "aadhaar_number": _search([r"\b(\d{4}\s?\d{4}\s?\d{4})\b"], text, flags=re.MULTILINE),
        "date_of_birth": _search(
            [
                r"(?:DOB|Date of Birth)\s*[:\-]?\s*([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})",
            ],
            text,
        ),
        "year_of_birth": _search([r"Year of Birth\s*[:\-]?\s*((?:19|20)\d{2})"], text),
        "gender": _search([r"\b(Male|Female)\b"], text),
    }


def _parse_pan(text: str) -> Dict[str, Any]:
    lines = _candidate_lines(text)
    pan_number = _search([r"\b([A-Z]{5}[0-9]{4}[A-Z])\b"], text, flags=re.IGNORECASE | re.MULTILINE)
    date_of_birth = _search(
        [r"([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})"],
        text,
    )
    has_pan_context = bool(
        pan_number
        or re.search(r"income tax department|permanent account number", text, re.IGNORECASE)
    )
    if not has_pan_context:
        return {}

    filtered = [
        line
        for line in lines
        if not re.search(
            r"income tax department|permanent account number|signature|india|government|father|date|dob|[a-z]{5}[0-9]{4}[a-z]",
            line,
            re.IGNORECASE,
        )
        and not re.search(r"\d{2}[\/\-]\d{2}[\/\-]\d{4}", line)
    ]
    name = filtered[0] if filtered else None
    father_name = filtered[1] if len(filtered) > 1 else None
    labeled_father = _search([r"Father(?:'s)? Name\s*[:\-]?\s*([A-Z][A-Za-z .]{2,})"], text)

    return {
        "name": _clean_field(name),
        "father_name": labeled_father or _clean_field(father_name),
        "pan_number": pan_number,
        "date_of_birth": date_of_birth,
    }


def _parse_driving_licence(text: str) -> Dict[str, Any]:
    lines = _candidate_lines(text)
    licence_number = _search(
        [
            r"(?:DL|D/L|Licence|License)\s*(?:No|Number)?\s*[:\-]?\s*([A-Z]{0,4}[- ]?\d[A-Z0-9 -]{6,20})",
            r"\b([A-Z]{2}[- ]?\d{2}[- ]?\d{4,13})\b",
        ],
        text,
    )
    name = _search(
        [
            r"(?:Name|Holder Name)\s*[:\-]?\s*([A-Z][A-Za-z .]{2,})",
        ],
        text,
    )
    if not name:
        name = _extract_name_from_lines(
            lines,
            [
                r"driving licence|driving license|licence|license|transport|authority|india|address|valid|issue|dob",
            ],
        )

    return {
        "name": name,
        "licence_number": licence_number,
        "date_of_birth": _search(
            [
                r"(?:DOB|Date of Birth|Birth)\s*[:\-]?\s*([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})",
                r"\b([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})\b",
            ],
            text,
        ),
        "issue_date": _search([r"(?:Issue Date|Issued On)\s*[:\-]?\s*([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})"], text),
        "valid_till": _search([r"(?:Valid Till|Valid To|Validity)\s*[:\-]?\s*([0-3]?\d[\/\-][01]?\d[\/\-](?:19|20)\d{2})"], text),
        "address": _search([r"Address\s*[:\-]?\s*([A-Za-z0-9,./\- ]{8,})"], text),
    }


def parse_document_fields(text: str, document_type: str) -> Dict[str, Any]:
    resolved_type = _infer_document_type(text, document_type)
    if resolved_type == "aadhaar":
        fields = _parse_aadhaar(text)
    elif resolved_type == "pan":
        fields = _parse_pan(text)
    elif resolved_type == "driving_licence":
        fields = _parse_driving_licence(text)
    else:
        fields = {}

    clean_fields = {key: value for key, value in fields.items() if value not in (None, "", [])}
    return {
        "document_type": resolved_type,
        "fields": clean_fields,
    }


def extract_document_ocr(
    *,
    content_base64: str,
    filename: Optional[str] = None,
    mime_type: Optional[str] = None,
    document_type: str = "auto",
) -> Dict[str, Any]:
    doc = _decode_document(content_base64, mime_type, filename)
    if doc.mime_type.startswith("image/"):
        _ensure_image_is_loadable(doc)

    text = _extract_pdf_text(doc)
    provider = "pypdf" if text else None

    if not text:
        text = _extract_text_with_vision(doc)
        provider = "openai_vision"

    parsed = parse_document_fields(text, document_type)
    matched_field_count = len(parsed["fields"])
    resolved_type = parsed["document_type"]
    ok = bool(text) and matched_field_count > 0
    error = None
    if not text:
        error = "No text could be extracted from the document."
    elif matched_field_count == 0:
        if resolved_type == "unknown":
            error = "OCR completed, but the document type could not be identified."
        else:
            error = f"OCR completed, but no expected {resolved_type} fields were matched."

    return {
        "ok": ok,
        "document_type": resolved_type,
        "filename": doc.filename,
        "mime_type": doc.mime_type,
        "size_bytes": doc.size_bytes,
        "ocr_provider": provider,
        "text": text,
        "fields": parsed["fields"],
        "matched_field_count": matched_field_count,
        "error": error,
    }
