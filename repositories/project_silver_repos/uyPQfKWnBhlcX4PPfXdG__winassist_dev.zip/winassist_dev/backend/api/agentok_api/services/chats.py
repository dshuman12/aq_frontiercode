import os
import tempfile
import asyncio
import json
import re
from datetime import datetime
from typing import List, Optional

from termcolor import colored

from ..models import Chat, ChatCreate, Log, LogCreate, Message, MessageCreate, Project
from .chat_manager import ChatManager
from .codegen import CodegenService
from .database import DatabaseClient
from .output_parser import clean_answer_text
from ..utils.knowledge_registry import (
    get_collection_documents,
    list_knowledge_collections,
    list_knowledge_documents,
)
from ..utils.ai_quality import detect_guardrail_hits
from ..utils.nlu import analyze_query

DEBUG = False


class ChatService:
    def __init__(self, supabase: DatabaseClient, codegen_service: CodegenService):
        self.codegen_service = codegen_service
        self.supabase = supabase
        self.chat_manager = ChatManager(supabase)

    async def get_chats(self) -> List[Chat]:
        return await self.supabase.fetch_chats()

    async def get_chat(self, chat_id: int) -> Chat:
        return await self.supabase.fetch_chat(chat_id)

    async def create_chat(self, chat: ChatCreate) -> Chat:
        """
        Create a new chat session.
        Ensures user_id is passed and not NULL.
        """
        if DEBUG:
            print(chat)
        chat_payload = {
            "name": chat.name,
            "from_type": chat.from_type,
            "from_project": chat.from_project,
            "from_template": chat.from_template,
            "user_id": chat.user_id,
            "session_id": chat.session_id,
        }

        new_chat_data = await self.supabase.create_chat(chat_payload)

        if isinstance(new_chat_data, Chat):
            return new_chat_data
        return Chat(**new_chat_data)

    async def get_messages(self, chat_id: int) -> List[Message]:
        return await self.supabase.fetch_messages(chat_id)

    async def get_logs(self, chat_id: int) -> List[Log]:
        return await self.supabase.fetch_logs(str(chat_id))

    async def start_chat(self, message: MessageCreate, chat_id: int, on_message=None):
        # ✅ Validate message content - allow '\n' as a valid message for special commands
        content = message.content or ""
        # Strip whitespace but allow single newline as valid input
        if not content or (content.strip() == "" and content != "\n"):
            if DEBUG:
                print(colored("⚠️ Received empty message, skipping...", "yellow"))
            return {"detail": "Message content cannot be empty", "status": "skipped"}

        user_query = clean_answer_text(content)
        if user_query:
            print(f"[USER]: {user_query}")

        # Persist user message first
        await self.supabase.add_message(message, chat_id)
        await self.supabase.set_chat_status(chat_id, "running")

        # Prepare target directory
        target_path = os.path.join(tempfile.gettempdir(), f"winassist/{chat_id}/")
        os.makedirs(target_path, exist_ok=True)
        if DEBUG:
            print(colored(f"Target directory {target_path}", "green"))

        # Fetch source/project metadata
        source = await self.supabase.fetch_source_metadata(chat_id)

        # Parse flow JSON safely
        if isinstance(source.get("flow"), str):
            try:
                source["flow"] = json.loads(source["flow"])
                if DEBUG:
                    print(colored("Converted source['flow'] from JSON string to dict", "yellow"))
            except json.JSONDecodeError:
                if DEBUG:
                    print(colored("Warning: source['flow'] could not be parsed as JSON", "red"))

        # --- OpenAI tool-calling agent runtime (backend projects): model picks tools + APIs ---
        try:
            from .agent_runtime import AgentRuntime, should_use_agent_runtime

            ai_config = (
                source.get("flow", {}).get("ai_config", {})
                if isinstance(source.get("flow"), dict)
                else {}
            )
            nlu_context = analyze_query(user_query, ai_config)
            if should_use_agent_runtime(source):
                runtime = AgentRuntime(self.supabase)
                knowledge_context = await self._build_knowledge_context(source)
                return await runtime.run(
                    int(chat_id),
                    message.content or "",
                    source,
                    knowledge_context=knowledge_context,
                    ai_config=ai_config,
                    nlu_context=nlu_context,
                    on_message=on_message,
                )
        except Exception as e:
            if DEBUG:
                print(colored(f"Agent runtime failed, falling back to legacy subprocess: {e}", "yellow"))
            # Fall through to generated Python agent

        # Prepare target directory (legacy AutoGen / codegen path)
        target_path = os.path.join(tempfile.gettempdir(), f"agentok/{chat_id}/")
        os.makedirs(target_path, exist_ok=True)
        if DEBUG:
            print(colored(f"Target directory {target_path}", "green"))

        # Handle created_at
        created_at_str = source.get("created_at")
        if created_at_str and isinstance(created_at_str, str):
            try:
                datetime_obj = datetime.fromisoformat(created_at_str)
            except ValueError:
                datetime_obj = datetime.now()
        else:
            datetime_obj = datetime.now()

        source_file = f"{source['id']}-{datetime_obj.timestamp()}.py"
        source_path = os.path.join(target_path, source_file)

        # Generate tool environment files
        if DEBUG:
            print(colored("Generating tool envs...", "blue"))
        project = Project(**source)
        tool_dict = await self.codegen_service.build_tool_dict(project)
        tool_envs = await self.codegen_service.generate_tool_envs(project, tool_dict)

        try:
            tool_assignments = self.codegen_service.generate_tool_assignments(
                project.flow.edges,
                tool_dict,
                project.flow.nodes,
            )
            planner_context = self.codegen_service.capability_planner.plan_for_query(
                user_query,
                tool_dict,
                tool_assignments,
            )
            guidance = planner_context.get("guidance_by_caller", {})
            if guidance:
                await self.supabase.add_log(
                    LogCreate(
                        message="planner_context_generated",
                        level="info",
                        chat_id=chat_id,
                        metadata={
                            "type": "planner_context",
                            "query": user_query,
                            "guidance_by_caller": guidance,
                            "ranked_by_caller": planner_context.get("ranked_by_caller", {}),
                            "confidence_by_caller": planner_context.get("confidence_by_caller", {}),
                            "approval_required_by_caller": planner_context.get("approval_required_by_caller", {}),
                        },
                    )
                )
        except Exception as e:
            if DEBUG:
                print(colored(f"Warning: Could not generate planner trace: {e}", "yellow"))

        for tool_id, env in tool_envs.items():
            env_path = os.path.join(target_path, f"{tool_id}.env")
            with open(env_path, "w", encoding="utf-8") as file:
                file.write(env)

        # Generate project code
        if DEBUG:
            print(colored("Generating project code...", "blue"))
        # Prefer DB column `code` if present; else use Python embedded in flow JSON
        # (frontend Code tab saves `flow.generated_python` so chat matches the previewed agent).
        project_code = source.get("code")
        flow_for_embed = source.get("flow")
        if isinstance(flow_for_embed, str):
            try:
                flow_for_embed = json.loads(flow_for_embed)
            except json.JSONDecodeError:
                flow_for_embed = {}
        if not project_code and isinstance(flow_for_embed, dict):
            embedded = flow_for_embed.get("generated_python")
            if isinstance(embedded, str) and embedded.strip():
                project_code = embedded

        if not project_code:
            # Try to generate code (may raise exception if templates are disabled)
            try:
                project_code = await self.codegen_service.generate_project(
                    Project(**source),
                    user_query=user_query,
                )
            except Exception as e:
                error_msg = str(e)
                if DEBUG:
                    print(colored(f"Warning: Could not generate project code: {error_msg}", "yellow"))
                    print(colored("Note: Project code generation via templates is disabled.", "yellow"))
                    print(colored("The frontend should generate code using codeGenerator.js and store it in the project.", "yellow"))
                # Create a minimal working Python script as placeholder
                # This allows the chat to start but won't actually run the agent
                project_code = f"""# Project code should be generated by frontend codeGenerator.js
# Project ID: {source.get('id', 'unknown')}
# This is a placeholder script. The frontend should generate the actual code.

import sys
import os

print("Error: Project code not available.")
print("Please ensure the frontend generates code using codeGenerator.js and stores it in the project.")
print(f"Project ID: {source.get('id', 'unknown')}")
sys.exit(1)
"""

        with open(source_path, "w", encoding="utf-8") as file:
            file.write(project_code)

        # Copy OAI_CONFIG_LIST.json to temp directory if it exists
        # This is needed because the generated code looks for it in the current directory
        # Find api directory by looking for OAI_CONFIG_LIST.json starting from current file location
        current_file_dir = os.path.dirname(os.path.abspath(__file__))
        # Try different path levels to find the api directory
        api_dir = None
        search_dir = current_file_dir
        for _ in range(5):  # Search up to 5 levels
            potential_path = os.path.join(search_dir, "OAI_CONFIG_LIST.json")
            if os.path.exists(potential_path):
                api_dir = search_dir
                break
            search_dir = os.path.dirname(search_dir)
        
        if api_dir:
            oai_config_path = os.path.join(api_dir, "OAI_CONFIG_LIST.json")
        else:
            # Fallback: assume 2 levels up from services/
            api_dir = os.path.dirname(os.path.dirname(current_file_dir))
            oai_config_path = os.path.join(api_dir, "OAI_CONFIG_LIST.json")
        
        if DEBUG:
            print(colored(f"Looking for OAI_CONFIG_LIST.json at: {oai_config_path}", "cyan"))
            print(colored(f"File exists: {os.path.exists(oai_config_path)}", "cyan"))
        if os.path.exists(oai_config_path):
            import shutil
            target_config_path = os.path.join(target_path, "OAI_CONFIG_LIST.json")
            shutil.copy2(oai_config_path, target_config_path)
            if DEBUG:
                print(colored(f"Copied OAI_CONFIG_LIST.json to {target_config_path}", "green"))
            
            # Set environment variable for autogen to find the config file
            # autogen.config_list_from_json looks for env var first, then file
            os.environ["OAI_CONFIG_LIST"] = target_config_path
            if DEBUG:
                print(colored(f"Set OAI_CONFIG_LIST environment variable to {target_config_path}", "green"))
        else:
            if DEBUG:
                print(colored(f"Warning: OAI_CONFIG_LIST.json not found at {oai_config_path}", "yellow"))

        # Launch the agent
        async def message_handler(assistant_message):
            # ✅ Validate assistant message before saving
            if not assistant_message.get("content") or not assistant_message["content"].strip():
                if DEBUG:
                    print(colored("⚠️ Assistant sent empty message, skipping save...", "yellow"))
                return

            cleaned_content = clean_answer_text(assistant_message.get("answer") or assistant_message.get("content"))
            if not cleaned_content:
                return

            message_to_save = {
                "type": assistant_message.get("type", "assistant"),
                "content": cleaned_content,
                "sender": assistant_message.get("sender"),
                "receiver": assistant_message.get("receiver"),
            }
            if DEBUG and assistant_message.get("metadata"):
                message_to_save["metadata"] = assistant_message.get("metadata")
            
            # Save to database - await to ensure it's saved before continuing
            try:
                await self.supabase.add_message(MessageCreate(**message_to_save), chat_id)
                if DEBUG:
                    print(colored(f"✅ Saved message to database: {assistant_message.get('type', 'unknown')}", "green"))
            except Exception as e:
                if DEBUG:
                    print(colored(f"❌ Error saving message to database: {e}", "red"))

            if assistant_message.get("type") == "summary":
                print(f"[AI]: {cleaned_content}")
            
            # Call the provided on_message callback if available (for streaming)
            if on_message:
                try:
                    outbound_message = {
                        **assistant_message,
                        "content": cleaned_content,
                    }
                    if assistant_message.get("type") == "summary":
                        outbound_message["answer"] = cleaned_content
                    if not DEBUG:
                        outbound_message.pop("metadata", None)
                    if asyncio.iscoroutinefunction(on_message):
                        await on_message(outbound_message)
                    else:
                        # If it's a sync function, run it in executor to avoid blocking
                        loop = asyncio.get_event_loop()
                        await loop.run_in_executor(None, on_message, outbound_message)
                except Exception as e:
                    if DEBUG:
                        print(colored(f"Error in on_message callback: {e}", "red"))

        memory_context = await self._build_memory_context(chat_id)
        ai_config = (
            source.get("flow", {}).get("ai_config", {})
            if isinstance(source.get("flow"), dict)
            else {}
        )
        nlu_context = analyze_query(user_query, ai_config)
        guardrail_hits = detect_guardrail_hits(user_query, ai_config.get("guardrails"))
        if nlu_context.get("intent_result", {}).get("best_intent") or nlu_context.get("entity_result", {}).get("entities"):
            await self.supabase.add_log(
                LogCreate(
                    message="nlu_analysis_generated",
                    level="info",
                    chat_id=chat_id,
                    metadata={
                        "type": "nlu_analysis",
                        "best_intent": nlu_context.get("intent_result", {}).get("best_intent"),
                        "intent_candidates": nlu_context.get("intent_result", {}).get("candidates", []),
                        "entities": nlu_context.get("entity_result", {}).get("entities", []),
                        "route_target": nlu_context.get("route_target"),
                        "insights": nlu_context.get("insights", {}),
                        "guardrail_hits": guardrail_hits,
                    },
                )
            )
        if guardrail_hits.get("has_guardrail_hit"):
            await self.supabase.add_log(
                LogCreate(
                    message="guardrail_hit_detected",
                    level="warning",
                    chat_id=chat_id,
                    metadata={
                        "type": "guardrail_hit",
                        "query": user_query,
                        "guardrail_hits": guardrail_hits,
                    },
                )
            )
        knowledge_context = await self._build_knowledge_context(source)
        if knowledge_context.get("collections") or knowledge_context.get("documents"):
            await self.supabase.add_log(
                LogCreate(
                    message="knowledge_bindings_loaded",
                    level="info",
                    chat_id=chat_id,
                    metadata={
                        "type": "knowledge_bindings",
                        "collection_count": len(knowledge_context.get("collections") or []),
                        "document_count": len(knowledge_context.get("documents") or []),
                        "collection_names": [
                            item.get("name") for item in (knowledge_context.get("collections") or [])
                        ],
                        "retrieval_defaults": knowledge_context.get("retrieval_defaults") or {},
                    },
                )
            )
        runtime_prompt = self._build_runtime_prompt(
            user_query=user_query,
            chat_id=chat_id,
            session_id=getattr(message, "session_id", None),
            memory_context=memory_context,
            knowledge_context=knowledge_context,
            ai_config=ai_config,
            nlu_context=nlu_context,
            guardrail_hits=guardrail_hits,
        )
        return await self.chat_manager.run_assistant(
            str(chat_id),  # Convert to string for consistent storage
            runtime_prompt or (message.content or "\n"),
            source_path,
            message_handler,
        )

    async def _build_memory_context(self, chat_id: int) -> dict:
        """
        Build lightweight memory tiers from chat history:
        - recent_turns: short rolling transcript window
        - key_facts: durable user facts inferred from previous turns
        """
        try:
            messages = await self.supabase.fetch_messages(str(chat_id))
        except Exception:
            return {"recent_turns": [], "key_facts": []}

        # Exclude status/system-like empty messages and keep the latest window.
        usable = []
        for m in messages or []:
            content = (getattr(m, "content", None) or "").strip()
            if not content:
                continue
            if content.startswith("__STATUS_"):
                continue
            role = (getattr(m, "type", None) or getattr(m, "sender", None) or "assistant").lower()
            if role not in {"user", "assistant", "summary"}:
                role = "assistant" if getattr(m, "sender", "") else "user"
            usable.append({"role": role, "content": content})

        recent = usable[-8:]
        facts = []
        fact_patterns = [
            r"\bmy name is\s+([A-Za-z][A-Za-z\s]{1,40})",
            r"\bi am from\s+([A-Za-z][A-Za-z\s]{1,60})",
            r"\bmy email is\s+([^\s,;]+@[^\s,;]+)",
            r"\bmy phone(?: number)? is\s+([0-9+\-\s]{7,20})",
            r"\bmy (?:order|ticket|booking) id is\s+([A-Za-z0-9\-_]{4,40})",
        ]
        for entry in usable[-20:]:
            if entry["role"] != "user":
                continue
            text = entry["content"]
            for pat in fact_patterns:
                match = re.search(pat, text, re.IGNORECASE)
                if match:
                    candidate = " ".join(match.group(0).split())
                    if candidate not in facts:
                        facts.append(candidate)
            if len(facts) >= 6:
                break

        return {"recent_turns": recent, "key_facts": facts[:6]}

    async def _build_knowledge_context(self, source: dict) -> dict:
        flow = source.get("flow") or {}
        ai_config = flow.get("ai_config") if isinstance(flow, dict) else {}
        ai_config = ai_config if isinstance(ai_config, dict) else {}
        collection_ids = [str(value) for value in (ai_config.get("knowledge_bindings") or []) if value]
        workspace_id = source.get("workspace_id")
        user_id = source.get("user_id")
        user_id_str = str(user_id) if user_id else ""
        workspace_id_str = str(workspace_id) if workspace_id else None

        if not user_id_str:
            return {
                "collections": [],
                "documents": [],
                "retrieval_defaults": {
                    "top_k": ai_config.get("retrievalTopK"),
                    "chunk_size": ai_config.get("chunkSize"),
                    "chunk_overlap": ai_config.get("chunkOverlap"),
                    "enable_rag": ai_config.get("enableRag"),
                },
            }

        pool = await self.supabase.get_pool()
        async with pool.acquire() as conn:
            if collection_ids:
                collections = [
                    item
                    for item in await list_knowledge_collections(conn, user_id_str, workspace_id_str)
                    if item.get("id") in set(collection_ids)
                ]
                bound_documents = await get_collection_documents(
                    conn,
                    user_id_str,
                    workspace_id_str,
                    collection_ids,
                )
            else:
                collections = []
                workspace_documents = await list_knowledge_documents(conn, user_id_str, workspace_id_str)
                bound_documents = [
                    {
                        "collection_id": None,
                        "collection_name": "Workspace knowledge",
                        "document": item,
                    }
                    for item in workspace_documents
                    if str(item.get("status") or "").strip().lower() == "indexed"
                    and int(item.get("extracted_chars") or 0) > 0
                ]
        documents = []
        for entry in bound_documents[:12]:
            document = entry.get("document") or {}
            documents.append(
                {
                    "collection_id": entry.get("collection_id"),
                    "collection_name": entry.get("collection_name"),
                    "title": document.get("title") or document.get("filename"),
                    "relative_path": document.get("relative_path"),
                    "status": document.get("status"),
                }
            )

        return {
            "collections": collections,
            "documents": documents,
            "retrieval_defaults": {
                "top_k": ai_config.get("retrievalTopK"),
                "chunk_size": ai_config.get("chunkSize"),
                "chunk_overlap": ai_config.get("chunkOverlap"),
                "enable_rag": ai_config.get("enableRag"),
            },
        }

    def _build_runtime_prompt(
        self,
        user_query: str,
        chat_id: int,
        session_id=None,
        memory_context=None,
        knowledge_context: Optional[dict] = None,
        ai_config: Optional[dict] = None,
        nlu_context: Optional[dict] = None,
        guardrail_hits: Optional[dict] = None,
    ) -> str:
        """
        Build a structured runtime prompt envelope.
        This improves context packing consistency without changing the user's raw query.
        """
        query = (user_query or "").strip()
        if not query:
            return user_query or "\n"
        safe_session = str(session_id).strip() if session_id else ""
        memory_context = memory_context or {}
        recent_turns = memory_context.get("recent_turns") or []
        key_facts = memory_context.get("key_facts") or []
        knowledge_context = knowledge_context or {}
        ai_config = ai_config if isinstance(ai_config, dict) else {}
        nlu_context = nlu_context if isinstance(nlu_context, dict) else {}
        guardrail_hits = guardrail_hits if isinstance(guardrail_hits, dict) else {}
        bound_collections = knowledge_context.get("collections") or []
        bound_documents = knowledge_context.get("documents") or []
        retrieval_defaults = knowledge_context.get("retrieval_defaults") or {}
        intents = ai_config.get("intents") or []
        entities = ai_config.get("entities") or []
        best_intent = (nlu_context.get("intent_result") or {}).get("best_intent")
        extracted_entities = (nlu_context.get("entity_result") or {}).get("entities") or []
        nlu_insights = nlu_context.get("insights") or {}
        detected_language = nlu_context.get("detected_language") or ai_config.get("defaultLanguage")
        guardrails = ai_config.get("guardrails") or {}
        retrieval_mode = str(ai_config.get("retrievalMode") or "hybrid").strip().lower()
        supported_languages = [
            line.strip()
            for line in str(ai_config.get("supportedLanguagesText") or "").splitlines()
            if line.strip()
        ]

        recent_text = "\n".join(
            f"- {t.get('role', 'assistant')}: {t.get('content', '')[:280]}"
            for t in recent_turns
        ) or "- none"
        facts_text = "\n".join(f"- {f}" for f in key_facts) or "- none"
        collections_text = "\n".join(
            f"- {item.get('name')} ({item.get('id')})"
            for item in bound_collections[:8]
        ) or "- none"
        documents_text = "\n".join(
            f"- {item.get('title')} | path={item.get('relative_path')} | collection={item.get('collection_name')}"
            for item in bound_documents[:12]
        ) or "- none"
        retrieval_text = "\n".join(
            f"- {key}: {value}"
            for key, value in retrieval_defaults.items()
            if value is not None and value != ""
        ) or "- none"
        intents_text = "\n".join(
            f"- {item.get('name')}: {item.get('description') or ''} | utterances={str(item.get('utterancesText') or '').replace(chr(10), ' | ')[:220]}"
            for item in intents[:12]
            if item.get("name")
        ) or "- none"
        entities_text = "\n".join(
            f"- {item.get('name')} ({item.get('entityType') or 'text'}): {item.get('description') or ''} | examples={str(item.get('examplesText') or '').replace(chr(10), ' | ')[:220]}"
            for item in entities[:12]
            if item.get("name")
        ) or "- none"
        best_intent_text = (
            f"- name: {best_intent.get('name')} | confidence: {best_intent.get('confidence')} | matched_utterance: {best_intent.get('matched_utterance')} | route_target: {best_intent.get('route_target') or 'none'}"
            if best_intent
            else "- none"
        )
        extracted_entities_text = "\n".join(
            f"- {item.get('name')}: raw={item.get('value')} | normalized={item.get('normalized_value')} | confidence={item.get('confidence')} | method={item.get('method')} | validation={'pass' if item.get('validation_passed') else 'fail'}"
            for item in extracted_entities[:12]
        ) or "- none"
        intent_warnings_text = "\n".join(
            f"- {item.get('message')}"
            for item in (nlu_insights.get("intent_warnings") or [])[:8]
        ) or "- none"
        entity_warnings_text = "\n".join(
            f"- {item.get('message')}"
            for item in (nlu_insights.get("entity_warnings") or [])[:8]
        ) or "- none"
        guardrails_text = "\n".join(
            f"- {key}: {value}"
            for key, value in {
                "fallback_policy": guardrails.get("fallbackPolicy"),
                "require_citation": guardrails.get("requireCitationForKnowledge"),
                "mask_sensitive_data": guardrails.get("maskSensitiveData"),
            }.items()
            if value not in (None, "", [])
        ) or "- none"
        guardrail_hits_text = "\n".join(
            f"- {key}: {', '.join(value)}"
            for key, value in guardrail_hits.items()
            if isinstance(value, list) and value
        ) or "- none"
        supported_languages_text = "\n".join(f"- {value}" for value in supported_languages) or "- none"
        retrieval_mode_text = f"- retrieval_mode: {retrieval_mode}"

        if retrieval_mode == "rag-first":
            retrieval_policy = "- Prioritize grounded retrieval from bound knowledge before general reasoning.\n- Use intent routing as secondary guidance.\n"
        elif retrieval_mode == "intent-first":
            retrieval_policy = "- Prioritize detected intent and route target first.\n- Use grounded retrieval when the intent needs document-backed answers.\n"
        elif retrieval_mode == "freeform":
            retrieval_policy = "- Answer flexibly using the model and available context.\n- Use retrieval only when it clearly improves factual grounding.\n"
        else:
            retrieval_policy = "- Blend intent routing and grounded retrieval.\n- Prefer retrieval for factual or policy answers and intent routing for workflow actions.\n"

        return (
            "RUNTIME_CONTEXT:\n"
            f"- chat_id: {chat_id}\n"
            f"- session_id: {safe_session or 'unknown'}\n"
            "- mode: execute_user_request\n\n"
            "MEMORY_TIERS:\n"
            "Tier-1 recent turns:\n"
            f"{recent_text}\n\n"
            "Tier-2 key facts:\n"
            f"{facts_text}\n\n"
            "KNOWLEDGE_BINDINGS:\n"
            "Bound collections:\n"
            f"{collections_text}\n\n"
            "Bound documents (these can be used with tools like rag_search via file_path):\n"
            f"{documents_text}\n\n"
            "Retrieval defaults:\n"
            f"{retrieval_text}\n\n"
            "Retrieval mode:\n"
            f"{retrieval_mode_text}\n\n"
            "INTENT_CATALOG:\n"
            f"{intents_text}\n\n"
            "ENTITY_CATALOG:\n"
            f"{entities_text}\n\n"
            "LANGUAGE_PROFILE:\n"
            f"- detected_language: {detected_language or 'unknown'}\n"
            "Supported languages:\n"
            f"{supported_languages_text}\n\n"
            "DETECTED_NLU:\n"
            "Best intent:\n"
            f"{best_intent_text}\n\n"
            "Extracted entities:\n"
            f"{extracted_entities_text}\n\n"
            "Intent warnings:\n"
            f"{intent_warnings_text}\n\n"
            "Entity warnings:\n"
            f"{entity_warnings_text}\n\n"
            "GUARDRAILS:\n"
            f"{guardrails_text}\n\n"
            "Guardrail hits for this request:\n"
            f"{guardrail_hits_text}\n\n"
            "USER_REQUEST:\n"
            f"{query}\n\n"
            "PLAN_EXECUTE_POLICY:\n"
            "1) Build a short internal plan (1-3 steps).\n"
            "2) If task requires tools, execute required tool(s) before final answer.\n"
            "3) For multi-tool tasks, chain tools in dependency order.\n"
            "4) If required parameters are missing, ask one focused clarification question.\n\n"
            "RESPONSE_REQUIREMENTS:\n"
            "- Use available tools when required by the task.\n"
            "- When grounded knowledge is needed, prefer bound knowledge documents and retrieval tools before answering.\n"
            f"{retrieval_policy}"
            "- If required information is missing, ask one focused clarification question.\n"
            "- Provide final answer in clear Markdown with short sections.\n"
            "- Keep tool internals/JSON out of the final user-facing response."
        )

    async def abort_chat(self, chat_id: int):
        return await self.chat_manager.abort_assistant(str(chat_id))  # Convert to string for lookup

    async def delete_chat(self, chat_id: int) -> dict:
        """Delete a chat and all associated messages"""
        # Abort any running chat process first
        try:
            await self.chat_manager.abort_assistant(str(chat_id))
        except Exception as e:
            # If abort fails, log but continue with deletion
            if DEBUG:
                print(f"Warning: Could not abort chat {chat_id} before deletion: {e}")
        
        # Delete from database (this will also delete messages and logs)
        return await self.supabase.delete_chat(str(chat_id))

    async def clear_messages(self, chat_id: int) -> dict:
        """Clear messages/logs for a chat while keeping the chat row."""
        try:
            await self.chat_manager.abort_assistant(str(chat_id))
        except Exception as e:
            if DEBUG:
                print(f"Warning: Could not abort chat {chat_id} before clearing messages: {e}")

        return await self.supabase.clear_chat_messages(str(chat_id))

    async def human_input(self, message: MessageCreate, chat_id: int):
        # ✅ Validate message content - allow '\n' as a valid message for special commands
        content = message.content or ""
        # Strip whitespace but allow single newline as valid input
        if not content or (content.strip() == "" and content != "\n"):
            if DEBUG:
                print(colored("⚠️ Received empty input message, skipping...", "yellow"))
            return {"error": "Message content cannot be empty"}
        
        # Check if assistant process exists (convert to string for lookup)
        proc_info = self.chat_manager._subprocesses.get(str(chat_id))
        if not proc_info:
            # No assistant running - check chat status
            chat = await self.get_chat(chat_id)
            chat_status = chat.status.lower() if chat.status else "idle"
            
            # If chat is in a recoverable state (including wait_for_human_input when process is lost), reset and start new chat
            if chat_status in ["completed", "aborted", "idle", "failed", "ready", "wait_for_human_input"]:
                # Reset status if it's stuck in wait_for_human_input
                if chat_status == "wait_for_human_input":
                    if DEBUG:
                        print(colored(f"[ChatService] Process lost but status is wait_for_human_input. Resetting to ready and starting new chat...", "yellow"))
                    await self.supabase.set_chat_status(str(chat_id), "ready")
                else:
                    if DEBUG:
                        print(colored(f"[ChatService] No assistant found for chat_id={chat_id}, but chat is {chat_status}. Starting new chat session...", "yellow"))
                return await self.start_chat(message, chat_id)
            else:
                # Chat is in an unexpected state, reset to ready and try again
                if DEBUG:
                    print(colored(f"[ChatService] No assistant found for chat_id={chat_id} with status {chat_status}. Resetting to ready...", "yellow"))
                await self.supabase.set_chat_status(str(chat_id), "ready")
                return await self.start_chat(message, chat_id)
            
        await self.supabase.add_message(message, chat_id)
        return await self.chat_manager.send_human_input(str(chat_id), message.content or "\n")  # Convert to string