# auth.py - JWT authentication helpers
import os
from datetime import datetime, timedelta
from typing import Optional
import jwt
import bcrypt
from fastapi import HTTPException, status
from uuid import UUID, NAMESPACE_URL, uuid5

# JWT Configuration
SECRET_KEY = os.getenv("JWT_SECRET", "your-secret-key-change-this-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_DAYS = 7


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against a hashed password"""
    try:
        # Check if the password is already a bytes object or string
        if isinstance(hashed_password, str):
            hashed_password = hashed_password.encode('utf-8')
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password)
    except Exception:
        return False


def get_password_hash(password: str) -> str:
    """Hash a password using bcrypt"""
    # Bcrypt has a 72-byte limit, ensure we don't exceed it
    password_bytes = password.encode('utf-8')
    if len(password_bytes) > 72:
        # Truncate to 72 bytes to prevent bcrypt errors
        password_bytes = password_bytes[:72]
    
    # Generate salt and hash password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    # Return as string for database storage
    return hashed.decode('utf-8')


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_token(token: str) -> dict:
    """Verify and decode a JWT token (local JWT first, then optional OIDC/Keycloak JWT)."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
        )
    except jwt.InvalidTokenError:
        # Optional OIDC fallback (Keycloak, etc.)
        issuer = (os.getenv("OIDC_ISSUER_URL") or "").strip().rstrip("/")
        if not issuer:
            keycloak_url = (os.getenv("KEYCLOAK_URL") or "").strip().rstrip("/")
            keycloak_realm = (os.getenv("KEYCLOAK_REALM") or "").strip().strip("/")
            if keycloak_url and keycloak_realm:
                issuer = f"{keycloak_url}/realms/{keycloak_realm}"
        if not issuer:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
            )

        jwks_url = f"{issuer}/protocol/openid-connect/certs"
        audience = (os.getenv("OIDC_AUDIENCE") or os.getenv("KEYCLOAK_CLIENT_ID") or "").strip()
        verify_aud = bool(audience)
        try:
            jwk_client = jwt.PyJWKClient(jwks_url)
            signing_key = jwk_client.get_signing_key_from_jwt(token)
            try:
                payload = jwt.decode(
                    token,
                    signing_key.key,
                    algorithms=["RS256", "RS384", "RS512"],
                    audience=audience if verify_aud else None,
                    issuer=issuer,
                    options={"verify_aud": verify_aud},
                )
            except jwt.InvalidAudienceError:
                # Some Keycloak setups put the client in `azp` but not in `aud`.
                payload = jwt.decode(
                    token,
                    signing_key.key,
                    algorithms=["RS256", "RS384", "RS512"],
                    issuer=issuer,
                    options={"verify_aud": False},
                )
                if audience and payload.get("azp") != audience:
                    raise

            # Normalize identity fields expected by existing backend code.
            subject = str(payload.get("sub") or "")
            if not payload.get("id"):
                try:
                    payload["id"] = str(UUID(subject))
                except Exception:
                    # Stable UUID mapping for non-UUID OIDC subject values.
                    payload["id"] = str(uuid5(NAMESPACE_URL, f"oidc:{subject}"))

            if not payload.get("email"):
                payload["email"] = payload.get("preferred_username") or f"user_{payload['id']}@oidc.local"

            return payload
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
            )