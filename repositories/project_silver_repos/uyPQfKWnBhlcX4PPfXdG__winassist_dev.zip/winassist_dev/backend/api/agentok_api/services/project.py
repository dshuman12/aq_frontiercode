# routers/projects.py - New projects router
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from datetime import datetime

from .database import DatabaseClient
from ..dependencies import get_database_client, get_current_user

logger = logging.getLogger(__name__)
router = APIRouter()


class ProjectBase(BaseModel):
    name: str
    description: Optional[str] = None
    flow: Optional[dict] = None


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    flow: Optional[dict] = None


class Project(ProjectBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


@router.get('/', response_model=List[Project], summary="Get all projects")
async def get_projects(
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get all projects for the current user
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            projects = await conn.fetch(
                """
                SELECT id, user_id, name, description, flow, created_at, updated_at
                FROM projects
                WHERE user_id = $1
                ORDER BY updated_at DESC
                """,
                current_user["id"]
            )
            
            return [dict(project) for project in projects]
    
    except Exception as e:
        logger.error(f"Get projects error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get projects: {str(e)}"
        )


@router.post('/', response_model=Project, summary="Create new project")
async def create_project(
    project_data: ProjectCreate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Create a new project
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            project = await conn.fetchrow(
                """
                INSERT INTO projects (user_id, name, description, flow, created_at, updated_at)
                VALUES ($1, $2, $3, $4, NOW(), NOW())
                RETURNING id, user_id, name, description, flow, created_at, updated_at
                """,
                current_user["id"],
                project_data.name,
                project_data.description,
                project_data.flow
            )
            
            return dict(project)
    
    except Exception as e:
        logger.error(f"Create project error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create project: {str(e)}"
        )


@router.get('/{project_id}', response_model=Project, summary="Get project by ID")
async def get_project(
    project_id: int,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get a specific project by ID
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            project = await conn.fetchrow(
                """
                SELECT id, user_id, name, description, flow, created_at, updated_at
                FROM projects
                WHERE id = $1 AND user_id = $2
                """,
                project_id,
                current_user["id"]
            )
            
            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )
            
            return dict(project)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get project error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get project: {str(e)}"
        )


@router.post('/{project_id}', response_model=Project, summary="Update project")
async def update_project(
    project_id: int,
    project_data: ProjectUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Update an existing project
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            # Build dynamic update query
            updates = []
            values = []
            param_count = 1
            
            if project_data.name is not None:
                updates.append(f"name = ${param_count}")
                values.append(project_data.name)
                param_count += 1
            
            if project_data.description is not None:
                updates.append(f"description = ${param_count}")
                values.append(project_data.description)
                param_count += 1
            
            if project_data.flow is not None:
                updates.append(f"flow = ${param_count}")
                values.append(project_data.flow)
                param_count += 1
            
            if not updates:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="No fields to update"
                )
            
            updates.append("updated_at = NOW()")
            values.extend([project_id, current_user["id"]])
            
            query = f"""
                UPDATE projects
                SET {', '.join(updates)}
                WHERE id = ${param_count} AND user_id = ${param_count + 1}
                RETURNING id, user_id, name, description, flow, created_at, updated_at
            """
            
            project = await conn.fetchrow(query, *values)
            
            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )
            
            return dict(project)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update project error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update project: {str(e)}"
        )


@router.delete('/{project_id}', summary="Delete project")
async def delete_project(
    project_id: int,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Delete a project
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            result = await conn.fetchrow(
                """
                DELETE FROM projects
                WHERE id = $1 AND user_id = $2
                RETURNING id
                """,
                project_id,
                current_user["id"]
            )
            
            if not result:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )
            
            return {"result": "success"}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete project error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete project: {str(e)}"
        )