from typing import Any, Dict, List


WHATSAPP_ICON_URL = "https://upload.wikimedia.org/wikipedia/commons/5/5e/WhatsApp_icon.png"


CONNECTOR_DEFINITIONS: List[Dict[str, Any]] = [
    {
        "connector_key": "whatsapp_meta_cloud",
        "channel_key": "whatsapp",
        "provider_key": "meta_cloud",
        "display_name": "WhatsApp",
        "description": "Guided connector for Meta WhatsApp Cloud API with runtime messaging, templates, flows, and health tooling.",
        "setup_route": "/integrations/whatsapp",
        "status_route": "/integrations/whatsapp",
        "icon_url": WHATSAPP_ICON_URL,
        "capabilities": {
            "inbound_webhook": True,
            "send_text": True,
            "send_media": True,
            "send_template": True,
            "send_flow": True,
            "flow_runtime": True,
            "analytics": True,
        },
    }
]


def list_connector_definitions() -> List[Dict[str, Any]]:
    return [dict(item) for item in CONNECTOR_DEFINITIONS]


def get_connector_definition(connector_key: str) -> Dict[str, Any]:
    key = str(connector_key or "").strip().lower()
    for item in CONNECTOR_DEFINITIONS:
        if str(item.get("connector_key") or "").strip().lower() == key:
            return dict(item)
    return {}


def get_whatsapp_connector_definition(provider_key: str = "meta_cloud") -> Dict[str, Any]:
    provider = str(provider_key or "meta_cloud").strip().lower()
    for item in CONNECTOR_DEFINITIONS:
        if item.get("channel_key") == "whatsapp" and str(item.get("provider_key") or "").strip().lower() == provider:
            return dict(item)
    return dict(CONNECTOR_DEFINITIONS[0])
