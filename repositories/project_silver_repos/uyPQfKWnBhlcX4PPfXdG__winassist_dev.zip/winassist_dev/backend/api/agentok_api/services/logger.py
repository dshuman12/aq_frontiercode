import sys
import logging
import asyncio
from typing import Optional
from contextlib import contextmanager
from io import StringIO
from .database import create_database_client, DatabaseClient

class DatabaseLogHandler(logging.Handler):
    def __init__(self, db: DatabaseClient, chat_id: int):
        super().__init__()
        self.db = db
        self.chat_id = chat_id
        
    def emit(self, record: logging.LogRecord):
        try:
            log_entry = {
                "chat_id": self.chat_id,
                "level": record.levelname.lower(),
                "message": self.format(record),
                "metadata": {
                    "filename": record.filename,
                    "lineno": record.lineno,
                    "funcName": record.funcName
                }
            }
            # Run async method in sync context
            asyncio.create_task(self._insert_log(log_entry))
        except Exception as e:
            print(f"Failed to write log to database: {e}", file=sys.__stderr__)
    
    async def _insert_log(self, log_entry):
        """Insert log entry asynchronously"""
        try:
            pool = await self.db.get_pool()
            async with pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO chat_logs (chat_id, level, message, metadata, created_at)
                    VALUES ($1, $2, $3, $4, NOW())
                    """,
                    log_entry["chat_id"],
                    log_entry["level"],
                    log_entry["message"],
                    log_entry.get("metadata")
                )
        except Exception as e:
            print(f"Failed to insert log: {e}", file=sys.__stderr__)

class StreamToLogger:
    def __init__(self, db: DatabaseClient, chat_id: int, level: str):
        self.db = db
        self.chat_id = chat_id
        self.level = level
        self.buffer = StringIO()

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            # Run async insert in background
            asyncio.create_task(self._insert_log(line))
    
    async def _insert_log(self, message: str):
        """Insert log entry asynchronously"""
        try:
            pool = await self.db.get_pool()
            async with pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO chat_logs (chat_id, level, message, created_at)
                    VALUES ($1, $2, $3, NOW())
                    """,
                    self.chat_id,
                    self.level,
                    message
                )
        except Exception as e:
            print(f"Failed to insert log: {e}", file=sys.__stderr__)
            
    def flush(self):
        pass

@contextmanager
def capture_output(chat_id: int):
    """Captures stdout and stderr, sending them to database logs table."""
    db = create_database_client()
    
    # Redirect stdout and stderr to our custom handlers
    stdout_logger = StreamToLogger(db, chat_id, "stdout")
    stderr_logger = StreamToLogger(db, chat_id, "stderr")
    
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = stdout_logger, stderr_logger
    
    try:
        yield
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr 