import os
from typing import Optional


def connector_credentials_secret() -> str:
    return (
        os.getenv("CONNECTOR_CREDENTIALS_SECRET")
        or os.getenv("WHATSAPP_CREDENTIALS_SECRET")
        or os.getenv("JWT_SECRET")
        or "winassist-connector-dev-secret"
    )


def mask_secret_hint(last4: Optional[str]) -> Optional[str]:
    if not last4:
        return None
    return f"********{last4}"
