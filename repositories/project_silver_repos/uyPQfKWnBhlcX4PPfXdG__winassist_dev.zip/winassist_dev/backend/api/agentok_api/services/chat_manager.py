import asyncio
import os
from asyncio import subprocess
import signal
import subprocess as sp
from fastapi import logger
from termcolor import colored
from dataclasses import dataclass
from typing import List, Dict, Optional
import ast
import sys
from ..models import LogCreate
from .database import DatabaseClient
from .output_parser import OutputParser

DEBUG = False


class ChatManager:
    def __init__(self, supabase: DatabaseClient):
        self._subprocesses = {}
        self.supabase = supabase

    def _debug_print(self, message: str, color: Optional[str] = None):
        if not DEBUG:
            return
        if color:
            print(colored(message, color))
        else:
            print(message)

    def _wrap_subprocess(self, proc: sp.Popen):
        """Wrap subprocess.Popen to be async-compatible on Windows"""
        class AsyncSubprocessWrapper:
            def __init__(self, proc):
                self._proc = proc
                self.pid = proc.pid
                self.stdin = proc.stdin
                self.stdout = proc.stdout
                self.stderr = proc.stderr
                self.returncode = proc.returncode
                
            async def wait(self):
                """Wait for process to complete"""
                while self._proc.poll() is None:
                    await asyncio.sleep(0.1)
                self.returncode = self._proc.returncode
                return self.returncode
                
            def poll(self):
                """Check if process is still running"""
                return self._proc.poll()
                
            def terminate(self):
                """Terminate the process"""
                self._proc.terminate()
                
            def kill(self):
                """Kill the process"""
                self._proc.kill()
                
            async def __aiter__(self):
                """Make stdout iterable"""
                return self
                
            async def __anext__(self):
                """Read next line from stdout"""
                if self._proc.poll() is not None:
                    raise StopAsyncIteration
                line = await asyncio.get_event_loop().run_in_executor(
                    None, self._proc.stdout.readline
                )
                if not line:
                    raise StopAsyncIteration
                return line
                
        return AsyncSubprocessWrapper(proc)

    async def _process_output_line(self, response_message: str, output_parser, chat_id: str, on_message):
        """Process a single output line from the subprocess"""
        if DEBUG:
            try:
                await self.supabase.add_log(
                    LogCreate(message=response_message, level="info", chat_id=chat_id)
                )
            except Exception as e:
                logger.error(f"Failed to log message: {e}")

        # Parse line
        try:
            output_parser.parse_line(response_message)
        except Exception as e:
            self._debug_print(f"[ChatManager] Output parser error: {e}", "red")
            await self._safe_send(on_message, {"type": "assistant", "content": response_message})

        # Update chat status
        try:
            new_status = output_parser.get_chat_status(response_message)
            if new_status:
                await self.supabase.set_chat_status(chat_id, new_status)
        except Exception as e:
            self._debug_print(f"[ChatManager] Status update error: {e}", "red")

        # Auto-send "exit" when agent waits for human input so the conversation ends with the final reply
        if "__STATUS_WAIT_FOR_HUMAN_INPUT__" in response_message:
            self._debug_print("[ChatManager] Auto-sending 'exit' to complete conversation", "cyan")
            asyncio.create_task(self.send_human_input(chat_id, "exit"))

    async def _print_message(self, message):
        self._debug_print(f"New message received: {message}")

    async def _safe_send(self, on_message, payload):
        """Safely call on_message whether it's async, sync, or None."""
        if on_message is None:
            return
        try:
            if asyncio.iscoroutinefunction(on_message):
                await on_message(payload)
            else:
                on_message(payload)
        except Exception as e:
            self._debug_print(f"[ChatManager] Error in on_message: {e}", "red")

    def strip_prefix(self, input_string, substrings):
        for substring in substrings:
            if substring in input_string:
                index = input_string.find(substring)
                return input_string[index:]
        return input_string

    async def run_assistant(
        self, chat_id: str, message: str, source_path: str, on_message=None
    ):
        """
        Launch an assistant subprocess that executes the generated agent script.
        Streams stdout and forwards messages via `on_message`.
        """
        # Ensure chat_id is always a string for consistent dictionary key lookup
        chat_id = str(chat_id)
        
        if on_message is None:
            on_message = self._print_message

        command = [sys.executable, "-u", source_path, f"{message}"]
        self._debug_print(f"[ChatManager] Launching agent: {' '.join(command)}", "yellow")
        script_dir = os.path.dirname(os.path.abspath(source_path))
        self._debug_print(f"[CHAT] Script cwd will be: {script_dir} (look for [TOOL_LOAD]/[TOOL_REG] in output to verify tool registration)", "cyan")

        env = os.environ.copy()
        api_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        existing_pythonpath = env.get("PYTHONPATH", "").strip()
        env["PYTHONPATH"] = api_dir if not existing_pythonpath else os.pathsep.join([api_dir, existing_pythonpath])
        # Force UTF-8 stdio for child agent process on Windows.
        # This prevents UnicodeEncodeError (e.g., emoji in model replies) that can suppress output parsing.
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        
        # Set working directory to the temp directory where the script is located
        # Set OAI_CONFIG_LIST environment variable to point to the config file in the script directory
        oai_config_in_script_dir = os.path.join(script_dir, "OAI_CONFIG_LIST.json")
        if os.path.exists(oai_config_in_script_dir):
            env["OAI_CONFIG_LIST"] = oai_config_in_script_dir
            self._debug_print(f"[ChatManager] Set OAI_CONFIG_LIST env var to: {oai_config_in_script_dir}", "cyan")

        # Terminate old process if one exists for this chat_id
        if chat_id in self._subprocesses:
            self._debug_print(
                f"[ChatManager] Existing subprocess found for chat_id={chat_id}, terminating it...",
                "yellow",
            )
            old_process_info = self._subprocesses[chat_id]
            old_process = old_process_info["process"]
            old_process.terminate()
            await old_process.wait()

        await self.supabase.set_chat_status(chat_id, "running")

        # On Windows, use subprocess.Popen directly due to ProactorEventLoop limitations
        # On Unix, use asyncio.create_subprocess_exec
        if sys.platform == "win32":
            # Use subprocess.Popen on Windows and wrap it to be async-compatible
            try:
                proc = sp.Popen(
                    command,
                    env=env,
                    stdout=sp.PIPE,
                    stdin=sp.PIPE,
                    stderr=sp.PIPE,
                    text=False,  # Use bytes mode for consistency
                    bufsize=0,  # Unbuffered
                    cwd=script_dir,  # Set working directory to script location
                )
                # Create a wrapper to make it async-compatible
                process = self._wrap_subprocess(proc)
            except Exception as e:
                self._debug_print(f"[ChatManager] Failed to create subprocess on Windows: {e}", "red")
                await self.supabase.set_chat_status(chat_id, "failed")
                return {"error": f"Failed to start assistant: {str(e)}"}
        else:
            process = await asyncio.create_subprocess_exec(
                *command,
                env=env,
                stdout=subprocess.PIPE,
                stdin=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=script_dir,  # Set working directory to script location
            )

        self._debug_print(f"[ChatManager] Spawned PID={process.pid}", "magenta")
        self._subprocesses[chat_id] = {"process": process, "stdin": process.stdin}

        # Create output parser with callback
        # The OutputParser will handle async callbacks internally via _safe_call_on_message
        output_parser = OutputParser(on_message=on_message)
        # Store parser reference to check for summary later
        self._subprocesses[chat_id]["parser"] = output_parser

        # Continuously read stdout
        # On Windows with wrapped subprocess, read using executor
        if sys.platform == "win32" and hasattr(process, '_proc'):
            # Read from wrapped subprocess using executor in a loop
            while True:
                if process._proc.poll() is not None:
                    # Process ended, read any remaining output
                    try:
                        remaining = await asyncio.get_event_loop().run_in_executor(
                            None, process._proc.stdout.read
                        )
                        if remaining:
                            for line in remaining.split(b'\n'):
                                if line:
                                    try:
                                        response_message = line.decode('utf-8', errors='replace').rstrip()
                                    except:
                                        response_message = line.decode('utf-8', errors='ignore').rstrip()
                                    self._debug_print(f"[ChatManager] STDOUT: {response_message}", "blue")
                                    await self._process_output_line(response_message, output_parser, chat_id, on_message)
                    except Exception as e:
                        self._debug_print(f"[ChatManager] Error reading remaining output: {e}", "red")
                        import traceback
                        traceback.print_exc()
                    break
                
                # Read a line
                try:
                    line = await asyncio.get_event_loop().run_in_executor(
                        None, process._proc.stdout.readline
                    )
                    if not line:
                        await asyncio.sleep(0.1)
                        continue
                    
                    # Decode with error handling to handle invalid UTF-8 bytes
                    if isinstance(line, bytes):
                        try:
                            response_message = line.decode('utf-8', errors='replace').rstrip()
                        except Exception as decode_error:
                            # Fallback: try with different encoding or use raw bytes
                            try:
                                response_message = line.decode('latin-1', errors='replace').rstrip()
                            except:
                                response_message = line.decode('utf-8', errors='ignore').rstrip()
                    else:
                        response_message = line.rstrip()
                    
                    self._debug_print(f"[ChatManager] STDOUT: {response_message}", "blue")
                    await self._process_output_line(response_message, output_parser, chat_id, on_message)
                except Exception as e:
                    self._debug_print(f"[ChatManager] Error reading stdout: {e}", "red")
                    import traceback
                    traceback.print_exc()
                    # Don't break on decode errors, continue reading
                    continue
        else:
            # Standard async subprocess reading
            async for line in process.stdout:
                if not line:
                    continue
                try:
                    if isinstance(line, bytes):
                        response_message = line.decode('utf-8', errors='replace').rstrip()
                    else:
                        response_message = line.rstrip()
                    self._debug_print(f"[ChatManager] STDOUT: {response_message}", "blue")
                    await self._process_output_line(response_message, output_parser, chat_id, on_message)
                except Exception as e:
                    self._debug_print(f"[ChatManager] Error processing line: {e}", "red")
                    continue

        # Wait for process to exit
        returncode = await process.wait()
        self._debug_print(f"[ChatManager] Process exited with code {returncode}", "cyan")

        # Cleanup
        self._subprocesses.pop(chat_id, None)

        # Final chat status
        # Update returncode in case it wasn't updated in wait()
        if hasattr(process, 'returncode') and process.returncode is not None:
            returncode = process.returncode
            
        # Check if process was terminated (SIGTERM on Unix)
        # On Windows, termination detection is handled in abort_assistant
        if sys.platform != "win32" and returncode == -signal.SIGTERM:
            self._debug_print(f"[ChatManager] Assistant terminated by user", "yellow")
            await self.supabase.set_chat_status(chat_id, "aborted")
            await self._safe_send(on_message, {"type": "assistant", "content": "__STATUS_COMPLETED__ TERMINATED"})

        elif returncode != 0:
            await self.supabase.set_chat_status(chat_id, "failed")

            if process.stderr is not None:
                # On Windows with wrapped subprocess, stderr is a regular file-like object
                if sys.platform == "win32" and hasattr(process, '_proc'):
                    err = await asyncio.get_event_loop().run_in_executor(
                        None, process._proc.stderr.read
                    )
                else:
                    err = await process.stderr.read()
                error_message = err.decode().strip() if isinstance(err, bytes) else err.strip()
                self._debug_print(f"[ChatManager] Assistant exited with error:\n{error_message}", "red")
                last_line = error_message.splitlines()[-1] if error_message else "Unknown error"
                await self._safe_send(on_message, {
                    "type": "assistant",
                    "content": (
                        "Assistant failed before generating a reply. "
                        f"Runtime error: {last_line}"
                    ),
                })
        else:
            await self.supabase.set_chat_status(chat_id, "completed")
            
            # Check if summary was generated, if not, use last assistant message as summary
            parser = self._subprocesses.get(chat_id, {}).get("parser")
            if parser and not parser.has_summary and parser.last_assistant_message:
                # Create summary from last assistant message
                last_msg = parser.last_assistant_message
                self._debug_print(f"[ChatManager] No summary found, using last assistant message as summary", "yellow")
                await self._safe_send(on_message, {
                    "type": "summary",
                    "content": last_msg.get("content", ""),
                    "answer": last_msg.get("content", ""),
                    "metadata": {
                        "summary": last_msg.get("content", ""),
                        "sender": last_msg.get("sender"),
                        "receiver": last_msg.get("receiver"),
                        "from_last_message": True  # Flag to indicate this was created from last message
                    },
                })
            
            await self._safe_send(on_message, {"type": "assistant", "content": "__STATUS_COMPLETED__ DONE"})

        self._debug_print(f"[ChatManager] Cleaned up chat_id={chat_id}", "green")

    async def send_human_input(self, chat_id: str, user_input: str):
        # Ensure chat_id is always a string for consistent dictionary key lookup
        chat_id = str(chat_id)
        proc_info = self._subprocesses.get(chat_id)
        if not proc_info:
            return {"error": f"No assistant found with that chat ID: {chat_id}"}

        try:
            self._debug_print(f"[ChatManager] 👤 Sending human input: {user_input}", "cyan")
            proc_info["stdin"].write(user_input.encode() + b"\n")
            await proc_info["stdin"].drain()
            await self.supabase.set_chat_status(chat_id, "running")
            return {"detail": "Input sent to assistant."}
        except Exception as e:
            return {"error": str(e)}

    async def abort_assistant(self, chat_id: str):
        # Ensure chat_id is always a string for consistent dictionary key lookup
        chat_id = str(chat_id)
        proc_info = self._subprocesses.get(chat_id)
        if not proc_info:
            # Process not found - check if status needs to be reset
            self._debug_print(f"[ChatManager] No assistant found for chat_id={chat_id}", "yellow")
            self._debug_print(f"[ChatManager] Available chat_ids: {list(self._subprocesses.keys())}", "yellow")
            
            # Reset chat status if it's stuck in wait_for_human_input or running
            try:
                chat = await self.supabase.fetch_chat(int(chat_id))
                chat_status = chat.status.lower() if chat.status else "ready"
                if chat_status in ["wait_for_human_input", "running"]:
                    self._debug_print(f"[ChatManager] Resetting chat status from {chat_status} to ready", "cyan")
                    await self.supabase.set_chat_status(chat_id, "ready")
                    return {"detail": f"Chat {chat_id} status reset to ready (process was already terminated)"}
            except Exception as e:
                self._debug_print(f"[ChatManager] Error checking/resetting chat status: {e}", "red")
            
            return {"detail": f"No assistant process found for chat {chat_id} (may have already terminated)"}

        process = proc_info["process"]
        self._debug_print(f"[ChatManager] Terminating PID={process.pid}", "cyan")

        try:
            process.terminate()

            try:
                await asyncio.wait_for(process.wait(), timeout=5.0)
                detail = f"Assistant for chat {chat_id} terminated gracefully."
            except asyncio.TimeoutError:
                self._debug_print(
                    f"[ChatManager] Process {process.pid} did not exit gracefully, force killing.",
                    "yellow",
                )
                if os.name != "nt":
                    os.kill(process.pid, signal.SIGKILL)
                else:
                    os.system(f"taskkill /F /T /PID {process.pid}")
                await process.wait()
                detail = f"Assistant for chat {chat_id} forcefully terminated."

            return {"detail": detail}
        except Exception as e:
            return {"error": f"Error terminating assistant: {str(e)}"}
        finally:
            self._subprocesses.pop(chat_id, None)
            self._debug_print(f"[ChatManager] Cleaned up chat_id={chat_id} after termination", "green")
            await self.supabase.set_chat_status(chat_id, "ready")
