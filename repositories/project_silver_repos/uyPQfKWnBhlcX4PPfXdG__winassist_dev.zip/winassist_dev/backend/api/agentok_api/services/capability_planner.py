import re
from typing import Any, Dict


class CapabilityPlannerService:
    """Lightweight query-to-capability planner for runtime tool guidance."""

    WRITE_HINTS = {
        "create", "update", "delete", "remove", "write", "send", "post",
        "patch", "put", "insert", "drop", "modify", "change",
    }

    READ_HINTS = {
        "get", "fetch", "read", "list", "find", "search", "lookup", "show",
        "view", "retrieve",
    }

    def _tokenize(self, text: str) -> set[str]:
        return {
            token
            for token in re.findall(r"[a-zA-Z0-9_]+", (text or "").lower())
            if len(token) > 1
        }

    def _infer_risk_level(self, capability: Dict[str, Any]) -> str:
        text = " ".join(
            filter(
                None,
                [
                    capability.get("name"),
                    capability.get("func_name"),
                    capability.get("description"),
                ],
            )
        ).lower()
        if any(hint in text for hint in self.WRITE_HINTS):
            return "high"
        if any(hint in text for hint in self.READ_HINTS):
            return "low"
        return "medium"

    def build_capabilities(self, tool_dict: Dict[Any, Dict[str, Any]]) -> Dict[Any, Dict[str, Any]]:
        capabilities: Dict[Any, Dict[str, Any]] = {}
        for tool_id, tool in (tool_dict or {}).items():
            signatures = tool.get("signatures") or []
            parameter_names = [sig.get("name") for sig in signatures if sig.get("name")]
            capability = {
                "tool_id": tool_id,
                "name": tool.get("name") or tool.get("func_name") or f"tool_{tool_id}",
                "func_name": tool.get("func_name") or tool.get("name") or f"tool_{tool_id}",
                "description": tool.get("description") or "",
                "parameter_names": parameter_names,
            }
            capability["risk_level"] = self._infer_risk_level(capability)
            capabilities[tool_id] = capability
        return capabilities

    def _score_capability(self, query_tokens: set[str], capability: Dict[str, Any]) -> tuple[int, list[str]]:
        score = 0
        reasons: list[str] = []

        name_tokens = self._tokenize(capability.get("name", ""))
        func_tokens = self._tokenize(capability.get("func_name", ""))
        desc_tokens = self._tokenize(capability.get("description", ""))
        param_tokens = {token for name in capability.get("parameter_names", []) for token in self._tokenize(name)}

        name_overlap = query_tokens & (name_tokens | func_tokens)
        desc_overlap = query_tokens & desc_tokens
        param_overlap = query_tokens & param_tokens

        if name_overlap:
            score += len(name_overlap) * 3
            reasons.append("name/function match: " + ", ".join(sorted(name_overlap)))
        if desc_overlap:
            score += len(desc_overlap) * 2
            reasons.append("description match: " + ", ".join(sorted(desc_overlap)))
        if param_overlap:
            score += len(param_overlap)
            reasons.append("parameter match: " + ", ".join(sorted(param_overlap)))

        if score == 0 and capability.get("risk_level") == "high":
            reasons.append("high-risk tool with weak semantic match")

        return score, reasons

    def _confidence(self, top_score: int) -> str:
        if top_score >= 5:
            return "high"
        if top_score >= 2:
            return "medium"
        return "low"

    def plan_for_query(
        self,
        user_query: str,
        tool_dict: Dict[Any, Dict[str, Any]],
        tool_assignments: Dict[Any, Dict[str, Any]],
    ) -> Dict[str, Any]:
        query = (user_query or "").strip()
        if not query or not tool_dict or not tool_assignments:
            return {
                "query": query,
                "guidance_by_caller": {},
                "capabilities": {},
            }

        capabilities = self.build_capabilities(tool_dict)
        query_tokens = self._tokenize(query)
        guidance_by_caller: Dict[str, str] = {}
        ranked_by_caller: Dict[str, list[Dict[str, Any]]] = {}
        confidence_by_caller: Dict[str, str] = {}
        approval_required_by_caller: Dict[str, bool] = {}

        assignments_by_caller: Dict[str, list[Dict[str, Any]]] = {}
        for key, assignment in tool_assignments.items():
            if assignment.get("is_websurfer"):
                continue
            tool_id = key[0] if isinstance(key, tuple) else key
            caller = str(assignment.get("caller"))
            capability = capabilities.get(tool_id)
            if not capability:
                continue
            assignments_by_caller.setdefault(caller, []).append(capability)

        for caller, caller_capabilities in assignments_by_caller.items():
            ranked = []
            for capability in caller_capabilities:
                score, reasons = self._score_capability(query_tokens, capability)
                ranked.append({
                    **capability,
                    "score": score,
                    "reasons": reasons,
                })

            ranked.sort(key=lambda item: (item["score"], item["risk_level"] == "low"), reverse=True)
            top_ranked = ranked[:5]
            top_score = top_ranked[0]["score"] if top_ranked else 0
            confidence = self._confidence(top_score)
            approval_required = any(
                item["risk_level"] == "high" and item["score"] > 0 for item in top_ranked[:2]
            )

            lines = [
                f"Planner guidance for the current user request: {query}",
                f"Planner confidence: {confidence}. Prefer the highest-ranked relevant tool. If the match is weak or ambiguous, ask a clarification question before taking action.",
                "Ranked capability candidates:",
            ]
            for item in top_ranked:
                reason_text = "; ".join(item["reasons"]) if item["reasons"] else "weak semantic match"
                lines.append(
                    f"- {item['func_name']} (risk: {item['risk_level']}, score: {item['score']}): {reason_text}"
                )
            if approval_required:
                lines.append("Planner policy: a high-risk capability is among the best matches. Require explicit user intent and ask for clarification before execution if any detail is missing.")
            elif any(item["risk_level"] == "high" for item in top_ranked):
                lines.append("For high-risk tools, do not execute unless the user intent is explicit and complete.")
            if confidence == "low":
                lines.append("Planner action: do not guess. Ask a clarification question before using any tool.")
            elif confidence in {"high", "medium"} and top_ranked and top_ranked[0]["score"] > 0:
                lines.append(f"Planner action: first attempt tool `{top_ranked[0]['func_name']}` before drafting the final response.")
                if len(top_ranked) > 1 and top_ranked[1]["score"] > 0:
                    lines.append(
                        f"Multi-tool chain hint: if needed, run `{top_ranked[0]['func_name']}` then `{top_ranked[1]['func_name']}`."
                    )

            lines.append(
                "Final response schema (Markdown):\n"
                "## Result\n"
                "<direct answer>\n\n"
                "## Actions Taken\n"
                "- <tool(s) used or 'none'>\n\n"
                "## Notes\n"
                "- <assumptions or missing info, if any>"
            )

            guidance_by_caller[caller] = "\n".join(lines)
            ranked_by_caller[caller] = [
                {
                    "tool_id": item["tool_id"],
                    "name": item["name"],
                    "func_name": item["func_name"],
                    "risk_level": item["risk_level"],
                    "score": item["score"],
                    "reasons": item["reasons"],
                }
                for item in top_ranked
            ]
            confidence_by_caller[caller] = confidence
            approval_required_by_caller[caller] = approval_required

        return {
            "query": query,
            "guidance_by_caller": guidance_by_caller,
            "ranked_by_caller": ranked_by_caller,
            "confidence_by_caller": confidence_by_caller,
            "approval_required_by_caller": approval_required_by_caller,
            "capabilities": capabilities,
        }
