import asyncio
from typing import Dict, List, Literal, Optional
import logging
import os
import jwt

import asyncpg
from dotenv import load_dotenv
from fastapi import HTTPException, status
from termcolor import colored

from ..models import (
    ApiKey,
    ApiKeyCreate,
    Chat,
    ChatCreate,
    LogCreate,
    Log,
    Message,
    MessageCreate,
    Tool,
)

logger = logging.getLogger(__name__)

load_dotenv()  # Load environment variables from .env


class PostgresClient:
    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.db_host = os.environ.get("DB_HOST", "localhost")
            self.db_port = os.environ.get("DB_PORT", "5432")
            self.db_name = os.environ.get("postgres")
            self.db_user = os.environ.get("postgres")
            self.db_password = os.environ.get("SUREVIN%40123")
            self.jwt_secret = os.environ.get("adarsh")
            
            if not all([self.db_name, self.db_user, self.db_password]):
                raise Exception("Database credentials not found in environment variables")
            
            self.pool: Optional[asyncpg.Pool] = None
            self.user_id = None
            self._initialized = True

    @classmethod
    def reset(cls):
        """Reset the singleton instance"""
        if cls._instance is not None:
            if hasattr(cls._instance, 'pool') and cls._instance.pool:
                asyncio.create_task(cls._instance.pool.close())
            cls._instance = None
            cls._initialized = False

    async def get_pool(self) -> asyncpg.Pool:
        """Get or create database connection pool"""
        if self.pool is None:
            self.pool = await asyncpg.create_pool(
                host=self.db_host,
                port=int(self.db_port),
                database=self.db_name,
                user=self.db_user,
                password=self.db_password,
                min_size=5,
                max_size=20,
            )
        return self.pool

    async def close(self):
        """Close the database connection pool"""
        if self.pool:
            await self.pool.close()
            self.pool = None

    async def get_user(self) -> Optional[Dict]:
        """Get user information by user_id"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                user = await conn.fetchrow(
                    """
                    SELECT id, email, created_at, 
                           app_metadata, user_metadata
                    FROM users 
                    WHERE id = $1
                    """,
                    self.user_id
                )
                if user:
                    return dict(user)
                return None
        except Exception as e:
            logger.error(f"Failed to fetch user info: {e}")
            return None

    async def authenticate_with_token(self, access_token: str) -> dict:
        """Authenticate user with JWT token"""
        try:
            # Decode JWT token
            payload = jwt.decode(
                access_token, 
                self.jwt_secret, 
                algorithms=["HS256"]
            )
            
            self.user_id = payload.get("user_id") or payload.get("sub")
            
            # Fetch user from database
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                user = await conn.fetchrow(
                    "SELECT id, email, created_at FROM users WHERE id = $1",
                    self.user_id
                )
                
            if not user:
                raise HTTPException(status_code=401, detail="User not found")
                
            return dict(user)
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")
        except Exception as exc:
            logger.error(f"Authentication error: {exc}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="An error occurred during authentication",
            )

    async def authenticate_with_apikey(self, apikey: str) -> dict:
        """Authenticate user with API key"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                api_key_data = await conn.fetchrow(
                    "SELECT user_id FROM api_keys WHERE key = $1",
                    apikey
                )
                
                if not api_key_data:
                    raise HTTPException(status_code=401, detail="Invalid API key")
                
                self.user_id = api_key_data['user_id']
                
                user = await conn.fetchrow(
                    "SELECT id, email, created_at FROM users WHERE id = $1",
                    self.user_id
                )
                
                if not user:
                    raise HTTPException(status_code=401, detail="User not found")
                
                return dict(user)
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="An error occurred during authentication",
            )

    async def save_apikey(self, key_to_create: ApiKeyCreate) -> ApiKey:
        """Create a new API key"""
        try:
            key_data = key_to_create.model_dump()
            key_data["user_id"] = self.user_id
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO api_keys (user_id, key, name, created_at)
                    VALUES ($1, $2, $3, NOW())
                    RETURNING *
                    """,
                    key_data["user_id"],
                    key_data["key"],
                    key_data.get("name", "")
                )
                
                if row:
                    return ApiKey(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create API key",
                    )
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to create API key",
            )

    async def fetch_apikeys(self) -> List[ApiKey]:
        """Fetch all API keys for the current user"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    "SELECT * FROM api_keys WHERE user_id = $1",
                    self.user_id
                )
                return [ApiKey(**dict(row)) for row in rows]
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to retrieve API keys",
            )

    async def fetch_apikey(self, apikey_id: str) -> Optional[ApiKey]:
        """Fetch a specific API key"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT * FROM api_keys 
                    WHERE id = $1 AND user_id = $2
                    """,
                    apikey_id,
                    self.user_id
                )
                if row:
                    return ApiKey(**dict(row))
                return None
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to retrieve API key",
            )

    async def delete_apikey(self, apikey_id: str) -> Dict:
        """Delete an API key"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                result = await conn.execute(
                    """
                    DELETE FROM api_keys 
                    WHERE id = $1 AND user_id = $2
                    """,
                    apikey_id,
                    self.user_id
                )
                
                if result == "DELETE 1":
                    return {"message": f"Successfully deleted {apikey_id}"}
                else:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="API key not found",
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to delete API key",
            )

    async def fetch_general_settings(self) -> Dict:
        """Fetch user general settings"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT general FROM user_settings 
                    WHERE user_id = $1
                    """,
                    self.user_id
                )
                if row:
                    return row['general'] or {}
                return {}
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"An error occurred while fetching user settings (general): {exc}",
            )

    async def fetch_tool_settings(self) -> Dict:
        """Fetch user tool settings"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tools FROM user_settings 
                    WHERE user_id = $1
                    """,
                    self.user_id
                )
                if row and row['tools']:
                    return row['tools']
                return {}
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"An error occurred while fetching user settings (tools): {exc}",
            )

    async def fetch_chats(self) -> List[Chat]:
        """Fetch all chats for the current user"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT * FROM chats 
                    WHERE user_id = $1 
                    ORDER BY created_at DESC
                    """,
                    self.user_id
                )
                return [Chat(**dict(row)) for row in rows]
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to get chats for user {self.user_id}: {exc}",
            )

    async def fetch_chat(self, chat_id: str) -> Chat:
        """Fetch a specific chat"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT * FROM chats 
                    WHERE id = $1 AND user_id = $2
                    """,
                    int(chat_id),
                    self.user_id
                )
                if row:
                    return Chat(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND, 
                        detail="Chat not found"
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Chat not found: {exc}",
            )

    async def create_chat(self, chat_to_create: ChatCreate) -> Chat:
        """Create a new chat"""
        try:
            chat_data = chat_to_create.model_dump(exclude={"id"})
            chat_data["user_id"] = self.user_id
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chats (user_id, title, status, from_type, 
                                      from_project, from_template, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, NOW())
                    RETURNING *
                    """,
                    chat_data["user_id"],
                    chat_data.get("title", ""),
                    chat_data.get("status", "ready"),
                    chat_data.get("from_type"),
                    chat_data.get("from_project"),
                    chat_data.get("from_template")
                )

                if row:
                    return Chat(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create chat",
                    )
        except Exception as exc:
            logger.error(f"Failed to create chat: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to create chat: {exc}",
            )

    async def fetch_tools(self, tool_ids: Optional[List[int]] = None) -> List[Tool]:
        """Fetch tools (user's own or public tools)"""
        try:
            if not self.user_id:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found",
                )
            if not tool_ids or len(tool_ids) == 0:
                return []

            pool = await self.get_pool()
            async with pool.acquire() as conn:
                if tool_ids:
                    rows = await conn.fetch(
                        """
                        SELECT * FROM tools 
                        WHERE (user_id = $1 OR is_public = true)
                          AND id = ANY($2::int[])
                        """,
                        self.user_id,
                        tool_ids
                    )
                else:
                    rows = await conn.fetch(
                        """
                        SELECT * FROM tools 
                        WHERE user_id = $1 OR is_public = true
                        """,
                        self.user_id
                    )

                return [dict(row) for row in rows]
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed fetching tools: {exc}",
            )

    async def create_tool(self, tool_to_create: Tool) -> Tool:
        """Create a new tool"""
        try:
            tool_data = tool_to_create.model_dump(exclude={"id"})
            tool_data["user_id"] = self.user_id
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO tools (user_id, name, description, 
                                      schema, is_public, created_at)
                    VALUES ($1, $2, $3, $4, $5, NOW())
                    RETURNING *
                    """,
                    tool_data["user_id"],
                    tool_data.get("name", ""),
                    tool_data.get("description", ""),
                    tool_data.get("schema", {}),
                    tool_data.get("is_public", False)
                )
                
                if row:
                    return Tool(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create tool",
                    )
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to create tool: {exc}",
            )

    async def fetch_tool(self, tool_id: str) -> Tool:
        """Fetch a specific tool"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM tools WHERE id = $1",
                    int(tool_id)
                )
                if row:
                    return Tool(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND, 
                        detail="Tool not found"
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tool not found: {exc}",
            )

    async def update_tool(self, tool_to_update: Tool) -> Tool:
        """Update an existing tool"""
        try:
            tool_data = tool_to_update.model_dump()
            tool_id = tool_data.pop("id")
            if not tool_id:
                raise Exception("Invalid tool_id")
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    UPDATE tools 
                    SET name = $2, description = $3, schema = $4, 
                        is_public = $5, updated_at = NOW()
                    WHERE id = $1 AND user_id = $6
                    RETURNING *
                    """,
                    tool_id,
                    tool_data.get("name"),
                    tool_data.get("description"),
                    tool_data.get("schema"),
                    tool_data.get("is_public", False),
                    self.user_id
                )
                
                if row:
                    return dict(row)
                else:
                    raise Exception("Tool not found or unauthorized")
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise

    async def delete_tool(self, tool_id: str) -> Dict:
        """Delete a tool"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                result = await conn.execute(
                    """
                    DELETE FROM tools 
                    WHERE id = $1 AND user_id = $2
                    """,
                    int(tool_id),
                    self.user_id
                )
                
                if result == "DELETE 1":
                    return {"message": f"Tool {tool_id} deleted successfully"}
                else:
                    raise Exception(f"Error deleting tool {tool_id}")
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise

    async def fetch_messages(self, chat_id: str) -> List[Message]:
        """Fetch all messages for a chat"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT * FROM chat_messages 
                    WHERE chat_id = $1 
                    ORDER BY created_at ASC
                    """,
                    int(chat_id)
                )
                return [Message(**dict(row)) for row in rows]
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed fetching messages: {exc}",
            )

    async def add_message(self, message: MessageCreate, chat_id: str) -> Message:
        """Add a new message to a chat"""
        try:
            message_dict = message.model_dump(exclude={"id"})
            message_dict["user_id"] = self.user_id
            message_dict["chat_id"] = int(chat_id)
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_messages (chat_id, sender, receiver, 
                                              content, type, user_id, meta, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
                    RETURNING *
                    """,
                    message_dict["chat_id"],
                    message_dict.get("sender"),
                    message_dict.get("receiver"),
                    message_dict.get("content"),
                    message_dict.get("type"),
                    message_dict["user_id"],
                    message_dict.get("meta")
                )
                return Message(**dict(row))
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to add message: {exc}",
            )

    async def add_log(self, log: LogCreate) -> Optional[Dict]:
        """Add a log entry to the database"""
        try:
            log_data = {
                "message": log.message,
                "level": log.level,
                "metadata": log.metadata,
                "chat_id": int(log.chat_id) if isinstance(log.chat_id, str) else log.chat_id
            }
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_logs (chat_id, message, level, 
                                          metadata, created_at)
                    VALUES ($1, $2, $3, $4, NOW())
                    RETURNING *
                    """,
                    log_data["chat_id"],
                    log_data["message"],
                    log_data["level"],
                    log_data["metadata"]
                )
                
                if row:
                    print(colored(f"Added log for chat {log_data['chat_id']}", "green"))
                    return dict(row)
                
                print(colored(f"No response data from log insertion", "yellow"))
                return None
                
        except Exception as exc:
            logger.error(f"Failed to add log: {exc}")
            logger.error(f"Attempted log data: {log_data}")
            return None

    async def fetch_source_metadata(self, chat_id: str) -> Dict:
        """Fetch source metadata (project or template) for a chat"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Get chat
                chat = await conn.fetchrow(
                    """
                    SELECT * FROM chats 
                    WHERE id = $1 AND user_id = $2
                    """,
                    int(chat_id),
                    self.user_id
                )
                
                if not chat:
                    raise HTTPException(status_code=404, detail="Chat not found")
                
                chat = dict(chat)
                
                # Get source (project or template)
                if chat["from_type"] == "project":
                    source = await conn.fetchrow(
                        "SELECT * FROM projects WHERE id = $1",
                        chat["from_project"]
                    )
                elif chat["from_type"] == "template":
                    source = await conn.fetchrow(
                        "SELECT project FROM templates WHERE id = $1",
                        chat["from_template"]
                    )
                    if source:
                        return source["project"]
                else:
                    return {}
                
                return dict(source) if source else {}
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source metadata not found: {exc}",
            )

    async def set_chat_status(
        self,
        chat_id: str,
        chat_status: Literal[
            "ready", "running", "wait_for_human_input", "completed", "aborted", "failed"
        ],
    ) -> Optional[Dict]:
        """Set the status of a chat"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    UPDATE chats 
                    SET status = $2, updated_at = NOW()
                    WHERE id = $1 AND user_id = $3
                    RETURNING *
                    """,
                    int(chat_id),
                    chat_status,
                    self.user_id
                )
                
                if row:
                    return dict(row)
                else:
                    return None
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to set chat status: {exc}",
            )

    async def search_chunks(self, dataset_id: int, query_vector: List[float], top_k: int) -> List[Dict]:
        """Search for similar chunks using vector similarity"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT * FROM search_chunks_by_dataset($1, $2, $3)
                    """,
                    dataset_id,
                    query_vector,
                    top_k
                )
                print("search_chunks", rows)
                return [dict(row) for row in rows]
        except Exception as exc:
            logger.error(f"An error occurred: {exc}")
            raise


def create_postgres_client():
    """Factory function to create PostgresClient instance"""
    return PostgresClient()