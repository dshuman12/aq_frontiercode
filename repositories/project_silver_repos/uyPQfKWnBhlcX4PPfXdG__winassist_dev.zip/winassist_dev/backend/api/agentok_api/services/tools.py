from ..models import Tool, ToolCreate
from .database import DatabaseClient

class ToolService:
    def __init__(self, supabase: DatabaseClient):
        self.supabase = supabase

    async def get_tools(self):
        """Get all tools for current user"""
        return await self.supabase.fetch_tools()

    async def get_tool(self, tool_id: str):
        """Get a single tool by ID"""
        return await self.supabase.fetch_tool(tool_id)

    async def create_tool(self, tool: ToolCreate):
        """Create a new tool"""
        # Convert ToolCreate to Tool for database method
        tool_dict = tool.model_dump()
        tool_dict['id'] = 0  # Will be set by database
        tool_obj = Tool(**tool_dict)
        return await self.supabase.create_tool(tool_obj)

    async def update_tool(self, tool_id: str, tool: ToolCreate):
        """Update an existing tool"""
        existing_tool = await self.supabase.fetch_tool(tool_id)
        tool_dict = tool.model_dump()
        current_user_id = getattr(self.supabase, "user_id", None)
        is_owner = (
            current_user_id is not None
            and existing_tool.user_id is not None
            and str(existing_tool.user_id) == str(current_user_id)
        )

        if existing_tool.is_public and not is_owner:
            cloned_tool = Tool(
                id=0,
                name=tool_dict.get("name") or existing_tool.name,
                description=tool_dict.get("description") if tool_dict.get("description") is not None else existing_tool.description,
                variables=tool_dict.get("variables") or existing_tool.variables or [],
                code=tool_dict.get("code") if tool_dict.get("code") is not None else existing_tool.code,
                logo_url=existing_tool.logo_url,
                is_public=False,
            )
            return await self.supabase.create_tool(cloned_tool)

        tool_dict['id'] = existing_tool.id
        tool_obj = Tool(**tool_dict)
        return await self.supabase.update_tool(tool_obj)

    async def delete_tool(self, tool_id: str):
        """Delete a tool"""
        return await self.supabase.delete_tool(tool_id)