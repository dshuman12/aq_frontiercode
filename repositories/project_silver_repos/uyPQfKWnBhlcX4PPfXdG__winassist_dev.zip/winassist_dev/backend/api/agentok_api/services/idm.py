import os
from typing import Optional, TypedDict
from uuid import UUID

import httpx
from fastapi import HTTPException, status


class IDMIdentity(TypedDict, total=False):
    id: UUID
    email: str
    auth_type: str
    subject: str


def _uuid_from_env(name: str, default: str) -> UUID:
    value = (os.getenv(name) or "").strip() or default
    try:
        return UUID(value)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Invalid {name}; expected UUID",
        )


async def verify_idm_api_key(api_key: str) -> IDMIdentity:
    """
    Verify an IDM API key and return a normalized identity.

    Modes:
    - Remote verification: set IDM_VERIFY_URL to call your IDM introspection endpoint.
    - Static key (local dev / simple setup): set IDM_API_KEY (exact match).
    """
    api_key = (api_key or "").strip()
    if not api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing IDM API key")

    verify_url = (os.getenv("IDM_VERIFY_URL") or "").strip()
    if verify_url:
        timeout_s = float(os.getenv("IDM_VERIFY_TIMEOUT_SECONDS", "10"))
        header_name = (os.getenv("IDM_VERIFY_HEADER_NAME") or "X-Api-Key").strip()
        try:
            async with httpx.AsyncClient(timeout=timeout_s) as client:
                resp = await client.get(
                    verify_url,
                    headers={header_name: api_key},
                )
        except httpx.HTTPError:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="IDM verification failed (network error)",
            )

        if resp.status_code == 401 or resp.status_code == 403:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid IDM API key")
        if resp.status_code >= 400:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="IDM verification failed",
            )

        try:
            data = resp.json()
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="IDM verification returned non-JSON response",
            )

        # Expected (flexible) payload:
        # - user_id OR id OR sub (UUID string)
        # - email (optional)
        user_id_raw: Optional[str] = (
            data.get("user_id") or data.get("id") or data.get("sub") or data.get("subject")
        )
        if not user_id_raw:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="IDM verification response missing user id",
            )
        try:
            user_id = UUID(str(user_id_raw))
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="IDM verification returned invalid user id",
            )

        email = data.get("email")
        if not isinstance(email, str) or not email.strip():
            email = f"user_{user_id}@idm.local"

        return {
            "id": user_id,
            "email": email,
            "auth_type": "idm_api_key",
            "subject": str(user_id_raw),
        }

    # Static local key mode (no network call)
    expected = (os.getenv("IDM_API_KEY") or "").strip()
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="IDM is not configured (missing IDM_VERIFY_URL or IDM_API_KEY)",
        )
    if api_key != expected:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid IDM API key")

    user_id = _uuid_from_env("IDM_USER_ID", "00000000-0000-0000-0000-000000000001")
    email = (os.getenv("IDM_USER_EMAIL") or "").strip() or f"user_{user_id}@idm.local"
    return {"id": user_id, "email": email, "auth_type": "idm_api_key", "subject": "static"}

