import asyncio
from typing import Any, Dict, List, Literal, Optional
import logging
import os
import json
from uuid import UUID

import asyncpg
from dotenv import load_dotenv
from fastapi import HTTPException, status
import jwt
from datetime import datetime, timedelta
from ..utils.datetime import IST_TIMEZONE_NAME

from ..models import (
    ApiKey,
    ApiKeyCreate,
    Chat,
    ChatCreate,
    LogCreate,
    Log,
    Message,
    MessageCreate,
    Tool,
)

logger = logging.getLogger(__name__)


async def _configure_connection(connection: asyncpg.Connection) -> None:
    await connection.execute(f"SET TIME ZONE '{IST_TIMEZONE_NAME}'")


def _normalize_message_metadata(value: Any) -> Optional[Dict[str, Any]]:
    """chat_messages.meta may be dict (JSONB) or a legacy/double-encoded JSON string."""
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
            return {"value": parsed}
        except (json.JSONDecodeError, TypeError):
            return {"raw": value}
    return None


def _normalize_chat_config(value: Any) -> Optional[Dict[str, Any]]:
    """chats.config may be dict (JSONB) or a legacy/double-encoded JSON string."""
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            return None
    return None


def _is_uuid_like(s: str) -> bool:
    """Return True if s looks like a UUID (hex with optional dashes)."""
    if not s or not isinstance(s, str):
        return False
    s = s.strip()
    if len(s) == 36 and s.count("-") == 4:
        try:
            UUID(s)
            return True
        except (ValueError, TypeError):
            pass
    if len(s) == 32 and all(c in "0123456789abcdefABCDEF" for c in s):
        return True
    return False


def convert_user_id_to_uuid(user_id):
    """Convert user_id to UUID format, handling both int and UUID inputs"""
    if user_id is None:
        return None
    if isinstance(user_id, UUID):
        return user_id
    if isinstance(user_id, str):
        try:
            return UUID(user_id)
        except ValueError:
            return user_id  # Return as-is if not valid UUID
    if isinstance(user_id, int):
        # This shouldn't happen after migration, but handle it gracefully
        logger.warning(f"Received integer user_id {user_id}, this should be UUID after migration")
        # After migration, integer IDs should not exist
        # But if they do, we need to handle it - for now raise an error
        raise ValueError(f"Integer user_id {user_id} found - database migration may not be complete. Please ensure the migration script has been run.")
    return user_id


async def normalize_row_user_id_async(row_dict: dict, conn, user_id_key: str = 'user_id'):
    """Normalize user_id in a database row dictionary to UUID (async version for DB lookups)"""
    if user_id_key in row_dict and row_dict[user_id_key] is not None:
        user_id = row_dict[user_id_key]
        
        # If it's already a UUID object, keep it
        if isinstance(user_id, UUID):
            return row_dict
        
        # If it's a string, try to convert to UUID
        if isinstance(user_id, str):
            try:
                row_dict[user_id_key] = UUID(user_id)
                return row_dict
            except ValueError:
                # Not a valid UUID string - might be UUID object from asyncpg serialized as string
                pass
        
        # If it's an integer, this means the migration wasn't complete or column type is wrong
        if isinstance(user_id, int):
            logger.error(f"CRITICAL: Received integer user_id {user_id} from database. Migration may not be complete.")
            # After migration, integer IDs should not exist
            # We need to provide a clear error but also try to work around it temporarily
            # by setting it to None (which will cause validation to fail gracefully)
            logger.error(
                f"Database returned integer user_id {user_id} but UUID is expected. "
                f"This indicates the migration script may not have been run or completed successfully. "
                f"Please verify that: 1) The migration script has been executed, 2) All user_id columns are UUID type, "
                f"3) All data has been migrated from integer to UUID."
            )
            # Set to None to avoid immediate crash, but Pydantic will validate and provide error
            row_dict[user_id_key] = None
    
    return row_dict


def normalize_row_user_id(row_dict: dict, user_id_key: str = 'user_id'):
    """Normalize user_id in a database row dictionary to UUID (sync version)"""
    if user_id_key in row_dict and row_dict[user_id_key] is not None:
        try:
            row_dict[user_id_key] = convert_user_id_to_uuid(row_dict[user_id_key])
        except ValueError as e:
            logger.error(f"Failed to convert user_id: {e}")
            # If conversion fails and it's an integer, we can't look it up synchronously
            # Set to None to avoid validation error
            if isinstance(row_dict[user_id_key], int):
                logger.error(f"Integer user_id {row_dict[user_id_key]} cannot be converted - migration may not be complete")
                row_dict[user_id_key] = None
    return row_dict

load_dotenv()  # Load environment variables from .env


class DatabaseClient:
    _shared_pool: Optional[asyncpg.Pool] = None
    _pool_lock = None

    def __init__(self):
        self.database_url = os.environ.get("DATABASE_URL")
        self.jwt_secret = os.environ.get("JWT_SECRET", "your-secret-key-change-this")
        if not self.database_url:
            raise Exception("DATABASE_URL not found in environment variables")
        self.user_id = None
        self.current_user = None

    @classmethod
    def reset(cls):
        """Reset the shared connection pool."""
        if cls._shared_pool is not None:
            try:
                asyncio.create_task(cls._shared_pool.close())
            except Exception:
                pass
        cls._shared_pool = None
        cls._pool_lock = None

    async def get_pool(self) -> asyncpg.Pool:
        """Get or create connection pool with retries for slow/unavailable DB (universal across systems)."""
        cls = type(self)
        if cls._shared_pool is None:
            if cls._pool_lock is None:
                cls._pool_lock = asyncio.Lock()
            async with cls._pool_lock:
                if cls._shared_pool is not None:
                    return cls._shared_pool
                db_url = self.database_url.replace('postgresql://', 'postgres://') if self.database_url.startswith('postgresql://') else self.database_url
                # Keep defaults reasonably fast so API calls don't sit "Pending" for a long time
                # when Postgres is not running (common in local development).
                timeout_seconds = float(os.environ.get("DB_POOL_TIMEOUT", "5"))
                max_attempts = int(os.environ.get("DB_POOL_RETRIES", "2"))
                retry_delay = float(os.environ.get("DB_POOL_RETRY_DELAY", "1"))
                last_error = None
                for attempt in range(1, max_attempts + 1):
                    try:
                        cls._shared_pool = await asyncio.wait_for(
                            asyncpg.create_pool(
                                db_url,
                                min_size=2,
                                max_size=20,
                                command_timeout=30,
                                server_settings={
                                    'application_name': 'winassist_api',
                                    'timezone': IST_TIMEZONE_NAME,
                                },
                                init=_configure_connection,
                            ),
                            timeout=timeout_seconds,
                        )
                        if attempt > 1:
                            logger.info(f"Database pool created on attempt {attempt}")
                        return cls._shared_pool
                    except asyncio.TimeoutError as e:
                        last_error = e
                        logger.warning(
                            f"Database pool creation timed out (attempt {attempt}/{max_attempts}). "
                            f"Retrying in {retry_delay}s..."
                        )
                    except (ConnectionRefusedError, OSError) as e:
                        # Fast-fail on "connection refused" (Postgres down). Retrying just makes the UI hang.
                        last_error = e
                        msg = str(e).lower()
                        win_conn_refused = getattr(e, "winerror", None) == 10061
                        errno_conn_refused = getattr(e, "errno", None) in (111, 61, 10061)
                        if win_conn_refused or errno_conn_refused or "connect call failed" in msg or "connection refused" in msg:
                            logger.error(f"Database connection refused: {e}")
                            raise HTTPException(
                                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                                detail="Database is not reachable. Start Postgres (port 5432) or update DATABASE_URL.",
                            )
                        logger.warning(
                            f"Database pool creation failed (attempt {attempt}/{max_attempts}): {e}. "
                            f"Retrying in {retry_delay}s..."
                        )
                    except Exception as e:
                        last_error = e
                        logger.warning(
                            f"Database pool creation failed (attempt {attempt}/{max_attempts}): {e}. "
                            f"Retrying in {retry_delay}s..."
                        )
                    if attempt < max_attempts:
                        await asyncio.sleep(retry_delay)
                logger.error("Database pool creation failed after all retries")
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail=(
                        "Database connection failed. Check DATABASE_URL and that Postgres is running "
                        "(e.g. start the service or docker-compose db)."
                    ),
                )
        return cls._shared_pool

    async def close(self):
        """Close the connection pool"""
        cls = type(self)
        if cls._shared_pool:
            await cls._shared_pool.close()
            cls._shared_pool = None

    async def get_user(self) -> Dict:
        """Get user information by user_id"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Handle UUID conversion if needed
                user_id_param = self.user_id
                if isinstance(user_id_param, str):
                    from uuid import UUID
                    try:
                        user_id_param = UUID(user_id_param)
                    except ValueError:
                        pass  # Keep as string if not valid UUID
                
                user = await conn.fetchrow(
                    """
                    SELECT id, email, user_metadata, app_metadata, created_at
                    FROM persons 
                    WHERE id = $1
                    """,
                    user_id_param
                )
                
                if user:
                    user_dict = dict(user)
                    # Parse JSON fields if they're strings
                    if isinstance(user_dict.get('user_metadata'), str):
                        user_dict['user_metadata'] = json.loads(user_dict['user_metadata'])
                    if isinstance(user_dict.get('app_metadata'), str):
                        user_dict['app_metadata'] = json.loads(user_dict['app_metadata'])
                    return user_dict
                
                return None
        except Exception as e:
            logger.error(f"Failed to fetch user info: {e}")
            return None

    async def authenticate_with_tokens(self, access_token: str) -> Dict:
        """Authenticate user with JWT token"""
        try:
            # Decode JWT token
            payload = jwt.decode(
                access_token,
                self.jwt_secret,
                algorithms=["HS256"],
                options={"verify_exp": True}
            )
            
            user_id_from_token = payload.get("sub") or payload.get("user_id") or payload.get("id")
            
            if not user_id_from_token:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token: user_id not found"
                )
            
            # Convert to UUID - handle both string and integer cases
            from uuid import UUID
            if isinstance(user_id_from_token, UUID):
                self.user_id = user_id_from_token
            elif isinstance(user_id_from_token, str):
                try:
                    self.user_id = UUID(user_id_from_token)
                except ValueError:
                    # Not a valid UUID string, might be old format - try to look up
                    logger.warning(f"JWT token contains non-UUID string user_id: {user_id_from_token}")
                    self.user_id = user_id_from_token
            elif isinstance(user_id_from_token, int):
                # Integer user_id from old token - need to look up UUID from persons table
                logger.warning(f"JWT token contains integer user_id {user_id_from_token} - looking up UUID")
                pool = await self.get_pool()
                async with pool.acquire() as conn:
                    person = await conn.fetchrow(
                        "SELECT id FROM persons WHERE id::text LIKE $1 OR CAST(id AS text) = $2",
                        f"%{user_id_from_token}%",
                        str(user_id_from_token)
                    )
                    if person:
                        self.user_id = person['id']
                    else:
                        # Try to find by old integer ID (if migration created a mapping)
                        # For now, raise error
                        raise HTTPException(
                            status_code=status.HTTP_401_UNAUTHORIZED,
                            detail=f"Could not find UUID for user_id {user_id_from_token}. Token may be from before migration."
                        )
            else:
                self.user_id = user_id_from_token
            
            # Get user from database
            user = await self.get_user()
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found"
                )
            
            return user

        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError as e:
            logger.error(f"Invalid token: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        except Exception as exc:
            logger.error(f"Authentication error: {exc}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Failed to authenticate"
            )

    async def authenticate_with_apikey(self, apikey: str) -> Dict:
        """Authenticate user with API key"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Get user_id from api_keys table
                api_key_response = await conn.fetchrow(
                    "SELECT user_id FROM api_keys WHERE key = $1",
                    apikey
                )

                if not api_key_response:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid API key",
                    )

                # Normalize user_id from database response
                user_id_from_db = api_key_response["user_id"]
                if isinstance(user_id_from_db, UUID):
                    self.user_id = user_id_from_db
                elif isinstance(user_id_from_db, str):
                    try:
                        self.user_id = UUID(user_id_from_db)
                    except ValueError:
                        self.user_id = user_id_from_db
                elif isinstance(user_id_from_db, int):
                    # Integer user_id from database - this shouldn't happen after migration
                    logger.error(f"API key lookup returned integer user_id {user_id_from_db} - migration may not be complete")
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Database migration may not be complete. Found integer user_id {user_id_from_db}."
                    )
                else:
                    self.user_id = user_id_from_db
                
                user = await self.get_user()
                
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found"
                    )
                
                return user

        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"API key authentication error: {exc}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication failed",
            )

    async def save_apikey(self, key_to_create: ApiKeyCreate) -> ApiKey:
        """Save API key to database"""
        try:
            key_data = key_to_create.model_dump()
            
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO api_keys (name, key, user_id, created_at)
                    VALUES ($1, $2, $3, NOW())
                    RETURNING *
                    """,
                    key_data.get("name"),
                    key_data.get("key"),
                    user_id_param
                )
                
                if row:
                    return ApiKey(**dict(row))
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create API key",
                    )
        except Exception as exc:
            logger.error(f"Failed to save API key: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to create API key: {exc}",
            )

    async def fetch_apikeys(self) -> List[ApiKey]:
        """Fetch all API keys for current user"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    "SELECT * FROM api_keys WHERE user_id = $1 ORDER BY created_at DESC",
                    user_id_param
                )
                return [ApiKey(**dict(row)) for row in rows]
        except Exception as exc:
            logger.error(f"Failed to fetch API keys: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to retrieve API keys",
            )

    async def fetch_apikey(self, apikey_id: str) -> Optional[ApiKey]:
        """Fetch single API key"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM api_keys WHERE id = $1 AND user_id = $2",
                    int(apikey_id),
                    user_id_param
                )
                
                if row:
                    return ApiKey(**dict(row))
                return None
        except Exception as exc:
            logger.error(f"Failed to fetch API key: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to retrieve API key",
            )

    async def delete_apikey(self, apikey_id: str) -> Dict:
        """Delete API key"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                result = await conn.execute(
                    "DELETE FROM api_keys WHERE id = $1 AND user_id = $2",
                    int(apikey_id),
                    user_id_param
                )
                
                if result == "DELETE 0":
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="API key not found",
                    )
                
                return {"message": f"Successfully deleted {apikey_id}"}
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to delete API key: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to delete API key",
            )

    async def fetch_general_settings(self) -> Dict:
        """Fetch user general settings"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT general FROM user_settings WHERE user_id = $1",
                    user_id_param
                )
                
                if row and row['general']:
                    return row['general'] if isinstance(row['general'], dict) else json.loads(row['general'])
                return {}
        except Exception as exc:
            logger.error(f"Failed to fetch general settings: {exc}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch user settings: {exc}",
            )

    async def fetch_tool_settings(self) -> Dict:
        """Fetch user tool settings"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT tools FROM user_settings WHERE user_id = $1",
                    user_id_param
                )
                
                if row and row['tools']:
                    return row['tools'] if isinstance(row['tools'], dict) else json.loads(row['tools'])
                return {}
        except Exception as exc:
            logger.error(f"Failed to fetch tool settings: {exc}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch tool settings: {exc}",
            )

    async def update_tool_settings(self, tools: Dict) -> Dict:
        """Upsert user tool settings (JSON object keyed by tool id)."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            tools_json = json.dumps(tools) if not isinstance(tools, str) else tools
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO user_settings (user_id, tools, updated_at)
                    VALUES ($1, $2::jsonb, NOW())
                    ON CONFLICT (user_id) DO UPDATE SET
                        tools = EXCLUDED.tools,
                        updated_at = NOW()
                    """,
                    user_id_param,
                    tools_json,
                )
            return tools if isinstance(tools, dict) else json.loads(tools)
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to update tool settings: {exc}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update tool settings: {exc}",
            )

    def _ensure_user_id_is_uuid(self, user_id):
        """Helper to ensure user_id is UUID format"""
        if user_id is None:
            return None
        if isinstance(user_id, UUID):
            return user_id
        if isinstance(user_id, str):
            try:
                return UUID(user_id)
            except ValueError:
                return user_id
        if isinstance(user_id, int):
            # Integer user_id - this shouldn't happen after migration
            logger.error(f"Integer user_id {user_id} found in _ensure_user_id_is_uuid - migration may not be complete")
            raise ValueError(f"Integer user_id {user_id} cannot be used - database migration may not be complete")
        return user_id

    async def fetch_chats(self) -> List[Chat]:
        """Fetch all chats for current user"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    "SELECT * FROM chats WHERE user_id = $1 ORDER BY created_at DESC",
                    user_id_param
                )
                # Normalize user_id in each row (async version for potential DB lookups)
                chats = []
                for row in rows:
                    row_dict = await normalize_row_user_id_async(dict(row), conn)
                    row_dict["config"] = _normalize_chat_config(row_dict.get("config"))
                    chats.append(Chat(**row_dict))
                return chats
        except Exception as exc:
            logger.error(f"Failed to fetch chats: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to get chats: {exc}",
            )

    async def fetch_chat(self, chat_id: str) -> Chat:
        """Fetch single chat by ID"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                
                if row:
                    row_dict = await normalize_row_user_id_async(dict(row), conn)
                    row_dict["config"] = _normalize_chat_config(row_dict.get("config"))
                    return Chat(**row_dict)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found"
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to fetch chat: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Chat not found: {exc}",
            )

    async def delete_chat(self, chat_id: str) -> Dict:
        """Delete chat and all associated messages"""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                owned_chat = await conn.fetchval(
                    "SELECT 1 FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                if not owned_chat:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found or unauthorized"
                    )

                # Only delete related rows after ownership is confirmed.
                await conn.execute(
                    "DELETE FROM chat_messages WHERE chat_id = $1",
                    int(chat_id)
                )
                
                await conn.execute(
                    "DELETE FROM chat_logs WHERE chat_id = $1",
                    int(chat_id)
                )
                
                result = await conn.execute(
                    "DELETE FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                
                if result == "DELETE 0":
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found or unauthorized"
                    )
                
                return {"message": f"Chat {chat_id} deleted successfully"}
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to delete chat: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to delete chat: {exc}",
            )

    async def clear_chat_messages(self, chat_id: str) -> Dict:
        """Delete messages/logs for a chat but keep the chat session."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )

            pool = await self.get_pool()
            async with pool.acquire() as conn:
                owned_chat = await conn.fetchval(
                    "SELECT 1 FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                if not owned_chat:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found or unauthorized"
                    )

                await conn.execute(
                    "DELETE FROM chat_messages WHERE chat_id = $1",
                    int(chat_id)
                )
                await conn.execute(
                    "DELETE FROM chat_logs WHERE chat_id = $1",
                    int(chat_id)
                )
                await conn.execute(
                    """
                    UPDATE chats
                    SET status = 'ready', updated_at = NOW()
                    WHERE id = $1 AND user_id = $2
                    """,
                    int(chat_id),
                    user_id_param
                )

                return {"message": f"Messages for chat {chat_id} cleared successfully"}
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to clear chat messages: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to clear chat messages: {exc}",
            )

    async def create_chat(self, chat_to_create: ChatCreate) -> Chat:
        """Create new chat"""
        try:
            if isinstance(chat_to_create, dict):
                chat_data = chat_to_create.copy()
                chat_data.pop("id", None)
            else:
                chat_data = chat_to_create.model_dump(exclude={"id"})
            
            pool = await self.get_pool()
            self.user_id= chat_data.get("user_id")
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chats (name, from_project, from_template, from_type, config, user_id, status, session_id, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
                    RETURNING *
                    """,
                    chat_data.get("name"),
                    chat_data.get("from_project"),
                    chat_data.get("from_template"),
                    chat_data.get("from_type"),
                    json.dumps(chat_data.get("config")) if chat_data.get("config") else None,
                    chat_data.get("user_id"),
                    chat_data.get("status", "ready"),
                    chat_data.get("session_id"),
                )
                
                if row:
                    row_dict = await normalize_row_user_id_async(dict(row), conn)
                    row_dict["config"] = _normalize_chat_config(row_dict.get("config"))
                    return Chat(**row_dict)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create chat",
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to create chat: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to create chat: {exc}",
            )

    async def fetch_tools(self, tool_ids: Optional[List[int]] = None) -> List[Tool]:
        """Fetch tools for current user. If tool_ids is None or empty, returns all tools."""
        try:
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found",
                )

            pool = await self.get_pool()
            async with pool.acquire() as conn:
                query = """
                    SELECT * FROM tools 
                    WHERE (user_id = $1 OR is_public = true)
                """
                params = [user_id_param]
                
                if tool_ids and len(tool_ids) > 0:
                    query += " AND id = ANY($2)"
                    params.append(tool_ids)
                
                query += " ORDER BY created_at DESC"
                
                rows = await conn.fetch(query, *params)
                tools = []
                seen_public_keys = set()
                for row in rows:
                    tool_dict = dict(row)
                    # Parse JSON fields if they're strings
                    if isinstance(tool_dict.get('code'), str):
                        try:
                            tool_dict['code'] = json.loads(tool_dict['code'])
                        except:
                            pass
                    if isinstance(tool_dict.get('variables'), str):
                        try:
                            tool_dict['variables'] = json.loads(tool_dict['variables'])
                        except:
                            pass
                    # Handle None or empty variables
                    if tool_dict.get('variables') is None:
                        tool_dict['variables'] = []
                    # Ensure variables is a list
                    if not isinstance(tool_dict.get('variables'), list):
                        tool_dict['variables'] = []

                    # Server databases may contain duplicate seeded public tools.
                    # Keep only one public tool per semantic name while preserving
                    # all private/user-owned tools.
                    if tool_dict.get('is_public'):
                        public_key = str(tool_dict.get('name') or '').strip().lower()
                        if public_key in seen_public_keys:
                            continue
                        seen_public_keys.add(public_key)

                    tools.append(Tool(**tool_dict))
                return tools
        except Exception as exc:
            logger.error(f"Failed to fetch tools: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed fetching tools: {exc}",
            )

    async def _ensure_person_exists(self, conn, user_id_param) -> None:
        """Ensure a row exists in persons for the current user (satisfies tools.user_id FK)."""
        existing = await conn.fetchval(
            "SELECT 1 FROM persons WHERE id = $1",
            user_id_param,
        )
        if existing:
            return
        email = None
        if getattr(self, "current_user", None) and isinstance(self.current_user, dict):
            email = self.current_user.get("email")
        normalized_email = (email or "").strip().lower() if isinstance(email, str) else ""
        if normalized_email:
            # If this email already exists, do NOT attempt to insert a new row with the same email.
            # This can happen when an external IdP subject->UUID differs from an existing local user id.
            existing_by_email = await conn.fetchval(
                "SELECT 1 FROM persons WHERE LOWER(TRIM(email)) = $1",
                normalized_email,
            )
            if existing_by_email:
                return
        else:
            normalized_email = f"user_{user_id_param}@placeholder.local"
        from ..services.auth import get_password_hash
        placeholder_hash = get_password_hash("no-password-set")
        await conn.execute(
            """
            INSERT INTO persons (id, email, password_hash, created_at, updated_at)
            VALUES ($1, $2, $3, NOW(), NOW())
            ON CONFLICT (email) DO UPDATE SET updated_at = NOW()
            """,
            user_id_param,
            normalized_email,
            placeholder_hash,
        )

    async def create_tool(self, tool_to_create: Tool) -> Tool:
        """Create new tool"""
        try:
            tool_data = tool_to_create.model_dump(exclude={"id"})
            
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                await self._ensure_person_exists(conn, user_id_param)
                row = await conn.fetchrow(
                    """
                    INSERT INTO tools (name, description, logo_url, code, user_id, variables, is_public, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
                    RETURNING *
                    """,
                    tool_data.get("name"),
                    tool_data.get("description"),
                    tool_data.get("logo_url"),
                    json.dumps(tool_data.get("code")) if tool_data.get("code") else None,
                    user_id_param,
                    json.dumps(tool_data.get("variables")) if tool_data.get("variables") else None,
                    tool_data.get("is_public", False)
                )
                
                if row:
                    tool_dict = dict(row)
                    # Parse JSON fields if they're strings
                    if isinstance(tool_dict.get('code'), str):
                        try:
                            tool_dict['code'] = json.loads(tool_dict['code'])
                        except:
                            pass
                    if isinstance(tool_dict.get('variables'), str):
                        try:
                            tool_dict['variables'] = json.loads(tool_dict['variables'])
                        except:
                            pass
                    # Handle None or empty variables
                    if tool_dict.get('variables') is None:
                        tool_dict['variables'] = []
                    # Ensure variables is a list
                    if not isinstance(tool_dict.get('variables'), list):
                        tool_dict['variables'] = []
                    return Tool(**tool_dict)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Failed to create tool",
                    )
        except Exception as exc:
            logger.error(f"Failed to create tool: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to create tool: {exc}",
            )

    async def fetch_tool(self, tool_id: str) -> Tool:
        """Fetch single tool by id (int) or uuid (str)."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found",
                )
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                if _is_uuid_like(tool_id):
                    uid = UUID(tool_id) if len(tool_id) == 36 else UUID(hex=tool_id)
                    row = await conn.fetchrow(
                        """
                        SELECT * FROM tools 
                        WHERE uuid = $1 AND (user_id = $2 OR is_public = true)
                        """,
                        uid,
                        user_id_param,
                    )
                else:
                    row = await conn.fetchrow(
                        """
                        SELECT * FROM tools 
                        WHERE id = $1 AND (user_id = $2 OR is_public = true)
                        """,
                        int(tool_id),
                        user_id_param,
                    )
                
                if row:
                    tool_dict = dict(row)
                    # Parse JSON fields if they're strings
                    if isinstance(tool_dict.get('code'), str):
                        try:
                            tool_dict['code'] = json.loads(tool_dict['code'])
                        except:
                            pass
                    if isinstance(tool_dict.get('variables'), str):
                        try:
                            tool_dict['variables'] = json.loads(tool_dict['variables'])
                        except:
                            pass
                    # Handle None or empty variables
                    if tool_dict.get('variables') is None:
                        tool_dict['variables'] = []
                    # Ensure variables is a list
                    if not isinstance(tool_dict.get('variables'), list):
                        tool_dict['variables'] = []
                    return Tool(**tool_dict)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Tool not found"
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to fetch tool: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tool not found: {exc}",
            )

    async def update_tool(self, tool_to_update: Tool) -> Tool:
        """Update existing tool"""
        try:
            tool_data = tool_to_update.model_dump()
            tool_id = tool_data.pop("id")
            
            if not tool_id:
                raise Exception("Invalid tool_id")
            
            # Ensure user_id is UUID before query
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            
            pool = await self.get_pool()
            tool_row_dict = None
            user_variables = None
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    UPDATE tools 
                    SET name = $1, description = $2, logo_url = $3, code = $4, 
                        variables = $5, is_public = $6, updated_at = NOW()
                    WHERE id = $7 AND user_id = $8
                    RETURNING *
                    """,
                    tool_data.get("name"),
                    tool_data.get("description"),
                    tool_data.get("logo_url"),
                    json.dumps(tool_data.get("code")) if tool_data.get("code") else None,
                    json.dumps(tool_data.get("variables")) if tool_data.get("variables") else None,
                    tool_data.get("is_public", False),
                    tool_id,
                    user_id_param
                )
                
                if row:
                    tool_dict = dict(row)
                    # Parse JSON fields if they're strings
                    if isinstance(tool_dict.get('code'), str):
                        try:
                            tool_dict['code'] = json.loads(tool_dict['code'])
                        except:
                            pass
                    if isinstance(tool_dict.get('variables'), str):
                        try:
                            tool_dict['variables'] = json.loads(tool_dict['variables'])
                        except:
                            pass
                    # Handle None or empty variables
                    if tool_dict.get('variables') is None:
                        tool_dict['variables'] = []
                    # Ensure variables is a list
                    if not isinstance(tool_dict.get('variables'), list):
                        tool_dict['variables'] = []
                    return Tool(**tool_dict)
                else:
                    # Not the owner: allow saving config for public tools to user_settings
                    tool_row = await conn.fetchrow(
                        "SELECT * FROM tools WHERE id = $1",
                        int(tool_id),
                    )
                    if not tool_row:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail="Tool not found",
                        )
                    tool_owner_id = tool_row.get("user_id")
                    is_public = tool_row.get("is_public") is True
                    if not is_public or tool_owner_id == user_id_param:
                        raise HTTPException(
                            status_code=status.HTTP_403_FORBIDDEN,
                            detail="Tool not found or unauthorized",
                        )
                    tool_row_dict = dict(tool_row)
                    user_variables = tool_data.get("variables", [])

            # Outside conn block: save to user_settings and return tool with user's variables
            if tool_row_dict is not None:
                current_settings = await self.fetch_tool_settings()
                current_settings[str(tool_id)] = {"variables": user_variables or []}
                await self.update_tool_settings(current_settings)
                out_dict = tool_row_dict
                if isinstance(out_dict.get('code'), str):
                    try:
                        out_dict['code'] = json.loads(out_dict['code'])
                    except Exception:
                        pass
                if isinstance(out_dict.get('variables'), str):
                    try:
                        out_dict['variables'] = json.loads(out_dict['variables'])
                    except Exception:
                        pass
                if out_dict.get('variables') is None:
                    out_dict['variables'] = []
                if not isinstance(out_dict.get('variables'), list):
                    out_dict['variables'] = []
                out_dict['variables'] = user_variables or []
                return Tool(**out_dict)

            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tool not found or unauthorized",
            )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to update tool: {exc}")
            raise

    async def delete_tool(self, tool_id: str) -> Dict:
        """Delete tool by id (int) or uuid (str)."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                if _is_uuid_like(tool_id):
                    row = await conn.fetchrow(
                        "SELECT id FROM tools WHERE uuid = $1 AND user_id = $2",
                        UUID(tool_id) if len(tool_id) == 36 else UUID(hex=tool_id),
                        user_id_param,
                    )
                    if not row:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail="Tool not found or unauthorized",
                        )
                    tool_id = str(row["id"])
                result = await conn.execute(
                    "DELETE FROM tools WHERE id = $1 AND user_id = $2",
                    int(tool_id),
                    user_id_param
                )
                
                if result == "DELETE 0":
                    raise Exception(f"Tool {tool_id} not found or unauthorized")
                
                return {"message": f"Tool {tool_id} deleted successfully"}
        except Exception as exc:
            logger.error(f"Failed to delete tool: {exc}")
            raise

    async def fetch_messages(self, chat_id: str) -> List[Message]:
        """Fetch all messages for a chat"""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )

            pool = await self.get_pool()
            async with pool.acquire() as conn:
                owned_chat = await conn.fetchval(
                    "SELECT 1 FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                if not owned_chat:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found or unauthorized"
                    )

                rows = await conn.fetch(
                    "SELECT * FROM chat_messages WHERE chat_id = $1 ORDER BY created_at ASC",
                    int(chat_id)
                )
                # Normalize user_id in each row (async version for potential DB lookups)
                messages = []
                for row in rows:
                    row_dict = await normalize_row_user_id_async(dict(row), conn)
                    raw_meta = row_dict.pop("meta", None)
                    if "metadata" in row_dict:
                        raw_meta = row_dict.pop("metadata", raw_meta)
                    row_dict["metadata"] = _normalize_message_metadata(raw_meta)
                    messages.append(Message(**row_dict))
                return messages
        except Exception as exc:
            logger.error(f"Failed to fetch messages: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed fetching messages: {exc}",
            )

    async def add_message(self, message: MessageCreate, chat_id: str) -> Message:
        """Add new message to chat"""
        try:
            message_dict = message.model_dump(exclude={"id"})
            meta_val = message_dict.get("metadata") or message_dict.get("meta")
            
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Never trust a stale client-sent user_id when we already have an
                # authenticated canonical user on the request-scoped DB client.
                effective_user_id = self._ensure_user_id_is_uuid(
                    self.user_id or message_dict.get("user_id")
                )
                if effective_user_id is not None:
                    await self._ensure_person_exists(conn, effective_user_id)

                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_messages (chat_id, sender, receiver, content, type, user_id, meta, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
                    RETURNING *
                    """,
                    int(chat_id),
                    message_dict.get("sender"),
                    message_dict.get("receiver"),
                    message_dict.get("content"),
                    message_dict.get("type"),
                    effective_user_id,
                    json.dumps(meta_val) if meta_val else None
                )
                
                if row:
                    logger.debug(f"Added message to chat {chat_id}")
                    row_dict = await normalize_row_user_id_async(dict(row), conn)
                    return Message(**row_dict)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Adding message failed",
                    )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to add message: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to add message: {exc}",
            )

    async def add_log(self, log: LogCreate):
        """Add log entry to database"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_logs (chat_id, message, level, metadata, created_at)
                    VALUES ($1, $2, $3, $4, NOW())
                    RETURNING *
                    """,
                    int(log.chat_id) if isinstance(log.chat_id, str) else log.chat_id,
                    log.message,
                    log.level,
                    json.dumps(log.metadata) if log.metadata else None
                )
                
                if row:
                    logger.debug(f"Added log for chat {log.chat_id}")
                    return dict(row)
                
                return None
                
        except Exception as exc:
            logger.error(f"Failed to add log: {exc}")
            return None

    async def fetch_logs(self, chat_id: str) -> List[Log]:
        """Fetch logs for a chat owned by the current user."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found"
                )

            pool = await self.get_pool()
            async with pool.acquire() as conn:
                owned_chat = await conn.fetchval(
                    "SELECT 1 FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param
                )
                if not owned_chat:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found or unauthorized"
                    )

                rows = await conn.fetch(
                    "SELECT * FROM chat_logs WHERE chat_id = $1 ORDER BY created_at ASC",
                    int(chat_id)
                )
                return [Log(**dict(row)) for row in rows]
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to fetch logs: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed fetching logs: {exc}",
            )

    async def fetch_source_metadata(self, chat_id: str) -> Dict:
        """Fetch source project/template metadata for a chat"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Get chat info
                chat = await conn.fetchrow(
                    "SELECT * FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    self.user_id
                )
                
                if not chat:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Chat not found"
                    )
                
                chat = dict(chat)
                
                # Get source metadata
                if chat["from_type"] == "project":
                    # from_project is now UUID, no conversion needed
                    source = await conn.fetchrow(
                        "SELECT * FROM projects WHERE id = $1",
                        chat["from_project"]
                    )
                    if source:
                        return dict(source)
                        
                elif chat["from_type"] == "template":
                    source = await conn.fetchrow(
                        "SELECT * FROM templates WHERE id = $1",
                        chat["from_template"]
                    )
                    if source:
                        source_dict = dict(source)
                        # Return the project field from template
                        return source_dict.get("project", {})
                
                return {}
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to fetch source metadata: {exc}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source metadata not found: {exc}",
            )

    async def update_chat_config(self, chat_id: str, config: Dict[str, Any]) -> None:
        """Merge `config` into chats.config (JSONB)."""
        try:
            user_id_param = self._ensure_user_id_is_uuid(self.user_id)
            if user_id_param is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User ID not found",
                )
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT config FROM chats WHERE id = $1 AND user_id = $2",
                    int(chat_id),
                    user_id_param,
                )
                existing: Dict[str, Any] = {}
                if row and row.get("config"):
                    raw = row["config"]
                    if isinstance(raw, dict):
                        existing = dict(raw)
                    elif isinstance(raw, str):
                        try:
                            existing = json.loads(raw)
                        except json.JSONDecodeError:
                            existing = {}
                merged = {**existing, **(config or {})}
                await conn.execute(
                    """
                    UPDATE chats SET config = $1::jsonb, updated_at = NOW()
                    WHERE id = $2 AND user_id = $3
                    """,
                    json.dumps(merged),
                    int(chat_id),
                    user_id_param,
                )
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Failed to update chat config: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to update chat config: {exc}",
            )

    async def set_chat_status(
        self,
        chat_id: str,
        chat_status: Literal[
            "ready", "running", "wait_for_human_input", "completed", "aborted", "failed"
        ],
    ):
        """Update chat status"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    UPDATE chats 
                    SET status = $1, updated_at = NOW()
                    WHERE id = $2 AND user_id = $3
                    RETURNING *
                    """,
                    chat_status,
                    int(chat_id),
                    self.user_id
                )
                
                if row:
                    return dict(row)
                return None
        except Exception as exc:
            logger.error(f"Failed to set chat status: {exc}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to set chat status: {exc}",
            )

    async def upload_image(self, image_path: str, image_data: bytes):
        """Upload image to storage - placeholder for file storage implementation"""
        try:
            # TODO: Implement file storage (local filesystem, S3, etc.)
            logger.warning("Image upload not implemented - file storage needed")
            return {"path": image_path, "message": "Upload not implemented"}
        except Exception as e:
            logger.error(f"Failed to upload image: {e}")
            raise

    async def search_chunks(self, dataset_id: int, query_vector: List[float], top_k: int):
        """Search vector chunks for RAG"""
        try:
            pool = await self.get_pool()
            async with pool.acquire() as conn:
                # Call PostgreSQL function for vector search
                rows = await conn.fetch(
                    """
                    SELECT * FROM search_chunks_by_dataset($1, $2::vector, $3)
                    """,
                    dataset_id,
                    query_vector,
                    top_k
                )
                return [dict(row) for row in rows]
        except Exception as exc:
            logger.error(f"Failed to search chunks: {exc}")
            return []


def create_database_client():
    """Factory function to create database client"""
    return DatabaseClient()