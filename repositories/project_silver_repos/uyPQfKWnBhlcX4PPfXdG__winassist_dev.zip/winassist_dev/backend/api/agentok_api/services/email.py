"""
SMTP email service for sending workspace invite emails.
Uses env: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM_EMAIL, SMTP_USE_TLS.
If any required var is missing, send_invite_email returns False and no email is sent.
Supports Gmail/Google: use App Password (2-Step Verification), port 587, TLS.
"""
import logging
import os
import re
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional, Tuple

logger = logging.getLogger(__name__)
SMTP_TIMEOUT = 15


def _smtp_configured() -> bool:
    host = os.getenv("SMTP_HOST", "").strip()
    user = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    ok = bool(host and user and password)
    if not ok:
        logger.info(
            "SMTP config check: host=%s user=%s password_set=%s",
            host or "(empty)",
            user or "(empty)",
            bool(password),
        )
    return ok


def _normalize_app_password(password: str) -> str:
    """Remove spaces from Google-style App Passwords (e.g. 'xxxx xxxx xxxx xxxx' -> 'xxxxxxxxxxxxxxxx')."""
    if not password:
        return password
    return re.sub(r"\s+", "", password)


def send_invite_email(
    to_email: str,
    inviter_email: str,
    workspace_name: str,
    invite_link: Optional[str],
    role: str,
    expires_in_days: Optional[int] = None,
) -> Tuple[bool, Optional[str]]:
    """
    Send workspace invite email. Returns (True, None) if sent, (False, error_message) otherwise.
    """
    logger.info(
        "send_invite_email: to=%s inviter=%s workspace=%s role=%s has_link=%s",
        to_email, inviter_email, workspace_name, role, bool(invite_link),
    )

    if not _smtp_configured():
        logger.info("SMTP not configured; skipping invite email to %s", to_email)
        return False, "SMTP not configured"

    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "").strip()
    raw_password = os.getenv("SMTP_PASSWORD", "").strip()
    password = _normalize_app_password(raw_password)
    from_email = os.getenv("SMTP_FROM_EMAIL", "").strip() or user
    use_tls = os.getenv("SMTP_USE_TLS", "true").lower() in ("1", "true", "yes")

    logger.info(
        "SMTP config: host=%s port=%s user=%s from=%s use_tls=%s password_len=%s",
        host, port, user, from_email, use_tls, len(password) if password else 0,
    )

    subject = f"You're invited to join {workspace_name}"
    expires_note = ""
    if expires_in_days:
        expires_note = f" This invite expires in {expires_in_days} days."
    link_note = invite_link or "The workspace owner can share the accept-invite link from the Team page in the app."
    body_plain = (
        f"{inviter_email} has invited you to join the workspace \"{workspace_name}\" as {role}.\n\n"
        f"Accept the invite by opening this link (log in or register first if needed):\n\n{link_note}\n\n"
        f"{expires_note}"
    )

    # Styled HTML email (inline CSS for compatibility)
    if invite_link:
        body_html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0; padding:0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f4f4f5;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f5; padding: 24px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow: hidden;">
          <tr>
            <td style="padding: 32px 32px 24px 32px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);">
              <h1 style="margin:0; font-size: 22px; font-weight: 700; color: #ffffff;">You're invited</h1>
              <p style="margin: 8px 0 0 0; font-size: 14px; color: rgba(255,255,255,0.9);">Join your team's workspace</p>
            </td>
          </tr>
          <tr>
            <td style="padding: 28px 32px;">
              <p style="margin:0 0 16px 0; font-size: 15px; color: #374151; line-height: 1.5;">
                <strong>{inviter_email}</strong> has invited you to join <strong>{workspace_name}</strong> as <strong>{role}</strong>.
              </p>
              <p style="margin:0 0 24px 0; font-size: 14px; color: #6b7280; line-height: 1.5;">
                Click the button below to accept. You'll need to log in or create an account if you don't have one yet.
              </p>
              <table role="presentation" cellspacing="0" cellpadding="0" width="100%">
                <tr>
                  <td>
                    <a href="{invite_link}" target="_blank" rel="noopener noreferrer" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: #ffffff; font-size: 15px; font-weight: 600; text-decoration: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(99, 102, 241, 0.3);">
                      Accept invite
                    </a>
                  </td>
                </tr>
              </table>
              <p style="margin: 20px 0 0 0; font-size: 12px; color: #9ca3af;">
                Or copy and paste this link into your browser:<br/>
                <a href="{invite_link}" style="color: #6366f1; word-break: break-all;">{invite_link}</a>
              </p>
              {f'<p style="margin: 16px 0 0 0; font-size: 13px; color: #6b7280;">{expires_note.strip()}</p>' if expires_note.strip() else ''}
            </td>
          </tr>
          <tr>
            <td style="padding: 16px 32px; background-color: #f9fafb; border-top: 1px solid #e5e7eb;">
              <p style="margin:0; font-size: 12px; color: #9ca3af;">This invite was sent from your workspace. If you didn't expect it, you can ignore this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
"""
    else:
        body_html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="margin:0; padding:24px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;">
  <p><strong>{inviter_email}</strong> has invited you to join <strong>{workspace_name}</strong> as <strong>{role}</strong>.</p>
  <p>Ask the workspace owner for the invite link from the Team page.</p>
  <p style="color:#6b7280; font-size:14px;">{expires_note.strip()}</p>
</body>
</html>
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.attach(MIMEText(body_plain, "plain"))
    msg.attach(MIMEText(body_html, "html"))

    try:
        if use_tls:
            logger.info("Connecting to %s:%s (TLS)", host, port)
            with smtplib.SMTP(host, port, timeout=SMTP_TIMEOUT) as server:
                logger.info("Connected; starting TLS")
                server.starttls()
                logger.info("TLS started; logging in as %s", user)
                server.login(user, password)
                logger.info("Logged in; sending mail to %s", to_email)
                server.sendmail(from_email, [to_email], msg.as_string())
        else:
            logger.info("Connecting to %s:%s (SSL)", host, port)
            with smtplib.SMTP_SSL(host, port, timeout=SMTP_TIMEOUT) as server:
                logger.info("Connected; logging in as %s", user)
                server.login(user, password)
                logger.info("Logged in; sending mail to %s", to_email)
                server.sendmail(from_email, [to_email], msg.as_string())
        logger.info("Invite email sent successfully to %s for workspace %s", to_email, workspace_name)
        return True, None
    except Exception as e:
        err_msg = str(e)
        logger.exception(
            "Failed to send invite email to %s: %s (type=%s)",
            to_email, err_msg, type(e).__name__,
        )
        return False, err_msg


def send_password_reset_email(to_email: str, reset_link: str) -> Tuple[bool, Optional[str]]:
    """
    Send password reset email with the reset link.
    Uses same SMTP env vars as invite emails. Returns (True, None) if sent, (False, error_message) otherwise.
    """
    logger.info("send_password_reset_email: to=%s has_link=%s", to_email, bool(reset_link))

    if not _smtp_configured():
        logger.info("SMTP not configured; skipping password reset email to %s", to_email)
        return False, "SMTP not configured"

    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "").strip()
    raw_password = os.getenv("SMTP_PASSWORD", "").strip()
    password = _normalize_app_password(raw_password)
    from_email = os.getenv("SMTP_FROM_EMAIL", "").strip() or user
    use_tls = os.getenv("SMTP_USE_TLS", "true").lower() in ("1", "true", "yes")

    subject = "Reset your WinAssist password"
    body_plain = (
        "You requested a password reset for your WinAssist account.\n\n"
        "Click the link below to set a new password (the link expires in 1 hour):\n\n"
        f"{reset_link}\n\n"
        "If you didn't request this, you can safely ignore this email.\n"
    )

    body_html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0; padding:0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f4f4f5;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f5; padding: 24px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow: hidden;">
          <tr>
            <td style="padding: 32px 32px 24px 32px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);">
              <h1 style="margin:0; font-size: 22px; font-weight: 700; color: #ffffff;">Reset your password</h1>
              <p style="margin: 8px 0 0 0; font-size: 14px; color: rgba(255,255,255,0.9);">WinAssist</p>
            </td>
          </tr>
          <tr>
            <td style="padding: 28px 32px;">
              <p style="margin:0 0 16px 0; font-size: 15px; color: #374151; line-height: 1.5;">
                You requested a password reset. Click the button below to set a new password. This link expires in 1 hour.
              </p>
              <table role="presentation" cellspacing="0" cellpadding="0" width="100%">
                <tr>
                  <td>
                    <a href="{reset_link}" target="_blank" rel="noopener noreferrer" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: #ffffff; font-size: 15px; font-weight: 600; text-decoration: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(99, 102, 241, 0.3);">
                      Reset password
                    </a>
                  </td>
                </tr>
              </table>
              <p style="margin: 20px 0 0 0; font-size: 12px; color: #9ca3af;">
                Or copy and paste this link into your browser:<br/>
                <a href="{reset_link}" style="color: #6366f1; word-break: break-all;">{reset_link}</a>
              </p>
              <p style="margin: 20px 0 0 0; font-size: 13px; color: #6b7280;">If you didn't request this, you can safely ignore this email.</p>
            </td>
          </tr>
          <tr>
            <td style="padding: 16px 32px; background-color: #f9fafb; border-top: 1px solid #e5e7eb;">
              <p style="margin:0; font-size: 12px; color: #9ca3af;">This email was sent by WinAssist. If you have questions, contact your administrator.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.attach(MIMEText(body_plain, "plain"))
    msg.attach(MIMEText(body_html, "html"))

    try:
        if use_tls:
            with smtplib.SMTP(host, port, timeout=SMTP_TIMEOUT) as server:
                server.starttls()
                server.login(user, password)
                server.sendmail(from_email, [to_email], msg.as_string())
        else:
            with smtplib.SMTP_SSL(host, port, timeout=SMTP_TIMEOUT) as server:
                server.login(user, password)
                server.sendmail(from_email, [to_email], msg.as_string())
        logger.info("Password reset email sent successfully to %s", to_email)
        return True, None
    except Exception as e:
        logger.exception(
            "Failed to send password reset email to %s: %s (type=%s)",
            to_email, str(e), type(e).__name__,
        )
        return False, str(e)
