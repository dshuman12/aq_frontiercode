from typing import Any, Dict

from fastapi import HTTPException, status

from .whatsapp_provider import get_whatsapp_provider


async def send_connector_payload(
    *,
    connector_key: str,
    connection: Dict[str, Any],
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    key = str(connector_key or "").strip().lower()
    if key == "whatsapp_meta_cloud":
        provider = get_whatsapp_provider(connection["provider"])
        return await provider.send_message_payload(
            graph_version=connection["graph_version"],
            phone_number_id=connection["phone_number_id"],
            access_token=connection["access_token"],
            payload=payload,
        )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"Unsupported connector transport: {connector_key}",
    )


async def send_connector_text(
    *,
    connector_key: str,
    connection: Dict[str, Any],
    to: str,
    text: str,
    preview_url: bool = False,
) -> Dict[str, Any]:
    payload = {
        "recipient_type": "individual",
        "to": to,
        "type": "text",
        "text": {
            "preview_url": bool(preview_url),
            "body": text,
        },
    }
    return await send_connector_payload(
        connector_key=connector_key,
        connection=connection,
        payload=payload,
    )
