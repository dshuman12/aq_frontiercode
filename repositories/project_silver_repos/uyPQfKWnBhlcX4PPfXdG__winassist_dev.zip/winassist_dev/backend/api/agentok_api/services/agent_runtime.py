"""
OpenAI tool-calling agent runtime for backend (AI Agent) projects.

Provides: multi-step tool loop, short-term memory from chat history + rolling summary,
HTTP tools from flow `api` nodes; DB catalog tools per `data.tools` rules; built-in `invoke_http` for direct GET/POST; optional web search.
Optional tool-chain state: after each tool round, a compact JSON summary of prior tool outputs is injected so the model can pass values between tools (e.g. order id → payment).
"""
from __future__ import annotations

import json
import logging
import os
import re
import uuid
from typing import Any, Callable, Awaitable, Dict, List, Optional, Tuple

import httpx

from ..models import MessageCreate
from .connector_registry import get_whatsapp_connector_definition
from .message_transport import send_connector_text as transport_send_connector_text
from .secret_store import connector_credentials_secret
from .whatsapp_provider import get_whatsapp_provider

logger = logging.getLogger(__name__)

# Max chars logged to terminal per field (avoid huge blobs / noisy logs)
_LOG_TOOL_ARG_MAX = 1200
_LOG_TOOL_OUT_MAX = 4000

# Tool chaining: inject accumulated JSON summaries so the model can pass outputs between tools
_DEFAULT_TOOL_STATE_MAX_CHARS = 8000


def _tool_result_summary_for_chain(result_text: str) -> Dict[str, Any]:
    """Compact representation of a tool result for cross-tool chaining (LLM-readable, size-bounded)."""
    rt = (result_text or "").strip()
    if not rt:
        return {"empty": True}
    try:
        parsed = json.loads(rt)
    except json.JSONDecodeError:
        return {"text_excerpt": rt[:6000] + ("..." if len(rt) > 6000 else "")}
    if isinstance(parsed, dict):
        slim: Dict[str, Any] = {}
        for idx, (k, v) in enumerate(parsed.items()):
            if idx >= 48:
                slim["_truncated_keys"] = f"{len(parsed) - 48} more"
                break
            if isinstance(v, dict):
                slim[k] = json.dumps(v, ensure_ascii=False, default=str)[:1200]
            elif isinstance(v, list):
                slim[k] = f"<list len={len(v)}>"
                if len(v) <= 8:
                    slim[k] = v
            else:
                s = json.dumps(v, ensure_ascii=False, default=str) if not isinstance(v, str) else v
                slim[k] = s[:2000] + ("..." if len(s) > 2000 else "")
        return {"parsed": slim}
    if isinstance(parsed, list):
        return {"parsed_list": {"length": len(parsed), "sample": parsed[:6]}}
    return {"parsed": str(parsed)[:4000]}


def _execution_state_append(
    state: Dict[str, Any],
    *,
    step_index: int,
    tool_name: str,
    result_text: str,
) -> None:
    steps: List[Dict[str, Any]] = state.setdefault("steps", [])
    steps.append(
        {
            "step": step_index,
            "tool": tool_name,
            "result": _tool_result_summary_for_chain(result_text),
        }
    )
    max_steps = int(os.getenv("AGENT_RUNTIME_TOOL_STATE_MAX_STEPS", "12"))
    if len(steps) > max_steps:
        del steps[: len(steps) - max_steps]


def _execution_state_system_content(state: Dict[str, Any]) -> str:
    """Extra system text listing prior tool outputs for chaining."""
    steps = state.get("steps") or []
    if not steps:
        return ""
    try:
        blob = json.dumps({"tool_chain_state": steps}, ensure_ascii=False, default=str)
    except TypeError:
        blob = str(steps)
    max_chars = int(os.getenv("AGENT_RUNTIME_MAX_TOOL_STATE_CHARS", str(_DEFAULT_TOOL_STATE_MAX_CHARS)))
    if len(blob) > max_chars:
        blob = blob[:max_chars] + "\n...[tool_chain_state truncated]"
    return (
        "Tool chain state (use this when calling the next tool). "
        "Copy IDs, amounts, prices, tokens, and status fields from `result.parsed` below — do not guess or invent values.\n"
        + blob
    )


def _redact_for_log(text: str) -> str:
    """Best-effort redaction for log lines (not cryptographic)."""
    if not text:
        return text
    out = text
    out = re.sub(r"Bearer\s+[A-Za-z0-9\-._~+/]+=*", "Bearer ***", out, flags=re.IGNORECASE)
    out = re.sub(
        r'(?i)(apikey|api_key|password|secret|token|authorization)\s*[:=]\s*["\']?[^\s,"\']+',
        r"\1=***",
        out,
    )
    return out


def _trunc_for_log(s: str, max_len: int) -> str:
    s = s or ""
    if len(s) <= max_len:
        return s
    return s[:max_len] + f"\n... [{len(s) - max_len} more chars truncated for log]"

# Optional OpenAI
try:
    from openai import AsyncOpenAI
except ImportError:
    AsyncOpenAI = None  # type: ignore


def _env_flag(name: str, default: str = "1") -> bool:
    return os.getenv(name, default).strip().lower() not in ("0", "false", "no", "off")


def _sanitize_tool_name(s: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_]", "_", s)
    if not s or s[0].isdigit():
        s = "t_" + s
    return s[:64]


def _flow_dict(raw: Any) -> Dict[str, Any]:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}
    return {}


def _tool_row_id(row: Any) -> int:
    try:
        return int(getattr(row, "id", None) or (row.get("id") if isinstance(row, dict) else 0) or 0)
    except (TypeError, ValueError):
        return 0


def _first_converser_node(flow: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Primary converser: first node in canvas order linked from initializer (matches codegen)."""
    nodes = flow.get("nodes") or []
    edges = flow.get("edges") or []
    initializer = next(
        (n for n in nodes if isinstance(n, dict) and n.get("type") == "initializer"),
        None,
    )
    if not initializer:
        return None
    init_id = initializer.get("id")
    if init_id is None:
        return None

    def _linked_from_initializer(target: Dict[str, Any]) -> bool:
        tid = target.get("id")
        if tid is None:
            return False
        return any(
            isinstance(e, dict) and e.get("source") == init_id and e.get("target") == tid for e in edges
        )

    for n in nodes:
        if isinstance(n, dict) and _linked_from_initializer(n):
            return n
    return None


def _explicit_db_tool_ids_from_primary(node: Optional[Dict[str, Any]]) -> Optional[set[int]]:
    """Returns which catalog tool IDs to expose.

    - ``None``: `data.tools` key absent — legacy; use all fetched catalog tools.
    - ``set()`` (empty): `data.tools` is empty list; treat like **not configured** — use all
      catalog tools (empty array is common when the user has not attached tools yet).
    - non-empty set: only these tool IDs (from ConversableAgentConfig).
    """
    if not node or not isinstance(node, dict):
        return None
    data = node.get("data")
    if not isinstance(data, dict):
        return None
    if "tools" not in data:
        return None
    raw = data.get("tools") or []
    out: set[int] = set()
    for x in raw:
        try:
            out.add(int(x))
        except (TypeError, ValueError):
            continue
    return out


def _message_suggests_api_or_http_tools(text: str) -> bool:
    """Heuristic: user wants external/API data — nudge model to call tools on first turn."""
    if not text or not str(text).strip():
        return False
    t = str(text).lower()
    if re.search(r"\b(api|http|https|endpoint|fetch|request|curl|invoke|rest)\b", t):
        return True
    if re.search(
        r"\b(get|give|retrieve|show|pull|load)\b.{0,80}\b(data|response|json|body|result)\b", t, re.DOTALL
    ):
        return True
    return False


def _is_placeholder_http_url(url: str) -> bool:
    u = (url or "").strip().lower()
    if not u:
        return True
    return "example.com" in u or "api.example" in u


def _tool_row_name_by_id(tools_rows: List[Any], tid: int) -> str:
    for tr in tools_rows:
        if _tool_row_id(tr) == tid:
            return str(getattr(tr, "name", None) or (tr.get("name") if isinstance(tr, dict) else "") or "")
    return ""


def _is_http_request_catalog_tool_name(name: str) -> bool:
    """Catalog tools may be renamed (e.g. 'HTTP Request new'); match by intent, not exact string."""
    n = (name or "").strip().lower()
    if not n:
        return False
    if "http" in n and "request" in n:
        return True
    return n in ("http request", "httpx request")


def _tool_has_real_http_default_url(tool_row: Any) -> bool:
    variables = getattr(tool_row, "variables", None) or (
        tool_row.get("variables") if isinstance(tool_row, dict) else []
    ) or []
    if not isinstance(variables, list):
        return False
    for item in variables:
        if not isinstance(item, dict):
            continue
        if str(item.get("name") or "").strip().lower() != "url":
            continue
        for key in ("value", "default"):
            val = str(item.get(key) or "").strip()
            if val and not _is_placeholder_http_url(val):
                return True
    return False


def _http_defaults_from_flow(
    flow: Dict[str, Any],
    tools_rows: List[Any],
) -> Dict[str, Any]:
    """URL/method/headers/data from any node's toolParameterConfigs (not only primary converser).

    Renamed HTTP tools and configs on user/conversable/assistant nodes are all considered.
    """
    out: Dict[str, Any] = {}

    def _pull(cfg: Dict[str, Any]) -> Dict[str, Any]:
        block: Dict[str, Any] = {}
        if not isinstance(cfg, dict):
            return block
        u = (cfg.get("url") or "").strip()
        if u:
            block["url"] = u
        m = (cfg.get("method") or "GET").strip().upper()
        if m:
            block["method"] = m
        h = cfg.get("headers")
        if h is not None:
            block["headers"] = h
        d = cfg.get("data")
        if d is not None:
            block["data"] = d
        return block

    for node in flow.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        data = node.get("data") or {}
        if not isinstance(data, dict):
            continue
        tpc = data.get("toolParameterConfigs") or {}
        if not isinstance(tpc, dict) or not tpc:
            continue

        # Prefer catalog HTTP Request-style tool with a real URL
        for key, cfg in tpc.items():
            if not isinstance(cfg, dict):
                continue
            try:
                tid = int(key)
            except (TypeError, ValueError):
                continue
            tname = _tool_row_name_by_id(tools_rows, tid)
            if not _is_http_request_catalog_tool_name(tname):
                continue
            block = _pull(cfg)
            u = str(block.get("url", "")).strip()
            if u and not _is_placeholder_http_url(u):
                out.update(block)
                logger.info(
                    "[agent_runtime] HTTP defaults from node %s tool_id=%s (%s): %s %s",
                    node.get("id"),
                    tid,
                    tname,
                    block.get("method"),
                    (block.get("url") or "")[:120],
                )
                return out

        # Any tool block with a non-placeholder URL on this node
        for cfg in tpc.values():
            if not isinstance(cfg, dict):
                continue
            block = _pull(cfg)
            u = str(block.get("url", "")).strip()
            if u and not _is_placeholder_http_url(u):
                out.update(block)
                logger.info(
                    "[agent_runtime] HTTP defaults from node %s (non-placeholder url in config): %s",
                    node.get("id"),
                    (block.get("url") or "")[:120],
                )
                return out
    return out


def _rag_defaults_from_flow(flow: Dict[str, Any], tools_rows: List[Any]) -> Dict[str, Any]:
    """file_path / knowledge_text / chunk settings from canvas toolParameterConfigs for RAG Search."""
    out: Dict[str, Any] = {}
    for node in flow.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        data = node.get("data") or {}
        if not isinstance(data, dict):
            continue
        tpc = data.get("toolParameterConfigs") or {}
        if not isinstance(tpc, dict) or not tpc:
            continue
        for key, cfg in tpc.items():
            if not isinstance(cfg, dict):
                continue
            try:
                tid = int(key)
            except (TypeError, ValueError):
                continue
            tname = _tool_row_name_by_id(tools_rows, tid)
            if not _is_rag_search_catalog_tool(tname):
                continue
            fp = str(cfg.get("file_path") or "").strip()
            kt = str(cfg.get("knowledge_text") or "").strip()
            if not fp and not kt:
                continue
            if fp:
                out["file_path"] = fp
            if kt:
                out["knowledge_text"] = kt
            for k in ("chunk_size", "chunk_overlap", "top_k"):
                v = cfg.get(k)
                if v is not None and str(v).strip() != "":
                    out[k] = v
            logger.info(
                "[agent_runtime] RAG defaults from node %s tool_id=%s (%s): file_path=%s",
                node.get("id"),
                tid,
                tname,
                (fp[:100] + "…") if len(fp) > 100 else fp,
            )
            return out
    return out


def _rag_defaults_from_knowledge_context(
    project_row: Dict[str, Any],
    knowledge_context: Optional[Dict[str, Any]],
    user_message: str = "",
) -> Dict[str, Any]:
    """Build fallback RAG defaults from bot knowledge bindings when canvas tool config is empty."""
    ctx = knowledge_context if isinstance(knowledge_context, dict) else {}
    retrieval_defaults = ctx.get("retrieval_defaults") or {}
    enable_rag = retrieval_defaults.get("enable_rag")
    if isinstance(enable_rag, bool) and not enable_rag:
        return {}

    out: Dict[str, Any] = {}
    for source_key, target_key in (
        ("chunk_size", "chunk_size"),
        ("chunk_overlap", "chunk_overlap"),
        ("top_k", "top_k"),
    ):
        value = retrieval_defaults.get(source_key)
        if value not in (None, ""):
            out[target_key] = value

    documents = ctx.get("documents") or []
    user_id = str(project_row.get("user_id") or "").strip()
    if not user_id or not isinstance(documents, list):
        return out

    try:
        from ..utils.knowledge_registry import resolve_relative_path
        from ..utils.rag_tool import extract_text_from_path
    except Exception as exc:
        logger.warning("Failed to import knowledge helpers for runtime RAG defaults: %s", exc)
        return out

    resolved_docs: List[Tuple[Dict[str, Any], str]] = []
    for item in documents[:6]:
        if not isinstance(item, dict):
            continue
        relative_path = str(item.get("relative_path") or "").strip()
        if not relative_path:
            continue
        status = str(item.get("status") or "").strip().lower()
        if status and status not in ("indexed", "synced"):
            continue
        try:
            abs_path = resolve_relative_path(user_id, relative_path)
        except Exception as exc:
            logger.warning("Unable to resolve bound knowledge path %s: %s", relative_path, exc)
            continue
        if abs_path.exists() and abs_path.is_file():
            resolved_docs.append((item, str(abs_path)))

    if not resolved_docs:
        return out

    query_terms = set(re.findall(r"\w+", str(user_message or "").lower()))
    if query_terms:
        best_doc: Optional[Tuple[Dict[str, Any], str]] = None
        best_score = -1
        for item, abs_path in resolved_docs:
            title = str(item.get("title") or item.get("relative_path") or "").lower()
            title_terms = set(re.findall(r"\w+", title))
            title_score = len(query_terms & title_terms) * 4
            content_score = 0
            try:
                from ..utils.rag_tool import extract_text_from_path

                preview = (extract_text_from_path(abs_path) or "")[:2000].lower()
                preview_terms = set(re.findall(r"\w+", preview))
                content_score = len(query_terms & preview_terms)
            except Exception:
                content_score = 0
            total_score = title_score + content_score
            if total_score > best_score:
                best_score = total_score
                best_doc = (item, abs_path)
        if best_doc and best_score > 0:
            out["file_path"] = best_doc[1]
            return out

    if len(resolved_docs) == 1:
        out["file_path"] = resolved_docs[0][1]
        return out

    combined_parts: List[str] = []
    total_chars = 0
    max_chars = 120000
    for item, abs_path in resolved_docs[:3]:
        try:
            extracted = re.sub(r"\s+", " ", extract_text_from_path(abs_path) or "").strip()
        except Exception as exc:
            logger.warning("Failed to extract bound knowledge text from %s: %s", abs_path, exc)
            continue
        if not extracted:
            continue
        title = str(item.get("title") or item.get("relative_path") or abs_path).strip()
        prefix = f"Document: {title}\n"
        remaining = max_chars - total_chars
        if remaining <= len(prefix):
            break
        piece = prefix + extracted[: remaining - len(prefix)]
        combined_parts.append(piece)
        total_chars += len(piece)
        if total_chars >= max_chars:
            break

    if combined_parts:
        out["knowledge_text"] = "\n\n".join(combined_parts)
    else:
        out["file_path"] = resolved_docs[0][1]
    return out


def _knowledge_context_summary(knowledge_context: Optional[Dict[str, Any]]) -> str:
    ctx = knowledge_context if isinstance(knowledge_context, dict) else {}
    documents = ctx.get("documents") or []
    retrieval_defaults = ctx.get("retrieval_defaults") or {}
    lines: List[str] = []
    if isinstance(documents, list) and documents:
        lines.append("Bound knowledge documents available to the bot:")
        for item in documents[:8]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or item.get("relative_path") or "document").strip()
            rel = str(item.get("relative_path") or "").strip()
            collection = str(item.get("collection_name") or "").strip()
            status = str(item.get("status") or "").strip()
            lines.append(
                f"- {title} | path={rel or 'n/a'} | collection={collection or 'n/a'} | status={status or 'unknown'}"
            )
    if retrieval_defaults:
        lines.append(
            "Knowledge retrieval defaults: "
            f"top_k={retrieval_defaults.get('top_k')}, "
            f"chunk_size={retrieval_defaults.get('chunk_size')}, "
            f"chunk_overlap={retrieval_defaults.get('chunk_overlap')}, "
            f"enable_rag={retrieval_defaults.get('enable_rag')}"
        )
    if lines:
        lines.append(
            "When the user asks about information likely covered by these documents, use RAG Search before asking them to upload/share the file again."
        )
    return "\n".join(lines).strip()


def _nlu_context_summary(ai_config: Optional[Dict[str, Any]], nlu_context: Optional[Dict[str, Any]]) -> str:
    config = ai_config if isinstance(ai_config, dict) else {}
    ctx = nlu_context if isinstance(nlu_context, dict) else {}
    intents = config.get("intents") or []
    entities = config.get("entities") or []
    best_intent = (ctx.get("intent_result") or {}).get("best_intent") or {}
    found_entities = (ctx.get("entity_result") or {}).get("entities") or []
    detected_language = ctx.get("detected_language") or config.get("defaultLanguage") or "unknown"

    lines: List[str] = [f"Detected language: {detected_language}"]
    if best_intent:
        lines.append(
            "Best intent: "
            f"name={best_intent.get('name')} "
            f"confidence={best_intent.get('confidence')} "
            f"route_target={best_intent.get('route_target') or 'none'} "
            f"matched_utterance={best_intent.get('matched_utterance') or 'none'}"
        )
    if found_entities:
        lines.append("Extracted entities:")
        for item in found_entities[:8]:
            if not isinstance(item, dict):
                continue
            lines.append(
                f"- {item.get('name')}: value={item.get('value')} normalized={item.get('normalized_value')} confidence={item.get('confidence')}"
            )
    if intents:
        lines.append("Configured intents:")
        for item in intents[:12]:
            if not isinstance(item, dict) or not item.get("name"):
                continue
            lines.append(
                f"- {item.get('name')}: route_target={item.get('routeTarget') or 'none'} utterances={str(item.get('utterancesText') or '').replace(chr(10), ' | ')[:220]}"
            )
    if entities:
        lines.append("Configured entities:")
        for item in entities[:12]:
            if not isinstance(item, dict) or not item.get("name"):
                continue
            lines.append(
                f"- {item.get('name')}: type={item.get('entityType') or 'text'} examples={str(item.get('examplesText') or '').replace(chr(10), ' | ')[:180]}"
            )
    return "\n".join(lines).strip()


def _route_aware_no_match_reply(
    user_message: str,
    nlu_context: Optional[Dict[str, Any]],
) -> Optional[str]:
    ctx = nlu_context if isinstance(nlu_context, dict) else {}
    best_intent = (ctx.get("intent_result") or {}).get("best_intent") or {}
    if not best_intent:
        return None

    intent_name = str(best_intent.get("name") or "").strip()
    route_target = str(best_intent.get("route_target") or "").strip()
    query = str(user_message or "").strip()
    if not intent_name:
        return None

    lowered = f"{intent_name} {route_target} {query}".lower()
    if any(token in lowered for token in ("pricing", "quote", "sales", "plan", "enterprise")):
        target_text = f" The configured route target is `{route_target}`." if route_target else ""
        return (
            "I could not find enterprise pricing details in the bot's current knowledge sources."
            f"{target_text} "
            "This request matches the pricing intent, so the next step is to connect a pricing document, pricing API, or sales workflow for this bot."
        )

    if route_target:
        return (
            f"I could not find the requested information in the bot's current knowledge sources. "
            f"This message matches the `{intent_name}` intent and is configured to route to `{route_target}`."
        )
    return None


def _merge_rag_tool_args_with_defaults(args: Dict[str, Any], defaults: Dict[str, Any]) -> Dict[str, Any]:
    """Apply canvas-saved file_path / knowledge_text when the model only passes query."""
    if not defaults:
        return args
    out = dict(args or {})
    if not str(out.get("file_path") or "").strip() and str(defaults.get("file_path") or "").strip():
        out["file_path"] = str(defaults["file_path"]).strip()
    if not str(out.get("knowledge_text") or "").strip() and str(defaults.get("knowledge_text") or "").strip():
        out["knowledge_text"] = str(defaults["knowledge_text"]).strip()
    for k in ("chunk_size", "chunk_overlap", "top_k"):
        if out.get(k) in (None, "") and defaults.get(k) not in (None, ""):
            out[k] = defaults[k]
    return out


def _merge_http_tool_args_with_defaults(args: Dict[str, Any], defaults: Dict[str, Any]) -> Dict[str, Any]:
    """Fill missing or placeholder model args from canvas defaults."""
    if not defaults:
        return args
    out = dict(args or {})
    cur_url = str(out.get("url", "")).strip()
    if _is_placeholder_http_url(cur_url) and defaults.get("url"):
        out["url"] = str(defaults["url"]).strip()
        # Model often sends GET + example.com; canvas may be POST with a real endpoint.
        if defaults.get("method"):
            out["method"] = str(defaults["method"]).strip()
    elif not str(out.get("method", "")).strip() and defaults.get("method"):
        out["method"] = str(defaults["method"]).strip()
    if (not out.get("headers")) and defaults.get("headers") is not None:
        out["headers"] = defaults["headers"]
    if out.get("data") is None and defaults.get("data") is not None:
        out["data"] = defaults["data"]
    return out


def _unwrap_llm_nested_tool_args(args: Dict[str, Any]) -> Dict[str, Any]:
    """Unwrap payloads like {\"args\": \"{\\\"query\\\":\\\"...\\\"}\"} or HTTP nested JSON.

    When the model wraps real parameters in a string under ``args``, merge into flat keys for
    HTTP Request, RAG Search, etc.
    """
    if not isinstance(args, dict):
        return {}
    wrapped = args.get("args")
    if wrapped is None:
        return dict(args)
    inner: Dict[str, Any] = {}
    if isinstance(wrapped, str) and wrapped.strip():
        try:
            p = json.loads(wrapped)
            if isinstance(p, dict):
                inner = p
        except json.JSONDecodeError:
            return dict(args)
    elif isinstance(wrapped, dict):
        inner = wrapped
    if not inner:
        return dict(args)
    # Inner params + any top-level keys except the wrapper (outer wins for same key)
    merged = {**inner, **{k: v for k, v in args.items() if k != "args"}}
    return merged


def _is_rag_search_catalog_tool(name: str) -> bool:
    n = (name or "").strip().lower()
    return n == "rag search" or n.startswith("rag search ")


def _coerce_rag_search_args(args: Dict[str, Any]) -> Dict[str, Any]:
    """If the model put free text in ``args`` (plain string, not JSON), map it to ``query``."""
    out = dict(args or {})
    q = str(out.get("query", "")).strip()
    if q:
        return out
    raw = out.get("args")
    if isinstance(raw, str) and raw.strip():
        s = raw.strip()
        if s.startswith("{"):
            try:
                inner = json.loads(s)
                if isinstance(inner, dict):
                    merged = {**inner, **{k: v for k, v in out.items() if k != "args"}}
                    if str(merged.get("query", "")).strip():
                        return merged
            except json.JSONDecodeError:
                pass
        out["query"] = s
        out.pop("args", None)
    return out


def _primary_converser_tool_context(primary: Optional[Dict[str, Any]]) -> str:
    """Surface canvas `data.tools` / `toolParameterConfigs` so the model sees latest editor defaults."""
    if not primary or not isinstance(primary, dict):
        return ""
    data = primary.get("data")
    if not isinstance(data, dict):
        return ""
    parts: List[str] = []
    tids = data.get("tools")
    if isinstance(tids, list) and tids:
        parts.append(f"Primary agent node — attached catalog tool ids: {tids}")
    tpc = data.get("toolParameterConfigs")
    if isinstance(tpc, dict) and tpc:
        try:
            compact = json.dumps(tpc, ensure_ascii=False, default=str)
        except TypeError:
            compact = str(tpc)
        if len(compact) > 4500:
            compact = compact[:4500] + "…"
        parts.append(
            "Primary agent node — toolParameterConfigs from canvas (use as defaults when calling tools, e.g. url/method): "
            + compact
        )
    return "\n".join(parts).strip()


def _substitute_placeholders(template: str, values: Dict[str, Any]) -> str:
    if not template:
        return template

    def repl(m: re.Match) -> str:
        key = (m.group(1) or "").strip()
        if key.startswith("context."):
            key = key[8:]
        v = values.get(key)
        if v is None:
            return m.group(0)
        return str(v)

    out = template
    out = re.sub(r"\{\{\s*([^}]+?)\s*\}\}", repl, out)
    return out


def _resolve_dot_path(values: Dict[str, Any], path: str) -> Any:
    cur: Any = values
    for part in [p for p in (path or "").split(".") if p]:
        if isinstance(cur, dict):
            cur = cur.get(part)
            continue
        if isinstance(cur, list):
            try:
                idx = int(part)
            except (TypeError, ValueError):
                return None
            if idx < 0 or idx >= len(cur):
                return None
            cur = cur[idx]
            continue
        return None
    return cur


def _render_template_string(template: str, values: Dict[str, Any]) -> str:
    if not template:
        return template

    def repl(m: re.Match) -> str:
        key = (m.group(1) or "").strip()
        if key.startswith("context."):
            key = key[8:]
        v = _resolve_dot_path(values, key)
        if v is None:
            return m.group(0)
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False, default=str)
        return str(v)

    return re.sub(r"\{\{\s*([^}]+?)\s*\}\}", repl, template)


def _render_template_value(obj: Any, values: Dict[str, Any]) -> Any:
    if isinstance(obj, str):
        s = _render_template_string(obj, values)
        try:
            return json.loads(s)
        except json.JSONDecodeError:
            return s
    if isinstance(obj, list):
        return [_render_template_value(x, values) for x in obj]
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            out[str(k)] = _render_template_value(v, values)
        return out
    return obj


def _latest_tool_chain_context(execution_state: Dict[str, Any]) -> Dict[str, Any]:
    steps = execution_state.get("steps") or []
    if not steps:
        return {}
    last = steps[-1] if isinstance(steps[-1], dict) else {}
    return {
        "last": last.get("result") or {},
        "steps": steps,
    }


async def _http_request_node(
    node_data: Dict[str, Any],
    arguments: Dict[str, Any],
    chain_context: Optional[Dict[str, Any]] = None,
) -> str:
    """Execute an `api` flow node using httpx."""
    method = (node_data.get("apiMethod") or "GET").upper()
    url_template = node_data.get("apiUrl") or ""
    if not url_template.strip():
        return json.dumps({"error": "api node has empty apiUrl"})

    subs = arguments.get("substitutions") if isinstance(arguments.get("substitutions"), dict) else {}
    if not subs and isinstance(arguments, dict):
        # allow flat kwargs from model
        subs = {k: v for k, v in arguments.items() if k not in ("substitutions", "body_json")}
    if chain_context:
        subs = {**chain_context, **subs}

    url = _render_template_string(url_template, subs)

    headers: Dict[str, str] = {}
    for h in node_data.get("headers") or []:
        if isinstance(h, dict) and h.get("key"):
            hk = _render_template_string(str(h.get("key", "")), subs)
            hv = _render_template_string(str(h.get("value", "")), subs)
            headers[hk] = hv

    params: Dict[str, str] = {}
    for p in node_data.get("parameters") or []:
        if isinstance(p, dict) and p.get("key"):
            pk = _render_template_string(str(p.get("key", "")), subs)
            pv = _render_template_string(str(p.get("value", "")), subs)
            params[pk] = pv

    body_str = node_data.get("body") or ""
    body_str = _render_template_string(body_str, subs)
    body_json = arguments.get("body_json")
    content: Any = None
    if body_json is not None:
        if isinstance(body_json, str):
            try:
                content = json.loads(body_json)
            except json.JSONDecodeError:
                content = body_json
        else:
            content = body_json
    elif body_str.strip():
        try:
            content = json.loads(body_str)
        except json.JSONDecodeError:
            content = body_str

    timeout = httpx.Timeout(60.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            request_kwargs: Dict[str, Any] = {"headers": headers}
            if params:
                request_kwargs["params"] = params
            if method == "GET":
                r = await client.request(method, url, **request_kwargs)
            elif method in ("POST", "PUT", "PATCH", "DELETE"):
                if content is not None and isinstance(content, (dict, list)):
                    r = await client.request(method, url, json=content, **request_kwargs)
                else:
                    r = await client.request(method, url, content=body_str or None, **request_kwargs)
            else:
                r = await client.request(method, url, **request_kwargs)
            text = r.text
            if len(text) > 12000:
                text = text[:12000] + "\n...[truncated]"
            return json.dumps(
                {
                    "status_code": r.status_code,
                    "url": str(r.url),
                    "body": text,
                },
                ensure_ascii=False,
            )
        except Exception as e:
            return json.dumps({"error": str(e), "url": url})


async def _run_registered_db_tool(
    name: str,
    raw_args: str,
    chain_context: Optional[Dict[str, Any]] = None,
) -> str:
    """Execute whitelisted tools from the tools table by name."""
    try:
        args = json.loads(raw_args) if raw_args else {}
    except json.JSONDecodeError:
        args = {"_raw": raw_args}

    if name == "HTTP Request":
        import requests

        args = _unwrap_llm_nested_tool_args(args if isinstance(args, dict) else {})
        if chain_context:
            args = _render_template_value(args, chain_context)

        method = str(args.get("method", "GET")).upper()
        url = str(args.get("url", "")).strip()
        headers = args.get("headers")
        if isinstance(headers, str):
            try:
                headers = json.loads(headers)
            except json.JSONDecodeError:
                headers = {}
        data = args.get("data")
        if not url:
            return json.dumps({"error": "url is required"})
        if _is_placeholder_http_url(url):
            return json.dumps(
                {
                    "error": "HTTP Request tool is not configured with a real endpoint. Update the tool or canvas URL before using it.",
                    "url": url,
                }
            )
        try:
            if method == "GET":
                r = requests.get(url, headers=headers or {}, timeout=30)
            elif method in ("POST", "PUT", "PATCH", "DELETE"):
                req_kwargs: Dict[str, Any] = {"headers": headers or {}, "timeout": 30}
                if isinstance(data, (dict, list)):
                    req_kwargs["json"] = data
                elif data is not None:
                    req_kwargs["data"] = str(data)
                r = requests.request(method, url, **req_kwargs)
            else:
                return json.dumps({"error": f"unsupported method {method}"})
            body = r.text
            if len(body) > 12000:
                body = body[:12000] + "...[truncated]"
            return json.dumps({"status_code": r.status_code, "body": body})
        except Exception as e:
            return json.dumps({"error": str(e)})

    if _is_rag_search_catalog_tool(name):
        from agentok_api.utils.rag_tool import run_rag_search

        args = _unwrap_llm_nested_tool_args(args if isinstance(args, dict) else {})
        args = _coerce_rag_search_args(args)
        query = str(args.get("query", "")).strip()
        if not query:
            return json.dumps(
                {
                    "error": "query is required — pass the user's question as the top-level \"query\" string.",
                }
            )
        file_path = args.get("file_path") or None
        knowledge_text = args.get("knowledge_text") or None
        try:
            chunk_size = int(args.get("chunk_size", 500))
            chunk_overlap = int(args.get("chunk_overlap", 50))
            top_k = int(args.get("top_k", 3))
        except (TypeError, ValueError):
            chunk_size, chunk_overlap, top_k = 500, 50, 3
        try:
            out = run_rag_search(
                query=query,
                file_path=file_path,
                knowledge_text=knowledge_text,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                top_k=top_k,
            )
            return json.dumps(out, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": str(e)})

    return json.dumps({"error": f"Tool {name!r} is not available in agent runtime registry."})


async def _tavily_search(query: str) -> str:
    key = (os.getenv("TAVILY_API_KEY") or "").strip()
    if not key:
        return json.dumps({"error": "TAVILY_API_KEY not configured"})
    try:
        from tavily import TavilyClient

        client = TavilyClient(api_key=key)
        resp = client.search(query=query, max_results=5)
        return json.dumps(resp, ensure_ascii=False, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


async def _builtin_invoke_http(
    arguments: Dict[str, Any],
    chain_context: Optional[Dict[str, Any]] = None,
) -> str:
    """Direct HTTP GET/POST for agent runtime when catalog tools are unavailable."""
    if chain_context:
        arguments = _render_template_value(arguments, chain_context)
    method = str(arguments.get("method", "GET")).upper()
    url = str(arguments.get("url", "")).strip()
    if not url:
        return json.dumps({"error": "url is required"})
    if _is_placeholder_http_url(url):
        return json.dumps(
            {
                "error": "No real HTTP endpoint is configured for this bot. Add a valid API URL before using invoke_http.",
                "url": url,
            }
        )
    headers = arguments.get("headers")
    if isinstance(headers, str):
        try:
            headers = json.loads(headers)
        except json.JSONDecodeError:
            headers = {}
    if not isinstance(headers, dict):
        headers = {}
    data = arguments.get("data")
    if data is None:
        data = arguments.get("body")

    timeout = httpx.Timeout(60.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            if method == "GET":
                r = await client.get(url, headers=headers)
            elif method in ("POST", "PUT", "PATCH", "DELETE"):
                if isinstance(data, (dict, list)):
                    r = await client.request(method, url, headers=headers, json=data)
                else:
                    r = await client.request(
                        method, url, headers=headers, content=str(data) if data is not None else None
                    )
            else:
                return json.dumps({"error": f"unsupported method {method} (use GET/POST/PUT/PATCH/DELETE)"})
            body = r.text
            if len(body) > 12000:
                body = body[:12000] + "...[truncated]"
            return json.dumps({"status_code": r.status_code, "body": body})
        except Exception as e:
            return json.dumps({"error": str(e), "url": url})


def _builtin_invoke_http_tool_definition(extra_description: str = "") -> Dict[str, Any]:
    desc = (
        "Call an external HTTP API (GET or POST). Use this to fetch JSON/text from a URL "
        "when the user asks for API data or web resources."
    )
    if extra_description:
        desc = f"{desc} {extra_description}"
    return {
        "type": "function",
        "function": {
            "name": "invoke_http",
            "description": desc[:1024],
            "parameters": {
                "type": "object",
                "properties": {
                    "method": {
                        "type": "string",
                        "description": "HTTP method",
                        "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                    },
                    "url": {"type": "string", "description": "Full URL including https://"},
                    "headers": {
                        "type": "object",
                        "description": "Optional HTTP headers (object).",
                        "additionalProperties": {"type": "string"},
                    },
                    "data": {
                        "type": "object",
                        "description": "Optional request body for non-GET requests. Supports placeholders like {{last.parsed.order_id}} in string fields.",
                    },
                },
                "required": ["method", "url"],
            },
        },
    }

async def _load_runtime_whatsapp_connections(db: Any, project_id: Any) -> List[Dict[str, Any]]:
    if not project_id:
        return []
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT id,
                       name,
                       provider,
                       graph_version,
                       phone_number_id,
                       display_phone_number,
                       business_phone_number,
                       project_id,
                       bot_project_id,
                       pgp_sym_decrypt(access_token_encrypted, $2::text) AS access_token
                FROM whatsapp_connections
                WHERE bot_project_id = $1 OR project_id = $1
                ORDER BY updated_at DESC, created_at DESC
                """,
                project_id,
                connector_credentials_secret(),
            )
            return [dict(row) for row in rows]
    except Exception as exc:
        logger.warning("Failed loading WhatsApp connections for runtime: %s", exc)
        return []


def _summarize_whatsapp_connections(connections: List[Dict[str, Any]]) -> str:
    if not connections:
        return ""
    items = []
    for row in connections[:8]:
        label = (
            str(row.get("name") or "").strip()
            or str(row.get("display_phone_number") or "").strip()
            or str(row.get("business_phone_number") or "").strip()
            or str(row.get("id"))
        )
        items.append(f"{label} ({row.get('id')})")
    return "; available connections: " + ", ".join(items)


async def _load_runtime_connector_connections(db: Any, project_id: Any) -> List[Dict[str, Any]]:
    whatsapp_connections = await _load_runtime_whatsapp_connections(db, project_id)
    normalized: List[Dict[str, Any]] = []
    for row in whatsapp_connections:
        definition = get_whatsapp_connector_definition(str(row.get("provider") or "meta_cloud"))
        normalized.append(
            {
                **row,
                "connector_key": definition.get("connector_key", "whatsapp_meta_cloud"),
                "channel_key": definition.get("channel_key", "whatsapp"),
                "provider_key": definition.get("provider_key", str(row.get("provider") or "meta_cloud")),
                "capabilities": definition.get("capabilities") or {},
            }
        )
    return normalized


def _summarize_connector_connections(connections: List[Dict[str, Any]]) -> str:
    if not connections:
        return ""
    items = []
    for row in connections[:8]:
        label = (
            str(row.get("name") or "").strip()
            or str(row.get("display_phone_number") or "").strip()
            or str(row.get("business_phone_number") or "").strip()
            or str(row.get("id"))
        )
        connector_key = str(row.get("connector_key") or row.get("channel_key") or "connector")
        items.append(f"{label} [{connector_key}] ({row.get('id')})")
    return "; available connector connections: " + ", ".join(items)


def _runtime_connector_tool_definitions(
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if not connections:
        return []
    current_connector = (chat_cfg.get("connector") or {}) if isinstance(chat_cfg, dict) else {}
    current_wa = (chat_cfg.get("whatsapp") or {}) if isinstance(chat_cfg, dict) else {}
    current_connection_id = str(current_connector.get("connection_id") or current_wa.get("connection_id") or "").strip()
    current_to = str(current_connector.get("recipient") or current_wa.get("wa_user_phone_number") or "").strip()
    context_hint = []
    if current_connection_id:
        context_hint.append(f"current connection={current_connection_id}")
    if current_to:
        context_hint.append(f"current recipient={current_to}")
    extra = "."
    if context_hint:
        extra = "; " + ", ".join(context_hint) + "."
    extra += _summarize_connector_connections(connections)
    return [
        {
            "type": "function",
            "function": {
                "name": "send_connector_text",
                "description": ("Send a text message using the current linked connector" + extra)[:1024],
                "parameters": {
                    "type": "object",
                    "properties": {
                        "connection_id": {
                            "type": "string",
                            "description": "Optional connector connection UUID. Omit it to use the current chat connection or the only linked connection.",
                        },
                        "to": {
                            "type": "string",
                            "description": "Recipient identifier for the connector. Optional when replying inside a channel chat.",
                        },
                        "text": {
                            "type": "string",
                            "description": "Message text to send.",
                        },
                        "preview_url": {
                            "type": "boolean",
                            "description": "Whether URL previews should be enabled when supported by the connector.",
                        },
                    },
                    "required": ["text"],
                },
            },
        }
    ]


def _runtime_whatsapp_tool_definition(
    *,
    name: str,
    description: str,
    properties: Dict[str, Any],
    required: List[str],
) -> Dict[str, Any]:
    base_properties = {
        "connection_id": {
            "type": "string",
            "description": "Optional WhatsApp connection UUID. Omit it to use the current chat connection or the only linked connection.",
        },
        "to": {
            "type": "string",
            "description": "Recipient phone number in WhatsApp format. Optional when replying inside a WhatsApp chat.",
        },
    }
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description[:1024],
            "parameters": {
                "type": "object",
                "properties": {
                    **base_properties,
                    **properties,
                },
                "required": required,
            },
        },
    }


def _runtime_whatsapp_tool_definitions(
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if not connections:
        return []
    current_wa = (chat_cfg.get("whatsapp") or {}) if isinstance(chat_cfg, dict) else {}
    current_connection_id = str(current_wa.get("connection_id") or "").strip()
    current_to = str(current_wa.get("wa_user_phone_number") or "").strip()
    context_hint = []
    if current_connection_id:
        context_hint.append(f"current connection={current_connection_id}")
    if current_to:
        context_hint.append(f"current recipient={current_to}")
    extra = "."
    if context_hint:
        extra = "; " + ", ".join(context_hint) + "."
    extra += _summarize_whatsapp_connections(connections)
    return [
        _runtime_whatsapp_tool_definition(
            name="send_whatsapp_text",
            description="Send a plain text WhatsApp message" + extra,
            properties={
                "text": {"type": "string", "description": "Text body to send."},
                "preview_url": {"type": "boolean", "description": "Whether URLs should render a preview."},
            },
            required=["text"],
        ),
        _runtime_whatsapp_tool_definition(
            name="send_whatsapp_template",
            description="Send an approved WhatsApp template message" + extra,
            properties={
                "template_name": {"type": "string", "description": "Approved template name."},
                "language_code": {"type": "string", "description": "Template language code, e.g. en_US."},
                "components": {
                    "type": "array",
                    "description": "Optional Meta template components array.",
                    "items": {"type": "object"},
                },
            },
            required=["template_name"],
        ),
        _runtime_whatsapp_tool_definition(
            name="send_whatsapp_media",
            description="Send a media message on WhatsApp" + extra,
            properties={
                "media_type": {
                    "type": "string",
                    "enum": ["image", "document", "audio", "video", "sticker"],
                    "description": "Type of media message.",
                },
                "media_id": {"type": "string", "description": "Existing uploaded Meta media id."},
                "media_link": {"type": "string", "description": "Publicly reachable media URL."},
                "caption": {"type": "string", "description": "Optional caption for supported media."},
                "filename": {"type": "string", "description": "Optional filename for document messages."},
            },
            required=["media_type"],
        ),
        _runtime_whatsapp_tool_definition(
            name="send_whatsapp_interactive",
            description="Send a raw interactive WhatsApp message body without raw Graph API auth setup" + extra,
            properties={
                "interactive": {
                    "type": "object",
                    "description": "Meta interactive payload object.",
                },
            },
            required=["interactive"],
        ),
        _runtime_whatsapp_tool_definition(
            name="send_whatsapp_flow",
            description="Send a WhatsApp Flow entry message" + extra,
            properties={
                "flow_id": {"type": "string", "description": "Meta WhatsApp flow id."},
                "flow_cta": {"type": "string", "description": "CTA label shown to the user."},
                "flow_token": {"type": "string", "description": "Optional flow token."},
                "flow_action": {
                    "type": "string",
                    "enum": ["navigate", "data_exchange"],
                    "description": "Initial flow action.",
                },
                "flow_action_payload": {
                    "type": "object",
                    "description": "Optional payload for the selected flow action.",
                },
                "body_text": {"type": "string", "description": "Main message text shown above the flow CTA."},
                "header_text": {"type": "string", "description": "Optional header text."},
                "footer_text": {"type": "string", "description": "Optional footer text."},
            },
            required=["flow_id", "body_text"],
        ),
    ]


def _resolve_runtime_whatsapp_target(
    arguments: Dict[str, Any],
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], str, Optional[str]]:
    current_wa = (chat_cfg.get("whatsapp") or {}) if isinstance(chat_cfg, dict) else {}
    requested_connection_id = str(arguments.get("connection_id") or "").strip()
    current_connection_id = str(current_wa.get("connection_id") or "").strip()
    requested_to = str(arguments.get("to") or "").strip()
    current_to = str(current_wa.get("wa_user_phone_number") or "").strip()

    connection = None
    if requested_connection_id:
        connection = next((row for row in connections if str(row.get("id")) == requested_connection_id), None)
    elif current_connection_id:
        connection = next((row for row in connections if str(row.get("id")) == current_connection_id), None)
    elif len(connections) == 1:
        connection = connections[0]

    to_number = requested_to or current_to
    return connection, to_number, current_connection_id or None


def _resolve_runtime_connector_target(
    arguments: Dict[str, Any],
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], str, Optional[str]]:
    current_connector = (chat_cfg.get("connector") or {}) if isinstance(chat_cfg, dict) else {}
    current_wa = (chat_cfg.get("whatsapp") or {}) if isinstance(chat_cfg, dict) else {}
    requested_connection_id = str(arguments.get("connection_id") or "").strip()
    current_connection_id = str(current_connector.get("connection_id") or current_wa.get("connection_id") or "").strip()
    requested_to = str(arguments.get("to") or "").strip()
    current_to = str(current_connector.get("recipient") or current_wa.get("wa_user_phone_number") or "").strip()

    connection = None
    if requested_connection_id:
        connection = next((row for row in connections if str(row.get("id")) == requested_connection_id), None)
    elif current_connection_id:
        connection = next((row for row in connections if str(row.get("id")) == current_connection_id), None)
    elif len(connections) == 1:
        connection = connections[0]

    to_value = requested_to or current_to
    return connection, to_value, current_connection_id or None


async def _log_runtime_whatsapp_outbound_message(
    db: Any,
    *,
    connection: Dict[str, Any],
    chat_id: int,
    payload: Dict[str, Any],
    response: Optional[Dict[str, Any]],
    message_type: str,
    to_number: str,
    status_text: str = "sent",
    error_text: Optional[str] = None,
) -> None:
    try:
        wa_messages = (response or {}).get("messages") or []
        wa_message_id = wa_messages[0].get("id") if wa_messages and isinstance(wa_messages[0], dict) else None
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO whatsapp_messages (
                    id,
                    connection_id,
                    direction,
                    wa_message_id,
                    chat_id,
                    project_id,
                    from_number,
                    to_number,
                    message_type,
                    status,
                    payload,
                    response,
                    error,
                    created_at,
                    updated_at
                )
                VALUES (
                    $1, $2, 'outbound', $3, $4, $5, $6, $7, $8, $9, $10::jsonb, $11::jsonb, $12, NOW(), NOW()
                )
                ON CONFLICT (wa_message_id) DO UPDATE SET
                    chat_id = COALESCE(EXCLUDED.chat_id, whatsapp_messages.chat_id),
                    status = EXCLUDED.status,
                    response = EXCLUDED.response,
                    error = COALESCE(EXCLUDED.error, whatsapp_messages.error),
                    updated_at = NOW()
                """,
                uuid.uuid4(),
                connection.get("id"),
                wa_message_id,
                chat_id,
                connection.get("bot_project_id") or connection.get("project_id"),
                connection.get("display_phone_number") or connection.get("business_phone_number"),
                to_number,
                message_type,
                status_text,
                json.dumps(payload or {}),
                json.dumps(response or {}),
                error_text,
            )
    except Exception as exc:
        logger.warning("Failed logging runtime WhatsApp outbound message: %s", exc)


async def _builtin_whatsapp_action(
    db: Any,
    *,
    chat_id: int,
    arguments: Dict[str, Any],
    action_name: str,
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
    chain_context: Optional[Dict[str, Any]] = None,
) -> str:
    if chain_context:
        arguments = _render_template_value(arguments, chain_context)
    args = _unwrap_llm_nested_tool_args(arguments if isinstance(arguments, dict) else {})
    connection, to_number, current_connection_id = _resolve_runtime_whatsapp_target(args, connections, chat_cfg)
    if not connection:
        return json.dumps(
            {
                "error": "No WhatsApp connection could be resolved for this bot",
                "current_connection_id": current_connection_id,
                "available_connection_ids": [str(row.get("id")) for row in connections],
            }
        )
    if not to_number:
        return json.dumps({"error": "Recipient phone number is required"})

    payload: Dict[str, Any]
    message_type = "text"
    if action_name == "text":
        text = str(args.get("text") or "").strip()
        if not text:
            return json.dumps({"error": "text is required"})
        payload = {
            "recipient_type": "individual",
            "to": to_number,
            "type": "text",
            "text": {
                "preview_url": bool(args.get("preview_url", False)),
                "body": text,
            },
        }
        message_type = "text"
    elif action_name == "template":
        template_name = str(args.get("template_name") or "").strip()
        if not template_name:
            return json.dumps({"error": "template_name is required"})
        components = args.get("components")
        if not isinstance(components, list):
            components = []
        payload = {
            "recipient_type": "individual",
            "to": to_number,
            "type": "template",
            "template": {
                "name": template_name,
                "language": {"code": str(args.get("language_code") or "en_US")},
                "components": components,
            },
        }
        message_type = "template"
    elif action_name == "media":
        media_type = str(args.get("media_type") or "").strip().lower()
        if media_type not in {"image", "document", "audio", "video", "sticker"}:
            return json.dumps({"error": "media_type must be one of image, document, audio, video, sticker"})
        media_id = str(args.get("media_id") or "").strip()
        media_link = str(args.get("media_link") or "").strip()
        if not media_id and not media_link:
            return json.dumps({"error": "media_id or media_link is required"})
        media_obj: Dict[str, Any] = {}
        if media_id:
            media_obj["id"] = media_id
        if media_link:
            media_obj["link"] = media_link
        caption = str(args.get("caption") or "").strip()
        filename = str(args.get("filename") or "").strip()
        if caption:
            media_obj["caption"] = caption
        if filename and media_type == "document":
            media_obj["filename"] = filename
        payload = {
            "recipient_type": "individual",
            "to": to_number,
            "type": media_type,
            media_type: media_obj,
        }
        message_type = media_type
    elif action_name == "interactive":
        interactive = args.get("interactive")
        if not isinstance(interactive, dict) or not interactive:
            return json.dumps({"error": "interactive must be a non-empty object"})
        payload = {
            "recipient_type": "individual",
            "to": to_number,
            "type": "interactive",
            "interactive": interactive,
        }
        message_type = "interactive"
    elif action_name == "flow":
        flow_id = str(args.get("flow_id") or "").strip()
        body_text = str(args.get("body_text") or "").strip()
        if not flow_id or not body_text:
            return json.dumps({"error": "flow_id and body_text are required"})
        action_parameters: Dict[str, Any] = {
            "flow_message_version": "3",
            "flow_id": flow_id,
            "flow_cta": str(args.get("flow_cta") or "Open flow"),
            "flow_action": str(args.get("flow_action") or "navigate"),
        }
        flow_token = str(args.get("flow_token") or "").strip()
        if flow_token:
            action_parameters["flow_token"] = flow_token
        flow_action_payload = args.get("flow_action_payload")
        if isinstance(flow_action_payload, dict) and flow_action_payload:
            action_parameters["flow_action_payload"] = flow_action_payload
        interactive: Dict[str, Any] = {
            "type": "flow",
            "body": {"text": body_text},
            "action": {"name": "flow", "parameters": action_parameters},
        }
        header_text = str(args.get("header_text") or "").strip()
        footer_text = str(args.get("footer_text") or "").strip()
        if header_text:
            interactive["header"] = {"type": "text", "text": header_text}
        if footer_text:
            interactive["footer"] = {"text": footer_text}
        payload = {
            "recipient_type": "individual",
            "to": to_number,
            "type": "interactive",
            "interactive": interactive,
        }
        message_type = "flow"
    else:
        return json.dumps({"error": f"Unsupported WhatsApp action: {action_name}"})

    try:
        provider = get_whatsapp_provider(str(connection.get("provider") or "meta_cloud"))
        response = await provider.send_message_payload(
            graph_version=str(connection.get("graph_version") or "v23.0"),
            phone_number_id=str(connection.get("phone_number_id") or ""),
            access_token=str(connection.get("access_token") or ""),
            payload=payload,
        )
        await _log_runtime_whatsapp_outbound_message(
            db,
            connection=connection,
            chat_id=chat_id,
            payload=payload,
            response=response,
            message_type=message_type,
            to_number=to_number,
        )
        return json.dumps(
            {
                "ok": True,
                "connection_id": str(connection.get("id")),
                "to": to_number,
                "message_type": message_type,
                "response": response,
            },
            ensure_ascii=False,
            default=str,
        )
    except Exception as exc:
        await _log_runtime_whatsapp_outbound_message(
            db,
            connection=connection,
            chat_id=chat_id,
            payload=payload,
            response={},
            message_type=message_type,
            to_number=to_number,
            status_text="error",
            error_text=str(exc),
        )
        return json.dumps(
            {
                "error": str(exc),
                "connection_id": str(connection.get("id")),
                "to": to_number,
                "message_type": message_type,
            },
            ensure_ascii=False,
            default=str,
        )


async def _builtin_connector_action(
    db: Any,
    *,
    chat_id: int,
    arguments: Dict[str, Any],
    action_name: str,
    connections: List[Dict[str, Any]],
    chat_cfg: Dict[str, Any],
    chain_context: Optional[Dict[str, Any]] = None,
) -> str:
    if chain_context:
        arguments = _render_template_value(arguments, chain_context)
    args = _unwrap_llm_nested_tool_args(arguments if isinstance(arguments, dict) else {})
    connection, to_value, current_connection_id = _resolve_runtime_connector_target(args, connections, chat_cfg)
    if not connection:
        return json.dumps(
            {
                "error": "No connector connection could be resolved for this bot",
                "current_connection_id": current_connection_id,
                "available_connection_ids": [str(row.get("id")) for row in connections],
            }
        )
    if action_name != "text":
        return json.dumps({"error": f"Unsupported connector action: {action_name}"})
    text = str(args.get("text") or "").strip()
    if not text:
        return json.dumps({"error": "text is required"})
    if not to_value:
        return json.dumps({"error": "Recipient is required"})

    connector_key = str(connection.get("connector_key") or "whatsapp_meta_cloud")
    payload = {
        "recipient_type": "individual",
        "to": to_value,
        "type": "text",
        "text": {
            "preview_url": bool(args.get("preview_url", False)),
            "body": text,
        },
    }
    try:
        response = await transport_send_connector_text(
            connector_key=connector_key,
            connection=connection,
            to=to_value,
            text=text,
            preview_url=bool(args.get("preview_url", False)),
        )
        if connector_key == "whatsapp_meta_cloud":
            await _log_runtime_whatsapp_outbound_message(
                db,
                connection=connection,
                chat_id=chat_id,
                payload=payload,
                response=response,
                message_type="text",
                to_number=to_value,
            )
        return json.dumps(
            {
                "ok": True,
                "connector_key": connector_key,
                "connection_id": str(connection.get("id")),
                "to": to_value,
                "message_type": "text",
                "response": response,
            },
            ensure_ascii=False,
            default=str,
        )
    except Exception as exc:
        if connector_key == "whatsapp_meta_cloud":
            await _log_runtime_whatsapp_outbound_message(
                db,
                connection=connection,
                chat_id=chat_id,
                payload=payload,
                response={},
                message_type="text",
                to_number=to_value,
                status_text="error",
                error_text=str(exc),
            )
        return json.dumps(
            {
                "error": str(exc),
                "connector_key": connector_key,
                "connection_id": str(connection.get("id")),
                "to": to_value,
                "message_type": "text",
            },
            ensure_ascii=False,
            default=str,
        )


def _openai_tool_schemas_from_flow(flow: Dict[str, Any]) -> List[Dict[str, Any]]:
    nodes = flow.get("nodes") or []
    tools: List[Dict[str, Any]] = []
    for n in nodes:
        if not isinstance(n, dict):
            continue
        if n.get("type") != "api":
            continue
        nid = str(n.get("id", uuid.uuid4()))
        data = n.get("data") or {}
        name = f"api_{_sanitize_tool_name(nid)}"
        desc = (data.get("description") or "").strip() or "Call external HTTP API"
        method = data.get("apiMethod") or "GET"
        url = data.get("apiUrl") or ""
        desc = f"{desc}\nMethod: {method}\nURL template: {url}\nUse substitutions for {{placeholders}} in URL/body."
        tools.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": desc[:1024],
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "substitutions": {
                                "type": "object",
                                "description": "Map placeholder names (without braces) to string values for URL/body/header templates.",
                                "additionalProperties": {"type": "string"},
                            },
                            "body_json": {
                                "type": "string",
                                "description": "Optional JSON string for POST/PUT/PATCH body override.",
                            },
                        },
                        "required": [],
                    },
                },
            }
        )
    return tools


def _openai_tool_schemas_from_db_tools(tools_rows: List[Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for t in tools_rows:
        name = getattr(t, "name", None) or (t.get("name") if isinstance(t, dict) else "")
        if not name:
            continue
        tid = getattr(t, "id", None) or (t.get("id") if isinstance(t, dict) else 0)
        desc = getattr(t, "description", None) or (t.get("description") if isinstance(t, dict) else "") or ""
        variables = getattr(t, "variables", None) or (t.get("variables") if isinstance(t, dict) else []) or []
        props: Dict[str, Any] = {}
        for v in variables:
            if not isinstance(v, dict):
                continue
            vn = v.get("name")
            if not vn:
                continue
            props[vn] = {
                "type": "string",
                "description": (v.get("description") or "")[:512],
            }
        fn = f"db_tool_{int(tid)}_{_sanitize_tool_name(name)}"
        if _is_rag_search_catalog_tool(name):
            out.append(
                {
                    "type": "function",
                    "function": {
                        "name": fn[:64],
                        "description": (
                            f"{name}: {desc} Use top-level fields only: set \"query\" to the user's question "
                            f"or search terms (required). Do not put parameters inside a string named \"args\"."
                        )[:1024],
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "query": {
                                    "type": "string",
                                    "description": "Required. User question or keywords to search the knowledge base.",
                                },
                                "file_path": {
                                    "type": "string",
                                    "description": "Optional path to a file to search.",
                                },
                                "knowledge_text": {
                                    "type": "string",
                                    "description": "Optional inline text to search when no file is used.",
                                },
                                "chunk_size": {"type": "string", "description": "Chunk size (default 500)."},
                                "chunk_overlap": {"type": "string", "description": "Chunk overlap (default 50)."},
                                "top_k": {"type": "string", "description": "Number of chunks to return (default 3)."},
                            },
                            "required": ["query"],
                        },
                    },
                }
            )
            continue

        out.append(
            {
                "type": "function",
                "function": {
                    "name": fn[:64],
                    "description": f"{name}: {desc}"[:1024],
                    "parameters": {
                        "type": "object",
                        "properties": props or {"args": {"type": "string", "description": "JSON-encoded arguments"}},
                        "required": [],
                    },
                },
            }
        )
    return out


def _memory_from_config(cfg: Any) -> Tuple[str, Dict[str, Any]]:
    if not cfg:
        return "", {}
    if isinstance(cfg, str):
        try:
            cfg = json.loads(cfg)
        except json.JSONDecodeError:
            return "", {}
    if not isinstance(cfg, dict):
        return "", {}
    mem = cfg.get("agent_memory") or {}
    summary = ""
    if isinstance(mem, dict):
        summary = str(mem.get("summary") or "").strip()
    return summary, cfg


def _messages_to_openai(
    rows: List[Any],
    memory_summary: str,
    system_extra: str,
) -> List[Dict[str, Any]]:
    """Convert DB messages to OpenAI chat messages (last turns, text only)."""
    msgs: List[Dict[str, Any]] = []
    system = (
        "You are a capable AI agent with tools. When the user asks for API data, HTTP content, or "
        "external resources, you must call the appropriate tool first (invoke_http or a db_tool_* function) "
        "— do not answer from memory alone. Use URLs from the project context or toolParameterConfigs "
        "when provided. After tool results, summarize for the user. "
        "If a tool returns JSON, interpret it clearly. "
        "If RAG Search reports no relevant matches, say the current bot knowledge does not contain the answer "
        "instead of implying the user forgot to upload a file."
    )
    if memory_summary:
        system += f"\n\nSession memory (may be incomplete):\n{memory_summary}"
    if system_extra:
        system += f"\n\n{system_extra}"
    msgs.append({"role": "system", "content": system})

    # last 24 messages max
    for m in rows[-24:]:
        t = (getattr(m, "type", None) or (m.get("type") if isinstance(m, dict) else "")) or ""
        content = getattr(m, "content", None) or (m.get("content") if isinstance(m, dict) else "") or ""
        if t == "user":
            msgs.append({"role": "user", "content": content})
        elif t in ("assistant", "summary"):
            if content and not str(content).startswith("__STATUS_"):
                msgs.append({"role": "assistant", "content": content})
    return msgs


class AgentRuntime:
    def __init__(self, db: Any):
        self.db = db

    async def run(
        self,
        chat_id: int,
        user_message: str,
        project_row: Dict[str, Any],
        knowledge_context: Optional[Dict[str, Any]] = None,
        ai_config: Optional[Dict[str, Any]] = None,
        nlu_context: Optional[Dict[str, Any]] = None,
        on_message: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> Dict[str, Any]:
        if AsyncOpenAI is None:
            return {"error": "openai package not available"}

        api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
        if not api_key:
            return {"error": "OPENAI_API_KEY is not set"}

        client = AsyncOpenAI(api_key=api_key)
        model = (os.getenv("OPENAI_AGENT_MODEL") or os.getenv("OPENAI_MODEL") or "gpt-4o-mini").strip()

        flow = _flow_dict(project_row.get("flow"))
        project_desc = (project_row.get("description") or "").strip()
        chat_row = await self.db.fetch_chat(str(chat_id))
        cfg_raw = getattr(chat_row, "config", None)
        if cfg_raw is None and isinstance(chat_row, dict):
            cfg_raw = chat_row.get("config")
        mem_summary, cfg_dict = _memory_from_config(cfg_raw)
        whatsapp_connections = await _load_runtime_whatsapp_connections(self.db, project_row.get("id"))
        connector_connections = await _load_runtime_connector_connections(self.db, project_row.get("id"))

        # Tools: flow API nodes + DB tools + optional tavily
        tool_defs: List[Dict[str, Any]] = []
        tool_defs.extend(_openai_tool_schemas_from_flow(flow))

        try:
            tools_rows = await self.db.fetch_tools()
        except Exception as e:
            logger.warning("fetch_tools failed: %s", e)
            tools_rows = []

        knowledge_context = knowledge_context if isinstance(knowledge_context, dict) else {}
        http_defaults = _http_defaults_from_flow(flow, tools_rows)

        # DB catalog tools: if primary converser has explicit `data.tools`, only those IDs;
        # if `tools` is absent (legacy), expose all fetched tools. Backend canvas has no `api`
        # nodes in the palette, so catalog tools are the usual way to call HTTP.
        primary = _first_converser_node(flow)
        explicit_ids = _explicit_db_tool_ids_from_primary(primary)
        # Only filter when non-empty: `data.tools: []` must not wipe the catalog (empty is common).
        if explicit_ids:
            tools_rows = [r for r in tools_rows if _tool_row_id(r) in explicit_ids]
            logger.info(
                "[agent_runtime] DB catalog tools (explicit data.tools on primary converser): count=%s ids=%s",
                len(tools_rows),
                sorted(explicit_ids),
            )
        else:
            logger.info(
                "[agent_runtime] DB catalog tools: no non-empty data.tools filter; using all fetched tools (%s).",
                len(tools_rows),
            )

        filtered_http_count = 0
        kept_tools: List[Any] = []
        for row in tools_rows:
            name = getattr(row, "name", None) or (row.get("name") if isinstance(row, dict) else "") or ""
            if not _is_http_request_catalog_tool_name(name):
                kept_tools.append(row)
                continue
            if http_defaults.get("url") or _tool_has_real_http_default_url(row):
                kept_tools.append(row)
                continue
            filtered_http_count += 1

        if filtered_http_count:
            logger.info(
                "[agent_runtime] Filtered %s generic HTTP catalog tool(s) with placeholder/no configured URL.",
                filtered_http_count,
            )
            tools_rows = kept_tools

        registry: Dict[str, Tuple[Any, ...]] = {}

        for n in flow.get("nodes") or []:
            if not isinstance(n, dict) or n.get("type") != "api":
                continue
            nid = str(n.get("id", ""))
            data = n.get("data") or {}
            fn = f"api_{_sanitize_tool_name(nid)}"
            registry[fn] = ("api", data)

        for spec in _openai_tool_schemas_from_db_tools(tools_rows):
            tool_defs.append(spec)
            fn = spec["function"]["name"]
            m = re.match(r"db_tool_(\d+)_", fn)
            if m:
                tid = int(m.group(1))
                tr = next(
                    (
                        x
                        for x in tools_rows
                        if int(getattr(x, "id", None) or (x.get("id") if isinstance(x, dict) else 0) or 0) == tid
                    ),
                    None,
                )
                tname = (getattr(tr, "name", None) or (tr.get("name") if isinstance(tr, dict) else "") or "")
                registry[fn] = ("db", tname)

        if (os.getenv("TAVILY_API_KEY") or "").strip():
            tool_defs.append(
                {
                    "type": "function",
                    "function": {
                        "name": "web_search",
                        "description": "Search the public web for up-to-date information (Tavily).",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "query": {"type": "string", "description": "Search query"},
                            },
                            "required": ["query"],
                        },
                    },
                }
            )
            registry["web_search"] = ("tavily",)

        # Only expose a direct HTTP tool when the bot actually has a real endpoint configured.
        rag_defaults = _merge_rag_tool_args_with_defaults(
            _rag_defaults_from_flow(flow, tools_rows),
            _rag_defaults_from_knowledge_context(project_row, knowledge_context, user_message),
        )
        invoke_hint = ""
        if http_defaults.get("url"):
            invoke_hint = (
                f"Project/canvas default URL (prefer this url/method when the user did not specify another): "
                f"method={http_defaults.get('method', 'GET')} url={http_defaults.get('url')}"
            )
            tool_defs.append(_builtin_invoke_http_tool_definition(invoke_hint))
            registry["invoke_http"] = ("builtin_http",)

        if whatsapp_connections:
            for spec in _runtime_whatsapp_tool_definitions(whatsapp_connections, cfg_dict):
                tool_defs.append(spec)
                registry[spec["function"]["name"]] = (
                    "builtin_whatsapp",
                    spec["function"]["name"].replace("send_whatsapp_", "", 1),
                    whatsapp_connections,
                    cfg_dict,
                )
        if connector_connections:
            for spec in _runtime_connector_tool_definitions(connector_connections, cfg_dict):
                tool_defs.append(spec)
                registry[spec["function"]["name"]] = (
                    "builtin_connector",
                    spec["function"]["name"].replace("send_connector_", "", 1),
                    connector_connections,
                    cfg_dict,
                )

        history = await self.db.fetch_messages(str(chat_id))
        # user message already persisted by ChatService before run — included in history
        tool_ctx = _primary_converser_tool_context(primary)
        knowledge_ctx = _knowledge_context_summary(knowledge_context)
        nlu_ctx = _nlu_context_summary(ai_config, nlu_context)
        base_ctx = f"Project: {project_row.get('name', '')}\nDescription: {project_desc}"[:2000]
        system_extra = "\n\n".join(s for s in (base_ctx, tool_ctx, knowledge_ctx, nlu_ctx) if s).strip()
        openai_msgs = _messages_to_openai(
            history,
            mem_summary,
            system_extra,
        )

        max_steps = int(os.getenv("AGENT_RUNTIME_MAX_STEPS", "16"))
        last_rag_found_relevant = None
        execution_state: Dict[str, Any] = {"steps": []}
        tool_chaining_state_enabled = _env_flag("AGENT_RUNTIME_TOOL_CHAINING_STATE", "1")

        await self.db.set_chat_status(str(chat_id), "running")

        try:
            for step in range(max_steps):
                kwargs: Dict[str, Any] = {
                    "model": model,
                    "messages": openai_msgs,
                }
                if tool_defs:
                    kwargs["tools"] = tool_defs
                    # Models often skip tools with tool_choice=auto on vague prompts; require a tool on
                    # the first step when the message clearly asks for API/HTTP data.
                    if (
                        step == 0
                        and _env_flag("AGENT_RUNTIME_REQUIRE_TOOLS_ON_API_HINT", "1")
                        and _message_suggests_api_or_http_tools(user_message)
                    ):
                        kwargs["tool_choice"] = "required"
                        logger.info(
                            "[agent_runtime] chat_id=%s step=1 tool_choice=required (API/HTTP hint)",
                            chat_id,
                        )
                    else:
                        kwargs["tool_choice"] = "auto"

                resp = await client.chat.completions.create(**kwargs)
                choice = resp.choices[0]
                msg = choice.message

                if msg.tool_calls:
                    # Append assistant message with tool_calls
                    openai_msgs.append(
                        {
                            "role": "assistant",
                            "content": msg.content or "",
                            "tool_calls": [
                                {
                                    "id": tc.id,
                                    "type": "function",
                                    "function": {
                                        "name": tc.function.name,
                                        "arguments": tc.function.arguments or "{}",
                                    },
                                }
                                for tc in msg.tool_calls
                            ],
                        }
                    )

                    for tc in msg.tool_calls:
                        fname = tc.function.name
                        raw_args = tc.function.arguments or "{}"
                        result_text = ""
                        chain_context = _latest_tool_chain_context(execution_state)

                        if fname in registry:
                            kind = registry[fname][0]
                            if kind == "api":
                                node_data = registry[fname][1]
                                try:
                                    args = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    args = {}
                                result_text = await _http_request_node(node_data, args, chain_context=chain_context)
                            elif kind == "db":
                                tname = registry[fname][1]
                                try:
                                    a = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    a = {}
                                if _is_http_request_catalog_tool_name(tname):
                                    a = _unwrap_llm_nested_tool_args(a if isinstance(a, dict) else {})
                                    a = _merge_http_tool_args_with_defaults(a, http_defaults)
                                    raw_args = json.dumps(a)
                                elif _is_rag_search_catalog_tool(tname):
                                    a = _unwrap_llm_nested_tool_args(a if isinstance(a, dict) else {})
                                    a = _coerce_rag_search_args(a)
                                    a = _merge_rag_tool_args_with_defaults(a, rag_defaults)
                                    raw_args = json.dumps(a)
                                result_text = await _run_registered_db_tool(
                                    tname,
                                    raw_args,
                                    chain_context=chain_context,
                                )
                                if _is_rag_search_catalog_tool(tname):
                                    try:
                                        parsed = json.loads(result_text)
                                    except json.JSONDecodeError:
                                        parsed = {}
                                    if isinstance(parsed, dict) and "has_relevant_match" in parsed:
                                        last_rag_found_relevant = bool(parsed.get("has_relevant_match"))
                            elif kind == "tavily":
                                try:
                                    a = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    a = {}
                                result_text = await _tavily_search(str(a.get("query", "")))
                            elif kind == "builtin_http":
                                try:
                                    a = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    a = {}
                                a = _unwrap_llm_nested_tool_args(a if isinstance(a, dict) else {})
                                a = _merge_http_tool_args_with_defaults(a, http_defaults)
                                if http_defaults:
                                    logger.info(
                                        "[agent_runtime] invoke_http effective url=%s method=%s",
                                        (a.get("url") or "")[:256],
                                        a.get("method", ""),
                                    )
                                result_text = await _builtin_invoke_http(a, chain_context=chain_context)
                            elif kind == "builtin_whatsapp":
                                try:
                                    a = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    a = {}
                                action_name = registry[fname][1]
                                runtime_connections = registry[fname][2]
                                runtime_cfg = registry[fname][3]
                                result_text = await _builtin_whatsapp_action(
                                    self.db,
                                    chat_id=chat_id,
                                    arguments=a if isinstance(a, dict) else {},
                                    action_name=action_name,
                                    connections=runtime_connections,
                                    chat_cfg=runtime_cfg if isinstance(runtime_cfg, dict) else {},
                                    chain_context=chain_context,
                                )
                            elif kind == "builtin_connector":
                                try:
                                    a = json.loads(raw_args) if raw_args else {}
                                except json.JSONDecodeError:
                                    a = {}
                                action_name = registry[fname][1]
                                runtime_connections = registry[fname][2]
                                runtime_cfg = registry[fname][3]
                                result_text = await _builtin_connector_action(
                                    self.db,
                                    chat_id=chat_id,
                                    arguments=a if isinstance(a, dict) else {},
                                    action_name=action_name,
                                    connections=runtime_connections,
                                    chat_cfg=runtime_cfg if isinstance(runtime_cfg, dict) else {},
                                    chain_context=chain_context,
                                )
                            else:
                                result_text = json.dumps({"error": f"Unknown registry kind {kind}"})
                        elif fname == "web_search":
                            try:
                                a = json.loads(raw_args) if raw_args else {}
                            except json.JSONDecodeError:
                                a = {}
                            result_text = await _tavily_search(str(a.get("query", "")))
                        else:
                            result_text = json.dumps({"error": f"Unknown tool {fname}"})

                        # Terminal-friendly trace: tool name, args, output (truncated + redacted)
                        logger.info(
                            "[agent_runtime] chat_id=%s step=%s/%s tool=%s args=%s",
                            chat_id,
                            step + 1,
                            max_steps,
                            fname,
                            _trunc_for_log(_redact_for_log(raw_args or ""), _LOG_TOOL_ARG_MAX),
                        )
                        logger.info(
                            "[agent_runtime] chat_id=%s tool=%s output=%s",
                            chat_id,
                            fname,
                            _trunc_for_log(_redact_for_log(result_text), _LOG_TOOL_OUT_MAX),
                        )

                        if tool_chaining_state_enabled:
                            _execution_state_append(
                                execution_state,
                                step_index=step + 1,
                                tool_name=fname,
                                result_text=result_text,
                            )

                        openai_msgs.append(
                            {
                                "role": "tool",
                                "tool_call_id": tc.id,
                                "content": result_text[:14000],
                            }
                        )

                        if on_message:
                            preview = result_text if len(result_text) < 500 else result_text[:500] + "..."
                            await on_message(
                                {
                                    "type": "assistant",
                                    "content": f"[Tool {fname}] {preview}",
                                    "sender": "Agent",
                                    "metadata": {"tool_info": True, "tool": fname},
                                }
                            )
                            await self.db.add_message(
                                MessageCreate(
                                    type="assistant",
                                    content=f"[Tool {fname}]",
                                    sender="Agent",
                                    metadata={"tool": fname, "result_preview": preview[:2000]},
                                ),
                                str(chat_id),
                            )

                    if tool_chaining_state_enabled and execution_state.get("steps"):
                        chain_content = _execution_state_system_content(execution_state)
                        if chain_content:
                            openai_msgs.append({"role": "system", "content": chain_content})
                            logger.info(
                                "[agent_runtime] chat_id=%s injected tool_chain_state steps=%s",
                                chat_id,
                                len(execution_state.get("steps") or []),
                            )
                    continue

                # No tool calls — final natural reply
                final = (msg.content or "").strip()
                if not final:
                    final = "(No response text from model.)"
                if last_rag_found_relevant is False:
                    route_reply = _route_aware_no_match_reply(user_message, nlu_context)
                    if route_reply:
                        final = route_reply

                logger.info(
                    "[agent_runtime] chat_id=%s step=%s/%s final_reply (no tool_calls this round) chars=%s",
                    chat_id,
                    step + 1,
                    max_steps,
                    len(final),
                )

                if on_message:
                    await on_message({"type": "summary", "answer": final, "content": final})
                    await on_message({"type": "assistant", "content": "__STATUS_COMPLETED__"})

                await self.db.add_message(
                    MessageCreate(
                        type="summary",
                        content=final,
                        sender="Agent",
                    ),
                    str(chat_id),
                )

                # Update rolling memory (lightweight summary)
                try:
                    new_summary = mem_summary
                    if len(user_message) + len(final) < 3000:
                        new_summary = f"{mem_summary}\nUser: {user_message[:800]}\nAssistant: {final[:800]}".strip()
                    else:
                        new_summary = (mem_summary + "\n" + final[:1200])[-4000:]

                    merged_cfg = dict(cfg_dict) if isinstance(cfg_dict, dict) else {}
                    merged_cfg["agent_memory"] = {"summary": new_summary[-8000:]}
                    await self.db.update_chat_config(str(chat_id), merged_cfg)
                except Exception as me:
                    logger.warning("memory update failed: %s", me)

                await self.db.set_chat_status(str(chat_id), "completed")
                return {
                    "ok": True,
                    "answer": final,
                    "tool_chain_steps": len(execution_state.get("steps") or []),
                }

            await self.db.set_chat_status(str(chat_id), "failed")
            err = "Agent stopped: max tool steps exceeded"
            if on_message:
                await on_message({"type": "error", "content": err})
            return {"error": err}

        except Exception as e:
            logger.exception("AgentRuntime failed")
            await self.db.set_chat_status(str(chat_id), "failed")
            if on_message:
                await on_message({"type": "error", "content": str(e)})
            return {"error": str(e)}


def should_use_agent_runtime(project_row: Dict[str, Any]) -> bool:
    if (project_row.get("project_type") or "") != "backend":
        return False
    if not _env_flag("WINASSIST_USE_AGENT_RUNTIME", "1"):
        return False
    flow = _flow_dict(project_row.get("flow"))
    if flow.get("use_runtime_agent") is False:
        return False
    if not (os.getenv("OPENAI_API_KEY") or "").strip():
        return False
    return True
