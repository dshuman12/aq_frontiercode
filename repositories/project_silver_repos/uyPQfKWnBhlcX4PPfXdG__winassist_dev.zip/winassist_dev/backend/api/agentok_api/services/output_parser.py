import re
import json
from dataclasses import dataclass
from typing import List, Dict, Optional
import ast
import asyncio

from fastapi import logger

DEBUG = False


def clean_answer_text(text: Optional[str]) -> str:
    value = str(text or "")
    value = value.replace("\\n", " ").replace("\\t", " ").replace('\\"', '"')
    value = value.strip().strip('"').strip("'")
    value = re.sub(r"\s+", " ", value)
    return value.strip()

@dataclass
class ChatResult:
    chat_id: Optional[str]
    chat_history: List[Dict[str, str]]
    summary: str
    cost: Dict
    human_input: List

class OutputParser:
    # Define states as class-level immutable constants
    STATE_VERSION = 1
    STATE_CHAT = 2
    STATE_META = 3
    STATE_CONTENT = 4
    STATE_END_OF_MESSAGE = 5

    def __init__(self, on_message=None):
        # Initial state
        self.state = self.STATE_CHAT
        self.on_message = on_message

        # Initialize patterns
        self._initialize_patterns()

        # Data structure for current parsed message
        self._reset_current_message()
        
        # Track last assistant message and whether summary was found
        self.last_assistant_message = None
        self.has_summary = False
        
        # Get event loop for scheduling async callbacks
        try:
            self.loop = asyncio.get_event_loop()
        except RuntimeError:
            # If no event loop exists, we'll create tasks when one is available
            self.loop = None

    def _initialize_patterns(self):
        """Compile regex patterns."""
        self.version_pattern = re.compile(r"^\d+\.\d+\.\d+[a-z]?\d*")
        self.meta_pattern = re.compile(r"^>>>>>>>> (.*?)")
        self.from_to_pattern = re.compile(r"^(.*?) \(to (.*?)\):")
        self.end_pattern = re.compile(r"^-{80}")  # Assuming 80 dashes as a separator
        self.next_speaker_pattern = re.compile(r"^Next speaker: (.*?)$")

        # Patterns for tool-related messages
        self.tool_response_pattern = re.compile(
            r"^\*\*\*\*\* Response from calling tool \((.*?)\) \*\*\*\*\*"
        )
        self.suggested_tool_call_pattern = re.compile(
            r"^\*\*\*\*\* Suggested tool call \((.*?)\): (.*?) \*\*\*\*\*"
        )
        self.arguments_pattern = re.compile(r"^Arguments:\s*(\{.*\})")

    def _debug_print(self, message: str):
        if DEBUG:
            print(message)

    def _is_internal_message(self) -> bool:
        tool_info = self.current_message.get("metadata", {}).get("tool_info")
        if tool_info:
            return True
        sender = (self.current_message.get("sender") or "").strip().lower()
        if sender == "user" and self.current_message.get("type") == "assistant":
            return True
        content = (self.current_message.get("content") or "").strip()
        if not content:
            return True
        if content.startswith('{"kwargs"') or content.startswith("{'query':") or content.startswith('{"query":'):
            return True
        return False

    def _reset_current_message(self):
        """Reset (or initialize) the current message structure."""
        self.current_message = {
            "version": "",
            "metadata": {},
            "sender": "",
            "receiver": "",
            "content": "",
            "type": "assistant",  # Default to 'assistant'
        }
        self.message_content = []

    def parse_line(self, line: str):
        """Parse a single line of output.
        
        This method maintains state between calls and handles different types of output:
        - Chat messages
        - Status updates
        - Chat results
        """
        # Skip empty lines
        if not line:
            return

        # Handle status messages first
        if self._handle_status_message(line):
            return

        # Handle chat results
        if "__CHAT_RESULT__ " in line:
            result = self.parse_chat_result(line)
            if result:
                self.has_summary = True
                summary = clean_answer_text(result.summary)
                self._safe_call_on_message({
                    "type": "summary",
                    "content": summary,
                    "answer": summary,
                    "metadata": {
                        "summary": summary,
                        "chat_history": result.chat_history,
                        "cost": result.cost,
                        "human_input": result.human_input
                    } if DEBUG else {},
                })
            else:
                self._debug_print(f"Error parsing chat result: {line}")
            return

        # Handle multiple chat results
        if "__CHAT_RESULTS__ " in line:
            results = self.parse_chat_results(line)
            if results:
                self.has_summary = True
                summary = clean_answer_text("\n\n".join(r.summary.strip() for r in results).strip())
                # Combine all results into one message
                self._safe_call_on_message({
                    "type": "summary",
                    "content": summary,
                    "answer": summary,
                    "metadata": {
                        "summaries": [result.summary for result in results],
                        "chat_histories": [result.chat_history for result in results],
                        "costs": [result.cost for result in results],
                        "human_inputs": [result.human_input for result in results]
                    } if DEBUG else {},
                })
            else:
                self._debug_print(f"Error parsing chat results: {line}")
            return

        # Handle normal chat messages
        handlers = {
            self.STATE_VERSION: self._handle_version_state,
            self.STATE_CHAT: self._handle_chat_state,
            self.STATE_CONTENT: self._handle_content_state,
        }

        handler = handlers.get(self.state, lambda x: None)
        handler(line)

    def _handle_version_state(self, line):
        if self.version_pattern.match(line):
            self.current_message["version"] = line
            self.state = self.STATE_CHAT

    def _handle_chat_state(self, line):
        if self.meta_pattern.match(line):
            match = self.meta_pattern.match(line)
            if match:
                self.current_message["metadata"]["general"] = match.group(1)
                self.current_message["type"] = "assistant"
        elif self.next_speaker_pattern.match(line):
            match = self.next_speaker_pattern.match(line)
            if match:
                # Store next speaker info in metadata
                self.current_message["metadata"]["next_speaker"] = match.group(1)
        elif self.from_to_pattern.match(line):
            match = self.from_to_pattern.match(line)
            if match:
                self.current_message["sender"] = match.group(1)
                self.current_message["receiver"] = match.group(2)
                self.current_message["type"] = "assistant"
                self.state = self.STATE_CONTENT
        elif self.end_pattern.match(line):
            self._end_of_message()

    def _handle_content_state(self, line):
        if self.end_pattern.match(line):
            self._end_of_message()
        elif self.tool_response_pattern.match(line):
            match = self.tool_response_pattern.match(line)
            if match:
                self.current_message["metadata"]["tool_info"] = {
                    "type": "tool_response",
                    "meta": match.group(1),
                }
                # Ensure type is 'assistant' for tool responses
                self.current_message["type"] = "assistant"
        elif self.suggested_tool_call_pattern.match(line):
            match = self.suggested_tool_call_pattern.match(line)
            if match:
                self.current_message["metadata"]["tool_info"] = {
                    "type": "suggested_tool_call",
                    "meta": match.group(1),
                    "tool": match.group(2),
                }
                # Ensure type is 'assistant' for suggested tool calls
                self.current_message["type"] = "assistant"
        elif (
            self.arguments_pattern.match(line)
            and self.current_message["metadata"].get("tool_info", {}).get("type")
            == "suggested_tool_call"
        ):
            match = self.arguments_pattern.match(line)
            if match:
                try:
                    self.current_message["metadata"]["tool_info"]["arguments"] = json.loads(
                        match.group(1).replace("'", '"')
                    )
                except json.JSONDecodeError:
                    self.current_message["metadata"]["tool_info"]["arguments"] = None
        else:
            # Filter out redundant 'User (to Assistant):' lines and trailing asterisks
            if not (
                self.from_to_pattern.match(line)
                and self.message_content
                and self.message_content[-1] == line
            ):
                if (
                    not line == "User (to Assistant):"
                    and not line.startswith("*****")
                    and not line.startswith("Arguments:")
                ):
                    self.message_content.append(line)

    def _end_of_message(self):
        self.current_message["content"] = "\n".join(self.message_content).strip()
        self.current_message["content"] = clean_answer_text(self.current_message["content"])

        # Track last assistant message (only if it has content and is from assistant)
        if (self.current_message.get("type") == "assistant" and 
            self.current_message.get("content") and 
            self.current_message["content"].strip() and
            not self._is_internal_message()):
            self.last_assistant_message = self.current_message.copy()
            self._debug_print(f"[OutputParser] End of assistant message: {self.current_message.get('content', '')[:100]}")

        if self.on_message and not self._is_internal_message():
            self._debug_print(f"[OutputParser] Calling on_message with: type={self.current_message.get('type')}, content_length={len(self.current_message.get('content', ''))}")
            self._safe_call_on_message(self.current_message)
        elif not self.on_message:
            self._debug_print("[OutputParser] No on_message callback set!")

        # Prepare for the next message
        self._reset_current_message()
        self.state = self.STATE_CHAT
    
    def _safe_call_on_message(self, message):
        """Safely call on_message whether it's async or sync"""
        if not self.on_message:
            return
        
        try:
            if asyncio.iscoroutinefunction(self.on_message):
                # It's an async function, schedule it as a task
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # Event loop is running, create a task
                        asyncio.create_task(self.on_message(message))
                    else:
                        # No running loop, run it directly
                        loop.run_until_complete(self.on_message(message))
                except RuntimeError:
                    # No event loop exists, create one
                    asyncio.run(self.on_message(message))
            else:
                # It's a sync function, call it directly
                self.on_message(message)
        except Exception as e:
            logger.error(f"Error calling on_message: {e}")
            import traceback
            logger.error(traceback.format_exc())

    def parse_output(self, stdout):
        """
        Parse multiple lines of output from stdout.
        """
        for line in stdout:
            self.parse_line(line)

    def parse_chat_result(self, result_str: str) -> Optional[ChatResult]:
        """Parse a chat result string into a ChatResult object.
        
        Args:
            result_str: The string containing the chat result in JSON format
            
        Returns:
            Optional[ChatResult]: The parsed chat result, or None if parsing failed
        """
        try:
            # Remove the "__CHAT_RESULT__ " prefix
            clean_str = result_str.replace("__CHAT_RESULT__ ", "")
            
            # Parse the JSON string
            result_dict = json.loads(clean_str)
            
            # Convert the dictionary to a ChatResult object
            return ChatResult(**result_dict)
            
        except Exception as e:
            logger.error(f"Error parsing chat result: {e}")
            logger.error(f"Input string was: {result_str}")
            return None

    def parse_chat_results(self, results_str: str) -> Optional[List[ChatResult]]:
        """Parse multiple chat results string into a list of ChatResult objects.
        
        Args:
            results_str: The string containing multiple chat results in JSON format
            
        Returns:
            Optional[List[ChatResult]]: The parsed chat results, or None if parsing failed
        """
        try:
            # Remove the "__CHAT_RESULTS__ " prefix
            clean_str = results_str.replace("__CHAT_RESULTS__ ", "")
            
            # Parse the JSON string
            results_list = json.loads(clean_str)
            
            # Convert each dictionary to a ChatResult object
            return [ChatResult(**result_dict) for result_dict in results_list]
            
        except Exception as e:
            logger.error(f"Error parsing chat results: {e}")
            logger.error(f"Input string was: {results_str}")
            return None

    def _handle_status_message(self, message: str) -> bool:
        """
        Handle status messages and return True if the message was a status message.
        Returns False otherwise.
        """
        status_prefixes = [
            "__STATUS_RECEIVED_HUMAN_INPUT__",
            "__STATUS_WAIT_FOR_HUMAN_INPUT__",
            "__STATUS_COMPLETED__"
        ]
        
        for prefix in status_prefixes:
            if prefix in message:
                # Remove the prefix and any leading/trailing whitespace
                content = message.replace(prefix, "").strip()
                # Do not send/save the "Please give feedback to User..." prompt - backend auto-sends "exit"
                if prefix == "__STATUS_WAIT_FOR_HUMAN_INPUT__" and content and (
                    "Please give feedback" in content or "Press enter to skip" in content or "use auto-reply" in content
                ):
                    return True
                # Only send message if there's actual content (not just the prefix)
                if content:
                    clean_content = clean_answer_text(content)
                    self._safe_call_on_message({
                        "type": "assistant",
                        "content": clean_content,
                    })
                return True
        return False

    def _strip_prefix(self, input_string: str, substrings: list[str]) -> str:
        """Strip status prefix from a message."""
        result = input_string
        for substring in substrings:
            if substring in result:
                result = result.replace(substring, "").strip()
        return result

    def get_chat_status(self, message: str) -> Optional[str]:
        """
        Determine chat status from a message.
        Returns None if the message doesn't indicate a status change.
        """
        if "__STATUS_WAIT_FOR_HUMAN_INPUT__" in message:
            return "wait_for_human_input"
        elif "__STATUS_RECEIVED_HUMAN_INPUT__" in message:
            return "running"
        elif "__STATUS_COMPLETED__" in message:
            if "TERMINATED" in message:
                return "aborted"
            elif any(str(i) for i in range(10) if str(i) in message):
                return "failed"
            else:
                return "completed"
        return None
