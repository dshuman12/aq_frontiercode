import ast
import json
import os
import re
import tempfile
import textwrap
from datetime import datetime
import hashlib
from pathlib import Path
import autogen

from jinja2 import Environment, FileSystemLoader, select_autoescape
from jinja2.ext import do
from openai import APIStatusError, OpenAI
from termcolor import colored

from ..models import Project, Tool
from ..utils.datetime import now_ist
from .capability_planner import CapabilityPlannerService
from .database import DatabaseClient



class CodegenService:
    def __init__(self, supabase: DatabaseClient):
        # Get templates directory relative to this file's location
        current_dir = os.path.dirname(os.path.abspath(__file__))
        templates_dir = os.path.join(os.path.dirname(current_dir), "templates")
        self.env = Environment(
            loader=FileSystemLoader(
                searchpath=templates_dir
            ),
            autoescape=select_autoescape(),
            extensions=[do],
        )
        # Add custom filter to properly escape Python strings (handles Windows paths)
        self.env.filters['py_repr'] = repr
        self.supabase = supabase  # Keep an instance of DatabaseClient
        self.capability_planner = CapabilityPlannerService()
        # Use temp directory for cache to avoid uvicorn reload issues
        # This prevents uvicorn from detecting cache file changes and reloading
        self.cache_dir = Path(tempfile.gettempdir()) / "winassist_cache" / "codegen"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_cache_key(self, project: Project) -> str:
        """Generate a unique cache key for the project."""
        project_data = {
            "id": project.id,
            "flow": project.flow.dict(),
            "updated_at": project.updated_at,
        }
        return hashlib.sha256(json.dumps(project_data, sort_keys=True).encode()).hexdigest()

    def _get_cached_code(self, cache_key: str) -> str | None:
        """Get cached code if it exists."""
        cache_file = self.cache_dir / f"{cache_key}.py"
        if cache_file.exists():
            return cache_file.read_text()
        return None

    def _cache_code(self, cache_key: str, code: str):
        """Cache the generated code."""
        cache_file = self.cache_dir / f"{cache_key}.py"
        cache_file.write_text(code)

    def validate_project_flow(self, project: Project) -> dict:
        """Validate critical runtime requirements before code generation."""
        issues = {"errors": [], "warnings": []}
        flow = project.flow
        nodes = flow.nodes or []
        edges = flow.edges or []
        node_ids = {str(node.get("id")) for node in nodes if node.get("id")}

        for edge in edges:
            source = str(edge.get("source")) if edge.get("source") is not None else None
            target = str(edge.get("target")) if edge.get("target") is not None else None
            if source and source not in node_ids:
                issues["errors"].append(f"Edge references missing source node: {source}")
            if target and target not in node_ids:
                issues["errors"].append(f"Edge references missing target node: {target}")

        for node in nodes:
            node_id = str(node.get("id"))
            node_type = node.get("type")
            data = node.get("data", {}) or {}

            if node_type == "api":
                api_url = (data.get("apiUrl") or node.get("apiUrl") or "").strip()
                if not api_url:
                    issues["errors"].append(f"API node {node_id} is missing apiUrl")
                headers = data.get("headers") or node.get("headers") or []
                for header in headers:
                    key = str(header.get("key") or "").strip().lower()
                    value = str(header.get("value") or "").strip()
                    if key == "authorization" and value and "{{context." not in value:
                        issues["warnings"].append(
                            f"API node {node_id} contains a non-dynamic Authorization header"
                        )

            if node_type == "assistant":
                backend_bot_id = (node.get("backend_bot_id") or data.get("backend_bot_id") or "").strip()
                bot_api_key = (node.get("bot_api_key") or data.get("bot_api_key") or "").strip()
                if backend_bot_id and not bot_api_key:
                    issues["errors"].append(
                        f"Assistant node {node_id} references backend_bot_id but has no bot_api_key"
                    )

            if node_type == "condition":
                if_condition = (data.get("ifCondition") or node.get("ifCondition") or "").strip()
                if not if_condition:
                    issues["errors"].append(f"Condition node {node_id} is missing ifCondition")

        return issues

    async def generate_project(self, project: Project, user_query: str | None = None) -> str:
        """Generate project code asynchronously."""
        try:
            # Initialize config_list
            config_list = []
            cache_key = None

            # Extend config_list with settings['models'] if available
            try:
                user_settings = await self.supabase.fetch_general_settings()
                settings_models = []
                if user_settings:
                    # Support both persisted shapes:
                    # 1) {"general": {"models": [...]}}
                    # 2) {"models": [...]}
                    if isinstance(user_settings.get("general"), dict):
                        settings_models = user_settings["general"].get("models", []) or []
                    if not settings_models:
                        settings_models = user_settings.get("models", []) or []
                config_list.extend(
                    [model for model in settings_models if model.get("enabled") is True]
                )
            except Exception as e:
                print(f"Warning: Could not fetch user settings: {e}")
                user_settings = {"general": {"models": []}}

            # Check cache first
            try:
                cache_key = self._get_cache_key(project)
                cached_code = self._get_cached_code(cache_key)
                if cached_code:
                    print(f"Using cached code for project {project.id}")
                    return cached_code
            except Exception as e:
                print(f"Warning: Cache check failed: {e}")

            # Validate flow exists
            if not project.flow:
                raise Exception("Project flow is missing")
            
            flow = project.flow
            
            # Validate nodes and edges exist
            if not hasattr(flow, 'nodes') or not flow.nodes:
                raise Exception("Flow nodes are missing or empty")
            
            if not hasattr(flow, 'edges'):
                raise Exception("Flow edges are missing")

            validation = self.validate_project_flow(project)
            if validation["warnings"]:
                for warning in validation["warnings"]:
                    print(f"[FLOW_VALIDATION][WARN] {warning}")
            if validation["errors"]:
                raise Exception(
                    "Flow validation failed: " + "; ".join(validation["errors"][:8])
                )
            
            print(f"Processing flow with {len(flow.nodes)} nodes and {len(flow.edges)} edges")
            
            # Find initializer node
            initializer_node = next(
                (node for node in flow.nodes if node.get("type") == "initializer"), None
            )
            if not initializer_node:
                raise Exception(
                    "No initializer node found. This should be the first node in the flow."
                )

            # Find the first converser node
            first_converser = next(
                (
                    node
                    for node in flow.nodes
                    if any(
                        edge.get("source") == initializer_node.get("id")
                        and edge.get("target") == node.get("id")
                        for edge in flow.edges
                    )
                ),
                None,
            )

            if not first_converser:
                raise Exception(
                    "No converser node found. This should be the second node in the flow."
                )

            if first_converser.get("type") not in {"conversable", "user", "assistant"}:
                raise Exception(
                    f"The first converser node should be the conversable, user, or assistant node. Found: {first_converser.get('type')}"
                )

            conversable_nodes = [
                node for node in flow.nodes if node.get("type") == "conversable"
            ]
            ASSISTANT_NODE_TYPES = ["assistant", "captain", "websurfer", "deepseek"]
            assistant_nodes = [node for node in flow.nodes if node.get("type") in ASSISTANT_NODE_TYPES]
            print("assistant_nodes", assistant_nodes)
            gpt_assistant_nodes = [
                node for node in flow.nodes if node.get("type") == "gpt_assistant"
            ]
            user_nodes = [node for node in flow.nodes if node.get("type") == "user"]

            initial_chat_targets = [
                {
                    "node": node,
                    "chat_options": next(
                        (
                            edge.get("data")
                            for edge in flow.edges
                            if edge.get("source") == first_converser.get("id")
                            and edge.get("target") == node.get("id")
                        ),
                        None,
                    ),
                }
                for node in flow.nodes
                if any(
                    edge.get("source") == first_converser.get("id") and edge.get("target") == node.get("id")
                    for edge in flow.edges
                )
            ]

            # Handle group chat nodes
            group_nodes = []
            for node in flow.nodes:
                if node.get("type") == "groupchat":
                    group_nodes.append(
                        {
                            "group_node": node,
                            "children": [
                                n for n in flow.nodes if n.get("parentId") == node.get("id")
                            ],
                            "preceding_node": next(
                                (
                                    n for n in flow.nodes
                                    if any(e.get("source") == n.get("id") and e.get("target") == node.get("id") 
                                          for e in flow.edges)
                                ),
                                None,
                            ),
                        }
                    )

            # Prepare nested chats data
            try:
                nested_chats = self.prepare_nested_chats(flow)
            except Exception as e:
                print(f"Warning: Could not prepare nested chats: {e}")
                nested_chats = []

            note_nodes = [node for node in flow.nodes if node.get("type") == "note"]

            try:
                settings = await self.supabase.fetch_general_settings()
                for model in settings.get("models", []):
                    if "id" in model:
                        del model["id"]
                    if "description" in model:
                        del model["description"]
            except Exception as e:
                print(f"Warning: Could not fetch settings: {e}")
                settings = {"models": []}
            
            # Use the template for each node
            template = self.env.get_template("main.j2")

            # Generate tool assignments
            try:
                tool_dict = await self.build_tool_dict(project)
                print(f"Built tool_dict: {len(tool_dict)} tools")
                
                tool_assignments = self.generate_tool_assignments(flow.edges, tool_dict, flow.nodes)
                print(f"Generated tool_assignments: {len(tool_assignments)} assignments")
                
                # Extract unique tool_ids from assignments (which may now be tuples)
                tool_ids_in_assignments = set()
                for key in tool_assignments.keys():
                    if isinstance(key, tuple):
                        tool_ids_in_assignments.add(key[0])
                    else:
                        tool_ids_in_assignments.add(key)
                
                tool_dict = {
                    tool_id: tool
                    for tool_id, tool in tool_dict.items()
                    if tool_id in tool_ids_in_assignments
                }
                print(f"Filtered tool_dict: {len(tool_dict)} tools")
                for key, assignment in tool_assignments.items():
                    tid = key[0] if isinstance(key, tuple) else key
                    if assignment.get('is_websurfer'):
                        print(f"[TOOL_ASSIGN] tool=websurfer caller={assignment.get('caller')} executor={assignment.get('executor')}")
                    else:
                        print(f"[TOOL_ASSIGN] tool_id={tid} caller=node_{assignment.get('caller')} executor=node_{assignment.get('executor')} (whoever receives tool call must be one of these)")
                
                # Generate tool envs and replace placeholders
                await self.generate_tool_envs(project, tool_dict)
                
                # Replace env placeholders and fix kwargs annotations in tool code
                for tool_id, tool in tool_dict.items():
                    tool['code'] = self.replace_env_placeholders(tool)
            except Exception as e:
                print(f"Warning: Tool processing failed: {e}")
                import traceback
                traceback.print_exc()
                tool_dict = {}
                tool_assignments = {}

            planner_context = {}
            try:
                planner_context = self.capability_planner.plan_for_query(
                    user_query or "",
                    tool_dict,
                    tool_assignments,
                )
            except Exception as e:
                print(f"Warning: Capability planner failed: {e}")
                planner_context = {}

            # Get user data
            try:
                user = await self.supabase.get_user()
            except Exception as e:
                print(f"Warning: Could not fetch user: {e}")
                user = None

            # Extract tool parameter configurations from assistant nodes and conversable nodes
            # Key format: (tool_id, node_id) to support multiple nodes using same tool
            tool_parameter_configs = {}
            for node in assistant_nodes:
                if node.get('data', {}).get('toolParameterConfigs'):
                    for tool_id, config in node['data']['toolParameterConfigs'].items():
                        key = (int(tool_id), node.get('id'))
                        tool_parameter_configs[key] = config
                        print(f"[TOOL_CONFIG] tool_id={tool_id} node_id={node.get('id')} (assistant) -> suffixed name will be used: {list(config.keys())}")
            
            # Also extract from conversable nodes
            for node in conversable_nodes:
                if node.get('data', {}).get('toolParameterConfigs'):
                    for tool_id, config in node['data']['toolParameterConfigs'].items():
                        key = (int(tool_id), node.get('id'))
                        tool_parameter_configs[key] = config
                        print(f"[TOOL_CONFIG] tool_id={tool_id} node_id={node.get('id')} -> tool will use SUFFIXED name (func_name__node) in generated script: {list(config.keys())}")
            if tool_parameter_configs:
                print(f"[TOOL_CONFIG] Total {len(tool_parameter_configs)} tool parameter config(s) -> WITH CONFIG path (suffixed name) will be used")

            # Render the template with the prepared config_list
            try:
                code = template.render(
                    project=project,
                    config_list=config_list,
                    user=user,
                    settings=settings,
                    nodes=flow.nodes,
                    initializer_node=initializer_node,
                    first_converser=first_converser,
                    initial_chat_targets=initial_chat_targets,
                    conversable_nodes=conversable_nodes,
                    assistant_nodes=assistant_nodes,
                    gpt_assistant_nodes=gpt_assistant_nodes,
                    user_nodes=user_nodes,
                    group_nodes=group_nodes,
                    nested_chats=nested_chats,
                    generation_date=now_ist().strftime("%Y-%m-%d %H:%M:%S"),
                    note_nodes=note_nodes,
                    tool_dict=tool_dict,
                    tool_assignments=tool_assignments,
                    tool_parameter_configs=tool_parameter_configs,
                    planner_context=planner_context,
                )
            except Exception as e:
                print(f"Error rendering template: {e}")
                import traceback
                traceback.print_exc()
                raise Exception(f"Template rendering failed: {str(e)}")

            # Cache the generated code
            try:
                if cache_key:
                    self._cache_code(cache_key, code)
            except Exception as e:
                print(f"Warning: Could not cache code: {e}")

            return code
            
        except Exception as e:
            print(f"Error in generate_project: {str(e)}")
            import traceback
            traceback.print_exc()
            raise

    def prepare_nested_chats(self, flow):
        nested_chats = []
        for node in flow.nodes:
            if node.get("type") == "nestedchat":
                sender_nodes = [
                    n
                    for n in flow.nodes
                    if any(
                        edge.get("source") == n.get("id") and edge.get("target") == node.get("id")
                        for edge in flow.edges
                    )
                ]

                # Check if there is exactly one upstream node
                if len(sender_nodes) != 1:
                    raise Exception(
                        f'Nested chat node {node.get("id")} must have exactly one upstream node, found {len(sender_nodes)}.'
                    )

                sender_node = sender_nodes[0]

                if not sender_node:
                    raise Exception(
                        f'Nested chat node {node.get("id")} must have exactly one upstream sender node.'
                    )

                recipient_nodes_with_options = [
                    {
                        "node": recipient_node,
                        "chat_options": next(
                            (
                                edge.get("data")
                                for edge in flow.edges
                                if edge.get("source") == node.get("id")
                                and edge.get("target") == recipient_node.get("id")
                            ),
                            {},
                        ),
                    }
                    for recipient_node in flow.nodes
                    if any(
                        edge.get("source") == node.get("id")
                        and edge.get("target") == recipient_node.get("id")
                        for edge in flow.edges
                    )
                ]

                nested_chats.append(
                    {
                        "nested_chat_node": node,
                        "sender": sender_node,
                        "recipients": recipient_nodes_with_options,
                    }
                )

        return nested_chats

    async def build_tool_dict(self, project: Project):
        tool_ids = []
        # Collect tools from edges (api2 style)
        for edge in project.flow.edges:
            if "data" in edge and "tools" in edge.get("data", {}):
                tool_ids.extend(edge["data"]["tools"])
        
        # Also collect tools from nodes (current src style)
        for node in project.flow.nodes:
            if "data" in node and "tools" in node.get("data", {}):
                node_tools = node["data"]["tools"]
                if isinstance(node_tools, list):
                    tool_ids.extend(node_tools)

        tools = await self.supabase.fetch_tools(tool_ids)
        tool_dict = {}
        
        for tool in tools:
            # Get tool ID first (before converting to dict)
            tool_id = tool.id if hasattr(tool, 'id') else (tool.get('id') if isinstance(tool, dict) else None)
            if tool_id is None:
                print(f"Warning: Tool missing ID, skipping: {tool}")
                continue
            
            # Convert Tool object to dict for modification
            # Handle both Pydantic v1 (dict()) and v2 (model_dump())
            if hasattr(tool, 'model_dump'):
                # Pydantic v2 - ensure nested models are serialized
                tool_data = tool.model_dump(mode='python')
            elif hasattr(tool, 'dict'):
                # Pydantic v1 - ensure nested models are serialized
                tool_data = tool.dict()
            elif isinstance(tool, dict):
                tool_data = tool.copy()
            else:
                # Fallback: convert to dict manually
                variables = tool.variables or []
                # Convert ToolVariable objects to dicts if needed
                if variables and len(variables) > 0:
                    if hasattr(variables[0], 'model_dump'):
                        variables = [v.model_dump(mode='python') for v in variables]
                    elif hasattr(variables[0], 'dict'):
                        variables = [v.dict() for v in variables]
                
                tool_data = {
                    'id': tool.id,
                    'name': tool.name,
                    'description': tool.description,
                    'code': tool.code,
                    'variables': variables,
                    'user_id': tool.user_id,
                    'logo_url': tool.logo_url,
                    'is_public': tool.is_public,
                    'created_at': tool.created_at,
                    'updated_at': tool.updated_at,
                }
            
            # Extract metadata from the tool's code
            try:
                tool_code = tool.code if hasattr(tool, 'code') else tool_data.get('code', '')
                if not tool_code:
                    # Skip tools without code
                    tool_dict[tool_id] = tool_data
                    continue
                    
                meta_info = self.extract_tool_meta(tool_code)
                # Merge the meta_info with the tool data
                tool_data["func_name"] = meta_info["func_name"]
                tool_data["description"] = meta_info["description"]
                tool_data["signatures"] = meta_info["signatures"]
                tool_data["variables"] = meta_info["variables"]
                tool_dict[tool_id] = tool_data
            except Exception as e:
                print(f"Warning: Failed to extract metadata for tool {tool_id}: {str(e)}")
                # Still include the tool even if metadata extraction fails
                tool_dict[tool_id] = tool_data
        
        return tool_dict

    def generate_tool_assignments(self, edges, tool_dict, nodes):
        tool_assignments = {}

        # Process regular tool assignments from edges
        for edge in edges:
            if edge.get("data") is not None and edge.get("data", {}).get("tools") is not None:
                for tool_id in edge["data"]["tools"]:
                    if tool_id in tool_dict:
                        target_node = next((n for n in nodes if n.get("id") == edge.get("target")), None)
                        source_node = next((n for n in nodes if n.get("id") == edge.get("source")), None)
                        target_class = target_node.get("data", {}).get("class_type") if target_node else None
                        source_class = source_node.get("data", {}).get("class_type") if source_node else None
                        # Caller must have llm_config (ConversableAgent/AssistantAgent). UserProxyAgent cannot be caller.
                        if target_class == "UserProxyAgent":
                            # Edge target is User proxy -> use source as caller, target as executor
                            caller_id = edge.get("source")
                            executor_id = edge.get("target")
                            print(f"Assigned tool {tool_id} to node {caller_id} (source as caller; target is UserProxyAgent)")
                        elif source_class == "UserProxyAgent":
                            # Normal: target is agent, source is User -> caller=target, executor=source
                            caller_id = edge.get("target")
                            executor_id = edge.get("source")
                            print(f"Assigned tool {tool_id} to edge target {edge.get('target')}")
                        else:
                            # Both are agents; use target as caller, source as executor
                            caller_id = edge.get("target")
                            executor_id = edge.get("source")
                            print(f"Assigned tool {tool_id} to edge target {edge.get('target')}")
                        caller_node = next((n for n in nodes if n.get("id") == caller_id), None)
                        if caller_node and caller_node.get("data", {}).get("class_type") == "UserProxyAgent":
                            print(f"Warning: Tool {tool_id} would have caller=UserProxyAgent (node {caller_id}) - skipping. Assign tools to an agent with LLM.")
                            continue
                        unique_key = (tool_id, caller_id)
                        tool_assignments[unique_key] = {
                            "caller": caller_id,
                            "executor": executor_id,
                        }
                    else:
                        print(colored(f"Assigned tool ID {tool_id} not found in tools", "red"))

        # Process tool assignments from agent nodes (Support tools stored in node data)
        for node in nodes:
            node_data = node.get("data", {})
            if node_data.get("tools") and isinstance(node_data["tools"], list):
                for tool_id in node_data["tools"]:
                    if tool_id in tool_dict:
                        # Skip tools assigned to UserProxyAgent - they can't be callers (no llm_config)
                        if node_data.get("class_type") == "UserProxyAgent":
                            print(f"Warning: Tool {tool_id} assigned to UserProxyAgent (node {node.get('id')}) - skipping. Tools should be assigned to ConversableAgent or AssistantAgent.")
                            continue
                        
                        # Create unique key for this node+tool combination
                        unique_key = (tool_id, node.get("id"))
                        
                        # Find the UserProxyAgent node for execution
                        user_proxy_node = None
                        for n in nodes:
                            # In WinAssist, user nodes use class_type "User" but are instantiated as UserProxyAgent
                            if n.get("data", {}).get("class_type") in ("UserProxyAgent", "User"):
                                user_proxy_node = n
                                break
                        
                        if user_proxy_node:
                            tool_assignments[unique_key] = {
                                "caller": node.get("id"),  # Assistant/ConversableAgent calls the tool
                                "executor": user_proxy_node.get("id"),  # UserProxy executes it
                            }
                        else:
                            tool_assignments[unique_key] = {
                                "caller": node.get("id"),
                                "executor": node.get("id"),  # Fallback: Agent executes its own tools
                            }
                        print(f"Assigned tool {tool_id} to node {node.get('id')}")
                    else:
                        print(colored(f"Assigned tool ID {tool_id} not found in tools", "red"))

        # Process WebSurferAgent tools
        for edge in edges:
            target_node = next(
                (node for node in nodes if node.get("id") == edge.get("target")),
                None
            )
            if target_node and target_node.get("data", {}).get("class_type") == "WebSurferAgent":
                source_node = next(
                    (node for node in nodes if node.get("id") == edge.get("source")),
                    None
                )
                if source_node:
                    web_tool = target_node.get("data", {}).get("web_tool", "browser_use")
                    tool_id = f"websurfer_{target_node.get('id')}"
                    if tool_id not in tool_assignments:
                        tool_assignments[tool_id] = {
                            "caller": target_node.get("id"),
                            "executor": source_node.get("id"),
                            "is_websurfer": True,
                            "web_tool": web_tool,
                            "websurfer_node_id": target_node.get("id")
                        }

        return tool_assignments

    def generate_rag_assignments(self, edges):
        # Prepare the tool assignments
        rag_assignments = {"execution": [], "llm": []}

        for edge in edges:
            if edge.get("data") is not None and edge.get("data", {}).get("enable_rag") is True:
                rag_assignments["execution"].append(edge.get("source"))
                rag_assignments["llm"].append(edge.get("target"))

        return rag_assignments

    async def generate_tool_envs(self, project: Project, tool_dict: dict) -> dict:
        """Generate tool environment files for the provided project."""
        # Fetch tool settings from Supabase
        tool_settings = await self.supabase.fetch_tool_settings()

        # Filter tool_settings to only include tools in tool_dict
        tool_settings = {
            int(tool_id): settings
            for tool_id, settings in tool_settings.items()
            if int(tool_id) in tool_dict
        }

        # Templates removed - tool_env generation disabled
        # Return empty dict since templates are not available
        tool_envs = {}
        # template = self.env.get_template("tool_env.j2")
        # tool_envs = {
        #     tool_id: template.render(tool_settings=tool_settings[tool_id])
        #     for tool_id in tool_settings
        # }

        return tool_envs

    def replace_env_placeholders(self, tool):
        """Replace all {{xxx}} placeholders in tool.code."""
        # Ensure tool is a dict or has attribute access
        tool_id = tool.get('id') if isinstance(tool, dict) else (tool.id if hasattr(tool, 'id') else None)
        if tool_id is None:
            print(f"Warning: Cannot replace env placeholders for tool without ID: {tool}")
            return tool.get('code', '') if isinstance(tool, dict) else (tool.code if hasattr(tool, 'code') else '')

        fixed_rule = f"env_{tool_id}['{{}}']"
        pattern = r"\{\{\s*(.*?)\s*\}\}"

        def replacer(match):
            placeholder = match.group(1)
            return fixed_rule.format(placeholder)

        tool_code = tool.get('code', '') if isinstance(tool, dict) else (tool.code if hasattr(tool, 'code') else '')
        tool_code = re.sub(pattern, replacer, tool_code)
        
        # Fix kwargs annotation if present - autogen requires all parameters to be annotated
        # Replace **kwargs with **kwargs: Any
        tool_code = self.fix_kwargs_annotation(tool_code)
        # Add : Any to any parameter that has no annotation (required by autogen.register_function)
        tool_code = self.ensure_parameter_annotations(tool_code)
        
        return tool_code
    
    def ensure_parameter_annotations(self, code: str) -> str:
        """Add ': Any' to function parameters that have no type annotation.
        Autogen requires all parameters to be annotated for tool schema generation.
        """
        lines = code.split("\n")
        out = []
        for line in lines:
            stripped = line.lstrip()
            if stripped.startswith("def ") and "(" in line and "):" in line:
                # Find the signature: from first ( to ):
                start = line.index("(")
                end = line.rindex("):")
                prefix = line[: start + 1]
                sig = line[start + 1 : end]
                suffix = line[end :]
                # Split params by comma (simple split - no nested parens in param defaults for now)
                parts = []
                for part in sig.split(","):
                    part = part.strip()
                    if not part:
                        continue
                    # If already has annotation (contains ':'), leave as is
                    if ":" in part:
                        parts.append(part)
                        continue
                    # Add : Any after the parameter name (first token)
                    if part.startswith("**"):
                        parts.append(part + ": Any" if ":" not in part else part)
                    elif part.startswith("*"):
                        parts.append(part + ": Any" if ":" not in part else part)
                    else:
                        name = part.split("=")[0].strip()
                        rest = part[len(name) :].lstrip()
                        parts.append(name + ": Any" + (" " + rest if rest else ""))
                line = prefix + ", ".join(parts) + suffix
            out.append(line)
        return "\n".join(out)
    
    def fix_kwargs_annotation(self, code: str) -> str:
        """Fix kwargs annotation in function definitions to satisfy autogen requirements.
        
        Note: The 'Any' import is added to the main template (import_mapping.j2),
        so we don't need to add it here. We just need to annotate **kwargs.
        """
        # Check if kwargs already has annotation
        if re.search(r'\*\*kwargs\s*:\s*\w+', code):
            return code
        
        # Only process if **kwargs exists without annotation
        if '**kwargs' not in code:
            return code
        
        # Replace **kwargs with **kwargs: Any
        # Match **kwargs followed by comma or closing paren (but not already annotated)
        code = re.sub(r'\*\*kwargs(?=\s*[,\)])', '**kwargs: Any', code)
        
        return code

    def generate_dataset_prompts(self, datasets):
        datasets_info = "\n".join(
            [
                f"- Dataset ID {d['id']}: {d['name']} - {d['description']}"
                for d in datasets
            ]
        )

        dataset_prompt = f"""
Retrieves relevant information and generates a response based on the query.
Available datasets:
{datasets_info}

Choose the appropriate dataset ID based on the query.
"""
        return dataset_prompt

    def generate_tool(self, tool: Tool):
        """Generate code based on the provided function meta information."""
        client = OpenAI()
        client.api_key = os.environ["OPENAI_API_KEY"]

        prompt = "Create a Python function as one text string based on the following information, provide the result in JSON format {name, description, code}.\n"
        prompt += f"Function Name: {tool.name}\n"
        prompt += f"Description: {tool.description}\n"
        prompt += "Parameters:\n"

        for signature in tool.signatures:
            prompt += (
                f"- {signature.name} ({signature.type}): {signature.description}\n"
            )

        prompt += "\nPython Function:\n"
        prompt += "The function should include the name, description, and parameters as annotations.\n"

        try:
            response = client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are a helpful assistant designed to output JSON.",
                    },
                    {
                        "role": "user",
                        "content": prompt,
                    },
                ],
                response_format={"type": "json_object"},
                model="gpt-4o-mini",
            )

            generated_code = response.choices[0].message.content
            if not generated_code:
                raise Exception("No code generated")
            print(generated_code)

            return json.loads(generated_code)
        except APIStatusError as e:
            print(f"Error: {e}")
            raise

    def extract_tool_meta(self, code: str):
        """Extract meta information from the provided Python function code."""
        tree = ast.parse(code)

        func_def = next(
            (node for node in tree.body if isinstance(node, ast.FunctionDef)), None
        )
        if not func_def:
            raise ValueError(
                f"No function definition found in the provided code: \n{code}"
            )

        func_name = func_def.name
        docstring = ast.get_docstring(func_def)
        description = ""
        param_descriptions = {}

        if docstring:
            docstring_lines = docstring.split("\n")
            description = docstring_lines[0].strip()
            if len(docstring_lines) > 1:
                param_lines = [
                    line.strip() for line in docstring_lines[1:] if line.strip()
                ]
                for line in param_lines:
                    match = re.match(r"(\w+) \((\w+)\): (.+)", line)
                    if match:
                        param_name, param_type, param_desc = match.groups()
                        param_descriptions[param_name] = {
                            "type": param_type,
                            "description": param_desc,
                        }

        parameters = []
        # Get default values to determine which parameters are required
        defaults = func_def.args.defaults
        num_defaults = len(defaults) if defaults else 0
        num_args = len(func_def.args.args)
        required_start_index = num_args - num_defaults  # Args before this index are required
        
        for i, arg in enumerate(func_def.args.args):
            param_name = arg.arg
            param_type = None
            if arg.annotation:
                param_type = ast.unparse(arg.annotation)
            param_desc = param_descriptions.get(param_name, {}).get("description", "")
            # Parameter is required if it doesn't have a default value
            is_required = i < required_start_index
            # Add [REQUIRED] marker to description if parameter is required
            if is_required and param_desc and not param_desc.startswith('[REQUIRED]'):
                param_desc = f"[REQUIRED] {param_desc}"
            elif is_required and not param_desc:
                param_desc = "[REQUIRED]"
            parameters.append(
                {"name": param_name, "type": param_type, "description": param_desc}
            )

        variables = []
        # Create a map of parameter names to their types from the function signature
        param_type_map = {}
        for param in parameters:
            param_name = param.get("name")
            param_type = param.get("type", "str")
            if param_name:
                # Normalize Python types to simpler forms
                if param_type:
                    # Remove Optional/Union wrappers and extract base type
                    param_type_clean = param_type.replace("Optional[", "").replace("]", "")
                    param_type_clean = param_type_clean.replace("Union[", "").replace("]", "")
                    # Handle str | None format
                    if "|" in param_type_clean:
                        param_type_clean = param_type_clean.split("|")[0].strip()
                    # Map common Python types to simple names
                    if "str" in param_type_clean.lower():
                        param_type_clean = "str"
                    elif "int" in param_type_clean.lower():
                        param_type_clean = "int"
                    elif "float" in param_type_clean.lower():
                        param_type_clean = "float"
                    elif "bool" in param_type_clean.lower():
                        param_type_clean = "bool"
                    elif "dict" in param_type_clean.lower():
                        param_type_clean = "dict"
                    elif "list" in param_type_clean.lower():
                        param_type_clean = "list"
                    else:
                        param_type_clean = "str"  # Default fallback
                    param_type_map[param_name] = param_type_clean
                else:
                    param_type_map[param_name] = "str"
        
        # Also add all function parameters as variables (not just from {{}} placeholders)
        # This ensures all parameters are available as variables
        for param in parameters:
            param_name = param.get("name")
            if param_name:
                var_type = param_type_map.get(param_name, "str")
                # Check if this variable already exists (from {{}} extraction)
                existing_var = next((v for v in variables if v.get("name") == param_name), None)
                if not existing_var:
                    variables.append({
                        "name": param_name,
                        "description": f"[TYPE:{var_type}]"
                    })
        
        # Also extract variables from {{}} placeholders in code
        for node in ast.walk(func_def):
            if isinstance(node, ast.Str) and "{{" in node.s and "}}" in node.s:
                vars_in_node = re.findall(r"\{\{(.*?)\}\}", node.s)
                for var in vars_in_node:
                    # Get the type from the parameter map using the variable name
                    # var is the variable name (e.g., "file"), look up its parameter type
                    var_type = param_type_map.get(var, "str")
                    # Check if variable already exists
                    existing_var = next((v for v in variables if v.get("name") == var), None)
                    if not existing_var:
                        # Store type in description as [TYPE:xxx] marker
                        variables.append({
                            "name": var,
                            "description": f"[TYPE:{var_type}]"
                        })
                    elif existing_var and not existing_var.get("description", "").startswith("[TYPE:"):
                        # Update existing variable with type if it doesn't have one
                        existing_var["description"] = f"[TYPE:{var_type}]"

        meta_info = {
            "func_name": func_name,
            "description": description,
            "signatures": parameters,
            "variables": variables,
        }

        return meta_info