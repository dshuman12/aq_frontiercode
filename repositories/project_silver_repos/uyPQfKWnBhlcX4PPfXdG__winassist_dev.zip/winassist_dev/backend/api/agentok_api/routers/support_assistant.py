from typing import Any, Dict, List

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from ..dependencies import get_current_user
from ..services.support_assistant import answer_platform_question


router = APIRouter()


class SupportAssistantAskRequest(BaseModel):
    query: str


class SupportAssistantReference(BaseModel):
    title: str
    section: str
    path: str


class SupportAssistantAskResponse(BaseModel):
    answer: str
    intent: str
    confidence: str
    references: List[SupportAssistantReference]
    highlights: List[str]


@router.post("/ask", response_model=SupportAssistantAskResponse, summary="Ask platform support assistant")
async def ask_support_assistant(
    body: SupportAssistantAskRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    del current_user
    result = answer_platform_question(body.query)
    return SupportAssistantAskResponse(**result)
