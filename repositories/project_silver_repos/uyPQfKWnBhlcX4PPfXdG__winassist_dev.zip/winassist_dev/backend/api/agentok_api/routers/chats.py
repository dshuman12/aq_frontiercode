from typing import List
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
import json
import asyncio
from ..models import Chat, ChatCreate, ChatCreateBody, MessageCreate
from ..services import ChatService
from ..dependencies import get_chat_service, get_chat_service_flexible

router = APIRouter()
DEBUG = False


@router.get("", summary="Get existing chats", response_model=List[Chat])
async def get_chats(service: ChatService = Depends(get_chat_service)):
    return await service.get_chats()


@router.post("", response_model=Chat, summary="Create a new chat")
async def new_chat(
    body: ChatCreateBody, service: ChatService = Depends(get_chat_service_flexible)
):
    # Use flexible auth to allow bot API keys
    # Set user_id from authenticated user (JWT or bot API key → project owner)
    if not hasattr(service.supabase, "user_id") or not service.supabase.user_id:
        raise HTTPException(
            status_code=400,
            detail="user_id is required; authentication may not have provided it",
        )
    chat_to_create = ChatCreate(
        name=body.name,
        from_type=body.from_type,
        from_project=body.from_project,
        from_template=body.from_template,
        user_id=service.supabase.user_id,
        session_id=body.session_id,
    )
    return await service.create_chat(chat_to_create)


@router.get("/{chat_id}", summary="Get chat status", response_model=Chat)
async def get_chat(chat_id: int, service: ChatService = Depends(get_chat_service)):
    return await service.get_chat(chat_id)


@router.get("/{chat_id}/messages", summary="Get messages of one chat session")
async def get_messages(
    chat_id: int,
    service: ChatService = Depends(get_chat_service),
):
    return await service.get_messages(chat_id)


@router.get("/{chat_id}/logs", summary="Get logs of one chat session")
async def get_logs(
    chat_id: int,
    service: ChatService = Depends(get_chat_service),
):
    return await service.get_logs(chat_id)


@router.delete("/{chat_id}/messages", summary="Clear messages of one chat session")
async def clear_messages(
    chat_id: int,
    service: ChatService = Depends(get_chat_service),
):
    return await service.clear_messages(chat_id)


@router.post("/{chat_id}/messages", summary="Start chat")
async def start_chat(
    message: MessageCreate,
    chat_id: int,
    service: ChatService = Depends(get_chat_service_flexible),
):
    """
    Start a chat and stream responses using Server-Sent Events (SSE).
    Returns a streaming response with messages as they arrive.
    Supports authentication via JWT token or bot API key (X-Bot-API-Key header).
    """
    # Normalize the incoming message user to the authenticated canonical user.
    if hasattr(service.supabase, "user_id") and service.supabase.user_id:
        message.user_id = service.supabase.user_id

    async def event_generator():
        """Generate SSE events for streaming chat responses"""
        message_queue = asyncio.Queue()
        error_occurred = False
        chat_completed = False
        
        async def message_handler(assistant_message):
            """Handle messages from the assistant and add to queue"""
            try:
                # Send all messages, even if content is empty (for status updates)
                # Filter empty content messages in the frontend instead
                await message_queue.put(assistant_message)
            except Exception as e:
                if DEBUG:
                    print(f"Error in message_handler: {e}")
                    import traceback
                    traceback.print_exc()
        
        # Start the chat in the background
        async def run_chat():
            nonlocal error_occurred, chat_completed
            try:
                result = await service.start_chat(message, chat_id, on_message=message_handler)
                if isinstance(result, dict) and result.get("error"):
                    error_occurred = True
                    await message_queue.put({"type": "error", "content": result.get("error")})
                chat_completed = True
            except Exception as e:
                error_occurred = True
                await message_queue.put({"type": "error", "content": str(e)})
                chat_completed = True
        
        # Start chat task
        chat_task = asyncio.create_task(run_chat())
        
        # Stream messages as they arrive
        try:
            # NOTE: Do not hard-close the SSE stream just because of inactivity;
            # keep it open until the chat actually completes.
            while True:
                try:
                    # Wait for message with timeout so we can send keepalives
                    msg = await asyncio.wait_for(message_queue.get(), timeout=0.5)

                    # Format as SSE
                    if not DEBUG and msg.get("type") == "summary" and msg.get("answer"):
                        data = json.dumps({"answer": msg.get("answer")}, ensure_ascii=False)
                    else:
                        data = json.dumps(msg, ensure_ascii=False)
                    yield f"data: {data}\n\n"
                    
                    # Check if this is a completion message
                    content = msg.get("content", "")
                    if content.startswith("__STATUS_COMPLETED__") or msg.get("type") == "done":
                        break
                except asyncio.TimeoutError:
                    # On timeout, if the chat is done and the queue is empty, we can close.
                    if chat_completed and message_queue.empty():
                        break
                    # Otherwise, keep the stream alive with a heartbeat.
                    yield ": keepalive\n\n"
                    continue
                except Exception as e:
                    if DEBUG:
                        print(f"[SSE] Error in event_generator: {e}")
                        import traceback
                        traceback.print_exc()
                    break
            
            # Wait for chat task to complete (with timeout)
            try:
                await asyncio.wait_for(chat_task, timeout=1.0)
            except asyncio.TimeoutError:
                pass  # Task may still be running, but we've sent all messages
        except Exception as e:
            error_data = json.dumps({"type": "error", "content": str(e)}, ensure_ascii=False)
            yield f"data: {error_data}\n\n"
        finally:
            # Send completion event
            completion_data = json.dumps({"type": "done"}, ensure_ascii=False)
            yield f"data: {completion_data}\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable buffering for nginx
        }
    )


@router.post(
    "/{chat_id}/input",
    summary="Send human input",
    description="Send human input to the chat. The current chat status must be `wait_for_human_input`.",
)
async def send_human_input(
    message: MessageCreate,
    chat_id: int,
    service: ChatService = Depends(get_chat_service),
):
    return await service.human_input(message, chat_id)


@router.post("/{chat_id}/abort", summary="Abort a running chat")
async def abort_chat(chat_id: int, service: ChatService = Depends(get_chat_service)):
    return await service.abort_chat(chat_id)


@router.delete("/{chat_id}", summary="Delete a chat")
async def delete_chat(chat_id: int, service: ChatService = Depends(get_chat_service)):
    """
    Delete a chat and all associated messages.
    This will also abort any running chat process.
    """
    return await service.delete_chat(chat_id)