import base64
import hashlib
import hmac
import json
import logging
import os
import uuid
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

import jwt
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import PlainTextResponse
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from ..dependencies import get_current_user, get_database_client, get_database_client_no_auth
from ..models import (
    ChatCreate,
    MessageCreate,
    WhatsAppConnection,
    WhatsAppConnectionCreate,
    WhatsAppConnectionUpdate,
    WhatsAppDiscoveryRequest,
    WhatsAppFlow,
    WhatsAppFlowCreateRequest,
    WhatsAppFlowMessageRequest,
    WhatsAppFlowEndpointConfigRequest,
    WhatsAppFlowPublicKeyRequest,
    WhatsAppFlowPublicKeyStatus,
    WhatsAppFlowRuntimeEvent,
    WhatsAppFlowRuntimeReplayResponse,
    WhatsAppFlowUpdateRequest,
    WhatsAppWebhookEvent,
    WhatsAppChannelDashboard,
    WhatsAppDashboardCountStat,
    WhatsAppDashboardDailyStat,
    WhatsAppFlowActivityStat,
    WhatsAppInteractiveMessageRequest,
    WhatsAppMessage,
    WhatsAppMediaMessageRequest,
    WhatsAppSavedFlowSendRequest,
    WhatsAppTemplate,
    WhatsAppTemplateCreateRequest,
    WhatsAppTemplateSendRequest,
    WhatsAppTemplateMessageRequest,
    WhatsAppTestMessageRequest,
    WhatsAppTextMessageRequest,
)
from ..services.chats import ChatService
from ..services.connector_registry import get_whatsapp_connector_definition
from ..services.codegen import CodegenService
from ..services.database import DatabaseClient
from ..services.message_transport import send_connector_payload
from ..services.secret_store import connector_credentials_secret, mask_secret_hint
from ..services.whatsapp_provider import get_whatsapp_provider

logger = logging.getLogger(__name__)
router = APIRouter()

def _credentials_secret() -> str:
    return connector_credentials_secret()


async def _get_user_id(current_user: dict) -> UUID:
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            return UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )
    return user_id


async def _ensure_whatsapp_schema(conn) -> None:
    await conn.execute('CREATE EXTENSION IF NOT EXISTS "pgcrypto";')
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_connections (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
            project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            bot_project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
            created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
            name VARCHAR(255),
            provider VARCHAR(32) NOT NULL DEFAULT 'meta_cloud',
            graph_version VARCHAR(32) NOT NULL DEFAULT 'v23.0',
            meta_business_account_id VARCHAR(255),
            waba_id VARCHAR(255) NOT NULL,
            phone_number_id VARCHAR(255) NOT NULL UNIQUE,
            business_phone_number VARCHAR(64),
            display_phone_number VARCHAR(64),
            access_token_encrypted BYTEA NOT NULL,
            access_token_hint VARCHAR(8),
            flow_private_key_encrypted BYTEA,
            flow_public_key_pem TEXT,
            flow_key_fingerprint VARCHAR(128),
            flow_key_generated_at TIMESTAMP,
            connection_status VARCHAR(32) NOT NULL DEFAULT 'draft',
            webhook_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            health_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
            last_sync_status VARCHAR(32) NOT NULL DEFAULT 'never',
            subscribed_app_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
            last_validation_error TEXT,
            metadata JSONB NOT NULL DEFAULT '{}',
            last_validated_at TIMESTAMP,
            last_synced_at TIMESTAMP,
            last_webhook_event_at TIMESTAMP,
            last_tested_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_phone_numbers (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
            phone_number_id VARCHAR(255) NOT NULL UNIQUE,
            display_phone_number VARCHAR(64),
            verified_name VARCHAR(255),
            quality_rating VARCHAR(64),
            code_verification_status VARCHAR(64),
            status VARCHAR(64) DEFAULT 'active',
            raw_data JSONB NOT NULL DEFAULT '{}',
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_templates (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
            meta_template_id VARCHAR(255) UNIQUE,
            name VARCHAR(255) NOT NULL,
            language VARCHAR(64),
            category VARCHAR(64),
            status VARCHAR(64),
            components JSONB NOT NULL DEFAULT '{}',
            raw_data JSONB NOT NULL DEFAULT '{}',
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_flows (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
            meta_flow_id VARCHAR(255) UNIQUE,
            name VARCHAR(255) NOT NULL,
            status VARCHAR(64),
            categories JSONB NOT NULL DEFAULT '{}',
            raw_data JSONB NOT NULL DEFAULT '{}',
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_webhook_events (
            id BIGSERIAL PRIMARY KEY,
            connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
            event_type VARCHAR(64),
            payload JSONB NOT NULL DEFAULT '{}',
            headers JSONB NOT NULL DEFAULT '{}',
            processed BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_messages (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            connection_id UUID REFERENCES whatsapp_connections(id) ON DELETE SET NULL,
            direction VARCHAR(16) NOT NULL,
            wa_message_id VARCHAR(255) UNIQUE,
            chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
            project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            from_number VARCHAR(64),
            to_number VARCHAR(64),
            message_type VARCHAR(64),
            status VARCHAR(64),
            payload JSONB NOT NULL DEFAULT '{}',
            response JSONB NOT NULL DEFAULT '{}',
            error TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS whatsapp_conversation_links (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            connection_id UUID NOT NULL REFERENCES whatsapp_connections(id) ON DELETE CASCADE,
            wa_user_phone_number VARCHAR(64) NOT NULL,
            chat_id INTEGER REFERENCES chats(id) ON DELETE SET NULL,
            project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            last_message_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            UNIQUE (connection_id, wa_user_phone_number)
        )
        """
    )
    await conn.execute(
        """
        ALTER TABLE whatsapp_connections
            ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
            ADD COLUMN IF NOT EXISTS project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS bot_project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES persons(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS name VARCHAR(255),
            ADD COLUMN IF NOT EXISTS provider VARCHAR(32) NOT NULL DEFAULT 'meta_cloud',
            ADD COLUMN IF NOT EXISTS graph_version VARCHAR(32) NOT NULL DEFAULT 'v23.0',
            ADD COLUMN IF NOT EXISTS meta_business_account_id VARCHAR(255),
            ADD COLUMN IF NOT EXISTS waba_id VARCHAR(255),
            ADD COLUMN IF NOT EXISTS phone_number_id VARCHAR(255),
            ADD COLUMN IF NOT EXISTS business_phone_number VARCHAR(64),
            ADD COLUMN IF NOT EXISTS display_phone_number VARCHAR(64),
            ADD COLUMN IF NOT EXISTS access_token_encrypted BYTEA,
            ADD COLUMN IF NOT EXISTS access_token_hint VARCHAR(8),
            ADD COLUMN IF NOT EXISTS flow_private_key_encrypted BYTEA,
            ADD COLUMN IF NOT EXISTS flow_public_key_pem TEXT,
            ADD COLUMN IF NOT EXISTS flow_key_fingerprint VARCHAR(128),
            ADD COLUMN IF NOT EXISTS flow_key_generated_at TIMESTAMP,
            ADD COLUMN IF NOT EXISTS connection_status VARCHAR(32) NOT NULL DEFAULT 'draft',
            ADD COLUMN IF NOT EXISTS webhook_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            ADD COLUMN IF NOT EXISTS health_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
            ADD COLUMN IF NOT EXISTS last_sync_status VARCHAR(32) NOT NULL DEFAULT 'never',
            ADD COLUMN IF NOT EXISTS subscribed_app_status VARCHAR(32) NOT NULL DEFAULT 'unknown',
            ADD COLUMN IF NOT EXISTS last_validation_error TEXT,
            ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}',
            ADD COLUMN IF NOT EXISTS last_validated_at TIMESTAMP,
            ADD COLUMN IF NOT EXISTS last_synced_at TIMESTAMP,
            ADD COLUMN IF NOT EXISTS last_webhook_event_at TIMESTAMP,
            ADD COLUMN IF NOT EXISTS last_tested_at TIMESTAMP,
            ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_workspace_id
        ON whatsapp_connections(workspace_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_project_id
        ON whatsapp_connections(project_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_bot_project_id
        ON whatsapp_connections(bot_project_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_user_id
        ON whatsapp_connections(user_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_connections_status
        ON whatsapp_connections(connection_status)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_connection_id
        ON whatsapp_webhook_events(connection_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_created_at
        ON whatsapp_webhook_events(created_at DESC)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_phone_numbers_connection_id
        ON whatsapp_phone_numbers(connection_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_templates_connection_id
        ON whatsapp_templates(connection_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_flows_connection_id
        ON whatsapp_flows(connection_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_connection_id
        ON whatsapp_messages(connection_id)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_created_at
        ON whatsapp_messages(created_at DESC)
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_whatsapp_conversation_links_connection_id
        ON whatsapp_conversation_links(connection_id)
        """
    )


async def _fetch_workspace_role(conn, workspace_id: UUID, user_id: UUID) -> Optional[str]:
    return await conn.fetchval(
        """
        SELECT role
        FROM workspace_members
        WHERE workspace_id = $1 AND user_id = $2
        """,
        workspace_id,
        user_id,
    )


async def _fetch_authorized_project(conn, user_id: UUID, project_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT p.id, p.user_id, p.workspace_id, wm.role AS member_role
        FROM projects p
        LEFT JOIN workspace_members wm
          ON wm.workspace_id = p.workspace_id
         AND wm.user_id = $1
        WHERE p.id = $2
        """,
        user_id,
        project_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    if row["workspace_id"] is None and row["user_id"] != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this project")
    if row["workspace_id"] is not None and row["member_role"] is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the project workspace")
    return dict(row)


async def _fetch_connection_row(conn, connection_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wc.*,
               wm.role AS member_role
        FROM whatsapp_connections wc
        LEFT JOIN workspace_members wm
          ON wm.workspace_id = wc.workspace_id
         AND wm.user_id = $2
        WHERE wc.id = $1
        """,
        connection_id,
        user_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp connection not found")
    row_dict = dict(row)
    if row_dict["workspace_id"] is None and row_dict["user_id"] != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this WhatsApp connection")
    if row_dict["workspace_id"] is not None and row_dict.get("member_role") is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the connection workspace")
    return row_dict


def _normalize_connection_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    row["access_token_masked"] = mask_secret_hint(row.get("access_token_hint"))
    row.pop("access_token_encrypted", None)
    row.pop("access_token_hint", None)
    row.pop("member_role", None)
    return row


def _normalize_whatsapp_message_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    for key in ("payload", "response"):
        value = row.get(key)
        if isinstance(value, str):
            try:
                row[key] = json.loads(value)
            except Exception:
                row[key] = {}
        elif value is None:
            row[key] = {}
    return row


def _normalize_whatsapp_template_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    for key in ("components", "raw_data"):
        value = row.get(key)
        if isinstance(value, str):
            try:
                row[key] = json.loads(value)
            except Exception:
                row[key] = {} if key == "raw_data" else []
        elif value is None:
            row[key] = {} if key == "raw_data" else []
    return row


def _normalize_whatsapp_flow_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    categories = row.get("categories")
    if isinstance(categories, str):
        try:
            categories = json.loads(categories)
        except Exception:
            categories = [categories] if categories.strip() else []
    elif categories is None:
        categories = []
    elif isinstance(categories, dict):
        categories = [str(key) for key, enabled in categories.items() if enabled]
    elif not isinstance(categories, list):
        categories = []
    row["categories"] = [str(item) for item in categories if str(item).strip()]

    raw_data = row.get("raw_data")
    if isinstance(raw_data, str):
        try:
            raw_data = json.loads(raw_data)
        except Exception:
            raw_data = {}
    elif raw_data is None:
        raw_data = {}
    row["raw_data"] = raw_data if isinstance(raw_data, dict) else {}
    return row


async def _fetch_template_row(conn, template_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wt.*,
               wc.workspace_id,
               wc.user_id AS connection_user_id,
               wm.role AS member_role
        FROM whatsapp_templates wt
        JOIN whatsapp_connections wc ON wc.id = wt.connection_id
        LEFT JOIN workspace_members wm
          ON wm.workspace_id = wc.workspace_id
         AND wm.user_id = $2
        WHERE wt.id = $1
        """,
        template_id,
        user_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp template not found")
    row_dict = dict(row)
    if row_dict["workspace_id"] is None and row_dict["connection_user_id"] != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this WhatsApp template")
    if row_dict["workspace_id"] is not None and row_dict.get("member_role") is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the template workspace")
    row_dict.pop("member_role", None)
    row_dict.pop("workspace_id", None)
    row_dict.pop("connection_user_id", None)
    return row_dict


async def _fetch_flow_row(conn, flow_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wf.*,
               wc.workspace_id,
               wc.user_id AS connection_user_id,
               wm.role AS member_role
        FROM whatsapp_flows wf
        JOIN whatsapp_connections wc ON wc.id = wf.connection_id
        LEFT JOIN workspace_members wm
          ON wm.workspace_id = wc.workspace_id
         AND wm.user_id = $2
        WHERE wf.id = $1
        """,
        flow_id,
        user_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp flow not found")
    row_dict = dict(row)
    if row_dict["workspace_id"] is None and row_dict["connection_user_id"] != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this WhatsApp flow")
    if row_dict["workspace_id"] is not None and row_dict.get("member_role") is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the flow workspace")
    row_dict.pop("member_role", None)
    row_dict.pop("workspace_id", None)
    row_dict.pop("connection_user_id", None)
    return row_dict


async def _fetch_flow_runtime_row(conn, flow_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wf.*,
               wc.provider,
               wc.graph_version,
               wc.phone_number_id,
               wc.flow_public_key_pem,
               wc.flow_key_fingerprint,
               wc.flow_key_generated_at,
               wc.metadata AS connection_metadata,
               wc.id AS connection_id
        FROM whatsapp_flows wf
        JOIN whatsapp_connections wc ON wc.id = wf.connection_id
        WHERE wf.id = $1
        """,
        flow_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp flow not found")
    return dict(row)


async def _fetch_flow_runtime_event_row(conn, flow_id: UUID, event_id: int) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT *
        FROM whatsapp_webhook_events
        WHERE id = $1
          AND event_type = 'flow_runtime_callback'
          AND payload->>'flow_id' = $2
        """,
        event_id,
        str(flow_id),
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Flow runtime event not found")
    return dict(row)


async def _list_accessible_whatsapp_connection_ids(conn, user_id: UUID) -> List[UUID]:
    rows = await conn.fetch(
        """
        SELECT DISTINCT wc.id
        FROM whatsapp_connections wc
        LEFT JOIN workspace_members m
          ON m.workspace_id = wc.workspace_id
         AND m.user_id = $1
        WHERE wc.user_id = $1
           OR m.user_id = $1
        """,
        user_id,
    )
    return [row["id"] for row in rows if row.get("id") is not None]


async def _fetch_message_row(conn, message_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wm.*,
               wc.workspace_id,
               wc.user_id AS connection_user_id,
               wc.provider,
               wc.graph_version,
               wc.phone_number_id,
               wm.connection_id AS resolved_connection_id,
               membership.role AS member_role
        FROM whatsapp_messages wm
        JOIN whatsapp_connections wc ON wc.id = wm.connection_id
        LEFT JOIN workspace_members membership
          ON membership.workspace_id = wc.workspace_id
         AND membership.user_id = $2
        WHERE wm.id = $1
        """,
        message_id,
        user_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp message not found")
    row_dict = dict(row)
    if row_dict["workspace_id"] is None and row_dict["connection_user_id"] != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this WhatsApp message")
    if row_dict["workspace_id"] is not None and row_dict.get("member_role") is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the message workspace")
    row_dict.pop("member_role", None)
    row_dict.pop("workspace_id", None)
    row_dict.pop("connection_user_id", None)
    return row_dict


async def _upsert_whatsapp_template_row(
    conn,
    *,
    connection_id: UUID,
    template_data: Dict[str, Any],
    template_id: Optional[UUID] = None,
    default_name: Optional[str] = None,
    default_language: Optional[str] = None,
    default_category: Optional[str] = None,
    default_components: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    payload = template_data or {}
    meta_template_id = str(payload.get("id") or "").strip() or None
    name = str(payload.get("name") or default_name or "").strip()
    language = str(payload.get("language") or default_language or "").strip() or None
    category = str(payload.get("category") or default_category or "").strip() or None
    status_value = str(payload.get("status") or "").strip() or ("draft" if not meta_template_id else "pending")
    components = payload.get("components")
    if not isinstance(components, list):
        components = default_components or []

    if template_id is not None:
        row = await conn.fetchrow(
            """
            UPDATE whatsapp_templates
            SET connection_id = $2,
                meta_template_id = $3,
                name = $4,
                language = $5,
                category = $6,
                status = $7,
                components = $8::jsonb,
                raw_data = $9::jsonb,
                updated_at = NOW()
            WHERE id = $1
            RETURNING *
            """,
            template_id,
            connection_id,
            meta_template_id,
            name,
            language,
            category,
            status_value,
            json.dumps(components or []),
            json.dumps(payload or {}),
        )
        return dict(row) if row else {}

    if meta_template_id:
        row = await conn.fetchrow(
            """
            INSERT INTO whatsapp_templates (
                connection_id,
                meta_template_id,
                name,
                language,
                category,
                status,
                components,
                raw_data,
                created_at,
                updated_at
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb, NOW(), NOW())
            ON CONFLICT (meta_template_id) DO UPDATE SET
                connection_id = EXCLUDED.connection_id,
                name = EXCLUDED.name,
                language = EXCLUDED.language,
                category = EXCLUDED.category,
                status = EXCLUDED.status,
                components = EXCLUDED.components,
                raw_data = EXCLUDED.raw_data,
                updated_at = NOW()
            RETURNING *
            """,
            connection_id,
            meta_template_id,
            name,
            language,
            category,
            status_value,
            json.dumps(components or []),
            json.dumps(payload or {}),
        )
        return dict(row) if row else {}

    row = await conn.fetchrow(
        """
        INSERT INTO whatsapp_templates (
            connection_id,
            meta_template_id,
            name,
            language,
            category,
            status,
            components,
            raw_data,
            created_at,
            updated_at
        )
        VALUES ($1, NULL, $2, $3, $4, $5, $6::jsonb, $7::jsonb, NOW(), NOW())
        RETURNING *
        """,
        connection_id,
        name,
        language,
        category,
        status_value,
        json.dumps(components or []),
        json.dumps(payload or {}),
    )
    return dict(row) if row else {}


async def _upsert_whatsapp_flow_row(
    conn,
    *,
    connection_id: UUID,
    flow_data: Dict[str, Any],
    flow_id: Optional[UUID] = None,
    default_name: Optional[str] = None,
    default_categories: Optional[List[str]] = None,
) -> Dict[str, Any]:
    payload = flow_data or {}
    meta_flow_id = str(payload.get("id") or payload.get("meta_flow_id") or "").strip() or None
    name = str(payload.get("name") or default_name or "").strip()
    categories = payload.get("categories")
    if isinstance(categories, str):
        try:
            categories = json.loads(categories)
        except Exception:
            categories = [categories] if categories.strip() else []
    if not isinstance(categories, list):
        categories = default_categories or []
    categories = [str(item) for item in categories if str(item).strip()]
    status_value = str(payload.get("status") or "").strip() or ("draft" if not meta_flow_id else "draft")

    if flow_id is not None:
        row = await conn.fetchrow(
            """
            UPDATE whatsapp_flows
            SET connection_id = $2,
                meta_flow_id = $3,
                name = $4,
                status = $5,
                categories = $6::jsonb,
                raw_data = $7::jsonb,
                updated_at = NOW()
            WHERE id = $1
            RETURNING *
            """,
            flow_id,
            connection_id,
            meta_flow_id,
            name,
            status_value,
            json.dumps(categories or []),
            json.dumps(payload or {}),
        )
        return dict(row) if row else {}

    if meta_flow_id:
        row = await conn.fetchrow(
            """
            INSERT INTO whatsapp_flows (
                connection_id,
                meta_flow_id,
                name,
                status,
                categories,
                raw_data,
                created_at,
                updated_at
            )
            VALUES ($1, $2, $3, $4, $5::jsonb, $6::jsonb, NOW(), NOW())
            ON CONFLICT (meta_flow_id) DO UPDATE SET
                connection_id = EXCLUDED.connection_id,
                name = EXCLUDED.name,
                status = EXCLUDED.status,
                categories = EXCLUDED.categories,
                raw_data = EXCLUDED.raw_data,
                updated_at = NOW()
            RETURNING *
            """,
            connection_id,
            meta_flow_id,
            name,
            status_value,
            json.dumps(categories or []),
            json.dumps(payload or {}),
        )
        return dict(row) if row else {}

    row = await conn.fetchrow(
        """
        INSERT INTO whatsapp_flows (
            connection_id,
            meta_flow_id,
            name,
            status,
            categories,
            raw_data,
            created_at,
            updated_at
        )
        VALUES ($1, NULL, $2, $3, $4::jsonb, $5::jsonb, NOW(), NOW())
        RETURNING *
        """,
        connection_id,
        name,
        status_value,
        json.dumps(categories or []),
        json.dumps(payload or {}),
    )
    return dict(row) if row else {}


def _build_meta_template_payload(body: WhatsAppTemplateCreateRequest) -> Dict[str, Any]:
    return {
        "name": body.name,
        "category": body.category,
        "language": body.language,
        "components": body.components or [],
    }


def _normalize_flow_json_string(flow_json: Optional[str]) -> Optional[str]:
    if flow_json is None:
        return None
    text = str(flow_json).strip()
    if not text:
        return None
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Invalid flow JSON: {exc}")
    return json.dumps(parsed, ensure_ascii=False, indent=2)


def _flow_runtime_token_secret() -> str:
    return (
        os.getenv("WHATSAPP_FLOW_TOKEN_SECRET")
        or os.getenv("WHATSAPP_CREDENTIALS_SECRET")
        or os.getenv("JWT_SECRET")
        or "winassist-whatsapp-flow-token"
    )


def _flow_runtime_signature_secret() -> str:
    return (os.getenv("WHATSAPP_META_APP_SECRET") or "").strip()


def _backend_api_base_url(request: Optional[Request] = None) -> str:
    configured = (os.getenv("BACKEND_URL") or "").strip().rstrip("/")
    if configured:
        return configured
    if request is None:
        return ""
    proto = (request.headers.get("x-forwarded-proto") or request.url.scheme or "https").split(",")[0].strip()
    host = (request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc).split(",")[0].strip()
    if not host:
        return ""
    path = str(request.scope.get("root_path") or "").rstrip("/")
    return f"{proto}://{host}{path}/v1".rstrip("/")


def _build_flow_runtime_callback_url(flow_id: UUID, request: Optional[Request] = None) -> Optional[str]:
    base = _backend_api_base_url(request).rstrip("/")
    if not base:
        return None
    if not base.endswith("/v1"):
        base = f"{base}/v1"
    return f"{base}/whatsapp/flows/{flow_id}/runtime-callback"


def _build_flow_runtime_metadata(existing_metadata: Optional[Dict[str, Any]], **updates: Any) -> Dict[str, Any]:
    metadata = dict(existing_metadata or {})
    flow_runtime = dict(metadata.get("flow_runtime") or {})
    for key, value in updates.items():
        if value is not None:
            flow_runtime[key] = value
    metadata["flow_runtime"] = flow_runtime
    return metadata


def _generate_flow_key_material() -> Dict[str, str]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    fingerprint = hashlib.sha256(public_pem.encode("utf-8")).hexdigest()
    return {
        "private_pem": private_pem,
        "public_pem": public_pem,
        "fingerprint": fingerprint,
    }


async def _decrypt_connection_flow_private_key(conn, connection_id: UUID) -> Optional[str]:
    return await conn.fetchval(
        """
        SELECT pgp_sym_decrypt(flow_private_key_encrypted, $2::text)
        FROM whatsapp_connections
        WHERE id = $1
        """,
        connection_id,
        _credentials_secret(),
    )


def _verify_flow_runtime_signature(raw_body: bytes, signature_header: Optional[str]) -> bool:
    app_secret = _flow_runtime_signature_secret()
    if not app_secret:
        return True
    if not signature_header or not signature_header.startswith("sha256="):
        return False
    expected = hmac.new(app_secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    provided = signature_header.split("sha256=", 1)[1].strip()
    return hmac.compare_digest(expected, provided)


def _decrypt_flow_runtime_payload(payload: Dict[str, Any], private_pem: str) -> Dict[str, Any]:
    try:
        encrypted_flow_data = base64.b64decode(str(payload["encrypted_flow_data"]))
        encrypted_aes_key = base64.b64decode(str(payload["encrypted_aes_key"]))
        initial_vector = base64.b64decode(str(payload["initial_vector"]))
    except Exception as exc:
        raise HTTPException(status_code=421, detail=f"Invalid encrypted flow payload: {exc}")

    private_key = serialization.load_pem_private_key(private_pem.encode("utf-8"), password=None)
    aes_key = private_key.decrypt(
        encrypted_aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    ciphertext = encrypted_flow_data[:-16]
    tag = encrypted_flow_data[-16:]
    decryptor = AESGCM(aes_key)
    try:
        plaintext = decryptor.decrypt(initial_vector, ciphertext + tag, None)
    except Exception as exc:
        raise HTTPException(status_code=421, detail=f"Failed to decrypt flow payload: {exc}")
    try:
        decrypted = json.loads(plaintext.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=421, detail=f"Invalid decrypted flow JSON: {exc}")
    return {
        "decrypted_payload": decrypted,
        "aes_key": aes_key,
        "initial_vector": initial_vector,
    }


def _encrypt_flow_runtime_response(response_payload: Dict[str, Any], aes_key: bytes, initial_vector: bytes) -> str:
    flipped_iv = bytes((b ^ 0xFF) for b in initial_vector)
    plaintext = json.dumps(response_payload, ensure_ascii=False).encode("utf-8")
    encrypted = AESGCM(aes_key).encrypt(flipped_iv, plaintext, None)
    return base64.b64encode(encrypted).decode("utf-8")


def _parse_saved_flow_json(flow_row: Dict[str, Any]) -> Dict[str, Any]:
    raw_data = flow_row.get("raw_data") or {}
    flow_json = raw_data.get("local_flow_json")
    if not flow_json or not isinstance(flow_json, str):
        return {}
    try:
        parsed = json.loads(flow_json)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        return {}


def _first_flow_screen_id(flow_row: Dict[str, Any]) -> Optional[str]:
    flow_json = _parse_saved_flow_json(flow_row)
    screens = flow_json.get("screens") or []
    for screen in screens:
        if isinstance(screen, dict) and screen.get("id"):
            return str(screen.get("id"))
    return None


def _next_flow_screen_id(flow_row: Dict[str, Any], current_screen: Optional[str]) -> Optional[str]:
    if not current_screen:
        return _first_flow_screen_id(flow_row)
    flow_json = _parse_saved_flow_json(flow_row)
    routing_model = flow_json.get("routing_model") or {}
    if isinstance(routing_model, dict):
        next_screens = routing_model.get(current_screen) or []
        if isinstance(next_screens, list):
            for next_screen in next_screens:
                if str(next_screen).strip():
                    return str(next_screen)
    screens = [screen for screen in (flow_json.get("screens") or []) if isinstance(screen, dict)]
    for idx, screen in enumerate(screens):
        if str(screen.get("id") or "") == str(current_screen) and idx + 1 < len(screens):
            next_id = screens[idx + 1].get("id")
            return str(next_id) if next_id else None
    return current_screen


def _issue_flow_runtime_token(
    *,
    connection_id: UUID,
    saved_flow_id: Optional[UUID],
    meta_flow_id: Optional[str],
    initial_screen: Optional[str],
) -> str:
    payload = {
        "kind": "wa_flow_runtime",
        "connection_id": str(connection_id),
        "saved_flow_id": str(saved_flow_id) if saved_flow_id else None,
        "meta_flow_id": str(meta_flow_id or ""),
        "initial_screen": initial_screen,
    }
    return jwt.encode(payload, _flow_runtime_token_secret(), algorithm="HS256")


def _decode_flow_runtime_token(flow_token: Optional[str]) -> Dict[str, Any]:
    token = str(flow_token or "").strip()
    if not token:
        return {}
    try:
        decoded = jwt.decode(token, _flow_runtime_token_secret(), algorithms=["HS256"])
        return decoded if isinstance(decoded, dict) else {}
    except Exception:
        return {}


def _build_dynamic_flow_runtime_response(flow_row: Dict[str, Any], decrypted_payload: Dict[str, Any]) -> Dict[str, Any]:
    action = str(decrypted_payload.get("action") or "").strip()
    current_screen = str(decrypted_payload.get("screen") or "").strip() or None
    flow_token_data = _decode_flow_runtime_token(decrypted_payload.get("flow_token"))
    if action == "ping":
        return {"data": {"status": "active"}}
    if action in {"error", "ERROR"}:
        return {"data": {"acknowledged": True}}

    initial_screen = flow_token_data.get("initial_screen") or _first_flow_screen_id(flow_row)
    next_screen = None
    if action == "INIT":
        next_screen = initial_screen
    elif action in {"data_exchange", "BACK"}:
        next_screen = _next_flow_screen_id(flow_row, current_screen or initial_screen)
    else:
        next_screen = current_screen or initial_screen

    response_data = {
        "version": str(decrypted_payload.get("version") or "3.0"),
        "flow_token": decrypted_payload.get("flow_token"),
        "acknowledged_action": action or "unknown",
        "echo_data": decrypted_payload.get("data") or {},
    }
    if not next_screen:
        return {"data": response_data}
    return {
        "screen": next_screen,
        "data": response_data,
    }


async def _upsert_phone_number_row(conn, connection_id: UUID, phone_data: Dict[str, Any]) -> None:
    if not phone_data or not phone_data.get("id"):
        return
    await conn.execute(
        """
        INSERT INTO whatsapp_phone_numbers (
            connection_id,
            phone_number_id,
            display_phone_number,
            verified_name,
            quality_rating,
            code_verification_status,
            status,
            raw_data,
            created_at,
            updated_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, NOW(), NOW())
        ON CONFLICT (phone_number_id) DO UPDATE SET
            connection_id = EXCLUDED.connection_id,
            display_phone_number = EXCLUDED.display_phone_number,
            verified_name = EXCLUDED.verified_name,
            quality_rating = EXCLUDED.quality_rating,
            code_verification_status = EXCLUDED.code_verification_status,
            status = EXCLUDED.status,
            raw_data = EXCLUDED.raw_data,
            updated_at = NOW()
        """,
        connection_id,
        str(phone_data.get("id")),
        phone_data.get("display_phone_number"),
        phone_data.get("verified_name"),
        phone_data.get("quality_rating"),
        phone_data.get("code_verification_status"),
        phone_data.get("status") or "active",
        json.dumps(phone_data),
    )


async def _log_whatsapp_message(
    conn,
    *,
    connection_id: Optional[UUID],
    direction: str,
    payload: Dict[str, Any],
    response: Optional[Dict[str, Any]] = None,
    message_type: Optional[str] = None,
    status_text: Optional[str] = None,
    from_number: Optional[str] = None,
    to_number: Optional[str] = None,
    wa_message_id: Optional[str] = None,
    chat_id: Optional[int] = None,
    project_id: Optional[UUID] = None,
    error: Optional[str] = None,
) -> None:
    await conn.execute(
        """
        INSERT INTO whatsapp_messages (
            id,
            connection_id,
            direction,
            wa_message_id,
            chat_id,
            project_id,
            from_number,
            to_number,
            message_type,
            status,
            payload,
            response,
            error,
            created_at,
            updated_at
        )
        VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
            $11::jsonb, $12::jsonb, $13, NOW(), NOW()
        )
        ON CONFLICT (wa_message_id) DO UPDATE SET
            chat_id = COALESCE(EXCLUDED.chat_id, whatsapp_messages.chat_id),
            status = COALESCE(EXCLUDED.status, whatsapp_messages.status),
            response = COALESCE(EXCLUDED.response, whatsapp_messages.response),
            error = COALESCE(EXCLUDED.error, whatsapp_messages.error),
            updated_at = NOW()
        """,
        uuid.uuid4(),
        connection_id,
        direction,
        wa_message_id,
        chat_id,
        project_id,
        from_number,
        to_number,
        message_type,
        status_text,
        json.dumps(payload or {}),
        json.dumps(response or {}),
        error,
    )


def _extract_connection_phone_number_id(payload: Dict[str, Any]) -> Optional[str]:
    entries = payload.get("entry") or []
    for entry in entries:
        for change in entry.get("changes") or []:
            value = change.get("value") or {}
            metadata = value.get("metadata") or {}
            phone_number_id = metadata.get("phone_number_id")
            if phone_number_id:
                return str(phone_number_id)
    return None


def _extract_event_type(payload: Dict[str, Any]) -> str:
    entries = payload.get("entry") or []
    for entry in entries:
        for change in entry.get("changes") or []:
            value = change.get("value") or {}
            if value.get("messages"):
                return "messages"
            if value.get("statuses"):
                return "statuses"
            if change.get("field"):
                return str(change.get("field"))
    return "unknown"


async def _fetch_connection_with_token(conn, connection_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await _fetch_connection_row(conn, connection_id, user_id)
    secret = _credentials_secret()
    token = await conn.fetchval(
        """
        SELECT pgp_sym_decrypt(access_token_encrypted, $2::text)
        FROM whatsapp_connections
        WHERE id = $1
        """,
        connection_id,
        secret,
    )
    row["access_token"] = token
    return row


async def _fetch_connection_for_webhook(conn, connection_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT *
        FROM whatsapp_connections
        WHERE id = $1
        """,
        connection_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="WhatsApp connection not found")
    row_dict = dict(row)
    secret = _credentials_secret()
    token = await conn.fetchval(
        """
        SELECT pgp_sym_decrypt(access_token_encrypted, $2::text)
        FROM whatsapp_connections
        WHERE id = $1
        """,
        connection_id,
        secret,
    )
    row_dict["access_token"] = token
    return row_dict


def _first_wa_message_id(response: Dict[str, Any]) -> Optional[str]:
    message_ids = response.get("messages") or []
    if message_ids and isinstance(message_ids[0], dict):
        return message_ids[0].get("id")
    return None


def _build_text_payload(body: WhatsAppTextMessageRequest) -> Dict[str, Any]:
    return {
        "recipient_type": "individual",
        "to": body.to,
        "type": "text",
        "text": {
            "preview_url": bool(body.preview_url),
            "body": body.text,
        },
    }


def _build_template_payload(body: WhatsAppTemplateMessageRequest) -> Dict[str, Any]:
    return {
        "recipient_type": "individual",
        "to": body.to,
        "type": "template",
        "template": {
            "name": body.template_name,
            "language": {"code": body.language_code},
            "components": body.components or [],
        },
    }


def _build_media_payload(body: WhatsAppMediaMessageRequest) -> Dict[str, Any]:
    if not body.media_id and not body.media_link:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either media_id or media_link is required for media messages",
        )
    media_object: Dict[str, Any] = {}
    if body.media_id:
        media_object["id"] = body.media_id
    if body.media_link:
        media_object["link"] = body.media_link
    if body.caption:
        media_object["caption"] = body.caption
    if body.filename and body.media_type == "document":
        media_object["filename"] = body.filename
    return {
        "recipient_type": "individual",
        "to": body.to,
        "type": body.media_type,
        body.media_type: media_object,
    }


def _build_interactive_payload(body: WhatsAppInteractiveMessageRequest) -> Dict[str, Any]:
    if not body.interactive:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="interactive payload is required",
        )
    return {
        "recipient_type": "individual",
        "to": body.to,
        "type": "interactive",
        "interactive": body.interactive,
    }


def _build_flow_payload(body: WhatsAppFlowMessageRequest) -> Dict[str, Any]:
    action_parameters: Dict[str, Any] = {
        "flow_message_version": "3",
        "flow_id": body.flow_id,
        "flow_cta": body.flow_cta,
        "flow_action": body.flow_action,
    }
    if body.flow_token:
        action_parameters["flow_token"] = body.flow_token
    if body.flow_action_payload:
        action_parameters["flow_action_payload"] = body.flow_action_payload

    interactive: Dict[str, Any] = {
        "type": "flow",
        "body": {"text": body.body_text},
        "action": {
            "name": "flow",
            "parameters": action_parameters,
        },
    }
    if body.header_text:
        interactive["header"] = {"type": "text", "text": body.header_text}
    if body.footer_text:
        interactive["footer"] = {"text": body.footer_text}

    return {
        "recipient_type": "individual",
        "to": body.to,
        "type": "interactive",
        "interactive": interactive,
    }


async def _send_whatsapp_payload(
    conn,
    *,
    connection: Dict[str, Any],
    connection_id: UUID,
    payload: Dict[str, Any],
    log_payload: Optional[Dict[str, Any]] = None,
    message_type: str,
    to_number: str,
    chat_id: Optional[int] = None,
    project_id: Optional[UUID] = None,
) -> Dict[str, Any]:
    message_payload = dict(log_payload or payload or {})
    if "send_payload" not in message_payload and isinstance(payload, dict):
        message_payload["send_payload"] = payload
    try:
        response = await send_connector_payload(
            connector_key=get_whatsapp_connector_definition(connection.get("provider")).get("connector_key", "whatsapp_meta_cloud"),
            connection=connection,
            payload=payload,
        )
    except HTTPException as exc:
        await _log_whatsapp_message(
            conn,
            connection_id=connection_id,
            direction="outbound",
            payload=message_payload,
            response={},
            message_type=message_type,
            status_text="error",
            from_number=connection.get("display_phone_number") or connection.get("business_phone_number"),
            to_number=to_number,
            chat_id=chat_id,
            project_id=project_id or connection.get("bot_project_id") or connection.get("project_id"),
            error=str(exc.detail),
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET health_status = 'error',
                updated_at = NOW()
            WHERE id = $1
            """,
            connection_id,
        )
        raise
    await _log_whatsapp_message(
        conn,
        connection_id=connection_id,
        direction="outbound",
        payload=message_payload,
        response=response,
        message_type=message_type,
        status_text="sent",
        from_number=connection.get("display_phone_number") or connection.get("business_phone_number"),
        to_number=to_number,
        wa_message_id=_first_wa_message_id(response),
        chat_id=chat_id,
        project_id=project_id or connection.get("bot_project_id") or connection.get("project_id"),
    )
    await conn.execute(
        """
        UPDATE whatsapp_connections
        SET health_status = 'healthy',
            updated_at = NOW()
        WHERE id = $1
        """,
        connection_id,
    )
    return response


def _extract_contact_name(value: Dict[str, Any], sender_number: Optional[str]) -> Optional[str]:
    if not sender_number:
        return None
    for contact in value.get("contacts") or []:
        if str(contact.get("wa_id") or "") != str(sender_number):
            continue
        profile = contact.get("profile") or {}
        profile_name = str(profile.get("name") or "").strip()
        if profile_name:
            return profile_name
    return None


def _build_whatsapp_session_id(connection_id: UUID, sender_number: Optional[str]) -> str:
    safe_sender = str(sender_number or "unknown").strip() or "unknown"
    return f"whatsapp:{connection_id}:{safe_sender}"


def _normalize_inbound_text_message(message: Dict[str, Any]) -> Optional[str]:
    message_type = str(message.get("type") or "").strip().lower()
    if message_type == "text":
        return str((message.get("text") or {}).get("body") or "").strip() or None
    if message_type == "button":
        button = message.get("button") or {}
        text = str(button.get("text") or "").strip()
        payload = str(button.get("payload") or "").strip()
        parts = [part for part in [text, payload] if part]
        return " | ".join(parts) or None
    if message_type == "interactive":
        interactive = message.get("interactive") or {}
        interactive_type = str(interactive.get("type") or "").strip().lower()
        if interactive_type == "button_reply":
            reply = interactive.get("button_reply") or {}
            title = str(reply.get("title") or "").strip()
            reply_id = str(reply.get("id") or "").strip()
            return " | ".join(part for part in [title, reply_id] if part) or None
        if interactive_type == "list_reply":
            reply = interactive.get("list_reply") or {}
            title = str(reply.get("title") or "").strip()
            description = str(reply.get("description") or "").strip()
            reply_id = str(reply.get("id") or "").strip()
            return " | ".join(part for part in [title, description, reply_id] if part) if any([title, description, reply_id]) else None
    media_payload = message.get(message_type) or {}
    if message_type in {"image", "video", "audio", "document", "sticker"}:
        caption = str(media_payload.get("caption") or "").strip()
        media_id = str(media_payload.get("id") or "").strip()
        filename = str(media_payload.get("filename") or "").strip()
        descriptor = f"[WhatsApp {message_type} message]"
        parts = [descriptor]
        if filename:
            parts.append(f"filename={filename}")
        if caption:
            parts.append(f"caption={caption}")
        if media_id:
            parts.append(f"media_id={media_id}")
        return " ".join(parts).strip()
    if message_type == "location":
        location = message.get("location") or {}
        latitude = location.get("latitude")
        longitude = location.get("longitude")
        name = str(location.get("name") or "").strip()
        address = str(location.get("address") or "").strip()
        parts = ["[WhatsApp location message]"]
        if name:
            parts.append(name)
        if address:
            parts.append(address)
        if latitude is not None and longitude is not None:
            parts.append(f"lat={latitude}, lng={longitude}")
        return " ".join(parts).strip()
    return None


async def _build_internal_chat_service(owner_user_id: UUID) -> ChatService:
    internal_db = DatabaseClient()
    await internal_db.get_pool()
    internal_db.user_id = owner_user_id
    internal_db.current_user = {
        "id": owner_user_id,
        "email": f"whatsapp_{owner_user_id}@internal.local",
        "auth_type": "whatsapp_webhook",
    }
    codegen_service = CodegenService(supabase=internal_db)
    return ChatService(supabase=internal_db, codegen_service=codegen_service)


async def _ensure_whatsapp_chat_for_sender(
    conn,
    *,
    connection_row: Dict[str, Any],
    sender_number: str,
    contact_name: Optional[str],
) -> Dict[str, Any]:
    target_project_id = connection_row.get("bot_project_id") or connection_row.get("project_id")
    owner_user_id = connection_row.get("user_id")
    if not target_project_id or not owner_user_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="WhatsApp connection is missing a linked bot project or owner",
        )

    link_row = await conn.fetchrow(
        """
        SELECT id, chat_id, project_id
        FROM whatsapp_conversation_links
        WHERE connection_id = $1 AND wa_user_phone_number = $2
        """,
        connection_row["id"],
        sender_number,
    )

    if link_row and link_row["chat_id"]:
        await conn.execute(
            """
            UPDATE whatsapp_conversation_links
            SET project_id = COALESCE($2, project_id),
                last_message_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
            """,
            link_row["id"],
            target_project_id,
        )
        return {"chat_id": int(link_row["chat_id"]), "project_id": target_project_id}

    chat_service = await _build_internal_chat_service(owner_user_id)
    chat_name = (contact_name or sender_number or "WhatsApp User").strip()
    new_chat = await chat_service.create_chat(
        ChatCreate(
            name=f"WhatsApp - {chat_name}",
            from_type="project",
            from_project=target_project_id,
            user_id=owner_user_id,
            session_id=_build_whatsapp_session_id(connection_row["id"], sender_number),
        )
    )
    await chat_service.supabase.update_chat_config(
        str(new_chat.id),
        {
            "channel": "whatsapp",
            "connector": {
                "connector_key": get_whatsapp_connector_definition(connection_row.get("provider")).get("connector_key", "whatsapp_meta_cloud"),
                "channel_key": "whatsapp",
                "provider_key": str(connection_row.get("provider") or "meta_cloud"),
                "connection_id": str(connection_row["id"]),
                "recipient": sender_number,
            },
            "whatsapp": {
                "connection_id": str(connection_row["id"]),
                "phone_number_id": str(connection_row.get("phone_number_id") or ""),
                "wa_user_phone_number": sender_number,
                "contact_name": contact_name,
            },
        },
    )

    if link_row:
        await conn.execute(
            """
            UPDATE whatsapp_conversation_links
            SET chat_id = $2,
                project_id = COALESCE($3, project_id),
                last_message_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
            """,
            link_row["id"],
            new_chat.id,
            target_project_id,
        )
    else:
        await conn.execute(
            """
            INSERT INTO whatsapp_conversation_links (
                id,
                connection_id,
                wa_user_phone_number,
                chat_id,
                project_id,
                last_message_at,
                created_at,
                updated_at
            )
            VALUES ($1, $2, $3, $4, $5, NOW(), NOW(), NOW())
            ON CONFLICT (connection_id, wa_user_phone_number) DO UPDATE SET
                chat_id = COALESCE(EXCLUDED.chat_id, whatsapp_conversation_links.chat_id),
                project_id = COALESCE(EXCLUDED.project_id, whatsapp_conversation_links.project_id),
                last_message_at = NOW(),
                updated_at = NOW()
            """,
            uuid.uuid4(),
            connection_row["id"],
            sender_number,
            new_chat.id,
            target_project_id,
        )

    return {"chat_id": int(new_chat.id), "project_id": target_project_id}


async def _route_whatsapp_message_to_bot(
    pool,
    *,
    connection_id: UUID,
    message: Dict[str, Any],
    value: Dict[str, Any],
    display_number: Optional[str],
) -> Dict[str, Any]:
    sender_number = str(message.get("from") or "").strip()
    wa_message_id = str(message.get("id") or "").strip() or None
    message_type = str(message.get("type") or "").strip() or "unknown"
    normalized_text = _normalize_inbound_text_message(message)
    contact_name = _extract_contact_name(value, sender_number)
    terminal_statuses = {"processed", "unsupported", "no_reply"}

    if not sender_number:
        return {"ok": True, "skipped_reply": True, "reason": "Missing sender number"}

    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection_row = await _fetch_connection_for_webhook(conn, connection_id)
        target_project_id = connection_row.get("bot_project_id") or connection_row.get("project_id")

        if wa_message_id:
            existing_message = await conn.fetchrow(
                """
                SELECT id, chat_id, status
                FROM whatsapp_messages
                WHERE wa_message_id = $1
                  AND direction = 'inbound'
                """,
                wa_message_id,
            )
            existing_status = str(existing_message.get("status") or "").strip().lower() if existing_message else ""
            if existing_message and existing_message.get("chat_id") and existing_status in terminal_statuses:
                return {"duplicate": True, "chat_id": int(existing_message["chat_id"])}

        chat_context = await _ensure_whatsapp_chat_for_sender(
            conn,
            connection_row=connection_row,
            sender_number=sender_number,
            contact_name=contact_name,
        )
        chat_id = int(chat_context["chat_id"])

        await _log_whatsapp_message(
            conn,
            connection_id=connection_id,
            direction="inbound",
            payload=message,
            response=value,
            message_type=message_type,
            status_text="processing",
            from_number=sender_number,
            to_number=display_number,
            wa_message_id=wa_message_id,
            chat_id=chat_id,
            project_id=target_project_id,
        )

    if not normalized_text:
        async with pool.acquire() as conn:
            await _log_whatsapp_message(
                conn,
                connection_id=connection_id,
                direction="inbound",
                payload=message,
                response=value,
                message_type=message_type,
                status_text="unsupported",
                from_number=sender_number,
                to_number=display_number,
                wa_message_id=wa_message_id,
                chat_id=chat_id,
                project_id=target_project_id,
            )
        return {"ok": True, "chat_id": chat_id, "skipped_reply": True, "reason": f"Unsupported message type: {message_type}"}

    owner_user_id = connection_row.get("user_id")
    if not owner_user_id:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="WhatsApp connection owner is missing")

    chat_service = await _build_internal_chat_service(owner_user_id)
    reply_state: Dict[str, Optional[str]] = {"summary": None, "assistant": None}

    async def capture_outbound_message(event: Dict[str, Any]) -> None:
        message_type_value = str(event.get("type") or "").strip().lower()
        content = str(event.get("answer") or event.get("content") or "").strip()
        if not content or content.startswith("__STATUS_") or content.startswith("[Tool "):
            return
        if message_type_value == "summary":
            reply_state["summary"] = content
            return
        if message_type_value == "assistant":
            reply_state["assistant"] = content

    inbound_message = MessageCreate(
        type="user",
        content=normalized_text,
        sender=sender_number or contact_name or "WhatsApp User",
        receiver=display_number or connection_row.get("display_phone_number") or connection_row.get("business_phone_number"),
        user_id=owner_user_id,
        metadata={
            "channel": "whatsapp",
            "connector_key": get_whatsapp_connector_definition(connection_row.get("provider")).get("connector_key", "whatsapp_meta_cloud"),
            "wa_message_id": wa_message_id,
            "whatsapp_message_type": message_type,
            "phone_number_id": str(connection_row.get("phone_number_id") or ""),
            "connection_id": str(connection_id),
            "contact_name": contact_name,
            "raw_message": message,
        },
    )
    result = await chat_service.start_chat(inbound_message, chat_id, on_message=capture_outbound_message)
    reply_text = (
        reply_state.get("summary")
        or (str(result.get("answer") or "").strip() if isinstance(result, dict) else "")
        or reply_state.get("assistant")
    )
    if not reply_text:
        async with pool.acquire() as conn:
            await _log_whatsapp_message(
                conn,
                connection_id=connection_id,
                direction="inbound",
                payload=message,
                response=value,
                message_type=message_type,
                status_text="no_reply",
                from_number=sender_number,
                to_number=display_number,
                wa_message_id=wa_message_id,
                chat_id=chat_id,
                project_id=target_project_id,
            )
        return {"ok": True, "chat_id": chat_id, "skipped_reply": True, "reason": "Bot produced no reply"}

    provider = get_whatsapp_provider(connection_row["provider"])
    outbound_response = await provider.send_text_message(
        graph_version=connection_row["graph_version"],
        phone_number_id=connection_row["phone_number_id"],
        access_token=connection_row["access_token"],
        to=sender_number,
        message=reply_text,
    )
    response_messages = outbound_response.get("messages") or []
    outbound_wa_message_id = (
        response_messages[0].get("id")
        if response_messages and isinstance(response_messages[0], dict)
        else None
    )

    async with pool.acquire() as conn:
        await _log_whatsapp_message(
            conn,
            connection_id=connection_id,
            direction="inbound",
            payload=message,
            response=value,
            message_type=message_type,
            status_text="processed",
            from_number=sender_number,
            to_number=display_number,
            wa_message_id=wa_message_id,
            chat_id=chat_id,
            project_id=chat_context["project_id"],
        )
        await _log_whatsapp_message(
            conn,
            connection_id=connection_id,
            direction="outbound",
            payload={"to": sender_number, "message": reply_text, "source_wa_message_id": wa_message_id},
            response=outbound_response,
            message_type="text",
            status_text="sent",
            from_number=display_number or connection_row.get("display_phone_number") or connection_row.get("business_phone_number"),
            to_number=sender_number,
            wa_message_id=outbound_wa_message_id,
            chat_id=chat_id,
            project_id=chat_context["project_id"],
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET health_status = 'healthy',
                last_webhook_event_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
            """,
            connection_id,
        )

    return {"ok": True, "chat_id": chat_id, "reply_sent": True}


@router.get("/connections", response_model=List[WhatsAppConnection], summary="List WhatsApp connections")
async def list_whatsapp_connections(
    workspace_id: Optional[UUID] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if workspace_id is not None:
            role = await _fetch_workspace_role(conn, workspace_id, user_id)
            if role is None:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the workspace")
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_connections
                WHERE workspace_id = $1
                ORDER BY updated_at DESC, created_at DESC
                """,
                workspace_id,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT wc.*
                FROM whatsapp_connections wc
                LEFT JOIN workspace_members wm
                  ON wm.workspace_id = wc.workspace_id
                 AND wm.user_id = $1
                WHERE wc.user_id = $1
                   OR wm.user_id = $1
                ORDER BY wc.updated_at DESC, wc.created_at DESC
                """,
                user_id,
            )
        return [WhatsAppConnection(**_normalize_connection_row(dict(row))) for row in rows]


@router.get("/messages", response_model=List[WhatsAppMessage], summary="List WhatsApp message logs")
async def list_whatsapp_messages(
    connection_id: Optional[UUID] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if connection_id is not None:
            await _fetch_connection_row(conn, connection_id, user_id)
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_messages
                WHERE connection_id = $1
                ORDER BY created_at DESC
                LIMIT $2
                """,
                connection_id,
                limit,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT wm.*
                FROM whatsapp_messages wm
                JOIN whatsapp_connections wc ON wc.id = wm.connection_id
                LEFT JOIN workspace_members m
                  ON m.workspace_id = wc.workspace_id
                 AND m.user_id = $1
                WHERE wc.user_id = $1
                   OR m.user_id = $1
                ORDER BY wm.created_at DESC
                LIMIT $2
                """,
                user_id,
                limit,
            )
        return [WhatsAppMessage(**_normalize_whatsapp_message_row(dict(row))) for row in rows]


@router.post("/messages/{message_id}/retry", summary="Retry failed WhatsApp message")
async def retry_whatsapp_message(
    message_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        message_row = await _fetch_message_row(conn, message_id, user_id)
        if str(message_row.get("direction") or "").strip().lower() != "outbound":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only outbound messages can be retried")
        if not message_row.get("error") and str(message_row.get("status") or "").strip().lower() not in {"error", "failed"}:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only failed outbound messages can be retried")
        connection = await _fetch_connection_with_token(conn, message_row["connection_id"], user_id)
        payload_data = dict(message_row.get("payload") or {})
        send_payload = payload_data.get("send_payload")
        if not isinstance(send_payload, dict) or not send_payload:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Retry payload is not available for this message log")
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=message_row["connection_id"],
            payload=send_payload,
            log_payload=payload_data,
            message_type=str(message_row.get("message_type") or "unknown"),
            to_number=str(message_row.get("to_number") or ""),
            chat_id=message_row.get("chat_id"),
            project_id=message_row.get("project_id"),
        )
        await conn.execute(
            """
            UPDATE whatsapp_messages
            SET response = jsonb_set(
                    COALESCE(response, '{}'::jsonb),
                    '{retry_response}',
                    $2::jsonb,
                    true
                ),
                updated_at = NOW()
            WHERE id = $1
            """,
            message_id,
            json.dumps(response or {}),
        )
        return {
            "ok": True,
            "message": "WhatsApp message retried successfully",
            "response": response,
        }


@router.get("/webhook-events", response_model=List[WhatsAppWebhookEvent], summary="List WhatsApp webhook events")
async def list_whatsapp_webhook_events(
    connection_id: Optional[UUID] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if connection_id is not None:
            await _fetch_connection_row(conn, connection_id, user_id)
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_webhook_events
                WHERE connection_id = $1
                ORDER BY created_at DESC, id DESC
                LIMIT $2
                """,
                connection_id,
                limit,
            )
        else:
            connection_ids = await _list_accessible_whatsapp_connection_ids(conn, user_id)
            if not connection_ids:
                return []
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_webhook_events
                WHERE connection_id = ANY($1::uuid[])
                ORDER BY created_at DESC, id DESC
                LIMIT $2
                """,
                connection_ids,
                limit,
            )
        return [
            WhatsAppWebhookEvent(
                id=int(row["id"]),
                connection_id=row.get("connection_id"),
                event_type=row.get("event_type"),
                payload=dict(row.get("payload") or {}),
                headers=dict(row.get("headers") or {}),
                processed=bool(row.get("processed")),
                created_at=row.get("created_at"),
            )
            for row in rows
        ]


@router.get("/dashboard", response_model=WhatsAppChannelDashboard, summary="Get WhatsApp support dashboard")
async def get_whatsapp_channel_dashboard(
    connection_id: Optional[UUID] = Query(None),
    days: int = Query(7, ge=1, le=90),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if connection_id is not None:
            await _fetch_connection_row(conn, connection_id, user_id)
            connection_ids = [connection_id]
            connection_rows = await conn.fetch(
                """
                SELECT id, connection_status, webhook_status, health_status
                FROM whatsapp_connections
                WHERE id = $1
                """,
                connection_id,
            )
        else:
            connection_ids = await _list_accessible_whatsapp_connection_ids(conn, user_id)
            if not connection_ids:
                return WhatsAppChannelDashboard(connection_id=None, generated_at=datetime.utcnow())
            connection_rows = await conn.fetch(
                """
                SELECT id, connection_status, webhook_status, health_status
                FROM whatsapp_connections
                WHERE id = ANY($1::uuid[])
                """,
                connection_ids,
            )

        since_expr = f"NOW() - INTERVAL '{int(days)} days'"
        message_rows = await conn.fetch(
            f"""
            SELECT id, direction, status, error, payload, created_at
            FROM whatsapp_messages
            WHERE connection_id = ANY($1::uuid[])
              AND created_at >= {since_expr}
            ORDER BY created_at DESC
            """,
            connection_ids,
        )
        webhook_rows = await conn.fetch(
            f"""
            SELECT id, event_type, processed, created_at
            FROM whatsapp_webhook_events
            WHERE connection_id = ANY($1::uuid[])
              AND created_at >= {since_expr}
            ORDER BY created_at DESC
            """,
            connection_ids,
        )
        template_rows = await conn.fetch(
            """
            SELECT wt.name, wt.status
            FROM whatsapp_templates wt
            WHERE wt.connection_id = ANY($1::uuid[])
            """,
            connection_ids,
        )
        flow_rows = await conn.fetch(
            """
            SELECT id, meta_flow_id, name, status, raw_data, updated_at
            FROM whatsapp_flows
            WHERE connection_id = ANY($1::uuid[])
            """,
            connection_ids,
        )

        connection_health = Counter()
        for row in connection_rows:
            status_value = str(row.get("health_status") or row.get("connection_status") or row.get("webhook_status") or "unknown")
            connection_health[status_value] += 1

        message_totals = Counter()
        daily_counts_map: Dict[str, Dict[str, int]] = defaultdict(lambda: {"inbound": 0, "outbound": 0, "status": 0, "total": 0})
        failure_reasons = Counter()
        pending_retries = 0
        flow_send_counts = Counter()
        flow_last_sent: Dict[str, datetime] = {}
        for row in message_rows:
            direction = str(row.get("direction") or "unknown")
            message_totals[direction] += 1
            created_at = row.get("created_at")
            if created_at is not None:
                date_key = created_at.date().isoformat()
                daily_counts_map[date_key]["total"] += 1
                if direction in {"inbound", "outbound", "status"}:
                    daily_counts_map[date_key][direction] += 1
            status_value = str(row.get("status") or "").strip().lower()
            error_value = str(row.get("error") or "").strip()
            if direction == "outbound" and (error_value or status_value in {"error", "failed"}):
                pending_retries += 1
                failure_reasons[error_value or status_value or "unknown"] += 1
            if direction == "status" and status_value in {"failed", "undelivered"}:
                failure_reasons[status_value] += 1
            payload = dict(row.get("payload") or {})
            flow_key = str(payload.get("saved_flow_id") or payload.get("flow_id") or "").strip()
            if flow_key:
                flow_send_counts[flow_key] += 1
                if created_at and (flow_key not in flow_last_sent or created_at > flow_last_sent[flow_key]):
                    flow_last_sent[flow_key] = created_at

        webhook_totals = Counter()
        for row in webhook_rows:
            event_type = str(row.get("event_type") or "unknown")
            webhook_totals[event_type] += 1
            if not bool(row.get("processed")):
                webhook_totals["unprocessed"] += 1

        template_statuses = Counter()
        rejected_templates: List[str] = []
        for row in template_rows:
            status_value = str(row.get("status") or "unknown")
            template_statuses[status_value] += 1
            if status_value.lower() in {"rejected", "disabled", "paused"}:
                rejected_templates.append(str(row.get("name") or "Unnamed template"))

        flow_statuses = Counter()
        flow_activity: List[WhatsAppFlowActivityStat] = []
        for row in flow_rows:
            row_dict = dict(row)
            raw_data = row_dict.get("raw_data") if isinstance(row_dict.get("raw_data"), dict) else {}
            status_value = str(row_dict.get("status") or "unknown")
            flow_statuses[status_value] += 1
            publish_response = raw_data.get("publish_response")
            last_published_at = row_dict.get("updated_at") if publish_response else None
            saved_flow_id = row_dict.get("id")
            meta_flow_id = str(row_dict.get("meta_flow_id") or "").strip() or None
            send_key = str(saved_flow_id) if saved_flow_id and str(saved_flow_id) in flow_send_counts else str(meta_flow_id or "")
            flow_activity.append(
                WhatsAppFlowActivityStat(
                    saved_flow_id=saved_flow_id,
                    meta_flow_id=meta_flow_id,
                    flow_name=str(row_dict.get("name") or "Unnamed flow"),
                    status=status_value,
                    send_count=int(flow_send_counts.get(send_key, 0)),
                    last_sent_at=flow_last_sent.get(send_key),
                    last_published_at=last_published_at,
                )
            )
        flow_activity.sort(key=lambda item: ((item.last_sent_at or item.last_published_at or datetime.min), item.send_count), reverse=True)

        daily_counts = [
            WhatsAppDashboardDailyStat(date=date_key, **counts)
            for date_key, counts in sorted(daily_counts_map.items())
        ]

        return WhatsAppChannelDashboard(
            connection_id=connection_id,
            generated_at=datetime.utcnow(),
            connection_health=dict(connection_health),
            message_totals=dict(message_totals),
            webhook_totals=dict(webhook_totals),
            daily_counts=daily_counts,
            failure_reasons=[
                WhatsAppDashboardCountStat(label=label, count=count)
                for label, count in failure_reasons.most_common(8)
            ],
            template_statuses=[
                WhatsAppDashboardCountStat(label=label, count=count)
                for label, count in template_statuses.most_common()
            ],
            rejected_templates=rejected_templates[:10],
            flow_statuses=[
                WhatsAppDashboardCountStat(label=label, count=count)
                for label, count in flow_statuses.most_common()
            ],
            flow_activity=flow_activity[:10],
            pending_retries=pending_retries,
        )


@router.get("/templates", response_model=List[WhatsAppTemplate], summary="List WhatsApp templates")
async def list_whatsapp_templates(
    connection_id: Optional[UUID] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if connection_id is not None:
            await _fetch_connection_row(conn, connection_id, user_id)
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_templates
                WHERE connection_id = $1
                ORDER BY updated_at DESC, created_at DESC
                """,
                connection_id,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT wt.*
                FROM whatsapp_templates wt
                JOIN whatsapp_connections wc ON wc.id = wt.connection_id
                LEFT JOIN workspace_members m
                  ON m.workspace_id = wc.workspace_id
                 AND m.user_id = $1
                WHERE wc.user_id = $1
                   OR m.user_id = $1
                ORDER BY wt.updated_at DESC, wt.created_at DESC
                """,
                user_id,
            )
        return [WhatsAppTemplate(**_normalize_whatsapp_template_row(dict(row))) for row in rows]


@router.post("/templates", response_model=WhatsAppTemplate, status_code=status.HTTP_201_CREATED, summary="Create WhatsApp template")
async def create_whatsapp_template(
    body: WhatsAppTemplateCreateRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        provider = get_whatsapp_provider(connection["provider"])

        template_payload = _build_meta_template_payload(body)
        if body.submit_to_meta:
            created = await provider.create_template(
                graph_version=connection["graph_version"],
                waba_id=connection["waba_id"],
                access_token=connection["access_token"],
                payload=template_payload,
            )
            row = await _upsert_whatsapp_template_row(
                conn,
                connection_id=body.connection_id,
                template_data=created,
                default_name=body.name,
                default_language=body.language,
                default_category=body.category,
                default_components=body.components,
            )
        else:
            row = await _upsert_whatsapp_template_row(
                conn,
                connection_id=body.connection_id,
                template_data={
                    "name": body.name,
                    "language": body.language,
                    "category": body.category,
                    "status": "draft",
                    "components": body.components,
                    "metadata": body.metadata,
                },
                default_name=body.name,
                default_language=body.language,
                default_category=body.category,
                default_components=body.components,
            )
        return WhatsAppTemplate(**_normalize_whatsapp_template_row(row))


@router.get("/templates/{template_id}", response_model=WhatsAppTemplate, summary="Get WhatsApp template")
async def get_whatsapp_template(
    template_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        row = await _fetch_template_row(conn, template_id, user_id)
        return WhatsAppTemplate(**_normalize_whatsapp_template_row(row))


@router.post("/templates/{template_id}/sync", response_model=WhatsAppTemplate, summary="Sync WhatsApp template from Meta")
async def sync_whatsapp_template(
    template_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        template_row = await _fetch_template_row(conn, template_id, user_id)
        connection = await _fetch_connection_with_token(conn, template_row["connection_id"], user_id)
        provider = get_whatsapp_provider(connection["provider"])

        remote_template = None
        meta_template_id = str(template_row.get("meta_template_id") or "").strip()
        if meta_template_id:
            remote_template = await provider.get_template(
                graph_version=connection["graph_version"],
                template_id=meta_template_id,
                access_token=connection["access_token"],
            )
        else:
            remote_list = await provider.list_templates(
                graph_version=connection["graph_version"],
                waba_id=connection["waba_id"],
                access_token=connection["access_token"],
                name=template_row["name"],
            )
            candidates = remote_list.get("data") or []
            remote_template = next(
                (
                    item for item in candidates
                    if str(item.get("name") or "").strip().lower() == str(template_row["name"]).strip().lower()
                ),
                None,
            )
            if remote_template is None:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template was not found on Meta")

        row = await _upsert_whatsapp_template_row(
            conn,
            connection_id=template_row["connection_id"],
            template_data=remote_template or {},
            template_id=template_id,
            default_name=template_row["name"],
            default_language=template_row.get("language"),
            default_category=template_row.get("category"),
            default_components=template_row.get("components") or [],
        )
        return WhatsAppTemplate(**_normalize_whatsapp_template_row(row))


@router.post("/templates/{template_id}/send", summary="Send WhatsApp template by saved template")
async def send_saved_whatsapp_template(
    template_id: UUID,
    body: WhatsAppTemplateSendRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        template_row = await _fetch_template_row(conn, template_id, user_id)
        connection = await _fetch_connection_with_token(conn, template_row["connection_id"], user_id)
        payload = {
            "recipient_type": "individual",
            "to": body.to,
            "type": "template",
            "template": {
                "name": template_row["name"],
                "language": {"code": body.language_code or template_row.get("language") or "en_US"},
                "components": body.components or [],
            },
        }
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=template_row["connection_id"],
            payload=payload,
            log_payload={
                "to": body.to,
                "template_id": str(template_id),
                "template_name": template_row["name"],
                "language_code": body.language_code or template_row.get("language") or "en_US",
                "components": body.components or [],
            },
            message_type="template",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp template send request sent",
            "response": response,
        }


@router.get("/flows", response_model=List[WhatsAppFlow], summary="List WhatsApp flows")
async def list_whatsapp_flows(
    connection_id: Optional[UUID] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if connection_id is not None:
            await _fetch_connection_row(conn, connection_id, user_id)
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_flows
                WHERE connection_id = $1
                ORDER BY updated_at DESC, created_at DESC
                """,
                connection_id,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT wf.*
                FROM whatsapp_flows wf
                JOIN whatsapp_connections wc ON wc.id = wf.connection_id
                LEFT JOIN workspace_members m
                  ON m.workspace_id = wc.workspace_id
                 AND m.user_id = $1
                WHERE wc.user_id = $1
                   OR m.user_id = $1
                ORDER BY wf.updated_at DESC, wf.created_at DESC
                """,
                user_id,
            )
        return [WhatsAppFlow(**_normalize_whatsapp_flow_row(dict(row))) for row in rows]


@router.post("/flows", response_model=WhatsAppFlow, status_code=status.HTTP_201_CREATED, summary="Create WhatsApp flow")
async def create_whatsapp_flow(
    body: WhatsAppFlowCreateRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    flow_json = _normalize_flow_json_string(body.flow_json)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        provider = get_whatsapp_provider(connection["provider"])

        created = await provider.create_flow(
            graph_version=connection["graph_version"],
            waba_id=connection["waba_id"],
            access_token=connection["access_token"],
            payload={
                "name": body.name,
                "categories": body.categories,
                "endpoint_uri": body.endpoint_uri,
                "clone_flow_id": body.clone_flow_id,
            },
        )
        remote_flow_id = str(created.get("id") or "").strip()
        if not remote_flow_id:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Meta did not return a flow id")

        upload_response = None
        if flow_json:
            upload_response = await provider.update_flow_json(
                graph_version=connection["graph_version"],
                flow_id=remote_flow_id,
                access_token=connection["access_token"],
                flow_json=flow_json,
            )

        flow_details = await provider.get_flow(
            graph_version=connection["graph_version"],
            flow_id=remote_flow_id,
            access_token=connection["access_token"],
        )
        preview = None
        try:
            preview = await provider.get_flow_preview(
                graph_version=connection["graph_version"],
                flow_id=remote_flow_id,
                access_token=connection["access_token"],
            )
        except HTTPException:
            preview = None

        row = await _upsert_whatsapp_flow_row(
            conn,
            connection_id=body.connection_id,
            flow_data={
                **flow_details,
                "upload_response": upload_response,
                "preview_data": preview,
                "local_flow_json": flow_json,
            },
            default_name=body.name,
            default_categories=body.categories,
        )
        return WhatsAppFlow(**_normalize_whatsapp_flow_row(row))


@router.get("/flows/{flow_id}", response_model=WhatsAppFlow, summary="Get WhatsApp flow")
async def get_whatsapp_flow(
    flow_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        if flow_row.get("meta_flow_id"):
            provider = get_whatsapp_provider(connection["provider"])
            details = await provider.get_flow(
                graph_version=connection["graph_version"],
                flow_id=flow_row["meta_flow_id"],
                access_token=connection["access_token"],
            )
            merged_raw = dict(flow_row.get("raw_data") or {})
            try:
                merged_raw["assets"] = await provider.list_flow_assets(
                    graph_version=connection["graph_version"],
                    flow_id=flow_row["meta_flow_id"],
                    access_token=connection["access_token"],
                )
            except HTTPException:
                pass
            try:
                merged_raw["preview_data"] = await provider.get_flow_preview(
                    graph_version=connection["graph_version"],
                    flow_id=flow_row["meta_flow_id"],
                    access_token=connection["access_token"],
                )
            except HTTPException:
                pass
            row = await _upsert_whatsapp_flow_row(
                conn,
                connection_id=flow_row["connection_id"],
                flow_data={**details, **merged_raw},
                flow_id=flow_id,
                default_name=flow_row["name"],
                default_categories=flow_row.get("categories") or [],
            )
            return WhatsAppFlow(**_normalize_whatsapp_flow_row(row))
        return WhatsAppFlow(**_normalize_whatsapp_flow_row(flow_row))


@router.get(
    "/flows/{flow_id}/public-key",
    response_model=WhatsAppFlowPublicKeyStatus,
    summary="Get WhatsApp flow runtime public key status",
)
async def get_whatsapp_flow_public_key(
    flow_id: UUID,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        callback_url = _build_flow_runtime_callback_url(flow_id, request)
        provider = get_whatsapp_provider(connection["provider"])
        try:
            remote_status = await provider.get_business_public_key(
                graph_version=connection["graph_version"],
                phone_number_id=connection["phone_number_id"],
                access_token=connection["access_token"],
            )
        except HTTPException:
            remote_status = {}
        metadata = _build_flow_runtime_metadata(
            connection.get("metadata"),
            callback_url=callback_url,
            meta_public_key_signature_status=remote_status.get("business_public_key_signature_status"),
            meta_public_key=remote_status.get("business_public_key"),
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET metadata = $2::jsonb,
                updated_at = NOW()
            WHERE id = $1
            """,
            flow_row["connection_id"],
            json.dumps(metadata),
        )
        return WhatsAppFlowPublicKeyStatus(
            flow_id=flow_id,
            connection_id=flow_row["connection_id"],
            phone_number_id=connection["phone_number_id"],
            callback_url=callback_url,
            public_key=connection.get("flow_public_key_pem"),
            public_key_fingerprint=connection.get("flow_key_fingerprint"),
            key_generated_at=connection.get("flow_key_generated_at"),
            meta_signature_status=remote_status.get("business_public_key_signature_status"),
            meta_public_key=remote_status.get("business_public_key"),
            metadata=metadata.get("flow_runtime") or {},
        )


@router.post(
    "/flows/{flow_id}/public-key",
    response_model=WhatsAppFlowPublicKeyStatus,
    summary="Generate and register WhatsApp flow runtime public key",
)
async def create_whatsapp_flow_public_key(
    flow_id: UUID,
    body: WhatsAppFlowPublicKeyRequest,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        provider = get_whatsapp_provider(connection["provider"])

        public_key_pem = connection.get("flow_public_key_pem")
        private_key_pem = None if not public_key_pem else await _decrypt_connection_flow_private_key(conn, flow_row["connection_id"])
        fingerprint = connection.get("flow_key_fingerprint")
        key_generated_at = connection.get("flow_key_generated_at")
        if body.regenerate or not public_key_pem or not private_key_pem:
            generated = _generate_flow_key_material()
            public_key_pem = generated["public_pem"]
            private_key_pem = generated["private_pem"]
            fingerprint = generated["fingerprint"]
            row = await conn.fetchrow(
                """
                UPDATE whatsapp_connections
                SET flow_private_key_encrypted = pgp_sym_encrypt($2::text, $3::text),
                    flow_public_key_pem = $4,
                    flow_key_fingerprint = $5,
                    flow_key_generated_at = NOW(),
                    updated_at = NOW()
                WHERE id = $1
                RETURNING flow_key_generated_at
                """,
                flow_row["connection_id"],
                private_key_pem,
                _credentials_secret(),
                public_key_pem,
                fingerprint,
            )
            key_generated_at = row.get("flow_key_generated_at") if row else None

        remote_status: Dict[str, Any] = {}
        registration_response: Dict[str, Any] = {}
        if body.register_with_meta and public_key_pem:
            registration_response = await provider.set_business_public_key(
                graph_version=connection["graph_version"],
                phone_number_id=connection["phone_number_id"],
                access_token=connection["access_token"],
                business_public_key=public_key_pem,
            )
            try:
                remote_status = await provider.get_business_public_key(
                    graph_version=connection["graph_version"],
                    phone_number_id=connection["phone_number_id"],
                    access_token=connection["access_token"],
                )
            except HTTPException:
                remote_status = {}

        callback_url = _build_flow_runtime_callback_url(flow_id, request)
        metadata = _build_flow_runtime_metadata(
            connection.get("metadata"),
            enabled=True,
            callback_url=callback_url,
            public_key_fingerprint=fingerprint,
            key_generated_at=str(key_generated_at) if key_generated_at else None,
            last_registration_response=registration_response or None,
            meta_public_key_signature_status=remote_status.get("business_public_key_signature_status"),
            meta_public_key=remote_status.get("business_public_key"),
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET metadata = $2::jsonb,
                updated_at = NOW()
            WHERE id = $1
            """,
            flow_row["connection_id"],
            json.dumps(metadata),
        )
        return WhatsAppFlowPublicKeyStatus(
            flow_id=flow_id,
            connection_id=flow_row["connection_id"],
            phone_number_id=connection["phone_number_id"],
            callback_url=callback_url,
            public_key=public_key_pem,
            public_key_fingerprint=fingerprint,
            key_generated_at=key_generated_at,
            meta_signature_status=remote_status.get("business_public_key_signature_status"),
            meta_public_key=remote_status.get("business_public_key"),
            metadata=metadata.get("flow_runtime") or {},
        )


@router.post(
    "/flows/{flow_id}/data-endpoint",
    response_model=WhatsAppFlow,
    summary="Bind WhatsApp flow to runtime data endpoint",
)
async def configure_whatsapp_flow_data_endpoint(
    flow_id: UUID,
    body: WhatsAppFlowEndpointConfigRequest,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        provider = get_whatsapp_provider(connection["provider"])
        endpoint_uri = (body.endpoint_uri or _build_flow_runtime_callback_url(flow_id, request) or "").strip()
        if not endpoint_uri:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unable to determine a public runtime callback URL. Set BACKEND_URL or provide endpoint_uri.",
            )
        if not flow_row.get("meta_flow_id"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only Meta-backed flows can be configured")

        if body.update_meta:
            await provider.update_flow_metadata(
                graph_version=connection["graph_version"],
                flow_id=flow_row["meta_flow_id"],
                access_token=connection["access_token"],
                name=flow_row["name"],
                categories=flow_row.get("categories") or [],
                endpoint_uri=endpoint_uri,
            )
            details = await provider.get_flow(
                graph_version=connection["graph_version"],
                flow_id=flow_row["meta_flow_id"],
                access_token=connection["access_token"],
            )
        else:
            details = {}

        merged_raw = dict(flow_row.get("raw_data") or {})
        merged_raw["endpoint_uri"] = endpoint_uri
        merged_raw["runtime_callback_url"] = endpoint_uri
        row = await _upsert_whatsapp_flow_row(
            conn,
            connection_id=flow_row["connection_id"],
            flow_data={**details, **merged_raw},
            flow_id=flow_id,
            default_name=flow_row["name"],
            default_categories=flow_row.get("categories") or [],
        )
        metadata = _build_flow_runtime_metadata(
            connection.get("metadata"),
            enabled=True,
            callback_url=endpoint_uri,
            bound_flow_id=str(flow_id),
            bound_meta_flow_id=flow_row.get("meta_flow_id"),
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET metadata = $2::jsonb,
                updated_at = NOW()
            WHERE id = $1
            """,
            flow_row["connection_id"],
            json.dumps(metadata),
        )
        return WhatsAppFlow(**_normalize_whatsapp_flow_row(row))


@router.get(
    "/flows/{flow_id}/runtime-events",
    response_model=List[WhatsAppFlowRuntimeEvent],
    summary="List WhatsApp flow runtime events",
)
async def list_whatsapp_flow_runtime_events(
    flow_id: UUID,
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        rows = await conn.fetch(
            """
            SELECT *
            FROM whatsapp_webhook_events
            WHERE connection_id = $1
              AND event_type = 'flow_runtime_callback'
              AND payload->>'flow_id' = $2
            ORDER BY created_at DESC, id DESC
            LIMIT $3
            """,
            flow_row["connection_id"],
            str(flow_id),
            limit,
        )
        return [
            WhatsAppFlowRuntimeEvent(
                id=int(row["id"]),
                flow_id=flow_id,
                connection_id=row.get("connection_id"),
                event_type=str(row.get("event_type") or "flow_runtime_callback"),
                processed=bool(row.get("processed")),
                payload=dict(row.get("payload") or {}),
                headers=dict(row.get("headers") or {}),
                created_at=row.get("created_at"),
            )
            for row in rows
        ]


@router.post(
    "/flows/{flow_id}/runtime-events/{event_id}/replay",
    response_model=WhatsAppFlowRuntimeReplayResponse,
    summary="Replay WhatsApp flow runtime event",
)
async def replay_whatsapp_flow_runtime_event(
    flow_id: UUID,
    event_id: int,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        event_row = await _fetch_flow_runtime_event_row(conn, flow_id, event_id)
        private_key_pem = await _decrypt_connection_flow_private_key(conn, flow_row["connection_id"])
        if not private_key_pem:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Flow runtime private key is not configured for this connection",
            )
        payload = dict(event_row.get("payload") or {})
        decrypted = _decrypt_flow_runtime_payload(payload, private_key_pem)
        decrypted_payload = decrypted["decrypted_payload"]
        response_payload = _build_dynamic_flow_runtime_response(flow_row, decrypted_payload)
        encrypted_response = _encrypt_flow_runtime_response(
            response_payload,
            decrypted["aes_key"],
            decrypted["initial_vector"],
        )
        replayed_at = datetime.utcnow()
        await conn.execute(
            """
            UPDATE whatsapp_webhook_events
            SET payload = jsonb_set(
                    jsonb_set(
                        payload,
                        '{last_replay_response_preview}',
                        to_jsonb($2::text),
                        true
                    ),
                    '{last_replayed_at}',
                    to_jsonb($3::text),
                    true
                )
            WHERE id = $1
            """,
            event_id,
            encrypted_response[:128],
            replayed_at.isoformat(),
        )
        return WhatsAppFlowRuntimeReplayResponse(
            flow_id=flow_id,
            event_id=event_id,
            decrypted_payload=decrypted_payload,
            response_payload=response_payload,
            encrypted_response=encrypted_response,
            replayed_at=replayed_at,
        )


@router.patch("/flows/{flow_id}", response_model=WhatsAppFlow, summary="Update WhatsApp flow")
async def update_whatsapp_flow(
    flow_id: UUID,
    body: WhatsAppFlowUpdateRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    flow_json = _normalize_flow_json_string(body.flow_json)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        provider = get_whatsapp_provider(connection["provider"])
        if not flow_row.get("meta_flow_id"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only Meta-backed flows can be updated")

        metadata_payload = {
            "name": body.name or flow_row["name"],
            "categories": body.categories if body.categories is not None else flow_row.get("categories") or [],
            "endpoint_uri": body.endpoint_uri,
        }
        metadata_response = await provider.update_flow_metadata(
            graph_version=connection["graph_version"],
            flow_id=flow_row["meta_flow_id"],
            access_token=connection["access_token"],
            payload=metadata_payload,
        )
        upload_response = None
        if flow_json:
            upload_response = await provider.update_flow_json(
                graph_version=connection["graph_version"],
                flow_id=flow_row["meta_flow_id"],
                access_token=connection["access_token"],
                flow_json=flow_json,
            )
        details = await provider.get_flow(
            graph_version=connection["graph_version"],
            flow_id=flow_row["meta_flow_id"],
            access_token=connection["access_token"],
        )
        merged_raw = dict(flow_row.get("raw_data") or {})
        merged_raw["metadata_update_response"] = metadata_response
        merged_raw["upload_response"] = upload_response
        if flow_json:
            merged_raw["local_flow_json"] = flow_json
        row = await _upsert_whatsapp_flow_row(
            conn,
            connection_id=flow_row["connection_id"],
            flow_data={**details, **merged_raw},
            flow_id=flow_id,
            default_name=metadata_payload["name"],
            default_categories=metadata_payload["categories"],
        )
        return WhatsAppFlow(**_normalize_whatsapp_flow_row(row))


@router.post("/flows/{flow_id}/publish", response_model=WhatsAppFlow, summary="Publish WhatsApp flow")
async def publish_whatsapp_flow(
    flow_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        provider = get_whatsapp_provider(connection["provider"])
        if not flow_row.get("meta_flow_id"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only Meta-backed flows can be published")

        publish_response = await provider.publish_flow(
            graph_version=connection["graph_version"],
            flow_id=flow_row["meta_flow_id"],
            access_token=connection["access_token"],
        )
        details = await provider.get_flow(
            graph_version=connection["graph_version"],
            flow_id=flow_row["meta_flow_id"],
            access_token=connection["access_token"],
        )
        merged_raw = dict(flow_row.get("raw_data") or {})
        merged_raw["publish_response"] = publish_response
        try:
            merged_raw["preview_data"] = await provider.get_flow_preview(
                graph_version=connection["graph_version"],
                flow_id=flow_row["meta_flow_id"],
                access_token=connection["access_token"],
            )
        except HTTPException:
            pass
        row = await _upsert_whatsapp_flow_row(
            conn,
            connection_id=flow_row["connection_id"],
            flow_data={**details, **merged_raw},
            flow_id=flow_id,
            default_name=flow_row["name"],
            default_categories=flow_row.get("categories") or [],
        )
        return WhatsAppFlow(**_normalize_whatsapp_flow_row(row))


@router.post("/flows/{flow_id}/send", summary="Send WhatsApp saved flow")
async def send_saved_whatsapp_flow(
    flow_id: UUID,
    body: WhatsAppSavedFlowSendRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_row(conn, flow_id, user_id)
        connection = await _fetch_connection_with_token(conn, flow_row["connection_id"], user_id)
        if not flow_row.get("meta_flow_id"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Only Meta-backed flows can be sent")
        flow_token = body.flow_token or _issue_flow_runtime_token(
            connection_id=flow_row["connection_id"],
            saved_flow_id=flow_id,
            meta_flow_id=flow_row.get("meta_flow_id"),
            initial_screen=_first_flow_screen_id(flow_row),
        )

        flow_payload = {
            "recipient_type": "individual",
            "to": body.to,
            "type": "interactive",
            "interactive": {
                "type": "flow",
                "body": {"text": body.body_text},
                "action": {
                    "name": "flow",
                    "parameters": {
                        "flow_message_version": "3",
                        "flow_id": flow_row["meta_flow_id"],
                        "flow_cta": body.flow_cta,
                        "flow_action": body.flow_action,
                        "flow_token": flow_token,
                    },
                },
            },
        }
        if body.flow_action_payload:
            flow_payload["interactive"]["action"]["parameters"]["flow_action_payload"] = body.flow_action_payload
        if body.header_text:
            flow_payload["interactive"]["header"] = {"type": "text", "text": body.header_text}
        if body.footer_text:
            flow_payload["interactive"]["footer"] = {"text": body.footer_text}

        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=flow_row["connection_id"],
            payload=flow_payload,
            log_payload={
                "to": body.to,
                "saved_flow_id": str(flow_id),
                "flow_id": flow_row["meta_flow_id"],
                "flow_name": flow_row["name"],
                "flow_cta": body.flow_cta,
                "flow_token": flow_token,
                "flow_action": body.flow_action,
                "flow_action_payload": body.flow_action_payload,
                "body_text": body.body_text,
                "header_text": body.header_text,
                "footer_text": body.footer_text,
            },
            message_type="flow",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp flow send request sent",
            "response": response,
        }


@router.post("/discover-assets", summary="Discover WhatsApp assets for setup")
async def discover_whatsapp_assets(
    body: WhatsAppDiscoveryRequest,
    current_user: dict = Depends(get_current_user),
):
    await _get_user_id(current_user)
    provider = get_whatsapp_provider(body.provider)
    graph_version = body.graph_version or os.getenv("WHATSAPP_GRAPH_VERSION") or "v23.0"

    wabas = []
    phone_numbers = []

    if body.meta_business_account_id:
        waba_response = await provider.list_wabas(
            graph_version=graph_version,
            meta_business_account_id=body.meta_business_account_id,
            access_token=body.access_token,
        )
        wabas = waba_response.get("data") or []

    selected_waba_id = body.waba_id or (wabas[0].get("id") if wabas and isinstance(wabas[0], dict) else None)
    if selected_waba_id:
        phone_response = await provider.list_phone_numbers(
            graph_version=graph_version,
            waba_id=str(selected_waba_id),
            access_token=body.access_token,
        )
        phone_numbers = phone_response.get("data") or []

    return {
        "provider": body.provider,
        "graph_version": graph_version,
        "wabas": wabas,
        "selected_waba_id": selected_waba_id,
        "phone_numbers": phone_numbers,
    }


@router.post("/connections", response_model=WhatsAppConnection, status_code=status.HTTP_201_CREATED, summary="Create WhatsApp connection")
async def create_whatsapp_connection(
    body: WhatsAppConnectionCreate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)

        project_row: Optional[Dict[str, Any]] = None
        bot_project_row: Optional[Dict[str, Any]] = None
        effective_workspace_id = body.workspace_id
        if body.project_id is not None:
            project_row = await _fetch_authorized_project(conn, user_id, body.project_id)
            project_workspace_id = project_row.get("workspace_id")
            if effective_workspace_id is None:
                effective_workspace_id = project_workspace_id
            elif project_workspace_id != effective_workspace_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="workspace_id must match the selected project's workspace",
                )

        if body.bot_project_id is not None:
            bot_project_row = await _fetch_authorized_project(conn, user_id, body.bot_project_id)
            bot_project_workspace_id = bot_project_row.get("workspace_id")
            if effective_workspace_id is None:
                effective_workspace_id = bot_project_workspace_id
            elif bot_project_workspace_id != effective_workspace_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="workspace_id must match the selected bot project's workspace",
                )

        if effective_workspace_id is not None:
            role = await _fetch_workspace_role(conn, effective_workspace_id, user_id)
            if role is None:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the workspace")

        connection_name = body.name or body.display_phone_number or body.business_phone_number or "WhatsApp connection"
        graph_version = body.graph_version or os.getenv("WHATSAPP_GRAPH_VERSION") or "v23.0"
        token_hint = body.access_token[-4:] if body.access_token else None
        metadata_json = json.dumps(body.metadata or {})
        secret = _credentials_secret()

        try:
            row = await conn.fetchrow(
                """
                INSERT INTO whatsapp_connections (
                    workspace_id,
                    project_id,
                    bot_project_id,
                    user_id,
                    created_by,
                    name,
                    provider,
                    graph_version,
                    meta_business_account_id,
                    waba_id,
                    phone_number_id,
                    business_phone_number,
                    display_phone_number,
                    access_token_encrypted,
                    access_token_hint,
                    connection_status,
                    webhook_status,
                    metadata,
                    created_at,
                    updated_at
                )
                VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
                    pgp_sym_encrypt($14, $15::text),
                    $16, 'draft', 'pending', 'unknown', 'never', 'unknown', $17::jsonb, NOW(), NOW()
                )
                RETURNING *
                """,
                effective_workspace_id,
                body.project_id,
                body.bot_project_id,
                user_id,
                user_id,
                connection_name,
                body.provider,
                graph_version,
                body.meta_business_account_id,
                body.waba_id,
                body.phone_number_id,
                body.business_phone_number,
                body.display_phone_number,
                body.access_token,
                secret,
                token_hint,
                metadata_json,
            )
        except Exception as exc:
            if "whatsapp_connections_phone_number_id_key" in str(exc):
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="This phone number is already connected")
            raise

        return WhatsAppConnection(**_normalize_connection_row(dict(row)))


@router.get("/connections/{connection_id}", response_model=WhatsAppConnection, summary="Get WhatsApp connection")
async def get_whatsapp_connection(
    connection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        row = await _fetch_connection_row(conn, connection_id, user_id)
        return WhatsAppConnection(**_normalize_connection_row(row))


@router.patch("/connections/{connection_id}", response_model=WhatsAppConnection, summary="Update WhatsApp connection")
async def update_whatsapp_connection(
    connection_id: UUID,
    body: WhatsAppConnectionUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        existing = await _fetch_connection_row(conn, connection_id, user_id)

        project_id = body.project_id if body.project_id is not None else existing.get("project_id")
        if project_id is not None:
            project_row = await _fetch_authorized_project(conn, user_id, project_id)
            if existing.get("workspace_id") is not None and project_row.get("workspace_id") != existing.get("workspace_id"):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Selected project must belong to the same workspace as the WhatsApp connection",
                )

        bot_project_id = body.bot_project_id if body.bot_project_id is not None else existing.get("bot_project_id")
        if bot_project_id is not None:
            bot_project_row = await _fetch_authorized_project(conn, user_id, bot_project_id)
            if existing.get("workspace_id") is not None and bot_project_row.get("workspace_id") != existing.get("workspace_id"):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Selected bot project must belong to the same workspace as the WhatsApp connection",
                )

        next_metadata = existing.get("metadata") or {}
        if body.metadata is not None:
            next_metadata = body.metadata

        token_value = body.access_token
        token_hint = token_value[-4:] if token_value else existing.get("access_token_hint")

        query = """
            UPDATE whatsapp_connections
            SET name = $2,
                project_id = $3,
                bot_project_id = $4,
                graph_version = $5,
                meta_business_account_id = $6,
                waba_id = $7,
                phone_number_id = $8,
                access_token_encrypted = CASE
                    WHEN $9::text IS NULL OR $9::text = '' THEN access_token_encrypted
                    ELSE pgp_sym_encrypt($9, $10::text)
                END,
                access_token_hint = $11,
                business_phone_number = $12,
                display_phone_number = $13,
                metadata = $14::jsonb,
                updated_at = NOW()
            WHERE id = $1
            RETURNING *
        """
        row = await conn.fetchrow(
            query,
            connection_id,
            body.name if body.name is not None else existing.get("name"),
            project_id,
            bot_project_id,
            body.graph_version if body.graph_version is not None else existing.get("graph_version"),
            body.meta_business_account_id if body.meta_business_account_id is not None else existing.get("meta_business_account_id"),
            body.waba_id if body.waba_id is not None else existing.get("waba_id"),
            body.phone_number_id if body.phone_number_id is not None else existing.get("phone_number_id"),
            token_value,
            _credentials_secret(),
            token_hint,
            body.business_phone_number if body.business_phone_number is not None else existing.get("business_phone_number"),
            body.display_phone_number if body.display_phone_number is not None else existing.get("display_phone_number"),
            json.dumps(next_metadata or {}),
        )
        return WhatsAppConnection(**_normalize_connection_row(dict(row)))


@router.delete("/connections/{connection_id}", summary="Delete WhatsApp connection")
async def delete_whatsapp_connection(
    connection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        await _fetch_connection_row(conn, connection_id, user_id)
        await conn.execute("DELETE FROM whatsapp_connections WHERE id = $1", connection_id)
        return {"ok": True, "deleted_connection_id": str(connection_id)}


@router.post("/connections/{connection_id}/validate", summary="Validate WhatsApp connection")
async def validate_whatsapp_connection(
    connection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, connection_id, user_id)
        provider = get_whatsapp_provider(connection["provider"])

        try:
            validation = await provider.validate_connection(
                graph_version=connection["graph_version"],
                waba_id=connection["waba_id"],
                phone_number_id=connection["phone_number_id"],
                access_token=connection["access_token"],
            )
            phone_info = validation["phone_info"]
            waba_info = validation["waba_info"]
            subscription = await provider.ensure_waba_subscription(
                graph_version=connection["graph_version"],
                waba_id=connection["waba_id"],
                access_token=connection["access_token"],
            )
            await _upsert_phone_number_row(conn, connection_id, phone_info)
            await conn.execute(
                """
                UPDATE whatsapp_connections
                SET connection_status = 'active',
                    health_status = 'healthy',
                    subscribed_app_status = $5,
                    display_phone_number = COALESCE($2, display_phone_number),
                    last_validation_error = NULL,
                    metadata = COALESCE(metadata, '{}'::jsonb)
                        || jsonb_build_object(
                            'validated_phone', $3::jsonb,
                            'validated_waba', $4::jsonb,
                            'waba_subscription', $6::jsonb
                        ),
                    last_validated_at = NOW(),
                    updated_at = NOW()
                WHERE id = $1
                """,
                connection_id,
                phone_info.get("display_phone_number"),
                json.dumps(phone_info),
                json.dumps(waba_info),
                subscription.get("status") or "unknown",
                json.dumps(subscription),
            )
        except HTTPException as exc:
            await conn.execute(
                """
                UPDATE whatsapp_connections
                SET connection_status = 'error',
                    health_status = 'error',
                    last_validation_error = $2,
                    updated_at = NOW()
                WHERE id = $1
                """,
                connection_id,
                str(exc.detail),
            )
            raise

        updated = await _fetch_connection_row(conn, connection_id, user_id)
        return {
            "connection": WhatsAppConnection(**_normalize_connection_row(updated)),
            "validation": {
                "status": "active",
                "phone_info": phone_info,
                "waba_info": waba_info,
                "subscription": subscription,
            },
        }


@router.post("/connections/{connection_id}/sync", summary="Sync WhatsApp connection metadata")
async def sync_whatsapp_connection(
    connection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, connection_id, user_id)
        provider = get_whatsapp_provider(connection["provider"])

        try:
            phone_numbers = await provider.list_phone_numbers(
                graph_version=connection["graph_version"],
                waba_id=connection["waba_id"],
                access_token=connection["access_token"],
            )
        except HTTPException as exc:
            await conn.execute(
                """
                UPDATE whatsapp_connections
                SET health_status = 'error',
                    last_sync_status = 'error',
                    last_validation_error = $2,
                    updated_at = NOW()
                WHERE id = $1
                """,
                connection_id,
                str(exc.detail),
            )
            raise
        phone_data = None
        for item in phone_numbers.get("data") or []:
            await _upsert_phone_number_row(conn, connection_id, item)
            if str(item.get("id")) == str(connection["phone_number_id"]):
                phone_data = item
                break

        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET display_phone_number = COALESCE($2, display_phone_number),
                health_status = 'healthy',
                last_sync_status = 'success',
                metadata = COALESCE(metadata, '{}'::jsonb)
                    || jsonb_build_object('last_sync_payload', $3::jsonb),
                last_synced_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
            """,
            connection_id,
            (phone_data or {}).get("display_phone_number"),
            json.dumps(phone_numbers),
        )
        updated = await _fetch_connection_row(conn, connection_id, user_id)
        return {
            "connection": WhatsAppConnection(**_normalize_connection_row(updated)),
            "sync": {
                "phone_data": phone_data,
                "phone_numbers": phone_numbers.get("data") or [],
            },
        }


@router.post("/connections/{connection_id}/test-message", summary="Send WhatsApp test message")
async def send_whatsapp_test_message(
    connection_id: UUID,
    body: WhatsAppTestMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, connection_id, user_id)
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=connection_id,
            payload={
                "recipient_type": "individual",
                "to": body.to,
                "type": "text",
                "text": {
                    "preview_url": False,
                    "body": body.message,
                },
            },
            log_payload={"to": body.to, "message": body.message},
            message_type="text",
            to_number=body.to,
        )
        await conn.execute(
            """
            UPDATE whatsapp_connections
            SET health_status = 'healthy',
                last_tested_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
            """,
            connection_id,
        )
        return {
            "ok": True,
            "message": "Test message request sent to WhatsApp",
            "response": response,
        }


@router.post("/messages/text", summary="Send WhatsApp text message")
async def send_whatsapp_text_message(
    body: WhatsAppTextMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        payload = _build_text_payload(body)
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=body.connection_id,
            payload=payload,
            log_payload={"to": body.to, "text": body.text, "preview_url": body.preview_url},
            message_type="text",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp text message request sent",
            "response": response,
        }


@router.post("/messages/template", summary="Send WhatsApp template message")
async def send_whatsapp_template_message(
    body: WhatsAppTemplateMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        payload = _build_template_payload(body)
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=body.connection_id,
            payload=payload,
            log_payload={
                "to": body.to,
                "template_name": body.template_name,
                "language_code": body.language_code,
                "components": body.components,
            },
            message_type="template",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp template message request sent",
            "response": response,
        }


@router.post("/messages/media", summary="Send WhatsApp media message")
async def send_whatsapp_media_message(
    body: WhatsAppMediaMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        payload = _build_media_payload(body)
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=body.connection_id,
            payload=payload,
            log_payload={
                "to": body.to,
                "media_type": body.media_type,
                "media_id": body.media_id,
                "media_link": body.media_link,
                "caption": body.caption,
                "filename": body.filename,
            },
            message_type=body.media_type,
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp media message request sent",
            "response": response,
        }


@router.post("/messages/interactive", summary="Send WhatsApp interactive message")
async def send_whatsapp_interactive_message(
    body: WhatsAppInteractiveMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        payload = _build_interactive_payload(body)
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=body.connection_id,
            payload=payload,
            log_payload={"to": body.to, "interactive": body.interactive},
            message_type="interactive",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp interactive message request sent",
            "response": response,
        }


@router.post("/messages/flow", summary="Send WhatsApp flow message")
async def send_whatsapp_flow_message(
    body: WhatsAppFlowMessageRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        connection = await _fetch_connection_with_token(conn, body.connection_id, user_id)
        flow_token = body.flow_token or _issue_flow_runtime_token(
            connection_id=body.connection_id,
            saved_flow_id=None,
            meta_flow_id=body.flow_id,
            initial_screen=None,
        )
        payload = _build_flow_payload(body.model_copy(update={"flow_token": flow_token}))
        response = await _send_whatsapp_payload(
            conn,
            connection=connection,
            connection_id=body.connection_id,
            payload=payload,
            log_payload={
                "to": body.to,
                "flow_id": body.flow_id,
                "flow_cta": body.flow_cta,
                "flow_token": flow_token,
                "flow_action": body.flow_action,
                "flow_action_payload": body.flow_action_payload,
                "body_text": body.body_text,
                "header_text": body.header_text,
                "footer_text": body.footer_text,
            },
            message_type="flow",
            to_number=body.to,
        )
        return {
            "ok": True,
            "message": "WhatsApp flow message request sent",
            "response": response,
        }


@router.post(
    "/flows/{flow_id}/runtime-callback",
    response_class=PlainTextResponse,
    include_in_schema=False,
)
async def handle_whatsapp_flow_runtime_callback(
    flow_id: UUID,
    request: Request,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    raw_body = await request.body()
    try:
        payload = json.loads(raw_body.decode("utf-8") or "{}")
    except json.JSONDecodeError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid JSON body")

    signature_header = request.headers.get("x-hub-signature-256")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        flow_row = await _fetch_flow_runtime_row(conn, flow_id)
        event_row = await conn.fetchrow(
            """
            INSERT INTO whatsapp_webhook_events (
                connection_id,
                event_type,
                payload,
                headers,
                processed,
                created_at
            )
            VALUES ($1, 'flow_runtime_callback', $2::jsonb, $3::jsonb, FALSE, NOW())
            RETURNING id
            """,
            flow_row["connection_id"],
            json.dumps({**(payload or {}), "flow_id": str(flow_id)}),
            json.dumps(dict(request.headers)),
        )
        event_id = int(event_row["id"]) if event_row else None
        try:
            if not _verify_flow_runtime_signature(raw_body, signature_header):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid flow runtime signature")
            private_key_pem = await _decrypt_connection_flow_private_key(conn, flow_row["connection_id"])
            if not private_key_pem:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Flow runtime private key is not configured for this connection",
                )
            decrypted = _decrypt_flow_runtime_payload(payload, private_key_pem)
            decrypted_payload = decrypted["decrypted_payload"]
            response_payload = _build_dynamic_flow_runtime_response(flow_row, decrypted_payload)
            encrypted_response = _encrypt_flow_runtime_response(
                response_payload,
                decrypted["aes_key"],
                decrypted["initial_vector"],
            )
            if event_id is not None:
                await conn.execute(
                    """
                    UPDATE whatsapp_webhook_events
                    SET processed = TRUE,
                        payload = jsonb_set(
                            jsonb_set(
                                jsonb_set(payload, '{decrypted_payload}', $2::jsonb, true),
                                '{response_payload}',
                                $3::jsonb,
                                true
                            ),
                            '{encrypted_response_preview}',
                            to_jsonb($4::text),
                            true
                        )
                    WHERE id = $1
                    """,
                    event_id,
                    json.dumps(decrypted_payload or {}),
                    json.dumps(response_payload or {}),
                    encrypted_response[:128],
                )
            return PlainTextResponse(content=encrypted_response, media_type="text/plain")
        except HTTPException as exc:
            if event_id is not None:
                await conn.execute(
                    """
                    UPDATE whatsapp_webhook_events
                    SET payload = jsonb_set(payload, '{error_detail}', to_jsonb($2::text), true)
                    WHERE id = $1
                    """,
                    event_id,
                    str(exc.detail),
                )
            raise


@router.get("/webhook", response_class=PlainTextResponse, include_in_schema=False)
async def verify_whatsapp_webhook(
    hub_mode: Optional[str] = Query(None, alias="hub.mode"),
    hub_verify_token: Optional[str] = Query(None, alias="hub.verify_token"),
    hub_challenge: Optional[str] = Query(None, alias="hub.challenge"),
):
    expected_token = os.getenv("WHATSAPP_WEBHOOK_VERIFY_TOKEN")
    if hub_mode == "subscribe" and expected_token and hub_verify_token == expected_token:
        return hub_challenge or ""
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Webhook verification failed")


@router.post("/webhook", include_in_schema=False)
async def receive_whatsapp_webhook(
    request: Request,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    try:
        payload = await request.json()
    except Exception:
        payload = {}

    headers = {
        "x-hub-signature-256": request.headers.get("x-hub-signature-256"),
        "user-agent": request.headers.get("user-agent"),
    }
    phone_number_id = _extract_connection_phone_number_id(payload)
    event_type = _extract_event_type(payload)

    pool = await db.get_pool()
    event_row_id = None
    connection_id = None
    status_events: List[Dict[str, Any]] = []
    inbound_events: List[Dict[str, Any]] = []
    async with pool.acquire() as conn:
        await _ensure_whatsapp_schema(conn)
        if phone_number_id:
            connection_id = await conn.fetchval(
                """
                SELECT id
                FROM whatsapp_connections
                WHERE phone_number_id = $1
                """,
                phone_number_id,
            )
        event_row_id = await conn.fetchval(
            """
            INSERT INTO whatsapp_webhook_events (connection_id, event_type, payload, headers, processed, created_at)
            VALUES ($1, $2, $3::jsonb, $4::jsonb, FALSE, NOW())
            RETURNING id
            """,
            connection_id,
            event_type,
            json.dumps(payload or {}),
            json.dumps(headers),
        )
        if connection_id is not None:
            connection_row = await conn.fetchrow(
                """
                SELECT id, project_id, bot_project_id
                FROM whatsapp_connections
                WHERE id = $1
                """,
                connection_id,
            )
            await conn.execute(
                """
                UPDATE whatsapp_connections
                SET webhook_status = 'receiving',
                    health_status = 'healthy',
                    last_webhook_event_at = NOW(),
                    updated_at = NOW()
                WHERE id = $1
                """,
                connection_id,
            )

            entries = payload.get("entry") or []
            for entry in entries:
                for change in entry.get("changes") or []:
                    value = change.get("value") or {}
                    metadata = value.get("metadata") or {}
                    display_number = metadata.get("display_phone_number")
                    inbound_messages = value.get("messages") or []
                    statuses = value.get("statuses") or []

                    for message in inbound_messages:
                        inbound_events.append(
                            {
                                "message": message,
                                "value": value,
                                "display_number": display_number,
                            }
                        )

                    for status_item in statuses:
                        status_events.append(
                            {
                                "status_item": status_item,
                                "value": value,
                                "display_number": display_number,
                                "project_id": (connection_row["bot_project_id"] if connection_row else None) or (connection_row["project_id"] if connection_row else None),
                            }
                        )

    processing_failed = False
    for inbound_event in inbound_events:
        try:
            await _route_whatsapp_message_to_bot(
                pool,
                connection_id=connection_id,
                message=inbound_event["message"],
                value=inbound_event["value"],
                display_number=inbound_event["display_number"],
            )
        except Exception as exc:
            processing_failed = True
            logger.exception("Failed to process inbound WhatsApp message")
            sender_number = str(inbound_event["message"].get("from") or "").strip() or None
            message_type = str(inbound_event["message"].get("type") or "").strip() or "unknown"
            wa_message_id = str(inbound_event["message"].get("id") or "").strip() or None
            async with pool.acquire() as conn:
                await _log_whatsapp_message(
                    conn,
                    connection_id=connection_id,
                    direction="inbound",
                    payload=inbound_event["message"],
                    response=inbound_event["value"],
                    message_type=message_type,
                    status_text="error",
                    from_number=sender_number,
                    to_number=inbound_event["display_number"],
                    wa_message_id=wa_message_id,
                    error=str(exc),
                )

    if connection_id is not None:
        for status_event in status_events:
            status_item = status_event["status_item"]
            recipient_number = status_item.get("recipient_id")
            wa_message_id = status_item.get("id")
            async with pool.acquire() as conn:
                await _log_whatsapp_message(
                    conn,
                    connection_id=connection_id,
                    direction="status",
                    payload=status_item,
                    response=status_event["value"],
                    message_type=status_item.get("type"),
                    status_text=status_item.get("status"),
                    from_number=status_event["display_number"],
                    to_number=recipient_number,
                    wa_message_id=wa_message_id,
                    project_id=status_event["project_id"],
                )

    if event_row_id is not None:
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE whatsapp_webhook_events
                SET processed = $2
                WHERE id = $1
                """,
                event_row_id,
                not processing_failed,
            )

    return {"status": "received"}
