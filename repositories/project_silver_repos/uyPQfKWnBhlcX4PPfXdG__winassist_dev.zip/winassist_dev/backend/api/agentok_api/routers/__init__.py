"""
Router package exports.

This makes `from agentok_api.routers import auth, projects, ...`
work reliably in both local runs and inside Docker.
"""

from . import api_docs
from . import auth
from . import projects
from . import chats
from . import codegen
from . import tools
from . import attachments
from . import knowledge
from . import dashboard
from . import settings
from . import project_analytics
from . import project_governance
from . import workspaces
from . import templates
from . import connectors
from . import ocr
from . import whatsapp
from . import support_assistant

__all__ = [
    "api_docs",
    "auth",
    "projects",
    "chats",
    "codegen",
    "tools",
    "attachments",
    "knowledge",
    "dashboard",
    "settings",
    "project_analytics",
    "project_governance",
    "workspaces",
    "templates",
    "connectors",
    "ocr",
    "whatsapp",
    "support_assistant",
]

