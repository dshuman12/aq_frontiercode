from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..dependencies import get_current_user_or_bot
from ..services.document_ocr import extract_document_ocr


router = APIRouter()


class OcrExtractRequest(BaseModel):
    content_base64: str = Field(..., min_length=16)
    filename: Optional[str] = Field(default=None, max_length=255)
    mime_type: Optional[str] = Field(default=None, max_length=120)
    document_type: Literal["auto", "aadhaar", "pan", "driving_licence"] = "auto"


@router.post("/extract", summary="Extract document fields using OCR + regex")
async def extract_document(
    payload: OcrExtractRequest,
    _current_user: dict = Depends(get_current_user_or_bot),
):
    try:
        return extract_document_ocr(
            content_base64=payload.content_base64,
            filename=payload.filename,
            mime_type=payload.mime_type,
            document_type=payload.document_type,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to process document OCR: {exc}")
