from fastapi import APIRouter, Depends
from typing import Any, Dict

from ..services.database import DatabaseClient
from ..dependencies import get_database_client

router = APIRouter()


@router.get("/tools", summary="Get user tool settings")
async def get_tool_settings(db: DatabaseClient = Depends(get_database_client)) -> Dict[str, Any]:
    """Return the current user's tool settings (JSON object keyed by tool id)."""
    return await db.fetch_tool_settings()


@router.post("/tools", summary="Update user tool settings")
async def update_tool_settings(
    settings: Dict[str, Any],
    db: DatabaseClient = Depends(get_database_client),
) -> Dict[str, Any]:
    """Upsert the current user's tool settings. Body is a JSON object keyed by tool id."""
    return await db.update_tool_settings(settings)
