from fastapi import APIRouter, Depends, File, UploadFile, HTTPException, Form
from fastapi import status
from typing import Dict, Any, Optional
import os
import re
from pathlib import Path
from datetime import datetime
from uuid import uuid4

from ..dependencies import get_database_client, get_current_user
from ..services.database import DatabaseClient
from ..utils.datetime import now_ist


router = APIRouter()


API_DIR = Path(__file__).resolve().parents[2]
ATTACHMENTS_ROOT = Path(
    os.environ.get("TOOL_ATTACHMENTS_ROOT", str(API_DIR / "attachments"))
).resolve()


def _safe_join(*parts: str) -> str:
    path = Path(os.path.join(*parts))
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _sanitize_filename(filename: Optional[str]) -> str:
    raw_name = (filename or "attachment").strip()
    path_name = Path(raw_name)
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", path_name.stem).strip("._-") or "attachment"
    suffix = re.sub(r"[^A-Za-z0-9.]+", "", path_name.suffix or "")
    return f"{stem}{suffix}"


@router.post("/attachments", summary="Upload attachment for tool execution")
async def upload_tool_attachment(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    db: DatabaseClient = Depends(get_database_client),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    user_id = str(current_user["id"])

    # Allow common doc types; tool will decide how to process
    allowed_types = {
        "application/pdf",
        "text/plain",
        "text/markdown",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # .docx
        "application/msword",  # legacy .doc
        "text/html",
        "text/csv",
        "application/vnd.ms-excel",  # .xls
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  # .xlsx
        "application/vnd.ms-powerpoint",  # .ppt
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",  # .pptx
    }
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported content type: {file.content_type}",
        )

    now = now_ist()
    y = now.strftime("%Y")
    m = now.strftime("%m")
    original_name = file.filename or "attachment"
    safe_name = _sanitize_filename(original_name)
    stem = Path(safe_name).stem or "attachment"
    suffix = Path(safe_name).suffix
    stored_name = f"{stem}_{now.strftime('%Y%m%d%H%M%S')}_{uuid4().hex[:8]}{suffix}"
    rel_path = os.path.join("tools", user_id, y, m, stored_name)
    abs_path = _safe_join(str(ATTACHMENTS_ROOT), rel_path)

    data = await file.read()
    try:
        with open(abs_path, "wb") as f:
            f.write(data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save attachment: {str(e)}")

    return {
        "path": abs_path,
        "relative_path": rel_path,
        "filename": original_name,
        "stored_filename": stored_name,
        "mime": file.content_type,
        "size": len(data),
        "title": title or original_name,
    }




