from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from fastapi.responses import Response
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta
from uuid import UUID
import logging
import os
import json

from ..services.database import DatabaseClient
from ..dependencies import (
    get_database_client,
    get_database_client_no_auth,
    get_database_client_flexible,
    get_current_user,
    get_current_user_or_bot,
    get_current_user_or_bot_optional,
)
from ..utils.datetime import now_ist_naive, serialize_datetime_for_api, today_ist

logger = logging.getLogger(__name__)
router = APIRouter()

# Workspace roles allowed to view project analytics (read-only). Viewers can see analytics but not edit projects.
ANALYTICS_WORKSPACE_ROLES = ("owner", "admin", "member", "viewer")


# --- Workspace & role behavior ---
# - Personal context (no workspace_id): user sees only their own projects (user_id = current user).
# - Workspace context (workspace_id provided): user must be a member of the workspace (any role).
#   Workspace overview and project list are scoped to that workspace.
# - Single project access: user must be project owner (personal project) or have a workspace role
#   in ANALYTICS_WORKSPACE_ROLES (owner, admin, member, viewer) for the project's workspace.
# - All project-analytics endpoints that take project_id use the same rule: project owner or
#   workspace member with role in ANALYTICS_WORKSPACE_ROLES.


def _backend_base_url(request: Optional[Request] = None) -> str:
    """Base URL for backend (for script/widget URLs). Prefer BACKEND_URL env; else derive from request (supports X-Forwarded-* behind nginx)."""
    base = (os.getenv("BACKEND_URL") or "").strip()
    if base:
        return base.rstrip("/")
    if request:
        # Behind nginx/reverse proxy, use forwarded host and scheme so script URLs work in the browser
        forwarded_proto = request.headers.get("x-forwarded-proto") or request.url.scheme
        forwarded_host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
        return f"{forwarded_proto}://{forwarded_host}".rstrip("/")
    return "http://localhost:9000"


def _widget_script_base_url(request: Optional[Request] = None) -> str:
    """Base URL for widget script and /static/widgets/ (must include port if not 80/443).
    Prefer WIDGET_SCRIPT_BASE_URL so script loads from the same origin as the app (e.g. :3001);
    else BACKEND_URL; else derived from request."""
    base = (os.getenv("WIDGET_SCRIPT_BASE_URL") or "").strip()
    if base:
        return base.rstrip("/")
    return _backend_base_url(request)


class ProjectStats(BaseModel):
    total_projects: int
    backend_projects: int
    frontend_projects: int


class MessageStats(BaseModel):
    total_user_messages: int
    total_bot_messages: int
    total_messages: int


class LanguageStats(BaseModel):
    language: str
    count: int
    percentage: float


class ProjectAnalytics(BaseModel):
    project_id: UUID
    project_name: str
    project_type: Optional[str] = None  # 'frontend' | 'backend' for display in list and dropdown
    total_user_messages: int
    total_bot_messages: int
    total_messages: int
    total_chats: int
    language_stats: List[LanguageStats]


class AnalyticsResponse(BaseModel):
    project_stats: ProjectStats
    message_stats: MessageStats
    projects: List[ProjectAnalytics]
    language_stats: List[LanguageStats]
    date_range: Optional[Dict[str, str]] = None


class WidgetConfig(BaseModel):
    project_id: UUID
    api_key: str
    widget_url: str
    embed_code: str


class SaveWidgetScriptRequest(BaseModel):
    script_content: str
    # Optional: base path for static folder (e.g. /var/www/myapp/frontend). If provided (e.g. from frontend env VITE_WIDGET_STATIC_BASE_PATH), widget is saved under {static_base_path}/static/widgets/.
    static_base_path: Optional[str] = None


class SaveWidgetScriptResponse(BaseModel):
    script_url: str
    filename: str


class PublicWidgetScriptUrlResponse(BaseModel):
    script_url: str


class PublicWidgetViewerConfigResponse(BaseModel):
    """Config for the shareable widget viewer page."""
    script_url: str
    project_id: str
    api_key: str
    backend_url: str


class StepEventCreate(BaseModel):
    project_id: UUID
    session_id: str
    node_id: str
    node_label: Optional[str] = None


class FlowMessageCreate(BaseModel):
    project_id: UUID
    session_id: str
    role: str  # 'user' | 'assistant'
    content: str
    node_id: Optional[str] = None
    node_label: Optional[str] = None


class QuickReplyChoiceCreate(BaseModel):
    project_id: UUID
    session_id: str
    node_id: str
    node_label: Optional[str] = None
    option_index: int
    option_text: str
    variable_key: Optional[str] = None  # optional key to store for use in body (e.g. "plan_type" -> {{context.plan_type}})


class QuickReplyOptionCount(BaseModel):
    option_index: int
    option_text: str
    count: int


class QuickReplyNodeStats(BaseModel):
    node_id: str
    node_label: Optional[str] = None
    options: List[QuickReplyOptionCount]
    total_choices: int


class QuickReplyStatsResponse(BaseModel):
    project_id: UUID
    project_name: str
    nodes: List[QuickReplyNodeStats]


class SessionQuickReplyValue(BaseModel):
    option_index: int
    option_text: str


class SessionVariablesResponse(BaseModel):
    """Stored quick reply and other session variables for use in API body (e.g. {{context.quickReplySelections.node_id.option_text}})."""
    project_id: UUID
    session_id: str
    variables: Dict[str, str]  # var_key -> var_value (e.g. node_id -> option_text, or custom variable_key -> option_text)
    quick_reply_by_node: Dict[str, SessionQuickReplyValue]  # node_id -> { option_index, option_text } (latest per node)


class FunnelStepResponse(BaseModel):
    node_id: str
    node_label: Optional[str] = None
    step_order: int
    reached_count: int
    drop_off_pct: Optional[float] = None


class FunnelResponse(BaseModel):
    project_id: UUID
    project_name: str
    steps: List[FunnelStepResponse]
    total_sessions: int
    completion_count: int
    completion_rate_pct: float


class TimelineDayResponse(BaseModel):
    date: str
    sessions: int


class TimelineResponse(BaseModel):
    project_id: UUID
    project_name: str
    days: List[TimelineDayResponse]


class EngagementDayResponse(BaseModel):
    date: str
    avg_messages_per_session: float
    avg_session_duration_seconds: float


class EngagementTimelineResponse(BaseModel):
    project_id: UUID
    project_name: str
    days: List[EngagementDayResponse]


class MessagesTimelineDayResponse(BaseModel):
    date: str
    user_messages: int
    bot_messages: int


class MessagesTimelineResponse(BaseModel):
    project_id: UUID
    project_name: str
    days: List[MessagesTimelineDayResponse]
    node_id: Optional[str] = None
    node_label: Optional[str] = None


class NodeOptionResponse(BaseModel):
    node_id: str
    node_label: Optional[str] = None


class ProjectNodesResponse(BaseModel):
    project_id: UUID
    nodes: List[NodeOptionResponse]


class MostAskedItem(BaseModel):
    content: str
    count: int


class MostAskedResponse(BaseModel):
    project_id: UUID
    project_name: str
    items: List[MostAskedItem]


class FlowMessageStatsResponse(BaseModel):
    project_id: UUID
    project_name: str
    total_user_messages: int
    total_assistant_messages: int
    empty_assistant_count: int
    total_sessions_with_messages: int


# --- Advanced analytics models ---

class SessionAnalyticsResponse(BaseModel):
    project_id: UUID
    project_name: str
    total_sessions: int
    avg_messages_per_session: float
    avg_steps_per_session: float
    avg_session_duration_seconds: Optional[float] = None
    sessions_with_no_user_response: int
    bounce_sessions: int


class BounceRateResponse(BaseModel):
    project_id: UUID
    project_name: str
    first_step_sessions: int
    second_step_sessions: int
    bounce_rate_pct: float


class NodePerformanceStep(BaseModel):
    node_id: str
    node_label: Optional[str] = None
    step_order: int
    times_reached: int
    unique_sessions: int
    next_step_reached: Optional[int] = None
    drop_off_pct: Optional[float] = None


class NodePerformanceResponse(BaseModel):
    project_id: UUID
    project_name: str
    nodes: List[NodePerformanceStep]


class FlowPathItem(BaseModel):
    path: str
    path_labels: List[str]
    session_count: int


class FlowPathsResponse(BaseModel):
    project_id: UUID
    project_name: str
    paths: List[FlowPathItem]


class CompletionAnalyticsResponse(BaseModel):
    project_id: UUID
    project_name: str
    completion_node_id: Optional[str] = None
    completion_node_label: Optional[str] = None
    completion_count: int
    total_sessions: int
    completion_rate_pct: float


class AbandonmentStep(BaseModel):
    node_id: str
    node_label: Optional[str] = None
    step_order: int
    reached: int
    continued: int
    exited: int
    abandonment_rate_pct: float


class AbandonmentResponse(BaseModel):
    project_id: UUID
    project_name: str
    steps: List[AbandonmentStep]


class BotResponseTimeResponse(BaseModel):
    project_id: UUID
    project_name: str
    avg_response_time_ms: Optional[float] = None
    max_response_time_ms: Optional[float] = None
    sample_count: int


class ActivityHeatmapResponse(BaseModel):
    project_id: UUID
    project_name: str
    by_hour: List[Dict[str, Any]]
    by_weekday: List[Dict[str, Any]]


class ConversionAnalyticsResponse(BaseModel):
    project_id: UUID
    project_name: str
    conversion_node_id: Optional[str] = None
    conversion_node_label: Optional[str] = None
    conversion_count: int
    total_sessions: int
    conversion_rate_pct: float


class UserInputInsightsResponse(BaseModel):
    project_id: UUID
    project_name: str
    top_queries: List[Dict[str, Any]]
    trend_by_date: List[Dict[str, Any]]


class ReturningVsNewResponse(BaseModel):
    project_id: UUID
    project_name: str
    new_sessions: int
    returning_sessions: int
    returning_pct: float


class DeviceDistributionItem(BaseModel):
    name: str
    count: int
    percentage: float


class DeviceAnalyticsResponse(BaseModel):
    project_id: UUID
    project_name: str
    device_type: List[DeviceDistributionItem]
    browser: List[DeviceDistributionItem]
    os: List[DeviceDistributionItem]


class TrafficSourceItem(BaseModel):
    source: str
    chats: int


class TrafficSourceResponse(BaseModel):
    project_id: UUID
    project_name: str
    by_page: List[TrafficSourceItem]
    by_referrer: List[TrafficSourceItem]


class ApiPerformanceSummary(BaseModel):
    api_name: str
    total_calls: int
    successful_calls: int
    failed_calls: int
    success_rate_pct: float
    avg_response_time_ms: Optional[float] = None


class ApiPerformanceResponse(BaseModel):
    project_id: UUID
    project_name: str
    total_api_calls: int
    apis: List[ApiPerformanceSummary]


class AnalyticsAlertItem(BaseModel):
    alert_type: str
    message: str
    severity: str
    value: Optional[float] = None
    threshold: Optional[float] = None


class AnalyticsAlertsResponse(BaseModel):
    project_id: UUID
    project_name: str
    alerts: List[AnalyticsAlertItem]


class SessionMetadataCreate(BaseModel):
    project_id: UUID
    session_id: str
    device_type: Optional[str] = None
    browser: Optional[str] = None
    os: Optional[str] = None
    page_url: Optional[str] = None
    referrer: Optional[str] = None


class ApiPerformanceCreate(BaseModel):
    project_id: UUID
    session_id: str
    node_id: Optional[str] = None
    api_name: str
    response_status: Optional[int] = None
    response_time_ms: Optional[int] = None


class SessionReplayEvent(BaseModel):
    type: str  # 'step' | 'message' | 'quick_reply'
    created_at: str
    node_id: Optional[str] = None
    node_label: Optional[str] = None
    role: Optional[str] = None
    content: Optional[str] = None
    option_index: Optional[int] = None
    option_text: Optional[str] = None


class SessionReplayResponse(BaseModel):
    project_id: UUID
    project_name: str
    session_id: str
    events: List[SessionReplayEvent]


@router.get('/all-projects', summary="Get all projects (frontend + backend) for dropdown")
async def get_all_projects(
    workspace_id: Optional[str] = Query(None, description="Filter by workspace ID"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Return both frontend and backend projects for the project selector. Each item has id, name, project_type.
    If workspace_id is set: caller must be a workspace member (any role); returns only projects in that workspace.
    If not set: returns only the caller's personal projects (user_id = current user)."""
    try:
        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            user_id = current_user["id"]
            if isinstance(user_id, str):
                user_id = UUID(user_id)
            if workspace_id:
                try:
                    ws_uuid = UUID(workspace_id)
                except ValueError:
                    raise HTTPException(status_code=400, detail="Invalid workspace ID")
                membership = await conn.fetchrow("SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2", ws_uuid, user_id)
                if not membership:
                    raise HTTPException(status_code=403, detail="Not a member of this workspace")
                rows = await conn.fetch(
                    "SELECT id, name, project_type FROM projects WHERE workspace_id = $1 ORDER BY name",
                    ws_uuid,
                )
            else:
                rows = await conn.fetch(
                    "SELECT id, name, project_type FROM projects WHERE user_id = $1 ORDER BY name",
                    user_id,
                )
            return [{"id": str(r["id"]), "name": r["name"] or "Unnamed", "project_type": r["project_type"] or "backend"} for r in rows]
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get all projects error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get('/frontend-projects', summary="Get all frontend projects for user")
async def get_frontend_projects(
    workspace_id: Optional[str] = Query(None, description="Filter by workspace ID; when set, only projects in this workspace are returned"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get all frontend projects for the current user.
    If workspace_id is provided, only projects in that workspace are returned (user must be a member).
    Used for project selector dropdown.
    """
    try:
        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            user_id = current_user["id"]
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid user ID format"
                    )

            if workspace_id:
                try:
                    ws_uuid = UUID(workspace_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid workspace ID format"
                    )
                membership = await conn.fetchrow(
                    "SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2",
                    ws_uuid,
                    user_id,
                )
                if not membership:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not a member of this workspace",
                    )
                projects = await conn.fetch(
                    """
                    SELECT id, name, description, created_at, updated_at
                    FROM projects
                    WHERE workspace_id = $1 AND project_type = 'frontend'
                    ORDER BY updated_at DESC
                    """,
                    ws_uuid,
                )
            else:
                projects = await conn.fetch(
                    """
                    SELECT id, name, description, created_at, updated_at
                    FROM projects
                    WHERE user_id = $1 AND project_type = 'frontend'
                    ORDER BY updated_at DESC
                    """,
                    user_id
                )

            return [
                {
                    "id": str(row["id"]),
                    "name": row["name"],
                    "description": row["description"],
                    "created_at": serialize_datetime_for_api(row["created_at"]),
                    "updated_at": serialize_datetime_for_api(row["updated_at"]),
                }
                for row in projects
            ]
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get frontend projects error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get frontend projects: {str(e)}"
        )


@router.get('/stats', response_model=AnalyticsResponse, summary="Get project analytics")
async def get_project_analytics(
    project_id: Optional[str] = Query(None, description="Filter by specific project ID (frontend or backend)"),
    workspace_id: Optional[str] = Query(None, description="Filter by workspace ID; when no project_id, stats and project list are limited to this workspace"),
    start_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    period: Optional[str] = Query(None, description="Period: 'weekly', 'monthly', or 'custom'"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get comprehensive project analytics including:
    - Total projects (backend and frontend)
    - Message statistics (user and bot messages)
    - Per-project analytics
    - Language selection analytics
    - Date range filtering (weekly, monthly, custom)
    
    If project_id is provided, returns analytics for that project (frontend or backend). Caller must be project owner or workspace member with role in ANALYTICS_WORKSPACE_ROLES.
    """
    try:
        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            user_id = current_user["id"]
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid user ID format"
                    )

            # Validate and parse project_id if provided, and authorize access
            selected_project_id = None
            selected_project = None
            if project_id:
                try:
                    selected_project_id = UUID(project_id)
                    # Verify project exists and that the current user is either:
                    # - the project owner for personal projects (workspace_id IS NULL), or
                    # - an owner/admin/member of the workspace the project belongs to.
                    selected_project = await conn.fetchrow(
                        """
                        SELECT
                            p.id,
                            p.name,
                            p.project_type,
                            p.flow,
                            p.user_id,
                            p.workspace_id,
                            wm.role AS member_role
                        FROM projects p
                        LEFT JOIN workspace_members wm
                          ON p.workspace_id = wm.workspace_id
                         AND wm.user_id = $2
                        WHERE p.id = $1
                        """,
                        selected_project_id,
                        user_id,
                    )
                    if not selected_project:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail="Project not found",
                        )
                    # Authorization: personal projects only owner, workspace projects owner/admin/member
                    if selected_project["workspace_id"] is None:
                        if selected_project["user_id"] != user_id:
                            raise HTTPException(
                                status_code=status.HTTP_403_FORBIDDEN,
                                detail="Not authorized to view analytics for this project",
                            )
                    else:
                        if selected_project["member_role"] not in ANALYTICS_WORKSPACE_ROLES:
                            raise HTTPException(
                                status_code=status.HTTP_403_FORBIDDEN,
                                detail="Not authorized to view analytics for this project",
                            )
                    # Both frontend and backend projects are allowed; detailed analytics (funnel, etc.) require frontend
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid project ID format",
                    )

            # Optional workspace filter (when no specific project selected)
            workspace_uuid = None
            if workspace_id and not selected_project_id:
                try:
                    workspace_uuid = UUID(workspace_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid workspace ID format"
                    )
                membership = await conn.fetchrow(
                    "SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2",
                    workspace_uuid,
                    user_id,
                )
                if not membership:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not a member of this workspace",
                    )

            # Determine date range
            date_filter = False
            date_params = []
            date_range = None
            
            if period == "weekly":
                end_date_obj = now_ist_naive()
                start_date_obj = end_date_obj - timedelta(days=7)
                date_filter = True
                date_params = [start_date_obj, end_date_obj]
                date_range = {
                    "start": start_date_obj.strftime("%Y-%m-%d"),
                    "end": end_date_obj.strftime("%Y-%m-%d")
                }
            elif period == "monthly":
                end_date_obj = now_ist_naive()
                start_date_obj = end_date_obj - timedelta(days=30)
                date_filter = True
                date_params = [start_date_obj, end_date_obj]
                date_range = {
                    "start": start_date_obj.strftime("%Y-%m-%d"),
                    "end": end_date_obj.strftime("%Y-%m-%d")
                }
            elif period == "custom" and start_date and end_date:
                try:
                    start_date_obj = datetime.strptime(start_date, "%Y-%m-%d")
                    end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")
                    date_filter = True
                    date_params = [start_date_obj, end_date_obj]
                    date_range = {
                        "start": start_date,
                        "end": end_date
                    }
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid date format. Use YYYY-MM-DD"
                    )

            # Get project counts (only if not filtering by specific project)
            if selected_project_id:
                is_backend = selected_project.get("project_type") == "backend"
                project_stats = ProjectStats(
                    total_projects=1,
                    backend_projects=1 if is_backend else 0,
                    frontend_projects=0 if is_backend else 1,
                )
                if is_backend:
                    # Backend project: use chat_messages and chats (count all users for project-level analytics)
                    if date_filter:
                        user_cnt = await conn.fetchval(
                            "SELECT COUNT(*) FROM chat_messages WHERE project_id = $1 AND type = 'user' AND created_at >= $2 AND created_at <= $3",
                            selected_project_id, date_params[0], date_params[1],
                        ) or 0
                        bot_cnt = await conn.fetchval(
                            "SELECT COUNT(*) FROM chat_messages WHERE project_id = $1 AND type IN ('assistant','bot','agent') AND created_at >= $2 AND created_at <= $3",
                            selected_project_id, date_params[0], date_params[1],
                        ) or 0
                        chats_cnt = await conn.fetchval(
                            "SELECT COUNT(DISTINCT id) FROM chats WHERE from_project = $1 AND created_at >= $2 AND created_at <= $3",
                            selected_project_id, date_params[0], date_params[1],
                        ) or 0
                    else:
                        user_cnt = await conn.fetchval(
                            "SELECT COUNT(*) FROM chat_messages WHERE project_id = $1 AND type = 'user'",
                            selected_project_id,
                        ) or 0
                        bot_cnt = await conn.fetchval(
                            "SELECT COUNT(*) FROM chat_messages WHERE project_id = $1 AND type IN ('assistant','bot','agent')",
                            selected_project_id,
                        ) or 0
                        chats_cnt = await conn.fetchval(
                            "SELECT COUNT(DISTINCT id) FROM chats WHERE from_project = $1",
                            selected_project_id,
                        ) or 0
                    message_stats = MessageStats(total_user_messages=user_cnt, total_bot_messages=bot_cnt, total_messages=user_cnt + bot_cnt)
                    lang_rows = await conn.fetch(
                        """SELECT COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language, COUNT(*) as count
                           FROM chat_messages m WHERE m.project_id = $1 AND m.type = 'user'
                           AND m.meta IS NOT NULL AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                           GROUP BY language ORDER BY count DESC""",
                        selected_project_id,
                    )
                    total_lang = sum(r["count"] for r in lang_rows) or 1
                    language_stats = [LanguageStats(language=r["language"], count=r["count"], percentage=round(r["count"] / total_lang * 100, 2)) for r in lang_rows]
                    overall_lang = language_stats
                    projects = [ProjectAnalytics(
                        project_id=selected_project_id,
                        project_name=selected_project["name"] or "Project",
                        project_type="backend",
                        total_user_messages=user_cnt,
                        total_bot_messages=bot_cnt,
                        total_messages=user_cnt + bot_cnt,
                        total_chats=chats_cnt,
                        language_stats=language_stats,
                    )]
                    date_range = None
                    if date_filter:
                        date_range = {"start": date_params[0].strftime("%Y-%m-%d"), "end": date_params[1].strftime("%Y-%m-%d")}
                    return AnalyticsResponse(
                        project_stats=project_stats,
                        message_stats=message_stats,
                        projects=projects,
                        language_stats=overall_lang,
                        date_range=date_range,
                    )
            else:
                if workspace_uuid:
                    # All projects in the workspace (user is already verified as member)
                    backend_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM projects WHERE workspace_id = $1 AND project_type = 'backend'",
                        workspace_uuid,
                    ) or 0
                    frontend_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM projects WHERE workspace_id = $1 AND project_type = 'frontend'",
                        workspace_uuid,
                    ) or 0
                else:
                    backend_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM projects WHERE user_id = $1 AND project_type = 'backend'",
                        user_id
                    ) or 0
                    frontend_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM projects WHERE user_id = $1 AND project_type = 'frontend'",
                        user_id
                    ) or 0

                total_projects = backend_count + frontend_count

                project_stats = ProjectStats(
                    total_projects=total_projects,
                    backend_projects=backend_count,
                    frontend_projects=frontend_count
                )

            # Get message statistics
            # For frontend projects: use flow_messages (widget); bot = messages from node type text/assistant, fallback role=assistant
            if selected_project_id:
                # Resolve bot messages by node type (text/assistant); parse flow if string; include role=assistant so count is never wrong
                flow = selected_project.get("flow") if selected_project else None
                if isinstance(flow, str):
                    try:
                        flow = json.loads(flow) if (flow or "").strip() else {}
                    except (ValueError, TypeError):
                        flow = {}
                nodes_list = (flow.get("nodes") or []) if isinstance(flow, dict) else []
                assistant_text_node_ids = [
                    n["id"] for n in nodes_list
                    if n.get("id") and (
                        n.get("type") in ("text", "assistant")
                        or (n.get("data") or {}).get("type") in ("text", "assistant")
                    )
                ]
                if date_filter:
                    user_messages_query = """
                        SELECT COUNT(*) FROM flow_messages
                        WHERE project_id = $3 AND role = 'user'
                        AND created_at >= $1 AND created_at <= $2
                    """
                    if assistant_text_node_ids:
                        bot_messages_query = """
                            SELECT COUNT(*) FROM flow_messages
                            WHERE project_id = $3 AND (node_id = ANY($4::text[]) OR role = 'assistant')
                            AND created_at >= $1 AND created_at <= $2
                        """
                        user_msg_params = date_params + [selected_project_id]
                        bot_msg_params = date_params + [selected_project_id, assistant_text_node_ids]
                    else:
                        bot_messages_query = """
                            SELECT COUNT(*) FROM flow_messages
                            WHERE project_id = $3 AND role = 'assistant'
                            AND created_at >= $1 AND created_at <= $2
                        """
                        user_msg_params = date_params + [selected_project_id]
                        bot_msg_params = date_params + [selected_project_id]
                else:
                    user_messages_query = """
                        SELECT COUNT(*) FROM flow_messages
                        WHERE project_id = $1 AND role = 'user'
                    """
                    if assistant_text_node_ids:
                        bot_messages_query = """
                            SELECT COUNT(*) FROM flow_messages
                            WHERE project_id = $1 AND (node_id = ANY($2::text[]) OR role = 'assistant')
                        """
                        user_msg_params = [selected_project_id]
                        bot_msg_params = [selected_project_id, assistant_text_node_ids]
                    else:
                        bot_messages_query = """
                            SELECT COUNT(*) FROM flow_messages
                            WHERE project_id = $1 AND role = 'assistant'
                        """
                        user_msg_params = [selected_project_id]
                        bot_msg_params = [selected_project_id]
                query_params = user_msg_params  # for any later use; fetches use their own params
            else:
                # Original logic for all projects (optionally scoped by workspace)
                ws_subquery = " AND workspace_id = $4" if workspace_uuid else ""
                ws_subquery_nd = " AND workspace_id = $2" if workspace_uuid else ""
                if date_filter:
                    # With date filter: params are [start_date, end_date, user_id] or + workspace_uuid
                    user_messages_query = """
                        SELECT COUNT(*) FROM chat_messages m
                        WHERE m.user_id = $3 
                        AND m.type = 'user'
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $3 AND project_type = 'backend'""" + ws_subquery + """)
                        AND m.created_at >= $1 AND m.created_at <= $2
                    """
                    bot_messages_query = """
                        SELECT COUNT(*) FROM chat_messages m
                        WHERE m.user_id = $3
                        AND m.type IN ('assistant', 'bot', 'agent')
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $3 AND project_type = 'backend'""" + ws_subquery + """)
                        AND m.created_at >= $1 AND m.created_at <= $2
                    """
                    query_params = date_params + [user_id]
                    if workspace_uuid:
                        query_params.append(workspace_uuid)
                else:
                    user_messages_query = """
                        SELECT COUNT(*) FROM chat_messages m
                        WHERE m.user_id = $1 
                        AND m.type = 'user'
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $1 AND project_type = 'backend'""" + ws_subquery_nd + """)
                    """
                    bot_messages_query = """
                        SELECT COUNT(*) FROM chat_messages m
                        WHERE m.user_id = $1
                        AND m.type IN ('assistant', 'bot', 'agent')
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $1 AND project_type = 'backend'""" + ws_subquery_nd + """)
                    """
                    query_params = [user_id]
                    if workspace_uuid:
                        query_params.append(workspace_uuid)

                user_msg_params = query_params
                bot_msg_params = query_params

            total_user_messages = await conn.fetchval(
                user_messages_query,
                *user_msg_params
            ) or 0
            total_bot_messages = await conn.fetchval(
                bot_messages_query,
                *bot_msg_params
            ) or 0
            total_messages = total_user_messages + total_bot_messages

            message_stats = MessageStats(
                total_user_messages=total_user_messages,
                total_bot_messages=total_bot_messages,
                total_messages=total_messages
            )

            # Get per-project analytics
            # If filtering by specific frontend project, return analytics for that project only
            if selected_project_id:
                # Single frontend project: get message counts from flow_messages; bot = node type text/assistant only
                if date_filter:
                    if assistant_text_node_ids:
                        project_analytics_query = """
                        SELECT 
                            $3::uuid as project_id,
                            $4::text as project_name,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND role = 'user' AND created_at >= $1 AND created_at <= $2) as user_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND (node_id = ANY($5::text[]) OR role = 'assistant') AND created_at >= $1 AND created_at <= $2) as bot_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND created_at >= $1 AND created_at <= $2) as total_messages,
                            (SELECT COUNT(DISTINCT session_id) FROM flow_step_events WHERE project_id = $3 AND created_at >= $1 AND created_at <= $2) as total_chats
                    """
                        query_params = date_params + [selected_project_id, selected_project['name'], assistant_text_node_ids]
                    else:
                        project_analytics_query = """
                        SELECT 
                            $3::uuid as project_id,
                            $4::text as project_name,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND role = 'user' AND created_at >= $1 AND created_at <= $2) as user_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND role = 'assistant' AND created_at >= $1 AND created_at <= $2) as bot_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $3 AND created_at >= $1 AND created_at <= $2) as total_messages,
                            (SELECT COUNT(DISTINCT session_id) FROM flow_step_events WHERE project_id = $3 AND created_at >= $1 AND created_at <= $2) as total_chats
                    """
                        query_params = date_params + [selected_project_id, selected_project['name']]
                else:
                    if assistant_text_node_ids:
                        project_analytics_query = """
                        SELECT 
                            $1::uuid as project_id,
                            $2::text as project_name,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1 AND role = 'user') as user_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1 AND (node_id = ANY($3::text[]) OR role = 'assistant')) as bot_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1) as total_messages,
                            (SELECT COUNT(DISTINCT session_id) FROM flow_step_events WHERE project_id = $1) as total_chats
                    """
                        query_params = [selected_project_id, selected_project['name'], assistant_text_node_ids]
                    else:
                        project_analytics_query = """
                        SELECT 
                            $1::uuid as project_id,
                            $2::text as project_name,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1 AND role = 'user') as user_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1 AND role = 'assistant') as bot_messages,
                            (SELECT COUNT(*) FROM flow_messages WHERE project_id = $1) as total_messages,
                            (SELECT COUNT(DISTINCT session_id) FROM flow_step_events WHERE project_id = $1) as total_chats
                    """
                        query_params = [selected_project_id, selected_project['name']]
                # Execute single-project analytics and set project_rows so the loop below runs
                row = await conn.fetchrow(project_analytics_query, *query_params)
                project_rows = []
                if row:
                    project_rows = [{
                        "project_id": row["project_id"],
                        "project_name": row["project_name"],
                        "project_type": "frontend",
                        "user_messages": row["user_messages"] or 0,
                        "bot_messages": row["bot_messages"] or 0,
                        "total_messages": row["total_messages"] or 0,
                        "total_chats": row["total_chats"] or 0,
                    }]
            else:
                # All projects (backend + frontend) for workspace or user
                project_rows = []
                # Backend projects: chats + chat_messages
                if workspace_uuid:
                    if date_filter:
                        backend_rows = await conn.fetch(
                            """
                            SELECT 
                                p.id as project_id,
                                p.name as project_name,
                                COUNT(DISTINCT CASE WHEN m.type = 'user' THEN m.id END)::int as user_messages,
                                COUNT(DISTINCT CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN m.id END)::int as bot_messages,
                                COUNT(DISTINCT m.id)::int as total_messages,
                                COUNT(DISTINCT c.id)::int as total_chats
                            FROM projects p
                            LEFT JOIN chats c ON c.from_project = p.id AND c.created_at >= $2 AND c.created_at <= $3
                            LEFT JOIN chat_messages m ON m.project_id = p.id AND m.created_at >= $2 AND m.created_at <= $3
                            WHERE p.project_type = 'backend' AND p.workspace_id = $1
                            GROUP BY p.id, p.name
                            """,
                            workspace_uuid,
                            date_params[0],
                            date_params[1],
                        )
                    else:
                        backend_rows = await conn.fetch(
                            """
                            SELECT 
                                p.id as project_id,
                                p.name as project_name,
                                COUNT(DISTINCT CASE WHEN m.type = 'user' THEN m.id END)::int as user_messages,
                                COUNT(DISTINCT CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN m.id END)::int as bot_messages,
                                COUNT(DISTINCT m.id)::int as total_messages,
                                COUNT(DISTINCT c.id)::int as total_chats
                            FROM projects p
                            LEFT JOIN chats c ON c.from_project = p.id
                            LEFT JOIN chat_messages m ON m.project_id = p.id
                            WHERE p.project_type = 'backend' AND p.workspace_id = $1
                            GROUP BY p.id, p.name
                            """,
                            workspace_uuid,
                        )
                else:
                    if date_filter:
                        backend_rows = await conn.fetch(
                            """
                            SELECT 
                                p.id as project_id,
                                p.name as project_name,
                                COUNT(DISTINCT CASE WHEN m.type = 'user' THEN m.id END)::int as user_messages,
                                COUNT(DISTINCT CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN m.id END)::int as bot_messages,
                                COUNT(DISTINCT m.id)::int as total_messages,
                                COUNT(DISTINCT c.id)::int as total_chats
                            FROM projects p
                            LEFT JOIN chats c ON c.from_project = p.id AND c.created_at >= $2 AND c.created_at <= $3
                            LEFT JOIN chat_messages m ON m.project_id = p.id AND m.created_at >= $2 AND m.created_at <= $3
                            WHERE p.project_type = 'backend' AND p.user_id = $1
                            GROUP BY p.id, p.name
                            """,
                            user_id,
                            date_params[0],
                            date_params[1],
                        )
                    else:
                        backend_rows = await conn.fetch(
                            """
                            SELECT 
                                p.id as project_id,
                                p.name as project_name,
                                COUNT(DISTINCT CASE WHEN m.type = 'user' THEN m.id END)::int as user_messages,
                                COUNT(DISTINCT CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN m.id END)::int as bot_messages,
                                COUNT(DISTINCT m.id)::int as total_messages,
                                COUNT(DISTINCT c.id)::int as total_chats
                            FROM projects p
                            LEFT JOIN chats c ON c.from_project = p.id
                            LEFT JOIN chat_messages m ON m.project_id = p.id
                            WHERE p.project_type = 'backend' AND p.user_id = $1
                            GROUP BY p.id, p.name
                            """,
                            user_id,
                        )
                for r in backend_rows:
                    project_rows.append({
                        "project_id": r["project_id"],
                        "project_name": r["project_name"],
                        "project_type": "backend",
                        "user_messages": r["user_messages"] or 0,
                        "bot_messages": r["bot_messages"] or 0,
                        "total_messages": r["total_messages"] or 0,
                        "total_chats": r["total_chats"] or 0,
                    })

                # Frontend projects: flow_messages + flow_step_events
                if workspace_uuid:
                    if date_filter:
                        frontend_rows = await conn.fetch(
                            """
                            SELECT p.id as project_id, p.name as project_name,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'user' AND created_at >= $2 AND created_at <= $3) as user_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'assistant' AND created_at >= $2 AND created_at <= $3) as bot_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND created_at >= $2 AND created_at <= $3) as total_messages,
                                (SELECT COUNT(DISTINCT session_id)::int FROM flow_step_events WHERE project_id = p.id AND created_at >= $2 AND created_at <= $3) as total_chats
                            FROM projects p
                            WHERE p.project_type = 'frontend' AND p.workspace_id = $1
                            """,
                            workspace_uuid,
                            date_params[0],
                            date_params[1],
                        )
                    else:
                        frontend_rows = await conn.fetch(
                            """
                            SELECT p.id as project_id, p.name as project_name,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'user') as user_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'assistant') as bot_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id) as total_messages,
                                (SELECT COUNT(DISTINCT session_id)::int FROM flow_step_events WHERE project_id = p.id) as total_chats
                            FROM projects p
                            WHERE p.project_type = 'frontend' AND p.workspace_id = $1
                            """,
                            workspace_uuid,
                        )
                else:
                    if date_filter:
                        frontend_rows = await conn.fetch(
                            """
                            SELECT p.id as project_id, p.name as project_name,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'user' AND created_at >= $2 AND created_at <= $3) as user_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'assistant' AND created_at >= $2 AND created_at <= $3) as bot_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND created_at >= $2 AND created_at <= $3) as total_messages,
                                (SELECT COUNT(DISTINCT session_id)::int FROM flow_step_events WHERE project_id = p.id AND created_at >= $2 AND created_at <= $3) as total_chats
                            FROM projects p
                            WHERE p.project_type = 'frontend' AND p.user_id = $1
                            """,
                            user_id,
                            date_params[0],
                            date_params[1],
                        )
                    else:
                        frontend_rows = await conn.fetch(
                            """
                            SELECT p.id as project_id, p.name as project_name,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'user') as user_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id AND role = 'assistant') as bot_messages,
                                (SELECT COUNT(*)::int FROM flow_messages WHERE project_id = p.id) as total_messages,
                                (SELECT COUNT(DISTINCT session_id)::int FROM flow_step_events WHERE project_id = p.id) as total_chats
                            FROM projects p
                            WHERE p.project_type = 'frontend' AND p.user_id = $1
                            """,
                            user_id,
                        )
                for r in frontend_rows:
                    project_rows.append({
                        "project_id": r["project_id"],
                        "project_name": r["project_name"],
                        "project_type": "frontend",
                        "user_messages": r["user_messages"] or 0,
                        "bot_messages": r["bot_messages"] or 0,
                        "total_messages": r["total_messages"] or 0,
                        "total_chats": r["total_chats"] or 0,
                    })
                project_rows.sort(key=lambda r: (-(r["total_messages"] or 0), (r["project_name"] or "")))

            projects = []
            for row in project_rows:
                # Get language stats for this project
                if selected_project_id:
                    # For frontend project, find messages from chats
                    if date_filter:
                        lang_query = """
                            SELECT 
                                COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                                COUNT(*) as count
                            FROM chat_messages m
                            INNER JOIN chats c ON m.chat_id = c.id
                            WHERE c.from_project::uuid = $1
                            AND c.user_id = $2
                            AND m.type = 'user'
                            AND m.meta IS NOT NULL
                            AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                            AND m.created_at >= $3 AND m.created_at <= $4
                            GROUP BY language
                            ORDER BY count DESC
                        """
                        lang_params = [selected_project_id, user_id] + date_params
                    else:
                        lang_query = """
                            SELECT 
                                COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                                COUNT(*) as count
                            FROM chat_messages m
                            INNER JOIN chats c ON m.chat_id = c.id
                            WHERE c.from_project::uuid = $1
                            AND c.user_id = $2
                            AND m.type = 'user'
                            AND m.meta IS NOT NULL
                            AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                            GROUP BY language
                            ORDER BY count DESC
                        """
                        lang_params = [selected_project_id, user_id]
                    lang_rows = await conn.fetch(lang_query, *lang_params)
                else:
                    # Backend projects only have chat_messages language meta; frontend skip
                    if row.get('project_type') == 'frontend':
                        lang_rows = []
                    elif date_filter:
                        lang_query = """
                            SELECT 
                                COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                                COUNT(*) as count
                            FROM chat_messages m
                            WHERE m.project_id::uuid = $1
                            AND m.user_id = $2
                            AND m.type = 'user'
                            AND m.meta IS NOT NULL
                            AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                            AND m.created_at >= $3 AND m.created_at <= $4
                            GROUP BY language
                            ORDER BY count DESC
                        """
                        lang_params = [row['project_id'], user_id] + date_params
                        lang_rows = await conn.fetch(lang_query, *lang_params)
                    else:
                        lang_query = """
                            SELECT 
                                COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                                COUNT(*) as count
                            FROM chat_messages m
                            WHERE m.project_id::uuid = $1
                            AND m.user_id = $2
                            AND m.type = 'user'
                            AND m.meta IS NOT NULL
                            AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                            GROUP BY language
                            ORDER BY count DESC
                        """
                        lang_params = [row['project_id'], user_id]
                        lang_rows = await conn.fetch(lang_query, *lang_params)

                total_lang_messages = sum(r['count'] for r in lang_rows) or 1
                
                language_stats = []
                for lang_row in lang_rows:
                    percentage = (lang_row['count'] / total_lang_messages * 100) if total_lang_messages > 0 else 0
                    language_stats.append(LanguageStats(
                        language=lang_row['language'],
                        count=lang_row['count'],
                        percentage=round(percentage, 2)
                    ))

                projects.append(ProjectAnalytics(
                    project_id=row['project_id'],
                    project_name=row['project_name'],
                    project_type=row.get('project_type') or ('frontend' if selected_project_id else None),
                    total_user_messages=row.get('user_messages', 0) or 0,
                    total_bot_messages=row.get('bot_messages', 0) or 0,
                    total_messages=row.get('total_messages', 0) or 0,
                    total_chats=row.get('total_chats', 0) or 0,
                    language_stats=language_stats
                ))

            # Get overall language stats
            if selected_project_id:
                # For frontend project, find messages from chats
                if date_filter:
                    overall_lang_query = """
                        SELECT 
                            COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                            COUNT(*) as count
                        FROM chat_messages m
                        INNER JOIN chats c ON m.chat_id = c.id
                        WHERE c.from_project::uuid = $3
                        AND c.user_id = $4
                        AND m.type = 'user'
                        AND m.meta IS NOT NULL
                        AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                        AND m.created_at >= $1 AND m.created_at <= $2
                        GROUP BY language
                        ORDER BY count DESC
                    """
                    overall_lang_params = date_params + [selected_project_id, user_id]
                else:
                    overall_lang_query = """
                        SELECT 
                            COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                            COUNT(*) as count
                        FROM chat_messages m
                        INNER JOIN chats c ON m.chat_id = c.id
                        WHERE c.from_project::uuid = $1
                        AND c.user_id = $2
                        AND m.type = 'user'
                        AND m.meta IS NOT NULL
                        AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                        GROUP BY language
                        ORDER BY count DESC
                    """
                    overall_lang_params = [selected_project_id, user_id]
            else:
                # Original logic for all backend projects
                if date_filter:
                    overall_lang_query = """
                        SELECT 
                            COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                            COUNT(*) as count
                        FROM chat_messages m
                        WHERE m.user_id = $3
                        AND m.type = 'user'
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $3 AND project_type = 'backend')
                        AND m.meta IS NOT NULL
                        AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                        AND m.created_at >= $1 AND m.created_at <= $2
                        GROUP BY language
                        ORDER BY count DESC
                    """
                    overall_lang_params = date_params + [user_id]
                else:
                    overall_lang_query = """
                        SELECT 
                            COALESCE(m.meta->>'language', m.meta->>'selected_language', 'Unknown') as language,
                            COUNT(*) as count
                        FROM chat_messages m
                        WHERE m.user_id = $1
                        AND m.type = 'user'
                        AND m.project_id IN (SELECT id FROM projects WHERE user_id = $1 AND project_type = 'backend')
                        AND m.meta IS NOT NULL
                        AND (m.meta ? 'language' OR m.meta ? 'selected_language')
                        GROUP BY language
                        ORDER BY count DESC
                    """
                    overall_lang_params = [user_id]

            overall_lang_rows = await conn.fetch(overall_lang_query, *overall_lang_params)
            total_lang_messages = sum(r['count'] for r in overall_lang_rows) or 1
            
            overall_language_stats = []
            for lang_row in overall_lang_rows:
                percentage = (lang_row['count'] / total_lang_messages * 100) if total_lang_messages > 0 else 0
                overall_language_stats.append(LanguageStats(
                    language=lang_row['language'],
                    count=lang_row['count'],
                    percentage=round(percentage, 2)
                ))

            return AnalyticsResponse(
                project_stats=project_stats,
                message_stats=message_stats,
                projects=projects,
                language_stats=overall_language_stats,
                date_range=date_range
            )

        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get project analytics error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get project analytics: {str(e)}"
        )


@router.post(
    "/step-event",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Record flow step reached (widget)",
)
async def record_step_event(
    body: StepEventCreate,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """
    Record that a session reached a flow step. Called by the widget.
    In production widgets this uses X-Bot-API-Key for auth; in builder preview
    it can be called anonymously (no auth), in which case we only validate that
    the project exists.
    """
    sid = (body.session_id or "").strip()
    nid = (body.node_id or "").strip()
    if not sid or not nid:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="session_id and node_id are required",
        )
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id FROM projects WHERE id = $1",
            body.project_id,
        )
        if not proj:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found",
            )
        # Some deployments may still have an old unique index on
        # (project_id, session_id, node_id). In that case, repeated step
        # reports can raise a duplicate-key DB error and appear as a CORS
        # failure in the browser. Treat duplicate events as success.
        # We keep the behavior unchanged for all other DB errors.
        try:
            await conn.execute(
                """
                INSERT INTO flow_step_events (project_id, session_id, node_id, node_label)
                VALUES ($1, $2, $3, $4)
                """,
                body.project_id,
                sid,
                nid,
                (body.node_label or "").strip() or None,
            )
        except Exception as e:
            msg = str(e).lower()
            if "duplicate key value violates unique constraint" not in msg:
                raise
    return None


@router.post(
    "/flow-message",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Record flow message (widget)",
)
async def record_flow_message(
    body: FlowMessageCreate,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """
    Record a user or assistant message from a frontend (widget) flow for analytics.
    In production widgets this uses X-Bot-API-Key for auth; in builder preview it
    can be called anonymously (no auth), in which case we only validate that the
    project exists.
    """
    sid = (body.session_id or "").strip()
    if not sid:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="session_id is required",
        )
    role = (body.role or "").strip().lower()
    if role not in ("user", "assistant"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="role must be 'user' or 'assistant'",
        )
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id FROM projects WHERE id = $1",
            body.project_id,
        )
        if not proj:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found",
            )
        content = (body.content or "").strip()
        await conn.execute(
            """
            INSERT INTO flow_messages (project_id, session_id, role, content, node_id, node_label)
            VALUES ($1, $2, $3, $4, $5, $6)
            """,
            body.project_id,
            sid,
            role,
            content[:65535] if content else "",  # cap length
            (body.node_id or "").strip() or None,
            (body.node_label or "").strip() or None,
        )
    return None


@router.post(
    "/quick-reply-choice",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Record quick reply option chosen (widget)",
)
async def record_quick_reply_choice(
    body: QuickReplyChoiceCreate,
    # Allow widgets to record quick replies even when X-Bot-API-Key is missing/empty
    # (public viewer mode). If authenticated, we still support bot/JWT auth.
    current_user: dict = Depends(get_current_user_or_bot_optional),
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """Record which quick reply option the user chose. Called by the widget."""
    sid = (body.session_id or "").strip()
    nid = (body.node_id or "").strip() or "unknown"
    if not sid:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="session_id is required",
        )
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, user_id FROM projects WHERE id = $1",
            body.project_id,
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        if user_id and str(proj["user_id"]) != str(user_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Project not found")
        option_text = (body.option_text or "").strip()[:2048]
        await conn.execute(
            """
            INSERT INTO quick_reply_choices (project_id, session_id, node_id, node_label, option_index, option_text)
            VALUES ($1, $2, $3, $4, $5, $6)
            """,
            body.project_id,
            sid,
            nid,
            (body.node_label or "").strip() or None,
            body.option_index,
            option_text or "",
        )
        # Store for use later in flow (e.g. pass in API body via {{context.quickReplySelections.node_id.option_text}})
        try:
            await conn.execute(
                """
                INSERT INTO session_variables (project_id, session_id, var_key, var_value, updated_at)
                VALUES ($1, $2, $3, $4, NOW())
                ON CONFLICT (project_id, session_id, var_key) DO UPDATE SET var_value = EXCLUDED.var_value, updated_at = NOW()
                """,
                body.project_id,
                sid,
                nid,
                option_text or "",
            )
            var_key = (body.variable_key or "").strip() or None
            if var_key:
                await conn.execute(
                    """
                    INSERT INTO session_variables (project_id, session_id, var_key, var_value, updated_at)
                    VALUES ($1, $2, $3, $4, NOW())
                    ON CONFLICT (project_id, session_id, var_key) DO UPDATE SET var_value = EXCLUDED.var_value, updated_at = NOW()
                    """,
                    body.project_id,
                    sid,
                    var_key,
                    option_text or "",
                )
        except Exception as e:
            if "session_variables" not in str(e).lower() and "does not exist" not in str(e).lower():
                raise
            # Table may not exist yet (migration 009 not run); skip
            pass
    return None


@router.get(
    "/session-variables",
    response_model=SessionVariablesResponse,
    summary="Get stored session variables (quick reply and custom) for use in API body",
)
async def get_session_variables(
    project_id: str = Query(..., description="Project ID (frontend)"),
    session_id: str = Query(..., description="Session ID from widget"),
    # Widgets can load anonymously in the public viewer (X-Bot-API-Key may be missing/empty).
    # If authenticated, we keep the extra safety check that the project belongs to the user/bot.
    current_user: dict = Depends(get_current_user_or_bot_optional),
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """Returns variables and latest quick reply per node for this session so the flow can pass them in request body (e.g. {{context.quickReplySelections.node_id.option_text}})."""
    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="session_id required")
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id") if isinstance(current_user, dict) else None
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            user_id = None
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow("SELECT id, user_id FROM projects WHERE id = $1", project_id_uuid)
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        if user_id and str(proj["user_id"]) != str(user_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Project not found")
        variables: Dict[str, str] = {}
        quick_reply_by_node: Dict[str, Dict[str, Any]] = {}
        try:
            var_rows = await conn.fetch(
                "SELECT var_key, var_value FROM session_variables WHERE project_id = $1 AND session_id = $2",
                project_id_uuid,
                sid,
            )
            for r in var_rows:
                variables[r["var_key"]] = r["var_value"] or ""
        except Exception:
            pass
        qr_rows = await conn.fetch(
            """
            SELECT DISTINCT ON (node_id) node_id, option_index, option_text
            FROM quick_reply_choices
            WHERE project_id = $1 AND session_id = $2
            ORDER BY node_id, created_at DESC
            """,
            project_id_uuid,
            sid,
        )
        for r in qr_rows:
            quick_reply_by_node[r["node_id"]] = SessionQuickReplyValue(
                option_index=r["option_index"],
                option_text=r["option_text"] or "",
            )
        return SessionVariablesResponse(
            project_id=project_id_uuid,
            session_id=sid,
            variables=variables,
            quick_reply_by_node=quick_reply_by_node,
        )


@router.get(
    "/quick-reply-stats",
    response_model=QuickReplyStatsResponse,
    summary="Get quick reply option counts per node",
)
async def get_quick_reply_stats(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Per quick reply node: how many users chose each option."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
            date_filter = ""
            params: List[Any] = [project_id_uuid]
            if start_date and end_date:
                try:
                    datetime.strptime(start_date, "%Y-%m-%d")
                    datetime.strptime(end_date, "%Y-%m-%d")
                    date_filter = " AND created_at::date >= $2 AND created_at::date <= $3"
                    params.extend([start_date, end_date])
                except ValueError:
                    pass
            rows = await conn.fetch(
                """
                SELECT node_id, node_label, option_index, option_text, COUNT(*) AS cnt
                FROM quick_reply_choices
                WHERE project_id = $1
                """ + date_filter + """
                GROUP BY node_id, node_label, option_index, option_text
                ORDER BY node_id, option_index
                """,
                *params,
            )
            by_node: Dict[str, Dict[str, Any]] = {}
            for r in rows:
                nid = r["node_id"]
                if nid not in by_node:
                    by_node[nid] = {"node_id": nid, "node_label": r["node_label"], "options": [], "total_choices": 0}
                by_node[nid]["options"].append(
                    {"option_index": r["option_index"], "option_text": r["option_text"] or "", "count": r["cnt"]}
                )
                by_node[nid]["total_choices"] += r["cnt"]
            nodes_list = [
                QuickReplyNodeStats(
                    node_id=v["node_id"],
                    node_label=v["node_label"],
                    options=[QuickReplyOptionCount(**o) for o in v["options"]],
                    total_choices=v["total_choices"],
                )
                for v in by_node.values()
            ]
            return QuickReplyStatsResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                nodes=nodes_list,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Quick reply stats error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/funnel", response_model=FunnelResponse, summary="Get step funnel for a project")
async def get_funnel(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Step-wise funnel: how many sessions reached each step, completion rate, drop-off.
    Uses project flow nodes for step order; flow_step_events for counts.
    """
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
            flow = proj.get("flow") or {}
            if isinstance(flow, str):
                try:
                    flow = json.loads(flow) if flow.strip() else {}
                except (ValueError, TypeError):
                    flow = {}
            nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
            if not nodes:
                return FunnelResponse(
                    project_id=project_id_uuid,
                    project_name=proj["name"] or "Project",
                    steps=[],
                    total_sessions=0,
                    completion_count=0,
                    completion_rate_pct=0.0,
                )
            date_filter = ""
            params: List[Any] = [project_id_uuid]
            if start_date and end_date:
                try:
                    datetime.strptime(start_date, "%Y-%m-%d")
                    datetime.strptime(end_date, "%Y-%m-%d")
                    date_filter = " AND created_at >= $2 AND created_at <= $3"
                    params.extend([start_date, end_date])
                except ValueError:
                    pass
            order_by_step: List[Dict[str, Any]] = []
            for i, n in enumerate(nodes):
                node_id = n.get("id") or n.get("data", {}).get("id")
                if not node_id:
                    continue
                data = n.get("data") or {}
                if data.get("trackAsStep") is False:
                    continue
                label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or n.get("text") or data.get("text") or n.get("type") or node_id
                order_by_step.append({"node_id": node_id, "node_label": label, "step_order": len(order_by_step) + 1})
            if not order_by_step:
                return FunnelResponse(
                    project_id=project_id_uuid,
                    project_name=proj["name"] or "Project",
                    steps=[],
                    total_sessions=0,
                    completion_count=0,
                    completion_rate_pct=0.0,
                )
            node_ids = [s["node_id"] for s in order_by_step]
            steps_with_counts: List[FunnelStepResponse] = []
            prev_count: Optional[int] = None
            for s in order_by_step:
                if date_filter:
                    q = """
                        SELECT COUNT(*) AS c FROM flow_step_events
                        WHERE project_id = $1 AND node_id = $4 AND created_at >= $2 AND created_at <= $3
                    """
                    p = params + [s["node_id"]]
                else:
                    q = """
                        SELECT COUNT(*) AS c FROM flow_step_events
                        WHERE project_id = $1 AND node_id = $2
                    """
                    p = [project_id_uuid, s["node_id"]]
                row = await conn.fetchrow(q, *p)
                count = row["c"] if row else 0
                drop_off = None
                if prev_count is not None and prev_count > 0 and count < prev_count:
                    drop_off = round((1 - count / prev_count) * 100, 1)
                steps_with_counts.append(FunnelStepResponse(
                    node_id=s["node_id"],
                    node_label=s["node_label"],
                    step_order=s["step_order"],
                    reached_count=count,
                    drop_off_pct=drop_off,
                ))
                prev_count = count
            # total_sessions = distinct sessions that reached first step (for "Opened bot" header)
            first_node_id = order_by_step[0]["node_id"] if order_by_step else None
            if date_filter and first_node_id:
                sess_row = await conn.fetchrow(
                    """
                    SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                    WHERE project_id = $1 AND node_id = $4 AND created_at >= $2 AND created_at <= $3
                    """,
                    *params,
                    first_node_id,
                )
            elif first_node_id:
                sess_row = await conn.fetchrow(
                    "SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events WHERE project_id = $1 AND node_id = $2",
                    project_id_uuid,
                    first_node_id,
                )
            else:
                sess_row = None
            total_sessions = sess_row["c"] if sess_row else (steps_with_counts[0].reached_count if steps_with_counts else 0)
            completion_count = steps_with_counts[-1].reached_count if steps_with_counts else 0
            # completion_rate_pct = % of sessions that reached last step (distinct sessions)
            last_node_id = order_by_step[-1]["node_id"] if order_by_step else None
            if date_filter and last_node_id and total_sessions:
                last_sess_row = await conn.fetchrow(
                    """
                    SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                    WHERE project_id = $1 AND node_id = $4 AND created_at >= $2 AND created_at <= $3
                    """,
                    *params,
                    last_node_id,
                )
            elif last_node_id and total_sessions:
                last_sess_row = await conn.fetchrow(
                    "SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events WHERE project_id = $1 AND node_id = $2",
                    project_id_uuid,
                    last_node_id,
                )
            else:
                last_sess_row = None
            sessions_reached_last = last_sess_row["c"] if last_sess_row else 0
            completion_rate_pct = round((sessions_reached_last / total_sessions * 100), 1) if total_sessions else 0.0
            return FunnelResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                steps=steps_with_counts,
                total_sessions=total_sessions,
                completion_count=completion_count,
                completion_rate_pct=completion_rate_pct,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Funnel error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/timeline", response_model=TimelineResponse, summary="Get daily session count for a project")
async def get_timeline(
    project_id: str = Query(..., description="Project ID"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Daily count of unique sessions (for timeline chart)."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
            end_d = today_ist()
            start_d = end_d - timedelta(days=30)
            if start_date:
                try:
                    start_d = datetime.strptime(start_date, "%Y-%m-%d").date()
                except ValueError:
                    pass
            if end_date:
                try:
                    end_d = datetime.strptime(end_date, "%Y-%m-%d").date()
                except ValueError:
                    pass
            rows = await conn.fetch(
                """
                SELECT DATE(created_at) AS d, COUNT(DISTINCT session_id) AS sessions
                FROM flow_step_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY DATE(created_at)
                ORDER BY d
                """,
                project_id_uuid,
                start_d,
                end_d,
            )
            days = [TimelineDayResponse(date=row["d"].strftime("%Y-%m-%d"), sessions=row["sessions"]) for row in rows]
            return TimelineResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                days=days,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Timeline error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get(
    "/engagement-timeline",
    response_model=EngagementTimelineResponse,
    summary="Get per-day engagement metrics (avg messages & duration) for a project",
)
async def get_engagement_timeline(
    project_id: str = Query(..., description="Project ID"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Per-day engagement metrics for a chatflow project:
    - avg_messages_per_session
    - avg_session_duration_seconds
    """
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")

    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")

    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                """
                SELECT id, name, project_type FROM projects
                WHERE id = $1
                  AND (
                    user_id = $2
                    OR workspace_id IN (
                        SELECT workspace_id FROM workspace_members
                        WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')
                    )
                  )
                """,
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

            # Backend projects have no flow_step_events/flow_messages; return empty timeline
            if (proj.get("project_type") or "backend") == "backend":
                return EngagementTimelineResponse(
                    project_id=project_id_uuid,
                    project_name=proj["name"] or "Project",
                    days=[],
                )

            end_d = today_ist()
            start_d = end_d - timedelta(days=30)
            if start_date:
                try:
                    start_d = datetime.strptime(start_date, "%Y-%m-%d").date()
                except ValueError:
                    pass
            if end_date:
                try:
                    end_d = datetime.strptime(end_date, "%Y-%m-%d").date()
                except ValueError:
                    pass

            # Compute per-session spans (for duration) and bucket by first event date
            session_spans = await conn.fetch(
                """
                SELECT
                    session_id,
                    MIN(created_at) AS first_at,
                    MAX(created_at) AS last_at
                FROM flow_step_events
                WHERE project_id = $1
                  AND created_at >= $2
                  AND created_at <= $3
                GROUP BY session_id
                """,
                project_id_uuid,
                start_d,
                end_d,
            )
            per_day_sessions: Dict[str, Dict[str, float]] = {}
            for row in session_spans:
                first_at = row["first_at"]
                last_at = row["last_at"]
                if not first_at or not last_at:
                    continue
                key = first_at.date().strftime("%Y-%m-%d")
                duration = (last_at - first_at).total_seconds()
                entry = per_day_sessions.setdefault(
                    key, {"sessions": 0.0, "total_duration": 0.0}
                )
                entry["sessions"] += 1.0
                entry["total_duration"] += max(duration, 0.0)

            # Messages per day (all roles) for this project
            msg_rows = await conn.fetch(
                """
                SELECT DATE(created_at) AS d, COUNT(*) AS total_messages
                FROM flow_messages
                WHERE project_id = $1
                  AND created_at >= $2
                  AND created_at <= $3
                GROUP BY DATE(created_at)
                ORDER BY d
                """,
                project_id_uuid,
                start_d,
                end_d,
            )
            messages_per_day: Dict[str, int] = {}
            for row in msg_rows:
                key = row["d"].strftime("%Y-%m-%d")
                messages_per_day[key] = row["total_messages"] or 0

            days: List[EngagementDayResponse] = []
            for date_str, sess in sorted(per_day_sessions.items(), key=lambda kv: kv[0]):
                sessions = sess["sessions"] or 0.0
                total_duration = sess["total_duration"] or 0.0
                total_messages = messages_per_day.get(date_str, 0)
                avg_msgs = (total_messages / sessions) if sessions > 0 else 0.0
                avg_dur = (total_duration / sessions) if sessions > 0 else 0.0
                days.append(
                    EngagementDayResponse(
                        date=date_str,
                        avg_messages_per_session=round(avg_msgs, 2),
                        avg_session_duration_seconds=avg_dur,
                    )
                )

            return EngagementTimelineResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                days=days,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Engagement timeline error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get(
    "/messages-timeline",
    response_model=MessagesTimelineResponse,
    summary="Get per-day user and bot message counts (optionally by node)",
)
async def get_messages_timeline(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    node_id: Optional[str] = Query(None, description="Filter by node_id; omit for all nodes"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Per-day counts of user and bot (assistant) messages from flow_messages.
    When node_id is set, only messages that occurred at that node are counted.
    """
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                """
                SELECT id, name, project_type FROM projects
                WHERE id = $1
                  AND (user_id = $2 OR workspace_id IN (
                    SELECT workspace_id FROM workspace_members
                    WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')
                  ))
                """,
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

            # Backend projects have no flow_messages; return empty timeline
            if (proj.get("project_type") or "backend") == "backend":
                return MessagesTimelineResponse(
                    project_id=project_id_uuid,
                    project_name=proj["name"] or "Project",
                    days=[],
                    node_id=node_id,
                    node_label=None,
                )

            end_d = today_ist()
            start_d = end_d - timedelta(days=30)
            if start_date:
                try:
                    start_d = datetime.strptime(start_date, "%Y-%m-%d").date()
                except ValueError:
                    pass
            if end_date:
                try:
                    end_d = datetime.strptime(end_date, "%Y-%m-%d").date()
                except ValueError:
                    pass

            node_filter = " AND node_id = $4" if node_id else ""
            params: List[Any] = [project_id_uuid, start_d, end_d]
            if node_id:
                params.append(node_id)

            # User messages per day
            user_rows = await conn.fetch(
                """
                SELECT DATE(created_at) AS d, COUNT(*) AS cnt
                FROM flow_messages
                WHERE project_id = $1 AND role = 'user'
                  AND created_at >= $2 AND created_at <= $3
                """ + node_filter + """
                GROUP BY DATE(created_at)
                ORDER BY d
                """,
                *params,
            )
            # Bot/assistant messages per day (role = 'assistant' or from assistant-like nodes)
            bot_rows = await conn.fetch(
                """
                SELECT DATE(created_at) AS d, COUNT(*) AS cnt
                FROM flow_messages
                WHERE project_id = $1 AND role = 'assistant'
                  AND created_at >= $2 AND created_at <= $3
                """ + node_filter + """
                GROUP BY DATE(created_at)
                ORDER BY d
                """,
                *params,
            )

            by_date: Dict[str, Dict[str, int]] = {}
            for row in user_rows:
                key = row["d"].strftime("%Y-%m-%d")
                by_date.setdefault(key, {"user_messages": 0, "bot_messages": 0})
                by_date[key]["user_messages"] = row["cnt"] or 0
            for row in bot_rows:
                key = row["d"].strftime("%Y-%m-%d")
                by_date.setdefault(key, {"user_messages": 0, "bot_messages": 0})
                by_date[key]["bot_messages"] = row["cnt"] or 0

            days_list: List[MessagesTimelineDayResponse] = []
            for date_str in sorted(by_date.keys()):
                d = by_date[date_str]
                days_list.append(
                    MessagesTimelineDayResponse(
                        date=date_str,
                        user_messages=d.get("user_messages", 0),
                        bot_messages=d.get("bot_messages", 0),
                    )
                )

            node_label: Optional[str] = None
            if node_id:
                label_row = await conn.fetchrow(
                    """
                    SELECT node_label FROM flow_messages
                    WHERE project_id = $1 AND node_id = $2 AND node_label IS NOT NULL AND node_label != ''
                    LIMIT 1
                    """,
                    project_id_uuid,
                    node_id,
                )
                node_label = label_row["node_label"] if label_row else node_id

            return MessagesTimelineResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                days=days_list,
                node_id=node_id,
                node_label=node_label,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Messages timeline error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get(
    "/nodes",
    response_model=ProjectNodesResponse,
    summary="Get list of nodes (for message timeline filter) for a project",
)
async def get_project_nodes(
    project_id: str = Query(..., description="Project ID (frontend or backend)"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Distinct node_id / node_label from flow_messages and flow_step_events for dropdown filter. Backend projects return empty nodes."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                """
                SELECT id, name, project_type FROM projects
                WHERE id = $1
                  AND (user_id = $2 OR workspace_id IN (
                    SELECT workspace_id FROM workspace_members
                    WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')
                  ))
                """,
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

            # Backend projects have no flow_messages/flow_step_events; return empty node list
            if (proj.get("project_type") or "backend") == "backend":
                return ProjectNodesResponse(project_id=project_id_uuid, nodes=[])

            rows = await conn.fetch(
                """
                SELECT node_id, MAX(node_label) AS node_label
                FROM (
                    SELECT node_id, node_label FROM flow_messages WHERE project_id = $1 AND node_id IS NOT NULL AND TRIM(node_id) != ''
                    UNION ALL
                    SELECT node_id, node_label FROM flow_step_events WHERE project_id = $2 AND node_id IS NOT NULL AND TRIM(node_id) != ''
                    UNION ALL
                    SELECT node_id, COALESCE(NULLIF(TRIM(node_label), ''), node_id) FROM quick_reply_choices WHERE project_id = $3 AND node_id IS NOT NULL AND TRIM(node_id) != ''
                ) u
                GROUP BY node_id
                ORDER BY node_id
                """,
                project_id_uuid,
                project_id_uuid,
                project_id_uuid,
            )
            nodes_list = [
                NodeOptionResponse(
                    node_id=(row["node_id"] or "").strip(),
                    node_label=(row["node_label"] or row["node_id"] or "").strip() or None,
                )
                for row in rows
                if (row["node_id"] or "").strip()
            ]

            return ProjectNodesResponse(project_id=project_id_uuid, nodes=nodes_list)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project nodes error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


def _parse_project_and_dates(
    project_id: str,
    user_id: UUID,
    start_date: Optional[str],
    end_date: Optional[str],
):
    """Validate project_id and optional start_date/end_date. Returns (project_id_uuid, start_d, end_d) for date range."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    end_d = today_ist()
    start_d = end_d - timedelta(days=30)
    if start_date:
        try:
            start_d = datetime.strptime(start_date, "%Y-%m-%d").date()
        except ValueError:
            pass
    if end_date:
        try:
            end_d = datetime.strptime(end_date, "%Y-%m-%d").date()
        except ValueError:
            pass
    return project_id_uuid, start_d, end_d


@router.get("/session-analytics", response_model=SessionAnalyticsResponse, summary="Session-level metrics")
async def get_session_analytics(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Total sessions, avg messages/steps/duration, no-response sessions, bounce (one-step) sessions."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        # Distinct sessions from flow_step_events in date range
        total_sessions_row = await conn.fetchrow(
            """
            SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        total_sessions = total_sessions_row["c"] if total_sessions_row else 0
        # Avg steps per session: total step events / distinct sessions
        steps_row = await conn.fetchrow(
            """
            SELECT COUNT(*) AS total FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        total_steps = steps_row["total"] if steps_row else 0
        avg_steps = (total_steps / total_sessions) if total_sessions else 0.0
        # Messages from flow_messages
        msg_row = await conn.fetchrow(
            """
            SELECT COUNT(*) AS total FROM flow_messages
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        total_messages = msg_row["total"] if msg_row else 0
        avg_messages = (total_messages / total_sessions) if total_sessions else 0.0
        # Session duration: max(created_at)-min(created_at) per session, then avg
        duration_row = await conn.fetchrow(
            """
            SELECT AVG(EXTRACT(EPOCH FROM (max_ts - min_ts))) AS avg_sec
            FROM (
                SELECT session_id, MAX(created_at) AS max_ts, MIN(created_at) AS min_ts
                FROM flow_step_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY session_id
            ) s
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        avg_duration = float(duration_row["avg_sec"]) if duration_row and duration_row["avg_sec"] is not None else None
        # Sessions with no user response: sessions that have only bot messages or only step events with no flow_messages role=user
        no_user_row = await conn.fetchrow(
            """
            SELECT COUNT(DISTINCT f.session_id) AS c
            FROM flow_step_events f
            WHERE f.project_id = $1 AND f.created_at >= $2 AND f.created_at <= $3
            AND NOT EXISTS (
                SELECT 1 FROM flow_messages m
                WHERE m.project_id = f.project_id AND m.session_id = f.session_id AND m.role = 'user'
            )
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        sessions_with_no_user_response = no_user_row["c"] if no_user_row else 0
        # Bounce: sessions that reached exactly one distinct node (one step)
        bounce_row = await conn.fetchrow(
            """
            SELECT COUNT(*) AS c FROM (
                SELECT session_id FROM flow_step_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY session_id
                HAVING COUNT(DISTINCT node_id) = 1
            ) b
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        bounce_sessions = bounce_row["c"] if bounce_row else 0
        return SessionAnalyticsResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            total_sessions=total_sessions,
            avg_messages_per_session=round(avg_messages, 2),
            avg_steps_per_session=round(avg_steps, 2),
            avg_session_duration_seconds=round(avg_duration, 2) if avg_duration is not None else None,
            sessions_with_no_user_response=sessions_with_no_user_response,
            bounce_sessions=bounce_sessions,
        )


@router.get("/bounce-rate", response_model=BounceRateResponse, summary="Bounce rate (first step only)")
async def get_bounce_rate(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Bounce rate = (first_step_sessions - second_step_sessions) / first_step_sessions * 100."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        order_by_step = []
        for n in nodes:
            node_id = n.get("id") or n.get("data", {}).get("id")
            if not node_id:
                continue
            data = n.get("data") or {}
            if data.get("trackAsStep") is False:
                continue
            order_by_step.append(node_id)
        first_node = order_by_step[0] if order_by_step else None
        second_node = order_by_step[1] if len(order_by_step) > 1 else None
        if not first_node:
            return BounceRateResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                first_step_sessions=0,
                second_step_sessions=0,
                bounce_rate_pct=0.0,
            )
        first_row = await conn.fetchrow(
            """
            SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
            WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
            """,
            project_id_uuid,
            first_node,
            start_d,
            end_d,
        )
        first_step_sessions = first_row["c"] if first_row else 0
        second_step_sessions = 0
        if second_node:
            second_row = await conn.fetchrow(
                """
                SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
                """,
                project_id_uuid,
                second_node,
                start_d,
                end_d,
            )
            second_step_sessions = second_row["c"] if second_row else 0
        bounce_rate = (
            round((first_step_sessions - second_step_sessions) / first_step_sessions * 100, 1)
            if first_step_sessions else 0.0
        )
        return BounceRateResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            first_step_sessions=first_step_sessions,
            second_step_sessions=second_step_sessions,
            bounce_rate_pct=bounce_rate,
        )


@router.get("/node-performance", response_model=NodePerformanceResponse, summary="Per-node performance and drop-off")
async def get_node_performance(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """For each step: times reached, unique sessions, next step reached, drop-off %."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        order_by_step: List[Dict[str, Any]] = []
        for n in nodes:
            node_id = n.get("id") or n.get("data", {}).get("id")
            if not node_id:
                continue
            data = n.get("data") or {}
            if data.get("trackAsStep") is False:
                continue
            label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or data.get("text") or n.get("type") or node_id
            order_by_step.append({"node_id": node_id, "node_label": label, "step_order": len(order_by_step) + 1})
        result_nodes: List[NodePerformanceStep] = []
        for i, s in enumerate(order_by_step):
            times_row = await conn.fetchrow(
                """
                SELECT COUNT(*) AS times, COUNT(DISTINCT session_id) AS sessions
                FROM flow_step_events
                WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
                """,
                project_id_uuid,
                s["node_id"],
                start_d,
                end_d,
            )
            times_reached = times_row["times"] if times_row else 0
            unique_sessions = times_row["sessions"] if times_row else 0
            next_step_reached = None
            drop_off_pct = None
            if i + 1 < len(order_by_step):
                next_node = order_by_step[i + 1]["node_id"]
                next_row = await conn.fetchrow(
                    """
                    SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                    WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
                    """,
                    project_id_uuid,
                    next_node,
                    start_d,
                    end_d,
                )
                next_step_reached = next_row["c"] if next_row else 0
                if unique_sessions and unique_sessions > 0:
                    drop_off_pct = round((1 - next_step_reached / unique_sessions) * 100, 1)
            result_nodes.append(
                NodePerformanceStep(
                    node_id=s["node_id"],
                    node_label=s["node_label"],
                    step_order=s["step_order"],
                    times_reached=times_reached,
                    unique_sessions=unique_sessions,
                    next_step_reached=next_step_reached,
                    drop_off_pct=drop_off_pct,
                )
            )
        return NodePerformanceResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            nodes=result_nodes,
        )


@router.get("/flow-paths", response_model=FlowPathsResponse, summary="Top flow paths (user journeys)")
async def get_flow_paths(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Top N most common paths: sequence of node labels per session, grouped."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        # Per session: ordered list of node_id by first occurrence (min created_at)
        rows = await conn.fetch(
            """
            SELECT session_id, array_agg(node_id ORDER BY min_ts) AS node_ids
            FROM (
                SELECT session_id, node_id, MIN(created_at) AS min_ts
                FROM flow_step_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY session_id, node_id
            ) t
            GROUP BY session_id
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        path_counts: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            node_ids = row["node_ids"] or []
            path_key = " → ".join(node_ids)
            if path_key not in path_counts:
                path_counts[path_key] = {"path_key": path_key, "node_ids": list(node_ids), "count": 0}
            path_counts[path_key]["count"] += 1
        sorted_paths = sorted(path_counts.values(), key=lambda x: -x["count"])[:limit]
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes_list = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        node_id_to_label = {}
        for n in nodes_list:
            nid = n.get("id") or n.get("data", {}).get("id")
            data = n.get("data") or {}
            label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or n.get("text") or data.get("text") or n.get("type") or nid or ""
            if nid:
                node_id_to_label[nid] = label
        path_items = []
        for p in sorted_paths:
            labels = [node_id_to_label.get(nid, nid) for nid in p["node_ids"]]
            path_items.append(
                FlowPathItem(
                    path=" → ".join(labels),
                    path_labels=labels,
                    session_count=p["count"],
                )
            )
        return FlowPathsResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            paths=path_items,
        )


def _node_label_from_flow(nodes_list: List[Dict[str, Any]], node_id: str) -> str:
    for n in nodes_list or []:
        nid = n.get("id") or (n.get("data") or {}).get("id")
        if nid != node_id:
            continue
        data = n.get("data") or {}
        return data.get("analyticsStepLabel") or n.get("label") or data.get("label") or n.get("text") or data.get("text") or n.get("type") or node_id or ""
    return node_id or ""


@router.get("/session-replay", response_model=SessionReplayResponse, summary="Session replay")
async def get_session_replay(
    project_id: str = Query(...),
    session_id: str = Query(...),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="session_id required")
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        user_id = UUID(user_id)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            user_id,
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            flow = json.loads(flow) if flow.strip() else {}
        nodes_list = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        steps = await conn.fetch(
            "SELECT node_id, node_label, created_at FROM flow_step_events WHERE project_id = $1 AND session_id = $2 ORDER BY created_at",
            project_id_uuid,
            sid,
        )
        messages = await conn.fetch(
            "SELECT role, content, node_id, node_label, created_at FROM flow_messages WHERE project_id = $1 AND session_id = $2 ORDER BY created_at",
            project_id_uuid,
            sid,
        )
        choices = await conn.fetch(
            "SELECT node_id, node_label, option_index, option_text, created_at FROM quick_reply_choices WHERE project_id = $1 AND session_id = $2 ORDER BY created_at",
            project_id_uuid,
            sid,
        )
        events = []
        for r in steps:
            label = (r["node_label"] or "").strip() or _node_label_from_flow(nodes_list, r["node_id"] or "")
            events.append(SessionReplayEvent(type="step", created_at=serialize_datetime_for_api(r["created_at"]) or "", node_id=r["node_id"], node_label=label or r["node_id"], role=None, content=None, option_index=None, option_text=None))
        for r in messages:
            label = (r["node_label"] or "").strip() or _node_label_from_flow(nodes_list, r["node_id"] or "")
            events.append(SessionReplayEvent(type="message", created_at=serialize_datetime_for_api(r["created_at"]) or "", node_id=r["node_id"], node_label=label or r["node_id"], role=r["role"], content=r["content"], option_index=None, option_text=None))
        for r in choices:
            label = (r["node_label"] or "").strip() or _node_label_from_flow(nodes_list, r["node_id"] or "")
            events.append(SessionReplayEvent(type="quick_reply", created_at=serialize_datetime_for_api(r["created_at"]) or "", node_id=r["node_id"], node_label=label or r["node_id"], role=None, content=None, option_index=r["option_index"], option_text=r["option_text"]))
        events.sort(key=lambda e: e.created_at)
        return SessionReplayResponse(project_id=project_id_uuid, project_name=proj["name"] or "Project", session_id=sid, events=events)


@router.get("/completion-analytics", response_model=CompletionAnalyticsResponse, summary="Completion node metrics")
async def get_completion_analytics(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Completion count and rate for nodes marked as completion (data.isCompletionNode) or last step."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        completion_node_id = None
        completion_node_label = None
        for n in nodes:
            data = n.get("data") or {}
            if data.get("isCompletionNode") is True:
                completion_node_id = n.get("id") or data.get("id")
                completion_node_label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or data.get("text") or n.get("type") or completion_node_id
                break
        if not completion_node_id:
            tracked = [n.get("id") or n.get("data", {}).get("id") for n in nodes if (n.get("data") or {}).get("trackAsStep") is not False]
            completion_node_id = tracked[-1] if tracked else None
            if completion_node_id:
                for n in nodes:
                    if (n.get("id") or n.get("data", {}).get("id")) == completion_node_id:
                        data = n.get("data") or {}
                        completion_node_label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or data.get("text") or n.get("type") or completion_node_id
                        break
        total_sessions_row = await conn.fetchrow(
            """
            SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        total_sessions = total_sessions_row["c"] if total_sessions_row else 0
        completion_count = 0
        if completion_node_id:
            comp_row = await conn.fetchrow(
                """
                SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
                """,
                project_id_uuid,
                completion_node_id,
                start_d,
                end_d,
            )
            completion_count = comp_row["c"] if comp_row else 0
        rate = round(completion_count / total_sessions * 100, 1) if total_sessions else 0.0
        return CompletionAnalyticsResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            completion_node_id=completion_node_id,
            completion_node_label=completion_node_label,
            completion_count=completion_count,
            total_sessions=total_sessions,
            completion_rate_pct=rate,
        )


@router.get("/abandonment", response_model=AbandonmentResponse, summary="Per-step abandonment")
async def get_abandonment(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Per step: reached, continued, exited; abandonment_rate = (reached - continued) / reached * 100."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        order_by_step: List[Dict[str, Any]] = []
        for n in nodes:
            node_id = n.get("id") or n.get("data", {}).get("id")
            if not node_id:
                continue
            data = n.get("data") or {}
            if data.get("trackAsStep") is False:
                continue
            label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or data.get("text") or n.get("type") or node_id
            order_by_step.append({"node_id": node_id, "node_label": label, "step_order": len(order_by_step) + 1})
        steps_out: List[AbandonmentStep] = []
        for i, s in enumerate(order_by_step):
            reached_row = await conn.fetchrow(
                """
                SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events
                WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4
                """,
                project_id_uuid,
                s["node_id"],
                start_d,
                end_d,
            )
            reached = reached_row["c"] if reached_row else 0
            continued = 0
            if i + 1 < len(order_by_step):
                next_node = order_by_step[i + 1]["node_id"]
                next_row = await conn.fetchrow(
                    """
                    SELECT COUNT(DISTINCT f1.session_id) AS c FROM flow_step_events f1
                    WHERE f1.project_id = $1 AND f1.node_id = $2 AND f1.created_at >= $3 AND f1.created_at <= $4
                    AND EXISTS (
                        SELECT 1 FROM flow_step_events f2
                        WHERE f2.project_id = f1.project_id AND f2.session_id = f1.session_id AND f2.node_id = $5
                        AND f2.created_at >= $3 AND f2.created_at <= $4
                    )
                    """,
                    project_id_uuid,
                    s["node_id"],
                    start_d,
                    end_d,
                    next_node,
                )
                continued = next_row["c"] if next_row else 0
            exited = reached - continued
            abandonment_rate = round((exited / reached) * 100, 1) if reached else 0.0
            steps_out.append(
                AbandonmentStep(
                    node_id=s["node_id"],
                    node_label=s["node_label"],
                    step_order=s["step_order"],
                    reached=reached,
                    continued=continued,
                    exited=exited,
                    abandonment_rate_pct=abandonment_rate,
                )
            )
        return AbandonmentResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            steps=steps_out,
        )


@router.get("/bot-response-time", response_model=BotResponseTimeResponse, summary="Bot response time")
async def get_bot_response_time(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Avg and max response time (assistant msg time - previous user msg time) in ms."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        rows = await conn.fetch(
            """
            WITH ordered AS (
                SELECT session_id, role, created_at,
                       LAG(created_at) OVER (PARTITION BY session_id ORDER BY created_at) AS prev_ts
                FROM flow_messages
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            )
            SELECT EXTRACT(EPOCH FROM (created_at - prev_ts)) * 1000 AS response_time_ms
            FROM ordered
            WHERE role = 'assistant' AND prev_ts IS NOT NULL
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        times_ms = [r["response_time_ms"] for r in rows if r["response_time_ms"] is not None and r["response_time_ms"] >= 0]
        avg_ms = round(sum(times_ms) / len(times_ms), 2) if times_ms else None
        max_ms = round(max(times_ms), 2) if times_ms else None
        return BotResponseTimeResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            avg_response_time_ms=avg_ms,
            max_response_time_ms=max_ms,
            sample_count=len(times_ms),
        )


@router.get("/activity-heatmap", response_model=ActivityHeatmapResponse, summary="Sessions by hour and weekday")
async def get_activity_heatmap(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        by_hour_rows = await conn.fetch(
            """
            -- created_at is stored in UTC; convert to IST for hour-of-day analytics.
            SELECT EXTRACT(HOUR FROM (created_at AT TIME ZONE 'Asia/Kolkata'))::int AS hour,
                   COUNT(DISTINCT session_id) AS sessions
            FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            GROUP BY EXTRACT(HOUR FROM (created_at AT TIME ZONE 'Asia/Kolkata'))
            ORDER BY hour
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        by_weekday_rows = await conn.fetch(
            """
            -- Convert to IST before extracting weekday so day buckets align with India time.
            SELECT EXTRACT(DOW FROM (created_at AT TIME ZONE 'Asia/Kolkata'))::int AS weekday,
                   COUNT(DISTINCT session_id) AS sessions
            FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            GROUP BY EXTRACT(DOW FROM (created_at AT TIME ZONE 'Asia/Kolkata'))
            ORDER BY weekday
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        day_names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        return ActivityHeatmapResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            by_hour=[{"hour": r["hour"], "sessions": r["sessions"]} for r in by_hour_rows],
            by_weekday=[{"weekday": r["weekday"], "day_name": day_names[r["weekday"]], "sessions": r["sessions"]} for r in by_weekday_rows],
        )


@router.get("/conversion-analytics", response_model=ConversionAnalyticsResponse, summary="Conversion node metrics")
async def get_conversion_analytics(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Nodes with data.isConversionNode = true."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        flow = proj.get("flow") or {}
        if isinstance(flow, str):
            try:
                flow = json.loads(flow) if flow.strip() else {}
            except (ValueError, TypeError):
                flow = {}
        nodes = (flow.get("nodes") or []) if isinstance(flow, dict) else []
        conversion_node_id = None
        conversion_node_label = None
        for n in nodes:
            data = n.get("data") or {}
            if data.get("isConversionNode") is True:
                conversion_node_id = n.get("id") or data.get("id")
                conversion_node_label = data.get("analyticsStepLabel") or n.get("label") or data.get("label") or data.get("text") or n.get("type") or conversion_node_id
                break
        total_sessions_row = await conn.fetchrow(
            "SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3",
            project_id_uuid,
            start_d,
            end_d,
        )
        total_sessions = total_sessions_row["c"] if total_sessions_row else 0
        conversion_count = 0
        if conversion_node_id:
            conv_row = await conn.fetchrow(
                "SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events WHERE project_id = $1 AND node_id = $2 AND created_at >= $3 AND created_at <= $4",
                project_id_uuid,
                conversion_node_id,
                start_d,
                end_d,
            )
            conversion_count = conv_row["c"] if conv_row else 0
        rate = round(conversion_count / total_sessions * 100, 1) if total_sessions else 0.0
        return ConversionAnalyticsResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            conversion_node_id=conversion_node_id,
            conversion_node_label=conversion_node_label,
            conversion_count=conversion_count,
            total_sessions=total_sessions,
            conversion_rate_pct=rate,
        )


@router.get("/user-input-insights", response_model=UserInputInsightsResponse, summary="Top queries and trend")
async def get_user_input_insights(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        top_rows = await conn.fetch(
            """
            SELECT MIN(TRIM(content)) AS content, LOWER(TRIM(content)) AS normalized, COUNT(*) AS cnt
            FROM flow_messages
            WHERE project_id = $1 AND role = 'user' AND content IS NOT NULL AND TRIM(content) != ''
            AND created_at >= $2 AND created_at <= $3
            GROUP BY LOWER(TRIM(content))
            ORDER BY cnt DESC
            LIMIT $4
            """,
            project_id_uuid,
            start_d,
            end_d,
            limit,
        )
        trend_rows = await conn.fetch(
            """
            SELECT DATE(created_at) AS d, COUNT(*) AS cnt
            FROM flow_messages
            WHERE project_id = $1 AND role = 'user' AND content IS NOT NULL AND TRIM(content) != ''
            AND created_at >= $2 AND created_at <= $3
            GROUP BY DATE(created_at)
            ORDER BY d
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        return UserInputInsightsResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            top_queries=[{"content": r["content"], "normalized": r["normalized"], "count": r["cnt"]} for r in top_rows],
            trend_by_date=[{"date": r["d"].strftime("%Y-%m-%d"), "count": r["cnt"]} for r in trend_rows],
        )


@router.get("/returning-vs-new", response_model=ReturningVsNewResponse, summary="New vs returning sessions")
async def get_returning_vs_new(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """New = one step and one day; returning = multiple steps or days."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        rows = await conn.fetch(
            """
            SELECT session_id, COUNT(DISTINCT node_id) AS steps, COUNT(DISTINCT DATE(created_at)) AS days
            FROM flow_step_events
            WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
            GROUP BY session_id
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        new_sessions = sum(1 for r in rows if r["steps"] == 1 and r["days"] == 1)
        returning_sessions = len(rows) - new_sessions
        total = len(rows)
        returning_pct = round(returning_sessions / total * 100, 1) if total else 0.0
        return ReturningVsNewResponse(
            project_id=project_id_uuid,
            project_name=proj["name"] or "Project",
            new_sessions=new_sessions,
            returning_sessions=returning_sessions,
            returning_pct=returning_pct,
        )


@router.get("/most-asked", response_model=MostAskedResponse, summary="Top user messages (flow_messages)")
async def get_most_asked(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Most frequent user messages (normalized: trim, lower) for analytics."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
            flow = proj.get("flow") or {}
            if isinstance(flow, str):
                try:
                    flow = json.loads(flow) if flow.strip() else {}
                except (ValueError, TypeError):
                    flow = {}
            nodes_list = (flow.get("nodes") or []) if isinstance(flow, dict) else []
            input_node_ids = [
                (n.get("id") or (n.get("data") or {}).get("id"))
                for n in nodes_list
                if (n.get("type") == "input" or (n.get("data") or {}).get("type") == "input")
            ]
            input_node_ids = [x for x in input_node_ids if x]

            date_filter = ""
            params: List[Any] = [project_id_uuid]
            if start_date and end_date:
                try:
                    datetime.strptime(start_date, "%Y-%m-%d")
                    datetime.strptime(end_date, "%Y-%m-%d")
                    date_filter = " AND created_at >= $2 AND created_at <= $3"
                    params.extend([start_date, end_date])
                except ValueError:
                    pass
            if input_node_ids:
                input_filter = " AND node_id = ANY($" + ("4" if date_filter else "2") + "::text[])"
                params.append(input_node_ids)
                params.append(limit)
                limit_arg = "$5" if date_filter else "$3"
            else:
                input_filter = " AND TRIM(COALESCE(node_label, '')) = 'Input'"
                params.append(limit)
                limit_arg = "$4" if date_filter else "$2"
            rows = await conn.fetch(
                """
                SELECT MIN(TRIM(content)) AS content, LOWER(TRIM(content)) AS normalized, COUNT(*) AS cnt
                FROM flow_messages
                WHERE project_id = $1 AND role = 'user' AND content IS NOT NULL AND TRIM(content) != ''
                """ + date_filter + input_filter + """
                GROUP BY LOWER(TRIM(content))
                ORDER BY cnt DESC
                LIMIT """ + limit_arg,
                *params,
            )
            items = [MostAskedItem(content=(r["content"] or r["normalized"]), count=r["cnt"]) for r in rows]
            return MostAskedResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                items=items,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Most-asked error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/flow-message-stats", response_model=FlowMessageStatsResponse, summary="Flow message counts for a project")
async def get_flow_message_stats(
    project_id: str = Query(..., description="Project ID (frontend)"),
    start_date: Optional[str] = Query(None, description="Start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="End date YYYY-MM-DD"),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Total user/assistant messages, empty assistant count, and sessions with at least one message."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            proj = await conn.fetchrow(
                "SELECT id, name, flow FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
                project_id_uuid,
                user_id,
            )
            if not proj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
            date_filter = ""
            params: List[Any] = [project_id_uuid]
            if start_date and end_date:
                try:
                    datetime.strptime(start_date, "%Y-%m-%d")
                    datetime.strptime(end_date, "%Y-%m-%d")
                    date_filter = " AND created_at >= $2 AND created_at <= $3"
                    params.extend([start_date, end_date])
                except ValueError:
                    pass
            base = " FROM flow_messages WHERE project_id = $1"
            extra = " AND created_at >= $2 AND created_at <= $3" if date_filter else ""
            # Bot/assistant messages = from nodes type text/assistant or role=assistant (so count is never wrong)
            flow = proj.get("flow") or {}
            if isinstance(flow, str):
                try:
                    flow = json.loads(flow) if (flow or "").strip() else {}
                except (ValueError, TypeError):
                    flow = {}
            nodes_list = (flow.get("nodes") or []) if isinstance(flow, dict) else []
            assistant_text_node_ids = [
                n["id"] for n in nodes_list
                if n.get("id") and (
                    n.get("type") in ("text", "assistant")
                    or (n.get("data") or {}).get("type") in ("text", "assistant")
                )
            ]
            if assistant_text_node_ids:
                bot_filter = " AND (node_id = ANY(" + ("$4" if date_filter else "$2") + "::text[]) OR role = 'assistant')"
                p = list(params) + [assistant_text_node_ids]
                a_row = await conn.fetchrow("SELECT COUNT(*) AS c " + base + bot_filter + extra, *p)
                empty_row = await conn.fetchrow(
                    "SELECT COUNT(*) AS c " + base + bot_filter + " AND (content IS NULL OR TRIM(content) = '')" + extra,
                    *p,
                )
            else:
                p = list(params)
                a_row = await conn.fetchrow("SELECT COUNT(*) AS c " + base + " AND role = 'assistant'" + extra, *p)
                empty_row = await conn.fetchrow("SELECT COUNT(*) AS c " + base + " AND role = 'assistant' AND (content IS NULL OR TRIM(content) = '')" + extra, *p)
            p = list(params)
            u_row = await conn.fetchrow("SELECT COUNT(*) AS c " + base + " AND role = 'user'" + extra, *p)
            sess_row = await conn.fetchrow("SELECT COUNT(DISTINCT session_id) AS c " + base + extra, *p)
            return FlowMessageStatsResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                total_user_messages=u_row["c"] if u_row else 0,
                total_assistant_messages=a_row["c"] if a_row else 0,
                empty_assistant_count=empty_row["c"] if empty_row else 0,
                total_sessions_with_messages=sess_row["c"] if sess_row else 0,
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Flow message stats error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/device-analytics", response_model=DeviceAnalyticsResponse, summary="Device, browser, OS distribution")
async def get_device_analytics(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """From session_metadata (widget sends device_type, browser, os)."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        try:
            base = " FROM session_metadata WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3"
            params: List[Any] = [project_id_uuid, start_d, end_d]
            total_row = await conn.fetchrow("SELECT COUNT(*) AS c " + base, *params)
            total = total_row["c"] if total_row else 0
            def to_dist(items, tot):
                return [DeviceDistributionItem(name=r["name"], count=r["count"], percentage=round(r["count"] / tot * 100, 2) if tot else 0) for r in items]
            device_rows = await conn.fetch(
                "SELECT COALESCE(device_type, 'Unknown') AS name, COUNT(*) AS count " + base + " GROUP BY COALESCE(device_type, 'Unknown') ORDER BY count DESC",
                *params,
            )
            browser_rows = await conn.fetch(
                "SELECT COALESCE(browser, 'Unknown') AS name, COUNT(*) AS count " + base + " GROUP BY COALESCE(browser, 'Unknown') ORDER BY count DESC",
                *params,
            )
            os_rows = await conn.fetch(
                "SELECT COALESCE(os, 'Unknown') AS name, COUNT(*) AS count " + base + " GROUP BY COALESCE(os, 'Unknown') ORDER BY count DESC",
                *params,
            )
            return DeviceAnalyticsResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                device_type=to_dist(device_rows, total),
                browser=to_dist(browser_rows, total),
                os=to_dist(os_rows, total),
            )
        except Exception:
            return DeviceAnalyticsResponse(project_id=project_id_uuid, project_name=proj["name"] or "Project", device_type=[], browser=[], os=[])


@router.get("/traffic-source", response_model=TrafficSourceResponse, summary="Chats per page and referrer")
async def get_traffic_source(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """From session_metadata (page_url, referrer)."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        try:
            base = " FROM session_metadata WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3"
            params: List[Any] = [project_id_uuid, start_d, end_d, limit]
            by_page_rows = await conn.fetch(
                "SELECT COALESCE(NULLIF(TRIM(page_url), ''), '(direct)') AS source, COUNT(*) AS chats " + base + " AND page_url IS NOT NULL GROUP BY COALESCE(NULLIF(TRIM(page_url), ''), '(direct)') ORDER BY chats DESC LIMIT $4",
                *params,
            )
            by_referrer_rows = await conn.fetch(
                "SELECT COALESCE(NULLIF(TRIM(referrer), ''), '(none)') AS source, COUNT(*) AS chats " + base + " GROUP BY COALESCE(NULLIF(TRIM(referrer), ''), '(none)') ORDER BY chats DESC LIMIT $4",
                *params,
            )
            return TrafficSourceResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                by_page=[TrafficSourceItem(source=r["source"], chats=r["chats"]) for r in by_page_rows],
                by_referrer=[TrafficSourceItem(source=r["source"], chats=r["chats"]) for r in by_referrer_rows],
            )
        except Exception:
            return TrafficSourceResponse(project_id=project_id_uuid, project_name=proj["name"] or "Project", by_page=[], by_referrer=[])


@router.get("/api-performance", response_model=ApiPerformanceResponse, summary="API node performance")
async def get_api_performance(
    project_id: str = Query(...),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """From api_performance_events (widget reports API calls)."""
    user_id = current_user.get("id")
    project_id_uuid, start_d, end_d = _parse_project_and_dates(project_id, user_id, start_date, end_date)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            UUID(str(user_id)),
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        try:
            rows = await conn.fetch(
                """
                SELECT api_name,
                       COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE response_status >= 200 AND response_status < 300) AS success,
                       COUNT(*) FILTER (WHERE response_status IS NULL OR response_status < 200 OR response_status >= 300) AS failed,
                       AVG(response_time_ms) FILTER (WHERE response_time_ms IS NOT NULL) AS avg_ms
                FROM api_performance_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY api_name
                ORDER BY total DESC
                """,
                project_id_uuid,
                start_d,
                end_d,
            )
            total_calls = sum(r["total"] for r in rows)
            apis = []
            for r in rows:
                success = r["success"] or 0
                failed = r["failed"] or 0
                rate = round(success / r["total"] * 100, 2) if r["total"] else 0
                apis.append(
                    ApiPerformanceSummary(
                        api_name=r["api_name"],
                        total_calls=r["total"],
                        successful_calls=success,
                        failed_calls=failed,
                        success_rate_pct=rate,
                        avg_response_time_ms=round(float(r["avg_ms"]), 2) if r["avg_ms"] is not None else None,
                    )
                )
            return ApiPerformanceResponse(
                project_id=project_id_uuid,
                project_name=proj["name"] or "Project",
                total_api_calls=total_calls,
                apis=apis,
            )
        except Exception:
            return ApiPerformanceResponse(project_id=project_id_uuid, project_name=proj["name"] or "Project", total_api_calls=0, apis=[])


@router.get("/analytics-alerts", response_model=AnalyticsAlertsResponse, summary="Smart analytics alerts")
async def get_analytics_alerts(
    project_id: str = Query(...),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """Computed alerts: high bounce, API failures, etc."""
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid project ID")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow(
            "SELECT id, name FROM projects WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))",
            project_id_uuid,
            user_id,
        )
        if not proj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        alerts: List[AnalyticsAlertItem] = []
        end_d = today_ist()
        start_d = end_d - timedelta(days=7)
        first_row = await conn.fetchrow(
            "SELECT COUNT(DISTINCT session_id) AS c FROM flow_step_events WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3",
            project_id_uuid,
            start_d,
            end_d,
        )
        total_sessions = first_row["c"] if first_row else 0
        bounce_row = await conn.fetchrow(
            """
            SELECT COUNT(*) AS c FROM (
                SELECT session_id FROM flow_step_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                GROUP BY session_id
                HAVING COUNT(DISTINCT node_id) = 1
            ) b
            """,
            project_id_uuid,
            start_d,
            end_d,
        )
        bounce_sessions = bounce_row["c"] if bounce_row else 0
        bounce_rate = round(bounce_sessions / total_sessions * 100, 1) if total_sessions else 0
        if bounce_rate > 50 and total_sessions >= 10:
            alerts.append(AnalyticsAlertItem(alert_type="bounce_rate", message=f"Bounce rate is {bounce_rate}% (sessions with only one step).", severity="warning", value=bounce_rate, threshold=50))
        try:
            api_fail_row = await conn.fetchrow(
                """
                SELECT COUNT(*) AS failed FROM api_performance_events
                WHERE project_id = $1 AND created_at >= $2 AND created_at <= $3
                AND (response_status IS NULL OR response_status < 200 OR response_status >= 300)
                """,
                project_id_uuid,
                start_d,
                end_d,
            )
            failed = api_fail_row["failed"] if api_fail_row else 0
            if failed > 5:
                alerts.append(AnalyticsAlertItem(alert_type="api_failures", message=f"{failed} API call(s) failed in the last 7 days.", severity="critical", value=float(failed)))
        except Exception:
            pass
        return AnalyticsAlertsResponse(project_id=project_id_uuid, project_name=proj["name"] or "Project", alerts=alerts)


@router.post("/session-metadata", status_code=status.HTTP_204_NO_CONTENT, summary="Record session metadata (widget)")
async def record_session_metadata(
    body: SessionMetadataCreate,
    current_user: dict = Depends(get_current_user_or_bot),
    db: DatabaseClient = Depends(get_database_client_flexible),
):
    """Widget sends device_type, browser, os, page_url, referrer."""
    sid = (body.session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="session_id required")
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow("SELECT id, user_id FROM projects WHERE id = $1", body.project_id)
        if not proj or str(proj["user_id"]) != str(user_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        try:
            await conn.execute(
                """
                INSERT INTO session_metadata (project_id, session_id, device_type, browser, os, page_url, referrer)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                body.project_id,
                sid,
                (body.device_type or "").strip() or None,
                (body.browser or "").strip() or None,
                (body.os or "").strip() or None,
                (body.page_url or "").strip()[:2048] or None,
                (body.referrer or "").strip()[:2048] or None,
            )
        except Exception as e:
            if "session_metadata" in str(e).lower() or "does not exist" in str(e).lower():
                raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Analytics tables not migrated yet.")
            raise
    return None


@router.post("/api-performance-event", status_code=status.HTTP_204_NO_CONTENT, summary="Record API call (widget)")
async def record_api_performance(
    body: ApiPerformanceCreate,
    current_user: dict = Depends(get_current_user_or_bot),
    db: DatabaseClient = Depends(get_database_client_flexible),
):
    """Widget reports each API node call: api_name, response_status, response_time_ms."""
    user_id = current_user.get("id")
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        proj = await conn.fetchrow("SELECT id, user_id FROM projects WHERE id = $1", body.project_id)
        if not proj or str(proj["user_id"]) != str(user_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        try:
            await conn.execute(
                """
                INSERT INTO api_performance_events (project_id, session_id, node_id, api_name, response_status, response_time_ms)
                VALUES ($1, $2, $3, $4, $5, $6)
                """,
                body.project_id,
                (body.session_id or "").strip(),
                (body.node_id or "").strip() or None,
                (body.api_name or "").strip() or "unknown",
                body.response_status,
                body.response_time_ms,
            )
        except Exception as e:
            if "api_performance_events" in str(e).lower() or "does not exist" in str(e).lower():
                raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Analytics tables not migrated yet.")
            raise
    return None


@router.get('/widget/{project_id}', response_model=WidgetConfig, summary="Get widget configuration")
async def get_widget_config(
    project_id: str,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get widget configuration and embed code for a project.
    Supports both backend and frontend projects.
    For frontend projects, finds the connected backend project.
    """
    try:
        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            user_id = current_user["id"]
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid user ID format"
                    )

            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format"
                )

            # Load project and workspace membership info so we can authorize:
            # - Personal projects (workspace_id IS NULL): only owner (user_id) can access
            # - Workspace projects: owner/admin/member roles can access (viewer cannot)
            project = await conn.fetchrow(
                """
                SELECT
                    p.id,
                    p.name,
                    p.project_type,
                    p.api_key,
                    p.user_id,
                    p.workspace_id,
                    wm.role AS member_role
                FROM projects p
                LEFT JOIN workspace_members wm
                  ON p.workspace_id = wm.workspace_id
                 AND wm.user_id = $1
                WHERE p.id = $2
                """,
                user_id,
                project_id_uuid,
            )

            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found",
                )

            # Authorization check
            if project["workspace_id"] is None:
                # Personal project: only owner may access
                if project["user_id"] != user_id:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to access this project",
                    )
            else:
                # Workspace project: owner/admin/member roles may access (viewer cannot)
                if project["member_role"] not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to access this project",
                    )

            # Handle frontend projects - find connected backend project
            backend_project_id = project_id_uuid
            backend_api_key = project['api_key']
            
            if project['project_type'] == 'frontend':
                # Find a backend project for api_key/embed (optional for preview)
                backend_project = await conn.fetchrow(
                    """
                    SELECT id, api_key
                    FROM projects
                    WHERE user_id = $1 
                    AND project_type = 'backend'
                    AND api_key IS NOT NULL
                    ORDER BY updated_at DESC
                    LIMIT 1
                    """,
                    user_id
                )
                if backend_project:
                    backend_project_id = backend_project['id']
                    backend_api_key = backend_project['api_key']
                else:
                    # No backend project: use frontend project id and empty api_key so preview still loads
                    backend_project_id = project_id_uuid
                    backend_api_key = project['api_key'] or ""
            elif project['project_type'] != 'backend':
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Widget is only available for backend or frontend projects"
                )
            elif not project['api_key']:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Project does not have an API key. Please regenerate it."
                )

            backend_url = _backend_base_url(request)
            script_base_url = _widget_script_base_url(request)
            
            # For frontend projects, generate the actual script from the flow
            if project['project_type'] == 'frontend':
                # Get the project flow to generate the script
                project_with_flow = await conn.fetchrow(
                    """
                    SELECT flow FROM projects WHERE id = $1
                    """,
                    project_id_uuid
                )
                
                if project_with_flow and project_with_flow['flow']:
                    # Serve the generated script via endpoint (same backend)
                    widget_script_url = f"{backend_url}/v1/project-analytics/widget-script/{project_id_uuid}"
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Frontend project has no flow data. Please create a flow first."
                    )
            else:
                # For backend projects, use the static widget.js (served from static dir; use script base URL)
                widget_script_url = f"{script_base_url}/static/widget.js"
            
            widget_url = f"{backend_url}/v1/widget/{backend_project_id}"
            
            analytics_project_id = project_id_uuid if project['project_type'] == 'frontend' else backend_project_id
            embed_code = f"""<div id="winassist-chatbot-{backend_project_id}"></div>
<script>
  (function() {{
    var script = document.createElement('script');
    script.src = '{widget_script_url}';
    script.setAttribute('data-project-id', '{backend_project_id}');
    script.setAttribute('data-analytics-project-id', '{analytics_project_id}');
    script.setAttribute('data-api-key', '{backend_api_key}');
    script.setAttribute('data-api-url', '{backend_url}/v1');
    document.head.appendChild(script);
  }})();
</script>"""

            return WidgetConfig(
                project_id=project_id_uuid,
                api_key=backend_api_key,
                widget_url=widget_url,
                embed_code=embed_code
            )

        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get widget config error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get widget config: {str(e)}"
        )


@router.post('/save-widget-script/{project_id}', response_model=SaveWidgetScriptResponse, summary="Save widget script to static folder for local testing")
async def save_widget_script(
    project_id: str,
    request: Request,
    body: SaveWidgetScriptRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Save the generated widget JavaScript to the backend's static/widgets folder
    with a unique filename widget_<user_id>_<project_id>.js.
    Returns the URL to load the script (e.g. http://localhost:9000/static/widgets/widget_xxx_yyy.js).
    """
    try:
        user_id = current_user["id"]
        if isinstance(user_id, str):
            try:
                user_id = UUID(user_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid user ID format"
                )
        try:
            project_id_uuid = UUID(project_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid project ID format"
            )

        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            # Workspace-aware auth: allow project owner or workspace owner/admin/member
            project = await conn.fetchrow(
                """
                SELECT
                    p.id,
                    p.name,
                    p.project_type,
                    p.user_id AS project_owner_id,
                    p.workspace_id,
                    wm.role AS member_role
                FROM projects p
                LEFT JOIN workspace_members wm
                  ON p.workspace_id = wm.workspace_id
                 AND wm.user_id = $1
                WHERE p.id = $2
                """,
                user_id,
                project_id_uuid,
            )
            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )
            if project["workspace_id"] is not None:
                if project["member_role"] not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to save widget for this project",
                    )
            else:
                if project["project_owner_id"] != user_id:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to save widget for this project",
                    )
            if project['project_type'] != 'frontend':
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Widget script save is only for frontend projects"
                )
            project_owner_id = project["project_owner_id"]
        finally:
            await pool.release(conn)

        # Must match main.py exactly: write only where we serve /static (single source of truth).
        api_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        backend_base = (os.getenv("WIDGET_STATIC_BASE_PATH") or "").strip()
        if backend_base:
            static_dir = os.path.join(backend_base.rstrip("/"), "static")
        else:
            static_dir = os.path.join(api_dir, "static")
        widgets_dir = os.path.join(static_dir, "widgets")
        os.makedirs(widgets_dir, exist_ok=True)

        filename = f"widget_{project_owner_id}_{project_id_uuid}.js"
        filepath = os.path.join(widgets_dir, filename)

        # Bake backend API URL from env into the script so the saved file works when loaded without window.BACKEND_API_URL
        api_base = _backend_base_url(request)
        backend_api_url = api_base if api_base.endswith("/v1") else f"{api_base}/v1"
        script_content = (body.script_content or "").replace("__BACKEND_API_URL__", backend_api_url)

        # If the frontend sent the old format (regex), the replace above corrupts the regex into e.g. /http://host/v1/g
        # which is invalid JS (the / in http:// closes the regex). Fix by replacing that line with split/join.
        broken_regex_line = "widgetHTML = widgetHTML.replace(/" + backend_api_url + "/g, backendApiUrl);"
        safe_line = "widgetHTML = widgetHTML.split('" + backend_api_url.replace("'", "\\'") + "').join(backendApiUrl);"
        if broken_regex_line in script_content:
            script_content = script_content.replace(broken_regex_line, safe_line)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(script_content)

        script_base_url = _widget_script_base_url(request)
        script_url = f"{script_base_url}/static/widgets/{filename}"

        # Persist script URL so shareable widget page can load it without auth
        conn2 = await pool.acquire()
        try:
            await conn2.execute(
                """
                UPDATE projects SET widget_script_url = $1, updated_at = NOW()
                WHERE id = $2
                """,
                script_url,
                project_id_uuid,
            )
        finally:
            await pool.release(conn2)

        logger.info("Saved widget script to %s for user %s project %s", filepath, user_id, project_id_uuid)
        return SaveWidgetScriptResponse(script_url=script_url, filename=filename)
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Save widget script error: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save widget script: {str(e)}"
        )


@router.get('/widget-script/{project_id}', summary="Get generated widget script for frontend project")
async def get_widget_script(
    project_id: str,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get the generated JavaScript widget script for a frontend project.
    This generates the actual script from the project's flow.
    """
    try:
        pool = await db.get_pool()
        conn = await pool.acquire()
        try:
            user_id = current_user["id"]
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid user ID format"
                    )

            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format"
                )

            project = await conn.fetchrow(
                """
                SELECT id, name, project_type, flow
                FROM projects
                WHERE id = $1 AND (user_id = $2 OR workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = $2 AND role IN ('owner','admin','member','viewer')))
                """,
                project_id_uuid,
                user_id
            )

            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )

            if project['project_type'] != 'frontend':
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Widget script is only available for frontend projects"
                )

            if not project['flow']:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Project has no flow data. Please create a flow first."
                )

            backend_url = _backend_base_url(request)
            # Get API key from a backend project if available (optional for preview)
            backend_project = await conn.fetchrow(
                """
                SELECT id, api_key
                FROM projects
                WHERE user_id = $1 
                AND project_type = 'backend'
                AND api_key IS NOT NULL
                ORDER BY updated_at DESC
                LIMIT 1
                """,
                user_id
            )
            api_key_for_script = backend_project['api_key'] if backend_project else ""
            backend_project_id = backend_project['id'] if backend_project else project_id_uuid

            # Generate a basic widget script that loads flow and executes it
            # This is a placeholder - the actual script should be generated from the flow
            widget_script = f"""
// WinAssist Widget Script for Project {project_id_uuid}
// This script loads the flow and executes it

(function() {{
    const projectId = '{project_id_uuid}';
    const apiKey = '{api_key_for_script}';
    const apiUrl = '{backend_url}/v1';
    
    // Load project flow from API
    fetch(`${{apiUrl}}/projects/${{projectId}}`, {{
        headers: {{
            'Authorization': `Bearer ${{apiKey}}`,
            'X-Bot-API-Key': apiKey
        }}
    }})
    .then(response => response.json())
    .then(project => {{
        if (project.flow && project.flow.nodes) {{
            // Execute the flow
            console.log('Widget loaded for project:', projectId);
            // TODO: Execute the actual flow logic here
            // This requires porting the JavaScript code generation from frontend
        }}
    }})
    .catch(error => {{
        console.error('Failed to load widget:', error);
    }});
}})();
"""
            
            # Return the generated JavaScript code
            return Response(
                content=widget_script,
                media_type="application/javascript",
                headers={
                    "Content-Disposition": f'inline; filename="widget-{project_id}.js"',
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                }
            )

        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get widget script error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get widget script: {str(e)}"
        )


@router.get(
    '/public/widget-script-url/{project_id}',
    response_model=PublicWidgetScriptUrlResponse,
    summary="Get widget script URL for shareable link (no auth)",
)
async def get_public_widget_script_url(
    project_id: str,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """
    Public endpoint: returns the saved widget script URL for a project so the
    shareable widget page can load the script without authentication.
    Returns 404 if the project has no saved widget script yet.
    """
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        )
    pool = await db.get_pool()
    conn = await pool.acquire()
    try:
        row = await conn.fetchrow(
            """
            SELECT widget_script_url FROM projects
            WHERE id = $1 AND widget_script_url IS NOT NULL
            """,
            project_id_uuid,
        )
        if not row or not row["widget_script_url"]:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Widget script not saved yet. Save the widget from Test Widget first.",
            )
        return PublicWidgetScriptUrlResponse(script_url=row["widget_script_url"])
    finally:
        await pool.release(conn)


@router.get(
    '/public/widget-viewer-config/{project_id}',
    response_model=PublicWidgetViewerConfigResponse,
    summary="Get widget config for viewer page (script URL + backend URL, no auth)",
)
async def get_public_widget_viewer_config(
    project_id: str,
    request: Request,
    db: DatabaseClient = Depends(get_database_client_no_auth),
):
    """
    Public endpoint for the shareable widget viewer page.
    Returns only non-secret data needed to load the saved widget script.
    """
    try:
        project_id_uuid = UUID(project_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        )
    pool = await db.get_pool()
    conn = await pool.acquire()
    try:
        row = await conn.fetchrow(
            """
            SELECT id, widget_script_url
            FROM projects
            WHERE id = $1 AND widget_script_url IS NOT NULL
            """,
            project_id_uuid,
        )
        if not row or not row["widget_script_url"]:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Widget script not saved yet. Save the widget from Test Widget first.",
            )
        backend_url = _backend_base_url(request)
        return PublicWidgetViewerConfigResponse(
            script_url=row["widget_script_url"],
            project_id=project_id,
            api_key="",
            backend_url=backend_url,
        )
    finally:
        await pool.release(conn)

