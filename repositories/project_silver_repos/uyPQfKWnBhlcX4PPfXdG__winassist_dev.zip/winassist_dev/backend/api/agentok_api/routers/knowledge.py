from datetime import datetime
import html
import os
from pathlib import Path
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse
from uuid import uuid4

import requests
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from pydantic import BaseModel

from ..dependencies import get_current_user, get_database_client
from ..services.database import DatabaseClient
from ..utils.knowledge_registry import (
    delete_knowledge_collection as delete_knowledge_collection_record,
    delete_knowledge_document as delete_knowledge_document_record,
    get_collection_documents,
    get_knowledge_collection,
    get_knowledge_document,
    list_knowledge_collections as list_knowledge_collection_records,
    list_knowledge_documents as list_knowledge_document_records,
    resolve_relative_path,
    upsert_knowledge_collection,
    upsert_knowledge_document,
)
from ..utils.rag_tool import extract_text_from_path, run_rag_search
from ..utils.datetime import now_ist, serialize_datetime_for_api


router = APIRouter()


API_DIR = Path(__file__).resolve().parents[2]
KNOWLEDGE_UPLOADS_ROOT = Path(
    os.environ.get("KNOWLEDGE_UPLOADS_ROOT", str(API_DIR / "knowledge_uploads"))
).resolve()


def _safe_join(*parts: str) -> str:
    path = Path(os.path.join(*parts))
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _sanitize_filename(filename: Optional[str]) -> str:
    raw_name = (filename or "document").strip()
    path_name = Path(raw_name)
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", path_name.stem).strip("._-") or "document"
    suffix = re.sub(r"[^A-Za-z0-9.]+", "", path_name.suffix or "")
    return f"{stem}{suffix}"


def _resolve_user_relative_path(user_id: str, relative_path: str) -> Path:
    try:
        return resolve_relative_path(user_id, relative_path)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


class RetrievalTestRequest(BaseModel):
    query: str
    workspace_id: Optional[str] = None
    collection_id: Optional[str] = None
    relative_path: Optional[str] = None
    knowledge_text: Optional[str] = None
    chunk_size: int = 500
    chunk_overlap: int = 50
    top_k: int = 3


class KnowledgeCollectionBody(BaseModel):
    workspace_id: Optional[str] = None
    id: Optional[str] = None
    name: str
    description: Optional[str] = None
    documentIds: List[str] = []
    botIds: List[str] = []


class KnowledgeUrlImportBody(BaseModel):
    workspace_id: Optional[str] = None
    title: Optional[str] = None
    source_url: str
    source_language: Optional[str] = None


def _index_document(abs_path: str) -> Dict[str, Any]:
    try:
        extracted_text = extract_text_from_path(abs_path)
        normalized = re.sub(r"\s+", " ", extracted_text or "").strip()
        if not normalized:
            return {
                "status": "failed",
                "extracted_chars": 0,
                "index_error": "No readable text extracted from document",
                "last_indexed_at": serialize_datetime_for_api(now_ist()),
            }
        return {
            "status": "indexed",
            "extracted_chars": len(normalized),
            "index_error": None,
            "last_indexed_at": serialize_datetime_for_api(now_ist()),
        }
    except Exception as exc:
        return {
            "status": "failed",
            "extracted_chars": 0,
            "index_error": str(exc),
            "last_indexed_at": serialize_datetime_for_api(now_ist()),
        }


def _extract_text_from_url_content(content_type: str, raw_text: str) -> str:
    text = str(raw_text or "")
    if "html" in str(content_type or "").lower():
        text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.IGNORECASE)
        text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def _store_web_connector_snapshot(
    user_id: str,
    source_url: str,
    source_language: Optional[str] = None,
) -> Dict[str, Any]:
    now = now_ist()
    y = now.strftime("%Y")
    m = now.strftime("%m")
    parsed = urlparse(source_url)
    hostname = parsed.netloc or "web"
    path_slug = re.sub(r"[^A-Za-z0-9._-]+", "_", (parsed.path or "/").strip("/")) or "index"
    safe_name = _sanitize_filename(f"{hostname}_{path_slug}.txt")
    stem = Path(safe_name).stem or "document"
    upload_id = uuid4().hex
    stored_name = f"{stem}_{now.strftime('%Y%m%d%H%M%S')}_{upload_id[:8]}.txt"
    rel_path = os.path.join("knowledge", user_id, y, m, stored_name)
    abs_path = _safe_join(str(KNOWLEDGE_UPLOADS_ROOT), rel_path)

    try:
        response = requests.get(source_url, timeout=20, headers={"User-Agent": "WinAssist Knowledge Sync/1.0"})
        response.raise_for_status()
    except requests.RequestException as exc:
        raise HTTPException(status_code=400, detail=f"Failed to fetch URL: {exc}") from exc

    extracted_text = _extract_text_from_url_content(
        response.headers.get("content-type") or "text/html",
        response.text,
    )
    if not extracted_text:
        raise HTTPException(status_code=400, detail="No readable text could be extracted from the provided URL")

    Path(abs_path).write_text(extracted_text, encoding="utf-8")
    metadata = {
        "id": upload_id,
        "title": source_url,
        "filename": f"{hostname}.txt",
        "stored_filename": stored_name,
        "relative_path": rel_path,
        "mime": "text/plain",
        "size": len(extracted_text.encode("utf-8")),
        "source_type": "url",
        "source_url": source_url,
        "sync_status": "synced",
        "sync_error": None,
        "source_language": (source_language or "").strip() or None,
        "created_at": serialize_datetime_for_api(now),
        "updated_at": serialize_datetime_for_api(now),
        "last_synced_at": serialize_datetime_for_api(now),
    }
    metadata.update(_index_document(abs_path))
    metadata["sync_status"] = "synced" if metadata.get("status") == "indexed" else "failed"
    metadata["sync_error"] = metadata.get("index_error")
    return metadata


@router.post("/uploads", summary="Upload knowledge document")
async def upload_knowledge_document(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    workspace_id: Optional[str] = Form(None),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])

    allowed_types = {
        "application/pdf",
        "text/plain",
        "text/markdown",
        "text/html",
        "text/csv",
        "application/json",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/msword",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported content type: {file.content_type}",
        )

    now = now_ist()
    y = now.strftime("%Y")
    m = now.strftime("%m")
    original_name = file.filename or "document"
    safe_name = _sanitize_filename(original_name)
    stem = Path(safe_name).stem or "document"
    suffix = Path(safe_name).suffix
    upload_id = uuid4().hex
    stored_name = f"{stem}_{now.strftime('%Y%m%d%H%M%S')}_{upload_id[:8]}{suffix}"
    rel_path = os.path.join("knowledge", user_id, y, m, stored_name)
    abs_path = _safe_join(str(KNOWLEDGE_UPLOADS_ROOT), rel_path)

    data = await file.read()
    try:
        with open(abs_path, "wb") as f:
            f.write(data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save upload: {str(e)}")

    metadata = {
        "id": upload_id,
        "workspace_id": workspace_id,
        "title": title or original_name,
        "filename": original_name,
        "stored_filename": stored_name,
        "relative_path": rel_path,
        "mime": file.content_type,
        "size": len(data),
        "source_type": "file",
        "source_url": None,
        "sync_status": "synced",
        "sync_error": None,
        "source_language": None,
        "created_at": serialize_datetime_for_api(now),
        "updated_at": serialize_datetime_for_api(now),
        "last_synced_at": serialize_datetime_for_api(now),
    }
    metadata.update(_index_document(abs_path))
    metadata["sync_error"] = metadata.get("index_error")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        return await upsert_knowledge_document(conn, user_id, metadata)


@router.post("/urls/import", summary="Import knowledge document from URL connector")
async def import_knowledge_url(
    body: KnowledgeUrlImportBody,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    metadata = _store_web_connector_snapshot(
        user_id,
        str(body.source_url or "").strip(),
        body.source_language,
    )
    metadata["workspace_id"] = body.workspace_id
    metadata["title"] = (body.title or metadata.get("title") or body.source_url).strip()
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        return await upsert_knowledge_document(conn, user_id, metadata)


@router.get("/uploads", summary="List uploaded knowledge documents")
async def list_knowledge_documents(
    workspace_id: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        return await list_knowledge_document_records(conn, str(current_user["id"]), workspace_id)


@router.delete("/uploads/{upload_id}", summary="Delete knowledge document")
async def delete_knowledge_document(
    upload_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        target = await get_knowledge_document(conn, user_id, upload_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Document not found")

        relative_path = target.get("relative_path") or ""
        abs_path = _resolve_user_relative_path(user_id, relative_path)
        try:
            if abs_path.exists():
                abs_path.unlink()
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to delete document: {exc}")

        deleted = await delete_knowledge_document_record(conn, user_id, upload_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Document not found")
    return {"deleted": True, "id": upload_id}


@router.post("/uploads/{upload_id}/reprocess", summary="Reprocess knowledge document")
async def reprocess_knowledge_document(
    upload_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        target = await get_knowledge_document(conn, user_id, upload_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Document not found")

        abs_path = _resolve_user_relative_path(user_id, target.get("relative_path") or "")
        if str(target.get("source_type") or "file") == "url" and target.get("source_url"):
            try:
                response = requests.get(
                    str(target.get("source_url") or "").strip(),
                    timeout=20,
                    headers={"User-Agent": "WinAssist Knowledge Sync/1.0"},
                )
                response.raise_for_status()
                refreshed_text = _extract_text_from_url_content(
                    response.headers.get("content-type") or "text/html",
                    response.text,
                )
            except requests.RequestException as exc:
                raise HTTPException(status_code=400, detail=f"Failed to sync URL source: {exc}") from exc

            if not refreshed_text:
                raise HTTPException(status_code=400, detail="No readable text could be extracted from the URL source")

            Path(abs_path).write_text(refreshed_text, encoding="utf-8")
            updated = {
                **target,
                "size": len(refreshed_text.encode("utf-8")),
                "sync_status": "synced",
                "sync_error": None,
                "last_synced_at": serialize_datetime_for_api(now_ist()),
            }
            updated.update(_index_document(str(abs_path)))
            updated["sync_status"] = "synced" if updated.get("status") == "indexed" else "failed"
            updated["sync_error"] = updated.get("index_error")
            updated["updated_at"] = serialize_datetime_for_api(now_ist())
            return await upsert_knowledge_document(conn, user_id, updated)

        updated = {**target, **_index_document(str(abs_path))}
        updated["updated_at"] = serialize_datetime_for_api(now_ist())
        updated["sync_error"] = updated.get("index_error")
        return await upsert_knowledge_document(conn, user_id, updated)


@router.get("/collections", summary="List knowledge collections")
async def list_knowledge_collections(
    workspace_id: Optional[str] = None,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        return await list_knowledge_collection_records(conn, str(current_user["id"]), workspace_id)


@router.post("/collections", summary="Create knowledge collection")
async def create_knowledge_collection(
    body: KnowledgeCollectionBody,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    collection_id = body.id or uuid4().hex
    now = serialize_datetime_for_api(now_ist())
    collection = {
        "id": collection_id,
        "workspace_id": body.workspace_id,
        "name": body.name.strip(),
        "description": (body.description or "").strip(),
        "documentIds": [str(value) for value in body.documentIds if value],
        "botIds": [str(value) for value in body.botIds if value],
        "created_at": now,
        "updated_at": now,
    }
    if not collection["name"]:
        raise HTTPException(status_code=400, detail="Collection name is required")
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        return await upsert_knowledge_collection(conn, user_id, collection)


@router.put("/collections/{collection_id}", summary="Update knowledge collection")
async def update_knowledge_collection(
    collection_id: str,
    body: KnowledgeCollectionBody,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        existing = await get_knowledge_collection(conn, user_id, collection_id)
        if existing is None:
            raise HTTPException(status_code=404, detail="Collection not found")

        updated = {
            **existing,
            "workspace_id": body.workspace_id,
            "name": body.name.strip(),
            "description": (body.description or "").strip(),
            "documentIds": [str(value) for value in body.documentIds if value],
            "botIds": [str(value) for value in body.botIds if value],
            "updated_at": serialize_datetime_for_api(now_ist()),
        }
        if not updated["name"]:
            raise HTTPException(status_code=400, detail="Collection name is required")
        return await upsert_knowledge_collection(conn, user_id, updated)


@router.delete("/collections/{collection_id}", summary="Delete knowledge collection")
async def delete_knowledge_collection(
    collection_id: str,
    workspace_id: Optional[str] = None,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    del workspace_id
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        deleted = await delete_knowledge_collection_record(conn, str(current_user["id"]), collection_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Collection not found")
    return {"deleted": True, "id": collection_id}


@router.post("/retrieval/test", summary="Run retrieval test on a document")
async def test_knowledge_retrieval(
    body: RetrievalTestRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = str(current_user["id"])
    file_path = None
    if body.collection_id:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            collection = await get_knowledge_collection(conn, user_id, body.collection_id)
            if collection is None:
                raise HTTPException(status_code=404, detail="Collection not found")
            bound_documents = await get_collection_documents(
                conn,
                user_id,
                body.workspace_id,
                [body.collection_id],
            )
        combined_matches: List[Dict[str, Any]] = []
        for entry in bound_documents:
            doc = entry.get("document") or {}
            doc_file_path = str(
                _resolve_user_relative_path(user_id, doc.get("relative_path") or "")
            )
            result = run_rag_search(
                query=body.query,
                file_path=doc_file_path,
                chunk_size=body.chunk_size,
                chunk_overlap=body.chunk_overlap,
                top_k=body.top_k,
            )
            if result.get("error"):
                continue
            for match in result.get("matches", []):
                combined_matches.append(
                    {
                        **match,
                        "document_id": doc.get("id"),
                        "document_title": doc.get("title") or doc.get("filename"),
                        "relative_path": doc.get("relative_path"),
                        "collection_name": entry.get("collection_name"),
                    }
                )
        ranked_matches = sorted(
            combined_matches,
            key=lambda item: (item.get("score", 0), item.get("density_score", 0)),
            reverse=True,
        )[: max(1, body.top_k)]
        return {
            "query": body.query,
            "knowledge_source": collection.get("name"),
            "chunk_size": body.chunk_size,
            "chunk_overlap": body.chunk_overlap,
            "top_k": body.top_k,
            "total_chunks": len(combined_matches),
            "matches": ranked_matches,
        }
    if body.relative_path:
        file_path = str(_resolve_user_relative_path(user_id, body.relative_path))

    result = run_rag_search(
        query=body.query,
        file_path=file_path,
        knowledge_text=body.knowledge_text,
        chunk_size=body.chunk_size,
        chunk_overlap=body.chunk_overlap,
        top_k=body.top_k,
    )
    if result.get("error"):
        raise HTTPException(status_code=400, detail=result["error"])
    return result
