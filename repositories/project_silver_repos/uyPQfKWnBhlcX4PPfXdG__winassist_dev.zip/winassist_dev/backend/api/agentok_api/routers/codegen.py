from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse
import traceback
from pydantic import BaseModel
from typing import List, Optional, Any
from ..models import Project, ToolVariable
from ..services.codegen import CodegenService

from ..services.database import DatabaseClient
from ..dependencies import get_database_client, get_current_user

router = APIRouter()


class ToolGenerateRequest(BaseModel):
    name: str
    description: Optional[str] = None
    variables: List[ToolVariable] = []
    code: Optional[str] = None


class ToolExtractRequest(BaseModel):
    code: str


@router.post("")
async def generate_code(
    project: Project,
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Generate Python code from a project flow.
    
    Args:
        project: The project containing the flow definition
        db: Database client dependency
        
    Returns:
        JSON response with the generated code
    """
    try:
        print(f"Generating code for project: {project.id} - {project.name}")
        print(f"Flow has {len(project.flow.nodes)} nodes and {len(project.flow.edges)} edges")
        
        # Initialize codegen service
        codegen_service = CodegenService(db)
        
        # Generate code (await the async method)
        code = await codegen_service.generate_project(project)
        
        print(f"Successfully generated {len(code)} characters of code")
        
        return JSONResponse(
            content={"code": code},
            status_code=200
        )
        
    except ValueError as e:
        # Validation errors (bad data)
        print(f"Validation error: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=422,
            detail=f"Validation error: {str(e)}"
        )
        
    except FileNotFoundError as e:
        # Template or file not found
        print(f"File not found error: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail=f"Template error: {str(e)}"
        )
        
    except Exception as e:
        # General server error
        print(f"Error in codegen endpoint: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@router.post("/tool", summary="Generate tool code")
async def generate_tool_code(
    tool_request: ToolGenerateRequest,
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Generate Python code for a tool using AI.
    
    Args:
        tool_request: The tool request containing name, description, and variables
        db: Database client dependency
        
    Returns:
        JSON response with the generated code
    """
    try:
        codegen_service = CodegenService(db)
        
        # Convert ToolGenerateRequest to Tool-like object for generate_tool
        # generate_tool expects a Tool object with signatures, but we have variables
        # Create a mock Tool object with signatures derived from variables
        class MockTool:
            def __init__(self, name, description, variables):
                self.name = name
                self.description = description or ""
                # Convert variables to signatures format expected by generate_tool
                self.signatures = []
                for var in variables:
                    # Determine type from variable value
                    var_type = "str"  # default
                    if isinstance(var.value, bool):
                        var_type = "bool"
                    elif isinstance(var.value, int):
                        var_type = "int"
                    elif isinstance(var.value, float):
                        var_type = "float"
                    elif isinstance(var.value, list):
                        var_type = "list"
                    elif isinstance(var.value, dict):
                        var_type = "dict"
                    elif var.value is None and hasattr(var, 'default') and var.default is not None:
                        var_type = type(var.default).__name__
                    
                    self.signatures.append({
                        "name": var.name,
                        "type": var_type,
                        "description": var.description or ""
                    })
        
        mock_tool = MockTool(
            tool_request.name,
            tool_request.description,
            tool_request.variables
        )
        
        result = codegen_service.generate_tool(mock_tool)
        return JSONResponse(
            content=result,
            status_code=200
        )
    except Exception as e:
        print(f"Error generating tool code: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate tool code: {str(e)}"
        )


@router.post("/extract", summary="Extract tool metadata from code")
async def extract_tool_meta(
    request: ToolExtractRequest,
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Extract metadata (function name, description, parameters) from Python code.
    
    Args:
        request: The code to extract metadata from
        db: Database client dependency
        
    Returns:
        JSON response with extracted metadata
    """
    try:
        codegen_service = CodegenService(db)
        result = codegen_service.extract_tool_meta(request.code)
        return JSONResponse(
            content=result,
            status_code=200
        )
    except Exception as e:
        print(f"Error extracting tool metadata: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to extract tool metadata: {str(e)}"
        )