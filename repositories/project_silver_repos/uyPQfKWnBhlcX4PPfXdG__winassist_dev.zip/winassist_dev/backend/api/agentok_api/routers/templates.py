from typing import List, Optional
from uuid import UUID
from datetime import datetime
import json

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from ..dependencies import get_database_client, get_current_user
from ..services.database import DatabaseClient
from ..utils.apikey import generate_bot_api_key

router = APIRouter()


class Template(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    project: dict
    project_id: Optional[UUID] = None
    project_type: Optional[str] = None
    workspace_id: Optional[UUID] = None
    user_id: Optional[UUID] = None
    is_published: bool
    rating_sum: int
    rating_count: int
    created_at: datetime
    updated_at: datetime
    can_delete: Optional[bool] = None

    class Config:
        from_attributes = True


class PublishTemplateRequest(BaseModel):
    """Payload to publish a project as a reusable template."""

    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None


class RateTemplateRequest(BaseModel):
    rating: int = Field(..., ge=1, le=5, description="Rating between 1 and 5")


class UseTemplateRequest(BaseModel):
    """Optional workspace to create the new project in. If omitted, user's default workspace is used."""
    workspace_id: Optional[UUID] = None


async def _get_user_id(current_user: dict) -> UUID:
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            return UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )
    return user_id


async def _ensure_admin_or_owner(
    conn, workspace_id: Optional[UUID], user_id: UUID
) -> None:
    """
    Ensure the caller is allowed to publish in this workspace:
    - If workspace_id is null: user must be the project owner (handled by caller)
    - If workspace_id is set: role must be owner or admin.
    """
    if workspace_id is None:
        return

    row = await conn.fetchrow(
        """
        SELECT role
        FROM workspace_members
        WHERE workspace_id = $1 AND user_id = $2
        """,
        workspace_id,
        user_id,
    )
    if not row or row["role"] not in ("owner", "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only workspace owner or admin can publish templates",
        )


async def _can_delete_template(conn, workspace_id: Optional[UUID], template_owner_id: Optional[UUID], user_id: UUID) -> bool:
    if workspace_id is None:
        return template_owner_id == user_id

    row = await conn.fetchrow(
        """
        SELECT role
        FROM workspace_members
        WHERE workspace_id = $1 AND user_id = $2
        """,
        workspace_id,
        user_id,
    )
    return bool(row and row["role"] in ("owner", "admin"))


async def _ensure_templates_schema(conn) -> None:
    """
    Keep the templates feature compatible with older local databases that were
    created before publish/rating fields were added.
    """
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS templates (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            category VARCHAR(100),
            project JSONB DEFAULT '{}',
            project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            project_type VARCHAR(50),
            workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
            user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
            is_published BOOLEAN DEFAULT FALSE,
            rating_sum INTEGER DEFAULT 0,
            rating_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        )
        """
    )
    await conn.execute(
        """
        ALTER TABLE templates
            ADD COLUMN IF NOT EXISTS category VARCHAR(100),
            ADD COLUMN IF NOT EXISTS project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS project_type VARCHAR(50),
            ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES persons(id) ON DELETE SET NULL,
            ADD COLUMN IF NOT EXISTS is_published BOOLEAN DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS rating_sum INTEGER DEFAULT 0,
            ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0
        """
    )
    await conn.execute(
        """
        UPDATE templates
        SET
            is_published = COALESCE(is_published, FALSE),
            rating_sum = COALESCE(rating_sum, 0),
            rating_count = COALESCE(rating_count, 0)
        WHERE is_published IS NULL
           OR rating_sum IS NULL
           OR rating_count IS NULL
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_templates_name ON templates(name);
        CREATE INDEX IF NOT EXISTS idx_templates_project_type ON templates(project_type);
        CREATE INDEX IF NOT EXISTS idx_templates_is_published ON templates(is_published)
        """
    )
    await conn.execute(
        """
        CREATE TABLE IF NOT EXISTS template_ratings (
            template_id INTEGER NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
            user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW(),
            PRIMARY KEY (template_id, user_id)
        )
        """
    )
    await conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_template_ratings_template_id ON template_ratings(template_id);
        CREATE INDEX IF NOT EXISTS idx_template_ratings_user_id ON template_ratings(user_id)
        """
    )


@router.post(
    "/projects/{project_id}/publish",
    response_model=Template,
    status_code=status.HTTP_201_CREATED,
    summary="Publish a project as a template",
)
async def publish_project_as_template(
    project_id: UUID,
    body: PublishTemplateRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Publish a backend (AI agent) or chatflow project as a template.

    Only the project owner or a workspace owner/admin can publish.
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()

    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        # Load project and validate ownership / workspace membership
        project = await conn.fetchrow(
            """
            SELECT id, user_id, name, description, flow, project_type, workspace_id
            FROM projects
            WHERE id = $1
            """,
            project_id,
        )
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Project not found"
            )

        project_dict = dict(project)
        project_owner_id = project_dict["user_id"]
        workspace_id = project_dict.get("workspace_id")

        # If project has workspace, enforce workspace role; otherwise ensure caller is owner
        if workspace_id:
            await _ensure_admin_or_owner(conn, workspace_id, user_id)
        else:
            if project_owner_id != user_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Only the project owner can publish this template",
                )

        # Insert or update template row for this project
        name = body.name or project_dict["name"]
        description = body.description or project_dict.get("description")

        # Store full project snapshot as JSON string to avoid codec issues
        project_snapshot = json.dumps(project_dict, default=str)

        # Look for an existing template for this project
        existing = await conn.fetchrow(
            "SELECT * FROM templates WHERE project_id = $1",
            project_dict["id"],
        )

        if existing:
            # Republish updates the same template row instead of creating a new one
            row = await conn.fetchrow(
                """
                UPDATE templates
                SET 
                    name = $1,
                    description = $2,
                    project = $3,
                    project_type = $4,
                    workspace_id = $5,
                    user_id = $6,
                    category = $7,
                    is_published = TRUE,
                    updated_at = NOW()
                WHERE id = $8
                RETURNING *
                """,
                name,
                description,
                project_snapshot,
                project_dict.get("project_type"),
                workspace_id,
                user_id,
                body.category,
                existing["id"],
            )
        else:
            # First time publish: create a new template row
            row = await conn.fetchrow(
                """
                INSERT INTO templates (
                    name,
                    description,
                    category,
                    project,
                    project_id,
                    project_type,
                    workspace_id,
                    user_id,
                    is_published,
                    rating_sum,
                    rating_count,
                    created_at,
                    updated_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8,
                    TRUE,
                    0,
                    0,
                    NOW(),
                    NOW()
                )
                RETURNING *
                """,
                name,
                description,
                body.category,
                project_snapshot,
                project_dict["id"],
                project_dict.get("project_type"),
                workspace_id,
                user_id,
            )

        template = dict(row)
        # Decode stored JSON snapshot back into a dict for the response model
        raw_project = template.get("project")
        if isinstance(raw_project, str):
            try:
                template["project"] = json.loads(raw_project)
            except Exception:
                template["project"] = {}

        return template


@router.get(
    "/top",
    response_model=List[Template],
    summary="Get top templates by rating and type",
)
async def get_top_templates(
    project_type: str,
    limit: int = 6,
    db: DatabaseClient = Depends(get_database_client),
    current_user: dict = Depends(get_current_user),
):
    """
    Return top-N published templates for a given type (e.g. 'backend', 'frontend').
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        rows = await conn.fetch(
            """
            SELECT *
            FROM templates
            WHERE is_published = TRUE
              AND project_type = $1
            ORDER BY 
                CASE 
                    WHEN rating_count = 0 THEN 0
                    ELSE rating_sum::float / rating_count
                END DESC,
                created_at DESC
            LIMIT $2
            """,
            project_type,
            limit,
        )
        templates: List[dict] = []
        for row in rows:
            item = dict(row)
            raw_project = item.get("project")
            if isinstance(raw_project, str):
                try:
                    item["project"] = json.loads(raw_project)
                except Exception:
                    item["project"] = {}
            item["can_delete"] = await _can_delete_template(
                conn,
                item.get("workspace_id"),
                item.get("user_id"),
                user_id,
            )
            templates.append(item)
        return templates


@router.get(
    "",
    response_model=List[Template],
    summary="List published templates (optionally filtered by type)",
)
async def list_templates(
    project_type: Optional[str] = Query(None, description="backend or frontend"),
    limit: int = Query(50, ge=1, le=200),
    db: DatabaseClient = Depends(get_database_client),
    current_user: dict = Depends(get_current_user),
):
    """
    List published templates visible to any authenticated user.
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        if project_type:
            rows = await conn.fetch(
                """
                SELECT *
                FROM templates
                WHERE is_published = TRUE
                  AND project_type = $1
                ORDER BY updated_at DESC
                LIMIT $2
                """,
                project_type,
                limit,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT *
                FROM templates
                WHERE is_published = TRUE
                ORDER BY updated_at DESC
                LIMIT $1
                """,
                limit,
            )

        templates: List[dict] = []
        for row in rows:
            item = dict(row)
            raw_project = item.get("project")
            if isinstance(raw_project, str):
                try:
                    item["project"] = json.loads(raw_project)
                except Exception:
                    item["project"] = {}
            item["can_delete"] = await _can_delete_template(
                conn,
                item.get("workspace_id"),
                item.get("user_id"),
                user_id,
            )
            templates.append(item)
        return templates


@router.post(
    "/{template_id}/rate",
    response_model=Template,
    summary="Rate a template (1-5 stars)",
)
async def rate_template(
    template_id: int,
    body: RateTemplateRequest,
    db: DatabaseClient = Depends(get_database_client),
    current_user: dict = Depends(get_current_user),
):
    """
    Rate a published template. One rating per user per template; submitting again
    updates the user's existing rating.
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        # Ensure template exists and is published
        tpl = await conn.fetchrow(
            """
            SELECT id, rating_sum, rating_count
            FROM templates
            WHERE id = $1 AND is_published = TRUE
            """,
            template_id,
        )
        if not tpl:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Template not found"
            )

        existing = await conn.fetchrow(
            """
            SELECT rating FROM template_ratings
            WHERE template_id = $1 AND user_id = $2
            """,
            template_id,
            user_id,
        )

        if existing:
            old_rating = int(existing["rating"])
            await conn.execute(
                """
                UPDATE template_ratings
                SET rating = $1, updated_at = NOW()
                WHERE template_id = $2 AND user_id = $3
                """,
                body.rating,
                template_id,
                user_id,
            )
            await conn.execute(
                """
                UPDATE templates
                SET rating_sum = rating_sum - $1 + $2, updated_at = NOW()
                WHERE id = $3
                """,
                old_rating,
                body.rating,
                template_id,
            )
        else:
            await conn.execute(
                """
                INSERT INTO template_ratings (template_id, user_id, rating)
                VALUES ($1, $2, $3)
                """,
                template_id,
                user_id,
                body.rating,
            )
            await conn.execute(
                """
                UPDATE templates
                SET rating_sum = rating_sum + $1, rating_count = rating_count + 1,
                    updated_at = NOW()
                WHERE id = $2
                """,
                body.rating,
                template_id,
            )

        row = await conn.fetchrow(
            "SELECT * FROM templates WHERE id = $1", template_id
        )
        template = dict(row)
        raw_project = template.get("project")
        if isinstance(raw_project, str):
            try:
                template["project"] = json.loads(raw_project)
            except Exception:
                template["project"] = {}

        return template


@router.delete(
    "/{template_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a template",
)
async def delete_template(
    template_id: int,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Delete a template.

    Allowed for:
    - the template owner when no workspace is attached
    - workspace owner/admin when the template belongs to a workspace
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()

    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        template = await conn.fetchrow(
            """
            SELECT id, user_id, workspace_id
            FROM templates
            WHERE id = $1
            """,
            template_id,
        )
        if not template:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Template not found",
            )

        template_owner_id = template["user_id"]
        workspace_id = template["workspace_id"]

        if workspace_id:
            await _ensure_admin_or_owner(conn, workspace_id, user_id)
        elif template_owner_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only the template owner can delete this template",
            )

        await conn.execute(
            "DELETE FROM templates WHERE id = $1",
            template_id,
        )

    return None


@router.post(
    "/{template_id}/use",
    status_code=status.HTTP_201_CREATED,
    summary="Create a new project from a published template (any authenticated user)",
)
async def use_template(
    template_id: int,
    body: Optional[UseTemplateRequest] = None,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Create a new project by copying a published template. The new project belongs to the
    current user (in their workspace or default workspace). Any authenticated user can
    use any published template; no need to be in the publisher's workspace.
    """
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()

    async with pool.acquire() as conn:
        await _ensure_templates_schema(conn)
        row = await conn.fetchrow(
            """
            SELECT id, name, description, project, project_type
            FROM templates
            WHERE id = $1 AND is_published = TRUE
            """,
            template_id,
        )
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Template not found or not published",
            )

        snapshot = row["project"]
        if isinstance(snapshot, str):
            try:
                snapshot = json.loads(snapshot)
            except Exception:
                snapshot = {}
        if not isinstance(snapshot, dict):
            snapshot = {}

        name = row["name"] or "Untitled"
        description = row["description"] or ""
        project_type = row["project_type"] or "backend"
        flow = snapshot.get("flow")
        # Template snapshot may have flow as dict (from JSONB) or as JSON string (if project had flow as string when published)
        if isinstance(flow, str):
            try:
                flow = json.loads(flow)
            except Exception:
                flow = {}
        if flow is not None and not isinstance(flow, dict):
            flow = {}
        if flow is None:
            flow = {}

        workspace_id = None
        if body is not None and getattr(body, "workspace_id", None) is not None:
            workspace_id = body.workspace_id
            membership = await conn.fetchrow(
                """
                SELECT 1 FROM workspace_members
                WHERE workspace_id = $1 AND user_id = $2 AND role IN ('owner', 'admin', 'member')
                """,
                workspace_id,
                user_id,
            )
            if not membership:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not a member of this workspace",
                )
        else:
            from ..routers.workspaces import _ensure_default_workspace
            default_ws = await _ensure_default_workspace(db, user_id)
            workspace_id = default_ws.id

        flow_json = json.dumps(flow)
        api_key = generate_bot_api_key() if project_type == "backend" else None

        new_project = await conn.fetchrow(
            """
            INSERT INTO projects (user_id, workspace_id, name, description, flow, project_type, api_key, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7, NOW(), NOW())
            RETURNING id, user_id, workspace_id, name, description, flow, project_type, api_key, created_at, updated_at
            """,
            user_id,
            workspace_id,
            name,
            description,
            flow_json,
            project_type,
            api_key,
        )

        out = dict(new_project)
        if isinstance(out.get("flow"), str):
            try:
                out["flow"] = json.loads(out["flow"])
            except Exception:
                out["flow"] = {}
        return out

