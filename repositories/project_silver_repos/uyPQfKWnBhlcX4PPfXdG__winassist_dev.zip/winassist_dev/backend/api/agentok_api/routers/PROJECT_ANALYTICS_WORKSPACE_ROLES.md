# Project Analytics – Workspace & Role Behavior

All project analytics features respect workspace membership and roles.

## Roles that can view analytics

- **owner**, **admin**, **member**, **viewer** (in the project’s workspace) can **view** project analytics.
- Viewers have read-only access: they can see analytics but cannot edit projects or flows.

## How each feature behaves

### 1. **Project list (dropdown / “Projects at a glance”)**

- **With workspace selected**  
  - Caller must be a **member of that workspace** (any role).  
  - Only projects in that workspace are returned (frontend + backend).  
  - Used by: `GET /project-analytics/stats?workspace_id=...` (no `project_id`), `GET /project-analytics/all-projects?workspace_id=...`.

- **Without workspace (personal)**  
  - Only the caller’s **personal projects** (where `user_id` = current user) are returned.

### 2. **Single project analytics (selecting one project)**

- Caller must either:
  - be the **project owner** (personal project), or  
  - be in the project’s **workspace** with a role in **owner, admin, member, viewer**.

- Applies to all endpoints that take `project_id`, e.g.:
  - `GET /project-analytics/stats?project_id=...`
  - `GET /project-analytics/nodes?project_id=...`
  - `GET /project-analytics/engagement-timeline?project_id=...`
  - `GET /project-analytics/messages-timeline?project_id=...`
  - Funnel, session analytics, bounce rate, alerts, etc.

### 3. **All-projects dropdown**

- **`GET /project-analytics/all-projects`**
  - With `workspace_id`: caller must be a workspace member (any role); returns all projects in that workspace (frontend + backend).  
  - Without `workspace_id`: returns only the caller’s personal projects.

### 4. **Frontend projects list**

- **`GET /project-analytics/frontend-projects`**
  - Same workspace/personal rules as above; returns only **frontend** projects (for backward compatibility).

## Summary

| Context              | Who can see data                                                                 |
|----------------------|-----------------------------------------------------------------------------------|
| Workspace overview   | Any workspace member (owner, admin, member, viewer) for that workspace           |
| Single project       | Project owner, or workspace member with role in owner / admin / member / viewer  |
| Personal (no workspace) | Only the current user’s own projects                                           |

Backend and frontend projects both follow these rules; counts and access are scoped by workspace and role as above.
