import json
import uuid
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ..dependencies import get_current_user, get_database_client
from ..models import (
    ConnectorConnectionSummary,
    ConnectorDefinition,
    ConnectorSendTextRequest,
)
from ..services.connector_registry import (
    get_whatsapp_connector_definition,
    list_connector_definitions,
)
from ..services.database import DatabaseClient
from ..services.message_transport import send_connector_text
from ..services.secret_store import connector_credentials_secret, mask_secret_hint

router = APIRouter()


async def _get_user_id(current_user: dict) -> UUID:
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            return UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid user ID format")
    return user_id


async def _fetch_workspace_role(conn, workspace_id: UUID, user_id: UUID) -> Optional[str]:
    row = await conn.fetchrow(
        """
        SELECT role
        FROM workspace_members
        WHERE workspace_id = $1 AND user_id = $2
        """,
        workspace_id,
        user_id,
    )
    return str(row["role"]) if row and row.get("role") else None


def _normalize_connector_connection_row(row: Dict[str, Any]) -> Dict[str, Any]:
    data = dict(row)
    definition = get_whatsapp_connector_definition(data.get("provider"))
    display_name = (
        str(data.get("name") or "").strip()
        or str(data.get("display_phone_number") or "").strip()
        or str(data.get("business_phone_number") or "").strip()
        or "WhatsApp connection"
    )
    metadata = data.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    return {
        "id": data["id"],
        "connector_key": definition["connector_key"],
        "channel_key": definition["channel_key"],
        "provider_key": definition["provider_key"],
        "workspace_id": data.get("workspace_id"),
        "project_id": data.get("project_id"),
        "bot_project_id": data.get("bot_project_id"),
        "display_name": display_name,
        "external_reference": str(data.get("display_phone_number") or data.get("phone_number_id") or ""),
        "connection_status": str(data.get("connection_status") or "unknown"),
        "health_status": data.get("health_status"),
        "setup_route": definition.get("setup_route"),
        "status_route": definition.get("status_route"),
        "access_token_masked": mask_secret_hint(data.get("access_token_hint")),
        "metadata": metadata,
        "capabilities": definition.get("capabilities") or {},
        "created_at": data.get("created_at"),
        "updated_at": data.get("updated_at"),
    }


async def _fetch_connector_connection_row(conn, connection_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT wc.*,
               wm.role AS member_role
        FROM whatsapp_connections wc
        LEFT JOIN workspace_members wm
          ON wm.workspace_id = wc.workspace_id
         AND wm.user_id = $2
        WHERE wc.id = $1
        """,
        connection_id,
        user_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Connector connection not found")
    data = dict(row)
    if data.get("workspace_id") is None and data.get("user_id") != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this connector connection")
    if data.get("workspace_id") is not None and data.get("member_role") is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the connector workspace")
    data.pop("member_role", None)
    return data


async def _fetch_connector_connection_with_token(conn, connection_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await _fetch_connector_connection_row(conn, connection_id, user_id)
    token = await conn.fetchval(
        """
        SELECT pgp_sym_decrypt(access_token_encrypted, $2::text)
        FROM whatsapp_connections
        WHERE id = $1
        """,
        connection_id,
        connector_credentials_secret(),
    )
    row["access_token"] = token
    return row


async def _log_whatsapp_connector_message(
    conn,
    *,
    connection_id: UUID,
    payload: Dict[str, Any],
    response: Dict[str, Any],
    to_number: str,
    error_text: Optional[str] = None,
) -> None:
    message_ids = response.get("messages") or []
    wa_message_id = message_ids[0].get("id") if message_ids and isinstance(message_ids[0], dict) else None
    await conn.execute(
        """
        INSERT INTO whatsapp_messages (
            id,
            connection_id,
            direction,
            wa_message_id,
            project_id,
            from_number,
            to_number,
            message_type,
            status,
            payload,
            response,
            error,
            created_at,
            updated_at
        )
        VALUES (
            $1, $2, 'outbound', $3, $4, $5, $6, 'text', $7, $8::jsonb, $9::jsonb, $10, NOW(), NOW()
        )
        ON CONFLICT (wa_message_id) DO UPDATE SET
            status = COALESCE(EXCLUDED.status, whatsapp_messages.status),
            response = COALESCE(EXCLUDED.response, whatsapp_messages.response),
            error = COALESCE(EXCLUDED.error, whatsapp_messages.error),
            updated_at = NOW()
        """,
        uuid.uuid4(),
        connection_id,
        wa_message_id,
        payload.get("project_id"),
        payload.get("from_number"),
        to_number,
        "error" if error_text else "sent",
        json.dumps(payload or {}),
        json.dumps(response or {}),
        error_text,
    )


@router.get("", response_model=List[ConnectorDefinition], summary="List available connector definitions")
async def list_connectors():
    return [ConnectorDefinition(**item) for item in list_connector_definitions()]


@router.get("/connections", response_model=List[ConnectorConnectionSummary], summary="List connector connections")
async def list_connector_connections(
    workspace_id: Optional[UUID] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        if workspace_id is not None:
            role = await _fetch_workspace_role(conn, workspace_id, user_id)
            if role is None:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of the workspace")
            rows = await conn.fetch(
                """
                SELECT *
                FROM whatsapp_connections
                WHERE workspace_id = $1
                ORDER BY updated_at DESC, created_at DESC
                """,
                workspace_id,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT wc.*
                FROM whatsapp_connections wc
                LEFT JOIN workspace_members wm
                  ON wm.workspace_id = wc.workspace_id
                 AND wm.user_id = $1
                WHERE wc.user_id = $1
                   OR wm.user_id = $1
                ORDER BY wc.updated_at DESC, wc.created_at DESC
                """,
                user_id,
            )
        return [ConnectorConnectionSummary(**_normalize_connector_connection_row(dict(row))) for row in rows]


@router.get("/connections/{connection_id}", response_model=ConnectorConnectionSummary, summary="Get connector connection summary")
async def get_connector_connection(
    connection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        row = await _fetch_connector_connection_row(conn, connection_id, user_id)
        return ConnectorConnectionSummary(**_normalize_connector_connection_row(row))


@router.post("/connections/{connection_id}/send-text", summary="Send text using connector transport")
async def send_connector_text_message(
    connection_id: UUID,
    body: ConnectorSendTextRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        connection = await _fetch_connector_connection_with_token(conn, connection_id, user_id)
        definition = get_whatsapp_connector_definition(connection.get("provider"))
        payload_meta = {
            "connector_key": definition["connector_key"],
            "channel_key": definition["channel_key"],
            "to": body.to,
            "text": body.text,
            "preview_url": bool(body.preview_url),
            "send_payload": {
                "recipient_type": "individual",
                "to": body.to,
                "type": "text",
                "text": {
                    "preview_url": bool(body.preview_url),
                    "body": body.text,
                },
            },
            "project_id": str(connection.get("bot_project_id") or connection.get("project_id") or "") or None,
            "from_number": connection.get("display_phone_number") or connection.get("business_phone_number"),
        }
        try:
            response = await send_connector_text(
                connector_key=definition["connector_key"],
                connection=connection,
                to=body.to,
                text=body.text,
                preview_url=body.preview_url,
            )
            await _log_whatsapp_connector_message(
                conn,
                connection_id=connection_id,
                payload=payload_meta,
                response=response,
                to_number=body.to,
            )
            return {
                "ok": True,
                "message": "Connector text message sent successfully",
                "response": response,
            }
        except HTTPException as exc:
            await _log_whatsapp_connector_message(
                conn,
                connection_id=connection_id,
                payload=payload_meta,
                response={},
                to_number=body.to,
                error_text=str(exc.detail),
            )
            raise
