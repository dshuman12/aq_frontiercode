from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta
from uuid import UUID
import logging

from ..services.database import DatabaseClient
from ..dependencies import get_database_client, get_current_user
from ..utils.datetime import now_ist_naive, serialize_datetime_for_api

logger = logging.getLogger(__name__)
router = APIRouter()


class DashboardStats(BaseModel):
    total_backend_projects: int
    total_frontend_projects: int
    total_tools: int
    total_published_projects: int = 0
    total_chats: int
    total_backend_chats: int = 0
    total_frontend_chats: int = 0
    chats_per_backend_project: List[Dict[str, Any]]
    chats_per_frontend_project: List[Dict[str, Any]] = []
    most_used_backend_project: Optional[Dict[str, Any]] = None
    most_used_frontend_project: Optional[Dict[str, Any]] = None
    recent_activity: List[Dict[str, Any]]
    projects_created_by_month: List[Dict[str, Any]]
    chats_created_by_month: List[Dict[str, Any]]
    total_messages: int = 0
    total_backend_messages: int = 0
    total_frontend_messages: int = 0
    activity_summary: Dict[str, Any] = {}
    # New time-series fields for SaaS-ready dashboard
    sessions_per_day: List[Dict[str, Any]] = []
    messages_per_day: List[Dict[str, Any]] = []
    projects_created_by_month_detailed: List[Dict[str, Any]] = []
    error_rate_per_day: List[Dict[str, Any]] = []


@router.get('/stats', response_model=DashboardStats, summary="Get dashboard statistics")
async def get_dashboard_stats(
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
    days: int = Query(30, ge=1, le=180, description="Time range in days for time-series charts"),
    workspace_id: Optional[UUID] = Query(
        None, description="Optional workspace scope. When provided, stats are limited to this workspace."
    ),
):
    """
    Get comprehensive dashboard statistics for the current user.
    Includes project counts, tool counts, chat counts, and activity data.
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user_id = current_user["id"]
            # Handle different user_id formats - support both UUID and integer
            # Check if persons table uses UUID or integer to determine how to handle user_id
            persons_id_type = await conn.fetchval(
                """
                SELECT data_type 
                FROM information_schema.columns 
                WHERE table_schema = 'public' 
                AND table_name = 'persons' 
                AND column_name = 'id'
                """
            )
            
            user_id_param = user_id
            
            # If persons table uses UUID, ensure user_id is UUID
            if persons_id_type == 'uuid':
                if isinstance(user_id, str):
                    try:
                        user_id_param = UUID(user_id)
                    except ValueError:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invalid user ID format"
                        )
                elif isinstance(user_id, int):
                    # Integer user_id but table expects UUID - this shouldn't happen with new users
                    # But handle it gracefully by trying to find the UUID
                    logger.warning(f"Dashboard received integer user_id {user_id} but persons table uses UUID")
                    # Try to find UUID from persons table (if there's a mapping or if it's stored as text)
                    uuid_result = await conn.fetchval(
                        """
                        SELECT id FROM persons 
                        WHERE CAST(id AS text) = $1 OR id::text = $1
                        LIMIT 1
                        """,
                        str(user_id)
                    )
                    if uuid_result:
                        user_id_param = uuid_result
                    else:
                        # If not found, log warning but try to use integer (PostgreSQL might cast it)
                        logger.warning(f"Could not find UUID for integer user_id {user_id}, using integer directly")
                        user_id_param = user_id
                # If already UUID, use as-is
                elif isinstance(user_id, UUID):
                    user_id_param = user_id
            # If persons table uses integer, keep user_id as integer (or convert if needed)
            elif persons_id_type in ('integer', 'bigint', 'smallint'):
                if isinstance(user_id, int):
                    user_id_param = user_id
                elif isinstance(user_id, str):
                    # Try to parse as integer
                    try:
                        user_id_param = int(user_id)
                    except ValueError:
                        # If not integer, might be UUID string - try to use as-is
                        logger.warning(f"Could not parse user_id '{user_id}' as integer, using as string")
                        user_id_param = user_id
                elif isinstance(user_id, UUID):
                    # UUID provided but table uses integer - this is unusual, log and try to use as-is
                    logger.warning(f"Dashboard received UUID user_id {user_id} but persons table uses integer")
                    user_id_param = user_id
            else:
                # Unknown type or table doesn't exist - use user_id as-is
                logger.warning(f"Could not determine persons.id column type (got: {persons_id_type}), using user_id as-is")
                user_id_param = user_id

            # Time window for daily series
            now = now_ist_naive()
            start_ts = now - timedelta(days=days)

            # Optional workspace scope:
            # - When provided, ensure caller is a member and scope all stats to projects in that workspace.
            # - When omitted, aggregate across all workspaces the user can access + personal (workspace_id is NULL).
            workspace_scope_params = [user_id_param]
            workspace_project_filter_sql = ""
            workspace_project_filter_sql_for_chats = ""

            if workspace_id is not None:
                membership = await conn.fetchrow(
                    """
                    SELECT 1
                    FROM workspace_members
                    WHERE workspace_id = $1 AND user_id = $2
                    """,
                    workspace_id,
                    user_id_param,
                )
                if not membership:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Workspace not found",
                    )
                workspace_scope_params.append(workspace_id)
                # Used for projects table filters
                workspace_project_filter_sql = " AND workspace_id = $2"
                # Used for chats join on projects (from_project belongs to workspace)
                workspace_project_filter_sql_for_chats = " AND p.workspace_id = $2"

            # When workspace_id is provided, workspace_scope_params becomes [user_id, workspace_id].
            # Time-series queries also take start_ts; its placeholder index must adapt accordingly.
            start_ts_param = f"${len(workspace_scope_params) + 1}"

            # Get project counts
            backend_count = await conn.fetchval(
                f"""
                SELECT COUNT(*) FROM projects
                WHERE user_id = $1 AND project_type = 'backend'{workspace_project_filter_sql}
                """,
                *workspace_scope_params,
            )
            
            frontend_count = await conn.fetchval(
                f"""
                SELECT COUNT(*) FROM projects
                WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                """,
                *workspace_scope_params,
            )

            # Get tools count
            tools_count = await conn.fetchval(
                """
                SELECT COUNT(*) FROM tools
                WHERE user_id = $1
                """,
                user_id_param
            )

            # Get published projects count (projects this user has published as templates)
            total_published_projects = 0
            try:
                total_published_projects = await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM templates
                    WHERE is_published = TRUE AND user_id = $1
                    """,
                    user_id_param
                ) or 0
            except Exception:
                pass

            # Check analytics tables used by Chat Flow projects
            flow_messages_exists = await conn.fetchval(
                """
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_schema = 'public'
                    AND table_name = 'flow_messages'
                )
                """
            )
            flow_step_events_exists = await conn.fetchval(
                """
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_schema = 'public'
                    AND table_name = 'flow_step_events'
                )
                """
            )

            # Get total AI Agent chats count
            total_backend_chats = await conn.fetchval(
                f"""
                SELECT COUNT(*)
                FROM chats c
                LEFT JOIN projects p ON p.id = c.from_project::uuid
                WHERE c.user_id = $1{workspace_project_filter_sql_for_chats}
                """,
                *workspace_scope_params,
            ) or 0

            # Get total Chat Flow sessions count
            total_frontend_chats = 0
            if flow_step_events_exists:
                total_frontend_chats = await conn.fetchval(
                    f"""
                    SELECT COUNT(*) FROM (
                        SELECT DISTINCT project_id, session_id
                        FROM flow_step_events
                        WHERE project_id IN (
                            SELECT id FROM projects
                            WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                        )
                    ) sessions
                    """,
                    *workspace_scope_params
                ) or 0

            total_chats = total_backend_chats + total_frontend_chats

            # Get chats per backend project (with message counts for better ranking)
            # Rank by message count first (better indicator of actual usage)
            # Count user messages and bot/assistant messages separately
            chats_per_project = []
            try:
                # Check if chat_messages table exists and has project_id column
                table_exists = await conn.fetchval(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = 'chat_messages'
                    )
                    """
                )
                
                column_exists = False
                if table_exists:
                    column_exists = await conn.fetchval(
                        """
                        SELECT EXISTS (
                            SELECT FROM information_schema.columns 
                            WHERE table_schema = 'public' 
                            AND table_name = 'chat_messages'
                            AND column_name = 'project_id'
                        )
                        """
                    )
                
                if table_exists and column_exists:
                    # Use message count for ranking (primary metric)
                    # Count user messages (type='user') and bot messages (type='assistant' or 'bot')
                    chats_per_project = await conn.fetch(
                        f"""
                        SELECT 
                            p.id as project_id,
                            p.name as project_name,
                            COUNT(DISTINCT c.id) as chat_count,
                            COUNT(CASE WHEN m.type = 'user' THEN 1 END) as user_message_count,
                            COUNT(CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN 1 END) as bot_message_count,
                            COUNT(m.id) as total_message_count
                        FROM projects p
                        LEFT JOIN chats c ON c.from_project::uuid = p.id AND c.user_id = $1
                        LEFT JOIN chat_messages m ON m.project_id::uuid = p.id AND m.user_id = $1
                        WHERE p.user_id = $1 AND p.project_type = 'backend'{workspace_project_filter_sql}
                        GROUP BY p.id, p.name
                        ORDER BY total_message_count DESC, chat_count DESC, p.name
                        """,
                        *workspace_scope_params
                    )
                elif table_exists:
                    # chat_messages table exists but project_id column doesn't - use chat join
                    chats_per_project = await conn.fetch(
                        f"""
                        SELECT 
                            p.id as project_id,
                            p.name as project_name,
                            COUNT(DISTINCT c.id) as chat_count,
                            COUNT(CASE WHEN m.type = 'user' THEN 1 END) as user_message_count,
                            COUNT(CASE WHEN m.type IN ('assistant', 'bot', 'agent') THEN 1 END) as bot_message_count,
                            COUNT(m.id) as total_message_count
                        FROM projects p
                        LEFT JOIN chats c ON c.from_project::uuid = p.id AND c.user_id = $1
                        LEFT JOIN chat_messages m ON m.chat_id = c.id
                        WHERE p.user_id = $1 AND p.project_type = 'backend'{workspace_project_filter_sql}
                        GROUP BY p.id, p.name
                        ORDER BY total_message_count DESC, chat_count DESC, p.name
                        """,
                        *workspace_scope_params
                    )
                else:
                    # chat_messages table doesn't exist, use chat count only
                    logger.warning("chat_messages table does not exist, ranking by chat count only")
                    chats_per_project = await conn.fetch(
                        f"""
                        SELECT 
                            p.id as project_id,
                            p.name as project_name,
                            COUNT(c.id) as chat_count,
                            0 as user_message_count,
                            0 as bot_message_count,
                            0 as total_message_count
                        FROM projects p
                        LEFT JOIN chats c ON c.from_project::uuid = p.id AND c.user_id = $1
                        WHERE p.user_id = $1 AND p.project_type = 'backend'{workspace_project_filter_sql}
                        GROUP BY p.id, p.name
                        ORDER BY chat_count DESC, p.name
                        """,
                        *workspace_scope_params
                    )
            except Exception as e:
                # Fallback if chat_messages table doesn't exist - use chat count only
                logger.warning(f"Error querying chat_messages, using chat count only: {str(e)}")
                chats_per_project = await conn.fetch(
                    f"""
                    SELECT 
                        p.id as project_id,
                        p.name as project_name,
                        COUNT(c.id) as chat_count,
                        0 as user_message_count,
                        0 as bot_message_count,
                        0 as total_message_count
                    FROM projects p
                    LEFT JOIN chats c ON c.from_project::uuid = p.id AND c.user_id = $1
                    WHERE p.user_id = $1 AND p.project_type = 'backend'{workspace_project_filter_sql}
                    GROUP BY p.id, p.name
                    ORDER BY chat_count DESC, p.name
                    """,
                    *workspace_scope_params
                )

            # Get Chat Flow usage by project
            chats_per_frontend_project = []
            try:
                frontend_chat_count_expr = (
                    """
                    COALESCE((
                        SELECT COUNT(*) FROM (
                            SELECT DISTINCT session_id
                            FROM flow_step_events fse
                            WHERE fse.project_id = p.id
                        ) sessions
                    ), 0)
                    """
                    if flow_step_events_exists
                    else "0"
                )
                frontend_user_message_expr = (
                    """
                    COALESCE((
                        SELECT COUNT(*)
                        FROM flow_messages fm
                        WHERE fm.project_id = p.id AND fm.role = 'user'
                    ), 0)
                    """
                    if flow_messages_exists
                    else "0"
                )
                frontend_bot_message_expr = (
                    """
                    COALESCE((
                        SELECT COUNT(*)
                        FROM flow_messages fm
                        WHERE fm.project_id = p.id AND fm.role = 'assistant'
                    ), 0)
                    """
                    if flow_messages_exists
                    else "0"
                )
                frontend_total_message_expr = (
                    """
                    COALESCE((
                        SELECT COUNT(*)
                        FROM flow_messages fm
                        WHERE fm.project_id = p.id
                    ), 0)
                    """
                    if flow_messages_exists
                    else "0"
                )

                chats_per_frontend_project = await conn.fetch(
                    f"""
                    SELECT
                        p.id AS project_id,
                        p.name AS project_name,
                        {frontend_chat_count_expr} AS chat_count,
                        {frontend_user_message_expr} AS user_message_count,
                        {frontend_bot_message_expr} AS bot_message_count,
                        {frontend_total_message_expr} AS total_message_count
                    FROM projects p
                    WHERE p.user_id = $1 AND p.project_type = 'frontend'
                    {workspace_project_filter_sql}
                    ORDER BY total_message_count DESC, chat_count DESC, p.name
                    """,
                    *workspace_scope_params
                )
            except Exception as e:
                logger.warning(f"Error querying Chat Flow analytics: {str(e)}")
                chats_per_frontend_project = []

            # Get most used backend project (highest message count, then chat count)
            most_used_project = None
            if chats_per_project and len(chats_per_project) > 0:
                top_project = chats_per_project[0]
                total_message_count = top_project.get('total_message_count', 0) or 0
                user_message_count = top_project.get('user_message_count', 0) or 0
                bot_message_count = top_project.get('bot_message_count', 0) or 0
                chat_count = top_project.get('chat_count', 0) or 0
                
                # Consider project "used" if it has messages OR chats
                if total_message_count > 0 or chat_count > 0:
                    most_used_project = {
                        'project_id': top_project['project_id'],
                        'project_name': top_project['project_name'],
                        'chat_count': chat_count,
                        'message_count': total_message_count,
                        'user_message_count': user_message_count,
                        'bot_message_count': bot_message_count
                    }

            # Get most used Chat Flow project
            most_used_frontend_project = None
            if chats_per_frontend_project and len(chats_per_frontend_project) > 0:
                top_frontend_project = chats_per_frontend_project[0]
                frontend_total_message_count = top_frontend_project.get('total_message_count', 0) or 0
                frontend_user_message_count = top_frontend_project.get('user_message_count', 0) or 0
                frontend_bot_message_count = top_frontend_project.get('bot_message_count', 0) or 0
                frontend_chat_count = top_frontend_project.get('chat_count', 0) or 0

                if frontend_total_message_count > 0 or frontend_chat_count > 0:
                    most_used_frontend_project = {
                        'project_id': top_frontend_project['project_id'],
                        'project_name': top_frontend_project['project_name'],
                        'chat_count': frontend_chat_count,
                        'message_count': frontend_total_message_count,
                        'user_message_count': frontend_user_message_count,
                        'bot_message_count': frontend_bot_message_count
                    }

            # Get total AI Agent messages count (handle case where table might not exist)
            total_backend_messages = 0
            try:
                # Check if project_id column exists
                column_exists = await conn.fetchval(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.columns 
                        WHERE table_schema = 'public' 
                        AND table_name = 'messages'
                        AND column_name = 'project_id'
                    )
                    """
                )
                
                if column_exists:
                    # Use project_id for faster query
                    total_backend_messages = await conn.fetchval(
                        f"""
                        SELECT COUNT(*) FROM chat_messages
                        WHERE user_id = $1 AND project_id::uuid IN (
                            SELECT id FROM projects WHERE user_id = $1 AND project_type = 'backend'
                            {workspace_project_filter_sql}
                        )
                        """,
                        *workspace_scope_params
                    ) or 0
                else:
                    # Fallback to chat-based query
                    total_backend_messages = await conn.fetchval(
                        f"""
                        SELECT COUNT(*) FROM chat_messages m
                        JOIN chats c ON m.chat_id = c.id
                        WHERE c.user_id = $1 AND c.from_project::uuid IN (
                            SELECT id FROM projects WHERE user_id = $1 AND project_type = 'backend'
                            {workspace_project_filter_sql}
                        )
                        """,
                        *workspace_scope_params
                    ) or 0
            except Exception as e:
                logger.warning(f"chat_messages table not found or error querying: {str(e)}")
                total_backend_messages = 0

            total_frontend_messages = 0
            if flow_messages_exists:
                try:
                    total_frontend_messages = await conn.fetchval(
                        f"""
                        SELECT COUNT(*)
                        FROM flow_messages
                        WHERE project_id IN (
                            SELECT id FROM projects
                            WHERE user_id = $1 AND project_type = 'frontend'
                            {workspace_project_filter_sql}
                        )
                        """,
                        *workspace_scope_params
                    ) or 0
                except Exception as e:
                    logger.warning(f"flow_messages table not found or error querying: {str(e)}")
                    total_frontend_messages = 0

            total_messages = total_backend_messages + total_frontend_messages

            # Get activity summary (last 30 days)
            projects_30d = await conn.fetchval(
                f"""
                SELECT COUNT(*) FROM projects
                WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '30 days'{workspace_project_filter_sql}
                """,
                *workspace_scope_params
            )
            
            backend_chats_30d = await conn.fetchval(
                f"""
                SELECT COUNT(*)
                FROM chats c
                LEFT JOIN projects p ON p.id = c.from_project::uuid
                WHERE c.user_id = $1
                  AND c.created_at >= NOW() - INTERVAL '30 days'{workspace_project_filter_sql_for_chats}
                """,
                *workspace_scope_params
            ) or 0

            frontend_chats_30d = 0
            if flow_step_events_exists:
                frontend_chats_30d = await conn.fetchval(
                    f"""
                    SELECT COUNT(*) FROM (
                        SELECT project_id, session_id, MIN(created_at) AS first_seen_at
                        FROM flow_step_events
                        WHERE project_id IN (
                            SELECT id FROM projects
                            WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                        )
                        GROUP BY project_id, session_id
                        HAVING MIN(created_at) >= NOW() - INTERVAL '30 days'
                    ) sessions
                    """,
                    *workspace_scope_params
                ) or 0
            chats_30d = backend_chats_30d + frontend_chats_30d
            
            tools_30d = await conn.fetchval(
                """
                SELECT COUNT(*) FROM tools
                WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
                """,
                user_id_param
            )
            
            activity_summary = {
                'projects_last_30d': projects_30d or 0,
                'chats_last_30d': chats_30d or 0,
                'tools_last_30d': tools_30d or 0
            }

            # Get recent activity (last 10 activities)
            recent_projects = await conn.fetch(
                f"""
                SELECT 
                    id,
                    name,
                    project_type,
                    created_at,
                    'project_created' as activity_type
                FROM projects
                WHERE user_id = $1{workspace_project_filter_sql}
                ORDER BY created_at DESC
                LIMIT 5
                """,
                *workspace_scope_params
            )

            recent_chats = await conn.fetch(
                f"""
                SELECT 
                    c.id,
                    c.name,
                    c.created_at,
                    'chat_created' as activity_type
                FROM chats c
                LEFT JOIN projects p ON p.id = c.from_project::uuid
                WHERE c.user_id = $1{workspace_project_filter_sql_for_chats}
                ORDER BY created_at DESC
                LIMIT 5
                """,
                *workspace_scope_params
            )

            recent_tools = await conn.fetch(
                """
                SELECT 
                    id,
                    name,
                    created_at,
                    'tool_created' as activity_type
                FROM tools
                WHERE user_id = $1
                ORDER BY created_at DESC
                LIMIT 5
                """,
                user_id_param
            )

            # Combine and sort recent activities
            all_activities = []
            for row in recent_projects:
                all_activities.append({
                    'id': row['id'],
                    'name': row['name'],
                    'type': row['activity_type'],
                    'subtype': row['project_type'],
                    'created_at': serialize_datetime_for_api(row['created_at'])
                })
            for row in recent_chats:
                all_activities.append({
                    'id': row['id'],
                    'name': row['name'],
                    'type': row['activity_type'],
                    'subtype': None,
                    'created_at': serialize_datetime_for_api(row['created_at'])
                })
            for row in recent_tools:
                all_activities.append({
                    'id': row['id'],
                    'name': row['name'],
                    'type': row['activity_type'],
                    'subtype': None,
                    'created_at': serialize_datetime_for_api(row['created_at'])
                })

            # Sort by created_at descending
            all_activities.sort(key=lambda x: x['created_at'] or '', reverse=True)
            recent_activity = all_activities[:10]

            # Get projects created by month (last 12 months), including backend/frontend split
            projects_by_month = await conn.fetch(
                f"""
                SELECT 
                    TO_CHAR(created_at, 'YYYY-MM') as month,
                    COUNT(*) as count,
                    COUNT(CASE WHEN project_type = 'backend' THEN 1 END) AS backend_count,
                    COUNT(CASE WHEN project_type = 'frontend' THEN 1 END) AS frontend_count
                FROM projects
                WHERE user_id = $1{workspace_project_filter_sql}
                AND created_at >= NOW() - INTERVAL '12 months'
                GROUP BY TO_CHAR(created_at, 'YYYY-MM')
                ORDER BY month
                """,
                *workspace_scope_params
            )

            # Get sessions created by month (last 12 months) across AI Agent + Chat Flow
            if flow_step_events_exists:
                chats_by_month = await conn.fetch(
                    f"""
                    WITH backend_sessions AS (
                        SELECT
                            TO_CHAR(c.created_at, 'YYYY-MM') AS month,
                            COUNT(*) AS count
                        FROM chats c
                        LEFT JOIN projects p ON p.id = c.from_project::uuid
                        WHERE c.user_id = $1
                          AND c.created_at >= NOW() - INTERVAL '12 months'{workspace_project_filter_sql_for_chats}
                        GROUP BY TO_CHAR(c.created_at, 'YYYY-MM')
                    ),
                    frontend_sessions AS (
                        SELECT
                            TO_CHAR(first_seen_at, 'YYYY-MM') AS month,
                            COUNT(*) AS count
                        FROM (
                            SELECT
                                project_id,
                                session_id,
                                MIN(created_at) AS first_seen_at
                            FROM flow_step_events
                            WHERE project_id IN (
                                SELECT id FROM projects
                                WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                            )
                            AND created_at >= NOW() - INTERVAL '12 months'
                            GROUP BY project_id, session_id
                        ) session_first_seen
                        GROUP BY TO_CHAR(first_seen_at, 'YYYY-MM')
                    )
                    SELECT month, SUM(count) AS count
                    FROM (
                        SELECT month, count FROM backend_sessions
                        UNION ALL
                        SELECT month, count FROM frontend_sessions
                    ) combined_sessions
                    GROUP BY month
                    ORDER BY month
                    """,
                    *workspace_scope_params,
                )
            else:
                chats_by_month = await conn.fetch(
                    f"""
                    SELECT 
                        TO_CHAR(c.created_at, 'YYYY-MM') as month,
                        COUNT(*) as count
                    FROM chats c
                    LEFT JOIN projects p ON p.id = c.from_project::uuid
                    WHERE c.user_id = $1
                      AND c.created_at >= NOW() - INTERVAL '12 months'{workspace_project_filter_sql_for_chats}
                    GROUP BY TO_CHAR(c.created_at, 'YYYY-MM')
                    ORDER BY month
                    """,
                    *workspace_scope_params,
                )

            # New: daily sessions split by backend vs frontend within selected window
            sessions_per_day: Dict[str, Dict[str, int]] = {}

            # Backend sessions per day from chats
            backend_daily = await conn.fetch(
                f"""
                SELECT DATE(c.created_at) AS d, COUNT(*) AS sessions
                FROM chats c
                LEFT JOIN projects p ON p.id = c.from_project::uuid
                WHERE c.user_id = $1
                  AND c.created_at >= {start_ts_param}
                  {workspace_project_filter_sql_for_chats}
                GROUP BY DATE(c.created_at)
                ORDER BY d
                """,
                *workspace_scope_params,
                start_ts,
            )
            for row in backend_daily:
                key = row["d"].strftime("%Y-%m-%d")
                entry = sessions_per_day.setdefault(
                    key, {"date": key, "backend_sessions": 0, "frontend_sessions": 0}
                )
                entry["backend_sessions"] = row["sessions"] or 0

            # Frontend sessions per day from flow_step_events, if table exists
            if flow_step_events_exists:
                frontend_daily = await conn.fetch(
                    f"""
                    SELECT DATE(first_seen_at) AS d, COUNT(*) AS sessions
                    FROM (
                        SELECT
                            project_id,
                            session_id,
                            MIN(created_at) AS first_seen_at
                        FROM flow_step_events
                        WHERE project_id IN (
                            SELECT id FROM projects
                            WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                        )
                        AND created_at >= {start_ts_param}
                        GROUP BY project_id, session_id
                    ) session_first_seen
                    GROUP BY DATE(first_seen_at)
                    ORDER BY d
                    """,
                    *workspace_scope_params,
                    start_ts,
                )
                for row in frontend_daily:
                    key = row["d"].strftime("%Y-%m-%d")
                    entry = sessions_per_day.setdefault(
                        key, {"date": key, "backend_sessions": 0, "frontend_sessions": 0}
                    )
                    entry["frontend_sessions"] = row["sessions"] or 0

            # New: daily messages split by user vs bot
            messages_per_day: Dict[str, Dict[str, int]] = {}

            try:
                table_exists = await conn.fetchval(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = 'chat_messages'
                    )
                    """
                )
                if table_exists:
                    backend_msgs_daily = await conn.fetch(
                        f"""
                        SELECT
                            DATE(m.created_at) AS d,
                            COUNT(CASE WHEN m.type = 'user' THEN 1 END) AS user_messages,
                            COUNT(CASE WHEN m.type IN ('assistant','bot','agent') THEN 1 END) AS bot_messages
                        FROM chat_messages m
                        JOIN chats c ON m.chat_id = c.id
                        LEFT JOIN projects p ON p.id = c.from_project::uuid
                        WHERE c.user_id = $1
                          AND m.created_at >= {start_ts_param}
                          {workspace_project_filter_sql_for_chats}
                        GROUP BY DATE(m.created_at)
                        ORDER BY d
                        """,
                        *workspace_scope_params,
                        start_ts,
                    )
                    for row in backend_msgs_daily:
                        key = row["d"].strftime("%Y-%m-%d")
                        entry = messages_per_day.setdefault(
                            key,
                            {
                                "date": key,
                                "user_messages": 0,
                                "bot_messages": 0,
                            },
                        )
                        entry["user_messages"] += row["user_messages"] or 0
                        entry["bot_messages"] += row["bot_messages"] or 0
            except Exception as e:
                logger.warning(f"Error computing backend messages_per_day: {e}")

            if flow_messages_exists:
                try:
                    frontend_msgs_daily = await conn.fetch(
                        f"""
                        SELECT
                            DATE(created_at) AS d,
                            COUNT(CASE WHEN role = 'user' THEN 1 END) AS user_messages,
                            COUNT(CASE WHEN role = 'assistant' THEN 1 END) AS bot_messages
                        FROM flow_messages
                        WHERE project_id IN (
                            SELECT id FROM projects
                            WHERE user_id = $1 AND project_type = 'frontend'{workspace_project_filter_sql}
                        )
                          AND created_at >= {start_ts_param}
                        GROUP BY DATE(created_at)
                        ORDER BY d
                        """,
                        *workspace_scope_params,
                        start_ts,
                    )
                    for row in frontend_msgs_daily:
                        key = row["d"].strftime("%Y-%m-%d")
                        entry = messages_per_day.setdefault(
                            key,
                            {
                                "date": key,
                                "user_messages": 0,
                                "bot_messages": 0,
                            },
                        )
                        entry["user_messages"] += row["user_messages"] or 0
                        entry["bot_messages"] += row["bot_messages"] or 0
                except Exception as e:
                    logger.warning(f"Error computing frontend messages_per_day: {e}")

            # New: error rate per day based on chat status (backend only)
            error_rate_per_day: List[Dict[str, Any]] = []
            error_rows = await conn.fetch(
                f"""
                SELECT
                    DATE(c.created_at) AS d,
                    COUNT(*) AS total_sessions,
                    COUNT(CASE WHEN status IN ('failed','aborted') THEN 1 END) AS error_sessions
                FROM chats c
                LEFT JOIN projects p ON p.id = c.from_project::uuid
                WHERE c.user_id = $1
                  AND c.created_at >= {start_ts_param}{workspace_project_filter_sql_for_chats}
                GROUP BY DATE(c.created_at)
                ORDER BY d
                """,
                *workspace_scope_params,
                start_ts,
            )
            for row in error_rows:
                total = row["total_sessions"] or 0
                errors = row["error_sessions"] or 0
                rate = (errors * 100.0 / total) if total > 0 else 0.0
                error_rate_per_day.append(
                    {
                        "date": row["d"].strftime("%Y-%m-%d"),
                        "total_sessions": total,
                        "error_sessions": errors,
                        "error_rate_pct": round(rate, 2),
                    }
                )

            return DashboardStats(
                total_backend_projects=backend_count or 0,
                total_frontend_projects=frontend_count or 0,
                total_tools=tools_count or 0,
                total_published_projects=total_published_projects,
                total_chats=total_chats or 0,
                total_backend_chats=total_backend_chats or 0,
                total_frontend_chats=total_frontend_chats or 0,
                chats_per_backend_project=[
                    {
                        'project_id': row['project_id'],
                        'project_name': row['project_name'],
                        'chat_count': row.get('chat_count', 0) or 0,
                        'message_count': row.get('total_message_count', 0) or 0,
                        'user_message_count': row.get('user_message_count', 0) or 0,
                        'bot_message_count': row.get('bot_message_count', 0) or 0
                    }
                    for row in chats_per_project
                ],
                chats_per_frontend_project=[
                    {
                        'project_id': row['project_id'],
                        'project_name': row['project_name'],
                        'chat_count': row.get('chat_count', 0) or 0,
                        'message_count': row.get('total_message_count', 0) or 0,
                        'user_message_count': row.get('user_message_count', 0) or 0,
                        'bot_message_count': row.get('bot_message_count', 0) or 0
                    }
                    for row in chats_per_frontend_project
                ],
                most_used_backend_project=most_used_project,
                most_used_frontend_project=most_used_frontend_project,
                recent_activity=recent_activity,
                projects_created_by_month=[
                    {
                        'month': row['month'],
                        'count': row['count']
                    }
                    for row in projects_by_month
                ],
                chats_created_by_month=[
                    {
                        'month': row['month'],
                        'count': row['count']
                    }
                    for row in chats_by_month
                ],
                total_messages=total_messages or 0,
                total_backend_messages=total_backend_messages or 0,
                total_frontend_messages=total_frontend_messages or 0,
                activity_summary=activity_summary,
                sessions_per_day=sorted(sessions_per_day.values(), key=lambda x: x["date"]),
                messages_per_day=sorted(messages_per_day.values(), key=lambda x: x["date"]),
                projects_created_by_month_detailed=[
                    {
                        "month": row["month"],
                        "count": row["count"],
                        "backend_count": row.get("backend_count", 0),
                        "frontend_count": row.get("frontend_count", 0),
                    }
                    for row in projects_by_month
                ],
                error_rate_per_day=error_rate_per_day,
            )

    except Exception as e:
        logger.error(f"Get dashboard stats error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get dashboard stats: {str(e)}"
        )

