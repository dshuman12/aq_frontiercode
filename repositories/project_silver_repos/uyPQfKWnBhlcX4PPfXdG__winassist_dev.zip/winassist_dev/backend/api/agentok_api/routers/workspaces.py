import logging
import os
import ipaddress
from datetime import datetime, timedelta
from typing import List, Optional
from urllib.parse import urlparse
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Request

from ..models import (
    Workspace,
    WorkspaceCreate,
    WorkspaceUpdate,
    WorkspaceInvite,
    WorkspaceInviteAccept,
    WorkspaceInviteCreate,
    WorkspaceInviteWithLink,
    WorkspaceMember,
    WorkspaceMemberRoleUpdate,
    WorkspaceMemberActiveUpdate,
    WorkspaceMemberWithEmail,
    WorkspaceWithRole,
)
from ..services.database import DatabaseClient
from ..services.email import send_invite_email
from ..services.auth import get_password_hash
from ..dependencies import get_current_user, get_database_client
from ..utils.datetime import now_ist_naive

logger = logging.getLogger(__name__)

router = APIRouter()


def _looks_like_ip_hostname(hostname: Optional[str]) -> bool:
    if not hostname:
        return False
    try:
        ipaddress.ip_address(hostname)
        return True
    except ValueError:
        return False


def _normalize_public_frontend_url(request: Request) -> str:
    configured_url = (os.getenv("INVITE_BASE_URL") or os.getenv("FRONTEND_URL") or "").strip().rstrip("/")
    request_origin = (request.headers.get("origin") or "").strip().rstrip("/")

    if configured_url.endswith("/v1"):
        configured_url = configured_url[: -len("/v1")]
    if request_origin.endswith("/v1"):
        request_origin = request_origin[: -len("/v1")]

    if not configured_url:
        return request_origin

    try:
        configured_host = urlparse(configured_url).hostname
    except Exception:
        configured_host = None

    try:
        request_host = urlparse(request_origin).hostname
    except Exception:
        request_host = None

    # If env is still pointing to a raw IP but the request came from the public frontend
    # domain, prefer the browser origin for invite links.
    if _looks_like_ip_hostname(configured_host) and request_origin and not _looks_like_ip_hostname(request_host):
        return request_origin

    return configured_url


async def _ensure_person_exists(conn, user_id: UUID, email: Optional[str] = None) -> None:
    """
    Ensure a row exists in persons for the given user_id (e.g. from JWT).
    If the user is not in persons, INSERT with a placeholder so FK constraints (e.g. workspaces.owner_id) succeed.
    """
    existing = await conn.fetchval("SELECT 1 FROM persons WHERE id = $1", user_id)
    if existing:
        return
    placeholder_email = email or f"user_{user_id}@placeholder.local"
    # Ensure email is unique; if placeholder exists (unlikely), append a suffix
    try:
        await conn.execute(
            """
            INSERT INTO persons (id, email, password_hash, created_at, updated_at)
            VALUES ($1, $2, $3, NOW(), NOW())
            ON CONFLICT (id) DO UPDATE SET updated_at = NOW()
            """,
            user_id,
            placeholder_email,
            get_password_hash("no-password-set"),
        )
    except Exception as e:
        if "unique" in str(e).lower() or "duplicate" in str(e).lower():
            # email collision, retry with unique suffix
            from uuid import uuid4
            await conn.execute(
                """
                INSERT INTO persons (id, email, password_hash, created_at, updated_at)
                VALUES ($1, $2, $3, NOW(), NOW())
                ON CONFLICT (id) DO UPDATE SET updated_at = NOW()
                """,
                user_id,
                f"user_{user_id}_{uuid4()}@placeholder.local",
                get_password_hash("no-password-set"),
            )
        else:
            raise


async def _ensure_default_workspace(
    db: DatabaseClient, user_id: UUID
) -> WorkspaceWithRole:
    """
    Ensure the user has at least one workspace.
    If none exist, create a personal workspace and owner membership.
    Returns one workspace with the caller's role.
    """
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        # Prevent race conditions on first-login /workspaces calls.
        # Multiple concurrent requests can otherwise create multiple "Personal workspace" rows.
        await conn.execute(
            "SELECT pg_advisory_xact_lock(hashtext($1::text))",
            str(user_id),
        )

        # Check existing workspaces via membership
        existing = await conn.fetch(
            """
            SELECT w.id, w.name, w.slug, w.owner_id, wm.role
            FROM workspaces w
            JOIN workspace_members wm ON wm.workspace_id = w.id
            WHERE wm.user_id = $1
            ORDER BY w.created_at ASC
            """,
            user_id,
        )
        if existing:
            row = existing[0]
            # Get owner email for display when this workspace is shown in list
            owner_email_row = await conn.fetchrow(
                "SELECT p.email FROM persons p JOIN workspaces w ON w.owner_id = p.id WHERE w.id = $1",
                row["id"],
            )
            return WorkspaceWithRole(
                id=row["id"],
                name=row["name"],
                slug=row["slug"],
                role=row["role"],
                owner_id=row["owner_id"],
                owner_email=owner_email_row["email"] if owner_email_row and owner_email_row.get("email") else None,
            )

        # No membership: ensure person exists (JWT user may not be in persons yet),
        # then create/reuse a personal workspace.
        await _ensure_person_exists(conn, user_id)
        name = "Personal workspace"

        # Reuse any existing personal workspace for this owner (created by earlier request).
        ws = await conn.fetchrow(
            """
            SELECT id, owner_id, name, slug
            FROM workspaces
            WHERE owner_id = $1 AND name = $2
            ORDER BY created_at ASC
            LIMIT 1
            """,
            user_id,
            name,
        )
        if not ws:
            ws = await conn.fetchrow(
                """
                INSERT INTO workspaces (owner_id, name, slug, created_at, updated_at)
                VALUES ($1, $2, NULL, NOW(), NOW())
                RETURNING id, owner_id, name, slug
                """,
                user_id,
                name,
            )

        await conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES ($1, $2, 'owner', NOW())
            ON CONFLICT (workspace_id, user_id) DO NOTHING
            """,
            ws["id"],
            user_id,
        )

        owner_email_row = await conn.fetchrow("SELECT email FROM persons WHERE id = $1", user_id)
        return WorkspaceWithRole(
            id=ws["id"],
            name=ws["name"],
            slug=ws["slug"],
            role="owner",
            owner_id=ws["owner_id"],
            owner_email=owner_email_row["email"] if owner_email_row and owner_email_row.get("email") else None,
        )


@router.get(
    "",
    response_model=List[WorkspaceWithRole],
    summary="List workspaces for current user",
)
async def list_workspaces(
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    List all workspaces the current user is a member of.
    If none exist, a personal workspace is created automatically.
    """
    user_id = current_user["id"]
    # Convert to UUID if string
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT w.id, w.name, w.slug, w.owner_id, wm.role, p.email AS owner_email
            FROM workspaces w
            JOIN workspace_members wm ON wm.workspace_id = w.id
            LEFT JOIN persons p ON p.id = w.owner_id
            WHERE wm.user_id = $1
            ORDER BY w.created_at ASC
            """,
            user_id,
        )

        if not rows:
            # Auto-create personal workspace
            default_ws = await _ensure_default_workspace(db, user_id)
            return [default_ws]

        # If older data already contains duplicates of the default personal workspace,
        # hide them so the UI shows only one by default.
        out: List[WorkspaceWithRole] = []
        seen_personal = False
        for row in rows:
            is_personal = (
                str(row["owner_id"]) == str(user_id)
                and (row["name"] or "").strip().lower() == "personal workspace"
            )
            if is_personal:
                if seen_personal:
                    continue
                seen_personal = True
            out.append(
                WorkspaceWithRole(
                    id=row["id"],
                    name=row["name"],
                    slug=row["slug"],
                    role=row["role"],
                    owner_id=row["owner_id"],
                    owner_email=row["owner_email"] if row["owner_email"] else None,
                )
            )
        return out


@router.post(
    "",
    response_model=WorkspaceWithRole,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new workspace",
)
async def create_workspace(
    body: WorkspaceCreate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        # Prevent duplicate workspace names for this owner (case-insensitive).
        normalized_name = (body.name or "").strip()
        if not normalized_name:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Workspace name cannot be empty",
            )
        duplicate = await conn.fetchrow(
            """
            SELECT 1
            FROM workspaces
            WHERE owner_id = $1
              AND LOWER(TRIM(name)) = LOWER(TRIM($2))
            LIMIT 1
            """,
            user_id,
            normalized_name,
        )
        if duplicate:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Workspace with same name already exists",
            )

        ws = await conn.fetchrow(
            """
            INSERT INTO workspaces (owner_id, name, slug, created_at, updated_at)
            VALUES ($1, $2, $3, NOW(), NOW())
            RETURNING id, owner_id, name, slug, created_at, updated_at
            """,
            user_id,
            normalized_name,
            body.slug,
        )
        await conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES ($1, $2, $3, NOW())
            ON CONFLICT (workspace_id, user_id) DO NOTHING
            """,
            ws["id"],
            user_id,
            "owner",
        )

        owner_email_row = await conn.fetchrow(
            "SELECT email FROM persons WHERE id = $1", user_id
        )
        return WorkspaceWithRole(
            id=ws["id"],
            name=ws["name"],
            slug=ws["slug"],
            role="owner",
            owner_id=ws["owner_id"],
            owner_email=owner_email_row["email"] if owner_email_row and owner_email_row.get("email") else None,
        )


@router.patch(
    "/{workspace_id}",
    response_model=WorkspaceWithRole,
    summary="Update workspace (name). Owner only.",
)
async def update_workspace(
    workspace_id: UUID,
    body: WorkspaceUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Update workspace name (and optionally slug). Only the workspace owner can update.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    if not body.name and body.slug is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Provide at least one of name or slug to update",
        )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        ws = await conn.fetchrow(
            """
            SELECT id, owner_id, name, slug
            FROM workspaces
            WHERE id = $1
            """,
            workspace_id,
        )
        if not ws:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )
        if ws["owner_id"] != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only the workspace owner can update the workspace name",
            )

        name = (body.name or "").strip() if body.name is not None else ws["name"]
        slug = body.slug if body.slug is not None else ws["slug"]
        if not name:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Workspace name cannot be empty",
            )

        await conn.execute(
            """
            UPDATE workspaces
            SET name = $1, slug = $2, updated_at = NOW()
            WHERE id = $3
            """,
            name,
            slug,
            workspace_id,
        )
        row = await conn.fetchrow(
            """
            SELECT w.id, w.name, w.slug, w.owner_id, wm.role, p.email AS owner_email
            FROM workspaces w
            JOIN workspace_members wm ON wm.workspace_id = w.id AND wm.user_id = $1
            LEFT JOIN persons p ON p.id = w.owner_id
            WHERE w.id = $2
            """,
            user_id,
            workspace_id,
        )
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )
        return WorkspaceWithRole(
            id=row["id"],
            name=row["name"],
            slug=row["slug"],
            role=row["role"],
            owner_id=row["owner_id"],
            owner_email=row["owner_email"] if row.get("owner_email") else None,
        )


@router.delete(
    "/{workspace_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a workspace. Owner only.",
)
async def delete_workspace(
    workspace_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Delete a workspace and all workspace-scoped resources.
    Owner only. Deletes all projects in the workspace first (required by FK constraints),
    then deletes the workspace (members/invites cascade).
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        ws = await conn.fetchrow(
            "SELECT id, owner_id, name FROM workspaces WHERE id = $1",
            workspace_id,
        )
        if not ws:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )
        if ws["owner_id"] != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only the workspace owner can delete the workspace",
            )

        # Safety: don't allow deleting the default personal workspace.
        if (ws.get("name") or "").strip().lower() == "personal workspace":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Personal workspace cannot be deleted.",
            )

        # Delete all projects in this workspace first (projects.workspace_id has no ON DELETE CASCADE).
        await conn.execute(
            "DELETE FROM projects WHERE workspace_id = $1",
            workspace_id,
        )
        await conn.execute(
            "DELETE FROM workspaces WHERE id = $1",
            workspace_id,
        )

    return None


@router.get(
    "/{workspace_id}/members",
    response_model=List[WorkspaceMemberWithEmail],
    summary="List members of a workspace",
)
async def list_members(
    workspace_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    List members of a workspace with their email.
    Requires the caller to be a member of the workspace.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        membership = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not membership:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not a member of this workspace",
            )

        rows = await conn.fetch(
            """
            SELECT wm.id, wm.workspace_id, wm.user_id, wm.role, wm.created_at,
                   p.email,
                   (wm.user_id = w.owner_id) AS is_workspace_owner,
                   COALESCE(p.is_active, TRUE) AS is_active
            FROM workspace_members wm
            JOIN workspaces w ON w.id = wm.workspace_id
            LEFT JOIN persons p ON p.id = wm.user_id
            WHERE wm.workspace_id = $1
            ORDER BY wm.created_at ASC
            """,
            workspace_id,
        )
        return [WorkspaceMemberWithEmail(**dict(row)) for row in rows]


@router.patch(
    "/{workspace_id}/members/{member_user_id}/active",
    response_model=WorkspaceMemberWithEmail,
    summary="Activate/deactivate a user. Owner/admin only.",
)
async def set_member_active_status(
    workspace_id: UUID,
    member_user_id: UUID,
    body: WorkspaceMemberActiveUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Toggle a member's account active status.
    - Only workspace owners/admins can do this
    - Status is global for the user (affects login/API access everywhere)
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        caller = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not caller or caller["role"] not in ("owner", "admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace owners and admins can activate/deactivate users",
            )

        # Ensure target is a member of this workspace
        target_membership = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            member_user_id,
        )
        if not target_membership:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Member not found",
            )

        # Safety: don't allow deactivating the workspace owner
        workspace = await conn.fetchrow(
            "SELECT owner_id FROM workspaces WHERE id = $1",
            workspace_id,
        )
        if workspace and workspace["owner_id"] == member_user_id and body.is_active is False:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot deactivate the workspace owner",
            )

        await conn.execute(
            """
            UPDATE persons
            SET is_active = $1, updated_at = NOW()
            WHERE id = $2
            """,
            body.is_active,
            member_user_id,
        )

        row = await conn.fetchrow(
            """
            SELECT wm.id, wm.workspace_id, wm.user_id, wm.role, wm.created_at,
                   p.email,
                   (wm.user_id = w.owner_id) AS is_workspace_owner,
                   COALESCE(p.is_active, TRUE) AS is_active
            FROM workspace_members wm
            JOIN workspaces w ON w.id = wm.workspace_id
            LEFT JOIN persons p ON p.id = wm.user_id
            WHERE wm.workspace_id = $1 AND wm.user_id = $2
            """,
            workspace_id,
            member_user_id,
        )
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Member not found",
            )
        return WorkspaceMemberWithEmail(**dict(row))


@router.patch(
    "/{workspace_id}/members/{member_user_id}",
    response_model=WorkspaceMemberWithEmail,
    summary="Update a member's role",
)
async def update_member_role(
    workspace_id: UUID,
    member_user_id: UUID,
    body: WorkspaceMemberRoleUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Change a member's role. Only workspace owners and admins can change roles.
    Role must be one of: owner, admin, member, viewer.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    role = (body.role or "").strip().lower()
    if role not in ("owner", "admin", "member", "viewer"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Role must be one of: owner, admin, member, viewer",
        )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        caller = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not caller or caller["role"] not in ("owner", "admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace owners and admins can change member roles",
            )

        workspace = await conn.fetchrow(
            """
            SELECT owner_id FROM workspaces
            WHERE id = $1
            """,
            workspace_id,
        )
        if not workspace:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )
        if member_user_id == workspace["owner_id"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot change the role of the workspace owner",
            )

        # Ensure at least one owner remains if demoting an owner
        if role != "owner":
            current_member = await conn.fetchrow(
                """
                SELECT role FROM workspace_members
                WHERE workspace_id = $1 AND user_id = $2
                """,
                workspace_id,
                member_user_id,
            )
            if current_member and current_member["role"] == "owner":
                owner_count = await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM workspace_members
                    WHERE workspace_id = $1 AND role = 'owner'
                    """,
                    workspace_id,
                )
                if owner_count <= 1:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Cannot change role: workspace must have at least one owner",
                    )

        await conn.execute(
            """
            UPDATE workspace_members
            SET role = $1
            WHERE workspace_id = $2 AND user_id = $3
            """,
            role,
            workspace_id,
            member_user_id,
        )

        row = await conn.fetchrow(
            """
            SELECT wm.id, wm.workspace_id, wm.user_id, wm.role, wm.created_at, p.email
            FROM workspace_members wm
            JOIN persons p ON p.id = wm.user_id
            WHERE wm.workspace_id = $1 AND wm.user_id = $2
            """,
            workspace_id,
            member_user_id,
        )
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Member not found",
            )
        return WorkspaceMemberWithEmail(**dict(row))


@router.delete(
    "/{workspace_id}/members/{member_user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove a member from the workspace",
)
async def remove_member(
    workspace_id: UUID,
    member_user_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Remove a member from the workspace. Only owners and admins can remove members.
    Cannot remove the last owner.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        caller = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not caller or caller["role"] not in ("owner", "admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace owners and admins can remove members",
            )

        workspace = await conn.fetchrow(
            """
            SELECT owner_id FROM workspaces
            WHERE id = $1
            """,
            workspace_id,
        )
        if not workspace:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )
        if member_user_id == workspace["owner_id"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot remove the workspace owner",
            )

        target = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            member_user_id,
        )
        if not target:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Member not found",
            )
        if target["role"] == "owner":
            owner_count = await conn.fetchval(
                """
                SELECT COUNT(*) FROM workspace_members
                WHERE workspace_id = $1 AND role = 'owner'
                """,
                workspace_id,
            )
            if owner_count <= 1:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot remove the last owner. Transfer ownership first.",
                )

        await conn.execute(
            """
            DELETE FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            member_user_id,
        )
        return None


@router.get(
    "/{workspace_id}/invites",
    response_model=List[WorkspaceInvite],
    summary="List invites for a workspace",
)
async def list_invites(
    workspace_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    List all invites for a workspace (pending and accepted).
    Requires the caller to be a member (owner/admin see all).
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        membership = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not membership:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not a member of this workspace",
            )

        rows = await conn.fetch(
            """
            SELECT id, workspace_id, email, role, token, expires_at, accepted_at, created_by, created_at
            FROM workspace_invites
            WHERE workspace_id = $1
            ORDER BY created_at DESC
            """,
            workspace_id,
        )
        return [WorkspaceInvite(**dict(row)) for row in rows]


@router.post(
    "/{workspace_id}/invites",
    response_model=WorkspaceInviteWithLink,
    status_code=status.HTTP_201_CREATED,
    summary="Create an invite to a workspace",
)
async def create_invite(
    workspace_id: UUID,
    body: WorkspaceInviteCreate,
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Create an invite for another user to join the workspace with a given role.
    Only owners and admins can invite. Sends email if SMTP is configured.
    """
    user_id = current_user["id"]
    inviter_email = (current_user.get("email") or "").strip() or "A team member"
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        membership = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not membership or membership["role"] not in ("owner", "admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace owners and admins can invite members",
            )

        # Get workspace name for email
        ws_row = await conn.fetchrow(
            "SELECT name FROM workspaces WHERE id = $1",
            workspace_id,
        )
        workspace_name = (ws_row["name"] if ws_row else "Workspace").strip()

        # Reject if invitee is already a member (match by email)
        existing_member = await conn.fetchrow(
            """
            SELECT 1
            FROM persons p
            JOIN workspace_members wm ON wm.user_id = p.id
            WHERE LOWER(TRIM(p.email)) = LOWER(TRIM($1))
              AND wm.workspace_id = $2
            """,
            body.email,
            workspace_id,
        )
        if existing_member:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This email is already a member of the workspace.",
            )

        # If this exact email+role was invited and accepted before, don't create another invite.
        previously_accepted = await conn.fetchrow(
            """
            SELECT 1
            FROM workspace_invites
            WHERE workspace_id = $1
              AND LOWER(TRIM(email)) = LOWER(TRIM($2))
              AND role = $3
              AND accepted_at IS NOT NULL
            LIMIT 1
            """,
            workspace_id,
            body.email,
            body.role,
        )
        if previously_accepted:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This email has already accepted an invite to the workspace.",
            )

        expires_at = None
        if body.expires_in_days and body.expires_in_days > 0:
            expires_at = now_ist_naive() + timedelta(days=body.expires_in_days)

        # Prevent duplicate pending invites for the same workspace + email + role.
        # If such an invite already exists (and not expired), reuse it instead of inserting a new row.
        normalized_email = (body.email or "").strip().lower()
        existing_invite = await conn.fetchrow(
            """
            SELECT id, workspace_id, email, role, token, expires_at, accepted_at, created_by, created_at
            FROM workspace_invites
            WHERE workspace_id = $1
              AND LOWER(TRIM(email)) = $2
              AND role = $3
              AND accepted_at IS NULL
              AND (expires_at IS NULL OR expires_at > NOW())
            ORDER BY created_at DESC
            LIMIT 1
            """,
            workspace_id,
            normalized_email,
            body.role,
        )

        reused = False
        if existing_invite:
            invite = existing_invite
            reused = True
        else:
            invite = await conn.fetchrow(
                """
                INSERT INTO workspace_invites (
                    workspace_id, email, role, expires_at, created_by, created_at
                )
                VALUES ($1, $2, $3, $4, $5, NOW())
                RETURNING id, workspace_id, email, role, token, expires_at,
                          accepted_at, created_by, created_at
                """,
                workspace_id,
                normalized_email,
                body.role,
                expires_at,
                user_id,
            )

    # Build invite link and send email (outside conn)
    frontend_url = _normalize_public_frontend_url(request)
    logger.info(
        "create_invite: FRONTEND_URL=%s inviter_email=%s to_email=%s",
        frontend_url or "(not set)",
        inviter_email,
        body.email,
    )
    invite_link = None
    if frontend_url:
        invite_link = f"{frontend_url}/accept-invite?token={invite['token']}"
        logger.info("create_invite: invite_link=%s", invite_link)
    else:
        logger.warning("FRONTEND_URL not set; invite email will not contain an accept link. Set FRONTEND_URL in .env for the link.")

    email_sent = False
    email_error = None
    if inviter_email:
        logger.info("create_invite: calling send_invite_email for %s", body.email)
        email_sent, email_error = send_invite_email(
            to_email=body.email,
            inviter_email=inviter_email,
            workspace_name=workspace_name,
            invite_link=invite_link,
            role=body.role,
            expires_in_days=body.expires_in_days,
        )
        logger.info("create_invite: send_invite_email returned email_sent=%s email_error=%s", email_sent, email_error)
        if email_sent:
            logger.info("Invite email sent to %s", body.email)
        elif email_error:
            logger.warning("Invite email not sent to %s: %s", body.email, email_error)
    else:
        logger.warning("create_invite: skipping email (no inviter_email)")

    result = dict(invite)
    result["invite_link"] = invite_link
    result["email_sent"] = email_sent
    result["email_error"] = email_error
    result["reused"] = reused
    return WorkspaceInviteWithLink(**result)


@router.delete(
    "/{workspace_id}/invites/{invite_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a pending invite. Owner/admin only.",
)
async def delete_invite(
    workspace_id: UUID,
    invite_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Delete an invite row (typically used to revoke a pending invite).
    Only workspace owners/admins can do this.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        caller = await conn.fetchrow(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = $1 AND user_id = $2
            """,
            workspace_id,
            user_id,
        )
        if not caller or caller["role"] not in ("owner", "admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace owners and admins can delete invites",
            )

        invite = await conn.fetchrow(
            """
            SELECT id, accepted_at
            FROM workspace_invites
            WHERE id = $1 AND workspace_id = $2
            """,
            invite_id,
            workspace_id,
        )
        if not invite:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Invite not found",
            )
        if invite["accepted_at"] is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete an accepted invite",
            )

        await conn.execute(
            "DELETE FROM workspace_invites WHERE id = $1 AND workspace_id = $2",
            invite_id,
            workspace_id,
        )

    return None


@router.post(
    "/invites/accept",
    response_model=WorkspaceWithRole,
    summary="Accept a workspace invite",
)
async def accept_invite(
    body: WorkspaceInviteAccept,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    """
    Accept a workspace invite using its token.
    The current user will be added as a member with the invite's role.
    """
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        # Normalize token: accept UUIDs that were corrupted in links (e.g. extra character in last segment)
        raw = (body.token or "").strip()
        token_uuid = None
        try:
            token_uuid = UUID(raw)
        except ValueError:
            if len(raw) == 37 and raw[-1].isdigit():
                try:
                    token_uuid = UUID(raw[:36])
                except ValueError:
                    pass
            if token_uuid is None:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="Invalid invite token format. Use the exact link from your invite email.",
                )

        invite = await conn.fetchrow(
            """
            SELECT *
            FROM workspace_invites
            WHERE token = $1
            """,
            token_uuid,
        )
        if not invite:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Invite not found",
            )

        if invite["accepted_at"] is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invite has already been accepted",
            )

        if invite["expires_at"] and invite["expires_at"] < now_ist_naive():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invite has expired",
            )

        workspace_id = invite["workspace_id"]
        role = invite["role"]

        # Create membership (idempotent via unique constraint)
        await conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES ($1, $2, $3, NOW())
            ON CONFLICT (workspace_id, user_id) DO UPDATE SET role = EXCLUDED.role
            """,
            workspace_id,
            user_id,
            role,
        )

        # Mark invite accepted
        await conn.execute(
            """
            UPDATE workspace_invites
            SET accepted_at = NOW()
            WHERE id = $1
            """,
            invite["id"],
        )

        ws = await conn.fetchrow(
            """
            SELECT w.id, w.name, w.slug, w.owner_id, p.email AS owner_email
            FROM workspaces w
            LEFT JOIN persons p ON p.id = w.owner_id
            WHERE w.id = $1
            """,
            workspace_id,
        )
        if not ws:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Workspace not found",
            )

        return WorkspaceWithRole(
            id=ws["id"],
            name=ws["name"],
            slug=ws["slug"],
            role=role,
            owner_id=ws["owner_id"],
            owner_email=ws["owner_email"] if ws.get("owner_email") else None,
        )

