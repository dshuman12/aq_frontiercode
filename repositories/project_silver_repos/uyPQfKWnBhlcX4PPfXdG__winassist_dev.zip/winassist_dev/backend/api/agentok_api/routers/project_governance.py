import hashlib
import json
import logging
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from ..dependencies import get_current_user, get_database_client
from ..utils.datetime import serialize_datetime_for_api
from ..services.database import DatabaseClient


logger = logging.getLogger(__name__)
router = APIRouter()

DEFAULT_POLICY = {
    "require_staging_for_production": True,
    "require_approval_for_production": True,
    "require_admin_approval_for_risky_ai_changes": True,
    "require_change_summary": True,
    "allow_member_releases": False,
    "allowed_domains": [],
    "blocked_capabilities": [],
    "sensitive_headers": ["authorization", "x-api-key", "cookie", "set-cookie"],
    "notes": "",
}


class GovernancePolicyUpdate(BaseModel):
    require_staging_for_production: bool = True
    require_approval_for_production: bool = True
    require_admin_approval_for_risky_ai_changes: bool = True
    require_change_summary: bool = True
    allow_member_releases: bool = False
    allowed_domains: List[str] = Field(default_factory=list)
    blocked_capabilities: List[str] = Field(default_factory=list)
    sensitive_headers: List[str] = Field(
        default_factory=lambda: ["authorization", "x-api-key", "cookie", "set-cookie"]
    )
    notes: Optional[str] = None


class ReleaseCreateRequest(BaseModel):
    environment: Literal["draft", "staging", "production"]
    notes: Optional[str] = None
    change_summary: Optional[str] = None
    approved: bool = False
    approval_reference: Optional[str] = None


class ReleaseRollbackRequest(BaseModel):
    notes: Optional[str] = None


def _json_dumps(value: Any) -> str:
    return json.dumps(value, sort_keys=True, default=str)


def _flow_fingerprint(flow: Any) -> str:
    payload = flow if isinstance(flow, dict) else {}
    return hashlib.sha256(_json_dumps(payload).encode("utf-8")).hexdigest()


def _normalize_policy(policy: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    merged = dict(DEFAULT_POLICY)
    if isinstance(policy, dict):
        merged.update(policy)
    merged["allowed_domains"] = [
        str(item).strip() for item in merged.get("allowed_domains", []) if str(item).strip()
    ]
    merged["blocked_capabilities"] = [
        str(item).strip()
        for item in merged.get("blocked_capabilities", [])
        if str(item).strip()
    ]
    merged["sensitive_headers"] = [
        str(item).strip().lower()
        for item in merged.get("sensitive_headers", [])
        if str(item).strip()
    ]
    merged["notes"] = (merged.get("notes") or "").strip()
    return merged


def _line_list(value: Any) -> List[str]:
    return [line.strip() for line in str(value or "").splitlines() if line.strip()]


def _get_ai_config_from_flow(flow: Any) -> Dict[str, Any]:
    if not isinstance(flow, dict):
        return {}
    ai_config = flow.get("ai_config")
    return ai_config if isinstance(ai_config, dict) else {}


def _build_release_readiness(project: Dict[str, Any]) -> Dict[str, Any]:
    ai_config = _get_ai_config_from_flow(project.get("flow"))
    project_type = str(project.get("project_type") or "")
    release_notes = str(ai_config.get("releaseNotes") or "").strip()
    evaluation_cases = [
        case
        for case in (ai_config.get("evaluationCases") or [])
        if isinstance(case, dict) and str(case.get("query") or "").strip()
    ]
    evaluation_runs = [
        run for run in (ai_config.get("evaluationRuns") or []) if isinstance(run, dict)
    ]
    latest_run = evaluation_runs[0] if evaluation_runs else {}
    latest_summary = latest_run.get("summary") if isinstance(latest_run, dict) else {}
    latest_total = int(latest_summary.get("total_cases") or 0) if latest_summary else 0
    latest_failed = int(latest_summary.get("failed_cases") or 0) if latest_summary else 0
    enable_rag = bool(ai_config.get("enableRag"))
    knowledge_bindings = [str(value) for value in (ai_config.get("knowledge_bindings") or []) if value]
    guardrails = ai_config.get("guardrails") if isinstance(ai_config.get("guardrails"), dict) else {}
    has_guardrails = bool(
        _line_list(guardrails.get("blockedTopicsText"))
        or _line_list(guardrails.get("escalationKeywordsText"))
        or _line_list(guardrails.get("restrictedActionsText"))
        or str(guardrails.get("fallbackPolicy") or "").strip()
    )
    applies_to_ai = project_type == "backend" and bool(ai_config)

    gates = [
        {
            "key": "release_notes",
            "label": "Release notes prepared",
            "required": applies_to_ai,
            "passed": bool(release_notes) if applies_to_ai else True,
            "detail": "Document prompt, knowledge, policy, or routing changes before governed publish.",
        },
        {
            "key": "evaluation_cases",
            "label": "Evaluation suite configured",
            "required": applies_to_ai,
            "passed": len(evaluation_cases) > 0 if applies_to_ai else True,
            "detail": "At least one evaluation case should exist before production promotion.",
        },
        {
            "key": "latest_evaluation",
            "label": "Latest evaluation passed",
            "required": applies_to_ai,
            "passed": latest_total > 0 and latest_failed == 0 if applies_to_ai else True,
            "detail": "Production release should only proceed after the latest evaluation run passes fully.",
        },
        {
            "key": "knowledge_bindings",
            "label": "Knowledge collections bound",
            "required": applies_to_ai and enable_rag,
            "passed": (not enable_rag) or len(knowledge_bindings) > 0,
            "detail": "Required when RAG is enabled so the bot has a grounded knowledge scope.",
        },
        {
            "key": "guardrails",
            "label": "Guardrails configured",
            "required": False,
            "passed": has_guardrails or not applies_to_ai,
            "detail": "Recommended for enterprise safety, escalation, and restricted action control.",
        },
    ]
    blocking_reasons = [gate["label"] for gate in gates if gate["required"] and not gate["passed"]]
    return {
        "applies_to_ai": applies_to_ai,
        "default_change_summary": release_notes or None,
        "knowledge_bindings_count": len(knowledge_bindings),
        "evaluation_case_count": len(evaluation_cases),
        "latest_evaluation": latest_summary or None,
        "gates": gates,
        "blocking_reasons": blocking_reasons,
        "ready_for_production": len(blocking_reasons) == 0,
    }


def _release_label(row: Optional[Dict[str, Any]], fallback: str) -> str:
    if not row:
        return fallback
    environment = row.get("environment")
    version_no = row.get("version_no")
    if environment and version_no is not None:
        return f"{environment} v{version_no}"
    return fallback


def _sorted_unique_strings(values: Any) -> List[str]:
    return sorted({str(value).strip() for value in (values or []) if str(value).strip()})


def _compare_named_sets(section: str, label: str, left: Any, right: Any) -> Optional[Dict[str, Any]]:
    left_set = set(_sorted_unique_strings(left))
    right_set = set(_sorted_unique_strings(right))
    added = sorted(right_set - left_set)
    removed = sorted(left_set - right_set)
    if not added and not removed:
        return None
    parts = []
    if added:
        parts.append(f"added {', '.join(added[:6])}")
    if removed:
        parts.append(f"removed {', '.join(removed[:6])}")
    return {
        "section": section,
        "message": f"{label}: {'; '.join(parts)}.",
        "added": added,
        "removed": removed,
    }


def _compare_flows(left_flow: Any, right_flow: Any) -> Dict[str, Any]:
    left_flow = left_flow if isinstance(left_flow, dict) else {}
    right_flow = right_flow if isinstance(right_flow, dict) else {}
    left_ai = _get_ai_config_from_flow(left_flow)
    right_ai = _get_ai_config_from_flow(right_flow)

    differences: List[Dict[str, Any]] = []

    def push_simple(section: str, message: str) -> None:
        differences.append({"section": section, "message": message})

    left_model = (
        str(left_ai.get("modelProvider") or "").strip(),
        str(left_ai.get("modelName") or "").strip(),
    )
    right_model = (
        str(right_ai.get("modelProvider") or "").strip(),
        str(right_ai.get("modelName") or "").strip(),
    )
    if left_model != right_model:
        push_simple(
            "model",
            f"Model profile changed from '{' / '.join([value for value in left_model if value]) or 'not set'}' to '{' / '.join([value for value in right_model if value]) or 'not set'}'.",
        )

    if str(left_ai.get("systemPrompt") or "").strip() != str(right_ai.get("systemPrompt") or "").strip():
        push_simple("prompt", "System prompt changed.")

    for field, label in [
        ("tone", "Tone"),
        ("responseStyle", "Response style"),
        ("defaultLanguage", "Default language"),
    ]:
        if str(left_ai.get(field) or "").strip() != str(right_ai.get(field) or "").strip():
            push_simple("persona", f"{label} changed.")

    left_retrieval = (
        bool(left_ai.get("enableRag")),
        str(left_ai.get("retrievalMode") or "").strip(),
        int(left_ai.get("retrievalTopK") or 0),
        int(left_ai.get("chunkSize") or 0),
        int(left_ai.get("chunkOverlap") or 0),
    )
    right_retrieval = (
        bool(right_ai.get("enableRag")),
        str(right_ai.get("retrievalMode") or "").strip(),
        int(right_ai.get("retrievalTopK") or 0),
        int(right_ai.get("chunkSize") or 0),
        int(right_ai.get("chunkOverlap") or 0),
    )
    if left_retrieval != right_retrieval:
        push_simple(
            "retrieval",
            f"Retrieval settings changed from {left_retrieval} to {right_retrieval}.",
        )

    named_diff = _compare_named_sets(
        "knowledge",
        "Knowledge bindings",
        left_ai.get("knowledge_bindings") or [],
        right_ai.get("knowledge_bindings") or [],
    )
    if named_diff:
        differences.append(named_diff)

    named_diff = _compare_named_sets(
        "intents",
        "Intent catalog",
        [item.get("name") for item in (left_ai.get("intents") or []) if isinstance(item, dict)],
        [item.get("name") for item in (right_ai.get("intents") or []) if isinstance(item, dict)],
    )
    if named_diff:
        differences.append(named_diff)

    named_diff = _compare_named_sets(
        "entities",
        "Entity catalog",
        [item.get("name") for item in (left_ai.get("entities") or []) if isinstance(item, dict)],
        [item.get("name") for item in (right_ai.get("entities") or []) if isinstance(item, dict)],
    )
    if named_diff:
        differences.append(named_diff)

    left_guardrails = {
        "blocked_topics": _line_list((left_ai.get("guardrails") or {}).get("blockedTopicsText")),
        "escalation_keywords": _line_list((left_ai.get("guardrails") or {}).get("escalationKeywordsText")),
        "restricted_actions": _line_list((left_ai.get("guardrails") or {}).get("restrictedActionsText")),
    }
    right_guardrails = {
        "blocked_topics": _line_list((right_ai.get("guardrails") or {}).get("blockedTopicsText")),
        "escalation_keywords": _line_list((right_ai.get("guardrails") or {}).get("escalationKeywordsText")),
        "restricted_actions": _line_list((right_ai.get("guardrails") or {}).get("restrictedActionsText")),
    }
    if left_guardrails != right_guardrails:
        push_simple("guardrails", "Guardrail definitions changed.")

    if str(left_ai.get("supportedLanguagesText") or "").strip() != str(right_ai.get("supportedLanguagesText") or "").strip():
        push_simple("languages", "Supported language coverage changed.")

    left_eval_count = len(left_ai.get("evaluationCases") or [])
    right_eval_count = len(right_ai.get("evaluationCases") or [])
    if left_eval_count != right_eval_count:
        push_simple(
            "evaluation",
            f"Evaluation case count changed from {left_eval_count} to {right_eval_count}.",
        )

    left_nodes = len(left_flow.get("nodes") or []) if isinstance(left_flow.get("nodes"), list) else 0
    right_nodes = len(right_flow.get("nodes") or []) if isinstance(right_flow.get("nodes"), list) else 0
    left_edges = len(left_flow.get("edges") or []) if isinstance(left_flow.get("edges"), list) else 0
    right_edges = len(right_flow.get("edges") or []) if isinstance(right_flow.get("edges"), list) else 0
    if (left_nodes, left_edges) != (right_nodes, right_edges):
        push_simple(
            "flow",
            f"Flow structure changed from {left_nodes} node(s) / {left_edges} edge(s) to {right_nodes} node(s) / {right_edges} edge(s).",
        )

    return {
        "is_same": _flow_fingerprint(left_flow) == _flow_fingerprint(right_flow),
        "difference_count": len(differences),
        "differences": differences,
    }


def _assess_risky_ai_changes(left_flow: Any, right_flow: Any) -> Dict[str, Any]:
    comparison = _compare_flows(left_flow, right_flow)
    risky_sections = {"model", "prompt", "guardrails", "knowledge", "retrieval", "intents", "entities"}
    risky_differences = [
        item for item in (comparison.get("differences") or []) if item.get("section") in risky_sections
    ]
    return {
        "has_risky_change": len(risky_differences) > 0,
        "risk_count": len(risky_differences),
        "risk_sections": [item.get("section") for item in risky_differences],
        "differences": risky_differences,
    }


def _serialize_release(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "project_id": str(row["project_id"]),
        "environment": row["environment"],
        "version_no": row["version_no"],
        "notes": row["notes"],
        "change_summary": row["change_summary"],
        "flow_fingerprint": row["flow_fingerprint"],
        "approval_metadata": row.get("approval_metadata") or {},
        "created_by": str(row["created_by"]) if row.get("created_by") else None,
        "created_by_email": row.get("created_by_email"),
        "created_at": serialize_datetime_for_api(row.get("created_at")),
    }


def _serialize_audit(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "project_id": str(row["project_id"]) if row.get("project_id") else None,
        "workspace_id": str(row["workspace_id"]) if row.get("workspace_id") else None,
        "project_name": row.get("project_name"),
        "actor_user_id": str(row["actor_user_id"]) if row.get("actor_user_id") else None,
        "actor_email": row.get("actor_email"),
        "action": row["action"],
        "metadata": row.get("metadata") or {},
        "created_at": serialize_datetime_for_api(row.get("created_at")),
    }


async def _get_user_id(current_user: dict) -> UUID:
    user_id = current_user["id"]
    if isinstance(user_id, UUID):
        return user_id
    try:
        return UUID(str(user_id))
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user ID format",
        ) from exc


async def _fetch_project_context(conn, project_id: UUID, user_id: UUID) -> Dict[str, Any]:
    row = await conn.fetchrow(
        """
        SELECT p.id,
               p.user_id,
               p.workspace_id,
               p.name,
               p.description,
               p.flow,
               p.project_type,
               p.updated_at,
               wm.role AS member_role
        FROM projects p
        LEFT JOIN workspace_members wm
          ON p.workspace_id = wm.workspace_id
         AND wm.user_id = $1
        WHERE p.id = $2
        """,
        user_id,
        project_id,
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

    project = dict(row)
    if project["workspace_id"] is None:
        if project["user_id"] != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to access this project",
            )
        project["effective_role"] = "owner"
    else:
        member_role = project.get("member_role")
        if member_role is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not a member of the project workspace",
            )
        project["effective_role"] = member_role
    return project


async def _fetch_workspace_policy(conn, workspace_id: Optional[UUID]) -> Dict[str, Any]:
    if workspace_id is None:
        return _normalize_policy(None)

    row = await conn.fetchrow(
        """
        SELECT workspace_id, policy, updated_by, updated_at
        FROM workspace_governance_policies
        WHERE workspace_id = $1
        """,
        workspace_id,
    )
    if not row:
        return _normalize_policy(None)
    return _normalize_policy(row["policy"])


async def _write_project_audit_log(
    conn,
    *,
    project_id: Optional[UUID],
    workspace_id: Optional[UUID],
    project_name: str,
    actor_user_id: UUID,
    action: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    await conn.execute(
        """
        INSERT INTO project_audit_logs (
            project_id,
            workspace_id,
            project_name,
            actor_user_id,
            action,
            metadata,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6::jsonb, NOW())
        """,
        project_id,
        workspace_id,
        project_name,
        actor_user_id,
        action,
        _json_dumps(metadata or {}),
    )


def _require_admin_role(project: Dict[str, Any]) -> None:
    if project["effective_role"] not in {"owner", "admin"}:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only workspace owners/admins can change governance settings",
        )


def _require_release_role(project: Dict[str, Any], policy: Dict[str, Any]) -> None:
    allowed_roles = {"owner", "admin"}
    if policy.get("allow_member_releases"):
        allowed_roles.add("member")
    if project["effective_role"] not in allowed_roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your workspace role cannot create releases for this project",
        )


async def _fetch_runtime_summary(conn, project_id: UUID) -> Dict[str, Any]:
    chats = await conn.fetchrow(
        """
        SELECT COUNT(*)::int AS total_chats,
               COUNT(*) FILTER (WHERE status = 'running')::int AS running_chats,
               COUNT(*) FILTER (WHERE status = 'completed')::int AS completed_chats,
               COUNT(*) FILTER (WHERE status = 'failed')::int AS failed_chats,
               MAX(updated_at) AS last_chat_activity
        FROM chats
        WHERE from_project = $1
        """,
        project_id,
    )
    messages = await conn.fetchrow(
        """
        SELECT COUNT(*)::int AS total_messages,
               MAX(created_at) AS last_message_activity
        FROM chat_messages
        WHERE project_id = $1
        """,
        project_id,
    )
    step_events = await conn.fetchrow(
        """
        SELECT COUNT(*)::int AS total_step_events,
               MAX(created_at) AS last_step_event_at
        FROM flow_step_events
        WHERE project_id = $1
        """,
        project_id,
    )
    releases = await conn.fetchrow(
        """
        SELECT COUNT(*)::int AS total_releases,
               MAX(created_at) AS last_release_at
        FROM project_releases
        WHERE project_id = $1
        """,
        project_id,
    )

    last_activity = None
    for candidate in [
        chats["last_chat_activity"],
        messages["last_message_activity"],
        step_events["last_step_event_at"],
        releases["last_release_at"],
    ]:
        if candidate is not None and (last_activity is None or candidate > last_activity):
            last_activity = candidate

    return {
        "total_chats": chats["total_chats"],
        "running_chats": chats["running_chats"],
        "completed_chats": chats["completed_chats"],
        "failed_chats": chats["failed_chats"],
        "total_messages": messages["total_messages"],
        "total_step_events": step_events["total_step_events"],
        "total_releases": releases["total_releases"],
        "last_activity_at": serialize_datetime_for_api(last_activity),
    }


@router.get("/{project_id}/governance", summary="Get project governance state")
async def get_project_governance(
    project_id: str,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        project = await _fetch_project_context(conn, project_id_uuid, user_id)
        policy = await _fetch_workspace_policy(conn, project["workspace_id"])
        current_releases_rows = await conn.fetch(
            """
            SELECT DISTINCT ON (pr.environment)
                   pr.*,
                   persons.email AS created_by_email
            FROM project_releases pr
            LEFT JOIN persons ON persons.id = pr.created_by
            WHERE pr.project_id = $1
            ORDER BY pr.environment, pr.version_no DESC
            """,
            project_id_uuid,
        )
        release_history_rows = await conn.fetch(
            """
            SELECT pr.*,
                   persons.email AS created_by_email
            FROM project_releases pr
            LEFT JOIN persons ON persons.id = pr.created_by
            WHERE pr.project_id = $1
            ORDER BY pr.created_at DESC
            LIMIT 25
            """,
            project_id_uuid,
        )
        audit_rows = await conn.fetch(
            """
            SELECT pal.*,
                   persons.email AS actor_email
            FROM project_audit_logs pal
            LEFT JOIN persons ON persons.id = pal.actor_user_id
            WHERE pal.project_id = $1
            ORDER BY pal.created_at DESC
            LIMIT 25
            """,
            project_id_uuid,
        )
        runtime_summary = await _fetch_runtime_summary(conn, project_id_uuid)
        latest_production_row = await conn.fetchrow(
            """
            SELECT *
            FROM project_releases
            WHERE project_id = $1 AND environment = 'production'
            ORDER BY version_no DESC
            LIMIT 1
            """,
            project_id_uuid,
        )

    current_releases = {
        row["environment"]: _serialize_release(dict(row)) for row in current_releases_rows
    }
    baseline_release = dict(latest_production_row) if latest_production_row else (dict(release_history_rows[0]) if release_history_rows else None)
    risk_assessment = _assess_risky_ai_changes(
        baseline_release.get("flow_snapshot") if baseline_release else {},
        project.get("flow") if isinstance(project.get("flow"), dict) else {},
    )

    return {
        "project": {
            "id": str(project["id"]),
            "name": project["name"],
            "workspace_id": str(project["workspace_id"]) if project["workspace_id"] else None,
            "project_type": project["project_type"],
            "updated_at": serialize_datetime_for_api(project.get("updated_at")),
            "effective_role": project["effective_role"],
        },
        "policy": policy,
        "current_releases": current_releases,
        "release_history": [_serialize_release(dict(row)) for row in release_history_rows],
        "audit_log": [_serialize_audit(dict(row)) for row in audit_rows],
        "runtime_summary": runtime_summary,
        "release_readiness": _build_release_readiness(project),
        "risk_assessment": {
            **risk_assessment,
            "baseline_label": _release_label(baseline_release, "current baseline") if baseline_release else "no baseline release",
        },
        "current_flow_fingerprint": _flow_fingerprint(project.get("flow")),
        "permissions": {
            "can_manage_policy": project["effective_role"] in {"owner", "admin"},
            "can_create_release": project["effective_role"] in {"owner", "admin"}
            or (
                policy.get("allow_member_releases")
                and project["effective_role"] == "member"
            ),
            "can_rollback": project["effective_role"] in {"owner", "admin"},
        },
    }


@router.put("/{project_id}/governance/policy", summary="Update workspace governance policy for this project")
async def update_project_governance_policy(
    project_id: str,
    policy_data: GovernancePolicyUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    policy = _normalize_policy(policy_data.model_dump())
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        project = await _fetch_project_context(conn, project_id_uuid, user_id)
        _require_admin_role(project)
        if project["workspace_id"] is not None:
            await conn.execute(
                """
                INSERT INTO workspace_governance_policies (
                    workspace_id,
                    policy,
                    updated_by,
                    updated_at
                )
                VALUES ($1, $2::jsonb, $3, NOW())
                ON CONFLICT (workspace_id)
                DO UPDATE
                SET policy = EXCLUDED.policy,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = NOW()
                """,
                project["workspace_id"],
                _json_dumps(policy),
                user_id,
            )

        await _write_project_audit_log(
            conn,
            project_id=project["id"],
            workspace_id=project["workspace_id"],
            project_name=project["name"],
            actor_user_id=user_id,
            action="governance.policy_updated",
            metadata={"policy": policy},
        )

    return {"project_id": project_id, "policy": policy}


@router.get("/{project_id}/governance/releases", summary="Get project release history")
async def get_project_releases(
    project_id: str,
    environment: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _fetch_project_context(conn, project_id_uuid, user_id)
        if environment:
            rows = await conn.fetch(
                """
                SELECT pr.*,
                       persons.email AS created_by_email
                FROM project_releases pr
                LEFT JOIN persons ON persons.id = pr.created_by
                WHERE pr.project_id = $1 AND pr.environment = $2
                ORDER BY pr.created_at DESC
                LIMIT $3
                """,
                project_id_uuid,
                environment,
                limit,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT pr.*,
                       persons.email AS created_by_email
                FROM project_releases pr
                LEFT JOIN persons ON persons.id = pr.created_by
                WHERE pr.project_id = $1
                ORDER BY pr.created_at DESC
                LIMIT $2
                """,
                project_id_uuid,
                limit,
            )
    return {"items": [_serialize_release(dict(row)) for row in rows]}


@router.post("/{project_id}/governance/releases", summary="Create a governed release snapshot")
async def create_project_release(
    project_id: str,
    release_data: ReleaseCreateRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        project = await _fetch_project_context(conn, project_id_uuid, user_id)
        policy = await _fetch_workspace_policy(conn, project["workspace_id"])
        _require_release_role(project, policy)

        flow = project["flow"] if isinstance(project.get("flow"), dict) else {}
        fingerprint = _flow_fingerprint(flow)
        release_readiness = _build_release_readiness(project)
        ai_config = _get_ai_config_from_flow(flow)
        change_summary = (release_data.change_summary or "").strip() or str(ai_config.get("releaseNotes") or "").strip()
        notes = (release_data.notes or "").strip() or None
        baseline_release = await conn.fetchrow(
            """
            SELECT *
            FROM project_releases
            WHERE project_id = $1 AND environment = $2
            ORDER BY version_no DESC
            LIMIT 1
            """,
            project_id_uuid,
            release_data.environment,
        )
        if not baseline_release and release_data.environment != "draft":
            baseline_release = await conn.fetchrow(
                """
                SELECT *
                FROM project_releases
                WHERE project_id = $1
                ORDER BY created_at DESC
                LIMIT 1
                """,
                project_id_uuid,
            )
        risky_change = _assess_risky_ai_changes(
            (dict(baseline_release).get("flow_snapshot") if baseline_release else {}),
            flow,
        )

        if release_data.environment == "production":
            if not release_readiness["ready_for_production"]:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Production release is blocked until required AI quality gates pass: "
                    + ", ".join(release_readiness["blocking_reasons"]),
                )
            if policy.get("require_change_summary") and not change_summary:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Production releases require a change summary",
                )
            if policy.get("require_approval_for_production") and not release_data.approved:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Production releases require explicit approval confirmation",
                )
            if policy.get("require_staging_for_production"):
                latest_staging = await conn.fetchrow(
                    """
                    SELECT flow_fingerprint
                    FROM project_releases
                    WHERE project_id = $1 AND environment = 'staging'
                    ORDER BY version_no DESC
                    LIMIT 1
                    """,
                    project_id_uuid,
                )
                if not latest_staging or latest_staging["flow_fingerprint"] != fingerprint:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Promote the current flow to staging before releasing it to production",
                    )

        if (
            risky_change.get("has_risky_change")
            and policy.get("require_admin_approval_for_risky_ai_changes")
        ):
            if project["effective_role"] not in {"owner", "admin"}:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Risky AI changes can only be promoted by workspace owners/admins",
                )
            if not release_data.approved or not (release_data.approval_reference or "").strip():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Risky AI changes require approval confirmation and an approval reference",
                )

        next_version = await conn.fetchval(
            """
            SELECT COALESCE(MAX(version_no), 0) + 1
            FROM project_releases
            WHERE project_id = $1 AND environment = $2
            """,
            project_id_uuid,
            release_data.environment,
        )
        approval_metadata = {
            "approved": release_data.approved,
            "approval_reference": (release_data.approval_reference or "").strip() or None,
            "policy_snapshot": policy,
            "release_readiness": release_readiness,
            "risky_change_assessment": risky_change,
        }

        row = await conn.fetchrow(
            """
            INSERT INTO project_releases (
                project_id,
                environment,
                version_no,
                flow_snapshot,
                flow_fingerprint,
                notes,
                change_summary,
                approval_metadata,
                created_by,
                created_at
            )
            VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8::jsonb, $9, NOW())
            RETURNING *
            """,
            project_id_uuid,
            release_data.environment,
            next_version,
            _json_dumps(flow),
            fingerprint,
            notes,
            change_summary or None,
            _json_dumps(approval_metadata),
            user_id,
        )
        release_record = dict(row)
        creator_email = await conn.fetchval(
            "SELECT email FROM persons WHERE id = $1",
            user_id,
        )
        release_record["created_by_email"] = creator_email

        await _write_project_audit_log(
            conn,
            project_id=project["id"],
            workspace_id=project["workspace_id"],
            project_name=project["name"],
            actor_user_id=user_id,
            action="governance.release_created",
            metadata={
                "environment": release_data.environment,
                "version_no": next_version,
                "flow_fingerprint": fingerprint,
                "change_summary": change_summary or None,
            },
        )

    return {"release": _serialize_release(release_record)}


@router.post(
    "/{project_id}/governance/releases/{release_id}/rollback",
    summary="Rollback project flow to a previous release snapshot",
)
async def rollback_project_release(
    project_id: str,
    release_id: int,
    rollback_data: ReleaseRollbackRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        project = await _fetch_project_context(conn, project_id_uuid, user_id)
        _require_admin_role(project)
        release = await conn.fetchrow(
            """
            SELECT *
            FROM project_releases
            WHERE id = $1 AND project_id = $2
            """,
            release_id,
            project_id_uuid,
        )
        if not release:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Release not found",
            )

        await conn.execute(
            """
            UPDATE projects
            SET flow = $1::jsonb,
                updated_at = NOW()
            WHERE id = $2
            """,
            _json_dumps(release["flow_snapshot"] or {}),
            project_id_uuid,
        )
        await _write_project_audit_log(
            conn,
            project_id=project["id"],
            workspace_id=project["workspace_id"],
            project_name=project["name"],
            actor_user_id=user_id,
            action="governance.release_rolled_back",
            metadata={
                "release_id": release_id,
                "environment": release["environment"],
                "version_no": release["version_no"],
                "notes": (rollback_data.notes or "").strip() or None,
            },
        )

    return {
        "result": "success",
        "project_id": project_id,
        "release_id": release_id,
    }


@router.get("/{project_id}/governance/compare", summary="Compare current flow or releases")
async def compare_project_releases(
    project_id: str,
    left_release_id: int = Query(..., ge=1),
    right_release_id: Optional[int] = Query(default=None, ge=1),
    compare_to_current: bool = Query(default=False),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    if not compare_to_current and right_release_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Provide right_release_id or set compare_to_current=true",
        )
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        project = await _fetch_project_context(conn, project_id_uuid, user_id)
        left_release = await conn.fetchrow(
            """
            SELECT pr.*, persons.email AS created_by_email
            FROM project_releases pr
            LEFT JOIN persons ON persons.id = pr.created_by
            WHERE pr.project_id = $1 AND pr.id = $2
            """,
            project_id_uuid,
            left_release_id,
        )
        if not left_release:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Left release not found",
            )

        right_release = None
        if not compare_to_current:
            right_release = await conn.fetchrow(
                """
                SELECT pr.*, persons.email AS created_by_email
                FROM project_releases pr
                LEFT JOIN persons ON persons.id = pr.created_by
                WHERE pr.project_id = $1 AND pr.id = $2
                """,
                project_id_uuid,
                right_release_id,
            )
            if not right_release:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Right release not found",
                )

    left_release_dict = dict(left_release)
    right_release_dict = dict(right_release) if right_release else None
    left_flow = left_release_dict.get("flow_snapshot") or {}
    right_flow = (
        project.get("flow") if compare_to_current else (right_release_dict.get("flow_snapshot") or {})
    )
    comparison = _compare_flows(left_flow, right_flow)
    return {
        "left": {
            "release_id": left_release_dict.get("id"),
            "label": _release_label(left_release_dict, "left release"),
            "environment": left_release_dict.get("environment"),
            "version_no": left_release_dict.get("version_no"),
            "fingerprint": left_release_dict.get("flow_fingerprint"),
        },
        "right": {
            "release_id": right_release_dict.get("id") if right_release_dict else None,
            "label": "current draft" if compare_to_current else _release_label(right_release_dict, "right release"),
            "environment": "current" if compare_to_current else right_release_dict.get("environment"),
            "version_no": None if compare_to_current else right_release_dict.get("version_no"),
            "fingerprint": _flow_fingerprint(right_flow),
        },
        "comparison": comparison,
    }


@router.get("/{project_id}/governance/audit", summary="Get project governance audit log")
async def get_project_audit_log(
    project_id: str,
    limit: int = Query(default=100, ge=1, le=500),
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        project_id_uuid = UUID(project_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project ID format",
        ) from exc

    user_id = await _get_user_id(current_user)
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await _fetch_project_context(conn, project_id_uuid, user_id)
        rows = await conn.fetch(
            """
            SELECT pal.*,
                   persons.email AS actor_email
            FROM project_audit_logs pal
            LEFT JOIN persons ON persons.id = pal.actor_user_id
            WHERE pal.project_id = $1
            ORDER BY pal.created_at DESC
            LIMIT $2
            """,
            project_id_uuid,
            limit,
        )
    return {"items": [_serialize_audit(dict(row)) for row in rows]}
