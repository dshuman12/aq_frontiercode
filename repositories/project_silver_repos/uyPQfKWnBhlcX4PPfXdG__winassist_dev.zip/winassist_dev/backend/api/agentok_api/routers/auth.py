import json
import logging
import os
import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from ..models import (
    AuthResponse,
    ChangePasswordRequest,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    User,
    UserCreate,
    UserLogin,
    UserProfileUpdate,
)
from ..services.database import DatabaseClient
from ..services.auth import get_password_hash, verify_password, create_access_token
from ..services.email import send_password_reset_email
from ..dependencies import get_current_user
from ..utils.datetime import now_ist_naive

logger = logging.getLogger(__name__)
router = APIRouter()

# Password strength rules (must match frontend register.jsx)
def _validate_password_strength(password: str) -> None:
    """Raise HTTPException if password does not meet requirements."""
    if not password or len(password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 8 characters.",
        )
    if not any(c.islower() for c in password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one lowercase letter.",
        )
    if not any(c.isupper() for c in password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one uppercase letter.",
        )
    if not any(c.isdigit() for c in password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one number.",
        )
    special = "!@#$%^&*()_+-=[]{};':\"\\|,.<>/?"
    if not any(c in special for c in password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must contain at least one special character (!@#$%^&* etc.).",
        )


async def get_db():
    """Get database client without authentication"""
    db = DatabaseClient()
    await db.get_pool()
    return db


def _parse_user_metadata(raw_metadata):
    meta = raw_metadata or {}
    if isinstance(meta, str):
        try:
            meta = json.loads(meta) if meta else {}
        except json.JSONDecodeError:
            meta = {}
    return meta if isinstance(meta, dict) else {}


def _build_user_response(user_record) -> User:
    meta = _parse_user_metadata(user_record.get("user_metadata"))
    return User(
        id=user_record["id"],
        email=user_record["email"],
        created_at=user_record["created_at"],
        first_name=meta.get("first_name"),
        last_name=meta.get("last_name"),
        user_name=meta.get("user_name"),
        company_name=meta.get("company_name"),
        mobile_number=meta.get("mobile_number"),
    )


def _normalize_user_id(user_id):
    from uuid import UUID

    if isinstance(user_id, str):
        try:
            return UUID(user_id)
        except ValueError:
            return user_id
    return user_id


@router.post('/register', response_model=AuthResponse, summary="Register new user")
async def register(user_data: UserCreate, db: DatabaseClient = Depends(get_db)):
    """
    Register a new user
    """
    try:
        # Check if user already exists
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            existing_user = await conn.fetchrow(
                "SELECT id FROM persons WHERE email = $1",   # changed table
                user_data.email
            )
            
            if existing_user:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="User with this email already exists"
                )

            _validate_password_strength(user_data.password)

            # Hash password
            hashed_password = get_password_hash(user_data.password)
            user_metadata = json.dumps({
                "first_name": user_data.first_name or "",
                "last_name": user_data.last_name or "",
                "user_name": user_data.user_name or "",
                "company_name": user_data.company_name or "",
                "mobile_number": user_data.mobile_number or "",
            })

            # Create user
            user = await conn.fetchrow(
                """
                INSERT INTO persons (email, password_hash, user_metadata, created_at, updated_at)
                VALUES ($1, $2, $3::jsonb, NOW(), NOW())
                RETURNING id, email, user_metadata, created_at
                """,
                user_data.email,
                hashed_password,
                user_metadata,
            )

            # Ensure exactly one default workspace and membership for this user (personal workspace, role=owner)
            ws_name = "Personal workspace"
            ws = await conn.fetchrow(
                """
                SELECT id
                FROM workspaces
                WHERE owner_id = $1 AND name = $2
                ORDER BY created_at ASC
                LIMIT 1
                """,
                user["id"],
                ws_name,
            )
            if not ws:
                ws = await conn.fetchrow(
                    """
                    INSERT INTO workspaces (owner_id, name, slug, created_at, updated_at)
                    VALUES ($1, $2, NULL, NOW(), NOW())
                    RETURNING id
                    """,
                    user["id"],
                    ws_name,
                )

            await conn.execute(
                """
                INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
                VALUES ($1, $2, 'owner', NOW())
                ON CONFLICT (workspace_id, user_id) DO NOTHING
                """,
                ws["id"],
                user["id"],
            )

            # Create access token - ensure user["id"] is converted to string for JWT
            user_id = str(user["id"]) if user["id"] else None
            access_token = create_access_token(
                data={"id": user_id, "email": user["email"]}
            )
            return AuthResponse(
                user=_build_user_response(user),
                token=access_token
            )
    
    except HTTPException:
        raise
    except ValueError as e:
        # Handle validation errors (e.g., password length)
        logger.error(f"Registration validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Registration error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )


@router.post('/login', response_model=AuthResponse, summary="Login user")
async def login(credentials: UserLogin, db: DatabaseClient = Depends(get_db)):
    """
    Login user with email and password
    """
    try:
        normalized_email = (credentials.email or "").strip().lower()
        if not normalized_email:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password",
            )

        pool = await db.get_pool()
        async with pool.acquire() as conn:
            # Get user
            user = await conn.fetchrow(
                """
                SELECT
                    id, email, password_hash, user_metadata, created_at,
                    COALESCE(is_active, TRUE) AS is_active
                FROM persons
                WHERE LOWER(TRIM(email)) = $1
                LIMIT 1
                """,
                normalized_email,
            )
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid email or password"
                )

            if not user.get("is_active", True):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Your account is inactive. Contact your workspace admin.",
                )
            
            # Verify password
            if not verify_password(credentials.password, user["password_hash"]):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid email or password"
                )
            
            # Create access token - ensure user["id"] is converted to string for JWT
            user_id = str(user["id"]) if user["id"] else None
            access_token = create_access_token(
                data={"id": user_id, "email": user["email"]}
            )
            
            return AuthResponse(
                user=_build_user_response(user),
                token=access_token
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


@router.get('/me', response_model=User, summary="Get current user")
async def get_me(current_user: dict = Depends(get_current_user), db: DatabaseClient = Depends(get_db)):
    """
    Get current authenticated user
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user_id = _normalize_user_id(current_user["id"])
            user = await conn.fetchrow(
                "SELECT id, email, user_metadata, created_at FROM persons WHERE id = $1",
                user_id
            )
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found"
                )
            return _build_user_response(user)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get user error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get user: {str(e)}"
        )


@router.patch('/me', response_model=User, summary="Update current user profile")
async def update_me(
    profile: UserProfileUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_db),
):
    """
    Update the current authenticated user's profile details.
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user_id = _normalize_user_id(current_user["id"])
            user = await conn.fetchrow(
                "SELECT id, email, user_metadata, created_at FROM persons WHERE id = $1",
                user_id,
            )

            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found",
                )

            meta = _parse_user_metadata(user.get("user_metadata"))
            if profile.first_name is not None:
                meta["first_name"] = profile.first_name.strip()
            if profile.last_name is not None:
                meta["last_name"] = profile.last_name.strip()
            if profile.user_name is not None:
                meta["user_name"] = profile.user_name.strip()
            if profile.company_name is not None:
                meta["company_name"] = profile.company_name.strip()
            if profile.mobile_number is not None:
                meta["mobile_number"] = profile.mobile_number.strip()

            updated_user = await conn.fetchrow(
                """
                UPDATE persons
                SET user_metadata = $1::jsonb, updated_at = NOW()
                WHERE id = $2
                RETURNING id, email, user_metadata, created_at
                """,
                json.dumps(meta),
                user_id,
            )

            return _build_user_response(updated_user)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update profile error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update profile.",
        )


@router.post('/change-password', summary="Change current user password")
async def change_password(
    body: ChangePasswordRequest,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_db),
):
    """
    Change the current authenticated user's password.
    """
    try:
        if body.current_password == body.new_password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="New password must be different from the current password.",
            )

        _validate_password_strength(body.new_password)

        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT id, password_hash FROM persons WHERE id = $1",
                _normalize_user_id(current_user["id"]),
            )
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found",
                )

            if not verify_password(body.current_password, user["password_hash"]):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Current password is incorrect.",
                )

            updated_password_hash = get_password_hash(body.new_password)
            await conn.execute(
                """
                UPDATE persons
                SET password_hash = $1, updated_at = NOW()
                WHERE id = $2
                """,
                updated_password_hash,
                user["id"],
            )

            return {"message": "Password updated successfully."}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Change password error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update password.",
        )


@router.post('/forgot-password', summary="Request password reset")
async def forgot_password(body: ForgotPasswordRequest, db: DatabaseClient = Depends(get_db)):
    """
    Request a password reset. If the email exists, a reset token is generated.
    When SMTP is configured, a reset link is sent by email. Otherwise the token is returned
    so the frontend can show the link (e.g. for development).
    """
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT id, email FROM persons WHERE email = $1",
                body.email,
            )
            if not user:
                return {"message": "If an account exists with this email, you will receive reset instructions."}
            token = secrets.token_urlsafe(32)
            expires = now_ist_naive() + timedelta(hours=1)
            await conn.execute(
                """
                UPDATE persons
                SET reset_token = $1, reset_token_expires_at = $2
                WHERE id = $3
                """,
                token,
                expires,
                user["id"],
            )

        frontend_url = (os.getenv("FRONTEND_URL") or "").strip().rstrip("/")
        reset_link = f"{frontend_url}/auth/reset-password?token={token}" if frontend_url else None

        email_sent = False
        if reset_link:
            email_sent, email_error = send_password_reset_email(to_email=user["email"], reset_link=reset_link)
            if email_sent:
                logger.info("Password reset email sent to %s", user["email"])
            elif email_error:
                logger.warning("Password reset email not sent to %s: %s", user["email"], email_error)

        response = {"message": "If an account exists with this email, you will receive reset instructions."}
        if not email_sent and reset_link:
            response["token"] = token
        return response
    except Exception as e:
        logger.error(f"Forgot password error: {str(e)}")
        return {"message": "If an account exists with this email, you will receive reset instructions."}


@router.post('/reset-password', summary="Reset password with token")
async def reset_password(body: ResetPasswordRequest, db: DatabaseClient = Depends(get_db)):
    """
    Reset password using the token from the forgot-password flow.
    """
    try:
        _validate_password_strength(body.new_password)
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                """
                SELECT id FROM persons
                WHERE reset_token = $1 AND reset_token_expires_at > NOW()
                """,
                body.token,
            )
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid or expired reset link. Please request a new one.",
                )
            hashed = get_password_hash(body.new_password)
            await conn.execute(
                """
                UPDATE persons
                SET password_hash = $1, reset_token = NULL, reset_token_expires_at = NULL
                WHERE id = $2
                """,
                hashed,
                user["id"],
            )
            return {"message": "Password has been reset. You can now sign in."}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reset password error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to reset password.",
        )
