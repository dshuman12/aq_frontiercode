# routers/projects.py - Fixed projects router with proper JSONB handling
import logging
import json
import asyncio
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID
import re

from ..services.database import DatabaseClient
from ..dependencies import get_database_client, get_current_user
from ..utils.apikey import generate_bot_api_key
from ..utils.ai_quality import evaluate_cases, generate_training_suggestions
from ..utils.nlu import (
    analyze_query,
    classify_intent,
    extract_entities,
    inspect_entities,
    inspect_intents,
)

logger = logging.getLogger(__name__)
router = APIRouter()


async def _generate_unique_project_name(conn, user_id, workspace_id, requested_name, project_type):
    base_name = (requested_name or '').strip() or (
        'Chatflow' if project_type == 'frontend' else 'New AI Agent Project'
    )

    rows = await conn.fetch(
        """
        SELECT name
        FROM projects
        WHERE user_id = $1
          AND workspace_id = $2
          AND project_type = $3
        """,
        user_id,
        workspace_id,
        project_type,
    )

    existing_names = {(row["name"] or "").strip() for row in rows}
    if base_name not in existing_names:
        return base_name

    escaped = re.escape(base_name)
    pattern = re.compile(rf"^{escaped}(\d+)?$")
    max_suffix = 0

    for name in existing_names:
        match = pattern.match(name)
        if not match:
            continue
        suffix = match.group(1)
        parsed = int(suffix) if suffix is not None else 0
        if parsed > max_suffix:
            max_suffix = parsed

    return f"{base_name}{max_suffix + 1}"


async def acquire_connection_with_timeout(pool, timeout=5.0):
    """Acquire a database connection with timeout to prevent hanging"""
    try:
        return await asyncio.wait_for(pool.acquire(), timeout=timeout)
    except asyncio.TimeoutError:
        logger.error(f"Timeout acquiring database connection after {timeout}s - pool may be exhausted")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database connection timeout. Please try again in a moment."
        )


# -------------------------
# Pydantic Models
# -------------------------
class ProjectBase(BaseModel):
    name: str
    description: Optional[str] = None
    flow: Optional[dict] = None
    project_type: Optional[str] = None
    workspace_id: Optional[UUID] = None


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    flow: Optional[dict] = None
    project_type: Optional[str] = None
    workspace_id: Optional[UUID] = None


class QueryTestBody(BaseModel):
    query: str
    language: Optional[str] = None


class EvaluationRunBody(BaseModel):
    cases: List[Dict[str, Any]] = Field(default_factory=list)


class Project(ProjectBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    api_key: Optional[str] = None  # Bot API key for widget authentication

    class Config:
        from_attributes = True


# -------------------------
# Utility
# -------------------------
def deserialize_flow(project_dict: dict) -> dict:
    """Ensure flow is always a dict or None for response model; never a JSON string."""
    raw = project_dict.get("flow")
    if raw is None:
        return project_dict
    if isinstance(raw, dict):
        return project_dict
    # DB may return JSONB as string (e.g. from template clone or some drivers)
    s = raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else str(raw)
    try:
        project_dict["flow"] = json.loads(s)
        if not isinstance(project_dict["flow"], dict):
            project_dict["flow"] = {}
    except Exception:
        project_dict["flow"] = {}
    return project_dict


async def record_project_audit(
    conn,
    *,
    project_id,
    workspace_id,
    project_name,
    actor_user_id,
    action,
    metadata: Optional[dict] = None,
):
    try:
        await conn.execute(
            """
            INSERT INTO project_audit_logs (
                project_id,
                workspace_id,
                project_name,
                actor_user_id,
                action,
                metadata,
                created_at
            )
            VALUES ($1, $2, $3, $4, $5, $6::jsonb, NOW())
            """,
            project_id,
            workspace_id,
            project_name,
            actor_user_id,
            action,
            json.dumps(metadata or {}),
        )
    except Exception as exc:
        logger.warning("Failed to write project audit log for %s: %s", action, exc)


# -------------------------
# Routes
# -------------------------

async def _get_user_id(current_user: dict) -> UUID:
    user_id = current_user["id"]
    if isinstance(user_id, str):
        try:
            user_id = UUID(user_id)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user ID format",
            )
    return user_id


async def _get_user_workspace_ids(conn, user_id: UUID) -> List[UUID]:
    rows = await conn.fetch(
        """
        SELECT workspace_id
        FROM workspace_members
        WHERE user_id = $1
        """,
        user_id,
    )
    return [row["workspace_id"] for row in rows]


async def _fetch_authorized_project_row(conn, user_id: UUID, project_id_uuid: UUID):
    project = await conn.fetchrow(
        """
        SELECT p.id,
               p.user_id,
               p.workspace_id,
               p.name,
               p.description,
               p.flow,
               p.project_type,
               p.api_key,
               p.created_at,
               p.updated_at,
               wm.role AS member_role
        FROM projects p
        LEFT JOIN workspace_members wm
          ON p.workspace_id = wm.workspace_id
         AND wm.user_id = $1
        WHERE p.id = $2
        """,
        user_id,
        project_id_uuid,
    )
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found",
        )
    if project["workspace_id"] is None and project["user_id"] != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to access this project",
        )
    if project["workspace_id"] is not None and project["member_role"] is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not a member of the project workspace",
        )
    return deserialize_flow(dict(project))


@router.get('', response_model=List[Project], summary="Get all projects", include_in_schema=True)
async def get_projects(
    project_type: Optional[str] = None,
    workspace_id: Optional[UUID] = None,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Get projects for the current user.
    - If workspace_id is provided, return only projects from that workspace (user must be a member).
    - Otherwise return all projects the user owns or can access across all workspaces.
    Optionally filter further by project_type.
    """
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            if workspace_id is not None:
                # Verify the caller is a member of the requested workspace
                membership = await conn.fetchrow(
                    """
                    SELECT role FROM workspace_members
                    WHERE workspace_id = $1 AND user_id = $2
                    """,
                    workspace_id,
                    user_id,
                )
                if not membership:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not a member of this workspace",
                    )

                # Return only projects belonging to that workspace
                params: list = [workspace_id]
                query = """
                    SELECT id, user_id, name, description, flow, project_type,
                           api_key, workspace_id, created_at, updated_at
                    FROM projects
                    WHERE workspace_id = $1
                """
                if project_type:
                    params.append(project_type)
                    query += f" AND project_type = ${len(params)}"
                query += " ORDER BY updated_at DESC"
                projects = await conn.fetch(query, *params)

            else:
                # No workspace filter: return personal projects + all workspace projects the user belongs to
                workspace_ids = await _get_user_workspace_ids(conn, user_id)
                params = [user_id]
                workspace_filter = ""
                if workspace_ids:
                    params.append(workspace_ids)
                    workspace_filter = "OR workspace_id = ANY($2)"

                base_query = f"""
                    SELECT id, user_id, name, description, flow, project_type,
                           api_key, workspace_id, created_at, updated_at
                    FROM projects
                    WHERE (user_id = $1 AND workspace_id IS NULL)
                    {workspace_filter}
                """
                if project_type:
                    params.append(project_type)
                    query_type_idx = len(params)
                    projects = await conn.fetch(
                        base_query + f" AND project_type = ${query_type_idx} ORDER BY updated_at DESC",
                        *params,
                    )
                else:
                    projects = await conn.fetch(base_query + " ORDER BY updated_at DESC", *params)

            # Normalize user_id fields
            normalized_projects = []
            for project in projects:
                project_dict = deserialize_flow(dict(project))
                uid = project_dict.get('user_id')
                if uid is not None:
                    if isinstance(uid, int):
                        logger.error(f"Integer user_id {uid} found — migration may not be complete")
                        raise HTTPException(
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Database migration may not be complete. Found integer user_id {uid}.",
                        )
                    elif isinstance(uid, str):
                        try:
                            project_dict['user_id'] = UUID(uid)
                        except ValueError:
                            pass
                normalized_projects.append(project_dict)
            return normalized_projects
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get projects error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get projects: {str(e)}"
        )


@router.post('/', response_model=Project, status_code=status.HTTP_201_CREATED, summary="Create new project")
async def create_project(
    project_data: ProjectCreate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    try:
        logger.info(f"Creating project: {project_data}")
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            # Determine workspace_id: use provided or default to first workspace
            workspace_id = project_data.workspace_id
            if workspace_id is not None:
                # Ensure user is member of this workspace
                membership = await conn.fetchrow(
                    """
                    SELECT role FROM workspace_members
                    WHERE workspace_id = $1 AND user_id = $2
                    """,
                    workspace_id,
                    user_id,
                )
                if not membership:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You are not a member of this workspace",
                    )
                # Simple role check: only owner/admin/member can create
                if membership["role"] not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Insufficient role to create projects in this workspace",
                    )
            else:
                # No workspace specified; default to first (or create personal)
                from ..routers.workspaces import _ensure_default_workspace

                default_ws = await _ensure_default_workspace(db, user_id)
                workspace_id = default_ws.id

            # ✅ Convert dict to JSON string for JSONB column
            flow_value = json.dumps(project_data.flow) if project_data.flow is not None else None

            # Generate API key for backend projects
            api_key = None
            if project_data.project_type == 'backend':
                api_key = generate_bot_api_key()
                logger.info(f"Generated API key for backend project: {api_key[:20]}...")

            unique_name = await _generate_unique_project_name(
                conn,
                user_id,
                workspace_id,
                project_data.name,
                project_data.project_type,
            )

            project = await conn.fetchrow(
                """
                INSERT INTO projects (user_id, workspace_id, name, description, flow, project_type, api_key, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7, NOW(), NOW())
                RETURNING id, user_id, workspace_id, name, description, flow, project_type, api_key, created_at, updated_at
                """,
                user_id,
                workspace_id,
                unique_name,
                project_data.description,
                flow_value,
                project_data.project_type,
                api_key,
            )

            await record_project_audit(
                conn,
                project_id=project["id"],
                workspace_id=project["workspace_id"],
                project_name=project["name"],
                actor_user_id=user_id,
                action="project.created",
                metadata={"project_type": project["project_type"]},
            )

            project_dict = deserialize_flow(dict(project))
            # Normalize user_id to UUID if needed
            if 'user_id' in project_dict and project_dict['user_id'] is not None:
                user_id_val = project_dict['user_id']
                if isinstance(user_id_val, int):
                    logger.error(f"Project {project_dict.get('id')} has integer user_id {user_id_val} - migration may not be complete")
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Database migration may not be complete. Found integer user_id {user_id_val}. Please ensure the migration script has been run successfully."
                    )
                elif isinstance(user_id_val, str):
                    try:
                        project_dict['user_id'] = UUID(user_id_val)
                    except ValueError:
                        pass
            return project_dict
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create project error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create project: {str(e)}"
        )


@router.get('/{project_id}', response_model=Project, summary="Get project by ID")
async def get_project(
    project_id: str,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            # Convert project_id to UUID
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project_dict = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            # Normalize user_id to UUID if needed
            if 'user_id' in project_dict and project_dict['user_id'] is not None:
                user_id_val = project_dict['user_id']
                if isinstance(user_id_val, int):
                    logger.error(f"Project {project_dict.get('id')} has integer user_id {user_id_val} - migration may not be complete")
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Database migration may not be complete. Found integer user_id {user_id_val}. Please ensure the migration script has been run successfully."
                    )
                elif isinstance(user_id_val, str):
                    try:
                        project_dict['user_id'] = UUID(user_id_val)
                    except ValueError:
                        pass
            return project_dict
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get project error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get project: {str(e)}"
        )


@router.put('/{project_id}', response_model=Project, summary="Update project")
async def update_project(
    project_id: str,
    project_data: ProjectUpdate,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            # Convert project_id to UUID
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            # First, check current project type, api key and workspace / role
            current_project = await conn.fetchrow(
                """
                SELECT p.project_type,
                       p.api_key,
                       p.user_id,
                       p.workspace_id,
                       wm.role AS member_role
                FROM projects p
                LEFT JOIN workspace_members wm
                  ON p.workspace_id = wm.workspace_id
                 AND wm.user_id = $1
                WHERE p.id = $2
                """,
                user_id,
                project_id_uuid,
            )

            if not current_project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found",
                )

            # Authorization:
            # - If workspace_id is NULL, only owner (user_id) can update
            # - If workspace_id is set, owner/admin/member can update (viewer cannot)
            if current_project["workspace_id"] is None:
                if current_project["user_id"] != user_id:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to update this project",
                    )
                member_role = "owner"
            else:
                member_role = current_project["member_role"]
                if member_role not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Viewers cannot update projects. Only members and above can edit.",
                    )

            updates = []
            values = []
            param_count = 1

            if project_data.name is not None:
                updates.append(f"name = ${param_count}")
                values.append(project_data.name)
                param_count += 1

            if project_data.description is not None:
                updates.append(f"description = ${param_count}")
                values.append(project_data.description)
                param_count += 1

            if project_data.flow is not None:
                flow_value = json.dumps(project_data.flow)
                updates.append(f"flow = ${param_count}::jsonb")
                values.append(flow_value)
                param_count += 1

            if project_data.project_type is not None:
                updates.append(f"project_type = ${param_count}")
                values.append(project_data.project_type)
                param_count += 1

            if project_data.workspace_id is not None:
                # Changing workspace: ensure caller is member of target workspace with sufficient role
                membership = await conn.fetchrow(
                    """
                    SELECT role FROM workspace_members
                    WHERE workspace_id = $1 AND user_id = $2
                    """,
                    project_data.workspace_id,
                    user_id,
                )
                if not membership or membership["role"] not in ("owner", "admin"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not allowed to move project to this workspace",
                    )
                updates.append(f"workspace_id = ${param_count}")
                values.append(project_data.workspace_id)
                param_count += 1

            # Generate API key if project is backend and doesn't have one
            new_project_type = project_data.project_type or current_project["project_type"]
            current_api_key = current_project["api_key"]

            if new_project_type == "backend" and not current_api_key:
                new_api_key = generate_bot_api_key()
                logger.info(f"Generating API key for existing backend project {project_id}")
                updates.append(f"api_key = ${param_count}")
                values.append(new_api_key)
                param_count += 1

            if not updates:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="No fields to update"
                )

            updates.append("updated_at = NOW()")
            values.extend([project_id_uuid])

            query = f"""
                UPDATE projects
                SET {', '.join(updates)}
                WHERE id = ${param_count}
                RETURNING id, user_id, workspace_id, name, description, flow, project_type, api_key, created_at, updated_at
            """

            project = await conn.fetchrow(query, *values)

            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )

            await record_project_audit(
                conn,
                project_id=project["id"],
                workspace_id=project["workspace_id"],
                project_name=project["name"],
                actor_user_id=user_id,
                action="project.updated",
                metadata={
                    "updated_fields": sorted(
                        field
                        for field, value in project_data.model_dump().items()
                        if value is not None
                    )
                },
            )

            project_dict = deserialize_flow(dict(project))
            # Normalize user_id to UUID if needed
            if 'user_id' in project_dict and project_dict['user_id'] is not None:
                user_id_val = project_dict['user_id']
                if isinstance(user_id_val, int):
                    logger.error(f"Project {project_dict.get('id')} has integer user_id {user_id_val} - migration may not be complete")
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Database migration may not be complete. Found integer user_id {user_id_val}. Please ensure the migration script has been run successfully."
                    )
                elif isinstance(user_id_val, str):
                    try:
                        project_dict['user_id'] = UUID(user_id_val)
                    except ValueError:
                        pass
            return project_dict
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update project error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update project: {str(e)}"
        )


@router.delete('/{project_id}', summary="Delete project")
async def delete_project(
    project_id: str,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            # Convert project_id to UUID
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            # Check project and membership/ownership, and get widget_script_url for cleanup
            project = await conn.fetchrow(
                """
                SELECT p.id,
                       p.user_id,
                       p.workspace_id,
                       p.name,
                       p.project_type,
                       p.widget_script_url,
                       wm.role AS member_role
                FROM projects p
                LEFT JOIN workspace_members wm
                  ON p.workspace_id = wm.workspace_id
                 AND wm.user_id = $1
                WHERE p.id = $2
                """,
                user_id,
                project_id_uuid,
            )

            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found",
                )

            # Authorization:
            # - If workspace_id is NULL, only owner (user_id) can delete
            # - If workspace_id is set, owner/admin/member can delete (viewer cannot)
            if project["workspace_id"] is None:
                if project["user_id"] != user_id:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not authorized to delete this project",
                    )
            else:
                if project["member_role"] not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Viewers cannot delete projects. Only members and above can delete.",
                    )

            # Best-effort: delete any saved widget script file for frontend projects
            try:
                if (
                    project["project_type"] == "frontend"
                    and project.get("widget_script_url")
                ):
                    widget_url = project["widget_script_url"]
                    # Only handle local static/widget URLs; skip if it's some external URL
                    # Expected pattern: <base>/static/widgets/<filename>.js
                    parts = widget_url.split("/static/widgets/")
                    if len(parts) == 2 and parts[1]:
                        filename = parts[1]
                        # Reuse the same logic as save_widget_script to locate static dir
                        api_dir = os.path.dirname(
                            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                        )
                        backend_base = (os.getenv("WIDGET_STATIC_BASE_PATH") or "").strip()
                        if backend_base:
                            static_dir = os.path.join(backend_base.rstrip("/"), "static")
                        else:
                            static_dir = os.path.join(api_dir, "static")
                        widgets_dir = os.path.join(static_dir, "widgets")
                        filepath = os.path.join(widgets_dir, filename)
                        try:
                            os.remove(filepath)
                            logger.info(
                                "Deleted widget script file %s for project %s",
                                filepath,
                                project_id_uuid,
                            )
                        except FileNotFoundError:
                            logger.info(
                                "Widget script file %s not found for project %s; skipping",
                                filepath,
                                project_id_uuid,
                            )
                        except Exception as file_err:
                            logger.error(
                                "Failed to delete widget script file for project %s: %s",
                                project_id_uuid,
                                file_err,
                            )
            except Exception:
                # Don't block project deletion if cleanup fails
                pass

            await record_project_audit(
                conn,
                project_id=project["id"],
                workspace_id=project["workspace_id"],
                project_name=project["name"],
                actor_user_id=user_id,
                action="project.deleted",
                metadata={"project_type": project["project_type"]},
            )

            result = await conn.fetchrow(
                """
                DELETE FROM projects
                WHERE id = $1
                RETURNING id
                """,
                project_id_uuid,
            )

            if not result:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found",
                )

            return {"result": "success"}
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete project error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete project: {str(e)}"
        )


@router.post('/{project_id}/regenerate-api-key', summary="Regenerate API key for project")
async def regenerate_api_key(
    project_id: str,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client)
):
    """
    Regenerate the API key for a backend project.
    Old API key will be invalidated immediately.
    Only project owner or workspace owner/admin/member can regenerate.
    """
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)

            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format"
                )

            project = await conn.fetchrow(
                """
                SELECT p.id, p.name, p.project_type, p.user_id, p.workspace_id, wm.role AS member_role
                FROM projects p
                LEFT JOIN workspace_members wm
                  ON p.workspace_id = wm.workspace_id AND wm.user_id = $1
                WHERE p.id = $2
                """,
                user_id,
                project_id_uuid,
            )

            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )

            if project["project_type"] != "backend":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="API keys are only available for backend projects"
                )

            if project["workspace_id"] is None:
                if project["user_id"] != user_id:
                    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized")
            else:
                if project["member_role"] not in ("owner", "admin", "member"):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Viewers cannot regenerate API keys",
                    )

            new_api_key = generate_bot_api_key()
            logger.info(f"Regenerating API key for project {project_id}")

            result = await conn.fetchrow(
                """
                UPDATE projects
                SET api_key = $1, updated_at = NOW()
                WHERE id = $2
                RETURNING id, api_key
                """,
                new_api_key,
                project_id_uuid,
            )

            await record_project_audit(
                conn,
                project_id=project["id"],
                workspace_id=project["workspace_id"],
                project_name=project["name"],
                actor_user_id=user_id,
                action="project.api_key_regenerated",
                metadata={"project_type": project["project_type"]},
            )

            return {"id": result["id"], "api_key": result["api_key"]}
        finally:
            await pool.release(conn)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Regenerate API key error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to regenerate API key: {str(e)}"
        )


@router.post('/{project_id}/ai/intent-test', summary="Test bot intent classification")
async def test_project_intents(
    project_id: str,
    body: QueryTestBody,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            analysis = analyze_query(body.query, {**ai_config, "queryLanguageHint": body.language})
            return {
                **(analysis.get("intent_result") or {}),
                "detected_language": analysis.get("detected_language"),
            }
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Intent test error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to test intents: {str(e)}"
        )


@router.post('/{project_id}/ai/entity-test', summary="Test bot entity extraction")
async def test_project_entities(
    project_id: str,
    body: QueryTestBody,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            analysis = analyze_query(body.query, {**ai_config, "queryLanguageHint": body.language})
            return {
                **(analysis.get("entity_result") or {}),
                "detected_language": analysis.get("detected_language"),
            }
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Entity test error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to test entities: {str(e)}"
        )


@router.post('/{project_id}/ai/analyze', summary="Run combined bot NLU analysis")
async def analyze_project_query(
    project_id: str,
    body: QueryTestBody,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            return analyze_query(body.query, {**ai_config, "queryLanguageHint": body.language})
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"NLU analysis error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to analyze query: {str(e)}"
        )


@router.get('/{project_id}/ai/nlu-insights', summary="Get bot NLU configuration insights")
async def get_project_nlu_insights(
    project_id: str,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            intents = ai_config.get("intents") or []
            entities = ai_config.get("entities") or []
            return {
                "intent_insights": inspect_intents(intents),
                "entity_insights": inspect_entities(entities),
            }
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"NLU insights error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to load NLU insights: {str(e)}"
        )


@router.post('/{project_id}/ai/evaluate', summary="Run bot evaluation cases")
async def evaluate_project_ai(
    project_id: str,
    body: EvaluationRunBody,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            return evaluate_cases(body.cases or [], ai_config)
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"AI evaluation error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to evaluate bot: {str(e)}"
        )


@router.get('/{project_id}/ai/improvement-suggestions', summary="Generate automated AI improvement suggestions")
async def get_project_improvement_suggestions(
    project_id: str,
    limit: int = 25,
    current_user: dict = Depends(get_current_user),
    db: DatabaseClient = Depends(get_database_client),
):
    try:
        pool = await db.get_pool()
        conn = await acquire_connection_with_timeout(pool)
        try:
            user_id = await _get_user_id(current_user)
            try:
                project_id_uuid = UUID(project_id)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid project ID format",
                )

            project = await _fetch_authorized_project_row(conn, user_id, project_id_uuid)
            ai_config = (
                project.get("flow", {}).get("ai_config", {})
                if isinstance(project.get("flow"), dict)
                else {}
            )
            rows = await conn.fetch(
                """
                SELECT content
                FROM chat_messages
                WHERE project_id = $1
                  AND (
                    LOWER(COALESCE(type, '')) = 'user'
                    OR LOWER(COALESCE(sender, '')) = 'user'
                  )
                  AND COALESCE(TRIM(content), '') <> ''
                ORDER BY created_at DESC
                LIMIT $2
                """,
                project_id_uuid,
                max(1, min(int(limit or 25), 100)),
            )
            recent_queries = [str(row["content"] or "").strip() for row in rows if str(row["content"] or "").strip()]
            return generate_training_suggestions(recent_queries, ai_config)
        finally:
            await pool.release(conn)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Improvement suggestion error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate improvement suggestions: {str(e)}"
        )
