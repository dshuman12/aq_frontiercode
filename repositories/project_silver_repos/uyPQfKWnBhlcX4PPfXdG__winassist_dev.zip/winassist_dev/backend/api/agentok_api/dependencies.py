# dependencies.py - Updated version
import logging
from pathlib import Path
from typing import Optional
import time

from fastapi import Depends, HTTPException, Header, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .services.auth import verify_token
from .services import (
    ChatService,
    CodegenService,
    DatabaseClient,
    ToolService,
)
from .services.idm import verify_idm_api_key
from .utils.apikey import is_valid_bot_api_key

logger = logging.getLogger(__name__)

# In-memory TTL cache so we don't hit Postgres on every request.
# `_bootstrap_user_records` is only needed to initialize local rows (persons, default workspace).
# Doing it on every API call makes the app feel slow.
_BOOTSTRAP_CACHE = {}
_BOOTSTRAP_CACHE_TTL_S = 300

_ACTIVE_CACHE = {}
_ACTIVE_CACHE_TTL_S = 10


async def _bootstrap_user_records_cached(user_id, email: Optional[str]):
    key = (str(user_id), (email or "").strip().lower())
    now = time.time()
    hit = _BOOTSTRAP_CACHE.get(key)
    if hit:
        cached_id, ts = hit
        if now - ts < _BOOTSTRAP_CACHE_TTL_S:
            return cached_id
    canonical_id = await _bootstrap_user_records(user_id, email)
    _BOOTSTRAP_CACHE[key] = (canonical_id, now)
    return canonical_id


async def _is_user_active_cached(user_id) -> bool:
    key = str(user_id)
    now = time.time()
    hit = _ACTIVE_CACHE.get(key)
    if hit:
        active, ts = hit
        if now - ts < _ACTIVE_CACHE_TTL_S:
            return bool(active)
    db = DatabaseClient()
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        active = await conn.fetchval(
            "SELECT COALESCE(is_active, TRUE) FROM persons WHERE id = $1",
            user_id,
        )
    _ACTIVE_CACHE[key] = (bool(active), now)
    return bool(active)


security_scheme = HTTPBearer(auto_error=True)

optional_security_scheme = HTTPBearer(auto_error=False)

async def _bootstrap_user_records(user_id, email: Optional[str]):
    """
    Ensure minimal local DB state exists for an externally-authenticated identity:
    - persons row
    - personal workspace + membership
    """
    db = DatabaseClient()
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        # persons
        from .services.auth import get_password_hash

        placeholder_hash = get_password_hash("no-password-set")
        normalized_email = (email or "").strip().lower()
        if normalized_email:
            existing_id = await conn.fetchval(
                "SELECT id FROM persons WHERE LOWER(TRIM(email)) = $1 LIMIT 1",
                normalized_email,
            )
            if existing_id:
                # If this email already exists, treat that row as the canonical local identity
                # (avoids unique constraint failures when OIDC subject->UUID differs).
                user_id = existing_id
                await conn.execute(
                    "UPDATE persons SET updated_at = NOW() WHERE id = $1",
                    user_id,
                )
            else:
                # Insert by id/email; if another request inserts same email concurrently, upsert by email.
                user_id = await conn.fetchval(
                    """
                    INSERT INTO persons (id, email, password_hash, created_at, updated_at)
                    VALUES ($1, $2, $3, NOW(), NOW())
                    ON CONFLICT (email) DO UPDATE
                      SET updated_at = NOW()
                    RETURNING id
                    """,
                    user_id,
                    normalized_email,
                    placeholder_hash,
                )
        else:
            # No email: ensure id exists with a placeholder email (stable, unique per id)
            await conn.execute(
                """
                INSERT INTO persons (id, email, password_hash, created_at, updated_at)
                VALUES ($1, $2, $3, NOW(), NOW())
                ON CONFLICT (id) DO UPDATE SET updated_at = NOW()
                """,
                user_id,
                f"user_{user_id}@idm.local",
                placeholder_hash,
            )

        # personal workspace + membership
        # Avoid race conditions creating multiple default workspaces.
        await conn.execute(
            "SELECT pg_advisory_xact_lock(hashtext($1::text))",
            str(user_id),
        )

        ws_name = "Personal workspace"
        ws_id = await conn.fetchval(
            """
            SELECT id
            FROM workspaces
            WHERE owner_id = $1 AND name = $2
            ORDER BY created_at ASC
            LIMIT 1
            """,
            user_id,
            ws_name,
        )
        if not ws_id:
            ws_id = await conn.fetchval(
                """
                INSERT INTO workspaces (owner_id, name, slug, created_at, updated_at)
                VALUES ($1, $2, NULL, NOW(), NOW())
                RETURNING id
                """,
                user_id,
                ws_name,
            )

        await conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES ($1, $2, 'owner', NOW())
            ON CONFLICT (workspace_id, user_id) DO NOTHING
            """,
            ws_id,
            user_id,
        )

        return user_id


def _extract_idm_key_from_auth_header(credentials: Optional[HTTPAuthorizationCredentials]) -> Optional[str]:
    if not credentials or not credentials.credentials:
        return None
    # Accept non-JWT API keys in Authorization header as well.
    # `HTTPBearer` only parses "Bearer <token>", so this is a best-effort fallback:
    # if the token fails JWT verification later, we can treat it as an IDM API key.
    return credentials.credentials


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security_scheme),
    x_idm_api_key: Optional[str] = Header(None, alias="X-IDM-API-Key"),
) -> dict:
    """
    Verify authentication and return current user info.

    Supported:
    - Bearer JWT (legacy)
    - IDM API key via `X-IDM-API-Key`
    """
    if x_idm_api_key:
        identity = await verify_idm_api_key(x_idm_api_key)
        canonical_id = await _bootstrap_user_records_cached(identity["id"], identity.get("email"))
        if not await _is_user_active_cached(canonical_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is inactive. Contact your workspace admin.",
            )
        identity = dict(identity)
        identity["id"] = canonical_id
        return identity

    token = credentials.credentials
    
    try:
        payload = verify_token(token)
        user_id = payload.get("id")
        email = payload.get("email")

        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
            )

        # Convert string UUID to UUID object if needed
        from uuid import UUID
        if isinstance(user_id, str):
            try:
                user_id = UUID(user_id)
            except ValueError:
                pass  # Keep as string if not valid UUID

        # If the identity comes from an external IdP (Keycloak/OIDC), ensure
        # DB rows exist so downstream routes don't create placeholder emails.
        canonical_id = await _bootstrap_user_records_cached(user_id, email)
        if not await _is_user_active_cached(canonical_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is inactive. Contact your workspace admin.",
            )
        return {"id": canonical_id, "email": email, "auth_type": "jwt"}
    except HTTPException:
        raise
    except Exception as e:
        # If JWT verification fails, fall back to treating the token as an IDM API key.
        try:
            identity = await verify_idm_api_key(token)
            canonical_id = await _bootstrap_user_records_cached(identity["id"], identity.get("email"))
            if not await _is_user_active_cached(canonical_id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Your account is inactive. Contact your workspace admin.",
                )
            identity = dict(identity)
            identity["id"] = canonical_id
            return identity
        except HTTPException:
            logger.error(f"Authentication error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
            )


async def get_current_user_or_bot(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(optional_security_scheme),
    x_bot_api_key: Optional[str] = Header(None, alias="X-Bot-API-Key"),
    x_idm_api_key: Optional[str] = Header(None, alias="X-IDM-API-Key"),
) -> dict:
    """
    Authenticate via:
    - bot API key (X-Bot-API-Key)
    - IDM API key (X-IDM-API-Key)
    - Bearer JWT (legacy)
    """
    
    if x_bot_api_key:
        logger.debug("Attempting bot API key authentication")
        
        if not is_valid_bot_api_key(x_bot_api_key):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid bot API key format",
            )

        db = DatabaseClient()
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            project = await conn.fetchrow(
                "SELECT id, user_id, name, project_type FROM projects WHERE api_key = $1",
                x_bot_api_key
            )
            
            if not project:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid bot API key",
                )
            
     
            await conn.execute(
                """
                UPDATE projects 
                SET api_key_last_used_at = NOW(), 
                    api_key_usage_count = COALESCE(api_key_usage_count, 0) + 1
                WHERE api_key = $1
                """,
                x_bot_api_key
            )
            
            logger.debug(f"Bot API key authenticated for project: {project['id']}")
            
            # Ensure user_id is UUID if it's a string
            user_id = project['user_id']
            from uuid import UUID
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    pass  # Keep as string if not valid UUID
            
            return {
                "id": user_id,
                "email": f"bot_{project['id']}@bot.local",  # Synthetic email
                "auth_type": "bot_api_key",
                "bot_project_id": project['id'],
                "bot_project_name": project['name']
            }

    if x_idm_api_key:
        identity = await verify_idm_api_key(x_idm_api_key)
        canonical_id = await _bootstrap_user_records_cached(identity["id"], identity.get("email"))
        if not await _is_user_active_cached(canonical_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account is inactive. Contact your workspace admin.",
            )
        identity = dict(identity)
        identity["id"] = canonical_id
        return identity
    
    if credentials and credentials.credentials:
        token = credentials.credentials
        try:
            payload = verify_token(token)
            user_id = payload.get("id")
            email = payload.get("email")
            
            if user_id is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid authentication credentials",
                )
            
            # Convert string UUID to UUID object if needed
            from uuid import UUID
            if isinstance(user_id, str):
                try:
                    user_id = UUID(user_id)
                except ValueError:
                    pass  # Keep as string if not valid UUID

            canonical_id = await _bootstrap_user_records_cached(user_id, email)
            if not await _is_user_active_cached(canonical_id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Your account is inactive. Contact your workspace admin.",
                )

            return {"id": canonical_id, "email": email, "auth_type": "jwt"}
        except HTTPException:
            raise
        except Exception as e:
            # Fallback: treat bearer token as IDM API key if JWT fails
            try:
                identity = await verify_idm_api_key(_extract_idm_key_from_auth_header(credentials) or token)
                canonical_id = await _bootstrap_user_records_cached(identity["id"], identity.get("email"))
                if not await _is_user_active_cached(canonical_id):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Your account is inactive. Contact your workspace admin.",
                    )
                identity = dict(identity)
                identity["id"] = canonical_id
                return identity
            except HTTPException:
                logger.error(f"JWT authentication error: {str(e)}")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials",
                )
    
    # No authentication provided
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required. Provide Bearer token, X-IDM-API-Key, or X-Bot-API-Key header.",
    )


async def get_current_user_or_bot_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(optional_security_scheme),
    x_bot_api_key: Optional[str] = Header(None, alias="X-Bot-API-Key"),
    x_idm_api_key: Optional[str] = Header(None, alias="X-IDM-API-Key"),
) -> dict:
    """
    Same as get_current_user_or_bot, but if no auth is provided (or it is invalid),
    it returns an empty dict instead of raising 401. Useful for endpoints that
    can work in anonymous/preview mode (e.g. widget analytics in builder preview).
    """
    try:
        return await get_current_user_or_bot(credentials, x_bot_api_key, x_idm_api_key)
    except HTTPException as e:
        if e.status_code == status.HTTP_401_UNAUTHORIZED:
            return {}
        raise


async def get_database_client(
    current_user: dict = Depends(get_current_user),
) -> DatabaseClient:
    """
    Get database client with authenticated user
    """
    db = DatabaseClient()
    # Don't await pool creation here - let it be lazy-loaded when needed
    # This prevents blocking if pool is being created or connections are busy
    db.user_id = current_user.get('id')  
    db.current_user = current_user  
    logger.debug(f"User authenticated: {current_user.get('id')}")
    return db


async def get_database_client_no_auth() -> DatabaseClient:
    """
    Get database client without authentication. Use only for public read-only endpoints
    (e.g. public widget script URL lookup).
    """
    return DatabaseClient()


async def get_database_client_flexible(
    current_user: dict = Depends(get_current_user_or_bot),
) -> DatabaseClient:
    """
    Get database client with authenticated user (supports both JWT and bot API key)
    """
    db = DatabaseClient()
    await db.get_pool()  
    db.user_id = current_user.get('id')  
    db.current_user = current_user  
    logger.debug(f"User authenticated via {current_user.get('auth_type', 'unknown')}: {current_user.get('id')}")
    return db


def get_tool_service(
    db: DatabaseClient = Depends(get_database_client),
) -> ToolService:
    return ToolService(supabase=db)


def get_codegen_service(
    db: DatabaseClient = Depends(get_database_client),
) -> CodegenService:
    return CodegenService(supabase=db)

def get_chat_service(
    codegen_service: CodegenService = Depends(get_codegen_service),
    db: DatabaseClient = Depends(get_database_client),
) -> ChatService:
    logger.debug("Creating request-scoped chat service")
    return ChatService(codegen_service=codegen_service, supabase=db)


def get_chat_service_flexible(
    db: DatabaseClient = Depends(get_database_client_flexible),
) -> ChatService:
    """
    Get chat service with flexible authentication (supports both JWT and bot API key).
    Note: This creates a new service instance instead of using singleton.
    """
    codegen_service = CodegenService(supabase=db)
    return ChatService(codegen_service=codegen_service, supabase=db)

