CREATE TABLE IF NOT EXISTS knowledge_documents (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    filename TEXT NOT NULL,
    stored_filename TEXT,
    relative_path TEXT NOT NULL,
    mime TEXT,
    size_bytes BIGINT DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'indexed',
    extracted_chars INTEGER DEFAULT 0,
    index_error TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    last_indexed_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_knowledge_documents_user_id
ON knowledge_documents(user_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_documents_workspace_id
ON knowledge_documents(workspace_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_documents_created_at
ON knowledge_documents(created_at DESC);

CREATE TABLE IF NOT EXISTS knowledge_collections (
    id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_knowledge_collections_user_id
ON knowledge_collections(user_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_collections_workspace_id
ON knowledge_collections(workspace_id);

CREATE TABLE IF NOT EXISTS knowledge_collection_documents (
    collection_id TEXT NOT NULL REFERENCES knowledge_collections(id) ON DELETE CASCADE,
    document_id TEXT NOT NULL REFERENCES knowledge_documents(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (collection_id, document_id)
);

CREATE INDEX IF NOT EXISTS idx_knowledge_collection_documents_document_id
ON knowledge_collection_documents(document_id);

CREATE TABLE IF NOT EXISTS knowledge_collection_bots (
    collection_id TEXT NOT NULL REFERENCES knowledge_collections(id) ON DELETE CASCADE,
    bot_project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (collection_id, bot_project_id)
);

CREATE INDEX IF NOT EXISTS idx_knowledge_collection_bots_bot_project_id
ON knowledge_collection_bots(bot_project_id);
