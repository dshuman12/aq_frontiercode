-- Add is_active flag to persons (idempotent)
ALTER TABLE persons
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- Backfill (in case column existed but had NULLs from older manual edits)
UPDATE persons
SET is_active = TRUE
WHERE is_active IS NULL;

-- Helpful index for admin/user lookups (optional, safe)
CREATE INDEX IF NOT EXISTS idx_persons_is_active ON persons(is_active);

