ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS source_type TEXT NOT NULL DEFAULT 'file';

ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS source_url TEXT;

ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS sync_status TEXT;

ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS sync_error TEXT;

ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS source_language TEXT;

ALTER TABLE knowledge_documents
ADD COLUMN IF NOT EXISTS last_synced_at TIMESTAMP;

UPDATE knowledge_documents
SET source_type = COALESCE(source_type, 'file')
WHERE source_type IS NULL;
