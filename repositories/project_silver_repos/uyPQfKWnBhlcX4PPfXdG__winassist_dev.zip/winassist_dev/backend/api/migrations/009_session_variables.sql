-- 009_session_variables.sql
-- Store quick reply and other session variables for use in API body (e.g. {{context.plan_type}}).

CREATE TABLE IF NOT EXISTS session_variables (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    var_key TEXT NOT NULL,
    var_value TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(project_id, session_id, var_key)
);

CREATE INDEX IF NOT EXISTS idx_session_variables_project_session ON session_variables(project_id, session_id);
