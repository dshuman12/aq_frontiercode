#!/usr/bin/env python3
"""
Run migrations 003–008 in a single script.

Includes:
003 - flow step analytics
004 - flow_messages table
005 - drop unique index for node loop counting
006 - quick_reply_choices table
007 - session_metadata and api_performance_events tables
008 - template_ratings (one rating per user per template)
009 - session_variables (store quick reply and other vars for use in body)

Uses DATABASE_URL from .env in the same directory.
Safe to run multiple times.
"""

import asyncio
import os
import re
from pathlib import Path
from dotenv import load_dotenv

# Load .env
_api_dir = Path(__file__).resolve().parent
load_dotenv(_api_dir / ".env")

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("ERROR: DATABASE_URL not found in .env")
    print("Example: DATABASE_URL=postgresql://user:pass@host:5432/dbname")
    exit(1)


MIGRATION_SQL = """
-----------------------------
-- MIGRATION 003
-----------------------------
ALTER TABLE chats ADD COLUMN IF NOT EXISTS session_id TEXT;

CREATE INDEX IF NOT EXISTS idx_chats_session_id 
ON chats(session_id);

CREATE TABLE IF NOT EXISTS flow_step_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_id 
ON flow_step_events(project_id);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_session_id 
ON flow_step_events(session_id);

CREATE INDEX IF NOT EXISTS idx_flow_step_events_project_created 
ON flow_step_events(project_id, created_at);

CREATE UNIQUE INDEX IF NOT EXISTS idx_flow_step_events_project_session_node
ON flow_step_events(project_id, session_id, node_id);


-----------------------------
-- MIGRATION 004
-----------------------------
CREATE TABLE IF NOT EXISTS flow_messages (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL DEFAULT '',
    node_id TEXT,
    node_label TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_id 
ON flow_messages(project_id);

CREATE INDEX IF NOT EXISTS idx_flow_messages_session_id 
ON flow_messages(session_id);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_created 
ON flow_messages(project_id, created_at);

CREATE INDEX IF NOT EXISTS idx_flow_messages_project_role 
ON flow_messages(project_id, role);


-----------------------------
-- MIGRATION 005
-----------------------------
DROP INDEX IF EXISTS idx_flow_step_events_project_session_node;


-----------------------------
-- MIGRATION 006
-----------------------------
CREATE TABLE IF NOT EXISTS quick_reply_choices (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    node_label TEXT,
    option_index INT NOT NULL,
    option_text TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_id 
ON quick_reply_choices(project_id);

CREATE INDEX IF NOT EXISTS idx_quick_reply_choices_project_node 
ON quick_reply_choices(project_id, node_id);


-----------------------------
-- MIGRATION 007
-----------------------------
CREATE TABLE IF NOT EXISTS session_metadata (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    device_type TEXT,
    browser TEXT,
    os TEXT,
    page_url TEXT,
    referrer TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_session_metadata_project_id 
ON session_metadata(project_id);

CREATE INDEX IF NOT EXISTS idx_session_metadata_session_id 
ON session_metadata(session_id);

CREATE INDEX IF NOT EXISTS idx_session_metadata_project_created 
ON session_metadata(project_id, created_at);


CREATE TABLE IF NOT EXISTS api_performance_events (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    node_id TEXT,
    api_name TEXT NOT NULL,
    response_status INT,
    response_time_ms INT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_performance_project_id 
ON api_performance_events(project_id);

CREATE INDEX IF NOT EXISTS idx_api_performance_project_created 
ON api_performance_events(project_id, created_at);

CREATE INDEX IF NOT EXISTS idx_api_performance_api_name 
ON api_performance_events(project_id, api_name);


-----------------------------
-- MIGRATION 008: template_ratings (one rating per user per template)
-----------------------------
CREATE TABLE IF NOT EXISTS template_ratings (
    template_id INTEGER NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES persons(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (template_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_template_ratings_template_id ON template_ratings(template_id);
CREATE INDEX IF NOT EXISTS idx_template_ratings_user_id ON template_ratings(user_id);


-----------------------------
-- MIGRATION 009: session_variables (quick reply and other vars for use in API body)
-----------------------------
CREATE TABLE IF NOT EXISTS session_variables (
    id SERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    var_key TEXT NOT NULL,
    var_value TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(project_id, session_id, var_key)
);
CREATE INDEX IF NOT EXISTS idx_session_variables_project_session ON session_variables(project_id, session_id);
"""


def split_sql(sql: str):
    """Split SQL into individual statements."""
    sql = re.sub(r"--[^\n]*", "", sql)
    parts = [p.strip() for p in sql.split(";") if p.strip()]
    return parts


async def run():
    try:
        import asyncpg
    except ImportError:
        print("Install asyncpg: pip install asyncpg")
        exit(1)

    print("Connecting to database...")
    conn = await asyncpg.connect(DATABASE_URL)

    try:
        for stmt in split_sql(MIGRATION_SQL):
            preview = stmt.replace("\n", " ")[:80]
            print(f"Running: {preview}...")
            await conn.execute(stmt)

        print("\nAll migrations (003–009) completed successfully.")

    except Exception as e:
        print(f"Migration failed: {e}")
        raise

    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(run())