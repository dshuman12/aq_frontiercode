# WinAssist Project Documentation

## 1) Project Overview

WinAssist is a full-stack platform for building, managing, and publishing AI assistants/chatflows.
It includes:

- A React frontend for dashboard, flow/canvas building, project management, widget preview, templates, analytics, and governance.
- A FastAPI backend for authentication, project/workspace management, chat execution, code generation, analytics, governance, templates, and integrations.
- A PostgreSQL-compatible data layer (configured through `DATABASE_URL`) with startup schema initialization and tool seeding.

---

## 2) Tech Stack

## Frontend Stack

Core:
- React 19
- Vite 7
- React Router
- SWR for data fetching/caching
- Tailwind CSS + PostCSS + Autoprefixer

UI and UX:
- Radix UI components
- Lucide icons
- Recharts for analytics charts
- React Markdown + KaTeX + Remark/Rehype plugins for rich text/math rendering
- React Resizable Panels

Canvas / No-code builder:
- `@xyflow/react` (flow/canvas editor)
- CodeMirror (`@uiw/react-codemirror`, `@codemirror/lang-python`) for code editing

Auth on frontend:
- `react-oidc-context` + `oidc-client-ts`
- Supports OIDC/Keycloak-driven auth flow

Build and code quality:
- ESLint 9 + React hooks plugin

## Backend Stack

Core:
- Python (requires `>=3.10,<3.11`)
- FastAPI + Starlette + Uvicorn
- Pydantic

Data / auth / security:
- `asyncpg` for PostgreSQL connection pooling
- JWT (`pyjwt`) and password hashing (`bcrypt`, `passlib[bcrypt]`)
- `python-dotenv` for environment configuration

AI + tooling integrations:
- OpenAI SDK
- Google Generative AI SDK
- Cohere
- Tavily
- AutoGen (`autogen[core]`)
- AgentOps

Files / utilities:
- `python-multipart` for uploads
- `python-magic`, Pillow for file/media-related processing

---

## 3) Frontend: What Is Being Used

Main frontend modules currently in use:

- Authentication pages and route protection:
  - Login, register, forgot/reset password
  - OIDC/Keycloak session integration
- Dashboard and project areas:
  - Dashboard
  - Projects list/detail
  - Project dashboard
- No-code builders:
  - AI Agent canvas (`/aiagent`)
  - Chatflow canvas (`/chatflow`)
- Tooling and templates:
  - Tools list/detail
  - Templates list, preview, canvas preview
- Widget flow:
  - Widget preview and public widget viewer
  - Publish center
- Governance and operations:
  - Settings, billing, integrations, help/support
  - Workspace invite and accept invite flow
- Analytics UI:
  - Project dashboard charts/metrics (backed by analytics APIs)

Frontend configuration currently depends on env/runtime values such as:

- `VITE_API_URL`
- `VITE_WIDGET_STATIC_BASE_PATH`
- `VITE_OIDC_*` (plus legacy `VITE_IAM_*` support)
- `VITE_APP_URL`
- `VITE_WHATSAPP_*` flags

---

## 4) Backend: What Is Being Used

API surface (major route groups):

- `auth` - registration, login, password reset, profile/auth workflows
- `projects` - project CRUD and project-level operations
- `chats` - chat sessions, messages, logs, abort, delete
- `tools` - tool management and tool attachments
- `knowledge` - knowledge document uploads
- `codegen` - tool code generation and metadata extraction
- `dashboard` - dashboard metrics endpoints
- `settings` - user tool settings
- `workspaces` - workspace and invite management
- `project-analytics` - funnel, timeline, session analytics, heatmaps, conversion, replay, device/source metrics, alerts, event ingestion
- `project governance` (under projects prefix) - governance policy, release snapshots, audit logs
- `templates` - template operations
- `api-docs` - rendered API docs entrypoint

Backend runtime behavior includes:

- `/v1` mounted app with generated OpenAPI/Swagger docs
- CORS middleware for local/dev/proxy hosts
- global exception handling
- startup schema initialization + initial tool seeding
- static widget file mounting and serving (`/static/widgets`)

---

## 5) Features Implemented (Current)

Based on current codebase, key completed feature areas:

1. User auth system with JWT and optional OIDC/Keycloak flow.
2. Protected/public frontend route handling.
3. Project and workspace management, including workspace invite flow.
4. No-code AI agent and chatflow builders (canvas-based).
5. Chat orchestration APIs (session/message lifecycle + abort/logs).
6. Tooling system with code generation support and file attachment upload endpoint.
7. Knowledge upload endpoint for retrieval/knowledge workflows.
8. Widget generation/preview/viewer and static widget serving support.
9. Governance features (policy, release snapshots, audit history).
10. Rich analytics module (funnel, behavior, performance, replay-style endpoints).
11. Template workflows (list/preview/canvas preview patterns).
12. Settings and operational UI pages (integrations, billing shell, help/support).

---

## 6) API / API Keys in Use

## Keys and Secrets Referenced by Backend

- `OPENAI_API_KEY`
- `GOOGLE_API_KEY` or `GEMINI_API_KEY`
- `COHERE_API_KEY`
- `TAVILY_API_KEY`
- `AGENTOPS_API_KEY`
- `SUPABASE_SERVICE_KEY` (with `SUPABASE_URL`)
- `IDM_API_KEY` (or `IDM_VERIFY_URL` flow for remote key verification)
- `JWT_SECRET`
- SMTP credentials (`SMTP_HOST`, `SMTP_USER`, `SMTP_PASSWORD`, etc.)
- Keycloak/OIDC values (`KEYCLOAK_URL`, `KEYCLOAK_REALM`, `KEYCLOAK_CLIENT_ID`, and OIDC issuer/audience values)

## Public/Runtime API Config Used by Frontend

- `VITE_API_URL` (primary backend base URL for frontend)
- OIDC frontend values (`VITE_OIDC_*` and legacy `VITE_IAM_*`)

## Important Security Note

- Keep real secrets only in local/runtime `.env` or secret manager.
- Do not store actual key values in documentation.
- Rotate keys immediately if they were ever committed or shared.

---

## 7) Completed vs Improvement Opportunities

## Already Completed Well

- Broad feature coverage across auth, project management, chatflow, tooling, analytics, governance, and publishing.
- Clear frontend/backend separation with consistent route grouping.
- Support for both JWT and API-key style authentication patterns.
- Startup automation for schema initialization and base tool seeding.
- API docs availability and structured endpoint organization.

## What Can Be Improved

1. **Secrets management hardening**
   - Move all sensitive values to secure secret stores in non-local environments.
   - Add automated secret scanning in CI.

2. **Testing depth**
   - Increase backend integration tests for core flows (auth, project lifecycle, chat execution, governance).
   - Add frontend e2e coverage for key user journeys.

3. **Observability**
   - Add structured logging, request tracing, and centralized metrics dashboards.
   - Define SLOs for chat latency/error rates.

4. **CORS and environment hygiene**
   - Reduce permissive/static host lists in production.
   - Maintain explicit environment-specific config bundles.

5. **Placeholder/partial implementations**
   - Replace placeholder paths with full production-ready implementations where noted.
   - Standardize unimplemented-path behavior and developer warnings.

6. **Documentation quality**
   - Add endpoint-level docs per module and architecture diagrams.
   - Maintain a changelog/release notes standard.

---

## 8) Missing Things To Add Next

High-value missing additions:

1. CI/CD pipeline documentation + deployment runbooks (dev/staging/prod).
2. Full test strategy document (unit/integration/e2e ownership and coverage goals).
3. Incident response and rollback procedure documentation.
4. Data retention, backup, and recovery documentation.
5. Security baseline document (auth model, key rotation cadence, permission model, audit process).
6. Performance benchmark and load testing plan.
7. Contribution guide (branching, PR rules, coding standards, release process).
8. API versioning and deprecation policy.

---

## 9) Future Roadmap (Suggested)

## Phase 1: Stability and Security
- Complete secret management hardening.
- Close placeholder implementations.
- Add automated tests for critical paths.
- Tighten production CORS and environment controls.

## Phase 2: Product Maturity
- Improve template ecosystem and reusable flow blocks.
- Expand analytics dashboards and business KPI mapping.
- Improve governance workflows with stronger approval policies.

## Phase 3: Scale and Reliability
- Add deeper observability (distributed tracing, SLO alerting).
- Optimize high-volume chat and analytics query performance.
- Add formal multi-environment deployment automation.

---

## 10) Extra Documentation That Should Exist

Recommended additional docs (separate files) for long-term maintainability:

- `ARCHITECTURE.md` (system design and request flows)
- `API_REFERENCE.md` (endpoint contract details)
- `DEPLOYMENT.md` (infra, env vars, release steps)
- `SECURITY.md` (auth model, key handling, hardening checklist)
- `TESTING.md` (test setup and quality gates)
- `TROUBLESHOOTING.md` (common issues and fixes)

---

## 11) Quick Runtime Pointers

- Frontend default local dev runs on Vite (typically `5173`).
- Backend serves APIs under `/v1` and docs under `/api-docs` and `/v1/docs`.
- Health checks exist at `/health` and `/v1/health`.

