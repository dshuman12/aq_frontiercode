# Environment Variables Setup

## How to Use Environment Variables for API Base URL

Your frontend is already configured to use environment variables for the API base URL. Here's how to set it up:

### 1. Create `.env` file

Create a `.env` file in the `WinAssist/frontend/` directory with the following content:

```env
# API Base URL Configuration
# For development:
VITE_API_URL=http://localhost:9000/v1

# For production, update to your production URL:
# VITE_API_URL=https://your-production-api.com/v1
```

### 2. How to Use in Your JavaScript Files

#### Option A: Using the API Client (Recommended)

If you're making API calls, use the `apiRequest` function from `api-client.js`:

```javascript
import { apiRequest } from '../lib/api-client';

// Make API call - base URL is automatically included
const data = await apiRequest('/api/endpoint', {
  method: 'POST',
  body: { key: 'value' }
});
```

#### Option B: Get Base URL Directly

If you need the base URL for custom fetch calls:

```javascript
import { getBackendUrl } from '../lib/api-client';
// OR
import { getBackendUrl } from '../lib/config';

const baseUrl = getBackendUrl();
const fullUrl = `${baseUrl}/api/endpoint`;

const response = await fetch(fullUrl, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ key: 'value' })
});
```

#### Option C: Using Config Directly

```javascript
import { getApiUrl } from '../lib/config';

const apiUrl = getApiUrl();
const response = await fetch(`${apiUrl}/your-endpoint`);
```

### 3. Environment Variable Priority

The system checks in this order:
1. `VITE_API_URL` from `.env` file (highest priority)
2. `window.__BACKEND_URL__` (for runtime configuration)
3. Default fallback: `http://localhost:9000/v1` (development) or `/api/v1` (production)

### 4. Important Notes

- **Vite requires the `VITE_` prefix** for environment variables to be exposed to the client
- After creating/updating `.env`, restart your dev server
- Never commit `.env` file to git (it should be in `.gitignore`)
- Use `.env.example` as a template for other developers

### 5. Example: Updating a File with Hardcoded URL

**Before:**
```javascript
const response = await fetch('http://localhost:9000/v1/api/endpoint');
```

**After:**
```javascript
import { getBackendUrl } from '../lib/api-client';

const baseUrl = getBackendUrl();
const response = await fetch(`${baseUrl}/api/endpoint`);
```

Or better yet:
```javascript
import { apiRequest } from '../lib/api-client';

const response = await apiRequest('/api/endpoint');
```




