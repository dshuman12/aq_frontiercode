# ---------- Stage 1: Build ----------
FROM node:22-alpine AS build

WORKDIR /app

# Install dependencies (faster with cache)
COPY package.json package-lock.json ./
RUN npm ci

# Copy full project, including frontend/.env used by Vite at build time
COPY . .

# Build Vite app -> dist/
RUN npm run build

# ---------- Stage 2: Nginx ----------
FROM nginx:alpine

# Remove default config
RUN rm /etc/nginx/conf.d/default.conf

# Copy your custom nginx config
COPY nginx.conf /etc/nginx/conf.d/default.conf

# Copy built frontend to your expected path
COPY --from=build /app/dist /var/www/myapp/frontend

# Create widgets directory (used by backend)
RUN mkdir -p /var/www/myapp/frontend/static/widgets

# Expose port
EXPOSE 80

# Start nginx
CMD ["nginx", "-g", "daemon off;"]
