import { useLocation, useParams } from 'react-router-dom';
import { ReactFlowProvider } from '@xyflow/react';
import { useProjects } from '../../hooks/project';
import { useEffect } from 'react';
import { Editor } from './resize';

// Backend nodes: initializer, conversable, groupchat, user
const BACKEND_NODES = ['initializer', 'conversable', 'groupchat', 'user'];

export default function NoCodeBackendCanvas() {
  const { id } = useParams();
  const projectId = id; // UUID is a string, no need to parse
  const location = useLocation();
  const { projects, isLoading, activeProjectId, setActiveProjectId } = useProjects();
  
  useEffect(() => {
    if (projectId !== activeProjectId) {
      setActiveProjectId(projectId);
    }
  }, [projectId, activeProjectId, setActiveProjectId]);

  if (!isLoading && !projects.find((project) => project.id === projectId)) {
    return <p>not found</p>;
  }
  
  return (
    <div className="h-screen overflow-hidden">
      <ReactFlowProvider key="nocode-backend-reactflow">
        <Editor 
          projectId={projectId} 
          nodeFilter={BACKEND_NODES}
          showChat={true}
          showConfigConditionally={false}
          showCodeTab={true}
          codeViewType="python"
          allowTemplatePublish={!location.state?.fromTemplate}
        />
      </ReactFlowProvider>
    </div>
  );
}

