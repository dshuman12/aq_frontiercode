import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/button';
import { Icons } from '../../components/ui/icons';
import { WINASSIST_LOGO_URL } from '../../lib/config';

export default function HomePage({
  onLogin,
  onGetStarted,
  disableAuthButtons = false,
} = {}) {
  const navigate = useNavigate();

  const handleLogin = () => (onLogin ? onLogin() : navigate('/auth/login'));
  const handleGetStarted = () => (onGetStarted ? onGetStarted() : navigate('/auth/register'));

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Login/Signup */}
      <header className="w-full px-4 sm:px-6 py-3 sm:py-4 flex justify-between items-center border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-2 min-w-0">
          <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-9 h-9 sm:w-10 sm:h-10 object-contain rounded-lg shrink-0" />
          <span className="text-lg sm:text-xl font-bold text-foreground truncate">WinAssist</span>
        </div>
        <div className="flex gap-2 sm:gap-3 shrink-0">
          <Button
            variant="ghost"
            onClick={handleLogin}
            disabled={disableAuthButtons}
            className="px-4 sm:px-6"
          >
            Login
          </Button>
          <Button
            onClick={handleGetStarted}
            disabled={disableAuthButtons}
            className="px-4 sm:px-6"
          >
            Get Started
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 sm:px-6">
        <div className="py-12 sm:py-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Icons.sparkles className="w-4 h-4" />
            Enterprise AI Platform
          </div>
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold text-foreground mb-4 sm:mb-6 leading-tight">
            Build AI-Powered Apps
            <br />
            <span className="text-primary">Without Code</span>
          </h1>
          <p className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 sm:mb-10 px-2">
            Create intelligent chatbots, automate workflows, and deploy AI solutions 
            in minutes. No programming required.
          </p>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
            <Button
              size="lg"
              onClick={handleGetStarted}
              disabled={disableAuthButtons}
              className="px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg"
            >
              Start Building Free
              <Icons.arrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate('/auth/login')}
              className="px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg"
            >
              View Demo
            </Button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="py-8 sm:py-12 border-t border-b border-border">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-muted-foreground">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">10k+</div>
              <div className="text-muted-foreground">Bots Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">99.9%</div>
              <div className="text-muted-foreground">Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">Support</div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="py-12 sm:py-24">
          <div className="text-center mb-10 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4">
              Everything You Need
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Powerful features designed for enterprise teams
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto px-2">
            {/* Feature 1 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                <Icons.code className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Backend Builder</h3>
              <p className="text-muted-foreground leading-relaxed">
                Create AI agents, connect APIs, and build complex workflows with our visual backend builder.
              </p>
            </div>
            
            {/* Feature 2 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-accent/10 flex items-center justify-center mb-6">
                <Icons.project className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Frontend Builder</h3>
              <p className="text-muted-foreground leading-relaxed">
                Design beautiful chat interfaces and user experiences with drag-and-drop simplicity.
              </p>
            </div>
            
            {/* Feature 3 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-green-500/10 flex items-center justify-center mb-6">
                <Icons.tool className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Custom Tools</h3>
              <p className="text-muted-foreground leading-relaxed">
                Extend your bots with custom tools, RAG integration, and external API connections.
              </p>
            </div>
            
            {/* Feature 4 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-orange-500/10 flex items-center justify-center mb-6">
                <Icons.zap className="w-7 h-7 text-orange-500" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Instant Deploy</h3>
              <p className="text-muted-foreground leading-relaxed">
                Deploy your AI bots instantly with one click. Get embeddable scripts for any website.
              </p>
            </div>
            
            {/* Feature 5 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-purple-500/10 flex items-center justify-center mb-6">
                <Icons.circleGauge className="w-7 h-7 text-purple-500" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Analytics Dashboard</h3>
              <p className="text-muted-foreground leading-relaxed">
                Track usage, monitor performance, and gain insights with comprehensive analytics.
              </p>
            </div>
            
            {/* Feature 6 */}
            <div className="p-6 sm:p-8 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors">
              <div className="w-14 h-14 rounded-lg bg-cyan-500/10 flex items-center justify-center mb-6">
                <Icons.key className="w-7 h-7 text-cyan-500" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Secure API Keys</h3>
              <p className="text-muted-foreground leading-relaxed">
                Enterprise-grade security with API key authentication and access controls.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-12 sm:py-24">
          <div className="max-w-4xl mx-auto text-center p-6 sm:p-12 rounded-2xl bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 border border-primary/20">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
              Join thousands of teams building AI-powered applications with WinAssist.
            </p>
            <Button
              size="lg"
              onClick={handleGetStarted}
              disabled={disableAuthButtons}
              className="px-10 py-6 text-lg"
            >
              Create Free Account
              <Icons.arrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-6 sm:py-8">
        <div className="container mx-auto px-4 sm:px-6 text-center text-muted-foreground text-sm sm:text-base">
          <p>© 2026 WinAssist. Built with ❤️ for enterprises.</p>
        </div>
      </footer>
    </div>
  );
}
