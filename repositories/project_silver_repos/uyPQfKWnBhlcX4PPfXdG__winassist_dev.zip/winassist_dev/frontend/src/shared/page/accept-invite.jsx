import { useEffect, useState, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '../../components/ui/button';
import { toast } from '../../hooks/toast';
import useUserStore from '../../store/user';
import useWorkspaceStore from '../../store/workspace';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../../components/ui/icons';

/**
 * Public page: /accept-invite?token=...
 * If not logged in, redirects to login with return URL. After login, user lands back here and we accept.
 * Waits for auth rehydration so the first click works when the user is already logged in.
 */
const AUTH_REHYDRATE_MS = 300;

export default function AcceptInvitePage() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();
  const user = useUserStore((s) => s.user);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const acceptStartedRef = useRef(false);

  useEffect(() => {
    const t = setTimeout(() => setAuthReady(true), AUTH_REHYDRATE_MS);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!token || !authReady || done) return;

    const run = async () => {
      if (!user?.token) {
        const returnUrl = `/accept-invite?token=${encodeURIComponent(token)}`;
        navigate(`/auth/login?redirect=${encodeURIComponent(returnUrl)}`, { replace: true });
        return;
      }

      if (acceptStartedRef.current) return;
      acceptStartedRef.current = true;
      setLoading(true);
      try {
        const joined = await apiRequest('/workspaces/invites/accept', {
          method: 'POST',
          body: { token },
          showErrorToast: true,
        });
        await useWorkspaceStore.getState().fetchWorkspaces();
        if (joined?.id) {
          useWorkspaceStore.getState().setCurrentWorkspaceId(joined.id);
        }
        toast({ title: 'Invite accepted', description: `You've joined "${joined?.name || 'the workspace'}".` });
        setDone(true);
        navigate('/dashboard', { replace: true });
      } catch (err) {
        acceptStartedRef.current = false;
        toast({
          title: 'Could not accept invite',
          description: err.message || 'Link may be invalid or expired.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [token, authReady, user?.token, navigate, done]);

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="text-center">
          <p className="text-muted-foreground">Missing invite token. Use the link from your invite email.</p>
          <Button className="mt-4" onClick={() => navigate('/')}>Go home</Button>
        </div>
      </div>
    );
  }

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="flex flex-col items-center gap-3">
          <Icons.spinner className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="flex flex-col items-center gap-3">
          <Icons.spinner className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Accepting invite...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="flex flex-col items-center gap-3">
        <Icons.spinner className="w-6 h-6 animate-spin text-muted-foreground" />
        <p className="text-sm text-muted-foreground">Redirecting...</p>
      </div>
    </div>
  );
}
