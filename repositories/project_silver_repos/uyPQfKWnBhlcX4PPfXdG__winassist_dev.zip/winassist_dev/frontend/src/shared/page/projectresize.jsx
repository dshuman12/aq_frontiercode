import { useParams } from 'react-router-dom';
import { ReactFlowProvider } from '@xyflow/react';
import Floweditor from '../reactflow';
import { useProjects } from '../../hooks/project';
import { useEffect } from 'react';
import { Editor } from './resize';

export default function ProjectResize() {
  const { id } = useParams();
  const projectId = id; // UUID is a string, no need to parse
  const { projects, isLoading, activeProjectId, setActiveProjectId } = useProjects();
  undefined
  useEffect(() => {
    if (projectId !== activeProjectId) {
      setActiveProjectId(projectId);
    }
  }, [projectId, activeProjectId, setActiveProjectId]);

  if (!isLoading && !projects.find((project) => project.id === projectId)) {
    return <p>not found</p>;
  }
  
  return (
    <ReactFlowProvider key="winassist-reactflow">
      <Editor projectId={projectId}  />
    </ReactFlowProvider>
  );
}

