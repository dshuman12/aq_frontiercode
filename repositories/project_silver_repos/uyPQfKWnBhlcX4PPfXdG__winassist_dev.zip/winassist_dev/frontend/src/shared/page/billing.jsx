import { useNavigate } from 'react-router-dom';
import { PlatformModulePage } from '../../components/shared/platform-module-page';
import { Icons } from '../../components/ui/icons';

export default function BillingPage() {
  const navigate = useNavigate();

  return (
    <PlatformModulePage
      icon={Icons.billing}
      title="Billing"
      description="Billing now has its own dedicated screen so account settings can stay focused on profile and password management."
      badge="Coming soon"
      stats={[
        { label: 'Plan', value: 'Starter', help: 'Replace this placeholder with the user workspace plan when billing data is connected.' },
        { label: 'Invoices', value: '0', help: 'Invoice history and downloadable receipts can live here.' },
        { label: 'Usage Alerts', value: '0', help: 'Message usage, API consumption, and quota warnings should appear in this module.' },
        { label: 'Payment Methods', value: '0', help: 'Saved cards and billing contacts can be managed separately from account settings.' },
      ]}
      sections={[
        {
          title: 'Billing management',
          description: 'Keep all payment and plan controls in one place.',
          items: [
            {
              title: 'Plan and subscription',
              description: 'Show the current plan, renewal status, billing cycle, and upgrade options for the active workspace.',
            },
            {
              title: 'Invoices and receipts',
              description: 'List past invoices with status, billing dates, and download links for finance teams.',
            },
            {
              title: 'Usage and quota',
              description: 'Display message volume, API usage, storage, and alert thresholds without mixing them into account settings.',
            },
          ],
        },
        {
          title: 'Account shortcuts',
          description: 'Account profile actions stay in Settings while billing remains here.',
          items: [
            {
              title: 'Open account settings',
              description: 'Manage your profile details or change your password from the dedicated settings page.',
              actionLabel: 'Open Settings',
              onAction: () => navigate('/settings'),
            },
          ],
        },
      ]}
    />
  );
}
