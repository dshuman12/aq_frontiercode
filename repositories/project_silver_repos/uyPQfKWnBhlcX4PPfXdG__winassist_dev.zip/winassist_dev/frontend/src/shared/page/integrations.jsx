import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { ConnectorCard } from '../../components/integrations/connector-card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Icons } from '../../components/ui/icons';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';
import { apiRequest } from '../../lib/api-client';
import { useToast } from '../../hooks/toast';
import { useWorkspaces } from '../../hooks/workspace';

const STATUS_BADGE_MAP = {
  active: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  healthy: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  draft: { variant: 'secondary', className: '' },
  pending: { variant: 'secondary', className: '' },
  error: { variant: 'destructive', className: '' },
  unknown: { variant: 'outline', className: '' },
};

function getStatusBadge(status) {
  return STATUS_BADGE_MAP[String(status || '').toLowerCase()] || { variant: 'outline', className: '' };
}

function normalizeConnector(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    connector_key: item.connector_key || '',
    channel_key: item.channel_key || '',
    provider_key: item.provider_key || '',
    display_name: item.display_name || 'Connector',
    description: item.description || '',
    setup_route: item.setup_route || '',
    status_route: item.status_route || '',
    icon_url: item.icon_url || '',
    capabilities: item.capabilities && typeof item.capabilities === 'object' ? item.capabilities : {},
  };
}

function normalizeConnection(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    id: item.id,
    connector_key: item.connector_key || '',
    channel_key: item.channel_key || '',
    provider_key: item.provider_key || '',
    display_name: item.display_name || 'Connection',
    external_reference: item.external_reference || '',
    connection_status: item.connection_status || 'unknown',
    health_status: item.health_status || 'unknown',
    setup_route: item.setup_route || '',
    access_token_masked: item.access_token_masked || '',
    capabilities: item.capabilities && typeof item.capabilities === 'object' ? item.capabilities : {},
    updated_at: item.updated_at || '',
  };
}

function formatTime(value) {
  if (!value) return 'Unknown';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function capabilityLabels(capabilities) {
  return Object.entries(capabilities || {})
    .filter(([, enabled]) => Boolean(enabled))
    .map(([key]) =>
      String(key)
        .split('_')
        .filter(Boolean)
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ')
    )
    .slice(0, 5);
}

export default function IntegrationsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentWorkspaceId, currentWorkspace, fetchWorkspaces } = useWorkspaces();
  const [connectors, setConnectors] = useState([]);
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedConnectionId, setSelectedConnectionId] = useState('');
  const [sendingText, setSendingText] = useState(false);
  const [sendForm, setSendForm] = useState({
    to: '',
    text: 'Hello from WinAssist connector transport.',
    preview_url: false,
  });

  useEffect(() => {
    fetchWorkspaces({ force: false });
  }, [fetchWorkspaces]);

  const refreshMarketplace = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (currentWorkspaceId) params.set('workspace_id', currentWorkspaceId);
      const [connectorData, connectionData] = await Promise.all([
        apiRequest('/connectors', { method: 'GET', showErrorToast: false }),
        apiRequest(`/connectors/connections${params.toString() ? `?${params.toString()}` : ''}`, {
          method: 'GET',
          showErrorToast: false,
        }),
      ]);
      setConnectors(Array.isArray(connectorData) ? connectorData.map(normalizeConnector).filter(Boolean) : []);
      setConnections(Array.isArray(connectionData) ? connectionData.map(normalizeConnection).filter(Boolean) : []);
    } catch {
      setConnectors([]);
      setConnections([]);
    } finally {
      setLoading(false);
    }
  }, [currentWorkspaceId]);

  useEffect(() => {
    refreshMarketplace();
  }, [refreshMarketplace]);

  const connectionCounts = useMemo(() => {
    const counts = {};
    for (const item of connections) {
      counts[item.connector_key] = (counts[item.connector_key] || 0) + 1;
    }
    return counts;
  }, [connections]);

  const healthyConnections = useMemo(
    () => connections.filter((item) => ['healthy', 'active'].includes(String(item.health_status || item.connection_status).toLowerCase())).length,
    [connections],
  );

  const selectedConnection = useMemo(
    () => connections.find((item) => item.id === selectedConnectionId) || null,
    [connections, selectedConnectionId],
  );

  useEffect(() => {
    if (!connections.length) {
      setSelectedConnectionId('');
      return;
    }
    if (!connections.some((item) => item.id === selectedConnectionId)) {
      setSelectedConnectionId(connections[0].id);
    }
  }, [connections, selectedConnectionId]);

  const updateSendForm = (key, value) => {
    setSendForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSendConnectorText = async () => {
    if (!selectedConnectionId) {
      toast({
        title: 'Connection required',
        description: 'Select a connector connection before sending a test message.',
        variant: 'destructive',
      });
      return;
    }
    if (!sendForm.to.trim() || !sendForm.text.trim()) {
      toast({
        title: 'Message details required',
        description: 'Add a recipient and message text before sending.',
        variant: 'destructive',
      });
      return;
    }
    setSendingText(true);
    try {
      await apiRequest(`/connectors/connections/${selectedConnectionId}/send-text`, {
        method: 'POST',
        body: {
          to: sendForm.to.trim(),
          text: sendForm.text.trim(),
          preview_url: Boolean(sendForm.preview_url),
        },
      });
      toast({
        title: 'Connector message sent',
        description: 'The generic connector transport submitted the text message successfully.',
      });
    } catch (error) {
      toast({
        title: 'Connector send failed',
        description: error.message || 'Please review the selected connection and try again.',
        variant: 'destructive',
      });
    } finally {
      setSendingText(false);
    }
  };

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-8">
        <PageHeader
          icon={Icons.package}
          title="Marketplace"
          description="Reusable connector directory for workspace-level messaging and future channel integrations."
          actions={(
            <Button variant="outline" size="sm" onClick={refreshMarketplace} disabled={loading}>
              {loading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
              Refresh
            </Button>
          )}
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Available connectors</CardDescription>
              <CardTitle className="text-2xl">{connectors.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Registry-driven connector definitions that can power future messaging and integration channels.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Reusable connections</CardDescription>
              <CardTitle className="text-2xl">{connections.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Saved connector connections available in {currentWorkspace?.name || 'your accessible workspaces'}.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Healthy connections</CardDescription>
              <CardTitle className="text-2xl text-primary">{healthyConnections}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Connections that currently report healthy or active delivery status.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Connector UX</CardDescription>
              <CardTitle className="text-2xl text-primary">Shared</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Connector definitions, capabilities, and setup routes are now modeled in a reusable marketplace layer.
              </p>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="mb-4 text-lg font-semibold tracking-tight text-foreground">Connector directory</h2>
          {loading && connectors.length === 0 ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Icons.spinner className="h-4 w-4 animate-spin" />
              Loading connector definitions...
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {connectors.map((connector) => (
                <ConnectorCard
                  key={connector.connector_key}
                  connector={connector}
                  connectedCount={connectionCounts[connector.connector_key] || 0}
                  onOpenSetup={() => navigate(connector.setup_route || '/integrations')}
                />
              ))}
            </div>
          )}
        </div>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Connector connections</CardTitle>
              <CardDescription>
                Provider-agnostic connection summaries for the current workspace, starting with WhatsApp as the first connector.
              </CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/tools')}>
              Open Tools
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading && connections.length === 0 ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="h-4 w-4 animate-spin" />
                Loading connector connections...
              </div>
            ) : connections.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No connector connections were found yet. Start by opening the WhatsApp connector.
              </div>
            ) : (
              connections.map((connection) => {
                const connectionBadge = getStatusBadge(connection.connection_status);
                const healthBadge = getStatusBadge(connection.health_status);
                return (
                  <div key={connection.id} className="rounded-lg border border-border/70 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium text-foreground">{connection.display_name}</div>
                        <div className="mt-1 text-xs text-muted-foreground">
                          {connection.channel_key} / {connection.provider_key}
                          {connection.external_reference ? ` · ${connection.external_reference}` : ''}
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">
                          Updated {formatTime(connection.updated_at)}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant={connectionBadge.variant} className={connectionBadge.className}>
                          {connection.connection_status}
                        </Badge>
                        <Badge variant={healthBadge.variant} className={healthBadge.className}>
                          {connection.health_status}
                        </Badge>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {capabilityLabels(connection.capabilities).map((label) => (
                        <Badge key={`${connection.id}:${label}`} variant="secondary">
                          {label}
                        </Badge>
                      ))}
                    </div>
                    <div className="mt-3 text-xs text-muted-foreground">
                      Secret hint: {connection.access_token_masked || 'Stored securely'}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button size="sm" onClick={() => navigate(connection.setup_route || '/integrations/whatsapp')}>
                        Open setup
                      </Button>
                      {connection.channel_key === 'whatsapp' ? (
                        <Button size="sm" variant="outline" onClick={() => navigate('/integrations/whatsapp')}>
                          Open operations
                        </Button>
                      ) : null}
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Generic connector send test</CardTitle>
            <CardDescription>
              Use the shared connector transport abstraction to send a text message through the selected connection.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="connector-connection">Connector connection</Label>
                <Select value={selectedConnectionId} onValueChange={setSelectedConnectionId}>
                  <SelectTrigger id="connector-connection">
                    <SelectValue placeholder="Choose a connector connection" />
                  </SelectTrigger>
                  <SelectContent>
                    {connections.map((connection) => (
                      <SelectItem key={connection.id} value={connection.id}>
                        {connection.display_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="connector-send-to">Recipient</Label>
                <Input
                  id="connector-send-to"
                  value={sendForm.to}
                  onChange={(event) => updateSendForm('to', event.target.value)}
                  placeholder="+919999999999"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="connector-send-text">Message text</Label>
                <Textarea
                  id="connector-send-text"
                  value={sendForm.text}
                  onChange={(event) => updateSendForm('text', event.target.value)}
                  className="min-h-[120px]"
                  placeholder="Hello from WinAssist connector transport."
                />
              </div>
              <Button onClick={handleSendConnectorText} disabled={sendingText || !selectedConnectionId}>
                {sendingText ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.send className="h-4 w-4" />}
                Send connector text
              </Button>
            </div>
            <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
              {selectedConnection ? (
                <>
                  <div className="font-medium text-foreground">{selectedConnection.display_name}</div>
                  <div className="mt-2">Channel: {selectedConnection.channel_key}</div>
                  <div>Provider: {selectedConnection.provider_key}</div>
                  <div>Status: {selectedConnection.connection_status}</div>
                  <div>Health: {selectedConnection.health_status}</div>
                  <div className="mt-3">
                    Capabilities: {capabilityLabels(selectedConnection.capabilities).join(', ') || 'No capabilities reported'}
                  </div>
                </>
              ) : (
                'Select a connector connection to test the shared send abstraction.'
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="border-dashed border-primary/25 bg-muted/20">
          <CardHeader>
            <CardTitle className="text-base">Phase 9 direction</CardTitle>
            <CardDescription>
              WhatsApp remains the first full connector, but the Marketplace now exposes reusable connector definitions,
              shared capability flags, and normalized connection summaries for future Telegram, SMS, Instagram, and
              email connectors.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    </AppLayout>
  );
}
