import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Icons } from '../../components/ui/icons';

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
              <Icons.warning className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <CardTitle className="text-2xl text-orange-600">
                Page Not Found
              </CardTitle>
              <CardDescription className="mt-1">
                The page you're looking for doesn't exist.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">
              The route you tried to access doesn't match any available pages.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button onClick={() => navigate('/')} variant="outline">
              <Icons.home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
            <Button onClick={() => navigate(-1)} variant="outline">
              <Icons.chevronLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
          </div>

          <div className="pt-4 border-t">
            <p className="text-xs text-muted-foreground mb-2">
              Available pages:
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigate('/')}
                className="text-xs"
              >
                Home
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigate('/projects')}
                className="text-xs"
              >
                Projects
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigate('/tools')}
                className="text-xs"
              >
                Tools
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigate('/aiagent')}
                className="text-xs"
              >
                Backend Builder
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigate('/chatflow')}
                className="text-xs"
              >
                Frontend Builder
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}



