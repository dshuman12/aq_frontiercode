import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Icons } from '../../components/ui/icons';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { useToast } from '../../hooks/toast';
import { apiRequest } from '../../lib/api-client';
import { useProjects } from '../../hooks/project';
import { useWorkspaces } from '../../hooks/workspace';
import useUserStore from '../../store/user';

function formatBytes(size) {
  const value = Number(size || 0);
  if (!Number.isFinite(value) || value <= 0) return '0 B';
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}

function arraysEqual(left = [], right = []) {
  if (left.length !== right.length) return false;
  return left.every((value, index) => value === right[index]);
}

export default function KnowledgeBasePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const token = useUserStore((state) => state.user?.token);
  const { currentWorkspaceId } = useWorkspaces();
  const {
    projects,
    updateProject,
    isUpdating: isUpdatingProject,
  } = useProjects();

  const backendBots = useMemo(
    () => (projects || []).filter((project) => project?.project_type === 'backend'),
    [projects]
  );

  const [documents, setDocuments] = useState([]);
  const [collections, setCollections] = useState([]);
  const [selectedDocumentIds, setSelectedDocumentIds] = useState([]);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [newCollectionDescription, setNewCollectionDescription] = useState('');
  const [urlImportForm, setUrlImportForm] = useState({
    title: '',
    source_url: '',
    source_language: '',
  });
  const [activeCollectionId, setActiveCollectionId] = useState('');
  const [activeBotId, setActiveBotId] = useState('');
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [retrievalForm, setRetrievalForm] = useState({
    query: '',
    collection_id: '',
    relative_path: '',
    chunk_size: 500,
    chunk_overlap: 50,
    top_k: 3,
  });
  const [retrievalResult, setRetrievalResult] = useState(null);
  const [isTestingRetrieval, setIsTestingRetrieval] = useState(false);

  const syncBotBindings = useCallback(
    async (nextCollections) => {
      const bindingMap = new Map();
      backendBots.forEach((bot) => bindingMap.set(bot.id, []));
      nextCollections.forEach((collection) => {
        (collection.botIds || []).forEach((botId) => {
          if (bindingMap.has(botId)) {
            bindingMap.get(botId).push(collection.id);
          }
        });
      });

      const updates = [];
      backendBots.forEach((bot) => {
        const nextBindingIds = [...(bindingMap.get(bot.id) || [])].sort();
        const currentBindingIds = [
          ...((bot.flow?.ai_config?.knowledge_bindings || []).filter(Boolean)),
        ].sort();
        if (arraysEqual(nextBindingIds, currentBindingIds)) return;

        updates.push(
          updateProject(
            bot.id,
            {
              flow: {
                ...(bot.flow || {}),
                ai_config: {
                  ...(bot.flow?.ai_config || {}),
                  knowledge_bindings: nextBindingIds,
                },
              },
            },
            { skipRevalidate: true }
          )
        );
      });

      if (updates.length > 0) {
        await Promise.all(updates);
      }
    },
    [backendBots, updateProject]
  );

  const persistCollections = useCallback(
    async (nextCollections, options = {}) => {
      const { syncBots = false } = options;
      setCollections(nextCollections);
      if (syncBots) {
        await syncBotBindings(nextCollections);
      }
    },
    [syncBotBindings]
  );

  const loadCollections = useCallback(async () => {
    if (!token) {
      setCollections([]);
      return;
    }
    try {
      const response = await apiRequest(
        `/knowledge/collections${currentWorkspaceId ? `?workspace_id=${encodeURIComponent(currentWorkspaceId)}` : ''}`,
        {
          method: 'GET',
          showErrorToast: false,
        }
      );
      setCollections(Array.isArray(response) ? response : []);
    } catch (error) {
      toast({
        title: 'Could not load collections',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    }
  }, [currentWorkspaceId, toast, token]);

  const loadDocuments = useCallback(async () => {
    if (!token) {
      setDocuments([]);
      return;
    }
    setIsLoadingDocs(true);
    try {
      const response = await apiRequest(
        `/knowledge/uploads${currentWorkspaceId ? `?workspace_id=${encodeURIComponent(currentWorkspaceId)}` : ''}`,
        {
          method: 'GET',
          showErrorToast: false,
        }
      );
      setDocuments(Array.isArray(response) ? response : []);
    } catch (error) {
      toast({
        title: 'Could not load documents',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingDocs(false);
    }
  }, [currentWorkspaceId, toast, token]);

  useEffect(() => {
    loadDocuments();
  }, [loadDocuments]);

  useEffect(() => {
    loadCollections();
  }, [loadCollections]);

  const handleUpload = useCallback(
    async (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      setIsUploading(true);
      try {
        const form = new FormData();
        form.append('file', file);
        form.append('title', file.name);
        if (currentWorkspaceId) {
          form.append('workspace_id', currentWorkspaceId);
        }
        const result = await apiRequest('/knowledge/uploads', {
          method: 'POST',
          body: form,
          showErrorToast: false,
        });
        setDocuments((current) => [result, ...current]);
        setRetrievalForm((current) => ({
          ...current,
          relative_path: current.relative_path || result.relative_path,
        }));
        toast({
          title: 'Document uploaded',
          description: `${file.name} is now available for retrieval testing.`,
        });
      } catch (error) {
        toast({
          title: 'Upload failed',
          description: error instanceof Error ? error.message : 'Request failed',
          variant: 'destructive',
        });
      } finally {
        event.target.value = '';
        setIsUploading(false);
      }
    },
    [currentWorkspaceId, toast]
  );

  const handleDeleteDocument = useCallback(
    async (documentId) => {
      try {
        await apiRequest(`/knowledge/uploads/${documentId}`, {
          method: 'DELETE',
          showErrorToast: false,
        });
        setDocuments((current) => current.filter((item) => item.id !== documentId));
        setSelectedDocumentIds((current) => current.filter((id) => id !== documentId));

        const nextCollections = collections.map((collection) => ({
          ...collection,
          documentIds: (collection.documentIds || []).filter((id) => id !== documentId),
        }));
        await persistCollections(nextCollections, { syncBots: false });
        await Promise.all(
          nextCollections.map((collection) =>
            apiRequest(`/knowledge/collections/${collection.id}`, {
              method: 'PUT',
              body: {
                workspace_id: currentWorkspaceId,
                ...collection,
              },
              showErrorToast: false,
            })
          )
        );

        toast({
          title: 'Document removed',
          description: 'The source was deleted from this knowledge workspace.',
        });
      } catch (error) {
        toast({
          title: 'Delete failed',
          description: error instanceof Error ? error.message : 'Request failed',
          variant: 'destructive',
        });
      }
    },
    [collections, currentWorkspaceId, persistCollections, toast]
  );

  const handleReprocessDocument = useCallback(
    async (documentId) => {
      try {
        const updated = await apiRequest(`/knowledge/uploads/${documentId}/reprocess`, {
          method: 'POST',
          showErrorToast: false,
        });
        setDocuments((current) =>
          current.map((item) => (item.id === documentId ? updated : item))
        );
        toast({
          title: updated.source_type === 'url' ? 'Source sync complete' : 'Reprocessing complete',
          description:
            updated.status === 'indexed'
              ? updated.source_type === 'url'
                ? 'The web connector source was refreshed and is ready for retrieval.'
                : 'The document is indexed and ready for retrieval.'
              : 'The document needs review. Check the indexing error in the source card.',
        });
      } catch (error) {
        toast({
          title: 'Reprocess failed',
          description: error instanceof Error ? error.message : 'Request failed',
          variant: 'destructive',
        });
      }
    },
    [toast]
  );

  const handleImportUrl = useCallback(async () => {
    const sourceUrl = urlImportForm.source_url.trim();
    if (!sourceUrl) {
      toast({
        title: 'URL required',
        description: 'Enter a source URL before importing a web connector.',
        variant: 'destructive',
      });
      return;
    }
    setIsUploading(true);
    try {
      const result = await apiRequest('/knowledge/urls/import', {
        method: 'POST',
        body: {
          workspace_id: currentWorkspaceId,
          title: urlImportForm.title.trim(),
          source_url: sourceUrl,
          source_language: urlImportForm.source_language.trim(),
        },
        showErrorToast: false,
      });
      setDocuments((current) => [result, ...current]);
      setUrlImportForm({ title: '', source_url: '', source_language: '' });
      toast({
        title: 'Web connector imported',
        description: 'The URL source has been fetched and added to the knowledge library.',
      });
    } catch (error) {
      toast({
        title: 'URL import failed',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  }, [currentWorkspaceId, toast, urlImportForm]);

  const handleCreateCollection = useCallback(async () => {
    const name = newCollectionName.trim();
    if (!name) {
      toast({
        title: 'Collection name required',
        description: 'Enter a collection name before creating it.',
        variant: 'destructive',
      });
      return;
    }
    try {
      const created = await apiRequest('/knowledge/collections', {
        method: 'POST',
        body: {
          workspace_id: currentWorkspaceId,
          name,
          description: newCollectionDescription.trim(),
          documentIds: [],
          botIds: [],
        },
        showErrorToast: false,
      });
      const nextCollections = [created, ...collections];
      await persistCollections(nextCollections, { syncBots: false });
      setNewCollectionName('');
      setNewCollectionDescription('');
      setActiveCollectionId(created?.id || '');
    } catch (error) {
      toast({
        title: 'Collection create failed',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    }
  }, [
    collections,
    currentWorkspaceId,
    newCollectionDescription,
    newCollectionName,
    persistCollections,
    toast,
  ]);

  const handleAttachSelectedDocuments = useCallback(async () => {
    if (!activeCollectionId || selectedDocumentIds.length === 0) {
      toast({
        title: 'Select a collection and documents',
        description: 'Choose at least one document and a collection to attach them.',
        variant: 'destructive',
      });
      return;
    }

    const nextCollections = collections.map((collection) => {
      if (collection.id !== activeCollectionId) return collection;
      return {
        ...collection,
        documentIds: Array.from(
          new Set([...(collection.documentIds || []), ...selectedDocumentIds])
        ),
      };
    });
    try {
      const target = nextCollections.find((collection) => collection.id === activeCollectionId);
      if (!target) return;
      const updated = await apiRequest(`/knowledge/collections/${activeCollectionId}`, {
        method: 'PUT',
        body: {
          workspace_id: currentWorkspaceId,
          ...target,
        },
        showErrorToast: false,
      });
      await persistCollections(
        nextCollections.map((collection) =>
          collection.id === activeCollectionId ? updated : collection
        ),
        { syncBots: false }
      );
      setSelectedDocumentIds([]);
      toast({
        title: 'Documents attached',
        description: 'Selected sources are now part of the chosen collection.',
      });
    } catch (error) {
      toast({
        title: 'Attach failed',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    }
  }, [activeCollectionId, collections, currentWorkspaceId, persistCollections, selectedDocumentIds, toast]);

  const handleToggleBotBinding = useCallback(
    async (collectionId, botId) => {
      const nextCollections = collections.map((collection) => {
        if (collection.id !== collectionId) return collection;
        const hasBot = (collection.botIds || []).includes(botId);
        return {
          ...collection,
          botIds: hasBot
            ? collection.botIds.filter((id) => id !== botId)
            : [...(collection.botIds || []), botId],
        };
      });
      const target = nextCollections.find((collection) => collection.id === collectionId);
      if (!target) return;
      const updated = await apiRequest(`/knowledge/collections/${collectionId}`, {
        method: 'PUT',
        body: {
          workspace_id: currentWorkspaceId,
          ...target,
        },
        showErrorToast: false,
      });
      await persistCollections(
        nextCollections.map((collection) => (collection.id === collectionId ? updated : collection)),
        { syncBots: true }
      );
    },
    [collections, currentWorkspaceId, persistCollections]
  );

  const handleBindCollectionToBot = useCallback(async () => {
    if (!activeCollectionId || !activeBotId) {
      toast({
        title: 'Select bot and collection',
        description: 'Choose both a backend bot and a collection to create a binding.',
        variant: 'destructive',
      });
      return;
    }
    await handleToggleBotBinding(activeCollectionId, activeBotId);
    toast({
      title: 'Bot binding updated',
      description: 'The selected backend bot now has this knowledge collection linked.',
    });
  }, [activeBotId, activeCollectionId, handleToggleBotBinding, toast]);

  const handleRemoveDocumentFromCollection = useCallback(
    async (collectionId, documentId) => {
      const nextCollections = collections.map((collection) =>
        collection.id === collectionId
          ? {
              ...collection,
              documentIds: (collection.documentIds || []).filter((id) => id !== documentId),
            }
          : collection
      );
      const target = nextCollections.find((collection) => collection.id === collectionId);
      if (!target) return;
      const updated = await apiRequest(`/knowledge/collections/${collectionId}`, {
        method: 'PUT',
        body: {
          workspace_id: currentWorkspaceId,
          ...target,
        },
        showErrorToast: false,
      });
      await persistCollections(
        nextCollections.map((collection) => (collection.id === collectionId ? updated : collection)),
        { syncBots: false }
      );
    },
    [collections, currentWorkspaceId, persistCollections]
  );

  const handleDeleteCollection = useCallback(
    async (collectionId) => {
      try {
        await apiRequest(
          `/knowledge/collections/${collectionId}${currentWorkspaceId ? `?workspace_id=${encodeURIComponent(currentWorkspaceId)}` : ''}`,
          {
            method: 'DELETE',
            showErrorToast: false,
          }
        );
        const nextCollections = collections.filter((collection) => collection.id !== collectionId);
        await persistCollections(nextCollections, { syncBots: true });
        if (activeCollectionId === collectionId) {
          setActiveCollectionId('');
        }
      } catch (error) {
        toast({
          title: 'Delete collection failed',
          description: error instanceof Error ? error.message : 'Request failed',
          variant: 'destructive',
        });
      }
    },
    [activeCollectionId, collections, currentWorkspaceId, persistCollections, toast]
  );

  const handleRunRetrievalTest = useCallback(async () => {
    if (!retrievalForm.query.trim()) {
      toast({
        title: 'Query required',
        description: 'Enter a user question before running retrieval.',
        variant: 'destructive',
      });
      return;
    }

    setIsTestingRetrieval(true);
    try {
      const result = await apiRequest('/knowledge/retrieval/test', {
        method: 'POST',
        body: {
          ...retrievalForm,
          workspace_id: currentWorkspaceId,
          chunk_size: Number(retrievalForm.chunk_size),
          chunk_overlap: Number(retrievalForm.chunk_overlap),
          top_k: Number(retrievalForm.top_k),
        },
        showErrorToast: false,
      });
      setRetrievalResult(result);
    } catch (error) {
      setRetrievalResult(null);
      toast({
        title: 'Retrieval test failed',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    } finally {
      setIsTestingRetrieval(false);
    }
  }, [currentWorkspaceId, retrievalForm, toast]);

  const stats = useMemo(() => {
    const indexed = documents.filter((document) => document.status === 'indexed').length;
    const boundBots = new Set(collections.flatMap((collection) => collection.botIds || []));
    return [
      { label: 'Sources', value: String(documents.length) },
      { label: 'Indexed', value: String(indexed) },
      { label: 'Collections', value: String(collections.length) },
      { label: 'Bound Bots', value: String(boundBots.size) },
    ];
  }, [collections, documents]);

  const collectionMap = useMemo(() => {
    const map = new Map();
    collections.forEach((collection) => {
      map.set(collection.id, collection);
    });
    return map;
  }, [collections]);

  const documentMap = useMemo(() => {
    const map = new Map();
    documents.forEach((document) => map.set(document.id, document));
    return map;
  }, [documents]);

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <PageHeader
          title="Knowledge Base"
          description="Turn business documents into bot-ready knowledge, organize them by use case, attach them to AI agents, and validate retrieval quality before going live."
          icon={Icons.docs}
          actions={
            <>
              <Button variant="outline" onClick={loadDocuments} disabled={isLoadingDocs}>
                <Icons.refresh className="mr-2 h-4 w-4" />
                Refresh
              </Button>
              <Button onClick={() => navigate('/aiagent')}>
                <Icons.sparkles className="mr-2 h-4 w-4" />
                Open AI Agent
              </Button>
            </>
          }
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardHeader className="pb-2">
                <CardDescription>{stat.label}</CardDescription>
                <CardTitle className="text-2xl">{stat.value}</CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>What This Page Does</CardTitle>
            <CardDescription>
              This page helps non-technical teams prepare trusted knowledge for AI agents.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className="rounded-xl border bg-muted/20 p-4">
              <div className="text-sm font-semibold">1. Upload business sources</div>
              <p className="mt-2 text-sm text-muted-foreground">
                Add product PDFs, SOPs, pricing sheets, onboarding guides, policy documents, and FAQ files so the bot can search them.
              </p>
            </div>
            <div className="rounded-xl border bg-muted/20 p-4">
              <div className="text-sm font-semibold">2. Group them into collections</div>
              <p className="mt-2 text-sm text-muted-foreground">
                Create collections such as `Sales`, `Support`, `HR`, or `Returns Policy` so each bot uses the right knowledge for its role.
              </p>
            </div>
            <div className="rounded-xl border bg-muted/20 p-4">
              <div className="text-sm font-semibold">3. Test before production</div>
              <p className="mt-2 text-sm text-muted-foreground">
                Use Retrieval Test to confirm the bot is finding the right passages before you bind the collection to a live AI agent.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="rounded-lg border bg-muted/20 p-4 text-sm text-muted-foreground">
          `Knowledge Base` owns sources, URL connectors, collections, and bot knowledge bindings. Bot tone, intents, entities, and guardrails belong in `AI Agent`, while governed publishing and rollback belong in `Publish Center`.
        </div>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <Card className="xl:col-span-1">
            <CardHeader>
              <CardTitle>Upload Sources</CardTitle>
              <CardDescription>
                Add source material the bot can search and quote from.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-primary/30 bg-primary/5 px-4 py-8 text-center">
                <Icons.upload className="mb-3 h-6 w-6 text-primary" />
                <span className="text-sm font-medium">Choose a file to upload</span>
                <span className="mt-1 text-xs text-muted-foreground">
                  PDF, TXT, Markdown, HTML, CSV, JSON, DOCX, XLSX, and more.
                </span>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleUpload}
                  disabled={isUploading}
                />
              </label>
              <div className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                Enterprise example: upload pricing catalogs for a sales bot, warranty PDFs for a support bot, or HR policy handbooks for an internal assistant.
              </div>
              <div className="rounded-lg border bg-muted/30 p-3 space-y-3">
                <div className="text-sm font-medium">Web URL connector</div>
                <Input
                  placeholder="Optional title, e.g. Public pricing page"
                  value={urlImportForm.title}
                  onChange={(event) =>
                    setUrlImportForm((current) => ({ ...current, title: event.target.value }))
                  }
                />
                <Input
                  placeholder="https://example.com/help/article"
                  value={urlImportForm.source_url}
                  onChange={(event) =>
                    setUrlImportForm((current) => ({ ...current, source_url: event.target.value }))
                  }
                />
                <Input
                  placeholder="Optional language, e.g. English"
                  value={urlImportForm.source_language}
                  onChange={(event) =>
                    setUrlImportForm((current) => ({ ...current, source_language: event.target.value }))
                  }
                />
                <Button variant="outline" onClick={handleImportUrl} disabled={isUploading}>
                  Import URL Source
                </Button>
                <p className="text-xs text-muted-foreground">
                  Use this for connector-style sync of public help pages, policy pages, documentation articles, or other web knowledge sources.
                </p>
              </div>
              <div className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                Uploaded files are stored in the knowledge service, their metadata is tracked in the database, and they become available immediately for retrieval testing.
              </div>
            </CardContent>
          </Card>

          <Card className="xl:col-span-2">
            <CardHeader>
              <CardTitle>Collections And Bot Bindings</CardTitle>
              <CardDescription>
                Organize documents by business purpose, then attach those collections to the right backend bots.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                Example collections: `Sales Enablement`, `Order Tracking`, `Claims Policy`, `Technical Troubleshooting`, or `Employee Benefits`.
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <Input
                  placeholder="Collection name"
                  value={newCollectionName}
                  onChange={(event) => setNewCollectionName(event.target.value)}
                />
                <Button onClick={handleCreateCollection}>Create Collection</Button>
              </div>
              <Textarea
                rows={3}
                placeholder="Describe the collection purpose, audience, or business domain."
                value={newCollectionDescription}
                onChange={(event) => setNewCollectionDescription(event.target.value)}
              />

              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <Select value={activeCollectionId} onValueChange={setActiveCollectionId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select collection" />
                  </SelectTrigger>
                  <SelectContent>
                    {collections.map((collection) => (
                      <SelectItem key={collection.id} value={collection.id}>
                        {collection.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  variant="outline"
                  onClick={handleAttachSelectedDocuments}
                  disabled={selectedDocumentIds.length === 0}
                >
                  Attach Selected Docs
                </Button>

                <Select value={activeBotId} onValueChange={setActiveBotId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select backend bot" />
                  </SelectTrigger>
                  <SelectContent>
                    {backendBots.map((bot) => (
                      <SelectItem key={bot.id} value={bot.id}>
                        {bot.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                variant="outline"
                onClick={handleBindCollectionToBot}
                disabled={!activeCollectionId || !activeBotId || isUpdatingProject}
              >
                Bind Collection To Bot
              </Button>

              <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                {collections.length === 0 ? (
                  <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground lg:col-span-2">
                    No collections yet. Create one, attach documents, then bind it to a backend bot.
                  </div>
                ) : (
                  collections.map((collection) => (
                    <div key={collection.id} className="rounded-xl border p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold">{collection.name}</div>
                          <p className="mt-1 text-xs text-muted-foreground">
                            {collection.description || 'No description yet.'}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteCollection(collection.id)}
                        >
                          <Icons.trash className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        <Badge variant="outline">
                          {(collection.documentIds || []).length} docs
                        </Badge>
                        <Badge variant="outline">
                          {(collection.botIds || []).length} bots
                        </Badge>
                      </div>

                      <div className="mt-4 space-y-2">
                        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                          Documents
                        </div>
                        {(collection.documentIds || []).length === 0 ? (
                          <div className="text-xs text-muted-foreground">
                            No documents attached yet.
                          </div>
                        ) : (
                          (collection.documentIds || []).map((documentId) => {
                            const document = documentMap.get(documentId);
                            return (
                              <div
                                key={documentId}
                                className="flex items-center justify-between gap-3 rounded-lg bg-muted/30 px-3 py-2"
                              >
                                <div className="min-w-0">
                                  <div className="truncate text-sm">
                                    {document?.title || documentId}
                                  </div>
                                  <div className="truncate text-xs text-muted-foreground">
                                    {document?.mime || 'Document reference'}
                                  </div>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() =>
                                    handleRemoveDocumentFromCollection(collection.id, documentId)
                                  }
                                >
                                  Remove
                                </Button>
                              </div>
                            );
                          })
                        )}
                      </div>

                      <div className="mt-4 space-y-2">
                        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                          Backend Bots
                        </div>
                        {backendBots.length === 0 ? (
                          <div className="text-xs text-muted-foreground">
                            No backend bots found yet.
                          </div>
                        ) : (
                          backendBots.map((bot) => {
                            const isBound = (collection.botIds || []).includes(bot.id);
                            return (
                              <button
                                key={bot.id}
                                type="button"
                                onClick={() => handleToggleBotBinding(collection.id, bot.id)}
                                className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition ${
                                  isBound
                                    ? 'border-primary bg-primary/5 text-foreground'
                                    : 'border-border bg-background text-muted-foreground'
                                }`}
                              >
                                <span className="truncate">{bot.name}</span>
                                <span>{isBound ? 'Bound' : 'Bind'}</span>
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Source Library</CardTitle>
              <CardDescription>
                Review document health, attach sources to collections, and remove outdated content.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {isLoadingDocs ? (
                <div className="text-sm text-muted-foreground">Loading documents...</div>
              ) : documents.length === 0 ? (
                <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                  No uploaded knowledge sources yet.
                </div>
              ) : (
                documents.map((document) => {
                  const checked = selectedDocumentIds.includes(document.id);
                  const usedByCollections = collections.filter((collection) =>
                    (collection.documentIds || []).includes(document.id)
                  );
                  return (
                    <div key={document.id} className="rounded-xl border p-4">
                      <div className="flex items-start justify-between gap-3">
                        <label className="flex min-w-0 flex-1 cursor-pointer items-start gap-3">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(event) => {
                              setSelectedDocumentIds((current) =>
                                event.target.checked
                                  ? [...current, document.id]
                                  : current.filter((id) => id !== document.id)
                              );
                            }}
                            className="mt-1 h-4 w-4"
                          />
                          <div className="min-w-0">
                            <div className="truncate text-sm font-medium">
                              {document.title || document.filename}
                            </div>
                            <div className="mt-1 flex flex-wrap gap-2">
                              <Badge variant="outline">{document.status || 'indexed'}</Badge>
                              <Badge variant="outline">{formatBytes(document.size)}</Badge>
                              <Badge variant="outline">{document.mime || 'file'}</Badge>
                              <Badge variant="outline">{document.source_type || 'file'}</Badge>
                              {document.sync_status ? (
                                <Badge variant="outline">sync: {document.sync_status}</Badge>
                              ) : null}
                            </div>
                            <div className="mt-2 text-xs text-muted-foreground">
                              {document.created_at || document.relative_path}
                            </div>
                            {document.source_url ? (
                              <div className="mt-2 truncate text-xs text-muted-foreground">
                                {document.source_url}
                              </div>
                            ) : null}
                            {document.index_error ? (
                              <div className="mt-2 rounded-md border border-red-200 bg-red-50 px-2 py-1 text-xs text-red-700">
                                {document.index_error}
                              </div>
                            ) : null}
                            {usedByCollections.length > 0 ? (
                              <div className="mt-2 flex flex-wrap gap-2">
                                {usedByCollections.map((collection) => (
                                  <Badge key={collection.id} variant="secondary">
                                    {collection.name}
                                  </Badge>
                                ))}
                              </div>
                            ) : null}
                          </div>
                        </label>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleReprocessDocument(document.id)}
                            title={document.source_type === 'url' ? 'Sync connector source' : 'Reprocess document'}
                          >
                            <Icons.refresh className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteDocument(document.id)}
                            title="Delete document"
                          >
                            <Icons.trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Retrieval Test</CardTitle>
              <CardDescription>
                Preview what the bot will retrieve from your sources before those sources influence live answers.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-xl border bg-muted/20 p-4 text-sm">
                <div className="font-semibold">What is Retrieval Test?</div>
                <p className="mt-2 text-muted-foreground">
                  Retrieval Test simulates the search step of RAG. It shows which document passages the platform would send to the AI model for grounding.
                </p>
                <p className="mt-2 text-muted-foreground">
                  This is useful when users say the bot "answered from the wrong document" or "missed the right policy". You can test and tune retrieval before customers see it.
                </p>
              </div>
              <div className="rounded-xl border bg-muted/20 p-4 text-sm">
                <div className="font-semibold">What do `500`, `50`, and `3` mean?</div>
                <p className="mt-2 text-muted-foreground">
                  These are not epochs or batch sizes. They are retrieval settings:
                </p>
                <p className="mt-2 text-muted-foreground">
                  `500` = chunk size. Each document is split into blocks of about 500 characters so the search engine can compare smaller passages instead of the full file.
                </p>
                <p className="mt-2 text-muted-foreground">
                  `50` = chunk overlap. Each chunk repeats about 50 characters from the previous chunk so important sentences are not cut in the middle.
                </p>
                <p className="mt-2 text-muted-foreground">
                  `3` = top K. The system returns the best 3 matching chunks to the AI model.
                </p>
              </div>
              <Select
                value={retrievalForm.collection_id}
                onValueChange={(value) =>
                  setRetrievalForm((current) => ({
                    ...current,
                    collection_id: value === '__none__' ? '' : value,
                    relative_path: value === '__none__' ? current.relative_path : '',
                  }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Optional: test an entire collection" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">Single document mode</SelectItem>
                  {collections.map((collection) => (
                    <SelectItem key={collection.id} value={collection.id}>
                      {collection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={retrievalForm.relative_path}
                onValueChange={(value) =>
                  setRetrievalForm((current) => ({
                    ...current,
                    relative_path: value,
                    collection_id: '',
                  }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose a source document" />
                </SelectTrigger>
                <SelectContent>
                  {documents.map((document) => (
                    <SelectItem key={document.id} value={document.relative_path}>
                      {document.title || document.filename}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Textarea
                rows={4}
                placeholder="Ask a question the bot should answer from this document or collection."
                value={retrievalForm.query}
                onChange={(event) =>
                  setRetrievalForm((current) => ({ ...current, query: event.target.value }))
                }
              />

              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div className="space-y-2">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Chunk size
                  </div>
                  <Input
                    type="number"
                    min="100"
                    value={retrievalForm.chunk_size}
                    onChange={(event) =>
                      setRetrievalForm((current) => ({
                        ...current,
                        chunk_size: event.target.value,
                      }))
                    }
                    placeholder="500"
                  />
                  <p className="text-xs text-muted-foreground">
                    Larger values keep more context together. Start with `500`.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Chunk overlap
                  </div>
                  <Input
                    type="number"
                    min="0"
                    value={retrievalForm.chunk_overlap}
                    onChange={(event) =>
                      setRetrievalForm((current) => ({
                        ...current,
                        chunk_overlap: event.target.value,
                      }))
                    }
                    placeholder="50"
                  />
                  <p className="text-xs text-muted-foreground">
                    Preserves continuity between chunks. Start with `50`.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Top K results
                  </div>
                  <Input
                    type="number"
                    min="1"
                    value={retrievalForm.top_k}
                    onChange={(event) =>
                      setRetrievalForm((current) => ({
                        ...current,
                        top_k: event.target.value,
                      }))
                    }
                    placeholder="3"
                  />
                  <p className="text-xs text-muted-foreground">
                    Number of best passages returned to the model. Start with `3`.
                  </p>
                </div>
              </div>

              <Button onClick={handleRunRetrievalTest} disabled={isTestingRetrieval}>
                {isTestingRetrieval ? 'Testing...' : 'Run Retrieval Test'}
              </Button>

              {retrievalResult ? (
                <div className="space-y-3 rounded-xl border bg-muted/20 p-4">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">
                      {retrievalResult.total_chunks || 0} chunks
                    </Badge>
                    <Badge variant="outline">
                      top {retrievalResult.top_k || 0}
                    </Badge>
                    <Badge variant="outline">
                      source {retrievalResult.knowledge_source || 'unknown'}
                    </Badge>
                  </div>
                  {(retrievalResult.matches || []).length === 0 ? (
                    <div className="text-sm text-muted-foreground">
                      No relevant chunks were found for this query.
                    </div>
                  ) : (
                    (retrievalResult.matches || []).map((match) => (
                      <div key={`${match.chunk_index}-${match.start}`} className="rounded-lg border bg-background p-3">
                        <div className="mb-2 flex flex-wrap gap-2 text-xs text-muted-foreground">
                          <span>Chunk {match.chunk_index}</span>
                          <span>score {match.score}</span>
                          <span>density {match.density_score}</span>
                        </div>
                        <p className="text-sm leading-6 text-foreground">{match.content}</p>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                  Run a retrieval test to preview the chunks a bot would use.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Backend Bot Coverage</CardTitle>
            <CardDescription>
              Verify which AI agents already have the right knowledge packs attached.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {backendBots.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No backend bots found. Create an AI Agent project first.
              </div>
            ) : (
              backendBots.map((bot) => {
                const bindingIds = bot.flow?.ai_config?.knowledge_bindings || [];
                return (
                  <div key={bot.id} className="rounded-xl border p-4">
                    <div className="text-sm font-semibold">{bot.name}</div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Badge variant="outline">{bindingIds.length} collections</Badge>
                      {bindingIds.length === 0 ? (
                        <Badge variant="secondary">Needs binding</Badge>
                      ) : (
                        <Badge variant="secondary">RAG ready</Badge>
                      )}
                    </div>
                    <div className="mt-3 space-y-2 text-xs text-muted-foreground">
                      {bindingIds.length === 0 ? (
                        <div>No collections are attached yet.</div>
                      ) : (
                        bindingIds.map((collectionId) => (
                          <div key={collectionId}>
                            {collectionMap.get(collectionId)?.name || collectionId}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
