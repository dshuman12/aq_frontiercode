import { ReactFlowProvider } from '@xyflow/react';
import { Editor } from './resize';

// Frontend nodes: initializer, api, note, text, image, input, delay, assistant, condition, quickreply, container, branch
const FRONTEND_NODES = [
  'initializer',
  'api',
  'note',
  'text',
  'image',
  'input',
  'calendar',
  'form',
  'document',
  'ocr',
  'delay',
  'assistant',
  'condition',
  'quickreply',
  'container',
  'branch',
  'switch',
  'merge',
];

export default function NoCodeFrontendCanvas() {
  return (
    <ReactFlowProvider key="nocode-frontend-reactflow">
      <Editor 
        projectId={-1} 
        nodeFilter={FRONTEND_NODES}
        showChat={false}
        showConfigConditionally={true}
      />
    </ReactFlowProvider>
  );
}

