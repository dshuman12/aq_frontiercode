import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icons } from '../../components/ui/icons';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import useWorkspaceStore from '../../store/workspace';
import useUserStore from '../../store/user';
import { toast } from '../../hooks/toast';
import { canUseAuthenticatedRequests } from '../../lib/api-client';
import { cn } from '../../lib/utils';

const TEMPLATE_TYPE_OPTIONS = [
  { id: 'all', label: 'All templates' },
  { id: 'frontend', label: 'Chat Flow' },
  { id: 'backend', label: 'AI Agent' },
];

const FETCH_LIMIT = { all: 12, single: 24 };

const CATEGORY_BADGE_LIGHT = [
  'border-teal-500/40 bg-teal-500/10 text-teal-800 dark:text-teal-200',
  'border-sky-500/40 bg-sky-500/10 text-sky-900 dark:text-sky-200',
  'border-amber-500/40 bg-amber-500/10 text-amber-950 dark:text-amber-100',
  'border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-900 dark:text-fuchsia-100',
  'border-rose-500/40 bg-rose-500/10 text-rose-900 dark:text-rose-100',
  'border-emerald-500/40 bg-emerald-500/10 text-emerald-900 dark:text-emerald-100',
  'border-indigo-500/40 bg-indigo-500/10 text-indigo-900 dark:text-indigo-100',
  'border-cyan-500/40 bg-cyan-500/10 text-cyan-900 dark:text-cyan-100',
  'border-orange-500/40 bg-orange-500/10 text-orange-950 dark:text-orange-100',
  'border-pink-500/40 bg-pink-500/10 text-pink-900 dark:text-pink-100',
  'border-lime-600/40 bg-lime-500/10 text-lime-950 dark:text-lime-100',
  'border-violet-500/40 bg-violet-500/10 text-violet-900 dark:text-violet-100',
];

const CATEGORY_DOT_BG = [
  'bg-teal-500',
  'bg-sky-500',
  'bg-amber-500',
  'bg-fuchsia-500',
  'bg-rose-500',
  'bg-emerald-500',
  'bg-indigo-500',
  'bg-cyan-500',
  'bg-orange-500',
  'bg-pink-500',
  'bg-lime-500',
  'bg-violet-500',
];

/** Same category string → same palette index (category pills + filter dots). */
function categoryStyleIndex(categoryOrKey) {
  const s = String(categoryOrKey || '').trim();
  if (!s) return 0;
  let h = 0;
  for (let i = 0; i < s.length; i += 1) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h) % CATEGORY_BADGE_LIGHT.length;
}

function categoryBadgeLightClass(category) {
  const s = String(category || '').trim();
  if (!s) return 'border-border/50 bg-muted/40 text-muted-foreground';
  return cn('border', CATEGORY_BADGE_LIGHT[categoryStyleIndex(s)]);
}

function categoryOptionsFromTemplates(templates) {
  const set = new Set();
  (templates || []).forEach((t) => {
    const c = t?.category != null ? String(t.category).trim() : '';
    if (c) set.add(c);
  });
  return [
    { id: 'all', label: 'All categories' },
    ...[...set].sort((a, b) => a.localeCompare(b)).map((c) => ({ id: c, label: c })),
  ];
}

function filterByCategory(templates, categoryId) {
  if (!categoryId || categoryId === 'all') return templates || [];
  return (templates || []).filter((t) => String(t?.category || '').trim() === categoryId);
}

const TemplateCard = ({ template, onUseTemplate, onTestTemplate, onRate, onDelete, isUsing, isDeleting, canDelete }) => {
  const average = template.rating_count > 0 ? template.rating_sum / template.rating_count : 0;
  const isBackend = template.project_type === 'backend';
  const destinationLabel = isBackend ? 'AI Agent' : 'Chat Flow';
  const WatermarkIcon = isBackend ? Icons.sparkles : Icons.gitFork;

  const deleteBtn = canDelete ? (
    <Button
      size="icon"
      variant="ghost"
      className="absolute right-2 top-2 z-20 h-8 w-8 rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
      disabled={isDeleting}
      onClick={(e) => {
        e.stopPropagation();
        onDelete?.();
      }}
      title="Delete template"
    >
      {isDeleting ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.trash className="h-4 w-4" />}
    </Button>
  ) : null;

  return (
    <Card
      className={cn(
        'group relative flex min-h-[220px] flex-col overflow-hidden p-5 shadow-sm transition-all duration-200',
        'hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md'
      )}
    >
      <WatermarkIcon
        className="pointer-events-none absolute -right-1 -top-1 h-28 w-28 text-primary/[0.07]"
        aria-hidden
      />
      {deleteBtn}
      <div className="relative z-10 flex min-h-0 flex-1 flex-col pr-2">
        <h2 className="line-clamp-2 pr-8 text-lg font-bold leading-snug tracking-tight text-primary">{template.name}</h2>
        {template.category ? (
          <span
            className={cn(
              'mt-2 inline-flex w-fit rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider',
              categoryBadgeLightClass(template.category)
            )}
          >
            {template.category}
          </span>
        ) : null}
        <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-muted-foreground">
          {template.description || 'No description provided.'}
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-1 rounded-md bg-muted/50 px-1.5 py-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className="rounded p-0.5 text-sm leading-none text-amber-500 transition hover:scale-110 active:scale-95"
              onClick={(e) => {
                e.stopPropagation();
                onRate(star);
              }}
              title={`Rate ${star} star${star > 1 ? 's' : ''}`}
            >
              <span className={star <= Math.round(average) ? 'drop-shadow' : 'opacity-35'}>★</span>
            </button>
          ))}
          <span className="ml-1 text-[11px] tabular-nums text-muted-foreground">
            {average.toFixed(1)} ({template.rating_count})
          </span>
        </div>
        <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-5">
          <Button
            size="sm"
            disabled={isUsing}
            variant="default"
            className="h-10 rounded-xl px-5 font-semibold shadow-sm"
            onClick={(e) => {
              e.stopPropagation();
              onUseTemplate({ mode: 'use' });
            }}
          >
            {isUsing ? <Icons.spinner className="mr-2 h-4 w-4 animate-spin" /> : <Icons.project className="mr-2 h-4 w-4" />}
            {isUsing ? 'Creating…' : `Use in ${destinationLabel}`}
          </Button>
          <Button
            size="sm"
            type="button"
            variant="outline"
            className="h-10 rounded-xl border-2 border-border/80 px-4 font-semibold"
            onClick={(e) => {
              e.stopPropagation();
              onTestTemplate?.();
            }}
          >
            <Icons.eye className="mr-2 h-4 w-4" />
            Preview
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default function TemplatesPage() {
  const [backendTemplates, setBackendTemplates] = useState([]);
  const [frontendTemplates, setFrontendTemplates] = useState([]);
  const [usingTemplateId, setUsingTemplateId] = useState(null);
  const [deletingTemplateId, setDeletingTemplateId] = useState(null);
  const [kindFilter, setKindFilter] = useState('all');
  const [templateCategory, setTemplateCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const currentWorkspaceId = useWorkspaceStore((s) => s.currentWorkspaceId);
  const user = useUserStore((s) => s.user);

  const setKindAndResetCategories = (id) => {
    setKindFilter(id);
    setTemplateCategory('all');
  };

  const loadTemplates = useCallback(async () => {
    if (!canUseAuthenticatedRequests(user)) {
      setBackendTemplates([]);
      setFrontendTemplates([]);
      return;
    }

    try {
      const { apiRequest } = await import('../../lib/api-client');
      const wantFe = kindFilter === 'all' || kindFilter === 'frontend';
      const wantBe = kindFilter === 'all' || kindFilter === 'backend';
      const limitFe = kindFilter === 'all' ? FETCH_LIMIT.all : FETCH_LIMIT.single;
      const limitBe = kindFilter === 'all' ? FETCH_LIMIT.all : FETCH_LIMIT.single;

      let fe = [];
      let be = [];

      if (wantFe && wantBe) {
        const [backendData, frontendData] = await Promise.all([
          apiRequest(`/templates/top?project_type=backend&limit=${limitBe}`, {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          }),
          apiRequest(`/templates/top?project_type=frontend&limit=${limitFe}`, {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          }),
        ]);
        be = backendData || [];
        fe = frontendData || [];
      } else if (wantFe) {
        fe =
          (await apiRequest(`/templates/top?project_type=frontend&limit=${limitFe}`, {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          })) || [];
      } else if (wantBe) {
        be =
          (await apiRequest(`/templates/top?project_type=backend&limit=${limitBe}`, {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          })) || [];
      }

      setFrontendTemplates(wantFe ? fe : []);
      setBackendTemplates(wantBe ? be : []);
    } catch (e) {
      console.error('Failed to load templates', e);
    }
  }, [user, kindFilter]);

  useEffect(() => {
    void loadTemplates();
  }, [loadTemplates]);

  const templatesInScope = useMemo(() => {
    if (kindFilter === 'all') return [...frontendTemplates, ...backendTemplates];
    if (kindFilter === 'frontend') return frontendTemplates;
    return backendTemplates;
  }, [kindFilter, frontendTemplates, backendTemplates]);

  const categoryOptions = useMemo(
    () => categoryOptionsFromTemplates(templatesInScope),
    [templatesInScope]
  );

  const visibleTemplates = useMemo(() => {
    let list = filterByCategory(templatesInScope, templateCategory);
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      list = list.filter((t) => {
        const name = String(t.name || '').toLowerCase();
        const desc = String(t.description || '').toLowerCase();
        const cat = String(t.category || '').toLowerCase();
        return name.includes(q) || desc.includes(q) || cat.includes(q);
      });
    }
    return list;
  }, [templatesInScope, templateCategory, searchQuery]);

  const handleUseTemplate = async (tpl) => {
    if (!tpl.id) return;
    setUsingTemplateId(tpl.id);
    try {
      const { apiRequest } = await import('../../lib/api-client');
      const body = currentWorkspaceId ? { workspace_id: currentWorkspaceId } : {};
      const newProject = await apiRequest(`/templates/${tpl.id}/use`, {
        method: 'POST',
        body,
      });
      if (newProject?.id) {
        if (newProject.project_type === 'backend') {
          navigate(`/aiagent/${newProject.id}`, { state: { fromTemplate: true } });
        } else {
          navigate(`/chatflow/${newProject.id}`, { state: { fromTemplate: true } });
        }
        toast({ title: 'Project created', description: `"${newProject.name || 'Template'}" was created from the template.` });
      }
    } catch (e) {
      console.error('Failed to use template', e);
      toast({
        title: 'Could not use template',
        description: e?.message || 'Something went wrong. Try again.',
        variant: 'destructive',
      });
    } finally {
      setUsingTemplateId(null);
    }
  };

  const handlePreviewTemplate = (tpl) => {
    if (!tpl?.id) return;
    navigate(`/templates/${tpl.id}/canvas`, { state: { template: tpl } });
  };

  const handleRateTemplate = async (tpl, rating) => {
    try {
      const { apiRequest } = await import('../../lib/api-client');
      const updated = await apiRequest(`/templates/${tpl.id}/rate`, {
        method: 'POST',
        body: { rating },
        includeAuth: true,
        showErrorToast: false,
      });
      const updateList = (list) =>
        list.map((t) => (t.id === tpl.id ? { ...t, ...updated } : t));
      setBackendTemplates((prev) => updateList(prev));
      setFrontendTemplates((prev) => updateList(prev));
    } catch (e) {
      console.error('Failed to rate template', e);
    }
  };

  const handleDeleteTemplate = async (tpl) => {
    if (!tpl?.id) return;

    const shouldDelete = window.confirm(
      `Delete template "${tpl.name}"? This cannot be undone.`
    );
    if (!shouldDelete) return;

    setDeletingTemplateId(tpl.id);
    try {
      const { apiRequest } = await import('../../lib/api-client');
      await apiRequest(`/templates/${tpl.id}`, {
        method: 'DELETE',
      });

      setBackendTemplates((prev) => prev.filter((template) => template.id !== tpl.id));
      setFrontendTemplates((prev) => prev.filter((template) => template.id !== tpl.id));
      toast({
        title: 'Template deleted',
        description: `"${tpl.name}" has been removed.`,
      });
    } catch (e) {
      console.error('Failed to delete template', e);
      toast({
        title: 'Could not delete template',
        description: e?.message || 'Something went wrong. Try again.',
        variant: 'destructive',
      });
    } finally {
      setDeletingTemplateId(null);
    }
  };

  const renderGrid = (templates) => {
    if (!templates || templates.length === 0) {
      return (
        <Card className="overflow-hidden rounded-2xl border border-dashed border-border/60 bg-gradient-to-b from-muted/25 to-muted/5 shadow-inner">
          <div className="flex flex-col items-center justify-center gap-4 px-8 py-20 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted/60 ring-1 ring-border/50">
              <Icons.package className="h-7 w-7 text-muted-foreground/50" />
            </div>
            <div className="space-y-1.5">
              <p className="text-base font-semibold text-foreground">No templates match</p>
              <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
                Try another category, adjust your search, or switch template type. Published templates from your workspace will show up here.
              </p>
            </div>
          </div>
        </Card>
      );
    }

    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
        {templates.map((tpl) => (
          <TemplateCard
            key={tpl.id}
            template={tpl}
            onUseTemplate={({ mode }) => {
              if (mode === 'use') return handleUseTemplate(tpl);
              return handlePreviewTemplate(tpl);
            }}
            onTestTemplate={() => handlePreviewTemplate(tpl)}
            onRate={(rating) => handleRateTemplate(tpl, rating)}
            onDelete={() => handleDeleteTemplate(tpl)}
            isUsing={usingTemplateId === tpl.id}
            isDeleting={deletingTemplateId === tpl.id}
            canDelete={Boolean(tpl.can_delete)}
          />
        ))}
      </div>
    );
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-8 pb-16">
        <div className="border-b border-border/40 pb-8">
          <PageHeader
            className="items-start"
            icon={Icons.package}
            title="Templates"
            description="Published Chat Flow and AI Agent starters for your workspace. Pick a type, narrow by category, then preview or use a template."
          />
        </div>

        <div className="flex flex-col gap-8 lg:flex-row lg:items-start">
          <aside className="w-full shrink-0 space-y-8 lg:w-52 xl:w-56">
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Template type</p>
              <ul className="space-y-0.5">
                {TEMPLATE_TYPE_OPTIONS.map((opt) => {
                  const active = kindFilter === opt.id;
                  return (
                    <li key={opt.id}>
                      <button
                        type="button"
                        onClick={() => setKindAndResetCategories(opt.id)}
                        className={cn(
                          'w-full rounded-md px-2 py-2 text-left text-sm transition',
                          active
                            ? 'bg-primary/10 font-semibold text-primary'
                            : 'text-muted-foreground hover:bg-muted/60 hover:text-foreground'
                        )}
                      >
                        {opt.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
            {categoryOptions.length > 1 ? (
              <div className="space-y-2">
                <Label
                  htmlFor="journeys-template-category"
                  className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
                >
                  Category
                </Label>
                <Select value={templateCategory} onValueChange={setTemplateCategory}>
                  <SelectTrigger
                    id="journeys-template-category"
                    className="h-10 w-full rounded-lg border-border/60 bg-background text-left text-sm font-medium shadow-sm"
                  >
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl border-border/60 shadow-lg">
                    {categoryOptions.map((opt) => (
                      <SelectItem key={opt.id} value={opt.id} className="rounded-lg py-2.5">
                        <span className="flex items-center gap-2.5">
                          {opt.id === 'all' ? (
                            <span
                              className="h-2 w-2 shrink-0 rounded-full bg-muted-foreground/35 ring-2 ring-muted-foreground/10"
                              aria-hidden
                            />
                          ) : (
                            <span
                              className={cn(
                                'h-2 w-2 shrink-0 rounded-full ring-2 ring-black/5 dark:ring-white/15',
                                CATEGORY_DOT_BG[categoryStyleIndex(opt.id)]
                              )}
                              aria-hidden
                            />
                          )}
                          <span>{opt.label}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}
          </aside>

          <div className="min-w-0 flex-1 space-y-5">
            <div className="relative">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search templates"
                className="h-11 rounded-lg border-border/60 bg-background pr-10 text-sm shadow-sm"
                aria-label="Search templates"
              />
              <Icons.search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">
              {visibleTemplates.length} {visibleTemplates.length === 1 ? 'template' : 'templates'}
              {searchQuery.trim() ? ` matching “${searchQuery.trim()}”` : ''}
            </p>
            {renderGrid(visibleTemplates)}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
