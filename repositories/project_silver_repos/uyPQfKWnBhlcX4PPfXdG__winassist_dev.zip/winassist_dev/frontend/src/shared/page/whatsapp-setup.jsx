import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Label } from '../../components/ui/label';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Icons } from '../../components/ui/icons';
import { apiRequest } from '../../lib/api-client';
import { getWhatsAppMetaConnectUrl, isWhatsAppEmbeddedSignupEnabled } from '../../lib/config';
import { useToast } from '../../hooks/toast';
import { useWorkspaces } from '../../hooks/workspace';

const DEFAULT_GRAPH_VERSION = 'v23.0';
const META_CONNECT_URL = getWhatsAppMetaConnectUrl();
const EMBEDDED_SIGNUP_ENABLED = isWhatsAppEmbeddedSignupEnabled();

const STEPS = [
  { id: 'method', label: 'Choose method' },
  { id: 'access', label: 'Connect account' },
  { id: 'waba', label: 'Select WABA' },
  { id: 'phone', label: 'Select phone' },
  { id: 'bot', label: 'Link bot' },
  { id: 'test', label: 'Send test' },
  { id: 'done', label: 'Finish' },
];

const STATUS_BADGE_MAP = {
  active: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  healthy: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  receiving: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  success: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  sent: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  delivered: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  read: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  processed: { variant: 'default', className: 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent' },
  draft: { variant: 'secondary', className: '' },
  pending: { variant: 'secondary', className: '' },
  failed: { variant: 'destructive', className: '' },
  rejected: { variant: 'destructive', className: '' },
  undelivered: { variant: 'destructive', className: '' },
  disabled: { variant: 'destructive', className: '' },
  paused: { variant: 'outline', className: '' },
  unknown: { variant: 'outline', className: '' },
  never: { variant: 'outline', className: '' },
  error: { variant: 'destructive', className: '' },
};

function getStatusBadge(status) {
  return STATUS_BADGE_MAP[String(status || '').toLowerCase()] || { variant: 'outline', className: '' };
}

function normalizeConnection(connection) {
  if (!connection || typeof connection !== 'object') return null;
  return {
    id: connection.id,
    name: connection.name || connection.display_phone_number || 'WhatsApp connection',
    display_phone_number: connection.display_phone_number || connection.business_phone_number || 'Not available',
    connection_status: connection.connection_status || 'unknown',
    webhook_status: connection.webhook_status || 'unknown',
    health_status: connection.health_status || 'unknown',
    last_sync_status: connection.last_sync_status || 'unknown',
    subscribed_app_status: connection.subscribed_app_status || 'unknown',
    access_token_masked: connection.access_token_masked || null,
    meta_business_account_id: connection.meta_business_account_id || '',
    waba_id: connection.waba_id || '',
    phone_number_id: connection.phone_number_id || '',
    business_phone_number: connection.business_phone_number || '',
    bot_project_id: connection.bot_project_id || '',
    project_id: connection.project_id || '',
    last_validation_error: connection.last_validation_error || '',
    metadata: connection.metadata && typeof connection.metadata === 'object' ? connection.metadata : {},
    created_at: connection.created_at || null,
    updated_at: connection.updated_at || null,
  };
}

function normalizeMessageLog(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    id: item.id,
    connection_id: item.connection_id || '',
    direction: item.direction || 'unknown',
    status: item.status || 'unknown',
    message_type: item.message_type || 'unknown',
    from_number: item.from_number || '',
    to_number: item.to_number || '',
    payload: item.payload && typeof item.payload === 'object' ? item.payload : {},
    response: item.response && typeof item.response === 'object' ? item.response : {},
    error: item.error || '',
    created_at: item.created_at || '',
  };
}

function summarizeMessageLog(item) {
  const payload = item?.payload || {};
  if (item?.message_type === 'text') {
    return payload?.text?.body || payload?.message || payload?.text || 'Text message';
  }
  if (item?.message_type === 'template') {
    return payload?.template_name || payload?.template?.name || 'Template message';
  }
  if (item?.message_type === 'flow') {
    return payload?.flow_id ? `Flow: ${payload.flow_id}` : 'Flow message';
  }
  if (item?.message_type === 'interactive') {
    return payload?.interactive?.body?.text || 'Interactive message';
  }
  if (['image', 'document', 'audio', 'video', 'sticker'].includes(item?.message_type)) {
    return payload?.caption || payload?.media_link || payload?.media_id || `${item.message_type} message`;
  }
  return payload?.message || payload?.status || `${item?.message_type || 'WhatsApp'} event`;
}

function normalizeTemplate(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    id: item.id,
    connection_id: item.connection_id || '',
    meta_template_id: item.meta_template_id || '',
    name: item.name || 'Untitled template',
    language: item.language || 'en_US',
    category: item.category || 'UTILITY',
    status: item.status || 'draft',
    components: Array.isArray(item.components) ? item.components : [],
    updated_at: item.updated_at || item.created_at || '',
  };
}

function normalizeFlow(item) {
  if (!item || typeof item !== 'object') return null;
  const rawData = item.raw_data && typeof item.raw_data === 'object' ? item.raw_data : {};
  return {
    id: item.id,
    connection_id: item.connection_id || '',
    meta_flow_id: item.meta_flow_id || '',
    name: item.name || 'Untitled flow',
    status: item.status || 'draft',
    categories: Array.isArray(item.categories) ? item.categories : [],
    raw_data: rawData,
    endpoint_uri: rawData.endpoint_uri || rawData.data_channel_uri || rawData.data_api_endpoint || '',
    updated_at: item.updated_at || item.created_at || '',
  };
}

function normalizeFlowRuntimeStatus(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    flow_id: item.flow_id || '',
    connection_id: item.connection_id || '',
    phone_number_id: item.phone_number_id || '',
    callback_url: item.callback_url || '',
    public_key: item.public_key || '',
    public_key_fingerprint: item.public_key_fingerprint || '',
    key_generated_at: item.key_generated_at || '',
    meta_signature_status: item.meta_signature_status || '',
    meta_public_key: item.meta_public_key || '',
    metadata: item.metadata && typeof item.metadata === 'object' ? item.metadata : {},
  };
}

function normalizeFlowRuntimeEvent(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    id: item.id,
    flow_id: item.flow_id || '',
    connection_id: item.connection_id || '',
    event_type: item.event_type || 'flow_runtime_callback',
    processed: Boolean(item.processed),
    payload: item.payload && typeof item.payload === 'object' ? item.payload : {},
    headers: item.headers && typeof item.headers === 'object' ? item.headers : {},
    created_at: item.created_at || '',
  };
}

function normalizeWebhookEvent(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    id: item.id,
    connection_id: item.connection_id || '',
    event_type: item.event_type || 'unknown',
    payload: item.payload && typeof item.payload === 'object' ? item.payload : {},
    headers: item.headers && typeof item.headers === 'object' ? item.headers : {},
    processed: Boolean(item.processed),
    created_at: item.created_at || '',
  };
}

function normalizeDashboard(item) {
  if (!item || typeof item !== 'object') return null;
  return {
    connection_id: item.connection_id || '',
    generated_at: item.generated_at || '',
    connection_health: item.connection_health && typeof item.connection_health === 'object' ? item.connection_health : {},
    message_totals: item.message_totals && typeof item.message_totals === 'object' ? item.message_totals : {},
    webhook_totals: item.webhook_totals && typeof item.webhook_totals === 'object' ? item.webhook_totals : {},
    daily_counts: Array.isArray(item.daily_counts) ? item.daily_counts : [],
    failure_reasons: Array.isArray(item.failure_reasons) ? item.failure_reasons : [],
    template_statuses: Array.isArray(item.template_statuses) ? item.template_statuses : [],
    rejected_templates: Array.isArray(item.rejected_templates) ? item.rejected_templates : [],
    flow_statuses: Array.isArray(item.flow_statuses) ? item.flow_statuses : [],
    flow_activity: Array.isArray(item.flow_activity) ? item.flow_activity : [],
    pending_retries: Number(item.pending_retries || 0),
  };
}

function getFlowRuntimeActionLabel(event) {
  const payload = event?.payload?.decrypted_payload || {};
  return payload?.action || payload?.screen || event?.event_type || 'runtime';
}

function formatJsonPreview(value, fallback = 'No data yet') {
  if (!value || (typeof value === 'object' && Object.keys(value).length === 0)) return fallback;
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

function summarizeWebhookEvent(event) {
  if (event?.event_type === 'messages') return 'Inbound WhatsApp message webhook';
  if (event?.event_type === 'statuses') return 'Delivery status webhook';
  if (event?.event_type === 'flow_runtime_callback') return 'Dynamic flow runtime callback';
  return event?.event_type || 'Webhook event';
}

function getFlowPreviewUrl(flow) {
  const previewData = flow?.raw_data?.preview_data;
  if (previewData?.preview?.preview_url) return previewData.preview.preview_url;
  if (previewData?.preview_url) return previewData.preview_url;
  return '';
}

function getFlowJsonText(flow) {
  return String(flow?.raw_data?.local_flow_json || '').trim();
}

function getStarterFlowJson() {
  return JSON.stringify(
    {
      version: '7.1',
      screens: [
        {
          id: 'WELCOME',
          title: 'Welcome',
          terminal: true,
          layout: {
            type: 'SingleColumnLayout',
            children: [
              {
                type: 'TextHeading',
                text: 'Welcome to WinAssist',
              },
              {
                type: 'TextBody',
                text: 'This is a starter WhatsApp Flow JSON file. Replace it with your own screens and actions.',
              },
            ],
          },
        },
      ],
    },
    null,
    2,
  );
}

function parseMultilineValues(value) {
  return String(value || '')
    .split('\n')
    .map((item) => item.trim())
    .filter(Boolean);
}

function buildTemplateComponents(formState) {
  const components = [];

  if (formState.header_text.trim()) {
    components.push({
      type: 'HEADER',
      format: 'TEXT',
      text: formState.header_text.trim(),
    });
  }

  if (formState.body_text.trim()) {
    const bodyExamples = parseMultilineValues(formState.body_examples);
    const bodyComponent = {
      type: 'BODY',
      text: formState.body_text.trim(),
    };
    if (bodyExamples.length > 0) {
      bodyComponent.example = {
        body_text: [bodyExamples],
      };
    }
    components.push(bodyComponent);
  }

  if (formState.footer_text.trim()) {
    components.push({
      type: 'FOOTER',
      text: formState.footer_text.trim(),
    });
  }

  return components;
}

function buildSendTemplateComponents(variableValues) {
  const values = parseMultilineValues(variableValues);
  if (values.length === 0) return [];
  return [
    {
      type: 'body',
      parameters: values.map((value) => ({
        type: 'text',
        text: value,
      })),
    },
  ];
}

function countBodyPlaceholders(template) {
  const bodyComponent = (template?.components || []).find((component) => String(component?.type || '').toUpperCase() === 'BODY');
  const text = String(bodyComponent?.text || '');
  const matches = text.match(/\{\{\d+\}\}/g);
  return matches ? matches.length : 0;
}

function formatLogTime(value) {
  if (!value) return 'Unknown time';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function buildConnectionPayload(formState, workspaceId) {
  return {
    name: formState.name.trim() || undefined,
    workspace_id: workspaceId || undefined,
    project_id: formState.project_id || undefined,
    bot_project_id: formState.bot_project_id || undefined,
    graph_version: formState.graph_version.trim() || DEFAULT_GRAPH_VERSION,
    meta_business_account_id: formState.meta_business_account_id.trim() || undefined,
    waba_id: formState.waba_id.trim(),
    phone_number_id: formState.phone_number_id.trim(),
    business_phone_number: formState.business_phone_number.trim() || undefined,
    display_phone_number: formState.display_phone_number.trim() || undefined,
    access_token: formState.access_token.trim(),
    metadata: {
      onboarding_source: 'whatsapp_setup_wizard',
      connection_method: formState.connection_method,
    },
  };
}

export default function WhatsAppSetupPage() {
  const { toast } = useToast();
  const { workspaces, currentWorkspace, currentWorkspaceId, fetchWorkspaces } = useWorkspaces();

  const [activeStep, setActiveStep] = useState(0);
  const [connections, setConnections] = useState([]);
  const [connectionsLoading, setConnectionsLoading] = useState(false);
  const [backendProjects, setBackendProjects] = useState([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [messageLogs, setMessageLogs] = useState([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messageActionId, setMessageActionId] = useState('');
  const [selectedLogConnectionId, setSelectedLogConnectionId] = useState('');
  const [channelDashboard, setChannelDashboard] = useState(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [webhookEvents, setWebhookEvents] = useState([]);
  const [webhookEventsLoading, setWebhookEventsLoading] = useState(false);
  const [templates, setTemplates] = useState([]);
  const [templatesLoading, setTemplatesLoading] = useState(false);
  const [selectedTemplateConnectionId, setSelectedTemplateConnectionId] = useState('');
  const [templateActionId, setTemplateActionId] = useState('');
  const [creatingTemplate, setCreatingTemplate] = useState(false);
  const [sendingTemplate, setSendingTemplate] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [flows, setFlows] = useState([]);
  const [flowsLoading, setFlowsLoading] = useState(false);
  const [selectedFlowConnectionId, setSelectedFlowConnectionId] = useState('');
  const [flowActionId, setFlowActionId] = useState('');
  const [creatingFlow, setCreatingFlow] = useState(false);
  const [sendingFlow, setSendingFlow] = useState(false);
  const [selectedFlowId, setSelectedFlowId] = useState('');
  const [flowRuntimeStatus, setFlowRuntimeStatus] = useState(null);
  const [flowRuntimeEvents, setFlowRuntimeEvents] = useState([]);
  const [flowRuntimeEventsLoading, setFlowRuntimeEventsLoading] = useState(false);
  const [flowRuntimeActionId, setFlowRuntimeActionId] = useState('');
  const [flowRuntimeReplayResult, setFlowRuntimeReplayResult] = useState(null);
  const [discoveringWabas, setDiscoveringWabas] = useState(false);
  const [discoveringPhones, setDiscoveringPhones] = useState(false);
  const [creatingConnection, setCreatingConnection] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);
  const [connectionActionId, setConnectionActionId] = useState('');
  const [createdConnection, setCreatedConnection] = useState(null);
  const [validationResult, setValidationResult] = useState(null);
  const [validationError, setValidationError] = useState('');
  const [testResponse, setTestResponse] = useState(null);
  const [wabaOptions, setWabaOptions] = useState([]);
  const [phoneOptions, setPhoneOptions] = useState([]);
  const [form, setForm] = useState({
    connection_method: 'manual',
    workspace_id: '',
    name: '',
    graph_version: DEFAULT_GRAPH_VERSION,
    meta_business_account_id: '',
    access_token: '',
    waba_id: '',
    phone_number_id: '',
    business_phone_number: '',
    display_phone_number: '',
    bot_project_id: '',
    project_id: '',
    test_to: '',
    test_message: 'Hello from WinAssist. Your WhatsApp channel is now connected.',
  });
  const [templateForm, setTemplateForm] = useState({
    name: '',
    category: 'UTILITY',
    language: 'en_US',
    header_text: '',
    body_text: '',
    body_examples: '',
    footer_text: '',
    publish_mode: 'submit',
  });
  const [templateSendForm, setTemplateSendForm] = useState({
    to: '',
    language_code: '',
    variable_values: '',
  });
  const [flowForm, setFlowForm] = useState({
    name: '',
    categories: 'OTHER',
    endpoint_uri: '',
    clone_flow_id: '',
    flow_json: getStarterFlowJson(),
  });
  const [flowSendForm, setFlowSendForm] = useState({
    to: '',
    body_text: 'Tap below to open this WhatsApp Flow.',
    header_text: '',
    footer_text: '',
    flow_cta: 'Open flow',
    flow_token: '',
  });
  const [flowRuntimeForm, setFlowRuntimeForm] = useState({
    endpoint_uri: '',
  });

  useEffect(() => {
    fetchWorkspaces({ force: false });
  }, [fetchWorkspaces]);

  useEffect(() => {
    if (!form.workspace_id && currentWorkspaceId) {
      setForm((prev) => ({ ...prev, workspace_id: currentWorkspaceId }));
    }
  }, [currentWorkspaceId, form.workspace_id]);

  const selectedWorkspaceId = form.workspace_id || currentWorkspaceId || '';

  const selectedWorkspace = useMemo(() => {
    if (!selectedWorkspaceId) return currentWorkspace || null;
    return workspaces.find((workspace) => workspace.id === selectedWorkspaceId) || currentWorkspace || null;
  }, [currentWorkspace, selectedWorkspaceId, workspaces]);

  const selectedBotProjectName = useMemo(
    () => backendProjects.find((project) => project.id === form.bot_project_id)?.name || '',
    [backendProjects, form.bot_project_id],
  );
  const selectedTemplate = useMemo(
    () => templates.find((template) => template.id === selectedTemplateId) || null,
    [selectedTemplateId, templates],
  );
  const selectedFlow = useMemo(
    () => flows.find((flow) => flow.id === selectedFlowId) || null,
    [flows, selectedFlowId],
  );

  const refreshConnections = useCallback(async (workspaceId = selectedWorkspaceId) => {
    setConnectionsLoading(true);
    try {
      const query = workspaceId
        ? `/whatsapp/connections?workspace_id=${encodeURIComponent(workspaceId)}`
        : '/whatsapp/connections';
      const data = await apiRequest(query, { method: 'GET', showErrorToast: false });
      setConnections(Array.isArray(data) ? data.map(normalizeConnection).filter(Boolean) : []);
    } catch {
      setConnections([]);
    } finally {
      setConnectionsLoading(false);
    }
  }, [selectedWorkspaceId]);

  useEffect(() => {
    refreshConnections(selectedWorkspaceId);
  }, [refreshConnections, selectedWorkspaceId]);

  useEffect(() => {
    if (!connections.length) {
      setSelectedLogConnectionId('');
      setSelectedTemplateConnectionId('');
      setSelectedFlowConnectionId('');
      return;
    }
    const exists = connections.some((connection) => connection.id === selectedLogConnectionId);
    if (!exists) {
      setSelectedLogConnectionId(connections[0].id);
    }
    const hasTemplateConnection = connections.some((connection) => connection.id === selectedTemplateConnectionId);
    if (!hasTemplateConnection) {
      setSelectedTemplateConnectionId(connections[0].id);
    }
    const hasFlowConnection = connections.some((connection) => connection.id === selectedFlowConnectionId);
    if (!hasFlowConnection) {
      setSelectedFlowConnectionId(connections[0].id);
    }
  }, [connections, selectedFlowConnectionId, selectedLogConnectionId, selectedTemplateConnectionId]);

  useEffect(() => {
    let cancelled = false;

    const loadBackendProjects = async () => {
      setProjectsLoading(true);
      try {
        const params = new URLSearchParams({ project_type: 'backend' });
        if (selectedWorkspaceId) params.set('workspace_id', selectedWorkspaceId);
        const data = await apiRequest(`/projects?${params.toString()}`, {
          method: 'GET',
          showErrorToast: false,
        });
        if (!cancelled) setBackendProjects(Array.isArray(data) ? data : []);
      } catch {
        if (!cancelled) setBackendProjects([]);
      } finally {
        if (!cancelled) setProjectsLoading(false);
      }
    };

    loadBackendProjects();
    return () => {
      cancelled = true;
    };
  }, [selectedWorkspaceId]);

  const refreshMessageLogs = useCallback(async (connectionId = selectedLogConnectionId) => {
    if (!connectionId) {
      setMessageLogs([]);
      return;
    }
    setMessagesLoading(true);
    try {
      const params = new URLSearchParams({
        connection_id: connectionId,
        limit: '25',
      });
      const data = await apiRequest(`/whatsapp/messages?${params.toString()}`, {
        method: 'GET',
        showErrorToast: false,
      });
      setMessageLogs(Array.isArray(data) ? data.map(normalizeMessageLog).filter(Boolean) : []);
    } catch {
      setMessageLogs([]);
    } finally {
      setMessagesLoading(false);
    }
  }, [selectedLogConnectionId]);

  useEffect(() => {
    refreshMessageLogs(selectedLogConnectionId);
  }, [refreshMessageLogs, selectedLogConnectionId]);

  const refreshChannelDashboard = useCallback(async (connectionId = selectedLogConnectionId) => {
    if (!connectionId) {
      setChannelDashboard(null);
      return null;
    }
    setDashboardLoading(true);
    try {
      const params = new URLSearchParams({
        connection_id: connectionId,
        days: '7',
      });
      const data = await apiRequest(`/whatsapp/dashboard?${params.toString()}`, {
        method: 'GET',
        showErrorToast: false,
      });
      const normalized = normalizeDashboard(data);
      setChannelDashboard(normalized);
      return normalized;
    } catch {
      setChannelDashboard(null);
      return null;
    } finally {
      setDashboardLoading(false);
    }
  }, [selectedLogConnectionId]);

  useEffect(() => {
    refreshChannelDashboard(selectedLogConnectionId);
  }, [refreshChannelDashboard, selectedLogConnectionId]);

  const refreshWebhookEvents = useCallback(async (connectionId = selectedLogConnectionId) => {
    if (!connectionId) {
      setWebhookEvents([]);
      return [];
    }
    setWebhookEventsLoading(true);
    try {
      const params = new URLSearchParams({
        connection_id: connectionId,
        limit: '20',
      });
      const data = await apiRequest(`/whatsapp/webhook-events?${params.toString()}`, {
        method: 'GET',
        showErrorToast: false,
      });
      const normalized = Array.isArray(data) ? data.map(normalizeWebhookEvent).filter(Boolean) : [];
      setWebhookEvents(normalized);
      return normalized;
    } catch {
      setWebhookEvents([]);
      return [];
    } finally {
      setWebhookEventsLoading(false);
    }
  }, [selectedLogConnectionId]);

  useEffect(() => {
    refreshWebhookEvents(selectedLogConnectionId);
  }, [refreshWebhookEvents, selectedLogConnectionId]);

  const refreshTemplates = useCallback(async (connectionId = selectedTemplateConnectionId) => {
    if (!connectionId) {
      setTemplates([]);
      return;
    }
    setTemplatesLoading(true);
    try {
      const params = new URLSearchParams({ connection_id: connectionId });
      const data = await apiRequest(`/whatsapp/templates?${params.toString()}`, {
        method: 'GET',
        showErrorToast: false,
      });
      setTemplates(Array.isArray(data) ? data.map(normalizeTemplate).filter(Boolean) : []);
    } catch {
      setTemplates([]);
    } finally {
      setTemplatesLoading(false);
    }
  }, [selectedTemplateConnectionId]);

  useEffect(() => {
    refreshTemplates(selectedTemplateConnectionId);
  }, [refreshTemplates, selectedTemplateConnectionId]);

  const refreshFlows = useCallback(async (connectionId = selectedFlowConnectionId) => {
    if (!connectionId) {
      setFlows([]);
      return;
    }
    setFlowsLoading(true);
    try {
      const params = new URLSearchParams({ connection_id: connectionId });
      const data = await apiRequest(`/whatsapp/flows?${params.toString()}`, {
        method: 'GET',
        showErrorToast: false,
      });
      setFlows(Array.isArray(data) ? data.map(normalizeFlow).filter(Boolean) : []);
    } catch {
      setFlows([]);
    } finally {
      setFlowsLoading(false);
    }
  }, [selectedFlowConnectionId]);

  useEffect(() => {
    refreshFlows(selectedFlowConnectionId);
  }, [refreshFlows, selectedFlowConnectionId]);

  const refreshFlowRuntimeStatus = useCallback(async (flowId = selectedFlowId) => {
    if (!flowId) {
      setFlowRuntimeStatus(null);
      return null;
    }
    try {
      const data = await apiRequest(`/whatsapp/flows/${flowId}/public-key`, {
        method: 'GET',
        showErrorToast: false,
      });
      const normalized = normalizeFlowRuntimeStatus(data);
      setFlowRuntimeStatus(normalized);
      if (normalized?.callback_url) {
        setFlowRuntimeForm((prev) => ({
          ...prev,
          endpoint_uri: prev.endpoint_uri || normalized.callback_url,
        }));
      }
      return normalized;
    } catch {
      setFlowRuntimeStatus(null);
      return null;
    }
  }, [selectedFlowId]);

  const refreshFlowRuntimeEvents = useCallback(async (flowId = selectedFlowId) => {
    if (!flowId) {
      setFlowRuntimeEvents([]);
      return [];
    }
    setFlowRuntimeEventsLoading(true);
    try {
      const data = await apiRequest(`/whatsapp/flows/${flowId}/runtime-events?limit=15`, {
        method: 'GET',
        showErrorToast: false,
      });
      const normalized = Array.isArray(data) ? data.map(normalizeFlowRuntimeEvent).filter(Boolean) : [];
      setFlowRuntimeEvents(normalized);
      return normalized;
    } catch {
      setFlowRuntimeEvents([]);
      return [];
    } finally {
      setFlowRuntimeEventsLoading(false);
    }
  }, [selectedFlowId]);

  useEffect(() => {
    if (!templates.length) {
      setSelectedTemplateId('');
      return;
    }
    const exists = templates.some((template) => template.id === selectedTemplateId);
    if (!exists) {
      setSelectedTemplateId(templates[0].id);
      setTemplateSendForm((prev) => ({
        ...prev,
        language_code: templates[0].language || 'en_US',
      }));
    }
  }, [selectedTemplateId, templates]);

  useEffect(() => {
    if (!flows.length) {
      setSelectedFlowId('');
      setFlowRuntimeStatus(null);
      setFlowRuntimeEvents([]);
      setFlowRuntimeReplayResult(null);
      return;
    }
    const exists = flows.some((flow) => flow.id === selectedFlowId);
    if (!exists) {
      setSelectedFlowId(flows[0].id);
    }
  }, [flows, selectedFlowId]);

  useEffect(() => {
    setFlowRuntimeForm((prev) => ({
      ...prev,
      endpoint_uri: selectedFlow?.endpoint_uri || selectedFlow?.raw_data?.runtime_callback_url || '',
    }));
    setFlowRuntimeReplayResult(null);
  }, [selectedFlow]);

  useEffect(() => {
    refreshFlowRuntimeStatus(selectedFlowId);
    refreshFlowRuntimeEvents(selectedFlowId);
  }, [refreshFlowRuntimeEvents, refreshFlowRuntimeStatus, selectedFlowId]);

  const updateForm = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateTemplateForm = (key, value) => {
    setTemplateForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateTemplateSendForm = (key, value) => {
    setTemplateSendForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateFlowForm = (key, value) => {
    setFlowForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateFlowSendForm = (key, value) => {
    setFlowSendForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateFlowRuntimeForm = (key, value) => {
    setFlowRuntimeForm((prev) => ({ ...prev, [key]: value }));
  };

  const resetRuntimeState = () => {
    setCreatedConnection(null);
    setValidationResult(null);
    setValidationError('');
    setTestResponse(null);
  };

  const resetWizard = () => {
    setActiveStep(0);
    setWabaOptions([]);
    setPhoneOptions([]);
    resetRuntimeState();
  };

  const canGoNext = useMemo(() => {
    if (activeStep === 0) return Boolean(form.connection_method);
    if (activeStep === 1) {
      return Boolean(selectedWorkspaceId && form.access_token.trim());
    }
    if (activeStep === 2) {
      return Boolean(form.waba_id.trim());
    }
    if (activeStep === 3) {
      return Boolean(form.phone_number_id.trim() && form.business_phone_number.trim());
    }
    if (activeStep === 4) {
      return Boolean(form.bot_project_id);
    }
    if (activeStep === 5) {
      return Boolean(testResponse);
    }
    return true;
  }, [
    activeStep,
    form.access_token,
    form.bot_project_id,
    form.business_phone_number,
    form.connection_method,
    form.phone_number_id,
    form.waba_id,
    selectedWorkspaceId,
    testResponse,
  ]);

  const discoverWabas = async () => {
    if (!form.access_token.trim() || !form.meta_business_account_id.trim()) {
      toast({
        title: 'Business account required',
        description: 'Enter the Meta business account ID and access token first.',
        variant: 'destructive',
      });
      return;
    }
    setDiscoveringWabas(true);
    try {
      const response = await apiRequest('/whatsapp/discover-assets', {
        method: 'POST',
        body: {
          provider: 'meta_cloud',
          graph_version: form.graph_version.trim() || DEFAULT_GRAPH_VERSION,
          meta_business_account_id: form.meta_business_account_id.trim(),
          access_token: form.access_token.trim(),
        },
      });
      const discoveredWabas = Array.isArray(response?.wabas) ? response.wabas : [];
      setWabaOptions(discoveredWabas);
      if (!form.waba_id && discoveredWabas[0]?.id) {
        updateForm('waba_id', String(discoveredWabas[0].id));
      }
      toast({
        title: 'WABAs loaded',
        description: discoveredWabas.length > 0 ? `Found ${discoveredWabas.length} WhatsApp business account(s).` : 'No WABAs were returned for this business account.',
      });
    } catch (error) {
      toast({
        title: 'Failed to load WABAs',
        description: error.message || 'Please verify the access token and Meta business account ID.',
        variant: 'destructive',
      });
    } finally {
      setDiscoveringWabas(false);
    }
  };

  const discoverPhoneNumbers = async () => {
    if (!form.access_token.trim() || !form.waba_id.trim()) {
      toast({
        title: 'WABA required',
        description: 'Select or enter the WABA first.',
        variant: 'destructive',
      });
      return;
    }
    setDiscoveringPhones(true);
    try {
      const response = await apiRequest('/whatsapp/discover-assets', {
        method: 'POST',
        body: {
          provider: 'meta_cloud',
          graph_version: form.graph_version.trim() || DEFAULT_GRAPH_VERSION,
          meta_business_account_id: form.meta_business_account_id.trim() || undefined,
          waba_id: form.waba_id.trim(),
          access_token: form.access_token.trim(),
        },
      });
      const discoveredPhones = Array.isArray(response?.phone_numbers) ? response.phone_numbers : [];
      setPhoneOptions(discoveredPhones);
      if (discoveredPhones[0]?.id) {
        updateForm('phone_number_id', String(discoveredPhones[0].id));
        updateForm('display_phone_number', discoveredPhones[0].display_phone_number || '');
        updateForm('business_phone_number', discoveredPhones[0].display_phone_number || form.business_phone_number);
      }
      toast({
        title: 'Phone numbers loaded',
        description: discoveredPhones.length > 0 ? `Found ${discoveredPhones.length} phone number(s) for the selected WABA.` : 'No phone numbers were returned for this WABA.',
      });
    } catch (error) {
      toast({
        title: 'Failed to load phone numbers',
        description: error.message || 'Please verify the WABA and access token.',
        variant: 'destructive',
      });
    } finally {
      setDiscoveringPhones(false);
    }
  };

  const handleCreateAndValidate = async () => {
    const payload = buildConnectionPayload(form, selectedWorkspaceId);
    setCreatingConnection(true);
    setValidationError('');
    setValidationResult(null);
    try {
      let connection = createdConnection;
      if (connection?.id) {
        connection = await apiRequest(`/whatsapp/connections/${connection.id}`, {
          method: 'PATCH',
          body: payload,
        });
      } else {
        connection = await apiRequest('/whatsapp/connections', {
          method: 'POST',
          body: payload,
        });
      }
      const validation = await apiRequest(`/whatsapp/connections/${connection.id}/validate`, {
        method: 'POST',
        body: {},
      });
      const normalized = normalizeConnection(validation?.connection || connection);
      setCreatedConnection(normalized);
      setValidationResult(validation?.validation || { status: 'active' });
      await refreshConnections(selectedWorkspaceId);
      toast({
        title: 'Connection ready',
        description: 'WinAssist validated the WhatsApp number and stored the connection successfully.',
      });
      setActiveStep(5);
    } catch (error) {
      setValidationError(error.message || 'Validation failed.');
      if (!createdConnection?.id) setCreatedConnection(null);
      toast({
        title: 'Connection failed',
        description: error.message || 'Please review the selected assets and try again.',
        variant: 'destructive',
      });
    } finally {
      setCreatingConnection(false);
    }
  };

  const handleSendTestMessage = async () => {
    if (!createdConnection?.id) return;
    setSendingTest(true);
    try {
      const response = await apiRequest(`/whatsapp/connections/${createdConnection.id}/test-message`, {
        method: 'POST',
        body: {
          to: form.test_to.trim(),
          message: form.test_message.trim(),
        },
      });
      setTestResponse(response);
      await refreshConnections(selectedWorkspaceId);
      toast({
        title: 'Test message sent',
        description: 'The connected WhatsApp number successfully submitted a test message.',
      });
      setActiveStep(6);
    } catch (error) {
      toast({
        title: 'Test message failed',
        description: error.message || 'Please verify the destination number and try again.',
        variant: 'destructive',
      });
    } finally {
      setSendingTest(false);
    }
  };

  const handleConnectionAction = async (connectionId, action) => {
    setConnectionActionId(`${connectionId}:${action}`);
    try {
      await apiRequest(`/whatsapp/connections/${connectionId}/${action}`, {
        method: 'POST',
        body: {},
      });
      await refreshConnections(selectedWorkspaceId);
      toast({
        title: action === 'sync' ? 'Connection synced' : 'Connection revalidated',
        description: action === 'sync' ? 'Latest WhatsApp metadata has been refreshed.' : 'The connection was validated again successfully.',
      });
    } catch (error) {
      toast({
        title: action === 'sync' ? 'Sync failed' : 'Validation failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setConnectionActionId('');
    }
  };

  const handleCreateTemplate = async () => {
    if (!selectedTemplateConnectionId) {
      toast({
        title: 'Connection required',
        description: 'Select a WhatsApp connection before creating a template.',
        variant: 'destructive',
      });
      return;
    }
    if (!templateForm.name.trim() || !templateForm.body_text.trim()) {
      toast({
        title: 'Template details required',
        description: 'Add a template name and body text before creating the template.',
        variant: 'destructive',
      });
      return;
    }

    setCreatingTemplate(true);
    try {
      await apiRequest('/whatsapp/templates', {
        method: 'POST',
        body: {
          connection_id: selectedTemplateConnectionId,
          name: templateForm.name.trim(),
          category: templateForm.category,
          language: templateForm.language.trim() || 'en_US',
          components: buildTemplateComponents(templateForm),
          submit_to_meta: templateForm.publish_mode === 'submit',
          metadata: {
            source: 'whatsapp_setup_template_manager',
          },
        },
      });
      await refreshTemplates(selectedTemplateConnectionId);
      toast({
        title: templateForm.publish_mode === 'submit' ? 'Template submitted' : 'Draft saved',
        description: templateForm.publish_mode === 'submit'
          ? 'The template was submitted to Meta and stored in WinAssist.'
          : 'The template draft was saved locally in WinAssist.',
      });
      setTemplateForm({
        name: '',
        category: 'UTILITY',
        language: 'en_US',
        header_text: '',
        body_text: '',
        body_examples: '',
        footer_text: '',
        publish_mode: 'submit',
      });
    } catch (error) {
      toast({
        title: 'Template creation failed',
        description: error.message || 'Please review the template details and try again.',
        variant: 'destructive',
      });
    } finally {
      setCreatingTemplate(false);
    }
  };

  const handleTemplateSync = async (templateId) => {
    setTemplateActionId(`${templateId}:sync`);
    try {
      await apiRequest(`/whatsapp/templates/${templateId}/sync`, {
        method: 'POST',
        body: {},
      });
      await Promise.all([
        refreshTemplates(selectedTemplateConnectionId),
        refreshChannelDashboard(selectedLogConnectionId),
      ]);
      toast({
        title: 'Template synced',
        description: 'The latest template status was refreshed from Meta.',
      });
    } catch (error) {
      toast({
        title: 'Template sync failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setTemplateActionId('');
    }
  };

  const handleUseTemplate = (template) => {
    setSelectedTemplateId(template.id);
    setTemplateSendForm((prev) => ({
      ...prev,
      language_code: template.language || 'en_US',
    }));
  };

  const handleSendTemplate = async () => {
    if (!selectedTemplateId) {
      toast({
        title: 'Template required',
        description: 'Choose a template to send first.',
        variant: 'destructive',
      });
      return;
    }
    if (!templateSendForm.to.trim()) {
      toast({
        title: 'Recipient required',
        description: 'Enter a WhatsApp phone number to send the template to.',
        variant: 'destructive',
      });
      return;
    }

    setSendingTemplate(true);
    try {
      await apiRequest(`/whatsapp/templates/${selectedTemplateId}/send`, {
        method: 'POST',
        body: {
          to: templateSendForm.to.trim(),
          language_code: templateSendForm.language_code.trim() || undefined,
          components: buildSendTemplateComponents(templateSendForm.variable_values),
        },
      });
      await Promise.all([
        refreshMessageLogs(selectedLogConnectionId),
        refreshChannelDashboard(selectedLogConnectionId),
      ]);
      toast({
        title: 'Template sent',
        description: 'The template send request was submitted successfully.',
      });
    } catch (error) {
      toast({
        title: 'Template send failed',
        description: error.message || 'Please review the template variables and try again.',
        variant: 'destructive',
      });
    } finally {
      setSendingTemplate(false);
    }
  };

  const handleRetryMessage = async (messageId) => {
    setMessageActionId(`retry:${messageId}`);
    try {
      await apiRequest(`/whatsapp/messages/${messageId}/retry`, {
        method: 'POST',
        body: {},
      });
      await Promise.all([
        refreshMessageLogs(selectedLogConnectionId),
        refreshChannelDashboard(selectedLogConnectionId),
      ]);
      toast({
        title: 'Message retried',
        description: 'The failed outbound WhatsApp message was queued again successfully.',
      });
    } catch (error) {
      toast({
        title: 'Retry failed',
        description: error.message || 'Please inspect the saved send payload and try again.',
        variant: 'destructive',
      });
    } finally {
      setMessageActionId('');
    }
  };

  const handleLoadStarterFlow = () => {
    updateFlowForm('flow_json', getStarterFlowJson());
    toast({
      title: 'Starter flow loaded',
      description: 'A simple starter WhatsApp Flow JSON has been inserted into the editor.',
    });
  };

  const handleImportFlowJson = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (loadEvent) => {
      try {
        const parsed = JSON.parse(loadEvent.target?.result || '{}');
        updateFlowForm('flow_json', JSON.stringify(parsed, null, 2));
        if (!flowForm.name.trim() && file.name) {
          updateFlowForm('name', file.name.replace(/\.json$/i, '').replace(/\s+/g, '_').toLowerCase());
        }
        toast({
          title: 'Flow JSON imported',
          description: 'The uploaded flow JSON is ready for review and publishing.',
        });
      } catch {
        toast({
          title: 'Invalid flow JSON',
          description: 'The selected file could not be parsed as valid JSON.',
          variant: 'destructive',
        });
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  };

  const handleCreateFlow = async () => {
    if (!selectedFlowConnectionId) {
      toast({
        title: 'Connection required',
        description: 'Select a WhatsApp connection before creating a flow.',
        variant: 'destructive',
      });
      return;
    }
    if (!flowForm.name.trim() || !flowForm.flow_json.trim()) {
      toast({
        title: 'Flow details required',
        description: 'Add a flow name and JSON payload before creating the flow.',
        variant: 'destructive',
      });
      return;
    }

    setCreatingFlow(true);
    try {
      await apiRequest('/whatsapp/flows', {
        method: 'POST',
        body: {
          connection_id: selectedFlowConnectionId,
          name: flowForm.name.trim(),
          categories: parseMultilineValues(flowForm.categories.replace(/,/g, '\n')),
          endpoint_uri: flowForm.endpoint_uri.trim() || undefined,
          clone_flow_id: flowForm.clone_flow_id.trim() || undefined,
          flow_json: flowForm.flow_json,
        },
      });
      await refreshFlows(selectedFlowConnectionId);
      toast({
        title: 'Flow created',
        description: 'The flow metadata and JSON were submitted and saved successfully.',
      });
    } catch (error) {
      toast({
        title: 'Flow creation failed',
        description: error.message || 'Please review the flow JSON and try again.',
        variant: 'destructive',
      });
    } finally {
      setCreatingFlow(false);
    }
  };

  const handlePublishFlow = async (flowId) => {
    setFlowActionId(`${flowId}:publish`);
    try {
      await apiRequest(`/whatsapp/flows/${flowId}/publish`, {
        method: 'POST',
        body: {},
      });
      await Promise.all([
        refreshFlows(selectedFlowConnectionId),
        refreshChannelDashboard(selectedLogConnectionId),
      ]);
      toast({
        title: 'Flow published',
        description: 'The selected flow was published successfully.',
      });
    } catch (error) {
      toast({
        title: 'Flow publish failed',
        description: error.message || 'Please review the flow and try again.',
        variant: 'destructive',
      });
    } finally {
      setFlowActionId('');
    }
  };

  const handleRefreshFlow = async (flowId) => {
    setFlowActionId(`${flowId}:refresh`);
    try {
      const refreshed = await apiRequest(`/whatsapp/flows/${flowId}`, {
        method: 'GET',
      });
      const normalized = normalizeFlow(refreshed);
      if (normalized) {
        setFlows((prev) => prev.map((item) => (item.id === normalized.id ? normalized : item)));
      }
      await refreshChannelDashboard(selectedLogConnectionId);
      toast({
        title: 'Flow refreshed',
        description: 'The latest flow metadata and preview details were loaded from Meta.',
      });
    } catch (error) {
      toast({
        title: 'Flow refresh failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setFlowActionId('');
    }
  };

  const handleGenerateFlowPublicKey = async (flowId) => {
    setFlowRuntimeActionId(`${flowId}:public-key`);
    try {
      const data = await apiRequest(`/whatsapp/flows/${flowId}/public-key`, {
        method: 'POST',
        body: {
          regenerate: false,
          register_with_meta: true,
        },
      });
      setFlowRuntimeStatus(normalizeFlowRuntimeStatus(data));
      toast({
        title: 'Runtime key ready',
        description: 'WinAssist generated the encryption key pair and registered the public key with Meta.',
      });
    } catch (error) {
      toast({
        title: 'Runtime key setup failed',
        description: error.message || 'Please verify the WhatsApp connection and try again.',
        variant: 'destructive',
      });
    } finally {
      setFlowRuntimeActionId('');
    }
  };

  const handleBindFlowRuntimeEndpoint = async (flowId) => {
    setFlowRuntimeActionId(`${flowId}:endpoint`);
    try {
      const refreshedFlow = await apiRequest(`/whatsapp/flows/${flowId}/data-endpoint`, {
        method: 'POST',
        body: {
          endpoint_uri: flowRuntimeForm.endpoint_uri.trim() || undefined,
          update_meta: true,
        },
      });
      const normalized = normalizeFlow(refreshedFlow);
      if (normalized) {
        setFlows((prev) => prev.map((item) => (item.id === normalized.id ? normalized : item)));
      }
      await refreshFlowRuntimeStatus(flowId);
      toast({
        title: 'Endpoint bound',
        description: 'The flow now points to the WinAssist runtime callback URL.',
      });
    } catch (error) {
      toast({
        title: 'Endpoint binding failed',
        description: error.message || 'Please review the endpoint URL and try again.',
        variant: 'destructive',
      });
    } finally {
      setFlowRuntimeActionId('');
    }
  };

  const handleUseFlow = (flow) => {
    setSelectedFlowId(flow.id);
    setFlowRuntimeForm((prev) => ({
      ...prev,
      endpoint_uri: flow?.endpoint_uri || flow?.raw_data?.runtime_callback_url || prev.endpoint_uri,
    }));
  };

  const handleSendFlow = async () => {
    if (!selectedFlowId) {
      toast({
        title: 'Flow required',
        description: 'Choose a flow to send first.',
        variant: 'destructive',
      });
      return;
    }
    if (!flowSendForm.to.trim()) {
      toast({
        title: 'Recipient required',
        description: 'Enter a WhatsApp phone number before sending the flow.',
        variant: 'destructive',
      });
      return;
    }

    setSendingFlow(true);
    try {
      await apiRequest(`/whatsapp/flows/${selectedFlowId}/send`, {
        method: 'POST',
        body: {
          to: flowSendForm.to.trim(),
          body_text: flowSendForm.body_text.trim(),
          header_text: flowSendForm.header_text.trim() || undefined,
          footer_text: flowSendForm.footer_text.trim() || undefined,
          flow_cta: flowSendForm.flow_cta.trim() || 'Open flow',
          flow_token: flowSendForm.flow_token.trim() || undefined,
        },
      });
      await Promise.all([
        refreshMessageLogs(selectedLogConnectionId),
        refreshChannelDashboard(selectedLogConnectionId),
      ]);
      toast({
        title: 'Flow sent',
        description: 'The flow send request was submitted successfully.',
      });
    } catch (error) {
      toast({
        title: 'Flow send failed',
        description: error.message || 'Please review the flow payload and try again.',
        variant: 'destructive',
      });
    } finally {
      setSendingFlow(false);
    }
  };

  const handleReplayFlowRuntimeEvent = async (eventId) => {
    if (!selectedFlowId) return;
    setFlowRuntimeActionId(`${selectedFlowId}:replay:${eventId}`);
    try {
      const data = await apiRequest(`/whatsapp/flows/${selectedFlowId}/runtime-events/${eventId}/replay`, {
        method: 'POST',
        body: {},
      });
      setFlowRuntimeReplayResult(data && typeof data === 'object' ? data : null);
      await refreshFlowRuntimeEvents(selectedFlowId);
      toast({
        title: 'Runtime event replayed',
        description: 'The saved callback payload was decrypted and replayed successfully.',
      });
    } catch (error) {
      toast({
        title: 'Replay failed',
        description: error.message || 'Please verify that the flow key is still configured and try again.',
        variant: 'destructive',
      });
    } finally {
      setFlowRuntimeActionId('');
    }
  };

  const summaryRows = [
    ['Workspace', selectedWorkspace?.name || 'Not selected'],
    ['Connection method', form.connection_method === 'meta' ? 'Connect with Meta' : 'Manual credentials'],
    ['Meta business account', form.meta_business_account_id || 'Not provided'],
    ['Selected WABA', form.waba_id || 'Not selected'],
    ['Selected phone number', form.business_phone_number || form.display_phone_number || 'Not selected'],
    ['Linked bot', selectedBotProjectName || 'Not selected'],
  ];

  const renderStep = () => {
    if (activeStep === 0) {
      return (
        <div className="grid gap-4 md:grid-cols-2">
          <Card className={form.connection_method === 'manual' ? 'border-emerald-200 shadow-sm' : 'shadow-sm'}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/WhatsApp_icon.png" alt="" className="h-6 w-6" />
                Enter details manually
              </CardTitle>
              <CardDescription>
                Best for customers who already have their WhatsApp Cloud API details from Meta Business Manager.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <p className="text-sm text-muted-foreground">
                Users provide their access token and business asset IDs once, and WinAssist handles validation and webhook ownership after that.
              </p>
              <Button
                variant={form.connection_method === 'manual' ? 'default' : 'outline'}
                onClick={() => updateForm('connection_method', 'manual')}
              >
                Use manual setup
              </Button>
            </CardContent>
          </Card>
          <Card className={form.connection_method === 'meta' ? 'border-emerald-200 shadow-sm' : 'shadow-sm'}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Icons.badgeCheck className="h-5 w-5 text-primary" />
                Connect with Meta
              </CardTitle>
              <CardDescription>
                Preferred when Embedded Signup or a Meta-owned connect URL is available for this deployment.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="flex flex-wrap gap-2">
                <Badge variant={EMBEDDED_SIGNUP_ENABLED ? 'default' : 'secondary'}>
                  {EMBEDDED_SIGNUP_ENABLED ? 'Enabled' : 'Manual follow-up'}
                </Badge>
                {META_CONNECT_URL ? <Badge variant="outline">Connect URL configured</Badge> : null}
              </div>
              <p className="text-sm text-muted-foreground">
                This flow can open an external Meta onboarding experience first, then continue here to confirm the WABA, phone number, and bot link.
              </p>
              <Button
                variant={form.connection_method === 'meta' ? 'default' : 'outline'}
                onClick={() => updateForm('connection_method', 'meta')}
              >
                Use Meta connect
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (activeStep === 1) {
      return (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>{form.connection_method === 'meta' ? 'Connect account' : 'Business access'}</CardTitle>
              <CardDescription>
                {form.connection_method === 'meta'
                  ? 'Open Meta first if a connect URL is available, then continue here with the returned business account and access token details.'
                  : 'Collect the workspace, business account, and access token that WinAssist needs before selecting the WABA.'}
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="workspace">Workspace</Label>
                <Select value={selectedWorkspaceId || ''} onValueChange={(value) => updateForm('workspace_id', value)}>
                  <SelectTrigger id="workspace">
                    <SelectValue placeholder="Choose workspace" />
                  </SelectTrigger>
                  <SelectContent>
                    {(workspaces || []).map((workspace) => (
                      <SelectItem key={workspace.id} value={workspace.id}>
                        {workspace.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="connection-name">Connection label</Label>
                <Input
                  id="connection-name"
                  value={form.name}
                  onChange={(event) => updateForm('name', event.target.value)}
                  placeholder="Example: Support number - India"
                />
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="graph-version">Graph version</Label>
                  <Input
                    id="graph-version"
                    value={form.graph_version}
                    onChange={(event) => updateForm('graph_version', event.target.value)}
                    placeholder={DEFAULT_GRAPH_VERSION}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="meta-business-id">Meta business account ID</Label>
                  <Input
                    id="meta-business-id"
                    value={form.meta_business_account_id}
                    onChange={(event) => updateForm('meta_business_account_id', event.target.value)}
                    placeholder="Used to discover WABAs automatically"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="access-token">Access token</Label>
                <Textarea
                  id="access-token"
                  value={form.access_token}
                  onChange={(event) => {
                    updateForm('access_token', event.target.value);
                    resetRuntimeState();
                  }}
                  className="min-h-[120px]"
                  placeholder="Paste the Cloud API token or the token returned after Meta onboarding"
                />
              </div>
            </CardContent>
          </Card>
          <Card className="border-dashed">
            <CardHeader>
              <CardTitle>Connect with Meta</CardTitle>
              <CardDescription>
                When configured for this environment, WinAssist can send the user into a Meta-managed connection flow first.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              {META_CONNECT_URL ? (
                <Button asChild variant="outline" size="sm">
                  <a href={META_CONNECT_URL} target="_blank" rel="noreferrer">
                    Open Meta connect
                  </a>
                </Button>
              ) : (
                <div className="rounded-lg border border-dashed p-3">
                  No Meta connect URL is configured for this environment, so manual credential entry remains the active path.
                </div>
              )}
              <p>WinAssist still validates everything before saving the connection, even if onboarding starts from Meta.</p>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (activeStep === 2) {
      return (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Select WABA</CardTitle>
              <CardDescription>
                Load WhatsApp business accounts from the Meta business account when possible, or enter the WABA ID manually.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  onClick={discoverWabas}
                  disabled={discoveringWabas || !form.meta_business_account_id.trim() || !form.access_token.trim()}
                >
                  {discoveringWabas ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                  Load WABAs
                </Button>
                <Badge variant="outline">{wabaOptions.length} discovered</Badge>
              </div>
              {wabaOptions.length > 0 ? (
                <div className="grid gap-2">
                  <Label htmlFor="waba-select">Choose discovered WABA</Label>
                  <Select value={form.waba_id || ''} onValueChange={(value) => updateForm('waba_id', value)}>
                    <SelectTrigger id="waba-select">
                      <SelectValue placeholder="Choose WABA" />
                    </SelectTrigger>
                    <SelectContent>
                      {wabaOptions.map((waba) => (
                        <SelectItem key={String(waba.id)} value={String(waba.id)}>
                          {waba.name || `WABA ${waba.id}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : null}
              <div className="grid gap-2">
                <Label htmlFor="waba-id">WABA ID</Label>
                <Input
                  id="waba-id"
                  value={form.waba_id}
                  onChange={(event) => {
                    updateForm('waba_id', event.target.value);
                    setPhoneOptions([]);
                    updateForm('phone_number_id', '');
                    updateForm('display_phone_number', '');
                    resetRuntimeState();
                  }}
                  placeholder="WhatsApp Business Account ID"
                />
              </div>
            </CardContent>
          </Card>
          <Card className="border-dashed">
            <CardHeader>
              <CardTitle>What the user is choosing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>The WABA is the business account container that owns the phone numbers, templates, and flows.</p>
              <p>If Meta discovery is not available for the current token, the user can still continue by entering the WABA ID manually.</p>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (activeStep === 3) {
      return (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Select phone number</CardTitle>
              <CardDescription>
                Load the numbers under the selected WABA or fill in the phone number details manually.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  onClick={discoverPhoneNumbers}
                  disabled={discoveringPhones || !form.waba_id.trim() || !form.access_token.trim()}
                >
                  {discoveringPhones ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                  Load phone numbers
                </Button>
                <Badge variant="outline">{phoneOptions.length} discovered</Badge>
              </div>
              {phoneOptions.length > 0 ? (
                <div className="grid gap-2">
                  <Label htmlFor="phone-select">Choose discovered phone number</Label>
                  <Select
                    value={form.phone_number_id || ''}
                    onValueChange={(value) => {
                      const phone = phoneOptions.find((item) => String(item.id) === value);
                      updateForm('phone_number_id', value);
                      updateForm('display_phone_number', phone?.display_phone_number || '');
                      updateForm('business_phone_number', phone?.display_phone_number || form.business_phone_number);
                      resetRuntimeState();
                    }}
                  >
                    <SelectTrigger id="phone-select">
                      <SelectValue placeholder="Choose phone number" />
                    </SelectTrigger>
                    <SelectContent>
                      {phoneOptions.map((phone) => (
                        <SelectItem key={String(phone.id)} value={String(phone.id)}>
                          {phone.display_phone_number || phone.verified_name || phone.id}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : null}
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="phone-number-id">Phone number ID</Label>
                  <Input
                    id="phone-number-id"
                    value={form.phone_number_id}
                    onChange={(event) => {
                      updateForm('phone_number_id', event.target.value);
                      resetRuntimeState();
                    }}
                    placeholder="Meta phone number ID"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="display-phone-number">Display phone number</Label>
                  <Input
                    id="display-phone-number"
                    value={form.display_phone_number}
                    onChange={(event) => updateForm('display_phone_number', event.target.value)}
                    placeholder="Optional display label"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="business-phone-number">Business phone number</Label>
                <Input
                  id="business-phone-number"
                  value={form.business_phone_number}
                  onChange={(event) => updateForm('business_phone_number', event.target.value)}
                  placeholder="+91..."
                />
              </div>
            </CardContent>
          </Card>
          <Card className="border-dashed">
            <CardHeader>
              <CardTitle>Friendly explanation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>This is the actual number your customers will message on WhatsApp.</p>
              <p>The `Phone number ID` is the technical Meta identifier WinAssist uses behind the scenes.</p>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (activeStep === 4) {
      return (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Link bot and validate</CardTitle>
              <CardDescription>
                Bind the selected WhatsApp number to a WinAssist backend bot, then let WinAssist create and validate the connection.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="bot-project">Backend AI agent</Label>
                <Select value={form.bot_project_id || ''} onValueChange={(value) => updateForm('bot_project_id', value)}>
                  <SelectTrigger id="bot-project">
                    <SelectValue placeholder={projectsLoading ? 'Loading backend projects...' : 'Choose backend AI agent'} />
                  </SelectTrigger>
                  <SelectContent>
                    {(backendProjects || []).map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="project-optional">Related project or flow</Label>
                <Select value={form.project_id || '__none__'} onValueChange={(value) => updateForm('project_id', value === '__none__' ? '' : value)}>
                  <SelectTrigger id="project-optional">
                    <SelectValue placeholder="Optional project reference" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">No extra project link</SelectItem>
                    {(backendProjects || []).map((project) => (
                      <SelectItem key={`project-${project.id}`} value={project.id}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="divide-y rounded-lg border">
                {summaryRows.map(([label, value]) => (
                  <div key={label} className="grid gap-1 p-4 sm:grid-cols-[180px_minmax(0,1fr)] sm:items-center">
                    <span className="text-sm font-medium text-foreground">{label}</span>
                    <span className="break-all text-sm text-muted-foreground">{value}</span>
                  </div>
                ))}
              </div>
              {validationError ? (
                <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                  {validationError}
                </div>
              ) : null}
              {validationResult ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
                  Validation completed successfully. You can move on to the test message.
                </div>
              ) : null}
            </CardContent>
          </Card>
          <Card className="border-dashed">
            <CardHeader>
              <CardTitle>What WinAssist does here</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>Stores the token securely.</p>
              <p>Checks access to the selected WABA and phone number.</p>
              <p>Subscribes the configured app to the WABA when needed.</p>
              <p>Keeps webhook management inside WinAssist so the customer does not have to paste callback URLs manually.</p>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (activeStep === 5) {
      return (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Send a test message</CardTitle>
              <CardDescription>
                Confirm that the connected number can send outbound WhatsApp messages through WinAssist.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="test-to">Recipient phone number</Label>
                <Input
                  id="test-to"
                  value={form.test_to}
                  onChange={(event) => updateForm('test_to', event.target.value)}
                  placeholder="+91..."
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="test-message">Message</Label>
                <Textarea
                  id="test-message"
                  value={form.test_message}
                  onChange={(event) => updateForm('test_message', event.target.value)}
                  className="min-h-[120px]"
                />
              </div>
            </CardContent>
          </Card>
          <Card className="border-dashed">
            <CardHeader>
              <CardTitle>Connection status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>{createdConnection?.display_phone_number || form.business_phone_number || 'Not available yet'}</p>
              <p>Validation: {validationResult?.status || createdConnection?.connection_status || 'pending'}</p>
              <p>Subscription: {createdConnection?.subscribed_app_status || 'tracked in connection status'}</p>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
        <Card>
          <CardHeader>
            <CardTitle>Setup complete</CardTitle>
            <CardDescription>
              The customer can now use the connected WhatsApp number through WinAssist without touching raw API nodes.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
              The connection has been created, validated, and tested successfully.
            </div>
            <div className="grid gap-2 text-sm">
              <div><span className="font-medium text-foreground">Connection:</span> {createdConnection?.name || 'WhatsApp connection'}</div>
              <div><span className="font-medium text-foreground">Phone number:</span> {createdConnection?.display_phone_number || form.business_phone_number}</div>
              <div><span className="font-medium text-foreground">Bot:</span> {selectedBotProjectName || 'Not linked'}</div>
              <div><span className="font-medium text-foreground">Workspace:</span> {selectedWorkspace?.name || 'Not selected'}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-dashed">
          <CardHeader>
            <CardTitle>Readiness summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>Connection record stored in WinAssist.</p>
            <p>WABA and phone number validated.</p>
            <p>Bot linked for later runtime routing phases.</p>
            <p>Test message submitted successfully.</p>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-8">
        <PageHeader
          icon={Icons.phone}
          title="WhatsApp Setup"
          description="Connect a customer-owned WhatsApp business number to WinAssist with a guided, non-technical setup flow."
          actions={(
            <>
              <Button asChild variant="outline" size="sm">
                <Link to="/channels">Back to Channels</Link>
              </Button>
              <Button variant="outline" size="sm" onClick={resetWizard}>
                Reset wizard
              </Button>
            </>
          )}
        />

        <div className="grid gap-4 md:grid-cols-7">
          {STEPS.map((step, index) => {
            const isActive = index === activeStep;
            const isComplete = index < activeStep;
            return (
              <Card
                key={step.id}
                className={isActive ? 'border-primary shadow-sm' : isComplete ? 'border-emerald-200 shadow-sm' : 'shadow-sm'}
              >
                <CardContent className="flex items-center gap-3 p-4">
                  <div
                    className={[
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-semibold',
                      isComplete ? 'bg-emerald-600 text-white' : isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground',
                    ].join(' ')}
                  >
                    {isComplete ? <Icons.check className="h-4 w-4" /> : index + 1}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-foreground">{step.label}</div>
                    <div className="text-xs text-muted-foreground">Step {index + 1}</div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {renderStep()}

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">
            {activeStep === 0
              ? 'Choose whether the customer starts with Meta connect or enters their credentials manually.'
              : activeStep === 4
                ? 'Link the bot, then let WinAssist create and validate the connection.'
                : activeStep === 6
                  ? 'Phase 2 onboarding is complete for this WhatsApp number.'
                  : 'Complete the current step to continue.'}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => setActiveStep((prev) => Math.max(0, prev - 1))} disabled={activeStep === 0 || creatingConnection || sendingTest}>
              Back
            </Button>
            {activeStep < 4 ? (
              <Button onClick={() => setActiveStep((prev) => prev + 1)} disabled={!canGoNext}>
                Next
              </Button>
            ) : null}
            {activeStep === 4 ? (
              <Button onClick={handleCreateAndValidate} disabled={creatingConnection || !canGoNext}>
                {creatingConnection ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                {createdConnection?.id ? 'Revalidate connection' : 'Create and validate'}
              </Button>
            ) : null}
            {activeStep === 5 ? (
              <Button onClick={handleSendTestMessage} disabled={sendingTest || !form.test_to.trim() || !form.test_message.trim()}>
                {sendingTest ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                Send test message
              </Button>
            ) : null}
            {activeStep === 6 ? (
              <Button onClick={resetWizard}>
                Connect another number
              </Button>
            ) : null}
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Connected numbers</CardTitle>
            <CardDescription>
              Existing WhatsApp connections for the selected workspace, with quick health actions.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {connectionsLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="h-4 w-4 animate-spin" />
                Loading connections...
              </div>
            ) : connections.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No WhatsApp connections were found in this workspace yet.
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {connections.map((connection) => {
                  const connectionBadge = getStatusBadge(connection.connection_status);
                  const webhookBadge = getStatusBadge(connection.webhook_status);
                  const healthBadge = getStatusBadge(connection.health_status);
                  const syncBadge = getStatusBadge(connection.last_sync_status);
                  const actionKeyValidate = `${connection.id}:validate`;
                  const actionKeySync = `${connection.id}:sync`;
                  return (
                    <Card key={connection.id} className="border-border/80 shadow-sm">
                      <CardHeader className="gap-3 pb-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <CardTitle className="text-base">{connection.name}</CardTitle>
                            <CardDescription className="mt-1">{connection.display_phone_number}</CardDescription>
                          </div>
                          <Badge variant={connectionBadge.variant} className={connectionBadge.className}>
                            {connection.connection_status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3 pt-0 text-sm">
                        <div className="flex flex-wrap gap-2">
                          <Badge variant={webhookBadge.variant} className={webhookBadge.className}>
                            webhook: {connection.webhook_status}
                          </Badge>
                          <Badge variant={healthBadge.variant} className={healthBadge.className}>
                            health: {connection.health_status}
                          </Badge>
                          <Badge variant={syncBadge.variant} className={syncBadge.className}>
                            sync: {connection.last_sync_status}
                          </Badge>
                        </div>
                        {connection.last_validation_error ? (
                          <div className="rounded-md border border-red-200 bg-red-50 p-3 text-red-700">
                            {connection.last_validation_error}
                          </div>
                        ) : null}
                        <div className="text-muted-foreground">
                          Token: {connection.access_token_masked || 'Stored securely'}
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleConnectionAction(connection.id, 'validate')}
                            disabled={connectionActionId === actionKeyValidate || connectionActionId === actionKeySync}
                          >
                            {connectionActionId === actionKeyValidate ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                            Revalidate
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleConnectionAction(connection.id, 'sync')}
                            disabled={connectionActionId === actionKeyValidate || connectionActionId === actionKeySync}
                          >
                            {connectionActionId === actionKeySync ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                            Sync assets
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>WhatsApp flows</CardTitle>
              <CardDescription>
                Upload Flow JSON, preview publish state, and send test flows from the same WhatsApp workspace.
              </CardDescription>
            </div>
            <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
              <Select value={selectedFlowConnectionId} onValueChange={setSelectedFlowConnectionId}>
                <SelectTrigger className="w-full md:w-[280px]">
                  <SelectValue placeholder="Select a connection" />
                </SelectTrigger>
                <SelectContent>
                  {connections.map((connection) => (
                    <SelectItem key={connection.id} value={connection.id}>
                      {connection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => refreshFlows(selectedFlowConnectionId)}
                disabled={!selectedFlowConnectionId || flowsLoading}
              >
                {flowsLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                Refresh flows
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {!selectedFlowConnectionId ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Connect a WhatsApp number first to manage flows.
              </div>
            ) : (
              <div className="grid gap-6 xl:grid-cols-[minmax(340px,1fr)_minmax(0,1.4fr)]">
                <Card className="shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-base">Create flow</CardTitle>
                    <CardDescription>
                      Start from starter JSON, upload an existing file, or clone an existing Meta flow before publishing.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="flow-name">Flow name</Label>
                      <Input
                        id="flow-name"
                        value={flowForm.name}
                        onChange={(event) => updateFlowForm('name', event.target.value)}
                        placeholder="lead_capture_flow"
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="flow-categories">Categories</Label>
                        <Input
                          id="flow-categories"
                          value={flowForm.categories}
                          onChange={(event) => updateFlowForm('categories', event.target.value)}
                          placeholder="OTHER, SUPPORT"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="flow-endpoint-uri">Endpoint URI</Label>
                        <Input
                          id="flow-endpoint-uri"
                          value={flowForm.endpoint_uri}
                          onChange={(event) => updateFlowForm('endpoint_uri', event.target.value)}
                          placeholder="Optional static endpoint"
                        />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="flow-clone-id">Clone flow ID</Label>
                      <Input
                        id="flow-clone-id"
                        value={flowForm.clone_flow_id}
                        onChange={(event) => updateFlowForm('clone_flow_id', event.target.value)}
                        placeholder="Optional existing Meta flow ID"
                      />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button type="button" variant="outline" onClick={handleLoadStarterFlow}>
                        Load starter JSON
                      </Button>
                      <Input
                        type="file"
                        accept=".json,application/json"
                        onChange={handleImportFlowJson}
                        className="max-w-[260px]"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="flow-json">Flow JSON</Label>
                      <Textarea
                        id="flow-json"
                        value={flowForm.flow_json}
                        onChange={(event) => updateFlowForm('flow_json', event.target.value)}
                        className="min-h-[260px] font-mono text-xs"
                        placeholder='Paste Meta Flow JSON here'
                      />
                    </div>
                    <Button onClick={handleCreateFlow} disabled={creatingFlow}>
                      {creatingFlow ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.plus className="h-4 w-4" />}
                      Create flow
                    </Button>
                  </CardContent>
                </Card>

                <div className="space-y-6">
                  <Card className="shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-base">Saved flows</CardTitle>
                      <CardDescription>
                        Preview status, fetch the latest Meta details, publish a flow, or select one for sending.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {flowsLoading ? (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Icons.spinner className="h-4 w-4 animate-spin" />
                          Loading flows...
                        </div>
                      ) : flows.length === 0 ? (
                        <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                          No flows are stored for this connection yet.
                        </div>
                      ) : (
                        flows.map((flow) => {
                          const statusBadge = getStatusBadge(flow.status);
                          const refreshKey = `${flow.id}:refresh`;
                          const publishKey = `${flow.id}:publish`;
                          const previewUrl = getFlowPreviewUrl(flow);
                          return (
                            <div key={flow.id} className="rounded-lg border border-border/70 p-4">
                              <div className="flex flex-wrap items-start justify-between gap-3">
                                <div className="min-w-0 flex-1">
                                  <div className="text-sm font-medium text-foreground">{flow.name}</div>
                                  <div className="mt-1 text-xs text-muted-foreground">
                                    {flow.categories.length > 0 ? flow.categories.join(', ') : 'No categories'} · Updated {formatLogTime(flow.updated_at)}
                                  </div>
                                  {previewUrl ? (
                                    <a
                                      href={previewUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="mt-2 inline-flex text-xs text-primary underline-offset-4 hover:underline"
                                    >
                                      Open preview URL
                                    </a>
                                  ) : null}
                                </div>
                                <Badge variant={statusBadge.variant} className={statusBadge.className}>
                                  {flow.status}
                                </Badge>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleRefreshFlow(flow.id)}
                                  disabled={flowActionId === refreshKey || flowActionId === publishKey}
                                >
                                  {flowActionId === refreshKey ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                                  Refresh
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handlePublishFlow(flow.id)}
                                  disabled={flowActionId === refreshKey || flowActionId === publishKey}
                                >
                                  {flowActionId === publishKey ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                                  Publish
                                </Button>
                                <Button
                                  size="sm"
                                  variant={selectedFlowId === flow.id ? 'default' : 'outline'}
                                  onClick={() => handleUseFlow(flow)}
                                >
                                  Use in send form
                                </Button>
                              </div>
                              {getFlowJsonText(flow) ? (
                                <div className="mt-3 rounded-md border bg-muted/30 p-3">
                                  <pre className="overflow-x-auto whitespace-pre-wrap text-[11px] text-muted-foreground">
                                    {getFlowJsonText(flow).slice(0, 1200)}
                                  </pre>
                                </div>
                              ) : null}
                            </div>
                          );
                        })
                      )}
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-base">Send test flow</CardTitle>
                      <CardDescription>
                        Send a saved flow as an interactive WhatsApp message using the flow send wrapper from WinAssist.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="grid gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="send-flow-id">Flow</Label>
                        <Select value={selectedFlowId} onValueChange={setSelectedFlowId}>
                          <SelectTrigger id="send-flow-id">
                            <SelectValue placeholder="Choose a flow" />
                          </SelectTrigger>
                          <SelectContent>
                            {flows.map((flow) => (
                              <SelectItem key={flow.id} value={flow.id}>
                                {flow.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="send-flow-to">Recipient number</Label>
                          <Input
                            id="send-flow-to"
                            value={flowSendForm.to}
                            onChange={(event) => updateFlowSendForm('to', event.target.value)}
                            placeholder="+919999999999"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="send-flow-cta">CTA label</Label>
                          <Input
                            id="send-flow-cta"
                            value={flowSendForm.flow_cta}
                            onChange={(event) => updateFlowSendForm('flow_cta', event.target.value)}
                            placeholder="Open flow"
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="send-flow-body">Body text</Label>
                        <Textarea
                          id="send-flow-body"
                          value={flowSendForm.body_text}
                          onChange={(event) => updateFlowSendForm('body_text', event.target.value)}
                          className="min-h-[100px]"
                          placeholder="Tap below to open this WhatsApp Flow."
                        />
                      </div>
                      <div className="grid gap-4 sm:grid-cols-3">
                        <div className="grid gap-2">
                          <Label htmlFor="send-flow-header">Header text</Label>
                          <Input
                            id="send-flow-header"
                            value={flowSendForm.header_text}
                            onChange={(event) => updateFlowSendForm('header_text', event.target.value)}
                            placeholder="Optional header"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="send-flow-footer">Footer text</Label>
                          <Input
                            id="send-flow-footer"
                            value={flowSendForm.footer_text}
                            onChange={(event) => updateFlowSendForm('footer_text', event.target.value)}
                            placeholder="Optional footer"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="send-flow-token">Flow token</Label>
                          <Input
                            id="send-flow-token"
                            value={flowSendForm.flow_token}
                            onChange={(event) => updateFlowSendForm('flow_token', event.target.value)}
                            placeholder="Optional token"
                          />
                        </div>
                      </div>
                      <Button onClick={handleSendFlow} disabled={sendingFlow || !selectedFlowId}>
                        {sendingFlow ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.send className="h-4 w-4" />}
                        Send test flow
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div>
                        <CardTitle className="text-base">Dynamic flow runtime</CardTitle>
                        <CardDescription>
                          Configure endpoint encryption, bind the callback URL, and inspect recent Phase 7 runtime callbacks.
                        </CardDescription>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => refreshFlowRuntimeStatus(selectedFlowId)}
                          disabled={!selectedFlowId || flowRuntimeActionId === `${selectedFlowId}:public-key` || flowRuntimeActionId === `${selectedFlowId}:endpoint`}
                        >
                          <Icons.refresh className="h-4 w-4" />
                          Refresh status
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => refreshFlowRuntimeEvents(selectedFlowId)}
                          disabled={!selectedFlowId || flowRuntimeEventsLoading}
                        >
                          {flowRuntimeEventsLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                          Refresh events
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {!selectedFlow ? (
                        <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                          Select a saved flow first to manage its dynamic runtime configuration.
                        </div>
                      ) : (
                        <>
                          <div className="grid gap-4 lg:grid-cols-2">
                            <div className="rounded-lg border p-4">
                              <div className="text-sm font-medium text-foreground">{selectedFlow.name}</div>
                              <div className="mt-2 space-y-2 text-sm text-muted-foreground">
                                <div>Meta flow ID: {selectedFlow.meta_flow_id || 'Not synced yet'}</div>
                                <div>Callback URL: {flowRuntimeStatus?.callback_url || selectedFlow.raw_data?.runtime_callback_url || 'Not generated yet'}</div>
                                <div>Key fingerprint: {flowRuntimeStatus?.public_key_fingerprint || 'Not generated yet'}</div>
                                <div>Meta signature status: {flowRuntimeStatus?.meta_signature_status || 'Unknown'}</div>
                                <div>Key generated: {flowRuntimeStatus?.key_generated_at ? formatLogTime(flowRuntimeStatus.key_generated_at) : 'Not generated yet'}</div>
                              </div>
                            </div>
                            <div className="grid gap-3">
                              <div className="grid gap-2">
                                <Label htmlFor="flow-runtime-endpoint">Endpoint URI</Label>
                                <Input
                                  id="flow-runtime-endpoint"
                                  value={flowRuntimeForm.endpoint_uri}
                                  onChange={(event) => updateFlowRuntimeForm('endpoint_uri', event.target.value)}
                                  placeholder="Leave blank to use the WinAssist generated callback URL"
                                />
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <Button
                                  onClick={() => handleGenerateFlowPublicKey(selectedFlow.id)}
                                  disabled={flowRuntimeActionId === `${selectedFlow.id}:public-key` || flowRuntimeActionId === `${selectedFlow.id}:endpoint`}
                                >
                                  {flowRuntimeActionId === `${selectedFlow.id}:public-key` ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                                  Generate and register key
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleBindFlowRuntimeEndpoint(selectedFlow.id)}
                                  disabled={flowRuntimeActionId === `${selectedFlow.id}:public-key` || flowRuntimeActionId === `${selectedFlow.id}:endpoint`}
                                >
                                  {flowRuntimeActionId === `${selectedFlow.id}:endpoint` ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                                  Bind endpoint
                                </Button>
                              </div>
                              <div className="rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
                                {flowRuntimeStatus?.public_key
                                  ? 'Encryption keys are configured for this connection. You can now run Meta health checks and endpoint-backed data exchange.'
                                  : 'Generate the runtime key pair first, then bind the endpoint before publishing endpoint-backed flows.'}
                              </div>
                            </div>
                          </div>

                          <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
                            <div className="rounded-lg border p-4">
                              <div className="mb-3 text-sm font-medium text-foreground">Recent runtime callbacks</div>
                              {flowRuntimeEventsLoading ? (
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <Icons.spinner className="h-4 w-4 animate-spin" />
                                  Loading runtime events...
                                </div>
                              ) : flowRuntimeEvents.length === 0 ? (
                                <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                                  No runtime callbacks have been captured for this flow yet.
                                </div>
                              ) : (
                                <div className="space-y-3">
                                  {flowRuntimeEvents.map((event) => {
                                    const replayKey = `${selectedFlow.id}:replay:${event.id}`;
                                    return (
                                      <div key={event.id} className="rounded-md border p-3">
                                        <div className="flex flex-wrap items-start justify-between gap-3">
                                          <div>
                                            <div className="text-sm font-medium text-foreground">
                                              {getFlowRuntimeActionLabel(event)}
                                            </div>
                                            <div className="text-xs text-muted-foreground">
                                              Event #{event.id} · {formatLogTime(event.created_at)}
                                            </div>
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <Badge variant={event.processed ? 'default' : 'outline'}>
                                              {event.processed ? 'processed' : 'captured'}
                                            </Badge>
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              onClick={() => handleReplayFlowRuntimeEvent(event.id)}
                                              disabled={flowRuntimeActionId === replayKey}
                                            >
                                              {flowRuntimeActionId === replayKey ? <Icons.spinner className="h-4 w-4 animate-spin" /> : null}
                                              Replay
                                            </Button>
                                          </div>
                                        </div>
                                        <div className="mt-3 rounded-md border bg-muted/30 p-3">
                                          <pre className="overflow-x-auto whitespace-pre-wrap text-[11px] text-muted-foreground">
                                            {formatJsonPreview(event.payload?.decrypted_payload || event.payload)}
                                          </pre>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>

                            <div className="rounded-lg border p-4">
                              <div className="mb-3 text-sm font-medium text-foreground">Replay result</div>
                              {flowRuntimeReplayResult ? (
                                <div className="space-y-3">
                                  <div className="text-xs text-muted-foreground">
                                    Last replayed at {formatLogTime(flowRuntimeReplayResult.replayed_at)}
                                  </div>
                                  <div className="rounded-md border bg-muted/30 p-3">
                                    <div className="mb-2 text-xs font-medium text-foreground">Decrypted request</div>
                                    <pre className="overflow-x-auto whitespace-pre-wrap text-[11px] text-muted-foreground">
                                      {formatJsonPreview(flowRuntimeReplayResult.decrypted_payload)}
                                    </pre>
                                  </div>
                                  <div className="rounded-md border bg-muted/30 p-3">
                                    <div className="mb-2 text-xs font-medium text-foreground">Response payload</div>
                                    <pre className="overflow-x-auto whitespace-pre-wrap text-[11px] text-muted-foreground">
                                      {formatJsonPreview(flowRuntimeReplayResult.response_payload)}
                                    </pre>
                                  </div>
                                </div>
                              ) : (
                                <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                                  Replay a runtime event to inspect the decrypted request and generated encrypted response payload.
                                </div>
                              )}
                            </div>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>WhatsApp templates</CardTitle>
              <CardDescription>
                Create, review, sync, and send approved templates without using raw Graph API nodes.
              </CardDescription>
            </div>
            <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
              <Select value={selectedTemplateConnectionId} onValueChange={setSelectedTemplateConnectionId}>
                <SelectTrigger className="w-full md:w-[280px]">
                  <SelectValue placeholder="Select a connection" />
                </SelectTrigger>
                <SelectContent>
                  {connections.map((connection) => (
                    <SelectItem key={connection.id} value={connection.id}>
                      {connection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => refreshTemplates(selectedTemplateConnectionId)}
                disabled={!selectedTemplateConnectionId || templatesLoading}
              >
                {templatesLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                Refresh templates
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {!selectedTemplateConnectionId ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Connect a WhatsApp number first to manage templates.
              </div>
            ) : (
              <div className="grid gap-6 xl:grid-cols-[minmax(320px,1fr)_minmax(0,1.4fr)]">
                <Card className="shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-base">Create template</CardTitle>
                    <CardDescription>
                      Build a reusable template draft, then submit it to Meta when ready.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="template-name">Template name</Label>
                      <Input
                        id="template-name"
                        value={templateForm.name}
                        onChange={(event) => updateTemplateForm('name', event.target.value)}
                        placeholder="order_update_v1"
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="template-category">Category</Label>
                        <Select value={templateForm.category} onValueChange={(value) => updateTemplateForm('category', value)}>
                          <SelectTrigger id="template-category">
                            <SelectValue placeholder="Choose category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="UTILITY">Utility</SelectItem>
                            <SelectItem value="MARKETING">Marketing</SelectItem>
                            <SelectItem value="AUTHENTICATION">Authentication</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="template-language">Language</Label>
                        <Input
                          id="template-language"
                          value={templateForm.language}
                          onChange={(event) => updateTemplateForm('language', event.target.value)}
                          placeholder="en_US"
                        />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="template-header">Header text</Label>
                      <Input
                        id="template-header"
                        value={templateForm.header_text}
                        onChange={(event) => updateTemplateForm('header_text', event.target.value)}
                        placeholder="Optional header"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="template-body">Body text</Label>
                      <Textarea
                        id="template-body"
                        value={templateForm.body_text}
                        onChange={(event) => updateTemplateForm('body_text', event.target.value)}
                        className="min-h-[120px]"
                        placeholder={"Hi {{1}}, your order {{2}} is scheduled for {{3}}."}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="template-examples">Example variable values</Label>
                      <Textarea
                        id="template-examples"
                        value={templateForm.body_examples}
                        onChange={(event) => updateTemplateForm('body_examples', event.target.value)}
                        className="min-h-[100px]"
                        placeholder={"One value per line\nDevesh\nORD-1024\nTomorrow at 10:00 AM"}
                      />
                      <p className="text-xs text-muted-foreground">
                        WinAssist maps each line to body placeholders like <code>{'{{1}}'}</code>, <code>{'{{2}}'}</code>, and <code>{'{{3}}'}</code>.
                      </p>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="template-footer">Footer text</Label>
                      <Input
                        id="template-footer"
                        value={templateForm.footer_text}
                        onChange={(event) => updateTemplateForm('footer_text', event.target.value)}
                        placeholder="Optional footer"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="template-publish-mode">Save mode</Label>
                      <Select value={templateForm.publish_mode} onValueChange={(value) => updateTemplateForm('publish_mode', value)}>
                        <SelectTrigger id="template-publish-mode">
                          <SelectValue placeholder="Choose save mode" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="submit">Submit to Meta now</SelectItem>
                          <SelectItem value="draft">Save as WinAssist draft</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCreateTemplate} disabled={creatingTemplate}>
                      {creatingTemplate ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.plus className="h-4 w-4" />}
                      {templateForm.publish_mode === 'submit' ? 'Create and submit' : 'Save draft'}
                    </Button>
                  </CardContent>
                </Card>

                <div className="space-y-6">
                  <Card className="shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-base">Saved templates</CardTitle>
                      <CardDescription>
                        Review approval state, refresh metadata from Meta, or select a template for sending.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {templatesLoading ? (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Icons.spinner className="h-4 w-4 animate-spin" />
                          Loading templates...
                        </div>
                      ) : templates.length === 0 ? (
                        <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                          No templates are stored for this connection yet.
                        </div>
                      ) : (
                        templates.map((template) => {
                          const statusBadge = getStatusBadge(template.status);
                          const syncKey = `${template.id}:sync`;
                          const placeholderCount = countBodyPlaceholders(template);
                          return (
                            <div key={template.id} className="rounded-lg border border-border/70 p-4">
                              <div className="flex flex-wrap items-start justify-between gap-3">
                                <div className="min-w-0 flex-1">
                                  <div className="text-sm font-medium text-foreground">{template.name}</div>
                                  <div className="mt-1 text-xs text-muted-foreground">
                                    {template.category} · {template.language} · {placeholderCount} body variable{placeholderCount === 1 ? '' : 's'}
                                  </div>
                                  <div className="mt-1 text-xs text-muted-foreground">
                                    Updated {formatLogTime(template.updated_at)}
                                  </div>
                                </div>
                                <Badge variant={statusBadge.variant} className={statusBadge.className}>
                                  {template.status}
                                </Badge>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleTemplateSync(template.id)}
                                  disabled={templateActionId === syncKey}
                                >
                                  {templateActionId === syncKey ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                                  Sync
                                </Button>
                                <Button
                                  size="sm"
                                  variant={selectedTemplateId === template.id ? 'default' : 'outline'}
                                  onClick={() => handleUseTemplate(template)}
                                >
                                  Use in send form
                                </Button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </CardContent>
                  </Card>

                  <Card className="shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-base">Send template</CardTitle>
                      <CardDescription>
                        Pick a saved template, map body variables in order, and send it as a test or operational message.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="grid gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="send-template-id">Template</Label>
                        <Select
                          value={selectedTemplateId}
                          onValueChange={(value) => {
                            setSelectedTemplateId(value);
                            const nextTemplate = templates.find((template) => template.id === value);
                            setTemplateSendForm((prev) => ({
                              ...prev,
                              language_code: nextTemplate?.language || prev.language_code || 'en_US',
                            }));
                          }}
                        >
                          <SelectTrigger id="send-template-id">
                            <SelectValue placeholder="Choose a template" />
                          </SelectTrigger>
                          <SelectContent>
                            {templates.map((template) => (
                              <SelectItem key={template.id} value={template.id}>
                                {template.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div className="grid gap-2">
                          <Label htmlFor="send-template-to">Recipient number</Label>
                          <Input
                            id="send-template-to"
                            value={templateSendForm.to}
                            onChange={(event) => updateTemplateSendForm('to', event.target.value)}
                            placeholder="+919999999999"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="send-template-language">Language code</Label>
                          <Input
                            id="send-template-language"
                            value={templateSendForm.language_code}
                            onChange={(event) => updateTemplateSendForm('language_code', event.target.value)}
                            placeholder={selectedTemplate?.language || 'en_US'}
                          />
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="send-template-variables">Body variable values</Label>
                        <Textarea
                          id="send-template-variables"
                          value={templateSendForm.variable_values}
                          onChange={(event) => updateTemplateSendForm('variable_values', event.target.value)}
                          className="min-h-[110px]"
                          placeholder={"One value per line\nDevesh\nORD-1024\nTomorrow at 10:00 AM"}
                        />
                        <p className="text-xs text-muted-foreground">
                          WinAssist turns each line into a body parameter in order. This is the lightweight variable mapping UI for template placeholders.
                        </p>
                      </div>
                      {selectedTemplate ? (
                        <div className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
                          Selected template: <span className="font-medium text-foreground">{selectedTemplate.name}</span>
                          {' · '}
                          Status: {selectedTemplate.status}
                          {' · '}
                          Body placeholders: {countBodyPlaceholders(selectedTemplate)}
                        </div>
                      ) : null}
                      <Button onClick={handleSendTemplate} disabled={sendingTemplate || !selectedTemplateId}>
                        {sendingTemplate ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.send className="h-4 w-4" />}
                        Send template
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Channel health dashboard</CardTitle>
              <CardDescription>
                Support view for connection health, daily traffic, template approval, flow usage, and pending retries.
              </CardDescription>
            </div>
            <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
              <Select value={selectedLogConnectionId} onValueChange={setSelectedLogConnectionId}>
                <SelectTrigger className="w-full md:w-[280px]">
                  <SelectValue placeholder="Select a connection" />
                </SelectTrigger>
                <SelectContent>
                  {connections.map((connection) => (
                    <SelectItem key={connection.id} value={connection.id}>
                      {connection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => refreshChannelDashboard(selectedLogConnectionId)}
                disabled={!selectedLogConnectionId || dashboardLoading}
              >
                {dashboardLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                Refresh dashboard
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {!selectedLogConnectionId ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Connect a WhatsApp number first to view support metrics.
              </div>
            ) : dashboardLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="h-4 w-4 animate-spin" />
                Loading channel dashboard...
              </div>
            ) : !channelDashboard ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Dashboard metrics are not available yet for this connection.
              </div>
            ) : (
              <>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="rounded-lg border p-4">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Pending retries</div>
                    <div className="mt-2 text-2xl font-semibold text-foreground">{channelDashboard.pending_retries}</div>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Inbound messages</div>
                    <div className="mt-2 text-2xl font-semibold text-foreground">{channelDashboard.message_totals.inbound || 0}</div>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Outbound messages</div>
                    <div className="mt-2 text-2xl font-semibold text-foreground">{channelDashboard.message_totals.outbound || 0}</div>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Webhook events</div>
                    <div className="mt-2 text-2xl font-semibold text-foreground">
                      {Object.values(channelDashboard.webhook_totals || {}).reduce((sum, value) => sum + Number(value || 0), 0)}
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
                  <div className="rounded-lg border p-4">
                    <div className="mb-3 text-sm font-medium text-foreground">Daily traffic</div>
                    {channelDashboard.daily_counts.length === 0 ? (
                      <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                        No traffic has been logged in the selected time window yet.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {channelDashboard.daily_counts.map((day) => (
                          <div key={day.date} className="rounded-md border p-3">
                            <div className="text-sm font-medium text-foreground">{day.date}</div>
                            <div className="mt-2 grid gap-2 text-xs text-muted-foreground md:grid-cols-4">
                              <div>Inbound: {day.inbound || 0}</div>
                              <div>Outbound: {day.outbound || 0}</div>
                              <div>Status: {day.status || 0}</div>
                              <div>Total: {day.total || 0}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <div className="mb-3 text-sm font-medium text-foreground">Connection health</div>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(channelDashboard.connection_health || {}).length === 0 ? (
                          <div className="text-sm text-muted-foreground">No health data yet.</div>
                        ) : (
                          Object.entries(channelDashboard.connection_health || {}).map(([label, count]) => {
                            const badge = getStatusBadge(label);
                            return (
                              <Badge key={label} variant={badge.variant} className={badge.className}>
                                {label}: {count}
                              </Badge>
                            );
                          })
                        )}
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <div className="mb-3 text-sm font-medium text-foreground">Failure reasons</div>
                      {channelDashboard.failure_reasons.length === 0 ? (
                        <div className="text-sm text-muted-foreground">No failures recorded in the selected time window.</div>
                      ) : (
                        <div className="space-y-2">
                          {channelDashboard.failure_reasons.map((item) => (
                            <div key={`${item.label}:${item.count}`} className="flex items-center justify-between gap-3 rounded-md border p-2 text-sm">
                              <span className="min-w-0 flex-1 truncate text-muted-foreground">{item.label}</span>
                              <Badge variant="outline">{item.count}</Badge>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 xl:grid-cols-3">
                  <div className="rounded-lg border p-4">
                    <div className="mb-3 text-sm font-medium text-foreground">Template approval funnel</div>
                    <div className="flex flex-wrap gap-2">
                      {channelDashboard.template_statuses.length === 0 ? (
                        <div className="text-sm text-muted-foreground">No templates tracked yet.</div>
                      ) : (
                        channelDashboard.template_statuses.map((item) => {
                          const badge = getStatusBadge(item.label);
                          return (
                            <Badge key={`${item.label}:${item.count}`} variant={badge.variant} className={badge.className}>
                              {item.label}: {item.count}
                            </Badge>
                          );
                        })
                      )}
                    </div>
                    {channelDashboard.rejected_templates.length > 0 ? (
                      <div className="mt-3 rounded-md border border-red-200 bg-red-50 p-3 text-xs text-red-700">
                        Rejected or blocked templates: {channelDashboard.rejected_templates.join(', ')}
                      </div>
                    ) : null}
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="mb-3 text-sm font-medium text-foreground">Flow usage funnel</div>
                    <div className="flex flex-wrap gap-2">
                      {channelDashboard.flow_statuses.length === 0 ? (
                        <div className="text-sm text-muted-foreground">No flows tracked yet.</div>
                      ) : (
                        channelDashboard.flow_statuses.map((item) => {
                          const badge = getStatusBadge(item.label);
                          return (
                            <Badge key={`${item.label}:${item.count}`} variant={badge.variant} className={badge.className}>
                              {item.label}: {item.count}
                            </Badge>
                          );
                        })
                      )}
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="mb-3 text-sm font-medium text-foreground">Recent flow activity</div>
                    {channelDashboard.flow_activity.length === 0 ? (
                      <div className="text-sm text-muted-foreground">No flow publish or send history yet.</div>
                    ) : (
                      <div className="space-y-2">
                        {channelDashboard.flow_activity.map((item) => (
                          <div key={`${item.saved_flow_id || item.meta_flow_id || item.flow_name}`} className="rounded-md border p-2">
                            <div className="text-sm font-medium text-foreground">{item.flow_name}</div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              Sends: {item.send_count || 0} · Status: {item.status || 'unknown'}
                            </div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              Last sent: {item.last_sent_at ? formatLogTime(item.last_sent_at) : 'Never'} · Last published: {item.last_published_at ? formatLogTime(item.last_published_at) : 'Never'}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Webhook event logs</CardTitle>
              <CardDescription>
                Recent webhook deliveries captured by WinAssist for the selected connection.
              </CardDescription>
            </div>
            <Button
              variant="outline"
              onClick={() => refreshWebhookEvents(selectedLogConnectionId)}
              disabled={!selectedLogConnectionId || webhookEventsLoading}
            >
              {webhookEventsLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
              Refresh webhook logs
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {!selectedLogConnectionId ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Select a connection above to inspect webhook events.
              </div>
            ) : webhookEventsLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="h-4 w-4 animate-spin" />
                Loading webhook events...
              </div>
            ) : webhookEvents.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No webhook events are available for this connection yet.
              </div>
            ) : (
              <div className="space-y-3">
                {webhookEvents.map((event) => (
                  <div key={event.id} className="rounded-lg border border-border/70 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium text-foreground">{summarizeWebhookEvent(event)}</div>
                        <div className="mt-1 text-xs text-muted-foreground">
                          Event #{event.id} · {formatLogTime(event.created_at)}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">{event.event_type}</Badge>
                        <Badge variant={event.processed ? 'default' : 'outline'}>
                          {event.processed ? 'processed' : 'pending'}
                        </Badge>
                      </div>
                    </div>
                    <div className="mt-3 rounded-md border bg-muted/30 p-3">
                      <pre className="overflow-x-auto whitespace-pre-wrap text-[11px] text-muted-foreground">
                        {formatJsonPreview(event.payload)}
                      </pre>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Message send logs</CardTitle>
              <CardDescription>
                Recent WhatsApp send and delivery activity for the selected connection.
              </CardDescription>
            </div>
            <div className="flex w-full flex-col gap-3 md:w-auto md:flex-row md:items-center">
              <Select value={selectedLogConnectionId} onValueChange={setSelectedLogConnectionId}>
                <SelectTrigger className="w-full md:w-[280px]">
                  <SelectValue placeholder="Select a connection" />
                </SelectTrigger>
                <SelectContent>
                  {connections.map((connection) => (
                    <SelectItem key={connection.id} value={connection.id}>
                      {connection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => refreshMessageLogs(selectedLogConnectionId)}
                disabled={!selectedLogConnectionId || messagesLoading}
              >
                {messagesLoading ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                Refresh logs
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {!selectedLogConnectionId ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                Connect a WhatsApp number first to view send logs.
              </div>
            ) : messagesLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="h-4 w-4 animate-spin" />
                Loading message logs...
              </div>
            ) : messageLogs.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No WhatsApp message logs are available for this connection yet.
              </div>
            ) : (
              <div className="space-y-3">
                {messageLogs.map((item) => {
                  const statusBadge = getStatusBadge(item.status);
                  const directionBadge = getStatusBadge(item.direction);
                  const canRetry = item.direction === 'outbound' && (item.error || ['error', 'failed'].includes(String(item.status || '').toLowerCase()));
                  const retryKey = `retry:${item.id}`;
                  return (
                    <div key={item.id} className="rounded-lg border border-border/70 p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium text-foreground">
                            {summarizeMessageLog(item)}
                          </div>
                          <div className="mt-1 text-xs text-muted-foreground">
                            {formatLogTime(item.created_at)}
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant={directionBadge.variant} className={directionBadge.className}>
                            {item.direction}
                          </Badge>
                          <Badge variant={statusBadge.variant} className={statusBadge.className}>
                            {item.status}
                          </Badge>
                          <Badge variant="outline">
                            {item.message_type}
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-3 grid gap-2 text-xs text-muted-foreground md:grid-cols-2">
                        <div>From: {item.from_number || 'Unknown'}</div>
                        <div>To: {item.to_number || 'Unknown'}</div>
                      </div>
                      {item.error ? (
                        <div className="mt-3 rounded-md border border-red-200 bg-red-50 p-3 text-xs text-red-700">
                          {item.error}
                        </div>
                      ) : null}
                      {canRetry ? (
                        <div className="mt-3 flex justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRetryMessage(item.id)}
                            disabled={messageActionId === retryKey}
                          >
                            {messageActionId === retryKey ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.refresh className="h-4 w-4" />}
                            Retry send
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
