import { useNavigate } from 'react-router-dom';
import { PlatformModulePage } from '../../components/shared/platform-module-page';
import { Icons } from '../../components/ui/icons';

export default function CampaignsPage() {
  const navigate = useNavigate();

  return (
    <PlatformModulePage
      icon={Icons.rocket}
      title="Campaigns"
      description="Create scheduled, triggered, and goal-based conversational campaigns with reusable messaging journeys."
      badge="New module"
      primaryAction={{ label: 'Create Campaign', onClick: () => navigate('/chatflow') }}
      secondaryAction={{ label: 'Template Library', onClick: () => navigate('/templates') }}
      stats={[
        { label: 'Draft Campaigns', value: '0', help: 'Create reusable lifecycle and engagement campaigns.' },
        { label: 'Scheduled', value: '0', help: 'Planned broadcasts and triggered journeys will appear here.' },
        { label: 'Active', value: '0', help: 'Campaigns connected to channels will show live status.' },
        { label: 'Conversions', value: '0%', help: 'Track campaign-to-conversation and campaign-to-goal conversion.' },
      ]}
      sections={[
        {
          title: 'Campaign Types',
          description: 'Start with the high-value use cases missing from the current product.',
          items: [
            { title: 'Broadcast campaigns', description: 'One-time launches for promotions, announcements, and re-engagement.' },
            { title: 'Triggered campaigns', description: 'Send journeys based on customer events, inactivity, or form submissions.' },
            { title: 'Lifecycle automations', description: 'Welcome, nurture, recovery, reminder, and retention flows.' },
          ],
        },
        {
          title: 'UI To Build Next',
          description: 'Recommended responsive pieces for the first campaign release.',
          items: [
            { title: 'Campaign list', description: 'Add search, status filters, schedule column, and performance summary cards.' },
            { title: 'Campaign builder', description: 'Support audience selection, message sequence, timing, and conversion goal setup.' },
            { title: 'Performance tab', description: 'Show sends, delivery, clicks, replies, conversions, and drop-off by step.' },
          ],
        },
      ]}
    />
  );
}
