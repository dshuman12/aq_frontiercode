import { useNavigate, Link } from 'react-router-dom';
import { ProjectList } from '../../components/shared/project-list';
import { initialEdges, initialNodes, useProjects } from '../../hooks/project';
import { useWorkspaces } from '../../hooks/workspace';
import { toast } from '../../hooks/toast';
import { Icons } from '../../components/ui/icons';
import { useEffect } from 'react';
import { Button } from '../../components/ui/button';

function getNextNumberedName(baseName, existingNames) {
  const base = (baseName ?? '').trim();
  if (!base) return 'New Project';

  const escaped = base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`^${escaped}(?:\\s+(\\d+))?$`);

  let maxN = 0;
  for (const name of existingNames || []) {
    const n = (name ?? '').trim();
    const m = n.match(re);
    if (!m) continue;
    const parsed = m[1] ? Number.parseInt(m[1], 10) : 1;
    if (Number.isFinite(parsed)) maxN = Math.max(maxN, parsed);
  }

  return maxN === 0 ? base : `${base} ${maxN + 1}`;
}

export default function ProjectsPage() {
  const navigate = useNavigate();
  const { createProject, setActiveProjectId, projects } = useProjects();
  const { currentWorkspace } = useWorkspaces();
  const canCreate = currentWorkspace?.role !== 'viewer';
  
  useEffect(() => {
    undefined
    setActiveProjectId(-1);
  }, [setActiveProjectId]);
  
  const onCreateProject = async () => {
    const nextName = getNextNumberedName('New Project', (projects || []).map((p) => p?.name));
    const project = await createProject({
      id: -1,
      name: nextName,
      description: 'A new project with sample flow.',
      flow: {
        nodes: initialNodes,
        edges: initialEdges,
      },
    });
    if (!project) {
      toast({ title: 'Failed to create this this project' });
      return;
    }
    undefined
    toast({ title: 'Project created. Now jumping to project page.' });
    navigate(`/projects/${project.id}`);
  };
  
  return (
    <div className="flex flex-col w-full gap-2">
      <div className="flex flex-col items-center justify-center gap-4 text-sm p-2">
        <span className="text-4xl font-bold font-arial p-4">
          Build Agentic Apps
        </span>
        <span className="text-lg">
          Create and manage your AI assistant projects with WinAssist.
        </span>
        {canCreate && (
        <Button size="lg" onClick={onCreateProject}>
          <Icons.project />
          Create New Project
        </Button>
        )}
        <ProjectList />
      </div>
     
    </div>
  );
}

