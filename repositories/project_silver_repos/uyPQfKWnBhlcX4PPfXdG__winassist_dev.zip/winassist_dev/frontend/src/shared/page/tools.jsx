import React from "react";
import { useNavigate } from "react-router-dom";
import { ToolCard } from "../../components/tools/card";
import { useTools } from "../../hooks/tool";
import { toast } from "../../hooks/toast";
import { Icons } from "../../components/ui/icons";
import { Button } from "../../components/ui/button";
import { AppLayout } from "../../components/shared/app-layout";
import { PageHeader } from "../../components/shared/page-header";

const getNextMcpToolName = (tools = []) => {
  const prefix = "mcp_tool";
  const highestIndex = tools.reduce((max, tool) => {
    const match = String(tool?.name || "").trim().toLowerCase().match(/^mcp_tool(\d+)$/);
    if (!match) return max;
    return Math.max(max, Number(match[1] || 0));
  }, 0);
  return `${prefix}${highestIndex + 1}`;
};

const NewToolCard = ({ onCreated, existingTools = [] }) => {
  const { createTool, isCreating } = useTools();

  const handleCreate = async () => {
    const name = getNextMcpToolName(existingTools);
    const tool = await createTool({
      name: name,
      description: "Send hello world message.",
      code: `def ${name}(message: str) -> None:\n\
    '''Send hello world message.'''\n\
    print(message)`,
      variables: [],
      parameters: [],
    });

    if (!tool) {
      toast({ title: "Failed to create tool" });
      return;
    }

    onCreated?.(tool.uuid || tool.id);
  };

  return (
    <Button
      variant="outline"
      onClick={handleCreate}
      className="group flex h-full min-h-[180px] flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border/70 p-4 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/20 hover:bg-muted/30 hover:shadow-md sm:p-5"
    >
      <div className="flex flex-col items-center gap-2">
        {isCreating && <Icons.spinner className="w-8 h-8 animate-spin" />}
        {!isCreating && (
          <Icons.tool className="w-8 h-8 shrink-0 group-hover:scale-125 transform transition duration-700 ease-in-out group-hover:text-primary" />
        )}
        <div className="text-base font-bold">New Tool</div>
      </div>
    </Button>
  );
};

const ToolsPage = () => {
  const navigate = useNavigate();
  const { tools: allTools } = useTools();
  const customTools = allTools.filter((tool) => !tool.is_public);
  const publicTools = allTools.filter((tool) => tool.is_public);

  const handleSelect = (tool) => {
    navigate(`/tools/${tool.uuid || tool.id}`);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-10 px-1 sm:px-0">
        <PageHeader
          title="Tools"
          description="Manage your custom tools"
          icon={Icons.tool}
        />
            {/* Public Tools Section */}
            {publicTools.length > 0 && (
              <section className="space-y-4">
                <div className="space-y-1">
                  <div className="text-lg font-semibold text-foreground">Public Tools</div>
                  <div className="text-sm text-muted-foreground">
                    Pre-built tools available to everyone
                  </div>
                </div>
                <div className="grid gap-4 [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))]">
                  {publicTools.map((tool) => (
                    <ToolCard tool={tool} key={tool.id} onClick={() => handleSelect(tool)} />
                  ))}
                </div>
              </section>
            )}

            {/* Custom Tools Section */}
            <section className="space-y-4">
              <div className="space-y-1">
                <div className="text-lg font-semibold text-foreground">Custom Tools</div>
                <div className="text-sm text-muted-foreground">
                  Create and manage your own custom tools
                </div>
              </div>
              <div className="grid gap-4 [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))]">
                <NewToolCard
                  existingTools={customTools}
                  onCreated={(id) => navigate(`/tools/${id}`)}
                />
                {customTools.map((tool) => (
                  <ToolCard tool={tool} key={tool.id} onClick={() => handleSelect(tool)} />
                ))}
              </div>
            </section>
      </div>
    </AppLayout>
  );
};

export default ToolsPage;
