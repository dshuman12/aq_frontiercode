import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { ReactFlowProvider } from '@xyflow/react';
import { apiRequest } from '../../lib/api-client';
import useWorkspaceStore from '../../store/workspace';
import { toast } from '../../hooks/toast';
import { Editor } from './resize';

// Match node filters used by the normal canvases
const FRONTEND_NODES = [
  'initializer',
  'api',
  'note',
  'text',
  'image',
  'input',
  'calendar',
  'form',
  'document',
  'ocr',
  'delay',
  'assistant',
  'condition',
  'quickreply',
  'container',
  'branch',
  'switch',
  'merge',
];
const BACKEND_NODES = ['initializer', 'conversable', 'groupchat', 'user'];

function safeJsonParse(value) {
  if (typeof value !== 'string') return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function normalizeFlow(rawFlow) {
  const parsed = typeof rawFlow === 'string' ? safeJsonParse(rawFlow) : rawFlow;
  const flow = parsed && typeof parsed === 'object' ? parsed : null;
  const nodes = Array.isArray(flow?.nodes) ? flow.nodes : [];
  const edges = Array.isArray(flow?.edges) ? flow.edges : [];
  return { ...flow, nodes, edges };
}

export default function TemplateCanvasPreviewPage() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const currentWorkspaceId = useWorkspaceStore((s) => s.currentWorkspaceId);

  const [template, setTemplate] = useState(location.state?.template || null);
  const [loading, setLoading] = useState(!location.state?.template);
  const [using, setUsing] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function fetchTemplate() {
      if (template || !id) return;
      setLoading(true);
      try {
        const [backend, frontend] = await Promise.all([
          apiRequest('/templates?project_type=backend&limit=200', {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          }),
          apiRequest('/templates?project_type=frontend&limit=200', {
            method: 'GET',
            includeAuth: true,
            showErrorToast: false,
          }),
        ]);
        const all = [...(backend || []), ...(frontend || [])];
        const found = all.find((t) => String(t?.id) === String(id));
        if (!cancelled) setTemplate(found || null);
      } catch (e) {
        if (!cancelled) {
          toast({
            title: 'Failed to load template',
            description: e?.message || 'Please try again.',
            variant: 'destructive',
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchTemplate();
    return () => {
      cancelled = true;
    };
  }, [id, template]);

  const flow = useMemo(() => {
    // Backend stores full project snapshot under template.project; flow can be a dict or a JSON string
    const raw =
      template?.project?.flow ??
      template?.project?.project?.flow ??
      template?.flow ??
      null;
    return normalizeFlow(raw);
  }, [template]);

  const nodeFilter = template?.project_type === 'backend' ? BACKEND_NODES : FRONTEND_NODES;
  const isBackend = template?.project_type === 'backend';

  const handleUseTemplate = async () => {
    if (!template?.id) return;
    setUsing(true);
    try {
      const body = currentWorkspaceId ? { workspace_id: currentWorkspaceId } : {};
      const newProject = await apiRequest(`/templates/${template.id}/use`, {
        method: 'POST',
        body,
      });
      if (newProject?.id) {
        if (newProject.project_type === 'backend') {
          navigate(`/aiagent/${newProject.id}`, { state: { fromTemplate: true } });
        } else {
          navigate(`/chatflow/${newProject.id}`, { state: { fromTemplate: true } });
        }
        toast({
          title: 'Project created',
          description: `"${newProject.name || template.name || 'Template'}" was created from the template.`,
        });
      }
    } catch (e) {
      toast({
        title: 'Could not use template',
        description: e?.message || 'Something went wrong. Try again.',
        variant: 'destructive',
      });
    } finally {
      setUsing(false);
    }
  };

  if (loading) {
    return (
      <div className="h-screen overflow-hidden flex items-center justify-center text-muted-foreground">
        Loading template...
      </div>
    );
  }

  if (!template) {
    return (
      <div className="h-screen overflow-hidden flex flex-col items-center justify-center gap-3 text-muted-foreground">
        <div>Template not found.</div>
        <button
          type="button"
          className="text-primary hover:underline"
          onClick={() => navigate('/templates')}
        >
          Back to Templates
        </button>
      </div>
    );
  }

  // Full-screen editor, same feel as normal project pages.
  // No project is created/saved because projectId is -1.
  return (
    <div className="h-screen overflow-hidden">
      <ReactFlowProvider key="template-canvas-preview-reactflow">
        <Editor
          projectId={-1}
          nodeFilter={nodeFilter}
          showChat={isBackend}
          showConfigConditionally={!isBackend}
          showCodeTab={true}
          codeViewType={isBackend ? 'python' : 'javascript'}
          allowTemplatePublish={false}
          initialFlow={flow}
        />
      </ReactFlowProvider>

      {/* Floating action: Use Template (explicit create) */}
      <div className="pointer-events-none fixed bottom-5 right-5 z-50">
        <div className="pointer-events-auto rounded-2xl border border-border/70 bg-background/95 shadow-lg backdrop-blur px-3 py-2 flex items-center gap-2">
          <button
            type="button"
            className="text-sm text-muted-foreground hover:text-foreground"
            onClick={() => navigate('/templates')}
            disabled={using}
          >
            Back
          </button>
          <div className="h-6 w-px bg-border/70" />
          <button
            type="button"
            className="inline-flex items-center justify-center rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
            onClick={handleUseTemplate}
            disabled={using}
            title="Create a project from this template"
          >
            {using ? 'Creating…' : 'Use template'}
          </button>
        </div>
      </div>
    </div>
  );
}

