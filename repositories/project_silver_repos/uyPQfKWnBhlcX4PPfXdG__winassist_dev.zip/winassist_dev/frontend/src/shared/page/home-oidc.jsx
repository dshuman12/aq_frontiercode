import { useState } from 'react';
import { useAuth } from 'react-oidc-context';
import { toast } from '../../hooks/toast';
import { buildOidcSigninArgs } from '../../common/oidc/navigation';
import HomePage from './home';

export default function HomePageOidc() {
  const auth = useAuth();
  const [redirecting, setRedirecting] = useState(false);

  const safeRedirect = async (options) => {
    try {
      setRedirecting(true);
      await auth.signinRedirect(options);
    } catch (err) {
      setRedirecting(false);
      toast({
        title: 'Keycloak redirect failed',
        description: err?.message || 'Could not redirect to Keycloak',
        variant: 'destructive',
      });
    }
  };

  return (
    <HomePage
      disableAuthButtons={redirecting}
      // Force Keycloak to show login screen (avoid auto-SSO after local logout).
      onLogin={() =>
        safeRedirect(buildOidcSigninArgs({ prompt: 'login' }))
      }
      onGetStarted={() =>
        safeRedirect(buildOidcSigninArgs({ prompt: 'create' }))
      }
    />
  );
}

