import React, { useCallback, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { EditableText } from '../../components/ui/editabletext';
import CodeEditor from '../../components/tools/code';

import { ParameterList } from '../../components/tools/parameterlist';
import { useTool } from '../../hooks/tool';
import { useToolSettings } from '../../hooks/toolsettings';
import useUserStore from '../../store/user';

import { Label } from '../../components/ui/label';
import { Switch } from '../../components/ui/switch';
import { Card, CardTitle, CardContent, CardHeader } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Icons } from '../../components/ui/icons';
import { cn } from '../../lib/utils';

/** Normalize ids for comparison (UUID strings, sub claims, etc.). */
function normalizeId(value) {
  if (value === undefined || value === null) return '';
  return String(value).toLowerCase().replace(/-/g, '');
}

function currentUserIdCandidates(user) {
  if (!user || typeof user !== 'object') return [];
  const raw = [user.id, user.sub, user.user_id, user.userId].filter(
    (v) => v !== undefined && v !== null && String(v).trim() !== ''
  );
  return [...new Set(raw.map(normalizeId))].filter(Boolean);
}

export default function Page() {
  const navigate = useNavigate();
  const params = useParams();
  const id = params?.id;
  const user = useUserStore((state) => state.user);
  const { settings } = useToolSettings();

  if (!id) return <div>Tool ID is missing</div>;

  const toolId = /^\d+$/.test(id) ? parseInt(id, 10) : id;
  const { tool, updateTool, isLoading, isUpdating } = useTool(toolId);

  const isOwner = useMemo(() => {
    if (!tool) return false;
    // Private tools are only returned for the owning user (see backend fetch_tools / fetch_tool).
    if (!tool.is_public) return true;
    const toolOwner = normalizeId(tool.user_id);
    if (!toolOwner) return false;
    return currentUserIdCandidates(user).some((id) => id === toolOwner);
  }, [tool, user]);
  const displayVariables = useMemo(() => {
    if (!tool) return [];
    const saved = settings[tool.id]?.variables;
    return Array.isArray(saved) ? saved : (tool.variables ?? []);
  }, [tool, settings]);

  const setToolData = useCallback(
    async (key, value) => {
      const savedTool = await updateTool({ [key]: value });
      if (savedTool && String(savedTool.id) !== String(toolId) && String(savedTool.uuid || '') !== String(toolId)) {
        navigate(`/tools/${savedTool.uuid || savedTool.id}`, {
          replace: true,
        });
      }
    },
    [navigate, toolId, updateTool]
  );

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <Icons.spinner className="w-8 h-8 animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading tool...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!tool) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <p className="text-muted-foreground">Tool not found</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto flex flex-col gap-4">
        <PageHeader
          title={tool.name || 'Tool'}
          description={tool.description || 'Edit tool details and code'}
          leftSlot={
            <Button variant="outline" size="sm" onClick={() => navigate('/tools')} className="shrink-0">
              <Icons.chevronLeft className="h-4 w-4 mr-1.5" />
              Back
            </Button>
          }
          actions={
            <div className="flex items-center gap-3 text-sm">
              <div className="flex flex-col">
                <Label htmlFor="is_public" className="cursor-pointer text-xs text-muted-foreground">
                  Visibility
                </Label>
                <div
                  className="flex items-center gap-2 mt-1"
                  title={
                    !isOwner
                      ? 'Only the owner can change visibility for tools shared from the public library.'
                      : undefined
                  }
                >
                  <span
                    className={cn(
                      'text-sm font-medium transition-colors',
                      !tool.is_public ? 'text-foreground' : 'text-foreground/50'
                    )}
                  >
                    Private
                  </span>
                  <Switch
                    id="is_public"
                    checked={!!tool.is_public}
                    onCheckedChange={(checked) => setToolData('is_public', checked)}
                    disabled={isUpdating || !isOwner}
                    className="data-[state=checked]:bg-primary"
                  />
                  <span
                    className={cn(
                      'text-sm font-medium transition-colors',
                      tool.is_public ? 'text-foreground' : 'text-foreground/50'
                    )}
                  >
                    Public
                  </span>
                </div>
                {tool.is_public ? (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Your public tool can be switched back to private any time. Other users still get a private copy if they edit a public tool they do not own.
                  </p>
                ) : (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Private tools are visible only to you until you turn them public.
                  </p>
                )}
              </div>
            </div>
          }
        />
            <Card className="flex flex-col gap-2 p-4">
              <div className="flex flex-col gap-1">
                <EditableText
                  value={tool.name ?? ''}
                  onChange={(text) => setToolData('name', text)}
                  className="!text-lg !font-bold"
                />
                <EditableText
                  value={tool.description ?? ''}
                  onChange={(text) => setToolData('description', text)}
                  className="!text-sm !font-normal text-muted-foreground"
                />
              </div>
            </Card>

            <ParameterList toolId={toolId} toolParameters={displayVariables} className="shrink-0" />

            <Card className="flex flex-col">
              <CardHeader>
                <CardTitle>Code</CardTitle>
              </CardHeader>
              <CardContent className="flex-1">
                <CodeEditor toolId={toolId} className="min-h-[500px]" />
            </CardContent>
          </Card>
        </div>
    </AppLayout>
  );
}
