import React, { useState, useEffect, useCallback, useRef } from "react";
import {
    ResizableHandle,
    ResizablePanel,
    ResizablePanelGroup,
} from '../../components/ui/resize';
  import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tab';
  import { ChatPane } from '../../components/shared/chatpane';
  import { FlowCanvas } from "../canvas";
  import { Icons } from "../../components/ui/icons";
  import { useChats } from '../../hooks/chat';
  import { useEdges, useNodes, useReactFlow, useStoreApi } from '@xyflow/react';
  import { FlowConfig } from "../../components/shared/config";
  import CodeView from '../../components/shared/codeview';
  import PythonCodeView from '../../components/shared/pythoncodeview';
import { useProject } from '../../hooks/project';
import { generateProjectCode } from '../../utils/codegen';
import { Button } from '../../components/ui/button';
import { toast } from '../../hooks/toast';
import { useNavigate } from 'react-router-dom';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../../components/ui/dialog';

const TEMPLATE_CATEGORIES = ['Hospital', 'Healthcare', 'Student', 'Sales', 'Marketing'];
  export const Editor = ({
    projectId,
    nodeFilter,
    showChat = true,
    showConfigConditionally = false,
    showCodeTab = false,
    codeViewType = 'javascript',
    allowTemplatePublish = true,
    initialFlow,
  }) => {
    const [mode, setMode] = useState('flow');
    const { chats } = useChats();
    const [flowNodes, setFlowNodes] = useState([]);
    const [flowEdges, setFlowEdges] = useState([]);
    const [isRightPanelVisible, setIsRightPanelVisible] = useState(true);
    const [rightPanelTab, setRightPanelTab] = useState(showChat ? 'chat' : 'config');
    const [isSaving, setIsSaving] = useState(false);
    const [isPublished, setIsPublished] = useState(false);
    const [publishDialogOpen, setPublishDialogOpen] = useState(false);
    const [publishName, setPublishName] = useState('');
    const [publishDescription, setPublishDescription] = useState('');
    const [publishCategory, setPublishCategory] = useState('Healthcare');
    const { project, updateProject, isUpdating } = useProject(projectId);
    const navigate = useNavigate();
    
    const handleNodesEdgesChange = useCallback((nodes, edges) => {
      setFlowNodes(nodes);
      setFlowEdges(edges);
    }, []);
    
    // Try multiple methods to get nodes/edges as fallback
    const store = useStoreApi();
    const reactFlowInstance = useReactFlow();
    const hookNodes = useNodes();
    const hookEdges = useEdges();
    const storeNodes = store.getState().nodeInternals ? Array.from(store.getState().nodeInternals.values()) : [];
    const storeEdges = store.getState().edges || [];
    const instanceNodes = reactFlowInstance ? reactFlowInstance.getNodes() : [];
    const instanceEdges = reactFlowInstance ? reactFlowInstance.getEdges() : [];
    // Use flowNodes/flowEdges from FlowCanvas callback first, then fallback to other methods
    const nodes = flowNodes.length > 0 ? flowNodes : (instanceNodes.length > 0 ? instanceNodes : (storeNodes.length > 0 ? storeNodes : hookNodes));
    const edges = flowEdges.length > 0 ? flowEdges : (instanceEdges.length > 0 ? instanceEdges : (storeEdges.length > 0 ? storeEdges : hookEdges));
    const selectedNode = nodes.find((node) => node.selected);
    const selectedEdge = edges.find((edge) => edge.selected);
    const [activeChatId, setActiveChatId] = useState(-1);
    const codeViewRef = useRef(null);
    useEffect(() => {
      const existingChat = chats.findLast(
        (chat) => chat.from_project === projectId
      );
      setActiveChatId(existingChat?.id || -1);
    }, [projectId, chats]);
  
    const handleModeChange = (mode) => {
      setMode(mode);
    };

    useEffect(() => {
      if (!project) return;
      setPublishName(project.name || '');
      setPublishDescription(project.description || '');
    }, [project?.name, project?.description]);

    const handlePublishTemplate = useCallback(async () => {
      if (!projectId || projectId === -1 || !project) return;
      try {
        const { apiRequest } = await import('../../lib/api-client');
        const result = await apiRequest(`/templates/projects/${projectId}/publish`, {
          method: 'POST',
          body: {
            name: publishName?.trim() || project.name,
            description: publishDescription?.trim() || project.description,
            category: publishCategory,
          },
        });
        setIsPublished(true);
        setPublishDialogOpen(false);
        toast({
          title: result?.created_at === result?.updated_at ? 'Template Published' : 'Template Updated',
          description: `This project is published under the "${publishCategory}" template category.`,
        });
      } catch (e) {
        console.error('Failed to publish template', e);
        toast({
          title: 'Publish failed',
          description:
            e?.message ||
            'Could not publish this project as a template. You must be workspace owner/admin or project owner.',
          variant: 'destructive',
        });
      }
    }, [projectId, project, publishCategory, publishDescription, publishName]);

    // Manual save function
    const handleSaveProject = useCallback(async () => {
      if (projectId === -1 || isSaving || isUpdating) return;
      
      setIsSaving(true);
      try {
        const flow = {
          nodes: nodes,
          edges: edges,
        };
        // Include saved widget settings so Test Widget uses them (from Code tab modal)
        const widgetSettings = codeViewRef.current?.getWidgetSettings?.();
        if (widgetSettings && typeof widgetSettings === 'object') {
          flow.widget_settings = widgetSettings;
        } else if (project?.flow?.widget_settings) {
          flow.widget_settings = project.flow.widget_settings;
        }
        // AI Agent (backend): embed generated Python in flow so chat/API runs the real agent, not a placeholder.
        if (project?.project_type === 'backend') {
          try {
            const payload = {
              ...project,
              flow,
            };
            const py = await generateProjectCode(payload);
            if (py && typeof py === 'string' && py.trim()) {
              flow.generated_python = py;
            }
          } catch (e) {
            console.warn('Save: could not refresh generated_python; chat may rely on server codegen.', e);
            if (project?.flow?.generated_python) {
              flow.generated_python = project.flow.generated_python;
            }
          }
        }
        // Manual save: force revalidation so other screens (projects list) reflect latest updated_at
        await updateProject({ flow }, { skipRevalidate: false });
        
        toast({
          title: 'Project Saved',
          description: 'Your project has been saved successfully. API key generated if not present.',
        });
      } catch (error) {
        console.error('Failed to save project:', error);
        toast({
          title: 'Save Failed',
          description: 'Failed to save project. Please try again.',
          variant: 'destructive',
        });
      } finally {
        setIsSaving(false);
      }
    }, [projectId, nodes, edges, updateProject, isSaving, isUpdating, project?.flow?.widget_settings, project?.project_type, project?.flow?.generated_python, project]);

    const shouldShowConfig = showConfigConditionally ? (selectedNode || selectedEdge) : true;
    const showRightPanel = isRightPanelVisible && (!showConfigConditionally || shouldShowConfig);
    
    // When a node or edge is selected: show right panel and switch to Properties tab
    useEffect(() => {
      if (selectedNode || selectedEdge) {
        if (showConfigConditionally) setIsRightPanelVisible(true);
        setRightPanelTab('config');
      }
    }, [selectedNode, selectedEdge, showConfigConditionally]);
  
    return (
        <div className="flex h-screen w-screen overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="flex h-full">
          {/* -------- Flow Panel -------- */}
          <ResizablePanel defaultSize={50} minSize={30}>
            <Tabs defaultValue="flow" className="flex flex-col h-full ">
              <TabsList className="flex h-auto flex-wrap items-center gap-2 border-b rounded-none px-2 py-2">
                <TabsTrigger value="flow" className="flex items-center gap-2">
                  <Icons.project className="w-4 h-4" />
                  <span className="hidden md:block text-sm">Flow</span>
                </TabsTrigger>
                {showCodeTab && (
                  <TabsTrigger value="code" className="flex items-center gap-2">
                    <Icons.code className="w-4 h-4" />
                    <span className="hidden md:block text-sm">Code</span>
                  </TabsTrigger>
                )}
                {/* Save button always; publish button only when allowed (not opened from Templates gallery) */}
                {projectId !== -1 && (
                  <div className="flex flex-wrap items-center gap-2 sm:ml-auto">
                    <Button
                      variant="default"
                      size="sm"
                      onClick={handleSaveProject}
                      disabled={isSaving || isUpdating}
                      className="ml-4 gap-2 bg-green-600 hover:bg-green-700 text-white"
                      title="Save Project"
                    >
                      {isSaving || isUpdating ? (
                        <>
                          <Icons.spinner className="w-4 h-4 animate-spin" />
                          <span className="hidden md:inline">Saving...</span>
                        </>
                      ) : (
                        <>
                          <Icons.save className="w-4 h-4" />
                          <span className="hidden md:inline">Save</span>
                        </>
                      )}
                    </Button>
                    {allowTemplatePublish && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPublishDialogOpen(true)}
                        className="gap-2"
                        title={
                          isPublished
                            ? 'Update this published template'
                            : 'Share this project in the Templates gallery so others can use it'
                        }
                      >
                        <Icons.package className="w-4 h-4" />
                        <span className="hidden md:inline">
                          {isPublished ? 'Update published template' : 'Publish as template'}
                        </span>
                      </Button>
                    )}
                    {/* Test Widget button - only for frontend projects */}
                    {project && project.project_type === 'frontend' && project.flow && project.flow.nodes && project.flow.nodes.length > 0 && (
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => {
                          navigate(`/widget-preview/${projectId}`);
                        }}
                        className="ml-2 gap-2 bg-blue-600 hover:bg-blue-700 text-white"
                        title="Test Widget"
                      >
                        <Icons.externalLink className="w-4 h-4" />
                        <span className="hidden md:inline">Test Widget</span>
                      </Button>
                    )}
                  </div>
                )}
                {/* Buttons to reopen panel when closed. AI Agent: Chat + Properties; Chat Flow: only Chat (Properties open on node/edge click) */}
                {!showRightPanel && (
                  <div className="ml-auto flex flex-wrap gap-1">
                    {showChat && (
                      <button
                        onClick={() => setIsRightPanelVisible(true)}
                        className="px-2 py-1 text-xs hover:bg-muted rounded-sm transition-colors flex items-center gap-1"
                        title="Show Chat"
                      >
                        <Icons.chat className="w-3 h-3" />
                        <span className="hidden md:inline">Chat</span>
                      </button>
                    )}
                    {!showConfigConditionally && (
                      <button
                        onClick={() => {
                          setIsRightPanelVisible(true);
                          setRightPanelTab('config');
                        }}
                        className="px-2 py-1 text-xs hover:bg-muted rounded-sm transition-colors flex items-center gap-1"
                        title="Show Properties"
                      >
                        <Icons.config className="w-3 h-3" />
                        <span className="hidden md:inline">Properties</span>
                      </button>
                    )}
                  </div>
                )}
              </TabsList>
  
              <TabsContent value="flow" className="flex-1 overflow-auto mt-0">
                <FlowCanvas 
                  projectId={projectId} 
                  onModeChange={handleModeChange} 
                  nodeFilter={nodeFilter} 
                  onNodesEdgesChange={handleNodesEdgesChange}
                  initialFlow={initialFlow}
                  onCanvasClick={() => {
                    // Close panel when clicking on canvas
                    setIsRightPanelVisible(false);
                  }}
                />
              </TabsContent>
              
              {showCodeTab && (
                <TabsContent value="code" className="flex-1 overflow-auto mt-0">
                  {codeViewType === 'python' ? (
                    <PythonCodeView projectId={projectId} />
                  ) : (
                    <CodeView
                      ref={codeViewRef}
                      nodes={nodes}
                      edges={edges}
                      projectId={projectId}
                      initialWidgetSettings={project?.flow?.widget_settings}
                      onWidgetSettingsSave={(settings) => {
                        if (projectId == null || projectId === -1) return;
                        updateProject({
                          flow: {
                            ...project?.flow,
                            nodes,
                            edges,
                            widget_settings: settings,
                          },
                        }, { skipRevalidate: true });
                        toast({
                          title: 'Widget settings saved',
                          description: 'Your widget appearance is saved. Click Test Widget to see it.',
                        });
                      }}
                    />
                  )}
                </TabsContent>
              )}
            </Tabs>
          </ResizablePanel>

          {/* -------- Chat/Config Panel -------- */}
          {showRightPanel && (
            <>
              <ResizableHandle withHandle />
              <ResizablePanel defaultSize={24} minSize={18} maxSize={34} className="properties-panel min-w-0">
                <Tabs value={rightPanelTab} onValueChange={setRightPanelTab} className="flex flex-col h-full">
                  <TabsList className="flex h-auto flex-wrap items-center gap-2 border-b rounded-none px-2 py-2">
                    {showChat && (
                      <TabsTrigger value="chat" className="flex items-center gap-2">
                        <Icons.chat className="w-4 h-4" />
                        <span className="hidden md:block text-sm">Chat</span>
                      </TabsTrigger>
                    )}
                    <TabsTrigger value="config" className="flex items-center gap-2">
                      <Icons.config className="w-4 h-4" />
                      <span className="hidden md:block text-sm">Properties</span>
                    </TabsTrigger>
                    <button
                      onClick={() => setIsRightPanelVisible(false)}
                      className="ml-auto flex h-6 w-6 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                      aria-label="Close panel"
                      title="Close panel"
                    >
                      <span className="text-lg leading-none">×</span>
                    </button>
                  </TabsList>
                  <TabsContent value="config" className="mt-0 flex-1 overflow-auto overflow-x-hidden">
                    <div className="word-wrap min-h-full w-full overflow-x-hidden rounded-lg border border-border bg-card p-4 shadow-sm">
                      <FlowConfig
                        projectId={projectId}
                        project={project}
                        nodeId={selectedNode?.id}
                        edgeId={selectedEdge?.id}
                      />
                    </div>
                  </TabsContent>
                  {showChat && (
                    <TabsContent value="chat" className="flex-1 overflow-auto mt-0">
                      <ChatPane 
                        projectId={projectId} 
                        chatId={activeChatId}
                        onChatIdChange={setActiveChatId}
                      />
                    </TabsContent>
                  )}
                </Tabs>
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>
        <Dialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{isPublished ? 'Update published template' : 'Publish as template'}</DialogTitle>
              <DialogDescription>
                Choose the template details and category. Republishing updates the same template instead of creating a new one.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">Template name</Label>
                <Input
                  id="template-name"
                  value={publishName}
                  onChange={(e) => setPublishName(e.target.value)}
                  placeholder="Template name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-description">Description</Label>
                <Textarea
                  id="template-description"
                  value={publishDescription}
                  onChange={(e) => setPublishDescription(e.target.value)}
                  rows={4}
                  placeholder="Describe the use case and business context"
                />
              </div>
              <div className="space-y-2">
                <Label>Template category</Label>
                <Select value={publishCategory} onValueChange={setPublishCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose category" />
                  </SelectTrigger>
                  <SelectContent>
                    {TEMPLATE_CATEGORIES.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPublishDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handlePublishTemplate} disabled={!publishName.trim()}>
                {isPublished ? 'Update template' : 'Publish template'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  };
  