import { ReactFlowProvider } from '@xyflow/react';
import { Editor } from './resize';

// Backend nodes: initializer, conversable, groupchat, user
const BACKEND_NODES = ['initializer', 'conversable', 'groupchat', 'user'];

export default function NoCodeBackendCanvas() {
  return (
    <ReactFlowProvider key="nocode-backend-reactflow">
      <Editor 
        projectId={-1} 
        nodeFilter={BACKEND_NODES}
        showChat={true}
        showConfigConditionally={false}
      />
    </ReactFlowProvider>
  );
}

