import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { getBackendUrl } from '../../lib/api-client';

/**
 * Public widget viewer page: /widget/:projectId
 * Fetches the saved widget script URL (no auth) and loads the script so anyone with the link can use the bot.
 */
export default function WidgetViewerPage() {
  const { projectId } = useParams();
  const [scriptUrl, setScriptUrl] = useState(null);
  const [viewerConfig, setViewerConfig] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const containerRef = useRef(null);
  const scriptRef = useRef(null);

  useEffect(() => {
    if (!projectId) {
      setError('Missing project ID');
      setLoading(false);
      return;
    }

    const backend = getBackendUrl().replace(/\/$/, '');
    // Use viewer config endpoint so we get the saved script URL and backend URL without exposing secrets.
    const url = `${backend}/project-analytics/public/widget-viewer-config/${projectId}`;

    fetch(url)
      .then((res) => {
        if (!res.ok) {
          if (res.status === 404) throw new Error('Widget not published yet. Save it from Test Widget first.');
          throw new Error(res.statusText || 'Failed to load widget');
        }
        return res.json();
      })
      .then((data) => {
        setScriptUrl(data.script_url);
        setViewerConfig(data);
        setError(null);
      })
      .catch((err) => {
        setError(err.message || 'Failed to load widget');
        setScriptUrl(null);
        setViewerConfig(null);
      })
      .finally(() => setLoading(false));
  }, [projectId]);

  // Load script when we have scriptUrl and a container
  useEffect(() => {
    if (!scriptUrl || !containerRef.current) return;

    const container = containerRef.current;
    container.innerHTML = '';

    const wrapper = document.createElement('div');
    wrapper.className = 'min-h-[400px] p-6';
    wrapper.innerHTML = `
      <div class="max-w-2xl mx-auto rounded-lg border border-border/70 bg-card p-6 shadow">
        <h1 class="mb-2 text-xl font-semibold text-card-foreground">Chat with us</h1>
        <p class="text-muted-foreground">The chatbot widget will appear in the corner of this page.</p>
      </div>
    `;
    container.appendChild(wrapper);

    const scriptEl = document.createElement('script');
    scriptEl.src = scriptUrl;
    scriptEl.async = true;
    // Set only non-secret data attributes for the public widget runtime.
    if (viewerConfig) {
      if (viewerConfig.project_id) scriptEl.setAttribute('data-project-id', viewerConfig.project_id);
      if (viewerConfig.project_id) scriptEl.setAttribute('data-analytics-project-id', viewerConfig.project_id);
      if (viewerConfig.api_key) scriptEl.setAttribute('data-api-key', viewerConfig.api_key);
      if (viewerConfig.backend_url) scriptEl.setAttribute('data-api-url', viewerConfig.backend_url);
    }
    scriptEl.onerror = () => setError('Failed to load widget script');
    if (scriptRef.current?.parentNode) scriptRef.current.remove();
    document.head.appendChild(scriptEl);
    scriptRef.current = scriptEl;

    return () => {
      if (scriptRef.current?.parentNode) scriptRef.current.remove();
      scriptRef.current = null;
    };
  }, [scriptUrl, viewerConfig]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-app">
        <p className="text-muted-foreground">Loading widget...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-app">
        <div className="max-w-md px-4 text-center">
          <p className="font-medium text-destructive">{error}</p>
          <p className="mt-2 text-sm text-muted-foreground">
            If you are the bot owner, open Test Widget for this project and click to generate & save the widget first.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-app text-foreground">
      <div ref={containerRef} className="w-full" />
    </div>
  );
}
