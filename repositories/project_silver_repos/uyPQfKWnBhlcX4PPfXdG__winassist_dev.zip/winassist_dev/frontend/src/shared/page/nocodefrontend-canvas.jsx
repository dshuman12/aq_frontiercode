import { useLocation, useParams } from 'react-router-dom';
import { ReactFlowProvider } from '@xyflow/react';
import { useProjects } from '../../hooks/project';
import { useEffect } from 'react';
import { Editor } from './resize';

// Frontend nodes allowed in the canvas node picker
const FRONTEND_NODES = [
  'initializer',
  'api',
  'note',
  'text',
  'image',
  'input',
  'calendar',
  'form',
  'document',
  'ocr',
  'delay',
  'assistant',
  'condition',
  'quickreply',
  'container',
  'branch',
  'switch',
  'merge',
];

export default function NoCodeFrontendCanvas() {
  const { id } = useParams();
  const projectId = id; // UUID is a string, no need to parse
  const location = useLocation();
  const { projects, isLoading, activeProjectId, setActiveProjectId } = useProjects();
  
  useEffect(() => {
    if (projectId !== activeProjectId) {
      setActiveProjectId(projectId);
    }
  }, [projectId, activeProjectId, setActiveProjectId]);

  if (!isLoading && !projects.find((project) => project.id === projectId)) {
    return <p>not found</p>;
  }
  
  return (
    <div className="h-screen overflow-hidden">
      <ReactFlowProvider key="nocode-frontend-reactflow">
        <Editor 
          projectId={projectId} 
          nodeFilter={FRONTEND_NODES}
          showChat={false}
          showConfigConditionally={true}
          showCodeTab={true}
          allowTemplatePublish={!location.state?.fromTemplate}
        />
      </ReactFlowProvider>
    </div>
  );
}

