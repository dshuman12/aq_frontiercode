import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Icons } from '../../components/ui/icons';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Textarea } from '../../components/ui/textarea';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { apiRequest } from '../../lib/api-client';
import { useToast } from '../../hooks/toast';

const supportScope = [
  {
    title: 'Build',
    description: 'AI Agent, Chat Flow, tools, prompts, intents, entities, and guardrails.',
    icon: Icons.sparkles,
    accent: 'from-primary/15 to-primary/5',
  },
  {
    title: 'Ground',
    description: 'Knowledge Base uploads, collections, bot bindings, and retrieval tests.',
    icon: Icons.docs,
    accent: 'from-emerald-500/15 to-emerald-500/5',
  },
  {
    title: 'Launch',
    description: 'Widget preview, WhatsApp setup, Publish Center, templates, and governance.',
    icon: Icons.rocket,
    accent: 'from-blue-500/15 to-blue-500/5',
  },
  {
    title: 'Improve',
    description: 'Analytics, wrong-answer diagnosis, evaluation checks, and release safety.',
    icon: Icons.circleGauge,
    accent: 'from-amber-500/15 to-amber-500/5',
  },
];

const moduleLinks = [
  { label: 'AI Agent', to: '/aiagent', icon: Icons.agent },
  { label: 'Chat Flow', to: '/chatflow', icon: Icons.chat },
  { label: 'Knowledge Base', to: '/knowledge-base', icon: Icons.docs },
  { label: 'Publish Center', to: '/publish-center', icon: Icons.share },
  { label: 'WhatsApp Setup', to: '/integrations/whatsapp', icon: Icons.phone },
  { label: 'Analytics', to: '/project-dashboard', icon: Icons.circleGauge },
];

const confidenceStyles = {
  high: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  medium: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  low: 'border-destructive/30 bg-destructive/10 text-destructive',
};

function formatIntent(intent) {
  return String(intent || 'feature_overview').replace(/_/g, ' ');
}

function responseLines(answer) {
  return String(answer || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);
}

export default function HelpSupportPage() {
  const { toast } = useToast();
  const [query, setQuery] = useState('');
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const promptGroups = useMemo(
    () => [
      {
        label: 'Build',
        prompts: [
          'How can I create AI agent?',
          'What is the difference between AI Agent and Chat Flow?',
          'How do I connect tools to an AI Agent?',
        ],
      },
      {
        label: 'Knowledge',
        prompts: [
          'How do I make the bot answer from my documents?',
          'Give me a step-by-step retrieval test guide.',
          'My bot answers from the wrong document. How do I fix it?',
        ],
      },
      {
        label: 'Launch',
        prompts: [
          'How do I publish a bot?',
          'How do I connect WhatsApp?',
          'My bot works in UI but not WhatsApp. What should I check?',
        ],
      },
    ],
    []
  );

  const handleAsk = async () => {
    const trimmedQuery = query.trim();
    if (!trimmedQuery) {
      toast({
        title: 'Question required',
        description: 'Type a question before asking the support assistant.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    try {
      const response = await apiRequest('/support-assistant/ask', {
        method: 'POST',
        body: { query: trimmedQuery },
        showErrorToast: false,
      });
      setHistory((current) => [
        {
          query: trimmedQuery,
          answer: response?.answer || 'No answer available.',
          confidence: response?.confidence || 'unknown',
          intent: response?.intent || 'feature_overview',
          references: Array.isArray(response?.references) ? response.references : [],
        },
        ...current,
      ]);
      setQuery('');
    } catch (error) {
      toast({
        title: 'Assistant request failed',
        description: error instanceof Error ? error.message : 'Request failed',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <PageHeader
          title="Help / Support Assistant"
          description="Ask anything about WinAssist features, workflows, publishing, integrations, and troubleshooting. Answers are grounded in the platform knowledge base."
          icon={Icons.help}
        />

        <Card className="border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/10">
          <CardContent className="grid gap-6 p-6 lg:grid-cols-[1.3fr_0.7fr] lg:items-center">
            <div className="space-y-4">
              <Badge variant="secondary" className="w-fit gap-1">
                <Icons.sparkles className="h-3.5 w-3.5" />
                Platform-grounded assistant
              </Badge>
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">
                  Get guided answers for building, launching, and improving WinAssist bots.
                </h2>
                <p className="max-w-3xl text-sm leading-6 text-muted-foreground">
                  The assistant searches the platform manual for exact workflows, module responsibilities,
                  configuration checks, and troubleshooting steps across AI Agent, Chat Flow, Knowledge Base,
                  WhatsApp, Publish Center, and analytics.
                </p>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              <div className="rounded-xl border bg-background/80 p-4 shadow-sm">
                <div className="text-sm font-medium">Best for</div>
                <div className="mt-2 text-xs leading-5 text-muted-foreground">
                  How-to steps, product navigation, launch checklists, wrong-answer debugging, and module comparisons.
                </div>
              </div>
              <div className="rounded-xl border bg-background/80 p-4 shadow-sm">
                <div className="text-sm font-medium">Source</div>
                <div className="mt-2 text-xs leading-5 text-muted-foreground">
                  `docs/platform-assistant/BOT_FAQ.md`
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {supportScope.map((item) => {
            const Icon = item.icon;
            return (
              <Card key={item.title} className={`bg-gradient-to-br ${item.accent}`}>
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className="rounded-xl bg-background/80 p-2 shadow-sm">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold">{item.title}</div>
                      <p className="mt-1 text-sm leading-5 text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Icons.chat className="h-5 w-5 text-primary" />
                Ask The Platform Assistant
              </CardTitle>
              <CardDescription>
                Describe what you are trying to build or what is failing. Ask with module names for the most precise answer.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <Textarea
                rows={6}
                placeholder="Example: My bot is replying from the wrong document. How do I diagnose and fix retrieval?"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                onKeyDown={(event) => {
                  if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
                    handleAsk();
                  }
                }}
                className="resize-none text-sm leading-6"
              />
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-muted-foreground">
                  Tip: press Ctrl + Enter to ask.
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setQuery('')} disabled={!query || isLoading}>
                    Clear
                  </Button>
                  <Button onClick={handleAsk} disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Icons.spinner className="h-4 w-4 animate-spin" />
                        Thinking...
                      </>
                    ) : (
                      <>
                        <Icons.send className="h-4 w-4" />
                        Ask Assistant
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Guided Prompts</CardTitle>
                <CardDescription>Start with a platform-aware question.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {promptGroups.map((group) => (
                  <div key={group.label} className="space-y-2">
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      {group.label}
                    </div>
                    <div className="flex flex-col gap-2">
                      {group.prompts.map((prompt) => (
                        <Button
                          key={prompt}
                          variant="outline"
                          size="sm"
                          className="h-auto justify-start whitespace-normal py-2 text-left leading-5"
                          onClick={() => setQuery(prompt)}
                        >
                          {prompt}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Open Platform Areas</CardTitle>
                <CardDescription>Jump to the module mentioned in an answer.</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-1">
                {moduleLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button key={item.to} asChild variant="ghost" className="justify-start">
                      <Link to={item.to}>
                        <Icon className="h-4 w-4" />
                        {item.label}
                      </Link>
                    </Button>
                  );
                })}
              </CardContent>
            </Card>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <CardTitle>Responses</CardTitle>
              <CardDescription>
                Recent assistant responses with confidence, intent, and documentation references.
              </CardDescription>
            </div>
            {history.length > 0 ? (
              <Button variant="outline" size="sm" onClick={() => setHistory([])}>
                Clear History
              </Button>
            ) : null}
          </CardHeader>
          <CardContent className="space-y-4">
            {history.length === 0 ? (
              <div className="rounded-xl border border-dashed bg-muted/20 p-8 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Icons.question className="h-5 w-5 text-primary" />
                </div>
                <div className="mt-4 font-medium">Ask your first platform question</div>
                <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">
                  Try a workflow question like creating an AI Agent, publishing a bot, connecting WhatsApp,
                  or fixing wrong document answers.
                </p>
              </div>
            ) : (
              history.map((item, index) => {
                const lines = responseLines(item.answer);
                const confidenceClass = confidenceStyles[item.confidence] || 'border-border bg-muted text-foreground';
                return (
                  <div key={`${item.query}-${index}`} className="rounded-2xl border bg-background p-5 shadow-sm">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                      <div className="min-w-0">
                        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Question</div>
                        <div className="mt-1 text-sm font-semibold leading-6">{item.query}</div>
                      </div>
                      <div className="flex shrink-0 flex-wrap gap-2">
                        <Badge variant="outline" className={confidenceClass}>
                          confidence: {item.confidence}
                        </Badge>
                        <Badge variant="outline">intent: {formatIntent(item.intent)}</Badge>
                      </div>
                    </div>

                    <div className="mt-4 rounded-xl border bg-muted/20 p-4">
                      <div className="mb-3 flex items-center gap-2 text-sm font-medium">
                        <Icons.robot className="h-4 w-4 text-primary" />
                        WinAssist Bot
                      </div>
                      <div className="space-y-2 text-sm leading-6">
                        {lines.map((line, lineIndex) => {
                          const isBullet = line.startsWith('- ');
                          return (
                            <div
                              key={`${line}-${lineIndex}`}
                              className={isBullet ? 'flex gap-2' : lineIndex === 0 ? 'font-medium' : ''}
                            >
                              {isBullet ? (
                                <>
                                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                                  <span>{line.replace(/^- /, '')}</span>
                                </>
                              ) : (
                                line
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {item.references.length > 0 ? (
                      <div className="mt-4">
                        <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                          Knowledge references
                        </div>
                        <div className="grid gap-2 md:grid-cols-2">
                          {item.references.map((reference, refIndex) => (
                            <div
                              key={`${reference.path}-${reference.section}-${refIndex}`}
                              className="rounded-lg border bg-muted/20 p-3 text-xs leading-5"
                            >
                              <div className="font-medium text-foreground">{reference.section}</div>
                              <div className="mt-1 text-muted-foreground">{reference.title}</div>
                              <div className="mt-1 truncate text-muted-foreground">{reference.path}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null}
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
