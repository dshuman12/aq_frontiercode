import { useNavigate } from 'react-router-dom';
import { PlatformModulePage } from '../../components/shared/platform-module-page';
import { Icons } from '../../components/ui/icons';

export default function ContactsPage() {
  const navigate = useNavigate();

  return (
    <PlatformModulePage
      icon={Icons.group}
      title="Contacts"
      description="Build customer profiles, segments, and targeting rules so campaigns and automations can work from audience data."
      badge="Scaffolded"
      primaryAction={{ label: 'View Campaigns', onClick: () => navigate('/campaigns') }}
      secondaryAction={{ label: 'Open Inbox', onClick: () => navigate('/inbox') }}
      stats={[
        { label: 'Profiles', value: '0', help: 'Customer records should unify web, widget, and future channel activity.' },
        { label: 'Segments', value: '0', help: 'Create reusable audiences for targeting and reporting.' },
        { label: 'Imported Lists', value: '0', help: 'CSV and CRM imports can seed outreach and lifecycle campaigns.' },
        { label: 'Tracked Events', value: '0', help: 'Audience activity will later feed triggers and automations.' },
      ]}
      sections={[
        {
          title: 'Core Contact Features',
          description: 'These features move WinAssist from project builder to engagement platform.',
          items: [
            { title: 'Unified customer profile', description: 'Store attributes, tags, source channel, activity summary, and consent state.' },
            { title: 'Segment builder', description: 'Support filters like last seen, campaign source, reply behavior, and custom properties.' },
            { title: 'Audience imports and exports', description: 'Allow manual list upload and export for ops and marketing teams.' },
          ],
        },
        {
          title: 'Responsive UI Work',
          description: 'Profile and segment screens must avoid table overflow on smaller devices.',
          items: [
            { title: 'Contact cards + detail drawer', description: 'Use stacked summary cards with a slide-over detail panel for mobile.' },
            { title: 'Filter chips', description: 'Move advanced filters into a wrap-safe chip row instead of a single toolbar line.' },
            { title: 'Segment preview counts', description: 'Show count, freshness, and filter summary in compact responsive cards.' },
          ],
        },
      ]}
    />
  );
}
