import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Switch } from '../../components/ui/switch';
import { Icons } from '../../components/ui/icons';
import { useProjects } from '../../hooks/project';
import { useProjectGovernance } from '../../hooks/project-governance';
import { toast } from '../../hooks/toast';
import { formatIstDateTime } from '../../lib/datetime';

const EMPTY_POLICY = {
  require_staging_for_production: true,
  require_approval_for_production: true,
  require_admin_approval_for_risky_ai_changes: true,
  require_change_summary: true,
  allow_member_releases: false,
  allowed_domains: [],
  blocked_capabilities: [],
  sensitive_headers: ['authorization', 'x-api-key', 'cookie', 'set-cookie'],
  notes: '',
};

const INITIAL_RELEASE_FORM = {
  environment: 'draft',
  notes: '',
  change_summary: '',
  approved: false,
  approval_reference: '',
};

function formatDate(value) {
  return formatIstDateTime(value) || 'Not available';
}

function getProjectEditorPath(project) {
  if (!project?.id) return '/projects';
  return project.project_type === 'frontend'
    ? `/chatflow/${project.id}`
    : `/aiagent/${project.id}`;
}

function getEnvironmentVariant(environment) {
  if (environment === 'production') return 'default';
  if (environment === 'staging') return 'secondary';
  return 'outline';
}

export default function PublishCenterPage() {
  const [searchParams] = useSearchParams();
  const { projects, isLoading: projectsLoading } = useProjects();
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [policyForm, setPolicyForm] = useState(EMPTY_POLICY);
  const [releaseForm, setReleaseForm] = useState(INITIAL_RELEASE_FORM);
  const [isSavingPolicy, setIsSavingPolicy] = useState(false);
  const [isCreatingRelease, setIsCreatingRelease] = useState(false);
  const [rollingBackReleaseId, setRollingBackReleaseId] = useState(null);
  const [compareLeftId, setCompareLeftId] = useState('');
  const [compareRightId, setCompareRightId] = useState('__current__');
  const [compareResult, setCompareResult] = useState(null);
  const [isComparing, setIsComparing] = useState(false);

  useEffect(() => {
    if (!projects?.length) return;
    const requestedId = searchParams.get('projectId');
    if (requestedId && projects.some((project) => String(project.id) === String(requestedId))) {
      setSelectedProjectId(String(requestedId));
      return;
    }
    if (!selectedProjectId) {
      setSelectedProjectId(String(projects[0].id));
    }
  }, [projects, searchParams, selectedProjectId]);

  const selectedProject = useMemo(
    () => projects?.find((project) => String(project.id) === String(selectedProjectId)),
    [projects, selectedProjectId]
  );

  const {
    governance,
    isLoading: governanceLoading,
    isError,
    refresh,
    updatePolicy,
    createRelease,
    rollbackRelease,
    compareReleases,
  } = useProjectGovernance(selectedProjectId || null);

  useEffect(() => {
    if (governance?.policy) {
      setPolicyForm({
        ...EMPTY_POLICY,
        ...governance.policy,
      });
    }
  }, [governance]);

  useEffect(() => {
    const releaseHistory = governance?.release_history || [];
    if (!releaseHistory.length) {
      setCompareLeftId('');
      setCompareRightId('__current__');
      setCompareResult(null);
      return;
    }
    if (!compareLeftId) {
      setCompareLeftId(String(releaseHistory[0].id));
    }
    if (
      compareRightId !== '__current__' &&
      !releaseHistory.some((release) => String(release.id) === String(compareRightId))
    ) {
      setCompareRightId('__current__');
    }
  }, [compareLeftId, compareRightId, governance]);

  const stats = useMemo(() => {
    const currentReleases = governance?.current_releases || {};
    const runtime = governance?.runtime_summary || {};
    return [
      {
        label: 'Projects',
        value: projects?.length || 0,
        help: 'Choose a project and govern releases from one place.',
      },
      {
        label: 'Active Environments',
        value: Object.keys(currentReleases).length,
        help: 'How many channels currently have governed snapshots.',
      },
      {
        label: 'Total Releases',
        value: runtime.total_releases || 0,
        help: 'Version count across draft, staging, and production.',
      },
      {
        label: 'Runtime Sessions',
        value: runtime.total_chats || 0,
        help: 'Observed chat sessions linked back to this project.',
      },
    ];
  }, [governance, projects]);

  const handlePolicySwitch = (field) => (checked) => {
    setPolicyForm((current) => ({ ...current, [field]: checked }));
  };

  const handlePolicyTextListChange = (field) => (event) => {
    const items = event.target.value
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean);
    setPolicyForm((current) => ({ ...current, [field]: items }));
  };

  const handleSavePolicy = async () => {
    try {
      setIsSavingPolicy(true);
      await updatePolicy(policyForm);
      toast({
        title: 'Governance policy updated',
        description: 'Workspace release controls were saved successfully.',
      });
    } catch (error) {
      toast({
        title: 'Failed to save governance policy',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSavingPolicy(false);
    }
  };

  const handleCreateRelease = async () => {
    try {
      setIsCreatingRelease(true);
      await createRelease(releaseForm);
      setReleaseForm(INITIAL_RELEASE_FORM);
      toast({
        title: 'Release created',
        description: `A ${releaseForm.environment} snapshot was recorded for ${selectedProject?.name || 'this project'}.`,
      });
    } catch (error) {
      toast({
        title: 'Release creation failed',
        description: error.message || 'Please review the governance requirements.',
        variant: 'destructive',
      });
    } finally {
      setIsCreatingRelease(false);
    }
  };

  const handleRollback = async (release) => {
    const confirmed = window.confirm(
      `Rollback ${selectedProject?.name || 'this project'} to ${release.environment} v${release.version_no}?`
    );
    if (!confirmed) return;

    try {
      setRollingBackReleaseId(release.id);
      await rollbackRelease(release.id, {
        notes: `Rollback requested from Publish Center to ${release.environment} v${release.version_no}.`,
      });
      toast({
        title: 'Rollback completed',
        description: `Project flow restored from ${release.environment} v${release.version_no}.`,
      });
    } catch (error) {
      toast({
        title: 'Rollback failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setRollingBackReleaseId(null);
    }
  };

  const handleCompareReleases = async () => {
    try {
      setIsComparing(true);
      const result = await compareReleases({
        leftReleaseId: compareLeftId,
        rightReleaseId: compareRightId === '__current__' ? null : compareRightId,
        compareToCurrent: compareRightId === '__current__',
      });
      setCompareResult(result);
    } catch (error) {
      toast({
        title: 'Release comparison failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsComparing(false);
    }
  };

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <PageHeader
          title="Publish Center"
          description="Run release governance, audit history, and production-readiness checks for chatflows and AI agents."
          icon={Icons.share}
        />

        <div className="rounded-lg border bg-muted/20 p-4 text-sm text-muted-foreground">
          `Publish Center` only handles release governance: readiness gates, approvals, comparisons, and rollback. Edit prompts, intents, entities, and retrieval defaults in `AI Agent`, and manage knowledge sources or collections in `Knowledge Base`.
        </div>

        <Card className="border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/5">
          <CardHeader className="gap-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <CardTitle className="text-lg sm:text-xl">Enterprise release controls</CardTitle>
                <CardDescription className="mt-1 max-w-3xl text-sm leading-6">
                  Phase 4 now adds governed versioning, approval-aware promotion,
                  rollback, workspace policy, and audit visibility directly inside the product.
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => refresh()} disabled={!selectedProjectId}>
                  <Icons.refresh className="mr-2 h-4 w-4" />
                  Refresh
                </Button>
                {selectedProject ? (
                  <Button asChild>
                    <Link to={getProjectEditorPath(selectedProject)}>Open Project</Link>
                  </Button>
                ) : null}
              </div>
            </div>
          </CardHeader>
        </Card>

        {!projectsLoading && (!projects || projects.length === 0) ? (
          <Card>
            <CardHeader>
              <CardTitle>No projects available</CardTitle>
              <CardDescription>
                Create a project first, then come back here to manage governed releases.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild>
                <Link to="/projects">Create or open projects</Link>
              </Button>
            </CardContent>
          </Card>
        ) : null}

        {projects?.length ? (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Project selection</CardTitle>
                <CardDescription>
                  Choose the chatflow or AI agent you want to govern.
                </CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Project</label>
                  <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={String(project.id)}>
                          {project.name} {project.project_type ? `(${project.project_type})` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">{selectedProject?.project_type || 'project'}</Badge>
                  {governance?.project?.effective_role ? (
                    <Badge variant="secondary">{governance.project.effective_role}</Badge>
                  ) : null}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {stats.map((stat) => (
                <Card key={stat.label}>
                  <CardHeader className="pb-2">
                    <CardDescription>{stat.label}</CardDescription>
                    <CardTitle className="text-2xl">{stat.value}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{stat.help}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {isError ? (
              <Card>
                <CardHeader>
                  <CardTitle>Governance data unavailable</CardTitle>
                  <CardDescription>
                    The selected project could not load governance details.
                  </CardDescription>
                </CardHeader>
              </Card>
            ) : null}

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Workspace governance policy</CardTitle>
                  <CardDescription>
                    Set the release rules that protect production promotions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Require staging before production</div>
                      <p className="text-sm text-muted-foreground">
                        Blocks production unless the current flow has already been staged.
                      </p>
                    </div>
                    <Switch
                      checked={policyForm.require_staging_for_production}
                      onCheckedChange={handlePolicySwitch('require_staging_for_production')}
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Require production approval</div>
                      <p className="text-sm text-muted-foreground">
                        Forces release confirmation before production snapshots are created.
                      </p>
                    </div>
                    <Switch
                      checked={policyForm.require_approval_for_production}
                      onCheckedChange={handlePolicySwitch('require_approval_for_production')}
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Require change summary</div>
                      <p className="text-sm text-muted-foreground">
                        Makes release notes mandatory for high-trust environments.
                      </p>
                    </div>
                    <Switch
                      checked={policyForm.require_change_summary}
                      onCheckedChange={handlePolicySwitch('require_change_summary')}
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Admin approval for risky AI changes</div>
                      <p className="text-sm text-muted-foreground">
                        Enforces owner/admin approval when model, prompt, guardrails, retrieval, or NLU behavior changes materially.
                      </p>
                    </div>
                    <Switch
                      checked={policyForm.require_admin_approval_for_risky_ai_changes}
                      onCheckedChange={handlePolicySwitch('require_admin_approval_for_risky_ai_changes')}
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Allow member releases</div>
                      <p className="text-sm text-muted-foreground">
                        When disabled, only owners and admins can create governed releases.
                      </p>
                    </div>
                    <Switch
                      checked={policyForm.allow_member_releases}
                      onCheckedChange={handlePolicySwitch('allow_member_releases')}
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">
                      Allowed domains
                    </label>
                    <Input
                      value={policyForm.allowed_domains.join(', ')}
                      onChange={handlePolicyTextListChange('allowed_domains')}
                      placeholder="app.example.com, support.example.com"
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">
                      Blocked capabilities
                    </label>
                    <Input
                      value={policyForm.blocked_capabilities.join(', ')}
                      onChange={handlePolicyTextListChange('blocked_capabilities')}
                      placeholder="delete_user, send_payment, run_shell"
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">
                      Sensitive headers
                    </label>
                    <Input
                      value={policyForm.sensitive_headers.join(', ')}
                      onChange={handlePolicyTextListChange('sensitive_headers')}
                      placeholder="authorization, x-api-key"
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Policy notes</label>
                    <Textarea
                      value={policyForm.notes || ''}
                      onChange={(event) =>
                        setPolicyForm((current) => ({
                          ...current,
                          notes: event.target.value,
                        }))
                      }
                      placeholder="Capture compliance, approval, or deployment guidance."
                      disabled={!governance?.permissions?.can_manage_policy || governanceLoading}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button
                      onClick={handleSavePolicy}
                      disabled={
                        governanceLoading ||
                        isSavingPolicy ||
                        !governance?.permissions?.can_manage_policy
                      }
                    >
                      {isSavingPolicy ? 'Saving...' : 'Save policy'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Release promotion</CardTitle>
                  <CardDescription>
                    Create draft, staging, or production snapshots from the current project flow.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {governance?.release_readiness ? (
                    <div className="rounded-lg border bg-muted/20 p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-sm font-medium">Production readiness gates</div>
                        <Badge variant={governance.release_readiness.ready_for_production ? 'secondary' : 'outline'}>
                          {governance.release_readiness.ready_for_production ? 'Ready for production' : 'Needs attention'}
                        </Badge>
                      </div>
                      <div className="mt-3 space-y-2">
                        {(governance.release_readiness.gates || []).map((gate) => (
                          <div key={gate.key} className="flex items-start justify-between gap-3 rounded-md border bg-background px-3 py-2">
                            <div>
                              <div className="text-sm font-medium">{gate.label}</div>
                              <p className="text-xs text-muted-foreground">{gate.detail}</p>
                            </div>
                            <Badge variant={gate.passed ? 'secondary' : gate.required ? 'outline' : 'outline'}>
                              {gate.passed ? 'Pass' : gate.required ? 'Required' : 'Recommended'}
                            </Badge>
                          </div>
                        ))}
                      </div>
                      {!governance.release_readiness.ready_for_production ? (
                        <p className="mt-3 text-xs text-muted-foreground">
                          Blocking items: {(governance.release_readiness.blocking_reasons || []).join(', ')}
                        </p>
                      ) : null}
                    </div>
                  ) : null}
                  {governance?.risk_assessment ? (
                    <div className="rounded-lg border bg-muted/20 p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-sm font-medium">Risky AI change assessment</div>
                        <Badge variant={governance.risk_assessment.has_risky_change ? 'outline' : 'secondary'}>
                          {governance.risk_assessment.has_risky_change ? 'Risk detected' : 'No risky AI change'}
                        </Badge>
                      </div>
                      <p className="mt-2 text-xs text-muted-foreground">
                        Baseline: {governance.risk_assessment.baseline_label}
                      </p>
                      {(governance.risk_assessment.differences || []).length > 0 ? (
                        <div className="mt-3 space-y-2">
                          {governance.risk_assessment.differences.map((item, index) => (
                            <div key={`${item.section}-${index}`} className="rounded-md border bg-background px-3 py-2">
                              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                {item.section}
                              </div>
                              <p className="mt-1 text-sm">{item.message}</p>
                            </div>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  ) : null}

                  <div className="grid gap-3 sm:grid-cols-3">
                    {['draft', 'staging', 'production'].map((environment) => {
                      const release = governance?.current_releases?.[environment];
                      return (
                        <div key={environment} className="rounded-lg border p-3">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-medium capitalize">{environment}</span>
                            <Badge variant={getEnvironmentVariant(environment)}>
                              {release ? `v${release.version_no}` : 'empty'}
                            </Badge>
                          </div>
                          <p className="mt-2 text-xs text-muted-foreground">
                            {release
                              ? `Last updated ${formatDate(release.created_at)}`
                              : 'No governed snapshot yet.'}
                          </p>
                        </div>
                      );
                    })}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Environment</label>
                    <Select
                      value={releaseForm.environment}
                      onValueChange={(value) =>
                        setReleaseForm((current) => ({ ...current, environment: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="staging">Staging</SelectItem>
                        <SelectItem value="production">Production</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Change summary</label>
                    <Textarea
                      value={releaseForm.change_summary}
                      onChange={(event) =>
                        setReleaseForm((current) => ({
                          ...current,
                          change_summary: event.target.value,
                        }))
                      }
                      placeholder="Why is this release needed?"
                      disabled={governanceLoading || !governance?.permissions?.can_create_release}
                    />
                    {governance?.release_readiness?.default_change_summary ? (
                      <p className="text-xs text-muted-foreground">
                        Tip: if left blank, the AI agent release notes can be used as the default summary.
                      </p>
                    ) : null}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Release notes</label>
                    <Textarea
                      value={releaseForm.notes}
                      onChange={(event) =>
                        setReleaseForm((current) => ({
                          ...current,
                          notes: event.target.value,
                        }))
                      }
                      placeholder="Optional deployment notes, rollout plan, or warnings."
                      disabled={governanceLoading || !governance?.permissions?.can_create_release}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">
                      Approval reference
                    </label>
                    <Input
                      value={releaseForm.approval_reference}
                      onChange={(event) =>
                        setReleaseForm((current) => ({
                          ...current,
                          approval_reference: event.target.value,
                        }))
                      }
                      placeholder="CAB-2026-042, Slack thread, ticket ID"
                      disabled={governanceLoading || !governance?.permissions?.can_create_release}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 rounded-lg border p-3">
                    <div>
                      <div className="text-sm font-medium">Approval confirmed</div>
                      <p className="text-sm text-muted-foreground">
                        Required for production if governance demands approval.
                      </p>
                    </div>
                    <Switch
                      checked={releaseForm.approved}
                      onCheckedChange={(checked) =>
                        setReleaseForm((current) => ({
                          ...current,
                          approved: checked,
                        }))
                      }
                      disabled={governanceLoading || !governance?.permissions?.can_create_release}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button
                      onClick={handleCreateRelease}
                      disabled={
                        governanceLoading ||
                        isCreatingRelease ||
                        !governance?.permissions?.can_create_release
                      }
                    >
                      {isCreatingRelease ? 'Creating...' : 'Create governed release'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Release history</CardTitle>
                  <CardDescription>
                    Full version trail with rollback access for admins and owners.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {governanceLoading ? (
                    <p className="text-sm text-muted-foreground">Loading release history...</p>
                  ) : governance?.release_history?.length ? (
                    governance.release_history.map((release) => (
                      <div key={release.id} className="rounded-lg border p-4">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Badge variant={getEnvironmentVariant(release.environment)}>
                              {release.environment}
                            </Badge>
                            <span className="text-sm font-medium">
                              Version {release.version_no}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <Badge variant="outline">{release.created_by_email || 'Unknown actor'}</Badge>
                            {governance?.permissions?.can_rollback ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleRollback(release)}
                                disabled={rollingBackReleaseId === release.id}
                              >
                                {rollingBackReleaseId === release.id ? 'Rolling back...' : 'Rollback'}
                              </Button>
                            ) : null}
                          </div>
                        </div>
                        <p className="mt-2 text-sm text-muted-foreground">
                          {formatDate(release.created_at)}
                        </p>
                        {release.change_summary ? (
                          <p className="mt-3 text-sm">{release.change_summary}</p>
                        ) : null}
                        {release.notes ? (
                          <p className="mt-2 text-sm text-muted-foreground">{release.notes}</p>
                        ) : null}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No governed releases yet for this project.
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Version comparison</CardTitle>
                  <CardDescription>
                    Compare two governed releases or compare a prior release against the current draft before promoting.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Base release</label>
                      <Select value={compareLeftId} onValueChange={setCompareLeftId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a base release" />
                        </SelectTrigger>
                        <SelectContent>
                          {(governance?.release_history || []).map((release) => (
                            <SelectItem key={release.id} value={String(release.id)}>
                              {release.environment} v{release.version_no}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Compare against</label>
                      <Select value={compareRightId} onValueChange={setCompareRightId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a comparison target" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="__current__">Current draft</SelectItem>
                          {(governance?.release_history || []).map((release) => (
                            <SelectItem key={release.id} value={String(release.id)}>
                              {release.environment} v{release.version_no}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={handleCompareReleases} disabled={!compareLeftId || isComparing}>
                      {isComparing ? 'Comparing...' : 'Compare versions'}
                    </Button>
                  </div>
                  {compareResult ? (
                    <div className="space-y-3 rounded-lg border bg-muted/20 p-4">
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">{compareResult.left?.label}</Badge>
                        <Badge variant="outline">{compareResult.right?.label}</Badge>
                        <Badge variant={compareResult.comparison?.is_same ? 'secondary' : 'outline'}>
                          {compareResult.comparison?.is_same ? 'No change' : `${compareResult.comparison?.difference_count || 0} differences`}
                        </Badge>
                      </div>
                      {(compareResult.comparison?.differences || []).length === 0 ? (
                        <p className="text-sm text-muted-foreground">
                          No meaningful differences were detected between these versions.
                        </p>
                      ) : (
                        <div className="space-y-2">
                          {(compareResult.comparison?.differences || []).map((item, index) => (
                            <div key={`${item.section}-${index}`} className="rounded-md border bg-background px-3 py-2">
                              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                {item.section}
                              </div>
                              <p className="mt-1 text-sm">{item.message}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      Run a comparison to see changes in model profile, prompt, retrieval, intents, entities, guardrails, and flow structure.
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Audit and runtime summary</CardTitle>
                  <CardDescription>
                    Track operational signals alongside governance actions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-lg border p-3">
                      <div className="text-sm font-medium">Completed chats</div>
                      <p className="mt-1 text-2xl font-semibold">
                        {governance?.runtime_summary?.completed_chats || 0}
                      </p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-sm font-medium">Failed chats</div>
                      <p className="mt-1 text-2xl font-semibold">
                        {governance?.runtime_summary?.failed_chats || 0}
                      </p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-sm font-medium">Stored messages</div>
                      <p className="mt-1 text-2xl font-semibold">
                        {governance?.runtime_summary?.total_messages || 0}
                      </p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-sm font-medium">Step events</div>
                      <p className="mt-1 text-2xl font-semibold">
                        {governance?.runtime_summary?.total_step_events || 0}
                      </p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <div className="text-sm font-medium">Last observed activity</div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {formatDate(governance?.runtime_summary?.last_activity_at)}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="text-sm font-medium">Recent audit log</div>
                    {governance?.audit_log?.length ? (
                      governance.audit_log.map((entry) => (
                        <div key={entry.id} className="rounded-lg border p-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <Badge variant="outline">{entry.action}</Badge>
                            <span className="text-xs text-muted-foreground">
                              {formatDate(entry.created_at)}
                            </span>
                          </div>
                          <p className="mt-2 text-sm text-muted-foreground">
                            {entry.actor_email || 'Unknown actor'}
                          </p>
                          {entry.metadata && Object.keys(entry.metadata).length ? (
                            <pre className="mt-3 overflow-x-auto rounded-md bg-muted/50 p-3 text-xs">
                              {JSON.stringify(entry.metadata, null, 2)}
                            </pre>
                          ) : null}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">
                        Governance actions will appear here after policy updates, releases, and rollbacks.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        ) : null}
      </div>
    </AppLayout>
  );
}
