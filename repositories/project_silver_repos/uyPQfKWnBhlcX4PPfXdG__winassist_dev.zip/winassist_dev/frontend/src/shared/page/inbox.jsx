import { useNavigate } from 'react-router-dom';
import { PlatformModulePage } from '../../components/shared/platform-module-page';
import { Icons } from '../../components/ui/icons';

export default function InboxPage() {
  const navigate = useNavigate();

  return (
    <PlatformModulePage
      icon={Icons.inbox}
      title="Inbox"
      description="Run human handoff, agent assist, and conversation operations from a shared, responsive support workspace."
      badge="Scaffolded"
      primaryAction={{ label: 'View Project Analytics', onClick: () => navigate('/project-dashboard') }}
      secondaryAction={{ label: 'Open Team', onClick: () => navigate('/workspaces/invites') }}
      stats={[
        { label: 'Open Conversations', value: '0', help: 'Future live queue for bot escalation and human support.' },
        { label: 'Assigned to Me', value: '0', help: 'Personal queue and ownership state for support agents.' },
        { label: 'Waiting on User', value: '0', help: 'Track stalled threads and follow-up opportunities.' },
        { label: 'SLA Alerts', value: '0', help: 'Surface response delays and critical customer issues.' },
      ]}
      sections={[
        {
          title: 'Operational Features',
          description: 'These are the missing support-focused capabilities in the current product.',
          items: [
            { title: 'Shared queue', description: 'Filter by workspace, priority, channel, assigned agent, and status.' },
            { title: 'Human handoff', description: 'Move from bot to person while preserving context and transcript history.' },
            { title: 'Agent assist', description: 'Add suggested replies, conversation summaries, and internal notes.' },
          ],
        },
        {
          title: 'Responsive UI Work',
          description: 'Inbox needs a mobile-safe split view instead of desktop-only layouts.',
          items: [
            { title: 'Master-detail stack', description: 'Use conversation list first, then open details full-screen on mobile.' },
            { title: 'Compact composer', description: 'Prevent attachment buttons and action controls from overlapping the message input.' },
            { title: 'Metadata drawer', description: 'Move customer context, tags, and notes into a right drawer on desktop and bottom sheet on mobile.' },
          ],
        },
      ]}
    />
  );
}
