import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Icons } from '../../components/ui/icons';
import { useUser } from '../../hooks/user';
import { apiRequest } from '../../lib/api-client';
import useUserStore from '../../store/user';
import { toast } from '../../hooks/toast';

const PASSWORD_RULES = [
  { id: 'length', label: 'At least 8 characters', test: (password) => password.length >= 8 },
  { id: 'lower', label: 'One lowercase letter', test: (password) => /[a-z]/.test(password) },
  { id: 'upper', label: 'One uppercase letter', test: (password) => /[A-Z]/.test(password) },
  { id: 'number', label: 'One number', test: (password) => /\d/.test(password) },
  {
    id: 'special',
    label: 'One special character (!@#$%^&* etc.)',
    test: (password) => /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password),
  },
];

function getPasswordErrors(password) {
  return PASSWORD_RULES.filter((rule) => !rule.test(password)).map((rule) => rule.label);
}

function getDisplayName(user) {
  const fullName = [user?.first_name, user?.last_name]
    .map((value) => value?.trim())
    .filter(Boolean)
    .join(' ');

  if (fullName) return fullName;
  return user?.email || 'WinAssist user';
}

export default function SettingsPage() {
  const navigate = useNavigate();
  const { user, loading } = useUser();
  const setUser = useUserStore((state) => state.setUser);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [userName, setUserName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [profileLoading, setProfileLoading] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [showPasswords, setShowPasswords] = useState(false);
  const [capsLockOn, setCapsLockOn] = useState(false);
  const [passwordSuccessMessage, setPasswordSuccessMessage] = useState('');

  useEffect(() => {
    if (!user) return;
    setFirstName(user.first_name || '');
    setLastName(user.last_name || '');
    setUserName(user.user_name || '');
    setCompanyName(user.company_name || '');
    setMobileNumber(user.mobile_number || '');
  }, [user]);

  const passwordChecks = useMemo(
    () =>
      PASSWORD_RULES.map((rule) => ({
        ...rule,
        passed: rule.test(newPassword),
      })),
    [newPassword]
  );
  const isPasswordValid = useMemo(
    () => passwordChecks.every((check) => check.passed),
    [passwordChecks]
  );
  const passwordStrengthScore = useMemo(
    () => passwordChecks.filter((check) => check.passed).length,
    [passwordChecks]
  );
  const passwordStrengthPercent = useMemo(() => {
    if (!newPassword) return 0;
    return Math.round((passwordStrengthScore / PASSWORD_RULES.length) * 100);
  }, [newPassword, passwordStrengthScore]);
  const passwordStrengthLabel = useMemo(() => {
    if (!newPassword) return 'Enter a new password';
    if (passwordStrengthScore <= 2) return 'Weak';
    if (passwordStrengthScore <= 4) return 'Moderate';
    return 'Strong';
  }, [newPassword, passwordStrengthScore]);
  const isPasswordReused = currentPassword.length > 0 && currentPassword === newPassword;
  const passwordsMatch = newPassword.length > 0 && newPassword === confirmPassword;
  const displayName = getDisplayName(user);

  const handlePasswordFieldChange = (setter) => (event) => {
    setPasswordSuccessMessage('');
    setter(event.target.value);
  };

  const handlePasswordFieldKeyEvent = (event) => {
    setCapsLockOn(event.getModifierState('CapsLock'));
  };

  const handleProfileSubmit = async (event) => {
    event.preventDefault();
    setProfileLoading(true);

    try {
      const updatedUser = await apiRequest('/auth/me', {
        method: 'PATCH',
        body: {
          first_name: firstName.trim(),
          last_name: lastName.trim(),
          user_name: userName.trim(),
          company_name: companyName.trim(),
          mobile_number: mobileNumber.trim(),
        },
        showErrorToast: false,
      });

      setUser({
        ...user,
        ...updatedUser,
        token: user?.token,
      });
      toast({
        title: 'Profile updated',
        description: 'Your account details were saved successfully.',
      });
    } catch (error) {
      toast({
        title: 'Profile update failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setProfileLoading(false);
    }
  };

  const handlePasswordSubmit = async (event) => {
    event.preventDefault();
    setPasswordSuccessMessage('');

    if (!currentPassword) {
      toast({
        title: 'Current password required',
        description: 'Enter your current password before choosing a new one.',
        variant: 'destructive',
      });
      return;
    }

    const passwordErrors = getPasswordErrors(newPassword);
    if (passwordErrors.length > 0) {
      toast({
        title: 'Password does not meet requirements',
        description: passwordErrors.join('. '),
        variant: 'destructive',
      });
      return;
    }

    if (!passwordsMatch) {
      toast({
        title: 'Passwords do not match',
        description: 'Confirm the new password so both fields match.',
        variant: 'destructive',
      });
      return;
    }

    if (currentPassword === newPassword) {
      toast({
        title: 'Choose a different password',
        description: 'Your new password should be different from the current one.',
        variant: 'destructive',
      });
      return;
    }

    setPasswordLoading(true);
    try {
      await apiRequest('/auth/change-password', {
        method: 'POST',
        body: {
          current_password: currentPassword,
          new_password: newPassword,
        },
        showErrorToast: false,
      });

      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setCapsLockOn(false);
      setPasswordSuccessMessage('Password updated successfully.');
      toast({
        title: 'Password updated',
        description: 'Your password has been changed successfully.',
      });
    } catch (error) {
      toast({
        title: 'Password update failed',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-5xl flex-col gap-6">
        <PageHeader
          title="Settings"
          description="Manage your profile details and account password here. Billing is now available on a separate screen."
          icon={Icons.settings}
          actions={(
            <Button variant="outline" onClick={() => navigate('/billing')}>
              <Icons.billing className="h-4 w-4" />
              Open Billing
            </Button>
          )}
        />

        <div className="grid gap-6 xl:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]">
          <Card>
            <CardHeader>
              <CardTitle>Profile information</CardTitle>
              <CardDescription>
                Update the account details shown across your workspace.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileSubmit} className="space-y-5">
                <div className="grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="settings-first-name">First name</Label>
                    <Input
                      id="settings-first-name"
                      value={firstName}
                      onChange={(event) => setFirstName(event.target.value)}
                      placeholder="Enter first name"
                      disabled={profileLoading || loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="settings-last-name">Last name</Label>
                    <Input
                      id="settings-last-name"
                      value={lastName}
                      onChange={(event) => setLastName(event.target.value)}
                      placeholder="Enter last name"
                      disabled={profileLoading || loading}
                    />
                  </div>
                </div>

                <div className="grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="settings-user-name">User name</Label>
                    <Input
                      id="settings-user-name"
                      value={userName}
                      onChange={(event) => setUserName(event.target.value)}
                      placeholder="Enter username"
                      disabled={profileLoading || loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="settings-company-name">Company name</Label>
                    <Input
                      id="settings-company-name"
                      value={companyName}
                      onChange={(event) => setCompanyName(event.target.value)}
                      placeholder="Enter company name"
                      disabled={profileLoading || loading}
                    />
                  </div>
                </div>

                <div className="grid gap-5 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="settings-mobile-number">Mobile number</Label>
                    <Input
                      id="settings-mobile-number"
                      value={mobileNumber}
                      onChange={(event) => setMobileNumber(event.target.value)}
                      placeholder="+1 234 567 8900"
                      disabled={profileLoading || loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="settings-email">Email</Label>
                    <Input
                      id="settings-email"
                      value={user?.email || ''}
                      readOnly
                      disabled
                    />
                  </div>
                </div>

                <Button type="submit" disabled={profileLoading || loading}>
                  {profileLoading ? (
                    <>
                      <Icons.spinner className="h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Icons.save className="h-4 w-4" />
                      Save profile
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Account overview</CardTitle>
              <CardDescription>
                Quick details for the signed-in user.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Display name
                </p>
                <p className="mt-1 text-sm font-semibold text-foreground">{displayName}</p>
              </div>
              <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Login email
                </p>
                <p className="mt-1 break-all text-sm text-foreground">{user?.email || 'Loading...'}</p>
              </div>
              <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                <p className="text-sm font-medium text-foreground">Billing is separate now</p>
                <p className="mt-1 text-sm leading-6 text-muted-foreground">
                  Open billing to manage plan details, invoices, and usage once those screens are ready.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  className="mt-4 w-full"
                  onClick={() => navigate('/billing')}
                >
                  <Icons.billing className="h-4 w-4" />
                  Go to Billing
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Change password</CardTitle>
            <CardDescription>
              Use your current password to set a new one. If you forgot your password, reset it by email instead.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="settings-current-password">Current password</Label>
                <div className="relative">
                  <Icons.lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="settings-current-password"
                    type={showPasswords ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={handlePasswordFieldChange(setCurrentPassword)}
                    onKeyDown={handlePasswordFieldKeyEvent}
                    onKeyUp={handlePasswordFieldKeyEvent}
                    placeholder="Enter current password"
                    className="h-11 pl-10 pr-12"
                    disabled={passwordLoading}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPasswords((value) => !value)}
                  >
                    {showPasswords ? (
                      <Icons.eyeOff className="h-5 w-5" />
                    ) : (
                      <Icons.eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <p className="text-muted-foreground">
                    This confirms it is you before changing account security.
                  </p>
                  <Link to="/auth/forgot-password" className="text-primary hover:underline">
                    Forgot password? Reset by email
                  </Link>
                </div>
                {capsLockOn ? (
                  <p className="text-xs text-amber-700 dark:text-amber-300">
                    Caps Lock is on.
                  </p>
                ) : null}
              </div>

              <div className="space-y-2">
                <Label htmlFor="settings-new-password">New password</Label>
                <div className="grid gap-5 md:grid-cols-2">
                  <Input
                    id="settings-new-password"
                    type={showPasswords ? 'text' : 'password'}
                    value={newPassword}
                    onChange={handlePasswordFieldChange(setNewPassword)}
                    onKeyDown={handlePasswordFieldKeyEvent}
                    onKeyUp={handlePasswordFieldKeyEvent}
                    placeholder="Enter new password"
                    className="h-11"
                    disabled={passwordLoading}
                    minLength={8}
                    aria-invalid={newPassword.length > 0 && !isPasswordValid}
                  />
                  {newPassword.length > 0 ? (
                    <Input
                      id="settings-confirm-password"
                      type={showPasswords ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={handlePasswordFieldChange(setConfirmPassword)}
                      onKeyDown={handlePasswordFieldKeyEvent}
                      onKeyUp={handlePasswordFieldKeyEvent}
                      placeholder="Confirm new password"
                      className="h-11"
                      disabled={passwordLoading}
                      minLength={8}
                      aria-invalid={confirmPassword.length > 0 && !passwordsMatch}
                    />
                  ) : (
                    <div className="flex h-11 items-center rounded-md border border-dashed border-border px-3 text-sm text-muted-foreground">
                      Confirm password appears after you enter a new password.
                    </div>
                  )}
                </div>
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-foreground">Strength</span>
                    <span
                      className={
                        passwordStrengthLabel === 'Strong'
                          ? 'text-green-700 dark:text-green-400'
                          : passwordStrengthLabel === 'Moderate'
                            ? 'text-amber-700 dark:text-amber-300'
                            : 'text-destructive'
                      }
                    >
                      {passwordStrengthLabel}
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className={
                        passwordStrengthLabel === 'Strong'
                          ? 'h-full bg-green-600 transition-all'
                          : passwordStrengthLabel === 'Moderate'
                            ? 'h-full bg-amber-500 transition-all'
                            : 'h-full bg-destructive transition-all'
                      }
                      style={{ width: `${passwordStrengthPercent}%` }}
                    />
                  </div>
                </div>
                {isPasswordReused ? (
                  <p className="text-sm text-destructive">
                    Your new password must be different from your current password.
                  </p>
                ) : null}
                {confirmPassword && !passwordsMatch ? (
                  <p className="text-sm text-destructive">
                    The new password and confirmation must match.
                  </p>
                ) : null}
              </div>

              <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                <p className="mb-3 text-sm font-medium text-foreground">Password must include:</p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  {passwordChecks.map(({ id, label, passed }) => (
                    <li key={id} className="flex items-center gap-2">
                      {passed ? (
                        <Icons.check className="h-4 w-4 shrink-0 text-green-600" />
                      ) : (
                        <span className="h-4 w-4 shrink-0 rounded-full border border-current" aria-hidden />
                      )}
                      <span className={passed ? 'text-green-700 dark:text-green-400' : ''}>{label}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {passwordSuccessMessage ? (
                <div className="rounded-lg border border-green-600/25 bg-green-50 px-3 py-2 text-sm text-green-800 dark:border-green-500/30 dark:bg-green-500/10 dark:text-green-300">
                  {passwordSuccessMessage}
                </div>
              ) : null}

              <Button
                type="submit"
                disabled={
                  passwordLoading ||
                  !currentPassword ||
                  !isPasswordValid ||
                  !passwordsMatch ||
                  isPasswordReused
                }
              >
                {passwordLoading ? (
                  <>
                    <Icons.spinner className="h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  <>
                    <Icons.lock className="h-4 w-4" />
                    Update password
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
