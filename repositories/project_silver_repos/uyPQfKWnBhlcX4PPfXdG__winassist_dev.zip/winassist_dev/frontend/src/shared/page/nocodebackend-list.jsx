import { useNavigate } from 'react-router-dom';
import { ProjectList } from '../../components/shared/project-list';
import { initialBackendEdges, initialBackendNodes, useProjects } from '../../hooks/project';
import { useWorkspaces } from '../../hooks/workspace';
import { toast } from '../../hooks/toast';
import { Icons } from '../../components/ui/icons';
import { useEffect } from 'react';
import { Button } from '../../components/ui/button';
import { AppLayout } from '../../components/shared/app-layout';

function getNextNumberedName(baseName, existingNames) {
  const base = (baseName ?? '').trim();
  if (!base) return 'New Project';

  const escaped = base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`^${escaped}(\\d+)?$`);

  let maxN = 0;
  for (const name of existingNames || []) {
    const n = (name ?? '').trim();
    const m = n.match(re);
    if (!m) continue;
    const parsed = m[1] ? Number.parseInt(m[1], 10) : 0;
    if (Number.isFinite(parsed)) maxN = Math.max(maxN, parsed);
  }

  return maxN === 0 && !existingNames?.includes(base) ? base : `${base}${maxN + 1}`;
}

export default function NoCodeBackendListPage() {
  const navigate = useNavigate();
  const { createProject, setActiveProjectId, projects } = useProjects();
  const { currentWorkspace } = useWorkspaces();
  const canCreate = currentWorkspace?.role !== 'viewer';
  
  useEffect(() => {
    setActiveProjectId(-1);
  }, [setActiveProjectId]);
  
  const onCreateProject = async () => {
    const nextName = getNextNumberedName(
      'New AI Agent Project',
      (projects || []).filter((p) => p?.project_type === 'backend').map((p) => p?.name)
    );
    const project = await createProject({
      id: -1,
      name: nextName,
      description: 'A new AI agent project with sample flow.',
      project_type: 'backend',
      flow: {
        nodes: initialBackendNodes,
        edges: initialBackendEdges,
      },
    });
    if (!project) {
      toast({ title: 'Failed to create this project' });
      return;
    }
    toast({ title: 'Project created. Now jumping to project page.' });
    navigate(`/aiagent/${project.id}`);
  };

  // Filter projects to show only backend projects
  const backendProjects = projects?.filter(p => p.project_type === 'backend') || [];
  
  // Debug: log projects to see what we're getting
  useEffect(() => {
    undefined
    undefined
    undefined
  }, [projects, backendProjects]);
  
  return (
    <AppLayout>
      <div className="flex flex-col items-center justify-center gap-4 text-sm max-w-7xl mx-auto">
        <span className="text-2xl sm:text-4xl font-bold font-arial p-4 text-center">
          AI Agent
        </span>
        <span className="text-base sm:text-lg text-center">
          Create and manage your AI agent projects.
        </span>
        {canCreate && (
        <Button size="lg" onClick={onCreateProject}>
          <Icons.project />
          Create New AI Agent Project
        </Button>
        )}
        <ProjectList projects={backendProjects} projectType="backend" />
      </div>
    </AppLayout>
  );
}
