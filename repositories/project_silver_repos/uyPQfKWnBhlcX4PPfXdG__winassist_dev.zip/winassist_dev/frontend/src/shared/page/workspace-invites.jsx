import { useState, useEffect } from 'react';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { toast } from '../../hooks/toast';
import { apiRequest } from '../../lib/api-client';
import { copyTextToClipboard } from '../../lib/utils';
import { useWorkspaces } from '../../hooks/workspace';
import { useUser } from '../../hooks/user';
import { Icons } from '../../components/ui/icons';
import { cn } from '../../lib/utils';
import { formatIstDate, isPastIst } from '../../lib/datetime';

const ROLE_PERMISSIONS = {
  owner: {
    label: 'Owner',
    description: 'Full access: create/edit/delete projects, invite and remove members, change roles, delete workspace.',
  },
  admin: {
    label: 'Admin',
    description: 'Manage workspace: create/edit/delete projects, invite and remove members, change roles. Cannot delete the workspace.',
  },
  member: {
    label: 'Member',
    description: 'Can create and edit projects in this workspace. Cannot invite members or change settings.',
  },
  viewer: {
    label: 'Viewer',
    description: 'Read-only: can view projects and chats. Cannot create, edit, or delete anything, or invite members.',
  },
};

function getInviteStatus(invite) {
  if (invite.accepted_at) return { label: 'Accepted', variant: 'success' };
  if (invite.expires_at && isPastIst(invite.expires_at)) return { label: 'Expired', variant: 'muted' };
  return { label: 'Pending', variant: 'warning' };
}

function buildInviteLink(token) {
  const base = typeof window !== 'undefined' && window.location.origin ? window.location.origin : '';
  return `${base}/accept-invite?token=${token}`;
}

function getWorkspaceSectionTitle(workspace, currentUserId) {
  return workspace?.owner_id === currentUserId ? 'Personal Workspace' : 'Team Workspace';
}

export default function WorkspaceInvitesPage() {
  const { currentWorkspace, currentWorkspaceId, setCurrentWorkspaceId, workspaces } = useWorkspaces();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('member');
  const [loading, setLoading] = useState(false);
  const [invites, setInvites] = useState([]);
  const [invitesLoading, setInvitesLoading] = useState(false);
  const [members, setMembers] = useState([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [lastCreatedInvite, setLastCreatedInvite] = useState(null);
  const [resolvedWorkspaceId, setResolvedWorkspaceId] = useState(null);
  const [resolvedWorkspaceName, setResolvedWorkspaceName] = useState('');
  const [resolvedWorkspaceRole, setResolvedWorkspaceRole] = useState(null);
  const { userId: currentUserId } = useUser();

  const wsId = resolvedWorkspaceId || currentWorkspaceId || (currentWorkspace && currentWorkspace.id);
  const canInviteAndManage = resolvedWorkspaceRole === 'owner' || resolvedWorkspaceRole === 'admin';
  const selectedWorkspace =
    currentWorkspace ||
    workspaces?.find((workspace) => workspace.id === resolvedWorkspaceId) ||
    null;

  const fetchWorkspaceThenData = async () => {
    try {
      const list = await apiRequest('/workspaces', { method: 'GET', showErrorToast: false });
      const workspaces = Array.isArray(list) ? list : [];
      if (workspaces.length === 0) return;
      const first = workspaces[0];
      const id = first.id;
      const name = first.name || 'Workspace';
      setResolvedWorkspaceId(id);
      setResolvedWorkspaceName(name);
      setResolvedWorkspaceRole(first.role || null);
      if (setCurrentWorkspaceId && !currentWorkspaceId) setCurrentWorkspaceId(id);
    } catch {
      return;
    }
  };

  const fetchInvites = async () => {
    const id = resolvedWorkspaceId || currentWorkspaceId || (currentWorkspace && currentWorkspace.id);
    if (!id) return;
    setInvitesLoading(true);
    try {
      const data = await apiRequest(`/workspaces/${id}/invites`, {
        method: 'GET',
        showErrorToast: false,
      });
      setInvites(Array.isArray(data) ? data : []);
    } catch {
      setInvites([]);
    } finally {
      setInvitesLoading(false);
    }
  };

  const fetchMembers = async () => {
    const id = resolvedWorkspaceId || currentWorkspaceId || (currentWorkspace && currentWorkspace.id);
    if (!id) return;
    setMembersLoading(true);
    try {
      const data = await apiRequest(`/workspaces/${id}/members`, {
        method: 'GET',
        showErrorToast: false,
      });
      setMembers(Array.isArray(data) ? data : []);
    } catch {
      setMembers([]);
    } finally {
      setMembersLoading(false);
    }
  };

  useEffect(() => {
    const id = currentWorkspaceId || (currentWorkspace && currentWorkspace.id);
    if (id) {
      setResolvedWorkspaceId(id);
      setResolvedWorkspaceName((currentWorkspace && currentWorkspace.name) || '');
      setResolvedWorkspaceRole((currentWorkspace && currentWorkspace.role) || null);
    } else {
      fetchWorkspaceThenData();
    }
  }, [currentWorkspaceId, currentWorkspace]);

  // When workspace list first loads or changes, ensure we use the current workspace and refetch members
  useEffect(() => {
    if (!workspaces?.length) return;
    const id = currentWorkspaceId || (workspaces[0] && workspaces[0].id);
    if (id) {
      setResolvedWorkspaceId(id);
      const ws = workspaces.find((w) => w.id === id) || workspaces[0];
      if (ws) {
        setResolvedWorkspaceName(ws.name || '');
        setResolvedWorkspaceRole(ws.role || null);
      }
    }
  }, [workspaces, currentWorkspaceId]);

  // Fetch members and invites when workspace is known; refetch when workspaces list loads so we use the right workspace
  useEffect(() => {
    if (!wsId) return;
    fetchInvites();
    fetchMembers();
  }, [wsId, workspaces?.length]);

  const handleInvite = async (e) => {
    e.preventDefault();
    setLoading(true);
    setLastCreatedInvite(null);
    try {
      let wsId = resolvedWorkspaceId || currentWorkspaceId || (currentWorkspace && currentWorkspace.id);
      if (!wsId) {
        const data = await apiRequest('/workspaces', { method: 'GET', showErrorToast: false });
        const list = Array.isArray(data) ? data : [];
        if (!list.length) {
          toast({ title: 'No workspace available', description: 'Could not find a workspace.', variant: 'destructive' });
          return;
        }
        wsId = list[0].id;
      }

      const res = await apiRequest(`/workspaces/${wsId}/invites`, {
        method: 'POST',
        body: { email, role, expires_in_days: 7 },
      });
      if (res?.reused) {
        toast({
          title: 'User already invited',
          description: 'A pending invite already exists for this email and role.',
        });
      } else {
        const desc = res.email_sent
          ? (res.invite_link ? 'Email sent with invite link.' : 'Email sent.')
          : res.email_error
            ? `Invite created but email failed: ${res.email_error}`
            : res.invite_link
              ? 'Invite created. You can share the link below.'
              : 'Invite created. Set FRONTEND_URL and SMTP in the backend for email.';
        toast({
          title: 'Invite created',
          description: desc,
          variant: res.email_error ? 'destructive' : undefined,
        });
      }
      setLastCreatedInvite(res?.invite_link ? res : null);
      setEmail('');
      fetchInvites();
      fetchMembers();
    } catch (err) {
      toast({ title: 'Failed to create invite', description: err.message || 'Please try again', variant: 'destructive' });
      fetchMembers();
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteInvite = async (inviteId) => {
    if (!wsId || !canInviteAndManage || !inviteId) return;
    const ok = window.confirm('Delete this invite? The user will no longer be able to accept it.');
    if (!ok) return;
    try {
      await apiRequest(`/workspaces/${wsId}/invites/${inviteId}`, { method: 'DELETE' });
      toast({ title: 'Invite deleted' });
      fetchInvites();
    } catch (err) {
      toast({
        title: 'Failed to delete invite',
        description: err.message || 'Please try again',
        variant: 'destructive',
      });
    }
  };

  const copyInviteLink = async (token) => {
    const link = buildInviteLink(token);
    try {
      await copyTextToClipboard(link);
      toast({ title: 'Link copied', description: 'Invite link copied to clipboard.' });
    } catch {
      toast({ title: 'Copy failed', variant: 'destructive' });
    }
  };

  const handleChangeRole = async (memberUserId, newRole) => {
    if (!wsId || !canInviteAndManage) return;
    try {
      await apiRequest(`/workspaces/${wsId}/members/${memberUserId}`, {
        method: 'PATCH',
        body: { role: newRole },
      });
      toast({ title: 'Role updated', description: `Member role set to ${newRole}.` });
      fetchMembers();
    } catch (err) {
      toast({ title: 'Failed to update role', description: err.message || 'Please try again', variant: 'destructive' });
    }
  };

  const handleToggleActive = async (memberUserId, nextActive) => {
    if (!wsId || !canInviteAndManage) return;
    try {
      await apiRequest(`/workspaces/${wsId}/members/${memberUserId}/active`, {
        method: 'PATCH',
        body: { is_active: !!nextActive },
      });
      toast({
        title: nextActive ? 'User activated' : 'User deactivated',
        description: nextActive
          ? 'User can log in and access APIs.'
          : 'User login/API access is now restricted.',
      });
      fetchMembers();
    } catch (err) {
      toast({
        title: 'Failed to update user status',
        description: err.message || 'Please try again',
        variant: 'destructive',
      });
    }
  };

  const handleRemoveMember = async (memberUserId) => {
    if (!wsId || !canInviteAndManage) return;
    if (!window.confirm('Remove this member from the workspace? They will lose access.')) return;
    try {
      await apiRequest(`/workspaces/${wsId}/members/${memberUserId}`, { method: 'DELETE' });
      toast({ title: 'Member removed' });
      fetchMembers();
    } catch (err) {
      toast({ title: 'Failed to remove member', description: err.message || 'Please try again', variant: 'destructive' });
    }
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <PageHeader
          title={getWorkspaceSectionTitle(selectedWorkspace, currentUserId)}
          description={`${canInviteAndManage ? 'Manage members in' : 'View members in'} ${resolvedWorkspaceName || (currentWorkspace && currentWorkspace.name) || 'your workspace'}`}
        />
        {/* Current members */}
        <Card>
          <CardHeader>
            <CardTitle>Members</CardTitle>
            <p className="text-sm text-muted-foreground">Everyone in this workspace. New members appear here after they accept an invite.</p>
          </CardHeader>
          <CardContent>
            {membersLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Icons.spinner className="w-4 h-4 animate-spin" />
                Loading members...
              </div>
            ) : members.length === 0 ? (
              <p className="text-sm text-muted-foreground">No members yet. You will appear here once the workspace is loaded.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 pr-4">Email</th>
                      <th className="text-left py-2 pr-4">Role</th>
                      <th className="text-left py-2 pr-4">Status</th>
                      <th className="text-left py-2 pr-4">Joined</th>
                      {canInviteAndManage && <th className="text-right py-2">Actions</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {members.map((m) => (
                      <tr key={m.id} className="border-b last:border-0">
                        <td className="py-3 pr-4">{m.email || '—'}</td>
                        <td className="py-3 pr-4">
                          {canInviteAndManage && m.user_id !== currentUserId && !m.is_workspace_owner ? (
                            <select
                              className="border rounded px-2 py-1 text-sm bg-background capitalize"
                              value={m.role}
                              onChange={(e) => handleChangeRole(m.user_id, e.target.value)}
                            >
                              <option value="owner">Owner</option>
                              <option value="admin">Admin</option>
                              <option value="member">Member</option>
                              <option value="viewer">Viewer</option>
                            </select>
                          ) : (
                            <span className="capitalize">
                              {m.role}
                              {m.is_workspace_owner ? ' (workspace owner)' : ''}
                            </span>
                          )}
                        </td>
                        <td className="py-3 pr-4">
                          <span
                            className={cn(
                              'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium',
                              m.is_active === false
                                ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                            )}
                          >
                            {m.is_active === false ? 'Inactive' : 'Active'}
                          </span>
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">
                          {formatIstDate(m.created_at, { dateStyle: 'short' })}
                        </td>
                        {canInviteAndManage && (
                          <td className="py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              {(() => {
                                const isSelf = String(m.user_id) === String(currentUserId);
                                const isOwner = !!m.is_workspace_owner;
                                const canChangeThisUser = !isSelf && !isOwner;
                                const toggleTitle = isOwner
                                  ? 'Workspace owner cannot be deactivated'
                                  : isSelf
                                    ? 'You cannot deactivate your own account'
                                    : (m.is_active === false ? 'Activate user' : 'Deactivate user');

                                return (
                                  <>
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={
                                        canChangeThisUser
                                          ? () => handleToggleActive(m.user_id, m.is_active === false)
                                          : undefined
                                      }
                                      disabled={!canChangeThisUser}
                                      title={toggleTitle}
                                    >
                                      {m.is_active === false ? 'Activate' : 'Deactivate'}
                                    </Button>
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      className="text-destructive hover:text-destructive"
                                      onClick={canChangeThisUser ? () => handleRemoveMember(m.user_id) : undefined}
                                      disabled={!canChangeThisUser}
                                      title={
                                        isOwner
                                          ? 'Workspace owner cannot be removed'
                                          : isSelf
                                            ? 'You cannot remove yourself'
                                            : 'Remove member'
                                      }
                                    >
                                      Remove
                                    </Button>
                                  </>
                                );
                              })()}
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Create invite - only for owner/admin */}
        {canInviteAndManage && (
        <Card>
          <CardHeader>
            <CardTitle>Invite by email</CardTitle>
            <p className="text-sm text-muted-foreground">Send an invite link by email (if SMTP is set) or copy the link and share it yourself.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleInvite} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <select
                    id="role"
                    className="w-full border rounded-md px-3 py-2 text-sm bg-background"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                  >
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                    <option value="viewer">Viewer</option>
                  </select>
                  <p className="text-xs text-muted-foreground">
                    {ROLE_PERMISSIONS[role] ? ROLE_PERMISSIONS[role].description : ''}
                  </p>
                </div>
              </div>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                    Creating invite...
                  </>
                ) : (
                  'Create invite'
                )}
              </Button>
            </form>

            {lastCreatedInvite && (
              <div className="mt-4 p-4 rounded-lg border bg-muted/30 space-y-2">
                <p className="text-sm font-medium">Invite link (share with {lastCreatedInvite.email})</p>
                <div className="flex flex-wrap gap-2 items-center">
                  <code className="text-xs bg-muted px-2 py-1 rounded break-all flex-1 min-w-0">
                    {lastCreatedInvite.invite_link || buildInviteLink(lastCreatedInvite.token)}
                  </code>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => copyInviteLink(lastCreatedInvite.token)}
                  >
                    <Icons.copy className="w-4 h-4 mr-1" />
                    Copy link
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        )}

        {/* Role permissions reference */}
        <Card>
          <CardHeader>
            <CardTitle>Role permissions</CardTitle>
            <p className="text-sm text-muted-foreground">What each role can do in this workspace.</p>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm">
              {Object.entries(ROLE_PERMISSIONS).filter(([k]) => k !== 'owner').map(([key, { label, description }]) => (
                <li key={key} className="flex flex-col gap-1">
                  <span className="font-medium capitalize">{label}</span>
                  <span className="text-muted-foreground">{description}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Invites list */}
        <Card>
          <CardHeader>
            <CardTitle>Invites</CardTitle>
            <p className="text-sm text-muted-foreground">All invites for this workspace. Pending invites can be shared again via the copy link.</p>
          </CardHeader>
          <CardContent>
            {invitesLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Icons.spinner className="w-4 h-4 animate-spin" />
                Loading invites...
              </div>
            ) : invites.length === 0 ? (
              <p className="text-sm text-muted-foreground">No invites yet. Create one above.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 pr-4">Email</th>
                      <th className="text-left py-2 pr-4">Role</th>
                      <th className="text-left py-2 pr-4">Status</th>
                      <th className="text-left py-2 pr-4">Created</th>
                      {canInviteAndManage && <th className="text-right py-2">Actions</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {invites.map((inv) => {
                      const status = getInviteStatus(inv);
                      return (
                        <tr key={inv.id} className="border-b last:border-0">
                          <td className="py-3 pr-4">{inv.email}</td>
                          <td className="py-3 pr-4 capitalize">{inv.role}</td>
                          <td className="py-3 pr-4">
                            <span
                              className={cn(
                                'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium',
                                status.variant === 'success' && 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
                                status.variant === 'warning' && 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400',
                                status.variant === 'muted' && 'bg-muted text-muted-foreground'
                              )}
                            >
                              {status.label}
                            </span>
                          </td>
                          <td className="py-3 pr-4 text-muted-foreground">
                            {formatIstDate(inv.created_at, { dateStyle: 'short' })}
                          </td>
                          {canInviteAndManage && (
                            <td className="py-3 text-right">
                              {!inv.accepted_at && (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="text-destructive hover:text-destructive"
                                  onClick={() => handleDeleteInvite(inv.id)}
                                  title="Delete invite"
                                >
                                  <Icons.trash className="w-4 h-4" />
                                </Button>
                              )}
                            </td>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
