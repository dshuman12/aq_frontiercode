import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { ReactFlowProvider } from '@xyflow/react';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Card, CardContent } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Icons } from '../../components/ui/icons';
import useWorkspaceStore from '../../store/workspace';
import { toast } from '../../hooks/toast';
import { Editor } from './resize';
import { apiRequest } from '../../lib/api-client';

const FRONTEND_NODES = [
  'initializer',
  'api',
  'note',
  'text',
  'image',
  'input',
  'calendar',
  'form',
  'document',
  'ocr',
  'delay',
  'assistant',
  'condition',
  'quickreply',
  'container',
  'branch',
  'switch',
  'merge',
];

const BACKEND_NODES = ['initializer', 'conversable', 'groupchat', 'user'];

function getAverageRating(template) {
  const count = Number(template?.rating_count || 0);
  const sum = Number(template?.rating_sum || 0);
  if (!count) return 0;
  return sum / count;
}

function safeJsonParse(value) {
  if (typeof value !== 'string') return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function normalizeFlow(rawFlow) {
  const parsed = typeof rawFlow === 'string' ? safeJsonParse(rawFlow) : rawFlow;
  const flow = parsed && typeof parsed === 'object' ? parsed : null;
  const nodes = Array.isArray(flow?.nodes) ? flow.nodes : [];
  const edges = Array.isArray(flow?.edges) ? flow.edges : [];
  return { ...flow, nodes, edges };
}

export default function TemplatePreviewPage() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const currentWorkspaceId = useWorkspaceStore((s) => s.currentWorkspaceId);

  const [template, setTemplate] = useState(location.state?.template || null);
  const [loading, setLoading] = useState(!location.state?.template);
  const [using, setUsing] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function fetchTemplate() {
      if (template || !id) return;
      setLoading(true);
      try {
        const [backend, frontend] = await Promise.all([
          apiRequest('/templates?project_type=backend&limit=200', { method: 'GET', includeAuth: true, showErrorToast: false }),
          apiRequest('/templates?project_type=frontend&limit=200', { method: 'GET', includeAuth: true, showErrorToast: false }),
        ]);
        const all = [...(backend || []), ...(frontend || [])];
        const found = all.find((t) => String(t?.id) === String(id));
        if (!cancelled) setTemplate(found || null);
      } catch (e) {
        if (!cancelled) {
          toast({
            title: 'Failed to load template',
            description: e?.message || 'Please try again.',
            variant: 'destructive',
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchTemplate();
    return () => {
      cancelled = true;
    };
  }, [id, template]);

  const flow = useMemo(() => {
    const raw =
      template?.project?.flow ??
      template?.project?.project?.flow ??
      template?.flow ??
      null;
    return normalizeFlow(raw);
  }, [template]);

  const templateTypeLabel = template?.project_type === 'backend' ? 'AI Agent template' : 'Chat Flow template';
  const nodeFilter = template?.project_type === 'backend' ? BACKEND_NODES : FRONTEND_NODES;

  const stats = useMemo(() => {
    const nodesCount = Array.isArray(flow?.nodes) ? flow.nodes.length : 0;
    const edgesCount = Array.isArray(flow?.edges) ? flow.edges.length : 0;
    return { nodesCount, edgesCount };
  }, [flow]);

  const handleUseTemplate = async () => {
    if (!template?.id) return;
    setUsing(true);
    try {
      const body = currentWorkspaceId ? { workspace_id: currentWorkspaceId } : {};
      const newProject = await apiRequest(`/templates/${template.id}/use`, {
        method: 'POST',
        body,
      });
      if (newProject?.id) {
        if (newProject.project_type === 'backend') {
          navigate(`/aiagent/${newProject.id}`, { state: { fromTemplate: true } });
        } else {
          navigate(`/chatflow/${newProject.id}`, { state: { fromTemplate: true } });
        }
        toast({
          title: 'Project created',
          description: `"${newProject.name || template.name || 'Template'}" was created from the template.`,
        });
      }
    } catch (e) {
      toast({
        title: 'Could not use template',
        description: e?.message || 'Something went wrong. Try again.',
        variant: 'destructive',
      });
    } finally {
      setUsing(false);
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <Icons.spinner className="mx-auto mb-4 h-8 w-8 animate-spin" />
            <p className="text-muted-foreground">Loading template preview...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!template) {
    return (
      <AppLayout>
        <div className="mx-auto max-w-4xl space-y-6">
          <PageHeader
            title="Template preview"
            description="This template could not be found."
            icon={Icons.package}
            actions={(
              <Button variant="outline" onClick={() => navigate('/templates')}>
                <Icons.chevronLeft className="h-4 w-4" />
                Back to Templates
              </Button>
            )}
          />
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">
              It may have been deleted or unpublished.
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  const average = getAverageRating(template);

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-5">
        <PageHeader
          title={template.name || 'Template preview'}
          description={template.description || templateTypeLabel}
          icon={Icons.package}
          actions={(
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" onClick={() => navigate('/templates')}>
                <Icons.chevronLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate(`/templates/${template.id}/canvas`, { state: { template } })}
                title="Test this template in the full-screen editor"
              >
                <Icons.play className="h-4 w-4" />
                Test
              </Button>
              <Button onClick={handleUseTemplate} disabled={using}>
                {using ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.project className="h-4 w-4" />}
                {using ? 'Creating…' : 'Use template'}
              </Button>
            </div>
          )}
        />

        <div className="grid gap-4 lg:grid-cols-[360px_1fr]">
          <Card className="h-fit">
            <CardContent className="space-y-4 p-5">
              <div className="space-y-1">
                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Details
                </div>
                <div className="text-sm font-semibold text-foreground">{templateTypeLabel}</div>
                <div className="text-xs text-muted-foreground">
                  ⭐ {average.toFixed(1)} ({template.rating_count || 0})
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-border/70 bg-muted/20 p-3">
                  <div className="text-xs font-medium text-muted-foreground">Nodes</div>
                  <div className="mt-1 text-lg font-semibold text-foreground">{stats.nodesCount}</div>
                </div>
                <div className="rounded-xl border border-border/70 bg-muted/20 p-3">
                  <div className="text-xs font-medium text-muted-foreground">Edges</div>
                  <div className="mt-1 text-lg font-semibold text-foreground">{stats.edgesCount}</div>
                </div>
              </div>

              {template.category ? (
                <div className="rounded-xl border border-border/70 bg-muted/20 p-3">
                  <div className="text-xs font-medium text-muted-foreground">Category</div>
                  <div className="mt-1 text-sm font-semibold text-foreground">{template.category}</div>
                </div>
              ) : null}

              <div className="text-xs text-muted-foreground">
                Preview mode: this will not create a project unless you click <span className="font-medium text-foreground">Use template</span>.
              </div>
            </CardContent>
          </Card>

          <div className="h-[calc(100vh-220px)] overflow-hidden rounded-xl border border-border/70 bg-background">
            <ReactFlowProvider key="template-preview-reactflow">
              <Editor
                projectId={-1}
                nodeFilter={nodeFilter}
                showChat={template?.project_type === 'backend'}
                showConfigConditionally={template?.project_type !== 'backend'}
                showCodeTab={true}
                codeViewType={template?.project_type === 'backend' ? 'python' : 'javascript'}
                allowTemplatePublish={false}
                initialFlow={flow}
              />
            </ReactFlowProvider>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

