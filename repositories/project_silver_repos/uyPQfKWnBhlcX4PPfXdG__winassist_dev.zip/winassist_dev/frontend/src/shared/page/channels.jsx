import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Icons } from '../../components/ui/icons';
import { cn } from '../../lib/utils';

const STATUS_BADGE = {
  live: { label: 'Live', variant: 'default', className: 'border-transparent bg-emerald-600 text-white hover:bg-emerald-700' },
  palette: {
    label: 'In flow builder',
    variant: 'secondary',
    className: 'border-transparent bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-100',
  },
};

const CHANNELS = [
  {
    id: 'web',
    name: 'Web',
    statusKey: 'live',
    Icon: Icons.globe,
    summary: 'Website widget, hosted viewer, and browser chat experiences.',
    bullets: [
      'Build journeys in Chat Flow and publish the embeddable widget.',
      'Share hosted widget links for testing and light deployments.',
    ],
    action: { label: 'Open Chat Flow', path: '/chatflow' },
    actionSecondary: null,
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    statusKey: 'live',
    iconUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/5e/WhatsApp_icon.png',
    summary: 'Self-serve setup plus WhatsApp Cloud API presets and flow logic for Business messaging.',
    bullets: [
      'Connect customer-owned WhatsApp numbers from the guided setup wizard.',
      'WhatsApp API nodes still remain available in the AI Agent palette for advanced use cases.',
    ],
    action: { label: 'Connect WhatsApp', path: '/integrations/whatsapp' },
    actionSecondary: { label: 'Open AI Agent', path: '/aiagent' },
  },
  {
    id: 'telegram',
    name: 'Telegram',
    statusKey: 'palette',
    iconUrl:
      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Telegram_logo.svg/960px-Telegram_logo.svg.png',
    summary: 'Telegram is a first-class target in the node palette for cross-channel flows.',
    bullets: [
      'Filter the node list with the Telegram channel in Chat Flow.',
      'Reuse the same journey patterns as Web where channel rules allow.',
    ],
    action: { label: 'Open Chat Flow', path: '/chatflow' },
    actionSecondary: { label: 'Open AI Agent', path: '/aiagent' },
  },
  {
    id: 'instagram',
    name: 'Instagram',
    statusKey: 'palette',
    iconUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png',
    summary: 'Instagram messaging is modeled in the builders alongside Web and WhatsApp.',
    bullets: [
      'Filter nodes by Instagram in Chat Flow when designing DM-style steps.',
      'Form-style steps are available for Web and Instagram in the palette.',
    ],
    action: { label: 'Open Chat Flow', path: '/chatflow' },
    actionSecondary: { label: 'Open AI Agent', path: '/aiagent' },
  },
];

export default function ChannelsPage() {
  const navigate = useNavigate();
  const liveCount = CHANNELS.filter((c) => c.statusKey === 'live').length;

  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-8">
        <PageHeader
          icon={Icons.globe}
          title="Channels"
          description="WinAssist supports Web, WhatsApp, Telegram, and Instagram across the Chat Flow and AI Agent builders. Use this overview to see what is live today and where to configure each surface."
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Live delivery</CardDescription>
              <CardTitle className="text-2xl">{liveCount}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Web widget and WhatsApp Cloud API paths you can ship with today.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Flow-ready surfaces</CardDescription>
              <CardTitle className="text-2xl">{CHANNELS.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                All four channels appear in the builder channel filters and node categories.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Chat Flow</CardDescription>
              <CardTitle className="text-2xl text-primary">Frontend</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Web, WhatsApp, Telegram, and Instagram filters in the node palette.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>AI Agent</CardDescription>
              <CardTitle className="text-2xl text-primary">Backend</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                WhatsApp Cloud API presets plus agents and tools for messaging backends.
              </p>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="mb-4 text-lg font-semibold tracking-tight text-foreground">Channel directory</h2>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            {CHANNELS.map((ch) => {
              const status = STATUS_BADGE[ch.statusKey];
              return (
                <Card key={ch.id} className="flex flex-col border-border/80 shadow-sm">
                  <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 pb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        {ch.iconUrl ? (
                          <img
                            src={ch.iconUrl}
                            alt=""
                            className="h-7 w-7 object-contain"
                            loading="lazy"
                            decoding="async"
                          />
                        ) : (
                          <ch.Icon className="h-5 w-5" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <CardTitle className="text-base">{ch.name}</CardTitle>
                        <CardDescription className="mt-1 line-clamp-2">{ch.summary}</CardDescription>
                      </div>
                    </div>
                    <Badge className={cn('shrink-0', status.className)} variant={status.variant}>
                      {status.label}
                    </Badge>
                  </CardHeader>
                  <CardContent className="flex flex-1 flex-col gap-4 pt-0">
                    <ul className="list-disc space-y-1.5 pl-4 text-sm text-muted-foreground">
                      {ch.bullets.map((line) => (
                        <li key={line}>{line}</li>
                      ))}
                    </ul>
                    <div className="mt-auto flex flex-wrap gap-2">
                      <Button size="sm" variant="default" onClick={() => navigate(ch.action.path)}>
                        {ch.action.label}
                      </Button>
                      {ch.actionSecondary ? (
                        <Button size="sm" variant="outline" onClick={() => navigate(ch.actionSecondary.path)}>
                          {ch.actionSecondary.label}
                        </Button>
                      ) : null}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        <Card className="border-dashed border-primary/25 bg-muted/20">
          <CardHeader>
            <CardTitle className="text-base">Roadmap</CardTitle>
            <CardDescription>
              Additional carrier channels (for example SMS) and deeper per-channel credential wizards can layer on
              top of this directory without changing how Web, WhatsApp, Telegram, and Instagram appear in the builders
              today.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    </AppLayout>
  );
}
