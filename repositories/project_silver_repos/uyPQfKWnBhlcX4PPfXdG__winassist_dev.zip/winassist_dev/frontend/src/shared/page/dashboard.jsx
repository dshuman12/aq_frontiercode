import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import useUserStore from '../../store/user';
import { useWorkspaces } from '../../hooks/workspace';
import { apiRequest, canUseAuthenticatedRequests } from '../../lib/api-client';
import { Icons } from '../../components/ui/icons';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  AnalyticsSection,
  ChartPanel,
  EmptyAnalyticsState,
  MetricCard,
  QuickInsightCard,
  RankedProjectList,
  TopProjectCard,
  analyticsCardClass,
  compareTrailingWindows,
  formatCompactNumber,
  getUsageScore,
} from '../../components/shared/analytics-ui';

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-5))',
];
const CHART_GRID = 'hsl(var(--border))';
const CHART_TICK = { fill: 'hsl(var(--muted-foreground))', fontSize: 12 };
const LEGEND_STYLE = { color: 'hsl(var(--muted-foreground))' };
const TOOLTIP_STYLE = {
  borderRadius: '16px',
  border: '1px solid hsl(var(--border))',
  backgroundColor: 'hsl(var(--popover))',
  color: 'hsl(var(--popover-foreground))',
  boxShadow: '0 20px 40px -28px rgba(15, 23, 42, 0.35)',
};
const HERO_CARD_STYLE = {
  backgroundImage:
    'radial-gradient(circle at top left, hsl(var(--chart-1) / 0.18), transparent 42%), radial-gradient(circle at top right, hsl(var(--chart-4) / 0.16), transparent 40%), linear-gradient(180deg, hsl(var(--card)), hsl(var(--background)))',
};

function sumBy(items, getValue) {
  return (items || []).reduce((sum, item) => sum + Number(getValue(item) || 0), 0);
}

function getPeakEntry(items, getValue) {
  if (!Array.isArray(items) || items.length === 0) return null;
  return [...items].sort((a, b) => Number(getValue(b) || 0) - Number(getValue(a) || 0))[0];
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useUserStore();
  const { currentWorkspaceId, loading: workspaceLoading } = useWorkspaces();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState(30);
  const [isCustomRange, setIsCustomRange] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [appliedCustomStartDate, setAppliedCustomStartDate] = useState('');
  const [appliedCustomEndDate, setAppliedCustomEndDate] = useState('');

  const selectedDays = useMemo(() => {
    if (!isCustomRange || !appliedCustomStartDate || !appliedCustomEndDate) return days;

    const start = new Date(appliedCustomStartDate);
    const end = new Date(appliedCustomEndDate);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start > end) return days;

    const msInDay = 24 * 60 * 60 * 1000;
    const diffDays = Math.floor((end.getTime() - start.getTime()) / msInDay) + 1;
    return Math.max(1, diffDays);
  }, [isCustomRange, appliedCustomStartDate, appliedCustomEndDate, days]);

  useEffect(() => {
    if (!canUseAuthenticatedRequests(user)) {
      setStats(null);
      setLoading(false);
      return;
    }
    if (workspaceLoading) {
      setLoading(true);
      return;
    }
    fetchDashboardStats();
  }, [selectedDays, currentWorkspaceId, user?.token, workspaceLoading]);

  useEffect(() => {
    if (!canUseAuthenticatedRequests(user) || workspaceLoading) return undefined;
    const refreshInterval = setInterval(() => {
      fetchDashboardStats();
    }, 5 * 60 * 1000);
    return () => clearInterval(refreshInterval);
  }, [selectedDays, currentWorkspaceId, user?.token, workspaceLoading]);

  const fetchDashboardStats = async () => {
    if (!canUseAuthenticatedRequests(user)) return;
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('days', String(selectedDays));
      if (currentWorkspaceId) params.set('workspace_id', currentWorkspaceId);

      try {
        const data = await apiRequest(`/dashboard/stats?${params.toString()}`, {
          method: 'GET',
          showErrorToast: false,
        });
        setStats(data);
      } catch (error) {
        if (error?.status === 401) {
          return;
        }
        return;
      }
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const getProjectTypeLabel = (projectType) => {
    if (projectType === 'backend') return 'AI Agent';
    if (projectType === 'frontend') return 'Chat Flow';
    return projectType;
  };

  const onPresetRangeSelect = (value) => {
    setDays(value);
    setIsCustomRange(false);
  };

  const customRangeLabel =
    isCustomRange && appliedCustomStartDate && appliedCustomEndDate
      ? `${appliedCustomStartDate} to ${appliedCustomEndDate}`
      : `last ${selectedDays} days`;

  const isValidCustomRange =
    customStartDate &&
    customEndDate &&
    new Date(customStartDate).getTime() <= new Date(customEndDate).getTime();

  const isCustomRangeApplied =
    isCustomRange &&
    Boolean(appliedCustomStartDate) &&
    Boolean(appliedCustomEndDate) &&
    customStartDate === appliedCustomStartDate &&
    customEndDate === appliedCustomEndDate;

  const applyCustomRange = () => {
    if (!isValidCustomRange) return;
    setAppliedCustomStartDate(customStartDate);
    setAppliedCustomEndDate(customEndDate);
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <Icons.spinner className="mx-auto mb-4 h-8 w-8 animate-spin" />
            <p className="text-muted-foreground">Loading dashboard...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  const totalProjects =
    Number(stats?.total_backend_projects || 0) + Number(stats?.total_frontend_projects || 0);
  const activeAiAgents = (stats?.chats_per_backend_project || []).filter(
    (project) => Number(project.message_count || 0) > 0 || Number(project.chat_count || 0) > 0
  ).length;
  const activeChatFlows = (stats?.chats_per_frontend_project || []).filter(
    (project) => Number(project.message_count || 0) > 0 || Number(project.chat_count || 0) > 0
  ).length;

  const sessionsTrend = compareTrailingWindows(
    stats?.sessions_per_day,
    (item) => Number(item.backend_sessions || 0) + Number(item.frontend_sessions || 0)
  );
  const messagesTrend = compareTrailingWindows(
    stats?.messages_per_day,
    (item) => Number(item.user_messages || 0) + Number(item.bot_messages || 0)
  );
  const projectCreationTrend = compareTrailingWindows(
    stats?.projects_created_by_month_detailed,
    (item) => Number(item.backend_count || 0) + Number(item.frontend_count || 0)
  );
  const monthlySessionsTrend = compareTrailingWindows(
    stats?.chats_created_by_month,
    (item) => Number(item.count || 0)
  );

  const combinedProjects = [
    ...(stats?.chats_per_backend_project || []).map((project) => ({
      ...project,
      project_type: 'backend',
      total_messages: Number(project.message_count || 0),
      total_chats: Number(project.chat_count || 0),
      usage_score: getUsageScore(project.message_count, project.chat_count),
    })),
    ...(stats?.chats_per_frontend_project || []).map((project) => ({
      ...project,
      project_type: 'frontend',
      total_messages: Number(project.message_count || 0),
      total_chats: Number(project.chat_count || 0),
      usage_score: getUsageScore(project.message_count, project.chat_count),
    })),
  ].sort((a, b) => b.usage_score - a.usage_score);

  const messagesByProject = combinedProjects.slice(0, 8).map((project) => ({
    name:
      project.project_name?.length > 20
        ? `${project.project_name.slice(0, 20)}...`
        : project.project_name,
    messages: project.total_messages,
    sessions: project.total_chats,
  }));

  const sessionsDistribution = [
    { name: 'AI Agent', value: Number(stats?.total_backend_chats || 0) },
    { name: 'Chat Flow', value: Number(stats?.total_frontend_chats || 0) },
  ].filter((entry) => entry.value > 0);

  const peakMessageDay = getPeakEntry(
    stats?.messages_per_day,
    (item) => Number(item.user_messages || 0) + Number(item.bot_messages || 0)
  );
  const peakSessionDay = getPeakEntry(
    stats?.sessions_per_day,
    (item) => Number(item.backend_sessions || 0) + Number(item.frontend_sessions || 0)
  );
  const mostActiveProject = combinedProjects[0];
  const fastestGrowingProject = [...combinedProjects]
    .sort((a, b) => Number(b.total_chats || 0) - Number(a.total_chats || 0))[0];

  const kpis = [
    {
      label: 'Total Projects',
      value: formatCompactNumber(totalProjects),
      description: 'Combined AI Agent and Chat Flow projects in this workspace.',
      comparison: `${stats?.activity_summary?.projects_last_30d || 0} created in the last 30 days`,
      trend: projectCreationTrend,
      icon: Icons.project,
      tone: 'blue',
    },
    {
      label: 'Total Messages',
      value: formatCompactNumber(stats?.total_messages || 0),
      description: 'All user and assistant message volume across your portfolio.',
      comparison: `AI Agent ${formatCompactNumber(stats?.total_backend_messages || 0)} • Chat Flow ${formatCompactNumber(stats?.total_frontend_messages || 0)}`,
      trend: messagesTrend,
      icon: Icons.send,
      tone: 'violet',
    },
    {
      label: 'Total Sessions',
      value: formatCompactNumber(stats?.total_chats || 0),
      description: 'Unique chatbot sessions recorded across live flows and agents.',
      comparison: `AI Agent ${formatCompactNumber(stats?.total_backend_chats || 0)} • Chat Flow ${formatCompactNumber(stats?.total_frontend_chats || 0)}`,
      trend: sessionsTrend,
      icon: Icons.chat,
      tone: 'emerald',
    },
    {
      label: 'Active AI Agents',
      value: formatCompactNumber(activeAiAgents),
      description: 'Backend agents with recent message or session activity.',
      comparison: `${formatCompactNumber(stats?.total_backend_projects || 0)} total AI Agent projects`,
      trend: monthlySessionsTrend,
      icon: Icons.sparkles,
      tone: 'amber',
    },
    {
      label: 'Active Chat Flows',
      value: formatCompactNumber(activeChatFlows),
      description: 'Frontend chat flows currently receiving user engagement.',
      comparison: `${formatCompactNumber(stats?.total_frontend_projects || 0)} total Chat Flow projects`,
      trend: sessionsTrend,
      icon: Icons.gitFork,
      tone: 'cyan',
    },
    {
      label: 'Tools Created',
      value: formatCompactNumber(stats?.total_tools || 0),
      description: 'Reusable tools available to power agent and flow automation.',
      comparison: `${stats?.activity_summary?.tools_last_30d || 0} new tools in the last 30 days`,
      trend: stats?.activity_summary?.tools_last_30d || 0,
      icon: Icons.tool,
      tone: 'rose',
    },
  ];

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-8">
        <PageHeader
          title="Dashboard"
          description={
            user
              ? `Welcome back, ${[user.first_name, user.last_name].filter(Boolean).join(' ') || user.email || 'there'}`
              : 'Welcome back'
          }
          icon={Icons.home}
        />
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="space-y-1">
            <h2 className="text-xl font-semibold tracking-tight text-foreground">Analytics Overview</h2>
            <p className="text-sm text-muted-foreground">
              Explore workspace performance, usage trends, and growth signals for the selected reporting window.
            </p>
          </div>
          <div className="w-full md:w-auto">
            <div className="flex w-full flex-col gap-2 md:items-end">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground md:text-right">
                Time Range Filter
              </div>
              <div className="grid w-full grid-cols-4 gap-2 rounded-2xl border border-border/70 bg-background/80 p-1 shadow-sm md:w-auto md:min-w-[360px] md:grid-cols-4">
                {[7, 30, 90].map((value) => (
                  <Button
                    key={value}
                    size="sm"
                    variant={!isCustomRange && days === value ? 'default' : 'outline'}
                    onClick={() => onPresetRangeSelect(value)}
                    className="rounded-xl px-3.5 transition-all duration-200 hover:-translate-y-0.5"
                  >
                    {value === 7 ? '7 Days' : value === 30 ? '30 Days' : '90 Days'}
                  </Button>
                ))}
                <Button
                  size="sm"
                  variant={isCustomRange ? 'default' : 'outline'}
                  onClick={() => {
                    if (isCustomRange) {
                      setIsCustomRange(false);
                      return;
                    }
                    setIsCustomRange(true);
                    if (!customStartDate && appliedCustomStartDate) setCustomStartDate(appliedCustomStartDate);
                    if (!customEndDate && appliedCustomEndDate) setCustomEndDate(appliedCustomEndDate);
                  }}
                  className="rounded-xl px-3.5 transition-all duration-200 hover:-translate-y-0.5"
                >
                  Custom
                </Button>
              </div>
              {isCustomRange ? (
                <div className="w-full space-y-2 rounded-xl border border-border/60 bg-background p-3 md:max-w-[380px] md:ml-auto">
                  <div className="grid w-full grid-cols-1 gap-2 md:grid-cols-[1fr_1fr_auto]">
                    <label className="space-y-1 text-xs text-muted-foreground">
                      <span className="uppercase tracking-wider">Start date</span>
                      <input
                        type="date"
                        value={customStartDate}
                        max={customEndDate || undefined}
                        onChange={(event) => setCustomStartDate(event.target.value)}
                        className="h-9 w-full rounded-lg border border-border bg-background px-2 text-sm text-foreground outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
                      />
                    </label>
                    <label className="space-y-1 text-xs text-muted-foreground">
                      <span className="uppercase tracking-wider">End date</span>
                      <input
                        type="date"
                        value={customEndDate}
                        min={customStartDate || undefined}
                        onChange={(event) => setCustomEndDate(event.target.value)}
                        className="h-9 w-full rounded-lg border border-border bg-background px-2 text-sm text-foreground outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
                      />
                    </label>
                    <div className="flex items-end">
                      <Button
                        type="button"
                        size="sm"
                        onClick={applyCustomRange}
                        disabled={!isValidCustomRange}
                        className="h-9 w-full rounded-lg px-3"
                      >
                        Apply
                      </Button>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {isCustomRangeApplied
                      ? `Custom range applied: ${appliedCustomStartDate} to ${appliedCustomEndDate}`
                      : 'Pick start and end date, then click Apply.'}
                  </div>
                  {!isValidCustomRange && customStartDate && customEndDate ? (
                    <div className="text-xs text-destructive">Start date must be before or equal to end date.</div>
                  ) : null}
                </div>
              ) : null}
            </div>
          </div>
        </div>
        <div className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
          <Card className={`${analyticsCardClass} overflow-hidden`} style={HERO_CARD_STYLE}>
            <CardHeader className="space-y-5 p-6 pb-4">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="space-y-2">
                  <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Executive Overview
                  </div>
                  <CardTitle className="text-3xl font-semibold tracking-tight text-foreground">
                    Enterprise analytics for the {customRangeLabel}
                  </CardTitle>
                  <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
                    Monitor project creation, user engagement, session growth, and tool adoption across AI Agent and Chat Flow workspaces.
                  </p>
                </div>
                <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 shadow-sm">
                  <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Workspace Health
                  </div>
                  <div className="mt-2 text-2xl font-semibold text-foreground">
                    {formatCompactNumber(stats?.total_chats || 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    sessions tracked across {formatCompactNumber(totalProjects)} projects
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="grid gap-4 p-6 pt-0 md:grid-cols-3">
              <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Published Templates
                </div>
                <div className="mt-2 text-2xl font-semibold">{formatCompactNumber(stats?.total_published_projects || 0)}</div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Shared templates and reusable experiences published for your team.
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  30 Day Activity
                </div>
                <div className="mt-2 text-2xl font-semibold">{formatCompactNumber(stats?.activity_summary?.chats_last_30d || 0)}</div>
                <p className="mt-1 text-sm text-muted-foreground">
                  New sessions created in the last month across live deployments.
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Portfolio Mix
                </div>
                <div className="mt-2 text-2xl font-semibold">
                  {formatCompactNumber(stats?.total_backend_projects || 0)} / {formatCompactNumber(stats?.total_frontend_projects || 0)}
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  AI Agent vs Chat Flow project distribution in the current workspace.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className={analyticsCardClass}>
            <CardHeader className="space-y-1 p-6 pb-4">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Quick Insights
              </div>
              <CardTitle className="text-xl font-semibold">High-signal business takeaways</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 p-6 pt-0">
              <QuickInsightCard
                title="Most active project"
                value={mostActiveProject?.project_name || 'No activity yet'}
                caption={
                  mostActiveProject
                    ? `${formatCompactNumber(mostActiveProject.total_messages)} messages • ${formatCompactNumber(mostActiveProject.total_chats)} sessions`
                    : 'Create your first AI Agent or Chat Flow to populate this insight.'
                }
                icon={Icons.trophy}
                tone="violet"
              />
              <QuickInsightCard
                title="Fastest growing project"
                value={fastestGrowingProject?.project_name || 'No activity yet'}
                caption={
                  fastestGrowingProject
                    ? `${formatCompactNumber(fastestGrowingProject.total_chats)} sessions in the selected period`
                    : 'Session growth insights appear after your first live conversations.'
                }
                icon={Icons.zap}
                tone="emerald"
              />
              <QuickInsightCard
                title="Messages peak day"
                value={peakMessageDay?.date || 'No activity yet'}
                caption={
                  peakMessageDay
                    ? `${formatCompactNumber(Number(peakMessageDay.user_messages || 0) + Number(peakMessageDay.bot_messages || 0))} total messages`
                    : 'No message activity recorded yet.'
                }
                icon={Icons.send}
                tone="amber"
              />
              <QuickInsightCard
                title="Sessions peak day"
                value={peakSessionDay?.date || 'No activity yet'}
                caption={
                  peakSessionDay
                    ? `${formatCompactNumber(Number(peakSessionDay.backend_sessions || 0) + Number(peakSessionDay.frontend_sessions || 0))} total sessions`
                    : 'No session activity recorded yet.'
                }
                icon={Icons.chat}
                tone="cyan"
              />
            </CardContent>
          </Card>
        </div>

        {totalProjects === 0 ? (
          <EmptyAnalyticsState
            icon={Icons.project}
            title="No activity yet"
            description="Create your first AI Agent or Chat Flow to unlock KPI monitoring, usage trends, and enterprise analytics insights."
          />
        ) : (
          <>
            <AnalyticsSection
              eyebrow={null}
              title="KPI Summary"
              description="A compact operating view of project volume, engagement, sessions, and tool growth."
            >
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
                {kpis.map((metric) => (
                  <MetricCard key={metric.label} {...metric} />
                ))}
              </div>
            </AnalyticsSection>

            <AnalyticsSection
              eyebrow={null}
              title="Activity Trends"
              description="Track portfolio growth, daily usage, and system behavior with smoother charts and richer trend context."
            >
              <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                {stats?.projects_created_by_month?.length > 0 && (
                  <ChartPanel
                    title="Projects Created"
                    description="Workspace project creation by month across all project types."
                  >
                    <ResponsiveContainer width="100%" height={320}>
                      <BarChart data={stats.projects_created_by_month} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
                        <CartesianGrid stroke={CHART_GRID} vertical={false} />
                        <XAxis dataKey="month" tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <YAxis tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: 'hsl(var(--primary) / 0.08)' }} />
                        <Legend wrapperStyle={LEGEND_STYLE} />
                        <Bar dataKey="count" fill="hsl(var(--chart-1))" radius={[10, 10, 0, 0]} name="Projects" />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartPanel>
                )}
                {stats?.chats_created_by_month?.length > 0 && (
                  <ChartPanel
                    title="Sessions Trend"
                    description="Session creation trend across the last twelve months."
                  >
                    <ResponsiveContainer width="100%" height={320}>
                      <AreaChart data={stats.chats_created_by_month} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
                        <defs>
                          <linearGradient id="dashboard-sessions" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="hsl(var(--chart-4))" stopOpacity={0.28} />
                            <stop offset="100%" stopColor="hsl(var(--chart-4))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid stroke={CHART_GRID} vertical={false} />
                        <XAxis dataKey="month" tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <YAxis tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={TOOLTIP_STYLE} />
                        <Legend wrapperStyle={LEGEND_STYLE} />
                        <Area type="monotone" dataKey="count" stroke="hsl(var(--chart-4))" fill="url(#dashboard-sessions)" strokeWidth={3} name="Sessions" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </ChartPanel>
                )}
                {stats?.sessions_per_day?.length > 0 && (
                  <ChartPanel
                    title="Sessions per Day"
                    description="Compare AI Agent and Chat Flow session activity for the selected period."
                  >
                    <ResponsiveContainer width="100%" height={320}>
                      <LineChart data={stats.sessions_per_day} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
                        <CartesianGrid stroke={CHART_GRID} vertical={false} />
                        <XAxis dataKey="date" tick={CHART_TICK} tickLine={false} axisLine={false} minTickGap={28} />
                        <YAxis tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={TOOLTIP_STYLE} />
                        <Legend wrapperStyle={LEGEND_STYLE} />
                        <Line type="monotone" dataKey="backend_sessions" stroke="hsl(var(--chart-1))" strokeWidth={3} dot={false} name="AI Agent sessions" />
                        <Line type="monotone" dataKey="frontend_sessions" stroke="hsl(var(--chart-2))" strokeWidth={3} dot={false} name="Chat Flow sessions" />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartPanel>
                )}
                {stats?.messages_per_day?.length > 0 && (
                  <ChartPanel
                    title="Messages per Day"
                    description="Daily user and assistant message volume with exact hover values."
                  >
                    <ResponsiveContainer width="100%" height={320}>
                      <LineChart data={stats.messages_per_day} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
                        <CartesianGrid stroke={CHART_GRID} vertical={false} />
                        <XAxis dataKey="date" tick={CHART_TICK} tickLine={false} axisLine={false} minTickGap={28} />
                        <YAxis tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={TOOLTIP_STYLE} />
                        <Legend wrapperStyle={LEGEND_STYLE} />
                        <Line type="monotone" dataKey="user_messages" stroke="hsl(var(--chart-4))" strokeWidth={3} dot={false} name="User messages" />
                        <Line type="monotone" dataKey="bot_messages" stroke="hsl(var(--chart-5))" strokeWidth={3} dot={false} name="Bot messages" />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartPanel>
                )}
              </div>
            </AnalyticsSection>

            <AnalyticsSection
              eyebrow={null}
              title="Project Performance"
              description="Identify the strongest performers, compare ranked projects, and inspect message distribution across your portfolio."
            >
              <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                {stats?.most_used_backend_project ? (
                  <TopProjectCard
                    title="Top AI Agent"
                    description="Highest-performing backend project by combined messages and sessions."
                    project={stats.most_used_backend_project}
                    tone="blue"
                    onOpen={() => navigate(`/aiagent/${stats.most_used_backend_project.project_id}`)}
                  />
                ) : null}
                {stats?.most_used_frontend_project ? (
                  <TopProjectCard
                    title="Top Chat Flow"
                    description="Highest-performing frontend flow by combined messages and sessions."
                    project={stats.most_used_frontend_project}
                    tone="cyan"
                    onOpen={() => navigate(`/chatflow/${stats.most_used_frontend_project.project_id}`)}
                  />
                ) : null}
              </div>

              <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                <ChartPanel
                  title="Top AI Agent Projects"
                  description="Ranked by usage score using message and session activity."
                >
                  <RankedProjectList
                    projects={stats?.chats_per_backend_project || []}
                    typeLabel="AI Agent"
                    tone="blue"
                    onOpen={(project) => navigate(`/aiagent/${project.project_id}`)}
                  />
                </ChartPanel>
                <ChartPanel
                  title="Top Chat Flow Projects"
                  description="Ranked by usage score using flow message and session activity."
                >
                  <RankedProjectList
                    projects={stats?.chats_per_frontend_project || []}
                    typeLabel="Chat Flow"
                    tone="cyan"
                    onOpen={(project) => navigate(`/chatflow/${project.project_id}`)}
                  />
                </ChartPanel>
              </div>

              <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.35fr_0.95fr]">
                <ChartPanel
                  title="Messages by Project"
                  description="Distribution of message volume across your highest-traffic projects."
                >
                  {messagesByProject.length > 0 ? (
                    <ResponsiveContainer width="100%" height={340}>
                      <BarChart data={messagesByProject} layout="vertical" margin={{ top: 8, right: 8, left: 12, bottom: 0 }}>
                        <CartesianGrid stroke={CHART_GRID} horizontal={false} />
                        <XAxis type="number" tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <YAxis type="category" dataKey="name" width={140} tick={CHART_TICK} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={TOOLTIP_STYLE} />
                        <Bar dataKey="messages" fill="hsl(var(--chart-2))" radius={[0, 10, 10, 0]} name="Messages" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <p className="py-10 text-sm text-muted-foreground">No project message activity yet.</p>
                  )}
                </ChartPanel>
                <ChartPanel
                  title="Sessions Distribution"
                  description="Share of total sessions between AI Agent and Chat Flow deployments."
                >
                  {sessionsDistribution.length > 0 ? (
                    <ResponsiveContainer width="100%" height={340}>
                      <PieChart>
                        <Pie
                          data={sessionsDistribution}
                          innerRadius={72}
                          outerRadius={112}
                          paddingAngle={4}
                          dataKey="value"
                          nameKey="name"
                        >
                          {sessionsDistribution.map((entry, index) => (
                            <Cell key={`${entry.name}-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={TOOLTIP_STYLE} />
                        <Legend wrapperStyle={LEGEND_STYLE} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <p className="py-10 text-sm text-muted-foreground">No session distribution data yet.</p>
                  )}
                </ChartPanel>
              </div>
            </AnalyticsSection>

            <AnalyticsSection
              eyebrow={null}
              title="Usage Insights"
              description="Recent operating signals, project mix, and activity context to support faster decisions."
            >
              <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1.2fr_0.8fr]">
                <ChartPanel
                  title="Recent Activity"
                  description="Newest projects, sessions, and tools created across the workspace."
                >
                  {stats?.recent_activity?.length > 0 ? (
                    <div className="space-y-3">
                      {stats.recent_activity.map((activity, index) => {
                        const Icon =
                          activity.type === 'project_created'
                            ? Icons.project
                            : activity.type === 'chat_created'
                              ? Icons.chat
                              : Icons.tool;
                        return (
                          <div
                            key={`${activity.name}-${index}`}
                            className="flex items-center justify-between gap-4 rounded-2xl border border-border/70 bg-muted/20 p-4"
                          >
                            <div className="flex min-w-0 items-center gap-3">
                              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted">
                                <Icon className="h-4 w-4 text-muted-foreground" />
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-semibold text-foreground">
                                  {activity.type === 'project_created' && 'Project Created'}
                                  {activity.type === 'chat_created' && 'Session Created'}
                                  {activity.type === 'tool_created' && 'Tool Created'}
                                </p>
                                <p className="truncate text-sm text-muted-foreground">
                                  {activity.name}
                                  {activity.subtype ? ` (${getProjectTypeLabel(activity.subtype)})` : ''}
                                </p>
                              </div>
                            </div>
                            <div className="shrink-0 text-xs text-muted-foreground">
                              {activity.created_at
                                ? new Date(activity.created_at).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })
                                : ''}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="py-10 text-sm text-muted-foreground">No recent activity yet.</p>
                  )}
                </ChartPanel>

                <Card className={analyticsCardClass}>
                  <CardHeader className="space-y-1 p-5 pb-3">
                    <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Portfolio Breakdown
                    </div>
                    <CardTitle className="text-lg font-semibold">Operational mix</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 p-5 pt-0">
                    <div className="rounded-2xl border border-border/70 bg-muted/20 p-4">
                      <div className="text-sm font-medium text-foreground">AI Agent projects</div>
                      <div className="mt-1 text-2xl font-semibold">{formatCompactNumber(stats?.total_backend_projects || 0)}</div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {formatCompactNumber(sumBy(stats?.chats_per_backend_project, (project) => project.message_count || 0))} messages generated in backend automations.
                      </p>
                    </div>
                    <div className="rounded-2xl border border-border/70 bg-muted/20 p-4">
                      <div className="text-sm font-medium text-foreground">Chat Flow projects</div>
                      <div className="mt-1 text-2xl font-semibold">{formatCompactNumber(stats?.total_frontend_projects || 0)}</div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {formatCompactNumber(sumBy(stats?.chats_per_frontend_project, (project) => project.message_count || 0))} messages generated through live conversation flows.
                      </p>
                    </div>
                    <div className="rounded-2xl border border-border/70 bg-muted/20 p-4">
                      <div className="text-sm font-medium text-foreground">Tool adoption</div>
                      <div className="mt-1 text-2xl font-semibold">{formatCompactNumber(stats?.total_tools || 0)}</div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {stats?.activity_summary?.tools_last_30d || 0} tools were created during the latest 30 day operating window.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </AnalyticsSection>
          </>
        )}
      </div>
    </AppLayout>
  );
}
