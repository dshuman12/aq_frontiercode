import { useState, useEffect, useLayoutEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Label } from '../../components/ui/label';
import { Input } from '../../components/ui/input';
import useUserStore from '../../store/user';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../../components/ui/icons';
import { toast } from '../../hooks/toast';
import { copyTextToClipboard } from '../../lib/utils';
import { generateWidgetScript } from '../../utils/codeGenerator';
import { getBackendUrl } from '../../lib/config';

export default function WidgetPreviewPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { user } = useUserStore();
  const [widgetConfig, setWidgetConfig] = useState(null);
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [embedDialogOpen, setEmbedDialogOpen] = useState(false);
  const [savedScriptUrl, setSavedScriptUrl] = useState(null);
  const [publishLoading, setPublishLoading] = useState(false);
  const [generatedScript, setGeneratedScript] = useState(null);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState('Loading project...');
  const [containerReady, setContainerReady] = useState(false);
  const previewContainerRef = useRef(null);
  const isGeneratingRef = useRef(false);
  const mountedRef = useRef(true);
  const injectedScriptRef = useRef(null);
  
  // Callback ref to detect when container is ready
  const setContainerRef = useCallback((node) => {
    if (node) {
      undefined
      previewContainerRef.current = node;
      setContainerReady(true);
    } else {
      undefined
      previewContainerRef.current = null;
      setContainerReady(false);
    }
  }, []);

  // Log component mount
  useEffect(() => {
    undefined
    undefined
    undefined
    undefined
    undefined
    undefined
  }, [projectId]);

  // Fetch project data
  const fetchProjectAndConfig = useCallback(async () => {
    undefined
    undefined
    undefined
    undefined
    
    if (!projectId) {
      console.error('[STEP 1] ERROR: No project ID provided');
      setError('No project ID provided');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      setStatus('Loading project...');
      
      const currentUser = useUserStore.getState().user;
      undefined
      
      if (!currentUser || !currentUser.token) {
        throw new Error('You are not authenticated. Please log in again.');
      }
      
      undefined
      const startTime = Date.now();
      
      const projectData = await apiRequest(`/projects/${projectId}`, {
        method: 'GET',
        includeAuth: true,
        showErrorToast: true,
      });
      
      const fetchTime = Date.now() - startTime;
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      
      if (!projectData) {
        throw new Error('Project not found or you do not have access to it.');
      }
      
      if (!projectData.flow) {
        throw new Error('Project has no flow data. Please create a flow first in the No-Code Frontend editor.');
      }
      
      if (!projectData.flow.nodes || projectData.flow.nodes.length === 0) {
        console.error('[STEP 1] ERROR: Project flow has no nodes');
        throw new Error('Project flow has no nodes. Please add nodes to your flow in the No-Code Frontend editor.');
      }
      
      undefined
      setProject(projectData);
      setStatus('Project loaded. Generating widget...');
      undefined
      
      // Fetch widget config for API key (optional)
      undefined
      try {
        const widgetData = await apiRequest(`/project-analytics/widget/${projectId}`, {
          method: 'GET',
          includeAuth: true,
          showErrorToast: false,
        });
        undefined
        setWidgetConfig(widgetData);
      } catch (widgetError) {
        console.warn('[STEP 1] Failed to fetch widget config (non-critical):', widgetError);
      }
      
      undefined
      undefined
    } catch (error) {
      console.error('========================================');
      console.error('[STEP 1] ERROR in fetchProjectAndConfig');
      console.error('[STEP 1] Error message:', error.message);
      console.error('[STEP 1] Error stack:', error.stack);
      console.error('[STEP 1] Full error:', error);
      console.error('========================================');
      setError(error.message || 'Failed to load project');
      setLoading(false);
      setStatus('');
      toast({
        title: 'Error',
        description: error.message || 'Failed to load project. Please check if you are logged in and have access to this project.',
        variant: 'destructive',
      });
    }
  }, [projectId]);

  // Generate widget script from project flow
  const generateAndLoadWidget = useCallback(async () => {
    undefined
    undefined
    undefined
    undefined
    
    if (!project || !project.flow || !previewContainerRef.current) {
      console.error('[STEP 2] ERROR: Cannot generate widget - missing requirements');
      console.error('[STEP 2] Details:', {
        hasProject: !!project,
        hasFlow: !!project?.flow,
        hasContainer: !!previewContainerRef.current
      });
      return;
    }

    if (isGeneratingRef.current) {
      console.warn('[STEP 2] Already generating, skipping...');
      return;
    }

    try {
      isGeneratingRef.current = true;
      setStatus('Processing flow nodes...');
      undefined
      
      const { nodes: rawNodes, edges: rawEdges } = project.flow;
      undefined
      
      if (!rawNodes || rawNodes.length === 0) {
        throw new Error('Project has no flow nodes. Please create a flow first.');
      }

      // Filter out note nodes (they're not part of the flow logic)
      undefined
      const flowNodesOnly = rawNodes.filter(node => node.type !== 'note');
      undefined
      
      if (flowNodesOnly.length === 0) {
        console.error('[STEP 2] ERROR: No valid flow nodes after filtering');
        throw new Error('Project has no valid flow nodes (only note nodes found). Please add flow nodes like API, Text, Input, etc.');
      }

      setStatus('Processing nodes and edges...');
      undefined
      
      // Process nodes exactly like codeview does
      const nodeProcessingStart = Date.now();
      const flowNodes = await Promise.all(flowNodesOnly.map(async (node, index) => {
        undefined
        const actualNodeId = node.id;
        
        const flatNode = {
          id: actualNodeId,
          type: node.type,
          label: node.data?.label || node.data?.name || '',
        };
        
        // Spread all data properties to top level
        Object.keys(node.data || {}).forEach(key => {
          if (!['id', 'label', 'name', 'data', 'connections', 'class_type'].includes(key)) {
            flatNode[key] = node.data[key];
          }
        });
        
        // For assistant nodes with backend_bot_id, fetch the API key
        if (node.type === 'assistant' && flatNode.backend_bot_id) {
          try {
            const currentUser = useUserStore.getState().user;
            if (currentUser && currentUser.token) {
              const backendProject = await apiRequest(`/projects/${flatNode.backend_bot_id}`, {
                method: 'GET',
                includeAuth: true,
                showErrorToast: false,
              });
              if (backendProject && backendProject.api_key) {
                flatNode.bot_api_key = backendProject.api_key;
                undefined
              }
            }
          } catch (error) {
            console.warn('[Widget Preview] Failed to fetch API key for backend bot:', flatNode.backend_bot_id, error);
          }
        }
        
        return flatNode;
      }));
      
      const nodeProcessingTime = Date.now() - nodeProcessingStart;
      undefined
      undefined

      // Process edges
      undefined
      const flowConnections = (rawEdges || []).map((edge, index) => {
        undefined
        return {
          from: edge.source || edge.from,
          to: edge.target || edge.to,
          sourceHandle: edge.sourceHandle,
          branch: edge.data?.branch,
          isLoop: edge.data?.isLoop || false,
          loopIterations: edge.data?.loopIterations || 5,
        };
      });
      
      undefined

      undefined

      setStatus('Generating widget script...');
      
      // Generate the widget script with error handling
      let script;
      const scriptGenStart = Date.now();
      try {
        undefined
        undefined
        
        script = generateWidgetScript(flowNodes, flowConnections, project.flow?.widget_settings || {});
        
        const scriptGenTime = Date.now() - scriptGenStart;
        undefined
        undefined
      } catch (genError) {
        const scriptGenTime = Date.now() - scriptGenStart;
        console.error('[STEP 2] ERROR in generateWidgetScript after', scriptGenTime, 'ms');
        console.error('[STEP 2] Error type:', genError.constructor.name);
        console.error('[STEP 2] Error message:', genError.message);
        console.error('[STEP 2] Error stack:', genError.stack);
        console.error('[STEP 2] Full error object:', genError);
        throw new Error(`Script generation failed: ${genError.message}`);
      }
      
      if (!script || script.trim().length === 0) {
        console.error('[STEP 2] ERROR: Generated script is empty');
        console.error('[STEP 2] Script value:', script);
        throw new Error('Generated script is empty. Please check your flow configuration.');
      }
      
      undefined
      undefined
      
      if (!mountedRef.current) {
        console.warn('[STEP 2] Component unmounted, aborting...');
        return; // Component unmounted
      }
      
      undefined
      setGeneratedScript(script);
      setError(null); // clear any previous timeout/error
      setStatus('Saving widget script to server...');

      // Save script to backend static folder (widget_<userId>_<projectId>.js) and get URL
      let scriptUrlToLoad = null;
      try {
        undefined
        const staticBasePath = (import.meta.env.VITE_WIDGET_STATIC_BASE_PATH || '').trim();
        const saveBody = { script_content: script };
        if (staticBasePath) saveBody.static_base_path = staticBasePath;
        const saveRes = await apiRequest(`/project-analytics/save-widget-script/${projectId}`, {
          method: 'POST',
          body: saveBody,
          includeAuth: true,
          showErrorToast: true,
        });
        if (saveRes && saveRes.script_url) {
          scriptUrlToLoad = saveRes.script_url;
          setSavedScriptUrl(saveRes.script_url);
          undefined
        }
      } catch (saveErr) {
        console.warn('[STEP 2] Save script failed, falling back to inline script:', saveErr?.message);
        toast({
          title: 'Widget not published',
          description: 'Shareable link will not work until the widget is saved. Check backend can write to static/widgets (or unset VITE_WIDGET_STATIC_BASE_PATH for local dev).',
          variant: 'destructive',
        });
      }

      setStatus('Loading widget...');

      // Use absolute backend URL directly from env when possible.
      // Some builds may provide a relative value like `/v1`; normalize it to an absolute URL.
      const envApiUrlRaw = String(import.meta.env.VITE_API_URL || '').trim();
      const backendBaseCandidate = String(envApiUrlRaw || getBackendUrl() || '').trim();
      let backendBase = backendBaseCandidate;

      if (backendBase && backendBase.startsWith('/') && typeof window !== 'undefined' && window.location?.origin) {
        backendBase = `${window.location.origin}${backendBase}`;
      }

      backendBase = backendBase.endsWith('/') ? backendBase.slice(0, -1) : backendBase;
      if (backendBase && !backendBase.endsWith('/v1')) backendBase = `${backendBase}/v1`;

      if (backendBase && !backendBase.startsWith('http')) {
        console.error('[Widget Preview] VITE_API_URL/backend base is not absolute:', backendBaseCandidate);
      }

      // Final guard: ensure absolute for fetch().
      const absoluteApiUrl = backendBase && backendBase.startsWith('http') ? backendBase : '';
      if (!absoluteApiUrl) {
        throw new Error('Invalid VITE_API_URL/backend URL. Please set an absolute API URL (example: https://api.example.com/v1).');
      }

      // Fetch widget config so we can pass projectId + apiKey + apiUrl to inline script.
      let widgetOptions = { projectId, apiUrl: absoluteApiUrl };
      try {
        const wc = await apiRequest(`/project-analytics/widget/${projectId}`, { method: 'GET' });
        if (wc && wc.api_key != null) {
          widgetOptions = { ...widgetOptions, apiKey: wc.api_key };
        }
      } catch (_) { /* use empty options */ }

      // Always use the freshly generated inline script for preview so widget_settings (colors, icons, etc.) are correct.
      // Using the saved URL can serve a cached script with old settings.
      const scriptToLoad = script;
      undefined
      const loadStart = Date.now();
      loadWidgetScript(scriptToLoad, () => {
        setLoading(false);
        setStatus('');
        setError(null);
        undefined
        undefined
      }, widgetOptions);
      const loadTime = Date.now() - loadStart;
      undefined
    } catch (error) {
      console.error('========================================');
      console.error('[STEP 2] ERROR in generateAndLoadWidget');
      console.error('[STEP 2] Error type:', error.constructor.name);
      console.error('[STEP 2] Error message:', error.message);
      console.error('[STEP 2] Error stack:', error.stack);
      console.error('[STEP 2] Full error object:', error);
      console.error('========================================');
      
      if (!mountedRef.current) {
        console.warn('[STEP 2] Component unmounted, not setting error state');
        return;
      }
      
      setError(error.message || 'Failed to generate widget script');
      setLoading(false);
      setStatus('');
      toast({
        title: 'Generation Error',
        description: `Failed to generate widget script: ${error.message}. Please check the console for details.`,
        variant: 'destructive',
      });
    } finally {
      isGeneratingRef.current = false;
      undefined
    }
  }, [project]);

  // Load widget script into preview container.
  // scriptContentOrUrl: either inline script string or URL (starts with 'http') to load from server.
  // onLoaded: optional callback when script is loaded (for URL) or executed (inline).
  // options: optional { projectId, apiKey, apiUrl } so inline script can send step analytics (reportFlowStep).
  const loadWidgetScript = useCallback((scriptContentOrUrl, onLoaded, options = {}) => {
    undefined
    undefined
    undefined
    const isUrl = typeof scriptContentOrUrl === 'string' && scriptContentOrUrl.startsWith('http');
    undefined

    if (!scriptContentOrUrl || !previewContainerRef.current) {
      console.error('[STEP 3] ERROR: Cannot load script - missing requirements');
      if (onLoaded) onLoaded();
      return;
    }

    try {
      const container = previewContainerRef.current;
      if (!container) {
        if (onLoaded) onLoaded();
        return;
      }

      undefined
      container.innerHTML = '';

      // Ensure widget runtime gets an absolute API base (includes /v1).
      if (typeof window !== 'undefined') {
        const baseRaw = String(options.apiUrl || getBackendUrl() || '').trim();
        let base = baseRaw.endsWith('/') ? baseRaw.slice(0, -1) : baseRaw;
        if (base && !base.endsWith('/v1')) base = `${base}/v1`;
        if (base.startsWith('http')) {
          window.BACKEND_API_URL = base;
        } else {
          delete window.BACKEND_API_URL;
        }
      }

      // Create demo content wrapper
      undefined
      const wrapper = document.createElement('div');
      wrapper.className = 'relative w-full min-h-[600px]';
      wrapper.style.position = 'relative';

      const demoContent = document.createElement('div');
      demoContent.className = 'rounded-lg border border-border/70 bg-card p-8 shadow-sm';
      demoContent.innerHTML = `
        <h1 class="mb-4 text-2xl font-bold text-card-foreground">Hello World</h1>
        <p class="mb-2 text-muted-foreground">This is a demo page to test the WinAssist chatbot widget.</p>
        <p class="text-muted-foreground">The widget should appear in the bottom-right corner of this page.</p>
      `;
      wrapper.appendChild(demoContent);
      container.appendChild(wrapper);
      undefined

      const scriptEl = document.createElement('script');
      const done = () => {
        if (onLoaded) onLoaded();
        setTimeout(() => {
          const widgetElements = document.querySelectorAll('[id^="winassist-chatbot-"]');
          undefined
        }, 2000);
      };

      scriptEl.onerror = (error) => {
        console.error('[STEP 3] ERROR: Script execution/load error', error);
        toast({
          title: 'Script Error',
          description: 'Failed to load or execute widget script. Check console for details.',
          variant: 'destructive',
        });
        done();
      };

      if (isUrl) {
        undefined
        scriptEl.src = scriptContentOrUrl;
        scriptEl.onload = () => {
          undefined
          done();
        };
      } else {
        // Inline script: set data attributes so createWidget() can replace placeholders and reportFlowStep can send analytics
        const { projectId: pId, apiKey: aKey, apiUrl: aUrl } = options;
        if (pId != null) scriptEl.setAttribute('data-project-id', pId);
        if (aKey != null) scriptEl.setAttribute('data-api-key', aKey);
        if (aUrl != null) scriptEl.setAttribute('data-api-url', aUrl);
        if (pId != null) scriptEl.setAttribute('data-analytics-project-id', pId);
        scriptEl.textContent = scriptContentOrUrl;
        scriptEl.onload = () => undefined
        done();
      }

      undefined
      if (injectedScriptRef.current && injectedScriptRef.current.parentNode) {
        injectedScriptRef.current.remove();
        injectedScriptRef.current = null;
      }
      document.head.appendChild(scriptEl);
      injectedScriptRef.current = scriptEl;
      undefined
      undefined
    } catch (error) {
      console.error('[STEP 3] ERROR in loadWidgetScript', error);
      toast({
        title: 'Error',
        description: `Failed to execute widget script: ${error.message}. Please check the console.`,
        variant: 'destructive',
      });
      if (onLoaded) onLoaded();
    }
  }, []);

  // Initial fetch on mount
  useEffect(() => {
    undefined
    undefined
    undefined
    undefined
    
    mountedRef.current = true;
    const currentUser = useUserStore.getState().user;
    
    undefined
    
    if (!currentUser || !currentUser.token) {
      console.error('[MOUNT] ERROR: User not authenticated');
      setError('You are not authenticated. Please log in.');
      setLoading(false);
      toast({
        title: 'Authentication Required',
        description: 'Please log in to view widget preview.',
        variant: 'destructive',
      });
      setTimeout(() => navigate('/auth/login'), 2000);
      return;
    }

    if (projectId) {
      undefined
      fetchProjectAndConfig();
    } else {
      console.error('[MOUNT] ERROR: No project ID');
    }
    
    return () => {
      undefined
      mountedRef.current = false;
    };
  }, [projectId, fetchProjectAndConfig, navigate]);

  // Clean up widget (script + DOM) when leaving this page — runs synchronously before next paint
  const removeWidgetFromDocument = useCallback(() => {
    if (typeof document === 'undefined') return;
    if (injectedScriptRef.current && injectedScriptRef.current.parentNode) {
      injectedScriptRef.current.remove();
      injectedScriptRef.current = null;
    }
    const widgetContainer = document.getElementById('flow-diagram-widget-container');
    if (widgetContainer?.parentNode) widgetContainer.remove();
    const toggleBtns = document.querySelectorAll('[data-flow-toggle]');
    toggleBtns.forEach((el) => el.parentNode?.removeChild(el));
    const styles = document.head.querySelectorAll('style');
    styles.forEach((el) => {
      if (el.textContent?.includes('flow-diagram-widget-container')) el.remove();
    });
    if (typeof window !== 'undefined' && window.FlowDiagramWidget) {
      delete window.FlowDiagramWidget;
    }
  }, []);

  useLayoutEffect(() => {
    return () => {
      removeWidgetFromDocument();
    };
  }, [removeWidgetFromDocument]);
  
  // Generate widget when project is loaded AND container is ready
  useEffect(() => {
    undefined
    undefined
    undefined
    undefined
    undefined
    
    if (!mountedRef.current) {
      undefined
      return;
    }
    
    const checks = {
      hasProject: !!project,
      hasFlow: !!project?.flow,
      hasNodes: !!project?.flow?.nodes,
      nodesCount: project?.flow?.nodes?.length,
      hasContainer: !!previewContainerRef.current,
      containerReady: containerReady,
      isGenerating: isGeneratingRef.current,
      hasUser: !!useUserStore.getState().user,
      hasToken: !!useUserStore.getState().user?.token
    };
    
    undefined
    
    const currentUser = useUserStore.getState().user;
    const allConditionsMet = 
      project && 
      project.flow && 
      project.flow.nodes && 
      project.flow.nodes.length > 0 && 
      containerReady &&
      previewContainerRef.current && 
      currentUser && 
      currentUser.token && 
      !isGeneratingRef.current;
    
    undefined
    
    if (allConditionsMet) {
      undefined
      // Use setTimeout to ensure DOM is fully ready
      setTimeout(() => {
        if (mountedRef.current && previewContainerRef.current && containerReady && !isGeneratingRef.current) {
          undefined
          generateAndLoadWidget();
        } else {
          undefined
        }
      }, 100);
    } else {
      undefined
      if (!project) undefined
      if (!project?.flow) undefined
      if (!project?.flow?.nodes || project?.flow?.nodes.length === 0) undefined
      if (!containerReady || !previewContainerRef.current) undefined
      if (!currentUser || !currentUser.token) undefined
      if (isGeneratingRef.current) undefined
    }
    undefined
  }, [project, containerReady, generateAndLoadWidget]);
  
  // Safety timeout only when we're actually waiting for generation (container + project ready)
  // so we don't timeout during initial fetch or before container is ready
  useEffect(() => {
    const waitingForGeneration = loading && !generatedScript && project?.flow?.nodes?.length > 0 && containerReady;
    if (!waitingForGeneration) return;

    const timeoutId = setTimeout(() => {
      if (mountedRef.current && !generatedScript) {
        console.error('[Widget Preview] Timeout: Widget generation took too long');
        setError('Widget generation timed out. Please try again or check your flow configuration.');
        setLoading(false);
        setStatus('');
        isGeneratingRef.current = false;
      }
    }, 30000);

    return () => clearTimeout(timeoutId);
  }, [loading, generatedScript, project, containerReady]);

  const copyToClipboard = async (text) => {
    try {
      await copyTextToClipboard(text ?? '');
      toast({
        title: 'Copied',
        description: 'Code copied to clipboard',
      });
    } catch {
      toast({
        title: 'Copy failed',
        description: 'Could not copy to clipboard',
        variant: 'destructive',
      });
    }
  };

  const openInNewTab = () => {
    if (!generatedScript) return;
    const isDark = typeof document !== 'undefined' && document.documentElement.classList.contains('dark');
    const bodyBackground = isDark ? '#0f172a' : '#f5f5f5';
    const surfaceBackground = isDark ? '#162033' : '#ffffff';
    const headingColor = isDark ? '#f8fafc' : '#333333';
    const bodyColor = isDark ? '#cbd5e1' : '#666666';
    const borderColor = isDark ? 'rgba(148, 163, 184, 0.18)' : 'rgba(15, 23, 42, 0.08)';

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Widget Preview - WinAssist</title>
  <style>
    body {
      margin: 0;
      padding: 20px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
      background: ${bodyBackground};
    }
    .demo-content {
      max-width: 800px;
      margin: 0 auto;
      background: ${surfaceBackground};
      padding: 40px;
      border-radius: 8px;
      border: 1px solid ${borderColor};
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    h1 {
      color: ${headingColor};
      margin-bottom: 20px;
    }
    p {
      color: ${bodyColor};
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="demo-content">
    <h1>Hello World</h1>
    <p>This is a demo page to test the WinAssist chatbot widget.</p>
    <p>The widget should appear in the bottom-right corner of this page.</p>
  </div>
  <script>
    ${generatedScript}
  </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  const handleBack = () => {
    // Go back to the no-code frontend canvas for this project
    if (projectId) {
      navigate(`/chatflow/${projectId}`);
    } else {
      navigate(-1);
    }
  };

  // Full-page loading only while fetching project (so the preview container can mount once we have project)
  if (loading && !project && !error) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <Icons.spinner className="w-8 h-8 animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading widget preview...</p>
            {status && (
              <p className="text-xs text-muted-foreground mt-2">{status}</p>
            )}
            <p className="text-xs text-muted-foreground mt-2">This may take a few moments</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Error state (before project loads)
  if (error && !project) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <Card className="max-w-md">
            <CardHeader>
              <CardTitle className="text-destructive">Error Loading Widget</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">{error}</p>
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => {
                  setError(null);
                  setLoading(true);
                  fetchProjectAndConfig();
                }}>
                  Retry
                </Button>
                <Button variant="outline" onClick={() => navigate('/project-dashboard')}>
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  // Main content
  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <PageHeader
          title="Widget Preview"
          description="Test your chatbot widget in a live environment"
          actions={
            <div className="flex flex-wrap gap-2 justify-end">
              <Button variant="outline" onClick={handleBack} size="sm" className="shrink-0">
                <Icons.chevronLeft className="w-4 h-4 mr-2" />
                Back to Canvas
              </Button>
              {generatedScript && (
                <>
                  <Button variant="outline" onClick={() => setEmbedDialogOpen(true)} size="sm" className="shrink-0">
                    <Icons.code className="w-4 h-4 mr-2" />
                    View Embed Code
                  </Button>
                  <Button onClick={openInNewTab} size="sm" className="shrink-0">
                    <Icons.externalLink className="w-4 h-4 mr-2" />
                    Open in New Tab
                  </Button>
                </>
              )}
            </div>
          }
        />
            {error && (
              <Card className="border-destructive">
                <CardHeader>
                  <CardTitle className="text-destructive">Error</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{error}</p>
                  <Button onClick={() => {
                    setError(null);
                    setLoading(true);
                    isGeneratingRef.current = false;
                    if (project) {
                      generateAndLoadWidget();
                    } else {
                      fetchProjectAndConfig();
                    }
                  }}>
                    Retry
                  </Button>
                </CardContent>
              </Card>
            )}

            <div ref={setContainerRef} className="sr-only" aria-hidden="true" />

            <Card>
              <CardHeader>
                <CardTitle>Shareable widget link</CardTitle>
                <CardDescription>
                  Share this link so anyone can open the widget in their browser (no login required). Publish the widget once so the link works.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {!savedScriptUrl && generatedScript && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                    <Button
                      disabled={publishLoading}
                      onClick={async () => {
                        setPublishLoading(true);
                        try {
                          const staticBasePath = (import.meta.env.VITE_WIDGET_STATIC_BASE_PATH || '').trim();
                          const saveBody = { script_content: generatedScript };
                          if (staticBasePath) saveBody.static_base_path = staticBasePath;
                          const saveRes = await apiRequest(`/project-analytics/save-widget-script/${projectId}`, {
                            method: 'POST',
                            body: saveBody,
                            includeAuth: true,
                            showErrorToast: true,
                          });
                          if (saveRes?.script_url) {
                            setSavedScriptUrl(saveRes.script_url);
                            toast({ title: 'Widget published', description: 'Shareable link is ready.' });
                          }
                        } catch (e) {
                          toast({
                            title: 'Publish failed',
                            description: e?.message || 'Backend may not have write access to static/widgets. For local dev, unset VITE_WIDGET_STATIC_BASE_PATH in frontend .env.',
                            variant: 'destructive',
                          });
                        } finally {
                          setPublishLoading(false);
                        }
                      }}
                    >
                      {publishLoading ? <Icons.spinner className="w-4 h-4 animate-spin mr-2" /> : null}
                      {publishLoading ? 'Publishing…' : 'Publish widget'}
                    </Button>
                    <span className="text-sm text-muted-foreground">Required for the shareable link to work</span>
                  </div>
                )}
                <div>
                  <Label className="text-muted-foreground">Shareable link</Label>
                  <div className="flex gap-2 mt-1 flex-wrap items-center">
                    <Input
                      readOnly
                      value={
                        (import.meta.env.VITE_APP_URL || (typeof window !== 'undefined' ? window.location.origin : ''))
                        + `/widget/${projectId || ''}`
                      }
                      className="font-mono text-sm"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={async () => {
                        const url = (import.meta.env.VITE_APP_URL || (typeof window !== 'undefined' ? window.location.origin : '')) + `/widget/${projectId || ''}`;
                        try {
                          await copyTextToClipboard(url);
                          toast({ title: 'Copied', description: 'Shareable link copied to clipboard' });
                        } catch {
                          toast({ title: 'Copy failed', variant: 'destructive' });
                        }
                      }}
                    >
                      <Icons.copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                {savedScriptUrl && (
                  <div>
                    <Label className="text-muted-foreground">Script URL (for embedding elsewhere)</Label>
                    <div className="flex gap-2 mt-1 flex-wrap items-center">
                      <Input readOnly value={savedScriptUrl} className="font-mono text-sm" />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={async () => {
                          try {
                            await copyTextToClipboard(savedScriptUrl ?? '');
                            toast({ title: 'Copied', description: 'Script URL copied' });
                          } catch {
                            toast({ title: 'Copy failed', variant: 'destructive' });
                          }
                        }}
                      >
                        <Icons.copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Validation Checklist</CardTitle>
                <CardDescription>
                  Verify these features are working correctly
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Icons.checkCircle className="w-5 h-5 text-muted-foreground" />
                    <span>Widget loads and appears on the page</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Icons.checkCircle className="w-5 h-5 text-muted-foreground" />
                    <span>Chat interface opens when clicked</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Icons.checkCircle className="w-5 h-5 text-muted-foreground" />
                    <span>Messages can be sent and received</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Icons.checkCircle className="w-5 h-5 text-muted-foreground" />
                    <span>Language selection works (if applicable)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Icons.checkCircle className="w-5 h-5 text-muted-foreground" />
                    <span>Messages are stored in the database</span>
                  </div>
                </div>
              </CardContent>
              </Card>
            </div>

        <Dialog open={embedDialogOpen} onOpenChange={setEmbedDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Widget Embed Code</DialogTitle>
            <DialogDescription>
              Copy and paste this code into your website to embed the chatbot widget
            </DialogDescription>
          </DialogHeader>
          {generatedScript && (
            <div className="space-y-4">
              <div>
                <Label>Generated Widget Script</Label>
                <div className="mt-1">
                  <textarea
                    readOnly
                    value={generatedScript}
                    className="w-full h-64 p-2 border rounded font-mono text-sm"
                  />
                  <Button
                    className="mt-2"
                    variant="outline"
                    onClick={() => copyToClipboard(generatedScript)}
                  >
                    <Icons.copy className="w-4 h-4 mr-2" />
                    Copy Script
                  </Button>
                </div>
              </div>
              {widgetConfig && (
                <div>
                  <Label>API Key</Label>
                  <div className="flex gap-2 mt-1">
                    <Input value={widgetConfig.api_key} readOnly type="password" />
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => copyToClipboard(widgetConfig.api_key)}
                    >
                      <Icons.copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
