import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../../components/shared/app-layout';
import { PageHeader } from '../../components/shared/page-header';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from '../../components/ui/select';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import useUserStore from '../../store/user';
import useWorkspaceStore from '../../store/workspace';
import { apiRequest } from '../../lib/api-client';
import { copyTextToClipboard } from '../../lib/utils';
import { Icons } from '../../components/ui/icons';
import { toast } from '../../hooks/toast';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from 'recharts';
import {
  AnalyticsSection,
  ChartPanel,
  EmptyAnalyticsState,
  MetricCard,
  ProjectAnalyticsCard,
  QuickInsightCard,
  RankedProjectList,
  analyticsCardClass,
  formatCompactNumber,
  getUsageScore,
} from '../../components/shared/analytics-ui';

// Color palette for charts
const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-5))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-4))',
];
const CHART_GRID = 'hsl(var(--border))';
const TOOLTIP_STYLE = {
  borderRadius: '16px',
  border: '1px solid hsl(var(--border))',
  backgroundColor: 'hsl(var(--popover))',
  color: 'hsl(var(--popover-foreground))',
  boxShadow: '0 20px 40px -28px rgba(15, 23, 42, 0.35)',
};
const HERO_CARD_STYLE = {
  backgroundImage:
    'radial-gradient(circle at top left, hsl(var(--chart-1) / 0.18), transparent 42%), radial-gradient(circle at top right, hsl(var(--chart-4) / 0.16), transparent 40%), linear-gradient(180deg, hsl(var(--card)), hsl(var(--background)))',
};

function getSelectedProject(projects, projectId) {
  return projects.find((project) => project.id === projectId);
}

export default function ProjectDashboardPage() {
  const navigate = useNavigate();
  const { user } = useUserStore();
  const currentWorkspaceId = useWorkspaceStore((state) => state.currentWorkspaceId);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [frontendProjects, setFrontendProjects] = useState([]);
  const [allProjects, setAllProjects] = useState([]); // frontend + backend for dropdown
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  const [period, setPeriod] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [widgetDialogOpen, setWidgetDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [widgetConfig, setWidgetConfig] = useState(null);
  const [loadingWidget, setLoadingWidget] = useState(false);
  const [funnel, setFunnel] = useState(null);
  const [timeline, setTimeline] = useState(null);
  const [funnelLoading, setFunnelLoading] = useState(false);
  const [timelineLoading, setTimelineLoading] = useState(false);
  const [mostAsked, setMostAsked] = useState(null);
  const [messageAnalyticsLoading, setMessageAnalyticsLoading] = useState(false);
  const [quickReplyStats, setQuickReplyStats] = useState(null);
  const [quickReplyStatsLoading, setQuickReplyStatsLoading] = useState(false);
  const [sessionAnalytics, setSessionAnalytics] = useState(null);
  const [bounceRate, setBounceRate] = useState(null);
  const [nodePerformance, setNodePerformance] = useState(null);
  const [flowPaths, setFlowPaths] = useState(null);
  const [analyticsAlerts, setAnalyticsAlerts] = useState(null);
  const [engagementTimeline, setEngagementTimeline] = useState(null);
  const [engagementLoading, setEngagementLoading] = useState(false);
  const [messagesTimeline, setMessagesTimeline] = useState(null);
  const [messagesTimelineLoading, setMessagesTimelineLoading] = useState(false);
  const [projectNodes, setProjectNodes] = useState([]);
  const [selectedNodeId, setSelectedNodeId] = useState('all');
  // Advanced analytics
  const [botResponseTime, setBotResponseTime] = useState(null);
  const [activityHeatmap, setActivityHeatmap] = useState(null);
  const [returningVsNew, setReturningVsNew] = useState(null);
  const [abandonment, setAbandonment] = useState(null);
  const [conversionAnalytics, setConversionAnalytics] = useState(null);
  const [userInputInsights, setUserInputInsights] = useState(null);
  const [deviceAnalytics, setDeviceAnalytics] = useState(null);
  const [trafficSource, setTrafficSource] = useState(null);
  const [advancedLoading, setAdvancedLoading] = useState(false);

  useEffect(() => {
    fetchFrontendProjects();
    fetchAllProjects();
  }, [currentWorkspaceId]);

  const fetchAllProjects = async () => {
    try {
      const params = new URLSearchParams();
      if (currentWorkspaceId) params.append('workspace_id', currentWorkspaceId);
      const url = `/project-analytics/all-projects${params.toString() ? '?' + params.toString() : ''}`;
      const data = await apiRequest(url, { method: 'GET' });
      setAllProjects(Array.isArray(data) ? data : []);
    } catch {
      setAllProjects([]);
    }
  };

  // When workspace changes, reset project selection so analytics reflect the new workspace
  useEffect(() => {
    setSelectedProjectId('all');
  }, [currentWorkspaceId]);

  useEffect(() => {
    fetchAnalytics();
  }, [period, startDate, endDate, selectedProjectId, currentWorkspaceId]);

  useEffect(() => {
    if (!selectedProjectId || selectedProjectId === 'all') {
      setFunnel(null);
      setTimeline(null);
      setMostAsked(null);
      setQuickReplyStats(null);
      setSessionAnalytics(null);
      setBounceRate(null);
      setNodePerformance(null);
      setFlowPaths(null);
      setAnalyticsAlerts(null);
      setMessagesTimeline(null);
      setProjectNodes([]);
      setSelectedNodeId('all');
      setBotResponseTime(null);
      setActivityHeatmap(null);
      setReturningVsNew(null);
      setAbandonment(null);
      setConversionAnalytics(null);
      setUserInputInsights(null);
      setDeviceAnalytics(null);
      setTrafficSource(null);
      return;
    }
    const range = {};
    if (period === 'custom' && startDate && endDate) {
      range.start_date = startDate;
      range.end_date = endDate;
    } else if (period === 'weekly') {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 7);
      range.start_date = start.toISOString().slice(0, 10);
      range.end_date = end.toISOString().slice(0, 10);
    } else if (period === 'monthly') {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 30);
      range.start_date = start.toISOString().slice(0, 10);
      range.end_date = end.toISOString().slice(0, 10);
    }
    const funnelParams = new URLSearchParams({ project_id: selectedProjectId, ...range });
    const timelineParams = new URLSearchParams({ project_id: selectedProjectId, ...range });
    setFunnelLoading(true);
    setTimelineLoading(true);
    setEngagementLoading(true);
    setMessageAnalyticsLoading(true);
    apiRequest(`/project-analytics/funnel?${funnelParams}`)
      .then(setFunnel)
      .catch(() => setFunnel(null))
      .finally(() => setFunnelLoading(false));
    apiRequest(`/project-analytics/timeline?${timelineParams}`)
      .then(setTimeline)
      .catch(() => setTimeline(null))
      .finally(() => setTimelineLoading(false));
    apiRequest(`/project-analytics/most-asked?${funnelParams}`)
      .then(setMostAsked)
      .catch(() => setMostAsked(null))
      .finally(() => setMessageAnalyticsLoading(false));
    apiRequest(`/project-analytics/quick-reply-stats?${funnelParams}`)
      .then(setQuickReplyStats)
      .catch(() => setQuickReplyStats(null))
      .finally(() => setQuickReplyStatsLoading(false));
    apiRequest(`/project-analytics/session-analytics?${funnelParams}`)
      .then(setSessionAnalytics)
      .catch(() => setSessionAnalytics(null));
    apiRequest(`/project-analytics/bounce-rate?${funnelParams}`)
      .then(setBounceRate)
      .catch(() => setBounceRate(null));
    apiRequest(`/project-analytics/node-performance?${funnelParams}`)
      .then(setNodePerformance)
      .catch(() => setNodePerformance(null));
    apiRequest(`/project-analytics/flow-paths?${funnelParams}`)
      .then(setFlowPaths)
      .catch(() => setFlowPaths(null));
    apiRequest(`/project-analytics/analytics-alerts?${new URLSearchParams({ project_id: selectedProjectId })}`)
      .then(setAnalyticsAlerts)
      .catch(() => setAnalyticsAlerts(null));
    apiRequest(`/project-analytics/engagement-timeline?${timelineParams}`)
      .then(setEngagementTimeline)
      .catch(() => setEngagementTimeline(null))
      .finally(() => setEngagementLoading(false));
    apiRequest(`/project-analytics/nodes?${new URLSearchParams({ project_id: selectedProjectId })}`)
      .then((data) => setProjectNodes(data?.nodes || []))
      .catch(() => setProjectNodes([]));
    // Advanced analytics (same date range)
    setAdvancedLoading(true);
    Promise.all([
      apiRequest(`/project-analytics/bot-response-time?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/activity-heatmap?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/returning-vs-new?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/abandonment?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/conversion-analytics?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/user-input-insights?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/device-analytics?${funnelParams}`).catch(() => null),
      apiRequest(`/project-analytics/traffic-source?${funnelParams}`).catch(() => null),
    ]).then(([bot, heatmap, rvn, abandon, conv, insights, device, traffic]) => {
      setBotResponseTime(bot);
      setActivityHeatmap(heatmap);
      setReturningVsNew(rvn);
      setAbandonment(abandon);
      setConversionAnalytics(conv);
      setUserInputInsights(insights);
      setDeviceAnalytics(device);
      setTrafficSource(traffic);
    }).finally(() => setAdvancedLoading(false));
  }, [selectedProjectId, period, startDate, endDate]);

  useEffect(() => {
    if (!selectedProjectId || selectedProjectId === 'all') return;
    const range = {};
    if (period === 'custom' && startDate && endDate) {
      range.start_date = startDate;
      range.end_date = endDate;
    } else if (period === 'weekly') {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 7);
      range.start_date = start.toISOString().slice(0, 10);
      range.end_date = end.toISOString().slice(0, 10);
    } else if (period === 'monthly') {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 30);
      range.start_date = start.toISOString().slice(0, 10);
      range.end_date = end.toISOString().slice(0, 10);
    }
    const params = new URLSearchParams({ project_id: selectedProjectId, ...range });
    if (selectedNodeId && selectedNodeId !== 'all') params.set('node_id', selectedNodeId);
    setMessagesTimelineLoading(true);
    apiRequest(`/project-analytics/messages-timeline?${params}`)
      .then(setMessagesTimeline)
      .catch(() => setMessagesTimeline(null))
      .finally(() => setMessagesTimelineLoading(false));
  }, [selectedProjectId, period, startDate, endDate, selectedNodeId]);

  const fetchFrontendProjects = async () => {
    try {
      const params = new URLSearchParams();
      if (currentWorkspaceId) {
        params.append('workspace_id', currentWorkspaceId);
      }
      const url = `/project-analytics/frontend-projects${params.toString() ? '?' + params.toString() : ''}`;
      const data = await apiRequest(url, {
        method: 'GET',
      });
      setFrontendProjects(data);
    } catch (error) {
      console.error('Failed to fetch frontend projects:', error);
      toast({
        title: 'Error',
        description: 'Failed to load frontend projects',
        variant: 'destructive',
      });
    }
  };

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedProjectId && selectedProjectId !== 'all') {
        params.append('project_id', selectedProjectId);
      }
      if (currentWorkspaceId) {
        params.append('workspace_id', currentWorkspaceId);
      }
      if (period !== 'all') {
        params.append('period', period);
      }
      if (period === 'custom' && startDate && endDate) {
        params.append('start_date', startDate);
        params.append('end_date', endDate);
      }

      const url = `/project-analytics/stats${params.toString() ? '?' + params.toString() : ''}`;
      const data = await apiRequest(url, {
        method: 'GET',
      });
      setAnalytics(data);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
      toast({
        title: 'Error',
        description: 'Failed to load analytics data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateWidget = async (projectId) => {
    try {
      setLoadingWidget(true);
      setSelectedProject(projectId);
      const data = await apiRequest(`/project-analytics/widget/${projectId}`, {
        method: 'GET',
      });
      setWidgetConfig(data);
      setWidgetDialogOpen(true);
    } catch (error) {
      console.error('Failed to generate widget:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate widget',
        variant: 'destructive',
      });
    } finally {
      setLoadingWidget(false);
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await copyTextToClipboard(text ?? '');
      toast({
        title: 'Copied',
        description: 'Code copied to clipboard',
      });
    } catch {
      toast({
        title: 'Copy failed',
        description: 'Could not copy to clipboard',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <Icons.spinner className="w-8 h-8 animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading analytics...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="mx-auto max-w-7xl space-y-8">
        <PageHeader
          title="Project Insight"
          description="Deep analytics, funnel performance, and engagement diagnostics for your projects"
          icon={Icons.circleGauge}
          actions={
            selectedProjectId !== 'all' ? (
              <Button
                variant="outline"
                size="sm"
                className="rounded-xl"
                onClick={() => setSelectedProjectId('all')}
              >
                View all projects
              </Button>
            ) : null
          }
        />
            {/* Project Selector */}
            <Card className={analyticsCardClass}>
              <CardHeader>
                <CardTitle>Project Scope</CardTitle>
                <CardDescription>Choose a project or stay on the workspace-level overview.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                  <div className="min-w-0">
                    <Label htmlFor="project">Project</Label>
                    <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                      <SelectTrigger id="project">
                        <SelectValue placeholder="Select a project" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Projects</SelectItem>
                        {(allProjects.length ? allProjects : frontendProjects).map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            <span className="flex items-center gap-2">
                              {project.name}
                              {project.project_type && (
                                <span className={`rounded px-1.5 py-0.5 text-xs ${project.project_type === 'frontend' ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300' : 'bg-slate-100 text-slate-700 dark:bg-slate-900/70 dark:text-slate-300'}`}>
                                  {project.project_type === 'frontend' ? 'Frontend' : 'Backend'}
                                </span>
                              )}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filters */}
            <Card className={analyticsCardClass}>
              <CardHeader>
                <CardTitle>Time Filters</CardTitle>
                <CardDescription>Refine the analytics window for trend, funnel, and engagement views.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <div className="min-w-0">
                    <Label htmlFor="period">Period</Label>
                    <Select value={period} onValueChange={setPeriod}>
                      <SelectTrigger id="period">
                        <SelectValue placeholder="Select period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Time</SelectItem>
                        <SelectItem value="weekly">Last 7 Days</SelectItem>
                        <SelectItem value="monthly">Last 30 Days</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {period === 'custom' && (
                    <>
                      <div className="min-w-0">
                        <Label htmlFor="startDate">Start Date</Label>
                        <Input
                          id="startDate"
                          type="date"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                        />
                      </div>
                      <div className="min-w-0">
                        <Label htmlFor="endDate">End Date</Label>
                        <Input
                          id="endDate"
                          type="date"
                          value={endDate}
                          onChange={(e) => setEndDate(e.target.value)}
                        />
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {analytics && (
              <>
                {selectedProjectId === 'all' && (
                  <div className="space-y-8">
                    <div className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
                      <Card className={`${analyticsCardClass} overflow-hidden`} style={HERO_CARD_STYLE}>
                        <CardHeader className="space-y-4 p-6 pb-4">
                          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                            Workspace Overview
                          </div>
                          <CardTitle className="text-3xl font-semibold tracking-tight">
                            Portfolio analytics across all projects
                          </CardTitle>
                          <CardDescription className="max-w-2xl leading-6">
                            Compare messages, sessions, project mix, and user/bot interaction patterns before drilling into a single project.
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="grid gap-4 p-6 pt-0 md:grid-cols-3">
                          <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                              Total projects
                            </div>
                            <div className="mt-2 text-2xl font-semibold">
                              {formatCompactNumber(analytics.project_stats.total_projects)}
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">
                              {analytics.project_stats.frontend_projects} frontend • {analytics.project_stats.backend_projects} backend
                            </p>
                          </div>
                          <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                              Message volume
                            </div>
                            <div className="mt-2 text-2xl font-semibold">
                              {formatCompactNumber(analytics.message_stats.total_messages)}
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">
                              {formatCompactNumber(analytics.message_stats.total_user_messages)} user • {formatCompactNumber(analytics.message_stats.total_bot_messages)} bot
                            </p>
                          </div>
                          <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                              Sessions tracked
                            </div>
                            <div className="mt-2 text-2xl font-semibold">
                              {formatCompactNumber((analytics.projects || []).reduce((sum, project) => sum + (project.total_chats || 0), 0))}
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">
                              Active conversations recorded across the full workspace
                            </p>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className={analyticsCardClass}>
                        <CardHeader className="space-y-1 p-6 pb-4">
                          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                            Quick Insights
                          </div>
                          <CardTitle className="text-xl font-semibold">Portfolio highlights</CardTitle>
                        </CardHeader>
                        <CardContent className="grid gap-3 p-6 pt-0">
                          <QuickInsightCard
                            title="Most active project"
                            value={analytics.projects?.[0]?.project_name || 'No activity yet'}
                            caption={
                              analytics.projects?.[0]
                                ? `${formatCompactNumber(analytics.projects[0].total_messages || 0)} messages • ${formatCompactNumber(analytics.projects[0].total_chats || 0)} sessions`
                                : 'Create your first AI Agent or Chat Flow to unlock insights.'
                            }
                            icon={Icons.trophy}
                            tone="violet"
                          />
                          <QuickInsightCard
                            title="User / bot split"
                            value={
                              analytics.message_stats.total_messages > 0
                                ? `${Math.round((analytics.message_stats.total_user_messages / analytics.message_stats.total_messages) * 100)}% / ${Math.round((analytics.message_stats.total_bot_messages / analytics.message_stats.total_messages) * 100)}%`
                                : '—'
                            }
                            caption="Share of user messages versus assistant replies across the workspace."
                            icon={Icons.circleGauge}
                            tone="amber"
                          />
                          <QuickInsightCard
                            title="Project mix"
                            value={`${analytics.project_stats.frontend_projects} / ${analytics.project_stats.backend_projects}`}
                            caption="Frontend versus backend project distribution."
                            icon={Icons.project}
                            tone="cyan"
                          />
                        </CardContent>
                      </Card>
                    </div>

                    <AnalyticsSection
                      eyebrow="Section 1"
                      title="KPI Summary"
                      description="Top-level analytics for your full project portfolio."
                    >
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                        <MetricCard
                          icon={Icons.project}
                          label="Projects"
                          value={formatCompactNumber(analytics.project_stats.total_projects)}
                          description="All tracked AI Agent and Chat Flow projects."
                          comparison={`${analytics.project_stats.frontend_projects} frontend • ${analytics.project_stats.backend_projects} backend`}
                          tone="blue"
                        />
                        <MetricCard
                          icon={Icons.send}
                          label="Total Messages"
                          value={formatCompactNumber(analytics.message_stats.total_messages)}
                          description="Combined user and assistant message volume."
                          comparison={`${formatCompactNumber(analytics.message_stats.total_user_messages)} user • ${formatCompactNumber(analytics.message_stats.total_bot_messages)} bot`}
                          tone="violet"
                        />
                        <MetricCard
                          icon={Icons.chat}
                          label="Sessions"
                          value={formatCompactNumber((analytics.projects || []).reduce((sum, project) => sum + (project.total_chats || 0), 0))}
                          description="Sessions recorded across all projects."
                          comparison="Workspace-level usage aggregation"
                          tone="emerald"
                        />
                        <MetricCard
                          icon={Icons.circleGauge}
                          label="User / Bot Split"
                          value={
                            analytics.message_stats.total_messages > 0
                              ? `${Math.round((analytics.message_stats.total_user_messages / analytics.message_stats.total_messages) * 100)}% / ${Math.round((analytics.message_stats.total_bot_messages / analytics.message_stats.total_messages) * 100)}%`
                              : '—'
                          }
                          description="Message ownership balance between users and assistants."
                          comparison="User • Bot"
                          tone="amber"
                        />
                      </div>
                    </AnalyticsSection>

                    {(analytics.projects && analytics.projects.length > 0) ? (
                      <AnalyticsSection
                        eyebrow="Section 2"
                        title="Project Performance"
                        description="Ranked project cards with activity density and direct analytics drill-down."
                      >
                        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                          {[...analytics.projects]
                            .sort((a, b) => getUsageScore(b.total_messages, b.total_chats) - getUsageScore(a.total_messages, a.total_chats))
                            .map((project, index) => (
                              <ProjectAnalyticsCard
                                key={project.project_id}
                                project={project}
                                rank={index + 1}
                                onViewAnalytics={() => setSelectedProjectId(project.project_id)}
                                onOpenProject={() => setSelectedProjectId(project.project_id)}
                              />
                            ))}
                        </div>
                      </AnalyticsSection>
                    ) : (
                      <EmptyAnalyticsState
                        icon={Icons.project}
                        title="No activity yet"
                        description="Create your first AI Agent or Chat Flow to start collecting workspace-level analytics."
                        actionLabel="Go to dashboard"
                        onAction={() => navigate('/')}
                      />
                    )}

                    {(analytics.projects && analytics.projects.length > 0) && (
                      <AnalyticsSection
                        eyebrow="Section 3"
                        title="Usage Insights"
                        description="Ranked project usage plus message and language distribution across the workspace."
                      >
                        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                          <ChartPanel
                            title="Top Performing Projects"
                            description="Projects ranked by a blended usage score of messages and sessions."
                          >
                            <RankedProjectList
                              projects={[...analytics.projects].map((project) => ({
                                ...project,
                                project_name: project.project_name,
                                message_count: project.total_messages,
                                chat_count: project.total_chats,
                              }))}
                              typeLabel="Project"
                              tone="blue"
                              onOpen={(project) => setSelectedProjectId(project.project_id)}
                            />
                          </ChartPanel>

                          {(analytics.message_stats.total_messages > 0) && (
                            <ChartPanel
                              title="Message Distribution"
                              description="User versus bot messages across the full workspace."
                            >
                              <ResponsiveContainer width="100%" height={280}>
                                <BarChart
                                  data={[
                                    { name: 'User', messages: analytics.message_stats.total_user_messages },
                                    { name: 'Bot', messages: analytics.message_stats.total_bot_messages },
                                  ]}
                                  margin={{ top: 12, right: 8, left: -12, bottom: 0 }}
                                >
                                  <CartesianGrid stroke={CHART_GRID} vertical={false} />
                                  <XAxis dataKey="name" tickLine={false} axisLine={false} />
                                  <YAxis tickLine={false} axisLine={false} />
                                  <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(value) => [formatCompactNumber(value), 'Messages']} />
                                  <Bar dataKey="messages" fill="hsl(var(--chart-4))" radius={[10, 10, 0, 0]} />
                                </BarChart>
                              </ResponsiveContainer>
                            </ChartPanel>
                          )}
                        </div>

                        {analytics.projects.length > 1 && analytics.projects.some((project) => (project.total_messages || 0) > 0) && (
                          <ChartPanel
                            title="Messages by Project"
                            description="Distribution of message volume across your most active projects."
                          >
                            <ResponsiveContainer width="100%" height={320}>
                              <BarChart
                                data={[...analytics.projects]
                                  .sort((a, b) => (b.total_messages || 0) - (a.total_messages || 0))
                                  .slice(0, 8)
                                  .map((project) => ({
                                    name:
                                      project.project_name?.length > 20
                                        ? `${project.project_name.slice(0, 20)}...`
                                        : project.project_name,
                                    messages: project.total_messages || 0,
                                  }))}
                                layout="vertical"
                                margin={{ top: 8, right: 8, left: 12, bottom: 0 }}
                              >
                                <CartesianGrid stroke={CHART_GRID} horizontal={false} />
                                <XAxis type="number" tickLine={false} axisLine={false} />
                                <YAxis type="category" dataKey="name" width={140} tickLine={false} axisLine={false} />
                                <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(value) => [formatCompactNumber(value), 'Messages']} />
                                <Bar dataKey="messages" fill="hsl(var(--chart-2))" radius={[0, 10, 10, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </ChartPanel>
                        )}

                        {analytics.language_stats && analytics.language_stats.length > 0 && (
                          <ChartPanel
                            title="Language Distribution"
                            description="Language selections across all projects in the workspace."
                          >
                            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                              <ResponsiveContainer width="100%" height={240}>
                                <PieChart>
                                  <Pie
                                    data={analytics.language_stats}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={56}
                                    outerRadius={86}
                                    dataKey="count"
                                    nameKey="language"
                                  >
                                    {analytics.language_stats.map((entry, index) => (
                                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                  </Pie>
                                  <Tooltip contentStyle={TOOLTIP_STYLE} />
                                  <Legend />
                                </PieChart>
                              </ResponsiveContainer>
                              <div className="space-y-2">
                                {analytics.language_stats.slice(0, 6).map((stat, index) => (
                                  <div key={stat.language} className="flex items-center justify-between rounded-2xl border border-border/70 bg-muted/20 p-3">
                                    <div className="flex items-center gap-2">
                                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                                      <span className="text-sm font-medium">{stat.language}</span>
                                    </div>
                                    <span className="text-sm font-semibold">
                                      {formatCompactNumber(stat.count)} <span className="font-normal text-muted-foreground">({stat.percentage}%)</span>
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </ChartPanel>
                        )}
                      </AnalyticsSection>
                    )}
                  </div>
                )}

                {selectedProjectId !== 'all' && (() => {
                  const projectList = allProjects.length ? allProjects : frontendProjects;
                  const selectedProject = getSelectedProject(projectList, selectedProjectId);
                  const projectTypeLabel = selectedProject?.project_type === 'backend' ? 'Backend' : 'Frontend';
                  const quickInsightCopy = funnel
                    ? `${funnel.completion_count || 0} completed of ${funnel.total_sessions || 0} total sessions`
                    : 'Completion insights will appear once live usage is available.';

                  return (
                    <div className="space-y-8">
                      <div className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
                        <Card className={`${analyticsCardClass} overflow-hidden`} style={HERO_CARD_STYLE}>
                          <CardHeader className="space-y-4 p-6 pb-4">
                            <div className="flex flex-wrap items-start justify-between gap-4">
                              <div className="space-y-2">
                                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                                  Selected Project
                                </div>
                                <CardTitle className="text-3xl font-semibold tracking-tight">
                                  {selectedProject?.name || 'Project analytics'}
                                </CardTitle>
                                <CardDescription className="max-w-2xl leading-6">
                                  Monitor funnel completion, message mix, engagement, and node-level performance for this {projectTypeLabel.toLowerCase()} project.
                                </CardDescription>
                              </div>
                              <div className="rounded-2xl border border-border/70 bg-background/80 px-4 py-3 text-right shadow-sm">
                                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                                  Project type
                                </div>
                                <div className="mt-2 text-2xl font-semibold">{projectTypeLabel}</div>
                                <div className="text-sm text-muted-foreground">
                                  {selectedProject?.project_type === 'backend' ? 'AI Agent workflow' : 'Chat Flow experience'}
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="grid gap-4 p-6 pt-0 md:grid-cols-3">
                            <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                                Messages
                              </div>
                              <div className="mt-2 text-2xl font-semibold">
                                {formatCompactNumber(analytics.message_stats.total_messages)}
                              </div>
                              <p className="mt-1 text-sm text-muted-foreground">
                                {formatCompactNumber(analytics.message_stats.total_user_messages)} user • {formatCompactNumber(analytics.message_stats.total_bot_messages)} bot
                              </p>
                            </div>
                            <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                                Sessions
                              </div>
                              <div className="mt-2 text-2xl font-semibold">
                                {formatCompactNumber(sessionAnalytics?.total_sessions || 0)}
                              </div>
                              <p className="mt-1 text-sm text-muted-foreground">
                                Avg {sessionAnalytics?.avg_messages_per_session?.toFixed?.(1) || 0} messages per session
                              </p>
                            </div>
                            <div className="rounded-2xl border border-border/70 bg-background/75 p-4">
                              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                                Completion
                              </div>
                              <div className="mt-2 text-2xl font-semibold">
                                {funnel?.completion_rate_pct != null ? `${funnel.completion_rate_pct}%` : '—'}
                              </div>
                              <p className="mt-1 text-sm text-muted-foreground">
                                {quickInsightCopy}
                              </p>
                            </div>
                          </CardContent>
                        </Card>

                        <Card className={analyticsCardClass}>
                          <CardHeader className="space-y-1 p-6 pb-4">
                            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                              Quick Insights
                            </div>
                            <CardTitle className="text-xl font-semibold">Project health snapshot</CardTitle>
                          </CardHeader>
                          <CardContent className="grid gap-3 p-6 pt-0">
                            <QuickInsightCard
                              title="Bounce rate"
                              value={bounceRate?.bounce_rate_pct != null ? `${bounceRate.bounce_rate_pct}%` : '—'}
                              caption={
                                bounceRate
                                  ? `${bounceRate.first_step_sessions || 0} started • ${bounceRate.second_step_sessions || 0} continued`
                                  : 'Bounce analytics will appear after project traffic is available.'
                              }
                              icon={Icons.alert}
                              tone="amber"
                            />
                            <QuickInsightCard
                              title="Completion rate"
                              value={funnel?.completion_rate_pct != null ? `${funnel.completion_rate_pct}%` : '—'}
                              caption={quickInsightCopy}
                              icon={Icons.checkCircle}
                              tone="emerald"
                            />
                            <QuickInsightCard
                              title="Average duration"
                              value={
                                sessionAnalytics?.avg_session_duration_seconds != null
                                  ? sessionAnalytics.avg_session_duration_seconds >= 60
                                    ? `${(sessionAnalytics.avg_session_duration_seconds / 60).toFixed(1)}m`
                                    : `${Math.round(sessionAnalytics.avg_session_duration_seconds)}s`
                                  : '—'
                              }
                              caption="Typical session length for the selected date range."
                              icon={Icons.circleGauge}
                              tone="violet"
                            />
                          </CardContent>
                        </Card>
                      </div>

                      <AnalyticsSection
                        eyebrow="Section 1"
                        title="KPI Summary"
                        description="Top-level project health metrics for the currently selected experience."
                      >
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                          <MetricCard
                            icon={Icons.project}
                            label="Project"
                            value={selectedProject?.name || 'N/A'}
                            description={`${projectTypeLabel} project`}
                            comparison={selectedProject?.project_type === 'backend' ? 'AI Agent workflow' : 'Chat Flow experience'}
                            tone="blue"
                          />
                          <MetricCard
                            icon={Icons.send}
                            label="Messages"
                            value={formatCompactNumber(analytics.message_stats.total_messages)}
                            description="Total user and assistant message volume."
                            comparison={`${formatCompactNumber(analytics.message_stats.total_user_messages)} user • ${formatCompactNumber(analytics.message_stats.total_bot_messages)} bot`}
                            tone="violet"
                          />
                          <MetricCard
                            icon={Icons.chat}
                            label="Sessions"
                            value={formatCompactNumber(sessionAnalytics?.total_sessions || 0)}
                            description="Sessions recorded for this project."
                            comparison={`Avg ${sessionAnalytics?.avg_messages_per_session?.toFixed?.(1) || 0} messages per session`}
                            tone="emerald"
                          />
                          <MetricCard
                            icon={Icons.circleGauge}
                            label="Usage Score"
                            value={formatCompactNumber(getUsageScore(analytics.message_stats.total_messages, sessionAnalytics?.total_sessions || 0))}
                            description="Blended usage score combining message volume and session activity."
                            comparison={funnel?.completion_rate_pct != null ? `${funnel.completion_rate_pct}% completion rate` : 'Completion analytics pending'}
                            tone="amber"
                          />
                        </div>
                      </AnalyticsSection>

                      {selectedProjectId !== 'all' && (sessionAnalytics || bounceRate || funnel) && (
                        <AnalyticsSection
                          eyebrow="Section 2"
                          title="Performance Signals"
                          description="Operational metrics for bounce, completion, and session engagement."
                        >
                          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                            {sessionAnalytics && (
                              <MetricCard
                                icon={Icons.chat}
                                label="Sessions"
                                value={formatCompactNumber(sessionAnalytics.total_sessions)}
                                description="Sessions captured during the selected time range."
                                comparison={`Avg ${sessionAnalytics.avg_messages_per_session?.toFixed?.(1) || 0} msgs • ${sessionAnalytics.bounce_sessions || 0} bounce`}
                                tone="emerald"
                              />
                            )}
                            {bounceRate && (
                              <MetricCard
                                icon={Icons.alert}
                                label="Bounce Rate"
                                value={`${bounceRate.bounce_rate_pct}%`}
                                description="Sessions leaving before the second meaningful step."
                                comparison={`${bounceRate.first_step_sessions || 0} started • ${bounceRate.second_step_sessions || 0} continued`}
                                tone="amber"
                              />
                            )}
                            {funnel && (
                              <MetricCard
                                icon={Icons.checkCircle}
                                label="Completion Rate"
                                value={`${funnel.completion_rate_pct}%`}
                                description="Share of sessions reaching the project completion point."
                                comparison={`${funnel.completion_count || 0} / ${funnel.total_sessions || 0} sessions`}
                                tone="blue"
                              />
                            )}
                            {sessionAnalytics?.avg_session_duration_seconds != null && (
                              <MetricCard
                                icon={Icons.circleGauge}
                                label="Avg Duration"
                                value={
                                  sessionAnalytics.avg_session_duration_seconds >= 60
                                    ? `${(sessionAnalytics.avg_session_duration_seconds / 60).toFixed(1)}m`
                                    : `${Math.round(sessionAnalytics.avg_session_duration_seconds)}s`
                                }
                                description="Average time spent inside this project."
                                comparison="Per session"
                                tone="violet"
                              />
                            )}
                          </div>
                        </AnalyticsSection>
                      )}
                    </div>
                  );
                })()}

                {/* Message Statistics Chart - when a single project is selected */}
                {selectedProjectId !== 'all' && (analytics.message_stats.total_user_messages > 0 || analytics.message_stats.total_bot_messages > 0) && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Message Statistics</CardTitle>
                      <CardDescription>User vs Bot messages</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={[
                          { name: 'User Messages', value: analytics.message_stats.total_user_messages },
                          { name: 'Bot Messages', value: analytics.message_stats.total_bot_messages },
                        ]}>
                          <CartesianGrid stroke={CHART_GRID} strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="value" fill="hsl(var(--chart-1))" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}

                {/* User vs Bot messages over time - line chart with node filter */}
                {selectedProjectId !== 'all' && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <CardTitle>User vs Bot messages over time</CardTitle>
                          <CardDescription>
                            Daily message counts
                            {messagesTimeline?.node_label && ` · Node: ${messagesTimeline.node_label}`}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          <Label htmlFor="node-filter" className="text-xs text-muted-foreground whitespace-nowrap">Filter by node</Label>
                          <Select value={selectedNodeId} onValueChange={setSelectedNodeId}>
                            <SelectTrigger id="node-filter" className="w-[220px]">
                              <SelectValue placeholder="All nodes" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All nodes</SelectItem>
                              {quickReplyStats?.nodes?.length > 0 && (
                                <SelectGroup>
                                  <SelectLabel className="text-muted-foreground">Quick reply nodes</SelectLabel>
                                  {quickReplyStats.nodes.map((n) => (
                                    <SelectItem key={n.node_id} value={n.node_id}>
                                      {n.node_label || n.node_id}
                                    </SelectItem>
                                  ))}
                                </SelectGroup>
                              )}
                              {projectNodes.filter((n) => !quickReplyStats?.nodes?.some((q) => q.node_id === n.node_id)).length > 0 && (
                                <SelectGroup>
                                  <SelectLabel className="text-muted-foreground">Other nodes</SelectLabel>
                                  {projectNodes
                                    .filter((n) => !quickReplyStats?.nodes?.some((q) => q.node_id === n.node_id))
                                    .map((n) => (
                                      <SelectItem key={n.node_id} value={n.node_id}>
                                        {n.node_label || n.node_id}
                                      </SelectItem>
                                    ))}
                                </SelectGroup>
                              )}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {messagesTimelineLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground py-8">
                          <Icons.spinner className="w-5 h-5 animate-spin" />
                          Loading...
                        </div>
                      ) : messagesTimeline?.days?.length > 0 ? (
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={messagesTimeline.days}>
                            <CartesianGrid stroke={CHART_GRID} strokeDasharray="3 3" />
                            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="user_messages" stroke="hsl(var(--chart-4))" strokeWidth={2} dot={false} name="User messages" />
                            <Line type="monotone" dataKey="bot_messages" stroke="hsl(var(--chart-5))" strokeWidth={2} dot={false} name="Bot messages" />
                          </LineChart>
                        </ResponsiveContainer>
                      ) : (
                        <p className="text-sm text-muted-foreground py-6">
                          No message data yet for this period{selectedNodeId !== 'all' ? ' for the selected node' : ''}. Use the widget to generate traffic.
                        </p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Step funnel (when a project is selected) */}
                {selectedProjectId !== 'all' && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Step funnel</CardTitle>
                      <CardDescription>How many times each step ran. Sessions can hit the same step multiple times (e.g. in loops).</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {funnelLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground py-8">
                          <Icons.spinner className="w-5 h-5 animate-spin" />
                          Loading funnel...
                        </div>
                      ) : funnel && funnel.steps && funnel.steps.length > 0 ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                            <div className="p-3 rounded-lg bg-muted/50">
                              <div className="text-2xl font-bold">{funnel.total_sessions}</div>
                              <div className="text-xs text-muted-foreground">Opened bot</div>
                            </div>
                            <div className="p-3 rounded-lg bg-muted/50">
                              <div className="text-2xl font-bold">{funnel.completion_count}</div>
                              <div className="text-xs text-muted-foreground">Completed flow</div>
                            </div>
                            <div className="p-3 rounded-lg bg-muted/50">
                              <div className="text-2xl font-bold">{funnel.completion_rate_pct}%</div>
                              <div className="text-xs text-muted-foreground">Completion rate</div>
                            </div>
                          </div>
                          <ResponsiveContainer width="100%" height={280}>
                            <BarChart data={funnel.steps.map((s, i) => ({ ...s, index: i + 1, label: s.node_label || s.node_id }))} layout="vertical" margin={{ left: 20 }}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" />
                              <YAxis type="category" dataKey="label" width={120} tick={{ fontSize: 11 }} />
                              <Tooltip formatter={(v, n, p) => (p.payload.drop_off_pct != null ? [`${v} (${p.payload.drop_off_pct}% drop-off)`, 'Times used'] : [v, 'Times used'])} />
                              <Bar dataKey="reached_count" fill="hsl(var(--chart-1))" name="Times used" />
                            </BarChart>
                          </ResponsiveContainer>
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-2">Step</th>
                                  <th className="text-left py-2">Label</th>
                                  <th className="text-right py-2">Times used</th>
                                  <th className="text-right py-2">Drop-off</th>
                                </tr>
                              </thead>
                              <tbody>
                                {funnel.steps.map((s) => (
                                  <tr key={s.node_id} className="border-b last:border-0">
                                    <td className="py-2">{s.step_order}</td>
                                    <td className="py-2">{s.node_label || s.node_id}</td>
                                    <td className="py-2 text-right font-medium">{s.reached_count}</td>
                                    <td className="py-2 text-right text-muted-foreground">{s.drop_off_pct != null ? `${s.drop_off_pct}%` : '—'}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground py-6">No step data yet. Use the shared widget so users can open the bot; funnel data will appear here.</p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Node performance table */}
                {selectedProjectId !== 'all' && nodePerformance && nodePerformance.nodes?.length > 0 && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Node performance</CardTitle>
                      <CardDescription>Per-step reach, unique sessions, next step reached, drop-off %</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-2">Step</th>
                              <th className="text-left py-2">Label</th>
                              <th className="text-right py-2">Times reached</th>
                              <th className="text-right py-2">Unique sessions</th>
                              <th className="text-right py-2">Next step reached</th>
                              <th className="text-right py-2">Drop-off %</th>
                            </tr>
                          </thead>
                          <tbody>
                            {nodePerformance.nodes.map((n) => (
                              <tr key={n.node_id} className="border-b last:border-0">
                                <td className="py-2">{n.step_order}</td>
                                <td className="py-2">{n.node_label || n.node_id}</td>
                                <td className="py-2 text-right">{n.times_reached}</td>
                                <td className="py-2 text-right">{n.unique_sessions}</td>
                                <td className="py-2 text-right">{n.next_step_reached ?? '—'}</td>
                                <td className="py-2 text-right">{n.drop_off_pct != null ? `${n.drop_off_pct}%` : '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Flow paths */}
                {selectedProjectId !== 'all' && flowPaths && flowPaths.paths?.length > 0 && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Flow paths</CardTitle>
                      <CardDescription>Top user journeys through the chatbot</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {flowPaths.paths.slice(0, 10).map((p, i) => (
                          <div key={i} className="flex items-center justify-between gap-4 py-2 border-b last:border-0">
                            <span className="text-sm truncate flex-1" title={p.path}>{p.path}</span>
                            <span className="font-medium shrink-0">{p.session_count} sessions</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Analytics alerts */}
                {selectedProjectId !== 'all' && analyticsAlerts && analyticsAlerts.alerts?.length > 0 && (
                  <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Alerts</CardTitle>
                      <CardDescription>Automated insights from recent activity</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {analyticsAlerts.alerts.map((a, i) => (
                          <li key={i} className={`rounded p-2 text-sm ${a.severity === 'critical' ? 'bg-red-50 text-red-800 dark:bg-red-950/40 dark:text-red-300' : a.severity === 'warning' ? 'bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300' : 'bg-muted/50'}`}>
                            {a.message}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                {/* Advanced analytics */}
                {selectedProjectId !== 'all' && (
                  <div className="space-y-6">
                    <h2 className="text-lg font-semibold text-foreground">Advanced analytics</h2>
                    {advancedLoading ? (
                      <div className="flex items-center gap-2 text-muted-foreground py-4">
                        <Icons.spinner className="w-5 h-5 animate-spin" />
                        Loading advanced analytics...
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-6">
                        {/* Bot response time + Returning vs new + Conversion in one row */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {botResponseTime != null && (
                            <Card className="rounded-xl shadow-sm">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">Bot response time</CardTitle>
                                <CardDescription>Time from user message to bot reply</CardDescription>
                              </CardHeader>
                              <CardContent>
                                {botResponseTime.sample_count === 0 ? (
                                  <p className="text-sm text-muted-foreground">No data yet</p>
                                ) : (
                                  <>
                                    <div className="text-2xl font-bold">
                                      {botResponseTime.avg_response_time_ms != null
                                        ? `${botResponseTime.avg_response_time_ms < 1000 ? Math.round(botResponseTime.avg_response_time_ms) + ' ms' : (botResponseTime.avg_response_time_ms / 1000).toFixed(2) + ' s'}`
                                        : '—'}
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      avg · max {botResponseTime.max_response_time_ms != null ? `${(botResponseTime.max_response_time_ms / 1000).toFixed(2)}s` : '—'} · {botResponseTime.sample_count} samples
                                    </p>
                                  </>
                                )}
                              </CardContent>
                            </Card>
                          )}
                          {returningVsNew != null && (
                            <Card className="rounded-xl shadow-sm">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">New vs returning</CardTitle>
                                <CardDescription>One-step vs multi-step or multi-day</CardDescription>
                              </CardHeader>
                              <CardContent>
                                <div className="flex items-center gap-4">
                                  <div>
                                    <div className="text-2xl font-bold">{returningVsNew.new_sessions}</div>
                                    <p className="text-xs text-muted-foreground">New</p>
                                  </div>
                                  <div>
                                    <div className="text-2xl font-bold">{returningVsNew.returning_sessions}</div>
                                    <p className="text-xs text-muted-foreground">Returning ({returningVsNew.returning_pct}%)</p>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          )}
                          {conversionAnalytics != null && conversionAnalytics.conversion_node_id && (
                            <Card className="rounded-xl shadow-sm">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">Conversion</CardTitle>
                                <CardDescription>{conversionAnalytics.conversion_node_label || 'Conversion node'}</CardDescription>
                              </CardHeader>
                              <CardContent>
                                <div className="text-2xl font-bold">{conversionAnalytics.conversion_rate_pct}%</div>
                                <p className="text-xs text-muted-foreground">
                                  {conversionAnalytics.conversion_count} / {conversionAnalytics.total_sessions} sessions
                                </p>
                              </CardContent>
                            </Card>
                          )}
                        </div>

                        {/* Activity heatmap: by hour + by weekday */}
                        {activityHeatmap != null && (activityHeatmap.by_hour?.length > 0 || activityHeatmap.by_weekday?.length > 0) && (
                          <Card className="rounded-xl shadow-sm">
                            <CardHeader>
                              <CardTitle>Activity heatmap</CardTitle>
                              <CardDescription>Sessions by hour and by weekday</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {activityHeatmap.by_hour?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">By hour (IST)</p>
                                    <ResponsiveContainer width="100%" height={220}>
                                      <BarChart data={activityHeatmap.by_hour.map((r) => ({ hour: `${r.hour}:00`, sessions: r.sessions }))}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="hour" tick={{ fontSize: 10 }} />
                                        <YAxis />
                                        <Tooltip />
                                        <Bar dataKey="sessions" fill="hsl(var(--chart-4))" name="Sessions" />
                                      </BarChart>
                                    </ResponsiveContainer>
                                  </div>
                                )}
                                {activityHeatmap.by_weekday?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">By weekday</p>
                                    <ResponsiveContainer width="100%" height={220}>
                                      <BarChart data={activityHeatmap.by_weekday.map((r) => ({ day: r.day_name, sessions: r.sessions }))}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                                        <YAxis />
                                        <Tooltip />
                                        <Bar dataKey="sessions" fill="hsl(var(--chart-2))" name="Sessions" />
                                      </BarChart>
                                    </ResponsiveContainer>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        )}

                        {/* Step abandonment table */}
                        {abandonment != null && abandonment.steps?.length > 0 && (
                          <Card className="rounded-xl shadow-sm">
                            <CardHeader>
                              <CardTitle>Step abandonment</CardTitle>
                              <CardDescription>Per step: reached, continued to next, exited; abandonment %</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                  <thead>
                                    <tr className="border-b">
                                      <th className="text-left py-2">Step</th>
                                      <th className="text-left py-2">Label</th>
                                      <th className="text-right py-2">Reached</th>
                                      <th className="text-right py-2">Continued</th>
                                      <th className="text-right py-2">Exited</th>
                                      <th className="text-right py-2">Abandonment %</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {abandonment.steps.map((s) => (
                                      <tr key={s.node_id} className="border-b last:border-0">
                                        <td className="py-2">{s.step_order}</td>
                                        <td className="py-2">{s.node_label || s.node_id}</td>
                                        <td className="py-2 text-right">{s.reached}</td>
                                        <td className="py-2 text-right">{s.continued}</td>
                                        <td className="py-2 text-right">{s.exited}</td>
                                        <td className="py-2 text-right font-medium">{s.abandonment_rate_pct}%</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </CardContent>
                          </Card>
                        )}

                        {/* User input insights: top queries + trend */}
                        {userInputInsights != null && (userInputInsights.top_queries?.length > 0 || userInputInsights.trend_by_date?.length > 0) && (
                          <Card className="rounded-xl shadow-sm">
                            <CardHeader>
                              <CardTitle>User input insights</CardTitle>
                              <CardDescription>Top queries and message volume over time</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {userInputInsights.trend_by_date?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">User messages by day</p>
                                    <ResponsiveContainer width="100%" height={200}>
                                      <AreaChart data={userInputInsights.trend_by_date}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                                        <YAxis />
                                        <Tooltip />
                                        <Area type="monotone" dataKey="count" stroke="hsl(var(--chart-4))" fill="hsl(var(--chart-4))" fillOpacity={0.3} name="Messages" />
                                      </AreaChart>
                                    </ResponsiveContainer>
                                  </div>
                                )}
                                {userInputInsights.top_queries?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">Top queries</p>
                                    <ul className="space-y-1.5 max-h-[200px] overflow-y-auto">
                                      {userInputInsights.top_queries.slice(0, 10).map((q, i) => (
                                        <li key={i} className="text-sm flex justify-between gap-2">
                                          <span className="truncate" title={q.content}>{q.content}</span>
                                          <span className="font-medium shrink-0">{q.count}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        )}

                        {/* Device analytics */}
                        {deviceAnalytics != null && (deviceAnalytics.device_type?.length > 0 || deviceAnalytics.browser?.length > 0 || deviceAnalytics.os?.length > 0) && (
                          <Card className="rounded-xl shadow-sm">
                            <CardHeader>
                              <CardTitle>Device & platform</CardTitle>
                              <CardDescription>Device type, browser, and OS (from widget)</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {deviceAnalytics.device_type?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">Device</p>
                                    <div className="space-y-1.5">
                                      {deviceAnalytics.device_type.slice(0, 5).map((d, i) => (
                                        <div key={i} className="flex justify-between text-sm">
                                          <span>{d.name}</span>
                                          <span className="text-muted-foreground">{d.count} ({d.percentage}%)</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                {deviceAnalytics.browser?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">Browser</p>
                                    <div className="space-y-1.5">
                                      {deviceAnalytics.browser.slice(0, 5).map((d, i) => (
                                        <div key={i} className="flex justify-between text-sm">
                                          <span>{d.name}</span>
                                          <span className="text-muted-foreground">{d.count} ({d.percentage}%)</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                {deviceAnalytics.os?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">OS</p>
                                    <div className="space-y-1.5">
                                      {deviceAnalytics.os.slice(0, 5).map((d, i) => (
                                        <div key={i} className="flex justify-between text-sm">
                                          <span>{d.name}</span>
                                          <span className="text-muted-foreground">{d.count} ({d.percentage}%)</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        )}

                        {/* Traffic source */}
                        {trafficSource != null && (trafficSource.by_page?.length > 0 || trafficSource.by_referrer?.length > 0) && (
                          <Card className="rounded-xl shadow-sm">
                            <CardHeader>
                              <CardTitle>Traffic source</CardTitle>
                              <CardDescription>Chats by page URL and referrer (from widget)</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {trafficSource.by_page?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">By page</p>
                                    <div className="overflow-x-auto max-h-48 overflow-y-auto">
                                      <table className="w-full text-sm">
                                        <thead>
                                          <tr className="border-b"><th className="text-left py-1.5">Page</th><th className="text-right py-1.5">Chats</th></tr>
                                        </thead>
                                        <tbody>
                                          {trafficSource.by_page.map((r, i) => (
                                            <tr key={i} className="border-b last:border-0">
                                              <td className="py-1.5 truncate max-w-[200px]" title={r.source}>{r.source}</td>
                                              <td className="py-1.5 text-right font-medium">{r.chats}</td>
                                            </tr>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                )}
                                {trafficSource.by_referrer?.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">By referrer</p>
                                    <div className="overflow-x-auto max-h-48 overflow-y-auto">
                                      <table className="w-full text-sm">
                                        <thead>
                                          <tr className="border-b"><th className="text-left py-1.5">Referrer</th><th className="text-right py-1.5">Chats</th></tr>
                                        </thead>
                                        <tbody>
                                          {trafficSource.by_referrer.map((r, i) => (
                                            <tr key={i} className="border-b last:border-0">
                                              <td className="py-1.5 truncate max-w-[200px]" title={r.source}>{r.source}</td>
                                              <td className="py-1.5 text-right font-medium">{r.chats}</td>
                                            </tr>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Daily usage & engagement timelines (when a project is selected) */}
                {selectedProjectId !== 'all' && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle>Daily usage</CardTitle>
                      <CardDescription>Sessions per day (unique users who reached at least one step)</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {timelineLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground py-8">
                          <Icons.spinner className="w-5 h-5 animate-spin" />
                          Loading timeline...
                        </div>
                      ) : timeline && timeline.days && timeline.days.length > 0 ? (
                        <ResponsiveContainer width="100%" height={260}>
                          <AreaChart data={timeline.days}>
                              <CartesianGrid stroke={CHART_GRID} strokeDasharray="3 3" />
                            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                            <YAxis />
                            <Tooltip />
                              <Area
                                type="monotone"
                                dataKey="sessions"
                                stroke="hsl(var(--chart-1))"
                                fill="hsl(var(--chart-1))"
                                fillOpacity={0.3}
                                name="Sessions"
                              />
                          </AreaChart>
                        </ResponsiveContainer>
                      ) : (
                          <p className="text-sm text-muted-foreground py-6">
                            No daily data yet for the selected period.
                          </p>
                      )}
                    </CardContent>
                  </Card>

                    <Card className="rounded-xl shadow-sm">
                      <CardHeader>
                        <CardTitle>Engagement over time</CardTitle>
                        <CardDescription>
                          Average messages and session duration per day
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {engagementLoading ? (
                          <div className="flex items-center gap-2 text-muted-foreground py-8">
                            <Icons.spinner className="w-5 h-5 animate-spin" />
                            Loading engagement...
                          </div>
                        ) : engagementTimeline && engagementTimeline.days && engagementTimeline.days.length > 0 ? (
                          <ResponsiveContainer width="100%" height={260}>
                            <LineChart data={engagementTimeline.days}>
                              <CartesianGrid stroke={CHART_GRID} strokeDasharray="3 3" />
                              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Line
                                type="monotone"
                                dataKey="avg_messages_per_session"
                                stroke="hsl(var(--chart-2))"
                                strokeWidth={2}
                                dot={false}
                                name="Avg messages / session"
                              />
                              <Line
                                type="monotone"
                                dataKey="avg_session_duration_seconds"
                                stroke="hsl(var(--chart-5))"
                                strokeWidth={2}
                                dot={false}
                                name="Avg duration (s)"
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        ) : (
                          <p className="text-sm text-muted-foreground py-6">
                            No engagement data yet for the selected period.
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Quick reply stats: how many chose each option per quick reply node */}
                {selectedProjectId !== 'all' && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick reply stats</CardTitle>
                      <CardDescription>How many users chose each option in quick reply nodes</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {quickReplyStatsLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground py-8">
                          <Icons.spinner className="w-5 h-5 animate-spin" />
                          Loading...
                        </div>
                      ) : quickReplyStats && quickReplyStats.nodes && quickReplyStats.nodes.length > 0 ? (
                        <div className="space-y-6">
                          {quickReplyStats.nodes.map((node, idx) => (
                            <div key={node.node_id || idx} className="border rounded-lg p-4 space-y-2">
                              <div className="font-medium text-sm">
                                {node.node_label || node.node_id || 'Quick reply'}
                                <span className="text-muted-foreground font-normal ml-2">({node.total_choices} total)</span>
                              </div>
                              <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                  <thead>
                                    <tr className="border-b">
                                      <th className="text-left py-1.5">Option</th>
                                      <th className="text-right py-1.5">Chosen</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {node.options.map((opt, i) => (
                                      <tr key={i} className="border-b last:border-0">
                                        <td className="py-1.5">{opt.option_text || `Option ${opt.option_index + 1}`}</td>
                                        <td className="py-1.5 text-right font-medium">{opt.count}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground py-6">No quick reply data yet. When users tap an option in a quick reply node, counts will appear here.</p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Most asked (top user messages from widget) */}
                {selectedProjectId !== 'all' && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Most asked</CardTitle>
                      <CardDescription>Top user messages from the widget (same phrasing grouped)</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {messageAnalyticsLoading ? (
                        <div className="flex items-center gap-2 text-muted-foreground py-8">
                          <Icons.spinner className="w-5 h-5 animate-spin" />
                          Loading...
                        </div>
                      ) : mostAsked && mostAsked.items && mostAsked.items.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2">#</th>
                                <th className="text-left py-2">Message</th>
                                <th className="text-right py-2">Count</th>
                              </tr>
                            </thead>
                            <tbody>
                              {mostAsked.items.map((item, i) => (
                                <tr key={i} className="border-b last:border-0">
                                  <td className="py-2 text-muted-foreground">{i + 1}</td>
                                  <td className="py-2 max-w-md truncate" title={item.content}>{item.content}</td>
                                  <td className="py-2 text-right font-medium">{item.count}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground py-6">No &quot;most asked&quot; data yet. User messages from the widget will appear here.</p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Language Statistics - when a single project is selected */}
                {selectedProjectId !== 'all' && analytics.language_stats && analytics.language_stats.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Language Selection Analytics</CardTitle>
                      <CardDescription>Distribution of language selections</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <ResponsiveContainer width="100%" height={300}>
                          <PieChart>
                            <Pie
                              data={analytics.language_stats}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ language, percentage }) => `${language}: ${percentage}%`}
                              outerRadius={80}
                              fill="hsl(var(--chart-4))"
                              dataKey="count"
                            >
                              {analytics.language_stats.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                        <div className="space-y-2">
                          {analytics.language_stats.map((stat, index) => (
                            <div key={stat.language} className="flex items-center justify-between p-2 border rounded">
                              <div className="flex items-center gap-2">
                                <div
                                  className="w-4 h-4 rounded"
                                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                                />
                                <span className="font-medium">{stat.language}</span>
                              </div>
                              <div className="text-right">
                                <div className="font-bold">{stat.count}</div>
                                <div className="text-xs text-muted-foreground">{stat.percentage}%</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

              </>
            )}
          </div>

      {/* Widget Dialog */}
      <Dialog open={widgetDialogOpen} onOpenChange={setWidgetDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Widget Embed Code</DialogTitle>
            <DialogDescription>
              Copy and paste this code into your website to embed the chatbot widget
            </DialogDescription>
          </DialogHeader>
          {widgetConfig && (
            <div className="space-y-4">
              <div>
                <Label>Widget URL</Label>
                <div className="flex gap-2 mt-1">
                  <Input value={widgetConfig.widget_url} readOnly />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => copyToClipboard(widgetConfig.widget_url)}
                  >
                    <Icons.copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>API Key</Label>
                <div className="flex gap-2 mt-1">
                  <Input value={widgetConfig.api_key} readOnly type="password" />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => copyToClipboard(widgetConfig.api_key)}
                  >
                    <Icons.copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>Embed Code</Label>
                <div className="mt-1">
                  <textarea
                    readOnly
                    value={widgetConfig.embed_code}
                    className="w-full h-32 p-2 border rounded font-mono text-sm"
                  />
                  <Button
                    className="mt-2"
                    variant="outline"
                    onClick={() => copyToClipboard(widgetConfig.embed_code)}
                  >
                    <Icons.copy className="w-4 h-4 mr-2" />
                    Copy Embed Code
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
        </Dialog>
      </AppLayout>
  );
}

