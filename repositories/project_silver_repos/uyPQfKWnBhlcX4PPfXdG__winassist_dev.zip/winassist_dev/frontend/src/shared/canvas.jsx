import { useState, useCallback, useMemo, useEffect, useRef, memo } from 'react';
import {
    ReactFlow,
    Background,
    Controls,
    MiniMap,
    useNodesState,
    useEdgesState,
    addEdge,
    useStoreApi,
    Panel,
    ReactFlowProvider,
    BackgroundVariant,
    SelectionMode,
    applyNodeChanges,
    applyEdgeChanges,
    ConnectionLineType,
    useReactFlow
} from '@xyflow/react';
import './reactflow.css';
import '@xyflow/react/dist/style.css';

import { initialBackendEdges, initialBackendNodes, initialFrontendEdges, initialFrontendNodes, useProject } from '../hooks/project';
import { Icons } from '../components/ui/icons';
import { genId } from '../lib/id';
import { debounce } from 'lodash-es';
import { DEFAULT_NODE_COLOR, edgeTypes,nodeTypes } from '../lib/flow';
import { WINASSIST_LOGO_URL } from '../lib/config';
import { NodeButton } from '../components/shared/nodebutton';
import { Button } from '../components/ui/button';
import { toast } from '../hooks/toast';
import { useNavigate } from 'react-router-dom';
import { validateFlow } from '../utils/flowValidation';


// Autosave debounce: higher value reduces chatty saves on node drag.
const DEBOUNCE_DELAY = 1500; 

const useDebouncedUpdate = (projectId, projectRef) => {
  const [isDirty, setIsDirty] = useState(false);
  const { updateProject } = useProject(projectId);

  const { toObject } = useReactFlow();
  const initialLoad = useRef(true);

  const debouncedUpdate = debounce((flowFromCanvas) => {
    if (projectId === -1) {
      setIsDirty(false);
      return;
    }
    // Preserve flow-level keys (e.g. widget_settings) so widget settings persist per chat flow
    const existingFlow = projectRef?.current?.flow || {};
    const flowToSave = {
      ...existingFlow,
      ...flowFromCanvas,
    };
    // Autosave: don't revalidate full projects list for every node move.
    updateProject({ flow: flowToSave }, { skipRevalidate: true });
    setIsDirty(false);
  }, DEBOUNCE_DELAY);

  useEffect(() => {
    if (initialLoad.current) {
      initialLoad.current = false;
      return;
    }
    if (isDirty && projectId !== -1) {
      debouncedUpdate(toObject());
    }

    return () => {
      debouncedUpdate.cancel();
    };
  }, [isDirty, toObject, debouncedUpdate, projectId]);

  return { setIsDirty, debouncedUpdate };
};

export const FlowCanvas = ({
  projectId,
  onModeChange,
  nodeFilter,
  onNodesEdgesChange,
  onCanvasClick,
  initialFlow,
}) => {
  const navigate = useNavigate();
  const { project, isLoading, isError } = useProject(projectId);
  const projectRef = useRef(project);
  projectRef.current = project;
  const { screenToFlowPosition } = useReactFlow();
  const [nodes, setNodes] = useNodesState([]);
  const [edges, setEdges] = useEdgesState([]);
  const { setIsDirty } = useDebouncedUpdate(projectId, projectRef);
  // Property panels use setNodeData / setNodes without going through onNodesChange — listen so autosave runs.
  useEffect(() => {
    const onDirty = () => setIsDirty(true);
    window.addEventListener('winassist-flow-dirty', onDirty);
    return () => window.removeEventListener('winassist-flow-dirty', onDirty);
  }, [setIsDirty]);
  const flowParent = useRef(null);
  const fileInputRef = useRef(null);
  const copiedNodesRef = useRef([]);
  const nodesRef = useRef(nodes);
  nodesRef.current = nodes;
  const edgesRef = useRef(edges);
  edgesRef.current = edges;

  const store = useStoreApi();
  useEffect(() => {
    if (import.meta.env.DEV) {
      store.getState().onError = (code, message) => {
        if (code === '002') {
          return;
        }
        console.warn('Workflow warning:', code, message);
      };
    }
  }, []);

  const normalizeNodes = useCallback((maybeNodes) => {
    const list = Array.isArray(maybeNodes) ? maybeNodes : [];
    return list.map((n) => ({
      ...n,
      position: {
        x: n?.position?.x ?? 0,
        y: n?.position?.y ?? 0,
      },
    }));
  }, []);

  useEffect(() => {
    const initializeProjectFlow = () => {
      if (project?.flow) {
        setNodes(normalizeNodes(project.flow.nodes));
        // Ensure all edges are selectable
        const edgesWithSelectable = (Array.isArray(project.flow.edges) ? project.flow.edges : []).map(edge => ({
          ...edge,
          selectable: true,
          focusable: true,
          deletable: true,
        }));
        setEdges(edgesWithSelectable);
        setIsDirty(false);
        return;
      }

      if (initialFlow && typeof initialFlow === 'object') {
        setNodes(normalizeNodes(initialFlow.nodes));
        const initialEdges = (Array.isArray(initialFlow.edges) ? initialFlow.edges : []).map((edge) => ({
          ...edge,
          selectable: true,
          focusable: true,
          deletable: true,
        }));
        setEdges(initialEdges);
        setIsDirty(false);
      }
    };

    initializeProjectFlow();
  }, [project?.flow, projectId, normalizeNodes, initialFlow]);

  
  useEffect(() => {
    if (onNodesEdgesChange) {
      onNodesEdgesChange(nodes, edges);
    }
  }, [nodes, edges, onNodesEdgesChange]);

  // Copy/paste nodes only when canvas has focus; never intercept text copy/paste in inputs
  useEffect(() => {
    const isTextInput = (el) => {
      if (!el || !el.closest) return false;
      const tag = el.tagName?.toUpperCase?.();
      return tag === 'INPUT' || tag === 'TEXTAREA' || el.isContentEditable;
    };
    const isCanvasFocused = () => {
      const el = document.activeElement;
      return flowParent.current && el && flowParent.current.contains(el) && !isTextInput(el);
    };

    const handleKeyDown = (event) => {
      // Never steal copy/paste when user is in a text field — let browser handle it
      if (isTextInput(event.target)) return;

      const isCopy = (event.key === 'c' || event.key === 'C') && (event.ctrlKey || event.metaKey);
      const isPaste = (event.key === 'v' || event.key === 'V') && (event.ctrlKey || event.metaKey);

      if (isCopy) {
        const selected = nodesRef.current.filter((n) => n.selected);
        if (selected.length > 0) copiedNodesRef.current = selected;
        return;
      }

      if (isPaste && isCanvasFocused() && copiedNodesRef.current.length > 0) {
        event.preventDefault();
        event.stopPropagation();
        const toPaste = copiedNodesRef.current;
        const offset = 40;

        setNodes((currentNodes) => {
          const cleared = currentNodes.map((n) => ({ ...n, selected: false }));
          const newNodes = toPaste.map((node) => {
            const newId = genId();
            return {
              ...node,
              id: `${node.data?.id || node.type || 'node'}_${newId}`,
              position: {
                x: (node.position?.x ?? 0) + offset,
                y: (node.position?.y ?? 0) + offset,
              },
              selected: true,
              parentId: undefined,
            };
          });
          return [...cleared, ...newNodes];
        });
        setIsDirty(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [setNodes, setIsDirty]);

  useEffect(() => {
    if (!edges || edges.length === 0) {
      
      setNodes((nds) =>
        nds.map((node) => ({
          ...node,
          data: {
            ...node.data,
            connections: {},
          },
        }))
      );
      return;
    }

    setNodes((nds) => {
      
      const nodesWithClearedConnections = nds.map((node) => ({
        ...node,
        data: {
          ...node.data,
          connections: {},
        },
      }));

      
      return edges.reduce((updatedNodes, edge) => {
        if (!edge.source || !edge.target) return updatedNodes;

        const sourceNode = updatedNodes.find((n) => n.id === edge.source);
        const targetNode = updatedNodes.find((n) => n.id === edge.target);

        if (sourceNode && edge.sourceHandle) {
          const nodeIndex = updatedNodes.findIndex((n) => n.id === sourceNode.id);
          if (nodeIndex !== -1) {
            updatedNodes[nodeIndex] = {
              ...updatedNodes[nodeIndex],
              data: {
                ...updatedNodes[nodeIndex].data,
                connections: {
                  ...updatedNodes[nodeIndex].data.connections || {},
                  [edge.sourceHandle]: true,
                },
              },
            };
          }
        }

        if (targetNode && edge.targetHandle) {
          const nodeIndex = updatedNodes.findIndex((n) => n.id === targetNode.id);
          if (nodeIndex !== -1) {
            updatedNodes[nodeIndex] = {
              ...updatedNodes[nodeIndex],
              data: {
                ...updatedNodes[nodeIndex].data,
                connections: {
                  ...updatedNodes[nodeIndex].data.connections || {},
                  [edge.targetHandle]: true,
                },
              },
            };
          }
        }

        return updatedNodes;
      }, nodesWithClearedConnections);
    });
  }, [edges, setNodes]);

  const isGroupType = (type) =>
    ['groupchat', 'nestedchat'].includes(type);

  const onNodesChange = useCallback(
    (changes) => {
      setNodes((nds) => {
        
        let nextNodes = applyNodeChanges(changes, nds);

        if (changes.some((c) => c.type === 'dimensions')) {
          setIsDirty(true);
        }

       
        changes.forEach((change) => {
          if (change.type === 'position') {
            const draggedNode = nextNodes.find((n) => n.id === change.id);
            if (
              !draggedNode ||
              (draggedNode.type && isGroupType(draggedNode.type))
            ) {
              return;
            }
            const absolutePosition = {
              x: draggedNode.position?.x ?? 0,
              y: draggedNode.position?.y ?? 0,
            };
            const oldParent = draggedNode.parentId
              ? nextNodes.find((n) => n.id === draggedNode.parentId)
              : null;
            if (oldParent) {
              absolutePosition.x += oldParent.position?.x ?? 0;
              absolutePosition.y += oldParent.position?.y ?? 0;
            }

            
            if ('dragging' in change && change.dragging) {
              draggedNode.position = absolutePosition;
              draggedNode.parentId = undefined;
              draggedNode.extent = undefined;

              const groupNode = nextNodes.find((n) => {
                if (
                  n.type === 'groupchat' &&
                  n.id !== draggedNode.id &&
                  !n.parentId
                ) {
                  if (!n.position) return false;
                  
                  const nodeElement = document.querySelector(
                    `[data-id="${n.id}"]`
                  );
                  const nodeWidth =
                    nodeElement?.getBoundingClientRect().width ?? n.width ?? 0;
                  const nodeHeight =
                    nodeElement?.getBoundingClientRect().height ??
                    n.height ??
                    0;

                  return (
                    absolutePosition.x >= n.position.x &&
                    absolutePosition.x <= n.position.x + nodeWidth &&
                    absolutePosition.y >= n.position.y &&
                    absolutePosition.y <= n.position.y + nodeHeight
                  );
                }
                return false;
              });

              
              nextNodes = nextNodes.map((node) => {
                if (node.type === 'groupchat') {
                  return {
                    ...node,
                    data: {
                      ...node.data,
                      hoveredGroupId: groupNode?.id || null,
                    },
                  };
                }
                return node;
              });

              return;
            }

            
            if ('dragging' in change && !change.dragging) {
              
              nextNodes = nextNodes.map((node) => {
                if (node.type === 'groupchat') {
                  return {
                    ...node,
                    data: {
                      ...node.data,
                      hoveredGroupId: null,
                    },
                  };
                }
                return node;
              });

              const groupNode = nextNodes.find(
                (n) =>
                  n.type === 'groupchat' &&
                  n.id !== draggedNode.id &&
                  !n.parentId && 
                  !!n.position &&
                  absolutePosition.x >= n.position.x &&
                  absolutePosition.x <= n.position.x + (n.width ?? 0) &&
                  absolutePosition.y >= n.position.y &&
                  absolutePosition.y <= n.position.y + (n.height ?? 0)
              );

          
              if (groupNode) {

                draggedNode.parentId = groupNode.id;
                draggedNode.position = {
                  x: absolutePosition.x - (groupNode.position?.x ?? 0),
                  y: absolutePosition.y - (groupNode.position?.y ?? 0),
                };
                draggedNode.extent = 'parent';

                nextNodes = nextNodes.filter((n) => n.id !== draggedNode.id);
                const groupIndex = nextNodes.findIndex(
                  (n) => n.id === groupNode.id
                );
                nextNodes.splice(groupIndex + 1, 0, draggedNode);
              }
            }
          }
        });

        return nextNodes;
      });
      setIsDirty(true); 
    },
    [setNodes, setIsDirty]
  );

  const onEdgesChange = useCallback(
   
    (changes) => {
      if (changes.some((change) => change.type !== 'select')) {
        setIsDirty(true);
      }
      setEdges((eds) => applyEdgeChanges(changes, eds));
    },
    [setIsDirty]
  );

  const onDragOver = useCallback(
    (event) => {
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';

      if (!flowParent.current) return;

      const flowBounds = flowParent.current.getBoundingClientRect();
      const position = screenToFlowPosition({
        x: event.clientX - flowBounds.left,
        y: event.clientY - flowBounds.top,
      });

      
      const groupNode = nodes.find(
        (n) =>
          n.type === 'groupchat' &&
          !!n.position &&
          position.x > n.position.x &&
          position.x < n.position.x + (n.width ?? 0) &&
          position.y > n.position.y &&
          position.y < n.position.y + (n.height ?? 0)
      );

      setNodes(
        nodes.map((node) => {
          if (node.type === 'groupchat') {
            return {
              ...node,
              data: {
                ...node.data,
                hoveredGroupId: groupNode?.id || null,
              },
            };
          }
          return node;
        })
      );
    },
    [nodes, screenToFlowPosition, flowParent]
  );

  const onDragLeave = useCallback(() => {
    
    setNodes((nodes) =>
      nodes.map((node) => {
        if (node.type === 'groupchat') {
          return {
            ...node,
            data: {
              ...node.data,
              hoveredGroupId: null,
            },
          };
        }
        return node;
      })
    );
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const data = JSON.parse(event.dataTransfer.getData('application/json'));
      if (!data || !flowParent.current) return;

      const flowBounds = flowParent.current.getBoundingClientRect();
      const position = screenToFlowPosition({
        x: event.clientX - flowBounds.left,
        y: event.clientY - flowBounds.top,
      });

      const { offsetX, offsetY, width, height, ...cleanedData } = data;
      const actualType = data.nodeType || data.id;
      const newId = genId();
      const newNode = {
        id: `${data.id}_${newId}`,
        type: actualType,
        data: {
          id: cleanedData.id,
          nodeType: actualType,
          name: cleanedData.name,
          description: cleanedData.description,
          class_type: cleanedData.class_type,
          ...(cleanedData.data || {}),
        },
        position,
        width,
        height,
        selected: true,
        draggable: true,
        selectable: true,
        focusable: true,
        parentId: undefined,
        style: undefined,
      } ;

      
      const groupNode = nodes.find(
        (n) =>
          n.type === 'groupchat' &&
          !!n.position &&
          position.x > n.position.x &&
          position.x < n.position.x + (n.width ?? 0) &&
          position.y > n.position.y &&
          position.y < n.position.y + (n.height ?? 0)
      );

      setNodes((nds) => {
        
        const updatedNodes = nds.map((n) => ({
          ...n,
          selected: false,
          data:
            n.type === 'groupchat'
              ? { ...n.data, hoveredGroupId: null }
              : n.data,
        }));

        if (groupNode) {
          
          const updatedNode = {
            ...newNode,
            position: {
              x: position.x - (groupNode.position?.x ?? 0),
              y: position.y - (groupNode.position?.y ?? 0),
            },
            parentId: groupNode.id,
            
            ...(data.id === 'groupchat'
              ? {
                style: {
                  width: Math.min(300, groupNode.width - 50),
                  height: Math.min(200, groupNode.height - 50),
                },
              }
              : {}),
          };

          
          const groupIndex = updatedNodes.findIndex(
            (n) => n.id === groupNode.id
          );
          if (groupIndex !== -1) {
            updatedNodes.splice(groupIndex + 1, 0, updatedNode);
            return updatedNodes;
          }
        }

        
        return [...updatedNodes, newNode];
      });
    },
    [nodes, screenToFlowPosition, setNodes, flowParent]
  );

  const onConnect = (params) => {
    setEdges((eds) => {
      const newEdge = {
        ...params,
        type: 'step',
        selectable: true,
        focusable: true,
        deletable: true,
        data: {
          strokeWidth: 4,
        },
      };

      return addEdge(newEdge, eds);
    });
    setIsDirty(true);
  };

  const onAddNode = useCallback(
    (nodeMeta) => {
      setNodes((nds) => {
        const newId = genId();
        const actualType = nodeMeta.nodeType || nodeMeta.id;
        const bounds = flowParent.current?.getBoundingClientRect();
        if (!bounds) return nds;
        const center = {
          x: bounds.left + (bounds.right - bounds.left) / 2,
          y: bounds.top + (bounds.bottom - bounds.top) / 2,
        };
        const randInt = (max) =>
          Math.floor(Math.random() * Math.floor(max));

        const position = screenToFlowPosition({
          x: center.x + randInt(100),
          y: center.y + randInt(100),
        });

        
        const defaultWidth = nodeMeta.width || 190;
        const defaultHeight = nodeMeta.height || 128;
        
        const newNode = {
          id: `${nodeMeta.id}_${newId}`,
          type: actualType,
          position,
          data: {
            id: nodeMeta.id,
            nodeType: actualType,
            name: nodeMeta.name,
            class_type: nodeMeta.class_type,
            color: nodeMeta.data?.color || DEFAULT_NODE_COLOR,
            ...nodeMeta.data, 
          },
          width: defaultWidth,
          height: defaultHeight,
          selected: true,
          draggable: true,
          selectable: true,
          focusable: true,
          resizable: true,
        };
        const updatedNodes = nds.map((n) => ({ ...n, selected: false }));
        return [...updatedNodes, newNode];
      });

      setIsDirty(true);
    },
    [screenToFlowPosition, setNodes]
  );

  const duplicateSelectedNodes = useCallback(() => {
    const selectedNodes = nodesRef.current.filter((node) => node.selected);

    if (selectedNodes.length === 0) {
      toast({
        title: 'No node selected',
        description: 'Select one or more nodes in the canvas to duplicate them.',
      });
      return;
    }

    const selectedNodeIds = new Set(selectedNodes.map((node) => node.id));
    const idMap = new Map();
    const offset = 40;

    const duplicatedNodes = selectedNodes.map((node) => {
      const newId = `${node.data?.id || node.type || 'node'}_${genId()}`;
      idMap.set(node.id, newId);

      return {
        ...node,
        id: newId,
        position: {
          x: (node.position?.x ?? 0) + offset,
          y: (node.position?.y ?? 0) + offset,
        },
        selected: true,
      };
    });

    const duplicatedEdges = edgesRef.current
      .filter((edge) => selectedNodeIds.has(edge.source) && selectedNodeIds.has(edge.target))
      .map((edge) => ({
        ...edge,
        id: `${idMap.get(edge.source)}-${idMap.get(edge.target)}-${genId()}`,
        source: idMap.get(edge.source),
        target: idMap.get(edge.target),
        selected: false,
      }));

    setNodes((currentNodes) => [
      ...currentNodes.map((node) => ({ ...node, selected: false })),
      ...duplicatedNodes,
    ]);
    setEdges((currentEdges) => [...currentEdges, ...duplicatedEdges]);
    setIsDirty(true);

    toast({
      title: 'Duplicated',
      description:
        selectedNodes.length === 1
          ? 'Selected node duplicated successfully.'
          : `${selectedNodes.length} selected nodes duplicated successfully.`,
    });
  }, [setEdges, setIsDirty, setNodes]);

  const handleLoadSampleFlow = useCallback(() => {
    const isFrontendCanvas = Array.isArray(nodeFilter) && nodeFilter.includes('api');
    const sampleNodes = isFrontendCanvas ? initialFrontendNodes : initialBackendNodes;
    const sampleEdges = isFrontendCanvas ? initialFrontendEdges : initialBackendEdges;

    const shouldReplace = window.confirm(
      'Load the sample flow? This will replace the current canvas flow so you can start from a working example.'
    );

    if (!shouldReplace) return;

    const clonedNodes = structuredClone(sampleNodes).map((node) => ({
      ...node,
      selected: false,
      draggable: true,
      selectable: true,
      focusable: true,
      resizable: true,
    }));
    const clonedEdges = structuredClone(sampleEdges).map((edge) => ({
      ...edge,
      selectable: true,
      focusable: true,
      deletable: true,
    }));

    setNodes(clonedNodes);
    setEdges(clonedEdges);
    setIsDirty(true);

    toast({
      title: 'Sample flow loaded',
      description: isFrontendCanvas
        ? 'A sample frontend flow has been loaded into the canvas.'
        : 'A sample backend flow has been loaded into the canvas.',
    });
  }, [nodeFilter, setEdges, setIsDirty, setNodes]);

  const handleImportJSON = useCallback(
    (event) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const jsonData = JSON.parse(e.target?.result || '{}');
          
          // Validate JSON structure
          if (!jsonData.nodes || !Array.isArray(jsonData.nodes)) {
            toast({
              title: 'Invalid JSON',
              description: 'JSON must contain a "nodes" array.',
              variant: 'destructive',
            });
            return;
          }

          if (!jsonData.edges && !jsonData.connections) {
            toast({
              title: 'Invalid JSON',
              description: 'JSON must contain "edges" or "connections" array.',
              variant: 'destructive',
            });
            return;
          }

          // Transform nodes to ReactFlow format if needed
          let importedNodes = jsonData.nodes.map((node) => {
            // If node already has position object, use it as is
            if (node.position) {
              return node;
            }
            
            // Transform from old format (x, y directly on node) to new format
            const transformedNode = {
              id: node.id,
              type: node.type,
              position: {
                x: node.x || node.position?.x || 0,
                y: node.y || node.position?.y || 0,
              },
            };
            
            // Copy width and height if present
            if (node.width !== undefined) transformedNode.width = node.width;
            if (node.height !== undefined) transformedNode.height = node.height;
            
            // Handle data object
            if (node.data) {
              // If data already exists, use it
              transformedNode.data = node.data;
            } else {
              // Otherwise, create data object from node properties
              const { id, type, x, y, width, height, position, label, color, ...nodeData } = node;
              transformedNode.data = {
                id: node.type || node.id,
                name: label || node.name || node.type || 'Node',
                class_type: node.class_type || `${node.type || 'Node'}Node`,
                color: nodeData.color || DEFAULT_NODE_COLOR,
                ...nodeData, // Include all other properties (message, options, text, apiMethod, etc.)
              };
            }
            
            return transformedNode;
          });
          
          // Filter nodes based on nodeFilter if provided
          if (nodeFilter && nodeFilter.length > 0) {
            const beforeFilter = importedNodes.length;
            importedNodes = importedNodes.filter((node) =>
              nodeFilter.includes(node.type || node.data?.id || node.data?.type)
            );
            
            if (importedNodes.length < beforeFilter) {
              const filteredCount = beforeFilter - importedNodes.length;
              toast({
                title: 'Some nodes filtered',
                description: `${filteredCount} node(s) were filtered out as they don't match the current project type.`,
              });
            }
          }

          // Convert connections to edges if needed
          let importedEdges = jsonData.edges || jsonData.connections || [];
          
          // Transform edges to ReactFlow format
          importedEdges = importedEdges.map((edge) => {
            const source = edge.source || edge.from;
            const target = edge.target || edge.to;
            const sourceHandle = edge.sourceHandle || edge.branch || null;
            const targetHandle = edge.targetHandle || null;
            
            // Extract edge data properties
            const edgeData = {
              branch: edge.branch || edge.data?.branch || sourceHandle,
              isLoop: edge.isLoop || edge.data?.isLoop || false,
              loopIterations: edge.loopIterations || edge.data?.loopIterations || 5,
              color: edge.data?.color,
              strokeWidth: edge.data?.strokeWidth || edge.strokeWidth || 4,
            };
            
            return {
              id: edge.id || `${source}-${sourceHandle || 'default'}-${target}-${genId()}`,
              source,
              target,
              sourceHandle,
              targetHandle,
              data: edgeData,
            };
          });

          // Filter edges to only include those connecting imported nodes
          const importedNodeIds = new Set(importedNodes.map((n) => n.id));
          importedEdges = importedEdges.filter(
            (edge) =>
              importedNodeIds.has(edge.source) && importedNodeIds.has(edge.target)
          );

          // Update the flow (normalize positions for ReactFlow)
          setNodes(normalizeNodes(importedNodes));
          setEdges(importedEdges);
          setIsDirty(true);

          toast({
            title: 'Import Successful',
            description: `Imported ${importedNodes.length} node(s) and ${importedEdges.length} edge(s).`,
          });

          // Reset file input
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        } catch (error) {
          console.error('Error parsing JSON:', error);
          toast({
            title: 'Import Failed',
            description: `Failed to parse JSON file: ${error.message}`,
            variant: 'destructive',
          });
        }
      };

      reader.onerror = () => {
        toast({
          title: 'Import Failed',
          description: 'Failed to read the file.',
          variant: 'destructive',
        });
      };

      reader.readAsText(file);
    },
    [nodeFilter, setNodes, setEdges, setIsDirty]
  );

  const handleImportClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleExportJSON = useCallback(() => {
    try {
      const exportPayload = {
        version: 1,
        exported_at: new Date().toISOString(),
        project_id: projectId,
        project_type:
          Array.isArray(nodeFilter) && nodeFilter.includes('api')
            ? 'frontend'
            : 'backend',
        nodes: nodesRef.current.map((node) => ({
          ...node,
          selected: false,
          dragging: false,
        })),
        edges: edgesRef.current.map((edge) => ({
          ...edge,
          selected: false,
        })),
      };

      const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
        type: 'application/json',
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      link.href = url;
      link.download = `winassist-flow-${timestamp}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: 'Export complete',
        description: 'The current flow has been downloaded as a JSON file.',
      });
    } catch (error) {
      console.error('Error exporting JSON:', error);
      toast({
        title: 'Export failed',
        description: 'Could not export the current flow as JSON.',
        variant: 'destructive',
      });
    }
  }, [nodeFilter, projectId]);

  const handleValidateFlow = useCallback(() => {
    const result = validateFlow(nodesRef.current, edgesRef.current);

    if (result.issues.length > 0) {
      console.group('WinAssist Flow Validation');
      result.issues.forEach((issue) => {
        const method = issue.severity === 'error' ? 'error' : 'warn';
        console[method](`[${issue.severity.toUpperCase()}] ${issue.code}: ${issue.message}`);
      });
      console.groupEnd();
    }

    if (result.summary.errors > 0) {
      toast({
        title: 'Flow validation failed',
        description: `${result.summary.errors} error(s) and ${result.summary.warnings} warning(s) found. Check the browser console for details.`,
        variant: 'destructive',
      });
      return;
    }

    if (result.summary.warnings > 0) {
      toast({
        title: 'Flow validated with warnings',
        description: `${result.summary.warnings} warning(s) found. Check the browser console for details.`,
      });
      return;
    }

    toast({
      title: 'Flow validated',
      description: 'No validation issues were found in the current flow.',
    });
  }, []);

  // For nocode pages (projectId === -1), skip loading/error states
  if (projectId !== -1) {
    if (isLoading) {
      return (
        <div className="relative flex w-full h-full items-center justify-center">
          <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain animate-pulse opacity-50" />
        </div>
      );
    }

    if (isError) {
      return (
        <div className="relative flex w-full h-full items-center justify-center">
          <p className="text-red-500">Project load failed </p>
        </div>
      );
    }
  }

  return (
    <div
      className="relative flex flex-grow flex-col w-full h-full outline-none"
      ref={flowParent}
      tabIndex={0}
    >
      <ReactFlow
        nodes={nodes}
        onNodesChange={onNodesChange}
        edges={edges}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onConnect={onConnect}
        defaultEdgeOptions={{ type: 'step' }}
        connectionLineType={ConnectionLineType.SmoothStep}
        connectionLineStyle={{ strokeWidth: 4, stroke: '#2563eb' }}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onPaneClick={(e) => {
          flowParent.current?.focus();
          onCanvasClick?.(e);
        }}
        panOnScroll
        snapToGrid
        snapGrid={[24, 24]}
        selectionOnDrag
        selectionMode={SelectionMode.Partial}
        fitView
        fitViewOptions={{ maxZoom: 1 }}
        minZoom={0.2}
        maxZoom={1.8}
        attributionPosition="bottom-right"
        deleteKeyCode={['Backspace', 'Delete']}
        multiSelectionKeyCode={['Meta', 'Control']}
        edgesUpdatable={true}
        edgesFocusable={true}
        edgesSelectable={true}
      >
        <Background
          variant={BackgroundVariant.Lines}
          gap={50}
          size={4}
          color="rgba(128,128,128,0.1)"
        />
        <Panel position="bottom-right" className="controls-minimap-row flex flex-row items-end gap-2 !right-4 !bottom-4 m-0 p-0 z-30">
          <Controls
            fitViewOptions={{ maxZoom: 1 }}
            showInteractive={false}
            position="bottom-right"
            className="flex rounded-2xl border border-border/70 bg-background/95 shadow-lg backdrop-blur"
          />
          <MiniMap
            pannable
            zoomable
            position="bottom-right"
            className="!rounded-2xl !border !border-border/70 !bg-background/95 !shadow-xl"
            nodeBorderRadius={16}
            maskColor="rgba(15, 23, 42, 0.08)"
            nodeColor="#94a3b8"
          />
        </Panel>
        <Panel position="top-left" className="flex max-w-[calc(100vw-2rem)] flex-wrap items-center gap-2 p-1">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate(-1)}
            className="gap-2"
          >
            <Icons.chevronLeft className="w-4 h-4" />
            Back
          </Button>
          <NodeButton onAddNode={onAddNode} nodeFilter={nodeFilter} />
          <Button
            variant="outline"
            size="sm"
            onClick={handleLoadSampleFlow}
            className="gap-2"
          >
            <Icons.package className="w-4 h-4" />
            Reset flow
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleImportClick}
            className="gap-2"
          >
            <Icons.download className="w-4 h-4" />
            Import JSON
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportJSON}
            className="gap-2"
          >
            <Icons.upload className="w-4 h-4" />
            Export JSON
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleValidateFlow}
            className="gap-2"
          >
            <Icons.checkCircle className="w-4 h-4" />
            Validate flow
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleImportJSON}
            style={{ display: 'none' }}
          />
        </Panel>
      </ReactFlow>
    </div>
  );
};
