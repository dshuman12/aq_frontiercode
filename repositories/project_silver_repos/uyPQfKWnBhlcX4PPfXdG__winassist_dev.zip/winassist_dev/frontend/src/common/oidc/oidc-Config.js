// OIDC configuration for Keycloak + react-oidc-context.
// Prefer the current VITE_OIDC_* names, but keep VITE_IAM_* as a legacy fallback.
const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
const rawAuthority = (import.meta.env.VITE_OIDC_AUTHORITY || import.meta.env.VITE_IAM_URL || '').trim();
const authority = rawAuthority.replace(/\/$/, '');
const clientId = (import.meta.env.VITE_OIDC_CLIENT_ID || import.meta.env.VITE_IAM_CLIENT_ID || '').trim();
const requestedScope = (import.meta.env.VITE_OIDC_SCOPE || 'openid profile email offline_access').trim();

const isLocalHostname = (hostname) => (
  hostname === 'localhost' ||
  hostname === '127.0.0.1' ||
  hostname === '0.0.0.0' ||
  hostname === '::1'
);

const getAppRelativePath = (value) => {
  const normalized = (value || '').trim();
  if (!normalized) return '';

  if (!/^https?:\/\//i.test(normalized)) {
    return normalized.startsWith('/') ? normalized : `/${normalized}`;
  }

  try {
    const parsed = new URL(normalized);
    return `${parsed.pathname || ''}${parsed.search || ''}${parsed.hash || ''}` || '/';
  } catch {
    return normalized;
  }
};

const normalizeUrl = (value, fallbackPath) => {
  const rawValue = (value || '').trim();
  if (rawValue) {
    if (/^https?:\/\//i.test(rawValue)) {
      try {
        const configuredUrl = new URL(rawValue);

        // Keep explicit remote callback URLs, but rewrite stale localhost
        // settings to the deployed app origin so server builds still work.
        if (currentOrigin) {
          const currentUrl = new URL(currentOrigin);
          if (isLocalHostname(configuredUrl.hostname) && !isLocalHostname(currentUrl.hostname)) {
            return `${currentOrigin}${configuredUrl.pathname}${configuredUrl.search}${configuredUrl.hash}`;
          }
        }

        return configuredUrl.toString().replace(/\/$/, '');
      } catch {
        return rawValue.replace(/\/$/, '');
      }
    }

    const normalized = getAppRelativePath(rawValue);
    if (!currentOrigin) {
      return normalized;
    }
    return `${currentOrigin}${normalized}`;
  }

  return fallbackPath ? `${currentOrigin}${fallbackPath}` : currentOrigin;
};

const redirectUri = normalizeUrl(
  import.meta.env.VITE_OIDC_REDIRECT_PATH || import.meta.env.VITE_IAM_REDIRECT_URI,
  '/dashboard',
);
const silentRedirectUri = normalizeUrl(
  import.meta.env.VITE_OIDC_SILENT_REDIRECT_PATH || import.meta.env.VITE_SILENT_REDIRECT_URI,
  '/silent-renew.html',
);
const postLogoutRedirectUri = normalizeUrl(
  import.meta.env.VITE_OIDC_POST_LOGOUT_REDIRECT_PATH || import.meta.env.VITE_IAM_POST_LOGOUT_REDIRECT_URI,
  '/',
);

export const isOidcConfigured = Boolean(authority && clientId && redirectUri);
export const keycloakAuthEndpoint = authority
  ? `${authority}/protocol/openid-connect/auth`
  : '';

export const getKeycloakLoginUrl = () => {
  if (!isOidcConfigured || !keycloakAuthEndpoint) return '';
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: requestedScope,
  });
  return `${keycloakAuthEndpoint}?${params.toString()}`;
};

const oidcConfig = {
  authority,
  client_id: clientId,
  redirect_uri: redirectUri,
  response_type: 'code',
  response_mode: 'query',
  scope: requestedScope,
  silent_redirect_uri: silentRedirectUri,
  post_logout_redirect_uri: postLogoutRedirectUri,
  automaticSilentRenew: true,
  onSigninCallback: () => {
    // Remove OIDC callback params after Keycloak redirect
    window.history.replaceState(
      {},
      document.title,
      window.location.pathname + window.location.hash
    );
  },
};

export default oidcConfig;
