export const DEFAULT_POST_LOGIN_PATH = '/dashboard';

export const sanitizeAppReturnPath = (value) => {
  if (typeof value !== 'string') return null;

  const trimmed = value.trim();
  if (!trimmed.startsWith('/') || trimmed.startsWith('//')) return null;
  if (trimmed.startsWith('/auth/login')) return null;

  return trimmed;
};

export const resolvePostLoginPath = (value, fallback = DEFAULT_POST_LOGIN_PATH) => {
  return sanitizeAppReturnPath(value) || fallback;
};

export const buildLoginRedirectPath = (returnTo) => {
  const safeReturnTo = sanitizeAppReturnPath(returnTo);
  if (!safeReturnTo || safeReturnTo === DEFAULT_POST_LOGIN_PATH) {
    return '/auth/login';
  }

  return `/auth/login?redirect=${encodeURIComponent(safeReturnTo)}`;
};

export const buildOidcSigninArgs = ({ returnTo, prompt } = {}) => {
  const safeReturnTo = sanitizeAppReturnPath(returnTo);
  const trimmedPrompt = typeof prompt === 'string' ? prompt.trim() : '';

  return {
    ...(safeReturnTo ? { state: { returnTo: safeReturnTo } } : {}),
    extraQueryParams: {
      ...(trimmedPrompt ? { prompt: trimmedPrompt } : {}),
      max_age: '0',
    },
  };
};

export const getOidcReturnPath = (authUser) => {
  return sanitizeAppReturnPath(authUser?.state?.returnTo);
};
