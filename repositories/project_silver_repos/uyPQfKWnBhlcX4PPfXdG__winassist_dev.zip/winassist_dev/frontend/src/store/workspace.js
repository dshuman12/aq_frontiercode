import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { apiRequest, canUseAuthenticatedRequests } from '../lib/api-client';
import useUserStore from './user';

const WORKSPACE_STORAGE_KEY = 'winassist-workspace-storage';
const LEGACY_WORKSPACE_STORAGE_KEY = 'agentok-workspace-storage';
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const clientStorage = {
  getItem: (name) => {
    if (typeof window === 'undefined') return null;
    const currentValue = localStorage.getItem(name);
    if (currentValue !== null || name !== WORKSPACE_STORAGE_KEY) return currentValue;
    return localStorage.getItem(LEGACY_WORKSPACE_STORAGE_KEY);
  },
  setItem: (name, value) => {
    if (typeof window !== 'undefined') localStorage.setItem(name, value);
  },
  removeItem: (name) => {
    if (typeof window !== 'undefined') localStorage.removeItem(name);
  },
};

const useWorkspaceStore = create()(
  persist(
    (set, get) => ({
      workspaces: [],
      currentWorkspaceId: null,
      loading: false,
      error: null,
      lastFetchedAt: 0,
      _inflight: null,

      setCurrentWorkspaceId: (id) => set({ currentWorkspaceId: id }),

      fetchWorkspaces: async (opts = {}) => {
        const { force = false, minIntervalMs = 5000, retries = 4, retryDelayMs = 1200 } = opts || {};
        const now = Date.now();
        const user = useUserStore?.getState?.().user;

        if (!canUseAuthenticatedRequests(user)) {
          set({ workspaces: [], currentWorkspaceId: null, loading: false });
          return [];
        }

        // Avoid request storms when multiple components mount at once.
        if (!force) {
          if (get().loading && get()._inflight) return get()._inflight;
          if (now - (get().lastFetchedAt || 0) < minIntervalMs) return get().workspaces;
        }

        try {
          set({ loading: true, error: null });
          const requestPromise = (async () => {
            let lastError = null;
            const maxAttempts = Math.max(1, Number(retries || 1));

            for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
              try {
                return await apiRequest('/workspaces', {
                  method: 'GET',
                  showErrorToast: false,
                });
              } catch (err) {
                lastError = err;
                if (err?.status === 401) {
                  set({ workspaces: [], currentWorkspaceId: null, error: null });
                  return [];
                }
                if (attempt >= maxAttempts) {
                  throw err;
                }
                await wait(retryDelayMs * attempt);
              }
            }

            throw lastError ?? new Error('Failed to load workspaces');
          })();

          set({ _inflight: requestPromise });

          const data = await requestPromise;

          const workspaces = Array.isArray(data) ? data : [];
          let currentWorkspaceId = get().currentWorkspaceId;

          // If the stored workspace is no longer in the list (e.g. removed from workspace),
          // fall back to the first available workspace.
          const ids = workspaces.map((w) => w.id);
          if (!currentWorkspaceId || !ids.includes(currentWorkspaceId)) {
            currentWorkspaceId = workspaces.length > 0 ? workspaces[0].id : null;
          }

          set({
            workspaces,
            currentWorkspaceId,
            error: null,
            lastFetchedAt: now,
          });
          return workspaces;
        } catch (err) {
          set({
            error: err instanceof Error ? err : new Error('Failed to load workspaces'),
          });
          return [];
        } finally {
          set({ loading: false, _inflight: null });
        }
      },
    }),
    {
      name: WORKSPACE_STORAGE_KEY,
      storage: createJSONStorage(() => clientStorage),
      // Only persist what we need
      partialize: (state) => ({
        currentWorkspaceId: state.currentWorkspaceId,
      }),
    }
  )
);

export default useWorkspaceStore;

