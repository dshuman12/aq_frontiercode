import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { apiRequest } from '../lib/api-client';
// export interface User {
//     id: number;
//     email: string;
//     user_metadata?: { name?: string; avatar_url?: string };
//     app_metadata?: any;
//     confirmed_at?: string;
//     created_at?: string;
//     token?: string;
//   }
  
//   interface UserState {
//     user: User | null;
//     loading: boolean;
//     error: Error | null;
//     fetchUser: () => Promise<void>;
//     setUser: (user: User | null) => void;
//   }

const USER_STORAGE_KEY = 'winassist-user-storage';
const LEGACY_USER_STORAGE_KEY = 'agentok-user-storage';

const clientStorage = {
    getItem: (name) => {
      if (typeof window === 'undefined') return null;
      const currentValue = localStorage.getItem(name);
      if (currentValue !== null || name !== USER_STORAGE_KEY) return currentValue;
      return localStorage.getItem(LEGACY_USER_STORAGE_KEY);
    },
    setItem: (name, value) => {
      if (typeof window !== 'undefined') localStorage.setItem(name, value);
    },
    removeItem: (name) => {
      if (typeof window !== 'undefined') localStorage.removeItem(name);
    },
  };

const parseMetadata = (user) => {
  const rawMeta = user?.user_metadata;
  if (!rawMeta) return {};
  if (typeof rawMeta === 'string') {
    try {
      const parsed = JSON.parse(rawMeta);
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }
  return typeof rawMeta === 'object' ? rawMeta : {};
};

const splitFullName = (fullName) => {
  const value = typeof fullName === 'string' ? fullName.trim() : '';
  if (!value) return { firstName: '', lastName: '' };
  const parts = value.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return { firstName: parts[0], lastName: '' };
  return {
    firstName: parts[0],
    lastName: parts.slice(1).join(' '),
  };
};

const firstDefined = (...values) => values.find((value) => value !== undefined && value !== null);

const firstNonEmptyString = (...values) => {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
};

const normalizeUser = (incomingUser, previousUser = null) => {
  if (!incomingUser) return null;

  const incomingMeta = parseMetadata(incomingUser);
  const previousMeta = parseMetadata(previousUser);
  const incomingFullName = incomingUser?.name || incomingMeta?.name;
  const previousFullName = previousUser?.name || previousMeta?.name;
  const incomingSplit = splitFullName(incomingFullName);
  const previousSplit = splitFullName(previousFullName);

  const firstName = firstNonEmptyString(
    incomingUser?.first_name,
    incomingUser?.firstName,
    incomingMeta?.first_name,
    incomingMeta?.firstName,
    incomingSplit.firstName,
    previousUser?.first_name,
    previousUser?.firstName,
    previousMeta?.first_name,
    previousMeta?.firstName,
    previousSplit.firstName
  );

  const lastName = firstNonEmptyString(
    incomingUser?.last_name,
    incomingUser?.lastName,
    incomingMeta?.last_name,
    incomingMeta?.lastName,
    incomingSplit.lastName,
    previousUser?.last_name,
    previousUser?.lastName,
    previousMeta?.last_name,
    previousMeta?.lastName,
    previousSplit.lastName
  );

  const mobileNumber = firstDefined(
    incomingUser?.mobile_number,
    incomingUser?.mobileNumber,
    incomingMeta?.mobile_number,
    incomingMeta?.mobileNumber,
    previousUser?.mobile_number,
    previousUser?.mobileNumber,
    previousMeta?.mobile_number,
    previousMeta?.mobileNumber
  );

  const userName = firstNonEmptyString(
    incomingUser?.user_name,
    incomingUser?.userName,
    incomingMeta?.user_name,
    incomingMeta?.userName,
    previousUser?.user_name,
    previousUser?.userName,
    previousMeta?.user_name,
    previousMeta?.userName
  );

  const companyName = firstNonEmptyString(
    incomingUser?.company_name,
    incomingUser?.companyName,
    incomingMeta?.company_name,
    incomingMeta?.companyName,
    previousUser?.company_name,
    previousUser?.companyName,
    previousMeta?.company_name,
    previousMeta?.companyName
  );

  const token = incomingUser?.token ?? previousUser?.token;

  return {
    ...previousUser,
    ...incomingUser,
    first_name: firstName,
    last_name: lastName,
    user_name: userName,
    company_name: companyName,
    mobile_number: mobileNumber ?? '',
    ...(token ? { token } : {}),
  };
};

  const useUserStore = create()(
    persist(
      (set, get) => ({
        user: null,
        loading: false,
        error: null,
        fetchUser: async () => {
          try {
            set({ loading: true });
            const currentUser = get().user;
            const user = await apiRequest('/auth/me', {
              method: 'GET',
              showErrorToast: false, // Don't show toast for user fetch errors
            });
            set({
              user: normalizeUser(user, currentUser),
              error: null,
            });
          } catch (err) {
            set({ error: err  instanceof Error ? err : new Error('Unknown error') });
          } finally {
            set({ loading: false });
          }
        },
        setUser: (user) =>
          set((state) => ({
            user: normalizeUser(user, state.user),
            error: null,
          })),
      }),
      { name: USER_STORAGE_KEY, storage: createJSONStorage(() => clientStorage) }
    )
  );
  export default useUserStore