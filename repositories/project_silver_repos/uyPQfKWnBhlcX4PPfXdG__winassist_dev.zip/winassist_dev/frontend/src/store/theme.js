import { create } from 'zustand';

export const THEME_STORAGE_KEY = 'winassist-theme';

export const THEMES = {
  LIGHT: 'light',
  DARK: 'dark',
};

function normalizeTheme(theme) {
  return theme === THEMES.DARK ? THEMES.DARK : THEMES.LIGHT;
}

export function getStoredTheme() {
  if (typeof window === 'undefined') return null;
  const storedTheme = window.localStorage.getItem(THEME_STORAGE_KEY);
  if (!storedTheme) return null;
  return normalizeTheme(storedTheme);
}

export function applyTheme(theme) {
  const resolvedTheme = normalizeTheme(theme);

  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    root.classList.toggle(THEMES.DARK, resolvedTheme === THEMES.DARK);
    root.setAttribute('data-theme', resolvedTheme);
    root.style.colorScheme = resolvedTheme;

    if (document.body) {
      document.body.setAttribute('data-theme', resolvedTheme);
    }
  }

  return resolvedTheme;
}

function commitTheme(theme, setThemeState) {
  const resolvedTheme = applyTheme(theme);
  persistTheme(resolvedTheme);
  setThemeState({ theme: resolvedTheme });
}

function supportsViewTransition() {
  return typeof document !== 'undefined' && typeof document.startViewTransition === 'function';
}

function setThemeTransitionState(active) {
  if (typeof document === 'undefined') return;
  document.documentElement.classList.toggle('theme-transitioning', active);
  if (document.body) {
    document.body.classList.toggle('theme-transitioning', active);
  }
}

function persistTheme(theme) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(THEME_STORAGE_KEY, normalizeTheme(theme));
}

const getInitialTheme = () => {
  if (typeof window === 'undefined') return THEMES.LIGHT;
  const storedTheme = window.localStorage.getItem(THEME_STORAGE_KEY);
  return normalizeTheme(storedTheme);
};

const useThemeStore = create((set, get) => ({
  theme: getInitialTheme(),
  setTheme: (theme) => {
    commitTheme(theme, set);
  },
  setThemeWithTransition: (theme) => {
    if (!supportsViewTransition()) {
      setThemeTransitionState(true);
      requestAnimationFrame(() => {
        commitTheme(theme, set);
        window.setTimeout(() => setThemeTransitionState(false), 240);
      });
      return;
    }

    setThemeTransitionState(true);

    const transition = document.startViewTransition(() => {
      commitTheme(theme, set);
    });

    transition.finished.finally(() => {
      setThemeTransitionState(false);
    });
  },
  toggleTheme: () => {
    const nextTheme = get().theme === THEMES.DARK ? THEMES.LIGHT : THEMES.DARK;
    get().setThemeWithTransition(nextTheme);
  },
  hydrateTheme: () => {
    const storedTheme = getStoredTheme();
    const resolvedTheme = applyTheme(storedTheme || get().theme);
    set({ theme: resolvedTheme });
  },
}));

export default useThemeStore;
