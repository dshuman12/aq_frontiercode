import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const CHAT_STORAGE_KEY = 'winassist-chats';
const LEGACY_CHAT_STORAGE_KEY = 'agentok-chats';

const chatStorage = {
  getItem: (name) => {
    if (typeof window === 'undefined') return null;
    const currentValue = localStorage.getItem(name);
    if (currentValue !== null || name !== CHAT_STORAGE_KEY) return currentValue;
    return localStorage.getItem(LEGACY_CHAT_STORAGE_KEY);
  },
  setItem: (name, value) => {
    if (typeof window !== 'undefined') localStorage.setItem(name, value);
  },
  removeItem: (name) => {
    if (typeof window !== 'undefined') localStorage.removeItem(name);
  },
};


const useChatStore = create()(
  persist(
    (set, get) => ({
     
      chats: [],
      sidebarCollapsed: false,
      activeChatId: -1,
      setChats: (chats) => set({ chats }),
      setActiveChatId: (chatId) => set({ activeChatId: chatId }),
      setSidebarCollapsed: (collapsed) =>
        set({ sidebarCollapsed: collapsed }),
      updateChat: (id, newChat) =>
        set((state) => {
          const chats = state.chats.map((chat) => {
            if (chat.id === id) {
           
              return { ...chat, ...newChat };
            }
            return chat;
          });
          return { chats };
        }),
      deleteChat: (id) =>
        set((state) => {
          return {
            chats: state.chats.filter((chat) => chat.id !== id),
          };
        }),
      getChatById: (id) => {
        return get().chats.find((chat) => chat.id === id);
      },
    }),
    {
      name: CHAT_STORAGE_KEY,
      storage: chatStorage,
    }
  )
);

export default useChatStore;
