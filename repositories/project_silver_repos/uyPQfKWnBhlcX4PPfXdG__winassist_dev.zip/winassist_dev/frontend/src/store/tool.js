import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const PROJECT_STORAGE_KEY = 'winassist-projects';
const LEGACY_PROJECT_STORAGE_KEY = 'agentok-projects';

const toolStorage = {
  getItem: (name) => {
    if (typeof window === 'undefined') return null;
    const currentValue = localStorage.getItem(name);
    if (currentValue !== null || name !== PROJECT_STORAGE_KEY) return currentValue;
    return localStorage.getItem(LEGACY_PROJECT_STORAGE_KEY);
  },
  setItem: (name, value) => {
    if (typeof window !== 'undefined') localStorage.setItem(name, value);
  },
  removeItem: (name) => {
    if (typeof window !== 'undefined') localStorage.removeItem(name);
  },
};



const useToolStore = create()(
  persist(
    (set, get) => ({
      tools: [],
      setTools: (tools) => set({ tools }),
      addTool: (newTool) =>
        set((state) => ({
          tools: [newTool, ...state.tools.filter((tool) => tool.id !== newTool.id)],
        })),
      updateTool: (id, newTool) =>
        set((state) => {
          const tools = state.tools.map((tool) => {
            if (tool.id === id || String(tool.id) === String(id) || tool.uuid === id) {
              return { ...tool, ...newTool };
            }
            return tool;
          });
          return { tools };
        }),
      deleteTool: (id) =>
        set((state) => ({
          tools: state.tools.filter((t) => t.id !== id),
        })),
      getToolById: (id) =>
        id ? get().tools.find((tool) => tool.id === id) : undefined,
    }),
    {
      name: PROJECT_STORAGE_KEY,
      storage: toolStorage,
    }
  )
);

export default useToolStore;
