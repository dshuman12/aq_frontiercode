import { useState, useCallback, useEffect, useRef } from 'react';
import useUserStore from '../store/user';
import useProjectStore from '../store/project';
import useSWR from 'swr';
import { isEqual } from "lodash-es";
import useToolStore from '../store/tool';
import { authenticatedFetcher, apiRequest } from '../lib/api-client';

  export function useTools() {
    const { data, error, mutate } = useSWR(
      `/tools`,
      authenticatedFetcher,
      {
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
      }
    );
  
    const tools = useToolStore((state) => state.tools);
    const setTools = useToolStore((state) => state.setTools);
    const addToolState = useToolStore((state) => state.addTool);
    const updateToolState = useToolStore((state) => state.updateTool);
    const deleteToolState = useToolStore((state) => state.deleteTool);
    const getToolById = useToolStore((state) => state.getToolById);
    const prevDataRef = useRef();
  
    useEffect(() => {
      if (data && !isEqual(data, prevDataRef.current)) {
        setTools(data);
        prevDataRef.current = data;
      }
    }, [data, setTools]);
  
 
    const [isCreating, setIsCreating] = useState(false);
    const createTool = useCallback(
      async (toolData) => {
        setIsCreating(true);
        try {
          const newTool = await apiRequest('/tools', {
            method: 'POST',
            body: toolData,
          });
  
          setTools([newTool, ...tools]);
          await mutate();
          return newTool;
        } catch (err) {
          console.error("❌ Failed to create tool:", err);
          throw err;
        } finally {
          setIsCreating(false);
        }
      },
      [tools, setTools, mutate]
    );
  
   
    const [isUpdating, setIsUpdating] = useState(false);
    const updateTool = useCallback(
      async (id, updates) => {
        setIsUpdating(true);
        try {
          const prevTool = tools.find((t) => t.id === id || t.uuid === id || String(t.id) === String(id));
          if (!prevTool) {
            return;
          }

          // Merge updates with previous tool
          const fullUpdates = { ...prevTool, ...updates };

          // Only send fields that ToolCreate expects (name, description, variables, code, is_public)
          const toolCreateData = {
            name: fullUpdates.name,
            description: fullUpdates.description || null,
            variables: fullUpdates.variables || [],
            code: fullUpdates.code || null,
            is_public: fullUpdates.is_public || false,
          };

          if (!prevTool.is_public) {
            updateToolState(id, fullUpdates);
          }

          const updatedTool = await apiRequest(`/tools/${id}`, {
            method: 'PUT',
            body: toolCreateData,
          });

          if (
            updatedTool &&
            String(updatedTool.id) !== String(id) &&
            String(updatedTool.uuid || '') !== String(id)
          ) {
            addToolState(updatedTool);
          } else {
            updateToolState(id, updatedTool);
          }
          await mutate();
          return updatedTool;
        } catch (err) {
          console.error("❌ Failed to update tool:", err);
          const prevTool = tools.find((t) => t.id === id || t.uuid === id || String(t.id) === String(id));
          if (prevTool) updateToolState(id, prevTool);
          throw err;
        } finally {
          setIsUpdating(false);
        }
      },
      [tools, addToolState, updateToolState, mutate]
    );
  
   
    const [isDeleting, setIsDeleting] = useState(false);
    const deleteTool = useCallback(
      async (id) => {
        setIsDeleting(true);
        const prevTools = [...tools];
        deleteToolState(id);
  
        try {
          await apiRequest(`/tools/${id}`, {
            method: 'DELETE',
          });
          await mutate();
        } catch (err) {
          console.error("❌ Failed to delete tool:", err);
          setTools(prevTools); 
        } finally {
          setIsDeleting(false);
        }
      },
      [tools, deleteToolState, setTools, mutate]
    );
  
   
    const saveToolParameterConfig = useCallback(
      async (
        toolId,
        nodeId,
        agentId,
        parameters
      ) => {
        // Parameters are stored in node.data.toolParameterConfigs which persists when project is saved
        // The backend endpoint doesn't exist, so we skip the API call
        // Return success immediately - parameters are saved in node data
        undefined
        return { success: true };
      },
      []
    );
  
  
    const getToolParameterConfigs = useCallback(
      async (toolId, nodeId, agentId) => {
        // Parameters are stored in node.data.toolParameterConfigs which is loaded from project flow
        // The backend endpoint doesn't exist, so we return empty object
        // The actual parameters are loaded from node data in the component
        undefined
        return {};
      },
      []
    );
  
    const deleteToolParameterConfigs = useCallback(
      async (toolId, nodeId, agentId) => {
        try {
          return await apiRequest(`/tools/${toolId}/parameter-configs?agent_id=${agentId}&node_id=${nodeId}`, {
            method: 'DELETE',
          });
        } catch (err) {
          console.error("❌ Failed to delete tool parameter configs:", err);
          throw err;
        }
      },
      []
    );
  
    return {
      tools: data ?? [],
      isLoading: !data && !error,
      isError: error,
      createTool,
      updateTool,
      deleteTool,
      isCreating,
      isUpdating,
      isDeleting,
      getToolById,
      refresh: mutate,
      saveToolParameterConfig,
      getToolParameterConfigs,
      deleteToolParameterConfigs,
    };
  }
  export function useTool(toolId) {
    const {
      tools,
      updateTool,
      deleteTool,
      isUpdating,
      isDeleting,
      isLoading,
      isError,
      saveToolParameterConfig,
      getToolParameterConfigs,
      deleteToolParameterConfigs,
    } = useTools();
  
    const tool = tools.find((t) => t.id === toolId || t.uuid === toolId || t.id === Number(toolId));
  
    return {
      tool,
      updateTool: (updates) => {
        if (!tool) return;
        const mergedUpdates = { ...tool, ...updates };
        return updateTool(toolId, mergedUpdates);
      },
      deleteTool: () => deleteTool(toolId),
      isUpdating,
      isDeleting,
      isLoading,
      isError,
     
      saveParameterConfig: (nodeId, agentId, parameters) =>
        saveToolParameterConfig(toolId, nodeId, agentId, parameters),
      getParameterConfigs: (nodeId, agentId) =>
        getToolParameterConfigs(toolId, nodeId, agentId),
      deleteParameterConfigs: (nodeId, agentId) =>
        deleteToolParameterConfigs(toolId, nodeId, agentId),
    };
  }