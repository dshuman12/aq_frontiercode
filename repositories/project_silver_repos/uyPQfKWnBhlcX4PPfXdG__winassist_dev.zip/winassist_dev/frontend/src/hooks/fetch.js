import { getBackendUrl, getHeaders } from '../lib/api-client';

export const fetcher = async (url) => {
    // If URL is already absolute, use it as-is; otherwise prepend base URL
    const baseUrl = getBackendUrl();
    // Ensure proper URL construction - handle leading slashes
    let fullUrl;
    if (url.startsWith('http')) {
      fullUrl = url;
    } else {
      // Remove leading slash from url if baseUrl already ends with one, or ensure proper joining
      const cleanUrl = url.startsWith('/') ? url.slice(1) : url;
      const cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
      fullUrl = `${cleanBaseUrl}/${cleanUrl}`;
    }
    
    const response = await fetch(fullUrl, {
      method: 'GET',
      headers: getHeaders(true),
      credentials: 'include',
    });
    if (!response.ok) {
      console.error(`Failed fetcher ${fullUrl}:`, response.statusText);
      return null;
    }
    return response.json();
  };
  