import useSWR from 'swr';
import { apiRequest, authenticatedFetcher } from '../lib/api-client';

export function useProjectGovernance(projectId) {
  const shouldFetch = Boolean(projectId);
  const endpoint = shouldFetch ? `/projects/${projectId}/governance` : null;

  const { data, error, isLoading, mutate } = useSWR(endpoint, authenticatedFetcher);

  const refresh = async () => mutate();

  const updatePolicy = async (policy) => {
    if (!projectId) {
      throw new Error('Project is required');
    }
    const result = await apiRequest(`/projects/${projectId}/governance/policy`, {
      method: 'PUT',
      body: policy,
    });
    await mutate();
    return result;
  };

  const createRelease = async (payload) => {
    if (!projectId) {
      throw new Error('Project is required');
    }
    const result = await apiRequest(`/projects/${projectId}/governance/releases`, {
      method: 'POST',
      body: payload,
    });
    await mutate();
    return result;
  };

  const rollbackRelease = async (releaseId, payload = {}) => {
    if (!projectId) {
      throw new Error('Project is required');
    }
    const result = await apiRequest(
      `/projects/${projectId}/governance/releases/${releaseId}/rollback`,
      {
        method: 'POST',
        body: payload,
      }
    );
    await mutate();
    return result;
  };

  const compareReleases = async ({ leftReleaseId, rightReleaseId, compareToCurrent = false }) => {
    if (!projectId) {
      throw new Error('Project is required');
    }
    if (!leftReleaseId) {
      throw new Error('A base release is required');
    }
    const params = new URLSearchParams();
    params.set('left_release_id', String(leftReleaseId));
    if (compareToCurrent) {
      params.set('compare_to_current', 'true');
    } else if (rightReleaseId) {
      params.set('right_release_id', String(rightReleaseId));
    }
    return apiRequest(`/projects/${projectId}/governance/compare?${params.toString()}`, {
      method: 'GET',
    });
  };

  return {
    governance: data,
    isLoading,
    isError: error,
    refresh,
    updatePolicy,
    createRelease,
    rollbackRelease,
    compareReleases,
  };
}
