import { useEffect } from 'react';
import useWorkspaceStore from '../store/workspace';
import useUserStore from '../store/user';
import { canUseAuthenticatedRequests } from '../lib/api-client';

export function useWorkspaces() {
  const {
    workspaces,
    currentWorkspaceId,
    loading,
    error,
    fetchWorkspaces,
    setCurrentWorkspaceId,
  } = useWorkspaceStore();
  const user = useUserStore((state) => state.user);

  // Always refresh workspace list on mount so that newly accepted invites show up
  // without requiring a full page reload.
  useEffect(() => {
    if (!canUseAuthenticatedRequests(user)) return;
    fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const currentWorkspace =
    workspaces?.find((w) => w.id === currentWorkspaceId) || workspaces?.[0] || null;

  return {
    workspaces,
    currentWorkspace,
    currentWorkspaceId: currentWorkspace?.id || null,
    loading,
    error,
    fetchWorkspaces,
    setCurrentWorkspaceId,
  };
}

