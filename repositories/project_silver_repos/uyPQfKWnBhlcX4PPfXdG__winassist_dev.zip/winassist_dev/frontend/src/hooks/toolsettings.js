import useSWR from 'swr';
import { useState } from 'react';
import { fetcher } from './fetch';
import { apiRequest } from '../lib/api-client';

export function useToolSettings() {
  const { data, error, mutate } = useSWR(
    '/settings/tools',
    fetcher
  );
  const [isUpdating, setIsUpdating] = useState(false);
  const handleUpdateSettings = async (newSettings) => {
    setIsUpdating(true);
    undefined
    try {
      const updatedSettings = await apiRequest('/settings/tools', {
        method: 'POST',
        body: newSettings,
        showErrorToast: true,
      });
      await mutate(); // Revalidate the SWR cache
      return updatedSettings;
    } catch (error) {
      console.error('Failed to update the settings:', error);
      throw error;
    } finally {
      setIsUpdating(false);
    }
  };

  return {
    settings: data ?? {},
    isLoading: !error && !data,
    isError: error,
    refresh: mutate,
    updateSettings: handleUpdateSettings,
    isUpdating,
  };
}
