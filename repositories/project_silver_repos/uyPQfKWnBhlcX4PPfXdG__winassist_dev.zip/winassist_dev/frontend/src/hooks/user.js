// useUser.ts
import { useEffect, useRef } from 'react';
import useUserStore from '../store/user';
import { canUseAuthenticatedRequests } from '../lib/api-client';

export function useUser() {
  const { user, loading, error, fetchUser } = useUserStore();
  const hydratedRef = useRef(false);
  const hasToken = canUseAuthenticatedRequests(user);

  useEffect(() => {
    const needsHydration =
      user &&
      (user.first_name == null ||
        user.last_name == null ||
        user.user_name == null ||
        user.company_name == null ||
        user.mobile_number == null);

    if (!hasToken) return;

    if (!loading && !error && (!user || (needsHydration && !hydratedRef.current))) {
      hydratedRef.current = true;
      fetchUser();
    }
  }, [user, hasToken, loading, error, fetchUser]);

  return { user, userId: user?.id || null, loading, error };
}
