import { useState, useCallback, useEffect, useRef } from 'react';
import useUserStore from '../store/user';
import useProjectStore from '../store/project';
import useWorkspaceStore from '../store/workspace';
import useSWR from 'swr';
import { authenticatedFetcher, canUseAuthenticatedRequests } from '../lib/api-client';
export const initialEdges = [
    {
      id: '1001-1',
      source: '1001',
      target: '1',
    },
    {
      id: '1-2',
      source: '1',
      target: '2',
      animated: true,
      type: 'converse',
    },
    // New node edges
    {
      id: '2-text',
      source: '2',
      target: 'text-1',
    },
    {
      id: 'text-input',
      source: 'text-1',
      target: 'input-1',
    },
    {
      id: 'input-delay',
      source: 'input-1',
      target: 'delay-1',
    },
    {
      id: 'delay-assistant',
      source: 'delay-1',
      target: 'assistant-1',
    },
    {
      id: 'assistant-condition',
      source: 'assistant-1',
      target: 'condition-1',
    },
    {
      id: 'condition-quickreply',
      source: 'condition-1',
      target: 'quickreply-1',
      sourceHandle: 'if',
    },
    {
      id: 'quickreply-container',
      source: 'quickreply-1',
      target: 'container-1',
      sourceHandle: 'option-0',
    },
    {
      id: 'container-branch',
      source: 'container-1',
      target: 'branch-1',
      sourceHandle: 'option-0',
    },
  ];

// Backend initial nodes: initializer, user, conversable, note (compact layout)
export const initialBackendNodes = [
  {
    id: '1001',
    type: 'initializer',
    data: {
      name: 'Initializer',
      id: 'initializer',
      class_type: 'Initializer',
      sample_messages: [
        'Write a poem based on recent headlines about Vancouver.',
      ],
    },
    position: { x: 80, y: 220 },
  },
  {
    id: '1',
    type: 'user',
    data: {
      name: 'User',
      id: 'user',
      class_type: 'User',
      human_input_mode: 'NEVER',
      termination_msg: 'TERMINATE',
      enable_code_execution: true,
      max_consecutive_auto_reply: 10,
      tools: [],
    },
    position: { x: 280, y: 220 },
  },
  {
    id: '2',
    type: 'conversable',
    data: {
      name: 'Conversable',
      id: 'conversable',
      class_type: 'ConversableAgent',
      max_consecutive_auto_reply: 10,
      tools: [],
    },
    position: { x: 480, y: 220 },
  },
  {
    id: '998',
    type: 'note',
    data: {
      name: 'note',
      id: 'note',
      class_type: 'Note',
      content:
        "**Welcome to your AI Agent**\n\nThis sample flow shows an Initializer → User → Conversable pipeline. Use the **Chat** panel (bottom right) to try the sample question. Add tools, more agents, or MCP nodes from the left panel. When you publish, you’ll get usage and analytics on the Dashboard.",
    },
    position: { x: 80, y: 440 },
    width: 420,
    height: 200,
    selected: false,
  },
];

// Backend initial edges (same step style for new AI agent flows)
export const initialBackendEdges = [
  {
    id: '1001-1',
    source: '1001',
    target: '1',
    type: 'step',
  },
  {
    id: '1-2',
    source: '1',
    target: '2',
    type: 'step',
  },
];

// Frontend initial nodes: 2D pattern from reference (Text top-middle; Delay top-right; Input middle-left; API bottom-left; Quick Reply bottom-right; Note bottom-middle)
export const initialFrontendNodes = [
  {
    id: 'text-1',
    type: 'text',
    data: {
      name: 'Text',
      id: 'text',
      class_type: 'TextNode',
      text: 'Welcome to the flow! This is a test node.',
    },
    position: { x: 260, y: 40 },
    width: 180,
    height: 100,
  },
  {
    id: 'delay-1',
    type: 'delay',
    data: {
      name: 'Delay',
      id: 'delay',
      class_type: 'DelayNode',
      delayMs: 2000,
    },
    position: { x: 500, y: 40 },
    width: 150,
    height: 100,
  },
  {
    id: 'input-1',
    type: 'input',
    data: {
      name: 'Input',
      id: 'input',
      class_type: 'InputNode',
      variableName: 'userInput',
      prompt: 'Please enter your input:',
    },
    position: { x: 80, y: 220 },
    width: 150,
    height: 100,
  },
  {
    id: '4',
    type: 'api',
    data: {
      name: 'Api',
      id: 'api',
      class_type: 'ApiNode',
      max_consecutive_auto_reply: 10,
      tools: [],
    },
    position: { x: 80, y: 380 },
  },
  {
    id: 'quickreply-1',
    type: 'quickreply',
    data: {
      name: 'Quick Reply',
      id: 'quickreply',
      class_type: 'QuickReplyNode',
      label: 'Quick Reply',
      message: 'Choose an option:',
      options: [
        { text: 'Option 1' },
        { text: 'Option 2' },
        { text: 'Option 3' },
      ],
      connections: {},
    },
    position: { x: 500, y: 300 },
    width: 200,
    height: 180,
  },
  {
    id: '998',
    type: 'note',
    data: {
      name: 'note',
      id: 'note',
      class_type: 'Note',
      content:
        "This is a frontend flow. Add nodes to build your conversation flow.",
    },
    position: { x: 220, y: 520 },
    width: 400,
    height: 200,
    selected: false,
  },
];

// Frontend initial edges: Text branches to Delay and Input; Delay → Quick Reply; Input → API
export const initialFrontendEdges = [
  { id: 'text-delay', source: 'text-1', target: 'delay-1' },
  { id: 'text-input', source: 'text-1', target: 'input-1' },
  { id: 'delay-quickreply', source: 'delay-1', target: 'quickreply-1' },
  { id: 'input-api', source: 'input-1', target: '4' },
];
export const initialNodes = [
    {
      id: '1001',
      type: 'initializer',
      data: {
        name: 'Initializer',
        id: 'initializer',
        class_type: 'Initializer',
        sample_messages: [
          'Write a poem based on recent headlines about Vancouver.',
        ],
      },
      position: { x: -133, y: 246 },
    },
    {
      id: '1',
      type: 'user',
      data: {
        name: 'User',
        id: 'user',
        class_type: 'User',
        human_input_mode: 'NEVER',
        termination_msg: 'TERMINATE',
        enable_code_execution: true,
        max_consecutive_auto_reply: 10,
        tools: [],
      },
      position: { x: 271, y: 222 },
    },
    {
      id: '2',
      type: 'conversable',
      data: {
        name: 'Conversable',
        id: 'conversable',
        class_type: 'ConversableAgent',
        max_consecutive_auto_reply: 10,
        tools: [],
      },
      position: { x: 811, y: 216 },
    },
    {
      id: '3',
      type: 'conversable',
      data: {
        name: 'Conversable',
        id: 'conversable',
        class_type: 'ConversableAgent',
        max_consecutive_auto_reply: 10,
        tools: [],
      },
      position: { x: 811, y: 214 },
    },
    {
      id: '4',
      type: 'api',
      data: {
        name: 'Api',
        id: 'api',
        class_type: 'ApiNode',
        max_consecutive_auto_reply: 10,
        tools: [],
      },
      position: { x: 271, y: 214 },
    },
    {
      id: '998',
      type: 'note',
      data: {
        name: 'note',
        id: 'note',
        class_type: 'Note',
        content:
          "Click **Chat** icon on the right bottom to show the chat pane, and in chat pane, select a sample question to start the conversation.",
      },
      position: { x: 87, y: 740 },
      width: 400,
      height: 200,
      selected: false,
    },
    // New nodes from src copy
    {
      id: 'text-1',
      type: 'text',
      data: {
        name: 'Text',
        id: 'text',
        class_type: 'TextNode',
        text: 'Welcome to the flow! This is a text node.',
      },
      position: { x: 1350, y: 216 },
      width: 150,
      height: 100,
    },
    {
      id: 'input-1',
      type: 'input',
      data: {
        name: 'Input',
        id: 'input',
        class_type: 'InputNode',
        variableName: 'userInput',
        prompt: 'Please enter your input:',
      },
      position: { x: 1600, y: 216 },
      width: 150,
      height: 100,
    },
    {
      id: 'delay-1',
      type: 'delay',
      data: {
        name: 'Delay',
        id: 'delay',
        class_type: 'DelayNode',
        delayMs: 2000,
      },
      position: { x: 1850, y: 216 },
      width: 150,
      height: 100,
    },
    {
      id: 'assistant-1',
      type: 'assistant',
      data: {
        name: 'Assistant',
        id: 'assistant',
        class_type: 'AssistantNode',
      },
      position: { x: 2100, y: 216 },
      width: 150,
      height: 100,
    },
    {
      id: 'condition-1',
      type: 'condition',
      data: {
        name: 'Condition',
        id: 'condition',
        class_type: 'ConditionNode',
        label: 'If-Else',
        ifCondition: 'userInput === "yes"',
        elseIfConditions: [
          { condition: 'userInput === "maybe"' },
        ],
        elseNode: true,
        connections: {},
      },
      position: { x: 2350, y: 216 },
      width: 220,
      height: 160,
    },
    {
      id: 'quickreply-1',
      type: 'quickreply',
      data: {
        name: 'Quick Reply',
        id: 'quickreply',
        class_type: 'QuickReplyNode',
        label: 'Quick Reply',
        message: 'Choose an option:',
        options: [
          { text: 'Option 1' },
          { text: 'Option 2' },
          { text: 'Option 3' },
        ],
        connections: {},
      },
      position: { x: 2600, y: 216 },
      width: 200,
      height: 180,
    },
    {
      id: 'container-1',
      type: 'container',
      data: {
        name: 'Container',
        id: 'container',
        class_type: 'ContainerNode',
        label: 'Container',
        icon: '📦',
        message: 'This is a container with quick reply options',
        options: [
          { text: 'Continue', id: 'opt1' },
          { text: 'Cancel', id: 'opt2' },
        ],
      },
      position: { x: 2850, y: 216 },
      width: 250,
      height: 200,
    },
    {
      id: 'branch-1',
      type: 'branch',
      data: {
        name: 'Branch',
        id: 'branch',
        class_type: 'BranchNode',
        label: 'IF Branch',
        condition: 'Continue selected',
        branchType: 'if',
      },
      position: { x: 3150, y: 216 },
    },
  ];
  
export function useProjects(){
    // React to the currently selected workspace so we only show its projects.
    const currentWorkspaceId = useWorkspaceStore((state) => state.currentWorkspaceId);
    const user = useUserStore((state) => state.user);
    const shouldFetch = canUseAuthenticatedRequests(user);

    // SWR key is workspace-scoped: changing workspace triggers an automatic refetch.
    const swrKey = shouldFetch
      ? (currentWorkspaceId ? `/projects?workspace_id=${currentWorkspaceId}` : '/projects')
      : null;

    const { data, error, mutate } = useSWR(
        swrKey,
        authenticatedFetcher,
        {
          revalidateOnFocus: false,
        }
      );
    const projects=useProjectStore((state)=>state.projects)
    const setProjects=useProjectStore((state)=>state.setProjects)
    const deleteProject=useProjectStore((state)=>state.deleteProject)
    const updateProject=useProjectStore((state)=>state.updateProject)
    const activeProjectId=useProjectStore((state)=>state.activeProjectId)
    const setActiveProjectId=useProjectStore((state)=>state.setActiveProjectId)
    const getProjectById = useProjectStore((state) => state.getProjectById);
    const prevDataRef = useRef(data);

    // Clear stale projects immediately when workspace changes so old ones don't flash.
    useEffect(() => {
      setProjects([]);
      prevDataRef.current = null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentWorkspaceId, shouldFetch]);

    useEffect(() => {
        if (data && !error && data !== prevDataRef.current) {
          setProjects(data);
          prevDataRef.current = data;
        }
      }, [data, error, setProjects]);
      const [isCreating, setIsCreating] = useState(false);
      const handleCreateProject = useCallback(
        async (project) => {
          setIsCreating(true);
          try {
            const { apiRequest } = await import('../lib/api-client');
            // Respect currently selected workspace when creating a project.
            // Fallback to the first available workspace if none selected.
            const { workspaces, currentWorkspaceId } = useWorkspaceStore.getState();
            let workspace_id = currentWorkspaceId;
            if (!workspace_id && Array.isArray(workspaces) && workspaces.length > 0) {
              workspace_id = workspaces[0].id;
            }

            const newProject = await apiRequest('/projects/', {
              method: 'POST',
              body: {
                name: project?.name ?? 'New Project',
                description:
                  project?.description ?? 'A new project with sample nodes.',
                flow: project?.flow ?? {},
                project_type: project?.project_type ?? null,
                workspace_id: workspace_id ?? null,
              },
            });
            
            setProjects([newProject, ...projects]);
            await mutate();
            return newProject;
          } catch (error) {
            console.error('Failed to create project:', error);
            throw error;
          } finally {
            setIsCreating(false);
          }
        },
        [projects, setProjects, mutate]
      );
      const [isDeleting, setIsDeleting] = useState(false);
      const handleDeleteProject = useCallback(
        async (id) => {
          setIsDeleting(true);
          const previousProjects = [...projects];
          
          deleteProject(id);
          mutate(projects.filter(p => p.id !== id), false);
          
          try {
            const { apiRequest } = await import('../lib/api-client');
            await apiRequest(`/projects/${id}`, {
              method: 'DELETE',
            });
            
            await mutate();
          } catch (error) {
            console.error('Failed to delete project:', error);
            setProjects(previousProjects);
            await mutate();
            throw error;
          } finally {
            setIsDeleting(false);
          }
        },
        [projects, deleteProject, setProjects, mutate]
      );
      const [isUpdating, setIsUpdating] = useState(false);
    const handleUpdateProject = useCallback(
    async (id, project, options = {}) => {
      const { skipRevalidate = false } = options || {};
    
      setIsUpdating(true);
      const previousProject = projects.find((p) => p.id === id);
      if (!previousProject) {
        setIsUpdating(false);
        return;
      }
      
      updateProject(id, project);
      
      try {
        const { apiRequest } = await import('../lib/api-client');
        const updatedProject = await apiRequest(`/projects/${id}`, {
          method: 'PUT',
          body: project,
        });
        
        updateProject(id, updatedProject);
        // Revalidating `/projects?...` on every node drag makes flow editing feel slow.
        // For flow-only autosaves, we keep UI optimistic and skip list refetch.
        if (!skipRevalidate) {
          await mutate();
        }
      } catch (error) {
        console.error('Failed to update project:', error);
        updateProject(id, previousProject);
        throw error;
      } finally {
        setIsUpdating(false);
      }
    },
    [projects, updateProject, mutate]
  );

  const publishAsTemplate = useCallback(
    async (projectId, { name, description, category } = {}) => {
      try {
        const { apiRequest } = await import('../lib/api-client');
        const template = await apiRequest(`/templates/projects/${projectId}/publish`, {
          method: 'POST',
          body: { name, description, category },
        });
        return template;
      } catch (e) {
        console.error('Failed to publish template', e);
        throw e;
      }
    },
    []
  );
  return {
    projects,
    activeProjectId,
    setActiveProjectId,
    isError: error,
    isLoading: shouldFetch && !error && !data,
    refresh: mutate,
    createProject: handleCreateProject,
    isCreating,
    updateProject: handleUpdateProject,
    isUpdating,
    deleteProject: handleDeleteProject,
    isDeleting,
    getProjectById,
    publishAsTemplate,
  }
}

export function useProject(id) {
    const { isLoading, isError, updateProject, isUpdating, getProjectById } =
      useProjects();
    return {
      project: getProjectById(id),
      isLoading,
      isError,
      updateProject: (project, options) => updateProject(id, project, options),
      isUpdating,
    };
  }
