/**
 * Parse cURL command and extract API details
 * Supports real-world cURL from Postman/Insomnia:
 * - Line continuations (backslash-newline)
 * - GET, POST, PUT, PATCH, DELETE with method and body
 * - Headers (quoted and unquoted)
 * - Request body (JSON, single/double quoted, escaped)
 * - Query parameters from URL
 */

export function parseCurl(curlCommand) {
  const result = {
    method: 'GET',
    url: '',
    headers: [],
    body: '',
    parameters: [],
    error: null,
  };

  try {
    // Normalize: line continuations (\) and collapse newlines to space
    let curl = curlCommand
      .trim()
      .replace(/\\\r?\n\s*/g, ' ')
      .replace(/\r?\n/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (!curl.toLowerCase().startsWith('curl')) {
      throw new Error('Not a valid cURL command');
    }

    // Strip leading "curl"
    curl = curl.replace(/^curl\s+/i, '').trim();

    // --- Method: -X POST or --request POST (explicit), or infer POST when --data/-d is used ---
    const methodMatch = curl.match(/(?:--request|-x)\s+([a-zA-Z]+)/i);
    if (methodMatch) {
      result.method = methodMatch[1].toUpperCase();
    } else if (/(?:--data-raw|--data|-d)\s+(?:'[^']*'|"[^"]*"|\S+)/i.test(curl)) {
      // cURL uses POST by default when -d/--data/--data-raw is present
      result.method = 'POST';
    }

    // --- URL: http(s)://... (quoted or unquoted) ---
    let url = '';
    const singleQuotedUrl = curl.match(/'(https?:\/\/[^']+)'/);
    const doubleQuotedUrl = curl.match(/"((?:https?:\/\/[^"]+))"/);
    const unquotedUrl = curl.match(/(https?:\/\/[^\s'"<>]+)/);
    if (singleQuotedUrl) url = singleQuotedUrl[1];
    else if (doubleQuotedUrl) url = doubleQuotedUrl[1];
    else if (unquotedUrl) url = unquotedUrl[1].replace(/\s+$/, '');
    if (!url) {
      throw new Error('No URL found in cURL command');
    }

    try {
      const urlObj = new URL(url);
      urlObj.searchParams.forEach((value, key) => {
        result.parameters.push({ key, value });
      });
      result.url = urlObj.origin + urlObj.pathname;
    } catch {
      result.url = url.split('?')[0] || url;
    }

    // --- Headers: -H "Key: Value" or -H 'Key: Value' or -H Key: Value ---
    const headerRegex = /(?:--header|-H)\s+(?:'([^']*)'|"((?:[^"\\]|\\.)*)"|([^\s-][^:]*(?:\s*:\s*[^\s-][^-]*)?))/gi;
    let headerMatch;
    while ((headerMatch = headerRegex.exec(curl)) !== null) {
      const raw = (headerMatch[1] ?? headerMatch[2] ?? headerMatch[3] ?? '').trim();
      if (!raw) continue;
      const colonIndex = raw.indexOf(':');
      if (colonIndex > 0) {
        const key = raw.substring(0, colonIndex).trim();
        const value = raw.substring(colonIndex + 1).trim();
        if (key) result.headers.push({ key, value });
      }
    }

    // --- Body: -d / --data / --data-raw (quoted string or unquoted token) ---
    const dataMatch = curl.match(
      /(?:--data-raw|--data|-d)\s+(?:'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)"|(\S+))/i
    );
    if (dataMatch) {
      let bodyData =
        dataMatch[1] !== undefined
          ? dataMatch[1].replace(/\\'/g, "'")
          : dataMatch[2] !== undefined
            ? dataMatch[2].replace(/\\"/g, '"')
            : (dataMatch[3] || '').trim();
      if (bodyData) {
        try {
          const parsed = JSON.parse(bodyData);
          result.body = JSON.stringify(parsed, null, 2);
        } catch {
          result.body = bodyData;
        }
      }
    }

    // If POST/PUT/PATCH and no body yet, check for empty body like -d '{}' or -d ""
    if (['POST', 'PUT', 'PATCH'].includes(result.method) && !result.body) {
      const emptyBodyMatch = curl.match(/(?:--data-raw|--data|-d)\s*$/i);
      if (emptyBodyMatch || curl.includes("-d ''") || curl.includes('-d ""')) {
        result.body = '{}';
      }
    }

    // Form data -F
    const formRegex = /(?:--form|-F)\s+'([^']*)'|(?:--form|-F)\s+"([^"]*)"|(?:--form|-F)\s+([^\s-][^\s]*)/gi;
    let formMatch;
    while ((formMatch = formRegex.exec(curl)) !== null) {
      const formStr = (formMatch[1] ?? formMatch[2] ?? formMatch[3] ?? '').trim();
      const eq = formStr.indexOf('=');
      if (eq > 0) {
        result.parameters.push({
          key: formStr.substring(0, eq).trim(),
          value: formStr.substring(eq + 1).trim(),
        });
      }
    }

    return result;
  } catch (error) {
    result.error = error.message || 'Failed to parse cURL command';
    return result;
  }
}

export function formatHeaders(headers) {
  return headers.map((h) => `${h.key}: ${h.value}`).join('\n');
}
