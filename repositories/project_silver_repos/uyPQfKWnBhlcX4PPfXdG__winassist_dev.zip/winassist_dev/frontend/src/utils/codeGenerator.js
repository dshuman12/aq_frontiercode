/**
 * Code Generator for Flow Diagrams
 * Converts flow nodes and connections into executable JavaScript code
 */

/**
 * Generates JavaScript code from flow nodes and connections
 * @param {Array} nodes - Array of flow nodes
 * @param {Array} connections - Array of edge connections
 * @returns {string} Generated JavaScript code
 */
export function generateJavaScriptCode(nodes, connections) {
  if (!nodes || nodes.length === 0) {
    return '// No nodes to generate code from\n';
  }

  // Debug: Log what we receive
  undefined
  undefined
  undefined
  undefined
  
  // CRITICAL: Verify each node's ID
  nodes.forEach((node, index) => {
    undefined
    if (node.id && node.id.includes('_')) {
      undefined
    } else {
      console.error(`  ✗ Node has base ID (missing suffix): ${node.id}`);
    }
  });
  
  // Check for ID mismatches
  const nodeIds = new Set(nodes.map(n => n.id));
  const connectionFromIds = new Set(connections.map(c => c.from || c.source).filter(Boolean));
  const connectionToIds = new Set(connections.map(c => c.to || c.target).filter(Boolean));
  const missingFromIds = [...connectionFromIds].filter(id => !nodeIds.has(id));
  const missingToIds = [...connectionToIds].filter(id => !nodeIds.has(id));
  
  if (missingFromIds.length > 0 || missingToIds.length > 0) {
    console.error('=== ID MISMATCH DETECTED ===');
    console.error('Connection "from" IDs that dont match any node:', missingFromIds);
    console.error('Connection "to" IDs that dont match any node:', missingToIds);
    console.error('Available node IDs:', [...nodeIds]);
  }

  const nodeMap = new Map(nodes.map(node => [node.id, node]));
  const adjacencyList = buildAdjacencyList(nodes, connections);
  const entryPoints = findEntryPoints(nodes, connections);
  
  undefined

  let code = generateHeader();
  code += generateNodeFunctions(nodes, nodeMap);
  code += generateFlowExecution(entryPoints, nodes, connections);
  code += generateNodeTraversal(nodes, connections);
  code += generateExports();

  return code;
}

/**
 * Builds adjacency list from connections
 */
function buildAdjacencyList(nodes, connections) {
  const adjacencyList = new Map();
  nodes.forEach(node => adjacencyList.set(node.id, []));
  
  connections.forEach(conn => {
    if (adjacencyList.has(conn.source || conn.from)) {
      adjacencyList.get(conn.source || conn.from).push(conn.target || conn.to);
    }
  });
  
  return adjacencyList;
}

/**
 * Finds entry points (nodes with no incoming connections or initializer nodes)
 */
function findEntryPoints(nodes, connections) {
  const hasIncoming = new Set();
  connections.forEach(conn => {
    hasIncoming.add(conn.target || conn.to);
  });

  const initializerNodes = nodes.filter(node => node.type === 'initializer');
  
  if (initializerNodes.length > 0) {
    return initializerNodes;
  }
  
  return nodes.filter(node => !hasIncoming.has(node.id));
}

/**
 * Generates code header with safety checks
 */
function generateHeader() {
  return `// Flow code generated from diagram

// Prevent execution in Windows Script Host
if (typeof WScript !== 'undefined') {
  WScript.Echo('This script is designed for browser or Node.js. Please use it in an HTML page or Node.js environment.');
  WScript.Quit();
}

function ensureFlowVars(context) {
  if (!context.vars || typeof context.vars !== 'object') context.vars = {};
  if (!context.vars.user || typeof context.vars.user !== 'object') context.vars.user = {};
  if (!context.vars.bot || typeof context.vars.bot !== 'object') context.vars.bot = {};
  if (!context.vars.api || typeof context.vars.api !== 'object') context.vars.api = {};
  if (!context.vars.flow || typeof context.vars.flow !== 'object') context.vars.flow = {};
  if (!Array.isArray(context.varEvents)) context.varEvents = [];
  return context.vars;
}

function storeFlowVariable(context, namespace, key, value, mode = 'replace', meta = {}) {
  if (!key) return;
  const vars = ensureFlowVars(context);
  const ns = String(namespace || 'flow').trim();
  if (!vars[ns] || typeof vars[ns] !== 'object') vars[ns] = {};
  if (mode === 'append') {
    if (!Array.isArray(vars[ns][key])) vars[ns][key] = [];
    vars[ns][key].push(value);
  } else if (mode === 'first_write') {
    if (vars[ns][key] === undefined) vars[ns][key] = value;
  } else {
    vars[ns][key] = value;
  }
  context.varEvents.push({
    ts: new Date().toISOString(),
    namespace: ns,
    key,
    mode,
    value,
    node_id: meta.node_id || null,
    node_type: meta.node_type || null,
    node_label: meta.node_label || null,
  });
}

function buildAssistantContext(context, config = {}) {
  const vars = ensureFlowVars(context);
  const includeAllUserVars = config.includeAllUserVars !== false;
  const keys = Array.isArray(config.contextKeys) ? config.contextKeys : [];
  const selected = {};
  keys.forEach((rawKey) => {
    const key = String(rawKey || '').trim();
    if (!key) return;
    if (key.startsWith('vars.')) {
      const parts = key.split('.');
      let cursor = context;
      for (const part of parts) {
        if (cursor == null) { cursor = undefined; break; }
        cursor = cursor[part];
      }
      selected[key] = cursor;
      return;
    }
    selected[key] = context[key];
  });

  const base = {
    last_user_message: context.lastUserMessage || context.message || null,
    selected_option: context.selectedOption || null,
    selected_date: context.selectedDate || null,
    form_data: context.formData || null,
    vars: {
      user: includeAllUserVars ? vars.user : {},
      bot: vars.bot,
      api: vars.api,
      flow: vars.flow,
      selected,
    },
    recent_variable_events: Array.isArray(context.varEvents) ? context.varEvents.slice(-12) : [],
  };

  return JSON.stringify(base);
}

function getContextValue(context, rawPath) {
  if (!rawPath) return undefined;
  const normalized = String(rawPath)
    .trim()
    .replace(/\[(\d+)\]/g, '.$1');
  if (!normalized) return undefined;

  const path = normalized.startsWith('context.')
    ? normalized.slice('context.'.length)
    : normalized;

  if (!path || path === 'context') return context;

  const parts = path.split('.').filter(Boolean);

  const resolveFromRoot = (root, rootParts = []) => {
    let cursor = root;
    const chain = [...rootParts, ...parts];
    for (const part of chain) {
      if (cursor === null || cursor === undefined) return undefined;
      cursor = cursor[part];
    }
    return cursor;
  };

  // Primary resolution path: context.<path>
  const directValue = resolveFromRoot(context);
  if (directValue !== undefined) {
    return directValue;
  }

  // Fallback resolution: values may be stored under vars namespaces.
  // This supports templates like {{context.someKey}} when runtime stored
  // someKey under context.vars.user/bot/api/flow.
  const namespaceCandidates = ['user', 'bot', 'api', 'flow'];
  for (const namespace of namespaceCandidates) {
    const namespacedValue = resolveFromRoot(context, ['vars', namespace]);
    if (namespacedValue !== undefined) {
      return namespacedValue;
    }
  }

  return undefined;
}

function formatContextValue(value, options = {}) {
  if (value === null || value === undefined) return undefined;
  if (options.json) return JSON.stringify(value);
  if (typeof value === 'object') {
    return options.prettyObject
      ? JSON.stringify(value, null, 2)
      : JSON.stringify(value);
  }
  const text = String(value);
  return options.encode ? encodeURIComponent(text) : text;
}

function replaceContextTemplates(text, context, options = {}) {
  if (typeof text !== 'string') return text;
  // Be tolerant to minor brace typos from UI input:
  // supports {{context.key}}, {context.key}}, {{context.key}
  return text.replace(/\{\{?\s*context\.([^}]+?)\s*\}?\}/g, (match, varName) => {
    try {
      const value = getContextValue(context, varName);
      const rendered = formatContextValue(value, options);
      return rendered === undefined ? match : rendered;
    } catch (error) {
      return match;
    }
  });
}

function coerceContextReference(value, context) {
  if (typeof value !== 'string') return value;
  const trimmed = value.trim();
  if (!trimmed) return value;
  if (trimmed.startsWith('context.') || trimmed.startsWith('vars.')) {
    const resolved = getContextValue(context, trimmed);
    return resolved === undefined ? value : resolved;
  }
  return value;
}

function tokenizeCondition(expression) {
  const source = String(expression || '');
  const tokens = [];
  let index = 0;

  const isWhitespace = (char) => /\s/.test(char);
  const isIdentifierStart = (char) => /[A-Za-z_$]/.test(char);
  const isIdentifierPart = (char) => /[A-Za-z0-9_$.[\]]/.test(char);

  while (index < source.length) {
    const char = source[index];
    const threeChar = source.slice(index, index + 3);
    const twoChar = source.slice(index, index + 2);

    if (isWhitespace(char)) {
      index += 1;
      continue;
    }

    if (threeChar === '===' || threeChar === '!==') {
      tokens.push({ type: 'operator', value: threeChar });
      index += 3;
      continue;
    }

    if (['&&', '||', '==', '!=', '>=', '<='].includes(twoChar)) {
      tokens.push({ type: 'operator', value: twoChar });
      index += 2;
      continue;
    }

    if (['(', ')', '!', '>', '<'].includes(char)) {
      tokens.push({
        type: char === '(' || char === ')' ? 'paren' : 'operator',
        value: char,
      });
      index += 1;
      continue;
    }

    if (char === '"' || char === "'") {
      const quote = char;
      index += 1;
      let value = '';
      while (index < source.length) {
        const current = source[index];
        if (current === '\\\\' && index + 1 < source.length) {
          value += source[index + 1];
          index += 2;
          continue;
        }
        if (current === quote) {
          index += 1;
          break;
        }
        value += current;
        index += 1;
      }
      tokens.push({ type: 'string', value });
      continue;
    }

    if (/[0-9]/.test(char)) {
      let start = index;
      index += 1;
      while (index < source.length && /[0-9.]/.test(source[index])) {
        index += 1;
      }
      tokens.push({
        type: 'number',
        value: Number(source.slice(start, index)),
      });
      continue;
    }

    if (isIdentifierStart(char)) {
      let start = index;
      index += 1;
      while (index < source.length && isIdentifierPart(source[index])) {
        index += 1;
      }
      tokens.push({
        type: 'identifier',
        value: source.slice(start, index),
      });
      continue;
    }

    throw new Error('Unsupported token in condition: ' + char);
  }

  return tokens;
}

function safeEvaluateCondition(expression, context) {
  try {
    const tokens = tokenizeCondition(expression);
    if (!tokens.length) return false;
    let cursor = 0;

    const peek = () => tokens[cursor];
    const consume = (expected) => {
      const token = tokens[cursor];
      if (!token) throw new Error('Unexpected end of expression');
      if (expected && token.value !== expected) {
        throw new Error('Unexpected token: ' + token.value);
      }
      cursor += 1;
      return token;
    };

    const parsePrimary = () => {
      const token = peek();
      if (!token) throw new Error('Missing expression value');

      if (token.type === 'paren' && token.value === '(') {
        consume('(');
        const value = parseOr();
        consume(')');
        return value;
      }

      if (token.type === 'string' || token.type === 'number') {
        consume();
        return token.value;
      }

      if (token.type === 'identifier') {
        consume();
        if (token.value === 'true') return true;
        if (token.value === 'false') return false;
        if (token.value === 'null') return null;
        if (token.value === 'undefined') return undefined;
        return getContextValue(context, token.value);
      }

      throw new Error('Unsupported primary token');
    };

    const parseUnary = () => {
      if (peek() && peek().type === 'operator' && peek().value === '!') {
        consume('!');
        return !Boolean(parseUnary());
      }
      return parsePrimary();
    };

    const applyComparison = (left, operator, right) => {
      switch (operator) {
        case '===':
          return left === right;
        case '!==':
          return left !== right;
        case '==':
          return left == right;
        case '!=':
          return left != right;
        case '>':
          return left > right;
        case '>=':
          return left >= right;
        case '<':
          return left < right;
        case '<=':
          return left <= right;
        default:
          throw new Error('Unsupported comparison operator');
      }
    };

    const parseComparison = () => {
      let left = parseUnary();
      while (
        peek() &&
        peek().type === 'operator' &&
        ['===', '!==', '==', '!=', '>', '>=', '<', '<='].includes(peek().value)
      ) {
        const operator = consume().value;
        const right = parseUnary();
        left = applyComparison(left, operator, right);
      }
      return left;
    };

    const parseAnd = () => {
      let left = parseComparison();
      while (peek() && peek().type === 'operator' && peek().value === '&&') {
        consume('&&');
        left = Boolean(left) && Boolean(parseComparison());
      }
      return left;
    };

    const parseOr = () => {
      let left = parseAnd();
      while (peek() && peek().type === 'operator' && peek().value === '||') {
        consume('||');
        left = Boolean(left) || Boolean(parseAnd());
      }
      return left;
    };

    const result = parseOr();
    if (cursor < tokens.length) {
      throw new Error('Unexpected trailing tokens');
    }
    return Boolean(result);
  } catch (error) {
    return false;
  }
}

`;
}

/**
 * Generates function definitions for all nodes
 */
function generateNodeFunctions(nodes, nodeMap) {
  let code = '// Node definitions\n';
  
  nodes.forEach(node => {
    // Use full node ID (with suffix) to ensure unique function names
    // e.g., "text_Ypzj5s" -> "text_Ypzj5s" (not just "text")
    const nodeName = sanitizeNodeId(node.id);
    code += `async function ${nodeName}(context) {\n`;
    code += `  // ${node.label || node.data?.label || 'Node'} (${node.type})\n`;
    code += generateNodeLogic(node);
    code += `  return context;\n`;
    code += `}\n\n`;
  });
  
  return code;
}

/**
 * Generates logic for a specific node type
 */
function generateNodeLogic(node) {
  switch (node.type) {
    case 'text':
      return generateTextNode(node);
    case 'image':
      return generateImageNode(node);
    case 'api':
      return generateApiNode(node);
    case 'input':
      return generateInputNode(node);
    case 'calendar':
      return generateCalendarNode(node);
    case 'form':
      return generateFormNode(node);
    case 'document':
      return generateDocumentNode(node);
    case 'ocr':
      return generateOcrNode(node);
    case 'quickreply':
    case 'container':
      return generateQuickReplyNode(node);
    case 'condition':
      return generateConditionNode(node);
    case 'delay':
      return generateDelayNode(node);
    case 'assistant':
      return generateAssistantNode(node);
    case 'initializer':
      return generateInitializerNode(node);
    case 'user':
      return generateUserNode(node);
    case 'note':
      return generateNoteNode(node);
    case 'branch':
      return generateBranchNode(node);
    case 'switch':
      return generateSwitchNode(node);
    case 'merge':
      return generateMergeNode(node);
    default:
      return '  // Node logic here\n';
  }
}

/**
 * Generates text node logic with context variable substitution
 */
function generateTextNode(node) {
  const textContent = node.text || node.data?.text || '';
  const storeAs = (node.data?.storeAs || node.storeAs || `text_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'bot').trim() || 'bot';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';
  const escapedText = JSON.stringify(textContent);
  const nodeLabel = node.data?.label || node.label || (typeof textContent === 'string' ? textContent.slice(0, 50) : 'Text') + (textContent && textContent.length > 50 ? '...' : '');

  let code = `  let messageText = ${escapedText};\n`;
  code += `  messageText = replaceContextTemplates(messageText, context, { prettyObject: true });\n`;
  code += `  var _fmt = (typeof WIDGET_UI_SETTINGS === 'object' && WIDGET_UI_SETTINGS) ? WIDGET_UI_SETTINGS : {};\n`;
  code += `  if (_fmt.enableAutoFormatting !== false) {\n`;
  code += `    messageText = String(messageText == null ? '' : messageText)\n`;
  code += `      .replace(/\\r\\n?/g, '\\n')\n`;
  code += `      .replace(/\\uFFFD/g, "'")\n`;
  code += `      .replace(/\\b(Ingredients|Instructions|Steps|Method|Directions)\\s*:\\s*/gi, '$1:\\n')\n`;
  code += `      .replace(/([^\\n])\\s+(\\d+\\.\\s+)/g, '$1\\n$2')\n`;
  code += `      .replace(/([^\\n])\\s+([\\-\\*\\u2022]\\s+)/g, '$1\\n$2')\n`;
  code += `      .replace(/\\n{3,}/g, '\\n\\n')\n`;
  code += `      .trim();\n`;
  code += `  }\n`;
  code += `  context.botMessage = messageText;\n`;
  code += `  if (typeof window !== 'undefined' && window.displayBotMessage) {\n`;
  code += `    window.displayBotMessage(messageText);\n`;
  code += `  }\n`;
  code += `  if (typeof window !== 'undefined' && window.reportFlowMessage) {\n`;
  code += `    window.reportFlowMessage('assistant', messageText, ${JSON.stringify(node.id)}, ${JSON.stringify(nodeLabel)});\n`;
  code += `  }\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, messageText, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'text', node_label: ${JSON.stringify(nodeLabel)} });\n`;

  return code;
}

/**
 * Generates image node logic with context variable substitution.
 * Renders an <img> bubble in the widget UI.
 */
function generateImageNode(node) {
  const storeAs = (node.data?.storeAs || node.storeAs || `image_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'bot').trim() || 'bot';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';
  const imageUrlContent = node.imageUrl || node.data?.imageUrl || node.url || node.data?.url || '';
  const altTextContent = node.altText || node.data?.altText || node.alt || node.data?.alt || '';
  const captionContent = node.caption || node.data?.caption || '';

  const escapedImageUrl = JSON.stringify(imageUrlContent);
  const escapedAltText = JSON.stringify(altTextContent);
  const escapedCaption = JSON.stringify(captionContent);

  const nodeLabel =
    node.data?.label ||
    node.label ||
    (typeof captionContent === 'string' && captionContent
      ? captionContent.slice(0, 50)
      : (imageUrlContent ? String(imageUrlContent).slice(0, 50) : 'Image')) +
      ((captionContent && captionContent.length > 50) || (imageUrlContent && String(imageUrlContent).length > 50) ? '...' : '');

  let code = `  let imageUrl = ${escapedImageUrl};\n`;
  code += `  imageUrl = replaceContextTemplates(imageUrl, context);\n`;

  code += `  let altText = ${escapedAltText};\n`;
  code += `  altText = replaceContextTemplates(altText, context);\n`;

  code += `  let captionText = ${escapedCaption};\n`;
  code += `  captionText = replaceContextTemplates(captionText, context);\n`;

  code += `  const reportText = (captionText && captionText.trim()) ? captionText : (altText || imageUrl);\n`;
  code += `  context.botMessage = reportText;\n`;
  code += `  if (typeof window !== 'undefined' && window.displayBotImage) {\n`;
  code += `    window.displayBotImage(imageUrl, altText, captionText);\n`;
  code += `  } else if (typeof window !== 'undefined' && window.displayBotMessage) {\n`;
  code += `    window.displayBotMessage(reportText);\n`;
  code += `  }\n`;
  code += `  if (typeof window !== 'undefined' && window.reportFlowMessage) {\n`;
  code += `    window.reportFlowMessage('assistant', reportText, ${JSON.stringify(node.id)}, ${JSON.stringify(nodeLabel)});\n`;
  code += `  }\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, { imageUrl, altText, captionText, reportText }, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'image', node_label: ${JSON.stringify(nodeLabel)} });\n`;

  return code;
}

/**
 * Generates API node logic with retry support
 */
function generateApiNode(node) {
  const apiUrl = node.data?.apiUrl || node.apiUrl || '';
  const apiMethod = node.data?.apiMethod || node.apiMethod || 'GET';
  const parameters = node.data?.parameters || node.parameters || [];
  const headers = node.data?.headers || node.headers || [];
  const body = node.data?.body || node.body || '';
  const bodyMode = node.data?.bodyMode || node.bodyMode || '';
  const formData = node.data?.formData || node.formData || [];
  const fileBody = node.data?.fileBody || node.fileBody || '';
  const enableRetry = node.data?.enableRetry || node.enableRetry || false;
  const retryCount = enableRetry ? (node.data?.retryCount || node.retryCount || 3) : 1;
  const responseTransform = node.data?.responseTransform || node.responseTransform;
  const responseVariable = node.data?.responseVariable || node.responseVariable || '';
  const apiStoreKey = (responseVariable && responseVariable.trim()) ? responseVariable.trim() : `api_${node.id}`;

  let code = `  // API node: ${apiMethod} ${apiUrl}\n`;
  code += `  const apiParams = ${JSON.stringify(parameters)};\n`;
  code += `  let apiUrl = ${JSON.stringify(apiUrl)};\n`;
  code += `  const runtimeApiBase = (context && typeof context.apiUrl === 'string') ? String(context.apiUrl).replace(/\\/$/, '') : '';\n`;
  code += `  if (runtimeApiBase && apiUrl.includes('__BACKEND_API_URL__')) {\n`;
  code += `    apiUrl = apiUrl.replace(/__BACKEND_API_URL__/g, runtimeApiBase);\n`;
  code += `  }\n`;
  code += `  apiUrl = replaceContextTemplates(apiUrl, context, { encode: true });\n`;
  code += `  const apiMethod = '${apiMethod}';\n`;
  code += `  const apiHeaders = { 'Content-Type': 'application/json' };\n`;
  code += `  (${JSON.stringify(headers)}).forEach(h => {\n`;
  code += `    if (h && h.key) {\n`;
  code += `      let v = (h.value != null && h.value !== undefined) ? String(h.value) : '';\n`;
  code += `      v = replaceContextTemplates(v, context);\n`;
  code += `      apiHeaders[h.key] = v;\n`;
  code += `    }\n`;
  code += `  });\n`;
  code += `  const requestOptions = { method: apiMethod, headers: apiHeaders };\n`;
  code += `  let fullUrl = apiUrl;\n`;
  
  // Handle request body (POST, PUT, PATCH, DELETE)
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(apiMethod)) {
    const hasBody = body && body.trim() !== '';
    if (bodyMode === 'formdata') {
      code += generateApiFormData(formData);
    } else if (bodyMode === 'file') {
      code += generateApiFileBody(fileBody);
    } else if (hasBody) {
      code += generateApiBodyWithContext(body);
    } else if (bodyMode === 'none') {
      code += `    delete requestOptions.body;\n`;
    } else {
      code += generateApiBodyFromParams(parameters);
    }
  } else {
    code += generateApiQueryParams(apiUrl, parameters);
  }
  
  // Retry logic
  code += `  let lastError = null;\n`;
  code += `  for (let attempt = 1; attempt <= ${retryCount}; attempt++) {\n`;
  code += `    try {\n`;
  code += `      const response = await fetch(fullUrl, requestOptions);\n`;
  code += `      context.apiStatus = response.status;\n`;
  code += `      const contentType = response.headers.get('content-type') || '';\n`;
  code += `      let responseData = contentType.includes('application/json') ? await response.json() : await response.text();\n`;
  
  if (responseTransform) {
    code += `      try {\n`;
    code += `        const response = responseData;\n`;
    code += `        responseData = ${responseTransform};\n`;
    code += `      } catch (e) {}\n`;
  }
  
  code += `      // Store response in context (latest - for backward compatibility)\n`;
  code += `      context.apiResponse = responseData;\n`;
  code += `      storeFlowVariable(context, 'api', ${JSON.stringify(apiStoreKey)}, responseData, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'api', node_label: ${JSON.stringify(node.data?.label || node.label || 'API')} });\n`;
  
  // Store in named variable if specified
  if (responseVariable && responseVariable.trim()) {
    const varName = responseVariable.trim();
    code += `      // Store response in named variable: ${varName}\n`;
    code += `      context.${varName} = responseData;\n`;
  }
  
  code += `      // Initialize apiResponses array if it doesn't exist (for backward compatibility)\n`;
  code += `      if (!context.apiResponses) {\n`;
  code += `        context.apiResponses = [];\n`;
  code += `      }\n`;
  code += `      // Store response in array with metadata for history access\n`;
  code += `      context.apiResponses.push({\n`;
  code += `        index: context.apiResponses.length,\n`;
  code += `        url: fullUrl,\n`;
  code += `        method: apiMethod,\n`;
  code += `        status: response.status,\n`;
  code += `        response: responseData,\n`;
  code += `        timestamp: new Date().toISOString()\n`;
  code += `      });\n`;
  code += `      // Also store latest response index for easy access\n`;
  code += `      context.apiResponseIndex = context.apiResponses.length - 1;\n`;
  code += `      if (!response.ok) {\n`;
  code += `        context.apiError = 'HTTP ' + response.status + ': ' + (responseData?.message || responseData || 'Request failed');\n`;
  
  if (retryCount > 1) {
    code += `        if (attempt < ${retryCount}) {\n`;
    code += `          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));\n`;
    code += `          continue;\n`;
    code += `        }\n`;
  }
  
  code += `      } else {\n`;
  code += `        lastError = null;\n`;
  code += `        break;\n`;
  code += `      }\n`;
  code += `    } catch (error) {\n`;
  code += `      lastError = error;\n`;
  
  if (retryCount > 1) {
    code += `      if (attempt < ${retryCount}) {\n`;
    code += `        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));\n`;
    code += `        continue;\n`;
    code += `      }\n`;
  }
  
  code += `    }\n`;
  code += `  }\n`;
  code += `  if (lastError) {\n`;
  code += `    context.apiError = lastError.message;\n`;
  code += `  }\n`;
  
  return code;
}

/**
 * Generates API body with context substitution
 */
function generateApiBodyWithContext(body) {
  let code = `    let bodyText = ${JSON.stringify(body)};\n`;
  code += `    bodyText = replaceContextTemplates(bodyText, context, { json: true });\n`;
  code += `    try {\n`;
  code += `      const parsedBody = JSON.parse(bodyText);\n`;
  code += `      requestOptions.body = JSON.stringify(parsedBody);\n`;
  code += `    } catch (e) {\n`;
  code += `      requestOptions.body = bodyText;\n`;
  code += `    }\n`;
  return code;
}

function generateApiFormData(formDataEntries) {
  let code = `    const requestFormData = new FormData();\n`;
  code += `    (${JSON.stringify(formDataEntries || [])}).forEach((entry) => {\n`;
  code += `      if (!entry || !entry.key) return;\n`;
  code += `      let rawValue = (entry.value != null && entry.value !== undefined) ? String(entry.value) : '';\n`;
  code += `      const exactContextMatch = rawValue.match(/^\\{\\{context\\.([^}]+)\\}\\}$/);\n`;
  code += `      let resolvedValue = exactContextMatch ? getContextValue(context, exactContextMatch[1]) : replaceContextTemplates(rawValue, context);\n`;
  code += `      if (entry.type === 'file') {\n`;
  code += `        if (typeof File !== 'undefined' && resolvedValue instanceof File) {\n`;
  code += `          requestFormData.append(entry.key, resolvedValue);\n`;
  code += `          return;\n`;
  code += `        }\n`;
  code += `        if (typeof Blob !== 'undefined' && resolvedValue instanceof Blob) {\n`;
  code += `          requestFormData.append(entry.key, resolvedValue, entry.key);\n`;
  code += `          return;\n`;
  code += `        }\n`;
  code += `      }\n`;
  code += `      if (resolvedValue == null) {\n`;
  code += `        resolvedValue = '';\n`;
  code += `      } else if (typeof resolvedValue === 'object' && !(typeof Blob !== 'undefined' && resolvedValue instanceof Blob) && !(typeof File !== 'undefined' && resolvedValue instanceof File)) {\n`;
  code += `        resolvedValue = JSON.stringify(resolvedValue);\n`;
  code += `      }\n`;
  code += `      requestFormData.append(entry.key, resolvedValue);\n`;
  code += `    });\n`;
  code += `    requestOptions.body = requestFormData;\n`;
  code += `    if (requestOptions.headers) {\n`;
  code += `      delete requestOptions.headers['Content-Type'];\n`;
  code += `    }\n`;
  return code;
}

function generateApiFileBody(fileBody) {
  let code = `    let binaryBody = ${JSON.stringify(fileBody || '')};\n`;
  code += `    const exactContextMatch = String(binaryBody).match(/^\\{\\{context\\.([^}]+)\\}\\}$/);\n`;
  code += `    binaryBody = exactContextMatch ? getContextValue(context, exactContextMatch[1]) : replaceContextTemplates(String(binaryBody), context);\n`;
  code += `    if (binaryBody != null) {\n`;
  code += `      requestOptions.body = binaryBody;\n`;
  code += `    }\n`;
  code += `    if (requestOptions.headers && requestOptions.headers['Content-Type'] === 'application/json') {\n`;
  code += `      delete requestOptions.headers['Content-Type'];\n`;
  code += `    }\n`;
  return code;
}

/**
 * Generates API body from parameters
 */
function generateApiBodyFromParams(parameters) {
  let code = `    // Build body from parameters\n`;
  code += `    const body = {};\n`;
  code += `    apiParams.forEach(param => {\n`;
  code += `      if (param.key) {\n`;
  code += `        let paramValue = param.value || context[param.key] || '';\n`;
  code += `        if (typeof paramValue === 'string') {\n`;
  code += `          paramValue = replaceContextTemplates(paramValue, context, { prettyObject: false });\n`;
  code += `          paramValue = coerceContextReference(paramValue, context);\n`;
  code += `        }\n`;
  code += `        body[param.key] = paramValue;\n`;
  code += `      }\n`;
  code += `    });\n`;
  code += `    requestOptions.body = JSON.stringify(body);\n`;
  return code;
}

/**
 * Generates API query parameters (for GET etc. - no request body).
 * Emits a standalone block; no leading "} else {" so the generated script has valid syntax.
 */
function generateApiQueryParams(apiUrl, parameters) {
  let code = `  const urlParts = apiUrl.split('?');\n`;
  code += `  const baseUrl = urlParts[0];\n`;
  code += `  const queryParams = new URLSearchParams(urlParts[1] || '');\n`;
  code += `  apiParams.forEach(param => {\n`;
  code += `    if (param.key) {\n`;
  code += `      let paramValue = param.value || context[param.key] || '';\n`;
  code += `      if (typeof paramValue === 'string') {\n`;
  code += `        paramValue = replaceContextTemplates(paramValue, context);\n`;
  code += `        paramValue = coerceContextReference(paramValue, context);\n`;
  code += `      }\n`;
  code += `      queryParams.set(param.key, paramValue);\n`;
  code += `    }\n`;
  code += `  });\n`;
  code += `  const queryString = queryParams.toString();\n`;
  code += `  fullUrl = queryString ? baseUrl + '?' + queryString : baseUrl;\n`;
  return code;
}

/**
 * Generates input node logic
 */
function generateInputNode(node) {
  const variableName = node.data?.variableName || node.variableName || 'userInput';
  const prompt = node.data?.prompt || node.prompt || 'Enter input:';
  const storeAs = (node.data?.storeAs || node.storeAs || variableName || `input_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'user').trim() || 'user';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';
  const nodeLabel = node.data?.label || node.label || node.data?.prompt || node.prompt || 'User input';

  let code = `  if (typeof window !== 'undefined' && window.waitForUserInput) {\n`;
  code += `    if (window._currentInputNodeId !== undefined) { window._currentInputNodeId = ${JSON.stringify(node.id)}; window._currentInputNodeLabel = ${JSON.stringify(nodeLabel)}; }\n`;
  code += `    context.${variableName} = await window.waitForUserInput(${JSON.stringify(prompt)});\n`;
  code += `  } else {\n`;
  code += `    const userInput = prompt(${JSON.stringify(prompt)});\n`;
  code += `    context.${variableName} = userInput !== null ? userInput : null;\n`;
  code += `  }\n`;
  code += `  context.message = context.${variableName};\n`;
  code += `  context.lastUserMessage = context.${variableName};\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, context.${variableName}, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'input', node_label: ${JSON.stringify(nodeLabel)} });\n`;

  return code;
}

/**
 * Generates calendar node logic
 */
function generateCalendarNode(node) {
  const storeAs = (node.data?.storeAs || node.storeAs || variableName || `calendar_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'user').trim() || 'user';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';
  const variableName = (node.data?.variableName || node.variableName || 'selectedDate').trim() || 'selectedDate';
  const prompt = node.data?.prompt || node.prompt || 'Select a date';
  const selectionType = node.data?.selectionType === 'datetime' ? 'datetime' : 'date';
  const minDate = node.data?.minDate || node.minDate || '';
  const maxDate = node.data?.maxDate || node.maxDate || '';
  const rawCalendarOptions = Array.isArray(node.data?.calendarOptions)
    ? node.data.calendarOptions
    : (Array.isArray(node.calendarOptions) ? node.calendarOptions : []);
  const dateOptions = Array.isArray(rawCalendarOptions)
    ? rawCalendarOptions
        .map((option) => (typeof option === 'string' ? option : option?.value))
        .filter(Boolean)
    : [];
  const confirmLabel = node.data?.confirmLabel || node.confirmLabel || 'Confirm';
  const nodeLabel = node.data?.label || node.label || 'Calendar';

  let code = `  if (typeof window !== 'undefined' && window.waitForCalendarInput) {\n`;
  code += `    if (window._currentInputNodeId !== undefined) { window._currentInputNodeId = ${JSON.stringify(node.id)}; window._currentInputNodeLabel = ${JSON.stringify(nodeLabel)}; }\n`;
  code += `    context.${variableName} = await window.waitForCalendarInput({\n`;
  code += `      prompt: ${JSON.stringify(prompt)},\n`;
  code += `      selectionType: ${JSON.stringify(selectionType)},\n`;
  code += `      minDate: ${JSON.stringify(minDate)},\n`;
  code += `      maxDate: ${JSON.stringify(maxDate)},\n`;
  code += `      dateOptions: ${JSON.stringify(dateOptions)},\n`;
  code += `      confirmLabel: ${JSON.stringify(confirmLabel)}\n`;
  code += `    });\n`;
  code += `  } else {\n`;
  code += `    const fallbackPrompt = ${JSON.stringify(prompt)} + (${JSON.stringify(selectionType)} === 'datetime' ? ' (YYYY-MM-DDTHH:mm)' : ' (YYYY-MM-DD)');\n`;
  code += `    const userInput = prompt(fallbackPrompt);\n`;
  code += `    context.${variableName} = userInput !== null ? userInput : null;\n`;
  code += `  }\n`;
  code += `  context.selectedDate = context.${variableName};\n`;
  code += `  context.message = context.${variableName};\n`;
  code += `  context.lastUserMessage = context.${variableName};\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, context.${variableName}, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'calendar', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  return code;
}

/**
 * Generates generalized form node logic
 */
function generateFormNode(node) {
  const variableName = (node.data?.variableName || node.variableName || 'formData').trim() || 'formData';
  const prompt = node.data?.prompt || node.prompt || 'Please fill details';
  const submitLabel = node.data?.submitLabel || node.submitLabel || 'Continue';
  const fields = Array.isArray(node.data?.fields || node.fields) ? (node.data?.fields || node.fields) : [];
  const nodeLabel = node.data?.label || node.label || 'Form';
  const storeAs = (node.data?.storeAs || node.storeAs || variableName || `form_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'user').trim() || 'user';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';

  let code = `  if (typeof window !== 'undefined') { window._currentInputNodeId = ${JSON.stringify(node.id)}; window._currentInputNodeLabel = ${JSON.stringify(nodeLabel)}; }\n`;
  code += `  if (typeof window !== 'undefined' && window.collectFormInput) {\n`;
  code += `    context.${variableName} = await window.collectFormInput({\n`;
  code += `      prompt: ${JSON.stringify(prompt)},\n`;
  code += `      submitLabel: ${JSON.stringify(submitLabel)},\n`;
  code += `      fields: ${JSON.stringify(fields)},\n`;
  code += `      context: context\n`;
  code += `    });\n`;
  code += `  } else {\n`;
  code += `    context.${variableName} = {};\n`;
  code += `  }\n`;
  code += `  context.lastFormData = context.${variableName};\n`;
  code += `  if (context.formData === undefined && ${JSON.stringify(variableName)} === 'formData') {\n`;
  code += `    context.formData = context.${variableName};\n`;
  code += `  }\n`;
  code += `  context.lastFormNodeId = ${JSON.stringify(node.id)};\n`;
  code += `  context.lastUserMessage = JSON.stringify(context.${variableName} || {});\n`;
  code += `  context.message = context.lastUserMessage;\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, context.${variableName}, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'form', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  return code;
}

/**
 * Generates document upload node logic
 */
function generateDocumentNode(node) {
  const variableName = (node.data?.variableName || node.variableName || 'uploadedDocument').trim() || 'uploadedDocument';
  const prompt = node.data?.prompt || node.prompt || 'Please upload your document';
  const accept = node.data?.accept || node.accept || '*/*';
  const maxSizeMb = Number(node.data?.maxSizeMb || node.maxSizeMb || 10);
  const nodeLabel = node.data?.label || node.label || 'Document Upload';
  const storeAs = (node.data?.storeAs || node.storeAs || variableName || `document_${node.id}`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'user').trim() || 'user';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';

  let code = `  let _documentValue = null;\n`;
  code += `  if (typeof window !== 'undefined' && window.waitForDocumentInput) {\n`;
  code += `    if (window._currentInputNodeId !== undefined) { window._currentInputNodeId = ${JSON.stringify(node.id)}; window._currentInputNodeLabel = ${JSON.stringify(nodeLabel)}; }\n`;
  code += `    _documentValue = await window.waitForDocumentInput({\n`;
  code += `      prompt: ${JSON.stringify(prompt)},\n`;
  code += `      accept: ${JSON.stringify(accept)},\n`;
  code += `      maxSizeMb: ${Number.isFinite(maxSizeMb) ? maxSizeMb : 10}\n`;
  code += `    });\n`;
  code += `  } else {\n`;
  code += `    _documentValue = null;\n`;
  code += `  }\n`;
  code += `  context[${JSON.stringify(variableName)}] = _documentValue;\n`;
  code += `  context[${JSON.stringify(storeAs)}] = _documentValue;\n`;
  code += `  ensureFlowVars(context);\n`;
  code += `  if (context.vars && context.vars.user) {\n`;
  code += `    context.vars.user[${JSON.stringify(variableName)}] = _documentValue;\n`;
  code += `    context.vars.user[${JSON.stringify(storeAs)}] = _documentValue;\n`;
  code += `  }\n`;
  code += `  context.lastDocument = _documentValue;\n`;
  code += `  context.message = _documentValue ? (_documentValue.name || 'Document uploaded') : null;\n`;
  code += `  context.lastUserMessage = context.message;\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(storeAs)}, _documentValue, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: 'document', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  return code;
}

/**
 * Generates OCR extraction node logic
 */
function generateOcrNode(node) {
  const sourceVariable = (node.data?.sourceVariable || node.sourceVariable || 'lastDocument').trim() || 'lastDocument';
  const outputVariable = (node.data?.outputVariable || node.outputVariable || 'ocrResult').trim() || 'ocrResult';
  const documentType = (node.data?.documentType || node.documentType || 'auto').trim() || 'auto';
  const processingMessage = node.data?.processingMessage || node.processingMessage || 'Processing your uploaded document...';
  const successMessage = node.data?.successMessage || node.successMessage || 'Document details extracted successfully.';
  const nodeLabel = node.data?.label || node.label || 'OCR Extract';

  let code = `  let _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {} };\n`;
  code += `  const _ocrSource = getContextValue(context, ${JSON.stringify(sourceVariable)}) ?? context[${JSON.stringify(sourceVariable)}] ?? context.lastDocument ?? null;\n`;
  code += `  if (!_ocrSource || typeof _ocrSource !== 'object') {\n`;
  code += `    _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: 'No uploaded document found in context.' };\n`;
  code += `  } else if (!_ocrSource.contentBase64) {\n`;
  code += `    _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: 'Selected source variable does not contain an uploaded file payload.' };\n`;
  code += `  } else if (!(typeof _apiUrl === 'string' && _apiUrl)) {\n`;
  code += `    _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: 'Backend API URL is not configured for OCR.' };\n`;
  code += `  } else if (!(typeof _apiKey === 'string' && _apiKey)) {\n`;
  code += `    _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: 'Bot API key is not configured for OCR.' };\n`;
  code += `  } else {\n`;
  code += `    if (typeof addMessage === 'function') {\n`;
  code += `      addMessage(${JSON.stringify(processingMessage)}, 'bot');\n`;
  code += `      if (typeof window.reportFlowMessage === 'function') {\n`;
  code += `        window.reportFlowMessage('assistant', ${JSON.stringify(processingMessage)}, ${JSON.stringify(node.id)}, ${JSON.stringify(nodeLabel)});\n`;
  code += `      }\n`;
  code += `    }\n`;
  code += `    try {\n`;
  code += `      const _ocrResponse = await fetch((_apiUrl || '') + '/ocr/extract', {\n`;
  code += `        method: 'POST',\n`;
  code += `        headers: {\n`;
  code += `          'Content-Type': 'application/json',\n`;
  code += `          'X-Bot-API-Key': _apiKey\n`;
  code += `        },\n`;
  code += `        body: JSON.stringify({\n`;
  code += `          document_type: ${JSON.stringify(documentType)},\n`;
  code += `          filename: _ocrSource.name || '',\n`;
  code += `          mime_type: _ocrSource.type || '',\n`;
  code += `          content_base64: _ocrSource.contentBase64 || ''\n`;
  code += `        })\n`;
  code += `      });\n`;
  code += `      let _ocrPayload = {};\n`;
  code += `      try {\n`;
  code += `        _ocrPayload = await _ocrResponse.json();\n`;
  code += `      } catch (error) {\n`;
  code += `        _ocrPayload = { detail: 'OCR endpoint returned an invalid response.' };\n`;
  code += `      }\n`;
  code += `      if (!_ocrResponse.ok) {\n`;
  code += `        _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: _ocrPayload.detail || 'OCR request failed.' };\n`;
  code += `      } else {\n`;
  code += `        _ocrResult = _ocrPayload && typeof _ocrPayload === 'object' ? _ocrPayload : { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: 'OCR response was empty.' };\n`;
  code += `      }\n`;
  code += `    } catch (error) {\n`;
  code += `      _ocrResult = { ok: false, document_type: ${JSON.stringify(documentType)}, fields: {}, error: error && error.message ? error.message : 'OCR extraction failed.' };\n`;
  code += `    }\n`;
  code += `  }\n`;
  code += `  const _ocrFields = _ocrResult && typeof _ocrResult.fields === 'object' && _ocrResult.fields ? _ocrResult.fields : {};\n`;
  code += `  const _ocrEntries = Object.entries(_ocrFields).filter(([, value]) => value !== undefined && value !== null && String(value).trim() !== '');\n`;
  code += `  const _ocrLabel = function(key) {\n`;
  code += `    return String(key || '').replace(/_/g, ' ').replace(/\\b\\w/g, function(char) { return char.toUpperCase(); });\n`;
  code += `  };\n`;
  code += `  const _ocrDetails = _ocrEntries.map(function(entry) { return _ocrLabel(entry[0]) + ': ' + entry[1]; }).join('\\n');\n`;
  code += `  context[${JSON.stringify(outputVariable)}] = _ocrResult;\n`;
  code += `  context.lastOcrResult = _ocrResult;\n`;
  code += `  context.ocrSummary = _ocrDetails || '';\n`;
  code += `  ensureFlowVars(context);\n`;
  code += `  if (context.vars && context.vars.user) {\n`;
  code += `    context.vars.user[${JSON.stringify(outputVariable)}] = _ocrResult;\n`;
  code += `    context.vars.user.ocrSummary = context.ocrSummary;\n`;
  code += `  }\n`;
  code += `  storeFlowVariable(context, 'user', ${JSON.stringify(outputVariable)}, _ocrResult, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'ocr', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  code += `  storeFlowVariable(context, 'user', 'ocrSummary', context.ocrSummary, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'ocr', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  code += `  if (_ocrResult.ok && _ocrEntries.length > 0) {\n`;
  code += `    context.message = (${JSON.stringify(successMessage)} ? ${JSON.stringify(successMessage)} + '\\n\\n' : '') + _ocrDetails;\n`;
  code += `  } else {\n`;
  code += `    context.message = _ocrResult.error || 'OCR extraction failed.';\n`;
  code += `  }\n`;
  code += `  context.lastUserMessage = context.message;\n`;
  code += `  if (typeof addMessage === 'function') {\n`;
  code += `    addMessage(context.message, 'bot');\n`;
  code += `    if (typeof window.reportFlowMessage === 'function') {\n`;
  code += `      window.reportFlowMessage('assistant', context.message, ${JSON.stringify(node.id)}, ${JSON.stringify(nodeLabel)});\n`;
  code += `    }\n`;
  code += `  }\n`;
  return code;
}

/**
 * Generates quick reply/container node logic
 */
function generateQuickReplyNode(node) {
  const isQuickReplyContainer = node.message !== undefined || 
                                 node.data?.message !== undefined || 
                                 (node.type === 'container' && (node.message !== undefined || node.data?.message !== undefined));
  
  if (!isQuickReplyContainer && node.type !== 'quickreply') {
    return '';
  }

  const message = node.message || node.data?.message || '';
  const options = node.options || node.data?.options || [];
  const optionTexts = options.map(o => typeof o === 'string' ? o : (o.text || o.value || ''));
  const nodeLabel = node.data?.label || node.label || message || 'Quick reply';
  const variableKey = (node.data?.variableKey || node.data?.storeAs || '').trim() || `qr_${node.id}`;
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'user').trim() || 'user';
  const storeMode = (node.data?.storeMode || node.storeMode || 'replace').trim() || 'replace';

  let code = `  context.quickReplyMessage = ${JSON.stringify(message)};\n`;
  code += `  context.quickReplyOptions = ${JSON.stringify(optionTexts)};\n`;
  code += `  if (typeof window !== 'undefined') { window._currentInputNodeId = ${JSON.stringify(node.id)}; window._currentInputNodeLabel = ${JSON.stringify(nodeLabel)}; }\n`;
  code += `  if (typeof window !== 'undefined') { window._currentQuickReplyNodeId = ${JSON.stringify(node.id)}; window._currentQuickReplyNodeLabel = ${JSON.stringify(nodeLabel)}; window._currentQuickReplyVariableKey = ${JSON.stringify(variableKey)}; }\n`;
  code += `  if (typeof window !== 'undefined' && window.showQuickReplyOptions) {\n`;
  code += `    context.selectedOption = await window.showQuickReplyOptions(${JSON.stringify(message)}, ${JSON.stringify(optionTexts)});\n`;
  code += `  } else if (typeof window !== 'undefined' && window.waitForUserInput) {\n`;
  code += `    const optionsText = ${JSON.stringify(optionTexts)}.join(', ');\n`;
  code += `    const userInput = await window.waitForUserInput(${JSON.stringify(message)} + ' (Options: ' + optionsText + ')');\n`;
  code += `    const matchedOption = ${JSON.stringify(optionTexts)}.find(opt => opt.toLowerCase() === userInput.toLowerCase());\n`;
  code += `    context.selectedOption = matchedOption || userInput;\n`;
  code += `  } else {\n`;
  code += `    const optionsText = ${JSON.stringify(optionTexts)}.join(', ');\n`;
  code += `    const userInput = prompt(${JSON.stringify(message)} + ' (Options: ' + optionsText + ')');\n`;
  code += `    const matchedOption = ${JSON.stringify(optionTexts)}.find(opt => opt.toLowerCase() === (userInput || '').toLowerCase());\n`;
  code += `    context.selectedOption = matchedOption || userInput || null;\n`;
  code += `  }\n`;
  code += `  const optionIndex = ${JSON.stringify(optionTexts)}.indexOf(context.selectedOption);\n`;
  code += `  context.selectedOptionIndex = optionIndex >= 0 ? optionIndex : null;\n`;
  code += `  context.selectedOptionHandle = optionIndex >= 0 ? 'option-' + optionIndex : null;\n`;
  code += `  if (!context.quickReplySelections) context.quickReplySelections = {};\n`;
  code += `  context.quickReplySelections[${JSON.stringify(node.id)}] = { option_text: context.selectedOption, option_index: context.selectedOptionIndex };\n`;
  code += `  context[${JSON.stringify(variableKey)}] = context.selectedOption;\n`;
  code += `  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(variableKey)}, context.selectedOption, ${JSON.stringify(storeMode)}, { node_id: ${JSON.stringify(node.id)}, node_type: ${JSON.stringify(node.type)}, node_label: ${JSON.stringify(nodeLabel)} });\n`;
  code += `  context.message = context.selectedOption;\n`;
  code += `  context.lastUserMessage = context.selectedOption;\n`;
  code += `\n`;
  return code;
}

/**
 * Generates condition node logic
 */
function generateConditionNode(node) {
  let code = `  let conditionMatched = false;\n`;
  code += `  let matchedNodeId = null;\n`;
  
  const ifCondition = node.data?.ifCondition || node.ifCondition;
  const ifNode = node.data?.ifNode || node.ifNode;
  const ifConditions = node.data?.ifConditions || node.ifConditions || [];
  const elseIfConditions = node.data?.elseIfConditions || node.elseIfConditions || [];
  const elseNode = node.data?.elseNode || node.elseNode;
  
  if (ifCondition) {
    code += `  try {\n`;
    let ifConditionCode = 'safeEvaluateCondition(' + JSON.stringify(ifCondition) + ', context)';

    if (ifConditions.length > 0) {
      ifConditions.forEach((cond) => {
        if (cond.condition) {
          const operator = cond.operator || 'AND';
          if (operator === 'AND') {
            ifConditionCode += ` && safeEvaluateCondition(${JSON.stringify(cond.condition)}, context)`;
          } else if (operator === 'OR') {
            ifConditionCode += ` || safeEvaluateCondition(${JSON.stringify(cond.condition)}, context)`;
          } else if (operator === 'NOT') {
            ifConditionCode += ` && !safeEvaluateCondition(${JSON.stringify(cond.condition)}, context)`;
          }
        }
      });
    }
    
    code += `    if (${ifConditionCode}) {\n`;
    code += `      conditionMatched = true;\n`;
    code += `      matchedNodeId = ${JSON.stringify(ifNode)};\n`;
    code += `    }\n`;
    code += `  } catch (error) {}\n`;
  }
  
  if (elseIfConditions && elseIfConditions.length > 0) {
    elseIfConditions.forEach((elseIf) => {
      if (elseIf.condition) {
        code += `  if (!conditionMatched) {\n`;
        code += `    try {\n`;
        code += `      if (safeEvaluateCondition(${JSON.stringify(elseIf.condition)}, context)) {\n`;
        code += `        conditionMatched = true;\n`;
        code += `        matchedNodeId = ${JSON.stringify(elseIf.node)};\n`;
        code += `      }\n`;
        code += `    } catch (error) {}\n`;
        code += `  }\n`;
      }
    });
  }
  
  if (elseNode) {
    code += `  if (!conditionMatched) matchedNodeId = ${JSON.stringify(elseNode)};\n`;
  }
  
  code += `  context.conditionMatched = conditionMatched;\n`;
  code += `  context.matchedNodeId = matchedNodeId;\n`;
  
  return code;
}

/**
 * Generates delay node logic
 */
function generateDelayNode(node) {
  const delayMs = node.data?.delayMs || node.delayMs || 1000;
  return `  await new Promise(resolve => setTimeout(resolve, ${delayMs}));\n`;
}

/**
 * Generates assistant node logic
 */
function generateAssistantNode(node) {
  const backendBotId = node.backend_bot_id || node.data?.backend_bot_id;
  const botApiKey = node.bot_api_key || node.data?.bot_api_key;
  const nodeLabel = node.data?.label || node.label || 'Assistant';
  const responseVariable = (node.data?.responseVariable || node.responseVariable || `assistant_${node.id}_response`).trim();
  const storeNamespace = (node.data?.storeNamespace || node.storeNamespace || 'flow').trim() || 'flow';
  const contextKeys = Array.isArray(node.data?.contextKeys)
    ? node.data.contextKeys
    : String(node.data?.contextKeysText || node.contextKeysText || '')
        .split('\n')
        .map((entry) => entry.trim())
        .filter(Boolean);
  const includeAllUserVars = node.data?.includeAllUserVars !== false;
  if (backendBotId) {
    // Generate code to call backend bot API using bot-specific API key
    let code = `  // Call backend bot API\n`;
    code += `  const _assistantNodeId = ${JSON.stringify(node.id)};\n`;
    code += `  const _assistantNodeLabel = ${JSON.stringify(nodeLabel)};\n`;
    code += `  const backendBotId = ${JSON.stringify(backendBotId)};\n`;
    code += `  const botApiKey = ${botApiKey ? JSON.stringify(botApiKey) : 'null'};\n`;
    code += `  try {\n`;
    code += `    // Build assistant context from stored variables + selected keys\n`;
    code += `    const userMessage = buildAssistantContext(context, { contextKeys: ${JSON.stringify(contextKeys)}, includeAllUserVars: ${JSON.stringify(includeAllUserVars)} }) || context.question || context.userInput || context.message || context.selectedOption || context.input || context.user_message || context.text || 'Hello';\n`;
    code += `    \n`;
    code += `    if (!botApiKey) {\n`;
    code += `      context.response = 'Error: Bot API key not found. Please regenerate the code after the backend bot is saved.';\n`;
    code += `      context[${JSON.stringify(responseVariable)}] = context.response;\n`;
    code += `      storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(responseVariable)}, context.response, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'assistant', node_label: ${JSON.stringify(nodeLabel)} });\n`;
    code += `      if (typeof window !== 'undefined' && window.reportFlowMessage) {\n`;
    code += `        window.reportFlowMessage('assistant', context.response, _assistantNodeId, _assistantNodeLabel);\n`;
    code += `      }\n`;
    code += `      return context;\n`;
    code += `    }\n`;
    code += `    \n`;
    code += `    // Make API call to backend bot\n`;
    code += `    const apiUrl = '__BACKEND_API_URL__';\n`;
    code += `    \n`;
    code += `    // Create a new chat session using bot API key\n`;
    code += `    const createChatResponse = await fetch(apiUrl + '/chats', {\n`;
    code += `      method: 'POST',\n`;
    code += `      headers: {\n`;
    code += `        'Content-Type': 'application/json',\n`;
    code += `        'X-Bot-API-Key': botApiKey\n`;
    code += `      },\n`;
    code += `      body: JSON.stringify({\n`;
    code += `        name: 'Bot Conversation - ' + new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),\n`;
    code += `        from_type: 'project',\n`;
    code += `        from_project: backendBotId,\n`;
    code += `        session_id: (context && (context.sessionId || context.session_id)) || null\n`;
    code += `      })\n`;
    code += `    });\n`;
    code += `    \n`;
    code += `    if (!createChatResponse.ok) {\n`;
    code += `      throw new Error('Failed to create chat session: ' + createChatResponse.statusText);\n`;
    code += `    }\n`;
    code += `    \n`;
    code += `    const chatData = await createChatResponse.json();\n`;
    code += `    const chatId = chatData.id;\n`;
    code += `    \n`;
    code += `    // Send message and stream response using bot API key\n`;
    code += `    const response = await fetch(apiUrl + '/chats/' + chatId + '/messages', {\n`;
    code += `      method: 'POST',\n`;
    code += `      headers: {\n`;
    code += `        'Content-Type': 'application/json',\n`;
    code += `        'X-Bot-API-Key': botApiKey\n`;
    code += `      },\n`;
    code += `      body: JSON.stringify({\n`;
    code += `        type: 'user',\n`;
    code += `        content: userMessage,\n`;
    code += `        sender: 'user'\n`;
    code += `      })\n`;
    code += `    });\n`;
    code += `    \n`;
    code += `    if (!response.ok) {\n`;
    code += `      throw new Error('Failed to send message: ' + response.statusText);\n`;
    code += `    }\n`;
    code += `    \n`;
    code += `    // Read SSE stream\n`;
    code += `    const reader = response.body.getReader();\n`;
    code += `    const decoder = new TextDecoder();\n`;
    code += `    let buffer = '';\n`;
    code += `    let fullResponse = '';\n`;
    code += `    \n`;
    code += `    while (true) {\n`;
    code += `      const { done, value } = await reader.read();\n`;
    code += `      if (done) break;\n`;
    code += `      \n`;
    code += `      buffer += decoder.decode(value, { stream: true });\n`;
    code += `      const lines = buffer.split('\\n');\n`;
    code += `      buffer = lines.pop() || '';\n`;
    code += `      \n`;
    code += `      for (const line of lines) {\n`;
    code += `        if (line.startsWith('data: ')) {\n`;
    code += `          const data = line.slice(6).trim();\n`;
    code += `          if (data === '[DONE]' || !data) continue;\n`;
    code += `          \n`;
    code += `          try {\n`;
    code += `            const message = JSON.parse(data);\n`;
    code += `            \n`;
    code += `            // Skip user messages (already displayed in UI)\n`;
    code += `            if (message.type === 'user' || message.sender === 'user') {\n`;
    code += `              continue;\n`;
    code += `            }\n`;
    code += `            \n`;
    code += `            if (message.type === 'done') {\n`;
    code += `              if (currentMessageId && typeof window !== 'undefined' && window.finalizeBotMessage) {\n`;
    code += `                window.finalizeBotMessage(currentMessageId);\n`;
    code += `              }\n`;
    code += `              break;\n`;
    code += `            }\n`;
    code += `            \n`;
    code += `            if (message.type === 'error') {\n`;
    code += `              throw new Error(message.content);\n`;
    code += `            }\n`;
    code += `            \n`;
    code += `            const assistantText = (typeof message.answer === 'string' && message.answer.trim())\n`;
    code += `              ? message.answer.trim()\n`;
    code += `              : ((message.content && !message.content.startsWith('__STATUS_')) ? message.content : '');\n`;
    code += `            const shouldReplaceMessage = typeof message.answer === 'string' && message.answer.trim();\n`;
    code += `            \n`;
    code += `            if (assistantText) {\n`;
            code += `              fullResponse = shouldReplaceMessage ? assistantText : (fullResponse + assistantText);\n`;
    code += `            }\n`;
    code += `          } catch (e) {\n`;
    code += `            console.error('Error parsing SSE message:', e);\n`;
    code += `          }\n`;
    code += `        }\n`;
    code += `      }\n`;
    code += `    }\n`;
    code += `    \n`;
    code += `    context.response = fullResponse.trim() || 'No response received from bot.';\n`;
    code += `    context[${JSON.stringify(responseVariable)}] = context.response;\n`;
    code += `    storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(responseVariable)}, context.response, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'assistant', node_label: ${JSON.stringify(nodeLabel)} });\n`;
    code += `    if (typeof window !== 'undefined' && window.reportFlowMessage) {\n`;
    code += `      window.reportFlowMessage('assistant', context.response, _assistantNodeId, _assistantNodeLabel);\n`;
    code += `    }\n`;
    code += `  } catch (error) {\n`;
    code += `    console.error('Backend bot error:', error);\n`;
    code += `    context.response = 'Error: ' + error.message;\n`;
    code += `    context[${JSON.stringify(responseVariable)}] = context.response;\n`;
    code += `    storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(responseVariable)}, context.response, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'assistant', node_label: ${JSON.stringify(nodeLabel)} });\n`;
    code += `    if (typeof window !== 'undefined' && window.reportFlowMessage) {\n`;
    code += `      window.reportFlowMessage('assistant', context.response, _assistantNodeId, _assistantNodeLabel);\n`;
    code += `    }\n`;
    code += `  }\n`;
    return code;
  } else {
    // No backend bot linked - use default behavior
    return `  context.response = 'Hello! How can I help you?';\n  context[${JSON.stringify(responseVariable)}] = context.response;\n  storeFlowVariable(context, ${JSON.stringify(storeNamespace)}, ${JSON.stringify(responseVariable)}, context.response, 'replace', { node_id: ${JSON.stringify(node.id)}, node_type: 'assistant', node_label: ${JSON.stringify(nodeLabel)} });\n`;
  }
}

/**
 * Generates initializer node logic
 */
function generateInitializerNode(node) {
  return `  context.initialized = true;\n`;
}

/**
 * Generates user node logic
 */
function generateUserNode(node) {
  return `  context.processed = true;\n`;
}

/**
 * Generates note node logic (no-op)
 */
function generateNoteNode(node) {
  return `  // Note: ${node.data?.note || node.note || ''}\n`;
}

/**
 * Generates branch node logic
 */
function generateBranchNode(node) {
  const condition = node.data?.condition || node.condition || '';
  const branchType = node.data?.branchType || node.branchType || 'option';
  
  let code = `  // Branch node: ${branchType}\n`;
  
  if (condition) {
    code += `  let branchMatched = false;\n`;
    code += `  try {\n`;
    code += `    branchMatched = safeEvaluateCondition(${JSON.stringify(condition)}, context);\n`;
    code += `  } catch (error) {\n`;
    code += `    branchMatched = false;\n`;
    code += `  }\n`;
    code += `  context.branchMatched = branchMatched;\n`;
    code += `  context.branchType = ${JSON.stringify(branchType)};\n`;
  } else {
    code += `  // No condition - always pass through\n`;
    code += `  context.branchMatched = true;\n`;
    code += `  context.branchType = ${JSON.stringify(branchType)};\n`;
  }
  
  return code;
}

/**
 * Generates switch node logic
 */
function generateSwitchNode(node) {
  const switchOnExpr = (node.data?.switchOn || node.switchOn || 'context.userInput').trim();
  const cases = Array.isArray(node.data?.cases || node.cases) ? (node.data?.cases || node.cases) : [];
  const hasDefault = node.data?.hasDefault !== false;

  let code = `  const switchValue = getContextValue(context, ${JSON.stringify(switchOnExpr)});\n`;
  code += `  const switchCases = ${JSON.stringify(cases)};\n`;
  code += `  let selectedSwitchHandle = null;\n`;
  code += `  for (let i = 0; i < switchCases.length; i++) {\n`;
  code += `    const caseValue = switchCases[i] && switchCases[i].value;\n`;
  code += `    if (String(switchValue) === String(caseValue)) {\n`;
  code += `      selectedSwitchHandle = 'option-' + i;\n`;
  code += `      break;\n`;
  code += `    }\n`;
  code += `  }\n`;
  if (hasDefault) {
    code += `  if (selectedSwitchHandle === null) selectedSwitchHandle = 'default';\n`;
  }
  code += `  context.switchValue = switchValue;\n`;
  code += `  context.selectedSwitchHandle = selectedSwitchHandle;\n`;
  return code;
}

/**
 * Generates merge node logic
 */
function generateMergeNode(node) {
  const mergeMode = (node.data?.mergeMode || node.mergeMode || 'first-arrival').trim();
  let code = `  context.lastMergeNode = ${JSON.stringify(node.id)};\n`;
  code += `  context.mergeMode = ${JSON.stringify(mergeMode)};\n`;
  return code;
}

/**
 * Generates flow execution function
 */
function generateFlowExecution(entryPoints, nodes, connections) {
  let code = `// Flow execution function\n`;
  code += `async function executeFlow(initialContext = {}) {\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  let context = { ...initialContext };\n`;
  code += `  ensureFlowVars(context);\n`;
  code += `  // Initialize API responses array for storing all API call history\n`;
  code += `  if (!context.apiResponses) {\n`;
  code += `    context.apiResponses = [];\n`;
  code += `  }\n`;
  code += `  const visited = new Set();\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  \n`;
  code += `  try {\n`;
  
  if (entryPoints.length > 0) {
    code += `    undefined\n`;
    code += `    undefined\n`;
    for (let i = 0; i < entryPoints.length; i++) {
      const nodeName = sanitizeNodeId(entryPoints[i].id);
      code += `    undefined\n`;
      code += `    undefined\n`;
      code += `    await traverseNode('${entryPoints[i].id}', context, visited);\n`;
      code += `    undefined\n`;
    }
  } else if (nodes.length > 0) {
    const firstNode = nodes[0];
    code += `    undefined\n`;
    code += `    undefined\n`;
    code += `    undefined\n`;
    code += `    await traverseNode('${firstNode.id}', context, visited);\n`;
    code += `    undefined\n`;
  } else {
    code += `    console.warn('=== NO NODES TO EXECUTE ===');\n`;
  }
  
  code += `    undefined\n`;
  code += `    undefined\n`;
  code += `  } catch (error) {\n`;
  code += `    console.error('=== EXECUTE FLOW ERROR ===');\n`;
  code += `    console.error('Error:', error);\n`;
  code += `    console.error('Error stack:', error.stack);\n`;
  code += `    throw error;\n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  return context;\n`;
  code += `}\n\n`;
  
  return code;
}

/**
 * Generates node traversal function with loop and condition support
 */
function generateNodeTraversal(nodes, connections) {
  let code = `// Node traversal helper\n`;
  code += `async function traverseNode(nodeId, context, visited, executionDepth = 0) {\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  
  // Debug: Log nodes before serialization
  undefined
  undefined
  
  // Serialize nodes - ensure they're flat (no data property) and have correct IDs
  // CRITICAL: Preserve the top-level id, never use data.id
  const serializedNodes = nodes.map(node => {
    // Extract id FIRST before destructuring to ensure we keep the correct one
    const correctId = node.id; // This should be the full ID with suffix
    const { data, ...rest } = node;
    
    // Ensure the id is correct (never use data.id)
    const serializedNode = {
      ...rest,
      id: correctId // Force the correct ID
    };
    
    // Remove data property completely
    delete serializedNode.data;
    
    return serializedNode;
  });
  
  undefined
  undefined
  
  code += `  const nodes = ${JSON.stringify(serializedNodes)};\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  
  code += `  const connections = ${JSON.stringify(connections.map(c => ({ 
    from: c.source || c.from, 
    to: c.target || c.to, 
    sourceHandle: c.sourceHandle, 
    branch: c.data?.branch || c.branch,
    isLoop: c.data?.isLoop || c.isLoop,
    loopIterations: c.data?.loopIterations || c.loopIterations
  })))};\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  const connectionFromIds = [...new Set(connections.map(c => c.from))];\n`;
  code += `  const nodeIds = nodes.map(n => n.id);\n`;
  code += `  const missingNodeIds = connectionFromIds.filter(id => !nodeIds.includes(id));\n`;
  code += `  if (missingNodeIds.length > 0) {\n`;
  code += `    console.error('ERROR: Connection references nodes that dont exist! Missing node IDs:', missingNodeIds);\n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  if (executionDepth > 1000) {\n`;
  code += `    console.warn('Execution depth exceeded 1000, stopping');\n`;
  code += `    return;\n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  undefined\n`;
  code += `  const currentNode = nodes.find(n => n.id === nodeId);\n`;
  code += `  undefined\n`;
  code += `  if (!currentNode) { \n`;
  code += `    console.error('ERROR: Node not found! nodeId:', nodeId);\n`;
  code += `    console.error('Available node IDs:', nodes.map(n => n.id));\n`;
  code += `    return; \n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  const isInteractiveNode = currentNode.type === 'quickreply' || \n`;
  code += `    (currentNode.type === 'container' && (currentNode.message !== undefined || currentNode.data?.message !== undefined)) || \n`;
  code += `    currentNode.type === 'input' || \n`;
  code += `    currentNode.type === 'calendar' || \n`;
  code += `    currentNode.type === 'document' || \n`;
  code += `    currentNode.type === 'condition';\n`;
  code += `  undefined\n`;
  code += `  \n`;
  code += `  const hasIncomingLoop = (connections || []).some(c => c.to === nodeId && c.isLoop);\n`;
  code += `  const hasOutgoingLoop = (connections || []).some(c => c.from === nodeId && c.isLoop);\n`;
  code += `  const isPartOfLoop = hasIncomingLoop || hasOutgoingLoop;\n`;
  code += `  undefined\n`;
  code += `  \n`;
  code += `  const hasIncomingConnections = (connections || []).some(c => c.to === nodeId);\n`;
  code += `  const isPartOfCycle = hasIncomingConnections && visited.has(nodeId);\n`;
  code += `  undefined\n`;
  code += `  \n`;
  code += `  if (!isInteractiveNode && !isPartOfLoop && !isPartOfCycle && visited.has(nodeId)) {\n`;
  code += `    undefined\n`;
  code += `    return;\n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  if ((isInteractiveNode || isPartOfLoop || isPartOfCycle) && visited.has(nodeId)) {\n`;
  code += `    visited.delete(nodeId);\n`;
  code += `    const reachable = new Set();\n`;
  code += `    const collectReachable = (startId) => {\n`;
  code += `      if (reachable.has(startId)) return;\n`;
  code += `      reachable.add(startId);\n`;
  code += `      const outs = (connections || []).filter(c => c.from === startId && !c.isLoop).map(c => c.to);\n`;
  code += `      outs.forEach(collectReachable);\n`;
  code += `    };\n`;
  code += `    collectReachable(nodeId);\n`;
  code += `    reachable.forEach(id => visited.delete(id));\n`;
  code += `  }\n`;
  code += `  \n`;
  code += `  visited.add(nodeId);\n`;
  code += `  undefined\n`;
  code += `  const nodeMap = {\n`;
  
  // CRITICAL: Use serializedNodes to ensure we have the correct IDs
  // The serializedNodes array has the correct full IDs that match connections
  serializedNodes.forEach(node => {
    // Use full node ID as key and sanitized ID as function name
    // This ensures nodeMap keys match connection references
    const nodeName = sanitizeNodeId(node.id);
    code += `    '${node.id}': ${nodeName},\n`;
  });
  
  code += `  };\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  code += `  const node = nodeMap[nodeId];\n`;
  code += `  undefined\n`;
  code += `  if (!node) { \n`;
  code += `    console.error('ERROR: Function not found in nodeMap! nodeId:', nodeId);\n`;
  code += `    console.error('Available keys in nodeMap:', Object.keys(nodeMap));\n`;
  code += `    return; \n`;
  code += `  }\n`;
  code += `  undefined\n`;
  code += `  context = await node(context);\n`;
  code += `  context.lastNodeId = nodeId;\n`;
  code += `  context.lastNodeType = currentNode.type;\n`;
  code += `  if (!context.nodeOutputs) context.nodeOutputs = {};\n`;
  code += `  context.nodeOutputs[nodeId] = {\n`;
  code += `    type: currentNode.type,\n`;
  code += `    botMessage: context.botMessage || null,\n`;
  code += `    response: context.response || null,\n`;
  code += `    selectedOption: context.selectedOption || null,\n`;
  code += `    selectedDate: context.selectedDate || null,\n`;
  code += `    userInput: context.userInput || null,\n`;
  code += `    message: context.message || null\n`;
  code += `  };\n`;
  code += `  if (typeof window !== 'undefined' && window.reportFlowStep) {\n`;
  code += `    var _track = currentNode && currentNode.data && currentNode.data.trackAsStep;\n`;
  code += `    if (_track !== false) {\n`;
  code += `      var _label = (currentNode && ((currentNode.data && currentNode.data.analyticsStepLabel) || currentNode.label || (currentNode.data && currentNode.data.label) || currentNode.text || (currentNode.data && currentNode.data.text) || currentNode.type)) || nodeId;\n`;
  code += `      window.reportFlowStep(nodeId, _label);\n`;
  code += `    }\n`;
  code += `  }\n`;
  code += `  undefined\n`;
  code += `  const connectionMap = {};\n`;
  code += `  connections.forEach(conn => {\n`;
  code += `    if (!connectionMap[conn.from]) connectionMap[conn.from] = [];\n`;
  code += `    connectionMap[conn.from].push(conn.to);\n`;
  code += `  });\n`;
  code += `  undefined\n`;
  code += `  const nextNodes = connectionMap[nodeId] || [];\n`;
  code += `  undefined\n`;
  code += `  undefined\n`;
  
  // Condition node handling
  code += `  if (currentNode && currentNode.type === 'condition') {\n`;
  code += `    const matchedNodeId = context.matchedNodeId;\n`;
  code += `    if (matchedNodeId) await traverseNode(matchedNodeId, context, visited, executionDepth + 1);\n`;
  code += `    const ifNode = currentNode.ifNode || currentNode.data?.ifNode;\n`;
  code += `    const elseIfConditions = currentNode.elseIfConditions || currentNode.data?.elseIfConditions || [];\n`;
  code += `    const elseNode = currentNode.elseNode || currentNode.data?.elseNode;\n`;
  code += `    const conditionNodeIds = [ifNode, ...elseIfConditions.map(e => e && e.node ? e.node : null), elseNode].filter(Boolean);\n`;
  code += `    for (const nextNodeId of nextNodes) {\n`;
  code += `      if (!conditionNodeIds.includes(nextNodeId)) await traverseNode(nextNodeId, context, visited, executionDepth + 1);\n`;
  code += `    }\n`;
  
  // Switch node handling
  code += `  } else if (currentNode && currentNode.type === 'switch') {\n`;
  code += `    const selectedSwitchHandle = context.selectedSwitchHandle;\n`;
  code += `    let nextMatched = null;\n`;
  code += `    if (selectedSwitchHandle) {\n`;
  code += `      nextMatched = connections.find(c => c.from === nodeId && c.sourceHandle === selectedSwitchHandle);\n`;
  code += `    }\n`;
  code += `    if (nextMatched) {\n`;
  code += `      await traverseNode(nextMatched.to, context, visited, executionDepth + 1);\n`;
  code += `    }\n`;
  code += `    const switchConnections = connections.filter(c => c.from === nodeId && (c.sourceHandle || c.branch)).map(c => c.to);\n`;
  code += `    for (const nextNodeId of nextNodes) {\n`;
  code += `      if (!switchConnections.includes(nextNodeId)) await traverseNode(nextNodeId, context, visited, executionDepth + 1);\n`;
  code += `    }\n`;

  // Branch node handling
  code += `  } else if (currentNode && currentNode.type === 'branch') {\n`;
  code += `    const branchMatched = context.branchMatched;\n`;
  code += `    if (branchMatched) {\n`;
  code += `      // Branch condition matched - continue to next nodes\n`;
  code += `      for (const nextNodeId of nextNodes) {\n`;
  code += `        await traverseNode(nextNodeId, context, visited, executionDepth + 1);\n`;
  code += `      }\n`;
  code += `    } else {\n`;
  code += `      // Branch condition not matched - skip this branch\n`;
  code += `    }\n`;
  
  // Quick reply handling
  code += `  } else if (currentNode && (currentNode.type === 'quickreply' || (currentNode.type === 'container' && (currentNode.message !== undefined || currentNode.data?.message !== undefined)))) {\n`;
  code += `    const selectedOptionIndex = context.selectedOptionIndex;\n`;
  code += `    const selectedOptionHandle = context.selectedOptionHandle;\n`;
  code += `    if (selectedOptionHandle !== null && selectedOptionHandle !== undefined) {\n`;
  code += `      let optionConnection = connections.find(c => c.from === nodeId && c.sourceHandle === selectedOptionHandle);\n`;
  code += `      if (!optionConnection && selectedOptionIndex !== null && selectedOptionIndex >= 0) {\n`;
  code += `        optionConnection = connections.find(c => c.from === nodeId && (c.branch === String(selectedOptionIndex) || c.branch === 'option-' + selectedOptionIndex));\n`;
  code += `      }\n`;
  code += `      if (optionConnection) {\n`;
  code += `        await traverseNode(optionConnection.to, context, visited, executionDepth + 1);\n`;
  code += `      }\n`;
  code += `    } else if (selectedOptionIndex !== null && selectedOptionIndex >= 0) {\n`;
  code += `      const optionConnection = connections.find(c => c.from === nodeId && (c.branch === String(selectedOptionIndex) || c.sourceHandle === 'option-' + selectedOptionIndex));\n`;
  code += `      if (optionConnection) {\n`;
  code += `        await traverseNode(optionConnection.to, context, visited, executionDepth + 1);\n`;
  code += `      }\n`;
  code += `    }\n`;
  code += `    const optionConnections = connections.filter(c => c.from === nodeId && (c.branch !== null || c.sourceHandle !== null)).map(c => c.to);\n`;
  code += `    for (const nextNodeId of nextNodes) {\n`;
  code += `      if (!optionConnections.includes(nextNodeId)) await traverseNode(nextNodeId, context, visited, executionDepth + 1);\n`;
  code += `    }\n`;
  
  // Regular and loop connections
  code += `  } else {\n`;
  code += `    undefined\n`;
  code += `    const loopConnections = context._inLoopIteration ? [] : connections.filter(c => c.from === nodeId && c.isLoop);\n`;
  code += `    const regularConnections = connections.filter(c => c.from === nodeId && !c.isLoop);\n`;
  code += `    undefined\n`;
  code += `    undefined\n`;
  code += `    \n`;
  code += `    for (const loopConn of loopConnections) {\n`;
  code += `      const loopIterations = loopConn.loopIterations || 5;\n`;
  code += `      const loopToNodeId = loopConn.to;\n`;
  code += `      const loopFromNodeId = loopConn.from;\n`;
  code += `      \n`;
  code += `      const nodesInLoopChain = new Set();\n`;
  code += `      const findNodesInChain = (startId) => {\n`;
  code += `        if (nodesInLoopChain.has(startId)) return;\n`;
  code += `        nodesInLoopChain.add(startId);\n`;
  code += `        const outgoingConnections = connections.filter(c => c.from === startId && !c.isLoop);\n`;
  code += `        for (const conn of outgoingConnections) {\n`;
  code += `          findNodesInChain(conn.to);\n`;
  code += `        }\n`;
  code += `      };\n`;
  code += `      nodesInLoopChain.add(loopToNodeId);\n`;
  code += `      findNodesInChain(loopToNodeId);\n`;
  code += `      nodesInLoopChain.add(loopFromNodeId);\n`;
  code += `      \n`;
  code += `      const loopStartVisited = new Set(visited);\n`;
  code += `      \n`;
  code += `      for (let i = 0; i < loopIterations; i++) {\n`;
  code += `        context._loopCurrentIteration = i + 1;\n`;
  code += `        \n`;
  code += `        context.selectedOption = null;\n`;
  code += `        context.selectedOptionIndex = null;\n`;
  code += `        context.quickReplyMessage = null;\n`;
  code += `        context.quickReplyOptions = null;\n`;
  code += `        \n`;
  code += `        const loopIterationVisited = new Set(loopStartVisited);\n`;
  code += `        for (const chainNodeId of nodesInLoopChain) {\n`;
  code += `          loopIterationVisited.delete(chainNodeId);\n`;
  code += `        }\n`;
  code += `        \n`;
  code += `        context._inLoopIteration = true;\n`;
  code += `        \n`;
  code += `        await traverseNode(loopToNodeId, context, loopIterationVisited, executionDepth + 1);\n`;
  code += `        \n`;
  code += `        context._inLoopIteration = false;\n`;
  code += `        \n`;
  code += `        if (context.userLeft) {\n`;
  code += `          break;\n`;
  code += `        }\n`;
  code += `        \n`;
  code += `      }\n`;
  code += `      \n`;
  code += `      for (const chainNodeId of nodesInLoopChain) {\n`;
  code += `        visited.add(chainNodeId);\n`;
  code += `      }\n`;
  code += `      \n`;
  code += `    }\n`;
  code += `    \n`;
    code += `    for (const nextNodeId of regularConnections.map(c => c.to)) {\n`;
    code += `      undefined\n`;
    code += `      undefined\n`;
    code += `      await traverseNode(nextNodeId, context, visited, executionDepth + 1);\n`;
    code += `      undefined\n`;
    code += `    }\n`;
  code += `  }\n`;
  code += `  undefined\n`;
  code += `}\n\n`;
  
  return code;
}

/**
 * Generates export statements
 */
function generateExports() {
  return `if (typeof module !== 'undefined' && module.exports) {
  module.exports = { executeFlow };
}

if (typeof window !== 'undefined') {
  window.FlowExecutor = { executeFlow };
}
`;
}

/**
 * Sanitizes node ID for use as function name
 * Ensures the result is a valid JavaScript identifier (starts with letter/underscore, contains only alphanumeric/underscore)
 */
function sanitizeNodeId(id) {
  // Replace non-alphanumeric characters with underscores
  let sanitized = id.replace(/[^a-zA-Z0-9]/g, '_');
  
  // If it starts with a number, prefix with underscore to make it a valid identifier
  if (/^\d/.test(sanitized)) {
    sanitized = '_' + sanitized;
  }
  
  // If it's empty or starts with invalid character, use a default
  if (!sanitized || !/^[a-zA-Z_]/.test(sanitized)) {
    sanitized = '_node_' + sanitized;
  }
  
  return sanitized;
}

/**
 * Generates widget script for embedding
 * @param {Array} nodes - Array of flow nodes
 * @param {Array} connections - Array of edge connections
 * @param {Object} widgetSettings - Widget configuration settings
 * @returns {string} Generated widget script
 */
export function generateWidgetScript(nodes, connections, widgetSettings = {}) {
  const settings = {
    buttonIcon: widgetSettings.buttonIcon || '💬',
    buttonImage: widgetSettings.buttonImage || null,
    backgroundColor: widgetSettings.backgroundColor || '#ffffff',
    headerBackgroundColor: widgetSettings.headerBackgroundColor || '#2196F3',
    botMessageColor: widgetSettings.botMessageColor || '#2196F3',
    botMessageTextColor: widgetSettings.botMessageTextColor || '#ffffff',
    userMessageColor: widgetSettings.userMessageColor || '#e0e0e0',
    userMessageTextColor: widgetSettings.userMessageTextColor || '#333333',
    quickReplyBgColor: widgetSettings.quickReplyBgColor || '#e0e0e0',
    quickReplyBorderColor: widgetSettings.quickReplyBorderColor || '#ddd',
    quickReplyPosition: widgetSettings.quickReplyPosition || 'left',
    botIconBackgroundColor: widgetSettings.botIconBackgroundColor ?? '#f0f0f0',
    botIcon: widgetSettings.botIcon || '💬',
    botIconImage: widgetSettings.botIconImage || null,
    botIconWidth: widgetSettings.botIconWidth || 8,
    botIconHeight: widgetSettings.botIconHeight || 8,
    textSize: widgetSettings.textSize || 14,
    widgetWidth: widgetSettings.widgetWidth || 30,
    widgetHeight: widgetSettings.widgetHeight || 100,
    widgetPosition: widgetSettings.widgetPosition || 'bottom-right',
    widgetSpacing: widgetSettings.widgetSpacing || 5,
    minWidth: widgetSettings.minWidth || '300px',
    // Message bubble
    botMessageMaxWidth: widgetSettings.botMessageMaxWidth ?? 85,
    userMessageMaxWidth: widgetSettings.userMessageMaxWidth ?? 85,
    botMessageAlign: widgetSettings.botMessageAlign ?? 'left',
    userMessageAlign: widgetSettings.userMessageAlign ?? 'right',
    messageBorderRadius: widgetSettings.messageBorderRadius ?? 12,
    messagePaddingVertical: widgetSettings.messagePaddingVertical ?? 12,
    messagePaddingHorizontal: widgetSettings.messagePaddingHorizontal ?? 16,
    messageGap: widgetSettings.messageGap ?? 16,
    messageShadow: widgetSettings.messageShadow ?? 'none',
    botMessageBorderWidth: widgetSettings.botMessageBorderWidth ?? 0,
    botMessageBorderColor: widgetSettings.botMessageBorderColor ?? '#00000000',
    userMessageBorderWidth: widgetSettings.userMessageBorderWidth ?? 0,
    userMessageBorderColor: widgetSettings.userMessageBorderColor ?? '#00000000',
    // Quick reply
    quickReplyBorderRadius: widgetSettings.quickReplyBorderRadius ?? 8,
    quickReplyPaddingVertical: widgetSettings.quickReplyPaddingVertical ?? 8,
    quickReplyPaddingHorizontal: widgetSettings.quickReplyPaddingHorizontal ?? 16,
    quickReplyLayout: widgetSettings.quickReplyLayout ?? 'wrap',
    quickReplyFullWidth: widgetSettings.quickReplyFullWidth ?? false,
    quickReplyTextColor: widgetSettings.quickReplyTextColor ?? '#333333',
    quickReplyBorderWidth: widgetSettings.quickReplyBorderWidth ?? 2,
    quickReplyFontSize: widgetSettings.quickReplyFontSize ?? 14,
    quickReplyGap: widgetSettings.quickReplyGap ?? 8,
    // Input & Send
    inputBorderRadius: widgetSettings.inputBorderRadius ?? 8,
    inputBorderWidth: widgetSettings.inputBorderWidth ?? 2,
    inputBorderColor: widgetSettings.inputBorderColor ?? '#ddd',
    sendButtonColor: widgetSettings.sendButtonColor ?? '#2196F3',
    sendButtonTextColor: widgetSettings.sendButtonTextColor ?? '#ffffff',
    sendButtonBorderRadius: widgetSettings.sendButtonBorderRadius ?? 8,
    // Form node
    formContainerBgColor: widgetSettings.formContainerBgColor ?? '#ffffff',
    formContainerBorderColor: widgetSettings.formContainerBorderColor ?? '#e5e7eb',
    formContainerBorderWidth: widgetSettings.formContainerBorderWidth ?? 1,
    formContainerBorderRadius: widgetSettings.formContainerBorderRadius ?? 10,
    formSectionGap: widgetSettings.formSectionGap ?? 8,
    formFieldGap: widgetSettings.formFieldGap ?? 6,
    formFieldLabelColor: widgetSettings.formFieldLabelColor ?? '#374151',
    formFieldLabelSize: widgetSettings.formFieldLabelSize ?? 12,
    formFieldInputBgColor: widgetSettings.formFieldInputBgColor ?? '#ffffff',
    formFieldInputTextColor: widgetSettings.formFieldInputTextColor ?? '#111827',
    formFieldInputBorderColor: widgetSettings.formFieldInputBorderColor ?? '#d1d5db',
    formFieldInputBorderWidth: widgetSettings.formFieldInputBorderWidth ?? 1,
    formFieldInputBorderRadius: widgetSettings.formFieldInputBorderRadius ?? 8,
    formFieldInputPaddingVertical: widgetSettings.formFieldInputPaddingVertical ?? 10,
    formFieldInputPaddingHorizontal: widgetSettings.formFieldInputPaddingHorizontal ?? 10,
    formErrorTextColor: widgetSettings.formErrorTextColor ?? '#dc2626',
    formSubmitBgColor: widgetSettings.formSubmitBgColor ?? '#111827',
    formSubmitTextColor: widgetSettings.formSubmitTextColor ?? '#ffffff',
    formSubmitBorderColor: widgetSettings.formSubmitBorderColor ?? '#111827',
    formSubmitBorderWidth: widgetSettings.formSubmitBorderWidth ?? 0,
    formSubmitBorderRadius: widgetSettings.formSubmitBorderRadius ?? 8,
    formSubmitPaddingVertical: widgetSettings.formSubmitPaddingVertical ?? 10,
    formSubmitPaddingHorizontal: widgetSettings.formSubmitPaddingHorizontal ?? 14,
    // Image node
    imageMaxWidthPercent: widgetSettings.imageMaxWidthPercent ?? 100,
    imageBorderRadius: widgetSettings.imageBorderRadius ?? 12,
    imageBorderColor: widgetSettings.imageBorderColor ?? '#00000000',
    imageBorderWidth: widgetSettings.imageBorderWidth ?? 0,
    imageShadow: widgetSettings.imageShadow ?? 'none',
    imageCaptionColor: widgetSettings.imageCaptionColor ?? '#374151',
    imageCaptionSize: widgetSettings.imageCaptionSize ?? 12,
    imageCaptionTopSpacing: widgetSettings.imageCaptionTopSpacing ?? 8,
    // Message formatting controls
    enableAutoFormatting: widgetSettings.enableAutoFormatting ?? true,
    formattingMode: widgetSettings.formattingMode || 'balanced',
    autoListDetection: widgetSettings.autoListDetection ?? true,
    sectionHeadingDetection: widgetSettings.sectionHeadingDetection ?? true,
    normalizeEncodingArtifacts: widgetSettings.normalizeEncodingArtifacts ?? true,
    maxConsecutiveBlankLines: widgetSettings.maxConsecutiveBlankLines ?? 1,
    // Floating button & widget container
    toggleButtonBorderRadius: widgetSettings.toggleButtonBorderRadius ?? 50,
    toggleButtonSize: widgetSettings.toggleButtonSize ?? 60,
    widgetBorderRadius: widgetSettings.widgetBorderRadius ?? 12,
    widgetBorder: widgetSettings.widgetBorder ?? 'none',
    widgetShadow: widgetSettings.widgetShadow ?? '-4px 0 20px rgba(0, 0, 0, 0.15)',
    headerFontSize: widgetSettings.headerFontSize ?? 20,
  };
  
  const flowCode = generateJavaScriptCode(nodes, connections);
  const functionCode = flowCode.split('// Export for use as module')[0].trim();
  
  const widgetHTML = generateWidgetHTML(settings, functionCode);
  const escapedHTML = JSON.stringify(widgetHTML);
  
  return generateWidgetEmbedScript(settings, escapedHTML);
}

/**
 * Generates widget HTML
 */
function generateWidgetHTML(settings, functionCode) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: ${settings.backgroundColor};
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .container { 
            display: flex; 
            flex-direction: column; 
            height: 100%; 
            background: ${settings.backgroundColor}; 
        }
        .header {
            background: ${settings.headerBackgroundColor};
            color: white;
            padding: 1rem;
            padding-right: 3rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            font-size: ${settings.headerFontSize}px;
        }
        .messages-container {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
            background: ${settings.backgroundColor};
        }
        .message-wrapper {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: ${settings.messageGap}px;
        }
        .message-wrapper.bot {
            margin-right: auto;
            max-width: ${settings.botMessageMaxWidth}%;
        }
        .message-wrapper.user {
            margin-left: auto;
            flex-direction: row-reverse;
            max-width: ${settings.userMessageMaxWidth}%;
        }
        .message-wrapper.bot.align-center {
            margin-left: auto;
            margin-right: auto;
        }
        .message-wrapper.user.align-center {
            margin-left: auto;
            margin-right: auto;
        }
        .message-wrapper.user.align-left {
            margin-left: 0;
            margin-right: auto;
            flex-direction: row-reverse;
        }
        .bot-icon {
            flex-shrink: 0;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: ${settings.botIconBackgroundColor ?? '#f0f0f0'};
        }
        .bot-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .message {
            padding: ${settings.messagePaddingVertical}px ${settings.messagePaddingHorizontal}px;
            border-radius: ${settings.messageBorderRadius}px;
            word-wrap: break-word;
            font-size: ${settings.textSize}px;
            flex: 1;
            box-shadow: ${settings.messageShadow};
        }
        .message.bot {
            background: ${settings.botMessageColor};
            color: ${settings.botMessageTextColor};
            border: ${settings.botMessageBorderWidth}px solid ${settings.botMessageBorderColor};
        }
        .message.user {
            background: ${settings.userMessageColor};
            color: ${settings.userMessageTextColor};
            border: ${settings.userMessageBorderWidth}px solid ${settings.userMessageBorderColor};
        }
        .message.streaming {
            opacity: 0.95;
            position: relative;
        }
        .message.streaming::after {
            content: '|';
            animation: blink 1s step-start infinite;
            margin-left: 2px;
        }
        @keyframes blink {
            0%, 50% { opacity: 1; }
            50.1%, 100% { opacity: 0; }
        }
        .message.complete {
            opacity: 1;
        }
        .message.bot p, .message.bot ul, .message.bot ol {
            margin: 0 0 0.5em 0;
        }
        .message.bot p:last-child, .message.bot ul:last-child, .message.bot ol:last-child {
            margin-bottom: 0;
        }
        .message.bot ul, .message.bot ol {
            padding-left: 1.25em;
        }
        .message.bot li {
            margin-bottom: 0.25em;
        }
        .input-container {
            padding: 1rem;
            background: ${settings.backgroundColor};
            border-top: 1px solid #e0e0e0;
        }
        .input-wrapper {
            display: flex;
            gap: 0.5rem;
            align-items: flex-end;
        }
        .input-wrapper input {
            flex: 1;
            padding: 0.75rem;
            border: ${settings.inputBorderWidth}px solid ${settings.inputBorderColor};
            border-radius: ${settings.inputBorderRadius}px;
            font-size: 0.875rem;
        }
        .input-wrapper input:focus {
            outline: none;
            border-color: ${settings.sendButtonColor};
        }
        .input-wrapper input:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        .input-wrapper button {
            padding: 0.75rem 1.5rem;
            background: ${settings.sendButtonColor};
            color: ${settings.sendButtonTextColor};
            border: none;
            border-radius: ${settings.sendButtonBorderRadius}px;
            cursor: pointer;
            font-size: 0.875rem;
            font-weight: 500;
        }
        .input-wrapper button:hover:not(:disabled) {
            filter: brightness(0.9);
        }
        .input-wrapper button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 id="header-title" style="font-size: 1.25rem; font-weight: 600; display: flex; align-items: center; gap: 0.5rem;"></h1>
        </div>
        
        <div class="messages-container" id="messagesContainer">
            <div class="empty-state">
                <p>Starting conversation...</p>
            </div>
        </div>
        
        <div class="input-container">
            <div class="input-wrapper">
                <input 
                    type="text" 
                    id="messageInput" 
                    placeholder="Type your message..." 
                    disabled
                />
                <button id="sendBtn" disabled>Send</button>
            </div>
        </div>
    </div>
    
    <script>
        ${functionCode}
        
        let isWaitingForInput = false;
        let currentInputVariable = null;
        let currentInputResolver = null;
        var _projectId = '__PROJECT_ID__';
        var _analyticsProjectId = '__ANALYTICS_PROJECT_ID__';
        var _apiKey = '__API_KEY__';
        var _apiUrl = '__BACKEND_API_URL__';
        var _sessionId = (function(){ var d=Date.now(); return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){ var r=(d+Math.random()*16)%16|0; d=Math.floor(d/16); return (c==='x'?r:(r&0x3|0x8)).toString(16); }); })();
        let flowContext = { projectId: _projectId, analyticsProjectId: _analyticsProjectId, sessionId: _sessionId, botApiKey: _apiKey, apiUrl: _apiUrl };
        window.reportFlowStep = function(nodeId, nodeLabel) {
            if (!_analyticsProjectId || !_sessionId || !_apiUrl) return;
            fetch(_apiUrl + '/project-analytics/step-event', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bot-API-Key': _apiKey }, body: JSON.stringify({ project_id: _analyticsProjectId, session_id: _sessionId, node_id: nodeId, node_label: nodeLabel || null }) }).catch(function(){});
        };
        
        window._currentInputNodeId = null;
        window._currentInputNodeLabel = null;
        window.reportFlowMessage = function(role, content, nodeId, nodeLabel) {
            if (!_analyticsProjectId || !_sessionId || !_apiUrl) return;
            if (role === 'user' && !content) return;
            fetch(_apiUrl + '/project-analytics/flow-message', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bot-API-Key': _apiKey }, body: JSON.stringify({ project_id: _analyticsProjectId, session_id: _sessionId, role: role, content: typeof content === 'string' ? content : String(content || ''), node_id: nodeId || null, node_label: nodeLabel || null }) }).catch(function(){});
        };
        window._currentQuickReplyNodeId = null;
        window._currentQuickReplyNodeLabel = null;
        window.reportQuickReplyChoice = function(nodeId, nodeLabel, optionIndex, optionText) {
            if (!_analyticsProjectId || !_sessionId || !_apiUrl) return;
            var payload = { project_id: _analyticsProjectId, session_id: _sessionId, node_id: (nodeId != null && nodeId !== '') ? nodeId : 'unknown', node_label: nodeLabel || null, option_index: optionIndex, option_text: typeof optionText === 'string' ? optionText : String(optionText) };
            if (typeof window._currentQuickReplyVariableKey !== 'undefined' && window._currentQuickReplyVariableKey) payload.variable_key = window._currentQuickReplyVariableKey;
            fetch(_apiUrl + '/project-analytics/quick-reply-choice', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bot-API-Key': _apiKey }, body: JSON.stringify(payload) }).catch(function(){});
        };
        
        window.waitForUserInput = function(prompt) {
            return new Promise((resolve) => {
                isWaitingForInput = true;
                currentInputVariable = prompt;
                currentInputResolver = resolve;
                
                const input = document.getElementById("messageInput");
                const sendBtn = document.getElementById("sendBtn");
                input.disabled = false;
                input.placeholder = prompt || "Type your message...";
                input.focus();
                sendBtn.disabled = false;
            });
        };

        window.waitForDocumentInput = function(config) {
            return new Promise((resolve) => {
                const container = document.getElementById("messagesContainer");
                if (!container) {
                    resolve(null);
                    return;
                }

                var promptText = (config && config.prompt) || "Please upload your document";
                var accept = (config && config.accept) || "*/*";
                var maxSizeMb = Number((config && config.maxSizeMb) || 10);
                if (!Number.isFinite(maxSizeMb) || maxSizeMb <= 0) maxSizeMb = 10;
                var maxBytes = maxSizeMb * 1024 * 1024;

                addMessage(promptText, "bot");

                var wrap = document.createElement("div");
                wrap.className = "quick-reply-container";
                wrap.style.cssText = "margin-top:0.5rem; display:flex; gap:8px; align-items:center; width:100%; flex-wrap:wrap;";

                var input = document.createElement("input");
                input.type = "file";
                input.accept = String(accept);
                input.style.cssText = "flex:1; min-width:220px; padding:8px; border:1px solid #d1d5db; border-radius:8px; background:#fff;";

                var info = document.createElement("div");
                info.style.cssText = "width:100%; font-size:11px; color:#6b7280;";
                info.textContent = "Allowed: " + accept + " | Max: " + maxSizeMb + " MB";

                var errorText = document.createElement("div");
                errorText.style.cssText = "width:100%; font-size:11px; color:#dc2626; display:none;";

                var btn = document.createElement("button");
                btn.type = "button";
                btn.className = "quick-reply-btn";
                btn.textContent = "Upload";
                btn.style.cssText = "padding:10px 14px; border:none; border-radius:8px; cursor:pointer;";

                btn.addEventListener("click", function() {
                    var file = input.files && input.files[0] ? input.files[0] : null;
                    if (!file) {
                        errorText.style.display = "block";
                        errorText.textContent = "Please choose a file.";
                        return;
                    }
                    if (file.size > maxBytes) {
                        errorText.style.display = "block";
                        errorText.textContent = "File is larger than " + maxSizeMb + " MB.";
                        return;
                    }

                    errorText.style.display = "none";
                    var reader = new FileReader();
                    reader.onload = function() {
                        var documentValue = {
                            name: file.name || "",
                            type: file.type || "",
                            size: Number(file.size || 0),
                            lastModified: Number(file.lastModified || 0),
                            contentBase64: typeof reader.result === "string" ? reader.result : ""
                        };
                        addMessage("Uploaded: " + (file.name || "document"), "user");
                        if (typeof window.reportFlowMessage === "function") {
                            window.reportFlowMessage("user", "Uploaded: " + (file.name || "document"), window._currentInputNodeId || null, window._currentInputNodeLabel || null);
                        }
                        try { wrap.remove(); } catch (e) {}
                        resolve(documentValue);
                    };
                    reader.onerror = function() {
                        errorText.style.display = "block";
                        errorText.textContent = "Unable to read this file.";
                    };
                    reader.readAsDataURL(file);
                });

                wrap.appendChild(input);
                wrap.appendChild(btn);
                wrap.appendChild(info);
                wrap.appendChild(errorText);
                container.appendChild(wrap);
                container.scrollTop = container.scrollHeight;
            });
        };

        window.waitForCalendarInput = function(config) {
            return new Promise((resolve) => {
                const container = document.getElementById("messagesContainer");
                if (!container) {
                    resolve(null);
                    return;
                }

                var promptText = (config && config.prompt) || "Select a date";
                var selectionType = (config && config.selectionType) === "datetime" ? "datetime-local" : "date";
                var minDate = (config && config.minDate) || "";
                var maxDate = (config && config.maxDate) || "";
                var dateOptions = (config && Array.isArray(config.dateOptions)) ? config.dateOptions.filter(Boolean) : [];
                var confirmLabel = (config && config.confirmLabel) || "Confirm";

                addMessage(promptText, "bot");

                var wrap = document.createElement("div");
                wrap.className = "quick-reply-container";
                wrap.style.cssText = "margin-top:0.5rem; display:flex; gap:8px; align-items:center; width:100%;";

                var cleanup = function(value) {
                    try { wrap.remove(); } catch(e) {}
                    if (typeof value === "string" && value.trim()) {
                        addMessage(value, "user");
                        if (typeof window.reportFlowMessage === "function") {
                            window.reportFlowMessage("user", value, window._currentInputNodeId || null, window._currentInputNodeLabel || null);
                        }
                    }
                    resolve(value || null);
                };

                if (dateOptions.length > 0) {
                    wrap.style.cssText = "margin-top:0.5rem; display:flex; gap:8px; align-items:center; width:100%; flex-wrap:wrap;";
                    dateOptions.forEach(function(optionValue) {
                        var optionBtn = document.createElement("button");
                        optionBtn.type = "button";
                        optionBtn.className = "quick-reply-btn";
                        optionBtn.textContent = optionValue;
                        optionBtn.style.cssText = "padding:8px 12px; border:1px solid #d1d5db; border-radius:8px; cursor:pointer; background:#fff;";
                        optionBtn.addEventListener("click", function() {
                            cleanup(optionValue);
                        });
                        wrap.appendChild(optionBtn);
                    });
                } else {
                    var input = document.createElement("input");
                    input.type = selectionType;
                    input.className = "calendar-node-input";
                    input.style.cssText = "flex:1; min-width:0; padding:10px; border:1px solid #d1d5db; border-radius:8px;";
                    if (minDate) input.min = minDate;
                    if (maxDate) input.max = maxDate;

                    var btn = document.createElement("button");
                    btn.type = "button";
                    btn.className = "quick-reply-btn";
                    btn.textContent = confirmLabel;
                    btn.style.cssText = "padding:10px 14px; border:none; border-radius:8px; cursor:pointer;";

                    btn.addEventListener("click", function() {
                        cleanup(input.value || null);
                    });
                    input.addEventListener("keydown", function(e) {
                        if (e.key === "Enter") {
                            e.preventDefault();
                            cleanup(input.value || null);
                        }
                    });

                    wrap.appendChild(input);
                    wrap.appendChild(btn);
                    setTimeout(function(){ try { input.focus(); } catch(e) {} }, 0);
                }
                container.appendChild(wrap);
                container.scrollTop = container.scrollHeight;
            });
        };

        window.collectFormInput = function(config) {
            return new Promise((resolve) => {
                const container = document.getElementById("messagesContainer");
                if (!container) {
                    resolve({});
                    return;
                }

                var promptText = (config && config.prompt) || "Please fill details";
                var submitLabel = (config && config.submitLabel) || "Continue";
                var fields = (config && Array.isArray(config.fields)) ? config.fields : [];
                var baseContext = (config && config.context && typeof config.context === "object") ? config.context : {};

                addMessage(promptText, "bot");

                var wrap = document.createElement("div");
                wrap.className = "quick-reply-container";
                wrap.style.cssText =
                  "margin-top:0.5rem;" +
                  "width:100%;" +
                  "display:flex;" +
                  "flex-direction:column;" +
                  "gap:" + (WIDGET_UI_SETTINGS.formSectionGap ?? 8) + "px;" +
                  "background:" + (WIDGET_UI_SETTINGS.formContainerBgColor || "#fff") + ";" +
                  "border:" + (WIDGET_UI_SETTINGS.formContainerBorderWidth ?? 1) + "px solid " + (WIDGET_UI_SETTINGS.formContainerBorderColor || "#e5e7eb") + ";" +
                  "border-radius:" + (WIDGET_UI_SETTINGS.formContainerBorderRadius ?? 10) + "px;" +
                  "padding:10px;";

                var values = {};
                var controls = [];

                function getPathValue(root, path) {
                    if (!root || !path) return undefined;
                    var normalized = String(path).trim().replace(/\[(\d+)\]/g, ".$1");
                    if (!normalized) return undefined;
                    var current = root;
                    var parts = normalized.split(".").filter(Boolean);
                    for (var i = 0; i < parts.length; i++) {
                        if (current === null || current === undefined) return undefined;
                        current = current[parts[i]];
                    }
                    return current;
                }

                function normalizeOptions(rawOptions) {
                    if (!Array.isArray(rawOptions)) return [];
                    return rawOptions
                      .map(function(opt) {
                        if (typeof opt === "string") return { label: opt, value: opt };
                        if (opt && typeof opt === "object") {
                          var label = opt.label || opt.text || opt.value || "";
                          var value = opt.value || opt.text || opt.label || "";
                          return { label: String(label), value: String(value) };
                        }
                        return null;
                      })
                      .filter(Boolean);
                }

                function resolveFieldOptions(field) {
                    var dependsOn = String(field.dependsOn || "").trim();
                    var optionsByValue = field.optionsByValue && typeof field.optionsByValue === "object" ? field.optionsByValue : null;
                    var contextPath = String(field.optionsContextPath || "").trim();

                    if (optionsByValue && dependsOn) {
                        var parentValue = values[dependsOn];
                        if (parentValue === undefined || parentValue === null || parentValue === "") {
                            parentValue = getPathValue(baseContext, dependsOn);
                        }
                        var exactMatch = optionsByValue[String(parentValue)];
                        var fallback = optionsByValue["*"];
                        return normalizeOptions(Array.isArray(exactMatch) ? exactMatch : fallback);
                    }

                    if (contextPath) {
                        var ctxValue = getPathValue({ context: baseContext, values: values }, contextPath);
                        if (Array.isArray(ctxValue)) return normalizeOptions(ctxValue);
                    }

                    return normalizeOptions(field.options);
                }

                function syncLiveValue(control) {
                    var field = control.field || {};
                    var key = String(field.key || "").trim();
                    if (!key) return;
                    var type = String(field.type || "text").toLowerCase();
                    var raw = control.input.value;
                    var value = typeof raw === "string" ? raw.trim() : raw;
                    if (!value) {
                        values[key] = null;
                        return;
                    }
                    values[key] = (type === "number" || type === "quantity") ? Number(value) : value;
                }

                function refreshDependentSelects(changedKey) {
                    controls.forEach(function(control) {
                        var field = control.field || {};
                        if (String(field.type || "").toLowerCase() !== "select") return;
                        var dependsOn = String(field.dependsOn || "").trim();
                        if (!dependsOn) return;
                        if (changedKey && dependsOn !== changedKey) return;
                        if (typeof control.refreshOptions === "function") {
                            control.refreshOptions();
                        }
                    });
                }

                function getFieldLabel(field, index) {
                    return String(field.label || field.key || ("Field " + (index + 1)));
                }

                function buildField(field, index) {
                    var fieldWrap = document.createElement("div");
                    fieldWrap.style.cssText = "display:flex; flex-direction:column; gap:" + (WIDGET_UI_SETTINGS.formFieldGap ?? 6) + "px;";

                    var label = document.createElement("label");
                    var labelText = getFieldLabel(field, index);
                    label.textContent = labelText + (field.required ? " *" : "");
                    label.style.cssText = "font-size:" + (WIDGET_UI_SETTINGS.formFieldLabelSize ?? 12) + "px; color:" + (WIDGET_UI_SETTINGS.formFieldLabelColor || "#374151") + ";";
                    fieldWrap.appendChild(label);

                    var type = String(field.type || "text").toLowerCase();
                    var input;
                    if (type === "textarea") {
                        input = document.createElement("textarea");
                        input.rows = 3;
                    } else if (type === "select") {
                        input = document.createElement("select");
                    } else {
                        input = document.createElement("input");
                        if (type === "number" || type === "quantity") input.type = "number";
                        else if (type === "date") input.type = "date";
                        else if (type === "datetime") input.type = "datetime-local";
                        else input.type = "text";
                    }

                    input.style.cssText =
                      "width:100%;" +
                      "padding:" + (WIDGET_UI_SETTINGS.formFieldInputPaddingVertical ?? 10) + "px " + (WIDGET_UI_SETTINGS.formFieldInputPaddingHorizontal ?? 10) + "px;" +
                      "border:" + (WIDGET_UI_SETTINGS.formFieldInputBorderWidth ?? 1) + "px solid " + (WIDGET_UI_SETTINGS.formFieldInputBorderColor || "#d1d5db") + ";" +
                      "border-radius:" + (WIDGET_UI_SETTINGS.formFieldInputBorderRadius ?? 8) + "px;" +
                      "background:" + (WIDGET_UI_SETTINGS.formFieldInputBgColor || "#fff") + ";" +
                      "color:" + (WIDGET_UI_SETTINGS.formFieldInputTextColor || "#111827") + ";";
                    if (field.placeholder && input.tagName !== "SELECT") input.placeholder = String(field.placeholder);
                    if (field.min !== undefined && input.tagName === "INPUT") input.min = String(field.min);
                    if (field.max !== undefined && input.tagName === "INPUT") input.max = String(field.max);
                    if (field.defaultValue !== undefined && field.defaultValue !== null) input.value = String(field.defaultValue);

                    var errorText = document.createElement("div");
                    errorText.style.cssText = "font-size:11px; color:" + (WIDGET_UI_SETTINGS.formErrorTextColor || "#dc2626") + "; display:none;";

                    fieldWrap.appendChild(input);
                    fieldWrap.appendChild(errorText);
                    wrap.appendChild(fieldWrap);

                    var control = { field: field, input: input, errorText: errorText, labelText: labelText };
                    controls.push(control);

                    var key = String(field.key || "").trim();

                    if (type === "select") {
                        control.refreshOptions = function() {
                            var previous = input.value;
                            input.innerHTML = "";
                            var placeholderOpt = document.createElement("option");
                            placeholderOpt.value = "";
                            placeholderOpt.textContent = field.placeholder || "Select an option";
                            input.appendChild(placeholderOpt);
                            var options = resolveFieldOptions(field);
                            options.forEach(function(opt) {
                                var optionEl = document.createElement("option");
                                optionEl.value = String(opt.value);
                                optionEl.textContent = String(opt.label);
                                input.appendChild(optionEl);
                            });
                            var hasPrevious = options.some(function(opt) { return String(opt.value) === String(previous); });
                            if (hasPrevious) {
                                input.value = previous;
                            } else {
                                input.value = "";
                                if (key) values[key] = null;
                            }
                        };
                        control.refreshOptions();
                    }

                    input.addEventListener("change", function() {
                        syncLiveValue(control);
                        if (key) refreshDependentSelects(key);
                    });
                    input.addEventListener("input", function() {
                        syncLiveValue(control);
                        if (key) refreshDependentSelects(key);
                    });

                    syncLiveValue(control);
                }

                function validateControl(control) {
                    var field = control.field || {};
                    var key = String(field.key || "").trim();
                    var raw = control.input.value;
                    var value = typeof raw === "string" ? raw.trim() : raw;
                    var type = String(field.type || "text").toLowerCase();
                    var required = !!field.required;

                    control.errorText.style.display = "none";
                    control.errorText.textContent = "";

                    if (!value && required) {
                        control.errorText.textContent = control.labelText + " is required";
                        control.errorText.style.display = "block";
                        return { ok: false };
                    }
                    if (!value) {
                        if (key) values[key] = null;
                        return { ok: true };
                    }

                    if ((type === "number" || type === "quantity") && isNaN(Number(value))) {
                        control.errorText.textContent = control.labelText + " must be a number";
                        control.errorText.style.display = "block";
                        return { ok: false };
                    }
                    if ((type === "number" || type === "quantity") && field.min !== undefined && Number(value) < Number(field.min)) {
                        control.errorText.textContent = control.labelText + " must be at least " + field.min;
                        control.errorText.style.display = "block";
                        return { ok: false };
                    }
                    if ((type === "number" || type === "quantity") && field.max !== undefined && Number(value) > Number(field.max)) {
                        control.errorText.textContent = control.labelText + " must be at most " + field.max;
                        control.errorText.style.display = "block";
                        return { ok: false };
                    }

                    if (key) values[key] = (type === "number" || type === "quantity") ? Number(value) : value;
                    return { ok: true };
                }

                if (fields.length === 0) {
                    var emptyMessage = document.createElement("div");
                    emptyMessage.textContent = "No fields configured in this form node.";
                    emptyMessage.style.cssText = "font-size:12px; color:#6b7280; padding:8px 0;";
                    wrap.appendChild(emptyMessage);
                } else {
                    fields.forEach(buildField);
                    refreshDependentSelects();
                }

                var submitBtn = document.createElement("button");
                submitBtn.type = "button";
                submitBtn.textContent = submitLabel;
                submitBtn.className = "quick-reply-btn";
                submitBtn.style.cssText =
                  "padding:" + (WIDGET_UI_SETTINGS.formSubmitPaddingVertical ?? 10) + "px " + (WIDGET_UI_SETTINGS.formSubmitPaddingHorizontal ?? 14) + "px;" +
                  "border:" + (WIDGET_UI_SETTINGS.formSubmitBorderWidth ?? 0) + "px solid " + (WIDGET_UI_SETTINGS.formSubmitBorderColor || "#111827") + ";" +
                  "border-radius:" + (WIDGET_UI_SETTINGS.formSubmitBorderRadius ?? 8) + "px;" +
                  "cursor:pointer;" +
                  "width:100%;" +
                  "margin-top:2px;" +
                  "background:" + (WIDGET_UI_SETTINGS.formSubmitBgColor || "#111827") + ";" +
                  "color:" + (WIDGET_UI_SETTINGS.formSubmitTextColor || "#ffffff") + ";";

                submitBtn.addEventListener("click", function() {
                    var allValid = true;
                    controls.forEach(function(control) {
                        var result = validateControl(control);
                        if (!result.ok) allValid = false;
                    });
                    if (!allValid) return;

                    var printablePairs = Object.keys(values).map(function(key) {
                        return key + ": " + (values[key] === null ? "" : String(values[key]));
                    });
                    var printable = printablePairs.length ? printablePairs.join(", ") : "Form submitted";
                    addMessage(printable, "user");
                    if (typeof window.reportFlowMessage === "function") {
                        window.reportFlowMessage("user", printable, window._currentInputNodeId || null, window._currentInputNodeLabel || null);
                    }
                    try { wrap.remove(); } catch (e) {}
                    resolve(values);
                });

                wrap.appendChild(submitBtn);
                container.appendChild(wrap);
                container.scrollTop = container.scrollHeight;
            });
        };
        
        // Create a new empty bot message bubble
        window.createBotMessageBubble = function() {
            const container = document.getElementById("messagesContainer");
            const emptyState = container.querySelector(".empty-state");
            if (emptyState) emptyState.remove();
            
            const messageId = "bot-msg-" + Date.now() + "-" + Math.random().toString(36).substr(2, 9);
            
            const messageWrapper = document.createElement("div");
            messageWrapper.className = "message-wrapper bot";
            messageWrapper.setAttribute("data-message-id", messageId);
            
            const iconContainer = document.createElement("div");
            iconContainer.className = "bot-icon";
            
            const containerWidth = container.offsetWidth || 400;
            const iconWidth = (containerWidth * WIDGET_UI_SETTINGS.botIconWidth) / 100;
            const iconHeight = (containerWidth * WIDGET_UI_SETTINGS.botIconHeight) / 100;
            const iconSize = Math.max(16, Math.min(iconWidth, iconHeight));
            
            iconContainer.style.cssText = "width: " + iconSize + "px; height: " + iconSize + "px; font-size: " + (iconSize * 0.6) + "px;";
            
            if (WIDGET_UI_SETTINGS.botIconImage) {
                const iconImg = document.createElement("img");
                iconImg.src = WIDGET_UI_SETTINGS.botIconImage;
                iconImg.alt = "Bot";
                iconContainer.appendChild(iconImg);
            } else if (WIDGET_UI_SETTINGS.botIcon) {
                iconContainer.textContent = WIDGET_UI_SETTINGS.botIcon;
            }
            
            messageWrapper.appendChild(iconContainer);
            
            const messageDiv = document.createElement("div");
            messageDiv.className = "message bot streaming";
            messageDiv.id = messageId;
            messageDiv.textContent = "";
            messageWrapper.appendChild(messageDiv);
            
            container.appendChild(messageWrapper);
            container.scrollTop = container.scrollHeight;
            
            return messageId;
        };
        
        // Append text to an existing bot message bubble
        window.appendToBotMessage = function(messageId, text) {
            const messageDiv = document.getElementById(messageId);
            if (messageDiv) {
                messageDiv.textContent += text;
                const container = document.getElementById("messagesContainer");
                container.scrollTop = container.scrollHeight;
            }
        };

        // Replace text in an existing bot message bubble
        window.setBotMessageContent = function(messageId, text) {
            const messageDiv = document.getElementById(messageId);
            if (messageDiv) {
                messageDiv.textContent = text || "";
                const container = document.getElementById("messagesContainer");
                container.scrollTop = container.scrollHeight;
            }
        };
        
        // Finalize bot message (mark as complete, format paragraphs and lists)
        window.finalizeBotMessage = function(messageId) {
            const messageDiv = document.getElementById(messageId);
            if (messageDiv) {
                messageDiv.className = "message bot complete";
                var raw = messageDiv.textContent || "";
                messageDiv.innerHTML = window.formatBotMessageText(raw);
                const container = document.getElementById("messagesContainer");
                if (container) container.scrollTop = container.scrollHeight;
            }
        };
        
        // Render Markdown-ish text safely (no raw HTML execution).
        // Supports: paragraphs, line breaks, bullet/numbered lists, links, inline code, code fences, bold/italic.
        window.formatBotMessageText = function(raw) {
            if (raw == null) return "";
            if (typeof raw !== "string") raw = String(raw);
            var fmt = (typeof WIDGET_UI_SETTINGS === "object" && WIDGET_UI_SETTINGS) ? WIDGET_UI_SETTINGS : {};
            var autoFormattingEnabled = fmt.enableAutoFormatting !== false;
            var formattingMode = String(fmt.formattingMode || "balanced").toLowerCase();
            var autoListDetection = fmt.autoListDetection !== false;
            var sectionHeadingDetection = fmt.sectionHeadingDetection !== false;
            var normalizeEncodingArtifacts = fmt.normalizeEncodingArtifacts !== false;
            var maxBlankLines = Number(fmt.maxConsecutiveBlankLines);
            if (!Number.isFinite(maxBlankLines) || maxBlankLines < 0) maxBlankLines = 1;
            if (maxBlankLines > 6) maxBlankLines = 6;

            if (autoFormattingEnabled) {
                raw = raw.replace(/\\r\\n?/g, "\\n");
                if (normalizeEncodingArtifacts) {
                    raw = raw.replace(/\\uFFFD/g, "'");
                }
                if (sectionHeadingDetection) {
                    raw = raw.replace(/\\b(Ingredients|Instructions|Steps|Method|Directions|Notes)\\s*:\\s*/gi, "$1:\\n");
                }
                if (autoListDetection) {
                    raw = raw.replace(/([^\\n])\\s+(\\d+\\.\\s+)/g, "$1\\n$2");
                    raw = raw.replace(/([^\\n])\\s+([\\-\\*\\u2022]\\s+)/g, "$1\\n$2");
                }
                if (formattingMode === "aggressive") {
                    raw = raw.replace(/([\\.!\\?])\\s+(\\d+\\.\\s+)/g, "$1\\n$2");
                }
                var blankRunRe = new RegExp("\\\\n{" + (maxBlankLines + 2) + ",}", "g");
                raw = raw.replace(blankRunRe, "\\n".repeat(maxBlankLines + 1)).trim();
            }

            function escapeHtml(s) {
                return String(s)
                  .replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/>/g, "&gt;")
                  .replace(/"/g, "&quot;")
                  .replace(/'/g, "&#39;");
            }

            function isSafeUrl(url) {
                try {
                    // If url is relative, URL() needs a base to resolve it.
                    // Use the injected backend API URL origin instead of hardcoding localhost.
                    var base = (function() {
                      try {
                        if (typeof _apiUrl === "string" && _apiUrl) return new URL(_apiUrl).origin;
                      } catch (e) {}
                      try {
                        if (typeof window !== "undefined" && window.location && window.location.origin) {
                          return window.location.origin;
                        }
                      } catch (e2) {}
                      return null;
                    })();
                    if (!base) return false;
                    var u = new URL(url, base);
                    return ["http:", "https:", "mailto:"].indexOf(u.protocol) >= 0;
                } catch (e) {
                    return false;
                }
            }

            // Extract fenced code blocks first so inline formatting doesn't touch them.
            var codeBlocks = [];
            // NOTE: This code is embedded inside a template literal in the generator,
            // so we avoid literal backticks here by using \\u0060 (the backtick codepoint).
            var fenceRe = new RegExp("\\u0060\\u0060\\u0060([a-zA-Z0-9_-]+)?\\\\n([\\\\s\\\\S]*?)\\u0060\\u0060\\u0060", "g");
            var text = raw.replace(fenceRe, function(_m, lang, code) {
                var idx = codeBlocks.length;
                codeBlocks.push({
                    lang: (lang || "").trim().toLowerCase(),
                    code: code == null ? "" : String(code)
                });
                return "%%CODEBLOCK_" + idx + "%%";
            });

            // Escape everything (we'll add back safe HTML tags via replacements).
            text = escapeHtml(text);

            // Restore code blocks into HTML
            text = text.replace(/%%CODEBLOCK_(\\d+)%%/g, function(_m, n) {
                var block = codeBlocks[Number(n)];
                if (!block) return "";
                var langClass = block.lang ? (" language-" + block.lang) : "";
                return (
                  '<pre class="md-code"><code class="' +
                  langClass +
                  '">' +
                  escapeHtml(block.code).replace(/\\n/g, "\\n") +
                  "</code></pre>"
                );
            });

            // Inline code: use \\u0060 delimiter (backtick)
            var inlineCodeRe = new RegExp("\\u0060([^\\u0060\\\\n]+)\\u0060", "g");
            text = text.replace(inlineCodeRe, function(_m, code) {
                return '<code class="md-inline-code">' + code + "</code>";
            });

            // Links: [text](url)
            text = text.replace(/\\[([^\\]]+)\\]\\(([^\\)\\s]+)\\)/g, function(_m, label, url) {
                var href = String(url || "");
                if (!isSafeUrl(href)) {
                    return label;
                }
                return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">' + label + "</a>";
            });

            // Bold / italic (simple)
            text = text.replace(/\\*\\*([^*\\n]+)\\*\\*/g, "<strong>$1</strong>");
            text = text.replace(/\\*([^*\\n]+)\\*/g, "<em>$1</em>");

            // Split into lines and build paragraphs/lists.
            var lines = text.split(/\\n/);
            var out = [];
            var inList = false;
            var listType = null;
            var listItems = [];

            function flushList() {
                if (listItems.length === 0) return;
                var tag = listType === "ol" ? "ol" : "ul";
                out.push("<" + tag + ">");
                for (var j = 0; j < listItems.length; j++) out.push("<li>" + listItems[j] + "</li>");
                out.push("</" + tag + ">");
                listItems = [];
                inList = false;
                listType = null;
            }

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                var trimmed = (line || "").trim();

                // If we hit a code block HTML line, flush list and emit as-is
                if (trimmed.indexOf("<pre") === 0 && trimmed.indexOf("md-code") >= 0) {
                    flushList();
                    out.push(line);
                    continue;
                }

                var isBullet = /^\\s*[\\*\\-\\u2022]\\s+/.test(line);
                var isNumbered = /^\\s*\\d+\\.\\s+/.test(line);
                if (isBullet || isNumbered) {
                    var desired = isNumbered ? "ol" : "ul";
                    if (inList && listType !== desired) flushList();
                    inList = true;
                    listType = desired;
                    var content = trimmed
                      .replace(/^[\\*\\-\\u2022]\\s+/, "")
                      .replace(/^\\d+\\.\\s+/, "");
                    listItems.push(content);
                    continue;
                }

                flushList();
                if (!trimmed) {
                    out.push("<br>");
                } else {
                    out.push("<p>" + trimmed + "</p>");
                }
            }

            flushList();
            return out.join("");
        };
        
        // Legacy function for compatibility (now creates one-time message)
        window.displayBotMessage = function(text) {
            const messageId = window.createBotMessageBubble();
            window.appendToBotMessage(messageId, text);
            window.finalizeBotMessage(messageId);
        };
        
        // Display a bot image bubble (safe DOM construction; no innerHTML injection)
        window.displayBotImage = function(imageUrl, altText, captionText) {
            const container = document.getElementById("messagesContainer");
            if (!container) return;
            
            const emptyState = container.querySelector(".empty-state");
            if (emptyState) emptyState.remove();

            if (!imageUrl) {
                if (typeof window.displayBotMessage === 'function') {
                    window.displayBotMessage(captionText || altText || "");
                }
                return;
            }

            const messageWrapper = document.createElement("div");
            messageWrapper.className = "message-wrapper bot";
            if (WIDGET_UI_SETTINGS && WIDGET_UI_SETTINGS.botMessageAlign === "center") {
                messageWrapper.className += " align-center";
            }

            const iconContainer = document.createElement("div");
            iconContainer.className = "bot-icon";

            const containerWidth = container.offsetWidth || 400;
            const iconWidth = (containerWidth * WIDGET_UI_SETTINGS.botIconWidth) / 100;
            const iconHeight = (containerWidth * WIDGET_UI_SETTINGS.botIconHeight) / 100;
            const iconSize = Math.max(16, Math.min(iconWidth, iconHeight));

            iconContainer.style.cssText = "width: " + iconSize + "px; height: " + iconSize + "px; font-size: " + (iconSize * 0.6) + "px;";
            if (WIDGET_UI_SETTINGS.botIconImage) {
                const iconImg = document.createElement("img");
                iconImg.src = WIDGET_UI_SETTINGS.botIconImage;
                iconImg.alt = "Bot";
                iconContainer.appendChild(iconImg);
            } else if (WIDGET_UI_SETTINGS.botIcon) {
                iconContainer.textContent = WIDGET_UI_SETTINGS.botIcon;
            }

            messageWrapper.appendChild(iconContainer);

            const messageDiv = document.createElement("div");
            messageDiv.className = "message bot complete";

            const img = document.createElement("img");
            img.src = String(imageUrl);
            img.alt = String(altText || "Image");
            img.style.cssText =
              "max-width: " + (WIDGET_UI_SETTINGS.imageMaxWidthPercent ?? 100) + "%;" +
              "height: auto;" +
              "display: block;" +
              "border-radius: " + (WIDGET_UI_SETTINGS.imageBorderRadius ?? 12) + "px;" +
              "border: " + (WIDGET_UI_SETTINGS.imageBorderWidth ?? 0) + "px solid " + (WIDGET_UI_SETTINGS.imageBorderColor || "#00000000") + ";" +
              "box-shadow: " + (WIDGET_UI_SETTINGS.imageShadow || "none") + ";";
            messageDiv.appendChild(img);

            if (captionText && String(captionText).trim()) {
                const captionDiv = document.createElement("div");
                captionDiv.className = "bot-image-caption";
                captionDiv.style.cssText =
                  "margin-top: " + (WIDGET_UI_SETTINGS.imageCaptionTopSpacing ?? 8) + "px;" +
                  "color: " + (WIDGET_UI_SETTINGS.imageCaptionColor || "#374151") + ";" +
                  "font-size: " + (WIDGET_UI_SETTINGS.imageCaptionSize ?? 12) + "px;";
                captionDiv.innerHTML = window.formatBotMessageText(String(captionText));
                messageDiv.appendChild(captionDiv);
            }

            messageWrapper.appendChild(messageDiv);
            container.appendChild(messageWrapper);
            container.scrollTop = container.scrollHeight;
        };
        
        window.showQuickReplyOptions = function(message, options) {
            return new Promise((resolve) => {
                addMessage(message, "bot");
                
                const container = document.getElementById("messagesContainer");
                if (!container) {
                    resolve(null);
                    return;
                }
                const normalizedOptions = Array.isArray(options)
                  ? options
                      .map(function(opt) {
                        if (typeof opt === 'string') return opt;
                        if (opt == null) return '';
                        if (typeof opt === 'object' && typeof opt.text === 'string') return opt.text;
                        return String(opt);
                      })
                      .map(function(text) { return text.trim(); })
                      .filter(Boolean)
                  : [];
                if (normalizedOptions.length === 0) {
                    resolve(null);
                    return;
                }
                const quickReplyDiv = document.createElement("div");
                quickReplyDiv.className = "quick-reply-container";
                const qrJc = (WIDGET_UI_SETTINGS.quickReplyPosition === 'center') ? 'center' : (WIDGET_UI_SETTINGS.quickReplyPosition === 'right') ? 'flex-end' : 'flex-start';
                const qrLayout = (WIDGET_UI_SETTINGS.quickReplyLayout === 'stack') ? 'column' : 'row';
                const qrWrap = (WIDGET_UI_SETTINGS.quickReplyLayout === 'stack') ? 'nowrap' : 'wrap';
                const qrGap = (WIDGET_UI_SETTINGS.quickReplyGap ?? 8);
                const qrFull = !!WIDGET_UI_SETTINGS.quickReplyFullWidth;
                quickReplyDiv.style.cssText =
                  "margin-top: 0.5rem;" +
                  " display: flex;" +
                  " flex-direction: " + qrLayout + ";" +
                  " flex-wrap: " + qrWrap + ";" +
                  " gap: " + qrGap + "px;" +
                  " justify-content: " + qrJc + ";" +
                  " align-items: " + ((qrLayout === 'column' || qrFull) ? 'stretch' : 'flex-start') + ";" +
                  " width: " + ((qrLayout === 'column' || qrFull) ? '100%' : 'auto') + ";";
                
                const quickReplyBg = WIDGET_UI_SETTINGS.quickReplyBgColor || "#e0e0e0";
                const quickReplyBorder = WIDGET_UI_SETTINGS.quickReplyBorderColor || "#ddd";
                const qrBr = (WIDGET_UI_SETTINGS.quickReplyBorderRadius ?? 8) + "px";
                const qrPv = (WIDGET_UI_SETTINGS.quickReplyPaddingVertical ?? 8) + "px";
                const qrPh = (WIDGET_UI_SETTINGS.quickReplyPaddingHorizontal ?? 16) + "px";
                const qrBw = (WIDGET_UI_SETTINGS.quickReplyBorderWidth ?? 2) + "px";
                const qrTc = (WIDGET_UI_SETTINGS.quickReplyTextColor || "#333");
                const qrFs = (WIDGET_UI_SETTINGS.quickReplyFontSize ?? 14) + "px";
                normalizedOptions.forEach((option, index) => {
                    const button = document.createElement("button");
                    button.className = "quick-reply-btn";
                    button.textContent = option;
                    button.style.cssText =
                      "padding: " + qrPv + " " + qrPh + ";" +
                      " background: " + quickReplyBg + ";" +
                      " color: " + qrTc + ";" +
                      " border: " + qrBw + " solid " + quickReplyBorder + ";" +
                      " border-radius: " + qrBr + ";" +
                      " cursor: pointer;" +
                      " font-size: " + qrFs + ";" +
                      " line-height: 1.35;" +
                      " text-align: left;" +
                      " white-space: normal;" +
                      (qrFull || qrLayout === 'column' ? " width: 100%;" : "");
                    button.onclick = () => {
                        addMessage(option, "user");
                        if (typeof window.reportFlowMessage === 'function') {
                            window.reportFlowMessage('user', option, window._currentInputNodeId || null, window._currentInputNodeLabel || null);
                        }
                        if (typeof window.reportQuickReplyChoice === 'function') {
                            window.reportQuickReplyChoice(window._currentQuickReplyNodeId || null, window._currentQuickReplyNodeLabel || null, index, option);
                        }
                        quickReplyDiv.remove();
                        resolve(option);
                    };
                    quickReplyDiv.appendChild(button);
                });
                
                container.appendChild(quickReplyDiv);
                container.scrollTop = container.scrollHeight;
            });
        };
        
        const WIDGET_UI_SETTINGS = ${JSON.stringify({
          botIcon: settings.botIcon,
          botIconImage: settings.botIconImage,
          botIconWidth: settings.botIconWidth,
          botIconHeight: settings.botIconHeight,
          botMessageAlign: settings.botMessageAlign,
          userMessageAlign: settings.userMessageAlign,
          botMessageColor: settings.botMessageColor,
          botMessageTextColor: settings.botMessageTextColor,
          userMessageColor: settings.userMessageColor,
          userMessageTextColor: settings.userMessageTextColor,
          quickReplyBgColor: settings.quickReplyBgColor,
          quickReplyBorderColor: settings.quickReplyBorderColor,
          quickReplyPosition: settings.quickReplyPosition || 'left',
          quickReplyBorderRadius: settings.quickReplyBorderRadius,
          quickReplyPaddingVertical: settings.quickReplyPaddingVertical,
          quickReplyPaddingHorizontal: settings.quickReplyPaddingHorizontal,
          quickReplyLayout: settings.quickReplyLayout,
          quickReplyFullWidth: settings.quickReplyFullWidth,
          quickReplyTextColor: settings.quickReplyTextColor,
          quickReplyBorderWidth: settings.quickReplyBorderWidth,
          quickReplyFontSize: settings.quickReplyFontSize,
          quickReplyGap: settings.quickReplyGap,
          formContainerBgColor: settings.formContainerBgColor,
          formContainerBorderColor: settings.formContainerBorderColor,
          formContainerBorderWidth: settings.formContainerBorderWidth,
          formContainerBorderRadius: settings.formContainerBorderRadius,
          formSectionGap: settings.formSectionGap,
          formFieldGap: settings.formFieldGap,
          formFieldLabelColor: settings.formFieldLabelColor,
          formFieldLabelSize: settings.formFieldLabelSize,
          formFieldInputBgColor: settings.formFieldInputBgColor,
          formFieldInputTextColor: settings.formFieldInputTextColor,
          formFieldInputBorderColor: settings.formFieldInputBorderColor,
          formFieldInputBorderWidth: settings.formFieldInputBorderWidth,
          formFieldInputBorderRadius: settings.formFieldInputBorderRadius,
          formFieldInputPaddingVertical: settings.formFieldInputPaddingVertical,
          formFieldInputPaddingHorizontal: settings.formFieldInputPaddingHorizontal,
          formErrorTextColor: settings.formErrorTextColor,
          formSubmitBgColor: settings.formSubmitBgColor,
          formSubmitTextColor: settings.formSubmitTextColor,
          formSubmitBorderColor: settings.formSubmitBorderColor,
          formSubmitBorderWidth: settings.formSubmitBorderWidth,
          formSubmitBorderRadius: settings.formSubmitBorderRadius,
          formSubmitPaddingVertical: settings.formSubmitPaddingVertical,
          formSubmitPaddingHorizontal: settings.formSubmitPaddingHorizontal,
          imageMaxWidthPercent: settings.imageMaxWidthPercent,
          imageBorderRadius: settings.imageBorderRadius,
          imageBorderColor: settings.imageBorderColor,
          imageBorderWidth: settings.imageBorderWidth,
          imageShadow: settings.imageShadow,
          imageCaptionColor: settings.imageCaptionColor,
          imageCaptionSize: settings.imageCaptionSize,
          imageCaptionTopSpacing: settings.imageCaptionTopSpacing,
          enableAutoFormatting: settings.enableAutoFormatting,
          formattingMode: settings.formattingMode,
          autoListDetection: settings.autoListDetection,
          sectionHeadingDetection: settings.sectionHeadingDetection,
          normalizeEncodingArtifacts: settings.normalizeEncodingArtifacts,
          maxConsecutiveBlankLines: settings.maxConsecutiveBlankLines,
          textSize: settings.textSize,
        })};
        
        function addMessage(text, type) {
            const container = document.getElementById("messagesContainer");
            const emptyState = container.querySelector(".empty-state");
            if (emptyState) emptyState.remove();
            
            const messageWrapper = document.createElement("div");
            messageWrapper.className = "message-wrapper " + type;
            if (type === "bot" && (WIDGET_UI_SETTINGS && WIDGET_UI_SETTINGS.botMessageAlign === "center")) {
              messageWrapper.className += " align-center";
            }
            if (type === "user") {
              if (WIDGET_UI_SETTINGS && WIDGET_UI_SETTINGS.userMessageAlign === "center") messageWrapper.className += " align-center";
              if (WIDGET_UI_SETTINGS && WIDGET_UI_SETTINGS.userMessageAlign === "left") messageWrapper.className += " align-left";
            }
            
            if (type === "bot") {
                const iconContainer = document.createElement("div");
                iconContainer.className = "bot-icon";
                
                const containerWidth = container.offsetWidth || 400;
                const iconWidth = (containerWidth * WIDGET_UI_SETTINGS.botIconWidth) / 100;
                const iconHeight = (containerWidth * WIDGET_UI_SETTINGS.botIconHeight) / 100;
                const iconSize = Math.max(16, Math.min(iconWidth, iconHeight));
                
                iconContainer.style.cssText = "width: " + iconSize + "px; height: " + iconSize + "px; font-size: " + (iconSize * 0.6) + "px;";
                
                if (WIDGET_UI_SETTINGS.botIconImage) {
                    const iconImg = document.createElement("img");
                    iconImg.src = WIDGET_UI_SETTINGS.botIconImage;
                    iconImg.alt = "Bot";
                    iconContainer.appendChild(iconImg);
                } else if (WIDGET_UI_SETTINGS.botIcon) {
                    iconContainer.textContent = WIDGET_UI_SETTINGS.botIcon;
                }
                
                messageWrapper.appendChild(iconContainer);
            }
            
            const messageDiv = document.createElement("div");
            messageDiv.className = "message " + type;
            if (type === "bot" && typeof window.formatBotMessageText === "function") {
                messageDiv.innerHTML = window.formatBotMessageText(text || "");
            } else {
                messageDiv.textContent = text || "";
            }
            messageWrapper.appendChild(messageDiv);
            
            container.appendChild(messageWrapper);
            container.scrollTop = container.scrollHeight;
        }
        
        let flowStarted = false;
        
        function startFlow() {
            if (flowStarted) return;
            flowStarted = true;
            
            setTimeout(async () => {
                try {
                    if (_analyticsProjectId && _sessionId && _apiUrl) {
                        try {
                            var svRes = await fetch(_apiUrl + '/project-analytics/session-variables?project_id=' + encodeURIComponent(_analyticsProjectId) + '&session_id=' + encodeURIComponent(_sessionId), { headers: { 'X-Bot-API-Key': _apiKey } });
                            if (svRes.ok) {
                                var sv = await svRes.json();
                                if (sv.quick_reply_by_node && Object.keys(sv.quick_reply_by_node).length) {
                                    flowContext.quickReplySelections = flowContext.quickReplySelections || {};
                                    for (var k in sv.quick_reply_by_node) flowContext.quickReplySelections[k] = sv.quick_reply_by_node[k];
                                }
                                if (sv.variables && Object.keys(sv.variables).length) {
                                    for (var vk in sv.variables) flowContext[vk] = sv.variables[vk];
                                }
                            }
                        } catch (e) {}
                    }
                    undefined
                    const result = await executeFlow(flowContext);
                    if (result && typeof result === 'object') {
                        flowContext = { ...flowContext, ...result };
                        window.__flowContext = flowContext;
                    }
                    undefined
                    if (!result || Object.keys(result).length === 0) {
                        console.warn("Flow executed but returned empty context. Check if flow has entry points.");
                    }
                } catch (error) {
                    console.error("Flow execution error:", error);
                    console.error("Error stack:", error.stack);
                    addMessage("Error: " + error.message, "bot");
                }
            }, 100);
        }
        
        function initializeWidget() {
            const headerTitle = document.getElementById("header-title");
            if (headerTitle) {
                if (WIDGET_UI_SETTINGS.botIconImage) {
                    const iconImg = document.createElement("img");
                    iconImg.src = WIDGET_UI_SETTINGS.botIconImage;
                    iconImg.style.cssText = "width: 24px; height: 24px; object-fit: contain;";
                    iconImg.alt = "Bot";
                    headerTitle.appendChild(iconImg);
                    headerTitle.appendChild(document.createTextNode(" Chatbot"));
                } else {
                    headerTitle.textContent = (WIDGET_UI_SETTINGS.botIcon || "💬") + " Chatbot";
                }
            }
            
            const messageInput = document.getElementById("messageInput");
            const sendBtn = document.getElementById("sendBtn");
            
            if (sendBtn) {
                sendBtn.addEventListener("click", handleSendMessage);
            }
            
            if (messageInput) {
                messageInput.addEventListener("keydown", function(e) {
                    if (e.key === "Enter" && !sendBtn.disabled) {
                        e.preventDefault();
                        handleSendMessage();
                    }
                });
            }
            
            startFlow();
        }
        
        // Initialize when DOM is ready (works in iframe too)
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", initializeWidget);
        } else {
            // DOM already loaded (common in iframes)
            initializeWidget();
        }
        
        window.startFlow = startFlow;
        
        function handleSendMessage() {
            if (!isWaitingForInput) return;
            
            const messageInput = document.getElementById("messageInput");
            const sendBtn = document.getElementById("sendBtn");
            const message = messageInput.value.trim();
            
            if (!message) return;
            
            addMessage(message, "user");
            
            if (typeof window.reportFlowMessage === 'function') {
                window.reportFlowMessage('user', message, window._currentInputNodeId || null, window._currentInputNodeLabel || null);
            }
            if (currentInputResolver) {
                currentInputResolver(message);
                currentInputResolver = null;
            }
            
            messageInput.value = "";
            messageInput.disabled = true;
            sendBtn.disabled = true;
            isWaitingForInput = false;
        }
    </script>
</body>
</html>`;
}

/**
 * Generates widget embed script
 */
function generateWidgetEmbedScript(settings, escapedHTML) {
  return `(function() {
    "use strict";
    
    if (document.getElementById("flow-diagram-widget-container")) {
      return;
    }
    
    const CONFIG = {
      widgetId: "flow-diagram-widget-" + Date.now()
    };
    
    const WIDGET_SETTINGS = ${JSON.stringify(settings)};
    
    function createWidget() {
      var script = document.currentScript;
      var backendApiUrl = (script && script.getAttribute && script.getAttribute('data-api-url')) || (typeof window !== 'undefined' && window.BACKEND_API_URL) || '__BACKEND_API_URL__';
      // Normalize backend URL to an absolute URL with /v1 suffix.
      // Prefer env-injected value; never hardcode localhost in generated runtime.
      var normalizeBackendUrl = function(url) {
        var value = String(url || '').trim();
        if (!value) return '';
        if (value.endsWith('/')) value = value.slice(0, -1);
        // If backend is provided as a relative path like /v1,
        // convert it to an absolute base using current origin.
        // This is required because the widget runs inside a blob: iframe,
        // and relative URLs may fail to resolve.
        if (value.startsWith('/') && typeof window !== 'undefined' && window.location && window.location.origin) {
          try {
            return window.location.origin + value;
          } catch (e) {
            // If URL() fails, fall through and return empty.
            return '';
          }
        }
        if (!value.endsWith('/v1')) value = value + '/v1';
        if (value.startsWith('http://') || value.startsWith('https://')) return value;
        return '';
      };
      var injectedBackendApiUrl = normalizeBackendUrl('__BACKEND_API_URL__');
      var normalizedBackendApiUrl = normalizeBackendUrl(backendApiUrl) || injectedBackendApiUrl;
      if (!normalizedBackendApiUrl) {
        console.error('[Widget] Invalid backend API URL. Set absolute VITE_API_URL (example: https://api.example.com/v1).');
        return;
      }
      backendApiUrl = normalizedBackendApiUrl;
      // backendApiUrl should already be absolute (from VITE_API_URL). We avoid auto-prefixing
      // with window.location.origin because it can point to the wrong host inside iframe/preview.
      var projectId = (script && script.getAttribute && script.getAttribute('data-project-id')) || '';
      var analyticsProjectId = (script && script.getAttribute && script.getAttribute('data-analytics-project-id')) || projectId;
      var apiKey = (script && script.getAttribute && script.getAttribute('data-api-key')) || '';
      var widgetHTML = ${escapedHTML};
      widgetHTML = widgetHTML.split('__BACKEND_API_URL__').join(backendApiUrl).split('__PROJECT_ID__').join(projectId).split('__ANALYTICS_PROJECT_ID__').join(analyticsProjectId).split('__API_KEY__').join(apiKey);
      
      const widget = document.createElement("div");
      widget.id = "flow-diagram-widget-container";
      
      const spacing = WIDGET_SETTINGS.widgetSpacing || 5;
      let positionStyle = "";
      switch(WIDGET_SETTINGS.widgetPosition) {
        case "top-right":
          positionStyle = "top: " + spacing + "px; right: " + spacing + "px; left: auto; bottom: auto;";
          break;
        case "top-left":
          positionStyle = "top: " + spacing + "px; left: " + spacing + "px; right: auto; bottom: auto;";
          break;
        case "bottom-left":
          positionStyle = "bottom: " + spacing + "px; left: " + spacing + "px; right: auto; top: auto;";
          break;
        case "bottom-right":
        default:
          positionStyle = "bottom: " + spacing + "px; right: " + spacing + "px; left: auto; top: auto;";
          break;
      }
      
      const wbr = (WIDGET_SETTINGS.widgetBorderRadius ?? 12) + "px";
      const wborder = WIDGET_SETTINGS.widgetBorder || "none";
      const wshadow = WIDGET_SETTINGS.widgetShadow || "-4px 0 20px rgba(0, 0, 0, 0.15)";
      widget.style.cssText = "position: fixed; " + positionStyle + " width: " + WIDGET_SETTINGS.widgetWidth + "vw; min-width: " + WIDGET_SETTINGS.minWidth + "; height: " + WIDGET_SETTINGS.widgetHeight + "vh; background: " + WIDGET_SETTINGS.backgroundColor + "; box-shadow: " + wshadow + "; border: " + wborder + "; border-radius: " + wbr + "; overflow: hidden; z-index: 9999; display: flex; flex-direction: column; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0;";
      
      const blob = new Blob([widgetHTML], { type: "text/html" });
      const blobUrl = URL.createObjectURL(blob);
      
      const iframe = document.createElement("iframe");
      iframe.style.cssText = "width: 100%; height: 100%; border: none;";
      iframe.src = blobUrl;
      
      widget.appendChild(iframe);
      
      widget.addEventListener("remove", () => {
        URL.revokeObjectURL(blobUrl);
      });
      
      const toggleBtn = document.createElement("button");
      toggleBtn.setAttribute("data-flow-toggle", "true");
      
      function setToggleButtonIcon() {
        toggleBtn.innerHTML = "";
        if (WIDGET_SETTINGS.buttonImage) {
          const img = document.createElement("img");
          img.src = WIDGET_SETTINGS.buttonImage;
          img.style.cssText = "width: 100%; height: 100%; object-fit: cover; display: block;";
          toggleBtn.appendChild(img);
        } else {
          toggleBtn.innerHTML = WIDGET_SETTINGS.buttonIcon || "💬";
        }
      }
      
      setToggleButtonIcon();
      toggleBtn.setAttribute("aria-label", "Open Chatbot");
      
      const buttonSpacing = 20;
      const tbtnSize = WIDGET_SETTINGS.toggleButtonSize ?? 60;
      const tbtnRadius = (WIDGET_SETTINGS.toggleButtonBorderRadius ?? 50) + "%";
      let buttonPosition = "";
      switch(WIDGET_SETTINGS.widgetPosition) {
        case "top-right":
          buttonPosition = "top: " + buttonSpacing + "px; right: " + buttonSpacing + "px; bottom: auto; left: auto;";
          break;
        case "top-left":
          buttonPosition = "top: " + buttonSpacing + "px; left: " + buttonSpacing + "px; bottom: auto; right: auto;";
          break;
        case "bottom-left":
          buttonPosition = "bottom: " + buttonSpacing + "px; left: " + buttonSpacing + "px; top: auto; right: auto;";
          break;
        case "bottom-right":
        default:
          buttonPosition = "bottom: " + buttonSpacing + "px; right: " + buttonSpacing + "px; top: auto; left: auto;";
          break;
      }
      
      toggleBtn.style.cssText = "position: fixed; " + buttonPosition + " width: " + tbtnSize + "px; height: " + tbtnSize + "px; border-radius: " + tbtnRadius + "; background: " + WIDGET_SETTINGS.botMessageColor + "; color: white; border: none; cursor: pointer; font-size: 24px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); z-index: 10000; transition: transform 0.2s; display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 0;";
      toggleBtn.onmouseover = () => toggleBtn.style.transform = "scale(1.1)";
      toggleBtn.onmouseout = () => toggleBtn.style.transform = "scale(1)";
      
      let isVisible = false;
      toggleBtn.onclick = () => {
        isVisible = !isVisible;
        widget.style.display = isVisible ? "flex" : "none";
        if (isVisible) {
          toggleBtn.innerHTML = "✕";
        } else {
          setToggleButtonIcon();
        }
        toggleBtn.setAttribute("aria-label", isVisible ? "Close Chatbot" : "Open Chatbot");
        
        if (isVisible) {
          const closeButtonSpacing = 10;
          toggleBtn.style.cssText = "position: absolute !important; top: " + closeButtonSpacing + "px !important; right: " + closeButtonSpacing + "px !important; width: 40px; height: 40px; border-radius: 50%; background: rgba(244, 67, 54, 0.9); color: white; border: none; cursor: pointer; font-size: 20px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2); z-index: 10001; transition: transform 0.2s; display: flex; align-items: center; justify-content: center;";
          widget.style.position = "relative";
          widget.appendChild(toggleBtn);
        } else {
          document.body.appendChild(toggleBtn);
          toggleBtn.style.cssText = "position: fixed !important; " + buttonPosition + " width: " + tbtnSize + "px; height: " + tbtnSize + "px; border-radius: " + tbtnRadius + "; background: " + WIDGET_SETTINGS.botMessageColor + "; color: white; border: none; cursor: pointer; font-size: 24px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); z-index: 10000; transition: transform 0.2s; display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 0;";
        }
      };
      
      const style = document.createElement("style");
      const containerSpacing = WIDGET_SETTINGS.widgetSpacing || 5;
      let containerPosition = "";
      switch(WIDGET_SETTINGS.widgetPosition) {
        case "top-right":
          containerPosition = "top: " + containerSpacing + "px !important; right: " + containerSpacing + "px !important; left: auto !important; bottom: auto !important;";
          break;
        case "top-left":
          containerPosition = "top: " + containerSpacing + "px !important; left: " + containerSpacing + "px !important; right: auto !important; bottom: auto !important;";
          break;
        case "bottom-left":
          containerPosition = "bottom: " + containerSpacing + "px !important; left: " + containerSpacing + "px !important; right: auto !important; top: auto !important;";
          break;
        case "bottom-right":
        default:
          containerPosition = "bottom: " + containerSpacing + "px !important; right: " + containerSpacing + "px !important; left: auto !important; top: auto !important;";
          break;
      }
      const containerBr = (WIDGET_SETTINGS.widgetBorderRadius ?? 12) + "px";
      const containerBorder = WIDGET_SETTINGS.widgetBorder || "none";
      style.textContent = "#flow-diagram-widget-container { position: fixed !important; " + containerPosition + " width: " + WIDGET_SETTINGS.widgetWidth + "vw !important; min-width: " + WIDGET_SETTINGS.minWidth + " !important; height: " + WIDGET_SETTINGS.widgetHeight + "vh !important; margin: 0 !important; padding: 0 !important; border-radius: " + containerBr + " !important; border: " + containerBorder + " !important; overflow: hidden !important; }";
      document.head.appendChild(style);
      
      document.body.appendChild(widget);
      document.body.appendChild(toggleBtn);
      widget.style.display = "none";
    }
    
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", createWidget);
    } else {
      createWidget();
    }
    
    window.FlowDiagramWidget = {
      show: function() {
        const widget = document.getElementById("flow-diagram-widget-container");
        const toggleBtn = document.querySelector("[data-flow-toggle]");
        if (widget && toggleBtn) {
          widget.style.display = "flex";
          toggleBtn.innerHTML = "✕";
          toggleBtn.setAttribute("aria-label", "Close Chatbot");
          
          const iframe = widget.querySelector("iframe");
          if (iframe && iframe.contentWindow && iframe.contentWindow.startFlow) {
            iframe.contentWindow.startFlow();
          }
        }
      },
      hide: function() {
        const widget = document.getElementById("flow-diagram-widget-container");
        const toggleBtn = document.querySelector("[data-flow-toggle]");
        if (widget && toggleBtn) {
          widget.style.display = "none";
          if (WIDGET_SETTINGS.buttonImage) {
            toggleBtn.innerHTML = "";
            const img = document.createElement("img");
            img.src = WIDGET_SETTINGS.buttonImage;
            img.style.cssText = "width: 100%; height: 100%; object-fit: cover; display: block;";
            toggleBtn.appendChild(img);
          } else {
            toggleBtn.innerHTML = WIDGET_SETTINGS.buttonIcon || "💬";
          }
          toggleBtn.setAttribute("aria-label", "Open Chatbot");
        }
      },
      toggle: function() {
        const widget = document.getElementById("flow-diagram-widget-container");
        if (widget) {
          if (widget.style.display === "none") {
            window.FlowDiagramWidget.show();
          } else {
            window.FlowDiagramWidget.hide();
          }
        }
      }
    };
  })();`;
}

/**
 * Downloads code as a file
 * @param {string} code - Code content to download
 * @param {string} filename - Filename for download
 */
export function downloadAsScript(code, filename = 'flow-script.js') {
  const blob = new Blob([code], { type: 'text/javascript' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

