/**
 * Code generation utility for projects
 * Calls the backend /v1/codegen endpoint to generate Python code
 */

import { apiRequest } from '../lib/api-client';

/**
 * Generate Python code for a project
 * @param {Object} project - Project object with flow, name, description, etc.
 * @returns {Promise<string>} Generated Python code
 */
export async function generateProjectCode(project) {
  try {
    const result = await apiRequest('/codegen', {
      method: 'POST',
      body: {
        id: project.id || 0,
        name: project.name || 'New Project',
        description: project.description || '',
        flow: project.flow || { nodes: [], edges: [] },
        user_id: project.user_id || null,
        created_at: project.created_at || new Date().toISOString(),
        updated_at: project.updated_at || new Date().toISOString(),
      },
      showErrorToast: false,
    });

    return result.code || '';
  } catch (error) {
    console.error('Failed to generate project code:', error);
    throw error;
  }
}

