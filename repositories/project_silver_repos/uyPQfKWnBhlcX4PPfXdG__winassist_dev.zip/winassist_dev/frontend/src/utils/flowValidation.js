const BUILT_IN_CONTEXT_KEYS = new Set([
  'apiError',
  'apiResponse',
  'apiResponseIndex',
  'apiResponses',
  'apiStatus',
  'botMessage',
  'branchMatched',
  'branchType',
  'conditionMatched',
  'formData',
  'lastDocument',
  'lastUserMessage',
  'matchedNodeId',
  'message',
  'response',
  'selectedDate',
  'selectedOption',
  'sessionId',
  'session_id',
  'userInput',
  'uploadedDocument',
  'lastOcrResult',
  'ocrSummary',
  'varEvents',
  'vars',
]);

function getNodeData(node) {
  return node?.data || {};
}

function getNodeLabel(node) {
  const data = getNodeData(node);
  return data.label || data.name || node?.label || node?.type || node?.id || 'node';
}

function normalizeValue(value) {
  return typeof value === 'string' ? value.trim() : value;
}

function collectProducedContextKeys(nodes) {
  const keys = new Set(BUILT_IN_CONTEXT_KEYS);

  nodes.forEach((node) => {
    const data = getNodeData(node);
    const type = node?.type;

    const storeAs = normalizeValue(data.storeAs || node.storeAs);
    if (storeAs) keys.add(storeAs);

    if (type === 'input') {
      const variableName = normalizeValue(data.variableName || node.variableName);
      if (variableName) keys.add(variableName);
    }

    if (type === 'calendar') {
      const variableName = normalizeValue(data.variableName || node.variableName);
      if (variableName) keys.add(variableName);
      keys.add('selectedDate');
    }

    if (type === 'form') {
      const variableName = normalizeValue(data.variableName || node.variableName);
      if (variableName) keys.add(variableName);
      keys.add('formData');
    }

    if (type === 'document') {
      const variableName = normalizeValue(data.variableName || node.variableName);
      if (variableName) keys.add(variableName);
      keys.add('lastDocument');
    }

    if (type === 'ocr') {
      const outputVariable = normalizeValue(data.outputVariable || node.outputVariable);
      if (outputVariable) keys.add(outputVariable);
      keys.add('lastOcrResult');
      keys.add('ocrSummary');
    }

    if (type === 'quickreply') {
      keys.add('selectedOption');
    }

    if (type === 'api') {
      const responseVariable = normalizeValue(data.responseVariable || node.responseVariable);
      if (responseVariable) keys.add(responseVariable);
      keys.add(`api_${node.id}`);
      keys.add('apiResponse');
      keys.add('apiResponses');
      keys.add('apiStatus');
      keys.add('apiError');
    }

    if (type === 'assistant') {
      const responseVariable = normalizeValue(data.responseVariable || node.responseVariable);
      if (responseVariable) keys.add(responseVariable);
      keys.add('response');
      keys.add(`assistant_${node.id}_response`);
    }
  });

  return keys;
}

function extractContextRefs(value) {
  if (typeof value !== 'string' || !value) return [];
  const refs = [];
  const regex = /\{\{context\.([^}]+)\}\}/g;
  let match;
  while ((match = regex.exec(value)) !== null) {
    const ref = String(match[1] || '').trim();
    if (ref) refs.push(ref);
  }
  return refs;
}

function addIssue(target, severity, code, message, meta = {}) {
  target.push({ severity, code, message, ...meta });
}

function looksLikeHardcodedSecret(value) {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!trimmed) return false;
  if (trimmed.includes('{{context.')) return false;
  if (/^Bearer\s+[A-Za-z0-9._-]{12,}$/i.test(trimmed)) return true;
  if (/^(sk-|pk_|xoxb-|AIza|ya29\.)/i.test(trimmed)) return true;
  return trimmed.length > 24 && /token|secret|key/i.test(trimmed);
}

function buildReachability(nodes, edges) {
  const incoming = new Set();
  const adjacency = new Map();
  nodes.forEach((node) => adjacency.set(node.id, []));
  edges.forEach((edge) => {
    if (!edge?.source || !edge?.target) return;
    incoming.add(edge.target);
    if (!adjacency.has(edge.source)) adjacency.set(edge.source, []);
    adjacency.get(edge.source).push(edge.target);
  });

  const entryNodes = nodes.filter((node) => node.type === 'initializer' || !incoming.has(node.id));
  const visited = new Set();

  const visit = (nodeId) => {
    if (!nodeId || visited.has(nodeId)) return;
    visited.add(nodeId);
    (adjacency.get(nodeId) || []).forEach(visit);
  };

  entryNodes.forEach((node) => visit(node.id));
  return visited;
}

export function validateFlow(nodes = [], edges = []) {
  const issues = [];
  const nodeIds = new Set(nodes.map((node) => node.id));
  const knownKeys = collectProducedContextKeys(nodes);

  if (!nodes.length) {
    addIssue(issues, 'error', 'flow.empty', 'Flow has no nodes.');
  }

  edges.forEach((edge) => {
    if (!nodeIds.has(edge.source)) {
      addIssue(issues, 'error', 'edge.missing_source', `Edge ${edge.id || '(no id)'} points to a missing source node.`, { edgeId: edge.id });
    }
    if (!nodeIds.has(edge.target)) {
      addIssue(issues, 'error', 'edge.missing_target', `Edge ${edge.id || '(no id)'} points to a missing target node.`, { edgeId: edge.id });
    }
  });

  nodes.forEach((node) => {
    const data = getNodeData(node);
    const label = getNodeLabel(node);
    const prefix = `${label} (${node.id})`;

    if (node.type === 'api') {
      const apiUrl = normalizeValue(data.apiUrl || node.apiUrl);
      if (!apiUrl) {
        addIssue(issues, 'error', 'api.missing_url', `${prefix}: API node is missing a URL.`, { nodeId: node.id });
      }

      const headers = Array.isArray(data.headers || node.headers) ? (data.headers || node.headers) : [];
      headers.forEach((header) => {
        const key = normalizeValue(header?.key);
        const value = normalizeValue(header?.value);
        if (!key) return;
        if (/^authorization$/i.test(key) && looksLikeHardcodedSecret(value)) {
          addIssue(
            issues,
            'warning',
            'api.inline_secret',
            `${prefix}: Authorization header appears to contain a hardcoded secret. Use a managed connection or context binding instead.`,
            { nodeId: node.id }
          );
        }
      });

      const refs = [
        ...extractContextRefs(apiUrl),
        ...headers.flatMap((header) => extractContextRefs(header?.value)),
        ...extractContextRefs(data.body || node.body || ''),
      ];
      refs.forEach((ref) => {
        const root = ref.split('.')[0];
        if (!knownKeys.has(root)) {
          addIssue(
            issues,
            'warning',
            'context.unresolved_reference',
            `${prefix}: Context reference "${ref}" may be unresolved at runtime.`,
            { nodeId: node.id }
          );
        }
      });
    }

    if (node.type === 'assistant') {
      const backendBotId = normalizeValue(node.backend_bot_id || data.backend_bot_id);
      const botApiKey = normalizeValue(node.bot_api_key || data.bot_api_key);
      if (backendBotId && !botApiKey) {
        addIssue(
          issues,
          'error',
          'assistant.missing_bot_key',
          `${prefix}: Connected backend bot is missing a bot API key.`,
          { nodeId: node.id }
        );
      }
    }

    if (node.type === 'condition') {
      const ifCondition = normalizeValue(data.ifCondition || node.ifCondition);
      if (!ifCondition) {
        addIssue(issues, 'error', 'condition.missing_if', `${prefix}: Condition node is missing its IF condition.`, { nodeId: node.id });
      }
      const elseIfConditions = Array.isArray(data.elseIfConditions || node.elseIfConditions)
        ? (data.elseIfConditions || node.elseIfConditions)
        : [];
      elseIfConditions.forEach((entry, index) => {
        if (!normalizeValue(entry?.condition)) {
          addIssue(
            issues,
            'error',
            'condition.empty_else_if',
            `${prefix}: ELSE IF ${index + 1} has no condition.`,
            { nodeId: node.id }
          );
        }
      });
    }

    if (node.type === 'branch') {
      const branchCondition = normalizeValue(data.condition || node.condition);
      if (!branchCondition) {
        addIssue(issues, 'warning', 'branch.missing_condition', `${prefix}: Branch node has no condition or label text configured.`, { nodeId: node.id });
      }
    }

    if (node.type === 'quickreply') {
      const options = Array.isArray(data.options || node.options) ? (data.options || node.options) : [];
      if (!options.length) {
        addIssue(issues, 'error', 'quickreply.missing_options', `${prefix}: Quick reply node has no options.`, { nodeId: node.id });
      }
    }

    if (node.type === 'form') {
      const fields = Array.isArray(data.fields || node.fields) ? (data.fields || node.fields) : [];
      const fieldKeys = new Set(fields.map((field) => normalizeValue(field?.key)).filter(Boolean));
      fields.forEach((field, index) => {
        const dependsOn = normalizeValue(field?.dependsOn);
        if (dependsOn && !fieldKeys.has(dependsOn)) {
          addIssue(
            issues,
            'warning',
            'form.invalid_dependency',
            `${prefix}: Field ${index + 1} depends on "${dependsOn}" which does not exist in this form schema.`,
            { nodeId: node.id }
          );
        }
      });
    }

    if (node.type === 'document') {
      const maxSizeMb = Number(data.maxSizeMb || node.maxSizeMb || 10);
      if (!Number.isFinite(maxSizeMb) || maxSizeMb <= 0) {
        addIssue(
          issues,
          'error',
          'document.invalid_max_size',
          `${prefix}: Document node has an invalid max file size.`,
          { nodeId: node.id }
        );
      }
    }

    if (node.type === 'ocr') {
      const sourceVariable = normalizeValue(data.sourceVariable || node.sourceVariable || 'lastDocument');
      const outputVariable = normalizeValue(data.outputVariable || node.outputVariable || 'ocrResult');
      if (!outputVariable) {
        addIssue(
          issues,
          'error',
          'ocr.missing_output_variable',
          `${prefix}: OCR node is missing an output variable.`,
          { nodeId: node.id }
        );
      }
      if (sourceVariable && !knownKeys.has(sourceVariable.split('.')[0])) {
        addIssue(
          issues,
          'warning',
          'ocr.unresolved_source_variable',
          `${prefix}: OCR source variable "${sourceVariable}" may be unresolved at runtime.`,
          { nodeId: node.id }
        );
      }
    }

    if (node.type === 'switch') {
      const switchOn = normalizeValue(data.switchOn || node.switchOn);
      const cases = Array.isArray(data.cases || node.cases) ? (data.cases || node.cases) : [];
      if (!switchOn) {
        addIssue(issues, 'error', 'switch.missing_expression', `${prefix}: Switch node is missing "switch on" expression.`, { nodeId: node.id });
      }
      if (!cases.length) {
        addIssue(issues, 'warning', 'switch.missing_cases', `${prefix}: Switch node has no cases configured.`, { nodeId: node.id });
      }
      cases.forEach((entry, index) => {
        if (!normalizeValue(entry?.value)) {
          addIssue(issues, 'error', 'switch.empty_case', `${prefix}: Case ${index + 1} has empty value.`, { nodeId: node.id });
        }
      });
    }
  });

  const reachableNodes = buildReachability(nodes, edges);
  nodes.forEach((node) => {
    if (!reachableNodes.has(node.id) && node.type !== 'note') {
      addIssue(
        issues,
        'warning',
        'flow.unreachable_node',
        `${getNodeLabel(node)} (${node.id}) is unreachable from any entry node.`,
        { nodeId: node.id }
      );
    }
  });

  const errors = issues.filter((issue) => issue.severity === 'error');
  const warnings = issues.filter((issue) => issue.severity === 'warning');

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    issues,
    summary: {
      total: issues.length,
      errors: errors.length,
      warnings: warnings.length,
    },
  };
}
