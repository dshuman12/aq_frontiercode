import './App.css'
import { useEffect, useRef } from 'react';

import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from 'react-oidc-context';
import { hasAuthParams } from 'react-oidc-context';
import HomePage from './shared/page/home'
import HomePageOidc from './shared/page/home-oidc'
import DashboardPage from './shared/page/dashboard'
import LoginPage from './components/shared/login'
import RegisterPage from './components/shared/register'
import ForgotPasswordPage from './components/shared/forgot-password'
import ResetPasswordPage from './components/shared/reset-password'
import ProjectsPage from './shared/page/project'
import ProjectResize from './shared/page/projectresize'
import ToolsPage from './shared/page/tools'
import Page from './shared/page/toolspage'
import NoCodeBackendListPage from './shared/page/nocodebackend-list'
import NoCodeFrontendListPage from './shared/page/nocodefrontend-list'
import NoCodeBackendCanvas from './shared/page/nocodebackend-canvas'
import NoCodeFrontendCanvas from './shared/page/nocodefrontend-canvas'
import ProjectDashboardPage from './shared/page/project-dashboard'
import WidgetPreviewPage from './shared/page/widget-preview'
import WidgetViewerPage from './shared/page/widget-viewer'
import WorkspaceInvitesPage from './shared/page/workspace-invites'
import AcceptInvitePage from './shared/page/accept-invite'
import ErrorBoundary from './components/shared/error-boundary'
import NotFoundPage from './shared/page/not-found'
import ChannelsPage from './shared/page/channels'
import TemplatesPage from './shared/page/templates'
import TemplatePreviewPage from './shared/page/template-preview'
import TemplateCanvasPreviewPage from './shared/page/template-canvas-preview'
import SettingsPage from './shared/page/settings'
import BillingPage from './shared/page/billing'
import HelpSupportPage from './shared/page/help-support'
import IntegrationsPage from './shared/page/integrations'
import WhatsAppSetupPage from './shared/page/whatsapp-setup'
import KnowledgeBasePage from './shared/page/knowledge-base'
import PublishCenterPage from './shared/page/publish-center'
import ContactsPage from './shared/page/contacts'
import CampaignsPage from './shared/page/campaigns'
import InboxPage from './shared/page/inbox'
import { ProtectedRoute, PublicRoute } from './components/shared/protected-route'
import { Toaster } from './components/ui/toaster'
import { ThemeToggle } from './components/shared/theme-toggle';
import useUserStore from './store/user';
import useWorkspaceStore from './store/workspace';
import { isOidcConfigured } from './common/oidc/oidc-Config';
import { DEFAULT_POST_LOGIN_PATH, getOidcReturnPath } from './common/oidc/navigation';

function OidcSessionSync() {
  const auth = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const setUser = useUserStore((state) => state.setUser);
  const setCurrentWorkspaceId = useWorkspaceStore((state) => state.setCurrentWorkspaceId);
  const appliedReturnPathRef = useRef(null);

  useEffect(() => {
    if (!auth?.isAuthenticated || !auth.user) return;

    const profile = auth.user.profile || {};
    const oidcUser = {
      id: profile.sub || auth.user.profile?.id || null,
      email: profile.email || '',
      first_name: profile.given_name || '',
      last_name: profile.family_name || '',
      name: profile.name || '',
      token: auth.user.access_token,
      auth_provider: 'keycloak',
    };
    setUser(oidcUser);
  }, [auth?.isAuthenticated, auth?.user, setUser]);

  useEffect(() => {
    if (!auth?.isAuthenticated || !auth.user) {
      appliedReturnPathRef.current = null;
      return;
    }

    const returnTo = getOidcReturnPath(auth.user);
    if (!returnTo || returnTo === DEFAULT_POST_LOGIN_PATH) return;

    const currentPath = `${location.pathname}${location.search}${location.hash}`;
    if (currentPath === returnTo) return;
    if (location.pathname !== DEFAULT_POST_LOGIN_PATH) return;
    if (appliedReturnPathRef.current === returnTo) return;

    appliedReturnPathRef.current = returnTo;
    navigate(returnTo, { replace: true });
  }, [
    auth?.isAuthenticated,
    auth?.user,
    location.hash,
    location.pathname,
    location.search,
    navigate,
  ]);

  useEffect(() => {
    if (!isOidcConfigured) return;
    if (!auth) return;
    if (auth.isLoading || auth.activeNavigator === 'signinRedirect' || hasAuthParams()) return;
    if (auth.isAuthenticated) return;

    setUser(null);
    setCurrentWorkspaceId(null);
  }, [
    auth,
    auth?.activeNavigator,
    auth?.isAuthenticated,
    auth?.isLoading,
    setCurrentWorkspaceId,
    setUser,
  ]);

  return null;
}

function App() {
  const location = useLocation();
  const showFloatingThemeToggle =
    location.pathname === '/' ||
    location.pathname.startsWith('/auth/') ||
    location.pathname.startsWith('/widget/') ||
    location.pathname === '/accept-invite';

  return (
    <ErrorBoundary>
      <OidcSessionSync />
      <div className="flex flex-col min-h-screen">
        {showFloatingThemeToggle ? (
          <div className="fixed right-4 top-4 z-50">
            <ThemeToggle className="bg-background/95 shadow-sm backdrop-blur" />
          </div>
        ) : null}
        <main className="flex-1">
          <Routes>
            <Route
              path="/"
              element={
                <PublicRoute>
                  {isOidcConfigured ? <HomePageOidc /> : <HomePage />}
                </PublicRoute>
              }
            />
            <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/project-dashboard" element={<ProtectedRoute><ProjectDashboardPage /></ProtectedRoute>} />
            <Route path="/widget-preview/:projectId" element={<ProtectedRoute><WidgetPreviewPage /></ProtectedRoute>} />
            <Route path="/widget/:projectId" element={<PublicRoute><WidgetViewerPage /></PublicRoute>} />
            <Route path="/auth/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
            <Route path="/auth/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />
            <Route path="/auth/forgot-password" element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
            <Route path="/auth/reset-password" element={<PublicRoute><ResetPasswordPage /></PublicRoute>} />
            <Route path="/projects" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
            <Route path="/projects/:id" element={<ProtectedRoute><ProjectResize /></ProtectedRoute>} />
            <Route path="/tools" element={<ProtectedRoute><ToolsPage /></ProtectedRoute>} />
            <Route path="/tools/:id" element={<ProtectedRoute><Page /></ProtectedRoute>} />
            <Route path="/aiagent" element={<ProtectedRoute><NoCodeBackendListPage /></ProtectedRoute>} />
            <Route path="/aiagent/:id" element={<ProtectedRoute><NoCodeBackendCanvas /></ProtectedRoute>} />
            <Route path="/chatflow" element={<ProtectedRoute><NoCodeFrontendListPage /></ProtectedRoute>} />
            <Route path="/chatflow/:id" element={<ProtectedRoute><NoCodeFrontendCanvas /></ProtectedRoute>} />
            <Route path="/channels" element={<ProtectedRoute><ChannelsPage /></ProtectedRoute>} />
            <Route path="/templates" element={<ProtectedRoute><TemplatesPage /></ProtectedRoute>} />
            <Route path="/templates/:id/preview" element={<ProtectedRoute><TemplatePreviewPage /></ProtectedRoute>} />
            <Route path="/templates/:id/canvas" element={<ProtectedRoute><TemplateCanvasPreviewPage /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
            <Route path="/billing" element={<ProtectedRoute><BillingPage /></ProtectedRoute>} />
            <Route path="/help-support" element={<ProtectedRoute><HelpSupportPage /></ProtectedRoute>} />
            <Route path="/contacts" element={<ProtectedRoute><ContactsPage /></ProtectedRoute>} />
            <Route path="/campaigns" element={<ProtectedRoute><CampaignsPage /></ProtectedRoute>} />
            <Route path="/inbox" element={<ProtectedRoute><InboxPage /></ProtectedRoute>} />
            <Route path="/integrations" element={<ProtectedRoute><IntegrationsPage /></ProtectedRoute>} />
            <Route path="/integrations/whatsapp" element={<ProtectedRoute><WhatsAppSetupPage /></ProtectedRoute>} />
            <Route path="/knowledge-base" element={<ProtectedRoute><KnowledgeBasePage /></ProtectedRoute>} />
            <Route path="/publish-center" element={<ProtectedRoute><PublishCenterPage /></ProtectedRoute>} />
            <Route path="/workspaces/invites" element={<ProtectedRoute><WorkspaceInvitesPage /></ProtectedRoute>} />
            <Route path="/accept-invite" element={<AcceptInvitePage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Toaster />
      </div>
    </ErrorBoundary>
  )
}

export default App
