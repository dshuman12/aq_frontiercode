// AI generated file
import React, { useState, useEffect } from 'react';
import { ScrollArea } from '../ui/scrollarea';
import { cn } from '../../lib/utils';
import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { GenericOption } from '../shared/option';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../lib/flow';
import { parseCurl } from '../../utils/curlParser';
import { toast } from '../../hooks/toast';

const API_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'];

export const ApiNodeConfig = React.memo(({ nodeId, data, className, ...props }) => {
  const instance = useReactFlow();
  const [parameters, setParameters] = useState(data?.parameters || []);
  const [headers, setHeaders] = useState(data?.headers || []);
  const [formData, setFormData] = useState(data?.formData || []);
  const [showCurlDialog, setShowCurlDialog] = useState(false);
  const [curlInput, setCurlInput] = useState('');
  const methodSupportsBody = ['POST', 'PUT', 'DELETE', 'PATCH'].includes(data?.apiMethod || 'GET');
  const bodyMode = data?.bodyMode || (data?.formData?.length ? 'formdata' : data?.fileBody ? 'file' : 'raw');

  useEffect(() => {
    setParameters(data?.parameters || []);
  }, [data?.parameters]);
  useEffect(() => {
    setHeaders(data?.headers || []);
  }, [data?.headers]);
  useEffect(() => {
    setFormData(data?.formData || []);
  }, [data?.formData]);

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  const handleAddParameter = () => {
    const newParams = [...parameters, { key: '', value: '' }];
    setParameters(newParams);
    updateNode({ parameters: newParams });
  };

  const handleUpdateParameter = (index, field, value) => {
    const newParams = [...parameters];
    newParams[index] = { ...newParams[index], [field]: value };
    setParameters(newParams);
    updateNode({ parameters: newParams });
  };

  const handleRemoveParameter = (index) => {
    const newParams = parameters.filter((_, i) => i !== index);
    setParameters(newParams);
    updateNode({ parameters: newParams });
  };

  const handleAddHeader = () => {
    const newHeaders = [...headers, { key: '', value: '' }];
    setHeaders(newHeaders);
    updateNode({ headers: newHeaders });
  };

  const handleUpdateHeader = (index, field, value) => {
    const newHeaders = [...headers];
    newHeaders[index] = { ...newHeaders[index], [field]: value };
    setHeaders(newHeaders);
    updateNode({ headers: newHeaders });
  };

  const handleRemoveHeader = (index) => {
    const newHeaders = headers.filter((_, i) => i !== index);
    setHeaders(newHeaders);
    updateNode({ headers: newHeaders });
  };

  const handlePasteCurl = () => {
    if (!curlInput.trim()) {
      toast({
        title: 'Error',
        description: 'Please paste a cURL command',
        variant: 'destructive',
      });
      return;
    }

    const parsed = parseCurl(curlInput);
    
    if (parsed.error) {
      toast({
        title: 'Parse Error',
        description: parsed.error,
        variant: 'destructive',
      });
      return;
    }

    // Update all fields with parsed data (including headers for Authorization, etc.)
    const updates = {
      apiMethod: parsed.method,
      apiUrl: parsed.url,
      body: parsed.body || '',
      bodyMode: parsed.body ? 'raw' : 'none',
      useBody: !!parsed.body,
    };

    if (parsed.parameters.length > 0) {
      setParameters(parsed.parameters);
      updates.parameters = parsed.parameters;
    }
    if (parsed.headers.length > 0) {
      setHeaders(parsed.headers);
      updates.headers = parsed.headers;
    }

    updateNode(updates);

    const headerCount = parsed.headers?.length || 0;
    toast({
      title: 'cURL Parsed Successfully',
      description: headerCount > 0
        ? `URL, method, body, and ${headerCount} header(s) (e.g. Authorization) have been applied.`
        : 'cURL command parsed and fields updated!',
    });

    setShowCurlDialog(false);
    setCurlInput('');
  };

  const handleAddFormData = () => {
    const nextFormData = [...formData, { key: '', value: '', type: 'text', contentType: '' }];
    setFormData(nextFormData);
    updateNode({ formData: nextFormData, bodyMode: 'formdata' });
  };

  const handleUpdateFormData = (index, field, value) => {
    const nextFormData = [...formData];
    nextFormData[index] = { ...nextFormData[index], [field]: value };
    setFormData(nextFormData);
    updateNode({ formData: nextFormData });
  };

  const handleRemoveFormData = (index) => {
    const nextFormData = formData.filter((_, i) => i !== index);
    setFormData(nextFormData);
    updateNode({ formData: nextFormData });
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        {(data?.presetSource === 'whatsapp_cloud_api' || data?.presetSource === 'winassist_whatsapp') && (
          <div className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
            <div className="font-medium text-foreground">
              {data?.presetSource === 'winassist_whatsapp' ? 'WinAssist WhatsApp preset' : 'WhatsApp Cloud API preset'}
            </div>
            <div className="mt-1">{data?.presetPath || data?.whatsappSection}</div>
          </div>
        )}

        {/* General Options */}
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="description"
          label="Description"
          placeholder="Enter description"
          rows={2}
        />

        {/* API Method */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>API Method</Label>
          <Select
            value={data?.apiMethod || 'GET'}
            onValueChange={(value) => updateNode({ apiMethod: value })}
          >
            <SelectTrigger className="bg-transparent w-full nodrag nowheel">
              <SelectValue placeholder="Select method" />
            </SelectTrigger>
            <SelectContent>
              {API_METHODS.map((method) => (
                <SelectItem key={method} value={method}>
                  {method}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* API URL */}
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>API URL</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowCurlDialog(true)}
              className="h-7 text-xs"
            >
              <Icons.add className="w-3 h-3 mr-1" />
              Paste cURL
            </Button>
          </div>
          <Input
            type="text"
            value={data?.apiUrl || ''}
            onChange={(e) => updateNode({ apiUrl: e.target.value })}
            placeholder="https://api.example.com/endpoint"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Use <code className="bg-muted px-1 rounded">{'{{context.variableName}}'}</code> in the URL to insert values from previous nodes (e.g. <code className="bg-muted px-1 rounded">/users/{'{{context.userId}}'}</code>).
          </p>
        </div>

        {/* Response Variable Name */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Response Variable Name</Label>
          <Input
            type="text"
            value={data?.responseVariable || ''}
            onChange={(e) => updateNode({ responseVariable: e.target.value })}
            placeholder="e.g., userData, productInfo, apiResult"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Store API response in this variable. Access it later using <code className="bg-muted px-1 rounded">{'{{context.variableName}}'}</code>
          </p>
        </div>

        {/* Optional: transform JSON before storing (e.g. pick one item from an array) */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Response transform (optional)</Label>
          <Textarea
            value={data?.responseTransform || ''}
            onChange={(e) => updateNode({ responseTransform: e.target.value.trim() === '' ? undefined : e.target.value })}
            placeholder={'Example: response.find((x) => x.id === context.userInput)\nLeave empty to keep the raw API JSON.'}
            rows={4}
            className="bg-transparent w-full nodrag nowheel font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">
            JavaScript expression assigned to <code className="bg-muted px-1 rounded">responseData</code>. The parsed body is{' '}
            <code className="bg-muted px-1 rounded">response</code>. Use{' '}
            <code className="bg-muted px-1 rounded">context</code> for values from earlier nodes (e.g. user input).
          </p>
        </div>

        {/* Request Headers (e.g. Authorization from cURL) */}
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>Request Headers</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={handleAddHeader}
              className="h-7"
            >
              <Icons.add className="w-3 h-3 mr-1" />
              Add Header
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            {headers.map((header, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  type="text"
                  placeholder="Header name (e.g. Authorization)"
                  value={header.key || ''}
                  onChange={(e) => handleUpdateHeader(index, 'key', e.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel"
                />
                <Input
                  type="text"
                  placeholder="Value (e.g. Bearer sk-...)"
                  value={header.value || ''}
                  onChange={(e) => handleUpdateHeader(index, 'value', e.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel font-mono text-xs"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleRemoveHeader(index)}
                  className="h-7 w-7 p-0"
                >
                  <Icons.trash className="w-3 h-3" />
                </Button>
              </div>
            ))}
            {headers.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                No headers. Paste a cURL with -H &quot;Authorization: Bearer ...&quot; or add manually.
              </p>
            )}
          </div>
        </div>

        {/* API Body (for POST, PUT, DELETE, PATCH) */}
        {methodSupportsBody && (
          <>
            <div className="flex flex-col gap-2 text-sm">
              <Label>Body Mode</Label>
              <Select
                value={bodyMode}
                onValueChange={(value) => updateNode({ bodyMode: value })}
              >
                <SelectTrigger className="bg-transparent w-full nodrag nowheel">
                  <SelectValue placeholder="Select body mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="raw">Raw JSON / text</SelectItem>
                  <SelectItem value="formdata">Multipart form-data</SelectItem>
                  <SelectItem value="file">Binary / file body</SelectItem>
                  <SelectItem value="none">No body</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {bodyMode === 'raw' && (
              <div className="flex flex-col gap-2 text-sm">
                <Label>Request Body</Label>
                <Textarea
                  value={data?.body || ''}
                  onChange={(e) => updateNode({ body: e.target.value, bodyMode: 'raw', useBody: true })}
                  placeholder="Enter JSON body or use {{context.variableName}} for dynamic values"
                  rows={6}
                  className="bg-transparent w-full nodrag nowheel font-mono text-xs"
                />
                <p className="text-xs text-muted-foreground">
                  Use <code className="bg-muted px-1 rounded">{'{{context.userInput}}'}</code> to insert user input,{' '}
                  <code className="bg-muted px-1 rounded">{'{{context.apiResponse}}'}</code> for latest API response, etc.
                </p>
                <div className="mt-2 p-2 bg-muted/50 rounded text-xs">
                  <p className="font-semibold mb-1">Tip</p>
                  <p className="text-muted-foreground">
                    Set a <strong>Response Variable Name</strong> above to store this API response in a named variable (e.g., <code className="bg-background px-1 rounded">userData</code>).
                  </p>
                  <p className="text-muted-foreground mt-1">
                    Then access it later using <code className="bg-background px-1 rounded">{'{{context.userData}}'}</code> or whatever name you chose.
                  </p>
                </div>
              </div>
            )}

            {bodyMode === 'formdata' && (
              <div className="flex flex-col gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <Label>Form Data Fields</Label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleAddFormData}
                    className="h-7"
                  >
                    <Icons.add className="w-3 h-3 mr-1" />
                    Add Field
                  </Button>
                </div>
                <div className="flex flex-col gap-2">
                  {formData.map((entry, index) => (
                    <div key={index} className="rounded-md border p-2 space-y-2">
                      <div className="grid grid-cols-1 gap-2 md:grid-cols-[1fr_1fr_140px_32px]">
                        <Input
                          type="text"
                          placeholder="Field name"
                          value={entry.key || ''}
                          onChange={(e) => handleUpdateFormData(index, 'key', e.target.value)}
                          className="bg-transparent nodrag nowheel"
                        />
                        <Input
                          type="text"
                          placeholder={entry.type === 'file' ? 'File placeholder or {{context.file}}' : 'Value'}
                          value={entry.value || ''}
                          onChange={(e) => handleUpdateFormData(index, 'value', e.target.value)}
                          className="bg-transparent nodrag nowheel"
                        />
                        <Select
                          value={entry.type || 'text'}
                          onValueChange={(value) => handleUpdateFormData(index, 'type', value)}
                        >
                          <SelectTrigger className="bg-transparent w-full nodrag nowheel">
                            <SelectValue placeholder="Type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="text">Text</SelectItem>
                            <SelectItem value="file">File</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveFormData(index)}
                          className="h-9 w-8 p-0"
                        >
                          <Icons.trash className="w-3 h-3" />
                        </Button>
                      </div>
                      <Input
                        type="text"
                        placeholder="Optional content type"
                        value={entry.contentType || ''}
                        onChange={(e) => handleUpdateFormData(index, 'contentType', e.target.value)}
                        className="bg-transparent nodrag nowheel"
                      />
                    </div>
                  ))}
                  {formData.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center py-2">
                      No form-data fields yet. Add the multipart fields required by this endpoint.
                    </p>
                  )}
                </div>
              </div>
            )}

            {bodyMode === 'file' && (
              <div className="flex flex-col gap-2 text-sm">
                <Label>Binary / File Body</Label>
                <Textarea
                  value={data?.fileBody || ''}
                  onChange={(e) => updateNode({ fileBody: e.target.value, bodyMode: 'file' })}
                  placeholder="Enter a file placeholder, URL, or {{context.fileBlob}}"
                  rows={4}
                  className="bg-transparent w-full nodrag nowheel font-mono text-xs"
                />
                <p className="text-xs text-muted-foreground">
                  Use a context value such as <code className="bg-muted px-1 rounded">{'{{context.fileBlob}}'}</code> if your runtime injects a Blob or File object.
                </p>
              </div>
            )}
          </>
        )}

        {/* Parameters */}
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>Query Parameters</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={handleAddParameter}
              className="h-7"
            >
              <Icons.add className="w-3 h-3 mr-1" />
              Add Parameter
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            {parameters.map((param, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  type="text"
                  placeholder="Key"
                  value={param.key || ''}
                  onChange={(e) => handleUpdateParameter(index, 'key', e.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel"
                />
                <Input
                  type="text"
                  placeholder="Value"
                  value={param.value || ''}
                  onChange={(e) => handleUpdateParameter(index, 'value', e.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleRemoveParameter(index)}
                  className="h-7 w-7 p-0"
                >
                  <Icons.trash className="w-3 h-3" />
                </Button>
              </div>
            ))}
            {parameters.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                No parameters added. Click "Add Parameter" to add one.
              </p>
            )}
          </div>
        </div>

        {/* cURL Paste Dialog */}
        <Dialog open={showCurlDialog} onOpenChange={setShowCurlDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Paste cURL Command</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col gap-4 py-4">
              <div className="flex flex-col gap-2">
                <Label>Paste your cURL command here:</Label>
                <Textarea
                  value={curlInput}
                  onChange={(e) => setCurlInput(e.target.value)}
                  placeholder={'curl -X POST https://api.example.com/endpoint -H "Content-Type: application/json" -d \'{"key":"value"}\''}
                  rows={8}
                  className="font-mono text-xs"
                />
              </div>
              <div className="text-xs text-muted-foreground">
                <p className="font-semibold mb-1">Supported cURL features:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>HTTP methods (GET, POST, PUT, DELETE, PATCH)</li>
                  <li>URLs with query parameters</li>
                  <li>Headers (-H or --header)</li>
                  <li>Request body (-d, --data, --data-raw)</li>
                  <li>Form data (-F or --form)</li>
                </ul>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setShowCurlDialog(false);
                setCurlInput('');
              }}>
                Cancel
              </Button>
              <Button onClick={handlePasteCurl}>
                Parse & Apply
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </ScrollArea>
  );
});

ApiNodeConfig.displayName = 'ApiNodeConfig';

