import { memo } from 'react';
import { GenericNode } from '../shared/generic-node';

const ApiNode = memo(function ApiNode(props) {
  const { data } = props;

  const method = data.apiMethod || 'GET';
  const url = data.apiUrl || 'No URL';
  const responseVariable = data.responseVariable || 'apiResponse';
  const ports = [
    { type: 'target', name: 'in' },
    { type: 'source', name: 'out' },
  ];

  return (
    <GenericNode
      {...props}
      ports={ports}
      data={{
        ...data,
        id: data.id || 'api',
        name: data.name || data.label || 'API',
      }}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            {method}
          </div>
          <div className="mt-1 break-words text-xs font-medium text-foreground">
            {url}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Variable
          </div>
          <div className="mt-1 break-words text-xs font-medium text-foreground">
            {responseVariable}
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

export default ApiNode;