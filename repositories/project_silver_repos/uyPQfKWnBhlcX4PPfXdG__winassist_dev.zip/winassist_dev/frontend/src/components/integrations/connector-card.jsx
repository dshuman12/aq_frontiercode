import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

function titleCaseLabel(value) {
  return String(value || '')
    .split('_')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

export function ConnectorCard({ connector, connectedCount = 0, onOpenSetup }) {
  const capabilities = Object.entries(connector?.capabilities || {})
    .filter(([, enabled]) => Boolean(enabled))
    .map(([key]) => key)
    .slice(0, 6);

  return (
    <Card className="flex flex-col border-border/80 shadow-sm">
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 pb-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            {connector?.icon_url ? (
              <img
                src={connector.icon_url}
                alt=""
                className="h-7 w-7 object-contain"
                loading="lazy"
                decoding="async"
              />
            ) : (
              <span className="text-sm font-semibold">{String(connector?.display_name || '?').slice(0, 1)}</span>
            )}
          </div>
          <div className="min-w-0">
            <CardTitle className="text-base">{connector?.display_name || 'Connector'}</CardTitle>
            <CardDescription className="mt-1 line-clamp-2">
              {connector?.description || 'Reusable connector definition'}
            </CardDescription>
          </div>
        </div>
        <Badge variant="outline">{connectedCount} connected</Badge>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4 pt-0">
        <div className="flex flex-wrap gap-2">
          {capabilities.map((capability) => (
            <Badge key={capability} variant="secondary">
              {titleCaseLabel(capability)}
            </Badge>
          ))}
        </div>
        <div className="mt-auto flex flex-wrap gap-2">
          <Button size="sm" onClick={onOpenSetup}>
            Open connector
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
