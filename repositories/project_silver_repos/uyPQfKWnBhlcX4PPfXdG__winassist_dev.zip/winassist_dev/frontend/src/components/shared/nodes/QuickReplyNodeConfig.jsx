
import React, { useState, useEffect } from 'react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { Button } from '../../ui/button';
import { Icons } from '../../ui/icons';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../../lib/flow';

export const QuickReplyNodeConfig = React.memo(({ nodeId, data, className, ...props }) => {
  const instance = useReactFlow();
  const [message, setMessage] = useState(data?.message || '');
  const [options, setOptions] = useState(data?.options || []);
  const [variableKey, setVariableKey] = useState(data?.variableKey ?? data?.storeAs ?? '');

  useEffect(() => {
    setMessage(data?.message || '');
    setOptions(data?.options || []);
    setVariableKey(data?.variableKey ?? data?.storeAs ?? '');
  }, [data?.message, data?.options, data?.variableKey, data?.storeAs]);

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
    // Don't auto-update node size - let user control it manually
  };

  const handleAddOption = () => {
    const newOptions = [...options, { text: '', value: '' }];
    setOptions(newOptions);
    updateNode({ options: newOptions });
  };

  const handleUpdateOption = (index, field, value) => {
    const newOptions = [...options];
    if (!newOptions[index]) {
      newOptions[index] = { text: '', value: '' };
    }
    newOptions[index][field] = value;
    // If text is updated, also update value
    if (field === 'text') {
      newOptions[index].value = value;
    }
    setOptions(newOptions);
    updateNode({ options: newOptions });
  };

  const handleRemoveOption = (index) => {
    const newOptions = options.filter((_, i) => i !== index);
    setOptions(newOptions);
    updateNode({ options: newOptions });

    // Remap edges: when an option is deleted, handles reindex.
    // option-i is removed; options after it shift down by 1.
    const edges = instance.getEdges();
    const remapped = [];
    for (const edge of edges) {
      if (edge.source !== nodeId || !edge.sourceHandle?.startsWith('option-')) {
        remapped.push(edge);
        continue;
      }
      const hi = parseInt(edge.sourceHandle.split('-')[1], 10);
      if (isNaN(hi)) { remapped.push(edge); continue; }
      if (hi === index) continue;
      if (hi > index) {
        remapped.push({ ...edge, sourceHandle: `option-${hi - 1}` });
      } else {
        remapped.push(edge);
      }
    }
    instance.setEdges(remapped);
  };

  const handleMessageChange = (value) => {
    setMessage(value);
    updateNode({ message: value });
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        {/* General Options */}
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="Quick Reply"
        />

        {/* Variable key: store selection for use in API body (e.g. {{context.plan_type}}) */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Store as (variable key)</Label>
          <Input
            type="text"
            value={variableKey}
            onChange={(e) => {
              const v = e.target.value.trim();
              setVariableKey(e.target.value);
              updateNode({ variableKey: v || undefined, storeAs: v || undefined });
            }}
            placeholder="e.g. plan_type (use in API body as {{context.plan_type}})"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Optional. Stored for the session so you can use it in a later API node body, e.g. {`{{context.plan_type}}`} or {`{{context.quickReplySelections.<nodeId>.option_text}}`}.
          </p>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Variable namespace</Label>
          <Input
            type="text"
            value={data?.storeNamespace || 'user'}
            onChange={(e) => updateNode({ storeNamespace: e.target.value || 'user' })}
            placeholder="user / bot / api / flow"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Store mode</Label>
          <select
            value={data?.storeMode || 'replace'}
            onChange={(e) => updateNode({ storeMode: e.target.value })}
            className="bg-transparent w-full nodrag nowheel rounded-md border border-input px-3 py-2 text-sm"
          >
            <option value="replace">Replace</option>
            <option value="append">Append</option>
            <option value="first_write">First write only</option>
          </select>
        </div>

        {/* Message */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Message</Label>
          <Textarea
            value={message}
            onChange={(e) => handleMessageChange(e.target.value)}
            placeholder="Enter the message/question to show to the user..."
            rows={3}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        {/* Quick Reply Options */}
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>Quick Reply Options</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={handleAddOption}
              className="h-7"
            >
              <Icons.add className="w-3 h-3 mr-1" />
              Add Option
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            {options.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  type="text"
                  placeholder={`Option ${index + 1} text`}
                  value={option.text || ''}
                  onChange={(e) => handleUpdateOption(index, 'text', e.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleRemoveOption(index)}
                  className="h-7 w-7 p-0"
                >
                  <Icons.trash className="w-3 h-3" />
                </Button>
              </div>
            ))}
            {options.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                No options added. Click "Add Option" to add one.
              </p>
            )}
          </div>
        </div>
      </div>
    </ScrollArea>
  );
});

QuickReplyNodeConfig.displayName = 'QuickReplyNodeConfig';

