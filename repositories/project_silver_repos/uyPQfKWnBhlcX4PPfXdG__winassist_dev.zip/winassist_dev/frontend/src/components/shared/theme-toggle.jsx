import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';
import useThemeStore, { THEMES } from '../../store/theme';

export function ThemeToggle({ className, compact = false }) {
  const theme = useThemeStore((state) => state.theme);
  const toggleTheme = useThemeStore((state) => state.toggleTheme);
  const isDark = theme === THEMES.DARK;
  const Icon = isDark ? Icons.sun : Icons.moon;
  const label = isDark ? 'Light mode' : 'Dark mode';

  return (
    <Button
      type="button"
      variant="outline"
      size={compact ? 'icon' : 'sm'}
      className={cn(
        compact ? 'group h-10 w-10 rounded-xl border-border/70' : 'group h-10 rounded-xl border-border/70 px-3',
        className
      )}
      onClick={toggleTheme}
      title={`Switch to ${label.toLowerCase()}`}
      aria-label={`Switch to ${label.toLowerCase()}`}
    >
      <Icon className="h-4 w-4 transition-transform duration-300 ease-out group-hover:rotate-12" />
      {!compact ? <span>{label}</span> : null}
    </Button>
  );
}
