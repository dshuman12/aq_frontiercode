import { memo } from 'react';
import { GenericNode } from '../generic-node';

const OcrNode = memo(({ id, data, selected, width, height, ...props }) => {
  const sourceVariable = data?.sourceVariable || 'lastDocument';
  const outputVariable = data?.outputVariable || 'ocrResult';
  const documentType = data?.documentType || 'auto';

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data?.id || 'ocr',
        name: data?.name || data?.label || 'OCR Extract',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Source
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {sourceVariable}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Document Type
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {documentType === 'auto' ? 'Auto detect' : documentType}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Output
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {outputVariable}
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

OcrNode.displayName = 'OcrNode';

export default OcrNode;
