import { useState, useMemo } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from '../../hooks/toast';
import useUserStore from '../../store/user';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../ui/icons';
import { WINASSIST_LOGO_URL } from '../../lib/config';
import { resolvePostLoginPath } from '../../common/oidc/navigation';

const PASSWORD_RULES = [
  { id: 'length', label: 'At least 8 characters', test: (p) => p.length >= 8 },
  { id: 'lower', label: 'One lowercase letter', test: (p) => /[a-z]/.test(p) },
  { id: 'upper', label: 'One uppercase letter', test: (p) => /[A-Z]/.test(p) },
  { id: 'number', label: 'One number', test: (p) => /\d/.test(p) },
  { id: 'special', label: 'One special character (!@#$%^&* etc.)', test: (p) => /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(p) },
];

function getPasswordErrors(password) {
  return PASSWORD_RULES.filter((r) => !r.test(password)).map((r) => r.label);
}

export default function RegisterPage() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [userName, setUserName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirectTo = searchParams.get('redirect');
  const setUser = useUserStore((state) => state.setUser);

  const passwordChecks = useMemo(() => {
    return PASSWORD_RULES.map((rule) => ({
      ...rule,
      passed: rule.test(password),
    }));
  }, [password]);

  const isPasswordValid = useMemo(() => passwordChecks.every((c) => c.passed), [passwordChecks]);

  const handleRegister = async (e) => {
    e.preventDefault();
    const errors = getPasswordErrors(password);
    if (errors.length > 0) {
      toast({
        title: 'Password does not meet requirements',
        description: errors.join('. '),
        variant: 'destructive',
      });
      return;
    }
    setLoading(true);

    try {
      const data = await apiRequest('/auth/register', {
        method: 'POST',
        body: {
          email,
          password,
          first_name: firstName.trim() || undefined,
          last_name: lastName.trim() || undefined,
          user_name: userName.trim() || undefined,
          company_name: companyName.trim() || undefined,
          mobile_number: mobileNumber.trim() || undefined,
        },
        credentials: 'include',
        showErrorToast: false,
      });

      setUser({ ...data.user, token: data.token });
      toast({ title: 'Account created successfully' });
      navigate(resolvePostLoginPath(redirectTo), { replace: true });
    } catch (err) {
      toast({ 
        title: 'Registration failed', 
        description: err.message || 'Failed to create account', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain rounded-xl shrink-0" />
            <span className="text-2xl font-bold text-foreground">WinAssist</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Start building today
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Create your free account and start building AI-powered applications in minutes.
          </p>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Icons.check className="w-4 h-4 text-primary" />
              </div>
              <span className="text-foreground">No credit card required</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Icons.check className="w-4 h-4 text-primary" />
              </div>
              <span className="text-foreground">Free tier available</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Icons.check className="w-4 h-4 text-primary" />
              </div>
              <span className="text-foreground">Unlimited projects</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Register Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-2 mb-8 justify-center">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-10 h-10 object-contain rounded-lg shrink-0" />
            <span className="text-xl font-bold text-foreground">WinAssist</span>
          </div>

          <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground">Create account</h2>
              <p className="text-muted-foreground mt-2">Enter your details to get started</p>
            </div>

            <form onSubmit={handleRegister} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-foreground">First name</Label>
                  <div className="relative">
                    <Icons.user className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="firstName"
                      type="text"
                      placeholder="John"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className="pl-10 h-11"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-foreground">Last name</Label>
                  <div className="relative">
                    <Icons.user className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="lastName"
                      type="text"
                      placeholder="Doe"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      className="pl-10 h-11"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="userName" className="text-foreground">User name</Label>
                <div className="relative">
                  <Icons.user className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="userName"
                    type="text"
                    placeholder="john_doe"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="pl-10 h-11"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="companyName" className="text-foreground">Company name</Label>
                <div className="relative">
                  <Icons.compass className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="companyName"
                    type="text"
                    placeholder="Acme Inc."
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="pl-10 h-11"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobileNumber" className="text-foreground">Mobile number</Label>
                <div className="relative">
                  <Icons.phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="mobileNumber"
                    type="tel"
                    placeholder="+1 234 567 8900"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="pl-10 h-11"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <div className="relative">
                  <Icons.mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-11"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="text-foreground">Password</Label>
                <div className="relative">
                  <Icons.lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-11"
                    required
                    minLength={8}
                    aria-invalid={password.length > 0 && !isPasswordValid}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? (
                      <Icons.eyeOff className="w-5 h-5" />
                    ) : (
                      <Icons.eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mb-1.5">Password must include:</p>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  {passwordChecks.map(({ id, label, passed }) => (
                    <li key={id} className="flex items-center gap-2">
                      {passed ? (
                        <Icons.check className="w-3.5 h-3.5 text-green-600 shrink-0" />
                      ) : (
                        <span className="w-3.5 h-3.5 rounded-full border border-current shrink-0" aria-hidden />
                      )}
                      <span className={passed ? 'text-green-700 dark:text-green-400' : ''}>{label}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Button type="submit" className="w-full h-11" disabled={loading}>
                {loading ? (
                  <>
                    <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  'Create account'
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-muted-foreground">
              Already have an account?{' '}
              <Link to={redirectTo ? `/auth/login?redirect=${encodeURIComponent(redirectTo)}` : '/auth/login'} className="text-primary font-medium hover:underline">
                Sign in
              </Link>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
