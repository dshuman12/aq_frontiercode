import React, { useState } from 'react'
import clsx from 'clsx'
import { Label } from '../ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select'

export const SelectOption = ({
  data,
  label,
  placeholder,
  name,
  options = [],
  onValueChange,
  compact = false,
}) => {
  const [value, setValue] = useState(data?.[name] ?? '')

  const handleValueChange = (newValue) => {
    setValue(newValue)
    if (onValueChange) {
      onValueChange(name, newValue)
    }
  }

  return (
    <div
      className={clsx('flex text-sm', {
        'flex-col gap-2': !compact,
        'items-center gap-2': compact,
      })}
    >
      <Label className="whitespace-nowrap">{label}</Label>

      <Select value={value} onValueChange={handleValueChange}>
        <SelectTrigger className="w-full nodrag">
          <SelectValue placeholder={placeholder || 'Select an option'} />
        </SelectTrigger>
        <SelectContent>
          {options.map((option, index) => (
            <SelectItem key={index} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

