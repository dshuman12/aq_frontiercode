import React from 'react';
import { useReactFlow } from '@xyflow/react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../ui/select';
import { setNodeData } from '../../../lib/flow';

export const OcrNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="OCR Extract"
        />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Source Variable</Label>
          <Input
            type="text"
            value={data?.sourceVariable || 'lastDocument'}
            onChange={(event) => updateNode({ sourceVariable: event.target.value.trim() || 'lastDocument' })}
            placeholder="lastDocument"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Usually use <code>lastDocument</code> or the variable name from your document upload node.
          </p>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Document Type</Label>
          <Select
            value={data?.documentType || 'auto'}
            onValueChange={(value) => updateNode({ documentType: value })}
          >
            <SelectTrigger className="bg-transparent w-full nodrag nowheel">
              <SelectValue placeholder="Choose document type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto detect</SelectItem>
              <SelectItem value="aadhaar">Aadhaar</SelectItem>
              <SelectItem value="pan">PAN</SelectItem>
              <SelectItem value="driving_licence">Driving Licence</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Store Result As</Label>
          <Input
            type="text"
            value={data?.outputVariable || 'ocrResult'}
            onChange={(event) => updateNode({ outputVariable: event.target.value.trim() || 'ocrResult' })}
            placeholder="ocrResult"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Processing Message</Label>
          <Textarea
            value={data?.processingMessage || ''}
            onChange={(event) => updateNode({ processingMessage: event.target.value })}
            placeholder="Processing your uploaded document..."
            rows={2}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Success Message</Label>
          <Textarea
            value={data?.successMessage || ''}
            onChange={(event) => updateNode({ successMessage: event.target.value })}
            placeholder="Document details extracted successfully."
            rows={2}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>
      </div>
    </ScrollArea>
  );
});

OcrNodeConfig.displayName = 'OcrNodeConfig';
