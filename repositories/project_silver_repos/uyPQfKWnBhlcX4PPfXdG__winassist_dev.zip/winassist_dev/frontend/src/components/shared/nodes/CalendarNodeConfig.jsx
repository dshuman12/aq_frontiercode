import React, { useEffect, useMemo, useState } from 'react';
import { useReactFlow } from '@xyflow/react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { Button } from '../../ui/button';
import { Icons } from '../../ui/icons';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../ui/select';
import { setNodeData } from '../../../lib/flow';

export const CalendarNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();
  const [calendarOptions, setCalendarOptions] = useState([]);

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  const selectionType = data?.selectionType || 'date';
  const dateInputType = selectionType === 'datetime' ? 'datetime-local' : 'date';
  const defaultValue = useMemo(() => {
    const now = new Date();
    const pad = (num) => String(num).padStart(2, '0');
    return selectionType === 'datetime'
      ? `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`
      : `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  }, [selectionType]);

  const normalizedOptions = useMemo(() => {
    if (!Array.isArray(data?.calendarOptions)) return [];
    return data.calendarOptions.map((option) => {
      const value = typeof option === 'string' ? option : option?.value;
      return { value: value || '' };
    });
  }, [data?.calendarOptions]);

  useEffect(() => {
    // If the user has added rows but left them empty, the widget runtime ignores empty values.
    // Auto-fill empties so the preview shows the configured number of date options.
    const hasEmpty = normalizedOptions.some((o) => !o?.value);
    if (!hasEmpty) {
      setCalendarOptions(normalizedOptions);
      return;
    }

    const updated = normalizedOptions.map((o) => (o?.value ? o : { ...o, value: defaultValue }));
    setCalendarOptions(updated);
    updateNode({ calendarOptions: updated });
  }, [normalizedOptions, defaultValue]);

  const handleAddDateOption = () => {
    const updated = [...calendarOptions, { value: defaultValue }];
    setCalendarOptions(updated);
    updateNode({ calendarOptions: updated });
  };

  const handleUpdateDateOption = (index, value) => {
    const updated = [...calendarOptions];
    if (!updated[index]) {
      updated[index] = { value: '' };
    }
    updated[index].value = value;
    setCalendarOptions(updated);
    updateNode({ calendarOptions: updated });
  };

  const handleRemoveDateOption = (index) => {
    const updated = calendarOptions.filter((_, optionIndex) => optionIndex !== index);
    setCalendarOptions(updated);
    updateNode({ calendarOptions: updated });
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="Calendar"
        />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Variable Name</Label>
          <Input
            type="text"
            value={data?.variableName || ''}
            onChange={(event) => updateNode({ variableName: event.target.value })}
            placeholder="e.g., appointmentDate"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            The selected value is stored in <code className="bg-muted px-1 rounded">{'{{context.variableName}}'}</code> and is also reused as flow memory.
          </p>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Prompt Text</Label>
          <Textarea
            value={data?.prompt || ''}
            onChange={(event) => updateNode({ prompt: event.target.value })}
            placeholder="Ask the user to pick a date or appointment slot..."
            rows={3}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Selection Type</Label>
          <Select
            value={selectionType}
            onValueChange={(value) => updateNode({ selectionType: value })}
          >
            <SelectTrigger className="bg-transparent w-full nodrag nowheel">
              <SelectValue placeholder="Choose selection type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="datetime">Date &amp; Time</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>Date Options</Label>
            <Button
              size="sm"
              variant="outline"
              onClick={handleAddDateOption}
              className="h-7"
            >
              <Icons.add className="w-3 h-3 mr-1" />
              Add Date
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            {calendarOptions.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  type={dateInputType}
                  value={option.value || ''}
                  onChange={(event) => handleUpdateDateOption(index, event.target.value)}
                  className="bg-transparent flex-1 nodrag nowheel"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleRemoveDateOption(index)}
                  className="h-7 w-7 p-0"
                >
                  <Icons.trash className="w-3 h-3" />
                </Button>
              </div>
            ))}
            {calendarOptions.length === 0 && (
              <p className="text-xs text-muted-foreground">
                No date options added. Click "Add Date" to add as many as needed.
              </p>
            )}
            {calendarOptions.length > 0 && (
              <p className="text-xs text-muted-foreground">
                Empty date rows are ignored in the widget preview.
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Confirm Button Label</Label>
          <Input
            type="text"
            value={data?.confirmLabel || ''}
            onChange={(event) => updateNode({ confirmLabel: event.target.value })}
            placeholder="Confirm"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>
      </div>
    </ScrollArea>
  );
});

CalendarNodeConfig.displayName = 'CalendarNodeConfig';
