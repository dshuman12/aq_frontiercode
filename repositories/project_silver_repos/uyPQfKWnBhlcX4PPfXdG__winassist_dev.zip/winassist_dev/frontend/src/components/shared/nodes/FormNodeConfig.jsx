import React, { useEffect, useMemo, useState } from 'react';
import { useReactFlow } from '@xyflow/react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { setNodeData } from '../../../lib/flow';

const DEFAULT_FIELDS = [
  {
    key: 'category',
    label: 'Category',
    type: 'select',
    required: true,
    options: ['Milk', 'Water'],
  },
  {
    key: 'product',
    label: 'Product',
    type: 'select',
    required: true,
    dependsOn: 'category',
    optionsByValue: {
      Milk: ['Buffalo Milk', 'Cow Milk'],
      Water: ['Coconut Water', 'Mineral Water'],
      '*': [],
    },
  },
  { key: 'quantity', label: 'Quantity', type: 'quantity', required: true, min: 1, max: 20, defaultValue: 1 },
  { key: 'start_date', label: 'Start date', type: 'date', required: true },
];

const toPrettyJson = (value) => JSON.stringify(value, null, 2);

export const FormNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();

  const initialFields = useMemo(() => {
    if (Array.isArray(data?.fields) && data.fields.length > 0) {
      return data.fields;
    }
    return DEFAULT_FIELDS;
  }, [data?.fields]);

  const [fieldsJson, setFieldsJson] = useState(toPrettyJson(initialFields));
  const [error, setError] = useState('');

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  const applyFields = (value) => {
    setFieldsJson(value);
    try {
      const parsed = JSON.parse(value);
      if (!Array.isArray(parsed)) {
        setError('Fields JSON must be an array');
        return;
      }
      setError('');
      updateNode({ fields: parsed });
    } catch (parseError) {
      setError('Invalid JSON format');
    }
  };

  useEffect(() => {
    if (Array.isArray(data?.fields) && data.fields.length > 0) {
      const next = toPrettyJson(data.fields);
      if (next !== fieldsJson) {
        setFieldsJson(next);
      }
      return;
    }

    // Ensure default schema is persisted to node data so runtime can render it.
    updateNode({ fields: DEFAULT_FIELDS });
    const defaults = toPrettyJson(DEFAULT_FIELDS);
    if (defaults !== fieldsJson) {
      setFieldsJson(defaults);
    }
  }, [data?.fields, nodeId]);

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="Form"
        />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Store As (context key)</Label>
          <Input
            type="text"
            value={data?.variableName || 'formData'}
            onChange={(event) => updateNode({ variableName: event.target.value.trim() || 'formData' })}
            placeholder="formData"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Prompt Text</Label>
          <Textarea
            value={data?.prompt || ''}
            onChange={(event) => updateNode({ prompt: event.target.value })}
            placeholder="Please fill details below"
            rows={3}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Submit Button Label</Label>
          <Input
            type="text"
            value={data?.submitLabel || 'Continue'}
            onChange={(event) => updateNode({ submitLabel: event.target.value || 'Continue' })}
            placeholder="Continue"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Fields Schema (JSON Array)</Label>
          <Textarea
            value={fieldsJson}
            onChange={(event) => applyFields(event.target.value)}
            rows={14}
            className="bg-transparent w-full nodrag nowheel font-mono text-xs"
          />
          {error ? (
            <p className="text-xs text-red-500">{error}</p>
          ) : (
            <p className="text-xs text-muted-foreground">
              Supported types: <code>text</code>, <code>textarea</code>, <code>number</code>, <code>quantity</code>, <code>date</code>, <code>datetime</code>, <code>select</code>. For dependent selects use <code>dependsOn</code> and <code>optionsByValue</code>.
            </p>
          )}
        </div>
      </div>
    </ScrollArea>
  );
});

FormNodeConfig.displayName = 'FormNodeConfig';
