
import { memo, useMemo } from 'react';
import { Position } from '@xyflow/react';
import { cn } from '../../../lib/utils';
import { DEFAULT_NODE_COLOR } from '../../../lib/flow';
import { GenericNode } from '../generic-node';

const ROW_HEIGHT = 28;
const ROW_GAP = 4;
const HEADER_HEIGHT = 40;
const CONTENT_PADDING_TOP = 10;
const CONTENT_PADDING_BOTTOM = 14;

const ContainerNode = memo(({ id, data, selected, width, height }) => {
  const { color = DEFAULT_NODE_COLOR, isEdgeSource } = data;

  const { handles, computedHeight } = useMemo(() => {
    const options = data?.options && Array.isArray(data.options) ? data.options : [];
    const count = Math.max(1, options.length);
    const contentHeight = count * ROW_HEIGHT + (count - 1) * ROW_GAP;
    const totalHeight = HEADER_HEIGHT + CONTENT_PADDING_TOP + contentHeight + CONTENT_PADDING_BOTTOM;
    const truncate = (s, max = 24) => (String(s || '').length > max ? String(s).slice(0, max) + '…' : String(s || ''));
    const sourceHandles = [];
    for (let i = 0; i < count; i++) {
      const rowCenterY = HEADER_HEIGHT + CONTENT_PADDING_TOP + i * (ROW_HEIGHT + ROW_GAP) + ROW_HEIGHT / 2;
      const topPct = (rowCenterY / totalHeight) * 100;
      const opt = options[i];
      const text = opt?.text || opt?.value || opt?.label;
      sourceHandles.push({
        type: 'source', id: `option-${i}`, position: Position.Right, style: { top: `${topPct}%` }, className: '!border-blue-500',
        label: text ? truncate(text) : `Option ${i + 1}`,
      });
    }
    return {
      handles: [
        { type: 'target', id: 'input', position: Position.Left, style: { top: '50%' }, className: '!border-green-500' },
        ...sourceHandles,
      ],
      computedHeight: totalHeight,
    };
  }, [data?.options]);

  return (
    <GenericNode
      id={id}
      data={data}
      selected={selected}
      width={width}
      height={computedHeight}
      minWidth={190}
      minHeight={computedHeight}
      handles={handles}
      resizerColor={color}
      className={cn(
        'rounded-lg border-2 bg-background shadow-sm transition-all overflow-visible',
        selected && 'ring-2 ring-primary/30 shadow-md',
        isEdgeSource && 'ring-4 ring-green-500/50'
      )}
    />
  );
});

ContainerNode.displayName = 'ContainerNode';

export default ContainerNode;
