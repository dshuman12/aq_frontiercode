import { memo } from 'react';
import { GenericNode } from '../generic-node';

const AssistantNode = memo(({ id, data, selected, width, height, ...props }) => {
  const botName = data.bot_name || data.backend_bot_id || 'Not connected';

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data.id || 'assistant',
        name: data.name || data.label || 'Assistant',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Mode
          </div>
          <div className="mt-1 text-xs font-medium text-foreground">
            Assistant response
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Bot
          </div>
          <div className="mt-1 break-words text-xs font-medium text-foreground">
            {botName}
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

AssistantNode.displayName = 'AssistantNode';

export default AssistantNode;

