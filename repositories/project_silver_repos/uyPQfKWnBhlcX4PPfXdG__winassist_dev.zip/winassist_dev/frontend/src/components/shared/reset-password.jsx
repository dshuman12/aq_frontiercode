import { useState, useMemo } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from '../../hooks/toast';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../ui/icons';
import { WINASSIST_LOGO_URL } from '../../lib/config';

const PASSWORD_RULES = [
  { id: 'length', label: 'At least 8 characters', test: (p) => p.length >= 8 },
  { id: 'lower', label: 'One lowercase letter', test: (p) => /[a-z]/.test(p) },
  { id: 'upper', label: 'One uppercase letter', test: (p) => /[A-Z]/.test(p) },
  { id: 'number', label: 'One number', test: (p) => /\d/.test(p) },
  { id: 'special', label: 'One special character (!@#$%^&* etc.)', test: (p) => /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(p) },
];

function getPasswordErrors(password) {
  return PASSWORD_RULES.filter((r) => !r.test(password)).map((r) => r.label);
}

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token') || '';
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const passwordChecks = useMemo(() => {
    return PASSWORD_RULES.map((rule) => ({
      ...rule,
      passed: rule.test(password),
    }));
  }, [password]);

  const isPasswordValid = useMemo(() => passwordChecks.every((c) => c.passed), [passwordChecks]);
  const match = password && confirmPassword && password === confirmPassword;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!token) {
      toast({ title: 'Invalid link', description: 'Missing reset token. Request a new link.', variant: 'destructive' });
      return;
    }
    const errors = getPasswordErrors(password);
    if (errors.length > 0) {
      toast({
        title: 'Password does not meet requirements',
        description: errors.join('. '),
        variant: 'destructive',
      });
      return;
    }
    if (password !== confirmPassword) {
      toast({ title: 'Passwords do not match', variant: 'destructive' });
      return;
    }
    setLoading(true);
    try {
      await apiRequest('/auth/reset-password', {
        method: 'POST',
        body: { token, new_password: password },
        credentials: 'include',
        showErrorToast: false,
      });
      toast({ title: 'Password reset', description: 'You can now sign in with your new password.' });
      navigate('/auth/login');
    } catch (err) {
      toast({
        title: 'Reset failed',
        description: err.message || 'Invalid or expired link. Request a new one.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen flex bg-background items-center justify-center p-8">
        <div className="max-w-md w-full text-center">
          <h1 className="text-xl font-bold text-foreground mb-2">Invalid reset link</h1>
          <p className="text-muted-foreground mb-6">This link is missing a token. Please request a new password reset.</p>
          <Button asChild>
            <Link to="/auth/forgot-password">Request new link</Link>
          </Button>
          <div className="mt-6">
            <Link to="/auth/login" className="text-sm text-primary hover:underline">← Back to sign in</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain rounded-xl shrink-0" />
            <span className="text-2xl font-bold text-foreground">WinAssist</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">Set new password</h1>
          <p className="text-lg text-muted-foreground">
            Choose a strong password that meets the requirements shown on the form.
          </p>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2 mb-8 justify-center">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-10 h-10 object-contain rounded-lg shrink-0" />
            <span className="text-xl font-bold text-foreground">WinAssist</span>
          </div>

          <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground">Reset password</h2>
              <p className="text-muted-foreground mt-2">Enter your new password below</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-foreground">New password</Label>
                <div className="relative">
                  <Icons.lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-11"
                    required
                    minLength={8}
                    aria-invalid={password.length > 0 && !isPasswordValid}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <Icons.eyeOff className="w-5 h-5" /> : <Icons.eye className="w-5 h-5" />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mb-1.5">Password must include:</p>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  {passwordChecks.map(({ id, label, passed }) => (
                    <li key={id} className="flex items-center gap-2">
                      {passed ? (
                        <Icons.check className="w-3.5 h-3.5 text-green-600 shrink-0" />
                      ) : (
                        <span className="w-3.5 h-3.5 rounded-full border border-current shrink-0" aria-hidden />
                      )}
                      <span className={passed ? 'text-green-700 dark:text-green-400' : ''}>{label}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-foreground">Confirm password</Label>
                <div className="relative">
                  <Icons.lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="confirmPassword"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="pl-10 h-11"
                    required
                    minLength={8}
                    aria-invalid={confirmPassword.length > 0 && password !== confirmPassword}
                  />
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-xs text-destructive">Passwords do not match</p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full h-11"
                disabled={loading || !isPasswordValid || !match}
              >
                {loading ? (
                  <>
                    <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                    Resetting...
                  </>
                ) : (
                  'Reset password'
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-muted-foreground">
              <Link to="/auth/login" className="text-primary font-medium hover:underline">
                ← Back to sign in
              </Link>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
