import TextNode from './TextNode';
import InputNode from './InputNode';
import DelayNode from './DelayNode';
import AssistantNode from './AssistantNode';
import ConditionNode from './ConditionNode';
import QuickReplyNode from './QuickReplyNode';
import ContainerNode from './ContainerNode';
import BranchNode from './BranchNode';
import ImageNode from './ImageNode'
import CalendarNode from './CalendarNode';
import FormNode from './FormNode';
import SwitchNode from './SwitchNode';
import MergeNode from './MergeNode';
import DocumentNode from './DocumentNode';
import OcrNode from './OcrNode';

export const nodeTypes = {
  text: TextNode,
  input: InputNode,
  delay: DelayNode,
  assistant: AssistantNode,
  condition: ConditionNode,
  quickreply: QuickReplyNode,
  container: ContainerNode,
  branch: BranchNode,
  image: ImageNode,
  calendar: CalendarNode,
  form: FormNode,
  document: DocumentNode,
  ocr: OcrNode,
  switch: SwitchNode,
  merge: MergeNode,
};

export {
  TextNode,
  InputNode,
  DelayNode,
  AssistantNode,
  ConditionNode,
  QuickReplyNode,
  ContainerNode,
  BranchNode,
  ImageNode,
  CalendarNode,
  FormNode,
  DocumentNode,
  OcrNode,
  SwitchNode,
  MergeNode,
};

