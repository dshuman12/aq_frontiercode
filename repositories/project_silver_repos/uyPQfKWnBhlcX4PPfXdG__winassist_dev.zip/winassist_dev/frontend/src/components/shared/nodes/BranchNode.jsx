
import { memo } from 'react';
import { Position } from '@xyflow/react';
import { cn } from '../../../lib/utils';
import { DEFAULT_NODE_COLOR } from '../../../lib/flow';
import { GenericNode } from '../generic-node';

const BranchNode = memo(({ id, data, selected, width, height }) => {
  const { branchType, color = DEFAULT_NODE_COLOR } = data;

  const borderColorMap = {
    if: color,
    elseif: color,
    else: color,
    option: color,
  };

  const borderColor = borderColorMap[branchType] || color;

  const handles = [
    { type: 'target', id: 'input', position: Position.Left, style: { top: '50%' }, className: '!border-green-500' },
    { type: 'source', id: 'output', position: Position.Right, style: { top: '50%' }, className: '!border-blue-500' },
  ];

  return (
    <GenericNode
      id={id}
      data={data}
      selected={selected}
      width={width}
      height={height}
      minWidth={150}
      minHeight={96}
      handles={handles}
      resizerColor={borderColor}
      className={cn(
        'rounded-lg border-2 bg-background shadow-sm transition-all',
        selected && 'ring-2 ring-primary/30 shadow-md'
      )}
    />
  );
});

BranchNode.displayName = 'BranchNode';

export default BranchNode;

