import { NodeList } from './nodelist';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../ui/popover';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';
import { Button } from '../ui/button';

export const NodeButton = ({ className, onAddNode, nodeFilter, ...props }) => {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="default" size="sm" className={cn(className)}>
          <Icons.add className="w-7 h-7" />
          Add Node
        </Button>
      </PopoverTrigger>
      <PopoverContent
        id="agent-list"
        side="bottom"
        align="start"
        className="add-node-panel box-border h-[min(70vh,32rem)] w-[min(20rem,calc(100vw-1rem))] max-w-[calc(100vw-1rem)] overflow-y-auto overflow-x-hidden p-0 sm:w-80"
      >
        <NodeList onAddNode={onAddNode} nodeFilter={nodeFilter} />
      </PopoverContent>
    </Popover>
  );
};
