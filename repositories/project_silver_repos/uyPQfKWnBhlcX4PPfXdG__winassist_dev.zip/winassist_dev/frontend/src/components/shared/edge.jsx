import {
  BaseEdge,
  EdgeLabelRenderer,
  MarkerType,
  getBezierPath,
  getSmoothStepPath,
  useReactFlow,
} from '@xyflow/react';
import { Icons } from '../ui/icons';
import { Button } from '../ui/button';
import { cn } from '../../lib/utils';
import { useState } from 'react';

const DEFAULT_EDGE_COLOR = '#1e3a5f';

function useEdgeHandlers(id) {
  const { setEdges } = useReactFlow();
  const [isHovered, setIsHovered] = useState(false);
  const handleDelete = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setEdges((edges) => edges.filter((edge) => edge.id !== id));
  };
  return { setEdges, isHovered, setIsHovered, handleDelete };
}

export function ConverseEdge({ id, data, selected, style, ...props }) {
  const [edgePath, labelX, labelY] = getBezierPath({ ...props });
  const { isHovered, setIsHovered, handleDelete } = useEdgeHandlers(id);
  const showDeleteButton = selected || isHovered;
  const strokeColor = data?.color || DEFAULT_EDGE_COLOR;
  const activeColor = selected || isHovered ? '#2563eb' : strokeColor;
  const baseStrokeWidth = Number(data?.strokeWidth ?? style?.strokeWidth ?? 4);
  const renderedStrokeWidth = selected || isHovered
    ? Math.max(baseStrokeWidth + 1, 5)
    : baseStrokeWidth;

  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        markerEnd={{
          type: MarkerType.ArrowClosed,
          width: 18,
          height: 18,
          color: activeColor,
        }}
        style={{
          ...style,
          stroke: activeColor,
          strokeWidth: renderedStrokeWidth,
          cursor: 'pointer',
          filter: selected ? 'none' : 'drop-shadow(0 2px 6px rgba(37, 99, 235, 0.22))',
        }}
        onClick={(e) => {
          e.stopPropagation();
          // Edge selection is handled by React Flow automatically
        }}
      />
      <EdgeLabelRenderer>
        <div
          className="button-edge__label nodrag nopan"
          style={{
            position: 'absolute',
            transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            pointerEvents: 'all',
            zIndex: selected ? 10 : 5,
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="flex items-center gap-2">
            {showDeleteButton && (
              <Button
                variant="destructive"
                size="icon"
                className={cn(
                  "rounded-full border-2 bg-background text-destructive hover:bg-destructive hover:text-destructive-foreground transition-all shadow-lg animate-in fade-in zoom-in duration-200",
                  selected ? "h-8 w-8 border-destructive" : "h-7 w-7 border-border"
                )}
                onClick={handleDelete}
                title="Delete connection (or press Delete key)"
              >
                <Icons.trash className={cn(selected ? "w-4 h-4" : "w-3.5 h-3.5")} />
              </Button>
            )}
          </div>
        </div>
      </EdgeLabelRenderer>
    </>
  );
}

/** Step edge: right-angle (90°) path like in the design. Uses data.color. */
export function StepEdge({ id, data, selected, style, ...props }) {
  const [edgePath, labelX, labelY] = getSmoothStepPath({
    ...props,
    borderRadius: 18,
    offset: 20,
  });
  const { isHovered, setIsHovered, handleDelete } = useEdgeHandlers(id);
  const showDeleteButton = selected || isHovered;
  const strokeColor = data?.color || DEFAULT_EDGE_COLOR;
  const activeColor = selected || isHovered ? '#2563eb' : strokeColor;
  const baseStrokeWidth = Number(data?.strokeWidth ?? style?.strokeWidth ?? 4);
  const renderedStrokeWidth = selected || isHovered
    ? Math.max(baseStrokeWidth + 1, 5)
    : baseStrokeWidth;

  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        markerEnd={{
          type: MarkerType.ArrowClosed,
          width: 18,
          height: 18,
          color: activeColor,
        }}
        style={{
          ...style,
          stroke: activeColor,
          strokeWidth: renderedStrokeWidth,
          cursor: 'pointer',
          filter: selected ? 'none' : 'drop-shadow(0 2px 6px rgba(37, 99, 235, 0.22))',
        }}
        onClick={(e) => {
          e.stopPropagation();
        }}
      />
      <EdgeLabelRenderer>
        <div
          className="button-edge__label nodrag nopan"
          style={{
            position: 'absolute',
            transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            pointerEvents: 'all',
            zIndex: selected ? 10 : 5,
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="flex items-center gap-2">
            {showDeleteButton && (
              <Button
                variant="destructive"
                size="icon"
                className={cn(
                  'rounded-full border-2 bg-background text-destructive hover:bg-destructive hover:text-destructive-foreground transition-all shadow-lg animate-in fade-in zoom-in duration-200',
                  selected ? 'h-8 w-8 border-destructive' : 'h-7 w-7 border-border'
                )}
                onClick={handleDelete}
                title="Delete connection (or press Delete key)"
              >
                <Icons.trash className={cn(selected ? 'w-4 h-4' : 'w-3.5 h-3.5')} />
              </Button>
            )}
          </div>
        </div>
      </EdgeLabelRenderer>
    </>
  );
}
