
import React from 'react';
import { ConversableAgentConfig } from '../../backend-node/config/config';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../../lib/flow';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { Input } from '../../ui/input';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';

export const AssistantNodeConfig = ({ nodeId, data, className }) => {
  const instance = useReactFlow();
  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  return (
    <ScrollArea>
      <div className={cn('flex flex-col gap-4 p-2', className)}>
        <ConversableAgentConfig
          className="flex flex-col gap-4 p-0"
          nodeId={nodeId}
          data={data}
          toolScene={'assistant'}
        />

        <div className="rounded-md border border-border p-3 space-y-3">
          <div className="text-sm font-semibold">Assistant Context Builder</div>

          <div className="flex flex-col gap-2 text-sm">
            <Label>Context keys (one per line)</Label>
            <Textarea
              value={data?.contextKeysText || ''}
              onChange={(e) => updateNode({ contextKeysText: e.target.value })}
              placeholder={'vars.user.plan_type\nvars.user.delivery_slot\nvars.bot.welcome_message'}
              rows={4}
              className="bg-transparent w-full nodrag nowheel font-mono text-xs"
            />
            <p className="text-xs text-muted-foreground">
              Optional. These keys are included in addition to default context for assistant input.
            </p>
          </div>

          <div className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={data?.includeAllUserVars !== false}
              onChange={(e) => updateNode({ includeAllUserVars: e.target.checked })}
              className="h-4 w-4"
            />
            <Label>Include all user variables by default</Label>
          </div>

          <div className="flex flex-col gap-2 text-sm">
            <Label>Store assistant output as (variable key)</Label>
            <Input
              type="text"
              value={data?.responseVariable || ''}
              onChange={(e) => updateNode({ responseVariable: e.target.value })}
              placeholder="e.g. recipe_response"
              className="bg-transparent w-full nodrag nowheel"
            />
            <p className="text-xs text-muted-foreground">
              Assistant response is not shown directly in bot UI. It is stored in this variable key
              so you can render it later via a Text node (for example,{' '}
              <code className="bg-muted px-1 rounded">{'{{context.recipe_response}}'}</code>).
            </p>
          </div>
        </div>
      </div>
    </ScrollArea>
  );
};

AssistantNodeConfig.displayName = 'AssistantNodeConfig';

