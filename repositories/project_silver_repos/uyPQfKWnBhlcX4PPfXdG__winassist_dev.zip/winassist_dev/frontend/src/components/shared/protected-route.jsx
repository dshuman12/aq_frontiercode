import { useContext } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { AuthContext, hasAuthParams } from 'react-oidc-context';
import useUserStore from '../../store/user';
import { isOidcConfigured } from '../../common/oidc/oidc-Config';
import { hasUsableToken } from '../../lib/api-client';
import { buildLoginRedirectPath } from '../../common/oidc/navigation';

export function ProtectedRoute({ children }) {
  const { user } = useUserStore();
  const location = useLocation();
  const oidcAuth = useContext(AuthContext);
  const usingOidc = isOidcConfigured && !!oidcAuth;
  const isProcessingOidc =
    !!oidcAuth &&
    (oidcAuth.isLoading || oidcAuth.activeNavigator === 'signinRedirect' || hasAuthParams());
  const oidcHasToken = !!oidcAuth?.isAuthenticated && !!oidcAuth?.user?.access_token;
  const localHasToken = hasUsableToken(user?.token);
  const isWaitingForOidcStoreSync =
    oidcHasToken && !localHasToken;
  const isAuthenticated = usingOidc ? oidcHasToken : (localHasToken || oidcHasToken);

  if (isProcessingOidc || isWaitingForOidcStoreSync) {
    return null;
  }

  if (!isAuthenticated) {
    const returnTo = `${location.pathname}${location.search}${location.hash}`;
    return <Navigate to={buildLoginRedirectPath(returnTo)} replace />;
  }

  return children;
}

export function PublicRoute({ children }) {
  const { user } = useUserStore();
  const oidcAuth = useContext(AuthContext);
  const usingOidc = isOidcConfigured && !!oidcAuth;
  const isProcessingOidc =
    !!oidcAuth &&
    (oidcAuth.isLoading || oidcAuth.activeNavigator === 'signinRedirect' || hasAuthParams());
  const oidcHasToken = !!oidcAuth?.isAuthenticated && !!oidcAuth?.user?.access_token;
  const localHasToken = hasUsableToken(user?.token);
  const isWaitingForOidcStoreSync =
    oidcHasToken && !localHasToken;
  const isAuthenticated = usingOidc ? oidcHasToken : (localHasToken || oidcHasToken);

  if (isProcessingOidc || isWaitingForOidcStoreSync) {
    return null;
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}






