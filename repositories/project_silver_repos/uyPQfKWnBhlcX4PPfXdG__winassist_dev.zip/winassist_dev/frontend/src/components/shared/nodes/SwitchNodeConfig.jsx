import React, { useEffect, useState } from 'react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { Button } from '../../ui/button';
import { Icons } from '../../ui/icons';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Switch } from '../../ui/switch';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../../lib/flow';

export const SwitchNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();
  const [switchOn, setSwitchOn] = useState(data?.switchOn || 'context.userInput');
  const [cases, setCases] = useState(Array.isArray(data?.cases) ? data.cases : []);
  const [hasDefault, setHasDefault] = useState(data?.hasDefault !== false);

  useEffect(() => {
    setSwitchOn(data?.switchOn || 'context.userInput');
    setCases(Array.isArray(data?.cases) ? data.cases : []);
    setHasDefault(data?.hasDefault !== false);
  }, [data?.switchOn, data?.cases, data?.hasDefault]);

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  const addCase = () => {
    const next = [...cases, { value: '', label: '' }];
    setCases(next);
    updateNode({ cases: next });
  };

  const updateCase = (index, field, value) => {
    const next = [...cases];
    next[index] = { ...next[index], [field]: value };
    setCases(next);
    updateNode({ cases: next });
  };

  const removeCase = (index) => {
    const next = cases.filter((_, i) => i !== index);
    setCases(next);
    updateNode({ cases: next });

    const edges = instance.getEdges();
    const remapped = [];
    for (const edge of edges) {
      if (edge.source !== nodeId || !edge.sourceHandle?.startsWith('option-')) {
        remapped.push(edge);
        continue;
      }
      const hi = parseInt(edge.sourceHandle.split('-')[1], 10);
      if (Number.isNaN(hi)) {
        remapped.push(edge);
        continue;
      }
      if (hi === index) continue;
      if (hi > index) {
        remapped.push({ ...edge, sourceHandle: `option-${hi - 1}` });
      } else {
        remapped.push(edge);
      }
    }
    instance.setEdges(remapped);
  };

  const onToggleDefault = (checked) => {
    setHasDefault(checked);
    updateNode({ hasDefault: checked });
    if (!checked) {
      const edges = instance.getEdges();
      const filtered = edges.filter((e) => !(e.source === nodeId && e.sourceHandle === 'default'));
      if (filtered.length !== edges.length) instance.setEdges(filtered);
    }
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption type="text" nodeId={nodeId} data={data} name="name" label="Name" placeholder="Switch" />
        <GenericOption type="text" nodeId={nodeId} data={data} name="label" label="Label" placeholder="Switch route" />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Switch on</Label>
          <Input
            value={switchOn}
            onChange={(e) => {
              setSwitchOn(e.target.value);
              updateNode({ switchOn: e.target.value });
            }}
            placeholder="context.userInput"
            className="bg-transparent w-full nodrag nowheel font-mono text-xs"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center justify-between">
            <Label>Cases</Label>
            <Button size="sm" variant="outline" onClick={addCase} className="h-7">
              <Icons.add className="w-3 h-3 mr-1" />
              Add case
            </Button>
          </div>
          {cases.map((item, index) => (
            <div key={index} className="grid grid-cols-[1fr_1fr_auto] gap-2">
              <Input
                value={item.value || ''}
                onChange={(e) => updateCase(index, 'value', e.target.value)}
                placeholder='Value (e.g. "sales")'
                className="bg-transparent nodrag nowheel font-mono text-xs"
              />
              <Input
                value={item.label || ''}
                onChange={(e) => updateCase(index, 'label', e.target.value)}
                placeholder="Label (optional)"
                className="bg-transparent nodrag nowheel text-xs"
              />
              <Button size="sm" variant="ghost" onClick={() => removeCase(index)} className="h-9 w-9 p-0">
                <Icons.trash className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-sm">
          <Label>Default branch</Label>
          <Switch checked={hasDefault} onCheckedChange={onToggleDefault} />
        </div>
      </div>
    </ScrollArea>
  );
});

SwitchNodeConfig.displayName = 'SwitchNodeConfig';
