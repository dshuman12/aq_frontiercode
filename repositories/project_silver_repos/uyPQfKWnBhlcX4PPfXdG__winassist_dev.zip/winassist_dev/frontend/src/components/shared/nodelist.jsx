import React from 'react';
import { advancedNodes, basicNodes, getNodeIcon, getNodeTheme } from '../../lib/flow';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../ui/accordion';
import { cn } from '../../lib/utils';
import { PopoverClose } from '../ui/popover';

const FILTER_OPTIONS = [
  { label: 'All', value: 'All' },
  { label: '🌐 Web', value: 'Web' },
  { label: '💬 WhatsApp', value: 'WhatsApp' },
  { label: '✈️ Telegram', value: 'Telegram' },
  { label: '📸 Instagram', value: 'Instagram' },
];

const matchesCategoryFilter = (node, selectedFilter) => {
  if (node?.data?.presetSource === 'whatsapp_cloud_api' && selectedFilter !== 'WhatsApp') {
    return false;
  }

  if (selectedFilter === 'All') {
    return true;
  }

  return Array.isArray(node.category) && node.category.includes(selectedFilter);
};

const buildWhatsappCategories = (nodes) => {
  const grouped = nodes.reduce((acc, node) => {
    const key = node.group || 'WhatsApp API';
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(node);
    return acc;
  }, {});

  return Object.entries(grouped).map(([title, sectionNodes]) => ({
    title,
    nodes: sectionNodes,
  }));
};

const WHATSAPP_DESCRIPTION_PREFIXES = [
  ['send reply to ', 'Send a reply to '],
  ['send ', 'Send a WhatsApp '],
  ['get all ', 'Get all '],
  ['get ', 'Get '],
  ['create ', 'Create '],
  ['update ', 'Update '],
  ['delete ', 'Delete '],
  ['register ', 'Register '],
  ['deregister ', 'Deregister '],
  ['verify ', 'Verify '],
  ['request ', 'Request '],
  ['mark ', 'Mark '],
  ['override ', 'Override '],
  ['upload ', 'Upload '],
  ['download ', 'Download '],
  ['retrieve ', 'Retrieve '],
  ['set ', 'Set '],
  ['edit ', 'Edit '],
  ['migrate ', 'Migrate '],
  ['block ', 'Block '],
  ['unblock ', 'Unblock '],
];

const getShortDescription = (node) => {
  if (node?.data?.presetSource !== 'whatsapp_cloud_api') {
    return node.description || 'Configure this node';
  }

  const rawName = String(node.name || '').trim();
  const normalizedName = rawName.replace(/\s+/g, ' ');
  const loweredName = normalizedName.toLowerCase();

  for (const [prefix, replacement] of WHATSAPP_DESCRIPTION_PREFIXES) {
    if (loweredName.startsWith(prefix)) {
      return `${replacement}${loweredName.slice(prefix.length)}`.trim();
    }
  }

  if (node.group === 'Messages' || node.group === 'Examples') {
    return `Use this WhatsApp message action for ${loweredName}`;
  }

  if (node.group === 'Media') {
    return `Manage WhatsApp media for ${loweredName}`;
  }

  return normalizedName || 'WhatsApp API action';
};

const NodeCard = ({
  id,
  nodeType,
  name,
  description,
  class_type,
  width,
  height,
  icon,
  data,
}) => {
  const NodeIcon = icon || getNodeIcon(nodeType || id);
  const theme = getNodeTheme(nodeType || id);
  const shortDescription = getShortDescription({ id, nodeType, name, description, data });
  const onDragStart = (
    event,
    nodeData
  ) => {
    event.dataTransfer.setData('application/json', JSON.stringify(nodeData));
  };

  return (
    <div
      className={cn(
        'node-card box-border flex w-full max-w-full cursor-grab items-center justify-between gap-3 rounded-[10px] border border-border bg-card px-3 py-3 text-left transition-colors',
        'hover:bg-muted/30 active:cursor-grabbing'
      )}
      draggable
      onDragStart={(e) =>
        onDragStart(e, {
          id,
          nodeType,
          name,
          description,
          class_type,
          width,
          height,
          icon,
          data,
        })
      }
    >
      <div className="node-left flex min-w-0 flex-1 items-center gap-2.5">
        <div className="node-icon flex h-9 w-9 min-w-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
          <NodeIcon className="h-4 w-4 shrink-0" />
        </div>
        <div className="node-content flex min-w-0 flex-1 flex-col gap-0.5 overflow-hidden">
          <div className="node-title truncate text-sm font-semibold leading-5 text-foreground">{name}</div>
          <div className="node-subtitle truncate text-xs font-medium leading-4 text-muted-foreground">
            {theme.label}
          </div>
          <div className="node-description truncate text-xs leading-4 text-muted-foreground/80">
            {shortDescription}
          </div>
        </div>
      </div>
      <span className="node-action ml-2.5 shrink-0 text-xs font-medium text-muted-foreground/80">Drag</span>
    </div>
  );
};

export const NodeList = ({
  onAddNode,
  nodeFilter,
  usePopoverClose = true,
}) => {
  const [selectedFilter, setSelectedFilter] = React.useState('All');

  const filterNodes = (nodes) => nodes.filter((node) => {
    const matchesNodeFilter =
      !nodeFilter ||
      nodeFilter.length === 0 ||
      nodeFilter.includes(node.id) ||
      nodeFilter.includes(node.nodeType);
    return matchesNodeFilter && matchesCategoryFilter(node, selectedFilter);
  });

  const filteredBasicNodes = filterNodes(basicNodes);
  const filteredAdvancedNodes = filterNodes(advancedNodes);

  const nodeCategories = selectedFilter === 'WhatsApp'
    ? [
        {
          title: 'Basic',
          nodes: filteredBasicNodes,
        },
        ...buildWhatsappCategories(filteredAdvancedNodes),
      ].filter((category) => category.nodes.length > 0)
    : [
        {
          title: 'Basic',
          nodes: filteredBasicNodes,
        },
        {
          title: 'Advanced',
          nodes: filteredAdvancedNodes,
        },
      ].filter((category) => category.nodes.length > 0);

  return (
    <div className="add-node-panel box-border w-full max-w-full overflow-x-hidden p-2.5 sm:p-3 [&_*]:box-border">
      <div className="node-filters mb-2.5 flex flex-wrap gap-1.5">
        {FILTER_OPTIONS.map((filter) => (
          <button
            key={filter.value}
            type="button"
            onClick={() => setSelectedFilter(filter.value)}
            className={cn(
              'cursor-pointer rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors',
              selectedFilter === filter.value
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-border bg-background text-foreground hover:bg-muted'
            )}
            aria-pressed={selectedFilter === filter.value}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {nodeCategories.length === 0 ? (
        <div className="py-4 text-center text-sm text-muted-foreground">
          No nodes available
        </div>
      ) : (
        <Accordion
          type="multiple"
          defaultValue={nodeCategories.map(({ title }) => title)}
          className="w-full max-w-full"
        >
          {nodeCategories.map(({ title, nodes }) => (
            <AccordionItem value={title} className="border-none" key={title}>
              <AccordionTrigger className="section-title py-2 text-[13px] font-semibold text-foreground outline-none">
                {title}
              </AccordionTrigger>
              <AccordionContent className="overflow-hidden">
                <div className="flex flex-col gap-2.5">
                  {nodes.map((node) => (
                    usePopoverClose ? (
                      <PopoverClose key={node.id} onClick={() => onAddNode(node)} asChild>
                        <button type="button" className="block w-full max-w-full text-left">
                          <NodeCard {...node} />
                        </button>
                      </PopoverClose>
                    ) : (
                      <button
                        key={node.id}
                        type="button"
                        className="block w-full max-w-full text-left"
                        onClick={() => onAddNode(node)}
                      >
                        <NodeCard {...node} />
                      </button>
                    )
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      )}
    </div>
  );
};
