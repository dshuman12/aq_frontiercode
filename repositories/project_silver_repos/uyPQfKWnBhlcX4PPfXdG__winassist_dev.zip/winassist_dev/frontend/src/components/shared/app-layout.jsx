import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from 'react-oidc-context';
import { Sidebar } from './sidebar';
import { PlatformHelpBot } from './platform-help-bot';
import { APP_HEADER_HEIGHT_CLASS, APP_HEADER_PADDING_X } from './layout-constants';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';
import { ThemeToggle } from './theme-toggle';
import { useWorkspaces } from '../../hooks/workspace';
import { useUser } from '../../hooks/user';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Popover, PopoverContent, PopoverTrigger, PopoverClose } from '../ui/popover';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from '../ui/dialog';
import { apiRequest } from '../../lib/api-client';
import { toast } from '../../hooks/toast';
import useUserStore from '../../store/user';
import useWorkspaceStore from '../../store/workspace';

const ROLE_COLORS = {
  owner: 'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400',
  admin: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  member: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  viewer: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400',
};

/** Content padding aligned with sidebar: same horizontal padding for header and main */
const CONTENT_PX = APP_HEADER_PADDING_X;
const CONTENT_MAIN = 'p-4 sm:p-6';

function getWorkspaceDisplayLabel(workspace, currentUserId) {
  if (!workspace) return 'Workspace';
  const prefix = workspace.owner_id === currentUserId ? 'Personal' : 'Team';
  return `${prefix} - ${workspace.name}`;
}

function getUserDisplayName(user) {
  const fullName = [user?.first_name, user?.last_name]
    .map((value) => value?.trim())
    .filter(Boolean)
    .join(' ');

  if (fullName) return fullName;
  return user?.user_metadata?.name || user?.email || 'WinAssist user';
}

/**
 * App layout with responsive sidebar and consistent alignment.
 * - Desktop (lg+): Sidebar column + main content; header and main use same horizontal padding.
 * - Mobile: Sidebar in a left drawer; hamburger in header opens it.
 * - Uses min-h-dvh and overflow handling for zoom and different screen sizes.
 * Pass headerLeft and headerRight for the header row; both use CONTENT_PX for alignment.
 */
const SEARCH_BAR_PATHS = ['/dashboard', '/project-dashboard', '/projects', '/tools'];

export function AppLayout({ headerLeft, headerRight, children, className }) {
  const navigate = useNavigate();
  const location = useLocation();
  const oidcAuth = useContext(AuthContext);
  const pathname = location.pathname.replace(/\/$/, '') || '/';
  const showSearchBar = SEARCH_BAR_PATHS.some(
    (base) => pathname === base || pathname.startsWith(base + '/')
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createWorkspaceOpen, setCreateWorkspaceOpen] = useState(false);
  const [newWorkspaceName, setNewWorkspaceName] = useState('');
  const [createWorkspaceLoading, setCreateWorkspaceLoading] = useState(false);
  const [editWorkspaceOpen, setEditWorkspaceOpen] = useState(false);
  const [editWorkspaceId, setEditWorkspaceId] = useState(null);
  const [editWorkspaceName, setEditWorkspaceName] = useState('');
  const [editWorkspaceLoading, setEditWorkspaceLoading] = useState(false);
  const [deleteWorkspaceOpen, setDeleteWorkspaceOpen] = useState(false);
  const [deleteWorkspaceId, setDeleteWorkspaceId] = useState(null);
  const [deleteWorkspaceName, setDeleteWorkspaceName] = useState('');
  const [deleteWorkspaceLoading, setDeleteWorkspaceLoading] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const hasPageHeader = headerLeft != null || headerRight != null;
  const { user, userId: currentUserId } = useUser();
  const userDisplayName = getUserDisplayName(user);
  const { workspaces, currentWorkspace, currentWorkspaceId, setCurrentWorkspaceId, loading, fetchWorkspaces } =
    useWorkspaces();

  const clearClientSession = () => {
    if (typeof window === 'undefined') return;
    try {
      [
        'winassist-user-storage',
        'winassist-workspace-storage',
        'winassist-chats',
        'winassist-projects',
        'agentok-user-storage',
        'agentok-workspace-storage',
        'agentok-chats',
        'agentok-projects',
      ].forEach((key) => localStorage.removeItem(key));

      // react-oidc-context / oidc-client-ts stores user under keys like:
      // "oidc.user:<authority>:<client_id>" (storage backend may be localStorage/sessionStorage)
      const removeOidcKeys = (storage) => {
        if (!storage) return;
        const keysToRemove = [];
        for (let i = 0; i < storage.length; i += 1) {
          const key = storage.key(i);
          if (!key) continue;
          if (key.startsWith('oidc.user:') || key.startsWith('oidc.') || key.startsWith('oidc_')) {
            keysToRemove.push(key);
          }
        }
        keysToRemove.forEach((key) => storage.removeItem(key));
      };
      removeOidcKeys(window.localStorage);
      removeOidcKeys(window.sessionStorage);
    } catch {
      // ignore storage errors (private mode / permissions)
    }

    // Clear in-memory Zustand stores as well (avoid flicker before reload)
    try {
      useUserStore.getState().setUser(null);
      useWorkspaceStore.getState().setCurrentWorkspaceId(null);
    } catch {
      // ignore
    }
  };

  const handleLogout = async () => {
    clearClientSession();

    try {
      if (oidcAuth?.signoutRedirect) {
        await oidcAuth.signoutRedirect();
        return;
      }
    } catch {
      // Fall back to a local sign-out if the provider logout redirect fails.
    }

    try {
      if (oidcAuth?.removeUser) await oidcAuth.removeUser();
    } catch {
      // ignore
    }

    if (typeof window !== 'undefined') {
      // Home page has Login + Get Started.
      window.location.replace('/');
    }
  };

  const handleCreateWorkspace = async (e) => {
    e.preventDefault();
    const name = newWorkspaceName.trim();
    if (!name) return;

    const normalize = (s) => (s ?? '').trim().toLowerCase();
    const proposed = normalize(name);
    const duplicate = (workspaces || []).some((w) => normalize(w?.name) === proposed);
    if (duplicate) {
      toast({
        title: 'Workspace already exists',
        description: 'Workspace with same name already exists.',
        variant: 'destructive',
      });
      return;
    }

    setCreateWorkspaceLoading(true);
    try {
      const created = await apiRequest('/workspaces', {
        method: 'POST',
        body: { name },
      });
      await fetchWorkspaces({ force: true });
      if (created?.id) setCurrentWorkspaceId(created.id);
      setCreateWorkspaceOpen(false);
      setNewWorkspaceName('');
      toast({ title: 'Workspace created', description: `"${name}" is ready. You can invite members from Team.` });
    } catch (err) {
      toast({ title: 'Failed to create workspace', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setCreateWorkspaceLoading(false);
    }
  };

  const openEditWorkspace = (ws) => {
    const id = ws?.id ?? currentWorkspaceId;
    const workspace = workspaces?.find((w) => w.id === id) ?? currentWorkspace;
    setEditWorkspaceId(id);
    setEditWorkspaceName(workspace?.name ?? '');
    setEditWorkspaceOpen(true);
  };

  const openDeleteWorkspace = (ws) => {
    const id = ws?.id ?? currentWorkspaceId;
    const workspace = workspaces?.find((w) => w.id === id) ?? currentWorkspace;
    setDeleteWorkspaceId(id);
    setDeleteWorkspaceName(workspace?.name ?? 'this workspace');
    setDeleteWorkspaceOpen(true);
  };

  const handleEditWorkspace = async (e) => {
    e.preventDefault();
    const name = editWorkspaceName.trim();
    const id = editWorkspaceId ?? currentWorkspaceId;
    if (!name || !id) return;
    setEditWorkspaceLoading(true);
    try {
      await apiRequest(`/workspaces/${id}`, {
        method: 'PATCH',
        body: { name },
      });
      await fetchWorkspaces({ force: true });
      setEditWorkspaceOpen(false);
      setEditWorkspaceId(null);
      toast({ title: 'Workspace renamed', description: `Name updated to "${name}".` });
    } catch (err) {
      toast({ title: 'Failed to rename workspace', description: err.message || 'Please try again', variant: 'destructive' });
    } finally {
      setEditWorkspaceLoading(false);
    }
  };

  const handleDeleteWorkspace = async (e) => {
    e.preventDefault();
    const id = deleteWorkspaceId ?? currentWorkspaceId;
    if (!id) return;
    setDeleteWorkspaceLoading(true);
    try {
      await apiRequest(`/workspaces/${id}`, { method: 'DELETE', showErrorToast: true });
      await fetchWorkspaces({ force: true });
      setDeleteWorkspaceOpen(false);
      setDeleteWorkspaceId(null);
      toast({
        title: 'Workspace deleted',
        description: `"${deleteWorkspaceName || 'Workspace'}" has been deleted.`,
      });
    } catch (err) {
      toast({
        title: 'Failed to delete workspace',
        description: err.message || 'Please try again',
        variant: 'destructive',
      });
    } finally {
      setDeleteWorkspaceLoading(false);
    }
  };

  const WorkspacePicker = () => (
    <div className="flex items-center gap-2 rounded-xl border border-border/70 bg-background/80 px-3 py-2 shadow-sm backdrop-blur">
      <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground shrink-0">
        Workspace
      </span>
      {loading ? (
        <span className="text-xs text-muted-foreground">Loading...</span>
      ) : workspaces?.length > 0 ? (
        <div className="flex items-center gap-1.5">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                className="h-9 w-52 justify-between rounded-xl px-2 font-normal text-sm cursor-pointer"
              >
                <span className="truncate text-left">
                  {getWorkspaceDisplayLabel(currentWorkspace, currentUserId)}
                </span>
                <Icons.chevronDown className="h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" side="bottom" sideOffset={6} className="w-72 rounded-2xl border-border/70 p-2 shadow-xl z-[100]">
              <div className="max-h-80 overflow-y-auto">
                {workspaces.map((ws) => (
                    <div
                      key={ws.id}
                      className={cn(
                        'flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm transition-colors',
                        currentWorkspaceId === ws.id
                          ? 'bg-primary/10 text-foreground'
                          : 'hover:bg-muted/60'
                      )}
                    >
                      <PopoverClose asChild>
                        <button
                          type="button"
                          className="min-w-0 flex-1 flex items-center gap-2 text-left"
                          onClick={() => setCurrentWorkspaceId(ws.id)}
                        >
                          <span className="truncate">
                            {getWorkspaceDisplayLabel(ws, currentUserId)}
                            {ws.owner_id !== currentUserId && ws.owner_email
                              ? ` (${ws.owner_email})`
                              : ''}
                          </span>
                          {ws.role && (
                            <span
                              className={cn(
                                'shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-medium capitalize',
                                ROLE_COLORS[ws.role] || ROLE_COLORS.viewer
                              )}
                            >
                              {ws.role}
                            </span>
                          )}
                        </button>
                      </PopoverClose>
                      {ws.role === 'owner' && (
                        <div className="flex items-center gap-1 shrink-0">
                          <PopoverClose asChild>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 rounded-lg"
                              onClick={(e) => {
                                e.stopPropagation();
                                openEditWorkspace(ws);
                              }}
                              title={`Rename ${ws.name}`}
                              aria-label={`Rename ${ws.name}`}
                            >
                              <Icons.edit className="h-3.5 w-3.5" />
                            </Button>
                          </PopoverClose>
                          {String(ws?.name || '')
                            .trim()
                            .toLowerCase() !== 'personal workspace' && (
                            <PopoverClose asChild>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 rounded-lg text-destructive hover:text-destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openDeleteWorkspace(ws);
                                }}
                                title={`Delete ${ws.name}`}
                                aria-label={`Delete ${ws.name}`}
                              >
                                <Icons.trash className="h-3.5 w-3.5" />
                              </Button>
                            </PopoverClose>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
              </div>
              <div className="mt-2 border-t border-border/70 pt-2">
                <PopoverClose asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="w-full rounded-xl"
                    onClick={() => setCreateWorkspaceOpen(true)}
                  >
                    <Icons.add className="h-4 w-4 mr-1.5" />
                    Create workspace
                  </Button>
                </PopoverClose>
              </div>
            </PopoverContent>
          </Popover>
          {currentWorkspace?.role && (
            <span
              className={cn(
                'hidden xl:inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium capitalize',
                ROLE_COLORS[currentWorkspace.role] || ROLE_COLORS.viewer
              )}
            >
              {currentWorkspace.role}
            </span>
          )}
        </div>
      ) : !loading ? (
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-9 rounded-xl text-xs"
          onClick={() => setCreateWorkspaceOpen(true)}
        >
          <Icons.add className="h-4 w-4 mr-1" />
          Create workspace
        </Button>
      ) : null}
    </div>
  );

  return (
    <div className={cn('flex h-dvh min-h-dvh w-full overflow-hidden bg-app', className)}>
      <Sidebar mobileOpen={mobileMenuOpen} onMobileOpenChange={setMobileMenuOpen} />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Always-visible top bar with workspace selector */}
        <div
          className={cn(
            'w-full shrink-0 border-b border-border/70 bg-background/95 backdrop-blur',
            'hidden lg:flex lg:items-center lg:justify-between lg:gap-3',
            APP_HEADER_HEIGHT_CLASS,
            CONTENT_PX,
            hasPageHeader ? '' : ''
          )}
        >
            <div className="flex min-w-0 flex-1 items-center justify-between gap-3">
            <div className="flex min-w-0 flex-1 items-center gap-4">
              {headerLeft}
              {showSearchBar && (
                <div className="relative w-full max-w-sm min-w-[180px]">
                  <Icons.search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    placeholder="Search analytics, projects, tools..."
                    className="h-11 rounded-2xl border-border/70 bg-muted/40 pl-10 pr-4 shadow-sm"
                  />
                </div>
              )}
            </div>
            <div className="hidden sm:flex items-center gap-2 shrink-0">
              <WorkspacePicker />
              <ThemeToggle />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 rounded-xl border-border/70"
                    title="Help / Support"
                    aria-label="Help / Support"
                  >
                    <Icons.help className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-72 rounded-2xl border-border/70 p-4 shadow-xl">
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-foreground">Help / Support</div>
                      <div className="text-xs leading-5 text-muted-foreground">
                        Support actions can be expanded here later for docs, tickets, and onboarding help.
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full justify-between rounded-xl"
                      onClick={() => navigate('/help-support')}
                    >
                      Open help center
                      <Icons.arrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className="h-10 w-10 rounded-full border-border/70 p-0 shadow-sm"
                    title="Open profile menu"
                    aria-label="Open profile menu"
                  >
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {(userDisplayName || 'U').slice(0, 1).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-72 rounded-2xl border-border/70 p-4 shadow-xl">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user?.user_metadata?.avatar_url} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {(userDisplayName || 'U').slice(0, 1).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-foreground">
                          {userDisplayName}
                        </div>
                        <div className="truncate text-xs text-muted-foreground">
                          {user?.email || 'Signed in'}
                        </div>
                      </div>
                    </div>
                    <div className="border-t border-border/70" />
                    <div className="rounded-2xl border border-border/70 bg-muted/30 p-3">
                      <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                        Active Workspace
                      </div>
                      <div className="mt-1 text-sm font-medium text-foreground">
                        {currentWorkspace?.name || 'Personal workspace'}
                      </div>
                    </div>
                    <div className="border-t border-border/70" />
                    <div className="space-y-2">
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl"
                        onClick={() => navigate('/settings')}
                      >
                        Settings
                        <Icons.settings className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl"
                        onClick={() => navigate('/billing')}
                      >
                        Billing
                        <Icons.billing className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl text-red-600 hover:bg-red-500/10 hover:text-red-700"
                        onClick={handleLogout}
                      >
                        Logout
                        <Icons.logout className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              {headerRight != null && <div className="shrink-0">{headerRight}</div>}
            </div>
          </div>
        </div>
        <div
          className={cn(
            'w-full border-b border-border/70 bg-background/95 backdrop-blur lg:hidden',
            CONTENT_PX
          )}
        >
          {/* Mobile: show workspace picker and page actions in their own rows */}
          <div className="flex w-full flex-col gap-2 py-3 sm:hidden">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="shrink-0"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open menu"
              >
                <Icons.menu className="h-5 w-5" />
              </Button>
              <div className="min-w-0 flex-1">
                {headerLeft}
              </div>
            </div>
            {showSearchBar && (
              <div className="relative">
                <Icons.search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  placeholder="Search..."
                  className="h-10 rounded-xl border-border/70 bg-muted/40 pl-10"
                />
              </div>
            )}
            <WorkspacePicker />
            <div className="flex w-full flex-wrap items-center justify-start gap-2">
              <ThemeToggle compact />
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 rounded-xl border-border/70"
                    title="Help / Support"
                    aria-label="Help / Support"
                  >
                    <Icons.help className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-72 rounded-2xl border-border/70 p-4 shadow-xl">
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-foreground">Help / Support</div>
                      <div className="text-xs leading-5 text-muted-foreground">
                        Support actions can be expanded here later for docs, tickets, and onboarding help.
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full justify-between rounded-xl"
                      onClick={() => navigate('/help-support')}
                    >
                      Open help center
                      <Icons.arrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className="h-10 w-10 rounded-full border-border/70 p-0 shadow-sm"
                    title="Open profile menu"
                    aria-label="Open profile menu"
                  >
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {(userDisplayName || 'U').slice(0, 1).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-72 rounded-2xl border-border/70 p-4 shadow-xl">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user?.user_metadata?.avatar_url} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {(userDisplayName || 'U').slice(0, 1).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-foreground">
                          {userDisplayName}
                        </div>
                        <div className="truncate text-xs text-muted-foreground">
                          {user?.email || 'Signed in'}
                        </div>
                      </div>
                    </div>
                    <div className="border-t border-border/70" />
                    <div className="rounded-2xl border border-border/70 bg-muted/30 p-3">
                      <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                        Active Workspace
                      </div>
                      <div className="mt-1 text-sm font-medium text-foreground">
                        {currentWorkspace?.name || 'Personal workspace'}
                      </div>
                    </div>
                    <div className="border-t border-border/70" />
                    <div className="space-y-2">
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl"
                        onClick={() => navigate('/settings')}
                      >
                        Settings
                        <Icons.settings className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl"
                        onClick={() => navigate('/billing')}
                      >
                        Billing
                        <Icons.billing className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full justify-between rounded-xl text-red-600 hover:bg-red-500/10 hover:text-red-700"
                        onClick={handleLogout}
                      >
                        Logout
                        <Icons.logout className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              {headerRight != null ? (
                <div className="flex w-full flex-wrap items-center justify-start gap-2">
                {headerRight}
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <main className={cn('flex-1 overflow-y-auto overflow-x-hidden min-h-0', CONTENT_MAIN)}>
          {children}
        </main>
        <footer className="w-full border-t border-border/80 bg-background px-4 py-3 text-center text-[11px] font-semibold tracking-wide text-foreground/80">
          <span className="text-xs">WinAssist @2026 Powered by WeWinLimited</span>
        </footer>
      </div>
      <PlatformHelpBot />

      <Dialog open={createWorkspaceOpen} onOpenChange={setCreateWorkspaceOpen}>
        <DialogContent className="bg-background border-border">
          <DialogHeader>
            <DialogTitle>Create workspace</DialogTitle>
            <DialogDescription>
              Create a new workspace to organize projects and invite team members.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateWorkspace} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="workspace-name">Workspace name</Label>
              <Input
                id="workspace-name"
                value={newWorkspaceName}
                onChange={(e) => setNewWorkspaceName(e.target.value)}
                placeholder="e.g. Marketing, Engineering"
                className="bg-background"
                autoFocus
                disabled={createWorkspaceLoading}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setCreateWorkspaceOpen(false)}
                disabled={createWorkspaceLoading}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={createWorkspaceLoading || !newWorkspaceName.trim()}>
                {createWorkspaceLoading ? (
                  <>
                    <Icons.spinner className="h-4 w-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={editWorkspaceOpen}
        onOpenChange={(open) => {
          setEditWorkspaceOpen(open);
          if (!open) setEditWorkspaceId(null);
        }}
      >
        <DialogContent className="bg-background border-border">
          <DialogHeader>
            <DialogTitle>Rename workspace</DialogTitle>
            <DialogDescription>
              Change the workspace name. Only the owner can rename this workspace.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditWorkspace} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-workspace-name">Workspace name</Label>
              <Input
                id="edit-workspace-name"
                value={editWorkspaceName}
                onChange={(e) => setEditWorkspaceName(e.target.value)}
                placeholder="e.g. Marketing, Engineering"
                className="bg-background"
                autoFocus
                disabled={editWorkspaceLoading}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setEditWorkspaceOpen(false)}
                disabled={editWorkspaceLoading}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={editWorkspaceLoading || !editWorkspaceName.trim()}>
                {editWorkspaceLoading ? (
                  <>
                    <Icons.spinner className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleteWorkspaceOpen}
        onOpenChange={(open) => {
          setDeleteWorkspaceOpen(open);
          if (!open) setDeleteWorkspaceId(null);
        }}
      >
        <DialogContent className="bg-background border-border">
          <DialogHeader>
            <DialogTitle>Delete workspace</DialogTitle>
            <DialogDescription>
              This will permanently delete the workspace and all projects inside it. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleDeleteWorkspace} className="space-y-4">
            <div className="rounded-xl border border-border/70 bg-muted/30 p-3 text-sm">
              <div className="font-medium text-foreground">Workspace</div>
              <div className="text-muted-foreground">{deleteWorkspaceName || '—'}</div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDeleteWorkspaceOpen(false)}
                disabled={deleteWorkspaceLoading}
              >
                Cancel
              </Button>
              <Button type="submit" variant="destructive" disabled={deleteWorkspaceLoading}>
                {deleteWorkspaceLoading ? (
                  <>
                    <Icons.spinner className="h-4 w-4 mr-2 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  'Delete'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
