import { useEffect } from 'react';
import useThemeStore, { THEME_STORAGE_KEY } from '../../store/theme';

export function ThemeProvider({ children }) {
  const hydrateTheme = useThemeStore((state) => state.hydrateTheme);

  useEffect(() => {
    hydrateTheme();

    const handleStorage = (event) => {
      if (event.key === THEME_STORAGE_KEY) {
        hydrateTheme();
      }
    };

    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [hydrateTheme]);

  return children;
}
