import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from '../../hooks/toast';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../ui/icons';
import { WINASSIST_LOGO_URL } from '../../lib/config';
import { copyTextToClipboard } from '../../lib/utils';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [resetLink, setResetLink] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResetLink(null);
    setSent(false);
    try {
      const data = await apiRequest('/auth/forgot-password', {
        method: 'POST',
        body: { email },
        credentials: 'include',
        showErrorToast: false,
      });
      setSent(true);
      if (data.token) {
        const base = typeof window !== 'undefined' ? window.location.origin : '';
        setResetLink(`${base}/auth/reset-password?token=${encodeURIComponent(data.token)}`);
        toast({
          title: 'Use the link below',
          description: 'Email could not be sent. Copy or open the link below to reset your password.',
        });
      } else {
        setResetLink(null);
        toast({
          title: 'Check your email',
          description: 'If an account exists with this email, we sent you a link to reset your password.',
        });
      }
    } catch (err) {
      toast({
        title: 'Request failed',
        description: err.message || 'Could not send reset link.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain rounded-xl shrink-0" />
            <span className="text-2xl font-bold text-foreground">WinAssist</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">Reset your password</h1>
          <p className="text-lg text-muted-foreground">
            Enter your email and we’ll send you a link to set a new password.
          </p>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2 mb-8 justify-center">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-10 h-10 object-contain rounded-lg shrink-0" />
            <span className="text-xl font-bold text-foreground">WinAssist</span>
          </div>

          <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground">Forgot password</h2>
              <p className="text-muted-foreground mt-2">Enter your email to get a reset link</p>
            </div>

            {!sent ? (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-foreground">Email</Label>
                  <div className="relative">
                    <Icons.mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@company.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 h-11"
                      required
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full h-11" disabled={loading}>
                  {loading ? (
                    <>
                      <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send reset link'
                  )}
                </Button>
              </form>
            ) : (
              <div className="space-y-4">
                {resetLink ? (
                  <>
                    <p className="text-sm text-muted-foreground">
                      Email could not be sent (SMTP may not be configured). Use the link below to reset your password. The link expires in 1 hour.
                    </p>
                    <div className="space-y-2">
                      <Label className="text-foreground">Reset link</Label>
                      <div className="flex gap-2">
                        <Input readOnly value={resetLink} className="text-xs font-mono" />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={async () => {
                            try {
                              await copyTextToClipboard(resetLink);
                              toast({ title: 'Link copied', description: 'Paste it in your browser to reset.' });
                            } catch {
                              toast({ title: 'Copy failed', variant: 'destructive' });
                            }
                          }}
                        >
                          <Icons.copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <Button asChild className="w-full">
                        <a href={resetLink}>Open reset page</a>
                      </Button>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    If an account exists for <strong className="text-foreground">{email}</strong>, we’ve sent you an email with a link to reset your password. Check your inbox (and spam folder). The link expires in 1 hour.
                  </p>
                )}
                <Button variant="ghost" className="w-full" onClick={() => { setSent(false); setResetLink(null); }}>
                  Use a different email
                </Button>
              </div>
            )}

            <div className="mt-6 text-center text-sm text-muted-foreground">
              <Link to="/auth/login" className="text-primary font-medium hover:underline">
                ← Back to sign in
              </Link>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
