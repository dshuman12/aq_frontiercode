import React from 'react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { GenericOption } from '../option';
import { Label } from '../../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../../lib/flow';

export const MergeNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption type="text" nodeId={nodeId} data={data} name="name" label="Name" placeholder="Merge" />
        <GenericOption type="text" nodeId={nodeId} data={data} name="label" label="Label" placeholder="Join branches" />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Merge mode</Label>
          <Select value={data?.mergeMode || 'first-arrival'} onValueChange={(value) => updateNode({ mergeMode: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Choose merge mode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="first-arrival">First arrival</SelectItem>
              <SelectItem value="wait-all">Wait all incoming</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </ScrollArea>
  );
});

MergeNodeConfig.displayName = 'MergeNodeConfig';
