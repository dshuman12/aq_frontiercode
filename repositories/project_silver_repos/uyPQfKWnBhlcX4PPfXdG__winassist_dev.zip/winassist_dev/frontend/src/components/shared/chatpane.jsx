import { useCallback, useEffect, useRef, useState } from 'react';
import { useChats } from '../../hooks/chat';
import { useUser } from '../../hooks/user';
import { useProjects } from '../../hooks/project';
import { useChat } from '../../hooks/chat';
import useUserStore from '../../store/user';
import { Icons } from '../ui/icons';
import { ChatInput } from '../ui/chatinput';
import { MessageList } from '../ui/messagelist';
import { useToast } from '../../hooks/toast';
import { Loading } from '../ui/loading';
import {ScrollArea} from '../ui/scrollarea'
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { genId } from '../../lib/id';
import { cn } from '../../lib/utils';
import { apiRequest, streamSSE } from '../../lib/api-client';
import { ChatList } from './chatlist';
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from '../ui/resize';

const looksLikeRawPayload = (value) => {
  const text = String(value || '').trim();
  if (!text) return false;
  if (text.startsWith('{"kwargs"') || text.startsWith("{'query':") || text.startsWith('{"query":')) {
    return true;
  }
  return text.includes('knowledge_source') || text.includes('chunk_index') || text.includes('density_score');
};

const summarizeTraceMetadata = (metadata) => {
  if (!metadata || typeof metadata !== 'object') return [];
  const items = [];
  if (metadata.type) items.push(`type: ${metadata.type}`);
  if (metadata.query) items.push(`query: ${String(metadata.query).slice(0, 80)}`);
  if (metadata.knowledge_source) items.push(`source: ${metadata.knowledge_source}`);
  if (metadata.top_k) items.push(`top_k: ${metadata.top_k}`);
  if (metadata.chunk_size) items.push(`chunk_size: ${metadata.chunk_size}`);
  if (metadata.chunk_overlap) items.push(`overlap: ${metadata.chunk_overlap}`);
  if (metadata.guidance_by_caller && typeof metadata.guidance_by_caller === 'object') {
    items.push(`guided callers: ${Object.keys(metadata.guidance_by_caller).length}`);
  }
  if (metadata.approval_required_by_caller && typeof metadata.approval_required_by_caller === 'object') {
    const approvals = Object.values(metadata.approval_required_by_caller).filter(Boolean).length;
    items.push(`approval-required callers: ${approvals}`);
  }
  if (Array.isArray(metadata.matches)) {
    items.push(`matches: ${metadata.matches.length}`);
  }
  return items;
};

export const ChatPane = ({ projectId, chatId, onChatIdChange }) => {
  const [currentChatId, setCurrentChatId] = useState(chatId);
  const { chat, isLoading: isLoadingChat, updateChat } = useChat(currentChatId);
  const { createChat, isCreating, setActiveChatId } = useChats();
  const { projects } = useProjects();
  const { toast } = useToast();
  const [messages, setMessages] = useState([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const isFirstRender = useRef(true);
  const messagesEndRef = useRef(null);
  const { user } = useUser();
  const [uploading, setUploading] = useState(false);
  const [uploadedDocs, setUploadedDocs] = useState([]);
  const [toolFile, setToolFile] = useState(null);
  const [showChatList, setShowChatList] = useState(true);
  const [traceOpen, setTraceOpen] = useState(false);
  const [traceLogs, setTraceLogs] = useState([]);
  const [isLoadingTrace, setIsLoadingTrace] = useState(false);

  const handleUpload = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('title', file.name);
      const json = await apiRequest('/knowledge/uploads', {
        method: 'POST',
        body: form,
        showErrorToast: false,
      });
      setUploadedDocs((docs) => [{ id: json.id, title: json.title }, ...docs]);
      toast({ title: 'Uploaded', description: `${file.name} is ready for RAG` });
      e.target.value = '';
    } catch (err) {
      toast({ 
        title: 'Upload error', 
        description: err instanceof Error ? err.message : 'Failed', 
        variant: 'destructive' 
      });
    } finally {
      setUploading(false);
    }
  }, [toast]);

  const handleToolFileChange = useCallback((e) => {
    const file = e.target.files?.[0] || null;
    setToolFile(file);
  }, []);

  const fetchTraceLogs = useCallback(async () => {
    if (!currentChatId || currentChatId === -1) return;
    setIsLoadingTrace(true);
    try {
      const logs = await apiRequest(`/chats/${currentChatId}/logs`, {
        method: 'GET',
        showErrorToast: false,
      });
      setTraceLogs(Array.isArray(logs) ? logs : []);
    } catch (err) {
      console.error('Failed to fetch trace logs:', err);
      toast({
        title: 'Trace load failed',
        description: err instanceof Error ? err.message : 'Failed to load chat traces',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingTrace(false);
    }
  }, [currentChatId, toast]);

  const handleOpenTrace = useCallback(async () => {
    setTraceOpen(true);
    await fetchTraceLogs();
  }, [fetchTraceLogs]);

  // ✅ Fetch chat messages
  const fetchMessages = useCallback(async () => {
    if (chatId === -1 || !chat) return;
    
    setIsLoadingMessages(true);
    try {
      const json = await apiRequest(`/chats/${chatId}/messages`, {
        method: 'GET',
        showErrorToast: false,
      });
      
      if (!json || json.length === 0) {
        setMessages([]);
        setIsLoadingMessages(false);
        return;
      }
      
      // Filter to keep only the last assistant message per conversation turn
      // Group messages by conversation turns (user message + assistant responses)
      const filtered = [];
      let lastAssistantMessage = null;
      let lastUserMessageTime = null;
      
      for (const msg of json) {
        if (msg.type === 'user') {
          // When we see a user message, add the previous assistant message (if any)
          if (lastAssistantMessage) {
            filtered.push(lastAssistantMessage);
            lastAssistantMessage = null;
          }
          filtered.push(msg);
          lastUserMessageTime = new Date(msg.created_at);
        } else if (msg.type === 'assistant' && msg.content) {
          if (msg.sender === 'User' || msg.metadata?.tool_info || looksLikeRawPayload(msg.content)) {
            continue;
          }
          // Filter out status-only messages
          const content = msg.content
            .replace(/__STATUS_WAIT_FOR_HUMAN_INPUT__/g, '')
            .replace(/__STATUS_RECEIVED_HUMAN_INPUT__/g, '')
            .replace(/__STATUS_COMPLETED__/g, '')
            .trim();
          
          if (content && content !== 'DONE') {
            // Keep only the last assistant message (most recent one)
            lastAssistantMessage = { ...msg, content };
          }
        } else if (msg.type === 'summary' || msg.type === 'error') {
          // Always keep summaries and errors
          if (lastAssistantMessage) {
            filtered.push(lastAssistantMessage);
            lastAssistantMessage = null;
          }
          filtered.push(msg);
        } else {
          // Keep status messages and other types
          filtered.push(msg);
        }
      }
      
      // Add the last assistant message if there's one remaining
      if (lastAssistantMessage) {
        filtered.push(lastAssistantMessage);
      }
      
      // Sort by created_at
      filtered.sort((a, b) => {
        return new Date(a.created_at) - new Date(b.created_at);
      });
      
      setMessages(filtered);
    } catch (err) {
      if (err.message && !err.message.includes('404')) {
        console.error('Failed to fetch messages:', err);
      }
    } finally {
      setIsLoadingMessages(false);
    }
  }, [chatId, chat]);

  // ✅ Fetch messages when chat changes
  useEffect(() => {
    setCurrentChatId(chatId);
    
    if (chatId === -1 || !chat) {
      setMessages([]);
      return;
    }

    fetchMessages();
  }, [chatId, chat, fetchMessages]);

  // ✅ Scroll behavior
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    if (isFirstRender.current) {
      messagesEndRef.current?.scrollIntoView();
      isFirstRender.current = false;
    } else {
      scrollToBottom();
    }
  }, [messages, scrollToBottom]);

  // ✅ Send message with async/await (NO POLLING)
  const handleSend = useCallback(
    async (message) => {
      const trimmedMessage = message.trim();
      
      if (!trimmedMessage || trimmedMessage.length === 0) {
        toast({
          title: 'Invalid message',
          description: 'Message cannot be empty',
          variant: 'destructive',
        });
        return;
      }

      if (!chat) {
        console.error('❌ No chat available');
        return;
      }

      const tempMessage = {
        id: genId(),
        chat_id: chatId,
        type: 'user',
        sender: user?.email,
        content: trimmedMessage,
        created_at: new Date().toISOString(),
        user: {
          email: user?.email,
          avatar_url: user?.avatar_url || null,
        },
      };

      try {
        // Set sending state
        setIsSending(true);

        // Optimistic UI update
        setMessages((msgs) => [...msgs, tempMessage]);

        const chatStatus = chat?.status?.toLowerCase() || 'idle';
        let endpoint;

        if (chatStatus === 'running') {
          toast({
            title: 'Agent is running',
            description: 'Please wait until the agent completes.',
          });
          setMessages((msgs) => msgs.filter((m) => m.id !== tempMessage.id));
          return;
        } else if (chatStatus === 'wait_for_human_input' || chatStatus === 'waiting') {
          // Only use /input endpoint if chat is actively waiting for input
          endpoint = `/chats/${chatId}/input`;
        } else {
          // For idle, completed, aborted, or failed status, start a new chat session
          endpoint = `/chats/${chatId}/messages`;
        }

        // Upload tool attachment first (optional)
        let attachmentMeta = undefined;
        if (toolFile) {
          const form = new FormData();
          form.append('file', toolFile);
          form.append('title', toolFile.name);
          attachmentMeta = await apiRequest('/tools/attachments', {
            method: 'POST',
            body: form,
            showErrorToast: false,
          });
          setToolFile(null); // Clear after upload
        }

        const payload = {
          type: 'user',
          content: trimmedMessage,
          sender: user?.email || 'unknown',
          user_id: user?.id,
          meta: attachmentMeta ? {
            attachment_path: attachmentMeta.path,
            attachment_name: attachmentMeta.filename,
            attachment_mime: attachmentMeta.mime,
          } : undefined,
        };

        // Handle SSE stream for /messages endpoint
        if (endpoint.includes('/messages')) {
          let streamCompleted = false;
          let hasReceivedMessage = false;
          let lastAssistantMessage = null; // Track the last assistant message
          
          await streamSSE(
            endpoint,
            {
              method: 'POST',
              body: payload,
              showErrorToast: false,
            },
            (data) => {
              // Handle error messages
              if (data.type === 'error') {
                throw new Error(data.content || 'An error occurred');
              }

              if (data.answer) {
                const content = String(data.answer || '').trim();
                if (!content) return;
                lastAssistantMessage = {
                  content,
                  sender: 'assistant',
                  receiver: 'user',
                };
                return;
              }
              
              // Handle completion
              if (data.type === 'done' || (data.content && data.content.includes('__STATUS_COMPLETED__'))) {
                streamCompleted = true;
                
                // Add the last assistant message when stream completes
                if (lastAssistantMessage) {
                  const content = lastAssistantMessage.content
                    .replace(/__STATUS_WAIT_FOR_HUMAN_INPUT__/g, '')
                    .replace(/__STATUS_RECEIVED_HUMAN_INPUT__/g, '')
                    .replace(/__STATUS_COMPLETED__/g, '')
                    .trim();
                  
                  if (content) {
                    hasReceivedMessage = true;
                    
                    setMessages((msgs) => {
                      // Remove any previous assistant messages from this chat session
                      const filtered = msgs.filter(
                        (m) => !(m.type === 'assistant' && m.chat_id === chatId && 
                                new Date(m.created_at) > new Date(Date.now() - 30000)) // Last 30 seconds
                      );
                      
                      // Add the last assistant message
                      const newMsg = {
                        id: genId(),
                        chat_id: chatId,
                        type: 'assistant',
                        content: content,
                        sender: lastAssistantMessage.sender || 'assistant',
                        receiver: lastAssistantMessage.receiver || 'user',
                        created_at: new Date().toISOString(),
                      };
                      
                      return [...filtered, newMsg];
                    });
                  }
                }
                return;
              }
              
              // Handle assistant messages - just track the last one, don't add yet
              if (data.type === 'assistant' && data.content) {
                if (data.sender === 'User' || looksLikeRawPayload(data.content)) {
                  return;
                }
                // Filter out status prefixes and empty messages
                let content = data.content
                  .replace(/__STATUS_WAIT_FOR_HUMAN_INPUT__/g, '')
                  .replace(/__STATUS_RECEIVED_HUMAN_INPUT__/g, '')
                  .replace(/__STATUS_COMPLETED__/g, '')
                  .trim();
                
                // Skip if content is empty after removing status prefixes
                if (!content) {
                  return;
                }
                
                // Store as the last assistant message (will be added when stream completes)
                lastAssistantMessage = {
                  content: content,
                  sender: data.sender || 'assistant',
                  receiver: data.receiver || 'user',
                };
              } else if (data.content && (
                data.content.includes('__STATUS_WAIT_FOR_HUMAN_INPUT__')
              )) {
                // Status message - update chat status but don't add as message
                if (chat) {
                  updateChat({
                    status: 'wait_for_human_input'
                  });
                }
              }
            }
          );
          
          // After stream completes, wait a bit then fetch all messages to ensure consistency
          // This ensures any messages that were saved to DB but missed in SSE are loaded
          if (hasReceivedMessage) {
            // Small delay to ensure DB is updated
            await new Promise(resolve => setTimeout(resolve, 500));
            await fetchMessages();
            toast({
              title: 'Message sent',
              description: 'Response received successfully',
            });
          } else {
            // If no messages received via SSE, fetch from DB (might be a delay)
            await fetchMessages();
          }
        } else {
          // For /input endpoint, use regular API request
        const responseData = await apiRequest(endpoint, {
          method: 'POST',
          body: payload,
          showErrorToast: false,
        });
        
        if (responseData && responseData.error) {
          throw new Error(responseData.error);
        }

          // After response, fetch updated messages
        await fetchMessages();

        toast({
          title: 'Message sent',
          description: 'Response received successfully',
        });
        }

      } catch (err) {
        console.error('Failed to send message:', err);
        toast({
          title: 'Error',
          description: err instanceof Error ? err.message : 'Failed to send message',
          variant: 'destructive',
        });
        // Remove optimistic message on error
        setMessages((msgs) => msgs.filter((m) => m.id !== tempMessage.id));
        await fetchMessages();
      } finally {
        setIsSending(false);
      }
    },
    [chatId, chat, user, toast, fetchMessages, toolFile]
  );

  // ✅ Start a new chat
  const handleStartChat = useCallback(async () => {
    try {
      const newChat = await createChat(projectId, 'project');
      setMessages([]);
      setCurrentChatId(newChat.id);
      setActiveChatId(newChat.id);
      if (onChatIdChange) {
        onChatIdChange(newChat.id);
      }
    } catch (err) {
      console.error('Failed to start chat:', err);
      toast({
        title: 'Error',
        description: 'Failed to start new chat',
        variant: 'destructive',
      });
    }
  }, [projectId, createChat, toast, setActiveChatId, onChatIdChange]);

  // ✅ Handle chat selection from list
  const handleChatSelect = useCallback((selectedChatId) => {
    setCurrentChatId(selectedChatId);
    setActiveChatId(selectedChatId);
    if (onChatIdChange) {
      onChatIdChange(selectedChatId);
    }
  }, [setActiveChatId, onChatIdChange]);

  // ✅ Update currentChatId when chatId prop changes
  useEffect(() => {
    if (chatId !== currentChatId) {
      setCurrentChatId(chatId);
    }
  }, [chatId]);

  const handleReset = useCallback(() => setMessages([]), []);

  // ✅ Abort chat
  const handleAbort = useCallback(async () => {
    try {
      // Update UI immediately
      if (updateChat) {
        updateChat({ status: 'aborted' });
      }
      
      // Call abort endpoint
      const result = await apiRequest(`/chats/${chatId}/abort`, {
        method: 'POST',
        showErrorToast: false,
      });
      
      if (updateChat) {
        updateChat({ status: 'aborted' });
      }
      
      toast({
        title: 'Agent Stopped',
        description: result.detail || 'Agent successfully terminated',
      });
      
      // Refresh messages
      await fetchMessages();
    } catch (err) {
      if (updateChat) {
        updateChat({ status: 'aborted' });
      }
      
      toast({
        title: 'Agent Stop Requested',
        description: err instanceof Error ? err.message : 'Force stop command sent',
        variant: 'destructive',
      });
    }
  }, [chatId, updateChat, toast, fetchMessages]);

  // 🟡 Empty state
  if (!chat && !isLoadingChat) {
    return (
      <div className="flex flex-col w-full h-full bg-muted items-center justify-center gap-2 text-muted-foreground/50">
        <Icons.agent className="w-8 h-8" />
        <p>Let's start chatting!</p>
        <Button onClick={handleStartChat} disabled={isCreating}>
          {isCreating && <Icons.spinner className="w-4 h-4 animate-spin mr-2" />}
          Start Chat
        </Button>
      </div>
    );
  }

  const sampleMessages = chat?.sample_messages || [];

  return (
    <>
    <div className="flex flex-col w-full h-full bg-muted">
      {/* Chat List Toggle Button */}
      <div className="flex items-center justify-between p-2 border-b bg-background">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowChatList(!showChatList)}
            className="h-7"
          >
            <Icons.chat className="w-4 h-4 mr-1" />
            <span className="text-xs">Threads</span>
            {showChatList ? (
              <Icons.chevronLeft className="w-3 h-3 ml-1" />
            ) : (
              <Icons.chevronRight className="w-3 h-3 ml-1" />
            )}
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleStartChat}
          disabled={isCreating}
          className="h-7 text-xs"
        >
          {isCreating ? (
            <>
              <Icons.spinner className="w-3 h-3 mr-1 animate-spin" />
              Creating...
            </>
          ) : (
            <>
              {Icons.add && <Icons.add className="w-3 h-3 mr-1" />}
              New Thread
            </>
          )}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleOpenTrace}
          disabled={!currentChatId || currentChatId === -1}
          className="h-7 text-xs"
        >
          <Icons.logs className="w-3 h-3 mr-1" />
          Traces
        </Button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Chat List Sidebar */}
        {showChatList && (
          <>
            <div className="w-64 border-r bg-background flex flex-col">
              <ChatList
                projectId={projectId}
                activeChatId={currentChatId}
                onChatSelect={handleChatSelect}
              />
            </div>
          </>
        )}

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
      {isLoadingMessages ? (
        <div className="flex justify-center items-center flex-1">
          <Loading />
        </div>
      ) : messages.length > 0 ? (
        <ScrollArea className="flex flex-col max-w-full w-full flex-1 p-2 pb-1 [&_[data-radix-scroll-area-viewport]>div]:!max-w-full">
          <div className="flex flex-col w-full gap-1 max-w-full">
            <MessageList
              chat={chat}
              messages={messages}
              className="max-w-4xl mx-auto"
            />
            <div className="flex justify-center gap-2 p-1 items-center">
              <Badge 
                variant="outline" 
                className={cn(
                  "text-xs",
                  chat?.status === 'running' && "bg-yellow-500/20 text-yellow-600 border-yellow-500/50",
                  chat?.status === 'completed' && "bg-green-500/20 text-green-600 border-green-500/50",
                  chat?.status === 'aborted' && "bg-red-500/20 text-red-600 border-red-500/50",
                  chat?.status === 'failed' && "bg-red-500/20 text-red-600 border-red-500/50"
                )}
              >
                {chat?.status || 'idle'}
              </Badge>

              {/* Abort Button */}
              {(chat?.status === 'running' || chat?.status === 'wait_for_human_input') && (
                <Button
                  variant="outline"
                  size="sm"
                  type="button"
                  onClick={handleAbort}
                  className="text-xs h-6 bg-red-500 hover:bg-red-600 active:bg-red-700 text-white border-red-500 font-semibold"
                >
                  <Icons.stop className="w-3 h-3 mr-1" />
                  Stop Agent
                </Button>
              )}

              {/* Sending indicator */}
              {isSending && (
                <Badge variant="outline" className="text-xs">
                  <Icons.spinner className="w-3 h-3 mr-1 animate-spin" />
                  Sending...
                </Badge>
              )}
            </div>
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      ) : (
        <div className="flex flex-col items-center justify-center h-full gap-2 text-muted-foreground/50">
          <Icons.agent className="w-8 h-8" />
          <p>No messages yet. Start chatting below!</p>
        </div>
      )}

      <div className="relative flex flex-col gap-1 w-full max-w-4xl mx-auto p-2 pt-0">
        <ChatInput
              chatId={currentChatId}
          onSend={handleSend}
          onReset={handleReset}
          disabled={currentChatId === -1 || !chat || isSending}
          className="w-full"
          sampleMessages={sampleMessages}
        />
          </div>
        </div>
      </div>
    </div>
    <Dialog open={traceOpen} onOpenChange={setTraceOpen}>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Chat Traces</DialogTitle>
          <DialogDescription>
            Inspect planner guidance, runtime events, and chat logs for the current thread.
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center justify-between gap-2">
          <Badge variant="outline" className="text-xs">
            Chat #{currentChatId}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchTraceLogs}
            disabled={isLoadingTrace}
          >
            {isLoadingTrace ? (
              <Icons.spinner className="w-3 h-3 mr-1 animate-spin" />
            ) : (
              <Icons.refresh className="w-3 h-3 mr-1" />
            )}
            Refresh
          </Button>
        </div>
        <ScrollArea className="flex-1 border rounded-md p-3 bg-background">
          <div className="space-y-3">
            {isLoadingTrace ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icons.spinner className="w-4 h-4 animate-spin" />
                Loading traces...
              </div>
            ) : traceLogs.length === 0 ? (
              <p className="text-sm text-muted-foreground">No trace logs available for this chat yet.</p>
            ) : (
              traceLogs.map((log) => (
                <div key={log.id} className="rounded-md border p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant="outline" className="text-[10px] uppercase">
                      {log.level || 'info'}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {log.created_at || ''}
                    </span>
                  </div>
                  <p className="text-sm font-medium break-words">{log.message}</p>
                  {summarizeTraceMetadata(log.metadata).length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {summarizeTraceMetadata(log.metadata).map((item) => (
                        <Badge key={item} variant="outline" className="text-[10px]">
                          {item}
                        </Badge>
                      ))}
                    </div>
                  )}
                  {log.metadata?.type === 'planner_context' && log.metadata?.guidance_by_caller && (
                    <div className="rounded border bg-muted/30 p-2">
                      <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Planner Guidance
                      </div>
                      <div className="space-y-2">
                        {Object.entries(log.metadata.guidance_by_caller).map(([caller, guidance]) => (
                          <div key={caller} className="rounded bg-background p-2 text-xs">
                            <div className="font-medium">{caller}</div>
                            <pre className="mt-1 whitespace-pre-wrap break-all text-[11px]">
                              {typeof guidance === 'string' ? guidance : JSON.stringify(guidance, null, 2)}
                            </pre>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {log.metadata && (
                    <pre className="text-xs overflow-auto rounded bg-muted p-2 whitespace-pre-wrap break-all">
                      {JSON.stringify(log.metadata, null, 2)}
                    </pre>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
    </>
  );
};