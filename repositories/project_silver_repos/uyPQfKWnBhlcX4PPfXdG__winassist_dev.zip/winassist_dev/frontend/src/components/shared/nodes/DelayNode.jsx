import { memo } from 'react';
import { GenericNode } from '../generic-node';

const DelayNode = memo(({ id, data, selected, width, height, ...props }) => {
  const delay = data.delayMs || 1000;

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data.id || 'delay',
        name: data.name || data.label || 'Delay',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="rounded-md border border-border/70 bg-background px-3 py-2">
        <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          Wait
        </div>
        <div className="mt-1 text-xs font-medium text-foreground">
          {delay} ms
        </div>
      </div>
    </GenericNode>
  );
});

DelayNode.displayName = 'DelayNode';

export default DelayNode;

