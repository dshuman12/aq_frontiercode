import { memo, useMemo } from 'react';
import { Position } from '@xyflow/react';
import { cn } from '../../../lib/utils';
import { DEFAULT_NODE_COLOR } from '../../../lib/flow';
import { GenericNode } from '../generic-node';

const ROW_HEIGHT = 28;
const ROW_GAP = 4;
const HEADER_HEIGHT = 40;
const CONTENT_PADDING_TOP = 10;
const CONTENT_PADDING_BOTTOM = 14;

const SwitchNode = memo(({ id, data, selected, width, height }) => {
  const { handles, computedHeight } = useMemo(() => {
    const cases = Array.isArray(data?.cases) ? data.cases : [];
    const hasDefault = data?.hasDefault !== false;
    const totalOut = Math.max(1, cases.length + (hasDefault ? 1 : 0));
    const contentHeight = totalOut * ROW_HEIGHT + (totalOut - 1) * ROW_GAP;
    const totalHeight = HEADER_HEIGHT + CONTENT_PADDING_TOP + contentHeight + CONTENT_PADDING_BOTTOM;
    const truncate = (s, max = 26) => (String(s || '').length > max ? String(s).slice(0, max) + '...' : String(s || ''));

    const outHandles = [];
    for (let i = 0; i < totalOut; i++) {
      const rowCenterY = HEADER_HEIGHT + CONTENT_PADDING_TOP + i * (ROW_HEIGHT + ROW_GAP) + ROW_HEIGHT / 2;
      const topPct = (rowCenterY / totalHeight) * 100;
      const isDefaultRow = hasDefault && i === totalOut - 1;
      if (isDefaultRow) {
        outHandles.push({
          type: 'source',
          id: 'default',
          position: Position.Right,
          style: { top: `${topPct}%` },
          className: '!border-blue-500',
          label: 'Default',
        });
      } else {
        const caseExpr = cases[i]?.value || '';
        outHandles.push({
          type: 'source',
          id: `option-${i}`,
          position: Position.Right,
          style: { top: `${topPct}%` },
          className: '!border-blue-500',
          label: caseExpr ? `Case ${truncate(caseExpr)}` : `Case ${i + 1}`,
        });
      }
    }

    return {
      handles: [
        { type: 'target', id: 'input', position: Position.Left, style: { top: '50%' }, className: '!border-green-500' },
        ...outHandles,
      ],
      computedHeight: totalHeight,
    };
  }, [data?.cases, data?.hasDefault]);

  const nodeColor = data?.color || DEFAULT_NODE_COLOR;

  return (
    <GenericNode
      id={id}
      data={data}
      selected={selected}
      width={width}
      height={computedHeight}
      minWidth={190}
      minHeight={computedHeight}
      handles={handles}
      resizerColor={nodeColor}
      className={cn(
        'rounded-lg border-2 bg-background shadow-sm transition-all',
        selected && 'ring-2 ring-primary/30 shadow-md'
      )}
    />
  );
});

SwitchNode.displayName = 'SwitchNode';

export default SwitchNode;
