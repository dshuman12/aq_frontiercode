import { useState } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { useAuth } from 'react-oidc-context';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from '../../hooks/toast';
import useUserStore from '../../store/user';
import useWorkspaceStore from '../../store/workspace';
import { apiRequest } from '../../lib/api-client';
import { Icons } from '../ui/icons';
import { WINASSIST_LOGO_URL } from '../../lib/config';
import { isOidcConfigured } from '../../common/oidc/oidc-Config';
import { buildOidcSigninArgs, resolvePostLoginPath } from '../../common/oidc/navigation';

export default function LoginPage() {
  const auth = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirectTo = searchParams.get('redirect');
  const prompt = searchParams.get('prompt');
  const setUser = useUserStore((state) => state.setUser);

  const oidcLoginLoading = isOidcConfigured && (auth.isLoading || auth.activeNavigator === 'signinRedirect');

  const handleOidcLogin = async () => {
    try {
      // This performs a real browser redirect and auto-adds PKCE/state/nonce.
      await auth.signinRedirect(
        buildOidcSigninArgs({
          returnTo: redirectTo,
          prompt: prompt || 'login',
        })
      );
    } catch (err) {
      toast({
        title: 'Keycloak login failed',
        description: err?.message || 'Could not redirect to Keycloak',
        variant: 'destructive',
      });
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        body: { email, password },
        credentials: 'include',
        showErrorToast: false,
      });
     
      setUser({ ...data.user, token: data.token });
      toast({ title: 'Logged in successfully' });
      await useWorkspaceStore.getState().fetchWorkspaces();
      navigate(resolvePostLoginPath(redirectTo), { replace: true });
    } catch (err) {
      toast({ 
        title: 'Login failed', 
        description: err.message || 'Invalid email or password', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain rounded-xl shrink-0" />
            <span className="text-2xl font-bold text-foreground">WinAssist</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Welcome back
          </h1>
          <p className="text-lg text-muted-foreground">
            Sign in to continue building amazing AI-powered applications with our no-code platform.
          </p>
        </div>
      </div>

      {/* Right side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-2 mb-8 justify-center">
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-10 h-10 object-contain rounded-lg shrink-0" />
            <span className="text-xl font-bold text-foreground">WinAssist</span>
          </div>

          <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground">Sign in</h2>
              <p className="text-muted-foreground mt-2">
                {isOidcConfigured ? 'Continue with Keycloak to access your account' : 'Enter your credentials to access your account'}
              </p>
            </div>

            {isOidcConfigured ? (
              <div className="space-y-3">
                <Button type="button" className="w-full h-11" onClick={handleOidcLogin} disabled={oidcLoginLoading}>
                  {oidcLoginLoading ? (
                    <>
                      <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                      Redirecting...
                    </>
                  ) : (
                    'Continue with Keycloak'
                  )}
                </Button>
              </div>
            ) : (
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <div className="relative">
                  <Icons.mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-11"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-foreground">Password</Label>
                  <Link
                    to="/auth/forgot-password"
                    className="text-xs text-primary hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <div className="relative">
                  <Icons.lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-11"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? (
                      <Icons.eyeOff className="w-5 h-5" />
                    ) : (
                      <Icons.eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              <Button type="submit" className="w-full h-11" disabled={loading}>
                {loading ? (
                  <>
                    <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign in'
                )}
              </Button>
            </form>
            )}

            <div className="mt-6 text-center text-sm text-muted-foreground">
              Don't have an account?{' '}
              <Link to={redirectTo ? `/auth/register?redirect=${encodeURIComponent(redirectTo)}` : '/auth/register'} className="text-primary font-medium hover:underline">
                Create account
              </Link>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
