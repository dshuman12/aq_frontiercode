import { memo } from 'react';
import { GenericNode } from '../generic-node';

const TextNode = memo(({ id, data, selected, width, height, ...props }) => {
  const preview = data.text || 'No text';
  const truncated = preview.length > 50 ? preview.substring(0, 50) + '...' : preview;

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data.id || 'text',
        name: data.name || data.label || 'Text',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="rounded-md border border-border/70 bg-background px-3 py-2">
        <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          Message
        </div>
        <div className="mt-1 text-xs font-medium text-foreground break-words">
          {truncated}
        </div>
      </div>
    </GenericNode>
  );
});

TextNode.displayName = 'TextNode';

export default TextNode;

