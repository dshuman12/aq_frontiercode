import { cn } from '../../lib/utils';

/**
 * Page header for use inside the main content area (not in navbar).
 * Renders title, optional description, optional icon or left slot, and optional actions on the right.
 */
export function PageHeader({ title, description, icon: Icon, leftSlot, actions, className }) {
  return (
    <header className={cn('flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between', className)}>
      <div className="flex min-w-0 items-center gap-3 sm:gap-4">
        {leftSlot}
        {Icon ? (
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Icon className="h-5 w-5" />
          </div>
        ) : null}
        <div className="min-w-0">
          <h1 className="truncate text-xl font-semibold tracking-tight text-foreground sm:text-2xl">
            {title}
          </h1>
          {description != null && description !== '' ? (
            <p className="mt-0.5 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
              {description}
            </p>
          ) : null}
        </div>
      </div>
      {actions ? <div className="shrink-0 flex flex-wrap items-center gap-2">{actions}</div> : null}
    </header>
  );
}
