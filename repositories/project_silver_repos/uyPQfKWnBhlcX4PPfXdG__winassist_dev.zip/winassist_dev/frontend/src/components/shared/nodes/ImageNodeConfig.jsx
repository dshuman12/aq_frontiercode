import React from 'react'
import { ScrollArea } from '../../ui/scrollarea'
import { cn } from '../../../lib/utils'
import { GenericOption } from '../option'
import { Input } from '../../ui/input'
import { Label } from '../../ui/label'
import { Textarea } from '../../ui/textarea'
import { useReactFlow } from '@xyflow/react'
import { setNodeData } from '../../../lib/flow'

export const ImageNodeConfig = React.memo(({ nodeId, data, className, ...props }) => {
  const instance = useReactFlow()

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates)
  }

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        {/* General Options */}
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="Image Node"
        />

        {/* Image URL */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Image URL</Label>
          <Input
            type="text"
            value={data?.imageUrl || ''}
            onChange={(e) => updateNode({ imageUrl: e.target.value })}
            placeholder="Paste an image URL (supports {{context.*}} variables)"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Use <code className="bg-muted px-1 rounded">{'{{context.variableName}}'}</code> to insert dynamic values.
          </p>
        </div>

        {/* Alt text */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Alt Text</Label>
          <Input
            type="text"
            value={data?.altText || ''}
            onChange={(e) => updateNode({ altText: e.target.value })}
            placeholder="e.g., product screenshot"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        {/* Caption (optional) */}
        <div className="flex flex-col gap-2 text-sm">
          <Label>Caption (optional)</Label>
          <Textarea
            value={data?.caption || ''}
            onChange={(e) => updateNode({ caption: e.target.value })}
            placeholder="Optional text shown under the image. Supports {{context.*}}."
            rows={3}
            className="bg-transparent w-full nodrag nowheel font-mono text-xs"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Store as (variable key)</Label>
          <Input
            type="text"
            value={data?.storeAs || ''}
            onChange={(e) => updateNode({ storeAs: e.target.value })}
            placeholder="e.g. product_image_card"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Variable namespace</Label>
          <Input
            type="text"
            value={data?.storeNamespace || 'bot'}
            onChange={(e) => updateNode({ storeNamespace: e.target.value || 'bot' })}
            placeholder="bot / user / api / flow"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>
      </div>
    </ScrollArea>
  )
})

ImageNodeConfig.displayName = 'ImageNodeConfig'

